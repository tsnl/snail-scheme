(module
 (rec
  (type $top-scalar (struct (field i32) (field i64)))
  (type $top-reference (struct (field i32) (field eqref)))
  (type $call0 (func (param eqref i64 f64) (result f64)))
  (type $type0 (struct (field (ref $call0)) (field eqref)))
  (type $call1 (func (param eqref f64 i64) (result f64)))
  (type $type1 (struct (field (ref $call1)) (field eqref)))
  (type $call2 (func (param eqref i64 f64) (result i32)))
  (type $type2 (struct (field (ref $call2)) (field eqref)))
  (type $call3 (func (param eqref f64 i64) (result i32)))
  (type $type3 (struct (field (ref $call3)) (field eqref)))
  (type $call4 (func (param eqref) (result i32)))
  (type $type4 (struct (field (ref $call4)) (field eqref)))
  (type $call5 (func (param eqref) (result i64)))
  (type $type5 (struct (field (ref $call5)) (field eqref)))
  (type $call6 (func (param eqref) (result f32)))
  (type $type6 (struct (field (ref $call6)) (field eqref)))
  (type $call7 (func (param eqref) (result f64)))
  (type $type7 (struct (field (ref $call7)) (field eqref)))
  (type $call8 (func (param eqref) (result i32)))
  (type $type8 (struct (field (ref $call8)) (field eqref)))
  (type $call9 (func (param eqref) (result i32)))
  (type $type9 (struct (field (ref $call9)) (field eqref)))
  (type $call10 (func (param eqref) (result i32)))
  (type $type10 (struct (field (ref $call10)) (field eqref)))
  (type $call11 (func (param eqref (ref null $type12)) (result (ref $type34))))
  (type $type11 (struct (field (ref $call11)) (field eqref)))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $type13 (sub (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type15 (sub $type13 (struct (field i32) (field i32))))
  (type $type16 (sub $type13 (struct (field i32) (field i32))))
  (type $type17 (sub $type13 (struct (field i32) (field (ref $type18)))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
  (type $type20 (array (mut (ref null $type19))))
  (type $type21 (sub $type13 (struct (field i32) (field (ref $type22)))))
  (type $type22 (struct (field i32)))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $type24 (sub (struct (field i32))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $type26 (sub $type24 (struct (field i32) (field f64))))
  (type $type27 (sub $type24 (struct (field i32) (field (ref $type28)) (field (ref $type28)))))
  (type $type28 (sub (struct (field i32))))
  (type $type29 (sub $type28 (struct (field i32) (field i64))))
  (type $type30 (sub $type28 (struct (field i32) (field f64))))
  (type $type31 (sub $type13 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $type32 (struct (field (mut (ref $type13)))))
  (type $type33 (sub $type13 (struct (field i32) (field (ref $type34)))))
  (type $type34 (array (mut (ref $type13))))
  (type $type35 (sub $type13 (struct (field i32) (field (ref $type36)))))
  (type $type36 (struct (field i32) (field (ref $type37))))
  (type $type37 (array (mut i8)))
  (type $call38 (func (param eqref (ref null $type12)) (result (ref $type34))))
  (type $type38 (struct (field (ref $call38)) (field eqref)))
  (type $call39 (func (param eqref (ref null $type40)) (result i64)))
  (type $type39 (struct (field (ref $call39)) (field eqref)))
  (type $type40 (struct (field i32) (field (ref null $type40))))
  (type $call41 (func (param eqref (ref null $type12)) (result i64)))
  (type $type41 (struct (field (ref $call41)) (field eqref)))
  (type $call42 (func (param eqref (ref $type34)) (result (ref $type34))))
  (type $type42 (struct (field (ref $call42)) (field eqref)))
  (type $call43 (func (param eqref i64) (result (ref $type18))))
  (type $type43 (struct (field (ref $call43)) (field eqref)))
  (type $call44 (func (param eqref (ref null $type40)) (result (ref $type18))))
  (type $type44 (struct (field (ref $call44)) (field eqref)))
  (type $call45 (func (param eqref (ref null $type40)) (result (ref $type18))))
  (type $type45 (struct (field (ref $call45)) (field eqref)))
  (type $call46 (func (param eqref (ref $type18)) (result (ref null $type40))))
  (type $type46 (struct (field (ref $call46)) (field eqref)))
  (type $call47 (func (param eqref (ref $type18) i64 i64) (result (ref $type18))))
  (type $type47 (struct (field (ref $call47)) (field eqref)))
  (type $call48 (func (param eqref (ref $type18)) (result (ref $type18))))
  (type $type48 (struct (field (ref $call48)) (field eqref)))
  (type $call49 (func (param eqref (ref null $type50)) (result (ref $type18))))
  (type $type49 (struct (field (ref $call49)) (field eqref)))
  (type $type50 (struct (field (ref $type18)) (field (ref null $type50))))
  (type $call51 (func (param eqref (ref null $type50)) (result i64)))
  (type $type51 (struct (field (ref $call51)) (field eqref)))
  (type $call52 (func (param eqref (ref $type18) (ref null $type50) i64) (result i32)))
  (type $type52 (struct (field (ref $call52)) (field eqref)))
  (type $call53 (func (param eqref (ref $type18) (ref $type18)) (result i32)))
  (type $type53 (struct (field (ref $call53)) (field eqref)))
  (type $call54 (func (param eqref i64) (result (ref $type36))))
  (type $type54 (struct (field (ref $call54)) (field eqref)))
  (type $call55 (func (param eqref (ref null $type56)) (result (ref $type36))))
  (type $type55 (struct (field (ref $call55)) (field eqref)))
  (type $type56 (struct (field i64) (field (ref null $type56))))
  (type $call57 (func (param eqref (ref null $type56)) (result i64)))
  (type $type57 (struct (field (ref $call57)) (field eqref)))
  (type $call58 (func (param eqref i64 i64 i64) (result i32)))
  (type $type58 (struct (field (ref $call58)) (field eqref)))
  (type $call59 (func (param eqref (ref $type36) i64 (ref $type36) i64) (result i32)))
  (type $type59 (struct (field (ref $call59)) (field eqref)))
  (type $call60 (func (param eqref (ref $type36) i64 (ref $type36)) (result i32)))
  (type $type60 (struct (field (ref $call60)) (field eqref)))
  (type $call61 (func (param eqref (ref $type36) i64 i64) (result (ref $type36))))
  (type $type61 (struct (field (ref $call61)) (field eqref)))
  (type $call62 (func (param eqref (ref $type36) i64) (result (ref $type36))))
  (type $type62 (struct (field (ref $call62)) (field eqref)))
  (type $call63 (func (param eqref (ref $type36)) (result (ref $type36))))
  (type $type63 (struct (field (ref $call63)) (field eqref)))
  (type $call64 (func (param eqref (ref null $type65)) (result (ref $type36))))
  (type $type64 (struct (field (ref $call64)) (field eqref)))
  (type $type65 (struct (field (ref $type36)) (field (ref null $type65))))
  (type $call66 (func (param eqref (ref null $type65)) (result i64)))
  (type $type66 (struct (field (ref $call66)) (field eqref)))
  (type $call67 (func (param eqref i64) (result i64)))
  (type $type67 (struct (field (ref $call67)) (field eqref)))
  (type $call68 (func (param eqref (ref $type36) i64 i64) (result i64)))
  (type $type68 (struct (field (ref $call68)) (field eqref)))
  (type $call69 (func (param eqref (ref $type36) i64) (result i64)))
  (type $type69 (struct (field (ref $call69)) (field eqref)))
  (type $call70 (func (param eqref (ref $type36) i64 i64) (result i32)))
  (type $type70 (struct (field (ref $call70)) (field eqref)))
  (type $call71 (func (param eqref (ref $type18) (ref $type36) i64 i64) (result i32)))
  (type $type71 (struct (field (ref $call71)) (field eqref)))
  (type $call72 (func (param eqref (ref $type36) i64 i64) (result (ref $type18))))
  (type $type72 (struct (field (ref $call72)) (field eqref)))
  (type $call73 (func (param eqref (ref $type36) i64) (result (ref $type18))))
  (type $type73 (struct (field (ref $call73)) (field eqref)))
  (type $call74 (func (param eqref (ref $type36)) (result (ref $type18))))
  (type $type74 (struct (field (ref $call74)) (field eqref)))
  (type $call75 (func (param eqref (ref $type18) i64 i64) (result i64)))
  (type $type75 (struct (field (ref $call75)) (field eqref)))
  (type $call76 (func (param eqref (ref $type36) i64 i64 i64) (result i32)))
  (type $type76 (struct (field (ref $call76)) (field eqref)))
  (type $call77 (func (param eqref (ref $type36) (ref $type18) i64 i64) (result i32)))
  (type $type77 (struct (field (ref $call77)) (field eqref)))
  (type $call78 (func (param eqref (ref $type18) i64 i64) (result (ref $type36))))
  (type $type78 (struct (field (ref $call78)) (field eqref)))
  (type $call79 (func (param eqref (ref $type18) i64) (result (ref $type36))))
  (type $type79 (struct (field (ref $call79)) (field eqref)))
  (type $call80 (func (param eqref (ref $type18)) (result (ref $type36))))
  (type $type80 (struct (field (ref $call80)) (field eqref)))
  (type $call81 (func (param eqref (ref $type18)) (result i32)))
  (type $type81 (struct (field (ref $call81)) (field eqref)))
  (type $call82 (func (param eqref (ref $type18))))
  (type $type82 (struct (field (ref $call82)) (field eqref)))
  (type $call83 (func (param eqref (ref $type18)) (result i32)))
  (type $type83 (struct (field (ref $call83)) (field eqref)))
  (type $call84 (func (param eqref (ref $type18)) (result (ref $type22))))
  (type $type84 (struct (field (ref $call84)) (field eqref)))
  (type $call85 (func (param eqref (ref $type22) (ref $type22)) (result i32)))
  (type $type85 (struct (field (ref $call85)) (field eqref)))
  (type $call86 (func (param eqref (ref $type22)) (result (ref $type18))))
  (type $type86 (struct (field (ref $call86)) (field eqref)))
  (type $call87 (func (param eqref (ref $type28)) (result f64)))
  (type $type87 (struct (field (ref $call87)) (field eqref)))
  (type $call88 (func (param eqref (ref $type24)) (result f64)))
  (type $type88 (struct (field (ref $call88)) (field eqref)))
  (type $call89 (func (param eqref i32 i32) (result (ref $type28))))
  (type $type89 (struct (field (ref $call89)) (field eqref)))
  (type $call90 (func (param eqref i32) (result (ref $type18))))
  (type $type90 (struct (field (ref $call90)) (field eqref)))
  (type $call91 (func (param eqref i32 i32) (result (ref $type92))))
  (type $type91 (struct (field (ref $call91)) (field eqref)))
  (type $type92 (sub (struct (field i32))))
  (type $type93 (sub $type92 (struct (field i32))))
  (type $type94 (sub $type92 (struct (field i32) (field (ref $type24)))))
  (type $type95 (sub $type92 (struct (field i32) (field (ref $type18)))))
  (type $call96 (func (param eqref (ref $type18)) (result (ref $type92))))
  (type $type96 (struct (field (ref $call96)) (field eqref)))
  (type $call97 (func (param eqref (ref $type28) (ref $type28)) (result i32)))
  (type $type97 (struct (field (ref $call97)) (field eqref)))
  (type $call98 (func (param eqref (ref $type24)) (result i64)))
  (type $type98 (struct (field (ref $call98)) (field eqref)))
  (type $call99 (func (param eqref (ref $type24) (ref $type24)) (result i32)))
  (type $type99 (struct (field (ref $call99)) (field eqref)))
  (type $call100 (func (param eqref i32 i32) (result (ref $type101))))
  (type $type100 (struct (field (ref $call100)) (field eqref)))
  (type $type101 (sub (struct (field i32))))
  (type $type102 (sub $type101 (struct (field i32))))
  (type $type103 (sub $type101 (struct (field i32) (field (ref $type13)))))
  (type $type104 (sub $type101 (struct (field i32) (field (ref $type18)))))
  (type $call105 (func (param eqref (ref $type18)) (result (ref $type101))))
  (type $type105 (struct (field (ref $call105)) (field eqref)))
  (type $call106 (func (param eqref (ref $type13) (ref $type13)) (result (ref $type13))))
  (type $type106 (struct (field (ref $call106)) (field eqref)))
  (type $call107 (func (param eqref (ref $type13)) (result (ref $type13))))
  (type $type107 (struct (field (ref $call107)) (field eqref)))
  (type $call108 (func (param eqref (ref $type13) (ref $type13)) (result i32)))
  (type $type108 (struct (field (ref $call108)) (field eqref)))
  (type $call109 (func (param eqref (ref $type13)) (result i64)))
  (type $type109 (struct (field (ref $call109)) (field eqref)))
  (type $call110 (func (param eqref (ref $type13)) (result i32)))
  (type $type110 (struct (field (ref $call110)) (field eqref)))
  (type $call111 (func (param eqref (ref $type13) (ref $type13)) (result i32)))
  (type $type111 (struct (field (ref $call111)) (field eqref)))
  (type $call112 (func (param eqref (ref null $type12)) (result (ref $type13))))
  (type $type112 (struct (field (ref $call112)) (field eqref)))
  (type $call113 (func (param eqref (ref $type107) (ref $type13)) (result (ref $type13))))
  (type $type113 (struct (field (ref $call113)) (field eqref)))
  (type $call114 (func (param eqref (ref $type34) (ref $type34)) (result i32)))
  (type $type114 (struct (field (ref $call114)) (field eqref)))
  (type $call115 (func (param eqref (ref $type36) (ref $type36)) (result i32)))
  (type $type115 (struct (field (ref $call115)) (field eqref)))
  (type $call116 (func (param eqref (ref $type18)) (result i32)))
  (type $type116 (struct (field (ref $call116)) (field eqref)))
  (type $call117 (func (param eqref (ref $type18)) (result (ref $type118))))
  (type $type117 (struct (field (ref $call117)) (field eqref)))
  (type $type118 (struct (field (ref $type119))))
  (type $type119 (struct (field (mut i32))))
  (type $call120 (func (param eqref (ref $type18)) (result (ref $type121))))
  (type $type120 (struct (field (ref $call120)) (field eqref)))
  (type $type121 (struct (field (ref $type119))))
  (type $call122 (func (param eqref (ref $type118)) (result i32)))
  (type $type122 (struct (field (ref $call122)) (field eqref)))
  (type $call123 (func (param eqref (ref $type121)) (result i32)))
  (type $type123 (struct (field (ref $call123)) (field eqref)))
  (type $call124 (func (param eqref (ref $type119)) (result i32)))
  (type $type124 (struct (field (ref $call124)) (field eqref)))
  (type $call125 (func (param eqref (ref $type18) (ref $type126)) (result i32)))
  (type $type125 (struct (field (ref $call125)) (field eqref)))
  (type $call126 (func (param eqref (ref $type121)) (result i32)))
  (type $type126 (struct (field (ref $call126)) (field eqref)))
  (type $call127 (func (param eqref (ref $type18) (ref $type128)) (result i64)))
  (type $type127 (struct (field (ref $call127)) (field eqref)))
  (type $call128 (func (param eqref (ref $type121)) (result i64)))
  (type $type128 (struct (field (ref $call128)) (field eqref)))
  (type $call129 (func (param eqref (ref $type130)) (result i32)))
  (type $type129 (struct (field (ref $call129)) (field eqref)))
  (type $type130 (sub (struct (field i32))))
  (type $type131 (sub $type130 (struct (field i32))))
  (type $type132 (sub $type130 (struct (field i32) (field i32))))
  (type $call133 (func (param eqref i32) (result (ref $type130))))
  (type $type133 (struct (field (ref $call133)) (field eqref)))
  (type $call134 (func (param eqref (ref $type121)) (result (ref $type130))))
  (type $type134 (struct (field (ref $call134)) (field eqref)))
  (type $call135 (func (param eqref (ref $type136)) (result i32)))
  (type $type135 (struct (field (ref $call135)) (field eqref)))
  (type $type136 (sub (struct (field i32))))
  (type $type137 (sub $type136 (struct (field i32))))
  (type $type138 (sub $type136 (struct (field i32) (field (ref $type18)))))
  (type $call139 (func (param eqref (ref $type121)) (result (ref $type136))))
  (type $type139 (struct (field (ref $call139)) (field eqref)))
  (type $call140 (func (param eqref i32) (result i32)))
  (type $type140 (struct (field (ref $call140)) (field eqref)))
  (type $call141 (func (param eqref i32 i32 (ref $type18) i64) (result (ref $type18))))
  (type $type141 (struct (field (ref $call141)) (field eqref)))
  (type $call142 (func (param eqref (ref $type18) i64) (result (ref $type18))))
  (type $type142 (struct (field (ref $call142)) (field eqref)))
  (type $call143 (func (param eqref i32 (ref $type118)) (result i32)))
  (type $type143 (struct (field (ref $call143)) (field eqref)))
  (type $call144 (func (param eqref (ref $type18) (ref $type118)) (result i32)))
  (type $type144 (struct (field (ref $call144)) (field eqref)))
  (type $call145 (func (param eqref i64 (ref $type118)) (result i32)))
  (type $type145 (struct (field (ref $call145)) (field eqref)))
  (type $call146 (func (param eqref (ref $type101)) (result i32)))
  (type $type146 (struct (field (ref $call146)) (field eqref)))
  (type $call147 (func (param eqref (ref $type101)) (result (ref $type13))))
  (type $type147 (struct (field (ref $call147)) (field eqref)))
  (type $call148 (func (param eqref (ref $type121)) (result (ref $type101))))
  (type $type148 (struct (field (ref $call148)) (field eqref)))
  (type $call149 (func (param eqref (ref $type130)) (result i64)))
  (type $type149 (struct (field (ref $call149)) (field eqref)))
  (type $call150 (func (param eqref i64 i32) (result i32)))
  (type $type150 (struct (field (ref $call150)) (field eqref)))
  (type $call151 (func (param eqref (ref $type121) i32) (result i32)))
  (type $type151 (struct (field (ref $call151)) (field eqref)))
  (type $call152 (func (param eqref i64) (result i32)))
  (type $type152 (struct (field (ref $call152)) (field eqref)))
  (type $call153 (func (param eqref) (result (ref $type154))))
  (type $type153 (struct (field (ref $call153)) (field eqref)))
  (type $type154 (struct (field (ref $type155)) (field (ref $type156))))
  (type $type155 (struct (field (mut (ref $type18)))))
  (type $type156 (struct (field (mut i64))))
  (type $call157 (func (param eqref (ref $type154) i32) (result i32)))
  (type $type157 (struct (field (ref $call157)) (field eqref)))
  (type $call158 (func (param eqref (ref $type154) i64) (result i32)))
  (type $type158 (struct (field (ref $call158)) (field eqref)))
  (type $call159 (func (param eqref (ref $type154)) (result (ref $type18))))
  (type $type159 (struct (field (ref $call159)) (field eqref)))
  (type $call160 (func (param eqref (ref $type121) i64) (result (ref $type18))))
  (type $type160 (struct (field (ref $call160)) (field eqref)))
  (type $call161 (func (param eqref (ref $type121) i64) (result i32)))
  (type $type161 (struct (field (ref $call161)) (field eqref)))
  (type $call162 (func (param eqref (ref $type121)) (result (ref $type163))))
  (type $type162 (struct (field (ref $call162)) (field eqref)))
  (type $type163 (sub (struct (field i32))))
  (type $type164 (sub $type163 (struct (field i32) (field (ref $type13)))))
  (type $type165 (sub $type163 (struct (field i32))))
  (type $type166 (sub $type163 (struct (field i32))))
  (type $type167 (sub $type163 (struct (field i32))))
  (type $type168 (sub $type163 (struct (field i32) (field i64))))
  (type $type169 (sub $type163 (struct (field i32) (field (ref $type18)))))
  (type $type170 (sub $type163 (struct (field i32) (field (ref $type18)))))
  (type $call171 (func (param eqref (ref $type121) i64) (result (ref $type163))))
  (type $type171 (struct (field (ref $call171)) (field eqref)))
  (type $call172 (func (param eqref (ref $type18)) (result (ref $type163))))
  (type $type172 (struct (field (ref $call172)) (field eqref)))
  (type $call173 (func (param eqref (ref $type121) i32 i32) (result (ref $type163))))
  (type $type173 (struct (field (ref $call173)) (field eqref)))
  (type $call174 (func (param eqref (ref $type121) i32) (result (ref $type175))))
  (type $type174 (struct (field (ref $call174)) (field eqref)))
  (type $type175 (sub (struct (field i32))))
  (type $type176 (sub $type175 (struct (field i32) (field (ref $type18)))))
  (type $type177 (sub $type175 (struct (field i32) (field (ref $type18)))))
  (type $call178 (func (param eqref (ref $type121) i32 (ref $type154)) (result (ref $type175))))
  (type $type178 (struct (field (ref $call178)) (field eqref)))
  (type $call179 (func (param eqref (ref $type121) i32 i64) (result i32)))
  (type $type179 (struct (field (ref $call179)) (field eqref)))
  (type $call180 (func (param eqref (ref $type121) i32 (ref $type154) (ref $type181)) (result (ref $type175))))
  (type $type180 (struct (field (ref $call180)) (field eqref)))
  (type $type181 (sub (struct (field i32))))
  (type $type182 (sub $type181 (struct (field i32) (field i32))))
  (type $type183 (sub $type181 (struct (field i32))))
  (type $type184 (sub $type181 (struct (field i32) (field (ref $type18)))))
  (type $call185 (func (param eqref (ref $type121) i32) (result (ref $type181))))
  (type $type185 (struct (field (ref $call185)) (field eqref)))
  (type $call186 (func (param eqref (ref $type121) i64) (result (ref $type181))))
  (type $type186 (struct (field (ref $call186)) (field eqref)))
  (type $call187 (func (param eqref i64 i64) (result (ref $type181))))
  (type $type187 (struct (field (ref $call187)) (field eqref)))
  (type $call188 (func (param eqref (ref $type121) i64 i64) (result (ref $type181))))
  (type $type188 (struct (field (ref $call188)) (field eqref)))
  (type $call189 (func (param eqref (ref $type18)) (result (ref $type181))))
  (type $type189 (struct (field (ref $call189)) (field eqref)))
  (type $call190 (func (param eqref (ref $type121) (ref $type163)) (result (ref $type101))))
  (type $type190 (struct (field (ref $call190)) (field eqref)))
  (type $call191 (func (param eqref (ref $type121) (ref $type18)) (result (ref $type101))))
  (type $type191 (struct (field (ref $call191)) (field eqref)))
  (type $call192 (func (param eqref (ref $type121) i64 (ref null $type12)) (result (ref $type101))))
  (type $type192 (struct (field (ref $call192)) (field eqref)))
  (type $call193 (func (param eqref (ref $type121) i64 (ref null $type12) (ref $type101)) (result (ref $type101))))
  (type $type193 (struct (field (ref $call193)) (field eqref)))
  (type $call194 (func (param eqref (ref $type121) (ref null $type12)) (result (ref $type101))))
  (type $type194 (struct (field (ref $call194)) (field eqref)))
  (type $call195 (func (param eqref (ref null $type12) (ref $type13)) (result (ref $type13))))
  (type $type195 (struct (field (ref $call195)) (field eqref)))
  (type $call196 (func (param eqref (ref null $type12)) (result (ref null $type12))))
  (type $type196 (struct (field (ref $call196)) (field eqref)))
  (type $call197 (func (param eqref i64 (ref null $type12)) (result (ref $type101))))
  (type $type197 (struct (field (ref $call197)) (field eqref)))
  (type $call198 (func (param eqref (ref null $type12)) (result (ref $type101))))
  (type $type198 (struct (field (ref $call198)) (field eqref)))
  (type $call199 (func (param eqref (ref null $type12) (ref $type36) i64) (result (ref $type101))))
  (type $type199 (struct (field (ref $call199)) (field eqref)))
  (type $call200 (func (param eqref (ref $type18)) (result (ref $type24))))
  (type $type200 (struct (field (ref $call200)) (field eqref)))
  (type $call201 (func (param eqref (ref $type28)) (result i32)))
  (type $type201 (struct (field (ref $call201)) (field eqref)))
  (type $call202 (func (param eqref (ref $type24)) (result i32)))
  (type $type202 (struct (field (ref $call202)) (field eqref)))
  (type $call203 (func (param eqref (ref $type13)) (result i32)))
  (type $type203 (struct (field (ref $call203)) (field eqref)))
  (type $call204 (func (param eqref (ref $type34)) (result i32)))
  (type $type204 (struct (field (ref $call204)) (field eqref)))
  (type $call205 (func (param eqref (ref $type36)) (result i32)))
  (type $type205 (struct (field (ref $call205)) (field eqref)))
  (type $environment0 (struct))
  (type $environment1 (struct))
  (type $environment2 (struct))
  (type $environment3 (struct))
  (type $environment4 (struct))
  (type $environment5 (struct))
  (type $environment6 (struct))
  (type $environment7 (struct))
  (type $environment8 (struct))
  (type $environment9 (struct))
  (type $environment10 (struct))
  (type $environment11 (struct))
  (type $environment12 (struct))
  (type $environment13 (struct))
  (type $environment14 (struct))
  (type $environment15 (struct))
  (type $environment16 (struct))
  (type $environment17 (struct))
  (type $environment18 (struct))
  (type $environment19 (struct))
  (type $environment20 (struct))
  (type $environment21 (struct))
  (type $environment22 (struct))
  (type $environment23 (struct))
  (type $environment24 (struct))
  (type $environment25 (struct))
  (type $environment26 (struct))
  (type $environment27 (struct))
  (type $environment28 (struct))
  (type $environment31 (struct))
  (type $environment33 (struct))
  (type $environment34 (struct))
  (type $environment35 (struct))
  (type $environment36 (struct))
  (type $environment38 (struct))
  (type $environment39 (struct))
  (type $environment41 (struct))
  (type $environment42 (struct))
  (type $environment43 (struct))
  (type $environment46 (struct))
  (type $environment47 (struct))
  (type $environment48 (struct))
  (type $environment49 (struct))
  (type $environment50 (struct))
  (type $environment51 (struct))
  (type $environment52 (struct))
  (type $environment53 (struct))
  (type $environment56 (struct))
  (type $environment57 (struct))
  (type $environment58 (struct))
  (type $environment60 (struct))
  (type $environment61 (struct))
  (type $environment62 (struct))
  (type $environment63 (struct))
  (type $environment65 (struct))
  (type $environment66 (struct))
  (type $environment68 (struct))
  (type $environment69 (struct))
  (type $environment70 (struct))
  (type $environment72 (struct))
  (type $environment73 (struct))
  (type $environment75 (struct))
  (type $environment76 (struct))
  (type $environment78 (struct))
  (type $environment79 (struct))
  (type $environment80 (struct))
  (type $environment82 (struct))
  (type $environment83 (struct))
  (type $environment84 (struct))
  (type $environment85 (struct))
  (type $environment86 (struct))
  (type $environment88 (struct))
  (type $environment90 (struct))
  (type $environment92 (struct))
  (type $environment93 (struct))
  (type $environment94 (struct))
  (type $environment95 (struct))
  (type $environment97 (struct))
  (type $environment98 (struct))
  (type $environment99 (struct))
  (type $environment100 (struct))
  (type $environment101 (struct))
  (type $environment102 (struct))
  (type $environment103 (struct))
  (type $environment104 (struct))
  (type $environment105 (struct))
  (type $environment106 (struct))
  (type $environment107 (struct))
  (type $environment108 (struct))
  (type $environment109 (struct))
  (type $environment110 (struct))
  (type $environment111 (struct))
  (type $environment112 (struct))
  (type $environment113 (struct))
  (type $environment114 (struct))
  (type $environment115 (struct))
  (type $environment117 (struct))
  (type $environment119 (struct))
  (type $environment120 (struct))
  (type $environment121 (struct))
  (type $environment122 (struct))
  (type $environment123 (struct))
  (type $environment125 (struct))
  (type $environment127 (struct))
  (type $environment129 (struct))
  (type $environment130 (struct))
  (type $environment131 (struct))
  (type $environment132 (struct))
  (type $environment133 (struct))
  (type $environment134 (struct))
  (type $environment135 (struct))
  (type $environment136 (struct))
  (type $environment137 (struct))
  (type $environment138 (struct))
  (type $environment139 (struct))
  (type $environment140 (struct))
  (type $environment141 (struct))
  (type $environment142 (struct))
  (type $environment143 (struct))
  (type $environment144 (struct))
  (type $environment145 (struct))
  (type $environment146 (struct))
  (type $environment148 (struct))
  (type $environment149 (struct))
  (type $environment150 (struct))
  (type $environment151 (struct))
  (type $environment152 (struct))
  (type $environment153 (struct))
  (type $environment154 (struct))
  (type $environment155 (struct))
  (type $environment156 (struct))
  (type $environment157 (struct))
  (type $environment158 (struct))
  (type $environment159 (struct))
  (type $environment160 (struct))
  (type $environment161 (struct))
  (type $environment162 (struct))
  (type $environment163 (struct))
  (type $environment164 (struct))
  (type $environment165 (struct))
  (type $environment166 (struct))
  (type $environment167 (struct))
  (type $environment168 (struct))
  (type $environment169 (struct))
  (type $environment170 (struct))
  (type $environment171 (struct))
  (type $environment172 (struct))
  (type $environment173 (struct))
  (type $environment174 (struct))
  (type $environment175 (struct))
  (type $environment176 (struct))
  (type $environment177 (struct))
  (type $environment178 (struct))
  (type $environment179 (struct))
  (type $environment180 (struct))
  (type $environment181 (struct))
  (type $environment182 (struct))
  (type $environment183 (struct))
  (type $environment184 (struct))
  (type $environment185 (struct))
  (type $environment187 (struct))
  (type $environment188 (struct))
  (type $environment190 (struct))
  (type $environment191 (struct))
  (type $environment193 (struct))
  (type $environment194 (struct))
  (type $environment195 (struct))
  (type $environment196 (struct))
  (type $environment197 (struct))
  (type $environment198 (struct))
  (type $environment199 (struct))
  (type $environment200 (struct))
  (type $environment202 (struct))
  (type $environment203 (struct))
  (type $environment206 (struct))
  (type $environment208 (struct))
  (type $environment209 (struct))
  (type $environment210 (struct))
  (type $environment211 (struct))
  (type $environment212 (struct))
  (type $environment213 (struct))
  (type $environment214 (struct))
  (type $environment215 (struct))
  (type $environment216 (struct))
  (type $environment217 (struct))
  (type $environment218 (struct))
  (type $environment219 (struct))
  (type $environment220 (struct))
  (type $environment221 (struct))
  (type $environment223 (struct))
  (type $environment224 (struct))
  (type $environment225 (struct))
  (type $environment226 (struct))
  (type $environment228 (struct))
  (type $environment230 (struct))
  (type $environment231 (struct))
  (type $environment233 (struct))
 )
 (type $546 (func (param i32) (result i32)))
 (type $547 (func (result i32)))
 (type $548 (func (param i32)))
 (type $549 (func (param i32 i32) (result i32)))
 (type $550 (func))
 (type $551 (func (param i32 i32)))
 (type $552 (func (param (ref $type18) i32 (ref $type18) i32 i32)))
 (type $553 (func (param (ref $type36) i64 i64 i32 i32 i64 i64) (result i32)))
 (type $554 (func (param i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
 (type $555 (func (param i32 i32 (ref null $type12) i64) (result i64)))
 (type $556 (func (result i64)))
 (type $557 (func (param i32) (result i64)))
 (type $558 (func (param i32 i32) (result f64)))
 (type $559 (func (param i32 i32) (result i64)))
 (type $560 (func (param f64 f64) (result i32)))
 (type $561 (func (param i64)))
 (type $562 (func (param f64)))
 (type $563 (func (param i32 i32) (result (ref $type18))))
 (type $564 (func (param (ref $type18) i32) (result (ref $type19))))
 (type $565 (func (param (ref $type18) i64 (ref $type18) i64 i64) (result i32)))
 (type $566 (func (param i32 i32 (ref null $type40) i64) (result i64)))
 (type $567 (func (param (ref $type18) i32 i32 (ref null $type40) i64) (result (ref $type18))))
 (type $568 (func (param (ref $type18) i32 i32 i64 (ref null $type40)) (result (ref null $type40))))
 (type $569 (func (param i32 i32 (ref null $type50) i64) (result i64)))
 (type $570 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
 (type $571 (func (param i32 i32 (ref null $type56) i64) (result i64)))
 (type $572 (func (param (ref $type36) i32 i32 (ref null $type56) i64) (result (ref $type36))))
 (type $573 (func (param i32 i32 (ref null $type65) i64) (result i64)))
 (type $574 (func (param (ref $type36) i32 i32 (ref null $type65) i64) (result (ref $type36))))
 (type $575 (func (param (ref $type36) i64 i32 i32 i64 i64) (result i64)))
 (type $576 (func (param (ref $type18) (ref $type36) i64 i32 i32 i64 i64) (result i32)))
 (type $577 (func (param (ref $type18) i64 i32 i32 i64 i64) (result i64)))
 (type $578 (func (param (ref $type36) (ref $type18) i64 i32 i32 i64 i64) (result i32)))
 (type $579 (func (param (ref $type18) i32 i64 i32 i32 i64) (result i32)))
 (type $580 (func (param i32 i32 i64 i64) (result i64)))
 (type $581 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type18))))
 (type $582 (func (param i32 i32 (ref null $type12)) (result (ref $type13))))
 (type $583 (func (param i32 i32 (ref $type13) i64) (result i64)))
 (type $584 (func (param (ref $type34) (ref $type34) i64 i32 i32 i64) (result i32)))
 (type $585 (func (param (ref $type36) (ref $type36) i64 i32 i32 i64) (result i32)))
 (type $586 (func (param (ref $type18) i64 i32 i32 i64) (result i32)))
 (type $587 (func (param (ref $type18) (ref $type118) i64 i32 i32 i64) (result i32)))
 (type $588 (func (param (ref $type121) (ref $type154) i32 i32) (result (ref $type18))))
 (type $589 (func (param (ref $type18) i32 i32 i64) (result (ref $type18))))
 (type $590 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type181))))
 (type $591 (func (param i32 i32 (ref null $type12) (ref null $type12)) (result (ref null $type12))))
 (type $592 (func (param (ref $type34) i32 i32 (ref null $type12) i64) (result (ref $type34))))
 (type $593 (func (param (ref $type18) i32 i32 i64) (result i32)))
 (type $594 (func (param (ref $type34) i32 i32 i64) (result i32)))
 (type $595 (func (param (ref $type36) i32 i32 i64) (result i32)))
 (type $596 (func (param (ref $type121) i32 i32 i64) (result i64)))
 (import "snail.library" "snail:datum/token-open" (func $foreign0 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign1 (param i32 i32)))
 (import "snail.library" "snail:datum/fail" (func $foreign2 (param i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign3 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign4 (param i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign5 (param i32) (result i32)))
 (import "snail.library" "snail:datum/symbol-length" (func $foreign6 (param i32) (result i64)))
 (import "snail.library" "snail:datum/symbol-character" (func $foreign7 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign8 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign9 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign10 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign11 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign12 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign13 (param i32) (result i32)))
 (import "snail.library" "snail:datum/real-equivalent" (func $foreign14 (param f64 f64) (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign15))
 (import "snail.library" "snail:io/path-character" (func $foreign16 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign17 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign18))
 (import "snail.library" "snail:io/open-output-file" (func $foreign19 (result i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign20 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign21 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign22 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign23 (param i32) (result i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign24 (param i32 i32)))
 (import "snail.library" "snail:datum/whitespace" (func $foreign25 (param i32) (result i32)))
 (import "reader.test" "emit_i64" (func $foreign26 (param i64)))
 (import "reader.test" "emit_char" (func $foreign27 (param i32)))
 (import "reader.test" "emit_f64" (func $foreign28 (param f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 45)
   (i32.const 62)
   (i32.const 102)
   (i32.const 54)
   (i32.const 52)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 108)
   (i32.const 45)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 117)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 71)
  (array.new_fixed $type19 71
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
   (i32.const 59)
   (i32.const 32)
   (i32.const 114)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 44)
  (array.new_fixed $type19 44
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 44)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 105)
   (i32.const 109)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 16)
  (array.new_fixed $type19 16
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 45)
   (i32.const 115)
   (i32.const 112)
   (i32.const 108)
   (i32.const 105)
   (i32.const 99)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
  )
  (ref.null none)
 ))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type19 10
   (i32.const 113)
   (i32.const 117)
   (i32.const 97)
   (i32.const 115)
   (i32.const 105)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string8 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 109)
   (i32.const 98)
   (i32.const 111)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string11 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 104)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 99)
   (i32.const 105)
   (i32.const 109)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string12 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 85)
   (i32.const 110)
   (i32.const 105)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string13 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 110)
   (i32.const 117)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string14 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 99)
   (i32.const 101)
   (i32.const 101)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 83)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
  )
  (ref.null none)
 ))
 (global $string15 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 35)
  )
  (ref.null none)
 ))
 (global $string16 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 108)
   (i32.const 97)
   (i32.const 98)
   (i32.const 101)
   (i32.const 108)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string17 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 32)
   (i32.const 100)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string18 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 108)
   (i32.const 111)
   (i32.const 99)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string19 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string20 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string21 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string22 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 25)
  (array.new_fixed $type19 25
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string23 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 116)
   (i32.const 97)
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string24 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string25 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string26 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string27 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string28 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string29 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string30 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 98)
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string31 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string32 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 22)
  (array.new_fixed $type19 22
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string33 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type19 31
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 117)
   (i32.const 56)
   (i32.const 40)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string34 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string35 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $string36 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 35)
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string37 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string38 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string39 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $string40 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 14)
  (array.new_fixed $type19 14
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string41 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 104)
   (i32.const 101)
   (i32.const 115)
   (i32.const 105)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string42 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 112)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 100)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string43 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 115)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string44 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 91)
   (i32.const 48)
   (i32.const 44)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
   (i32.const 93)
  )
  (ref.null none)
 ))
 (global $string45 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string46 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 36)
  (array.new_fixed $type19 36
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string47 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 33)
  (array.new_fixed $type19 33
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string48 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string49 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 117)
   (i32.const 110)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string50 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string51 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string52 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 49)
  )
  (ref.null none)
 ))
 (global $string53 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 955)
   (i32.const 128512)
  )
  (ref.null none)
 ))
 (global $string54 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 49)
   (i32.const 50)
   (i32.const 46)
   (i32.const 53)
  )
  (ref.null none)
 ))
 (global $string55 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 49)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string56 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 43)
   (i32.const 110)
   (i32.const 97)
   (i32.const 110)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string57 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 45)
   (i32.const 110)
   (i32.const 97)
   (i32.const 110)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string58 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 48)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string59 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 45)
   (i32.const 48)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string60 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 49)
   (i32.const 43)
   (i32.const 48)
   (i32.const 105)
  )
  (ref.null none)
 ))
 (global $string61 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 35)
   (i32.const 120)
   (i32.const 45)
   (i32.const 56)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string62 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 35)
   (i32.const 101)
   (i32.const 57)
   (i32.const 48)
   (i32.const 48)
   (i32.const 55)
   (i32.const 49)
   (i32.const 57)
   (i32.const 57)
   (i32.const 50)
   (i32.const 53)
   (i32.const 52)
   (i32.const 55)
   (i32.const 52)
   (i32.const 48)
   (i32.const 57)
   (i32.const 57)
   (i32.const 51)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string63 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 13)
  (array.new_fixed $type19 13
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 104)
   (i32.const 105)
   (i32.const 112)
   (i32.const 46)
   (i32.const 115)
   (i32.const 99)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string64 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 116)
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string65 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 88)
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string66 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 115)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string67 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 46)
   (i32.const 115)
   (i32.const 99)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $empty93 (ref $type93) (struct.new $type93
  (i32.const 0)
 ))
 (global $empty102 (ref $type102) (struct.new $type102
  (i32.const 0)
 ))
 (global $empty131 (ref $type131) (struct.new $type131
  (i32.const 0)
 ))
 (global $empty137 (ref $type137) (struct.new $type137
  (i32.const 0)
 ))
 (global $empty165 (ref $type165) (struct.new $type165
  (i32.const 1)
 ))
 (global $empty166 (ref $type166) (struct.new $type166
  (i32.const 2)
 ))
 (global $empty167 (ref $type167) (struct.new $type167
  (i32.const 3)
 ))
 (global $empty183 (ref $type183) (struct.new $type183
  (i32.const 1)
 ))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global3 (mut (ref null $type1)) (ref.null none))
 (global $ready3 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type0)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global9 (mut (ref null $type1)) (ref.null none))
 (global $ready9 (mut i32) (i32.const 0))
 (global $global12 (mut (ref null $type0)) (ref.null none))
 (global $ready12 (mut i32) (i32.const 0))
 (global $global15 (mut (ref null $type1)) (ref.null none))
 (global $ready15 (mut i32) (i32.const 0))
 (global $global18 (mut (ref null $type0)) (ref.null none))
 (global $ready18 (mut i32) (i32.const 0))
 (global $global21 (mut (ref null $type1)) (ref.null none))
 (global $ready21 (mut i32) (i32.const 0))
 (global $global24 (mut (ref null $type2)) (ref.null none))
 (global $ready24 (mut i32) (i32.const 0))
 (global $global27 (mut (ref null $type3)) (ref.null none))
 (global $ready27 (mut i32) (i32.const 0))
 (global $global30 (mut (ref null $type2)) (ref.null none))
 (global $ready30 (mut i32) (i32.const 0))
 (global $global33 (mut (ref null $type3)) (ref.null none))
 (global $ready33 (mut i32) (i32.const 0))
 (global $global36 (mut (ref null $type2)) (ref.null none))
 (global $ready36 (mut i32) (i32.const 0))
 (global $global39 (mut (ref null $type3)) (ref.null none))
 (global $ready39 (mut i32) (i32.const 0))
 (global $global42 (mut (ref null $type2)) (ref.null none))
 (global $ready42 (mut i32) (i32.const 0))
 (global $global45 (mut (ref null $type3)) (ref.null none))
 (global $ready45 (mut i32) (i32.const 0))
 (global $global48 (mut (ref null $type2)) (ref.null none))
 (global $ready48 (mut i32) (i32.const 0))
 (global $global51 (mut (ref null $type3)) (ref.null none))
 (global $ready51 (mut i32) (i32.const 0))
 (global $global54 (mut (ref null $type4)) (ref.null none))
 (global $ready54 (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global56 (mut (ref null $type6)) (ref.null none))
 (global $ready56 (mut i32) (i32.const 0))
 (global $global57 (mut (ref null $type7)) (ref.null none))
 (global $ready57 (mut i32) (i32.const 0))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $ready58 (mut i32) (i32.const 0))
 (global $global59 (mut (ref null $type9)) (ref.null none))
 (global $ready59 (mut i32) (i32.const 0))
 (global $global60 (mut (ref null $type10)) (ref.null none))
 (global $ready60 (mut i32) (i32.const 0))
 (global $global795 (mut (ref null $type11)) (ref.null none))
 (global $ready795 (mut i32) (i32.const 0))
 (global $global726 (mut (ref null $type38)) (ref.null none))
 (global $ready726 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type39)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global729 (mut (ref null $type41)) (ref.null none))
 (global $ready729 (mut i32) (i32.const 0))
 (global $global797 (mut (ref null $type42)) (ref.null none))
 (global $ready797 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type43)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type44)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type45)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type46)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type47)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type48)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type49)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type51)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type52)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type53)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type54)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type55)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type57)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type58)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type59)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type60)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type61)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type62)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type63)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type64)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type66)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global182 (mut (ref null $type67)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type67)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global193 (mut (ref null $type67)) (ref.null none))
 (global $ready193 (mut i32) (i32.const 0))
 (global $global177 (mut (ref null $type68)) (ref.null none))
 (global $ready177 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type69)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global184 (mut (ref null $type70)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type68)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global195 (mut (ref null $type71)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type72)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global204 (mut (ref null $type73)) (ref.null none))
 (global $ready204 (mut i32) (i32.const 0))
 (global $global207 (mut (ref null $type74)) (ref.null none))
 (global $ready207 (mut i32) (i32.const 0))
 (global $global229 (mut (ref null $type67)) (ref.null none))
 (global $ready229 (mut i32) (i32.const 0))
 (global $global222 (mut (ref null $type75)) (ref.null none))
 (global $ready222 (mut i32) (i32.const 0))
 (global $global209 (mut (ref null $type76)) (ref.null none))
 (global $ready209 (mut i32) (i32.const 0))
 (global $global231 (mut (ref null $type77)) (ref.null none))
 (global $ready231 (mut i32) (i32.const 0))
 (global $global217 (mut (ref null $type78)) (ref.null none))
 (global $ready217 (mut i32) (i32.const 0))
 (global $global241 (mut (ref null $type79)) (ref.null none))
 (global $ready241 (mut i32) (i32.const 0))
 (global $global244 (mut (ref null $type80)) (ref.null none))
 (global $ready244 (mut i32) (i32.const 0))
 (global $global246 (mut (ref null $type81)) (ref.null none))
 (global $ready246 (mut i32) (i32.const 0))
 (global $global252 (mut (ref null $type82)) (ref.null none))
 (global $ready252 (mut i32) (i32.const 0))
 (global $global254 (mut (ref null $type83)) (ref.null none))
 (global $ready254 (mut i32) (i32.const 0))
 (global $global258 (mut (ref null $type84)) (ref.null none))
 (global $ready258 (mut i32) (i32.const 0))
 (global $global260 (mut (ref null $type85)) (ref.null none))
 (global $ready260 (mut i32) (i32.const 0))
 (global $global263 (mut (ref null $type86)) (ref.null none))
 (global $ready263 (mut i32) (i32.const 0))
 (global $global270 (mut (ref null $type67)) (ref.null none))
 (global $ready270 (mut i32) (i32.const 0))
 (global $global275 (mut (ref null $type43)) (ref.null none))
 (global $ready275 (mut i32) (i32.const 0))
 (global $global284 (mut (ref null $type87)) (ref.null none))
 (global $ready284 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type88)) (ref.null none))
 (global $ready289 (mut i32) (i32.const 0))
 (global $global296 (mut (ref null $type89)) (ref.null none))
 (global $ready296 (mut i32) (i32.const 0))
 (global $global299 (mut (ref null $type90)) (ref.null none))
 (global $ready299 (mut i32) (i32.const 0))
 (global $global305 (mut (ref null $type91)) (ref.null none))
 (global $ready305 (mut i32) (i32.const 0))
 (global $global308 (mut (ref null $type96)) (ref.null none))
 (global $ready308 (mut i32) (i32.const 0))
 (global $global313 (mut (ref null $type97)) (ref.null none))
 (global $ready313 (mut i32) (i32.const 0))
 (global $global325 (mut (ref null $type98)) (ref.null none))
 (global $ready325 (mut i32) (i32.const 0))
 (global $global332 (mut (ref null $type99)) (ref.null none))
 (global $ready332 (mut i32) (i32.const 0))
 (global $global340 (mut (ref null $type100)) (ref.null none))
 (global $ready340 (mut i32) (i32.const 0))
 (global $global347 (mut (ref null $type105)) (ref.null none))
 (global $ready347 (mut i32) (i32.const 0))
 (global $global351 (mut (ref null $type106)) (ref.null none))
 (global $ready351 (mut i32) (i32.const 0))
 (global $global354 (mut (ref null $type107)) (ref.null none))
 (global $ready354 (mut i32) (i32.const 0))
 (global $global356 (mut (ref null $type107)) (ref.null none))
 (global $ready356 (mut i32) (i32.const 0))
 (global $global358 (mut (ref null $type108)) (ref.null none))
 (global $ready358 (mut i32) (i32.const 0))
 (global $global361 (mut (ref null $type108)) (ref.null none))
 (global $ready361 (mut i32) (i32.const 0))
 (global $global364 (mut (ref null $type109)) (ref.null none))
 (global $ready364 (mut i32) (i32.const 0))
 (global $global376 (mut (ref null $type110)) (ref.null none))
 (global $ready376 (mut i32) (i32.const 0))
 (global $global378 (mut (ref null $type110)) (ref.null none))
 (global $ready378 (mut i32) (i32.const 0))
 (global $global380 (mut (ref null $type110)) (ref.null none))
 (global $ready380 (mut i32) (i32.const 0))
 (global $global382 (mut (ref null $type110)) (ref.null none))
 (global $ready382 (mut i32) (i32.const 0))
 (global $global384 (mut (ref null $type111)) (ref.null none))
 (global $ready384 (mut i32) (i32.const 0))
 (global $global397 (mut (ref null $type112)) (ref.null none))
 (global $ready397 (mut i32) (i32.const 0))
 (global $global401 (mut (ref null $type109)) (ref.null none))
 (global $ready401 (mut i32) (i32.const 0))
 (global $global406 (mut (ref null $type106)) (ref.null none))
 (global $ready406 (mut i32) (i32.const 0))
 (global $global409 (mut (ref null $type106)) (ref.null none))
 (global $ready409 (mut i32) (i32.const 0))
 (global $global413 (mut (ref null $type113)) (ref.null none))
 (global $ready413 (mut i32) (i32.const 0))
 (global $global417 (mut (ref null $type111)) (ref.null none))
 (global $ready417 (mut i32) (i32.const 0))
 (global $global429 (mut (ref null $type114)) (ref.null none))
 (global $ready429 (mut i32) (i32.const 0))
 (global $global437 (mut (ref null $type115)) (ref.null none))
 (global $ready437 (mut i32) (i32.const 0))
 (global $global444 (mut (ref null $type116)) (ref.null none))
 (global $ready444 (mut i32) (i32.const 0))
 (global $global449 (mut (ref null $type83)) (ref.null none))
 (global $ready449 (mut i32) (i32.const 0))
 (global $global451 (mut (ref null $type116)) (ref.null none))
 (global $ready451 (mut i32) (i32.const 0))
 (global $global453 (mut (ref null $type117)) (ref.null none))
 (global $ready453 (mut i32) (i32.const 0))
 (global $global455 (mut (ref null $type120)) (ref.null none))
 (global $ready455 (mut i32) (i32.const 0))
 (global $global457 (mut (ref null $type122)) (ref.null none))
 (global $ready457 (mut i32) (i32.const 0))
 (global $global462 (mut (ref null $type123)) (ref.null none))
 (global $ready462 (mut i32) (i32.const 0))
 (global $global459 (mut (ref null $type124)) (ref.null none))
 (global $ready459 (mut i32) (i32.const 0))
 (global $global814 (mut (ref null $type125)) (ref.null none))
 (global $ready814 (mut i32) (i32.const 0))
 (global $global862 (mut (ref null $type127)) (ref.null none))
 (global $ready862 (mut i32) (i32.const 0))
 (global $global464 (mut (ref null $type129)) (ref.null none))
 (global $ready464 (mut i32) (i32.const 0))
 (global $global468 (mut (ref null $type133)) (ref.null none))
 (global $ready468 (mut i32) (i32.const 0))
 (global $global470 (mut (ref null $type134)) (ref.null none))
 (global $ready470 (mut i32) (i32.const 0))
 (global $global472 (mut (ref null $type134)) (ref.null none))
 (global $ready472 (mut i32) (i32.const 0))
 (global $global474 (mut (ref null $type135)) (ref.null none))
 (global $ready474 (mut i32) (i32.const 0))
 (global $global478 (mut (ref null $type139)) (ref.null none))
 (global $ready478 (mut i32) (i32.const 0))
 (global $global489 (mut (ref null $type140)) (ref.null none))
 (global $ready489 (mut i32) (i32.const 0))
 (global $global482 (mut (ref null $type141)) (ref.null none))
 (global $ready482 (mut i32) (i32.const 0))
 (global $global492 (mut (ref null $type142)) (ref.null none))
 (global $ready492 (mut i32) (i32.const 0))
 (global $global497 (mut (ref null $type143)) (ref.null none))
 (global $ready497 (mut i32) (i32.const 0))
 (global $global500 (mut (ref null $type144)) (ref.null none))
 (global $ready500 (mut i32) (i32.const 0))
 (global $global506 (mut (ref null $type122)) (ref.null none))
 (global $ready506 (mut i32) (i32.const 0))
 (global $global508 (mut (ref null $type145)) (ref.null none))
 (global $ready508 (mut i32) (i32.const 0))
 (global $global511 (mut (ref null $type145)) (ref.null none))
 (global $ready511 (mut i32) (i32.const 0))
 (global $global515 (mut (ref null $type146)) (ref.null none))
 (global $ready515 (mut i32) (i32.const 0))
 (global $global520 (mut (ref null $type147)) (ref.null none))
 (global $ready520 (mut i32) (i32.const 0))
 (global $global525 (mut (ref null $type148)) (ref.null none))
 (global $ready525 (mut i32) (i32.const 0))
 (global $global532 (mut (ref null $type149)) (ref.null none))
 (global $ready532 (mut i32) (i32.const 0))
 (global $global552 (mut (ref null $type128)) (ref.null none))
 (global $ready552 (mut i32) (i32.const 0))
 (global $global530 (mut (ref null $type128)) (ref.null none))
 (global $ready530 (mut i32) (i32.const 0))
 (global $global538 (mut (ref null $type150)) (ref.null none))
 (global $ready538 (mut i32) (i32.const 0))
 (global $global549 (mut (ref null $type151)) (ref.null none))
 (global $ready549 (mut i32) (i32.const 0))
 (global $global536 (mut (ref null $type152)) (ref.null none))
 (global $ready536 (mut i32) (i32.const 0))
 (global $global643 (mut (ref null $type152)) (ref.null none))
 (global $ready643 (mut i32) (i32.const 0))
 (global $global562 (mut (ref null $type153)) (ref.null none))
 (global $ready562 (mut i32) (i32.const 0))
 (global $global611 (mut (ref null $type157)) (ref.null none))
 (global $ready611 (mut i32) (i32.const 0))
 (global $global615 (mut (ref null $type158)) (ref.null none))
 (global $ready615 (mut i32) (i32.const 0))
 (global $global568 (mut (ref null $type159)) (ref.null none))
 (global $ready568 (mut i32) (i32.const 0))
 (global $global658 (mut (ref null $type160)) (ref.null none))
 (global $ready658 (mut i32) (i32.const 0))
 (global $global666 (mut (ref null $type48)) (ref.null none))
 (global $ready666 (mut i32) (i32.const 0))
 (global $global541 (mut (ref null $type123)) (ref.null none))
 (global $ready541 (mut i32) (i32.const 0))
 (global $global635 (mut (ref null $type161)) (ref.null none))
 (global $ready635 (mut i32) (i32.const 0))
 (global $global630 (mut (ref null $type162)) (ref.null none))
 (global $ready630 (mut i32) (i32.const 0))
 (global $global527 (mut (ref null $type162)) (ref.null none))
 (global $ready527 (mut i32) (i32.const 0))
 (global $global546 (mut (ref null $type171)) (ref.null none))
 (global $ready546 (mut i32) (i32.const 0))
 (global $global627 (mut (ref null $type162)) (ref.null none))
 (global $ready627 (mut i32) (i32.const 0))
 (global $global684 (mut (ref null $type162)) (ref.null none))
 (global $ready684 (mut i32) (i32.const 0))
 (global $global686 (mut (ref null $type172)) (ref.null none))
 (global $ready686 (mut i32) (i32.const 0))
 (global $global697 (mut (ref null $type172)) (ref.null none))
 (global $ready697 (mut i32) (i32.const 0))
 (global $global554 (mut (ref null $type173)) (ref.null none))
 (global $ready554 (mut i32) (i32.const 0))
 (global $global559 (mut (ref null $type174)) (ref.null none))
 (global $ready559 (mut i32) (i32.const 0))
 (global $global563 (mut (ref null $type178)) (ref.null none))
 (global $ready563 (mut i32) (i32.const 0))
 (global $global621 (mut (ref null $type179)) (ref.null none))
 (global $ready621 (mut i32) (i32.const 0))
 (global $global604 (mut (ref null $type180)) (ref.null none))
 (global $ready604 (mut i32) (i32.const 0))
 (global $global570 (mut (ref null $type185)) (ref.null none))
 (global $ready570 (mut i32) (i32.const 0))
 (global $global591 (mut (ref null $type152)) (ref.null none))
 (global $ready591 (mut i32) (i32.const 0))
 (global $global601 (mut (ref null $type123)) (ref.null none))
 (global $ready601 (mut i32) (i32.const 0))
 (global $global596 (mut (ref null $type186)) (ref.null none))
 (global $ready596 (mut i32) (i32.const 0))
 (global $global588 (mut (ref null $type67)) (ref.null none))
 (global $ready588 (mut i32) (i32.const 0))
 (global $global584 (mut (ref null $type152)) (ref.null none))
 (global $ready584 (mut i32) (i32.const 0))
 (global $global581 (mut (ref null $type187)) (ref.null none))
 (global $ready581 (mut i32) (i32.const 0))
 (global $global576 (mut (ref null $type188)) (ref.null none))
 (global $ready576 (mut i32) (i32.const 0))
 (global $global674 (mut (ref null $type189)) (ref.null none))
 (global $ready674 (mut i32) (i32.const 0))
 (global $global640 (mut (ref null $type162)) (ref.null none))
 (global $ready640 (mut i32) (i32.const 0))
 (global $global663 (mut (ref null $type172)) (ref.null none))
 (global $ready663 (mut i32) (i32.const 0))
 (global $global672 (mut (ref null $type189)) (ref.null none))
 (global $ready672 (mut i32) (i32.const 0))
 (global $global702 (mut (ref null $type190)) (ref.null none))
 (global $ready702 (mut i32) (i32.const 0))
 (global $global780 (mut (ref null $type191)) (ref.null none))
 (global $ready780 (mut i32) (i32.const 0))
 (global $global709 (mut (ref null $type192)) (ref.null none))
 (global $ready709 (mut i32) (i32.const 0))
 (global $global770 (mut (ref null $type193)) (ref.null none))
 (global $ready770 (mut i32) (i32.const 0))
 (global $global756 (mut (ref null $type194)) (ref.null none))
 (global $ready756 (mut i32) (i32.const 0))
 (global $global718 (mut (ref null $type195)) (ref.null none))
 (global $ready718 (mut i32) (i32.const 0))
 (global $global721 (mut (ref null $type196)) (ref.null none))
 (global $ready721 (mut i32) (i32.const 0))
 (global $global715 (mut (ref null $type197)) (ref.null none))
 (global $ready715 (mut i32) (i32.const 0))
 (global $global737 (mut (ref null $type198)) (ref.null none))
 (global $ready737 (mut i32) (i32.const 0))
 (global $global748 (mut (ref null $type109)) (ref.null none))
 (global $ready748 (mut i32) (i32.const 0))
 (global $global743 (mut (ref null $type199)) (ref.null none))
 (global $ready743 (mut i32) (i32.const 0))
 (global $global786 (mut (ref null $type200)) (ref.null none))
 (global $ready786 (mut i32) (i32.const 0))
 (global $global788 (mut (ref null $type8)) (ref.null none))
 (global $ready788 (mut i32) (i32.const 0))
 (global $global801 (mut (ref null $type5)) (ref.null none))
 (global $ready801 (mut i32) (i32.const 0))
 (global $global805 (mut (ref null $type8)) (ref.null none))
 (global $ready805 (mut i32) (i32.const 0))
 (global $global819 (mut (ref null $type116)) (ref.null none))
 (global $ready819 (mut i32) (i32.const 0))
 (global $global823 (mut (ref null $type201)) (ref.null none))
 (global $ready823 (mut i32) (i32.const 0))
 (global $global828 (mut (ref null $type202)) (ref.null none))
 (global $ready828 (mut i32) (i32.const 0))
 (global $global835 (mut (ref null $type203)) (ref.null none))
 (global $ready835 (mut i32) (i32.const 0))
 (global $global846 (mut (ref null $type204)) (ref.null none))
 (global $ready846 (mut i32) (i32.const 0))
 (global $global851 (mut (ref null $type205)) (ref.null none))
 (global $ready851 (mut i32) (i32.const 0))
 (global $global855 (mut (ref null $type5)) (ref.null none))
 (global $ready855 (mut i32) (i32.const 0))
 (export "check" (func $export0))
 (export "scan" (func $export1))
 (export "storage" (func $export2))
 (export "main" (func $main))
 (func $string-min (param $a i32) (param $b i32) (result i32)
  (if (result i32)
   (i32.lt_u
    (local.get $a)
    (local.get $b)
   )
   (then
    (local.get $a)
   )
   (else
    (local.get $b)
   )
  )
 )
 (func $string-new (param $length i32) (param $fill i32) (result (ref $type18))
  (local $first (ref null $type19))
  (local $directory (ref null $type20))
  (local $remaining i32)
  (local $index i32)
  (local $size i32)
  (local.set $size
   (call $string-min
    (local.get $length)
    (i32.const 8192)
   )
  )
  (local.set $first
   (array.new $type19
    (local.get $fill)
    (local.get $size)
   )
  )
  (local.set $remaining
   (i32.sub
    (local.get $length)
    (local.get $size)
   )
  )
  (if
   (local.get $remaining)
   (then
    (local.set $directory
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $length)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (local.set $size
      (call $string-min
       (local.get $remaining)
       (i32.const 8192)
      )
     )
     (array.set $type20
      (local.get $directory)
      (local.get $index)
      (array.new $type19
       (local.get $fill)
       (local.get $size)
      )
     )
     (local.set $index
      (i32.add
       (local.get $index)
       (i32.const 1)
      )
     )
     (local.set $remaining
      (i32.sub
       (local.get $remaining)
       (local.get $size)
      )
     )
     (br_if $label
      (local.get $remaining)
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $length)
   (ref.as_non_null
    (local.get $first)
   )
   (local.get $directory)
  )
 )
 (func $string-block (param $string (ref $type18)) (param $index i32) (result (ref $type19))
  (if (result (ref $type19))
   (i32.lt_u
    (local.get $index)
    (i32.const 8192)
   )
   (then
    (struct.get $type18 2
     (local.get $string)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type20
      (struct.get $type18 3
       (local.get $string)
      )
      (i32.sub
       (i32.shr_u
        (local.get $index)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy-forward (param $target (ref $type18)) (param $at i32) (param $source (ref $type18)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $at)
         (i32.const 8191)
        )
       )
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $start)
         (i32.const 8191)
        )
       )
      )
     )
    )
    (array.copy $type19 $type19
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $at
     (i32.add
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.add
      (local.get $start)
      (local.get $step)
     )
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy-backward (param $target (ref $type18)) (param $at i32) (param $source (ref $type18)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (local.set $at
   (i32.add
    (local.get $at)
    (local.get $remaining)
   )
  )
  (local.set $start
   (i32.add
    (local.get $start)
    (local.get $remaining)
   )
  )
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.add
        (i32.and
         (i32.sub
          (local.get $at)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
       (i32.add
        (i32.and
         (i32.sub
          (local.get $start)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
      )
     )
    )
    (local.set $at
     (i32.sub
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.sub
      (local.get $start)
      (local.get $step)
     )
    )
    (array.copy $type19 $type19
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy (param $target (ref $type18)) (param $at i64) (param $source (ref $type18)) (param $start i64) (param $end i64) (result i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $target)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $at)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $target)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $end)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $source)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $start)
    (local.get $end)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $end)
     (local.get $start)
    )
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $target)
      )
     )
     (local.get $at)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (ref.eq
     (local.get $target)
     (local.get $source)
    )
    (i64.gt_u
     (local.get $at)
     (local.get $start)
    )
   )
   (then
    (call $string-copy-backward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
   (else
    (call $string-copy-forward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function0 (type $call0) (param $environment eqref) (param $argument1 i64) (param $argument2 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument1)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument2)
  )
  (f64.add
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function1 (type $call1) (param $environment eqref) (param $argument4 f64) (param $argument5 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument4)
  )
  (local.set $local2
   (local.get $argument5)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.add
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function2 (type $call0) (param $environment eqref) (param $argument7 i64) (param $argument8 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument7)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument8)
  )
  (f64.sub
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function3 (type $call1) (param $environment eqref) (param $argument10 f64) (param $argument11 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument10)
  )
  (local.set $local2
   (local.get $argument11)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.sub
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function4 (type $call0) (param $environment eqref) (param $argument13 i64) (param $argument14 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument13)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument14)
  )
  (f64.mul
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function5 (type $call1) (param $environment eqref) (param $argument16 f64) (param $argument17 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument16)
  )
  (local.set $local2
   (local.get $argument17)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.mul
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function6 (type $call0) (param $environment eqref) (param $argument19 i64) (param $argument20 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument19)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument20)
  )
  (f64.div
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function7 (type $call1) (param $environment eqref) (param $argument22 f64) (param $argument23 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument22)
  )
  (local.set $local2
   (local.get $argument23)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.div
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function8 (type $call2) (param $environment eqref) (param $argument25 i64) (param $argument26 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument25)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument26)
  )
  (f64.eq
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function9 (type $call3) (param $environment eqref) (param $argument28 f64) (param $argument29 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument28)
  )
  (local.set $local2
   (local.get $argument29)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function10 (type $call2) (param $environment eqref) (param $argument31 i64) (param $argument32 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument31)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument32)
  )
  (f64.lt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function11 (type $call3) (param $environment eqref) (param $argument34 f64) (param $argument35 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument34)
  )
  (local.set $local2
   (local.get $argument35)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.lt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function12 (type $call2) (param $environment eqref) (param $argument37 i64) (param $argument38 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument37)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument38)
  )
  (f64.le
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function13 (type $call3) (param $environment eqref) (param $argument40 f64) (param $argument41 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument40)
  )
  (local.set $local2
   (local.get $argument41)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.le
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function14 (type $call2) (param $environment eqref) (param $argument43 i64) (param $argument44 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument43)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument44)
  )
  (f64.gt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function15 (type $call3) (param $environment eqref) (param $argument46 f64) (param $argument47 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument46)
  )
  (local.set $local2
   (local.get $argument47)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.gt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function16 (type $call2) (param $environment eqref) (param $argument49 i64) (param $argument50 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument49)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument50)
  )
  (f64.ge
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function17 (type $call3) (param $environment eqref) (param $argument52 f64) (param $argument53 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument52)
  )
  (local.set $local2
   (local.get $argument53)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.ge
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function18 (type $call4) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function19 (type $call5) (param $environment eqref) (result i64)
  (i64.const 0)
 )
 (func $function20 (type $call6) (param $environment eqref) (result f32)
  (f32.const 0)
 )
 (func $function21 (type $call7) (param $environment eqref) (result f64)
  (f64.const 0)
 )
 (func $function22 (type $call8) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function23 (type $call9) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function24 (type $call10) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function25 (type $call43) (param $environment eqref) (param $argument62 i64) (result (ref $type18))
  (local $local0 i64)
  (local $local1 i32)
  (local.set $local0
   (local.get $argument62)
  )
  (local.set $local1
   (i32.const 0)
  )
  (if
   (i64.gt_u
    (local.get $local0)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (call $string-new
   (i32.wrap_i64
    (local.get $local0)
   )
   (local.get $local1)
  )
 )
 (func $function26 (type $call44) (param $environment eqref) (param $argument64 (ref null $type40)) (result (ref $type18))
  (local $local0 (ref null $type40))
  (local $local1 (ref null $type45))
  (local.set $local0
   (local.get $argument64)
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (return_call $function27
   (struct.get $type45 1
    (ref.as_non_null
     (local.get $local1)
    )
   )
   (local.get $local0)
  )
 )
 (func $function27 (type $call45) (param $environment eqref) (param $argument66 (ref null $type40)) (result (ref $type18))
  (local $local0 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local2 i64)
  (local $local7 i64)
  (local $local1 (ref null $type18))
  (local $local3 (ref null $type40))
  (local $local6 (ref null $type40))
  (local $local4 (ref null $type39))
  (local $local5 (ref null $type43))
  (local.set $local3
   (local.get $argument66)
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global68)
   )
  )
  (local.set $local2
   (call $function28
    (struct.get $type39 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type43 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local6
   (local.get $argument66)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function30
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local9)
   (local.get $local8)
   (local.get $local6)
   (local.get $local7)
  )
 )
 (func $function28 (type $call39) (param $environment eqref) (param $argument69 (ref null $type40)) (result i64)
  (local $local0 (ref null $type40))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument69)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function29
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function29 (param $capture70 i32) (param $initialized70 i32) (param $argument71 (ref null $type40)) (param $argument72 i64) (result i64)
  (local $local0 (ref null $type40))
  (local $local1 (ref null $type40))
  (local $local7 (ref null $type40))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local.set $local7
   (local.get $argument71)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local7)
   )
   (then
    (local.get $argument72)
   )
   (else
    (local.set $local5
     (local.get $argument72)
    )
    (local.set $local6
     (i64.const 4294967295)
    )
    (if (result i64)
     (i64.eq
      (local.get $local5)
      (local.get $local6)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local1
       (local.get $argument71)
      )
      (local.set $local0
       (struct.get $type40 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument72)
      )
      (local.set $local4
       (i64.const 1)
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized70)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture70)
      )
      (return_call $function29
       (local.get $capture70)
       (local.get $initialized70)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function30 (param $capture67 (ref $type18)) (param $capture73 i32) (param $initialized73 i32) (param $argument74 (ref null $type40)) (param $argument75 i64) (result (ref $type18))
  (local $local0 (ref null $type40))
  (local $local1 (ref null $type40))
  (local $local8 (ref null $type40))
  (local $local10 (ref null $type40))
  (local $local5 (ref null $type18))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i32)
  (local $local9 i32)
  (local.set $local10
   (local.get $argument74)
  )
  (if (result (ref $type18))
   (ref.is_null
    (local.get $local10)
   )
   (then
    (ref.as_non_null
     (local.get $capture67)
    )
   )
   (else
    (local.set $local5
     (ref.as_non_null
      (local.get $capture67)
     )
    )
    (local.set $local6
     (local.get $argument75)
    )
    (local.set $local8
     (local.get $argument74)
    )
    (local.set $local7
     (struct.get $type40 0
      (local.get $local8)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (array.set $type19
     (call $string-block
      (ref.as_non_null
       (local.get $local5)
      )
      (local.get $local9)
     )
     (i32.and
      (local.get $local9)
      (i32.const 8191)
     )
     (local.get $local7)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument74)
    )
    (local.set $local0
     (struct.get $type40 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument75)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized73)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture73)
    )
    (return_call $function30
     (ref.as_non_null
      (local.get $capture67)
     )
     (local.get $capture73)
     (local.get $initialized73)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function31 (type $call46) (param $environment eqref) (param $argument77 (ref $type18)) (result (ref null $type40))
  (local $local0 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local $local1 (ref null $type18))
  (local $local2 (ref null $type40))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument77)
   )
  )
  (local.set $local0
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local2
   (ref.null none)
  )
  (local.set $local4
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local4)
  )
  (return_call $function32
   (ref.as_non_null
    (local.get $argument77)
   )
   (local.get $local4)
   (local.get $local3)
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function32 (param $capture77 (ref $type18)) (param $capture78 i32) (param $initialized78 i32) (param $argument79 i64) (param $argument80 (ref null $type40)) (result (ref null $type40))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local4 i32)
  (local $local9 i32)
  (local $local3 (ref null $type40))
  (local $local10 (ref null $type40))
  (local $local5 (ref null $type18))
  (local.set $local11
   (local.get $argument79)
  )
  (local.set $local12
   (i64.const 0)
  )
  (if (result (ref null $type40))
   (i64.eq
    (local.get $local11)
    (local.get $local12)
   )
   (then
    (local.get $argument80)
   )
   (else
    (local.set $local1
     (local.get $argument79)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $capture77)
     )
    )
    (local.set $local7
     (local.get $argument79)
    )
    (local.set $local8
     (i64.const 1)
    )
    (local.set $local6
     (i64.sub
      (local.get $local7)
      (local.get $local8)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (local.set $local4
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local5)
       )
       (local.get $local9)
      )
      (i32.and
       (local.get $local9)
       (i32.const 8191)
      )
     )
    )
    (local.set $local10
     (local.get $argument80)
    )
    (local.set $local3
     (struct.new $type40
      (local.get $local4)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture78)
    )
    (return_call $function32
     (ref.as_non_null
      (local.get $capture77)
     )
     (local.get $capture78)
     (local.get $initialized78)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function33 (type $call47) (param $environment eqref) (param $argument82 (ref $type18)) (param $argument83 i64) (param $argument84 i64) (result (ref $type18))
  (local $local0 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local16 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local1 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local8 (ref null $type18))
  (local $local21 (ref null $type18))
  (local $local5 (ref null $type43))
  (local.set $local13
   (local.get $argument83)
  )
  (local.set $local14
   (i64.const 0)
  )
  (local.set $local12
   (i64.lt_s
    (local.get $local13)
    (local.get $local14)
   )
  )
  (local.set $local11
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (if (result i32)
    (local.get $local12)
    (then
     (if
      (i32.eqz
       (local.get $local11)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local12)
    )
    (else
     (local.set $local17
      (local.get $argument84)
     )
     (local.set $local18
      (local.get $argument83)
     )
     (local.set $local16
      (i64.lt_s
       (local.get $local17)
       (local.get $local18)
      )
     )
     (local.set $local15
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local15)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local16)
      (then
       (if
        (i32.eqz
         (local.get $local15)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local16)
      )
      (else
       (local.set $local19
        (local.get $argument84)
       )
       (local.set $local21
        (ref.as_non_null
         (local.get $argument82)
        )
       )
       (local.set $local20
        (i64.extend_i32_u
         (struct.get $type18 1
          (ref.as_non_null
           (local.get $local21)
          )
         )
        )
       )
       (i64.gt_s
        (local.get $local19)
        (local.get $local20)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local3
     (local.get $argument84)
    )
    (local.set $local4
     (local.get $argument83)
    )
    (local.set $local2
     (i64.sub
      (local.get $local3)
      (local.get $local4)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local1
     (call $function25
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local7
     (i64.const 0)
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $argument82)
     )
    )
    (local.set $local9
     (local.get $argument83)
    )
    (local.set $local10
     (local.get $argument84)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local6)
      )
      (local.get $local7)
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
 )
 (func $function34 (type $call48) (param $environment eqref) (param $argument89 (ref $type18)) (result (ref $type18))
  (local $local0 (ref null $type18))
  (local $local3 (ref null $type18))
  (local $local4 (ref null $type47))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument89)
   )
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument89)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (return_call $function33
   (struct.get $type47 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function35 (type $call49) (param $environment eqref) (param $argument91 (ref null $type50)) (result (ref $type18))
  (local $local0 i32)
  (local $local2 i64)
  (local $local8 i64)
  (local $local1 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local3 (ref null $type50))
  (local $local7 (ref null $type50))
  (local $local4 (ref null $type51))
  (local $local5 (ref null $type43))
  (local $local9 (ref null $type52))
  (local.set $local3
   (local.get $argument91)
  )
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $local2
   (call $function36
    (struct.get $type51 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type43 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (local.get $argument91)
  )
  (local.set $local8
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (call $function38
    (struct.get $type52 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (local.get $local7)
    (local.get $local8)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function36 (type $call51) (param $environment eqref) (param $argument94 (ref null $type50)) (result i64)
  (local $local0 (ref null $type50))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument94)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function37
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function37 (param $capture95 i32) (param $initialized95 i32) (param $argument96 (ref null $type50)) (param $argument97 i64) (result i64)
  (local $local0 (ref null $type50))
  (local $local1 (ref null $type50))
  (local $local6 (ref null $type50))
  (local $local7 (ref null $type50))
  (local $local5 (ref null $type18))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local.set $local8
   (local.get $argument97)
  )
  (local.set $local9
   (i64.const 4294967294)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local7
     (local.get $argument96)
    )
    (if (result i64)
     (ref.is_null
      (local.get $local7)
     )
     (then
      (local.get $argument97)
     )
     (else
      (local.set $local1
       (local.get $argument96)
      )
      (local.set $local0
       (struct.get $type50 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument97)
      )
      (local.set $local6
       (local.get $argument96)
      )
      (local.set $local5
       (struct.get $type50 0
        (local.get $local6)
       )
      )
      (local.set $local4
       (i64.extend_i32_u
        (struct.get $type18 1
         (ref.as_non_null
          (local.get $local5)
         )
        )
       )
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized95)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture95)
      )
      (return_call $function37
       (local.get $capture95)
       (local.get $initialized95)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call52) (param $environment eqref) (param $argument99 (ref $type18)) (param $argument100 (ref null $type50)) (param $argument101 i64) (result i32)
  (local $local0 i32)
  (local $local1 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local2 (ref null $type18))
  (local $local4 (ref null $type18))
  (local $local11 (ref null $type18))
  (local $local13 (ref null $type18))
  (local $local3 (ref null $type50))
  (local $local5 (ref null $type50))
  (local $local6 (ref null $type50))
  (local $local14 (ref null $type50))
  (local $local17 (ref null $type50))
  (local $local10 (ref null $type52))
  (local.set $local17
   (local.get $argument100)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local17)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (local.get $argument100)
    )
    (local.set $local2
     (struct.get $type50 0
      (local.get $local3)
     )
    )
    (local.set $local1
     (i64.extend_i32_u
      (struct.get $type18 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $argument99)
     )
    )
    (local.set $local12
     (local.get $argument101)
    )
    (local.set $local14
     (local.get $argument100)
    )
    (local.set $local13
     (struct.get $type50 0
      (local.get $local14)
     )
    )
    (local.set $local15
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local11)
      )
      (local.get $local12)
      (ref.as_non_null
       (local.get $local13)
      )
      (local.get $local15)
      (local.get $local16)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (local.get $argument99)
     )
    )
    (local.set $local6
     (local.get $argument100)
    )
    (local.set $local5
     (struct.get $type50 1
      (local.get $local6)
     )
    )
    (local.set $local8
     (local.get $argument101)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (local.get $local1)
    )
    (local.set $local7
     (i64.add
      (local.get $local8)
      (local.get $local9)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (struct.get $type52 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (ref.as_non_null
      (local.get $local4)
     )
     (local.get $local5)
     (local.get $local7)
    )
   )
  )
 )
 (func $function39 (type $call53) (param $environment eqref) (param $argument104 (ref $type18)) (param $argument105 (ref $type18)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 (ref null $type18))
  (local $local6 (ref null $type18))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument104)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $argument105)
   )
  )
  (local.set $local5
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local3)
    (local.get $local5)
   )
   (then
    (local.set $local0
     (i64.const 0)
    )
    (local.set $local2
     (i32.const 0)
    )
    (local.set $local1
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local2)
    )
    (return_call $function40
     (ref.as_non_null
      (local.get $argument104)
     )
     (ref.as_non_null
      (local.get $argument105)
     )
     (local.get $local2)
     (local.get $local1)
     (local.get $local0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function40 (param $capture104 (ref $type18)) (param $capture105 (ref $type18)) (param $capture106 i32) (param $initialized106 i32) (param $argument107 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local8 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local14 i64)
  (local $local4 (ref null $type18))
  (local $local9 (ref null $type18))
  (local $local13 (ref null $type18))
  (local.set $local2
   (local.get $argument107)
  )
  (local.set $local4
   (ref.as_non_null
    (local.get $capture104)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local1
   (i64.eq
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local9
     (ref.as_non_null
      (local.get $capture104)
     )
    )
    (local.set $local10
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local10)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (i32.wrap_i64
      (local.get $local10)
     )
    )
    (local.set $local8
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local9)
       )
       (local.get $local11)
      )
      (i32.and
       (local.get $local11)
       (i32.const 8191)
      )
     )
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $capture105)
     )
    )
    (local.set $local14
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local14)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (i32.wrap_i64
      (local.get $local14)
     )
    )
    (local.set $local12
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local13)
       )
       (local.get $local15)
      )
      (i32.and
       (local.get $local15)
       (i32.const 8191)
      )
     )
    )
    (if (result i32)
     (i32.eq
      (local.get $local8)
      (local.get $local12)
     )
     (then
      (local.set $local6
       (local.get $argument107)
      )
      (local.set $local7
       (i64.const 1)
      )
      (local.set $local5
       (i64.add
        (local.get $local6)
        (local.get $local7)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized106)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture106)
      )
      (return_call $function40
       (ref.as_non_null
        (local.get $capture104)
       )
       (ref.as_non_null
        (local.get $capture105)
       )
       (local.get $capture106)
       (local.get $initialized106)
       (local.get $local5)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call54) (param $environment eqref) (param $argument110 i64) (result (ref $type36))
  (local $local0 i64)
  (local $local1 i64)
  (local.set $local0
   (local.get $argument110)
  )
  (local.set $local1
   (i64.const 0)
  )
  (struct.new $type36
   (i32.const 1)
   (block (result (ref (exact $type37)))
    (if
     (i64.gt_u
      (local.get $local1)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.new $type37
     (i32.wrap_i64
      (local.get $local1)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local0)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local0)
      )
     )
    )
   )
  )
 )
 (func $function42 (type $call55) (param $environment eqref) (param $argument112 (ref null $type56)) (result (ref $type36))
  (local $local0 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local2 i64)
  (local $local7 i64)
  (local $local1 (ref null $type36))
  (local $local3 (ref null $type56))
  (local $local6 (ref null $type56))
  (local $local4 (ref null $type57))
  (local $local5 (ref null $type54))
  (local.set $local3
   (local.get $argument112)
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (local.set $local2
   (call $function43
    (struct.get $type57 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (local.set $local1
   (call $function41
    (struct.get $type54 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local6
   (local.get $argument112)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function45
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local9)
   (local.get $local8)
   (local.get $local6)
   (local.get $local7)
  )
 )
 (func $function43 (type $call57) (param $environment eqref) (param $argument115 (ref null $type56)) (result i64)
  (local $local0 (ref null $type56))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument115)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function44
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function44 (param $capture116 i32) (param $initialized116 i32) (param $argument117 (ref null $type56)) (param $argument118 i64) (result i64)
  (local $local0 (ref null $type56))
  (local $local1 (ref null $type56))
  (local $local7 (ref null $type56))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local.set $local7
   (local.get $argument117)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local7)
   )
   (then
    (local.get $argument118)
   )
   (else
    (local.set $local5
     (local.get $argument118)
    )
    (local.set $local6
     (i64.const 4294967295)
    )
    (if (result i64)
     (i64.eq
      (local.get $local5)
      (local.get $local6)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local1
       (local.get $argument117)
      )
      (local.set $local0
       (struct.get $type56 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument118)
      )
      (local.set $local4
       (i64.const 1)
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized116)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture116)
      )
      (return_call $function44
       (local.get $capture116)
       (local.get $initialized116)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function45 (param $capture113 (ref $type36)) (param $capture119 i32) (param $initialized119 i32) (param $argument120 (ref null $type56)) (param $argument121 i64) (result (ref $type36))
  (local $local0 (ref null $type56))
  (local $local1 (ref null $type56))
  (local $local8 (ref null $type56))
  (local $local9 (ref null $type56))
  (local $local5 (ref null $type36))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local.set $local9
   (local.get $argument120)
  )
  (if (result (ref $type36))
   (ref.is_null
    (local.get $local9)
   )
   (then
    (ref.as_non_null
     (local.get $capture113)
    )
   )
   (else
    (local.set $local5
     (ref.as_non_null
      (local.get $capture113)
     )
    )
    (local.set $local6
     (local.get $argument121)
    )
    (local.set $local8
     (local.get $argument120)
    )
    (local.set $local7
     (struct.get $type56 0
      (local.get $local8)
     )
    )
    (if
     (i32.ne
      (struct.get $type36 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type37
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local5)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local6)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local6)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local7)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local7)
      )
     )
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument120)
    )
    (local.set $local0
     (struct.get $type56 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument121)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized119)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture119)
    )
    (return_call $function45
     (ref.as_non_null
      (local.get $capture113)
     )
     (local.get $capture119)
     (local.get $initialized119)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function46 (type $call59) (param $environment eqref) (param $argument123 (ref $type36)) (param $argument124 i64) (param $argument125 (ref $type36)) (param $argument126 i64) (result i32)
  (local $local0 (ref null $type36))
  (local $local2 (ref null $type36))
  (local $local5 (ref null $type36))
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument123)
   )
  )
  (local.set $local1
   (local.get $argument124)
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument125)
   )
  )
  (local.set $local3
   (local.get $argument126)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument125)
   )
  )
  (local.set $local4
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local5)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type36 0
     (ref.as_non_null
      (local.get $local0)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.lt_s
    (local.get $local4)
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type37 $type37
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local0)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local1)
    )
   )
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local3)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (i64.sub
       (local.get $local4)
       (local.get $local3)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (i64.sub
      (local.get $local4)
      (local.get $local3)
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function47 (type $call60) (param $environment eqref) (param $argument128 (ref $type36)) (param $argument129 i64) (param $argument130 (ref $type36)) (result i32)
  (local $local0 (ref null $type36))
  (local $local2 (ref null $type36))
  (local $local5 (ref null $type36))
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument128)
   )
  )
  (local.set $local1
   (local.get $argument129)
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument130)
   )
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument130)
   )
  )
  (local.set $local4
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local5)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type36 0
     (ref.as_non_null
      (local.get $local0)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.lt_s
    (local.get $local4)
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type37 $type37
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local0)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local1)
    )
   )
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local3)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (i64.sub
       (local.get $local4)
       (local.get $local3)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (i64.sub
      (local.get $local4)
      (local.get $local3)
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function48 (type $call61) (param $environment eqref) (param $argument132 (ref $type36)) (param $argument133 i64) (param $argument134 i64) (result (ref $type36))
  (local $local0 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local1 (ref null $type36))
  (local $local6 (ref null $type36))
  (local $local8 (ref null $type36))
  (local $local12 (ref null $type36))
  (local $local5 (ref null $type54))
  (local $local15 (ref null $type58))
  (local.set $local12
   (ref.as_non_null
    (local.get $argument132)
   )
  )
  (local.set $local11
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local12)
      )
     )
    )
   )
  )
  (local.set $local13
   (local.get $argument133)
  )
  (local.set $local14
   (local.get $argument134)
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (drop
   (call $function49
    (struct.get $type58 1
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (local.get $local11)
    (local.get $local13)
    (local.get $local14)
   )
  )
  (local.set $local3
   (local.get $argument134)
  )
  (local.set $local4
   (local.get $argument133)
  )
  (local.set $local2
   (i64.sub
    (local.get $local3)
    (local.get $local4)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (local.set $local1
   (call $function41
    (struct.get $type54 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $argument132)
   )
  )
  (local.set $local9
   (local.get $argument133)
  )
  (local.set $local10
   (local.get $argument134)
  )
  (if
   (i32.ne
    (struct.get $type36 0
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.lt_s
    (local.get $local10)
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type37 $type37
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local6)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local7)
    )
   )
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local8)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local9)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (i64.sub
       (local.get $local10)
       (local.get $local9)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (i64.sub
      (local.get $local10)
      (local.get $local9)
     )
    )
   )
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function49 (type $call58) (param $environment eqref) (param $argument136 i64) (param $argument137 i64) (param $argument138 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local.set $local2
   (local.get $argument137)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local1
   (i64.lt_s
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.get $local1)
    (then
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local1)
    )
    (else
     (local.set $local6
      (local.get $argument138)
     )
     (local.set $local7
      (local.get $argument137)
     )
     (local.set $local5
      (i64.lt_s
       (local.get $local6)
       (local.get $local7)
      )
     )
     (local.set $local4
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local4)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local5)
      (then
       (if
        (i32.eqz
         (local.get $local4)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local5)
      )
      (else
       (local.set $local8
        (local.get $argument138)
       )
       (local.set $local9
        (local.get $argument136)
       )
       (i64.gt_s
        (local.get $local8)
        (local.get $local9)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function50 (type $call62) (param $environment eqref) (param $argument143 (ref $type36)) (param $argument144 i64) (result (ref $type36))
  (local $local0 (ref null $type36))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type61))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument143)
   )
  )
  (local.set $local1
   (local.get $argument144)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument143)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (return_call $function48
   (struct.get $type61 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function51 (type $call63) (param $environment eqref) (param $argument146 (ref $type36)) (result (ref $type36))
  (local $local0 (ref null $type36))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type61))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument146)
   )
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument146)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (return_call $function48
   (struct.get $type61 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function52 (type $call64) (param $environment eqref) (param $argument148 (ref null $type65)) (result (ref $type36))
  (local $local0 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local2 i64)
  (local $local7 i64)
  (local $local1 (ref null $type36))
  (local $local3 (ref null $type65))
  (local $local6 (ref null $type65))
  (local $local4 (ref null $type66))
  (local $local5 (ref null $type54))
  (local.set $local3
   (local.get $argument148)
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (local.set $local2
   (call $function53
    (struct.get $type66 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (local.set $local1
   (call $function41
    (struct.get $type54 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local6
   (local.get $argument148)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function55
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local9)
   (local.get $local8)
   (local.get $local6)
   (local.get $local7)
  )
 )
 (func $function53 (type $call66) (param $environment eqref) (param $argument151 (ref null $type65)) (result i64)
  (local $local0 (ref null $type65))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument151)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function54
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function54 (param $capture152 i32) (param $initialized152 i32) (param $argument153 (ref null $type65)) (param $argument154 i64) (result i64)
  (local $local0 (ref null $type65))
  (local $local1 (ref null $type65))
  (local $local6 (ref null $type65))
  (local $local7 (ref null $type65))
  (local $local5 (ref null $type36))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local.set $local8
   (local.get $argument154)
  )
  (local.set $local9
   (i64.const 4294967295)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local7
     (local.get $argument153)
    )
    (if (result i64)
     (ref.is_null
      (local.get $local7)
     )
     (then
      (local.get $argument154)
     )
     (else
      (local.set $local1
       (local.get $argument153)
      )
      (local.set $local0
       (struct.get $type65 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument154)
      )
      (local.set $local6
       (local.get $argument153)
      )
      (local.set $local5
       (struct.get $type65 0
        (local.get $local6)
       )
      )
      (local.set $local4
       (i64.extend_i32_u
        (array.len
         (struct.get $type36 1
          (ref.as_non_null
           (local.get $local5)
          )
         )
        )
       )
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized152)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture152)
      )
      (return_call $function54
       (local.get $capture152)
       (local.get $initialized152)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function55 (param $capture149 (ref $type36)) (param $capture155 i32) (param $initialized155 i32) (param $argument156 (ref null $type65)) (param $argument157 i64) (result (ref $type36))
  (local $local0 i32)
  (local $local1 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local2 (ref null $type36))
  (local $local9 (ref null $type36))
  (local $local11 (ref null $type36))
  (local $local3 (ref null $type65))
  (local $local4 (ref null $type65))
  (local $local5 (ref null $type65))
  (local $local12 (ref null $type65))
  (local $local15 (ref null $type65))
  (local.set $local15
   (local.get $argument156)
  )
  (if (result (ref $type36))
   (ref.is_null
    (local.get $local15)
   )
   (then
    (ref.as_non_null
     (local.get $capture149)
    )
   )
   (else
    (local.set $local3
     (local.get $argument156)
    )
    (local.set $local2
     (struct.get $type65 0
      (local.get $local3)
     )
    )
    (local.set $local1
     (i64.extend_i32_u
      (array.len
       (struct.get $type36 1
        (ref.as_non_null
         (local.get $local2)
        )
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $capture149)
     )
    )
    (local.set $local10
     (local.get $argument157)
    )
    (local.set $local12
     (local.get $argument156)
    )
    (local.set $local11
     (struct.get $type65 0
      (local.get $local12)
     )
    )
    (local.set $local13
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (local.get $local1)
    )
    (if
     (i32.ne
      (struct.get $type36 0
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $local14)
      (local.get $local13)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type37 $type37
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local9)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local10)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local10)
      )
     )
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local11)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local13)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local13)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (i64.sub
         (local.get $local14)
         (local.get $local13)
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (i64.sub
        (local.get $local14)
        (local.get $local13)
       )
      )
     )
    )
    (drop
     (i32.const 0)
    )
    (local.set $local5
     (local.get $argument156)
    )
    (local.set $local4
     (struct.get $type65 1
      (local.get $local5)
     )
    )
    (local.set $local7
     (local.get $argument157)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (local.set $local6
     (i64.add
      (local.get $local7)
      (local.get $local8)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture155)
    )
    (return_call $function55
     (ref.as_non_null
      (local.get $capture149)
     )
     (local.get $capture155)
     (local.get $initialized155)
     (local.get $local4)
     (local.get $local6)
    )
   )
  )
 )
 (func $function56 (type $call69) (param $environment eqref) (param $argument160 (ref $type36)) (param $argument161 i64) (result i64)
  (local $local0 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local2 (ref null $type36))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument160)
   )
  )
  (local.set $local3
   (local.get $argument161)
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.get_u $type37
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local2)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local3)
      )
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (local.get $local1)
  )
  (local.set $local9
   (i64.const 128)
  )
  (local.set $local7
   (i64.lt_s
    (local.get $local8)
    (local.get $local9)
   )
  )
  (local.set $local6
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local6)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (if (result i32)
    (local.get $local7)
    (then
     (if
      (i32.eqz
       (local.get $local6)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local7)
    )
    (else
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local10
      (local.get $local1)
     )
     (local.set $local11
      (i64.const 191)
     )
     (i64.gt_s
      (local.get $local10)
      (local.get $local11)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (local.get $local1)
    )
    (local.set $local5
     (i64.const 128)
    )
    (i64.sub
     (local.get $local4)
     (local.get $local5)
    )
   )
  )
 )
 (func $function57 (type $call72) (param $environment eqref) (param $argument165 (ref $type36)) (param $argument166 i64) (param $argument167 i64) (result (ref $type18))
  (local $local0 i32)
  (local $local2 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local1 (ref null $type18))
  (local $local8 (ref null $type18))
  (local $local3 (ref null $type36))
  (local $local9 (ref null $type36))
  (local $local14 (ref null $type36))
  (local $local6 (ref null $type68))
  (local $local7 (ref null $type43))
  (local $local12 (ref null $type71))
  (local $local17 (ref null $type58))
  (local.set $local14
   (ref.as_non_null
    (local.get $argument165)
   )
  )
  (local.set $local13
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local14)
      )
     )
    )
   )
  )
  (local.set $local15
   (local.get $argument166)
  )
  (local.set $local16
   (local.get $argument167)
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (drop
   (call $function49
    (struct.get $type58 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (local.get $local13)
    (local.get $local15)
    (local.get $local16)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument165)
   )
  )
  (local.set $local4
   (local.get $argument166)
  )
  (local.set $local5
   (local.get $argument167)
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (local.set $local2
   (call $function58
    (struct.get $type68 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (ref.as_non_null
     (local.get $local3)
    )
    (local.get $local4)
    (local.get $local5)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type43 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $argument165)
   )
  )
  (local.set $local10
   (local.get $argument166)
  )
  (local.set $local11
   (local.get $argument167)
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (drop
   (call $function66
    (struct.get $type71 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local8)
    )
    (ref.as_non_null
     (local.get $local9)
    )
    (local.get $local10)
    (local.get $local11)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function58 (type $call68) (param $environment eqref) (param $argument170 (ref $type36)) (param $argument171 i64) (param $argument172 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument171)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function59
   (ref.as_non_null
    (local.get $argument170)
   )
   (local.get $argument172)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function59 (param $capture170 (ref $type36)) (param $capture172 i64) (param $capture173 i32) (param $initialized173 i32) (param $argument174 i64) (param $argument175 i64) (result i64)
  (local $local0 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local2 (ref null $type36))
  (local $local12 (ref null $type36))
  (local $local5 (ref null $type68))
  (local $local15 (ref null $type70))
  (local.set $local16
   (local.get $argument174)
  )
  (local.set $local17
   (local.get $capture172)
  )
  (if (result i64)
   (i64.eq
    (local.get $local16)
    (local.get $local17)
   )
   (then
    (local.get $argument175)
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $capture170)
     )
    )
    (local.set $local3
     (local.get $argument174)
    )
    (local.set $local4
     (local.get $capture172)
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (local.set $local1
     (call $function60
      (struct.get $type68 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (local.get $local3)
      (local.get $local4)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $capture170)
     )
    )
    (local.set $local13
     (local.get $argument174)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (local.get $local1)
    )
    (local.set $local15
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (drop
     (call $function62
      (struct.get $type70 1
       (ref.as_non_null
        (local.get $local15)
       )
      )
      (ref.as_non_null
       (local.get $local12)
      )
      (local.get $local13)
      (local.get $local14)
     )
    )
    (local.set $local7
     (local.get $argument174)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (local.set $local6
     (i64.add
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local10
     (local.get $argument175)
    )
    (local.set $local11
     (i64.const 1)
    )
    (local.set $local9
     (i64.add
      (local.get $local10)
      (local.get $local11)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized173)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture173)
    )
    (return_call $function59
     (ref.as_non_null
      (local.get $capture170)
     )
     (local.get $capture172)
     (local.get $capture173)
     (local.get $initialized173)
     (local.get $local6)
     (local.get $local9)
    )
   )
  )
 )
 (func $function60 (type $call68) (param $environment eqref) (param $argument178 (ref $type36)) (param $argument179 i64) (param $argument180 i64) (result i64)
  (local $local0 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local3 (ref null $type36))
  (local $local5 (ref null $type67))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument178)
   )
  )
  (local.set $local4
   (local.get $argument179)
  )
  (local.set $local2
   (i64.extend_i32_u
    (array.get_u $type37
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local4)
      )
     )
    )
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (local.set $local1
   (call $function61
    (struct.get $type67 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local8
   (local.get $argument180)
  )
  (local.set $local9
   (local.get $argument179)
  )
  (local.set $local7
   (i64.sub
    (local.get $local8)
    (local.get $local9)
   )
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
  )
 )
 (func $function61 (type $call67) (param $environment eqref) (param $argument183 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local.set $local12
   (local.get $argument183)
  )
  (local.set $local13
   (i64.const 128)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local12)
    (local.get $local13)
   )
   (then
    (i64.const 1)
   )
   (else
    (local.set $local10
     (local.get $argument183)
    )
    (local.set $local11
     (i64.const 194)
    )
    (if (result i64)
     (if (result i32)
      (i64.ge_s
       (local.get $local10)
       (local.get $local11)
      )
      (then
       (local.set $local8
        (local.get $argument183)
       )
       (local.set $local9
        (i64.const 224)
       )
       (i64.lt_s
        (local.get $local8)
        (local.get $local9)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (i64.const 2)
     )
     (else
      (local.set $local6
       (local.get $argument183)
      )
      (local.set $local7
       (i64.const 224)
      )
      (if (result i64)
       (if (result i32)
        (i64.ge_s
         (local.get $local6)
         (local.get $local7)
        )
        (then
         (local.set $local4
          (local.get $argument183)
         )
         (local.set $local5
          (i64.const 240)
         )
         (i64.lt_s
          (local.get $local4)
          (local.get $local5)
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (i64.const 3)
       )
       (else
        (local.set $local2
         (local.get $argument183)
        )
        (local.set $local3
         (i64.const 240)
        )
        (if (result i64)
         (if (result i32)
          (i64.ge_s
           (local.get $local2)
           (local.get $local3)
          )
          (then
           (local.set $local0
            (local.get $argument183)
           )
           (local.set $local1
            (i64.const 245)
           )
           (i64.lt_s
            (local.get $local0)
            (local.get $local1)
           )
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (i64.const 4)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function62 (type $call70) (param $environment eqref) (param $argument185 (ref $type36)) (param $argument186 i64) (param $argument187 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local8 i32)
  (local $local9 i32)
  (local $local3 (ref null $type36))
  (local $local7 (ref null $type67))
  (local.set $local0
   (i64.const 1)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument185)
   )
  )
  (local.set $local4
   (local.get $argument186)
  )
  (local.set $local2
   (i64.extend_i32_u
    (array.get_u $type37
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local4)
      )
     )
    )
   )
  )
  (local.set $local6
   (local.get $argument187)
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global188)
   )
  )
  (local.set $local5
   (call $function63
    (struct.get $type67 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local6)
   )
  )
  (local.set $local1
   (i64.sub
    (local.get $local2)
    (local.get $local5)
   )
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (return_call $function64
   (ref.as_non_null
    (local.get $argument185)
   )
   (local.get $argument186)
   (local.get $argument187)
   (local.get $local9)
   (local.get $local8)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function63 (type $call67) (param $environment eqref) (param $argument189 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local.set $local4
   (local.get $argument189)
  )
  (local.set $local5
   (i64.const 1)
  )
  (if (result i64)
   (i64.eq
    (local.get $local4)
    (local.get $local5)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $local2
     (local.get $argument189)
    )
    (local.set $local3
     (i64.const 2)
    )
    (if (result i64)
     (i64.eq
      (local.get $local2)
      (local.get $local3)
     )
     (then
      (i64.const 192)
     )
     (else
      (local.set $local0
       (local.get $argument189)
      )
      (local.set $local1
       (i64.const 3)
      )
      (if (result i64)
       (i64.eq
        (local.get $local0)
        (local.get $local1)
       )
       (then
        (i64.const 224)
       )
       (else
        (i64.const 240)
       )
      )
     )
    )
   )
  )
 )
 (func $function64 (param $capture185 (ref $type36)) (param $capture186 i64) (param $capture187 i64) (param $capture190 i32) (param $initialized190 i32) (param $argument191 i64) (param $argument192 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local8 (ref null $type36))
  (local $local12 (ref null $type69))
  (local $local17 (ref null $type67))
  (local.set $local18
   (local.get $argument191)
  )
  (local.set $local19
   (local.get $capture187)
  )
  (if (result i32)
   (i64.eq
    (local.get $local18)
    (local.get $local19)
   )
   (then
    (local.set $local14
     (local.get $argument192)
    )
    (local.set $local16
     (local.get $capture187)
    )
    (local.set $local17
     (ref.as_non_null
      (global.get $global193)
     )
    )
    (local.set $local15
     (call $function65
      (struct.get $type67 1
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (local.get $local16)
     )
    )
    (if (result i32)
     (i64.lt_s
      (local.get $local14)
      (local.get $local15)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local13
       (local.get $argument192)
      )
      (if
       (i64.gt_u
        (local.get $local13)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.ge_u
         (local.get $local13)
         (i64.const 55296)
        )
        (i64.le_u
         (local.get $local13)
         (i64.const 57343)
        )
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local13)
      )
     )
    )
   )
   (else
    (local.set $local1
     (local.get $argument191)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local5
     (local.get $argument192)
    )
    (local.set $local6
     (i64.const 64)
    )
    (local.set $local4
     (i64.mul
      (local.get $local5)
      (local.get $local6)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $capture185)
     )
    )
    (local.set $local10
     (local.get $capture186)
    )
    (local.set $local11
     (local.get $argument191)
    )
    (local.set $local9
     (i64.add
      (local.get $local10)
      (local.get $local11)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global159)
     )
    )
    (local.set $local7
     (call $function56
      (struct.get $type69 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
     )
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local7)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture190)
    )
    (return_call $function64
     (ref.as_non_null
      (local.get $capture185)
     )
     (local.get $capture186)
     (local.get $capture187)
     (local.get $capture190)
     (local.get $initialized190)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function65 (type $call67) (param $environment eqref) (param $argument194 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local.set $local4
   (local.get $argument194)
  )
  (local.set $local5
   (i64.const 1)
  )
  (if (result i64)
   (i64.eq
    (local.get $local4)
    (local.get $local5)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $local2
     (local.get $argument194)
    )
    (local.set $local3
     (i64.const 2)
    )
    (if (result i64)
     (i64.eq
      (local.get $local2)
      (local.get $local3)
     )
     (then
      (i64.const 128)
     )
     (else
      (local.set $local0
       (local.get $argument194)
      )
      (local.set $local1
       (i64.const 3)
      )
      (if (result i64)
       (i64.eq
        (local.get $local0)
        (local.get $local1)
       )
       (then
        (i64.const 2048)
       )
       (else
        (i64.const 65536)
       )
      )
     )
    )
   )
  )
 )
 (func $function66 (type $call71) (param $environment eqref) (param $argument196 (ref $type18)) (param $argument197 (ref $type36)) (param $argument198 i64) (param $argument199 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument198)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function67
   (ref.as_non_null
    (local.get $argument196)
   )
   (ref.as_non_null
    (local.get $argument197)
   )
   (local.get $argument199)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function67 (param $capture196 (ref $type18)) (param $capture197 (ref $type36)) (param $capture199 i64) (param $capture200 i32) (param $initialized200 i32) (param $argument201 i64) (param $argument202 i64) (result i32)
  (local $local0 i32)
  (local $local14 i32)
  (local $local19 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local2 (ref null $type36))
  (local $local15 (ref null $type36))
  (local $local5 (ref null $type68))
  (local $local12 (ref null $type18))
  (local $local18 (ref null $type70))
  (local.set $local20
   (local.get $argument201)
  )
  (local.set $local21
   (local.get $capture199)
  )
  (if (result i32)
   (i64.eq
    (local.get $local20)
    (local.get $local21)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $capture197)
     )
    )
    (local.set $local3
     (local.get $argument201)
    )
    (local.set $local4
     (local.get $capture199)
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (local.set $local1
     (call $function60
      (struct.get $type68 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (local.get $local3)
      (local.get $local4)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $capture196)
     )
    )
    (local.set $local13
     (local.get $argument202)
    )
    (local.set $local15
     (ref.as_non_null
      (local.get $capture197)
     )
    )
    (local.set $local16
     (local.get $argument201)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (local.get $local1)
    )
    (local.set $local18
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (local.set $local14
     (call $function62
      (struct.get $type70 1
       (ref.as_non_null
        (local.get $local18)
       )
      )
      (ref.as_non_null
       (local.get $local15)
      )
      (local.get $local16)
      (local.get $local17)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local13)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local12)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (i32.wrap_i64
      (local.get $local13)
     )
    )
    (array.set $type19
     (call $string-block
      (ref.as_non_null
       (local.get $local12)
      )
      (local.get $local19)
     )
     (i32.and
      (local.get $local19)
      (i32.const 8191)
     )
     (local.get $local14)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local7
     (local.get $argument201)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (local.set $local6
     (i64.add
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local10
     (local.get $argument202)
    )
    (local.set $local11
     (i64.const 1)
    )
    (local.set $local9
     (i64.add
      (local.get $local10)
      (local.get $local11)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized200)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture200)
    )
    (return_call $function67
     (ref.as_non_null
      (local.get $capture196)
     )
     (ref.as_non_null
      (local.get $capture197)
     )
     (local.get $capture199)
     (local.get $capture200)
     (local.get $initialized200)
     (local.get $local6)
     (local.get $local9)
    )
   )
  )
 )
 (func $function68 (type $call73) (param $environment eqref) (param $argument205 (ref $type36)) (param $argument206 i64) (result (ref $type18))
  (local $local0 (ref null $type36))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type72))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument205)
   )
  )
  (local.set $local1
   (local.get $argument206)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument205)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (return_call $function57
   (struct.get $type72 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function69 (type $call74) (param $environment eqref) (param $argument208 (ref $type36)) (result (ref $type18))
  (local $local0 (ref null $type36))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type72))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument208)
   )
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument208)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (return_call $function57
   (struct.get $type72 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function70 (type $call76) (param $environment eqref) (param $argument210 (ref $type36)) (param $argument211 i64) (param $argument212 i64) (param $argument213 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument213)
  )
  (local.set $local1
   (local.get $argument212)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function71
   (ref.as_non_null
    (local.get $argument210)
   )
   (local.get $argument211)
   (local.get $argument213)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function71 (param $capture210 (ref $type36)) (param $capture211 i64) (param $capture213 i64) (param $capture214 i32) (param $initialized214 i32) (param $argument215 i64) (param $argument216 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local6 (ref null $type36))
  (local $local17 (ref null $type36))
  (local $local22 (ref null $type67))
  (local.set $local24
   (local.get $argument215)
  )
  (local.set $local25
   (i64.const 1)
  )
  (if (result i32)
   (i64.eq
    (local.get $local24)
    (local.get $local25)
   )
   (then
    (local.set $local17
     (ref.as_non_null
      (local.get $capture210)
     )
    )
    (local.set $local18
     (local.get $capture211)
    )
    (local.set $local21
     (local.get $capture213)
    )
    (local.set $local22
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (local.set $local20
     (call $function63
      (struct.get $type67 1
       (ref.as_non_null
        (local.get $local22)
       )
      )
      (local.get $local21)
     )
    )
    (local.set $local23
     (local.get $argument216)
    )
    (local.set $local19
     (i64.add
      (local.get $local20)
      (local.get $local23)
     )
    )
    (if
     (i32.ne
      (struct.get $type36 0
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type37
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local17)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local18)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local18)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local19)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local19)
      )
     )
    )
    (i32.const 0)
   )
   (else
    (local.set $local6
     (ref.as_non_null
      (local.get $capture210)
     )
    )
    (local.set $local8
     (local.get $capture211)
    )
    (local.set $local10
     (local.get $argument215)
    )
    (local.set $local11
     (i64.const 1)
    )
    (local.set $local9
     (i64.sub
      (local.get $local10)
      (local.get $local11)
     )
    )
    (local.set $local7
     (i64.add
      (local.get $local8)
      (local.get $local9)
     )
    )
    (local.set $local13
     (i64.const 128)
    )
    (local.set $local15
     (local.get $argument216)
    )
    (local.set $local16
     (i64.const 64)
    )
    (local.set $local14
     (i64.rem_s
      (local.get $local15)
      (local.get $local16)
     )
    )
    (local.set $local12
     (i64.add
      (local.get $local13)
      (local.get $local14)
     )
    )
    (if
     (i32.ne
      (struct.get $type36 0
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type37
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local6)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local7)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local7)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local12)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local12)
      )
     )
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument215)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument216)
    )
    (local.set $local5
     (i64.const 64)
    )
    (local.set $local3
     (i64.div_s
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized214)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture214)
    )
    (return_call $function71
     (ref.as_non_null
      (local.get $capture210)
     )
     (local.get $capture211)
     (local.get $capture213)
     (local.get $capture214)
     (local.get $initialized214)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function72 (type $call78) (param $environment eqref) (param $argument218 (ref $type18)) (param $argument219 i64) (param $argument220 i64) (result (ref $type36))
  (local $local0 i32)
  (local $local2 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local1 (ref null $type36))
  (local $local8 (ref null $type36))
  (local $local3 (ref null $type18))
  (local $local9 (ref null $type18))
  (local $local14 (ref null $type18))
  (local $local6 (ref null $type75))
  (local $local7 (ref null $type54))
  (local $local12 (ref null $type77))
  (local $local17 (ref null $type58))
  (local.set $local14
   (ref.as_non_null
    (local.get $argument218)
   )
  )
  (local.set $local13
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
   )
  )
  (local.set $local15
   (local.get $argument219)
  )
  (local.set $local16
   (local.get $argument220)
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (drop
   (call $function49
    (struct.get $type58 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (local.get $local13)
    (local.get $local15)
    (local.get $local16)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument218)
   )
  )
  (local.set $local4
   (local.get $argument219)
  )
  (local.set $local5
   (local.get $argument220)
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global222)
   )
  )
  (local.set $local2
   (call $function73
    (struct.get $type75 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (ref.as_non_null
     (local.get $local3)
    )
    (local.get $local4)
    (local.get $local5)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (local.set $local1
   (call $function41
    (struct.get $type54 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $argument218)
   )
  )
  (local.set $local10
   (local.get $argument219)
  )
  (local.set $local11
   (local.get $argument220)
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global231)
   )
  )
  (drop
   (call $function76
    (struct.get $type77 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local8)
    )
    (ref.as_non_null
     (local.get $local9)
    )
    (local.get $local10)
    (local.get $local11)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function73 (type $call75) (param $environment eqref) (param $argument223 (ref $type18)) (param $argument224 i64) (param $argument225 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument224)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function74
   (ref.as_non_null
    (local.get $argument223)
   )
   (local.get $argument225)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function74 (param $capture223 (ref $type18)) (param $capture225 i64) (param $capture226 i32) (param $initialized226 i32) (param $argument227 i64) (param $argument228 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local7 i32)
  (local $local10 i32)
  (local $local8 (ref null $type18))
  (local $local11 (ref null $type67))
  (local.set $local14
   (local.get $argument228)
  )
  (local.set $local15
   (i64.const 4294967295)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local14)
    (local.get $local15)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local12
     (local.get $argument227)
    )
    (local.set $local13
     (local.get $capture225)
    )
    (if (result i64)
     (i64.eq
      (local.get $local12)
      (local.get $local13)
     )
     (then
      (local.get $argument228)
     )
     (else
      (local.set $local1
       (local.get $argument227)
      )
      (local.set $local2
       (i64.const 1)
      )
      (local.set $local0
       (i64.add
        (local.get $local1)
        (local.get $local2)
       )
      )
      (local.set $local4
       (local.get $argument228)
      )
      (local.set $local8
       (ref.as_non_null
        (local.get $capture223)
       )
      )
      (local.set $local9
       (local.get $argument227)
      )
      (if
       (i64.ge_u
        (local.get $local9)
        (i64.extend_i32_u
         (struct.get $type18 1
          (ref.as_non_null
           (local.get $local8)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $local10
       (i32.wrap_i64
        (local.get $local9)
       )
      )
      (local.set $local7
       (array.get $type19
        (call $string-block
         (ref.as_non_null
          (local.get $local8)
         )
         (local.get $local10)
        )
        (i32.and
         (local.get $local10)
         (i32.const 8191)
        )
       )
      )
      (local.set $local6
       (i64.extend_i32_u
        (local.get $local7)
       )
      )
      (local.set $local11
       (ref.as_non_null
        (global.get $global229)
       )
      )
      (local.set $local5
       (call $function75
        (struct.get $type67 1
         (ref.as_non_null
          (local.get $local11)
         )
        )
        (local.get $local6)
       )
      )
      (local.set $local3
       (i64.add
        (local.get $local4)
        (local.get $local5)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized226)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture226)
      )
      (return_call $function74
       (ref.as_non_null
        (local.get $capture223)
       )
       (local.get $capture225)
       (local.get $capture226)
       (local.get $initialized226)
       (local.get $local0)
       (local.get $local3)
      )
     )
    )
   )
  )
 )
 (func $function75 (type $call67) (param $environment eqref) (param $argument230 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local.set $local4
   (local.get $argument230)
  )
  (local.set $local5
   (i64.const 128)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local4)
    (local.get $local5)
   )
   (then
    (i64.const 1)
   )
   (else
    (local.set $local2
     (local.get $argument230)
    )
    (local.set $local3
     (i64.const 2048)
    )
    (if (result i64)
     (i64.lt_s
      (local.get $local2)
      (local.get $local3)
     )
     (then
      (i64.const 2)
     )
     (else
      (local.set $local0
       (local.get $argument230)
      )
      (local.set $local1
       (i64.const 65536)
      )
      (if (result i64)
       (i64.lt_s
        (local.get $local0)
        (local.get $local1)
       )
       (then
        (i64.const 3)
       )
       (else
        (i64.const 4)
       )
      )
     )
    )
   )
  )
 )
 (func $function76 (type $call77) (param $environment eqref) (param $argument232 (ref $type36)) (param $argument233 (ref $type18)) (param $argument234 i64) (param $argument235 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument234)
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function77
   (ref.as_non_null
    (local.get $argument232)
   )
   (ref.as_non_null
    (local.get $argument233)
   )
   (local.get $argument235)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function77 (param $capture232 (ref $type36)) (param $capture233 (ref $type18)) (param $capture235 i64) (param $capture236 i32) (param $initialized236 i32) (param $argument237 i64) (param $argument238 i64) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local3 (ref null $type18))
  (local $local9 (ref null $type67))
  (local $local16 (ref null $type36))
  (local $local20 (ref null $type76))
  (local.set $local21
   (local.get $argument237)
  )
  (local.set $local22
   (local.get $capture235)
  )
  (if (result i32)
   (i64.eq
    (local.get $local21)
    (local.get $local22)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture233)
     )
    )
    (local.set $local4
     (local.get $argument237)
    )
    (if
     (i64.ge_u
      (local.get $local4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local3)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (i32.wrap_i64
      (local.get $local4)
     )
    )
    (local.set $local2
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local3)
       )
       (local.get $local5)
      )
      (i32.and
       (local.get $local5)
       (i32.const 8191)
      )
     )
    )
    (local.set $local1
     (i64.extend_i32_u
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global229)
     )
    )
    (local.set $local7
     (call $function75
      (struct.get $type67 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.get $local8)
     )
    )
    (local.set $local6
     (i32.const 1)
    )
    (local.set $local16
     (ref.as_non_null
      (local.get $capture232)
     )
    )
    (local.set $local17
     (local.get $argument238)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (local.get $local7)
    )
    (local.set $local20
     (ref.as_non_null
      (global.get $global209)
     )
    )
    (drop
     (call $function70
      (struct.get $type76 1
       (ref.as_non_null
        (local.get $local20)
       )
      )
      (ref.as_non_null
       (local.get $local16)
      )
      (local.get $local17)
      (local.get $local18)
      (local.get $local19)
     )
    )
    (local.set $local11
     (local.get $argument237)
    )
    (local.set $local12
     (i64.const 1)
    )
    (local.set $local10
     (i64.add
      (local.get $local11)
      (local.get $local12)
     )
    )
    (local.set $local14
     (local.get $argument238)
    )
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (local.get $local7)
    )
    (local.set $local13
     (i64.add
      (local.get $local14)
      (local.get $local15)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized236)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture236)
    )
    (return_call $function77
     (ref.as_non_null
      (local.get $capture232)
     )
     (ref.as_non_null
      (local.get $capture233)
     )
     (local.get $capture235)
     (local.get $capture236)
     (local.get $initialized236)
     (local.get $local10)
     (local.get $local13)
    )
   )
  )
 )
 (func $function78 (type $call79) (param $environment eqref) (param $argument242 (ref $type18)) (param $argument243 i64) (result (ref $type36))
  (local $local0 (ref null $type18))
  (local $local3 (ref null $type18))
  (local $local4 (ref null $type78))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument242)
   )
  )
  (local.set $local1
   (local.get $argument243)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument242)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (return_call $function72
   (struct.get $type78 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function79 (type $call80) (param $environment eqref) (param $argument245 (ref $type18)) (result (ref $type36))
  (local $local0 (ref null $type18))
  (local $local3 (ref null $type18))
  (local $local4 (ref null $type78))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument245)
   )
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument245)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (return_call $function72
   (struct.get $type78 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function80 (type $call81) (param $environment eqref) (param $argument247 (ref $type18)) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local3 i64)
  (local $local5 i64)
  (local $local4 (ref null $type18))
  (local.set $local1
   (call $foreign0)
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local4
   (ref.as_non_null
    (local.get $argument247)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local2
   (i32.const 1)
  )
  (local.set $local5
   (i64.const 0)
  )
  (local.set $local7
   (i32.const 0)
  )
  (local.set $local6
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local6)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local7)
  )
  (return_call $function81
   (ref.as_non_null
    (local.get $argument247)
   )
   (block (result i32)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local3)
   )
   (local.get $local7)
   (local.get $local6)
   (local.get $local5)
  )
 )
 (func $function81 (param $capture247 (ref $type18)) (param $capture248 i32) (param $capture249 i64) (param $capture250 i32) (param $initialized250 i32) (param $argument251 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local6 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local $local7 i32)
  (local $local5 (ref null $type18))
  (local.set $local8
   (local.get $argument251)
  )
  (local.set $local9
   (local.get $capture249)
  )
  (if (result i32)
   (i64.eq
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (local.get $capture248)
   )
   (else
    (local.set $local3
     (local.get $capture248)
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $capture247)
     )
    )
    (local.set $local6
     (local.get $argument251)
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (local.set $local4
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local5)
       )
       (local.get $local7)
      )
      (i32.and
       (local.get $local7)
       (i32.const 8191)
      )
     )
    )
    (call $foreign1
     (local.get $local3)
     (local.get $local4)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument251)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized250)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture250)
    )
    (return_call $function81
     (ref.as_non_null
      (local.get $capture247)
     )
     (local.get $capture248)
     (local.get $capture249)
     (local.get $capture250)
     (local.get $initialized250)
     (local.get $local0)
    )
   )
  )
 )
 (func $function82 (type $call82) (param $environment eqref) (param $argument253 (ref $type18))
  (local $local0 i32)
  (local $local1 (ref null $type18))
  (local $local2 (ref null $type81))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument253)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $local0
   (call $function80
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (call $foreign2
   (local.get $local0)
  )
  (drop
   (i32.const 0)
  )
  (unreachable)
 )
 (func $function83 (type $call83) (param $environment eqref) (param $argument255 (ref $type18)) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type81))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument255)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $local1
   (call $function80
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local5
   (call $foreign3
    (local.get $local6)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (local.get $local1)
  )
  (call $foreign4
   (local.get $local9)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (local.get $local5)
  )
  (local.set $local8
   (i32.const 1)
  )
  (i32.eq
   (local.get $local7)
   (local.get $local8)
  )
 )
 (func $function84 (type $call84) (param $environment eqref) (param $argument259 (ref $type18)) (result (ref $type22))
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type81))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument259)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $local1
   (call $function80
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (call $foreign5
    (local.get $local1)
   )
  )
  (struct.new $type22
   (local.get $local0)
  )
 )
 (func $function85 (type $call85) (param $environment eqref) (param $argument261 (ref $type22)) (param $argument262 (ref $type22)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local1 (ref null $type22))
  (local $local3 (ref null $type22))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument261)
   )
  )
  (local.set $local0
   (struct.get $type22 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument262)
   )
  )
  (local.set $local2
   (struct.get $type22 0
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (i32.eq
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function86 (type $call86) (param $environment eqref) (param $argument264 (ref $type22)) (result (ref $type18))
  (local $local0 i32)
  (local $local1 i32)
  (local $local3 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local4 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local2 (ref null $type22))
  (local $local7 (ref null $type18))
  (local $local9 (ref null $type43))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument264)
   )
  )
  (local.set $local1
   (struct.get $type22 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (local.get $local1)
  )
  (local.set $local4
   (call $foreign6
    (local.get $local5)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (local.get $local4)
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local7
   (call $function25
    (struct.get $type43 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (local.get $local8)
   )
  )
  (local.set $local6
   (i32.const 1)
  )
  (local.set $local10
   (i64.const 0)
  )
  (local.set $local12
   (i32.const 0)
  )
  (local.set $local11
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local12)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function87
   (local.get $local1)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local4)
   )
   (block (result (ref $type18))
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local7)
    )
   )
   (local.get $local12)
   (local.get $local11)
   (local.get $local10)
  )
 )
 (func $function87 (param $capture265 i32) (param $capture266 i64) (param $capture267 (ref $type18)) (param $capture268 i32) (param $initialized268 i32) (param $argument269 i64) (result (ref $type18))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local4 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local9 i32)
  (local $local3 (ref null $type18))
  (local.set $local10
   (local.get $argument269)
  )
  (local.set $local11
   (local.get $capture266)
  )
  (if (result (ref $type18))
   (i64.eq
    (local.get $local10)
    (local.get $local11)
   )
   (then
    (ref.as_non_null
     (local.get $capture267)
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture267)
     )
    )
    (local.set $local4
     (local.get $argument269)
    )
    (local.set $local6
     (local.get $capture265)
    )
    (local.set $local8
     (local.get $argument269)
    )
    (local.set $local7
     (i32.wrap_i64
      (local.get $local8)
     )
    )
    (local.set $local5
     (call $foreign7
      (local.get $local6)
      (local.get $local7)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local3)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local4)
     )
    )
    (array.set $type19
     (call $string-block
      (ref.as_non_null
       (local.get $local3)
      )
      (local.get $local9)
     )
     (i32.and
      (local.get $local9)
      (i32.const 8191)
     )
     (local.get $local5)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument269)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized268)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture268)
    )
    (return_call $function87
     (local.get $capture265)
     (local.get $capture266)
     (ref.as_non_null
      (local.get $capture267)
     )
     (local.get $capture268)
     (local.get $initialized268)
     (local.get $local0)
    )
   )
  )
 )
 (func $function88 (type $call67) (param $environment eqref) (param $argument271 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument271)
  )
  (local.set $local1
   (i64.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function89
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function89 (param $capture272 i32) (param $initialized272 i32) (param $argument273 i64) (param $argument274 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local.set $local6
   (local.get $argument273)
  )
  (local.set $local7
   (i64.const -10)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (local.get $argument274)
   )
   (else
    (local.set $local1
     (local.get $argument273)
    )
    (local.set $local2
     (i64.const 10)
    )
    (local.set $local0
     (i64.div_s
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument274)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized272)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture272)
    )
    (return_call $function89
     (local.get $capture272)
     (local.get $initialized272)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function90 (type $call43) (param $environment eqref) (param $argument276 i64) (result (ref $type18))
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local8 i32)
  (local $local14 i32)
  (local $local22 i32)
  (local $local23 i32)
  (local $local26 i32)
  (local $local27 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local25 i64)
  (local $local12 (ref null $type67))
  (local $local15 (ref null $type18))
  (local $local24 (ref null $type18))
  (local $local17 (ref null $type43))
  (local.set $local2
   (local.get $argument276)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local1
   (i64.lt_s
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (if (result i64)
    (local.get $local1)
    (then
     (local.get $argument276)
    )
    (else
     (local.set $local6
      (i64.const 0)
     )
     (local.set $local7
      (local.get $argument276)
     )
     (i64.sub
      (local.get $local6)
      (local.get $local7)
     )
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (local.get $local5)
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global270)
   )
  )
  (local.set $local10
   (call $function88
    (struct.get $type67 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (local.get $local11)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (if (result i64)
    (local.get $local1)
    (then
     (i64.const 1)
    )
    (else
     (i64.const 0)
    )
   )
  )
  (local.set $local9
   (i64.add
    (local.get $local10)
    (local.get $local13)
   )
  )
  (local.set $local8
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local16
   (local.get $local9)
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local15
   (call $function25
    (struct.get $type43 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (local.get $local16)
   )
  )
  (local.set $local14
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (if (result i32)
    (local.get $local1)
    (then
     (if
      (i32.eqz
       (local.get $local14)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local24
      (ref.as_non_null
       (local.get $local15)
      )
     )
     (local.set $local25
      (i64.const 0)
     )
     (local.set $local26
      (i32.const 45)
     )
     (if
      (i32.ne
       (struct.get $type18 0
        (ref.as_non_null
         (local.get $local24)
        )
       )
       (i32.const 1)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.ge_u
       (local.get $local25)
       (i64.extend_i32_u
        (struct.get $type18 1
         (ref.as_non_null
          (local.get $local24)
         )
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $local27
      (i32.wrap_i64
       (local.get $local25)
      )
     )
     (array.set $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local24)
       )
       (local.get $local27)
      )
      (i32.and
       (local.get $local27)
       (i32.const 8191)
      )
      (local.get $local26)
     )
     (drop
      (i32.const 0)
     )
     (i32.const 0)
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local18
   (local.get $local5)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local20
   (local.get $local9)
  )
  (local.set $local21
   (i64.const 1)
  )
  (local.set $local19
   (i64.sub
    (local.get $local20)
    (local.get $local21)
   )
  )
  (local.set $local23
   (i32.const 0)
  )
  (local.set $local22
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local22)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local23)
  )
  (if
   (i32.eqz
    (local.get $local14)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function91
   (ref.as_non_null
    (local.get $local15)
   )
   (local.get $local23)
   (local.get $local22)
   (local.get $local18)
   (local.get $local19)
  )
 )
 (func $function91 (param $capture280 (ref $type18)) (param $capture281 i32) (param $initialized281 i32) (param $argument282 i64) (param $argument283 i64) (result (ref $type18))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local10 i32)
  (local $local16 i32)
  (local $local8 (ref null $type18))
  (local.set $local8
   (ref.as_non_null
    (local.get $capture280)
   )
  )
  (local.set $local9
   (local.get $argument283)
  )
  (local.set $local12
   (i64.const 48)
  )
  (local.set $local14
   (local.get $argument282)
  )
  (local.set $local15
   (i64.const 10)
  )
  (local.set $local13
   (i64.rem_s
    (local.get $local14)
    (local.get $local15)
   )
  )
  (local.set $local11
   (i64.sub
    (local.get $local12)
    (local.get $local13)
   )
  )
  (if
   (i64.gt_u
    (local.get $local11)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ge_u
     (local.get $local11)
     (i64.const 55296)
    )
    (i64.le_u
     (local.get $local11)
     (i64.const 57343)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (i32.wrap_i64
    (local.get $local11)
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $local9)
    (i64.extend_i32_u
     (struct.get $type18 1
      (ref.as_non_null
       (local.get $local8)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local16
   (i32.wrap_i64
    (local.get $local9)
   )
  )
  (array.set $type19
   (call $string-block
    (ref.as_non_null
     (local.get $local8)
    )
    (local.get $local16)
   )
   (i32.and
    (local.get $local16)
    (i32.const 8191)
   )
   (local.get $local10)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local6
   (local.get $argument282)
  )
  (local.set $local7
   (i64.const -10)
  )
  (if (result (ref $type18))
   (i64.gt_s
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (ref.as_non_null
     (local.get $capture280)
    )
   )
   (else
    (local.set $local1
     (local.get $argument282)
    )
    (local.set $local2
     (i64.const 10)
    )
    (local.set $local0
     (i64.div_s
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument283)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.sub
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized281)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture281)
    )
    (return_call $function91
     (ref.as_non_null
      (local.get $capture280)
     )
     (local.get $capture281)
     (local.get $initialized281)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function92 (type $call87) (param $environment eqref) (param $argument285 (ref $type28)) (result f64)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local3 f64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local1 (ref null $type28))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument285)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result f64)
   (i32.eq
    (struct.get $type28 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (struct.get $type29 1
      (ref.cast (ref $type29)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local4
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (local.get $local5)
    )
    (f64.convert_i64_s
     (local.get $local6)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type30 1
      (ref.cast (ref $type30)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local3)
   )
  )
 )
 (func $function93 (type $call88) (param $environment eqref) (param $argument290 (ref $type24)) (result f64)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local14 i32)
  (local $local16 i32)
  (local $local10 f64)
  (local $local13 f64)
  (local $local15 f64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local1 (ref null $type24))
  (local $local3 (ref null $type28))
  (local $local5 (ref null $type28))
  (local $local8 (ref null $type28))
  (local $local11 (ref null $type28))
  (local $local6 (ref null $type18))
  (local $local7 (ref null $type82))
  (local $local9 (ref null $type87))
  (local $local12 (ref null $type87))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument290)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result f64)
   (i32.eq
    (struct.get $type24 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (struct.get $type25 1
      (ref.cast (ref $type25)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local16
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local16)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local17)
    )
    (f64.convert_i64_s
     (local.get $local18)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result f64)
     (i32.eq
      (struct.get $type24 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local15
       (struct.get $type26 1
        (ref.cast (ref $type26)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local14
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local14)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local15)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local3
       (struct.get $type27 1
        (ref.cast (ref $type27)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local2
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type27 2
        (ref.cast (ref $type27)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local11
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (local.set $local12
       (ref.as_non_null
        (global.get $global284)
       )
      )
      (local.set $local10
       (call $function92
        (struct.get $type87 1
         (ref.as_non_null
          (local.get $local12)
         )
        )
        (ref.as_non_null
         (local.get $local11)
        )
       )
      )
      (local.set $local13
       (f64.const 0)
      )
      (if (result f64)
       (f64.eq
        (local.get $local10)
        (local.get $local13)
       )
       (then
        (if
         (i32.eqz
          (local.get $local2)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local8
         (ref.as_non_null
          (local.get $local3)
         )
        )
        (local.set $local9
         (ref.as_non_null
          (global.get $global284)
         )
        )
        (return_call $function92
         (struct.get $type87 1
          (ref.as_non_null
           (local.get $local9)
          )
         )
         (ref.as_non_null
          (local.get $local8)
         )
        )
       )
       (else
        (local.set $local6
         (global.get $string0)
        )
        (local.set $local7
         (ref.as_non_null
          (global.get $global252)
         )
        )
        (call $function82
         (struct.get $type82 1
          (ref.as_non_null
           (local.get $local7)
          )
         )
         (ref.as_non_null
          (local.get $local6)
         )
        )
        (unreachable)
       )
      )
     )
    )
   )
  )
 )
 (func $function94 (type $call89) (param $environment eqref) (param $argument297 i32) (param $argument298 i32) (result (ref $type28))
  (local $local0 f64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local3 i64)
  (local.set $local7
   (local.get $argument297)
  )
  (local.set $local8
   (local.get $argument298)
  )
  (local.set $local6
   (call $foreign10
    (local.get $local7)
    (local.get $local8)
   )
  )
  (local.set $local9
   (i32.const 1)
  )
  (if (result (ref $type28))
   (i32.eq
    (local.get $local6)
    (local.get $local9)
   )
   (then
    (local.set $local4
     (local.get $argument297)
    )
    (local.set $local5
     (local.get $argument298)
    )
    (local.set $local3
     (call $foreign9
      (local.get $local4)
      (local.get $local5)
     )
    )
    (struct.new $type29
     (i32.const 0)
     (local.get $local3)
    )
   )
   (else
    (local.set $local1
     (local.get $argument297)
    )
    (local.set $local2
     (local.get $argument298)
    )
    (local.set $local0
     (call $foreign8
      (local.get $local1)
      (local.get $local2)
     )
    )
    (struct.new $type30
     (i32.const 1)
     (local.get $local0)
    )
   )
  )
 )
 (func $function95 (type $call90) (param $environment eqref) (param $argument300 i32) (result (ref $type18))
  (local $local0 i32)
  (local $local2 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local1 i64)
  (local $local6 i64)
  (local $local8 i64)
  (local $local5 (ref null $type18))
  (local $local7 (ref null $type43))
  (local.set $local3
   (local.get $argument300)
  )
  (local.set $local2
   (call $foreign11
    (local.get $local3)
   )
  )
  (local.set $local1
   (i64.extend_i32_s
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local5
   (call $function25
    (struct.get $type43 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local6)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (local.set $local8
   (i64.const 0)
  )
  (local.set $local10
   (i32.const 0)
  )
  (local.set $local9
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local10)
  )
  (return_call $function96
   (local.get $argument300)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (block (result (ref $type18))
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local5)
    )
   )
   (local.get $local10)
   (local.get $local9)
   (local.get $local8)
  )
 )
 (func $function96 (param $capture300 i32) (param $capture301 i64) (param $capture302 (ref $type18)) (param $capture303 i32) (param $initialized303 i32) (param $argument304 i64) (result (ref $type18))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local4 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local9 i32)
  (local $local3 (ref null $type18))
  (local.set $local10
   (local.get $argument304)
  )
  (local.set $local11
   (local.get $capture301)
  )
  (if (result (ref $type18))
   (i64.eq
    (local.get $local10)
    (local.get $local11)
   )
   (then
    (ref.as_non_null
     (local.get $capture302)
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture302)
     )
    )
    (local.set $local4
     (local.get $argument304)
    )
    (local.set $local6
     (local.get $capture300)
    )
    (local.set $local8
     (local.get $argument304)
    )
    (local.set $local7
     (i32.wrap_i64
      (local.get $local8)
     )
    )
    (local.set $local5
     (call $foreign12
      (local.get $local6)
      (local.get $local7)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local3)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local4)
     )
    )
    (array.set $type19
     (call $string-block
      (ref.as_non_null
       (local.get $local3)
      )
      (local.get $local9)
     )
     (i32.and
      (local.get $local9)
      (i32.const 8191)
     )
     (local.get $local5)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument304)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized303)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture303)
    )
    (return_call $function96
     (local.get $capture300)
     (local.get $capture301)
     (ref.as_non_null
      (local.get $capture302)
     )
     (local.get $capture303)
     (local.get $initialized303)
     (local.get $local0)
    )
   )
  )
 )
 (func $function97 (type $call91) (param $environment eqref) (param $argument306 i32) (param $argument307 i32) (result (ref $type92))
  (local $local0 (ref null $type18))
  (local $local2 (ref null $type90))
  (local $local3 (ref null $type24))
  (local $local14 (ref null $type24))
  (local $local20 (ref null $type24))
  (local $local4 (ref null $type28))
  (local $local8 (ref null $type28))
  (local $local7 (ref null $type89))
  (local $local11 (ref null $type89))
  (local $local1 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local12 i32)
  (local $local13 i32)
  (local $local16 i32)
  (local $local17 i32)
  (local $local18 i32)
  (local $local19 i32)
  (local $local22 i32)
  (local $local23 i32)
  (local $local24 i32)
  (local $local25 i32)
  (local $local26 i32)
  (local $local27 i32)
  (local $local15 f64)
  (local $local21 i64)
  (local.set $local26
   (local.get $argument307)
  )
  (local.set $local27
   (i32.const 0)
  )
  (if (result (ref $type92))
   (i32.eq
    (local.get $local26)
    (local.get $local27)
   )
   (then
    (global.get $empty93)
   )
   (else
    (local.set $local24
     (local.get $argument307)
    )
    (local.set $local25
     (i32.const 1)
    )
    (if (result (ref $type92))
     (i32.eq
      (local.get $local24)
      (local.get $local25)
     )
     (then
      (local.set $local22
       (local.get $argument306)
      )
      (local.set $local23
       (i32.const 0)
      )
      (local.set $local21
       (call $foreign9
        (local.get $local22)
        (local.get $local23)
       )
      )
      (local.set $local20
       (struct.new $type25
        (i32.const 0)
        (local.get $local21)
       )
      )
      (struct.new $type94
       (i32.const 1)
       (ref.as_non_null
        (local.get $local20)
       )
      )
     )
     (else
      (local.set $local18
       (local.get $argument307)
      )
      (local.set $local19
       (i32.const 2)
      )
      (if (result (ref $type92))
       (i32.eq
        (local.get $local18)
        (local.get $local19)
       )
       (then
        (local.set $local16
         (local.get $argument306)
        )
        (local.set $local17
         (i32.const 0)
        )
        (local.set $local15
         (call $foreign8
          (local.get $local16)
          (local.get $local17)
         )
        )
        (local.set $local14
         (struct.new $type26
          (i32.const 1)
          (local.get $local15)
         )
        )
        (struct.new $type94
         (i32.const 1)
         (ref.as_non_null
          (local.get $local14)
         )
        )
       )
       (else
        (local.set $local12
         (local.get $argument307)
        )
        (local.set $local13
         (i32.const 3)
        )
        (if (result (ref $type92))
         (i32.eq
          (local.get $local12)
          (local.get $local13)
         )
         (then
          (local.set $local5
           (local.get $argument306)
          )
          (local.set $local6
           (i32.const 0)
          )
          (local.set $local7
           (ref.as_non_null
            (global.get $global296)
           )
          )
          (local.set $local4
           (call $function94
            (struct.get $type89 1
             (ref.as_non_null
              (local.get $local7)
             )
            )
            (local.get $local5)
            (local.get $local6)
           )
          )
          (local.set $local9
           (local.get $argument306)
          )
          (local.set $local10
           (i32.const 1)
          )
          (local.set $local11
           (ref.as_non_null
            (global.get $global296)
           )
          )
          (local.set $local8
           (call $function94
            (struct.get $type89 1
             (ref.as_non_null
              (local.get $local11)
             )
            )
            (local.get $local9)
            (local.get $local10)
           )
          )
          (local.set $local3
           (struct.new $type27
            (i32.const 2)
            (ref.as_non_null
             (local.get $local4)
            )
            (ref.as_non_null
             (local.get $local8)
            )
           )
          )
          (struct.new $type94
           (i32.const 1)
           (ref.as_non_null
            (local.get $local3)
           )
          )
         )
         (else
          (local.set $local1
           (local.get $argument306)
          )
          (local.set $local2
           (ref.as_non_null
            (global.get $global299)
           )
          )
          (local.set $local0
           (call $function95
            (struct.get $type90 1
             (ref.as_non_null
              (local.get $local2)
             )
            )
            (local.get $local1)
           )
          )
          (struct.new $type95
           (i32.const 2)
           (ref.as_non_null
            (local.get $local0)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function98 (type $call96) (param $environment eqref) (param $argument309 (ref $type18)) (result (ref $type92))
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local12 i32)
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type81))
  (local $local8 (ref null $type92))
  (local $local11 (ref null $type91))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument309)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $local1
   (call $function80
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local5
   (call $foreign13
    (local.get $local6)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (local.get $local1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (local.get $local5)
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global305)
   )
  )
  (local.set $local8
   (call $function97
    (struct.get $type91 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (local.get $local9)
    (local.get $local10)
   )
  )
  (local.set $local7
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (local.get $local1)
  )
  (call $foreign4
   (local.get $local12)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local7)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local8)
  )
 )
 (func $function99 (type $call97) (param $environment eqref) (param $argument314 (ref $type28)) (param $argument315 (ref $type28)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local10 i32)
  (local $local13 i32)
  (local $local14 i32)
  (local $local16 i32)
  (local $local18 i32)
  (local $local20 i32)
  (local $local3 f64)
  (local $local9 f64)
  (local $local11 f64)
  (local $local12 f64)
  (local $local19 f64)
  (local $local7 i64)
  (local $local15 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local1 (ref null $type28))
  (local $local5 (ref null $type28))
  (local $local17 (ref null $type28))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument314)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type28 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (struct.get $type29 1
      (ref.cast (ref $type29)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local14
     (i32.const 1)
    )
    (local.set $local17
     (ref.as_non_null
      (local.get $argument315)
     )
    )
    (local.set $local16
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local16)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type28 0
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (i32.const 0)
     )
     (then
      (if
       (i32.eqz
        (local.get $local16)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local21
       (struct.get $type29 1
        (ref.cast (ref $type29)
         (ref.as_non_null
          (local.get $local17)
         )
        )
       )
      )
      (local.set $local20
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local22
       (local.get $local15)
      )
      (if
       (i32.eqz
        (local.get $local20)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local23
       (local.get $local21)
      )
      (i64.eq
       (local.get $local22)
       (local.get $local23)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local16)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local19
       (struct.get $type30 1
        (ref.cast (ref $type30)
         (ref.as_non_null
          (local.get $local17)
         )
        )
       )
      )
      (local.set $local18
       (i32.const 1)
      )
      (i32.const 0)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type30 1
      (ref.cast (ref $type30)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $argument315)
     )
    )
    (local.set $local4
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type28 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local9
       (struct.get $type30 1
        (ref.cast (ref $type30)
         (ref.as_non_null
          (local.get $local5)
         )
        )
       )
      )
      (local.set $local8
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local11
       (local.get $local3)
      )
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local12
       (local.get $local9)
      )
      (local.set $local10
       (call $foreign14
        (local.get $local11)
        (local.get $local12)
       )
      )
      (local.set $local13
       (i32.const 1)
      )
      (i32.eq
       (local.get $local10)
       (local.get $local13)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local7
       (struct.get $type29 1
        (ref.cast (ref $type29)
         (ref.as_non_null
          (local.get $local5)
         )
        )
       )
      )
      (local.set $local6
       (i32.const 1)
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function100 (type $call98) (param $environment eqref) (param $argument326 (ref $type24)) (result i64)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local7 f64)
  (local $local9 i64)
  (local $local1 (ref null $type24))
  (local $local3 (ref null $type28))
  (local $local5 (ref null $type28))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument326)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i32.eq
    (struct.get $type24 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (struct.get $type25 1
      (ref.cast (ref $type25)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local8
     (i32.const 1)
    )
    (i64.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i32.eq
      (struct.get $type24 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local7
       (struct.get $type26 1
        (ref.cast (ref $type26)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local6
       (i32.const 1)
      )
      (i64.const 1)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local3
       (struct.get $type27 1
        (ref.cast (ref $type27)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local2
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type27 2
        (ref.cast (ref $type27)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function101 (type $call99) (param $environment eqref) (param $argument333 (ref $type24)) (param $argument334 (ref $type24)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local14 i32)
  (local $local16 i32)
  (local $local20 i32)
  (local $local21 i32)
  (local $local15 f64)
  (local $local17 f64)
  (local $local18 f64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local26 i64)
  (local $local29 i64)
  (local $local1 (ref null $type24))
  (local $local8 (ref null $type24))
  (local $local12 (ref null $type24))
  (local $local19 (ref null $type24))
  (local $local25 (ref null $type24))
  (local $local27 (ref null $type24))
  (local $local30 (ref null $type24))
  (local $local3 (ref null $type28))
  (local $local5 (ref null $type28))
  (local $local6 (ref null $type28))
  (local $local7 (ref null $type28))
  (local $local10 (ref null $type28))
  (local $local11 (ref null $type28))
  (local $local9 (ref null $type97))
  (local $local13 (ref null $type97))
  (local $local28 (ref null $type98))
  (local $local31 (ref null $type98))
  (local.set $local27
   (ref.as_non_null
    (local.get $argument333)
   )
  )
  (local.set $local28
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (local.set $local26
   (call $function100
    (struct.get $type98 1
     (ref.as_non_null
      (local.get $local28)
     )
    )
    (ref.as_non_null
     (local.get $local27)
    )
   )
  )
  (local.set $local30
   (ref.as_non_null
    (local.get $argument334)
   )
  )
  (local.set $local31
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (local.set $local29
   (call $function100
    (struct.get $type98 1
     (ref.as_non_null
      (local.get $local31)
     )
    )
    (ref.as_non_null
     (local.get $local30)
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local26)
    (local.get $local29)
   )
   (then
    (local.set $local1
     (ref.as_non_null
      (local.get $argument333)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type24 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local22
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local21
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local21)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local23
       (local.get $local22)
      )
      (local.set $local25
       (ref.as_non_null
        (local.get $argument334)
       )
      )
      (if
       (i32.ne
        (struct.get $type24 0
         (ref.as_non_null
          (local.get $local25)
         )
        )
        (i32.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local24
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (ref.as_non_null
          (local.get $local25)
         )
        )
       )
      )
      (i64.eq
       (local.get $local23)
       (local.get $local24)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i32.eq
        (struct.get $type24 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 1)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local15
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local14
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local14)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local17
         (local.get $local15)
        )
        (local.set $local19
         (ref.as_non_null
          (local.get $argument334)
         )
        )
        (if
         (i32.ne
          (struct.get $type24 0
           (ref.as_non_null
            (local.get $local19)
           )
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local18
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (ref.as_non_null
            (local.get $local19)
           )
          )
         )
        )
        (local.set $local16
         (call $foreign14
          (local.get $local17)
          (local.get $local18)
         )
        )
        (local.set $local20
         (i32.const 1)
        )
        (i32.eq
         (local.get $local16)
         (local.get $local20)
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local3
         (struct.get $type27 1
          (ref.cast (ref $type27)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local2
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local5
         (struct.get $type27 2
          (ref.cast (ref $type27)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local4
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local2)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local10
         (ref.as_non_null
          (local.get $local3)
         )
        )
        (local.set $local12
         (ref.as_non_null
          (local.get $argument334)
         )
        )
        (if
         (i32.ne
          (struct.get $type24 0
           (ref.as_non_null
            (local.get $local12)
           )
          )
          (i32.const 2)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local11
         (struct.get $type27 1
          (ref.cast (ref $type27)
           (ref.as_non_null
            (local.get $local12)
           )
          )
         )
        )
        (local.set $local13
         (ref.as_non_null
          (global.get $global313)
         )
        )
        (if (result i32)
         (call $function99
          (struct.get $type97 1
           (ref.as_non_null
            (local.get $local13)
           )
          )
          (ref.as_non_null
           (local.get $local10)
          )
          (ref.as_non_null
           (local.get $local11)
          )
         )
         (then
          (if
           (i32.eqz
            (local.get $local4)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local6
           (ref.as_non_null
            (local.get $local5)
           )
          )
          (local.set $local8
           (ref.as_non_null
            (local.get $argument334)
           )
          )
          (if
           (i32.ne
            (struct.get $type24 0
             (ref.as_non_null
              (local.get $local8)
             )
            )
            (i32.const 2)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local7
           (struct.get $type27 2
            (ref.cast (ref $type27)
             (ref.as_non_null
              (local.get $local8)
             )
            )
           )
          )
          (local.set $local9
           (ref.as_non_null
            (global.get $global313)
           )
          )
          (return_call $function99
           (struct.get $type97 1
            (ref.as_non_null
             (local.get $local9)
            )
           )
           (ref.as_non_null
            (local.get $local6)
           )
           (ref.as_non_null
            (local.get $local7)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function102 (type $call100) (param $environment eqref) (param $argument341 i32) (param $argument342 i32) (result (ref $type101))
  (local $local0 i32)
  (local $local2 i32)
  (local $local3 i32)
  (local $local5 i32)
  (local $local7 i32)
  (local $local10 i32)
  (local $local14 i32)
  (local $local1 (ref null $type92))
  (local $local6 (ref null $type92))
  (local $local4 (ref null $type91))
  (local $local8 (ref null $type18))
  (local $local9 (ref null $type18))
  (local $local11 (ref null $type24))
  (local $local13 (ref null $type24))
  (local $local12 (ref null $type13))
  (local.set $local2
   (local.get $argument341)
  )
  (local.set $local3
   (local.get $argument342)
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global305)
   )
  )
  (local.set $local1
   (call $function97
    (struct.get $type91 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local14
   (local.get $argument341)
  )
  (call $foreign4
   (local.get $local14)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local5
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local5)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type101))
   (i32.eq
    (struct.get $type92 0
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (struct.get $type94 1
      (ref.cast (ref $type94)
       (ref.as_non_null
        (local.get $local6)
       )
      )
     )
    )
    (local.set $local10
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (local.set $local12
     (struct.new $type23
      (i32.const 5)
      (ref.as_non_null
       (local.get $local13)
      )
     )
    )
    (struct.new $type103
     (i32.const 1)
     (ref.as_non_null
      (local.get $local12)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type92 0
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (i32.const 2)
     )
     (then
      (if
       (i32.eqz
        (local.get $local5)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local8
       (struct.get $type95 1
        (ref.cast (ref $type95)
         (ref.as_non_null
          (local.get $local6)
         )
        )
       )
      )
      (local.set $local7
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local7)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local9
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local9)
       )
      )
     )
     (else
      (unreachable)
     )
    )
   )
  )
 )
 (func $function103 (type $call105) (param $environment eqref) (param $argument348 (ref $type18)) (result (ref $type101))
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local11 i32)
  (local $local14 i32)
  (local $local15 i32)
  (local $local16 i32)
  (local $local17 i32)
  (local $local18 i32)
  (local $local19 i32)
  (local $local20 i32)
  (local $local2 (ref null $type18))
  (local $local10 (ref null $type18))
  (local $local3 (ref null $type81))
  (local $local9 (ref null $type100))
  (local $local12 (ref null $type13))
  (local $local13 (ref null $type22))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument348)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $local1
   (call $function80
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local5
   (call $foreign13
    (local.get $local6)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local19
   (local.get $local5)
  )
  (local.set $local20
   (i32.const 0)
  )
  (if (result (ref $type101))
   (i32.eq
    (local.get $local19)
    (local.get $local20)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (local.get $local1)
    )
    (local.set $local16
     (call $foreign3
      (local.get $local17)
     )
    )
    (local.set $local18
     (i32.const 1)
    )
    (if (result (ref $type101))
     (i32.eq
      (local.get $local16)
      (local.get $local18)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local15
       (local.get $local1)
      )
      (local.set $local14
       (call $foreign5
        (local.get $local15)
       )
      )
      (local.set $local13
       (struct.new $type22
        (local.get $local14)
       )
      )
      (local.set $local12
       (struct.new $type21
        (i32.const 4)
        (ref.as_non_null
         (local.get $local13)
        )
       )
      )
      (struct.new $type103
       (i32.const 1)
       (ref.as_non_null
        (local.get $local12)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local11
       (local.get $local1)
      )
      (call $foreign4
       (local.get $local11)
      )
      (drop
       (i32.const 0)
      )
      (local.set $local10
       (global.get $string1)
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local10)
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local5)
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global340)
     )
    )
    (return_call $function102
     (struct.get $type100 1
      (ref.as_non_null
       (local.get $local9)
      )
     )
     (local.get $local7)
     (local.get $local8)
    )
   )
  )
 )
 (func $function104 (type $call106) (param $environment eqref) (param $argument352 (ref $type13)) (param $argument353 (ref $type13)) (result (ref $type13))
  (local $local0 (ref null $type32))
  (local $local2 (ref null $type32))
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument352)
   )
  )
  (local.set $local0
   (struct.new $type32
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument353)
   )
  )
  (local.set $local2
   (struct.new $type32
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (struct.new $type31
   (i32.const 6)
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local2)
   )
  )
 )
 (func $function105 (type $call107) (param $environment eqref) (param $argument355 (ref $type13)) (result (ref $type13))
  (local $local0 (ref null $type32))
  (local $local1 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument355)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (struct.get $type31 1
    (ref.cast (ref $type31)
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (struct.get $type32 0
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function106 (type $call107) (param $environment eqref) (param $argument357 (ref $type13)) (result (ref $type13))
  (local $local0 (ref null $type32))
  (local $local1 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument357)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (struct.get $type31 2
    (ref.cast (ref $type31)
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (struct.get $type32 0
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function107 (type $call108) (param $environment eqref) (param $argument359 (ref $type13)) (param $argument360 (ref $type13)) (result i32)
  (local $local0 (ref null $type32))
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument359)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (struct.get $type31 1
    (ref.cast (ref $type31)
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument360)
   )
  )
  (struct.set $type32 0
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local2)
   )
  )
  (i32.const 0)
 )
 (func $function108 (type $call108) (param $environment eqref) (param $argument362 (ref $type13)) (param $argument363 (ref $type13)) (result i32)
  (local $local0 (ref null $type32))
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument362)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (struct.get $type31 2
    (ref.cast (ref $type31)
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument363)
   )
  )
  (struct.set $type32 0
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local2)
   )
  )
  (i32.const 0)
 )
 (func $function109 (type $call109) (param $environment eqref) (param $argument365 (ref $type13)) (result i64)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local10 i32)
  (local $local12 i32)
  (local $local14 i32)
  (local $local16 i32)
  (local $local17 i32)
  (local $local18 i32)
  (local $local19 i32)
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type36))
  (local $local5 (ref null $type34))
  (local $local7 (ref null $type32))
  (local $local9 (ref null $type32))
  (local $local11 (ref null $type24))
  (local $local13 (ref null $type22))
  (local $local15 (ref null $type18))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument365)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i32.eq
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i32.eq
      (struct.get $type13 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local19
       (struct.get $type15 1
        (ref.cast (ref $type15)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local18
       (i32.const 1)
      )
      (i64.const 1)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i64)
       (i32.eq
        (struct.get $type13 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 2)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local17
         (struct.get $type16 1
          (ref.cast (ref $type16)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local16
         (i32.const 1)
        )
        (i64.const 2)
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (if (result i64)
         (i32.eq
          (struct.get $type13 0
           (ref.as_non_null
            (local.get $local1)
           )
          )
          (i32.const 3)
         )
         (then
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local15
           (struct.get $type17 1
            (ref.cast (ref $type17)
             (ref.as_non_null
              (local.get $local1)
             )
            )
           )
          )
          (local.set $local14
           (i32.const 1)
          )
          (i64.const 3)
         )
         (else
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (if (result i64)
           (i32.eq
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local1)
             )
            )
            (i32.const 4)
           )
           (then
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local13
             (struct.get $type21 1
              (ref.cast (ref $type21)
               (ref.as_non_null
                (local.get $local1)
               )
              )
             )
            )
            (local.set $local12
             (i32.const 1)
            )
            (i64.const 4)
           )
           (else
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (if (result i64)
             (i32.eq
              (struct.get $type13 0
               (ref.as_non_null
                (local.get $local1)
               )
              )
              (i32.const 5)
             )
             (then
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local11
               (struct.get $type23 1
                (ref.cast (ref $type23)
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
               )
              )
              (local.set $local10
               (i32.const 1)
              )
              (i64.const 5)
             )
             (else
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (if (result i64)
               (i32.eq
                (struct.get $type13 0
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
                (i32.const 6)
               )
               (then
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local7
                 (struct.get $type31 1
                  (ref.cast (ref $type31)
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                 )
                )
                (local.set $local6
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local9
                 (struct.get $type31 2
                  (ref.cast (ref $type31)
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                 )
                )
                (local.set $local8
                 (i32.const 1)
                )
                (i64.const 6)
               )
               (else
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i64)
                 (i32.eq
                  (struct.get $type13 0
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                  (i32.const 7)
                 )
                 (then
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local5
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local4
                   (i32.const 1)
                  )
                  (i64.const 7)
                 )
                 (else
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local3
                   (struct.get $type35 1
                    (ref.cast (ref $type35)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local2
                   (i32.const 1)
                  )
                  (i64.const 8)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function110 (type $call110) (param $environment eqref) (param $argument377 (ref $type13)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type109))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument377)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local0
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (i64.const 5)
  )
  (i64.eq
   (local.get $local0)
   (local.get $local3)
  )
 )
 (func $function111 (type $call110) (param $environment eqref) (param $argument379 (ref $type13)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type109))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument379)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local0
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (i64.const 0)
  )
  (i64.eq
   (local.get $local0)
   (local.get $local3)
  )
 )
 (func $function112 (type $call110) (param $environment eqref) (param $argument381 (ref $type13)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type109))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument381)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local0
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (i64.const 6)
  )
  (i64.eq
   (local.get $local0)
   (local.get $local3)
  )
 )
 (func $function113 (type $call110) (param $environment eqref) (param $argument383 (ref $type13)) (result i32)
  (local $local0 (ref null $type13))
  (local $local2 (ref null $type13))
  (local $local3 (ref null $type109))
  (local $local1 i64)
  (local $local4 i64)
  (local.set $local2
   (ref.as_non_null
    (local.get $argument383)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local1
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (i64.const 1)
  )
  (if (result i32)
   (i64.eq
    (local.get $local1)
    (local.get $local4)
   )
   (then
    (local.set $local0
     (ref.as_non_null
      (local.get $argument383)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (ref.as_non_null
        (local.get $local0)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (struct.get $type15 1
     (ref.cast (ref $type15)
      (ref.as_non_null
       (local.get $local0)
      )
     )
    )
   )
   (else
    (i32.const 1)
   )
  )
 )
 (func $function114 (type $call111) (param $environment eqref) (param $argument385 (ref $type13)) (param $argument386 (ref $type13)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local7 i32)
  (local $local12 i32)
  (local $local14 i32)
  (local $local22 i32)
  (local $local28 i32)
  (local $local34 i32)
  (local $local39 i32)
  (local $local40 i32)
  (local $local41 i32)
  (local $local42 i32)
  (local $local44 i32)
  (local $local45 i32)
  (local $local46 i32)
  (local $local49 i64)
  (local $local52 i64)
  (local $local1 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local18 (ref null $type13))
  (local $local21 (ref null $type13))
  (local $local26 (ref null $type13))
  (local $local32 (ref null $type13))
  (local $local38 (ref null $type13))
  (local $local43 (ref null $type13))
  (local $local47 (ref null $type13))
  (local $local48 (ref null $type13))
  (local $local50 (ref null $type13))
  (local $local53 (ref null $type13))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type36))
  (local $local5 (ref null $type36))
  (local $local8 (ref null $type34))
  (local $local9 (ref null $type34))
  (local $local10 (ref null $type34))
  (local $local13 (ref null $type32))
  (local $local15 (ref null $type32))
  (local $local16 (ref null $type32))
  (local $local17 (ref null $type32))
  (local $local19 (ref null $type32))
  (local $local20 (ref null $type32))
  (local $local23 (ref null $type24))
  (local $local24 (ref null $type24))
  (local $local25 (ref null $type24))
  (local $local27 (ref null $type99))
  (local $local29 (ref null $type22))
  (local $local30 (ref null $type22))
  (local $local31 (ref null $type22))
  (local $local33 (ref null $type85))
  (local $local35 (ref null $type18))
  (local $local36 (ref null $type18))
  (local $local37 (ref null $type18))
  (local $local51 (ref null $type109))
  (local $local54 (ref null $type109))
  (local.set $local50
   (ref.as_non_null
    (local.get $argument385)
   )
  )
  (local.set $local51
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local49
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local51)
     )
    )
    (ref.as_non_null
     (local.get $local50)
    )
   )
  )
  (local.set $local53
   (ref.as_non_null
    (local.get $argument386)
   )
  )
  (local.set $local54
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local52
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local54)
     )
    )
    (ref.as_non_null
     (local.get $local53)
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local49)
    (local.get $local52)
   )
   (then
    (local.set $local1
     (ref.as_non_null
      (local.get $argument385)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type13 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (i32.const 1)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i32.eq
        (struct.get $type13 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 1)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local45
         (struct.get $type15 1
          (ref.cast (ref $type15)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local44
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local44)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (local.get $local45)
         (then
          (local.set $local48
           (ref.as_non_null
            (local.get $argument386)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local48)
             )
            )
            (i32.const 1)
           )
           (then
            (unreachable)
           )
          )
          (struct.get $type15 1
           (ref.cast (ref $type15)
            (ref.as_non_null
             (local.get $local48)
            )
           )
          )
         )
         (else
          (local.set $local47
           (ref.as_non_null
            (local.get $argument386)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local47)
             )
            )
            (i32.const 1)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local46
           (struct.get $type15 1
            (ref.cast (ref $type15)
             (ref.as_non_null
              (local.get $local47)
             )
            )
           )
          )
          (i32.eqz
           (local.get $local46)
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (ref.as_non_null
            (local.get $local1)
           )
          )
          (i32.const 2)
         )
         (then
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local40
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (ref.as_non_null
              (local.get $local1)
             )
            )
           )
          )
          (local.set $local39
           (i32.const 1)
          )
          (if
           (i32.eqz
            (local.get $local39)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local41
           (local.get $local40)
          )
          (local.set $local43
           (ref.as_non_null
            (local.get $argument386)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local43)
             )
            )
            (i32.const 2)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local42
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (ref.as_non_null
              (local.get $local43)
             )
            )
           )
          )
          (i32.eq
           (local.get $local41)
           (local.get $local42)
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local1)
             )
            )
            (i32.const 3)
           )
           (then
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local35
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (ref.as_non_null
                (local.get $local1)
               )
              )
             )
            )
            (local.set $local34
             (i32.const 1)
            )
            (if
             (i32.eqz
              (local.get $local34)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local36
             (ref.as_non_null
              (local.get $local35)
             )
            )
            (local.set $local38
             (ref.as_non_null
              (local.get $argument386)
             )
            )
            (if
             (i32.ne
              (struct.get $type13 0
               (ref.as_non_null
                (local.get $local38)
               )
              )
              (i32.const 3)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local37
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (ref.as_non_null
                (local.get $local38)
               )
              )
             )
            )
            (ref.eq
             (ref.as_non_null
              (local.get $local36)
             )
             (ref.as_non_null
              (local.get $local37)
             )
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (ref.as_non_null
                (local.get $local1)
               )
              )
              (i32.const 4)
             )
             (then
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local29
               (struct.get $type21 1
                (ref.cast (ref $type21)
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
               )
              )
              (local.set $local28
               (i32.const 1)
              )
              (if
               (i32.eqz
                (local.get $local28)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local30
               (ref.as_non_null
                (local.get $local29)
               )
              )
              (local.set $local32
               (ref.as_non_null
                (local.get $argument386)
               )
              )
              (if
               (i32.ne
                (struct.get $type13 0
                 (ref.as_non_null
                  (local.get $local32)
                 )
                )
                (i32.const 4)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local31
               (struct.get $type21 1
                (ref.cast (ref $type21)
                 (ref.as_non_null
                  (local.get $local32)
                 )
                )
               )
              )
              (local.set $local33
               (ref.as_non_null
                (global.get $global260)
               )
              )
              (return_call $function85
               (struct.get $type85 1
                (ref.as_non_null
                 (local.get $local33)
                )
               )
               (ref.as_non_null
                (local.get $local30)
               )
               (ref.as_non_null
                (local.get $local31)
               )
              )
             )
             (else
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
                (i32.const 5)
               )
               (then
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local23
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                 )
                )
                (local.set $local22
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (local.get $local22)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local24
                 (ref.as_non_null
                  (local.get $local23)
                 )
                )
                (local.set $local26
                 (ref.as_non_null
                  (local.get $argument386)
                 )
                )
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (ref.as_non_null
                    (local.get $local26)
                   )
                  )
                  (i32.const 5)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local25
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (ref.as_non_null
                    (local.get $local26)
                   )
                  )
                 )
                )
                (local.set $local27
                 (ref.as_non_null
                  (global.get $global332)
                 )
                )
                (return_call $function101
                 (struct.get $type99 1
                  (ref.as_non_null
                   (local.get $local27)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local24)
                 )
                 (ref.as_non_null
                  (local.get $local25)
                 )
                )
               )
               (else
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                  (i32.const 6)
                 )
                 (then
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local13
                   (struct.get $type31 1
                    (ref.cast (ref $type31)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local12
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local15
                   (struct.get $type31 2
                    (ref.cast (ref $type31)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local14
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (local.get $local12)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local19
                   (ref.as_non_null
                    (local.get $local13)
                   )
                  )
                  (local.set $local21
                   (ref.as_non_null
                    (local.get $argument386)
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (ref.as_non_null
                      (local.get $local21)
                     )
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local20
                   (struct.get $type31 1
                    (ref.cast (ref $type31)
                     (ref.as_non_null
                      (local.get $local21)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (ref.eq
                    (ref.as_non_null
                     (local.get $local19)
                    )
                    (ref.as_non_null
                     (local.get $local20)
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (local.get $local14)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local16
                     (ref.as_non_null
                      (local.get $local15)
                     )
                    )
                    (local.set $local18
                     (ref.as_non_null
                      (local.get $argument386)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (ref.as_non_null
                        (local.get $local18)
                       )
                      )
                      (i32.const 6)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local17
                     (struct.get $type31 2
                      (ref.cast (ref $type31)
                       (ref.as_non_null
                        (local.get $local18)
                       )
                      )
                     )
                    )
                    (ref.eq
                     (ref.as_non_null
                      (local.get $local16)
                     )
                     (ref.as_non_null
                      (local.get $local17)
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if (result i32)
                   (i32.eq
                    (struct.get $type13 0
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                    (i32.const 7)
                   )
                   (then
                    (if
                     (i32.eqz
                      (local.get $local0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local8
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (ref.as_non_null
                        (local.get $local1)
                       )
                      )
                     )
                    )
                    (local.set $local7
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (local.get $local7)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local9
                     (ref.as_non_null
                      (local.get $local8)
                     )
                    )
                    (local.set $local11
                     (ref.as_non_null
                      (local.get $argument386)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (ref.as_non_null
                        (local.get $local11)
                       )
                      )
                      (i32.const 7)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local10
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (ref.as_non_null
                        (local.get $local11)
                       )
                      )
                     )
                    )
                    (ref.eq
                     (ref.as_non_null
                      (local.get $local9)
                     )
                     (ref.as_non_null
                      (local.get $local10)
                     )
                    )
                   )
                   (else
                    (if
                     (i32.eqz
                      (local.get $local0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local3
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (ref.as_non_null
                        (local.get $local1)
                       )
                      )
                     )
                    )
                    (local.set $local2
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (local.get $local2)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local4
                     (ref.as_non_null
                      (local.get $local3)
                     )
                    )
                    (local.set $local6
                     (ref.as_non_null
                      (local.get $argument386)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (ref.as_non_null
                        (local.get $local6)
                       )
                      )
                      (i32.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local5
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (ref.as_non_null
                        (local.get $local6)
                       )
                      )
                     )
                    )
                    (ref.eq
                     (ref.as_non_null
                      (local.get $local4)
                     )
                     (ref.as_non_null
                      (local.get $local5)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function115 (type $call112) (param $environment eqref) (param $argument398 (ref null $type12)) (result (ref $type13))
  (local $local0 (ref null $type12))
  (local $local1 i32)
  (local $local2 i32)
  (local.set $local0
   (local.get $argument398)
  )
  (local.set $local2
   (i32.const 0)
  )
  (local.set $local1
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local2)
  )
  (return_call $function116
   (local.get $local2)
   (local.get $local1)
   (local.get $local0)
  )
 )
 (func $function116 (param $capture399 i32) (param $initialized399 i32) (param $argument400 (ref null $type12)) (result (ref $type13))
  (local $local0 (ref null $type13))
  (local $local2 (ref null $type13))
  (local $local1 (ref null $type12))
  (local $local3 (ref null $type12))
  (local $local4 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local5 (ref null $type106))
  (local.set $local6
   (local.get $argument400)
  )
  (if (result (ref $type13))
   (ref.is_null
    (local.get $local6)
   )
   (then
    (global.get $empty14)
   )
   (else
    (local.set $local1
     (local.get $argument400)
    )
    (local.set $local0
     (struct.get $type12 0
      (local.get $local1)
     )
    )
    (local.set $local4
     (local.get $argument400)
    )
    (local.set $local3
     (struct.get $type12 1
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized399)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture399)
    )
    (local.set $local2
     (call $function116
      (local.get $capture399)
      (local.get $initialized399)
      (local.get $local3)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (return_call $function104
     (struct.get $type106 1
      (ref.as_non_null
       (local.get $local5)
      )
     )
     (ref.as_non_null
      (local.get $local0)
     )
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
 )
 (func $function117 (type $call109) (param $environment eqref) (param $argument402 (ref $type13)) (result i64)
  (local $local0 (ref null $type13))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument402)
   )
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function118
   (local.get $local3)
   (local.get $local2)
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
  )
 )
 (func $function118 (param $capture403 i32) (param $initialized403 i32) (param $argument404 (ref $type13)) (param $argument405 i64) (result i64)
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local2 (ref null $type107))
  (local $local7 (ref null $type110))
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local.set $local6
   (ref.as_non_null
    (local.get $argument404)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (if (result i64)
   (call $function111
    (struct.get $type110 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
   )
   (then
    (local.get $argument405)
   )
   (else
    (local.set $local1
     (ref.as_non_null
      (local.get $argument404)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global356)
     )
    )
    (local.set $local0
     (call $function106
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
    )
    (local.set $local4
     (local.get $argument405)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized403)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture403)
    )
    (return_call $function118
     (local.get $capture403)
     (local.get $initialized403)
     (ref.as_non_null
      (local.get $local0)
     )
     (local.get $local3)
    )
   )
  )
 )
 (func $function119 (type $call106) (param $environment eqref) (param $argument407 (ref $type13)) (param $argument408 (ref $type13)) (result (ref $type13))
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local5 (ref null $type13))
  (local $local7 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local2 (ref null $type107))
  (local $local6 (ref null $type107))
  (local $local8 (ref null $type106))
  (local $local9 (ref null $type106))
  (local $local11 (ref null $type110))
  (local.set $local10
   (ref.as_non_null
    (local.get $argument407)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (if (result (ref $type13))
   (call $function111
    (struct.get $type110 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (ref.as_non_null
     (local.get $local10)
    )
   )
   (then
    (ref.as_non_null
     (local.get $argument408)
    )
   )
   (else
    (local.set $local1
     (ref.as_non_null
      (local.get $argument407)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global354)
     )
    )
    (local.set $local0
     (call $function105
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $argument407)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global356)
     )
    )
    (local.set $local4
     (call $function106
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local5)
      )
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument408)
     )
    )
    (if
     (i32.eqz
      (global.get $ready406)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (local.set $local3
     (call $function119
      (struct.get $type106 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (return_call $function104
     (struct.get $type106 1
      (ref.as_non_null
       (local.get $local9)
      )
     )
     (ref.as_non_null
      (local.get $local0)
     )
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
 )
 (func $function120 (type $call106) (param $environment eqref) (param $argument410 (ref $type13)) (param $argument411 (ref $type13)) (result (ref $type13))
  (local $local0 i32)
  (local $local14 i32)
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local5 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local15 (ref null $type13))
  (local $local3 (ref null $type107))
  (local $local7 (ref null $type107))
  (local $local12 (ref null $type107))
  (local $local8 (ref null $type106))
  (local $local13 (ref null $type111))
  (local $local16 (ref null $type110))
  (local.set $local15
   (ref.as_non_null
    (local.get $argument411)
   )
  )
  (local.set $local16
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (if (result (ref $type13))
   (call $function111
    (struct.get $type110 1
     (ref.as_non_null
      (local.get $local16)
     )
    )
    (ref.as_non_null
     (local.get $local15)
    )
   )
   (then
    (local.set $local14
     (i32.const 0)
    )
    (struct.new $type15
     (i32.const 1)
     (local.get $local14)
    )
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument411)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (global.get $global354)
     )
    )
    (local.set $local1
     (call $function105
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $argument410)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global354)
     )
    )
    (local.set $local10
     (call $function105
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local11)
      )
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global384)
     )
    )
    (if (result (ref $type13))
     (call $function114
      (struct.get $type111 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local9)
      )
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
     (else
      (local.set $local4
       (ref.as_non_null
        (local.get $argument410)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $argument411)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global356)
       )
      )
      (local.set $local5
       (call $function106
        (struct.get $type107 1
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (ref.as_non_null
         (local.get $local6)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready409)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local8
       (ref.as_non_null
        (global.get $global409)
       )
      )
      (return_call $function120
       (struct.get $type106 1
        (ref.as_non_null
         (local.get $local8)
        )
       )
       (ref.as_non_null
        (local.get $local4)
       )
       (ref.as_non_null
        (local.get $local5)
       )
      )
     )
    )
   )
  )
 )
 (func $function121 (type $call113) (param $environment eqref) (param $argument414 (ref $type107)) (param $argument415 (ref $type13)) (result (ref $type13))
  (local $local0 i32)
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local7 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local14 (ref null $type13))
  (local $local4 (ref null $type107))
  (local $local5 (ref null $type107))
  (local $local8 (ref null $type107))
  (local $local11 (ref null $type107))
  (local $local12 (ref null $type113))
  (local $local13 (ref null $type106))
  (local $local15 (ref null $type110))
  (local.set $local14
   (ref.as_non_null
    (local.get $argument415)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (if (result (ref $type13))
   (call $function111
    (struct.get $type110 1
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (ref.as_non_null
     (local.get $local14)
    )
   )
   (then
    (global.get $empty14)
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $argument415)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global354)
     )
    )
    (local.set $local2
     (call $function105
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $argument414)
     )
    )
    (local.set $local1
     (call_ref $call107
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (struct.get $type107 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $argument414)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $argument415)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (global.get $global356)
     )
    )
    (local.set $local9
     (call $function106
      (struct.get $type107 1
       (ref.as_non_null
        (local.get $local11)
       )
      )
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready413)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global413)
     )
    )
    (local.set $local7
     (call $function121
      (struct.get $type113 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (ref.as_non_null
       (local.get $local9)
      )
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (return_call $function104
     (struct.get $type106 1
      (ref.as_non_null
       (local.get $local13)
      )
     )
     (ref.as_non_null
      (local.get $local6)
     )
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
 )
 (func $function122 (type $call111) (param $environment eqref) (param $argument418 (ref $type13)) (param $argument419 (ref $type13)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local8 i32)
  (local $local14 i32)
  (local $local16 i32)
  (local $local30 i32)
  (local $local36 i32)
  (local $local42 i32)
  (local $local48 i32)
  (local $local49 i32)
  (local $local50 i32)
  (local $local51 i32)
  (local $local53 i32)
  (local $local54 i32)
  (local $local55 i32)
  (local $local58 i64)
  (local $local61 i64)
  (local $local1 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local12 (ref null $type13))
  (local $local18 (ref null $type13))
  (local $local20 (ref null $type13))
  (local $local21 (ref null $type13))
  (local $local24 (ref null $type13))
  (local $local26 (ref null $type13))
  (local $local27 (ref null $type13))
  (local $local34 (ref null $type13))
  (local $local40 (ref null $type13))
  (local $local46 (ref null $type13))
  (local $local52 (ref null $type13))
  (local $local56 (ref null $type13))
  (local $local57 (ref null $type13))
  (local $local59 (ref null $type13))
  (local $local62 (ref null $type13))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type36))
  (local $local5 (ref null $type36))
  (local $local7 (ref null $type115))
  (local $local9 (ref null $type34))
  (local $local10 (ref null $type34))
  (local $local11 (ref null $type34))
  (local $local13 (ref null $type114))
  (local $local15 (ref null $type32))
  (local $local17 (ref null $type32))
  (local $local19 (ref null $type32))
  (local $local25 (ref null $type32))
  (local $local22 (ref null $type107))
  (local $local28 (ref null $type107))
  (local $local23 (ref null $type111))
  (local $local29 (ref null $type111))
  (local $local31 (ref null $type24))
  (local $local32 (ref null $type24))
  (local $local33 (ref null $type24))
  (local $local35 (ref null $type99))
  (local $local37 (ref null $type22))
  (local $local38 (ref null $type22))
  (local $local39 (ref null $type22))
  (local $local41 (ref null $type85))
  (local $local43 (ref null $type18))
  (local $local44 (ref null $type18))
  (local $local45 (ref null $type18))
  (local $local47 (ref null $type53))
  (local $local60 (ref null $type109))
  (local $local63 (ref null $type109))
  (local.set $local59
   (ref.as_non_null
    (local.get $argument418)
   )
  )
  (local.set $local60
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local58
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local60)
     )
    )
    (ref.as_non_null
     (local.get $local59)
    )
   )
  )
  (local.set $local62
   (ref.as_non_null
    (local.get $argument419)
   )
  )
  (local.set $local63
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (local.set $local61
   (call $function109
    (struct.get $type109 1
     (ref.as_non_null
      (local.get $local63)
     )
    )
    (ref.as_non_null
     (local.get $local62)
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local58)
    (local.get $local61)
   )
   (then
    (local.set $local1
     (ref.as_non_null
      (local.get $argument418)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type13 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (i32.const 1)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i32.eq
        (struct.get $type13 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 1)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local54
         (struct.get $type15 1
          (ref.cast (ref $type15)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local53
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local53)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (local.get $local54)
         (then
          (local.set $local57
           (ref.as_non_null
            (local.get $argument419)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local57)
             )
            )
            (i32.const 1)
           )
           (then
            (unreachable)
           )
          )
          (struct.get $type15 1
           (ref.cast (ref $type15)
            (ref.as_non_null
             (local.get $local57)
            )
           )
          )
         )
         (else
          (local.set $local56
           (ref.as_non_null
            (local.get $argument419)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local56)
             )
            )
            (i32.const 1)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local55
           (struct.get $type15 1
            (ref.cast (ref $type15)
             (ref.as_non_null
              (local.get $local56)
             )
            )
           )
          )
          (i32.eqz
           (local.get $local55)
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (ref.as_non_null
            (local.get $local1)
           )
          )
          (i32.const 2)
         )
         (then
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local49
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (ref.as_non_null
              (local.get $local1)
             )
            )
           )
          )
          (local.set $local48
           (i32.const 1)
          )
          (if
           (i32.eqz
            (local.get $local48)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local50
           (local.get $local49)
          )
          (local.set $local52
           (ref.as_non_null
            (local.get $argument419)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local52)
             )
            )
            (i32.const 2)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local51
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (ref.as_non_null
              (local.get $local52)
             )
            )
           )
          )
          (i32.eq
           (local.get $local50)
           (local.get $local51)
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local1)
             )
            )
            (i32.const 3)
           )
           (then
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local43
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (ref.as_non_null
                (local.get $local1)
               )
              )
             )
            )
            (local.set $local42
             (i32.const 1)
            )
            (if
             (i32.eqz
              (local.get $local42)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local44
             (ref.as_non_null
              (local.get $local43)
             )
            )
            (local.set $local46
             (ref.as_non_null
              (local.get $argument419)
             )
            )
            (if
             (i32.ne
              (struct.get $type13 0
               (ref.as_non_null
                (local.get $local46)
               )
              )
              (i32.const 3)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local45
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (ref.as_non_null
                (local.get $local46)
               )
              )
             )
            )
            (local.set $local47
             (ref.as_non_null
              (global.get $global103)
             )
            )
            (return_call $function39
             (struct.get $type53 1
              (ref.as_non_null
               (local.get $local47)
              )
             )
             (ref.as_non_null
              (local.get $local44)
             )
             (ref.as_non_null
              (local.get $local45)
             )
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (ref.as_non_null
                (local.get $local1)
               )
              )
              (i32.const 4)
             )
             (then
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local37
               (struct.get $type21 1
                (ref.cast (ref $type21)
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
               )
              )
              (local.set $local36
               (i32.const 1)
              )
              (if
               (i32.eqz
                (local.get $local36)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local38
               (ref.as_non_null
                (local.get $local37)
               )
              )
              (local.set $local40
               (ref.as_non_null
                (local.get $argument419)
               )
              )
              (if
               (i32.ne
                (struct.get $type13 0
                 (ref.as_non_null
                  (local.get $local40)
                 )
                )
                (i32.const 4)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local39
               (struct.get $type21 1
                (ref.cast (ref $type21)
                 (ref.as_non_null
                  (local.get $local40)
                 )
                )
               )
              )
              (local.set $local41
               (ref.as_non_null
                (global.get $global260)
               )
              )
              (return_call $function85
               (struct.get $type85 1
                (ref.as_non_null
                 (local.get $local41)
                )
               )
               (ref.as_non_null
                (local.get $local38)
               )
               (ref.as_non_null
                (local.get $local39)
               )
              )
             )
             (else
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
                (i32.const 5)
               )
               (then
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local31
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                 )
                )
                (local.set $local30
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (local.get $local30)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local32
                 (ref.as_non_null
                  (local.get $local31)
                 )
                )
                (local.set $local34
                 (ref.as_non_null
                  (local.get $argument419)
                 )
                )
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (ref.as_non_null
                    (local.get $local34)
                   )
                  )
                  (i32.const 5)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local33
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (ref.as_non_null
                    (local.get $local34)
                   )
                  )
                 )
                )
                (local.set $local35
                 (ref.as_non_null
                  (global.get $global332)
                 )
                )
                (return_call $function101
                 (struct.get $type99 1
                  (ref.as_non_null
                   (local.get $local35)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local32)
                 )
                 (ref.as_non_null
                  (local.get $local33)
                 )
                )
               )
               (else
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                  (i32.const 6)
                 )
                 (then
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local15
                   (struct.get $type31 1
                    (ref.cast (ref $type31)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local14
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local17
                   (struct.get $type31 2
                    (ref.cast (ref $type31)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local16
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (local.get $local14)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local25
                   (ref.as_non_null
                    (local.get $local15)
                   )
                  )
                  (local.set $local24
                   (struct.get $type32 0
                    (ref.as_non_null
                     (local.get $local25)
                    )
                   )
                  )
                  (local.set $local27
                   (ref.as_non_null
                    (local.get $argument419)
                   )
                  )
                  (local.set $local28
                   (ref.as_non_null
                    (global.get $global354)
                   )
                  )
                  (local.set $local26
                   (call $function105
                    (struct.get $type107 1
                     (ref.as_non_null
                      (local.get $local28)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local27)
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready417)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local29
                   (ref.as_non_null
                    (global.get $global417)
                   )
                  )
                  (if (result i32)
                   (call $function122
                    (struct.get $type111 1
                     (ref.as_non_null
                      (local.get $local29)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local24)
                    )
                    (ref.as_non_null
                     (local.get $local26)
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (local.get $local16)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local19
                     (ref.as_non_null
                      (local.get $local17)
                     )
                    )
                    (local.set $local18
                     (struct.get $type32 0
                      (ref.as_non_null
                       (local.get $local19)
                      )
                     )
                    )
                    (local.set $local21
                     (ref.as_non_null
                      (local.get $argument419)
                     )
                    )
                    (local.set $local22
                     (ref.as_non_null
                      (global.get $global356)
                     )
                    )
                    (local.set $local20
                     (call $function106
                      (struct.get $type107 1
                       (ref.as_non_null
                        (local.get $local22)
                       )
                      )
                      (ref.as_non_null
                       (local.get $local21)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready417)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local23
                     (ref.as_non_null
                      (global.get $global417)
                     )
                    )
                    (return_call $function122
                     (struct.get $type111 1
                      (ref.as_non_null
                       (local.get $local23)
                      )
                     )
                     (ref.as_non_null
                      (local.get $local18)
                     )
                     (ref.as_non_null
                      (local.get $local20)
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if (result i32)
                   (i32.eq
                    (struct.get $type13 0
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                    (i32.const 7)
                   )
                   (then
                    (if
                     (i32.eqz
                      (local.get $local0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local9
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (ref.as_non_null
                        (local.get $local1)
                       )
                      )
                     )
                    )
                    (local.set $local8
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (local.get $local8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local10
                     (ref.as_non_null
                      (local.get $local9)
                     )
                    )
                    (local.set $local12
                     (ref.as_non_null
                      (local.get $argument419)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (ref.as_non_null
                        (local.get $local12)
                       )
                      )
                      (i32.const 7)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local11
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (ref.as_non_null
                        (local.get $local12)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready429)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local13
                     (ref.as_non_null
                      (global.get $global429)
                     )
                    )
                    (return_call $function123
                     (struct.get $type114 1
                      (ref.as_non_null
                       (local.get $local13)
                      )
                     )
                     (ref.as_non_null
                      (local.get $local10)
                     )
                     (ref.as_non_null
                      (local.get $local11)
                     )
                    )
                   )
                   (else
                    (if
                     (i32.eqz
                      (local.get $local0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local3
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (ref.as_non_null
                        (local.get $local1)
                       )
                      )
                     )
                    )
                    (local.set $local2
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (local.get $local2)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local4
                     (ref.as_non_null
                      (local.get $local3)
                     )
                    )
                    (local.set $local6
                     (ref.as_non_null
                      (local.get $argument419)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (ref.as_non_null
                        (local.get $local6)
                       )
                      )
                      (i32.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local5
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (ref.as_non_null
                        (local.get $local6)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready437)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local7
                     (ref.as_non_null
                      (global.get $global437)
                     )
                    )
                    (return_call $function125
                     (struct.get $type115 1
                      (ref.as_non_null
                       (local.get $local7)
                      )
                     )
                     (ref.as_non_null
                      (local.get $local4)
                     )
                     (ref.as_non_null
                      (local.get $local5)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function123 (type $call114) (param $environment eqref) (param $argument430 (ref $type34)) (param $argument431 (ref $type34)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local2 (ref null $type34))
  (local $local8 (ref null $type34))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument430)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $argument431)
   )
  )
  (local.set $local7
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local8)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (local.set $local3
     (i64.const 0)
    )
    (local.set $local5
     (i32.const 0)
    )
    (local.set $local4
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local5)
    )
    (return_call $function124
     (ref.as_non_null
      (local.get $argument430)
     )
     (ref.as_non_null
      (local.get $argument431)
     )
     (block (result i64)
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local1)
     )
     (local.get $local5)
     (local.get $local4)
     (local.get $local3)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function124 (param $capture430 (ref $type34)) (param $capture431 (ref $type34)) (param $capture432 i64) (param $capture433 i32) (param $initialized433 i32) (param $argument434 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local7 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local8 (ref null $type34))
  (local $local11 (ref null $type34))
  (local $local13 (ref null $type111))
  (local.set $local2
   (local.get $argument434)
  )
  (local.set $local3
   (local.get $capture432)
  )
  (local.set $local1
   (i64.eq
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local8
     (ref.as_non_null
      (local.get $capture430)
     )
    )
    (local.set $local9
     (local.get $argument434)
    )
    (local.set $local7
     (array.get $type34
      (ref.as_non_null
       (local.get $local8)
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local9)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local9)
       )
      )
     )
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $capture431)
     )
    )
    (local.set $local12
     (local.get $argument434)
    )
    (local.set $local10
     (array.get $type34
      (ref.as_non_null
       (local.get $local11)
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local12)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local12)
       )
      )
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (if (result i32)
     (call $function122
      (struct.get $type111 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local7)
      )
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (then
      (local.set $local5
       (local.get $argument434)
      )
      (local.set $local6
       (i64.const 1)
      )
      (local.set $local4
       (i64.add
        (local.get $local5)
        (local.get $local6)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized433)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture433)
      )
      (return_call $function124
       (ref.as_non_null
        (local.get $capture430)
       )
       (ref.as_non_null
        (local.get $capture431)
       )
       (local.get $capture432)
       (local.get $capture433)
       (local.get $initialized433)
       (local.get $local4)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function125 (type $call115) (param $environment eqref) (param $argument438 (ref $type36)) (param $argument439 (ref $type36)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local2 (ref null $type36))
  (local $local8 (ref null $type36))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument438)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $argument439)
   )
  )
  (local.set $local7
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local8)
      )
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (local.set $local3
     (i64.const 0)
    )
    (local.set $local5
     (i32.const 0)
    )
    (local.set $local4
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local5)
    )
    (return_call $function126
     (ref.as_non_null
      (local.get $argument438)
     )
     (ref.as_non_null
      (local.get $argument439)
     )
     (block (result i64)
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local1)
     )
     (local.get $local5)
     (local.get $local4)
     (local.get $local3)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function126 (param $capture438 (ref $type36)) (param $capture439 (ref $type36)) (param $capture440 i64) (param $capture441 i32) (param $initialized441 i32) (param $argument442 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local8 (ref null $type36))
  (local $local11 (ref null $type36))
  (local.set $local2
   (local.get $argument442)
  )
  (local.set $local3
   (local.get $capture440)
  )
  (local.set $local1
   (i64.eq
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local8
     (ref.as_non_null
      (local.get $capture438)
     )
    )
    (local.set $local9
     (local.get $argument442)
    )
    (local.set $local7
     (i64.extend_i32_u
      (array.get_u $type37
       (struct.get $type36 1
        (ref.as_non_null
         (local.get $local8)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.get $local9)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $local9)
        )
       )
      )
     )
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $capture439)
     )
    )
    (local.set $local12
     (local.get $argument442)
    )
    (local.set $local10
     (i64.extend_i32_u
      (array.get_u $type37
       (struct.get $type36 1
        (ref.as_non_null
         (local.get $local11)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.get $local12)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $local12)
        )
       )
      )
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $local7)
      (local.get $local10)
     )
     (then
      (local.set $local5
       (local.get $argument442)
      )
      (local.set $local6
       (i64.const 1)
      )
      (local.set $local4
       (i64.add
        (local.get $local5)
        (local.get $local6)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized441)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture441)
      )
      (return_call $function126
       (ref.as_non_null
        (local.get $capture438)
       )
       (ref.as_non_null
        (local.get $capture439)
       )
       (local.get $capture440)
       (local.get $capture441)
       (local.get $initialized441)
       (local.get $local4)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function127 (type $call116) (param $environment eqref) (param $argument445 (ref $type18)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local2 (ref null $type18))
  (call $foreign15)
  (drop
   (i32.const 0)
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument445)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function128
   (ref.as_non_null
    (local.get $argument445)
   )
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local5)
   (local.get $local4)
   (local.get $local3)
  )
 )
 (func $function128 (param $capture445 (ref $type18)) (param $capture446 i64) (param $capture447 i32) (param $initialized447 i32) (param $argument448 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type18))
  (local.set $local7
   (local.get $argument448)
  )
  (local.set $local8
   (local.get $capture446)
  )
  (if (result i32)
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture445)
     )
    )
    (local.set $local5
     (local.get $argument448)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (call $foreign16
     (local.get $local3)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument448)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized447)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture447)
    )
    (return_call $function128
     (ref.as_non_null
      (local.get $capture445)
     )
     (local.get $capture446)
     (local.get $capture447)
     (local.get $initialized447)
     (local.get $local0)
    )
   )
  )
 )
 (func $function129 (type $call83) (param $environment eqref) (param $argument450 (ref $type18)) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type116))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument450)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global444)
   )
  )
  (drop
   (call $function127
    (struct.get $type116 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (call $foreign17)
  )
  (local.set $local1
   (i32.const 1)
  )
  (i32.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function130 (type $call116) (param $environment eqref) (param $argument452 (ref $type18)) (result i32)
  (local $local0 (ref null $type18))
  (local $local1 (ref null $type116))
  (local.set $local0
   (ref.as_non_null
    (local.get $argument452)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global444)
   )
  )
  (drop
   (call $function127
    (struct.get $type116 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (ref.as_non_null
     (local.get $local0)
    )
   )
  )
  (call $foreign18)
  (i32.const 0)
 )
 (func $function131 (type $call117) (param $environment eqref) (param $argument454 (ref $type18)) (result (ref $type118))
  (local $local0 (ref null $type119))
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type116))
  (local $local1 i32)
  (local.set $local2
   (ref.as_non_null
    (local.get $argument454)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global444)
   )
  )
  (drop
   (call $function127
    (struct.get $type116 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local1
   (call $foreign19)
  )
  (local.set $local0
   (struct.new $type119
    (local.get $local1)
   )
  )
  (struct.new $type118
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function132 (type $call120) (param $environment eqref) (param $argument456 (ref $type18)) (result (ref $type121))
  (local $local0 (ref null $type119))
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type116))
  (local $local1 i32)
  (local.set $local2
   (ref.as_non_null
    (local.get $argument456)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global444)
   )
  )
  (drop
   (call $function127
    (struct.get $type116 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local1
   (call $foreign20)
  )
  (local.set $local0
   (struct.new $type119
    (local.get $local1)
   )
  )
  (struct.new $type121
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function133 (type $call122) (param $environment eqref) (param $argument458 (ref $type118)) (result i32)
  (local $local0 (ref null $type119))
  (local $local1 (ref null $type118))
  (local $local2 (ref null $type124))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument458)
   )
  )
  (local.set $local0
   (struct.get $type118 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready459)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global459)
   )
  )
  (return_call $function134
   (struct.get $type124 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function134 (type $call124) (param $environment eqref) (param $argument460 (ref $type119)) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local3 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local2 (ref null $type119))
  (local $local4 (ref null $type119))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument460)
   )
  )
  (local.set $local1
   (struct.get $type119 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local7
   (i32.const -1)
  )
  (if (result i32)
   (i32.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $argument460)
     )
    )
    (local.set $local5
     (i32.const -1)
    )
    (struct.set $type119 0
     (ref.as_non_null
      (local.get $local4)
     )
     (local.get $local5)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (local.get $local1)
    )
    (call $foreign21
     (local.get $local3)
    )
    (i32.const 0)
   )
  )
 )
 (func $function135 (type $call123) (param $environment eqref) (param $argument463 (ref $type121)) (result i32)
  (local $local0 (ref null $type119))
  (local $local1 (ref null $type121))
  (local $local2 (ref null $type124))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument463)
   )
  )
  (local.set $local0
   (struct.get $type121 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready459)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global459)
   )
  )
  (return_call $function134
   (struct.get $type124 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function136 (type $call129) (param $environment eqref) (param $argument465 (ref $type130)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local3 i32)
  (local $local1 (ref null $type130))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument465)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type130 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type132 1
      (ref.cast (ref $type132)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (i32.const 0)
   )
  )
 )
 (func $function137 (type $call133) (param $environment eqref) (param $argument469 i32) (result (ref $type130))
  (local $local0 i32)
  (local $local2 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local1 i64)
  (local.set $local3
   (local.get $argument469)
  )
  (local.set $local4
   (i32.const -1)
  )
  (if (result (ref $type130))
   (i32.eq
    (local.get $local3)
    (local.get $local4)
   )
   (then
    (global.get $empty131)
   )
   (else
    (local.set $local2
     (local.get $argument469)
    )
    (local.set $local1
     (i64.extend_i32_s
      (local.get $local2)
     )
    )
    (if
     (i64.gt_u
      (local.get $local1)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local1)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local1)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local0
     (i32.wrap_i64
      (local.get $local1)
     )
    )
    (struct.new $type132
     (i32.const 1)
     (local.get $local0)
    )
   )
  )
 )
 (func $function138 (type $call134) (param $environment eqref) (param $argument471 (ref $type121)) (result (ref $type130))
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 (ref null $type119))
  (local $local3 (ref null $type121))
  (local $local4 (ref null $type133))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument471)
   )
  )
  (local.set $local2
   (struct.get $type121 0
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local1
   (struct.get $type119 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (call $foreign22
    (local.get $local1)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (return_call $function137
   (struct.get $type133 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (local.get $local0)
  )
 )
 (func $function139 (type $call134) (param $environment eqref) (param $argument473 (ref $type121)) (result (ref $type130))
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 (ref null $type119))
  (local $local3 (ref null $type121))
  (local $local4 (ref null $type133))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument473)
   )
  )
  (local.set $local2
   (struct.get $type121 0
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local1
   (struct.get $type119 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (call $foreign23
    (local.get $local1)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (return_call $function137
   (struct.get $type133 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (local.get $local0)
  )
 )
 (func $function140 (type $call135) (param $environment eqref) (param $argument475 (ref $type136)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local1 (ref null $type136))
  (local $local3 (ref null $type18))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument475)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type136 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type138 1
      (ref.cast (ref $type138)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (i32.const 0)
   )
  )
 )
 (func $function141 (type $call139) (param $environment eqref) (param $argument479 (ref $type121)) (result (ref $type136))
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local15 i32)
  (local $local16 i32)
  (local $local11 i64)
  (local $local13 i64)
  (local $local2 (ref null $type119))
  (local $local3 (ref null $type121))
  (local $local7 (ref null $type18))
  (local $local10 (ref null $type18))
  (local $local12 (ref null $type43))
  (local $local14 (ref null $type141))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument479)
   )
  )
  (local.set $local2
   (struct.get $type121 0
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local1
   (struct.get $type119 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local5
   (call $foreign22
    (local.get $local6)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (local.get $local5)
  )
  (local.set $local16
   (i32.const -1)
  )
  (if (result (ref $type136))
   (i32.eq
    (local.get $local15)
    (local.get $local16)
   )
   (then
    (global.get $empty137)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (local.get $local5)
    )
    (local.set $local11
     (i64.const 0)
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local10
     (call $function25
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (local.get $local11)
     )
    )
    (local.set $local13
     (i64.const 0)
    )
    (if
     (i32.eqz
      (global.get $ready482)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global482)
     )
    )
    (local.set $local7
     (call $function142
      (struct.get $type141 1
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (local.get $local8)
      (local.get $local9)
      (ref.as_non_null
       (local.get $local10)
      )
      (local.get $local13)
     )
    )
    (struct.new $type138
     (i32.const 1)
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
 )
 (func $function142 (type $call141) (param $environment eqref) (param $argument483 i32) (param $argument484 i32) (param $argument485 (ref $type18)) (param $argument486 i64) (result (ref $type18))
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local15 i32)
  (local $local17 i32)
  (local $local18 i32)
  (local $local26 i32)
  (local $local28 i32)
  (local $local29 i32)
  (local $local30 i32)
  (local $local31 i32)
  (local $local32 i32)
  (local $local33 i32)
  (local $local34 i32)
  (local $local35 i32)
  (local $local36 i32)
  (local $local37 i32)
  (local $local38 i32)
  (local $local39 i32)
  (local $local3 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local1 (ref null $type18))
  (local $local2 (ref null $type18))
  (local $local8 (ref null $type18))
  (local $local13 (ref null $type18))
  (local $local19 (ref null $type18))
  (local $local25 (ref null $type18))
  (local $local4 (ref null $type142))
  (local $local12 (ref null $type141))
  (local $local22 (ref null $type47))
  (local $local27 (ref null $type140))
  (local.set $local32
   (local.get $argument484)
  )
  (local.set $local33
   (i32.const -1)
  )
  (local.set $local31
   (i32.eq
    (local.get $local32)
    (local.get $local33)
   )
  )
  (local.set $local30
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local30)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (if (result i32)
    (local.get $local31)
    (then
     (if
      (i32.eqz
       (local.get $local30)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local31)
    )
    (else
     (local.set $local36
      (local.get $argument484)
     )
     (local.set $local37
      (i32.const 10)
     )
     (local.set $local35
      (i32.eq
       (local.get $local36)
       (local.get $local37)
      )
     )
     (local.set $local34
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local34)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local35)
      (then
       (if
        (i32.eqz
         (local.get $local34)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local35)
      )
      (else
       (local.set $local38
        (local.get $argument484)
       )
       (local.set $local39
        (i32.const 13)
       )
       (i32.eq
        (local.get $local38)
        (local.get $local39)
       )
      )
     )
    )
   )
   (then
    (local.set $local28
     (local.get $argument484)
    )
    (local.set $local29
     (i32.const 13)
    )
    (drop
     (if (result i32)
      (i32.eq
       (local.get $local28)
       (local.get $local29)
      )
      (then
       (local.set $local26
        (local.get $argument483)
       )
       (local.set $local27
        (ref.as_non_null
         (global.get $global489)
        )
       )
       (drop
        (call $function143
         (struct.get $type140 1
          (ref.as_non_null
           (local.get $local27)
          )
         )
         (local.get $local26)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $local23
     (local.get $argument486)
    )
    (local.set $local25
     (ref.as_non_null
      (local.get $argument485)
     )
    )
    (local.set $local24
     (i64.extend_i32_u
      (struct.get $type18 1
       (ref.as_non_null
        (local.get $local25)
       )
      )
     )
    )
    (if (result (ref $type18))
     (i64.eq
      (local.get $local23)
      (local.get $local24)
     )
     (then
      (ref.as_non_null
       (local.get $argument485)
      )
     )
     (else
      (local.set $local19
       (ref.as_non_null
        (local.get $argument485)
       )
      )
      (local.set $local20
       (i64.const 0)
      )
      (local.set $local21
       (local.get $argument486)
      )
      (local.set $local22
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (return_call $function33
       (struct.get $type47 1
        (ref.as_non_null
         (local.get $local22)
        )
       )
       (ref.as_non_null
        (local.get $local19)
       )
       (local.get $local20)
       (local.get $local21)
      )
     )
    )
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument485)
     )
    )
    (local.set $local3
     (local.get $argument486)
    )
    (if
     (i32.eqz
      (global.get $ready492)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global492)
     )
    )
    (local.set $local1
     (call $function144
      (struct.get $type142 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (local.get $local3)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local14
     (local.get $argument486)
    )
    (local.set $local17
     (local.get $argument484)
    )
    (local.set $local16
     (i64.extend_i32_s
      (local.get $local17)
     )
    )
    (if
     (i64.gt_u
      (local.get $local16)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local16)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local16)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (i32.wrap_i64
      (local.get $local16)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local14)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (i32.wrap_i64
      (local.get $local14)
     )
    )
    (array.set $type19
     (call $string-block
      (ref.as_non_null
       (local.get $local13)
      )
      (local.get $local18)
     )
     (i32.and
      (local.get $local18)
      (i32.const 8191)
     )
     (local.get $local15)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local5
     (local.get $argument483)
    )
    (local.set $local7
     (local.get $argument483)
    )
    (local.set $local6
     (call $foreign22
      (local.get $local7)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local10
     (local.get $argument486)
    )
    (local.set $local11
     (i64.const 1)
    )
    (local.set $local9
     (i64.add
      (local.get $local10)
      (local.get $local11)
     )
    )
    (if
     (i32.eqz
      (global.get $ready482)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global482)
     )
    )
    (return_call $function142
     (struct.get $type141 1
      (ref.as_non_null
       (local.get $local12)
      )
     )
     (local.get $local5)
     (local.get $local6)
     (ref.as_non_null
      (local.get $local8)
     )
     (local.get $local9)
    )
   )
  )
 )
 (func $function143 (type $call140) (param $environment eqref) (param $argument490 i32) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local2
   (local.get $argument490)
  )
  (local.set $local1
   (call $foreign23
    (local.get $local2)
   )
  )
  (local.set $local3
   (i32.const 10)
  )
  (if (result i32)
   (i32.eq
    (local.get $local1)
    (local.get $local3)
   )
   (then
    (local.set $local0
     (local.get $argument490)
    )
    (drop
     (call $foreign22
      (local.get $local0)
     )
    )
    (i32.const 0)
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function144 (type $call142) (param $environment eqref) (param $argument493 (ref $type18)) (param $argument494 i64) (result (ref $type18))
  (local $local0 i32)
  (local $local8 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local9 (ref null $type18))
  (local $local12 (ref null $type18))
  (local $local14 (ref null $type18))
  (local $local21 (ref null $type18))
  (local $local11 (ref null $type43))
  (local.set $local19
   (local.get $argument494)
  )
  (local.set $local21
   (ref.as_non_null
    (local.get $argument493)
   )
  )
  (local.set $local20
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local21)
     )
    )
   )
  )
  (if (result (ref $type18))
   (i64.lt_s
    (local.get $local19)
    (local.get $local20)
   )
   (then
    (ref.as_non_null
     (local.get $argument493)
    )
   )
   (else
    (local.set $local17
     (local.get $argument494)
    )
    (local.set $local18
     (i64.const 4294967294)
    )
    (if (result (ref $type18))
     (i64.eq
      (local.get $local17)
      (local.get $local18)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local6
       (local.get $argument494)
      )
      (local.set $local7
       (i64.const 0)
      )
      (local.set $local1
       (if (result i64)
        (i64.eq
         (local.get $local6)
         (local.get $local7)
        )
        (then
         (i64.const 64)
        )
        (else
         (local.set $local4
          (local.get $argument494)
         )
         (local.set $local5
          (i64.const 2147483647)
         )
         (if (result i64)
          (i64.gt_s
           (local.get $local4)
           (local.get $local5)
          )
          (then
           (i64.const 4294967294)
          )
          (else
           (local.set $local2
            (local.get $argument494)
           )
           (local.set $local3
            (i64.const 2)
           )
           (i64.mul
            (local.get $local2)
            (local.get $local3)
           )
          )
         )
        )
       )
      )
      (local.set $local0
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local10
       (local.get $local1)
      )
      (local.set $local11
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (local.set $local9
       (call $function25
        (struct.get $type43 1
         (ref.as_non_null
          (local.get $local11)
         )
        )
        (local.get $local10)
       )
      )
      (local.set $local8
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local12
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.set $local13
       (i64.const 0)
      )
      (local.set $local14
       (ref.as_non_null
        (local.get $argument493)
       )
      )
      (local.set $local15
       (i64.const 0)
      )
      (local.set $local16
       (local.get $argument494)
      )
      (drop
       (call $string-copy
        (ref.as_non_null
         (local.get $local12)
        )
        (local.get $local13)
        (ref.as_non_null
         (local.get $local14)
        )
        (local.get $local15)
        (local.get $local16)
       )
      )
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (local.get $local9)
      )
     )
    )
   )
  )
 )
 (func $function145 (type $call143) (param $environment eqref) (param $argument498 i32) (param $argument499 (ref $type118)) (result i32)
  (local $local0 i32)
  (local $local3 i32)
  (local $local1 (ref null $type119))
  (local $local2 (ref null $type118))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument499)
   )
  )
  (local.set $local1
   (struct.get $type118 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (struct.get $type119 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (local.get $argument498)
  )
  (call $foreign24
   (local.get $local0)
   (local.get $local3)
  )
  (i32.const 0)
 )
 (func $function146 (type $call144) (param $environment eqref) (param $argument501 (ref $type18)) (param $argument502 (ref $type118)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local2 (ref null $type18))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument501)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function147
   (ref.as_non_null
    (local.get $argument501)
   )
   (ref.as_non_null
    (local.get $argument502)
   )
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local5)
   (local.get $local4)
   (local.get $local3)
  )
 )
 (func $function147 (param $capture501 (ref $type18)) (param $capture502 (ref $type118)) (param $capture503 i64) (param $capture504 i32) (param $initialized504 i32) (param $argument505 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type18))
  (local $local7 (ref null $type118))
  (local $local8 (ref null $type143))
  (local.set $local9
   (local.get $argument505)
  )
  (local.set $local10
   (local.get $capture503)
  )
  (if (result i32)
   (i64.eq
    (local.get $local9)
    (local.get $local10)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture501)
     )
    )
    (local.set $local5
     (local.get $argument505)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $capture502)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global497)
     )
    )
    (drop
     (call $function145
      (struct.get $type143 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (local.get $local3)
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local1
     (local.get $argument505)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized504)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture504)
    )
    (return_call $function147
     (ref.as_non_null
      (local.get $capture501)
     )
     (ref.as_non_null
      (local.get $capture502)
     )
     (local.get $capture503)
     (local.get $capture504)
     (local.get $initialized504)
     (local.get $local0)
    )
   )
  )
 )
 (func $function148 (type $call122) (param $environment eqref) (param $argument507 (ref $type118)) (result i32)
  (local $local0 i32)
  (local $local1 (ref null $type118))
  (local $local2 (ref null $type143))
  (local.set $local0
   (i32.const 10)
  )
  (local.set $local1
   (ref.as_non_null
    (local.get $argument507)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global497)
   )
  )
  (return_call $function145
   (struct.get $type143 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (local.get $local0)
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function149 (type $call145) (param $environment eqref) (param $argument509 i64) (param $argument510 (ref $type118)) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local7 i32)
  (local $local5 (ref null $type118))
  (local $local8 (ref null $type118))
  (local $local6 (ref null $type145))
  (local $local9 (ref null $type143))
  (local.set $local10
   (local.get $argument509)
  )
  (local.set $local11
   (i64.const 0)
  )
  (drop
   (if (result i32)
    (i64.lt_s
     (local.get $local10)
     (local.get $local11)
    )
    (then
     (local.set $local7
      (i32.const 45)
     )
     (local.set $local8
      (ref.as_non_null
       (local.get $argument510)
      )
     )
     (local.set $local9
      (ref.as_non_null
       (global.get $global497)
      )
     )
     (drop
      (call $function145
       (struct.get $type143 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
       (local.get $local7)
       (ref.as_non_null
        (local.get $local8)
       )
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 0)
    )
   )
  )
  (local.set $local3
   (local.get $argument509)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local0
   (if (result i64)
    (i64.gt_s
     (local.get $local3)
     (local.get $local4)
    )
    (then
     (local.set $local1
      (i64.const 0)
     )
     (local.set $local2
      (local.get $argument509)
     )
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (else
     (local.get $argument509)
    )
   )
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument510)
   )
  )
  (if
   (i32.eqz
    (global.get $ready511)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global511)
   )
  )
  (return_call $function150
   (struct.get $type145 1
    (ref.as_non_null
     (local.get $local6)
    )
   )
   (local.get $local0)
   (ref.as_non_null
    (local.get $local5)
   )
  )
 )
 (func $function150 (type $call145) (param $environment eqref) (param $argument512 i64) (param $argument513 (ref $type118)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local10 (ref null $type118))
  (local $local13 (ref null $type118))
  (local $local11 (ref null $type143))
  (local $local14 (ref null $type145))
  (local.set $local2
   (local.get $argument512)
  )
  (local.set $local3
   (i64.const 10)
  )
  (local.set $local1
   (i64.div_s
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (local.get $local1)
  )
  (local.set $local16
   (i64.const 0)
  )
  (drop
   (if (result i32)
    (i64.eq
     (local.get $local15)
     (local.get $local16)
    )
    (then
     (i32.const 0)
    )
    (else
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local12
      (local.get $local1)
     )
     (local.set $local13
      (ref.as_non_null
       (local.get $argument513)
      )
     )
     (if
      (i32.eqz
       (global.get $ready511)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local14
      (ref.as_non_null
       (global.get $global511)
      )
     )
     (drop
      (call $function150
       (struct.get $type145 1
        (ref.as_non_null
         (local.get $local14)
        )
       )
       (local.get $local12)
       (ref.as_non_null
        (local.get $local13)
       )
      )
     )
     (i32.const 0)
    )
   )
  )
  (local.set $local6
   (i64.const 48)
  )
  (local.set $local8
   (local.get $argument512)
  )
  (local.set $local9
   (i64.const 10)
  )
  (local.set $local7
   (i64.rem_s
    (local.get $local8)
    (local.get $local9)
   )
  )
  (local.set $local5
   (i64.sub
    (local.get $local6)
    (local.get $local7)
   )
  )
  (if
   (i64.gt_u
    (local.get $local5)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ge_u
     (local.get $local5)
     (i64.const 55296)
    )
    (i64.le_u
     (local.get $local5)
     (i64.const 57343)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (i32.wrap_i64
    (local.get $local5)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (local.get $argument513)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global497)
   )
  )
  (return_call $function145
   (struct.get $type143 1
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (local.get $local4)
   (ref.as_non_null
    (local.get $local10)
   )
  )
 )
 (func $function151 (type $call146) (param $environment eqref) (param $argument516 (ref $type101)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local1 (ref null $type101))
  (local $local3 (ref null $type18))
  (local $local5 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument516)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type101 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type103 1
        (ref.cast (ref $type103)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (i32.const 0)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local3
       (struct.get $type104 1
        (ref.cast (ref $type104)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local2
       (i32.const 1)
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function152 (type $call147) (param $environment eqref) (param $argument521 (ref $type101)) (result (ref $type13))
  (local $local0 i32)
  (local $local2 i32)
  (local $local11 i32)
  (local $local1 (ref null $type101))
  (local $local3 (ref null $type18))
  (local $local4 (ref null $type18))
  (local $local5 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local9 (ref null $type18))
  (local $local7 (ref null $type49))
  (local $local8 (ref null $type82))
  (local $local10 (ref null $type82))
  (local $local12 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument521)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type13))
   (i32.eq
    (struct.get $type101 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (struct.get $type103 1
      (ref.cast (ref $type103)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local11
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local11)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local12)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type13))
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (local.set $local9
       (global.get $string3)
      )
      (local.set $local10
       (ref.as_non_null
        (global.get $global252)
       )
      )
      (call $function82
       (struct.get $type82 1
        (ref.as_non_null
         (local.get $local10)
        )
       )
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (unreachable)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local3
       (struct.get $type104 1
        (ref.cast (ref $type104)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local2
       (i32.const 1)
      )
      (local.set $local5
       (global.get $string2)
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global90)
       )
      )
      (local.set $local4
       (call $function35
        (struct.get $type49 1
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (struct.new $type50
         (ref.as_non_null
          (local.get $local5)
         )
         (struct.new $type50
          (ref.as_non_null
           (local.get $local6)
          )
          (ref.null none)
         )
        )
       )
      )
      (local.set $local8
       (ref.as_non_null
        (global.get $global252)
       )
      )
      (call $function82
       (struct.get $type82 1
        (ref.as_non_null
         (local.get $local8)
        )
       )
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (unreachable)
     )
    )
   )
  )
 )
 (func $function153 (type $call148) (param $environment eqref) (param $argument526 (ref $type121)) (result (ref $type101))
  (local $local0 (ref null $type121))
  (local $local2 (ref null $type121))
  (local $local1 (ref null $type163))
  (local $local3 (ref null $type162))
  (local $local4 (ref null $type190))
  (local.set $local0
   (ref.as_non_null
    (local.get $argument526)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument526)
   )
  )
  (if
   (i32.eqz
    (global.get $ready527)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (local.set $local1
   (call $function154
    (struct.get $type162 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready702)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global702)
   )
  )
  (return_call $function196
   (struct.get $type190 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function154 (type $call162) (param $environment eqref) (param $argument528 (ref $type121)) (result (ref $type163))
  (local $local0 i32)
  (local $local12 i32)
  (local $local1 i64)
  (local $local5 i64)
  (local $local11 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local2 (ref null $type121))
  (local $local4 (ref null $type121))
  (local $local7 (ref null $type121))
  (local $local9 (ref null $type121))
  (local $local14 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local6 (ref null $type171))
  (local $local8 (ref null $type162))
  (local $local15 (ref null $type162))
  (local $local10 (ref null $type123))
  (local $local13 (ref null $type150))
  (local $local17 (ref null $type152))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument528)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local18
   (local.get $local1)
  )
  (local.set $local19
   (i64.const 0)
  )
  (if (result (ref $type163))
   (i64.lt_s
    (local.get $local18)
    (local.get $local19)
   )
   (then
    (global.get $empty165)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (local.set $local17
     (ref.as_non_null
      (global.get $global536)
     )
    )
    (if (result (ref $type163))
     (call $function157
      (struct.get $type152 1
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (local.get $local16)
     )
     (then
      (local.set $local14
       (ref.as_non_null
        (local.get $argument528)
       )
      )
      (if
       (i32.eqz
        (global.get $ready527)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local15
       (ref.as_non_null
        (global.get $global527)
       )
      )
      (return_call $function154
       (struct.get $type162 1
        (ref.as_non_null
         (local.get $local15)
        )
       )
       (ref.as_non_null
        (local.get $local14)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local11
       (local.get $local1)
      )
      (local.set $local12
       (i32.const 59)
      )
      (local.set $local13
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result (ref $type163))
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local13)
         )
        )
        (local.get $local11)
        (local.get $local12)
       )
       (then
        (local.set $local9
         (ref.as_non_null
          (local.get $argument528)
         )
        )
        (local.set $local10
         (ref.as_non_null
          (global.get $global541)
         )
        )
        (drop
         (call $function159
          (struct.get $type123 1
           (ref.as_non_null
            (local.get $local10)
           )
          )
          (ref.as_non_null
           (local.get $local9)
          )
         )
        )
        (local.set $local7
         (ref.as_non_null
          (local.get $argument528)
         )
        )
        (if
         (i32.eqz
          (global.get $ready527)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local8
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (return_call $function154
         (struct.get $type162 1
          (ref.as_non_null
           (local.get $local8)
          )
         )
         (ref.as_non_null
          (local.get $local7)
         )
        )
       )
       (else
        (local.set $local4
         (ref.as_non_null
          (local.get $argument528)
         )
        )
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local5
         (local.get $local1)
        )
        (if
         (i32.eqz
          (global.get $ready546)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local6
         (ref.as_non_null
          (global.get $global546)
         )
        )
        (return_call $function160
         (struct.get $type171 1
          (ref.as_non_null
           (local.get $local6)
          )
         )
         (ref.as_non_null
          (local.get $local4)
         )
         (local.get $local5)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function155 (type $call128) (param $environment eqref) (param $argument531 (ref $type121)) (result i64)
  (local $local0 (ref null $type130))
  (local $local1 (ref null $type121))
  (local $local2 (ref null $type134))
  (local $local3 (ref null $type149))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument531)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global470)
   )
  )
  (local.set $local0
   (call $function138
    (struct.get $type134 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (return_call $function156
   (struct.get $type149 1
    (ref.as_non_null
     (local.get $local3)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function156 (type $call149) (param $environment eqref) (param $argument533 (ref $type130)) (result i64)
  (local $local0 i32)
  (local $local2 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local1 (ref null $type130))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument533)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i32.eq
    (struct.get $type130 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i64.const -1)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type132 1
      (ref.cast (ref $type132)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (local.get $local3)
    )
    (i64.extend_i32_u
     (local.get $local4)
    )
   )
  )
 )
 (func $function157 (type $call152) (param $environment eqref) (param $argument537 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local3 i32)
  (local $local2 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local.set $local4
   (local.get $argument537)
  )
  (local.set $local5
   (i64.const 0)
  )
  (if (result i32)
   (i64.ge_s
    (local.get $local4)
    (local.get $local5)
   )
   (then
    (local.set $local2
     (local.get $argument537)
    )
    (if
     (i64.gt_u
      (local.get $local2)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local2)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local2)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local1
     (i32.wrap_i64
      (local.get $local2)
     )
    )
    (local.set $local0
     (call $foreign25
      (local.get $local1)
     )
    )
    (local.set $local3
     (i32.const 1)
    )
    (i32.eq
     (local.get $local0)
     (local.get $local3)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function158 (type $call150) (param $environment eqref) (param $argument539 i64) (param $argument540 i32) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local.set $local0
   (local.get $argument539)
  )
  (local.set $local2
   (local.get $argument540)
  )
  (local.set $local1
   (i64.extend_i32_u
    (local.get $local2)
   )
  )
  (i64.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function159 (type $call123) (param $environment eqref) (param $argument542 (ref $type121)) (result i32)
  (local $local0 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local10 i32)
  (local $local11 i32)
  (local $local13 i32)
  (local $local16 i32)
  (local $local1 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local2 (ref null $type121))
  (local $local4 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local5 (ref null $type123))
  (local $local14 (ref null $type150))
  (local $local17 (ref null $type150))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument542)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (local.get $local1)
  )
  (local.set $local9
   (i64.const 0)
  )
  (local.set $local7
   (i64.lt_s
    (local.get $local8)
    (local.get $local9)
   )
  )
  (local.set $local6
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local6)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.get $local7)
    (then
     (if
      (i32.eqz
       (local.get $local6)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local7)
    )
    (else
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local12
      (local.get $local1)
     )
     (local.set $local13
      (i32.const 10)
     )
     (local.set $local14
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (local.set $local11
      (call $function158
       (struct.get $type150 1
        (ref.as_non_null
         (local.get $local14)
        )
       )
       (local.get $local12)
       (local.get $local13)
      )
     )
     (local.set $local10
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local10)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local11)
      (then
       (if
        (i32.eqz
         (local.get $local10)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local11)
      )
      (else
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local15
        (local.get $local1)
       )
       (local.set $local16
        (i32.const 13)
       )
       (local.set $local17
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local17)
         )
        )
        (local.get $local15)
        (local.get $local16)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $argument542)
     )
    )
    (if
     (i32.eqz
      (global.get $ready541)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global541)
     )
    )
    (return_call $function159
     (struct.get $type123 1
      (ref.as_non_null
       (local.get $local5)
      )
     )
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
 )
 (func $function160 (type $call171) (param $environment eqref) (param $argument547 (ref $type121)) (param $argument548 i64) (result (ref $type163))
  (local $local0 (ref null $type18))
  (local $local5 (ref null $type18))
  (local $local43 (ref null $type18))
  (local $local50 (ref null $type18))
  (local $local54 (ref null $type18))
  (local $local1 (ref null $type121))
  (local $local24 (ref null $type121))
  (local $local29 (ref null $type121))
  (local $local36 (ref null $type121))
  (local $local44 (ref null $type121))
  (local $local3 (ref null $type160))
  (local $local4 (ref null $type172))
  (local $local10 (ref null $type150))
  (local $local15 (ref null $type150))
  (local $local20 (ref null $type150))
  (local $local23 (ref null $type150))
  (local $local28 (ref null $type150))
  (local $local35 (ref null $type150))
  (local $local42 (ref null $type150))
  (local $local49 (ref null $type150))
  (local $local53 (ref null $type150))
  (local $local57 (ref null $type150))
  (local $local60 (ref null $type150))
  (local $local64 (ref null $type150))
  (local $local25 (ref null $type162))
  (local $local32 (ref null $type173))
  (local $local39 (ref null $type173))
  (local $local46 (ref null $type151))
  (local $local2 i64)
  (local $local8 i64)
  (local $local13 i64)
  (local $local18 i64)
  (local $local21 i64)
  (local $local26 i64)
  (local $local33 i64)
  (local $local40 i64)
  (local $local47 i64)
  (local $local51 i64)
  (local $local55 i64)
  (local $local58 i64)
  (local $local61 i64)
  (local $local62 i64)
  (local $local6 i32)
  (local $local7 i32)
  (local $local9 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local14 i32)
  (local $local16 i32)
  (local $local17 i32)
  (local $local19 i32)
  (local $local22 i32)
  (local $local27 i32)
  (local $local30 i32)
  (local $local31 i32)
  (local $local34 i32)
  (local $local37 i32)
  (local $local38 i32)
  (local $local41 i32)
  (local $local45 i32)
  (local $local48 i32)
  (local $local52 i32)
  (local $local56 i32)
  (local $local59 i32)
  (local $local63 i32)
  (local.set $local62
   (local.get $argument548)
  )
  (local.set $local63
   (i32.const 40)
  )
  (local.set $local64
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result (ref $type163))
   (call $function158
    (struct.get $type150 1
     (ref.as_non_null
      (local.get $local64)
     )
    )
    (local.get $local62)
    (local.get $local63)
   )
   (then
    (local.set $local61
     (i64.const 0)
    )
    (struct.new $type168
     (i32.const 4)
     (local.get $local61)
    )
   )
   (else
    (local.set $local58
     (local.get $argument548)
    )
    (local.set $local59
     (i32.const 41)
    )
    (local.set $local60
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result (ref $type163))
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local60)
       )
      )
      (local.get $local58)
      (local.get $local59)
     )
     (then
      (global.get $empty166)
     )
     (else
      (local.set $local55
       (local.get $argument548)
      )
      (local.set $local56
       (i32.const 39)
      )
      (local.set $local57
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result (ref $type163))
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local57)
         )
        )
        (local.get $local55)
        (local.get $local56)
       )
       (then
        (local.set $local54
         (global.get $string8)
        )
        (struct.new $type169
         (i32.const 5)
         (ref.as_non_null
          (local.get $local54)
         )
        )
       )
       (else
        (local.set $local51
         (local.get $argument548)
        )
        (local.set $local52
         (i32.const 96)
        )
        (local.set $local53
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if (result (ref $type163))
         (call $function158
          (struct.get $type150 1
           (ref.as_non_null
            (local.get $local53)
           )
          )
          (local.get $local51)
          (local.get $local52)
         )
         (then
          (local.set $local50
           (global.get $string7)
          )
          (struct.new $type169
           (i32.const 5)
           (ref.as_non_null
            (local.get $local50)
           )
          )
         )
         (else
          (local.set $local47
           (local.get $argument548)
          )
          (local.set $local48
           (i32.const 44)
          )
          (local.set $local49
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (if (result (ref $type163))
           (call $function158
            (struct.get $type150 1
             (ref.as_non_null
              (local.get $local49)
             )
            )
            (local.get $local47)
            (local.get $local48)
           )
           (then
            (local.set $local44
             (ref.as_non_null
              (local.get $argument547)
             )
            )
            (local.set $local45
             (i32.const 64)
            )
            (local.set $local46
             (ref.as_non_null
              (global.get $global549)
             )
            )
            (local.set $local43
             (if (result (ref $type18))
              (call $function161
               (struct.get $type151 1
                (ref.as_non_null
                 (local.get $local46)
                )
               )
               (ref.as_non_null
                (local.get $local44)
               )
               (local.get $local45)
              )
              (then
               (global.get $string6)
              )
              (else
               (global.get $string5)
              )
             )
            )
            (struct.new $type169
             (i32.const 5)
             (ref.as_non_null
              (local.get $local43)
             )
            )
           )
           (else
            (local.set $local40
             (local.get $argument548)
            )
            (local.set $local41
             (i32.const 34)
            )
            (local.set $local42
             (ref.as_non_null
              (global.get $global538)
             )
            )
            (if (result (ref $type163))
             (call $function158
              (struct.get $type150 1
               (ref.as_non_null
                (local.get $local42)
               )
              )
              (local.get $local40)
              (local.get $local41)
             )
             (then
              (local.set $local36
               (ref.as_non_null
                (local.get $argument547)
               )
              )
              (local.set $local37
               (i32.const 34)
              )
              (local.set $local38
               (i32.const 0)
              )
              (if
               (i32.eqz
                (global.get $ready554)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local39
               (ref.as_non_null
                (global.get $global554)
               )
              )
              (return_call $function163
               (struct.get $type173 1
                (ref.as_non_null
                 (local.get $local39)
                )
               )
               (ref.as_non_null
                (local.get $local36)
               )
               (local.get $local37)
               (local.get $local38)
              )
             )
             (else
              (local.set $local33
               (local.get $argument548)
              )
              (local.set $local34
               (i32.const 124)
              )
              (local.set $local35
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (if (result (ref $type163))
               (call $function158
                (struct.get $type150 1
                 (ref.as_non_null
                  (local.get $local35)
                 )
                )
                (local.get $local33)
                (local.get $local34)
               )
               (then
                (local.set $local29
                 (ref.as_non_null
                  (local.get $argument547)
                 )
                )
                (local.set $local30
                 (i32.const 124)
                )
                (local.set $local31
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (global.get $ready554)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local32
                 (ref.as_non_null
                  (global.get $global554)
                 )
                )
                (return_call $function163
                 (struct.get $type173 1
                  (ref.as_non_null
                   (local.get $local32)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local29)
                 )
                 (local.get $local30)
                 (local.get $local31)
                )
               )
               (else
                (local.set $local26
                 (local.get $argument548)
                )
                (local.set $local27
                 (i32.const 35)
                )
                (local.set $local28
                 (ref.as_non_null
                  (global.get $global538)
                 )
                )
                (if (result (ref $type163))
                 (call $function158
                  (struct.get $type150 1
                   (ref.as_non_null
                    (local.get $local28)
                   )
                  )
                  (local.get $local26)
                  (local.get $local27)
                 )
                 (then
                  (local.set $local24
                   (ref.as_non_null
                    (local.get $argument547)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready627)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local25
                   (ref.as_non_null
                    (global.get $global627)
                   )
                  )
                  (return_call $function180
                   (struct.get $type162 1
                    (ref.as_non_null
                     (local.get $local25)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local24)
                   )
                  )
                 )
                 (else
                  (local.set $local8
                   (local.get $argument548)
                  )
                  (local.set $local9
                   (i32.const 91)
                  )
                  (local.set $local10
                   (ref.as_non_null
                    (global.get $global538)
                   )
                  )
                  (local.set $local7
                   (call $function158
                    (struct.get $type150 1
                     (ref.as_non_null
                      (local.get $local10)
                     )
                    )
                    (local.get $local8)
                    (local.get $local9)
                   )
                  )
                  (local.set $local6
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (local.get $local6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if (result (ref $type163))
                   (if (result i32)
                    (local.get $local7)
                    (then
                     (if
                      (i32.eqz
                       (local.get $local6)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.get $local7)
                    )
                    (else
                     (local.set $local13
                      (local.get $argument548)
                     )
                     (local.set $local14
                      (i32.const 93)
                     )
                     (local.set $local15
                      (ref.as_non_null
                       (global.get $global538)
                      )
                     )
                     (local.set $local12
                      (call $function158
                       (struct.get $type150 1
                        (ref.as_non_null
                         (local.get $local15)
                        )
                       )
                       (local.get $local13)
                       (local.get $local14)
                      )
                     )
                     (local.set $local11
                      (i32.const 1)
                     )
                     (if
                      (i32.eqz
                       (local.get $local11)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if (result i32)
                      (local.get $local12)
                      (then
                       (if
                        (i32.eqz
                         (local.get $local11)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.get $local12)
                      )
                      (else
                       (local.set $local18
                        (local.get $argument548)
                       )
                       (local.set $local19
                        (i32.const 123)
                       )
                       (local.set $local20
                        (ref.as_non_null
                         (global.get $global538)
                        )
                       )
                       (local.set $local17
                        (call $function158
                         (struct.get $type150 1
                          (ref.as_non_null
                           (local.get $local20)
                          )
                         )
                         (local.get $local18)
                         (local.get $local19)
                        )
                       )
                       (local.set $local16
                        (i32.const 1)
                       )
                       (if
                        (i32.eqz
                         (local.get $local16)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if (result i32)
                        (local.get $local17)
                        (then
                         (if
                          (i32.eqz
                           (local.get $local16)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.get $local17)
                        )
                        (else
                         (local.set $local21
                          (local.get $argument548)
                         )
                         (local.set $local22
                          (i32.const 125)
                         )
                         (local.set $local23
                          (ref.as_non_null
                           (global.get $global538)
                          )
                         )
                         (call $function158
                          (struct.get $type150 1
                           (ref.as_non_null
                            (local.get $local23)
                           )
                          )
                          (local.get $local21)
                          (local.get $local22)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (then
                    (local.set $local5
                     (global.get $string4)
                    )
                    (struct.new $type170
                     (i32.const 6)
                     (ref.as_non_null
                      (local.get $local5)
                     )
                    )
                   )
                   (else
                    (local.set $local1
                     (ref.as_non_null
                      (local.get $argument547)
                     )
                    )
                    (local.set $local2
                     (local.get $argument548)
                    )
                    (local.set $local3
                     (ref.as_non_null
                      (global.get $global658)
                     )
                    )
                    (local.set $local0
                     (call $function185
                      (struct.get $type160 1
                       (ref.as_non_null
                        (local.get $local3)
                       )
                      )
                      (ref.as_non_null
                       (local.get $local1)
                      )
                      (local.get $local2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready697)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local4
                     (ref.as_non_null
                      (global.get $global697)
                     )
                    )
                    (return_call $function195
                     (struct.get $type172 1
                      (ref.as_non_null
                       (local.get $local4)
                      )
                     )
                     (ref.as_non_null
                      (local.get $local0)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function161 (type $call151) (param $environment eqref) (param $argument550 (ref $type121)) (param $argument551 i32) (result i32)
  (local $local0 (ref null $type121))
  (local $local3 (ref null $type121))
  (local $local1 (ref null $type134))
  (local $local4 (ref null $type128))
  (local $local6 (ref null $type150))
  (local $local2 i64)
  (local $local5 i32)
  (local.set $local3
   (ref.as_non_null
    (local.get $argument550)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (local.set $local2
   (call $function162
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local5
   (local.get $argument551)
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result i32)
   (call $function158
    (struct.get $type150 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (local.get $local2)
    (local.get $local5)
   )
   (then
    (local.set $local0
     (ref.as_non_null
      (local.get $argument550)
     )
    )
    (local.set $local1
     (ref.as_non_null
      (global.get $global470)
     )
    )
    (drop
     (call $function138
      (struct.get $type134 1
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (ref.as_non_null
       (local.get $local0)
      )
     )
    )
    (i32.const 1)
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function162 (type $call128) (param $environment eqref) (param $argument553 (ref $type121)) (result i64)
  (local $local0 (ref null $type130))
  (local $local1 (ref null $type121))
  (local $local2 (ref null $type134))
  (local $local3 (ref null $type149))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument553)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global472)
   )
  )
  (local.set $local0
   (call $function139
    (struct.get $type134 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (return_call $function156
   (struct.get $type149 1
    (ref.as_non_null
     (local.get $local3)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function163 (type $call173) (param $environment eqref) (param $argument555 (ref $type121)) (param $argument556 i32) (param $argument557 i32) (result (ref $type163))
  (local $local0 i32)
  (local $local3 i32)
  (local $local5 i32)
  (local $local8 i32)
  (local $local1 (ref null $type175))
  (local $local2 (ref null $type121))
  (local $local4 (ref null $type174))
  (local $local6 (ref null $type18))
  (local $local7 (ref null $type18))
  (local $local9 (ref null $type18))
  (local $local11 (ref null $type18))
  (local $local13 (ref null $type18))
  (local $local10 (ref null $type13))
  (local $local12 (ref null $type22))
  (local $local14 (ref null $type84))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument555)
   )
  )
  (local.set $local3
   (local.get $argument556)
  )
  (if
   (i32.eqz
    (global.get $ready559)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global559)
   )
  )
  (local.set $local1
   (call $function164
    (struct.get $type174 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type163))
   (i32.eq
    (struct.get $type175 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (struct.get $type176 1
      (ref.cast (ref $type176)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local8
     (i32.const 1)
    )
    (local.set $local10
     (if (result (ref $type13))
      (local.get $argument557)
      (then
       (if
        (i32.eqz
         (local.get $local8)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local13
        (ref.as_non_null
         (local.get $local9)
        )
       )
       (local.set $local14
        (ref.as_non_null
         (global.get $global258)
        )
       )
       (local.set $local12
        (call $function84
         (struct.get $type84 1
          (ref.as_non_null
           (local.get $local14)
          )
         )
         (ref.as_non_null
          (local.get $local13)
         )
        )
       )
       (struct.new $type21
        (i32.const 4)
        (ref.as_non_null
         (local.get $local12)
        )
       )
      )
      (else
       (if
        (i32.eqz
         (local.get $local8)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local11
        (ref.as_non_null
         (local.get $local9)
        )
       )
       (struct.new $type17
        (i32.const 3)
        (ref.as_non_null
         (local.get $local11)
        )
       )
      )
     )
    )
    (struct.new $type164
     (i32.const 0)
     (ref.as_non_null
      (local.get $local10)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (struct.get $type177 1
      (ref.cast (ref $type177)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local5
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (struct.new $type170
     (i32.const 6)
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
 )
 (func $function164 (type $call174) (param $environment eqref) (param $argument560 (ref $type121)) (param $argument561 i32) (result (ref $type175))
  (local $local0 (ref null $type121))
  (local $local2 (ref null $type154))
  (local $local3 (ref null $type153))
  (local $local4 (ref null $type178))
  (local $local1 i32)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument560)
   )
  )
  (local.set $local1
   (local.get $argument561)
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global562)
   )
  )
  (local.set $local2
   (call $function165
    (struct.get $type153 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready563)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global563)
   )
  )
  (return_call $function166
   (struct.get $type178 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (ref.as_non_null
    (local.get $local2)
   )
  )
 )
 (func $function165 (type $call153) (param $environment eqref) (result (ref $type154))
  (local $local0 (ref null $type155))
  (local $local1 (ref null $type18))
  (local $local3 (ref null $type43))
  (local $local4 (ref null $type156))
  (local $local2 i64)
  (local $local5 i64)
  (local.set $local2
   (i64.const 32)
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type43 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (struct.new $type155
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local5
   (i64.const 0)
  )
  (local.set $local4
   (struct.new $type156
    (local.get $local5)
   )
  )
  (struct.new $type154
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local4)
   )
  )
 )
 (func $function166 (type $call178) (param $environment eqref) (param $argument564 (ref $type121)) (param $argument565 i32) (param $argument566 (ref $type154)) (result (ref $type175))
  (local $local0 i32)
  (local $local5 i32)
  (local $local9 i32)
  (local $local11 i32)
  (local $local16 i32)
  (local $local20 i32)
  (local $local24 i32)
  (local $local30 i32)
  (local $local1 i64)
  (local $local12 i64)
  (local $local23 i64)
  (local $local29 i64)
  (local $local33 i64)
  (local $local34 i64)
  (local $local2 (ref null $type121))
  (local $local4 (ref null $type121))
  (local $local10 (ref null $type121))
  (local $local15 (ref null $type121))
  (local $local19 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local6 (ref null $type154))
  (local $local8 (ref null $type154))
  (local $local17 (ref null $type154))
  (local $local27 (ref null $type154))
  (local $local7 (ref null $type178))
  (local $local13 (ref null $type179))
  (local $local14 (ref null $type157))
  (local $local18 (ref null $type181))
  (local $local21 (ref null $type185))
  (local $local22 (ref null $type180))
  (local $local25 (ref null $type150))
  (local $local31 (ref null $type150))
  (local $local26 (ref null $type18))
  (local $local32 (ref null $type18))
  (local $local28 (ref null $type159))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument564)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local33
   (local.get $local1)
  )
  (local.set $local34
   (i64.const 0)
  )
  (if (result (ref $type175))
   (i64.lt_s
    (local.get $local33)
    (local.get $local34)
   )
   (then
    (local.set $local32
     (global.get $string9)
    )
    (struct.new $type177
     (i32.const 1)
     (ref.as_non_null
      (local.get $local32)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local29
     (local.get $local1)
    )
    (local.set $local30
     (local.get $argument565)
    )
    (local.set $local31
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result (ref $type175))
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local31)
       )
      )
      (local.get $local29)
      (local.get $local30)
     )
     (then
      (local.set $local27
       (ref.as_non_null
        (local.get $argument566)
       )
      )
      (local.set $local28
       (ref.as_non_null
        (global.get $global568)
       )
      )
      (local.set $local26
       (call $function167
        (struct.get $type159 1
         (ref.as_non_null
          (local.get $local28)
         )
        )
        (ref.as_non_null
         (local.get $local27)
        )
       )
      )
      (struct.new $type176
       (i32.const 0)
       (ref.as_non_null
        (local.get $local26)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local23
       (local.get $local1)
      )
      (local.set $local24
       (i32.const 92)
      )
      (local.set $local25
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result (ref $type175))
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local25)
         )
        )
        (local.get $local23)
        (local.get $local24)
       )
       (then
        (local.set $local15
         (ref.as_non_null
          (local.get $argument564)
         )
        )
        (local.set $local16
         (local.get $argument565)
        )
        (local.set $local17
         (ref.as_non_null
          (local.get $argument566)
         )
        )
        (local.set $local19
         (ref.as_non_null
          (local.get $argument564)
         )
        )
        (local.set $local20
         (local.get $argument565)
        )
        (if
         (i32.eqz
          (global.get $ready570)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local21
         (ref.as_non_null
          (global.get $global570)
         )
        )
        (local.set $local18
         (call $function168
          (struct.get $type185 1
           (ref.as_non_null
            (local.get $local21)
           )
          )
          (ref.as_non_null
           (local.get $local19)
          )
          (local.get $local20)
         )
        )
        (if
         (i32.eqz
          (global.get $ready604)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local22
         (ref.as_non_null
          (global.get $global604)
         )
        )
        (return_call $function176
         (struct.get $type180 1
          (ref.as_non_null
           (local.get $local22)
          )
         )
         (ref.as_non_null
          (local.get $local15)
         )
         (local.get $local16)
         (ref.as_non_null
          (local.get $local17)
         )
         (ref.as_non_null
          (local.get $local18)
         )
        )
       )
       (else
        (local.set $local8
         (ref.as_non_null
          (local.get $argument566)
         )
        )
        (local.set $local10
         (ref.as_non_null
          (local.get $argument564)
         )
        )
        (local.set $local11
         (local.get $argument565)
        )
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local12
         (local.get $local1)
        )
        (if
         (i32.eqz
          (global.get $ready621)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local13
         (ref.as_non_null
          (global.get $global621)
         )
        )
        (local.set $local9
         (call $function179
          (struct.get $type179 1
           (ref.as_non_null
            (local.get $local13)
           )
          )
          (ref.as_non_null
           (local.get $local10)
          )
          (local.get $local11)
          (local.get $local12)
         )
        )
        (local.set $local14
         (ref.as_non_null
          (global.get $global611)
         )
        )
        (drop
         (call $function177
          (struct.get $type157 1
           (ref.as_non_null
            (local.get $local14)
           )
          )
          (ref.as_non_null
           (local.get $local8)
          )
          (local.get $local9)
         )
        )
        (local.set $local4
         (ref.as_non_null
          (local.get $argument564)
         )
        )
        (local.set $local5
         (local.get $argument565)
        )
        (local.set $local6
         (ref.as_non_null
          (local.get $argument566)
         )
        )
        (if
         (i32.eqz
          (global.get $ready563)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local7
         (ref.as_non_null
          (global.get $global563)
         )
        )
        (return_call $function166
         (struct.get $type178 1
          (ref.as_non_null
           (local.get $local7)
          )
         )
         (ref.as_non_null
          (local.get $local4)
         )
         (local.get $local5)
         (ref.as_non_null
          (local.get $local6)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function167 (type $call159) (param $environment eqref) (param $argument569 (ref $type154)) (result (ref $type18))
  (local $local0 (ref null $type18))
  (local $local1 (ref null $type155))
  (local $local2 (ref null $type154))
  (local $local6 (ref null $type154))
  (local $local5 (ref null $type156))
  (local $local7 (ref null $type47))
  (local $local3 i64)
  (local $local4 i64)
  (local.set $local2
   (ref.as_non_null
    (local.get $argument569)
   )
  )
  (local.set $local1
   (struct.get $type154 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (struct.get $type155 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $argument569)
   )
  )
  (local.set $local5
   (struct.get $type154 1
    (ref.as_non_null
     (local.get $local6)
    )
   )
  )
  (local.set $local4
   (struct.get $type156 0
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (return_call $function33
   (struct.get $type47 1
    (ref.as_non_null
     (local.get $local7)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local3)
   (local.get $local4)
  )
 )
 (func $function168 (type $call185) (param $environment eqref) (param $argument571 (ref $type121)) (param $argument572 i32) (result (ref $type181))
  (local $local0 i32)
  (local $local10 i32)
  (local $local11 i32)
  (local $local17 i32)
  (local $local19 i32)
  (local $local21 i32)
  (local $local22 i32)
  (local $local24 i32)
  (local $local26 i32)
  (local $local27 i32)
  (local $local29 i32)
  (local $local32 i32)
  (local $local34 i32)
  (local $local36 i32)
  (local $local38 i32)
  (local $local40 i32)
  (local $local42 i32)
  (local $local44 i32)
  (local $local46 i32)
  (local $local49 i32)
  (local $local51 i32)
  (local $local54 i32)
  (local $local1 i64)
  (local $local6 i64)
  (local $local8 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local20 i64)
  (local $local23 i64)
  (local $local28 i64)
  (local $local31 i64)
  (local $local35 i64)
  (local $local39 i64)
  (local $local43 i64)
  (local $local47 i64)
  (local $local48 i64)
  (local $local52 i64)
  (local $local53 i64)
  (local $local2 (ref null $type121))
  (local $local5 (ref null $type121))
  (local $local12 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local4 (ref null $type18))
  (local $local7 (ref null $type186))
  (local $local9 (ref null $type152))
  (local $local15 (ref null $type188))
  (local $local18 (ref null $type150))
  (local $local25 (ref null $type150))
  (local $local30 (ref null $type150))
  (local $local33 (ref null $type150))
  (local $local37 (ref null $type150))
  (local $local41 (ref null $type150))
  (local $local45 (ref null $type150))
  (local $local50 (ref null $type150))
  (local $local55 (ref null $type150))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument571)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local53
   (local.get $local1)
  )
  (local.set $local54
   (i32.const 97)
  )
  (local.set $local55
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result (ref $type181))
   (call $function158
    (struct.get $type150 1
     (ref.as_non_null
      (local.get $local55)
     )
    )
    (local.get $local53)
    (local.get $local54)
   )
   (then
    (local.set $local52
     (i64.const 7)
    )
    (if
     (i64.gt_u
      (local.get $local52)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local52)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local52)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local51
     (i32.wrap_i64
      (local.get $local52)
     )
    )
    (struct.new $type182
     (i32.const 0)
     (local.get $local51)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local48
     (local.get $local1)
    )
    (local.set $local49
     (i32.const 98)
    )
    (local.set $local50
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result (ref $type181))
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local50)
       )
      )
      (local.get $local48)
      (local.get $local49)
     )
     (then
      (local.set $local47
       (i64.const 8)
      )
      (if
       (i64.gt_u
        (local.get $local47)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.ge_u
         (local.get $local47)
         (i64.const 55296)
        )
        (i64.le_u
         (local.get $local47)
         (i64.const 57343)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $local46
       (i32.wrap_i64
        (local.get $local47)
       )
      )
      (struct.new $type182
       (i32.const 0)
       (local.get $local46)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local43
       (local.get $local1)
      )
      (local.set $local44
       (i32.const 116)
      )
      (local.set $local45
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result (ref $type181))
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local45)
         )
        )
        (local.get $local43)
        (local.get $local44)
       )
       (then
        (local.set $local42
         (i32.const 9)
        )
        (struct.new $type182
         (i32.const 0)
         (local.get $local42)
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local39
         (local.get $local1)
        )
        (local.set $local40
         (i32.const 110)
        )
        (local.set $local41
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if (result (ref $type181))
         (call $function158
          (struct.get $type150 1
           (ref.as_non_null
            (local.get $local41)
           )
          )
          (local.get $local39)
          (local.get $local40)
         )
         (then
          (local.set $local38
           (i32.const 10)
          )
          (struct.new $type182
           (i32.const 0)
           (local.get $local38)
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local35
           (local.get $local1)
          )
          (local.set $local36
           (i32.const 114)
          )
          (local.set $local37
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (if (result (ref $type181))
           (call $function158
            (struct.get $type150 1
             (ref.as_non_null
              (local.get $local37)
             )
            )
            (local.get $local35)
            (local.get $local36)
           )
           (then
            (local.set $local34
             (i32.const 13)
            )
            (struct.new $type182
             (i32.const 0)
             (local.get $local34)
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local23
             (local.get $local1)
            )
            (local.set $local24
             (i32.const 34)
            )
            (local.set $local25
             (ref.as_non_null
              (global.get $global538)
             )
            )
            (local.set $local22
             (call $function158
              (struct.get $type150 1
               (ref.as_non_null
                (local.get $local25)
               )
              )
              (local.get $local23)
              (local.get $local24)
             )
            )
            (local.set $local21
             (i32.const 1)
            )
            (if
             (i32.eqz
              (local.get $local21)
             )
             (then
              (unreachable)
             )
            )
            (if (result (ref $type181))
             (if (result i32)
              (local.get $local22)
              (then
               (if
                (i32.eqz
                 (local.get $local21)
                )
                (then
                 (unreachable)
                )
               )
               (local.get $local22)
              )
              (else
               (if
                (i32.eqz
                 (local.get $local0)
                )
                (then
                 (unreachable)
                )
               )
               (local.set $local28
                (local.get $local1)
               )
               (local.set $local29
                (i32.const 124)
               )
               (local.set $local30
                (ref.as_non_null
                 (global.get $global538)
                )
               )
               (local.set $local27
                (call $function158
                 (struct.get $type150 1
                  (ref.as_non_null
                   (local.get $local30)
                  )
                 )
                 (local.get $local28)
                 (local.get $local29)
                )
               )
               (local.set $local26
                (i32.const 1)
               )
               (if
                (i32.eqz
                 (local.get $local26)
                )
                (then
                 (unreachable)
                )
               )
               (if (result i32)
                (local.get $local27)
                (then
                 (if
                  (i32.eqz
                   (local.get $local26)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.get $local27)
                )
                (else
                 (if
                  (i32.eqz
                   (local.get $local0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $local31
                  (local.get $local1)
                 )
                 (local.set $local32
                  (i32.const 92)
                 )
                 (local.set $local33
                  (ref.as_non_null
                   (global.get $global538)
                  )
                 )
                 (call $function158
                  (struct.get $type150 1
                   (ref.as_non_null
                    (local.get $local33)
                   )
                  )
                  (local.get $local31)
                  (local.get $local32)
                 )
                )
               )
              )
             )
             (then
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local20
               (local.get $local1)
              )
              (if
               (i64.gt_u
                (local.get $local20)
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.ge_u
                 (local.get $local20)
                 (i64.const 55296)
                )
                (i64.le_u
                 (local.get $local20)
                 (i64.const 57343)
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $local19
               (i32.wrap_i64
                (local.get $local20)
               )
              )
              (struct.new $type182
               (i32.const 0)
               (local.get $local19)
              )
             )
             (else
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local16
               (local.get $local1)
              )
              (local.set $local17
               (i32.const 120)
              )
              (local.set $local18
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (if (result (ref $type181))
               (call $function158
                (struct.get $type150 1
                 (ref.as_non_null
                  (local.get $local18)
                 )
                )
                (local.get $local16)
                (local.get $local17)
               )
               (then
                (local.set $local12
                 (ref.as_non_null
                  (local.get $argument571)
                 )
                )
                (local.set $local13
                 (i64.const 0)
                )
                (local.set $local14
                 (i64.const 0)
                )
                (if
                 (i32.eqz
                  (global.get $ready576)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local15
                 (ref.as_non_null
                  (global.get $global576)
                 )
                )
                (return_call $function169
                 (struct.get $type188 1
                  (ref.as_non_null
                   (local.get $local15)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local12)
                 )
                 (local.get $local13)
                 (local.get $local14)
                )
               )
               (else
                (local.set $local10
                 (local.get $argument572)
                )
                (local.set $local11
                 (i32.const 34)
                )
                (if (result (ref $type181))
                 (if (result i32)
                  (i32.eq
                   (local.get $local10)
                   (local.get $local11)
                  )
                  (then
                   (if
                    (i32.eqz
                     (local.get $local0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $local8
                    (local.get $local1)
                   )
                   (if
                    (i32.eqz
                     (global.get $ready591)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $local9
                    (ref.as_non_null
                     (global.get $global591)
                    )
                   )
                   (call $function173
                    (struct.get $type152 1
                     (ref.as_non_null
                      (local.get $local9)
                     )
                    )
                    (local.get $local8)
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                 (then
                  (local.set $local5
                   (ref.as_non_null
                    (local.get $argument571)
                   )
                  )
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local6
                   (local.get $local1)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready596)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local7
                   (ref.as_non_null
                    (global.get $global596)
                   )
                  )
                  (return_call $function174
                   (struct.get $type186 1
                    (ref.as_non_null
                     (local.get $local7)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local5)
                   )
                   (local.get $local6)
                  )
                 )
                 (else
                  (local.set $local4
                   (global.get $string10)
                  )
                  (struct.new $type184
                   (i32.const 2)
                   (ref.as_non_null
                    (local.get $local4)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function169 (type $call188) (param $environment eqref) (param $argument577 (ref $type121)) (param $argument578 i64) (param $argument579 i64) (result (ref $type181))
  (local $local0 i32)
  (local $local4 i32)
  (local $local19 i32)
  (local $local20 i32)
  (local $local29 i32)
  (local $local1 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local28 i64)
  (local $local2 (ref null $type121))
  (local $local8 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local7 (ref null $type67))
  (local $local17 (ref null $type188))
  (local $local18 (ref null $type18))
  (local $local27 (ref null $type187))
  (local $local30 (ref null $type150))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument577)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local28
   (local.get $local1)
  )
  (local.set $local29
   (i32.const 59)
  )
  (local.set $local30
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result (ref $type181))
   (call $function158
    (struct.get $type150 1
     (ref.as_non_null
      (local.get $local30)
     )
    )
    (local.get $local28)
    (local.get $local29)
   )
   (then
    (local.set $local25
     (local.get $argument578)
    )
    (local.set $local26
     (local.get $argument579)
    )
    (local.set $local27
     (ref.as_non_null
      (global.get $global581)
     )
    )
    (return_call $function170
     (struct.get $type187 1
      (ref.as_non_null
       (local.get $local27)
      )
     )
     (local.get $local25)
     (local.get $local26)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (local.get $local1)
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global588)
     )
    )
    (local.set $local5
     (call $function172
      (struct.get $type67 1
       (ref.as_non_null
        (local.get $local7)
       )
      )
      (local.get $local6)
     )
    )
    (local.set $local4
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local21
     (local.get $local5)
    )
    (local.set $local22
     (i64.const 0)
    )
    (local.set $local20
     (i64.lt_s
      (local.get $local21)
      (local.get $local22)
     )
    )
    (local.set $local19
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local19)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (local.get $local20)
      (then
       (if
        (i32.eqz
         (local.get $local19)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local20)
      )
      (else
       (local.set $local23
        (local.get $argument578)
       )
       (local.set $local24
        (i64.const 69631)
       )
       (i64.gt_s
        (local.get $local23)
        (local.get $local24)
       )
      )
     )
     (then
      (local.set $local18
       (global.get $string11)
      )
      (struct.new $type184
       (i32.const 2)
       (ref.as_non_null
        (local.get $local18)
       )
      )
     )
     (else
      (local.set $local8
       (ref.as_non_null
        (local.get $argument577)
       )
      )
      (local.set $local11
       (local.get $argument578)
      )
      (local.set $local12
       (i64.const 16)
      )
      (local.set $local10
       (i64.mul
        (local.get $local11)
        (local.get $local12)
       )
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local13
       (local.get $local5)
      )
      (local.set $local9
       (i64.add
        (local.get $local10)
        (local.get $local13)
       )
      )
      (local.set $local15
       (local.get $argument579)
      )
      (local.set $local16
       (i64.const 1)
      )
      (local.set $local14
       (i64.add
        (local.get $local15)
        (local.get $local16)
       )
      )
      (if
       (i32.eqz
        (global.get $ready576)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local17
       (ref.as_non_null
        (global.get $global576)
       )
      )
      (return_call $function169
       (struct.get $type188 1
        (ref.as_non_null
         (local.get $local17)
        )
       )
       (ref.as_non_null
        (local.get $local8)
       )
       (local.get $local9)
       (local.get $local14)
      )
     )
    )
   )
  )
 )
 (func $function170 (type $call187) (param $environment eqref) (param $argument582 i64) (param $argument583 i64) (result (ref $type181))
  (local $local0 (ref null $type18))
  (local $local4 (ref null $type152))
  (local $local1 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local.set $local5
   (local.get $argument583)
  )
  (local.set $local6
   (i64.const 0)
  )
  (if (result (ref $type181))
   (if (result i32)
    (i64.gt_s
     (local.get $local5)
     (local.get $local6)
    )
    (then
     (local.set $local3
      (local.get $argument582)
     )
     (local.set $local4
      (ref.as_non_null
       (global.get $global584)
      )
     )
     (call $function171
      (struct.get $type152 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (local.get $local3)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $local2
     (local.get $argument582)
    )
    (if
     (i64.gt_u
      (local.get $local2)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local2)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local2)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local1
     (i32.wrap_i64
      (local.get $local2)
     )
    )
    (struct.new $type182
     (i32.const 0)
     (local.get $local1)
    )
   )
   (else
    (local.set $local0
     (global.get $string12)
    )
    (struct.new $type184
     (i32.const 2)
     (ref.as_non_null
      (local.get $local0)
     )
    )
   )
  )
 )
 (func $function171 (type $call152) (param $environment eqref) (param $argument585 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local.set $local8
   (local.get $argument585)
  )
  (local.set $local9
   (i64.const 0)
  )
  (if (result i32)
   (i64.ge_s
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (local.set $local6
     (local.get $argument585)
    )
    (local.set $local7
     (i64.const 1114111)
    )
    (if (result i32)
     (i64.le_s
      (local.get $local6)
      (local.get $local7)
     )
     (then
      (local.set $local2
       (local.get $argument585)
      )
      (local.set $local3
       (i64.const 55296)
      )
      (local.set $local1
       (i64.lt_s
        (local.get $local2)
        (local.get $local3)
       )
      )
      (local.set $local0
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (local.get $local1)
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.get $local1)
       )
       (else
        (local.set $local4
         (local.get $argument585)
        )
        (local.set $local5
         (i64.const 57343)
        )
        (i64.gt_s
         (local.get $local4)
         (local.get $local5)
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function172 (type $call67) (param $environment eqref) (param $argument589 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local.set $local16
   (local.get $argument589)
  )
  (local.set $local17
   (i64.const 48)
  )
  (if (result i64)
   (if (result i32)
    (i64.ge_s
     (local.get $local16)
     (local.get $local17)
    )
    (then
     (local.set $local14
      (local.get $argument589)
     )
     (local.set $local15
      (i64.const 57)
     )
     (i64.le_s
      (local.get $local14)
      (local.get $local15)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $local12
     (local.get $argument589)
    )
    (local.set $local13
     (i64.const 48)
    )
    (i64.sub
     (local.get $local12)
     (local.get $local13)
    )
   )
   (else
    (local.set $local10
     (local.get $argument589)
    )
    (local.set $local11
     (i64.const 65)
    )
    (if (result i64)
     (if (result i32)
      (i64.ge_s
       (local.get $local10)
       (local.get $local11)
      )
      (then
       (local.set $local8
        (local.get $argument589)
       )
       (local.set $local9
        (i64.const 70)
       )
       (i64.le_s
        (local.get $local8)
        (local.get $local9)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (local.set $local6
       (local.get $argument589)
      )
      (local.set $local7
       (i64.const 55)
      )
      (i64.sub
       (local.get $local6)
       (local.get $local7)
      )
     )
     (else
      (local.set $local4
       (local.get $argument589)
      )
      (local.set $local5
       (i64.const 97)
      )
      (if (result i64)
       (if (result i32)
        (i64.ge_s
         (local.get $local4)
         (local.get $local5)
        )
        (then
         (local.set $local2
          (local.get $argument589)
         )
         (local.set $local3
          (i64.const 102)
         )
         (i64.le_s
          (local.get $local2)
          (local.get $local3)
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (local.set $local0
         (local.get $argument589)
        )
        (local.set $local1
         (i64.const 87)
        )
        (i64.sub
         (local.get $local0)
         (local.get $local1)
        )
       )
       (else
        (i64.const -1)
       )
      )
     )
    )
   )
  )
 )
 (func $function173 (type $call152) (param $environment eqref) (param $argument592 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local3 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local10 i32)
  (local $local11 i32)
  (local $local13 i32)
  (local $local16 i32)
  (local $local2 i64)
  (local $local7 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local4 (ref null $type150))
  (local $local9 (ref null $type150))
  (local $local14 (ref null $type150))
  (local $local17 (ref null $type150))
  (local.set $local2
   (local.get $argument592)
  )
  (local.set $local3
   (i32.const 32)
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (local.set $local1
   (call $function158
    (struct.get $type150 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local7
     (local.get $argument592)
    )
    (local.set $local8
     (i32.const 9)
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (local.set $local6
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local5
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (local.get $local6)
     (then
      (if
       (i32.eqz
        (local.get $local5)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local6)
     )
     (else
      (local.set $local12
       (local.get $argument592)
      )
      (local.set $local13
       (i32.const 10)
      )
      (local.set $local14
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (local.set $local11
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local14)
         )
        )
        (local.get $local12)
        (local.get $local13)
       )
      )
      (local.set $local10
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local10)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (local.get $local11)
       (then
        (if
         (i32.eqz
          (local.get $local10)
         )
         (then
          (unreachable)
         )
        )
        (local.get $local11)
       )
       (else
        (local.set $local15
         (local.get $argument592)
        )
        (local.set $local16
         (i32.const 13)
        )
        (local.set $local17
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (return_call $function158
         (struct.get $type150 1
          (ref.as_non_null
           (local.get $local17)
          )
         )
         (local.get $local15)
         (local.get $local16)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function174 (type $call186) (param $environment eqref) (param $argument597 (ref $type121)) (param $argument598 i64) (result (ref $type181))
  (local $local0 (ref null $type18))
  (local $local1 (ref null $type121))
  (local $local3 (ref null $type121))
  (local $local17 (ref null $type121))
  (local $local19 (ref null $type121))
  (local $local2 (ref null $type123))
  (local $local5 (ref null $type151))
  (local $local8 (ref null $type150))
  (local $local13 (ref null $type150))
  (local $local16 (ref null $type150))
  (local $local26 (ref null $type150))
  (local $local29 (ref null $type150))
  (local $local20 (ref null $type128))
  (local $local21 (ref null $type186))
  (local $local4 i32)
  (local $local7 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local22 i32)
  (local $local23 i32)
  (local $local25 i32)
  (local $local28 i32)
  (local $local6 i64)
  (local $local11 i64)
  (local $local14 i64)
  (local $local18 i64)
  (local $local24 i64)
  (local $local27 i64)
  (local.set $local24
   (local.get $argument598)
  )
  (local.set $local25
   (i32.const 32)
  )
  (local.set $local26
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (local.set $local23
   (call $function158
    (struct.get $type150 1
     (ref.as_non_null
      (local.get $local26)
     )
    )
    (local.get $local24)
    (local.get $local25)
   )
  )
  (local.set $local22
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local22)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type181))
   (if (result i32)
    (local.get $local23)
    (then
     (if
      (i32.eqz
       (local.get $local22)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local23)
    )
    (else
     (local.set $local27
      (local.get $argument598)
     )
     (local.set $local28
      (i32.const 9)
     )
     (local.set $local29
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local29)
       )
      )
      (local.get $local27)
      (local.get $local28)
     )
    )
   )
   (then
    (local.set $local17
     (ref.as_non_null
      (local.get $argument597)
     )
    )
    (local.set $local19
     (ref.as_non_null
      (local.get $argument597)
     )
    )
    (local.set $local20
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (local.set $local18
     (call $function155
      (struct.get $type128 1
       (ref.as_non_null
        (local.get $local20)
       )
      )
      (ref.as_non_null
       (local.get $local19)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready596)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local21
     (ref.as_non_null
      (global.get $global596)
     )
    )
    (return_call $function174
     (struct.get $type186 1
      (ref.as_non_null
       (local.get $local21)
      )
     )
     (ref.as_non_null
      (local.get $local17)
     )
     (local.get $local18)
    )
   )
   (else
    (local.set $local11
     (local.get $argument598)
    )
    (local.set $local12
     (i32.const 10)
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (local.set $local10
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (local.get $local11)
      (local.get $local12)
     )
    )
    (local.set $local9
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local9)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (local.get $local10)
      (then
       (if
        (i32.eqz
         (local.get $local9)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local10)
      )
      (else
       (local.set $local14
        (local.get $argument598)
       )
       (local.set $local15
        (i32.const 13)
       )
       (local.set $local16
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local16)
         )
        )
        (local.get $local14)
        (local.get $local15)
       )
      )
     )
     (then
      (local.set $local6
       (local.get $argument598)
      )
      (local.set $local7
       (i32.const 13)
      )
      (local.set $local8
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (drop
       (if (result i32)
        (call $function158
         (struct.get $type150 1
          (ref.as_non_null
           (local.get $local8)
          )
         )
         (local.get $local6)
         (local.get $local7)
        )
        (then
         (local.set $local3
          (ref.as_non_null
           (local.get $argument597)
          )
         )
         (local.set $local4
          (i32.const 10)
         )
         (local.set $local5
          (ref.as_non_null
           (global.get $global549)
          )
         )
         (drop
          (call $function161
           (struct.get $type151 1
            (ref.as_non_null
             (local.get $local5)
            )
           )
           (ref.as_non_null
            (local.get $local3)
           )
           (local.get $local4)
          )
         )
         (drop
          (i32.const 0)
         )
         (i32.const 0)
        )
        (else
         (i32.const 0)
        )
       )
      )
      (local.set $local1
       (ref.as_non_null
        (local.get $argument597)
       )
      )
      (local.set $local2
       (ref.as_non_null
        (global.get $global601)
       )
      )
      (drop
       (call $function175
        (struct.get $type123 1
         (ref.as_non_null
          (local.get $local2)
         )
        )
        (ref.as_non_null
         (local.get $local1)
        )
       )
      )
      (global.get $empty183)
     )
     (else
      (local.set $local0
       (global.get $string13)
      )
      (struct.new $type184
       (i32.const 2)
       (ref.as_non_null
        (local.get $local0)
       )
      )
     )
    )
   )
  )
 )
 (func $function175 (type $call123) (param $environment eqref) (param $argument602 (ref $type121)) (result i32)
  (local $local0 (ref null $type121))
  (local $local2 (ref null $type121))
  (local $local7 (ref null $type121))
  (local $local12 (ref null $type121))
  (local $local1 (ref null $type123))
  (local $local3 (ref null $type134))
  (local $local8 (ref null $type128))
  (local $local13 (ref null $type128))
  (local $local10 (ref null $type150))
  (local $local15 (ref null $type150))
  (local $local4 i32)
  (local $local5 i32)
  (local $local9 i32)
  (local $local14 i32)
  (local $local6 i64)
  (local $local11 i64)
  (local.set $local7
   (ref.as_non_null
    (local.get $argument602)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (local.set $local6
   (call $function162
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (ref.as_non_null
     (local.get $local7)
    )
   )
  )
  (local.set $local9
   (i32.const 32)
  )
  (local.set $local10
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (local.set $local5
   (call $function158
    (struct.get $type150 1
     (ref.as_non_null
      (local.get $local10)
     )
    )
    (local.get $local6)
    (local.get $local9)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.get $local5)
    (then
     (if
      (i32.eqz
       (local.get $local4)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local5)
    )
    (else
     (local.set $local12
      (ref.as_non_null
       (local.get $argument602)
      )
     )
     (local.set $local13
      (ref.as_non_null
       (global.get $global552)
      )
     )
     (local.set $local11
      (call $function162
       (struct.get $type128 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
       (ref.as_non_null
        (local.get $local12)
       )
      )
     )
     (local.set $local14
      (i32.const 9)
     )
     (local.set $local15
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local15)
       )
      )
      (local.get $local11)
      (local.get $local14)
     )
    )
   )
   (then
    (local.set $local2
     (ref.as_non_null
      (local.get $argument602)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (global.get $global470)
     )
    )
    (drop
     (call $function138
      (struct.get $type134 1
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (ref.as_non_null
      (local.get $argument602)
     )
    )
    (if
     (i32.eqz
      (global.get $ready601)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local1
     (ref.as_non_null
      (global.get $global601)
     )
    )
    (return_call $function175
     (struct.get $type123 1
      (ref.as_non_null
       (local.get $local1)
      )
     )
     (ref.as_non_null
      (local.get $local0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function176 (type $call180) (param $environment eqref) (param $argument605 (ref $type121)) (param $argument606 i32) (param $argument607 (ref $type154)) (param $argument608 (ref $type181)) (result (ref $type175))
  (local $local0 i32)
  (local $local2 i32)
  (local $local6 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local12 i32)
  (local $local16 i32)
  (local $local1 (ref null $type181))
  (local $local3 (ref null $type18))
  (local $local4 (ref null $type18))
  (local $local5 (ref null $type121))
  (local $local11 (ref null $type121))
  (local $local7 (ref null $type154))
  (local $local13 (ref null $type154))
  (local $local15 (ref null $type154))
  (local $local8 (ref null $type178))
  (local $local14 (ref null $type178))
  (local $local17 (ref null $type157))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument608)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type175))
   (i32.eq
    (struct.get $type181 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (struct.get $type182 1
      (ref.cast (ref $type182)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local9
     (i32.const 1)
    )
    (local.set $local15
     (ref.as_non_null
      (local.get $argument607)
     )
    )
    (if
     (i32.eqz
      (local.get $local9)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local10)
    )
    (local.set $local17
     (ref.as_non_null
      (global.get $global611)
     )
    )
    (drop
     (call $function177
      (struct.get $type157 1
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (ref.as_non_null
       (local.get $local15)
      )
      (local.get $local16)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $argument605)
     )
    )
    (local.set $local12
     (local.get $argument606)
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $argument607)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global563)
     )
    )
    (return_call $function166
     (struct.get $type178 1
      (ref.as_non_null
       (local.get $local14)
      )
     )
     (ref.as_non_null
      (local.get $local11)
     )
     (local.get $local12)
     (ref.as_non_null
      (local.get $local13)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type175))
     (i32.eq
      (struct.get $type181 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (local.set $local5
       (ref.as_non_null
        (local.get $argument605)
       )
      )
      (local.set $local6
       (local.get $argument606)
      )
      (local.set $local7
       (ref.as_non_null
        (local.get $argument607)
       )
      )
      (local.set $local8
       (ref.as_non_null
        (global.get $global563)
       )
      )
      (return_call $function166
       (struct.get $type178 1
        (ref.as_non_null
         (local.get $local8)
        )
       )
       (ref.as_non_null
        (local.get $local5)
       )
       (local.get $local6)
       (ref.as_non_null
        (local.get $local7)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local3
       (struct.get $type184 1
        (ref.cast (ref $type184)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local2
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local4
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (struct.new $type177
       (i32.const 1)
       (ref.as_non_null
        (local.get $local4)
       )
      )
     )
    )
   )
  )
 )
 (func $function177 (type $call157) (param $environment eqref) (param $argument612 (ref $type154)) (param $argument613 i32) (result i32)
  (local $local0 i32)
  (local $local13 i32)
  (local $local14 i32)
  (local $local1 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local12 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local2 (ref null $type156))
  (local $local4 (ref null $type156))
  (local $local3 (ref null $type154))
  (local $local5 (ref null $type154))
  (local $local11 (ref null $type154))
  (local $local15 (ref null $type154))
  (local $local22 (ref null $type154))
  (local $local9 (ref null $type18))
  (local $local20 (ref null $type18))
  (local $local10 (ref null $type155))
  (local $local21 (ref null $type155))
  (local $local17 (ref null $type158))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument612)
   )
  )
  (local.set $local2
   (struct.get $type154 1
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local1
   (struct.get $type156 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local18
   (local.get $local1)
  )
  (local.set $local22
   (ref.as_non_null
    (local.get $argument612)
   )
  )
  (local.set $local21
   (struct.get $type154 0
    (ref.as_non_null
     (local.get $local22)
    )
   )
  )
  (local.set $local20
   (struct.get $type155 0
    (ref.as_non_null
     (local.get $local21)
    )
   )
  )
  (local.set $local19
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local20)
     )
    )
   )
  )
  (drop
   (if (result i32)
    (i64.eq
     (local.get $local18)
     (local.get $local19)
    )
    (then
     (local.set $local15
      (ref.as_non_null
       (local.get $argument612)
      )
     )
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local16
      (local.get $local1)
     )
     (if
      (i32.eqz
       (global.get $ready615)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local17
      (ref.as_non_null
       (global.get $global615)
      )
     )
     (drop
      (call $function178
       (struct.get $type158 1
        (ref.as_non_null
         (local.get $local17)
        )
       )
       (ref.as_non_null
        (local.get $local15)
       )
       (local.get $local16)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 0)
    )
   )
  )
  (local.set $local11
   (ref.as_non_null
    (local.get $argument612)
   )
  )
  (local.set $local10
   (struct.get $type154 0
    (ref.as_non_null
     (local.get $local11)
    )
   )
  )
  (local.set $local9
   (struct.get $type155 0
    (ref.as_non_null
     (local.get $local10)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (local.get $local1)
  )
  (local.set $local13
   (local.get $argument613)
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $local12)
    (i64.extend_i32_u
     (struct.get $type18 1
      (ref.as_non_null
       (local.get $local9)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (i32.wrap_i64
    (local.get $local12)
   )
  )
  (array.set $type19
   (call $string-block
    (ref.as_non_null
     (local.get $local9)
    )
    (local.get $local14)
   )
   (i32.and
    (local.get $local14)
    (i32.const 8191)
   )
   (local.get $local13)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument612)
   )
  )
  (local.set $local4
   (struct.get $type154 1
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (local.get $local1)
  )
  (local.set $local8
   (i64.const 1)
  )
  (local.set $local6
   (i64.add
    (local.get $local7)
    (local.get $local8)
   )
  )
  (struct.set $type156 0
   (ref.as_non_null
    (local.get $local4)
   )
   (local.get $local6)
  )
  (i32.const 0)
 )
 (func $function178 (type $call158) (param $environment eqref) (param $argument616 (ref $type154)) (param $argument617 i64) (result i32)
  (local $local0 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local8 i64)
  (local $local14 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local7 (ref null $type18))
  (local $local12 (ref null $type18))
  (local $local13 (ref null $type18))
  (local $local15 (ref null $type18))
  (local $local20 (ref null $type18))
  (local $local9 (ref null $type43))
  (local $local10 (ref null $type155))
  (local $local16 (ref null $type155))
  (local $local11 (ref null $type154))
  (local $local17 (ref null $type154))
  (local $local21 (ref null $type82))
  (local.set $local22
   (local.get $argument617)
  )
  (local.set $local23
   (i64.const 4294967294)
  )
  (if (result i32)
   (i64.ge_s
    (local.get $local22)
    (local.get $local23)
   )
   (then
    (local.set $local20
     (global.get $string14)
    )
    (local.set $local21
     (ref.as_non_null
      (global.get $global252)
     )
    )
    (call $function82
     (struct.get $type82 1
      (ref.as_non_null
       (local.get $local21)
      )
     )
     (ref.as_non_null
      (local.get $local20)
     )
    )
    (unreachable)
   )
   (else
    (local.set $local4
     (local.get $argument617)
    )
    (local.set $local5
     (i64.const 2147483647)
    )
    (local.set $local1
     (if (result i64)
      (i64.gt_s
       (local.get $local4)
       (local.get $local5)
      )
      (then
       (i64.const 4294967294)
      )
      (else
       (local.set $local2
        (local.get $argument617)
       )
       (local.set $local3
        (i64.const 2)
       )
       (i64.mul
        (local.get $local2)
        (local.get $local3)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local7
     (call $function25
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.get $local8)
     )
    )
    (local.set $local6
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.set $local14
     (i64.const 0)
    )
    (local.set $local17
     (ref.as_non_null
      (local.get $argument616)
     )
    )
    (local.set $local16
     (struct.get $type154 0
      (ref.as_non_null
       (local.get $local17)
      )
     )
    )
    (local.set $local15
     (struct.get $type155 0
      (ref.as_non_null
       (local.get $local16)
      )
     )
    )
    (local.set $local18
     (i64.const 0)
    )
    (local.set $local19
     (local.get $argument617)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local13)
      )
      (local.get $local14)
      (ref.as_non_null
       (local.get $local15)
      )
      (local.get $local18)
      (local.get $local19)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $argument616)
     )
    )
    (local.set $local10
     (struct.get $type154 0
      (ref.as_non_null
       (local.get $local11)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (struct.set $type155 0
     (ref.as_non_null
      (local.get $local10)
     )
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function179 (type $call179) (param $environment eqref) (param $argument622 (ref $type121)) (param $argument623 i32) (param $argument624 i64) (result i32)
  (local $local0 i64)
  (local $local4 i64)
  (local $local2 i32)
  (local $local5 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local1 (ref null $type121))
  (local $local3 (ref null $type151))
  (local $local6 (ref null $type150))
  (local.set $local7
   (local.get $argument623)
  )
  (local.set $local8
   (i32.const 34)
  )
  (if (result i32)
   (if (result i32)
    (i32.eq
     (local.get $local7)
     (local.get $local8)
    )
    (then
     (local.set $local4
      (local.get $argument624)
     )
     (local.set $local5
      (i32.const 13)
     )
     (local.set $local6
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (local.get $local4)
      (local.get $local5)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $local1
     (ref.as_non_null
      (local.get $argument622)
     )
    )
    (local.set $local2
     (i32.const 10)
    )
    (local.set $local3
     (ref.as_non_null
      (global.get $global549)
     )
    )
    (drop
     (call $function161
      (struct.get $type151 1
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
      (local.get $local2)
     )
    )
    (i32.const 10)
   )
   (else
    (local.set $local0
     (local.get $argument624)
    )
    (if
     (i64.gt_u
      (local.get $local0)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local0)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local0)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local0)
    )
   )
  )
 )
 (func $function180 (type $call162) (param $environment eqref) (param $argument628 (ref $type121)) (result (ref $type163))
  (local $local0 i32)
  (local $local19 i32)
  (local $local23 i32)
  (local $local24 i32)
  (local $local26 i32)
  (local $local29 i32)
  (local $local34 i32)
  (local $local43 i32)
  (local $local48 i32)
  (local $local52 i32)
  (local $local1 i64)
  (local $local8 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local25 i64)
  (local $local28 i64)
  (local $local33 i64)
  (local $local40 i64)
  (local $local42 i64)
  (local $local47 i64)
  (local $local50 i64)
  (local $local51 i64)
  (local $local55 i64)
  (local $local56 i64)
  (local $local2 (ref null $type121))
  (local $local7 (ref null $type121))
  (local $local21 (ref null $type121))
  (local $local31 (ref null $type121))
  (local $local37 (ref null $type121))
  (local $local39 (ref null $type121))
  (local $local45 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local4 (ref null $type18))
  (local $local5 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local12 (ref null $type18))
  (local $local17 (ref null $type18))
  (local $local36 (ref null $type18))
  (local $local54 (ref null $type18))
  (local $local9 (ref null $type160))
  (local $local10 (ref null $type49))
  (local $local11 (ref null $type172))
  (local $local20 (ref null $type150))
  (local $local27 (ref null $type150))
  (local $local30 (ref null $type150))
  (local $local35 (ref null $type150))
  (local $local44 (ref null $type150))
  (local $local49 (ref null $type150))
  (local $local53 (ref null $type150))
  (local $local22 (ref null $type162))
  (local $local32 (ref null $type162))
  (local $local38 (ref null $type162))
  (local $local46 (ref null $type162))
  (local $local41 (ref null $type161))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument628)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local55
   (local.get $local1)
  )
  (local.set $local56
   (i64.const 0)
  )
  (if (result (ref $type163))
   (i64.lt_s
    (local.get $local55)
    (local.get $local56)
   )
   (then
    (local.set $local54
     (global.get $string19)
    )
    (struct.new $type170
     (i32.const 6)
     (ref.as_non_null
      (local.get $local54)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local51
     (local.get $local1)
    )
    (local.set $local52
     (i32.const 40)
    )
    (local.set $local53
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result (ref $type163))
     (call $function158
      (struct.get $type150 1
       (ref.as_non_null
        (local.get $local53)
       )
      )
      (local.get $local51)
      (local.get $local52)
     )
     (then
      (local.set $local50
       (i64.const 1)
      )
      (struct.new $type168
       (i32.const 4)
       (local.get $local50)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local47
       (local.get $local1)
      )
      (local.set $local48
       (i32.const 59)
      )
      (local.set $local49
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result (ref $type163))
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local49)
         )
        )
        (local.get $local47)
        (local.get $local48)
       )
       (then
        (local.set $local45
         (ref.as_non_null
          (local.get $argument628)
         )
        )
        (local.set $local46
         (ref.as_non_null
          (global.get $global630)
         )
        )
        (return_call $function181
         (struct.get $type162 1
          (ref.as_non_null
           (local.get $local46)
          )
         )
         (ref.as_non_null
          (local.get $local45)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local42
         (local.get $local1)
        )
        (local.set $local43
         (i32.const 124)
        )
        (local.set $local44
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if (result (ref $type163))
         (call $function158
          (struct.get $type150 1
           (ref.as_non_null
            (local.get $local44)
           )
          )
          (local.get $local42)
          (local.get $local43)
         )
         (then
          (local.set $local39
           (ref.as_non_null
            (local.get $argument628)
           )
          )
          (local.set $local40
           (i64.const 1)
          )
          (local.set $local41
           (ref.as_non_null
            (global.get $global635)
           )
          )
          (if (result (ref $type163))
           (call $function182
            (struct.get $type161 1
             (ref.as_non_null
              (local.get $local41)
             )
            )
            (ref.as_non_null
             (local.get $local39)
            )
            (local.get $local40)
           )
           (then
            (local.set $local37
             (ref.as_non_null
              (local.get $argument628)
             )
            )
            (local.set $local38
             (ref.as_non_null
              (global.get $global527)
             )
            )
            (return_call $function154
             (struct.get $type162 1
              (ref.as_non_null
               (local.get $local38)
              )
             )
             (ref.as_non_null
              (local.get $local37)
             )
            )
           )
           (else
            (local.set $local36
             (global.get $string18)
            )
            (struct.new $type170
             (i32.const 6)
             (ref.as_non_null
              (local.get $local36)
             )
            )
           )
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local33
           (local.get $local1)
          )
          (local.set $local34
           (i32.const 92)
          )
          (local.set $local35
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (if (result (ref $type163))
           (call $function158
            (struct.get $type150 1
             (ref.as_non_null
              (local.get $local35)
             )
            )
            (local.get $local33)
            (local.get $local34)
           )
           (then
            (local.set $local31
             (ref.as_non_null
              (local.get $argument628)
             )
            )
            (if
             (i32.eqz
              (global.get $ready640)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local32
             (ref.as_non_null
              (global.get $global640)
             )
            )
            (return_call $function183
             (struct.get $type162 1
              (ref.as_non_null
               (local.get $local32)
              )
             )
             (ref.as_non_null
              (local.get $local31)
             )
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local25
             (local.get $local1)
            )
            (local.set $local26
             (i32.const 117)
            )
            (local.set $local27
             (ref.as_non_null
              (global.get $global538)
             )
            )
            (local.set $local24
             (call $function158
              (struct.get $type150 1
               (ref.as_non_null
                (local.get $local27)
               )
              )
              (local.get $local25)
              (local.get $local26)
             )
            )
            (local.set $local23
             (i32.const 1)
            )
            (if
             (i32.eqz
              (local.get $local23)
             )
             (then
              (unreachable)
             )
            )
            (if (result (ref $type163))
             (if (result i32)
              (local.get $local24)
              (then
               (if
                (i32.eqz
                 (local.get $local23)
                )
                (then
                 (unreachable)
                )
               )
               (local.get $local24)
              )
              (else
               (if
                (i32.eqz
                 (local.get $local0)
                )
                (then
                 (unreachable)
                )
               )
               (local.set $local28
                (local.get $local1)
               )
               (local.set $local29
                (i32.const 85)
               )
               (local.set $local30
                (ref.as_non_null
                 (global.get $global538)
                )
               )
               (call $function158
                (struct.get $type150 1
                 (ref.as_non_null
                  (local.get $local30)
                 )
                )
                (local.get $local28)
                (local.get $local29)
               )
              )
             )
             (then
              (local.set $local21
               (ref.as_non_null
                (local.get $argument628)
               )
              )
              (if
               (i32.eqz
                (global.get $ready684)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local22
               (ref.as_non_null
                (global.get $global684)
               )
              )
              (return_call $function193
               (struct.get $type162 1
                (ref.as_non_null
                 (local.get $local22)
                )
               )
               (ref.as_non_null
                (local.get $local21)
               )
              )
             )
             (else
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local18
               (local.get $local1)
              )
              (local.set $local19
               (i32.const 33)
              )
              (local.set $local20
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (if (result (ref $type163))
               (call $function158
                (struct.get $type150 1
                 (ref.as_non_null
                  (local.get $local20)
                 )
                )
                (local.get $local18)
                (local.get $local19)
               )
               (then
                (local.set $local17
                 (global.get $string17)
                )
                (struct.new $type170
                 (i32.const 6)
                 (ref.as_non_null
                  (local.get $local17)
                 )
                )
               )
               (else
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local15
                 (local.get $local1)
                )
                (local.set $local16
                 (i64.const 48)
                )
                (if (result (ref $type163))
                 (if (result i32)
                  (i64.ge_s
                   (local.get $local15)
                   (local.get $local16)
                  )
                  (then
                   (if
                    (i32.eqz
                     (local.get $local0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $local13
                    (local.get $local1)
                   )
                   (local.set $local14
                    (i64.const 57)
                   )
                   (i64.le_s
                    (local.get $local13)
                    (local.get $local14)
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                 (then
                  (local.set $local12
                   (global.get $string16)
                  )
                  (struct.new $type170
                   (i32.const 6)
                   (ref.as_non_null
                    (local.get $local12)
                   )
                  )
                 )
                 (else
                  (local.set $local5
                   (global.get $string15)
                  )
                  (local.set $local7
                   (ref.as_non_null
                    (local.get $argument628)
                   )
                  )
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local8
                   (local.get $local1)
                  )
                  (local.set $local9
                   (ref.as_non_null
                    (global.get $global658)
                   )
                  )
                  (local.set $local6
                   (call $function185
                    (struct.get $type160 1
                     (ref.as_non_null
                      (local.get $local9)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local7)
                    )
                    (local.get $local8)
                   )
                  )
                  (local.set $local10
                   (ref.as_non_null
                    (global.get $global90)
                   )
                  )
                  (local.set $local4
                   (call $function35
                    (struct.get $type49 1
                     (ref.as_non_null
                      (local.get $local10)
                     )
                    )
                    (struct.new $type50
                     (ref.as_non_null
                      (local.get $local5)
                     )
                     (struct.new $type50
                      (ref.as_non_null
                       (local.get $local6)
                      )
                      (ref.null none)
                     )
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready686)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local11
                   (ref.as_non_null
                    (global.get $global686)
                   )
                  )
                  (return_call $function194
                   (struct.get $type172 1
                    (ref.as_non_null
                     (local.get $local11)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local4)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function181 (type $call162) (param $environment eqref) (param $argument631 (ref $type121)) (result (ref $type163))
  (local $local0 i32)
  (local $local4 i32)
  (local $local8 i32)
  (local $local1 (ref null $type101))
  (local $local2 (ref null $type121))
  (local $local10 (ref null $type121))
  (local $local3 (ref null $type148))
  (local $local5 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local7 (ref null $type18))
  (local $local9 (ref null $type13))
  (local $local11 (ref null $type162))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument631)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local1
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type163))
   (i32.eq
    (struct.get $type101 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (struct.get $type103 1
      (ref.cast (ref $type103)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local8
     (i32.const 1)
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $argument631)
     )
    )
    (if
     (i32.eqz
      (global.get $ready527)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (global.get $global527)
     )
    )
    (return_call $function154
     (struct.get $type162 1
      (ref.as_non_null
       (local.get $local11)
      )
     )
     (ref.as_non_null
      (local.get $local10)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type163))
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (local.set $local7
       (global.get $string20)
      )
      (struct.new $type170
       (i32.const 6)
       (ref.as_non_null
        (local.get $local7)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type104 1
        (ref.cast (ref $type104)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (struct.new $type170
       (i32.const 6)
       (ref.as_non_null
        (local.get $local6)
       )
      )
     )
    )
   )
  )
 )
 (func $function182 (type $call161) (param $environment eqref) (param $argument636 (ref $type121)) (param $argument637 i64) (result i32)
  (local $local0 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local17 i32)
  (local $local20 i32)
  (local $local28 i32)
  (local $local31 i32)
  (local $local1 i64)
  (local $local5 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local19 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local30 i64)
  (local $local33 i64)
  (local $local34 i64)
  (local $local2 (ref null $type121))
  (local $local4 (ref null $type121))
  (local $local11 (ref null $type121))
  (local $local16 (ref null $type121))
  (local $local22 (ref null $type121))
  (local $local27 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local6 (ref null $type161))
  (local $local15 (ref null $type161))
  (local $local26 (ref null $type161))
  (local $local18 (ref null $type151))
  (local $local29 (ref null $type151))
  (local $local21 (ref null $type150))
  (local $local32 (ref null $type150))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument636)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local33
   (local.get $local1)
  )
  (local.set $local34
   (i64.const 0)
  )
  (if (result i32)
   (i64.lt_s
    (local.get $local33)
    (local.get $local34)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local30
     (local.get $local1)
    )
    (local.set $local31
     (i32.const 35)
    )
    (local.set $local32
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result i32)
     (if (result i32)
      (call $function158
       (struct.get $type150 1
        (ref.as_non_null
         (local.get $local32)
        )
       )
       (local.get $local30)
       (local.get $local31)
      )
      (then
       (local.set $local27
        (ref.as_non_null
         (local.get $argument636)
        )
       )
       (local.set $local28
        (i32.const 124)
       )
       (local.set $local29
        (ref.as_non_null
         (global.get $global549)
        )
       )
       (call $function161
        (struct.get $type151 1
         (ref.as_non_null
          (local.get $local29)
         )
        )
        (ref.as_non_null
         (local.get $local27)
        )
        (local.get $local28)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (local.set $local22
       (ref.as_non_null
        (local.get $argument636)
       )
      )
      (local.set $local24
       (local.get $argument637)
      )
      (local.set $local25
       (i64.const 1)
      )
      (local.set $local23
       (i64.add
        (local.get $local24)
        (local.get $local25)
       )
      )
      (if
       (i32.eqz
        (global.get $ready635)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local26
       (ref.as_non_null
        (global.get $global635)
       )
      )
      (return_call $function182
       (struct.get $type161 1
        (ref.as_non_null
         (local.get $local26)
        )
       )
       (ref.as_non_null
        (local.get $local22)
       )
       (local.get $local23)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local19
       (local.get $local1)
      )
      (local.set $local20
       (i32.const 124)
      )
      (local.set $local21
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result i32)
       (if (result i32)
        (call $function158
         (struct.get $type150 1
          (ref.as_non_null
           (local.get $local21)
          )
         )
         (local.get $local19)
         (local.get $local20)
        )
        (then
         (local.set $local16
          (ref.as_non_null
           (local.get $argument636)
          )
         )
         (local.set $local17
          (i32.const 35)
         )
         (local.set $local18
          (ref.as_non_null
           (global.get $global549)
          )
         )
         (call $function161
          (struct.get $type151 1
           (ref.as_non_null
            (local.get $local18)
           )
          )
          (ref.as_non_null
           (local.get $local16)
          )
          (local.get $local17)
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (local.set $local9
         (local.get $argument637)
        )
        (local.set $local10
         (i64.const 1)
        )
        (local.set $local8
         (i64.eq
          (local.get $local9)
          (local.get $local10)
         )
        )
        (local.set $local7
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local7)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (local.get $local8)
         (then
          (if
           (i32.eqz
            (local.get $local7)
           )
           (then
            (unreachable)
           )
          )
          (local.get $local8)
         )
         (else
          (local.set $local11
           (ref.as_non_null
            (local.get $argument636)
           )
          )
          (local.set $local13
           (local.get $argument637)
          )
          (local.set $local14
           (i64.const 1)
          )
          (local.set $local12
           (i64.sub
            (local.get $local13)
            (local.get $local14)
           )
          )
          (if
           (i32.eqz
            (global.get $ready635)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local15
           (ref.as_non_null
            (global.get $global635)
           )
          )
          (return_call $function182
           (struct.get $type161 1
            (ref.as_non_null
             (local.get $local15)
            )
           )
           (ref.as_non_null
            (local.get $local11)
           )
           (local.get $local12)
          )
         )
        )
       )
       (else
        (local.set $local4
         (ref.as_non_null
          (local.get $argument636)
         )
        )
        (local.set $local5
         (local.get $argument637)
        )
        (if
         (i32.eqz
          (global.get $ready635)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local6
         (ref.as_non_null
          (global.get $global635)
         )
        )
        (return_call $function182
         (struct.get $type161 1
          (ref.as_non_null
           (local.get $local6)
          )
         )
         (ref.as_non_null
          (local.get $local4)
         )
         (local.get $local5)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function183 (type $call162) (param $environment eqref) (param $argument641 (ref $type121)) (result (ref $type163))
  (local $local0 i32)
  (local $local10 i32)
  (local $local1 i64)
  (local $local6 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local2 (ref null $type121))
  (local $local5 (ref null $type121))
  (local $local3 (ref null $type128))
  (local $local4 (ref null $type18))
  (local $local14 (ref null $type18))
  (local $local7 (ref null $type160))
  (local $local8 (ref null $type172))
  (local $local9 (ref null $type13))
  (local $local13 (ref null $type152))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument641)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (local.set $local1
   (call $function155
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (local.get $local1)
  )
  (local.set $local16
   (i64.const 0)
  )
  (if (result (ref $type163))
   (i64.lt_s
    (local.get $local15)
    (local.get $local16)
   )
   (then
    (local.set $local14
     (global.get $string21)
    )
    (struct.new $type170
     (i32.const 6)
     (ref.as_non_null
      (local.get $local14)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (local.get $local1)
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global643)
     )
    )
    (if (result (ref $type163))
     (call $function184
      (struct.get $type152 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (local.get $local12)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local11
       (local.get $local1)
      )
      (if
       (i64.gt_u
        (local.get $local11)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.ge_u
         (local.get $local11)
         (i64.const 55296)
        )
        (i64.le_u
         (local.get $local11)
         (i64.const 57343)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $local10
       (i32.wrap_i64
        (local.get $local11)
       )
      )
      (local.set $local9
       (struct.new $type16
        (i32.const 2)
        (local.get $local10)
       )
      )
      (struct.new $type164
       (i32.const 0)
       (ref.as_non_null
        (local.get $local9)
       )
      )
     )
     (else
      (local.set $local5
       (ref.as_non_null
        (local.get $argument641)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (local.get $local1)
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global658)
       )
      )
      (local.set $local4
       (call $function185
        (struct.get $type160 1
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (ref.as_non_null
         (local.get $local5)
        )
        (local.get $local6)
       )
      )
      (if
       (i32.eqz
        (global.get $ready663)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local8
       (ref.as_non_null
        (global.get $global663)
       )
      )
      (return_call $function187
       (struct.get $type172 1
        (ref.as_non_null
         (local.get $local8)
        )
       )
       (ref.as_non_null
        (local.get $local4)
       )
      )
     )
    )
   )
  )
 )
 (func $function184 (type $call152) (param $environment eqref) (param $argument644 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local11 i32)
  (local $local13 i32)
  (local $local14 i32)
  (local $local16 i32)
  (local $local18 i32)
  (local $local19 i32)
  (local $local21 i32)
  (local $local23 i32)
  (local $local24 i32)
  (local $local26 i32)
  (local $local28 i32)
  (local $local29 i32)
  (local $local31 i32)
  (local $local33 i32)
  (local $local34 i32)
  (local $local36 i32)
  (local $local38 i32)
  (local $local39 i32)
  (local $local41 i32)
  (local $local43 i32)
  (local $local44 i32)
  (local $local46 i32)
  (local $local48 i32)
  (local $local49 i32)
  (local $local51 i32)
  (local $local53 i32)
  (local $local54 i32)
  (local $local56 i32)
  (local $local58 i32)
  (local $local59 i32)
  (local $local61 i32)
  (local $local64 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local10 i64)
  (local $local15 i64)
  (local $local20 i64)
  (local $local25 i64)
  (local $local30 i64)
  (local $local35 i64)
  (local $local40 i64)
  (local $local45 i64)
  (local $local50 i64)
  (local $local55 i64)
  (local $local60 i64)
  (local $local63 i64)
  (local $local7 (ref null $type152))
  (local $local12 (ref null $type150))
  (local $local17 (ref null $type150))
  (local $local22 (ref null $type150))
  (local $local27 (ref null $type150))
  (local $local32 (ref null $type150))
  (local $local37 (ref null $type150))
  (local $local42 (ref null $type150))
  (local $local47 (ref null $type150))
  (local $local52 (ref null $type150))
  (local $local57 (ref null $type150))
  (local $local62 (ref null $type150))
  (local $local65 (ref null $type150))
  (local.set $local2
   (local.get $argument644)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local1
   (i64.lt_s
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local6
     (local.get $argument644)
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global536)
     )
    )
    (local.set $local5
     (call $function157
      (struct.get $type152 1
       (ref.as_non_null
        (local.get $local7)
       )
      )
      (local.get $local6)
     )
    )
    (local.set $local4
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (local.get $local5)
     (then
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local5)
     )
     (else
      (local.set $local10
       (local.get $argument644)
      )
      (local.set $local11
       (i32.const 40)
      )
      (local.set $local12
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (local.set $local9
       (call $function158
        (struct.get $type150 1
         (ref.as_non_null
          (local.get $local12)
         )
        )
        (local.get $local10)
        (local.get $local11)
       )
      )
      (local.set $local8
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (local.get $local9)
       (then
        (if
         (i32.eqz
          (local.get $local8)
         )
         (then
          (unreachable)
         )
        )
        (local.get $local9)
       )
       (else
        (local.set $local15
         (local.get $argument644)
        )
        (local.set $local16
         (i32.const 41)
        )
        (local.set $local17
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (local.set $local14
         (call $function158
          (struct.get $type150 1
           (ref.as_non_null
            (local.get $local17)
           )
          )
          (local.get $local15)
          (local.get $local16)
         )
        )
        (local.set $local13
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local13)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (local.get $local14)
         (then
          (if
           (i32.eqz
            (local.get $local13)
           )
           (then
            (unreachable)
           )
          )
          (local.get $local14)
         )
         (else
          (local.set $local20
           (local.get $argument644)
          )
          (local.set $local21
           (i32.const 34)
          )
          (local.set $local22
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (local.set $local19
           (call $function158
            (struct.get $type150 1
             (ref.as_non_null
              (local.get $local22)
             )
            )
            (local.get $local20)
            (local.get $local21)
           )
          )
          (local.set $local18
           (i32.const 1)
          )
          (if
           (i32.eqz
            (local.get $local18)
           )
           (then
            (unreachable)
           )
          )
          (if (result i32)
           (local.get $local19)
           (then
            (if
             (i32.eqz
              (local.get $local18)
             )
             (then
              (unreachable)
             )
            )
            (local.get $local19)
           )
           (else
            (local.set $local25
             (local.get $argument644)
            )
            (local.set $local26
             (i32.const 59)
            )
            (local.set $local27
             (ref.as_non_null
              (global.get $global538)
             )
            )
            (local.set $local24
             (call $function158
              (struct.get $type150 1
               (ref.as_non_null
                (local.get $local27)
               )
              )
              (local.get $local25)
              (local.get $local26)
             )
            )
            (local.set $local23
             (i32.const 1)
            )
            (if
             (i32.eqz
              (local.get $local23)
             )
             (then
              (unreachable)
             )
            )
            (if (result i32)
             (local.get $local24)
             (then
              (if
               (i32.eqz
                (local.get $local23)
               )
               (then
                (unreachable)
               )
              )
              (local.get $local24)
             )
             (else
              (local.set $local30
               (local.get $argument644)
              )
              (local.set $local31
               (i32.const 124)
              )
              (local.set $local32
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (local.set $local29
               (call $function158
                (struct.get $type150 1
                 (ref.as_non_null
                  (local.get $local32)
                 )
                )
                (local.get $local30)
                (local.get $local31)
               )
              )
              (local.set $local28
               (i32.const 1)
              )
              (if
               (i32.eqz
                (local.get $local28)
               )
               (then
                (unreachable)
               )
              )
              (if (result i32)
               (local.get $local29)
               (then
                (if
                 (i32.eqz
                  (local.get $local28)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.get $local29)
               )
               (else
                (local.set $local35
                 (local.get $argument644)
                )
                (local.set $local36
                 (i32.const 39)
                )
                (local.set $local37
                 (ref.as_non_null
                  (global.get $global538)
                 )
                )
                (local.set $local34
                 (call $function158
                  (struct.get $type150 1
                   (ref.as_non_null
                    (local.get $local37)
                   )
                  )
                  (local.get $local35)
                  (local.get $local36)
                 )
                )
                (local.set $local33
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (local.get $local33)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i32)
                 (local.get $local34)
                 (then
                  (if
                   (i32.eqz
                    (local.get $local33)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.get $local34)
                 )
                 (else
                  (local.set $local40
                   (local.get $argument644)
                  )
                  (local.set $local41
                   (i32.const 96)
                  )
                  (local.set $local42
                   (ref.as_non_null
                    (global.get $global538)
                   )
                  )
                  (local.set $local39
                   (call $function158
                    (struct.get $type150 1
                     (ref.as_non_null
                      (local.get $local42)
                     )
                    )
                    (local.get $local40)
                    (local.get $local41)
                   )
                  )
                  (local.set $local38
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (local.get $local38)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if (result i32)
                   (local.get $local39)
                   (then
                    (if
                     (i32.eqz
                      (local.get $local38)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.get $local39)
                   )
                   (else
                    (local.set $local45
                     (local.get $argument644)
                    )
                    (local.set $local46
                     (i32.const 44)
                    )
                    (local.set $local47
                     (ref.as_non_null
                      (global.get $global538)
                     )
                    )
                    (local.set $local44
                     (call $function158
                      (struct.get $type150 1
                       (ref.as_non_null
                        (local.get $local47)
                       )
                      )
                      (local.get $local45)
                      (local.get $local46)
                     )
                    )
                    (local.set $local43
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (local.get $local43)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if (result i32)
                     (local.get $local44)
                     (then
                      (if
                       (i32.eqz
                        (local.get $local43)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.get $local44)
                     )
                     (else
                      (local.set $local50
                       (local.get $argument644)
                      )
                      (local.set $local51
                       (i32.const 91)
                      )
                      (local.set $local52
                       (ref.as_non_null
                        (global.get $global538)
                       )
                      )
                      (local.set $local49
                       (call $function158
                        (struct.get $type150 1
                         (ref.as_non_null
                          (local.get $local52)
                         )
                        )
                        (local.get $local50)
                        (local.get $local51)
                       )
                      )
                      (local.set $local48
                       (i32.const 1)
                      )
                      (if
                       (i32.eqz
                        (local.get $local48)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if (result i32)
                       (local.get $local49)
                       (then
                        (if
                         (i32.eqz
                          (local.get $local48)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.get $local49)
                       )
                       (else
                        (local.set $local55
                         (local.get $argument644)
                        )
                        (local.set $local56
                         (i32.const 93)
                        )
                        (local.set $local57
                         (ref.as_non_null
                          (global.get $global538)
                         )
                        )
                        (local.set $local54
                         (call $function158
                          (struct.get $type150 1
                           (ref.as_non_null
                            (local.get $local57)
                           )
                          )
                          (local.get $local55)
                          (local.get $local56)
                         )
                        )
                        (local.set $local53
                         (i32.const 1)
                        )
                        (if
                         (i32.eqz
                          (local.get $local53)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if (result i32)
                         (local.get $local54)
                         (then
                          (if
                           (i32.eqz
                            (local.get $local53)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.get $local54)
                         )
                         (else
                          (local.set $local60
                           (local.get $argument644)
                          )
                          (local.set $local61
                           (i32.const 123)
                          )
                          (local.set $local62
                           (ref.as_non_null
                            (global.get $global538)
                           )
                          )
                          (local.set $local59
                           (call $function158
                            (struct.get $type150 1
                             (ref.as_non_null
                              (local.get $local62)
                             )
                            )
                            (local.get $local60)
                            (local.get $local61)
                           )
                          )
                          (local.set $local58
                           (i32.const 1)
                          )
                          (if
                           (i32.eqz
                            (local.get $local58)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if (result i32)
                           (local.get $local59)
                           (then
                            (if
                             (i32.eqz
                              (local.get $local58)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (local.get $local59)
                           )
                           (else
                            (local.set $local63
                             (local.get $argument644)
                            )
                            (local.set $local64
                             (i32.const 125)
                            )
                            (local.set $local65
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (return_call $function158
                             (struct.get $type150 1
                              (ref.as_non_null
                               (local.get $local65)
                              )
                             )
                             (local.get $local63)
                             (local.get $local64)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function185 (type $call160) (param $environment eqref) (param $argument659 (ref $type121)) (param $argument660 i64) (result (ref $type18))
  (local $local0 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local6 i32)
  (local $local7 i64)
  (local $local1 (ref null $type154))
  (local $local5 (ref null $type154))
  (local $local2 (ref null $type153))
  (local $local8 (ref null $type157))
  (local.set $local2
   (ref.as_non_null
    (global.get $global562)
   )
  )
  (local.set $local1
   (call $function165
    (struct.get $type153 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (local.get $argument660)
  )
  (if
   (i64.gt_u
    (local.get $local7)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ge_u
     (local.get $local7)
     (i64.const 55296)
    )
    (i64.le_u
     (local.get $local7)
     (i64.const 57343)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (i32.wrap_i64
    (local.get $local7)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global611)
   )
  )
  (drop
   (call $function177
    (struct.get $type157 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (ref.as_non_null
     (local.get $local5)
    )
    (local.get $local6)
   )
  )
  (local.set $local4
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local4)
  )
  (return_call $function186
   (ref.as_non_null
    (local.get $argument659)
   )
   (block (result (ref $type154))
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
   (local.get $local4)
   (local.get $local3)
  )
 )
 (func $function186 (param $capture659 (ref $type121)) (param $capture661 (ref $type154)) (param $capture662 i32) (param $initialized662 i32) (result (ref $type18))
  (local $local0 (ref null $type154))
  (local $local6 (ref null $type154))
  (local $local3 (ref null $type121))
  (local $local9 (ref null $type121))
  (local $local4 (ref null $type128))
  (local $local10 (ref null $type128))
  (local $local5 (ref null $type157))
  (local $local7 (ref null $type159))
  (local $local11 (ref null $type152))
  (local $local1 i32)
  (local $local2 i64)
  (local $local8 i64)
  (local.set $local9
   (ref.as_non_null
    (local.get $capture659)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (local.set $local8
   (call $function162
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local10)
     )
    )
    (ref.as_non_null
     (local.get $local9)
    )
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global643)
   )
  )
  (if (result (ref $type18))
   (call $function184
    (struct.get $type152 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (local.get $local8)
   )
   (then
    (local.set $local6
     (ref.as_non_null
      (local.get $capture661)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global568)
     )
    )
    (return_call $function167
     (struct.get $type159 1
      (ref.as_non_null
       (local.get $local7)
      )
     )
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
   (else
    (local.set $local0
     (ref.as_non_null
      (local.get $capture661)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (local.get $capture659)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (local.set $local2
     (call $function155
      (struct.get $type128 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $local2)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local2)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local2)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local1
     (i32.wrap_i64
      (local.get $local2)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global611)
     )
    )
    (drop
     (call $function177
      (struct.get $type157 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local0)
      )
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized662)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture662)
    )
    (return_call $function186
     (ref.as_non_null
      (local.get $capture659)
     )
     (ref.as_non_null
      (local.get $capture661)
     )
     (local.get $capture662)
     (local.get $initialized662)
    )
   )
  )
 )
 (func $function187 (type $call172) (param $environment eqref) (param $argument664 (ref $type18)) (result (ref $type163))
  (local $local0 i32)
  (local $local6 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local12 i32)
  (local $local14 i32)
  (local $local17 i32)
  (local $local16 i64)
  (local $local18 i64)
  (local $local20 i64)
  (local $local1 (ref null $type181))
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type18))
  (local $local7 (ref null $type18))
  (local $local8 (ref null $type18))
  (local $local15 (ref null $type18))
  (local $local19 (ref null $type18))
  (local $local4 (ref null $type48))
  (local $local5 (ref null $type189))
  (local $local11 (ref null $type13))
  (local $local13 (ref null $type13))
  (local.set $local19
   (ref.as_non_null
    (local.get $argument664)
   )
  )
  (local.set $local18
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local19)
     )
    )
   )
  )
  (local.set $local20
   (i64.const 1)
  )
  (if (result (ref $type163))
   (i64.eq
    (local.get $local18)
    (local.get $local20)
   )
   (then
    (local.set $local15
     (ref.as_non_null
      (local.get $argument664)
     )
    )
    (local.set $local16
     (i64.const 0)
    )
    (if
     (i64.ge_u
      (local.get $local16)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local15)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (i32.wrap_i64
      (local.get $local16)
     )
    )
    (local.set $local14
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local15)
       )
       (local.get $local17)
      )
      (i32.and
       (local.get $local17)
       (i32.const 8191)
      )
     )
    )
    (local.set $local13
     (struct.new $type16
      (i32.const 2)
      (local.get $local14)
     )
    )
    (struct.new $type164
     (i32.const 0)
     (ref.as_non_null
      (local.get $local13)
     )
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $argument664)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global666)
     )
    )
    (local.set $local2
     (call $function188
      (struct.get $type48 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready672)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global672)
     )
    )
    (local.set $local1
     (call $function190
      (struct.get $type189 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type163))
     (i32.eq
      (struct.get $type181 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local10
       (struct.get $type182 1
        (ref.cast (ref $type182)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local9
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local9)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local12
       (local.get $local10)
      )
      (local.set $local11
       (struct.new $type16
        (i32.const 2)
        (local.get $local12)
       )
      )
      (struct.new $type164
       (i32.const 0)
       (ref.as_non_null
        (local.get $local11)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result (ref $type163))
       (i32.eq
        (struct.get $type181 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 2)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local7
         (struct.get $type184 1
          (ref.cast (ref $type184)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local6
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local6)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local8
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (struct.new $type170
         (i32.const 6)
         (ref.as_non_null
          (local.get $local8)
         )
        )
       )
       (else
        (unreachable)
       )
      )
     )
    )
   )
  )
 )
 (func $function188 (type $call48) (param $environment eqref) (param $argument667 (ref $type18)) (result (ref $type18))
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local4 i64)
  (local $local1 (ref null $type18))
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type48))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument667)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (local.set $local1
   (call $function34
    (struct.get $type48 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local6
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local5)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local6)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function189
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local6)
   (local.get $local5)
   (local.get $local4)
  )
 )
 (func $function189 (param $capture668 (ref $type18)) (param $capture669 i32) (param $initialized669 i32) (param $argument670 i64) (result (ref $type18))
  (local $local0 i32)
  (local $local2 i32)
  (local $local5 i32)
  (local $local11 i32)
  (local $local15 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local3 (ref null $type18))
  (local $local9 (ref null $type18))
  (local $local22 (ref null $type18))
  (local.set $local20
   (local.get $argument670)
  )
  (local.set $local22
   (ref.as_non_null
    (local.get $capture668)
   )
  )
  (local.set $local21
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local22)
     )
    )
   )
  )
  (if (result (ref $type18))
   (i64.eq
    (local.get $local20)
    (local.get $local21)
   )
   (then
    (ref.as_non_null
     (local.get $capture668)
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture668)
     )
    )
    (local.set $local4
     (local.get $argument670)
    )
    (if
     (i64.ge_u
      (local.get $local4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local3)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (i32.wrap_i64
      (local.get $local4)
     )
    )
    (local.set $local2
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local3)
       )
       (local.get $local5)
      )
      (i32.and
       (local.get $local5)
       (i32.const 8191)
      )
     )
    )
    (local.set $local1
     (i64.extend_i32_u
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local1)
    )
    (local.set $local19
     (i64.const 65)
    )
    (drop
     (if (result i32)
      (if (result i32)
       (i64.ge_s
        (local.get $local18)
        (local.get $local19)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local16
         (local.get $local1)
        )
        (local.set $local17
         (i64.const 90)
        )
        (i64.le_s
         (local.get $local16)
         (local.get $local17)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (local.set $local9
        (ref.as_non_null
         (local.get $capture668)
        )
       )
       (local.set $local10
        (local.get $argument670)
       )
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local13
        (local.get $local1)
       )
       (local.set $local14
        (i64.const 32)
       )
       (local.set $local12
        (i64.add
         (local.get $local13)
         (local.get $local14)
        )
       )
       (if
        (i64.gt_u
         (local.get $local12)
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.ge_u
          (local.get $local12)
          (i64.const 55296)
         )
         (i64.le_u
          (local.get $local12)
          (i64.const 57343)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $local11
        (i32.wrap_i64
         (local.get $local12)
        )
       )
       (if
        (i32.ne
         (struct.get $type18 0
          (ref.as_non_null
           (local.get $local9)
          )
         )
         (i32.const 1)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.ge_u
         (local.get $local10)
         (i64.extend_i32_u
          (struct.get $type18 1
           (ref.as_non_null
            (local.get $local9)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $local15
        (i32.wrap_i64
         (local.get $local10)
        )
       )
       (array.set $type19
        (call $string-block
         (ref.as_non_null
          (local.get $local9)
         )
         (local.get $local15)
        )
        (i32.and
         (local.get $local15)
         (i32.const 8191)
        )
        (local.get $local11)
       )
       (drop
        (i32.const 0)
       )
       (i32.const 0)
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $local7
     (local.get $argument670)
    )
    (local.set $local8
     (i64.const 1)
    )
    (local.set $local6
     (i64.add
      (local.get $local7)
      (local.get $local8)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized669)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture669)
    )
    (return_call $function189
     (ref.as_non_null
      (local.get $capture668)
     )
     (local.get $capture669)
     (local.get $initialized669)
     (local.get $local6)
    )
   )
  )
 )
 (func $function190 (type $call189) (param $environment eqref) (param $argument673 (ref $type18)) (result (ref $type181))
  (local $local0 (ref null $type18))
  (local $local1 (ref null $type18))
  (local $local4 (ref null $type18))
  (local $local9 (ref null $type18))
  (local $local10 (ref null $type18))
  (local $local13 (ref null $type18))
  (local $local14 (ref null $type18))
  (local $local17 (ref null $type18))
  (local $local18 (ref null $type18))
  (local $local22 (ref null $type18))
  (local $local23 (ref null $type18))
  (local $local26 (ref null $type18))
  (local $local27 (ref null $type18))
  (local $local31 (ref null $type18))
  (local $local32 (ref null $type18))
  (local $local36 (ref null $type18))
  (local $local37 (ref null $type18))
  (local $local41 (ref null $type18))
  (local $local42 (ref null $type18))
  (local $local46 (ref null $type18))
  (local $local47 (ref null $type18))
  (local $local2 (ref null $type189))
  (local $local11 (ref null $type53))
  (local $local15 (ref null $type53))
  (local $local19 (ref null $type53))
  (local $local24 (ref null $type53))
  (local $local28 (ref null $type53))
  (local $local33 (ref null $type53))
  (local $local38 (ref null $type53))
  (local $local43 (ref null $type53))
  (local $local48 (ref null $type53))
  (local $local3 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local12 i32)
  (local $local16 i32)
  (local $local20 i32)
  (local $local25 i32)
  (local $local29 i32)
  (local $local34 i32)
  (local $local39 i32)
  (local $local44 i32)
  (local $local5 i64)
  (local $local21 i64)
  (local $local30 i64)
  (local $local35 i64)
  (local $local40 i64)
  (local $local45 i64)
  (local.set $local46
   (ref.as_non_null
    (local.get $argument673)
   )
  )
  (local.set $local47
   (global.get $string31)
  )
  (local.set $local48
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (if (result (ref $type181))
   (call $function39
    (struct.get $type53 1
     (ref.as_non_null
      (local.get $local48)
     )
    )
    (ref.as_non_null
     (local.get $local46)
    )
    (ref.as_non_null
     (local.get $local47)
    )
   )
   (then
    (local.set $local45
     (i64.const 7)
    )
    (if
     (i64.gt_u
      (local.get $local45)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local45)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local45)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local44
     (i32.wrap_i64
      (local.get $local45)
     )
    )
    (struct.new $type182
     (i32.const 0)
     (local.get $local44)
    )
   )
   (else
    (local.set $local41
     (ref.as_non_null
      (local.get $argument673)
     )
    )
    (local.set $local42
     (global.get $string30)
    )
    (local.set $local43
     (ref.as_non_null
      (global.get $global103)
     )
    )
    (if (result (ref $type181))
     (call $function39
      (struct.get $type53 1
       (ref.as_non_null
        (local.get $local43)
       )
      )
      (ref.as_non_null
       (local.get $local41)
      )
      (ref.as_non_null
       (local.get $local42)
      )
     )
     (then
      (local.set $local40
       (i64.const 8)
      )
      (if
       (i64.gt_u
        (local.get $local40)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.ge_u
         (local.get $local40)
         (i64.const 55296)
        )
        (i64.le_u
         (local.get $local40)
         (i64.const 57343)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $local39
       (i32.wrap_i64
        (local.get $local40)
       )
      )
      (struct.new $type182
       (i32.const 0)
       (local.get $local39)
      )
     )
     (else
      (local.set $local36
       (ref.as_non_null
        (local.get $argument673)
       )
      )
      (local.set $local37
       (global.get $string29)
      )
      (local.set $local38
       (ref.as_non_null
        (global.get $global103)
       )
      )
      (if (result (ref $type181))
       (call $function39
        (struct.get $type53 1
         (ref.as_non_null
          (local.get $local38)
         )
        )
        (ref.as_non_null
         (local.get $local36)
        )
        (ref.as_non_null
         (local.get $local37)
        )
       )
       (then
        (local.set $local35
         (i64.const 127)
        )
        (if
         (i64.gt_u
          (local.get $local35)
          (i64.const 1114111)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.and
          (i64.ge_u
           (local.get $local35)
           (i64.const 55296)
          )
          (i64.le_u
           (local.get $local35)
           (i64.const 57343)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $local34
         (i32.wrap_i64
          (local.get $local35)
         )
        )
        (struct.new $type182
         (i32.const 0)
         (local.get $local34)
        )
       )
       (else
        (local.set $local31
         (ref.as_non_null
          (local.get $argument673)
         )
        )
        (local.set $local32
         (global.get $string28)
        )
        (local.set $local33
         (ref.as_non_null
          (global.get $global103)
         )
        )
        (if (result (ref $type181))
         (call $function39
          (struct.get $type53 1
           (ref.as_non_null
            (local.get $local33)
           )
          )
          (ref.as_non_null
           (local.get $local31)
          )
          (ref.as_non_null
           (local.get $local32)
          )
         )
         (then
          (local.set $local30
           (i64.const 27)
          )
          (if
           (i64.gt_u
            (local.get $local30)
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.ge_u
             (local.get $local30)
             (i64.const 55296)
            )
            (i64.le_u
             (local.get $local30)
             (i64.const 57343)
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $local29
           (i32.wrap_i64
            (local.get $local30)
           )
          )
          (struct.new $type182
           (i32.const 0)
           (local.get $local29)
          )
         )
         (else
          (local.set $local26
           (ref.as_non_null
            (local.get $argument673)
           )
          )
          (local.set $local27
           (global.get $string27)
          )
          (local.set $local28
           (ref.as_non_null
            (global.get $global103)
           )
          )
          (if (result (ref $type181))
           (call $function39
            (struct.get $type53 1
             (ref.as_non_null
              (local.get $local28)
             )
            )
            (ref.as_non_null
             (local.get $local26)
            )
            (ref.as_non_null
             (local.get $local27)
            )
           )
           (then
            (local.set $local25
             (i32.const 10)
            )
            (struct.new $type182
             (i32.const 0)
             (local.get $local25)
            )
           )
           (else
            (local.set $local22
             (ref.as_non_null
              (local.get $argument673)
             )
            )
            (local.set $local23
             (global.get $string26)
            )
            (local.set $local24
             (ref.as_non_null
              (global.get $global103)
             )
            )
            (if (result (ref $type181))
             (call $function39
              (struct.get $type53 1
               (ref.as_non_null
                (local.get $local24)
               )
              )
              (ref.as_non_null
               (local.get $local22)
              )
              (ref.as_non_null
               (local.get $local23)
              )
             )
             (then
              (local.set $local21
               (i64.const 0)
              )
              (if
               (i64.gt_u
                (local.get $local21)
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.ge_u
                 (local.get $local21)
                 (i64.const 55296)
                )
                (i64.le_u
                 (local.get $local21)
                 (i64.const 57343)
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $local20
               (i32.wrap_i64
                (local.get $local21)
               )
              )
              (struct.new $type182
               (i32.const 0)
               (local.get $local20)
              )
             )
             (else
              (local.set $local17
               (ref.as_non_null
                (local.get $argument673)
               )
              )
              (local.set $local18
               (global.get $string25)
              )
              (local.set $local19
               (ref.as_non_null
                (global.get $global103)
               )
              )
              (if (result (ref $type181))
               (call $function39
                (struct.get $type53 1
                 (ref.as_non_null
                  (local.get $local19)
                 )
                )
                (ref.as_non_null
                 (local.get $local17)
                )
                (ref.as_non_null
                 (local.get $local18)
                )
               )
               (then
                (local.set $local16
                 (i32.const 13)
                )
                (struct.new $type182
                 (i32.const 0)
                 (local.get $local16)
                )
               )
               (else
                (local.set $local13
                 (ref.as_non_null
                  (local.get $argument673)
                 )
                )
                (local.set $local14
                 (global.get $string24)
                )
                (local.set $local15
                 (ref.as_non_null
                  (global.get $global103)
                 )
                )
                (if (result (ref $type181))
                 (call $function39
                  (struct.get $type53 1
                   (ref.as_non_null
                    (local.get $local15)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local13)
                  )
                  (ref.as_non_null
                   (local.get $local14)
                  )
                 )
                 (then
                  (local.set $local12
                   (i32.const 32)
                  )
                  (struct.new $type182
                   (i32.const 0)
                   (local.get $local12)
                  )
                 )
                 (else
                  (local.set $local9
                   (ref.as_non_null
                    (local.get $argument673)
                   )
                  )
                  (local.set $local10
                   (global.get $string23)
                  )
                  (local.set $local11
                   (ref.as_non_null
                    (global.get $global103)
                   )
                  )
                  (if (result (ref $type181))
                   (call $function39
                    (struct.get $type53 1
                     (ref.as_non_null
                      (local.get $local11)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local9)
                    )
                    (ref.as_non_null
                     (local.get $local10)
                    )
                   )
                   (then
                    (local.set $local8
                     (i32.const 9)
                    )
                    (struct.new $type182
                     (i32.const 0)
                     (local.get $local8)
                    )
                   )
                   (else
                    (local.set $local4
                     (ref.as_non_null
                      (local.get $argument673)
                     )
                    )
                    (local.set $local5
                     (i64.const 0)
                    )
                    (if
                     (i64.ge_u
                      (local.get $local5)
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (ref.as_non_null
                         (local.get $local4)
                        )
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $local6
                     (i32.wrap_i64
                      (local.get $local5)
                     )
                    )
                    (local.set $local3
                     (array.get $type19
                      (call $string-block
                       (ref.as_non_null
                        (local.get $local4)
                       )
                       (local.get $local6)
                      )
                      (i32.and
                       (local.get $local6)
                       (i32.const 8191)
                      )
                     )
                    )
                    (local.set $local7
                     (i32.const 120)
                    )
                    (if (result (ref $type181))
                     (i32.eq
                      (local.get $local3)
                      (local.get $local7)
                     )
                     (then
                      (local.set $local1
                       (ref.as_non_null
                        (local.get $argument673)
                       )
                      )
                      (local.set $local2
                       (ref.as_non_null
                        (global.get $global674)
                       )
                      )
                      (return_call $function191
                       (struct.get $type189 1
                        (ref.as_non_null
                         (local.get $local2)
                        )
                       )
                       (ref.as_non_null
                        (local.get $local1)
                       )
                      )
                     )
                     (else
                      (local.set $local0
                       (global.get $string22)
                      )
                      (struct.new $type184
                       (i32.const 2)
                       (ref.as_non_null
                        (local.get $local0)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function191 (type $call189) (param $environment eqref) (param $argument675 (ref $type18)) (result (ref $type181))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (i64.const 1)
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function192
   (ref.as_non_null
    (local.get $argument675)
   )
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function192 (param $capture675 (ref $type18)) (param $capture676 i32) (param $initialized676 i32) (param $argument677 i64) (param $argument678 i64) (result (ref $type181))
  (local $local0 i32)
  (local $local3 i32)
  (local $local6 i32)
  (local $local17 i32)
  (local $local18 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local28 i64)
  (local $local29 i64)
  (local $local4 (ref null $type18))
  (local $local16 (ref null $type18))
  (local $local30 (ref null $type18))
  (local $local7 (ref null $type67))
  (local $local27 (ref null $type187))
  (local.set $local28
   (local.get $argument677)
  )
  (local.set $local30
   (ref.as_non_null
    (local.get $capture675)
   )
  )
  (local.set $local29
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local30)
     )
    )
   )
  )
  (if (result (ref $type181))
   (i64.eq
    (local.get $local28)
    (local.get $local29)
   )
   (then
    (local.set $local23
     (local.get $argument678)
    )
    (local.set $local25
     (local.get $argument677)
    )
    (local.set $local26
     (i64.const 1)
    )
    (local.set $local24
     (i64.sub
      (local.get $local25)
      (local.get $local26)
     )
    )
    (local.set $local27
     (ref.as_non_null
      (global.get $global581)
     )
    )
    (return_call $function170
     (struct.get $type187 1
      (ref.as_non_null
       (local.get $local27)
      )
     )
     (local.get $local23)
     (local.get $local24)
    )
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture675)
     )
    )
    (local.set $local5
     (local.get $argument677)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (local.set $local2
     (i64.extend_i32_u
      (local.get $local3)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global588)
     )
    )
    (local.set $local1
     (call $function172
      (struct.get $type67 1
       (ref.as_non_null
        (local.get $local7)
       )
      )
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (local.get $local1)
    )
    (local.set $local20
     (i64.const 0)
    )
    (local.set $local18
     (i64.lt_s
      (local.get $local19)
      (local.get $local20)
     )
    )
    (local.set $local17
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local17)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (local.get $local18)
      (then
       (if
        (i32.eqz
         (local.get $local17)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local18)
      )
      (else
       (local.set $local21
        (local.get $argument678)
       )
       (local.set $local22
        (i64.const 69631)
       )
       (i64.gt_s
        (local.get $local21)
        (local.get $local22)
       )
      )
     )
     (then
      (local.set $local16
       (global.get $string32)
      )
      (struct.new $type184
       (i32.const 2)
       (ref.as_non_null
        (local.get $local16)
       )
      )
     )
     (else
      (local.set $local9
       (local.get $argument677)
      )
      (local.set $local10
       (i64.const 1)
      )
      (local.set $local8
       (i64.add
        (local.get $local9)
        (local.get $local10)
       )
      )
      (local.set $local13
       (local.get $argument678)
      )
      (local.set $local14
       (i64.const 16)
      )
      (local.set $local12
       (i64.mul
        (local.get $local13)
        (local.get $local14)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local15
       (local.get $local1)
      )
      (local.set $local11
       (i64.add
        (local.get $local12)
        (local.get $local15)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized676)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture676)
      )
      (return_call $function192
       (ref.as_non_null
        (local.get $capture675)
       )
       (local.get $capture676)
       (local.get $initialized676)
       (local.get $local8)
       (local.get $local11)
      )
     )
    )
   )
  )
 )
 (func $function193 (type $call162) (param $environment eqref) (param $argument685 (ref $type121)) (result (ref $type163))
  (local $local0 (ref null $type18))
  (local $local2 (ref null $type121))
  (local $local5 (ref null $type121))
  (local $local4 (ref null $type151))
  (local $local7 (ref null $type151))
  (local $local1 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local.set $local5
   (ref.as_non_null
    (local.get $argument685)
   )
  )
  (local.set $local6
   (i32.const 56)
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global549)
   )
  )
  (if (result (ref $type163))
   (if (result i32)
    (call $function161
     (struct.get $type151 1
      (ref.as_non_null
       (local.get $local7)
      )
     )
     (ref.as_non_null
      (local.get $local5)
     )
     (local.get $local6)
    )
    (then
     (local.set $local2
      (ref.as_non_null
       (local.get $argument685)
      )
     )
     (local.set $local3
      (i32.const 40)
     )
     (local.set $local4
      (ref.as_non_null
       (global.get $global549)
      )
     )
     (call $function161
      (struct.get $type151 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (local.get $local3)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $local1
     (i64.const 2)
    )
    (struct.new $type168
     (i32.const 4)
     (local.get $local1)
    )
   )
   (else
    (local.set $local0
     (global.get $string33)
    )
    (struct.new $type170
     (i32.const 6)
     (ref.as_non_null
      (local.get $local0)
     )
    )
   )
  )
 )
 (func $function194 (type $call172) (param $environment eqref) (param $argument687 (ref $type18)) (result (ref $type163))
  (local $local0 i32)
  (local $local4 i32)
  (local $local9 i32)
  (local $local12 i32)
  (local $local17 i32)
  (local $local18 i32)
  (local $local19 i32)
  (local $local27 i32)
  (local $local28 i32)
  (local $local29 i32)
  (local $local1 (ref null $type18))
  (local $local2 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local8 (ref null $type18))
  (local $local10 (ref null $type18))
  (local $local11 (ref null $type18))
  (local $local20 (ref null $type18))
  (local $local21 (ref null $type18))
  (local $local23 (ref null $type18))
  (local $local24 (ref null $type18))
  (local $local30 (ref null $type18))
  (local $local31 (ref null $type18))
  (local $local33 (ref null $type18))
  (local $local34 (ref null $type18))
  (local $local3 (ref null $type48))
  (local $local5 (ref null $type92))
  (local $local7 (ref null $type96))
  (local $local13 (ref null $type24))
  (local $local15 (ref null $type24))
  (local $local14 (ref null $type13))
  (local $local16 (ref null $type13))
  (local $local26 (ref null $type13))
  (local $local22 (ref null $type53))
  (local $local25 (ref null $type53))
  (local $local32 (ref null $type53))
  (local $local35 (ref null $type53))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument687)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global666)
   )
  )
  (local.set $local1
   (call $function188
    (struct.get $type48 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local30
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local31
   (global.get $string37)
  )
  (local.set $local32
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (local.set $local29
   (call $function39
    (struct.get $type53 1
     (ref.as_non_null
      (local.get $local32)
     )
    )
    (ref.as_non_null
     (local.get $local30)
    )
    (ref.as_non_null
     (local.get $local31)
    )
   )
  )
  (local.set $local28
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local28)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type163))
   (if (result i32)
    (local.get $local29)
    (then
     (if
      (i32.eqz
       (local.get $local28)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local29)
    )
    (else
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local33
      (ref.as_non_null
       (local.get $local1)
      )
     )
     (local.set $local34
      (global.get $string38)
     )
     (local.set $local35
      (ref.as_non_null
       (global.get $global103)
      )
     )
     (call $function39
      (struct.get $type53 1
       (ref.as_non_null
        (local.get $local35)
       )
      )
      (ref.as_non_null
       (local.get $local33)
      )
      (ref.as_non_null
       (local.get $local34)
      )
     )
    )
   )
   (then
    (local.set $local27
     (i32.const 1)
    )
    (local.set $local26
     (struct.new $type15
      (i32.const 1)
      (local.get $local27)
     )
    )
    (struct.new $type164
     (i32.const 0)
     (ref.as_non_null
      (local.get $local26)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local20
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local21
     (global.get $string35)
    )
    (local.set $local22
     (ref.as_non_null
      (global.get $global103)
     )
    )
    (local.set $local19
     (call $function39
      (struct.get $type53 1
       (ref.as_non_null
        (local.get $local22)
       )
      )
      (ref.as_non_null
       (local.get $local20)
      )
      (ref.as_non_null
       (local.get $local21)
      )
     )
    )
    (local.set $local18
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local18)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type163))
     (if (result i32)
      (local.get $local19)
      (then
       (if
        (i32.eqz
         (local.get $local18)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local19)
      )
      (else
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local23
        (ref.as_non_null
         (local.get $local1)
        )
       )
       (local.set $local24
        (global.get $string36)
       )
       (local.set $local25
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (call $function39
        (struct.get $type53 1
         (ref.as_non_null
          (local.get $local25)
         )
        )
        (ref.as_non_null
         (local.get $local23)
        )
        (ref.as_non_null
         (local.get $local24)
        )
       )
      )
     )
     (then
      (local.set $local17
       (i32.const 0)
      )
      (local.set $local16
       (struct.new $type15
        (i32.const 1)
        (local.get $local17)
       )
      )
      (struct.new $type164
       (i32.const 0)
       (ref.as_non_null
        (local.get $local16)
       )
      )
     )
     (else
      (local.set $local6
       (ref.as_non_null
        (local.get $argument687)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global308)
       )
      )
      (local.set $local5
       (call $function98
        (struct.get $type96 1
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (ref.as_non_null
         (local.get $local6)
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (if (result (ref $type163))
       (i32.eq
        (struct.get $type92 0
         (ref.as_non_null
          (local.get $local5)
         )
        )
        (i32.const 1)
       )
       (then
        (if
         (i32.eqz
          (local.get $local4)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local13
         (struct.get $type94 1
          (ref.cast (ref $type94)
           (ref.as_non_null
            (local.get $local5)
           )
          )
         )
        )
        (local.set $local12
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local12)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local15
         (ref.as_non_null
          (local.get $local13)
         )
        )
        (local.set $local14
         (struct.new $type23
          (i32.const 5)
          (ref.as_non_null
           (local.get $local15)
          )
         )
        )
        (struct.new $type164
         (i32.const 0)
         (ref.as_non_null
          (local.get $local14)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local4)
         )
         (then
          (unreachable)
         )
        )
        (if (result (ref $type163))
         (i32.eq
          (struct.get $type92 0
           (ref.as_non_null
            (local.get $local5)
           )
          )
          (i32.const 2)
         )
         (then
          (if
           (i32.eqz
            (local.get $local4)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local10
           (struct.get $type95 1
            (ref.cast (ref $type95)
             (ref.as_non_null
              (local.get $local5)
             )
            )
           )
          )
          (local.set $local9
           (i32.const 1)
          )
          (if
           (i32.eqz
            (local.get $local9)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local11
           (ref.as_non_null
            (local.get $local10)
           )
          )
          (struct.new $type170
           (i32.const 6)
           (ref.as_non_null
            (local.get $local11)
           )
          )
         )
         (else
          (local.set $local8
           (global.get $string34)
          )
          (struct.new $type170
           (i32.const 6)
           (ref.as_non_null
            (local.get $local8)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function195 (type $call172) (param $environment eqref) (param $argument698 (ref $type18)) (result (ref $type163))
  (local $local0 i32)
  (local $local4 i32)
  (local $local7 i32)
  (local $local1 (ref null $type101))
  (local $local2 (ref null $type18))
  (local $local5 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local10 (ref null $type18))
  (local $local11 (ref null $type18))
  (local $local3 (ref null $type105))
  (local $local8 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local12 (ref null $type53))
  (local.set $local10
   (ref.as_non_null
    (local.get $argument698)
   )
  )
  (local.set $local11
   (global.get $string39)
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (if (result (ref $type163))
   (call $function39
    (struct.get $type53 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local10)
    )
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (then
    (global.get $empty167)
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument698)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (global.get $global347)
     )
    )
    (local.set $local1
     (call $function103
      (struct.get $type105 1
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type163))
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local8
       (struct.get $type103 1
        (ref.cast (ref $type103)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local7
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local7)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local9
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (struct.new $type164
       (i32.const 0)
       (ref.as_non_null
        (local.get $local9)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result (ref $type163))
       (i32.eq
        (struct.get $type101 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 2)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local5
         (struct.get $type104 1
          (ref.cast (ref $type104)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local4
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local4)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local6
         (ref.as_non_null
          (local.get $local5)
         )
        )
        (struct.new $type170
         (i32.const 6)
         (ref.as_non_null
          (local.get $local6)
         )
        )
       )
       (else
        (unreachable)
       )
      )
     )
    )
   )
  )
 )
 (func $function196 (type $call190) (param $environment eqref) (param $argument703 (ref $type121)) (param $argument704 (ref $type163)) (result (ref $type101))
  (local $local0 i32)
  (local $local4 i32)
  (local $local9 i32)
  (local $local15 i32)
  (local $local18 i32)
  (local $local10 i64)
  (local $local12 i64)
  (local $local1 (ref null $type163))
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type18))
  (local $local5 (ref null $type18))
  (local $local7 (ref null $type18))
  (local $local16 (ref null $type18))
  (local $local17 (ref null $type18))
  (local $local6 (ref null $type121))
  (local $local11 (ref null $type121))
  (local $local8 (ref null $type191))
  (local $local13 (ref null $type12))
  (local $local14 (ref null $type192))
  (local $local19 (ref null $type13))
  (local $local20 (ref null $type13))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument704)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type101))
   (i32.eq
    (struct.get $type163 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (struct.get $type164 1
      (ref.cast (ref $type164)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local18
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local18)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local20
     (ref.as_non_null
      (local.get $local19)
     )
    )
    (struct.new $type103
     (i32.const 1)
     (ref.as_non_null
      (local.get $local20)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type163 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (global.get $empty102)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result (ref $type101))
       (i32.eq
        (struct.get $type163 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 6)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local16
         (struct.get $type170 1
          (ref.cast (ref $type170)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local15
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local15)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local17
         (ref.as_non_null
          (local.get $local16)
         )
        )
        (struct.new $type104
         (i32.const 2)
         (ref.as_non_null
          (local.get $local17)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (if (result (ref $type101))
         (i32.eq
          (struct.get $type163 0
           (ref.as_non_null
            (local.get $local1)
           )
          )
          (i32.const 4)
         )
         (then
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local10
           (struct.get $type168 1
            (ref.cast (ref $type168)
             (ref.as_non_null
              (local.get $local1)
             )
            )
           )
          )
          (local.set $local9
           (i32.const 1)
          )
          (local.set $local11
           (ref.as_non_null
            (local.get $argument703)
           )
          )
          (if
           (i32.eqz
            (local.get $local9)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local12
           (local.get $local10)
          )
          (local.set $local13
           (ref.null none)
          )
          (if
           (i32.eqz
            (global.get $ready709)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local14
           (ref.as_non_null
            (global.get $global709)
           )
          )
          (return_call $function197
           (struct.get $type192 1
            (ref.as_non_null
             (local.get $local14)
            )
           )
           (ref.as_non_null
            (local.get $local11)
           )
           (local.get $local12)
           (local.get $local13)
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (if (result (ref $type101))
           (i32.eq
            (struct.get $type163 0
             (ref.as_non_null
              (local.get $local1)
             )
            )
            (i32.const 5)
           )
           (then
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local5
             (struct.get $type169 1
              (ref.cast (ref $type169)
               (ref.as_non_null
                (local.get $local1)
               )
              )
             )
            )
            (local.set $local4
             (i32.const 1)
            )
            (local.set $local6
             (ref.as_non_null
              (local.get $argument703)
             )
            )
            (if
             (i32.eqz
              (local.get $local4)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local7
             (ref.as_non_null
              (local.get $local5)
             )
            )
            (if
             (i32.eqz
              (global.get $ready780)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local8
             (ref.as_non_null
              (global.get $global780)
             )
            )
            (return_call $function212
             (struct.get $type191 1
              (ref.as_non_null
               (local.get $local8)
              )
             )
             (ref.as_non_null
              (local.get $local6)
             )
             (ref.as_non_null
              (local.get $local7)
             )
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (if (result (ref $type101))
             (i32.eq
              (struct.get $type163 0
               (ref.as_non_null
                (local.get $local1)
               )
              )
              (i32.const 2)
             )
             (then
              (local.set $local3
               (global.get $string41)
              )
              (struct.new $type104
               (i32.const 2)
               (ref.as_non_null
                (local.get $local3)
               )
              )
             )
             (else
              (local.set $local2
               (global.get $string40)
              )
              (struct.new $type104
               (i32.const 2)
               (ref.as_non_null
                (local.get $local2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function197 (type $call192) (param $environment eqref) (param $argument710 (ref $type121)) (param $argument711 i64) (param $argument712 (ref null $type12)) (result (ref $type101))
  (local $local0 i32)
  (local $local4 i32)
  (local $local6 i32)
  (local $local16 i32)
  (local $local26 i32)
  (local $local34 i32)
  (local $local41 i32)
  (local $local9 i64)
  (local $local17 i64)
  (local $local19 i64)
  (local $local29 i64)
  (local $local43 i64)
  (local $local44 i64)
  (local $local46 i64)
  (local $local1 (ref null $type163))
  (local $local5 (ref null $type163))
  (local $local13 (ref null $type163))
  (local $local23 (ref null $type163))
  (local $local2 (ref null $type121))
  (local $local8 (ref null $type121))
  (local $local12 (ref null $type121))
  (local $local18 (ref null $type121))
  (local $local22 (ref null $type121))
  (local $local28 (ref null $type121))
  (local $local38 (ref null $type121))
  (local $local3 (ref null $type162))
  (local $local7 (ref null $type18))
  (local $local35 (ref null $type18))
  (local $local36 (ref null $type18))
  (local $local37 (ref null $type18))
  (local $local45 (ref null $type18))
  (local $local10 (ref null $type12))
  (local $local20 (ref null $type12))
  (local $local30 (ref null $type12))
  (local $local32 (ref null $type12))
  (local $local39 (ref null $type12))
  (local $local42 (ref null $type12))
  (local $local47 (ref null $type12))
  (local $local11 (ref null $type101))
  (local $local21 (ref null $type101))
  (local $local14 (ref null $type190))
  (local $local24 (ref null $type190))
  (local $local15 (ref null $type193))
  (local $local25 (ref null $type193))
  (local $local27 (ref null $type13))
  (local $local31 (ref null $type13))
  (local $local33 (ref null $type192))
  (local $local40 (ref null $type194))
  (local $local48 (ref null $type197))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument710)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (local.set $local1
   (call $function154
    (struct.get $type162 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type101))
   (i32.eq
    (struct.get $type163 0
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (i32.const 2)
   )
   (then
    (local.set $local46
     (local.get $argument711)
    )
    (local.set $local47
     (local.get $argument712)
    )
    (if
     (i32.eqz
      (global.get $ready715)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local48
     (ref.as_non_null
      (global.get $global715)
     )
    )
    (return_call $function198
     (struct.get $type197 1
      (ref.as_non_null
       (local.get $local48)
      )
     )
     (local.get $local46)
     (local.get $local47)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type163 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (i32.const 1)
     )
     (then
      (local.set $local45
       (global.get $string43)
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local45)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (if (result (ref $type101))
       (i32.eq
        (struct.get $type163 0
         (ref.as_non_null
          (local.get $local5)
         )
        )
        (i32.const 3)
       )
       (then
        (local.set $local43
         (local.get $argument711)
        )
        (local.set $local44
         (i64.const 0)
        )
        (if (result (ref $type101))
         (if (result i32)
          (i64.eq
           (local.get $local43)
           (local.get $local44)
          )
          (then
           (local.set $local42
            (local.get $argument712)
           )
           (local.set $local41
            (ref.is_null
             (local.get $local42)
            )
           )
           (i32.eqz
            (local.get $local41)
           )
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (local.set $local38
           (ref.as_non_null
            (local.get $argument710)
           )
          )
          (local.set $local39
           (local.get $argument712)
          )
          (if
           (i32.eqz
            (global.get $ready756)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local40
           (ref.as_non_null
            (global.get $global756)
           )
          )
          (return_call $function210
           (struct.get $type194 1
            (ref.as_non_null
             (local.get $local40)
            )
           )
           (ref.as_non_null
            (local.get $local38)
           )
           (local.get $local39)
          )
         )
         (else
          (local.set $local37
           (global.get $string42)
          )
          (struct.new $type104
           (i32.const 2)
           (ref.as_non_null
            (local.get $local37)
           )
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local4)
         )
         (then
          (unreachable)
         )
        )
        (if (result (ref $type101))
         (i32.eq
          (struct.get $type163 0
           (ref.as_non_null
            (local.get $local5)
           )
          )
          (i32.const 6)
         )
         (then
          (if
           (i32.eqz
            (local.get $local4)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local35
           (struct.get $type170 1
            (ref.cast (ref $type170)
             (ref.as_non_null
              (local.get $local5)
             )
            )
           )
          )
          (local.set $local34
           (i32.const 1)
          )
          (if
           (i32.eqz
            (local.get $local34)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local36
           (ref.as_non_null
            (local.get $local35)
           )
          )
          (struct.new $type104
           (i32.const 2)
           (ref.as_non_null
            (local.get $local36)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local4)
           )
           (then
            (unreachable)
           )
          )
          (if (result (ref $type101))
           (i32.eq
            (struct.get $type163 0
             (ref.as_non_null
              (local.get $local5)
             )
            )
            (i32.const 0)
           )
           (then
            (if
             (i32.eqz
              (local.get $local4)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local27
             (struct.get $type164 1
              (ref.cast (ref $type164)
               (ref.as_non_null
                (local.get $local5)
               )
              )
             )
            )
            (local.set $local26
             (i32.const 1)
            )
            (local.set $local28
             (ref.as_non_null
              (local.get $argument710)
             )
            )
            (local.set $local29
             (local.get $argument711)
            )
            (if
             (i32.eqz
              (local.get $local26)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local31
             (ref.as_non_null
              (local.get $local27)
             )
            )
            (local.set $local32
             (local.get $argument712)
            )
            (local.set $local30
             (struct.new $type12
              (ref.as_non_null
               (local.get $local31)
              )
              (local.get $local32)
             )
            )
            (if
             (i32.eqz
              (global.get $ready709)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local33
             (ref.as_non_null
              (global.get $global709)
             )
            )
            (return_call $function197
             (struct.get $type192 1
              (ref.as_non_null
               (local.get $local33)
              )
             )
             (ref.as_non_null
              (local.get $local28)
             )
             (local.get $local29)
             (local.get $local30)
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local4)
             )
             (then
              (unreachable)
             )
            )
            (if (result (ref $type101))
             (i32.eq
              (struct.get $type163 0
               (ref.as_non_null
                (local.get $local5)
               )
              )
              (i32.const 4)
             )
             (then
              (if
               (i32.eqz
                (local.get $local4)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local17
               (struct.get $type168 1
                (ref.cast (ref $type168)
                 (ref.as_non_null
                  (local.get $local5)
                 )
                )
               )
              )
              (local.set $local16
               (i32.const 1)
              )
              (local.set $local18
               (ref.as_non_null
                (local.get $argument710)
               )
              )
              (local.set $local19
               (local.get $argument711)
              )
              (local.set $local20
               (local.get $argument712)
              )
              (local.set $local22
               (ref.as_non_null
                (local.get $argument710)
               )
              )
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local23
               (ref.as_non_null
                (local.get $local1)
               )
              )
              (local.set $local24
               (ref.as_non_null
                (global.get $global702)
               )
              )
              (local.set $local21
               (call $function196
                (struct.get $type190 1
                 (ref.as_non_null
                  (local.get $local24)
                 )
                )
                (ref.as_non_null
                 (local.get $local22)
                )
                (ref.as_non_null
                 (local.get $local23)
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready770)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local25
               (ref.as_non_null
                (global.get $global770)
               )
              )
              (return_call $function211
               (struct.get $type193 1
                (ref.as_non_null
                 (local.get $local25)
                )
               )
               (ref.as_non_null
                (local.get $local18)
               )
               (local.get $local19)
               (local.get $local20)
               (ref.as_non_null
                (local.get $local21)
               )
              )
             )
             (else
              (if
               (i32.eqz
                (local.get $local4)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local7
               (struct.get $type169 1
                (ref.cast (ref $type169)
                 (ref.as_non_null
                  (local.get $local5)
                 )
                )
               )
              )
              (local.set $local6
               (i32.const 1)
              )
              (local.set $local8
               (ref.as_non_null
                (local.get $argument710)
               )
              )
              (local.set $local9
               (local.get $argument711)
              )
              (local.set $local10
               (local.get $argument712)
              )
              (local.set $local12
               (ref.as_non_null
                (local.get $argument710)
               )
              )
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local13
               (ref.as_non_null
                (local.get $local1)
               )
              )
              (local.set $local14
               (ref.as_non_null
                (global.get $global702)
               )
              )
              (local.set $local11
               (call $function196
                (struct.get $type190 1
                 (ref.as_non_null
                  (local.get $local14)
                 )
                )
                (ref.as_non_null
                 (local.get $local12)
                )
                (ref.as_non_null
                 (local.get $local13)
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready770)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local15
               (ref.as_non_null
                (global.get $global770)
               )
              )
              (return_call $function211
               (struct.get $type193 1
                (ref.as_non_null
                 (local.get $local15)
                )
               )
               (ref.as_non_null
                (local.get $local8)
               )
               (local.get $local9)
               (local.get $local10)
               (ref.as_non_null
                (local.get $local11)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function198 (type $call197) (param $environment eqref) (param $argument716 i64) (param $argument717 (ref null $type12)) (result (ref $type101))
  (local $local0 (ref null $type12))
  (local $local4 (ref null $type12))
  (local $local5 (ref null $type12))
  (local $local11 (ref null $type12))
  (local $local1 (ref null $type198))
  (local $local2 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local12 (ref null $type13))
  (local $local3 (ref null $type34))
  (local $local6 (ref null $type196))
  (local $local7 (ref null $type38))
  (local $local13 (ref null $type195))
  (local $local8 i64)
  (local $local9 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local.set $local14
   (local.get $argument716)
  )
  (local.set $local15
   (i64.const 0)
  )
  (if (result (ref $type101))
   (i64.eq
    (local.get $local14)
    (local.get $local15)
   )
   (then
    (local.set $local11
     (local.get $argument717)
    )
    (local.set $local12
     (global.get $empty14)
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global718)
     )
    )
    (local.set $local10
     (call $function199
      (struct.get $type195 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (local.get $local11)
      (ref.as_non_null
       (local.get $local12)
      )
     )
    )
    (struct.new $type103
     (i32.const 1)
     (ref.as_non_null
      (local.get $local10)
     )
    )
   )
   (else
    (local.set $local8
     (local.get $argument716)
    )
    (local.set $local9
     (i64.const 1)
    )
    (if (result (ref $type101))
     (i64.eq
      (local.get $local8)
      (local.get $local9)
     )
     (then
      (local.set $local5
       (local.get $argument717)
      )
      (local.set $local6
       (ref.as_non_null
        (global.get $global721)
       )
      )
      (local.set $local4
       (call $function200
        (struct.get $type196 1
         (ref.as_non_null
          (local.get $local6)
         )
        )
        (local.get $local5)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global726)
       )
      )
      (local.set $local3
       (call $function202
        (struct.get $type38 1
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (local.get $local4)
       )
      )
      (local.set $local2
       (struct.new $type33
        (i32.const 7)
        (ref.as_non_null
         (local.get $local3)
        )
       )
      )
      (struct.new $type103
       (i32.const 1)
       (ref.as_non_null
        (local.get $local2)
       )
      )
     )
     (else
      (local.set $local0
       (local.get $argument717)
      )
      (if
       (i32.eqz
        (global.get $ready737)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local1
       (ref.as_non_null
        (global.get $global737)
       )
      )
      (return_call $function206
       (struct.get $type198 1
        (ref.as_non_null
         (local.get $local1)
        )
       )
       (local.get $local0)
      )
     )
    )
   )
  )
 )
 (func $function199 (type $call195) (param $environment eqref) (param $argument719 (ref null $type12)) (param $argument720 (ref $type13)) (result (ref $type13))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local4 (ref null $type12))
  (local $local8 (ref null $type12))
  (local $local2 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local5 (ref null $type13))
  (local $local6 (ref null $type106))
  (local $local7 (ref null $type195))
  (local.set $local8
   (local.get $argument719)
  )
  (if (result (ref $type13))
   (ref.is_null
    (local.get $local8)
   )
   (then
    (ref.as_non_null
     (local.get $argument720)
    )
   )
   (else
    (local.set $local1
     (local.get $argument719)
    )
    (local.set $local0
     (struct.get $type12 1
      (local.get $local1)
     )
    )
    (local.set $local4
     (local.get $argument719)
    )
    (local.set $local3
     (struct.get $type12 0
      (local.get $local4)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $argument720)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (local.set $local2
     (call $function104
      (struct.get $type106 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (ref.as_non_null
       (local.get $local5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready718)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global718)
     )
    )
    (return_call $function199
     (struct.get $type195 1
      (ref.as_non_null
       (local.get $local7)
      )
     )
     (local.get $local0)
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
 )
 (func $function200 (type $call196) (param $environment eqref) (param $argument722 (ref null $type12)) (result (ref null $type12))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument722)
  )
  (local.set $local1
   (ref.null none)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function201
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function201 (param $capture723 i32) (param $initialized723 i32) (param $argument724 (ref null $type12)) (param $argument725 (ref null $type12)) (result (ref null $type12))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local2 (ref null $type12))
  (local $local4 (ref null $type12))
  (local $local5 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local3 (ref null $type13))
  (local.set $local6
   (local.get $argument724)
  )
  (if (result (ref null $type12))
   (ref.is_null
    (local.get $local6)
   )
   (then
    (local.get $argument725)
   )
   (else
    (local.set $local1
     (local.get $argument724)
    )
    (local.set $local0
     (struct.get $type12 1
      (local.get $local1)
     )
    )
    (local.set $local4
     (local.get $argument724)
    )
    (local.set $local3
     (struct.get $type12 0
      (local.get $local4)
     )
    )
    (local.set $local5
     (local.get $argument725)
    )
    (local.set $local2
     (struct.new $type12
      (ref.as_non_null
       (local.get $local3)
      )
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized723)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture723)
    )
    (return_call $function201
     (local.get $capture723)
     (local.get $initialized723)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function202 (type $call38) (param $environment eqref) (param $argument727 (ref null $type12)) (result (ref $type34))
  (local $local0 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local2 i64)
  (local $local8 i64)
  (local $local1 (ref null $type34))
  (local $local3 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local7 (ref null $type12))
  (local $local11 (ref null $type12))
  (local $local4 (ref null $type41))
  (local $local5 (ref null $type13))
  (local.set $local11
   (local.get $argument727)
  )
  (if (result (ref $type34))
   (ref.is_null
    (local.get $local11)
   )
   (then
    (array.new_fixed $type34 0)
   )
   (else
    (local.set $local3
     (local.get $argument727)
    )
    (if
     (i32.eqz
      (global.get $ready729)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global729)
     )
    )
    (local.set $local2
     (call $function203
      (struct.get $type41 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (local.get $local3)
     )
    )
    (local.set $local6
     (local.get $argument727)
    )
    (local.set $local5
     (struct.get $type12 0
      (local.get $local6)
     )
    )
    (local.set $local1
     (array.new $type34
      (ref.as_non_null
       (local.get $local5)
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local2)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local7
     (local.get $argument727)
    )
    (local.set $local8
     (i64.const 0)
    )
    (local.set $local10
     (i32.const 0)
    )
    (local.set $local9
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local9)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local10)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function205
     (ref.as_non_null
      (local.get $local1)
     )
     (local.get $local10)
     (local.get $local9)
     (local.get $local7)
     (local.get $local8)
    )
   )
  )
 )
 (func $function203 (type $call41) (param $environment eqref) (param $argument730 (ref null $type12)) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument730)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function204
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function204 (param $capture731 i32) (param $initialized731 i32) (param $argument732 (ref null $type12)) (param $argument733 i64) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local7 (ref null $type12))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local.set $local7
   (local.get $argument732)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local7)
   )
   (then
    (local.get $argument733)
   )
   (else
    (local.set $local5
     (local.get $argument733)
    )
    (local.set $local6
     (i64.const 4294967295)
    )
    (if (result i64)
     (i64.eq
      (local.get $local5)
      (local.get $local6)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local1
       (local.get $argument732)
      )
      (local.set $local0
       (struct.get $type12 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument733)
      )
      (local.set $local4
       (i64.const 1)
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized731)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture731)
      )
      (return_call $function204
       (local.get $capture731)
       (local.get $initialized731)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function205 (param $capture728 (ref $type34)) (param $capture734 i32) (param $initialized734 i32) (param $argument735 (ref null $type12)) (param $argument736 i64) (result (ref $type34))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local8 (ref null $type12))
  (local $local9 (ref null $type12))
  (local $local5 (ref null $type34))
  (local $local7 (ref null $type13))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local.set $local9
   (local.get $argument735)
  )
  (if (result (ref $type34))
   (ref.is_null
    (local.get $local9)
   )
   (then
    (ref.as_non_null
     (local.get $capture728)
    )
   )
   (else
    (local.set $local5
     (ref.as_non_null
      (local.get $capture728)
     )
    )
    (local.set $local6
     (local.get $argument736)
    )
    (local.set $local8
     (local.get $argument735)
    )
    (local.set $local7
     (struct.get $type12 0
      (local.get $local8)
     )
    )
    (array.set $type34
     (ref.as_non_null
      (local.get $local5)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local6)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local6)
      )
     )
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument735)
    )
    (local.set $local0
     (struct.get $type12 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument736)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized734)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture734)
    )
    (return_call $function205
     (ref.as_non_null
      (local.get $capture728)
     )
     (local.get $capture734)
     (local.get $initialized734)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function206 (type $call198) (param $environment eqref) (param $argument738 (ref null $type12)) (result (ref $type101))
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local2 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local7 (ref null $type36))
  (local $local9 (ref null $type54))
  (local $local11 (ref null $type199))
  (local.set $local2
   (local.get $argument738)
  )
  (local.set $local3
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (local.set $local1
   (call $function207
    (local.get $local5)
    (local.get $local4)
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local6
   (local.get $argument738)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (local.get $local1)
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (local.set $local7
   (call $function41
    (struct.get $type54 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (local.get $local8)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (local.get $local1)
  )
  (if
   (i32.eqz
    (global.get $ready743)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global743)
   )
  )
  (return_call $function208
   (struct.get $type199 1
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (local.get $local6)
   (ref.as_non_null
    (local.get $local7)
   )
   (local.get $local10)
  )
 )
 (func $function207 (param $capture740 i32) (param $initialized740 i32) (param $argument741 (ref null $type12)) (param $argument742 i64) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local5 (ref null $type12))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local.set $local5
   (local.get $argument741)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local5)
   )
   (then
    (local.get $argument742)
   )
   (else
    (local.set $local1
     (local.get $argument741)
    )
    (local.set $local0
     (struct.get $type12 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument742)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized740)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture740)
    )
    (return_call $function207
     (local.get $capture740)
     (local.get $initialized740)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function208 (type $call199) (param $environment eqref) (param $argument744 (ref null $type12)) (param $argument745 (ref $type36)) (param $argument746 i64) (result (ref $type101))
  (local $local0 i32)
  (local $local18 i32)
  (local $local19 i32)
  (local $local1 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local2 (ref null $type13))
  (local $local24 (ref null $type13))
  (local $local3 (ref null $type12))
  (local $local5 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local26 (ref null $type12))
  (local $local4 (ref null $type109))
  (local $local7 (ref null $type36))
  (local $local12 (ref null $type36))
  (local $local25 (ref null $type36))
  (local $local11 (ref null $type199))
  (local $local17 (ref null $type18))
  (local.set $local26
   (local.get $argument744)
  )
  (if (result (ref $type101))
   (ref.is_null
    (local.get $local26)
   )
   (then
    (local.set $local25
     (ref.as_non_null
      (local.get $argument745)
     )
    )
    (local.set $local24
     (struct.new $type35
      (i32.const 8)
      (ref.as_non_null
       (local.get $local25)
      )
     )
    )
    (struct.new $type103
     (i32.const 1)
     (ref.as_non_null
      (local.get $local24)
     )
    )
   )
   (else
    (local.set $local3
     (local.get $argument744)
    )
    (local.set $local2
     (struct.get $type12 0
      (local.get $local3)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global748)
     )
    )
    (local.set $local1
     (call $function209
      (struct.get $type109 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local20
     (local.get $local1)
    )
    (local.set $local21
     (i64.const 0)
    )
    (local.set $local19
     (i64.lt_s
      (local.get $local20)
      (local.get $local21)
     )
    )
    (local.set $local18
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local18)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (if (result i32)
      (local.get $local19)
      (then
       (if
        (i32.eqz
         (local.get $local18)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local19)
      )
      (else
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local22
        (local.get $local1)
       )
       (local.set $local23
        (i64.const 255)
       )
       (i64.gt_s
        (local.get $local22)
        (local.get $local23)
       )
      )
     )
     (then
      (local.set $local17
       (global.get $string44)
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local17)
       )
      )
     )
     (else
      (local.set $local12
       (ref.as_non_null
        (local.get $argument745)
       )
      )
      (local.set $local14
       (local.get $argument746)
      )
      (local.set $local15
       (i64.const 1)
      )
      (local.set $local13
       (i64.sub
        (local.get $local14)
        (local.get $local15)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local16
       (local.get $local1)
      )
      (if
       (i32.ne
        (struct.get $type36 0
         (ref.as_non_null
          (local.get $local12)
         )
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type37
       (struct.get $type36 1
        (ref.as_non_null
         (local.get $local12)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.get $local13)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $local13)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.get $local16)
          (i64.const 255)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $local16)
        )
       )
      )
      (drop
       (i32.const 0)
      )
      (local.set $local6
       (local.get $argument744)
      )
      (local.set $local5
       (struct.get $type12 1
        (local.get $local6)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (local.get $argument745)
       )
      )
      (local.set $local9
       (local.get $argument746)
      )
      (local.set $local10
       (i64.const 1)
      )
      (local.set $local8
       (i64.sub
        (local.get $local9)
        (local.get $local10)
       )
      )
      (if
       (i32.eqz
        (global.get $ready743)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local11
       (ref.as_non_null
        (global.get $global743)
       )
      )
      (return_call $function208
       (struct.get $type199 1
        (ref.as_non_null
         (local.get $local11)
        )
       )
       (local.get $local5)
       (ref.as_non_null
        (local.get $local7)
       )
       (local.get $local8)
      )
     )
    )
   )
  )
 )
 (func $function209 (type $call109) (param $environment eqref) (param $argument749 (ref $type13)) (result i64)
  (local $local0 i32)
  (local $local3 i32)
  (local $local5 i32)
  (local $local7 i32)
  (local $local9 i32)
  (local $local8 f64)
  (local $local10 i64)
  (local $local1 (ref null $type24))
  (local $local2 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local4 (ref null $type28))
  (local $local6 (ref null $type28))
  (local $local12 (ref null $type110))
  (local.set $local11
   (ref.as_non_null
    (local.get $argument749)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global376)
   )
  )
  (if (result i64)
   (call $function110
    (struct.get $type110 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (then
    (local.set $local2
     (ref.as_non_null
      (local.get $argument749)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (i32.const 5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local1
     (struct.get $type23 1
      (ref.cast (ref $type23)
       (ref.as_non_null
        (local.get $local2)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i32.eq
      (struct.get $type24 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local10
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local9
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local9)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local10)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i64)
       (i32.eq
        (struct.get $type24 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 1)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local8
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local7
         (i32.const 1)
        )
        (i64.const -1)
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local4
         (struct.get $type27 1
          (ref.cast (ref $type27)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local3
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local6
         (struct.get $type27 2
          (ref.cast (ref $type27)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local5
         (i32.const 1)
        )
        (i64.const -1)
       )
      )
     )
    )
   )
   (else
    (i64.const -1)
   )
  )
 )
 (func $function210 (type $call194) (param $environment eqref) (param $argument757 (ref $type121)) (param $argument758 (ref null $type12)) (result (ref $type101))
  (local $local0 i32)
  (local $local4 i32)
  (local $local8 i32)
  (local $local10 i32)
  (local $local14 i32)
  (local $local17 i32)
  (local $local22 i32)
  (local $local25 i32)
  (local $local18 i64)
  (local $local1 (ref null $type101))
  (local $local2 (ref null $type121))
  (local $local12 (ref null $type121))
  (local $local3 (ref null $type148))
  (local $local5 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local7 (ref null $type18))
  (local $local15 (ref null $type18))
  (local $local16 (ref null $type18))
  (local $local19 (ref null $type18))
  (local $local20 (ref null $type18))
  (local $local21 (ref null $type18))
  (local $local24 (ref null $type18))
  (local $local26 (ref null $type18))
  (local $local27 (ref null $type18))
  (local $local9 (ref null $type13))
  (local $local23 (ref null $type13))
  (local $local28 (ref null $type13))
  (local $local30 (ref null $type13))
  (local $local11 (ref null $type163))
  (local $local13 (ref null $type162))
  (local $local29 (ref null $type12))
  (local $local31 (ref null $type195))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument757)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local1
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type101))
   (i32.eq
    (struct.get $type101 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (struct.get $type103 1
      (ref.cast (ref $type103)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local8
     (i32.const 1)
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $argument757)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global527)
     )
    )
    (local.set $local11
     (call $function154
      (struct.get $type162 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local12)
      )
     )
    )
    (local.set $local10
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type163 0
       (ref.as_non_null
        (local.get $local11)
       )
      )
      (i32.const 2)
     )
     (then
      (local.set $local29
       (local.get $argument758)
      )
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local30
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (if
       (i32.eqz
        (global.get $ready718)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local31
       (ref.as_non_null
        (global.get $global718)
       )
      )
      (local.set $local28
       (call $function199
        (struct.get $type195 1
         (ref.as_non_null
          (local.get $local31)
         )
        )
        (local.get $local29)
        (ref.as_non_null
         (local.get $local30)
        )
       )
      )
      (struct.new $type103
       (i32.const 1)
       (ref.as_non_null
        (local.get $local28)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local10)
       )
       (then
        (unreachable)
       )
      )
      (if (result (ref $type101))
       (i32.eq
        (struct.get $type163 0
         (ref.as_non_null
          (local.get $local11)
         )
        )
        (i32.const 6)
       )
       (then
        (if
         (i32.eqz
          (local.get $local10)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local26
         (struct.get $type170 1
          (ref.cast (ref $type170)
           (ref.as_non_null
            (local.get $local11)
           )
          )
         )
        )
        (local.set $local25
         (i32.const 1)
        )
        (if
         (i32.eqz
          (local.get $local25)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local27
         (ref.as_non_null
          (local.get $local26)
         )
        )
        (struct.new $type104
         (i32.const 2)
         (ref.as_non_null
          (local.get $local27)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (local.get $local10)
         )
         (then
          (unreachable)
         )
        )
        (if (result (ref $type101))
         (i32.eq
          (struct.get $type163 0
           (ref.as_non_null
            (local.get $local11)
           )
          )
          (i32.const 0)
         )
         (then
          (if
           (i32.eqz
            (local.get $local10)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local23
           (struct.get $type164 1
            (ref.cast (ref $type164)
             (ref.as_non_null
              (local.get $local11)
             )
            )
           )
          )
          (local.set $local22
           (i32.const 1)
          )
          (local.set $local24
           (global.get $string50)
          )
          (struct.new $type104
           (i32.const 2)
           (ref.as_non_null
            (local.get $local24)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local10)
           )
           (then
            (unreachable)
           )
          )
          (if (result (ref $type101))
           (i32.eq
            (struct.get $type163 0
             (ref.as_non_null
              (local.get $local11)
             )
            )
            (i32.const 1)
           )
           (then
            (local.set $local21
             (global.get $string49)
            )
            (struct.new $type104
             (i32.const 2)
             (ref.as_non_null
              (local.get $local21)
             )
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local10)
             )
             (then
              (unreachable)
             )
            )
            (if (result (ref $type101))
             (i32.eq
              (struct.get $type163 0
               (ref.as_non_null
                (local.get $local11)
               )
              )
              (i32.const 3)
             )
             (then
              (local.set $local20
               (global.get $string48)
              )
              (struct.new $type104
               (i32.const 2)
               (ref.as_non_null
                (local.get $local20)
               )
              )
             )
             (else
              (if
               (i32.eqz
                (local.get $local10)
               )
               (then
                (unreachable)
               )
              )
              (if (result (ref $type101))
               (i32.eq
                (struct.get $type163 0
                 (ref.as_non_null
                  (local.get $local11)
                 )
                )
                (i32.const 4)
               )
               (then
                (if
                 (i32.eqz
                  (local.get $local10)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local18
                 (struct.get $type168 1
                  (ref.cast (ref $type168)
                   (ref.as_non_null
                    (local.get $local11)
                   )
                  )
                 )
                )
                (local.set $local17
                 (i32.const 1)
                )
                (local.set $local19
                 (global.get $string47)
                )
                (struct.new $type104
                 (i32.const 2)
                 (ref.as_non_null
                  (local.get $local19)
                 )
                )
               )
               (else
                (if
                 (i32.eqz
                  (local.get $local10)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local15
                 (struct.get $type169 1
                  (ref.cast (ref $type169)
                   (ref.as_non_null
                    (local.get $local11)
                   )
                  )
                 )
                )
                (local.set $local14
                 (i32.const 1)
                )
                (local.set $local16
                 (global.get $string46)
                )
                (struct.new $type104
                 (i32.const 2)
                 (ref.as_non_null
                  (local.get $local16)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (local.set $local7
       (global.get $string45)
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local7)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type104 1
        (ref.cast (ref $type104)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local6)
       )
      )
     )
    )
   )
  )
 )
 (func $function211 (type $call193) (param $environment eqref) (param $argument771 (ref $type121)) (param $argument772 i64) (param $argument773 (ref null $type12)) (param $argument774 (ref $type101)) (result (ref $type101))
  (local $local0 i32)
  (local $local2 i32)
  (local $local5 i32)
  (local $local8 i64)
  (local $local1 (ref null $type101))
  (local $local3 (ref null $type18))
  (local $local4 (ref null $type18))
  (local $local6 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local7 (ref null $type121))
  (local $local9 (ref null $type12))
  (local $local11 (ref null $type12))
  (local $local12 (ref null $type192))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument774)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type101))
   (i32.eq
    (struct.get $type101 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (struct.get $type103 1
      (ref.cast (ref $type103)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local5
     (i32.const 1)
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument771)
     )
    )
    (local.set $local8
     (local.get $argument772)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (local.set $local11
     (local.get $argument773)
    )
    (local.set $local9
     (struct.new $type12
      (ref.as_non_null
       (local.get $local10)
      )
      (local.get $local11)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global709)
     )
    )
    (return_call $function197
     (struct.get $type192 1
      (ref.as_non_null
       (local.get $local12)
      )
     )
     (ref.as_non_null
      (local.get $local7)
     )
     (local.get $local8)
     (local.get $local9)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 2)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local3
       (struct.get $type104 1
        (ref.cast (ref $type104)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local2
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local4
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local4)
       )
      )
     )
     (else
      (unreachable)
     )
    )
   )
  )
 )
 (func $function212 (type $call191) (param $environment eqref) (param $argument781 (ref $type121)) (param $argument782 (ref $type18)) (result (ref $type101))
  (local $local0 i32)
  (local $local4 i32)
  (local $local8 i32)
  (local $local1 (ref null $type101))
  (local $local2 (ref null $type121))
  (local $local3 (ref null $type148))
  (local $local5 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local7 (ref null $type18))
  (local $local13 (ref null $type18))
  (local $local9 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local15 (ref null $type13))
  (local $local16 (ref null $type13))
  (local $local17 (ref null $type13))
  (local $local12 (ref null $type22))
  (local $local14 (ref null $type84))
  (local $local18 (ref null $type106))
  (local $local19 (ref null $type106))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument781)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local1
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type101))
   (i32.eq
    (struct.get $type101 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (struct.get $type103 1
      (ref.cast (ref $type103)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local8
     (i32.const 1)
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $argument782)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global258)
     )
    )
    (local.set $local12
     (call $function84
      (struct.get $type84 1
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (ref.as_non_null
       (local.get $local13)
      )
     )
    )
    (local.set $local11
     (struct.new $type21
      (i32.const 4)
      (ref.as_non_null
       (local.get $local12)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local8)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (local.set $local17
     (global.get $empty14)
    )
    (local.set $local18
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (local.set $local15
     (call $function104
      (struct.get $type106 1
       (ref.as_non_null
        (local.get $local18)
       )
      )
      (ref.as_non_null
       (local.get $local16)
      )
      (ref.as_non_null
       (local.get $local17)
      )
     )
    )
    (local.set $local19
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (local.set $local10
     (call $function104
      (struct.get $type106 1
       (ref.as_non_null
        (local.get $local19)
       )
      )
      (ref.as_non_null
       (local.get $local11)
      )
      (ref.as_non_null
       (local.get $local15)
      )
     )
    )
    (struct.new $type103
     (i32.const 1)
     (ref.as_non_null
      (local.get $local10)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (local.set $local7
       (global.get $string51)
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local7)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type104 1
        (ref.cast (ref $type104)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (struct.new $type104
       (i32.const 2)
       (ref.as_non_null
        (local.get $local6)
       )
      )
     )
    )
   )
  )
 )
 (func $function213 (type $call200) (param $environment eqref) (param $argument787 (ref $type18)) (result (ref $type24))
  (local $local0 (ref null $type92))
  (local $local1 (ref null $type18))
  (local $local2 (ref null $type96))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument787)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global308)
   )
  )
  (local.set $local0
   (call $function98
    (struct.get $type96 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type92 0
     (ref.as_non_null
      (local.get $local0)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type94 1
   (ref.cast (ref $type94)
    (ref.as_non_null
     (local.get $local0)
    )
   )
  )
 )
 (func $function214 (type $call8) (param $environment eqref) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local8 i32)
  (local $local13 i32)
  (local $local18 i32)
  (local $local23 i32)
  (local $local28 i32)
  (local $local33 i32)
  (local $local50 i32)
  (local $local66 i32)
  (local $local73 i32)
  (local $local3 i64)
  (local $local7 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local38 i64)
  (local $local39 i64)
  (local $local46 i64)
  (local $local47 i64)
  (local $local1 (ref null $type13))
  (local $local5 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local14 (ref null $type13))
  (local $local15 (ref null $type13))
  (local $local16 (ref null $type13))
  (local $local25 (ref null $type13))
  (local $local26 (ref null $type13))
  (local $local29 (ref null $type13))
  (local $local31 (ref null $type13))
  (local $local34 (ref null $type13))
  (local $local36 (ref null $type13))
  (local $local42 (ref null $type13))
  (local $local44 (ref null $type13))
  (local $local51 (ref null $type13))
  (local $local53 (ref null $type13))
  (local $local55 (ref null $type13))
  (local $local56 (ref null $type13))
  (local $local59 (ref null $type13))
  (local $local61 (ref null $type13))
  (local $local67 (ref null $type13))
  (local $local68 (ref null $type13))
  (local $local69 (ref null $type13))
  (local $local70 (ref null $type13))
  (local $local74 (ref null $type13))
  (local $local75 (ref null $type13))
  (local $local76 (ref null $type13))
  (local $local77 (ref null $type13))
  (local $local80 (ref null $type13))
  (local $local81 (ref null $type13))
  (local $local2 (ref null $type24))
  (local $local6 (ref null $type24))
  (local $local12 (ref null $type106))
  (local $local17 (ref null $type106))
  (local $local71 (ref null $type106))
  (local $local78 (ref null $type106))
  (local $local19 (ref null $type36))
  (local $local35 (ref null $type36))
  (local $local37 (ref null $type36))
  (local $local43 (ref null $type36))
  (local $local45 (ref null $type36))
  (local $local22 (ref null $type55))
  (local $local40 (ref null $type55))
  (local $local48 (ref null $type55))
  (local $local24 (ref null $type34))
  (local $local52 (ref null $type34))
  (local $local54 (ref null $type34))
  (local $local60 (ref null $type34))
  (local $local62 (ref null $type34))
  (local $local63 (ref null $type34))
  (local $local27 (ref null $type11))
  (local $local57 (ref null $type11))
  (local $local30 (ref null $type18))
  (local $local32 (ref null $type111))
  (local $local41 (ref null $type111))
  (local $local49 (ref null $type111))
  (local $local58 (ref null $type111))
  (local $local65 (ref null $type111))
  (local $local72 (ref null $type111))
  (local $local79 (ref null $type111))
  (local $local82 (ref null $type111))
  (local $local64 (ref null $type42))
  (local.set $local3
   (i64.const 1)
  )
  (local.set $local2
   (struct.new $type25
    (i32.const 0)
    (local.get $local3)
   )
  )
  (local.set $local1
   (struct.new $type23
    (i32.const 5)
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local7
   (i64.const 2)
  )
  (local.set $local6
   (struct.new $type25
    (i32.const 0)
    (local.get $local7)
   )
  )
  (local.set $local5
   (struct.new $type23
    (i32.const 5)
    (ref.as_non_null
     (local.get $local6)
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local11
   (global.get $empty14)
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global351)
   )
  )
  (local.set $local9
   (call $function104
    (struct.get $type106 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local10)
    )
    (ref.as_non_null
     (local.get $local11)
    )
   )
  )
  (local.set $local8
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local16
   (global.get $empty14)
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global351)
   )
  )
  (local.set $local14
   (call $function104
    (struct.get $type106 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (ref.as_non_null
     (local.get $local15)
    )
    (ref.as_non_null
     (local.get $local16)
    )
   )
  )
  (local.set $local13
   (i32.const 1)
  )
  (local.set $local20
   (i64.const 1)
  )
  (local.set $local21
   (i64.const 2)
  )
  (local.set $local22
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (local.set $local19
   (call $function42
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local22)
     )
    )
    (struct.new $type56
     (local.get $local20)
     (struct.new $type56
      (local.get $local21)
      (ref.null none)
     )
    )
   )
  )
  (local.set $local18
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local25
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local26
   (ref.as_non_null
    (local.get $local5)
   )
  )
  (local.set $local27
   (ref.as_non_null
    (global.get $global795)
   )
  )
  (local.set $local24
   (call $function215
    (struct.get $type11 1
     (ref.as_non_null
      (local.get $local27)
     )
    )
    (struct.new $type12
     (ref.as_non_null
      (local.get $local25)
     )
     (struct.new $type12
      (ref.as_non_null
       (local.get $local26)
      )
      (ref.null none)
     )
    )
   )
  )
  (local.set $local23
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local80
   (ref.as_non_null
    (local.get $local9)
   )
  )
  (if
   (i32.eqz
    (local.get $local13)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local81
   (ref.as_non_null
    (local.get $local14)
   )
  )
  (local.set $local82
   (ref.as_non_null
    (global.get $global417)
   )
  )
  (if (result i32)
   (call $function122
    (struct.get $type111 1
     (ref.as_non_null
      (local.get $local82)
     )
    )
    (ref.as_non_null
     (local.get $local80)
    )
    (ref.as_non_null
     (local.get $local81)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $local8)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local74
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local76
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.set $local77
     (global.get $empty14)
    )
    (local.set $local78
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (local.set $local75
     (call $function104
      (struct.get $type106 1
       (ref.as_non_null
        (local.get $local78)
       )
      )
      (ref.as_non_null
       (local.get $local76)
      )
      (ref.as_non_null
       (local.get $local77)
      )
     )
    )
    (local.set $local79
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (local.set $local73
     (call $function122
      (struct.get $type111 1
       (ref.as_non_null
        (local.get $local79)
       )
      )
      (ref.as_non_null
       (local.get $local74)
      )
      (ref.as_non_null
       (local.get $local75)
      )
     )
    )
    (if (result i32)
     (i32.eqz
      (local.get $local73)
     )
     (then
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local67
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local69
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (if
       (i32.eqz
        (local.get $local13)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local70
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (local.set $local71
       (ref.as_non_null
        (global.get $global351)
       )
      )
      (local.set $local68
       (call $function104
        (struct.get $type106 1
         (ref.as_non_null
          (local.get $local71)
         )
        )
        (ref.as_non_null
         (local.get $local69)
        )
        (ref.as_non_null
         (local.get $local70)
        )
       )
      )
      (local.set $local72
       (ref.as_non_null
        (global.get $global417)
       )
      )
      (local.set $local66
       (call $function122
        (struct.get $type111 1
         (ref.as_non_null
          (local.get $local72)
         )
        )
        (ref.as_non_null
         (local.get $local67)
        )
        (ref.as_non_null
         (local.get $local68)
        )
       )
      )
      (if (result i32)
       (i32.eqz
        (local.get $local66)
       )
       (then
        (if
         (i32.eqz
          (local.get $local23)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local60
         (ref.as_non_null
          (local.get $local24)
         )
        )
        (local.set $local59
         (struct.new $type33
          (i32.const 7)
          (ref.as_non_null
           (local.get $local60)
          )
         )
        )
        (if
         (i32.eqz
          (local.get $local23)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local63
         (ref.as_non_null
          (local.get $local24)
         )
        )
        (local.set $local64
         (ref.as_non_null
          (global.get $global797)
         )
        )
        (local.set $local62
         (call $function216
          (struct.get $type42 1
           (ref.as_non_null
            (local.get $local64)
           )
          )
          (ref.as_non_null
           (local.get $local63)
          )
         )
        )
        (local.set $local61
         (struct.new $type33
          (i32.const 7)
          (ref.as_non_null
           (local.get $local62)
          )
         )
        )
        (local.set $local65
         (ref.as_non_null
          (global.get $global417)
         )
        )
        (if (result i32)
         (call $function122
          (struct.get $type111 1
           (ref.as_non_null
            (local.get $local65)
           )
          )
          (ref.as_non_null
           (local.get $local59)
          )
          (ref.as_non_null
           (local.get $local61)
          )
         )
         (then
          (if
           (i32.eqz
            (local.get $local23)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local52
           (ref.as_non_null
            (local.get $local24)
           )
          )
          (local.set $local51
           (struct.new $type33
            (i32.const 7)
            (ref.as_non_null
             (local.get $local52)
            )
           )
          )
          (if
           (i32.eqz
            (local.get $local4)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local55
           (ref.as_non_null
            (local.get $local5)
           )
          )
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local56
           (ref.as_non_null
            (local.get $local1)
           )
          )
          (local.set $local57
           (ref.as_non_null
            (global.get $global795)
           )
          )
          (local.set $local54
           (call $function215
            (struct.get $type11 1
             (ref.as_non_null
              (local.get $local57)
             )
            )
            (struct.new $type12
             (ref.as_non_null
              (local.get $local55)
             )
             (struct.new $type12
              (ref.as_non_null
               (local.get $local56)
              )
              (ref.null none)
             )
            )
           )
          )
          (local.set $local53
           (struct.new $type33
            (i32.const 7)
            (ref.as_non_null
             (local.get $local54)
            )
           )
          )
          (local.set $local58
           (ref.as_non_null
            (global.get $global417)
           )
          )
          (local.set $local50
           (call $function122
            (struct.get $type111 1
             (ref.as_non_null
              (local.get $local58)
             )
            )
            (ref.as_non_null
             (local.get $local51)
            )
            (ref.as_non_null
             (local.get $local53)
            )
           )
          )
          (if (result i32)
           (i32.eqz
            (local.get $local50)
           )
           (then
            (if
             (i32.eqz
              (local.get $local18)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local43
             (ref.as_non_null
              (local.get $local19)
             )
            )
            (local.set $local42
             (struct.new $type35
              (i32.const 8)
              (ref.as_non_null
               (local.get $local43)
              )
             )
            )
            (local.set $local46
             (i64.const 1)
            )
            (local.set $local47
             (i64.const 2)
            )
            (local.set $local48
             (ref.as_non_null
              (global.get $global111)
             )
            )
            (local.set $local45
             (call $function42
              (struct.get $type55 1
               (ref.as_non_null
                (local.get $local48)
               )
              )
              (struct.new $type56
               (local.get $local46)
               (struct.new $type56
                (local.get $local47)
                (ref.null none)
               )
              )
             )
            )
            (local.set $local44
             (struct.new $type35
              (i32.const 8)
              (ref.as_non_null
               (local.get $local45)
              )
             )
            )
            (local.set $local49
             (ref.as_non_null
              (global.get $global417)
             )
            )
            (if (result i32)
             (call $function122
              (struct.get $type111 1
               (ref.as_non_null
                (local.get $local49)
               )
              )
              (ref.as_non_null
               (local.get $local42)
              )
              (ref.as_non_null
               (local.get $local44)
              )
             )
             (then
              (if
               (i32.eqz
                (local.get $local18)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local35
               (ref.as_non_null
                (local.get $local19)
               )
              )
              (local.set $local34
               (struct.new $type35
                (i32.const 8)
                (ref.as_non_null
                 (local.get $local35)
                )
               )
              )
              (local.set $local38
               (i64.const 1)
              )
              (local.set $local39
               (i64.const 3)
              )
              (local.set $local40
               (ref.as_non_null
                (global.get $global111)
               )
              )
              (local.set $local37
               (call $function42
                (struct.get $type55 1
                 (ref.as_non_null
                  (local.get $local40)
                 )
                )
                (struct.new $type56
                 (local.get $local38)
                 (struct.new $type56
                  (local.get $local39)
                  (ref.null none)
                 )
                )
               )
              )
              (local.set $local36
               (struct.new $type35
                (i32.const 8)
                (ref.as_non_null
                 (local.get $local37)
                )
               )
              )
              (local.set $local41
               (ref.as_non_null
                (global.get $global417)
               )
              )
              (local.set $local33
               (call $function122
                (struct.get $type111 1
                 (ref.as_non_null
                  (local.get $local41)
                 )
                )
                (ref.as_non_null
                 (local.get $local34)
                )
                (ref.as_non_null
                 (local.get $local36)
                )
               )
              )
              (if (result i32)
               (i32.eqz
                (local.get $local33)
               )
               (then
                (local.set $local30
                 (global.get $string52)
                )
                (local.set $local29
                 (struct.new $type17
                  (i32.const 3)
                  (ref.as_non_null
                   (local.get $local30)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local31
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
                (local.set $local32
                 (ref.as_non_null
                  (global.get $global417)
                 )
                )
                (local.set $local28
                 (call $function122
                  (struct.get $type111 1
                   (ref.as_non_null
                    (local.get $local32)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local29)
                  )
                  (ref.as_non_null
                   (local.get $local31)
                  )
                 )
                )
                (i32.eqz
                 (local.get $local28)
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function215 (type $call11) (param $environment eqref) (param $argument796 (ref null $type12)) (result (ref $type34))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type38))
  (local.set $local0
   (local.get $argument796)
  )
  (if
   (i32.eqz
    (global.get $ready726)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global726)
   )
  )
  (return_call $function202
   (struct.get $type38 1
    (ref.as_non_null
     (local.get $local1)
    )
   )
   (local.get $local0)
  )
 )
 (func $function216 (type $call42) (param $environment eqref) (param $argument798 (ref $type34)) (result (ref $type34))
  (local $local0 i32)
  (local $local3 i32)
  (local $local1 i64)
  (local $local5 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local2 (ref null $type34))
  (local $local4 (ref null $type34))
  (local $local7 (ref null $type34))
  (local $local9 (ref null $type34))
  (local $local11 (ref null $type34))
  (local $local6 (ref null $type13))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument798)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (local.get $local1)
  )
  (local.set $local15
   (i64.const 0)
  )
  (if (result (ref $type34))
   (i64.eq
    (local.get $local14)
    (local.get $local15)
   )
   (then
    (array.new_fixed $type34 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (local.get $local1)
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument798)
     )
    )
    (local.set $local8
     (i64.const 0)
    )
    (local.set $local6
     (array.get $type34
      (ref.as_non_null
       (local.get $local7)
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local8)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local8)
       )
      )
     )
    )
    (local.set $local4
     (array.new $type34
      (ref.as_non_null
       (local.get $local6)
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local5)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local5)
       )
      )
     )
    )
    (local.set $local3
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.set $local10
     (i64.const 0)
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $argument798)
     )
    )
    (local.set $local12
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (local.get $local1)
    )
    (if
     (i64.lt_s
      (local.get $local13)
      (local.get $local12)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type34 $type34
     (ref.as_non_null
      (local.get $local9)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local10)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local10)
      )
     )
     (ref.as_non_null
      (local.get $local11)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local12)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local12)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (i64.sub
         (local.get $local13)
         (local.get $local12)
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (i64.sub
        (local.get $local13)
        (local.get $local12)
       )
      )
     )
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
 )
 (func $function217 (type $call5) (param $environment eqref) (result i64)
  (local $local0 i32)
  (local $local4 i32)
  (local $local10 i32)
  (local $local29 i32)
  (local $local44 i32)
  (local $local16 f64)
  (local $local21 f64)
  (local $local27 i64)
  (local $local63 i64)
  (local $local1 (ref null $type22))
  (local $local5 (ref null $type22))
  (local $local13 (ref null $type22))
  (local $local66 (ref null $type22))
  (local $local70 (ref null $type22))
  (local $local71 (ref null $type22))
  (local $local2 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local7 (ref null $type18))
  (local $local18 (ref null $type18))
  (local $local31 (ref null $type18))
  (local $local34 (ref null $type18))
  (local $local38 (ref null $type18))
  (local $local41 (ref null $type18))
  (local $local46 (ref null $type18))
  (local $local49 (ref null $type18))
  (local $local53 (ref null $type18))
  (local $local56 (ref null $type18))
  (local $local60 (ref null $type18))
  (local $local65 (ref null $type18))
  (local $local68 (ref null $type18))
  (local $local77 (ref null $type18))
  (local $local3 (ref null $type84))
  (local $local9 (ref null $type84))
  (local $local8 (ref null $type48))
  (local $local11 (ref null $type13))
  (local $local12 (ref null $type13))
  (local $local14 (ref null $type13))
  (local $local22 (ref null $type13))
  (local $local23 (ref null $type13))
  (local $local25 (ref null $type13))
  (local $local74 (ref null $type13))
  (local $local75 (ref null $type13))
  (local $local15 (ref null $type106))
  (local $local17 (ref null $type24))
  (local $local26 (ref null $type24))
  (local $local30 (ref null $type24))
  (local $local33 (ref null $type24))
  (local $local37 (ref null $type24))
  (local $local40 (ref null $type24))
  (local $local45 (ref null $type24))
  (local $local48 (ref null $type24))
  (local $local52 (ref null $type24))
  (local $local55 (ref null $type24))
  (local $local59 (ref null $type24))
  (local $local62 (ref null $type24))
  (local $local76 (ref null $type24))
  (local $local19 (ref null $type200))
  (local $local32 (ref null $type200))
  (local $local35 (ref null $type200))
  (local $local39 (ref null $type200))
  (local $local42 (ref null $type200))
  (local $local47 (ref null $type200))
  (local $local50 (ref null $type200))
  (local $local54 (ref null $type200))
  (local $local57 (ref null $type200))
  (local $local61 (ref null $type200))
  (local $local78 (ref null $type200))
  (local $local20 (ref null $type88))
  (local $local24 (ref null $type107))
  (local $local28 (ref null $type111))
  (local $local36 (ref null $type99))
  (local $local43 (ref null $type99))
  (local $local51 (ref null $type99))
  (local $local58 (ref null $type99))
  (local $local64 (ref null $type99))
  (local $local67 (ref null $type86))
  (local $local69 (ref null $type53))
  (local $local72 (ref null $type85))
  (local $local73 (ref null $type8))
  (local $local79 (ref null $type108))
  (local.set $local2
   (global.get $string53)
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global258)
   )
  )
  (local.set $local1
   (call $function84
    (struct.get $type84 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local7
   (global.get $string53)
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (local.set $local6
   (call $function34
    (struct.get $type48 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (ref.as_non_null
     (local.get $local7)
    )
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global258)
   )
  )
  (local.set $local5
   (call $function84
    (struct.get $type84 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local12
   (struct.new $type21
    (i32.const 4)
    (ref.as_non_null
     (local.get $local13)
    )
   )
  )
  (local.set $local14
   (global.get $empty14)
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global351)
   )
  )
  (local.set $local11
   (call $function104
    (struct.get $type106 1
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (ref.as_non_null
     (local.get $local12)
    )
    (ref.as_non_null
     (local.get $local14)
    )
   )
  )
  (local.set $local10
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local10)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local74
   (ref.as_non_null
    (local.get $local11)
   )
  )
  (local.set $local77
   (global.get $string62)
  )
  (local.set $local78
   (ref.as_non_null
    (global.get $global786)
   )
  )
  (local.set $local76
   (call $function213
    (struct.get $type200 1
     (ref.as_non_null
      (local.get $local78)
     )
    )
    (ref.as_non_null
     (local.get $local77)
    )
   )
  )
  (local.set $local75
   (struct.new $type23
    (i32.const 5)
    (ref.as_non_null
     (local.get $local76)
    )
   )
  )
  (local.set $local79
   (ref.as_non_null
    (global.get $global358)
   )
  )
  (drop
   (call $function107
    (struct.get $type108 1
     (ref.as_non_null
      (local.get $local79)
     )
    )
    (ref.as_non_null
     (local.get $local74)
    )
    (ref.as_non_null
     (local.get $local75)
    )
   )
  )
  (local.set $local73
   (ref.as_non_null
    (global.get $global788)
   )
  )
  (if (result i64)
   (if (result i32)
    (call $function214
     (struct.get $type8 1
      (ref.as_non_null
       (local.get $local73)
      )
     )
    )
    (then
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local70
      (ref.as_non_null
       (local.get $local1)
      )
     )
     (if
      (i32.eqz
       (local.get $local4)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local71
      (ref.as_non_null
       (local.get $local5)
      )
     )
     (local.set $local72
      (ref.as_non_null
       (global.get $global260)
      )
     )
     (if (result i32)
      (call $function85
       (struct.get $type85 1
        (ref.as_non_null
         (local.get $local72)
        )
       )
       (ref.as_non_null
        (local.get $local70)
       )
       (ref.as_non_null
        (local.get $local71)
       )
      )
      (then
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local66
        (ref.as_non_null
         (local.get $local1)
        )
       )
       (local.set $local67
        (ref.as_non_null
         (global.get $global263)
        )
       )
       (local.set $local65
        (call $function86
         (struct.get $type86 1
          (ref.as_non_null
           (local.get $local67)
          )
         )
         (ref.as_non_null
          (local.get $local66)
         )
        )
       )
       (local.set $local68
        (global.get $string53)
       )
       (local.set $local69
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (if (result i32)
        (call $function39
         (struct.get $type53 1
          (ref.as_non_null
           (local.get $local69)
          )
         )
         (ref.as_non_null
          (local.get $local65)
         )
         (ref.as_non_null
          (local.get $local68)
         )
        )
        (then
         (local.set $local60
          (global.get $string61)
         )
         (local.set $local61
          (ref.as_non_null
           (global.get $global786)
          )
         )
         (local.set $local59
          (call $function213
           (struct.get $type200 1
            (ref.as_non_null
             (local.get $local61)
            )
           )
           (ref.as_non_null
            (local.get $local60)
           )
          )
         )
         (local.set $local63
          (i64.const -9223372036854775808)
         )
         (local.set $local62
          (struct.new $type25
           (i32.const 0)
           (local.get $local63)
          )
         )
         (local.set $local64
          (ref.as_non_null
           (global.get $global332)
          )
         )
         (if (result i32)
          (call $function101
           (struct.get $type99 1
            (ref.as_non_null
             (local.get $local64)
            )
           )
           (ref.as_non_null
            (local.get $local59)
           )
           (ref.as_non_null
            (local.get $local62)
           )
          )
          (then
           (local.set $local53
            (global.get $string60)
           )
           (local.set $local54
            (ref.as_non_null
             (global.get $global786)
            )
           )
           (local.set $local52
            (call $function213
             (struct.get $type200 1
              (ref.as_non_null
               (local.get $local54)
              )
             )
             (ref.as_non_null
              (local.get $local53)
             )
            )
           )
           (local.set $local56
            (global.get $string52)
           )
           (local.set $local57
            (ref.as_non_null
             (global.get $global786)
            )
           )
           (local.set $local55
            (call $function213
             (struct.get $type200 1
              (ref.as_non_null
               (local.get $local57)
              )
             )
             (ref.as_non_null
              (local.get $local56)
             )
            )
           )
           (local.set $local58
            (ref.as_non_null
             (global.get $global332)
            )
           )
           (if (result i32)
            (call $function101
             (struct.get $type99 1
              (ref.as_non_null
               (local.get $local58)
              )
             )
             (ref.as_non_null
              (local.get $local52)
             )
             (ref.as_non_null
              (local.get $local55)
             )
            )
            (then
             (local.set $local46
              (global.get $string58)
             )
             (local.set $local47
              (ref.as_non_null
               (global.get $global786)
              )
             )
             (local.set $local45
              (call $function213
               (struct.get $type200 1
                (ref.as_non_null
                 (local.get $local47)
                )
               )
               (ref.as_non_null
                (local.get $local46)
               )
              )
             )
             (local.set $local49
              (global.get $string59)
             )
             (local.set $local50
              (ref.as_non_null
               (global.get $global786)
              )
             )
             (local.set $local48
              (call $function213
               (struct.get $type200 1
                (ref.as_non_null
                 (local.get $local50)
                )
               )
               (ref.as_non_null
                (local.get $local49)
               )
              )
             )
             (local.set $local51
              (ref.as_non_null
               (global.get $global332)
              )
             )
             (local.set $local44
              (call $function101
               (struct.get $type99 1
                (ref.as_non_null
                 (local.get $local51)
                )
               )
               (ref.as_non_null
                (local.get $local45)
               )
               (ref.as_non_null
                (local.get $local48)
               )
              )
             )
             (if (result i32)
              (i32.eqz
               (local.get $local44)
              )
              (then
               (local.set $local38
                (global.get $string56)
               )
               (local.set $local39
                (ref.as_non_null
                 (global.get $global786)
                )
               )
               (local.set $local37
                (call $function213
                 (struct.get $type200 1
                  (ref.as_non_null
                   (local.get $local39)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local38)
                 )
                )
               )
               (local.set $local41
                (global.get $string57)
               )
               (local.set $local42
                (ref.as_non_null
                 (global.get $global786)
                )
               )
               (local.set $local40
                (call $function213
                 (struct.get $type200 1
                  (ref.as_non_null
                   (local.get $local42)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local41)
                 )
                )
               )
               (local.set $local43
                (ref.as_non_null
                 (global.get $global332)
                )
               )
               (if (result i32)
                (call $function101
                 (struct.get $type99 1
                  (ref.as_non_null
                   (local.get $local43)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local37)
                 )
                 (ref.as_non_null
                  (local.get $local40)
                 )
                )
                (then
                 (local.set $local31
                  (global.get $string52)
                 )
                 (local.set $local32
                  (ref.as_non_null
                   (global.get $global786)
                  )
                 )
                 (local.set $local30
                  (call $function213
                   (struct.get $type200 1
                    (ref.as_non_null
                     (local.get $local32)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local31)
                   )
                  )
                 )
                 (local.set $local34
                  (global.get $string55)
                 )
                 (local.set $local35
                  (ref.as_non_null
                   (global.get $global786)
                  )
                 )
                 (local.set $local33
                  (call $function213
                   (struct.get $type200 1
                    (ref.as_non_null
                     (local.get $local35)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local34)
                   )
                  )
                 )
                 (local.set $local36
                  (ref.as_non_null
                   (global.get $global332)
                  )
                 )
                 (local.set $local29
                  (call $function101
                   (struct.get $type99 1
                    (ref.as_non_null
                     (local.get $local36)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local30)
                   )
                   (ref.as_non_null
                    (local.get $local33)
                   )
                  )
                 )
                 (if (result i32)
                  (i32.eqz
                   (local.get $local29)
                  )
                  (then
                   (if
                    (i32.eqz
                     (local.get $local10)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $local23
                    (ref.as_non_null
                     (local.get $local11)
                    )
                   )
                   (local.set $local24
                    (ref.as_non_null
                     (global.get $global354)
                    )
                   )
                   (local.set $local22
                    (call $function105
                     (struct.get $type107 1
                      (ref.as_non_null
                       (local.get $local24)
                      )
                     )
                     (ref.as_non_null
                      (local.get $local23)
                     )
                    )
                   )
                   (local.set $local27
                    (i64.const 9007199254740993)
                   )
                   (local.set $local26
                    (struct.new $type25
                     (i32.const 0)
                     (local.get $local27)
                    )
                   )
                   (local.set $local25
                    (struct.new $type23
                     (i32.const 5)
                     (ref.as_non_null
                      (local.get $local26)
                     )
                    )
                   )
                   (local.set $local28
                    (ref.as_non_null
                     (global.get $global417)
                    )
                   )
                   (if (result i32)
                    (call $function122
                     (struct.get $type111 1
                      (ref.as_non_null
                       (local.get $local28)
                      )
                     )
                     (ref.as_non_null
                      (local.get $local22)
                     )
                     (ref.as_non_null
                      (local.get $local25)
                     )
                    )
                    (then
                     (local.set $local18
                      (global.get $string54)
                     )
                     (local.set $local19
                      (ref.as_non_null
                       (global.get $global786)
                      )
                     )
                     (local.set $local17
                      (call $function213
                       (struct.get $type200 1
                        (ref.as_non_null
                         (local.get $local19)
                        )
                       )
                       (ref.as_non_null
                        (local.get $local18)
                       )
                      )
                     )
                     (local.set $local20
                      (ref.as_non_null
                       (global.get $global289)
                      )
                     )
                     (local.set $local16
                      (call $function93
                       (struct.get $type88 1
                        (ref.as_non_null
                         (local.get $local20)
                        )
                       )
                       (ref.as_non_null
                        (local.get $local17)
                       )
                      )
                     )
                     (local.set $local21
                      (f64.const 12.5)
                     )
                     (f64.eq
                      (local.get $local16)
                      (local.get $local21)
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (i64.const 42)
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function218 (type $call8) (param $environment eqref) (result i32)
  (local $local0 (ref null $type18))
  (local $local1 (ref null $type126))
  (local $local2 (ref null $type125))
  (local.set $local0
   (global.get $string63)
  )
  (local.set $local1
   (struct.new $type126
    (ref.func $function219)
    (ref.null none)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global814)
   )
  )
  (return_call $function220
   (struct.get $type125 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function219 (type $call126) (param $environment eqref) (param $argument806 (ref $type121)) (result i32)
  (local $local0 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local13 i32)
  (local $local20 i32)
  (local $local24 i32)
  (local $local31 i32)
  (local $local65 i32)
  (local $local66 i32)
  (local $local69 i32)
  (local $local70 i32)
  (local $local47 i64)
  (local $local64 i64)
  (local $local68 i64)
  (local $local74 i64)
  (local $local1 (ref null $type13))
  (local $local7 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local15 (ref null $type13))
  (local $local26 (ref null $type13))
  (local $local33 (ref null $type13))
  (local $local42 (ref null $type13))
  (local $local43 (ref null $type13))
  (local $local45 (ref null $type13))
  (local $local71 (ref null $type13))
  (local $local72 (ref null $type13))
  (local $local2 (ref null $type101))
  (local $local16 (ref null $type101))
  (local $local27 (ref null $type101))
  (local $local34 (ref null $type101))
  (local $local38 (ref null $type101))
  (local $local3 (ref null $type121))
  (local $local17 (ref null $type121))
  (local $local28 (ref null $type121))
  (local $local35 (ref null $type121))
  (local $local39 (ref null $type121))
  (local $local4 (ref null $type148))
  (local $local18 (ref null $type148))
  (local $local29 (ref null $type148))
  (local $local36 (ref null $type148))
  (local $local40 (ref null $type148))
  (local $local5 (ref null $type147))
  (local $local19 (ref null $type147))
  (local $local30 (ref null $type147))
  (local $local37 (ref null $type147))
  (local $local9 (ref null $type22))
  (local $local14 (ref null $type22))
  (local $local22 (ref null $type22))
  (local $local56 (ref null $type22))
  (local $local60 (ref null $type22))
  (local $local61 (ref null $type22))
  (local $local12 (ref null $type107))
  (local $local44 (ref null $type107))
  (local $local21 (ref null $type18))
  (local $local25 (ref null $type18))
  (local $local32 (ref null $type18))
  (local $local49 (ref null $type18))
  (local $local50 (ref null $type18))
  (local $local52 (ref null $type18))
  (local $local53 (ref null $type18))
  (local $local55 (ref null $type18))
  (local $local58 (ref null $type18))
  (local $local63 (ref null $type18))
  (local $local67 (ref null $type18))
  (local $local23 (ref null $type86))
  (local $local57 (ref null $type86))
  (local $local41 (ref null $type146))
  (local $local46 (ref null $type24))
  (local $local73 (ref null $type24))
  (local $local48 (ref null $type111))
  (local $local51 (ref null $type53))
  (local $local54 (ref null $type53))
  (local $local59 (ref null $type53))
  (local $local62 (ref null $type85))
  (local $local75 (ref null $type108))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument806)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local2
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global520)
   )
  )
  (local.set $local1
   (call $function152
    (struct.get $type147 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local6
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global354)
   )
  )
  (local.set $local10
   (call $function105
    (struct.get $type107 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local11)
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local10)
     )
    )
    (i32.const 4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (struct.get $type21 1
    (ref.cast (ref $type21)
     (ref.as_non_null
      (local.get $local10)
     )
    )
   )
  )
  (local.set $local8
   (i32.const 1)
  )
  (local.set $local17
   (ref.as_non_null
    (local.get $argument806)
   )
  )
  (local.set $local18
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local16
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local18)
     )
    )
    (ref.as_non_null
     (local.get $local17)
    )
   )
  )
  (local.set $local19
   (ref.as_non_null
    (global.get $global520)
   )
  )
  (local.set $local15
   (call $function152
    (struct.get $type147 1
     (ref.as_non_null
      (local.get $local19)
     )
    )
    (ref.as_non_null
     (local.get $local16)
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (i32.const 4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (struct.get $type21 1
    (ref.cast (ref $type21)
     (ref.as_non_null
      (local.get $local15)
     )
    )
   )
  )
  (local.set $local13
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local13)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local22
   (ref.as_non_null
    (local.get $local14)
   )
  )
  (local.set $local23
   (ref.as_non_null
    (global.get $global263)
   )
  )
  (local.set $local21
   (call $function86
    (struct.get $type86 1
     (ref.as_non_null
      (local.get $local23)
     )
    )
    (ref.as_non_null
     (local.get $local22)
    )
   )
  )
  (local.set $local20
   (i32.const 1)
  )
  (local.set $local28
   (ref.as_non_null
    (local.get $argument806)
   )
  )
  (local.set $local29
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local27
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local29)
     )
    )
    (ref.as_non_null
     (local.get $local28)
    )
   )
  )
  (local.set $local30
   (ref.as_non_null
    (global.get $global520)
   )
  )
  (local.set $local26
   (call $function152
    (struct.get $type147 1
     (ref.as_non_null
      (local.get $local30)
     )
    )
    (ref.as_non_null
     (local.get $local27)
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local26)
     )
    )
    (i32.const 3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local25
   (struct.get $type17 1
    (ref.cast (ref $type17)
     (ref.as_non_null
      (local.get $local26)
     )
    )
   )
  )
  (local.set $local24
   (i32.const 1)
  )
  (local.set $local35
   (ref.as_non_null
    (local.get $argument806)
   )
  )
  (local.set $local36
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local34
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local36)
     )
    )
    (ref.as_non_null
     (local.get $local35)
    )
   )
  )
  (local.set $local37
   (ref.as_non_null
    (global.get $global520)
   )
  )
  (local.set $local33
   (call $function152
    (struct.get $type147 1
     (ref.as_non_null
      (local.get $local37)
     )
    )
    (ref.as_non_null
     (local.get $local34)
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local33)
     )
    )
    (i32.const 3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local32
   (struct.get $type17 1
    (ref.cast (ref $type17)
     (ref.as_non_null
      (local.get $local33)
     )
    )
   )
  )
  (local.set $local31
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local71
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local74
   (i64.const 42)
  )
  (local.set $local73
   (struct.new $type25
    (i32.const 0)
    (local.get $local74)
   )
  )
  (local.set $local72
   (struct.new $type23
    (i32.const 5)
    (ref.as_non_null
     (local.get $local73)
    )
   )
  )
  (local.set $local75
   (ref.as_non_null
    (global.get $global361)
   )
  )
  (drop
   (call $function108
    (struct.get $type108 1
     (ref.as_non_null
      (local.get $local75)
     )
    )
    (ref.as_non_null
     (local.get $local71)
    )
    (ref.as_non_null
     (local.get $local72)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local24)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local67
   (ref.as_non_null
    (local.get $local25)
   )
  )
  (local.set $local68
   (i64.const 0)
  )
  (local.set $local69
   (i32.const 88)
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (ref.as_non_null
      (local.get $local67)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $local68)
    (i64.extend_i32_u
     (struct.get $type18 1
      (ref.as_non_null
       (local.get $local67)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local70
   (i32.wrap_i64
    (local.get $local68)
   )
  )
  (array.set $type19
   (call $string-block
    (ref.as_non_null
     (local.get $local67)
    )
    (local.get $local70)
   )
   (i32.and
    (local.get $local70)
    (i32.const 8191)
   )
   (local.get $local69)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local20)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local63
   (ref.as_non_null
    (local.get $local21)
   )
  )
  (local.set $local64
   (i64.const 0)
  )
  (local.set $local65
   (i32.const 88)
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (ref.as_non_null
      (local.get $local63)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $local64)
    (i64.extend_i32_u
     (struct.get $type18 1
      (ref.as_non_null
       (local.get $local63)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local66
   (i32.wrap_i64
    (local.get $local64)
   )
  )
  (array.set $type19
   (call $string-block
    (ref.as_non_null
     (local.get $local63)
    )
    (local.get $local66)
   )
   (i32.and
    (local.get $local66)
    (i32.const 8191)
   )
   (local.get $local65)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local60
   (ref.as_non_null
    (local.get $local9)
   )
  )
  (if
   (i32.eqz
    (local.get $local13)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local61
   (ref.as_non_null
    (local.get $local14)
   )
  )
  (local.set $local62
   (ref.as_non_null
    (global.get $global260)
   )
  )
  (if (result i32)
   (call $function85
    (struct.get $type85 1
     (ref.as_non_null
      (local.get $local62)
     )
    )
    (ref.as_non_null
     (local.get $local60)
    )
    (ref.as_non_null
     (local.get $local61)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $local8)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local56
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (local.set $local57
     (ref.as_non_null
      (global.get $global263)
     )
    )
    (local.set $local55
     (call $function86
      (struct.get $type86 1
       (ref.as_non_null
        (local.get $local57)
       )
      )
      (ref.as_non_null
       (local.get $local56)
      )
     )
    )
    (local.set $local58
     (global.get $string66)
    )
    (local.set $local59
     (ref.as_non_null
      (global.get $global103)
     )
    )
    (if (result i32)
     (call $function39
      (struct.get $type53 1
       (ref.as_non_null
        (local.get $local59)
       )
      )
      (ref.as_non_null
       (local.get $local55)
      )
      (ref.as_non_null
       (local.get $local58)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $local24)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local52
       (ref.as_non_null
        (local.get $local25)
       )
      )
      (local.set $local53
       (global.get $string65)
      )
      (local.set $local54
       (ref.as_non_null
        (global.get $global103)
       )
      )
      (if (result i32)
       (call $function39
        (struct.get $type53 1
         (ref.as_non_null
          (local.get $local54)
         )
        )
        (ref.as_non_null
         (local.get $local52)
        )
        (ref.as_non_null
         (local.get $local53)
        )
       )
       (then
        (if
         (i32.eqz
          (local.get $local31)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local49
         (ref.as_non_null
          (local.get $local32)
         )
        )
        (local.set $local50
         (global.get $string64)
        )
        (local.set $local51
         (ref.as_non_null
          (global.get $global103)
         )
        )
        (if (result i32)
         (call $function39
          (struct.get $type53 1
           (ref.as_non_null
            (local.get $local51)
           )
          )
          (ref.as_non_null
           (local.get $local49)
          )
          (ref.as_non_null
           (local.get $local50)
          )
         )
         (then
          (if
           (i32.eqz
            (local.get $local6)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local43
           (ref.as_non_null
            (local.get $local7)
           )
          )
          (local.set $local44
           (ref.as_non_null
            (global.get $global356)
           )
          )
          (local.set $local42
           (call $function106
            (struct.get $type107 1
             (ref.as_non_null
              (local.get $local44)
             )
            )
            (ref.as_non_null
             (local.get $local43)
            )
           )
          )
          (local.set $local47
           (i64.const 42)
          )
          (local.set $local46
           (struct.new $type25
            (i32.const 0)
            (local.get $local47)
           )
          )
          (local.set $local45
           (struct.new $type23
            (i32.const 5)
            (ref.as_non_null
             (local.get $local46)
            )
           )
          )
          (local.set $local48
           (ref.as_non_null
            (global.get $global417)
           )
          )
          (if (result i32)
           (call $function122
            (struct.get $type111 1
             (ref.as_non_null
              (local.get $local48)
             )
            )
            (ref.as_non_null
             (local.get $local42)
            )
            (ref.as_non_null
             (local.get $local45)
            )
           )
           (then
            (local.set $local39
             (ref.as_non_null
              (local.get $argument806)
             )
            )
            (local.set $local40
             (ref.as_non_null
              (global.get $global525)
             )
            )
            (local.set $local38
             (call $function153
              (struct.get $type148 1
               (ref.as_non_null
                (local.get $local40)
               )
              )
              (ref.as_non_null
               (local.get $local39)
              )
             )
            )
            (local.set $local41
             (ref.as_non_null
              (global.get $global515)
             )
            )
            (return_call $function151
             (struct.get $type146 1
              (ref.as_non_null
               (local.get $local41)
              )
             )
             (ref.as_non_null
              (local.get $local38)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function220 (type $call125) (param $environment eqref) (param $argument815 (ref $type18)) (param $argument816 (ref $type126)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 (ref null $type121))
  (local $local6 (ref null $type121))
  (local $local8 (ref null $type121))
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type120))
  (local $local7 (ref null $type126))
  (local $local9 (ref null $type123))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument815)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global455)
   )
  )
  (local.set $local1
   (call $function132
    (struct.get $type120 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (local.get $argument816)
   )
  )
  (local.set $local5
   (call_ref $call126
    (struct.get $type126 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (struct.get $type126 0
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global462)
   )
  )
  (drop
   (call $function135
    (struct.get $type123 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local8)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.get $local5)
 )
 (func $function221 (type $call116) (param $environment eqref) (param $argument820 (ref $type18)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 (ref null $type18))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument820)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (call $foreign26
   (local.get $local3)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local0
   (i64.const 0)
  )
  (local.set $local2
   (i32.const 0)
  )
  (local.set $local1
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local2)
  )
  (return_call $function222
   (ref.as_non_null
    (local.get $argument820)
   )
   (local.get $local2)
   (local.get $local1)
   (local.get $local0)
  )
 )
 (func $function222 (param $capture820 (ref $type18)) (param $capture821 i32) (param $initialized821 i32) (param $argument822 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type18))
  (local $local9 (ref null $type18))
  (local.set $local7
   (local.get $argument822)
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $capture820)
   )
  )
  (local.set $local8
   (i64.extend_i32_u
    (struct.get $type18 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture820)
     )
    )
    (local.set $local5
     (local.get $argument822)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type19
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (call $foreign27
     (local.get $local3)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument822)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized821)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture821)
    )
    (return_call $function222
     (ref.as_non_null
      (local.get $capture820)
     )
     (local.get $capture821)
     (local.get $initialized821)
     (local.get $local0)
    )
   )
  )
 )
 (func $function223 (type $call201) (param $environment eqref) (param $argument824 (ref $type28)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local6 i32)
  (local $local3 f64)
  (local $local4 f64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local1 (ref null $type28))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument824)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type28 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (struct.get $type29 1
      (ref.cast (ref $type29)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local6
     (i32.const 1)
    )
    (local.set $local9
     (i64.const 0)
    )
    (call $foreign26
     (local.get $local9)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local7)
    )
    (call $foreign26
     (local.get $local8)
    )
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type30 1
      (ref.cast (ref $type30)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (local.set $local5
     (i64.const 1)
    )
    (call $foreign26
     (local.get $local5)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (local.get $local3)
    )
    (call $foreign28
     (local.get $local4)
    )
    (i32.const 0)
   )
  )
 )
 (func $function224 (type $call202) (param $environment eqref) (param $argument829 (ref $type24)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local11 i32)
  (local $local15 i32)
  (local $local10 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local12 f64)
  (local $local13 f64)
  (local $local1 (ref null $type24))
  (local $local3 (ref null $type28))
  (local $local5 (ref null $type28))
  (local $local6 (ref null $type28))
  (local $local8 (ref null $type28))
  (local $local7 (ref null $type201))
  (local $local9 (ref null $type201))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument829)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type24 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (struct.get $type25 1
      (ref.cast (ref $type25)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local15
     (i32.const 1)
    )
    (local.set $local18
     (i64.const 0)
    )
    (call $foreign26
     (local.get $local18)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local15)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (local.get $local16)
    )
    (call $foreign26
     (local.get $local17)
    )
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type24 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local12
       (struct.get $type26 1
        (ref.cast (ref $type26)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local11
       (i32.const 1)
      )
      (local.set $local14
       (i64.const 1)
      )
      (call $foreign26
       (local.get $local14)
      )
      (drop
       (i32.const 0)
      )
      (if
       (i32.eqz
        (local.get $local11)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local13
       (local.get $local12)
      )
      (call $foreign28
       (local.get $local13)
      )
      (i32.const 0)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local3
       (struct.get $type27 1
        (ref.cast (ref $type27)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local2
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type27 2
        (ref.cast (ref $type27)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (local.set $local10
       (i64.const 2)
      )
      (call $foreign26
       (local.get $local10)
      )
      (drop
       (i32.const 0)
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local8
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (local.set $local9
       (ref.as_non_null
        (global.get $global823)
       )
      )
      (drop
       (call $function223
        (struct.get $type201 1
         (ref.as_non_null
          (local.get $local9)
         )
        )
        (ref.as_non_null
         (local.get $local8)
        )
       )
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global823)
       )
      )
      (return_call $function223
       (struct.get $type201 1
        (ref.as_non_null
         (local.get $local7)
        )
       )
       (ref.as_non_null
        (local.get $local6)
       )
      )
     )
    )
   )
  )
 )
 (func $function225 (type $call203) (param $environment eqref) (param $argument836 (ref $type13)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local7 i32)
  (local $local12 i32)
  (local $local14 i32)
  (local $local23 i32)
  (local $local28 i32)
  (local $local35 i32)
  (local $local40 i32)
  (local $local41 i32)
  (local $local42 i32)
  (local $local44 i32)
  (local $local45 i32)
  (local $local6 i64)
  (local $local11 i64)
  (local $local22 i64)
  (local $local27 i64)
  (local $local34 i64)
  (local $local39 i64)
  (local $local43 i64)
  (local $local46 i64)
  (local $local47 i64)
  (local $local48 i64)
  (local $local1 (ref null $type13))
  (local $local16 (ref null $type13))
  (local $local19 (ref null $type13))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type36))
  (local $local5 (ref null $type205))
  (local $local8 (ref null $type34))
  (local $local9 (ref null $type34))
  (local $local10 (ref null $type204))
  (local $local13 (ref null $type32))
  (local $local15 (ref null $type32))
  (local $local17 (ref null $type32))
  (local $local20 (ref null $type32))
  (local $local18 (ref null $type203))
  (local $local21 (ref null $type203))
  (local $local24 (ref null $type24))
  (local $local25 (ref null $type24))
  (local $local26 (ref null $type202))
  (local $local29 (ref null $type22))
  (local $local31 (ref null $type22))
  (local $local30 (ref null $type18))
  (local $local36 (ref null $type18))
  (local $local37 (ref null $type18))
  (local $local32 (ref null $type86))
  (local $local33 (ref null $type116))
  (local $local38 (ref null $type116))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument836)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type13 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (local.set $local48
     (i64.const 0)
    )
    (call $foreign26
     (local.get $local48)
    )
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (struct.get $type13 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local45
       (struct.get $type15 1
        (ref.cast (ref $type15)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local44
       (i32.const 1)
      )
      (local.set $local47
       (i64.const 1)
      )
      (call $foreign26
       (local.get $local47)
      )
      (drop
       (i32.const 0)
      )
      (if
       (i32.eqz
        (local.get $local44)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local46
       (if (result i64)
        (local.get $local45)
        (then
         (i64.const 1)
        )
        (else
         (i64.const 0)
        )
       )
      )
      (call $foreign26
       (local.get $local46)
      )
      (i32.const 0)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i32.eq
        (struct.get $type13 0
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (i32.const 2)
       )
       (then
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local41
         (struct.get $type16 1
          (ref.cast (ref $type16)
           (ref.as_non_null
            (local.get $local1)
           )
          )
         )
        )
        (local.set $local40
         (i32.const 1)
        )
        (local.set $local43
         (i64.const 2)
        )
        (call $foreign26
         (local.get $local43)
        )
        (drop
         (i32.const 0)
        )
        (if
         (i32.eqz
          (local.get $local40)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local42
         (local.get $local41)
        )
        (call $foreign27
         (local.get $local42)
        )
        (i32.const 0)
       )
       (else
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (ref.as_non_null
            (local.get $local1)
           )
          )
          (i32.const 3)
         )
         (then
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local36
           (struct.get $type17 1
            (ref.cast (ref $type17)
             (ref.as_non_null
              (local.get $local1)
             )
            )
           )
          )
          (local.set $local35
           (i32.const 1)
          )
          (local.set $local39
           (i64.const 3)
          )
          (call $foreign26
           (local.get $local39)
          )
          (drop
           (i32.const 0)
          )
          (if
           (i32.eqz
            (local.get $local35)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local37
           (ref.as_non_null
            (local.get $local36)
           )
          )
          (local.set $local38
           (ref.as_non_null
            (global.get $global819)
           )
          )
          (return_call $function221
           (struct.get $type116 1
            (ref.as_non_null
             (local.get $local38)
            )
           )
           (ref.as_non_null
            (local.get $local37)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (local.get $local0)
           )
           (then
            (unreachable)
           )
          )
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (ref.as_non_null
              (local.get $local1)
             )
            )
            (i32.const 4)
           )
           (then
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local29
             (struct.get $type21 1
              (ref.cast (ref $type21)
               (ref.as_non_null
                (local.get $local1)
               )
              )
             )
            )
            (local.set $local28
             (i32.const 1)
            )
            (local.set $local34
             (i64.const 4)
            )
            (call $foreign26
             (local.get $local34)
            )
            (drop
             (i32.const 0)
            )
            (if
             (i32.eqz
              (local.get $local28)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local31
             (ref.as_non_null
              (local.get $local29)
             )
            )
            (local.set $local32
             (ref.as_non_null
              (global.get $global263)
             )
            )
            (local.set $local30
             (call $function86
              (struct.get $type86 1
               (ref.as_non_null
                (local.get $local32)
               )
              )
              (ref.as_non_null
               (local.get $local31)
              )
             )
            )
            (local.set $local33
             (ref.as_non_null
              (global.get $global819)
             )
            )
            (return_call $function221
             (struct.get $type116 1
              (ref.as_non_null
               (local.get $local33)
              )
             )
             (ref.as_non_null
              (local.get $local30)
             )
            )
           )
           (else
            (if
             (i32.eqz
              (local.get $local0)
             )
             (then
              (unreachable)
             )
            )
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (ref.as_non_null
                (local.get $local1)
               )
              )
              (i32.const 5)
             )
             (then
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local24
               (struct.get $type23 1
                (ref.cast (ref $type23)
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
               )
              )
              (local.set $local23
               (i32.const 1)
              )
              (local.set $local27
               (i64.const 5)
              )
              (call $foreign26
               (local.get $local27)
              )
              (drop
               (i32.const 0)
              )
              (if
               (i32.eqz
                (local.get $local23)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local25
               (ref.as_non_null
                (local.get $local24)
               )
              )
              (local.set $local26
               (ref.as_non_null
                (global.get $global828)
               )
              )
              (return_call $function224
               (struct.get $type202 1
                (ref.as_non_null
                 (local.get $local26)
                )
               )
               (ref.as_non_null
                (local.get $local25)
               )
              )
             )
             (else
              (if
               (i32.eqz
                (local.get $local0)
               )
               (then
                (unreachable)
               )
              )
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (ref.as_non_null
                  (local.get $local1)
                 )
                )
                (i32.const 6)
               )
               (then
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local13
                 (struct.get $type31 1
                  (ref.cast (ref $type31)
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                 )
                )
                (local.set $local12
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local15
                 (struct.get $type31 2
                  (ref.cast (ref $type31)
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                 )
                )
                (local.set $local14
                 (i32.const 1)
                )
                (local.set $local22
                 (i64.const 6)
                )
                (call $foreign26
                 (local.get $local22)
                )
                (drop
                 (i32.const 0)
                )
                (if
                 (i32.eqz
                  (local.get $local12)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local20
                 (ref.as_non_null
                  (local.get $local13)
                 )
                )
                (local.set $local19
                 (struct.get $type32 0
                  (ref.as_non_null
                   (local.get $local20)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready835)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local21
                 (ref.as_non_null
                  (global.get $global835)
                 )
                )
                (drop
                 (call $function225
                  (struct.get $type203 1
                   (ref.as_non_null
                    (local.get $local21)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local19)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (local.get $local14)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local17
                 (ref.as_non_null
                  (local.get $local15)
                 )
                )
                (local.set $local16
                 (struct.get $type32 0
                  (ref.as_non_null
                   (local.get $local17)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready835)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local18
                 (ref.as_non_null
                  (global.get $global835)
                 )
                )
                (return_call $function225
                 (struct.get $type203 1
                  (ref.as_non_null
                   (local.get $local18)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local16)
                 )
                )
               )
               (else
                (if
                 (i32.eqz
                  (local.get $local0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (ref.as_non_null
                    (local.get $local1)
                   )
                  )
                  (i32.const 7)
                 )
                 (then
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local8
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local7
                   (i32.const 1)
                  )
                  (local.set $local11
                   (i64.const 7)
                  )
                  (call $foreign26
                   (local.get $local11)
                  )
                  (drop
                   (i32.const 0)
                  )
                  (if
                   (i32.eqz
                    (local.get $local7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local9
                   (ref.as_non_null
                    (local.get $local8)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready846)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local10
                   (ref.as_non_null
                    (global.get $global846)
                   )
                  )
                  (return_call $function226
                   (struct.get $type204 1
                    (ref.as_non_null
                     (local.get $local10)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local9)
                   )
                  )
                 )
                 (else
                  (if
                   (i32.eqz
                    (local.get $local0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local3
                   (struct.get $type35 1
                    (ref.cast (ref $type35)
                     (ref.as_non_null
                      (local.get $local1)
                     )
                    )
                   )
                  )
                  (local.set $local2
                   (i32.const 1)
                  )
                  (local.set $local6
                   (i64.const 8)
                  )
                  (call $foreign26
                   (local.get $local6)
                  )
                  (drop
                   (i32.const 0)
                  )
                  (if
                   (i32.eqz
                    (local.get $local2)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local4
                   (ref.as_non_null
                    (local.get $local3)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready851)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local5
                   (ref.as_non_null
                    (global.get $global851)
                   )
                  )
                  (return_call $function228
                   (struct.get $type205 1
                    (ref.as_non_null
                     (local.get $local5)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local4)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function226 (type $call204) (param $environment eqref) (param $argument847 (ref $type34)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 (ref null $type34))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument847)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (call $foreign26
   (local.get $local3)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local0
   (i64.const 0)
  )
  (local.set $local2
   (i32.const 0)
  )
  (local.set $local1
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local2)
  )
  (return_call $function227
   (ref.as_non_null
    (local.get $argument847)
   )
   (local.get $local2)
   (local.get $local1)
   (local.get $local0)
  )
 )
 (func $function227 (param $capture847 (ref $type34)) (param $capture848 i32) (param $initialized848 i32) (param $argument849 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local3 (ref null $type13))
  (local $local4 (ref null $type34))
  (local $local9 (ref null $type34))
  (local $local6 (ref null $type203))
  (local.set $local7
   (local.get $argument849)
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $capture847)
   )
  )
  (local.set $local8
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local9)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture847)
     )
    )
    (local.set $local5
     (local.get $argument849)
    )
    (local.set $local3
     (array.get $type34
      (ref.as_non_null
       (local.get $local4)
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local5)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local5)
       )
      )
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global835)
     )
    )
    (drop
     (call $function225
      (struct.get $type203 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local1
     (local.get $argument849)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized848)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture848)
    )
    (return_call $function227
     (ref.as_non_null
      (local.get $capture847)
     )
     (local.get $capture848)
     (local.get $initialized848)
     (local.get $local0)
    )
   )
  )
 )
 (func $function228 (type $call205) (param $environment eqref) (param $argument852 (ref $type36)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 (ref null $type36))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument852)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local4)
      )
     )
    )
   )
  )
  (call $foreign26
   (local.get $local3)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local0
   (i64.const 0)
  )
  (local.set $local2
   (i32.const 0)
  )
  (local.set $local1
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local2)
  )
  (return_call $function229
   (ref.as_non_null
    (local.get $argument852)
   )
   (local.get $local2)
   (local.get $local1)
   (local.get $local0)
  )
 )
 (func $function229 (param $capture852 (ref $type36)) (param $capture853 i32) (param $initialized853 i32) (param $argument854 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local4 (ref null $type36))
  (local $local8 (ref null $type36))
  (local.set $local6
   (local.get $argument854)
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $capture852)
   )
  )
  (local.set $local7
   (i64.extend_i32_u
    (array.len
     (struct.get $type36 1
      (ref.as_non_null
       (local.get $local8)
      )
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture852)
     )
    )
    (local.set $local5
     (local.get $argument854)
    )
    (local.set $local3
     (i64.extend_i32_u
      (array.get_u $type37
       (struct.get $type36 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.get $local5)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $local5)
        )
       )
      )
     )
    )
    (call $foreign26
     (local.get $local3)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument854)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized853)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture853)
    )
    (return_call $function229
     (ref.as_non_null
      (local.get $capture852)
     )
     (local.get $capture853)
     (local.get $initialized853)
     (local.get $local0)
    )
   )
  )
 )
 (func $function230 (type $call5) (param $environment eqref) (result i64)
  (local $local0 (ref null $type18))
  (local $local1 (ref null $type128))
  (local $local2 (ref null $type127))
  (local.set $local0
   (global.get $string67)
  )
  (local.set $local1
   (struct.new $type128
    (ref.func $function231)
    (ref.null none)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global862)
   )
  )
  (return_call $function233
   (struct.get $type127 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function231 (type $call128) (param $environment eqref) (param $argument856 (ref $type121)) (result i64)
  (local $local0 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local.set $local0
   (i64.const 0)
  )
  (local.set $local2
   (i32.const 0)
  )
  (local.set $local1
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local2)
  )
  (return_call $function232
   (ref.as_non_null
    (local.get $argument856)
   )
   (local.get $local2)
   (local.get $local1)
   (local.get $local0)
  )
 )
 (func $function232 (param $capture856 (ref $type121)) (param $capture857 i32) (param $initialized857 i32) (param $argument858 i64) (result i64)
  (local $local0 i32)
  (local $local4 i32)
  (local $local13 i32)
  (local $local8 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local1 (ref null $type101))
  (local $local9 (ref null $type101))
  (local $local2 (ref null $type121))
  (local $local10 (ref null $type121))
  (local $local3 (ref null $type148))
  (local $local11 (ref null $type148))
  (local $local5 (ref null $type18))
  (local $local6 (ref null $type18))
  (local $local7 (ref null $type116))
  (local $local12 (ref null $type146))
  (local $local14 (ref null $type13))
  (local $local18 (ref null $type13))
  (local $local19 (ref null $type203))
  (local.set $local2
   (ref.as_non_null
    (local.get $capture856)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $local1
   (call $function153
    (struct.get $type148 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i32.eq
    (struct.get $type101 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (struct.get $type103 1
      (ref.cast (ref $type103)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local13
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local13)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (local.set $local19
     (ref.as_non_null
      (global.get $global835)
     )
    )
    (drop
     (call $function225
      (struct.get $type203 1
       (ref.as_non_null
        (local.get $local19)
       )
      )
      (ref.as_non_null
       (local.get $local18)
      )
     )
    )
    (local.set $local16
     (local.get $argument858)
    )
    (local.set $local17
     (i64.const 1)
    )
    (local.set $local15
     (i64.add
      (local.get $local16)
      (local.get $local17)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized857)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture857)
    )
    (return_call $function232
     (ref.as_non_null
      (local.get $capture856)
     )
     (local.get $capture857)
     (local.get $initialized857)
     (local.get $local15)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i32.eq
      (struct.get $type101 0
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (i32.const 0)
     )
     (then
      (local.set $local10
       (ref.as_non_null
        (local.get $capture856)
       )
      )
      (local.set $local11
       (ref.as_non_null
        (global.get $global525)
       )
      )
      (local.set $local9
       (call $function153
        (struct.get $type148 1
         (ref.as_non_null
          (local.get $local11)
         )
        )
        (ref.as_non_null
         (local.get $local10)
        )
       )
      )
      (local.set $local12
       (ref.as_non_null
        (global.get $global515)
       )
      )
      (if (result i64)
       (call $function151
        (struct.get $type146 1
         (ref.as_non_null
          (local.get $local12)
         )
        )
        (ref.as_non_null
         (local.get $local9)
        )
       )
       (then
        (local.get $argument858)
       )
       (else
        (unreachable)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local5
       (struct.get $type104 1
        (ref.cast (ref $type104)
         (ref.as_non_null
          (local.get $local1)
         )
        )
       )
      )
      (local.set $local4
       (i32.const 1)
      )
      (local.set $local8
       (i64.const 99)
      )
      (call $foreign26
       (local.get $local8)
      )
      (drop
       (i32.const 0)
      )
      (if
       (i32.eqz
        (local.get $local4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global819)
       )
      )
      (drop
       (call $function221
        (struct.get $type116 1
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (ref.as_non_null
         (local.get $local6)
        )
       )
      )
      (i64.const -1)
     )
    )
   )
  )
 )
 (func $function233 (type $call127) (param $environment eqref) (param $argument863 (ref $type18)) (param $argument864 (ref $type128)) (result i64)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i64)
  (local $local1 (ref null $type121))
  (local $local6 (ref null $type121))
  (local $local8 (ref null $type121))
  (local $local2 (ref null $type18))
  (local $local3 (ref null $type120))
  (local $local7 (ref null $type128))
  (local $local9 (ref null $type123))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument863)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global455)
   )
  )
  (local.set $local1
   (call $function132
    (struct.get $type120 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (local.get $argument864)
   )
  )
  (local.set $local5
   (call_ref $call128
    (struct.get $type128 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (struct.get $type128 0
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global462)
   )
  )
  (drop
   (call $function135
    (struct.get $type123 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local8)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.get $local5)
 )
 (func $export0 (result i64)
  (local $local0 (ref null $type5))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready801)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global801)
   )
  )
  (return_call $function217
   (struct.get $type5 1
    (ref.as_non_null
     (local.get $local0)
    )
   )
  )
 )
 (func $export1 (result i64)
  (local $local0 (ref null $type5))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready855)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global855)
   )
  )
  (return_call $function230
   (struct.get $type5 1
    (ref.as_non_null
     (local.get $local0)
    )
   )
  )
 )
 (func $export2 (result i32)
  (local $local0 (ref null $type8))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready805)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global805)
   )
  )
  (return_call $function218
   (struct.get $type8 1
    (ref.as_non_null
     (local.get $local0)
    )
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new $type0
    (ref.func $function0)
    (ref.null none)
   )
  )
  (global.set $ready0
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global3
   (struct.new $type1
    (ref.func $function1)
    (ref.null none)
   )
  )
  (global.set $ready3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global6
   (struct.new $type0
    (ref.func $function2)
    (ref.null none)
   )
  )
  (global.set $ready6
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global9
   (struct.new $type1
    (ref.func $function3)
    (ref.null none)
   )
  )
  (global.set $ready9
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global12
   (struct.new $type0
    (ref.func $function4)
    (ref.null none)
   )
  )
  (global.set $ready12
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global15
   (struct.new $type1
    (ref.func $function5)
    (ref.null none)
   )
  )
  (global.set $ready15
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global18
   (struct.new $type0
    (ref.func $function6)
    (ref.null none)
   )
  )
  (global.set $ready18
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global21
   (struct.new $type1
    (ref.func $function7)
    (ref.null none)
   )
  )
  (global.set $ready21
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global24
   (struct.new $type2
    (ref.func $function8)
    (ref.null none)
   )
  )
  (global.set $ready24
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global27
   (struct.new $type3
    (ref.func $function9)
    (ref.null none)
   )
  )
  (global.set $ready27
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global30
   (struct.new $type2
    (ref.func $function10)
    (ref.null none)
   )
  )
  (global.set $ready30
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global33
   (struct.new $type3
    (ref.func $function11)
    (ref.null none)
   )
  )
  (global.set $ready33
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global36
   (struct.new $type2
    (ref.func $function12)
    (ref.null none)
   )
  )
  (global.set $ready36
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global39
   (struct.new $type3
    (ref.func $function13)
    (ref.null none)
   )
  )
  (global.set $ready39
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global42
   (struct.new $type2
    (ref.func $function14)
    (ref.null none)
   )
  )
  (global.set $ready42
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global45
   (struct.new $type3
    (ref.func $function15)
    (ref.null none)
   )
  )
  (global.set $ready45
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global48
   (struct.new $type2
    (ref.func $function16)
    (ref.null none)
   )
  )
  (global.set $ready48
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global51
   (struct.new $type3
    (ref.func $function17)
    (ref.null none)
   )
  )
  (global.set $ready51
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global54
   (struct.new $type4
    (ref.func $function18)
    (ref.null none)
   )
  )
  (global.set $ready54
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global55
   (struct.new $type5
    (ref.func $function19)
    (ref.null none)
   )
  )
  (global.set $ready55
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global56
   (struct.new $type6
    (ref.func $function20)
    (ref.null none)
   )
  )
  (global.set $ready56
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global57
   (struct.new $type7
    (ref.func $function21)
    (ref.null none)
   )
  )
  (global.set $ready57
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global58
   (struct.new $type8
    (ref.func $function22)
    (ref.null none)
   )
  )
  (global.set $ready58
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global59
   (struct.new $type9
    (ref.func $function23)
    (ref.null none)
   )
  )
  (global.set $ready59
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global60
   (struct.new $type10
    (ref.func $function24)
    (ref.null none)
   )
  )
  (global.set $ready60
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global795
   (struct.new $type11
    (ref.func $function215)
    (ref.null none)
   )
  )
  (global.set $ready795
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global726
   (struct.new $type38
    (ref.func $function202)
    (ref.null none)
   )
  )
  (global.set $ready726
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global68
   (struct.new $type39
    (ref.func $function28)
    (ref.null none)
   )
  )
  (global.set $ready68
   (i32.const 1)
  )
  (global.set $global729
   (struct.new $type41
    (ref.func $function203)
    (ref.null none)
   )
  )
  (global.set $ready729
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global797
   (struct.new $type42
    (ref.func $function216)
    (ref.null none)
   )
  )
  (global.set $ready797
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global61
   (struct.new $type43
    (ref.func $function25)
    (ref.null none)
   )
  )
  (global.set $ready61
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global63
   (struct.new $type44
    (ref.func $function26)
    (ref.null none)
   )
  )
  (global.set $ready63
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global65
   (struct.new $type45
    (ref.func $function27)
    (ref.null none)
   )
  )
  (global.set $ready65
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global76
   (struct.new $type46
    (ref.func $function31)
    (ref.null none)
   )
  )
  (global.set $ready76
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global81
   (struct.new $type47
    (ref.func $function33)
    (ref.null none)
   )
  )
  (global.set $ready81
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global88
   (struct.new $type48
    (ref.func $function34)
    (ref.null none)
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global90
   (struct.new $type49
    (ref.func $function35)
    (ref.null none)
   )
  )
  (global.set $ready90
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global93
   (struct.new $type51
    (ref.func $function36)
    (ref.null none)
   )
  )
  (global.set $ready93
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global98
   (struct.new $type52
    (ref.func $function38)
    (ref.null none)
   )
  )
  (global.set $ready98
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global103
   (struct.new $type53
    (ref.func $function39)
    (ref.null none)
   )
  )
  (global.set $ready103
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global109
   (struct.new $type54
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global111
   (struct.new $type55
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $ready111
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global114
   (struct.new $type57
    (ref.func $function43)
    (ref.null none)
   )
  )
  (global.set $ready114
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global135
   (struct.new $type58
    (ref.func $function49)
    (ref.null none)
   )
  )
  (global.set $ready135
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global122
   (struct.new $type59
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready122
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global127
   (struct.new $type60
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $ready127
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global131
   (struct.new $type61
    (ref.func $function48)
    (ref.null none)
   )
  )
  (global.set $ready131
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global142
   (struct.new $type62
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready142
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global145
   (struct.new $type63
    (ref.func $function51)
    (ref.null none)
   )
  )
  (global.set $ready145
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global147
   (struct.new $type64
    (ref.func $function52)
    (ref.null none)
   )
  )
  (global.set $ready147
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global150
   (struct.new $type66
    (ref.func $function53)
    (ref.null none)
   )
  )
  (global.set $ready150
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global182
   (struct.new $type67
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $ready182
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global188
   (struct.new $type67
    (ref.func $function63)
    (ref.null none)
   )
  )
  (global.set $ready188
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global193
   (struct.new $type67
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $ready193
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global177
   (struct.new $type68
    (ref.func $function60)
    (ref.null none)
   )
  )
  (global.set $ready177
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global159
   (struct.new $type69
    (ref.func $function56)
    (ref.null none)
   )
  )
  (global.set $ready159
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global184
   (struct.new $type70
    (ref.func $function62)
    (ref.null none)
   )
  )
  (global.set $ready184
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global169
   (struct.new $type68
    (ref.func $function58)
    (ref.null none)
   )
  )
  (global.set $ready169
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global195
   (struct.new $type71
    (ref.func $function66)
    (ref.null none)
   )
  )
  (global.set $ready195
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global164
   (struct.new $type72
    (ref.func $function57)
    (ref.null none)
   )
  )
  (global.set $ready164
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global204
   (struct.new $type73
    (ref.func $function68)
    (ref.null none)
   )
  )
  (global.set $ready204
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global207
   (struct.new $type74
    (ref.func $function69)
    (ref.null none)
   )
  )
  (global.set $ready207
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global229
   (struct.new $type67
    (ref.func $function75)
    (ref.null none)
   )
  )
  (global.set $ready229
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global222
   (struct.new $type75
    (ref.func $function73)
    (ref.null none)
   )
  )
  (global.set $ready222
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global209
   (struct.new $type76
    (ref.func $function70)
    (ref.null none)
   )
  )
  (global.set $ready209
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global231
   (struct.new $type77
    (ref.func $function76)
    (ref.null none)
   )
  )
  (global.set $ready231
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global217
   (struct.new $type78
    (ref.func $function72)
    (ref.null none)
   )
  )
  (global.set $ready217
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global241
   (struct.new $type79
    (ref.func $function78)
    (ref.null none)
   )
  )
  (global.set $ready241
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global244
   (struct.new $type80
    (ref.func $function79)
    (ref.null none)
   )
  )
  (global.set $ready244
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global246
   (struct.new $type81
    (ref.func $function80)
    (ref.null none)
   )
  )
  (global.set $ready246
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global252
   (struct.new $type82
    (ref.func $function82)
    (ref.null none)
   )
  )
  (global.set $ready252
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global254
   (struct.new $type83
    (ref.func $function83)
    (ref.null none)
   )
  )
  (global.set $ready254
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global258
   (struct.new $type84
    (ref.func $function84)
    (ref.null none)
   )
  )
  (global.set $ready258
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global260
   (struct.new $type85
    (ref.func $function85)
    (ref.null none)
   )
  )
  (global.set $ready260
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global263
   (struct.new $type86
    (ref.func $function86)
    (ref.null none)
   )
  )
  (global.set $ready263
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global270
   (struct.new $type67
    (ref.func $function88)
    (ref.null none)
   )
  )
  (global.set $ready270
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global275
   (struct.new $type43
    (ref.func $function90)
    (ref.null none)
   )
  )
  (global.set $ready275
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global284
   (struct.new $type87
    (ref.func $function92)
    (ref.null none)
   )
  )
  (global.set $ready284
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global289
   (struct.new $type88
    (ref.func $function93)
    (ref.null none)
   )
  )
  (global.set $ready289
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global296
   (struct.new $type89
    (ref.func $function94)
    (ref.null none)
   )
  )
  (global.set $ready296
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global299
   (struct.new $type90
    (ref.func $function95)
    (ref.null none)
   )
  )
  (global.set $ready299
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global305
   (struct.new $type91
    (ref.func $function97)
    (ref.null none)
   )
  )
  (global.set $ready305
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global308
   (struct.new $type96
    (ref.func $function98)
    (ref.null none)
   )
  )
  (global.set $ready308
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global313
   (struct.new $type97
    (ref.func $function99)
    (ref.null none)
   )
  )
  (global.set $ready313
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global325
   (struct.new $type98
    (ref.func $function100)
    (ref.null none)
   )
  )
  (global.set $ready325
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global332
   (struct.new $type99
    (ref.func $function101)
    (ref.null none)
   )
  )
  (global.set $ready332
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global340
   (struct.new $type100
    (ref.func $function102)
    (ref.null none)
   )
  )
  (global.set $ready340
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global347
   (struct.new $type105
    (ref.func $function103)
    (ref.null none)
   )
  )
  (global.set $ready347
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global351
   (struct.new $type106
    (ref.func $function104)
    (ref.null none)
   )
  )
  (global.set $ready351
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global354
   (struct.new $type107
    (ref.func $function105)
    (ref.null none)
   )
  )
  (global.set $ready354
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global356
   (struct.new $type107
    (ref.func $function106)
    (ref.null none)
   )
  )
  (global.set $ready356
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global358
   (struct.new $type108
    (ref.func $function107)
    (ref.null none)
   )
  )
  (global.set $ready358
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global361
   (struct.new $type108
    (ref.func $function108)
    (ref.null none)
   )
  )
  (global.set $ready361
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global364
   (struct.new $type109
    (ref.func $function109)
    (ref.null none)
   )
  )
  (global.set $ready364
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global376
   (struct.new $type110
    (ref.func $function110)
    (ref.null none)
   )
  )
  (global.set $ready376
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global378
   (struct.new $type110
    (ref.func $function111)
    (ref.null none)
   )
  )
  (global.set $ready378
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global380
   (struct.new $type110
    (ref.func $function112)
    (ref.null none)
   )
  )
  (global.set $ready380
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global382
   (struct.new $type110
    (ref.func $function113)
    (ref.null none)
   )
  )
  (global.set $ready382
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global384
   (struct.new $type111
    (ref.func $function114)
    (ref.null none)
   )
  )
  (global.set $ready384
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global397
   (struct.new $type112
    (ref.func $function115)
    (ref.null none)
   )
  )
  (global.set $ready397
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global401
   (struct.new $type109
    (ref.func $function117)
    (ref.null none)
   )
  )
  (global.set $ready401
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global406
   (struct.new $type106
    (ref.func $function119)
    (ref.null none)
   )
  )
  (global.set $ready406
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global409
   (struct.new $type106
    (ref.func $function120)
    (ref.null none)
   )
  )
  (global.set $ready409
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global413
   (struct.new $type113
    (ref.func $function121)
    (ref.null none)
   )
  )
  (global.set $ready413
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global417
   (struct.new $type111
    (ref.func $function122)
    (ref.null none)
   )
  )
  (global.set $ready417
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global429
   (struct.new $type114
    (ref.func $function123)
    (ref.null none)
   )
  )
  (global.set $ready429
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global437
   (struct.new $type115
    (ref.func $function125)
    (ref.null none)
   )
  )
  (global.set $ready437
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global444
   (struct.new $type116
    (ref.func $function127)
    (ref.null none)
   )
  )
  (global.set $ready444
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global449
   (struct.new $type83
    (ref.func $function129)
    (ref.null none)
   )
  )
  (global.set $ready449
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global451
   (struct.new $type116
    (ref.func $function130)
    (ref.null none)
   )
  )
  (global.set $ready451
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global453
   (struct.new $type117
    (ref.func $function131)
    (ref.null none)
   )
  )
  (global.set $ready453
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global455
   (struct.new $type120
    (ref.func $function132)
    (ref.null none)
   )
  )
  (global.set $ready455
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global457
   (struct.new $type122
    (ref.func $function133)
    (ref.null none)
   )
  )
  (global.set $ready457
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global462
   (struct.new $type123
    (ref.func $function135)
    (ref.null none)
   )
  )
  (global.set $ready462
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global459
   (struct.new $type124
    (ref.func $function134)
    (ref.null none)
   )
  )
  (global.set $ready459
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global814
   (struct.new $type125
    (ref.func $function220)
    (ref.null none)
   )
  )
  (global.set $ready814
   (i32.const 1)
  )
  (global.set $global862
   (struct.new $type127
    (ref.func $function233)
    (ref.null none)
   )
  )
  (global.set $ready862
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global464
   (struct.new $type129
    (ref.func $function136)
    (ref.null none)
   )
  )
  (global.set $ready464
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global468
   (struct.new $type133
    (ref.func $function137)
    (ref.null none)
   )
  )
  (global.set $ready468
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global470
   (struct.new $type134
    (ref.func $function138)
    (ref.null none)
   )
  )
  (global.set $ready470
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global472
   (struct.new $type134
    (ref.func $function139)
    (ref.null none)
   )
  )
  (global.set $ready472
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global474
   (struct.new $type135
    (ref.func $function140)
    (ref.null none)
   )
  )
  (global.set $ready474
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global478
   (struct.new $type139
    (ref.func $function141)
    (ref.null none)
   )
  )
  (global.set $ready478
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global489
   (struct.new $type140
    (ref.func $function143)
    (ref.null none)
   )
  )
  (global.set $ready489
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global482
   (struct.new $type141
    (ref.func $function142)
    (ref.null none)
   )
  )
  (global.set $ready482
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global492
   (struct.new $type142
    (ref.func $function144)
    (ref.null none)
   )
  )
  (global.set $ready492
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global497
   (struct.new $type143
    (ref.func $function145)
    (ref.null none)
   )
  )
  (global.set $ready497
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global500
   (struct.new $type144
    (ref.func $function146)
    (ref.null none)
   )
  )
  (global.set $ready500
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global506
   (struct.new $type122
    (ref.func $function148)
    (ref.null none)
   )
  )
  (global.set $ready506
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global508
   (struct.new $type145
    (ref.func $function149)
    (ref.null none)
   )
  )
  (global.set $ready508
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global511
   (struct.new $type145
    (ref.func $function150)
    (ref.null none)
   )
  )
  (global.set $ready511
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global515
   (struct.new $type146
    (ref.func $function151)
    (ref.null none)
   )
  )
  (global.set $ready515
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global520
   (struct.new $type147
    (ref.func $function152)
    (ref.null none)
   )
  )
  (global.set $ready520
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global525
   (struct.new $type148
    (ref.func $function153)
    (ref.null none)
   )
  )
  (global.set $ready525
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global532
   (struct.new $type149
    (ref.func $function156)
    (ref.null none)
   )
  )
  (global.set $ready532
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global552
   (struct.new $type128
    (ref.func $function162)
    (ref.null none)
   )
  )
  (global.set $ready552
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global530
   (struct.new $type128
    (ref.func $function155)
    (ref.null none)
   )
  )
  (global.set $ready530
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global538
   (struct.new $type150
    (ref.func $function158)
    (ref.null none)
   )
  )
  (global.set $ready538
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global549
   (struct.new $type151
    (ref.func $function161)
    (ref.null none)
   )
  )
  (global.set $ready549
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global536
   (struct.new $type152
    (ref.func $function157)
    (ref.null none)
   )
  )
  (global.set $ready536
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global643
   (struct.new $type152
    (ref.func $function184)
    (ref.null none)
   )
  )
  (global.set $ready643
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global562
   (struct.new $type153
    (ref.func $function165)
    (ref.null none)
   )
  )
  (global.set $ready562
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global611
   (struct.new $type157
    (ref.func $function177)
    (ref.null none)
   )
  )
  (global.set $ready611
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global615
   (struct.new $type158
    (ref.func $function178)
    (ref.null none)
   )
  )
  (global.set $ready615
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global568
   (struct.new $type159
    (ref.func $function167)
    (ref.null none)
   )
  )
  (global.set $ready568
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global658
   (struct.new $type160
    (ref.func $function185)
    (ref.null none)
   )
  )
  (global.set $ready658
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global666
   (struct.new $type48
    (ref.func $function188)
    (ref.null none)
   )
  )
  (global.set $ready666
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global541
   (struct.new $type123
    (ref.func $function159)
    (ref.null none)
   )
  )
  (global.set $ready541
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global635
   (struct.new $type161
    (ref.func $function182)
    (ref.null none)
   )
  )
  (global.set $ready635
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global630
   (struct.new $type162
    (ref.func $function181)
    (ref.null none)
   )
  )
  (global.set $ready630
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global527
   (struct.new $type162
    (ref.func $function154)
    (ref.null none)
   )
  )
  (global.set $ready527
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global546
   (struct.new $type171
    (ref.func $function160)
    (ref.null none)
   )
  )
  (global.set $ready546
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global627
   (struct.new $type162
    (ref.func $function180)
    (ref.null none)
   )
  )
  (global.set $ready627
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global684
   (struct.new $type162
    (ref.func $function193)
    (ref.null none)
   )
  )
  (global.set $ready684
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global686
   (struct.new $type172
    (ref.func $function194)
    (ref.null none)
   )
  )
  (global.set $ready686
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global697
   (struct.new $type172
    (ref.func $function195)
    (ref.null none)
   )
  )
  (global.set $ready697
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global554
   (struct.new $type173
    (ref.func $function163)
    (ref.null none)
   )
  )
  (global.set $ready554
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global559
   (struct.new $type174
    (ref.func $function164)
    (ref.null none)
   )
  )
  (global.set $ready559
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global563
   (struct.new $type178
    (ref.func $function166)
    (ref.null none)
   )
  )
  (global.set $ready563
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global621
   (struct.new $type179
    (ref.func $function179)
    (ref.null none)
   )
  )
  (global.set $ready621
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global604
   (struct.new $type180
    (ref.func $function176)
    (ref.null none)
   )
  )
  (global.set $ready604
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global570
   (struct.new $type185
    (ref.func $function168)
    (ref.null none)
   )
  )
  (global.set $ready570
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global591
   (struct.new $type152
    (ref.func $function173)
    (ref.null none)
   )
  )
  (global.set $ready591
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global601
   (struct.new $type123
    (ref.func $function175)
    (ref.null none)
   )
  )
  (global.set $ready601
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global596
   (struct.new $type186
    (ref.func $function174)
    (ref.null none)
   )
  )
  (global.set $ready596
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global588
   (struct.new $type67
    (ref.func $function172)
    (ref.null none)
   )
  )
  (global.set $ready588
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global584
   (struct.new $type152
    (ref.func $function171)
    (ref.null none)
   )
  )
  (global.set $ready584
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global581
   (struct.new $type187
    (ref.func $function170)
    (ref.null none)
   )
  )
  (global.set $ready581
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global576
   (struct.new $type188
    (ref.func $function169)
    (ref.null none)
   )
  )
  (global.set $ready576
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global674
   (struct.new $type189
    (ref.func $function191)
    (ref.null none)
   )
  )
  (global.set $ready674
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global640
   (struct.new $type162
    (ref.func $function183)
    (ref.null none)
   )
  )
  (global.set $ready640
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global663
   (struct.new $type172
    (ref.func $function187)
    (ref.null none)
   )
  )
  (global.set $ready663
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global672
   (struct.new $type189
    (ref.func $function190)
    (ref.null none)
   )
  )
  (global.set $ready672
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global702
   (struct.new $type190
    (ref.func $function196)
    (ref.null none)
   )
  )
  (global.set $ready702
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global780
   (struct.new $type191
    (ref.func $function212)
    (ref.null none)
   )
  )
  (global.set $ready780
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global709
   (struct.new $type192
    (ref.func $function197)
    (ref.null none)
   )
  )
  (global.set $ready709
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global770
   (struct.new $type193
    (ref.func $function211)
    (ref.null none)
   )
  )
  (global.set $ready770
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global756
   (struct.new $type194
    (ref.func $function210)
    (ref.null none)
   )
  )
  (global.set $ready756
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global718
   (struct.new $type195
    (ref.func $function199)
    (ref.null none)
   )
  )
  (global.set $ready718
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global721
   (struct.new $type196
    (ref.func $function200)
    (ref.null none)
   )
  )
  (global.set $ready721
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global715
   (struct.new $type197
    (ref.func $function198)
    (ref.null none)
   )
  )
  (global.set $ready715
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global737
   (struct.new $type198
    (ref.func $function206)
    (ref.null none)
   )
  )
  (global.set $ready737
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global748
   (struct.new $type109
    (ref.func $function209)
    (ref.null none)
   )
  )
  (global.set $ready748
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global743
   (struct.new $type199
    (ref.func $function208)
    (ref.null none)
   )
  )
  (global.set $ready743
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global786
   (struct.new $type200
    (ref.func $function213)
    (ref.null none)
   )
  )
  (global.set $ready786
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global788
   (struct.new $type8
    (ref.func $function214)
    (ref.null none)
   )
  )
  (global.set $ready788
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global801
   (struct.new $type5
    (ref.func $function217)
    (ref.null none)
   )
  )
  (global.set $ready801
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global805
   (struct.new $type8
    (ref.func $function218)
    (ref.null none)
   )
  )
  (global.set $ready805
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global819
   (struct.new $type116
    (ref.func $function221)
    (ref.null none)
   )
  )
  (global.set $ready819
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global823
   (struct.new $type201
    (ref.func $function223)
    (ref.null none)
   )
  )
  (global.set $ready823
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global828
   (struct.new $type202
    (ref.func $function224)
    (ref.null none)
   )
  )
  (global.set $ready828
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global835
   (struct.new $type203
    (ref.func $function225)
    (ref.null none)
   )
  )
  (global.set $ready835
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global846
   (struct.new $type204
    (ref.func $function226)
    (ref.null none)
   )
  )
  (global.set $ready846
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global851
   (struct.new $type205
    (ref.func $function228)
    (ref.null none)
   )
  )
  (global.set $ready851
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global855
   (struct.new $type5
    (ref.func $function230)
    (ref.null none)
   )
  )
  (global.set $ready855
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

