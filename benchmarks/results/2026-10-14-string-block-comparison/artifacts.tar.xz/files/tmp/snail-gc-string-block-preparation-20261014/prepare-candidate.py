"""Rebuild the frozen full String sources with the String-block compiler only."""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/tmp/snail-gc-string-blocks-20261014')
FREEZE = Path(__file__).resolve().parent
BASELINE = FREEZE / 'baseline'
CANDIDATE = FREEZE / 'candidate'


# ---- Source-only representation difference ----


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


compiler = CANDIDATE / 'compiler-source'
sources = [*ROOT.glob('src/**/*.sld'), ROOT / 'scripts/build-strict', ROOT / 'tests/build-strict-program.scm']
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
compiler_differences = []
for source in sources:
    relative = source.relative_to(ROOT)
    assert source.read_bytes() == (compiler / relative).read_bytes(), str(relative)
    assert source.read_bytes() == subprocess.check_output(['git', 'show', revision + ':' + str(relative)], cwd=ROOT)
    if source.read_bytes() != (BASELINE / 'compiler-source' / relative).read_bytes():
        compiler_differences.append(str(relative))
assert compiler_differences == ['src/snail-scheme/strict-wasm.sld'], compiler_differences
shared = ['host.mjs', 'measure.py', 'r7rs.py', 'string_port.py',
          'string/host.mjs', 'string/strict.scm', 'string/upstream.scm',
          'string/original-kernel.scm', 'string/adapted-kernel.scm',
          'string/program.scm', 'string/same-source-chez/program.scm',
          'string/input.txt', 'string/spec.json', 'string/source-proof.json',
          'string/kernel-adaptation.patch', 'string/complete-source-adaptation.patch']
for relative in shared:
    assert (BASELINE / relative).read_bytes() == (CANDIDATE / relative).read_bytes(), relative
source_proof = dict(compiler_commit=revision, compiler_differences=compiler_differences,
                    shared_files={name: digest(CANDIDATE / name) for name in shared},
                    canonical_spec=json.loads((CANDIDATE / 'string/spec.json').read_text()),
                    baseline_manifest_sha256=digest(FREEZE / 'baseline-manifest.json'))
save(FREEZE / 'source-comparison.json', source_proof)


# ---- Established full-source preparation and complete-value probes ----


sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
spec = importlib.util.spec_from_file_location('storage_preparation', ROOT / 'benchmarks/strict-suite/measure.py')
preparation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(preparation)
runner = preparation.upstream_runner()
tools = preparation.tool_paths(('string',))
environment = {**os.environ, **tools, 'BINARYEN_CORES': '1'}
preparation.ROOT = compiler
directory = CANDIDATE / 'string'
for name in ('strict-output-probe', 'strict-alias-probe', 'chez-output-original',
             'chez-output-adapted', 'chez-alias-original', 'chez-alias-adapted'):
    shutil.rmtree(directory / name)
preparation.build_strict(directory, tools, environment)
print('Canonical raw/optimized candidate rebuilt from frozen compiler.', flush=True)
chez_command = preparation.build_chez(directory, runner, environment, 'chez-build.json')
preparation.build_chez(directory / 'same-source-chez', runner, environment, 'build.json')
preparation.validate_strict(directory, tools, environment)
print('Canonical counts 1, 2 and 100 passed in raw/optimized Node.', flush=True)
preparation.validate_chez(directory, runner, tools, environment, source_proof['canonical_spec'])
preparation.validate_string_outputs(directory, runner, tools, environment)
print('Complete Unicode payload/store, alias and harness probes passed across four systems.', flush=True)


# ---- Hash-frozen handoff, with no comparative measurements ----


report = json.loads((BASELINE / 'prepared.json').read_text())
report.update(date=datetime.now(timezone.utc).isoformat(), compiler_commit=revision,
              compiler_files={str(p.relative_to(compiler)): digest(p) for p in compiler.rglob('*') if p.is_file()},
              preparation_note='Frozen baseline sources rebuilt with only strict-wasm String storage changed; correctness executions only.')
case = report['cases'][0]
case.update(status='ready', chez_command=chez_command,
            hashes={str(p.relative_to(directory)): digest(p) for p in directory.rglob('*') if p.is_file()})
save(CANDIDATE / 'prepared.json', report)
save(FREEZE / 'candidate-manifest.json', dict(compiler_commit=revision, files={
    str(p.relative_to(CANDIDATE)): digest(p) for p in CANDIDATE.rglob('*') if p.is_file()}))
save(FREEZE / 'handoff.json', dict(
    baseline=str(BASELINE), candidate=str(CANDIDATE), compiler_commit=revision,
    source_proof=str(FREEZE / 'source-comparison.json'),
    baseline_manifest_sha256=digest(FREEZE / 'baseline-manifest.json'),
    candidate_manifest_sha256=digest(FREEZE / 'candidate-manifest.json'),
    canonical_artifacts={system: {name: digest(path / 'string' / name) for name in (
        'strict.scm', 'strict.wasm.raw.wasm', 'strict.wasm', 'strict.optimized.wat', 'spec.json')}
        for system, path in [('baseline', BASELINE), ('candidate', CANDIDATE)]},
    checks=dict(focused_contracts=15, raw_and_optimized=True, actual_node=True,
                make_test='passed', make_check='passed', complete_value_probes='passed',
                original_full_count=100, threshold=500000, original_expected=524278),
    measurement='Parent-owned clean comparison; no comparative worker timings.'))
print(json.dumps(dict(handoff=str(FREEZE / 'handoff.json'), compiler_commit=revision)), flush=True)
