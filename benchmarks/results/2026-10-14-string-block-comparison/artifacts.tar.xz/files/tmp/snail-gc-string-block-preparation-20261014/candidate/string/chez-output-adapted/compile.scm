(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-gc-string-block-preparation-20261014/candidate/string/chez-output-adapted/program.scm" "/tmp/snail-gc-string-block-preparation-20261014/candidate/string/chez-output-adapted/program.so"))
