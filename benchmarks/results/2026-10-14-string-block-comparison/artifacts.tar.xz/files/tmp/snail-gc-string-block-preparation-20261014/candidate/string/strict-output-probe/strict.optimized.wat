(module
 (rec
  (type $0 (func (param i64 i32 i32 i64) (result i64)))
  (type $1 (func (param (ref $type14) i32 i32 i64) (result i32)))
  (type $call28 (func (result (ref $type14))))
  (type $call25 (func (param (ref $type14) (ref null $type23) i64) (result i32)))
  (type $4 (func (param i32 i32 (ref null $type23) i64) (result i64)))
  (type $type23 (struct (field (ref $type14)) (field (ref null $type23))))
  (type $call22 (func (param (ref $type23)) (result (ref $type14))))
  (type $call20 (func (param (ref $type14) i64 i64) (result (ref $type14))))
  (type $8 (func (param (ref $type14) i64 (ref $type14) i64 i64)))
  (type $type16 (array (mut (ref null $type15))))
  (type $10 (func (param i32) (result (ref $type14))))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type5 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct (field (mut (ref $type14)))))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type22 (struct))
  (type $type20 (struct))
  (type $type13 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $26 (func (param i64)))
 (type $27 (func (result i64)))
 (type $28 (func (result i32)))
 (type $29 (func (param i32)))
 (type $30 (func (param i64) (result i64)))
 (type $31 (func (param i64 i32)))
 (type $32 (func (param i64) (result i32)))
 (type $33 (func))
 (import "probe" "length" (func $foreign0 (param i64)))
 (import "probe" "trace" (func $foreign1 (result i32)))
 (import "probe" "character" (func $foreign2 (param i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 49)
   (i32.const 50)
   (i32.const 51)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 52)
   (i32.const 53)
   (i32.const 54)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 55)
   (i32.const 56)
   (i32.const 57)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 97)
   (i32.const 98)
   (i32.const 99)
   (i32.const 100)
   (i32.const 101)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type22)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type24)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type25)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type28)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type29)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type30)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type29)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type5)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type31)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type32)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type33)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type5)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (export "probe-run" (func $export0))
 (export "probe-grow" (func $export1))
 (export "probe-seed" (func $export2))
 (export "probe-set-character" (func $export3))
 (export "probe-character" (func $export4))
 (export "probe-length" (func $export5))
 (export "main" (func $main))
 (func $string-new (type $10) (param $0 i32) (result (ref $type14))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type16))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type14
   (i32.const 1)
   (local.get $0)
   (array.new_default $type15
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-copy (type $8) (param $0 (ref $type14)) (param $1 i64) (param $2 (ref $type14)) (param $3 i64) (param $4 i64)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (if
   (i32.ne
    (struct.get $type14 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $4)
     (local.get $3)
    )
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.gt_u
     (local.get $1)
     (local.get $3)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (i64.sub
         (local.get $4)
         (local.get $3)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $8
     (i32.add
      (i32.wrap_i64
       (local.get $3)
      )
      (local.get $7)
     )
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type15 $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $5
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $8)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $5)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $8
           (i32.sub
            (local.get $8)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $8)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $7
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $5
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $8
     (i32.wrap_i64
      (i64.sub
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (loop $label1
     (if
      (local.get $8)
      (then
       (local.set $6
        (select
         (local.get $8)
         (local.tee $6
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $9
              (i32.and
               (local.get $7)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $11
            (i32.sub
             (i32.const 8192)
             (local.tee $10
              (i32.and
               (local.get $5)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.lt_u
            (local.get $6)
            (local.get $11)
           )
          )
         )
         (i32.gt_u
          (local.get $6)
          (local.get $8)
         )
        )
       )
       (array.copy $type15 $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.get $7)
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $7)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $9)
        (if (result (ref $type15))
         (i32.lt_u
          (local.get $5)
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $10)
        (local.get $6)
       )
       (local.set $7
        (i32.add
         (local.get $6)
         (local.get $7)
        )
       )
       (local.set $5
        (i32.add
         (local.get $5)
         (local.get $6)
        )
       )
       (local.set $8
        (i32.sub
         (local.get $8)
         (local.get $6)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function33 (type $call20) (param $0 (ref $type14)) (param $1 i64) (param $2 i64) (result (ref $type14))
  (local $3 i32)
  (local $4 i64)
  (local $5 (ref $type14))
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $3
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (if (result i32)
      (local.tee $3
       (i64.gt_s
        (local.get $1)
        (local.get $2)
       )
      )
      (then
       (local.get $3)
      )
      (else
       (i64.lt_s
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (local.get $2)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (i64.sub
        (local.get $2)
        (local.get $1)
       )
      )
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (call $string-copy
     (local.tee $5
      (call $string-new
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (i64.const 0)
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
    (local.get $5)
   )
  )
 )
 (func $function35 (type $call22) (param $0 (ref $type23)) (result (ref $type14))
  (local $1 (ref null $type23))
  (local $2 (ref null $type23))
  (local $3 (ref null $type23))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $6 i64)
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $6
   (if (result i64)
    (i64.gt_u
     (local.tee $6
      (i64.extend_i32_u
       (struct.get $type14 1
        (struct.get $type23 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type23 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $3
        (struct.get $type23 1
         (local.get $1)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $6
          (i64.add
           (i64.extend_i32_u
            (struct.get $type14 1
             (struct.get $type23 0
              (local.get $1)
             )
            )
           )
           (local.get $6)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $2
            (struct.get $type23 1
             (local.get $3)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $6
              (i64.add
               (i64.extend_i32_u
                (struct.get $type14 1
                 (struct.get $type23 0
                  (local.get $3)
                 )
                )
               )
               (local.get $6)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $1
                (struct.get $type23 1
                 (local.get $2)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $6
                  (i64.add
                   (i64.extend_i32_u
                    (struct.get $type14 1
                     (struct.get $type23 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $6)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type23 1
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $6
                      (i64.add
                       (i64.extend_i32_u
                        (struct.get $type14 1
                         (struct.get $type23 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $6)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $1
                        (struct.get $type23 1
                         (local.get $2)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $6
                          (i64.add
                           (i64.extend_i32_u
                            (struct.get $type14 1
                             (struct.get $type23 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $6)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $2
                            (struct.get $type23 1
                             (local.get $1)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $6
                              (i64.add
                               (i64.extend_i32_u
                                (struct.get $type14 1
                                 (struct.get $type23 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.get $6)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $1
                                (struct.get $type23 1
                                 (local.get $2)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $6
                                  (i64.add
                                   (i64.extend_i32_u
                                    (struct.get $type14 1
                                     (struct.get $type23 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (call $function37
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type23 1
                                     (local.get $1)
                                    )
                                    (i64.add
                                     (i64.extend_i32_u
                                      (struct.get $type14 1
                                       (struct.get $type23 0
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (local.get $6)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-new
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (call $string-copy
   (local.get $5)
   (i64.const 0)
   (local.tee $4
    (struct.get $type23 0
     (local.get $0)
    )
   )
   (i64.const 0)
   (local.tee $7
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $4)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $1
      (struct.get $type23 1
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $string-copy
      (local.get $5)
      (local.get $7)
      (local.tee $4
       (struct.get $type23 0
        (local.get $1)
       )
      )
      (i64.const 0)
      (local.tee $6
       (i64.extend_i32_u
        (struct.get $type14 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (struct.get $type23 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready98)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global98)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $string-copy
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
        (local.tee $4
         (struct.get $type23 0
          (local.get $1)
         )
        )
        (i64.const 0)
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $4)
          )
         )
        )
       )
       (local.set $1
        (struct.get $type23 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready98)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global98)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $string-copy
          (local.get $5)
          (local.tee $7
           (i64.add
            (local.get $6)
            (local.get $7)
           )
          )
          (local.tee $4
           (struct.get $type23 0
            (local.get $1)
           )
          )
          (i64.const 0)
          (local.tee $6
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $4)
            )
           )
          )
         )
         (local.set $1
          (struct.get $type23 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready98)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global98)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $string-copy
            (local.get $5)
            (local.tee $7
             (i64.add
              (local.get $6)
              (local.get $7)
             )
            )
            (local.tee $4
             (struct.get $type23 0
              (local.get $1)
             )
            )
            (i64.const 0)
            (local.tee $6
             (i64.extend_i32_u
              (struct.get $type14 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (struct.get $type23 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready98)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global98)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $string-copy
              (local.get $5)
              (local.tee $7
               (i64.add
                (local.get $6)
                (local.get $7)
               )
              )
              (local.tee $4
               (struct.get $type23 0
                (local.get $1)
               )
              )
              (i64.const 0)
              (local.tee $6
               (i64.extend_i32_u
                (struct.get $type14 1
                 (local.get $4)
                )
               )
              )
             )
             (local.set $1
              (struct.get $type23 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready98)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global98)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $string-copy
                (local.get $5)
                (local.tee $7
                 (i64.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (local.tee $4
                 (struct.get $type23 0
                  (local.get $1)
                 )
                )
                (i64.const 0)
                (local.tee $6
                 (i64.extend_i32_u
                  (struct.get $type14 1
                   (local.get $4)
                  )
                 )
                )
               )
               (local.set $1
                (struct.get $type23 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready98)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global98)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $string-copy
                  (local.get $5)
                  (local.tee $7
                   (i64.add
                    (local.get $6)
                    (local.get $7)
                   )
                  )
                  (local.tee $4
                   (struct.get $type23 0
                    (local.get $1)
                   )
                  )
                  (i64.const 0)
                  (local.tee $6
                   (i64.extend_i32_u
                    (struct.get $type14 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type23 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready98)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global98)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $string-copy
                    (local.get $5)
                    (local.tee $7
                     (i64.add
                      (local.get $6)
                      (local.get $7)
                     )
                    )
                    (local.tee $4
                     (struct.get $type23 0
                      (local.get $1)
                     )
                    )
                    (i64.const 0)
                    (local.tee $6
                     (i64.extend_i32_u
                      (struct.get $type14 1
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type23 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready98)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global98)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $string-copy
                      (local.get $5)
                      (local.tee $7
                       (i64.add
                        (local.get $6)
                        (local.get $7)
                       )
                      )
                      (local.tee $4
                       (struct.get $type23 0
                        (local.get $1)
                       )
                      )
                      (i64.const 0)
                      (local.tee $6
                       (i64.extend_i32_u
                        (struct.get $type14 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type23 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready98)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global98)
                      )
                     )
                     (call $function38
                      (local.get $5)
                      (local.get $1)
                      (i64.add
                       (local.get $6)
                       (local.get $7)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function37 (type $4) (param $0 i32) (param $1 i32) (param $2 (ref null $type23)) (param $3 i64) (result i64)
  (local $4 (ref null $type23))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type23 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.extend_i32_u
        (struct.get $type14 1
         (struct.get $type23 0
          (local.get $2)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call25) (param $0 (ref $type14)) (param $1 (ref null $type23)) (param $2 i64) (result i32)
  (local $3 (ref $type14))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type23 0
       (local.get $1)
      )
     )
     (i64.const 0)
     (local.tee $4
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $3)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type23 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function41 (type $call28) (result (ref $type14))
  (local $0 (ref $type14))
  (local $1 (ref $type14))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 (ref $type27))
  (local $5 i64)
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type27 0
      (global.get $global109)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type27 0
      (global.get $global109)
     )
    )
    (if
     (i32.eqz
      (global.get $ready90)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global90)
     )
    )
    (local.set $0
     (call $function35
      (struct.new $type23
       (global.get $string0)
       (struct.new $type23
        (local.get $1)
        (struct.new $type23
         (global.get $string1)
         (struct.new $type23
          (local.get $2)
          (struct.new $type23
           (global.get $string2)
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.get $0)
   )
  )
  (drop
   (if (result i32)
    (call $foreign1)
    (then
     (call $foreign0
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (call $function43
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (local.set $0
     (call $function35
      (struct.new $type23
       (call $function33
        (struct.get $type27 0
         (global.get $global109)
        )
        (block (result i64)
         (if
          (i32.eqz
           (global.get $ready109)
          )
          (then
           (unreachable)
          )
         )
         (i64.shr_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (struct.get $type27 0
             (global.get $global109)
            )
           )
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready109)
            )
            (then
             (unreachable)
            )
           )
           (local.set $6
            (i64.extend_i32_u
             (struct.get $type14 1
              (struct.get $type27 0
               (global.get $global109)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready81)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global81)
            )
           )
           (i64.const 1)
          )
         )
        )
        (local.get $6)
       )
       (block (result (ref (exact $type23)))
        (if
         (i32.eqz
          (global.get $ready109)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type23
         (call $function33
          (struct.get $type27 0
           (global.get $global109)
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready109)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (i64.extend_i32_u
             (struct.get $type14 1
              (struct.get $type27 0
               (global.get $global109)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready81)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global81)
            )
           )
           (i64.const 0)
          )
          (i64.add
           (i64.shr_u
            (local.get $5)
            (i64.const 1)
           )
           (i64.const 1)
          )
         )
         (block (result nullref)
          (if
           (i32.eqz
            (global.get $ready90)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global90)
           )
          )
          (ref.null none)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.get $0)
   )
  )
  (drop
   (if (result i32)
    (call $foreign1)
    (then
     (call $foreign0
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (call $function43
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type27 0
   (global.get $global109)
  )
 )
 (func $function43 (type $1) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign2
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $4
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $4)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function46 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 (ref $type27))
  (local $5 (ref $type14))
  (if (result i64)
   (i64.ge_s
    (local.get $3)
    (i64.const 10)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (i64.extend_i32_u
     (struct.get $type14 1
      (struct.get $type27 0
       (global.get $global109)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type27 0
     (ref.as_non_null
      (global.get $global109)
     )
     (block (result (ref $type14))
      (if
       (i32.eqz
        (global.get $ready111)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global111)
       )
      )
      (local.tee $5
       (global.get $string3)
      )
     )
    )
    (drop
     (if (result i32)
      (call $foreign1)
      (then
       (call $foreign0
        (i64.const 6)
       )
       (call $function43
        (local.get $5)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready122)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (drop
     (call $function48
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function48 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i64.lt_s
    (local.get $0)
    (i64.extend_i32_u
     (struct.get $type14 1
      (struct.get $type27 0
       (global.get $global109)
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (i64.extend_i32_u
     (struct.get $type14 1
      (struct.get $type27 0
       (global.get $global109)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (drop
     (call $function41)
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (return_call $function46
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
  )
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 1
    (call $function41)
   )
  )
 )
 (func $export2 (param $0 i64)
  (local $1 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (call $string-new
     (i32.wrap_i64
      (local.get $0)
     )
    )
   )
  )
 )
 (func $export3 (param $0 i64) (param $1 i32)
  (local $2 (ref $type14))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type14 0
     (local.tee $2
      (struct.get $type27 0
       (global.get $global109)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $0)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type15
   (if (result (ref $type15))
    (i32.lt_u
     (local.tee $3
      (i32.wrap_i64
       (local.get $0)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type14 2
      (local.get $2)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type16
       (struct.get $type14 3
        (local.get $2)
       )
       (i32.sub
        (i32.shr_u
         (local.get $3)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $3)
    (i32.const 8191)
   )
   (local.get $1)
  )
 )
 (func $export4 (param $0 i64) (result i32)
  (local $1 (ref $type14))
  (local $2 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $0)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.tee $1
       (struct.get $type27 0
        (global.get $global109)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.get $type15
   (if (result (ref $type15))
    (i32.lt_u
     (local.tee $2
      (i32.wrap_i64
       (local.get $0)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type14 2
      (local.get $1)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type16
       (struct.get $type14 3
        (local.get $1)
       )
       (i32.sub
        (i32.shr_u
         (local.get $2)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $2)
    (i32.const 8191)
   )
  )
 )
 (func $export5 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 1
    (struct.get $type27 0
     (global.get $global109)
    )
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type20)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global90
   (struct.new_default $type22)
  )
  (global.set $ready90
   (i32.const 1)
  )
  (global.set $global93
   (struct.new_default $type24)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type25)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global109
   (struct.new $type27
    (global.get $string3)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type28)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type29)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type29)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type30)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type29)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type5)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type31)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type32)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type33)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type5)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

