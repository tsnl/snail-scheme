(import (snail strict) (snail io) (snail datum) (snail read))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(: abs (-> F64 F64))
(define (abs value) (if (< value 0.0) (- 0.0 value) value))
(: workload-read (-> InputPort ReadResult))
(define (workload-read port)
  (let ((result (read port)))
    (match result
      ((read-error message) (datum-fail (string-append "read: " message)))
      ((read-value value) result) ((read-end) result))))
(: real-datum (-> Datum F64))
(define (real-datum value)
  (if (datum-number? value) (number->f64 (datum-number-value value))
      (datum-fail "sum1: expected a real number")))
(: exact-datum (-> Datum I64))
(define (exact-datum value)
  (match (datum-number-value value)
    ((exact-number value) value)
    ((rational-number value) (datum-fail "benchmark count must fit an exact I64"))
    ((inexact-number value) (datum-fail "benchmark count must be exact"))
    ((complex-number real imaginary) (datum-fail "benchmark count must be exact"))))
(: read-from-file-benchmark (-> String Datum))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;
;;; Test of R6RS get-datum, comparable to the parsing benchmark.
;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; get-datum benchmark comparable to the parsing benchmark.
;;
;; Reads nboyer.sch into a string before timing begins.
;;
;; The timed portion of the benchmark parses the string
;; representation of nboyer.sch 1000 times.
;;
;; The output of that parse is checked by comparing it
;; the the value returned by the read procedure.
;;
;; Usage:
;;     (read-benchmark n input)
;;     (read-from-string-port-benchmark n input)
;;
;;
;; n defaults to 1000, and input defaults to "nboyer.sch".
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(define (read-from-file-benchmark input)
  (call-with-input-file
      input
    (lambda (in)
      (do ((x (workload-read in) (workload-read in))
           (y (datum-boolean #f) (read-value! x))
           (i 0 (+ i 1)))
          ((read-end? x) y)))))

(define-data Specification
  (specification (count I64 specification-count) (path String specification-path)
                 (expected Datum specification-expected)))
(: read-specification (-> InputPort Specification))
(define (read-specification port)
  (let* ((count (exact-datum (read-value! (workload-read port))))
         (path (datum-string-value (read-value! (workload-read port))))
         (expected (read-value! (workload-read port))))
    (specification count path expected)))
(define configured (call-with-input-file "input.txt" read-specification))
(define input0 (specification-path configured))
(define expected (specification-expected configured))
(: configured-count (-> I64))
(define (configured-count) (specification-count configured))
(: hide-path (-> I64 String String))
(define (hide-path count path) (if (barrier) path (unreachable)))
(: bench (-> I64 I64))
(define (bench count) (let loop ((i 0) (result (datum-boolean #f)))
  (if (< i count) (loop (+ i 1) (read-from-file-benchmark (hide-path count input0)))
      (if (datum=? result expected) 1 0))))
(unit)
