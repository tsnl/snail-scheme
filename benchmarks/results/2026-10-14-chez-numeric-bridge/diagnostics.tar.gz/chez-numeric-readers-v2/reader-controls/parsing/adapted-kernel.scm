(define parsing-symbol-<abbrev-prefix>-value (typed-string->symbol "<abbrev-prefix>"))
(define parsing-symbol-<abbreviation>-value (typed-string->symbol "<abbreviation>"))
(define parsing-symbol-<compound-datum>-value (typed-string->symbol "<compound-datum>"))
(define parsing-symbol-<data>-value (typed-string->symbol "<data>"))
(define parsing-symbol-<datum>-value (typed-string->symbol "<datum>"))
(define parsing-symbol-<list2>-value (typed-string->symbol "<list2>"))
(define parsing-symbol-<list3>-value (typed-string->symbol "<list3>"))
(define parsing-symbol-<list4>-value (typed-string->symbol "<list4>"))
(define parsing-symbol-<list>-value (typed-string->symbol "<list>"))
(define parsing-symbol-<simple-datum>-value (typed-string->symbol "<simple-datum>"))
(define parsing-symbol-<symbol>-value (typed-string->symbol "<symbol>"))
(define parsing-symbol-<vector>-value (typed-string->symbol "<vector>"))
(define parsing-symbol-backquote-value (typed-string->symbol "backquote"))
(define parsing-symbol-boolean-value (typed-string->symbol "boolean"))
(define parsing-symbol-character-value (typed-string->symbol "character"))
(define parsing-symbol-comma-value (typed-string->symbol "comma"))
(define parsing-symbol-eof-value (typed-string->symbol "eof"))
(define parsing-symbol-id-value (typed-string->symbol "id"))
(define parsing-symbol-lparen-value (typed-string->symbol "lparen"))
(define parsing-symbol-number-value (typed-string->symbol "number"))
(define parsing-symbol-period-value (typed-string->symbol "period"))
(define parsing-symbol-quasiquote-value (typed-string->symbol "quasiquote"))
(define parsing-symbol-quote-value (typed-string->symbol "quote"))
(define parsing-symbol-rparen-value (typed-string->symbol "rparen"))
(define parsing-symbol-splicing-value (typed-string->symbol "splicing"))
(define parsing-symbol-string-value (typed-string->symbol "string"))
(define parsing-symbol-unquote-value (typed-string->symbol "unquote"))
(define parsing-symbol-unquote-splicing-value (typed-string->symbol "unquote-splicing"))
(define parsing-symbol-vecstart-value (typed-string->symbol "vecstart"))
(define parsing-symbol-z1-value (typed-string->symbol "z1"))
(define parsing-literal-0 (parsing-list ))
(define parsing-literal-1 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-quote-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-2 (parsing-list parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-id-value parsing-symbol-number-value parsing-symbol-string-value))
(define parsing-literal-3 (parsing-list parsing-symbol-id-value))
(define parsing-literal-4 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-lparen-value parsing-symbol-quote-value parsing-symbol-splicing-value parsing-symbol-vecstart-value))
(define parsing-literal-5 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-lparen-value parsing-symbol-quote-value parsing-symbol-splicing-value))
(define parsing-literal-6 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-quote-value parsing-symbol-rparen-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-7 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-period-value parsing-symbol-quote-value parsing-symbol-rparen-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-8 (parsing-list parsing-symbol-rparen-value))
(define parsing-literal-9 (parsing-list parsing-symbol-period-value parsing-symbol-rparen-value))
(define parsing-literal-10 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-quote-value parsing-symbol-splicing-value))
(define parsing-literal-11 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-quote-value parsing-symbol-splicing-value))
(define parsing-literal-12 (parsing-list parsing-symbol-rparen-value))
(define parsing-literal-13 (parsing-list parsing-symbol-vecstart-value))
(define parsing-literal-14 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-period-value parsing-symbol-quote-value parsing-symbol-rparen-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-15 (parsing-list parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-id-value parsing-symbol-number-value parsing-symbol-string-value))
(define-syntax parsing-case-value
  (syntax-rules (<abbrev-prefix> <abbreviation> <compound-datum> <data> <datum> <list2> <list3> <list4> <list> <simple-datum> <symbol> <vector> backquote boolean character comma eof id lparen number period quasiquote quote rparen splicing string unquote unquote-splicing vecstart z1)
    ((_ <abbrev-prefix>) parsing-symbol-<abbrev-prefix>-value)
    ((_ <abbreviation>) parsing-symbol-<abbreviation>-value)
    ((_ <compound-datum>) parsing-symbol-<compound-datum>-value)
    ((_ <data>) parsing-symbol-<data>-value)
    ((_ <datum>) parsing-symbol-<datum>-value)
    ((_ <list2>) parsing-symbol-<list2>-value)
    ((_ <list3>) parsing-symbol-<list3>-value)
    ((_ <list4>) parsing-symbol-<list4>-value)
    ((_ <list>) parsing-symbol-<list>-value)
    ((_ <simple-datum>) parsing-symbol-<simple-datum>-value)
    ((_ <symbol>) parsing-symbol-<symbol>-value)
    ((_ <vector>) parsing-symbol-<vector>-value)
    ((_ backquote) parsing-symbol-backquote-value)
    ((_ boolean) parsing-symbol-boolean-value)
    ((_ character) parsing-symbol-character-value)
    ((_ comma) parsing-symbol-comma-value)
    ((_ eof) parsing-symbol-eof-value)
    ((_ id) parsing-symbol-id-value)
    ((_ lparen) parsing-symbol-lparen-value)
    ((_ number) parsing-symbol-number-value)
    ((_ period) parsing-symbol-period-value)
    ((_ quasiquote) parsing-symbol-quasiquote-value)
    ((_ quote) parsing-symbol-quote-value)
    ((_ rparen) parsing-symbol-rparen-value)
    ((_ splicing) parsing-symbol-splicing-value)
    ((_ string) parsing-symbol-string-value)
    ((_ unquote) parsing-symbol-unquote-value)
    ((_ unquote-splicing) parsing-symbol-unquote-splicing-value)
    ((_ vecstart) parsing-symbol-vecstart-value)
    ((_ z1) parsing-symbol-z1-value)
    ((_ other) other)))
(define-syntax parsing-cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (parsing-cond rest ...)))))
(define-syntax do-step
  (syntax-rules () ((_ variable) variable) ((_ variable step) step)))
(define-syntax parsing-do
  (syntax-rules ()
    ((_ ((variable initial step ...) ...) (test result ...) body ...)
     (let loop ((variable initial) ...)
       (if test (begin (unit) result ...)
           (begin body ... (loop (do-step variable step ...) ...)))))))

(define-syntax parsing-case
  (syntax-rules (else)
    ((_ key (else body ...)) (begin body ...))
    ((_ key ((value ...) body ...) rest ...)
     (let ((saved key))
       (if (or (parsing-case=? saved (parsing-case-value value)) ...)
           (begin body ...) (parsing-case saved rest ...))))))
(: parsing-benchmark (-> (Rest Datum) Datum))
(: read-file-as-string (-> String String))
(: parse-string (-> String Datum))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Copyright 2006 William D Clinger.
;;
;; Permission to copy this software, in whole or in part, to use this
;; software for any lawful purpose, and to redistribute this software
;; is granted subject to the restriction that all copies made of this
;; software must include this copyright notice in full.
;;
;; I also request that you send me a copy of any improvements that you
;; make to this software so that they may be incorporated within it to
;; the benefit of the Scheme community.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Parsing benchmark.
;;
;; Reads nboyer.sch into a string before timing begins.
;;
;; The timed portion of the benchmark parses the string
;; representation of nboyer.sch 1000 times.
;;
;; The output of that parse is checked by comparing it
;; the the value returned by the read procedure.
;;
;; Usage:
;;     (parsing-benchmark n input)
;;
;; n defaults to 1000, and input defaults to "nboyer.sch".
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(define (parsing-benchmark . rest)
  (let* ((n (parsing-exact (if (null? rest) (parsing-integer 1000) (car rest))))
         (input (datum-string-value (if (or (null? rest) (null? (cdr rest)))
                    (datum-string "nboyer.sch")
                    (parsing-cadr rest))))
         (input-string (read-file-as-string input)))
    (let loop ((i 0) (result (datum-boolean #f)))
      (if (= i n)
          result
          (loop (+ i 1) (parse-string input-string))))))

(define (read-file-as-string name)
  (call-with-input-file
      name
    (lambda (in)
      (parsing-do ((x (parsing-read-char in) (parsing-read-char in))
           (chars parsing-literal-0 (cons (parsing-character-text x) chars)))
          ((parsing-character-end? x)
           (list->string (parsing-reverse chars)))))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; The parser used for benchmarking.
;;
;; Given a string containing Scheme code, parses the entire
;; string and returns the last <datum> read from the string.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(define (parse-string input-string)

  ;; Constants and local variables.

  (let* (; Constants.

         ;; Any character that doesn't appear within nboyer.sch
         ;; (or the input file, if different) can be used to
         ;; represent end-of-file.

         (eof #\~)

         ;; length of longest token allowed
         ;; (this allows static allocation in C)

         (max_token_size 1024)

         ;; Encodings of error messages.

         (errLongToken 1);; extremely long token
         (errincompletetoken 2);; any lexical error, really
         (errLexGenBug 3);; can't happen

         ;; State for one-token buffering in lexical analyzer.

         (kindOfNextToken (ref parsing-symbol-z1-value));; valid iff nextTokenIsReady
         (nextTokenIsReady (ref #f))

         (tokenValue (ref ""));; string associated with current token

         (totalErrors 0);; errors so far
         (lineNumber (ref 1));; rudimentary source code location
         (lineNumberOfLastError 0);; ditto

         ;; A string buffer for the characters of the current token.

         (string_accumulator (make-string max_token_size))

         ;; Number of characters in string_accumulator.

         (string_accumulator_length (ref 0))

         ;; A single character of buffering.
         ;; nextCharacter is valid iff nextCharacterIsReady

         (nextCharacter (ref #\space))
         (nextCharacterIsReady (ref #f))

         ;; Index of next character to be read from input-string.

         (input-index (ref 0))

         (input-length (string-length input-string))
         )

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; LexGen generated the code for the state machine.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (: scanner0 (->  Symbol))
    (: next-token (->  Symbol))
    (: accept (-> Symbol Symbol))
    (: consume-token! (->  Unit))
    (: scannererror (-> I64 Symbol))
    (: scanchar (->  Char))
    (: consumechar (->  Unit))
    (: pseudoAppend (-> Datum Datum Datum))
    (: parse-error (-> Symbol (List Symbol) Datum))
    (: state0 (-> Char Symbol))
    (: state1 (-> Char Symbol))
    (: state2 (-> Char Symbol))
    (: state3 (-> Char Symbol))
    (: state4 (-> Char Symbol))
    (: state5 (-> Char Symbol))
    (: state6 (-> Char Symbol))
    (: state7 (-> Char Symbol))
    (: state8 (-> Char Symbol))
    (: state9 (-> Char Symbol))
    (: state10 (-> Char Symbol))
    (: state11 (-> Char Symbol))
    (: state12 (-> Char Symbol))
    (: state13 (-> Char Symbol))
    (: state14 (-> Char Symbol))
    (: state15 (-> Char Symbol))
    (: state16 (-> Char Symbol))
    (: state17 (-> Char Symbol))
    (: state18 (-> Char Symbol))
    (: state19 (-> Char Symbol))
    (: state20 (-> Char Symbol))
    (: state21 (-> Char Symbol))
    (: state22 (-> Char Symbol))
    (: state23 (-> Char Symbol))
    (: state24 (-> Char Symbol))
    (: state25 (-> Char Symbol))
    (: state26 (-> Char Symbol))
    (: state27 (-> Char Symbol))
    (: state28 (-> Char Symbol))
    (: state29 (-> Char Symbol))
    (: state30 (-> Char Symbol))
    (: state31 (-> Char Symbol))
    (: state32 (-> Char Symbol))
    (: state33 (-> Char Symbol))
    (: state34 (-> Char Symbol))
    (: state35 (-> Char Symbol))
    (: state36 (-> Char Symbol))
    (: state37 (-> Char Symbol))
    (: state38 (-> Char Symbol))
    (: state39 (-> Char Symbol))
    (: state40 (-> Char Symbol))
    (: state41 (-> Char Symbol))
    (: parse-datum (->  Datum))
    (: parse-simple-datum (->  Datum))
    (: parse-symbol (->  Datum))
    (: parse-compound-datum (->  Datum))
    (: parse-list (->  Datum))
    (: parse-list2 (->  Datum))
    (: parse-list3 (->  Datum))
    (: parse-list4 (->  Datum))
    (: parse-abbreviation (->  Datum))
    (: parse-abbrev-prefix (->  Datum))
    (: parse-vector (->  Datum))
    (: parse-data (->  Datum))
    (: emptyList (->  Datum))
    (: makeBool (->  Datum))
    (: makeChar (->  Datum))
    (: makeNum (->  Datum))
    (: makeString (->  Datum))
    (: makeSym (->  Datum))
    (: symBackquote (->  Datum))
    (: symQuote (->  Datum))
    (: symSplicing (->  Datum))
    (: symUnquote (->  Datum))

    (define (scanner0)
      (let loop ((c (scanchar)))
        (when (parsing-whitespace? c)
          (consumechar)
          (ref-set! string_accumulator_length 0)
          (loop (scanchar))))
      (let ((c (scanchar)))
        (if (char=? c eof) (accept parsing-symbol-eof-value) (state0 c))))

    (define (state0 c)
      (parsing-case c
        ((#\`) (consumechar) (accept parsing-symbol-backquote-value))
        ((#\') (consumechar) (accept parsing-symbol-quote-value))
        ((#\)) (consumechar) (accept parsing-symbol-rparen-value))
        ((#\() (consumechar) (accept parsing-symbol-lparen-value))
        ((#\;) (consumechar) (state29 (scanchar)))
        ((#\+ #\-) (consumechar) (state28 (scanchar)))
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state27 (scanchar)))
        ((#\.) (consumechar) (state16 (scanchar)))
        ((#\a
          #\b
          #\c
          #\d
          #\e
          #\f
          #\g
          #\h
          #\i
          #\j
          #\k
          #\l
          #\m
          #\n
          #\o
          #\p
          #\q
          #\r
          #\s
          #\t
          #\u
          #\v
          #\w
          #\x
          #\y
          #\z
          #\A
          #\B
          #\C
          #\D
          #\E
          #\F
          #\G
          #\H
          #\I
          #\J
          #\K
          #\L
          #\M
          #\N
          #\O
          #\P
          #\Q
          #\R
          #\S
          #\T
          #\U
          #\V
          #\W
          #\X
          #\Y
          #\Z
          #\!
          #\$
          #\%
          #\&
          #\*
          #\/
          #\:
          #\<
          #\=
          #\>
          #\?
          #\^
          #\_
          #\~)
         (consumechar)
         (state14 (scanchar)))
        ((#\#) (consumechar) (state13 (scanchar)))
        ((#\") (consumechar) (state2 (scanchar)))
        ((#\,) (consumechar) (state1 (scanchar)))
        (else
         (if (parsing-whitespace? c)
             (begin (consumechar) (state30 (scanchar)))
             (scannererror errincompletetoken)))))
    (define (state1 c)
      (parsing-case c
        ((#\@) (consumechar) (accept parsing-symbol-splicing-value))
        (else (accept parsing-symbol-comma-value))))
    (define (state2 c)
      (parsing-case c
        ((#\") (consumechar) (accept parsing-symbol-string-value))
        (else
         (if (isnotdoublequote? c)
             (begin (consumechar) (state2 (scanchar)))
             (scannererror errincompletetoken)))))
    (define (state3 c)
      (parsing-case c
        ((#\n) (consumechar) (state8 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state4 c)
      (parsing-case c
        ((#\i) (consumechar) (state3 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state5 c)
      (parsing-case c
        ((#\l) (consumechar) (state4 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state6 c)
      (parsing-case c
        ((#\w) (consumechar) (state5 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state7 c)
      (parsing-case c
        ((#\e) (consumechar) (state6 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state8 c)
      (parsing-case c
        ((#\e) (consumechar) (accept parsing-symbol-character-value))
        (else (scannererror errincompletetoken))))
    (define (state9 c)
      (parsing-case c
        ((#\c) (consumechar) (state8 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state10 c)
      (parsing-case c
        ((#\a) (consumechar) (state9 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state11 c)
      (parsing-case c
        ((#\p) (consumechar) (state10 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state12 c)
      (parsing-case c
        ((#\s) (consumechar) (state11 (scanchar)))
        ((#\n) (consumechar) (state7 (scanchar)))
        (else
         (if (parsing-char? c)
             (begin (consumechar) (accept parsing-symbol-character-value))
             (scannererror errincompletetoken)))))
    (define (state13 c)
      (parsing-case c
        ((#\() (consumechar) (accept parsing-symbol-vecstart-value))
        ((#\t #\f) (consumechar) (accept parsing-symbol-boolean-value))
        ((#\\) (consumechar) (state12 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state14 c)
      (parsing-case c
        ((#\a
          #\b
          #\c
          #\d
          #\e
          #\f
          #\g
          #\h
          #\i
          #\j
          #\k
          #\l
          #\m
          #\n
          #\o
          #\p
          #\q
          #\r
          #\s
          #\t
          #\u
          #\v
          #\w
          #\x
          #\y
          #\z
          #\A
          #\B
          #\C
          #\D
          #\E
          #\F
          #\G
          #\H
          #\I
          #\J
          #\K
          #\L
          #\M
          #\N
          #\O
          #\P
          #\Q
          #\R
          #\S
          #\T
          #\U
          #\V
          #\W
          #\X
          #\Y
          #\Z
          #\!
          #\$
          #\%
          #\&
          #\*
          #\/
          #\:
          #\<
          #\=
          #\>
          #\?
          #\^
          #\_
          #\~
          #\0
          #\1
          #\2
          #\3
          #\4
          #\5
          #\6
          #\7
          #\8
          #\9
          #\+
          #\-
          #\.
          #\@)
         (consumechar)
         (state14 (scanchar)))
        (else (accept parsing-symbol-id-value))))
    (define (state15 c)
      (parsing-case c
        ((#\.) (consumechar) (accept parsing-symbol-id-value))
        (else (scannererror errincompletetoken))))
    (define (state16 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state18 (scanchar)))
        ((#\.) (consumechar) (state15 (scanchar)))
        (else (accept parsing-symbol-period-value))))
    (define (state17 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state18 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state18 c)
      (parsing-case c
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\#) (consumechar) (state19 (scanchar)))
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state18 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state19 c)
      (parsing-case c
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\#) (consumechar) (state19 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state20 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state20 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state21 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state20 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state22 c)
      (parsing-case c
        ((#\+ #\-) (consumechar) (state21 (scanchar)))
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state20 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state23 c)
      (parsing-case c
        ((#\#) (consumechar) (state23 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state24 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state24 (scanchar)))
        ((#\#) (consumechar) (state23 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state25 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state24 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state26 c)
      (parsing-case c
        ((#\#) (consumechar) (state26 (scanchar)))
        ((#\/) (consumechar) (state25 (scanchar)))
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\.) (consumechar) (state19 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state27 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state27 (scanchar)))
        ((#\#) (consumechar) (state26 (scanchar)))
        ((#\/) (consumechar) (state25 (scanchar)))
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\.) (consumechar) (state18 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state28 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state27 (scanchar)))
        ((#\.) (consumechar) (state17 (scanchar)))
        (else (accept parsing-symbol-id-value))))
    (define (state29 c)
      (parsing-case c
        ((#\newline)
         (consumechar)
         (begin
           (ref-set! string_accumulator_length 0)
           (state0 (scanchar))))
        (else
         (if (isnotnewline? c)
             (begin (consumechar) (state29 (scanchar)))
             (scannererror errincompletetoken)))))
    (define (state30 c)
      (parsing-case c
        (else
         (if (parsing-whitespace? c)
             (begin (consumechar) (state30 (scanchar)))
             (begin
               (ref-set! string_accumulator_length 0)
               (state0 (scanchar)))))))
    (define (state31 c)
      (parsing-case c
        (else
         (begin
           (ref-set! string_accumulator_length 0)
           (state0 (scanchar))))))
    (define (state32 c) (parsing-case c (else (accept parsing-symbol-id-value))))
    (define (state33 c)
      (parsing-case c (else (accept parsing-symbol-boolean-value))))
    (define (state34 c)
      (parsing-case c (else (accept parsing-symbol-character-value))))
    (define (state35 c)
      (parsing-case c (else (accept parsing-symbol-vecstart-value))))
    (define (state36 c)
      (parsing-case c (else (accept parsing-symbol-string-value))))
    (define (state37 c)
      (parsing-case c (else (accept parsing-symbol-lparen-value))))
    (define (state38 c)
      (parsing-case c (else (accept parsing-symbol-rparen-value))))
    (define (state39 c)
      (parsing-case c (else (accept parsing-symbol-quote-value))))
    (define (state40 c)
      (parsing-case c (else (accept parsing-symbol-backquote-value))))
    (define (state41 c)
      (parsing-case c (else (accept parsing-symbol-splicing-value))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; End of state machine generated by LexGen.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; ParseGen generated the code for the strong LL(1) parser.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (parse-datum)
      (parsing-case (next-token)
        ((splicing comma backquote quote lparen vecstart)
         (let ((ast1 (parse-compound-datum)))
           (identity ast1)))
        ((boolean number character string id)
         (let ((ast1 (parse-simple-datum)))
           (identity ast1)))
        (else
         (parse-error
          parsing-symbol-<datum>-value
          parsing-literal-1))))

    (define (parse-simple-datum)
      (parsing-case (next-token)
        ((id)
         (let ((ast1 (parse-symbol))) (identity ast1)))
        ((string) (begin (consume-token!) (makeString)))
        ((character) (begin (consume-token!) (makeChar)))
        ((number) (begin (consume-token!) (makeNum)))
        ((boolean) (begin (consume-token!) (makeBool)))
        (else
         (parse-error
          parsing-symbol-<simple-datum>-value
          parsing-literal-15))))

    (define (parse-symbol)
      (parsing-case (next-token)
        ((id) (begin (consume-token!) (makeSym)))
        (else (parse-error parsing-symbol-<symbol>-value parsing-literal-3))))

    (define (parse-compound-datum)
      (parsing-case (next-token)
        ((vecstart)
         (let ((ast1 (parse-vector))) (identity ast1)))
        ((lparen quote backquote comma splicing)
         (let ((ast1 (parse-list))) (identity ast1)))
        (else
         (parse-error
          parsing-symbol-<compound-datum>-value
          parsing-literal-4))))

    (define (parse-list)
      (parsing-case (next-token)
        ((splicing comma backquote quote)
         (let ((ast1 (parse-abbreviation)))
           (identity ast1)))
        ((lparen)
         (begin
           (consume-token!)
           (let ((ast1 (parse-list2))) (identity ast1))))
        (else
         (parse-error
          parsing-symbol-<list>-value
          parsing-literal-5))))

    (define (parse-list2)
      (parsing-case (next-token)
        ((id string
             character
             number
             boolean
             vecstart
             lparen
             quote
             backquote
             comma
             splicing)
         (let ((ast1 (parse-datum)))
           (let ((ast2 (parse-list3))) (datum-cons ast1 ast2))))
        ((rparen) (begin (consume-token!) (emptyList)))
        (else
         (parse-error
          parsing-symbol-<list2>-value
          parsing-literal-6))))

    (define (parse-list3)
      (parsing-case (next-token)
        ((rparen
          period
          splicing
          comma
          backquote
          quote
          lparen
          vecstart
          boolean
          number
          character
          string
          id)
         (let ((ast1 (parse-data)))
           (let ((ast2 (parse-list4)))
             (pseudoAppend ast1 ast2))))
        (else
         (parse-error
          parsing-symbol-<list3>-value
          parsing-literal-14))))

    (define (parse-list4)
      (parsing-case (next-token)
        ((period)
         (begin
           (consume-token!)
           (let ((ast1 (parse-datum)))
             (if (typed-symbol=? (next-token) parsing-symbol-rparen-value)
                 (begin (consume-token!) (identity ast1))
                 (parse-error parsing-symbol-<list4>-value parsing-literal-12)))))
        ((rparen) (begin (consume-token!) (emptyList)))
        (else (parse-error parsing-symbol-<list4>-value parsing-literal-9))))

    (define (parse-abbreviation)
      (parsing-case (next-token)
        ((quote backquote comma splicing)
         (let ((ast1 (parse-abbrev-prefix)))
           (let ((ast2 (parse-datum))) (datum-list ast1 ast2))))
        (else
         (parse-error
          parsing-symbol-<abbreviation>-value
          parsing-literal-11))))

    (define (parse-abbrev-prefix)
      (parsing-case (next-token)
        ((splicing)
         (begin (consume-token!) (symSplicing)))
        ((comma) (begin (consume-token!) (symUnquote)))
        ((backquote)
         (begin (consume-token!) (symBackquote)))
        ((quote) (begin (consume-token!) (symQuote)))
        (else
         (parse-error
          parsing-symbol-<abbrev-prefix>-value
          parsing-literal-11))))

    (define (parse-vector)
      (parsing-case (next-token)
        ((vecstart)
         (begin
           (consume-token!)
           (let ((ast1 (parse-data)))
             (if (typed-symbol=? (next-token) parsing-symbol-rparen-value)
                 (begin (consume-token!) (list2vector ast1))
                 (parse-error parsing-symbol-<vector>-value parsing-literal-12)))))
        (else (parse-error parsing-symbol-<vector>-value parsing-literal-13))))

    (define (parse-data)
      (parsing-case (next-token)
        ((id string
             character
             number
             boolean
             vecstart
             lparen
             quote
             backquote
             comma
             splicing)
         (let ((ast1 (parse-datum)))
           (let ((ast2 (parse-data))) (datum-cons ast1 ast2))))
        ((rparen period) (emptyList))
        (else
         (parse-error
          parsing-symbol-<data>-value
          parsing-literal-14))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; End of LL(1) parser generated by ParseGen.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Help predicates used by the lexical analyzer's state machine.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (isnotdoublequote? c) (not (char=? c #\")))
    (define (isnotnewline? c) (not (char=? c #\newline)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Lexical analyzer.
    ;;
    ;; This code is adapted from the quirk23 lexical analyzer written
    ;; by Will Clinger for a compiler course.
    ;;
    ;; The scanner and parser were generated automatically and then
    ;; printed using an R5RS Scheme pretty-printer, so they do not
    ;; preserve case.  In preparation for the case-sensitivity of
    ;; R6RS Scheme, several identifiers and constants have been
    ;; lower-cased in the hand-written code to match the generated
    ;; code.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; next-token and consume-token! are called by the parser.

    ;; Returns the current token.

    (define (next-token)
      (if (ref-get nextTokenIsReady)
          (ref-get kindOfNextToken)
          (begin (ref-set! string_accumulator_length 0)
                 (scanner0))))

    ;; Consumes the current token.

    (define (consume-token!)
      (ref-set! nextTokenIsReady #f))

    ;; Called by the lexical analyzer's state machine,
    ;; hence the unfortunate lower case.

    (define (scannererror msg)
      (define msgtxt
        (parsing-cond ((= msg errLongToken)
               "Amazingly long token")
              ((= msg errincompletetoken)
               "in line ")
              ((= msg errLexGenBug)
               "Bug in lexical analyzer (generated)")
              (else "Bug in lexical analyzer")))
      (datum-fail (string-append "Lexical Error: " msgtxt " " (i64->string (ref-get lineNumber))))
      (ref-set! nextTokenIsReady #f)
      (ref-set! nextCharacterIsReady #f)
      (next-token))

    ;; Accepts a token of the given kind, returning that kind.
    ;;
    ;; For some kinds of tokens, a value for the token must also be
    ;; recorded in tokenValue.

    (define (accept t)
      (when (parsing-member? t parsing-literal-15)
        (ref-set! tokenValue
              (substring string_accumulator 0 (ref-get string_accumulator_length))))
      (ref-set! kindOfNextToken t)
      (ref-set! nextTokenIsReady #t)
      t)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Character i/o, so to speak.
    ;; Uses the input-string as input.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; Returns the current character from the input.

    (define (scanchar)
      (if (ref-get nextCharacterIsReady)
          (ref-get nextCharacter)
          (begin (if (< (ref-get input-index) input-length)
                     (begin (ref-set! nextCharacter
                                  (string-ref input-string (ref-get input-index)))
                            (ref-set! input-index (+ (ref-get input-index) 1)))
                     (ref-set! nextCharacter eof))
                 (ref-set! nextCharacterIsReady #t)
                 ;; For debugging, change #f to #t below.
                 (when #f
                   (parsing-write-character (ref-get nextCharacter)))
                 (scanchar))))

    ;; Consumes the current character, and returns the next.

    (define (consumechar)
      (unless (ref-get nextCharacterIsReady)
        (scanchar))
      (if (< (ref-get string_accumulator_length) max_token_size)
          (begin (ref-set! nextCharacterIsReady #f)
                 (when (char=? (ref-get nextCharacter) #\newline)
                   (ref-set! lineNumber (+ (ref-get lineNumber) 1)))
                 (string-set! string_accumulator
                              (ref-get string_accumulator_length)
                              (ref-get nextCharacter))
                 (ref-set! string_accumulator_length
                       (+ (ref-get string_accumulator_length) 1)))
          (begin (scannererror errLongToken) (unit))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Action procedures called by the parser.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (emptyList) (datum-null))

    (define (identity x) x)

    (define (list2vector vals) (parsing-vector vals))

    (define (makeBool)
      (datum-boolean (string=? (ref-get tokenValue) "#t")))

    (define (makeChar)
      (datum-character (string-ref (ref-get tokenValue) 0)))

    (define (makeNum)
      (parsing-number (ref-get tokenValue)))

    (define (makeString)
      ;; Must strip off outer double quotes.
      ;; Ought to process escape characters also, but we won't.
      (datum-string (substring (ref-get tokenValue) 1 (- (string-length (ref-get tokenValue)) 1))))

    (define (makeSym)
      (datum-symbol (typed-string->symbol (ref-get tokenValue))))

    ;; Like append, but allows the last argument to be a non-list.

    (define (pseudoAppend vals terminus)
      (if (datum-null? vals)
          terminus
          (datum-cons (datum-car vals)
                (pseudoAppend (datum-cdr vals) terminus))))

    (define (symBackquote) (datum-symbol parsing-symbol-quasiquote-value))
    (define (symQuote) (datum-symbol parsing-symbol-quote-value))
    (define (symSplicing) (datum-symbol parsing-symbol-unquote-splicing-value))
    (define (symUnquote) (datum-symbol parsing-symbol-unquote-value))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Error procedure called by the parser.
    ;; As a hack, this error procedure recovers from end-of-file.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (parse-error nonterminal expected-terminals)
      (if (typed-symbol=? parsing-symbol-eof-value (next-token))
          (datum-symbol parsing-symbol-eof-value)
          (begin
            (parsing-display-string "Syntax error in line ")
            (parsing-display-string (i64->string (ref-get lineNumber)))
            (parsing-display-string " while parsing a ")
            (parsing-display-symbol nonterminal)
            (parsing-newline)
            (parsing-display-string "  Encountered a ")
            (parsing-display-symbol (next-token))
            (parsing-display-string " while expecting something in")
            (parsing-newline)
            (parsing-display-string "  ")
            (parsing-display-symbols expected-terminals)
            (parsing-newline)
            (datum-fail "Syntax error"))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Parses repeatedly, returning the last <datum> parsed.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (parsing-do ((x (parse-datum) (parse-datum))
         (y (datum-symbol parsing-symbol-eof-value) x))
        ((datum-eq? x (datum-symbol parsing-symbol-eof-value))
         y))))

