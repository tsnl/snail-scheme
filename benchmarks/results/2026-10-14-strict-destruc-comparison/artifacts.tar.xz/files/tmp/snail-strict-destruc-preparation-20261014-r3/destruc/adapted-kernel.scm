(: append-to-tail! (All (T)
  (-> (MutableList T) (MutableList T) (MutableList T))))
(: destructive (-> I64 I64 (MutableList (MutableList Item))))
;;; DESTRUC -- Destructive operation benchmark.


(define (append-to-tail! x y)
  (if (ml-null? x)
      y
      (let loop ((a x) (b (ml-cdr x)))
        (if (ml-null? b)
            (begin
              (ml-set-cdr! a y)
              x)
            (loop b (ml-cdr b))))))

(define (destructive n m)
  (let ((l (do ((i 10 (- i 1)) (a (ml-empty) (ml-cons (ml-empty) a)))
               ((= i 0) a))))
    (do ((i n (- i 1)))
        ((= i 0) l)
      (cond ((ml-null? (ml-car l))
             (do ((l l (ml-cdr l)))
                 ((ml-null? l))
               (when (ml-null? (ml-car l))
                 (ml-set-car! l (ml-cons empty-value (ml-empty))))
               (append-to-tail! (ml-car l)
                                (do ((j m (- j 1)) (a (ml-empty) (ml-cons empty-value a)))
                                    ((= j 0) a)))))
            (else
             (do ((l1 l (ml-cdr l1)) (l2 (ml-cdr l) (ml-cdr l2)))
                 ((ml-null? l2))
               (let* ((destruc-suffix (let ((n (quotient (ml-length (ml-car l1)) 2)))
                           (cond ((= n 0)
                                  (ml-set-car! l1 (ml-empty))
                                  (ml-car l1))
                                 (else
                                  (do ((j n (- j 1)) (a (ml-car l1) (ml-cdr a)))
                                      ((= j 1)
                                       (let ((x (ml-cdr a)))
                                         (ml-set-cdr! a (ml-empty))
                                         x))
                                    (ml-set-car! a (integer-item i)))))))
                         (destruc-target (do ((j (quotient (ml-length (ml-car l2)) 2) (- j 1))
                              (a (ml-car l2) (ml-cdr a)))
                             ((zero? j) a)
                           (ml-set-car! a (integer-item i)))))
                 (ml-set-cdr! destruc-target destruc-suffix))))))))

