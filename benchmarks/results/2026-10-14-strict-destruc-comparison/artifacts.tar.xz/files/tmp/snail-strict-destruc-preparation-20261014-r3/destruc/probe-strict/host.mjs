import fs from 'node:fs';
import assert from 'node:assert/strict';
const [artifact, n, m, trace, calls] = process.argv.slice(2);
const values = [];
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact),
  {probe: {emit: value => values.push(Number(value))}});
instance.exports.main();
for (let i = 0; i < Number(calls); i++)
  assert.equal(instance.exports.probe(BigInt(n), BigInt(m), BigInt(trace)), 1n);
console.log(JSON.stringify(values));
