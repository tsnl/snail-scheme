(module
 (rec
  (type $type31 (sub (struct)))
  (type $type37 (sub (struct)))
  (type $type27 (sub (struct)))
  (type $3 (func (param (ref $type72) i32 i32 (ref null $type26)) (result i32)))
  (type $4 (func (param (ref $type71) i32 i32 (ref null $type36)) (result i32)))
  (type $call10 (func (result i32)))
  (type $6 (func (param i32 i32 (ref $type37)) (result i32)))
  (type $7 (func (param i32 i32 (ref $type37) i64) (result i64)))
  (type $8 (func (param i32 i32 (ref $type27)) (result i32)))
  (type $9 (func (param i64 i32 i32 i64 (ref $type27)) (result (ref $type27))))
  (type $10 (func (param i32 i32 (ref $type27) i64) (result i64)))
  (type $11 (func (param i64 i32 i32 (ref $type37) (ref $type37)) (result i32)))
  (type $12 (func (param i32 i32 i64 (ref $type27)) (result (ref $type27))))
  (type $call49 (func (param (ref $type37) (ref $type27)) (result i32)))
  (type $type33 (sub $type31 (struct (field i64))))
  (type $call72 (func (param (ref $type29)) (result i32)))
  (type $16 (func (param (ref $type32) (ref $type27)) (result (ref $type29))))
  (type $17 (func (param i64 i32 i32 (ref $type37)) (result i32)))
  (type $18 (func (param i64 (ref $type37) i32 i32 i64) (result (ref $type37))))
  (type $call62 (func (param (ref $type37) (ref $type37)) (result i32)))
  (type $20 (func (param (ref $type37) i32 i32 (ref null $type36) i64) (result i64)))
  (type $21 (func (param i32 i32 (ref null $type36) i64) (result i64)))
  (type $call35 (func (param (ref null $type36)) (result i64)))
  (type $call69 (func (param (ref $type37) (ref null $type36)) (result i64)))
  (type $call71 (func (param (ref $type39)) (result i32)))
  (type $type36 (struct (field (ref $type39)) (field (ref null $type36))))
  (type $type40 (struct (field (ref $type37))))
  (type $27 (func (param (ref $type28) (ref $type37)) (result (ref $type39))))
  (type $28 (func (param i32 i32 i64 (ref $type37)) (result (ref $type37))))
  (type $type38 (sub $type37 (struct)))
  (type $type28 (sub $type27 (struct)))
  (type $type39 (sub $type37 (struct (field (ref $type34)) (field (ref $type40)))))
  (type $call64 (func (param i64 i64) (result (ref $type37))))
  (type $type30 (struct (field (mut (ref $type31)))))
  (type $call61 (func (param (ref $type27) (ref $type27)) (result i32)))
  (type $35 (func (param (ref $type27) i32 i32 (ref null $type26) i64) (result i64)))
  (type $36 (func (param i32 i32 (ref null $type26) i64) (result i64)))
  (type $call25 (func (param (ref null $type26)) (result i64)))
  (type $call68 (func (param (ref $type27) (ref null $type26)) (result i64)))
  (type $type26 (struct (field (ref $type29)) (field (ref null $type26))))
  (type $call51 (func (param (ref $type27) (ref $type27)) (result i32)))
  (type $type34 (struct (field (mut (ref $type27)))))
  (type $type29 (sub $type27 (struct (field (ref $type30)) (field (ref $type34)))))
  (type $43 (func (param (ref $type27) (ref $type27) i32 i32 (ref $type27) (ref $type27)) (result (ref $type27))))
  (type $type75 (struct))
  (type $type10 (struct))
  (type $type74 (struct))
  (type $type73 (struct))
  (type $type72 (struct (field (ref $call72))))
  (type $type71 (struct (field (ref $call71))))
  (type $type70 (struct))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type67 (struct (field (mut (ref null $type26)))))
  (type $type66 (struct (field (mut (ref null $type36)))))
  (type $type65 (struct (field (mut i32))))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type32 (sub $type31 (struct)))
  (type $type35 (struct))
  (type $type25 (struct))
 )
 (type $78 (func (param i64)))
 (type $79 (func (param (ref $type27) (ref $type27))))
 (type $80 (func (param (ref $type27) (ref $type29)) (result i32)))
 (type $81 (func (param i32 i32 i64 (ref $type39)) (result (ref $type37))))
 (type $82 (func (param (ref $type37) (ref $type39)) (result i32)))
 (type $83 (func (param (ref $type37) (ref $type27))))
 (type $84 (func (param i32 i32 i64 (ref $type29)) (result (ref $type27))))
 (type $85 (func (param i64 i64 i64) (result i64)))
 (type $86 (func))
 (import "probe" "emit" (func $foreign0 (param i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global157 (mut (ref null $type25)) (ref.null none))
 (global $ready157 (mut i32) (i32.const 0))
 (global $global193 (mut (ref null $type35)) (ref.null none))
 (global $ready193 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type32)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global182 (mut (ref null $type41)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global212 (mut (ref null $type42)) (ref.null none))
 (global $ready212 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type43)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type44)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type45)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type46)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type47)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type48)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global222 (mut (ref null $type49)) (ref.null none))
 (global $ready222 (mut i32) (i32.const 0))
 (global $global245 (mut (ref null $type50)) (ref.null none))
 (global $ready245 (mut i32) (i32.const 0))
 (global $global168 (mut (ref null $type51)) (ref.null none))
 (global $ready168 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type52)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global252 (mut (ref null $type53)) (ref.null none))
 (global $ready252 (mut i32) (i32.const 0))
 (global $global233 (mut (ref null $type54)) (ref.null none))
 (global $ready233 (mut i32) (i32.const 0))
 (global $global260 (mut (ref null $type55)) (ref.null none))
 (global $ready260 (mut i32) (i32.const 0))
 (global $global165 (mut (ref null $type61)) (ref.null none))
 (global $ready165 (mut i32) (i32.const 0))
 (global $global201 (mut (ref null $type62)) (ref.null none))
 (global $ready201 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type63)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global171 (mut (ref null $type64)) (ref.null none))
 (global $ready171 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type65)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type66)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type67)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global154 (mut (ref null $type68)) (ref.null none))
 (global $ready154 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type69)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type55)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global151 (mut (ref null $type54)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (global $global217 (mut (ref null $type70)) (ref.null none))
 (global $ready217 (mut i32) (i32.const 0))
 (global $global186 (mut (ref null $type71)) (ref.null none))
 (global $ready186 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type72)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global178 (mut (ref null $type41)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (global $global208 (mut (ref null $type42)) (ref.null none))
 (global $ready208 (mut i32) (i32.const 0))
 (global $global219 (mut (ref null $type49)) (ref.null none))
 (global $ready219 (mut i32) (i32.const 0))
 (global $global242 (mut (ref null $type50)) (ref.null none))
 (global $ready242 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type51)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global254 (mut (ref null $type72)) (ref.null none))
 (global $ready254 (mut i32) (i32.const 0))
 (global $global258 (mut (ref null $type71)) (ref.null none))
 (global $ready258 (mut i32) (i32.const 0))
 (global $global268 (mut (ref null $type73)) (ref.null none))
 (global $ready268 (mut i32) (i32.const 0))
 (global $global273 (mut (ref null $type74)) (ref.null none))
 (global $ready273 (mut i32) (i32.const 0))
 (global $global267 (mut (ref null $type10)) (ref.null none))
 (global $ready267 (mut i32) (i32.const 0))
 (global $global278 (mut (ref null $type75)) (ref.null none))
 (global $ready278 (mut i32) (i32.const 0))
 (export "probe" (func $export0))
 (export "main" (func $main))
 (func $function52 (type $43) (param $0 (ref $type27)) (param $1 (ref $type27)) (param $2 i32) (param $3 i32) (param $4 (ref $type27)) (param $5 (ref $type27)) (result (ref $type27))
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if (result (ref $type27))
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $5)
    )
    (then
     (drop
      (ref.cast (ref $type29)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready147)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (call $function53
     (local.get $4)
     (local.get $1)
    )
    (local.get $0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type34 0
      (struct.get $type29 1
       (ref.cast (ref $type29)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $5)
     (local.get $4)
    )
   )
  )
 )
 (func $function53 (param $0 (ref $type27)) (param $1 (ref $type27))
  (local $2 (ref null $type26))
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (if
   (struct.get $type65 0
    (global.get $global150)
   )
   (then
    (call $foreign0
     (i64.const 4)
    )
    (if
     (i32.eqz
      (global.get $ready151)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global151)
     )
    )
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type67 0
      (global.get $global153)
     )
    )
    (if
     (i32.eqz
      (global.get $ready154)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global154)
     )
    )
    (call $foreign0
     (call $function55
      (local.get $0)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready151)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global151)
     )
    )
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type67 0
      (global.get $global153)
     )
    )
    (if
     (i32.eqz
      (global.get $ready154)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global154)
     )
    )
    (call $foreign0
     (call $function55
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready168)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global168)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type29)
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type34 0
   (struct.get $type29 1
    (ref.cast (ref $type29)
     (local.get $0)
    )
   )
   (local.get $1)
  )
 )
 (func $function55 (type $call68) (param $0 (ref $type27)) (param $1 (ref null $type26)) (result i64)
  (local $2 i64)
  (local $3 (ref $type29))
  (local $4 (ref null $type26))
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type29)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready157)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global157)
     )
    )
    (local.set $2
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $4
          (struct.get $type26 1
           (local.get $1)
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $4
            (struct.get $type26 1
             (local.get $4)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $4
              (struct.get $type26 1
               (local.get $4)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $4
                (struct.get $type26 1
                 (local.get $4)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $4
                  (struct.get $type26 1
                   (local.get $4)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $4
                    (struct.get $type26 1
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $4
                      (struct.get $type26 1
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $4
                        (struct.get $type26 1
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (call $function57
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type26 1
                         (local.get $4)
                        )
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $3
       (struct.get $type26 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready165)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global165)
       )
      )
      (if (result i64)
       (call $function59
        (local.get $0)
        (local.get $3)
       )
       (then
        (local.get $2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $1
           (struct.get $type26 1
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
         (else
          (local.set $3
           (struct.get $type26 0
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready165)
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global165)
           )
          )
          (if (result i64)
           (call $function59
            (local.get $0)
            (local.get $3)
           )
           (then
            (local.get $2)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $1
               (struct.get $type26 1
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
             (else
              (local.set $3
               (struct.get $type26 0
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready165)
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global165)
               )
              )
              (if (result i64)
               (call $function59
                (local.get $0)
                (local.get $3)
               )
               (then
                (local.get $2)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $1
                   (struct.get $type26 1
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (local.set $3
                   (struct.get $type26 0
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready165)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global165)
                   )
                  )
                  (if (result i64)
                   (call $function59
                    (local.get $0)
                    (local.get $3)
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $1
                       (struct.get $type26 1
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                     (else
                      (local.set $3
                       (struct.get $type26 0
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready165)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $2
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global165)
                       )
                      )
                      (if (result i64)
                       (call $function59
                        (local.get $0)
                        (local.get $3)
                       )
                       (then
                        (local.get $2)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $1
                           (struct.get $type26 1
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                         (else
                          (local.set $3
                           (struct.get $type26 0
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready165)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $2
                           (i64.sub
                            (local.get $2)
                            (i64.const 1)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global165)
                           )
                          )
                          (if (result i64)
                           (call $function59
                            (local.get $0)
                            (local.get $3)
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $1
                               (struct.get $type26 1
                                (local.get $1)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                             (else
                              (local.set $3
                               (struct.get $type26 0
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready165)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $2
                               (i64.sub
                                (local.get $2)
                                (i64.const 1)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global165)
                               )
                              )
                              (if (result i64)
                               (call $function59
                                (local.get $0)
                                (local.get $3)
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (if (result i64)
                                 (ref.is_null
                                  (local.tee $1
                                   (struct.get $type26 1
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                 (else
                                  (local.set $3
                                   (struct.get $type26 0
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready165)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (local.set $2
                                   (i64.sub
                                    (local.get $2)
                                    (i64.const 1)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global165)
                                   )
                                  )
                                  (if (result i64)
                                   (call $function59
                                    (local.get $0)
                                    (local.get $3)
                                   )
                                   (then
                                    (local.get $2)
                                   )
                                   (else
                                    (if (result i64)
                                     (ref.is_null
                                      (local.tee $1
                                       (struct.get $type26 1
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                     (else
                                      (local.set $3
                                       (struct.get $type26 0
                                        (local.get $1)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready165)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (local.set $2
                                       (i64.sub
                                        (local.get $2)
                                        (i64.const 1)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global165)
                                       )
                                      )
                                      (if (result i64)
                                       (call $function59
                                        (local.get $0)
                                        (local.get $3)
                                       )
                                       (then
                                        (local.get $2)
                                       )
                                       (else
                                        (if (result i64)
                                         (ref.is_null
                                          (local.tee $1
                                           (struct.get $type26 1
                                            (local.get $1)
                                           )
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                         (else
                                          (local.set $2
                                           (i64.sub
                                            (local.get $2)
                                            (i64.const 1)
                                           )
                                          )
                                          (local.set $3
                                           (struct.get $type26 0
                                            (local.get $1)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready165)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global165)
                                           )
                                          )
                                          (if (result i64)
                                           (call $function59
                                            (local.get $0)
                                            (local.get $3)
                                           )
                                           (then
                                            (local.get $2)
                                           )
                                           (else
                                            (return_call $function58
                                             (local.get $0)
                                             (i32.const 0)
                                             (i32.const 1)
                                             (struct.get $type26 1
                                              (local.get $1)
                                             )
                                             (i64.sub
                                              (local.get $2)
                                              (i64.const 1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function56 (type $call25) (param $0 (ref null $type26)) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $0
       (struct.get $type26 1
        (local.get $0)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $0
         (struct.get $type26 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $0
           (struct.get $type26 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $0
             (struct.get $type26 1
              (local.get $0)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $0
               (struct.get $type26 1
                (local.get $0)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $0
                 (struct.get $type26 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type26 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type26 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (return_call $function57
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type26 1
                      (local.get $0)
                     )
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function57 (type $36) (param $0 i32) (param $1 i32) (param $2 (ref null $type26)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type26 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function58 (type $35) (param $0 (ref $type27)) (param $1 i32) (param $2 i32) (param $3 (ref null $type26)) (param $4 i64) (result i64)
  (local $5 (ref $type29))
  (if (result i64)
   (ref.is_null
    (local.get $3)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $5
     (struct.get $type26 0
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (global.get $ready165)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global165)
     )
    )
    (if (result i64)
     (call $function59
      (local.get $0)
      (local.get $5)
     )
     (then
      (local.get $4)
     )
     (else
      (local.set $3
       (struct.get $type26 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function58
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.sub
        (local.get $4)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function59 (param $0 (ref $type27)) (param $1 (ref $type29)) (result i32)
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type29)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $0)
      )
     )
     (then
      (unreachable)
     )
    )
    (ref.eq
     (struct.get $type29 0
      (ref.cast (ref $type29)
       (local.get $0)
      )
     )
     (struct.get $type29 0
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function61 (type $call64) (param $0 i64) (param $1 i64) (result (ref $type37))
  (local $2 (ref $type39))
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (struct.new_default $type38)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (call $function63
    (struct.new_default $type28)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (return_call $function72
   (local.get $1)
   (call $function62
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (call $function63
     (struct.new_default $type28)
     (local.get $2)
    )
   )
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
  )
 )
 (func $function62 (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref $type39)) (result (ref $type37))
  (if (result (ref $type39))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready178)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (local.set $3
     (call $function63
      (struct.new_default $type28)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (local.get $0)
     (local.get $1)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
     (local.get $3)
    )
   )
  )
 )
 (func $function63 (type $27) (param $0 (ref $type28)) (param $1 (ref $type37)) (result (ref $type39))
  (local $2 (ref $type39))
  (local $3 (ref $type66))
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.new $type39
    (struct.new $type34
     (local.get $0)
    )
    (struct.new $type40
     (local.get $1)
    )
   )
  )
  (if
   (struct.get $type65 0
    (global.get $global150)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready185)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type66 0
     (ref.as_non_null
      (global.get $global185)
     )
     (block (result (ref (exact $type36)))
      (if
       (i32.eqz
        (global.get $ready185)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type36
       (local.get $2)
       (struct.get $type66 0
        (global.get $global185)
       )
      )
     )
    )
    (call $foreign0
     (i64.const 0)
    )
    (if
     (i32.eqz
      (global.get $ready186)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global186)
     )
    )
    (drop
     (call $function65
      (local.get $2)
     )
    )
   )
  )
  (local.get $2)
 )
 (func $function65 (type $call71) (param $0 (ref $type39)) (result i32)
  (local $1 (ref null $type36))
  (local $2 (ref $type27))
  (local $3 (ref null $type26))
  (local $4 (ref $type37))
  (local $scratch (ref null $type26))
  (local $scratch_6 (ref null $type36))
  (if
   (i32.eqz
    (global.get $ready188)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global188)
   )
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type66 0
    (global.get $global185)
   )
  )
  (if
   (i32.eqz
    (global.get $ready190)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global190)
   )
  )
  (call $foreign0
   (call $function67
    (local.get $0)
    (local.get $1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (call $foreign0
   (call $function55
    (struct.get $type34 0
     (struct.get $type39 0
      (local.get $0)
     )
    )
    (block (result (ref null $type26))
     (if
      (i32.eqz
       (global.get $ready151)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global151)
      )
     )
     (if
      (i32.eqz
       (global.get $ready153)
      )
      (then
       (unreachable)
      )
     )
     (local.set $scratch
      (struct.get $type67 0
       (global.get $global153)
      )
     )
     (if
      (i32.eqz
       (global.get $ready154)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global154)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (call $foreign0
   (call $function67
    (struct.get $type40 0
     (struct.get $type39 1
      (local.get $0)
     )
    )
    (block (result (ref null $type36))
     (if
      (i32.eqz
       (global.get $ready188)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global188)
      )
     )
     (if
      (i32.eqz
       (global.get $ready185)
      )
      (then
       (unreachable)
      )
     )
     (local.set $scratch_6
      (struct.get $type66 0
       (global.get $global185)
      )
     )
     (if
      (i32.eqz
       (global.get $ready190)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global190)
      )
     )
     (local.get $scratch_6)
    )
   )
  )
  (i32.const 0)
 )
 (func $function67 (type $call69) (param $0 (ref $type37)) (param $1 (ref null $type36)) (result i64)
  (local $2 i64)
  (local $3 (ref $type39))
  (local $4 (ref null $type36))
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type39)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type39)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready193)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global193)
     )
    )
    (local.set $2
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $4
          (struct.get $type36 1
           (local.get $1)
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $4
            (struct.get $type36 1
             (local.get $4)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $4
              (struct.get $type36 1
               (local.get $4)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $4
                (struct.get $type36 1
                 (local.get $4)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $4
                  (struct.get $type36 1
                   (local.get $4)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $4
                    (struct.get $type36 1
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $4
                      (struct.get $type36 1
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $4
                        (struct.get $type36 1
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (call $function69
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type36 1
                         (local.get $4)
                        )
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $3
       (struct.get $type36 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready201)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global201)
       )
      )
      (if (result i64)
       (call $function71
        (local.get $0)
        (local.get $3)
       )
       (then
        (local.get $2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $1
           (struct.get $type36 1
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
         (else
          (local.set $3
           (struct.get $type36 0
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready201)
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global201)
           )
          )
          (if (result i64)
           (call $function71
            (local.get $0)
            (local.get $3)
           )
           (then
            (local.get $2)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $1
               (struct.get $type36 1
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
             (else
              (local.set $3
               (struct.get $type36 0
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready201)
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global201)
               )
              )
              (if (result i64)
               (call $function71
                (local.get $0)
                (local.get $3)
               )
               (then
                (local.get $2)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $1
                   (struct.get $type36 1
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (local.set $3
                   (struct.get $type36 0
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready201)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global201)
                   )
                  )
                  (if (result i64)
                   (call $function71
                    (local.get $0)
                    (local.get $3)
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $1
                       (struct.get $type36 1
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                     (else
                      (local.set $3
                       (struct.get $type36 0
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready201)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $2
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global201)
                       )
                      )
                      (if (result i64)
                       (call $function71
                        (local.get $0)
                        (local.get $3)
                       )
                       (then
                        (local.get $2)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $1
                           (struct.get $type36 1
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                         (else
                          (local.set $3
                           (struct.get $type36 0
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready201)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $2
                           (i64.sub
                            (local.get $2)
                            (i64.const 1)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global201)
                           )
                          )
                          (if (result i64)
                           (call $function71
                            (local.get $0)
                            (local.get $3)
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $1
                               (struct.get $type36 1
                                (local.get $1)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                             (else
                              (local.set $3
                               (struct.get $type36 0
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready201)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $2
                               (i64.sub
                                (local.get $2)
                                (i64.const 1)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global201)
                               )
                              )
                              (if (result i64)
                               (call $function71
                                (local.get $0)
                                (local.get $3)
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (if (result i64)
                                 (ref.is_null
                                  (local.tee $1
                                   (struct.get $type36 1
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                 (else
                                  (local.set $3
                                   (struct.get $type36 0
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready201)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (local.set $2
                                   (i64.sub
                                    (local.get $2)
                                    (i64.const 1)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global201)
                                   )
                                  )
                                  (if (result i64)
                                   (call $function71
                                    (local.get $0)
                                    (local.get $3)
                                   )
                                   (then
                                    (local.get $2)
                                   )
                                   (else
                                    (if (result i64)
                                     (ref.is_null
                                      (local.tee $1
                                       (struct.get $type36 1
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                     (else
                                      (local.set $3
                                       (struct.get $type36 0
                                        (local.get $1)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready201)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (local.set $2
                                       (i64.sub
                                        (local.get $2)
                                        (i64.const 1)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global201)
                                       )
                                      )
                                      (if (result i64)
                                       (call $function71
                                        (local.get $0)
                                        (local.get $3)
                                       )
                                       (then
                                        (local.get $2)
                                       )
                                       (else
                                        (if (result i64)
                                         (ref.is_null
                                          (local.tee $1
                                           (struct.get $type36 1
                                            (local.get $1)
                                           )
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                         (else
                                          (local.set $2
                                           (i64.sub
                                            (local.get $2)
                                            (i64.const 1)
                                           )
                                          )
                                          (local.set $3
                                           (struct.get $type36 0
                                            (local.get $1)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready201)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global201)
                                           )
                                          )
                                          (if (result i64)
                                           (call $function71
                                            (local.get $0)
                                            (local.get $3)
                                           )
                                           (then
                                            (local.get $2)
                                           )
                                           (else
                                            (return_call $function70
                                             (local.get $0)
                                             (i32.const 0)
                                             (i32.const 1)
                                             (struct.get $type36 1
                                              (local.get $1)
                                             )
                                             (i64.sub
                                              (local.get $2)
                                              (i64.const 1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function68 (type $call35) (param $0 (ref null $type36)) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $0
       (struct.get $type36 1
        (local.get $0)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $0
         (struct.get $type36 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $0
           (struct.get $type36 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $0
             (struct.get $type36 1
              (local.get $0)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $0
               (struct.get $type36 1
                (local.get $0)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $0
                 (struct.get $type36 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type36 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type36 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (return_call $function69
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type36 1
                      (local.get $0)
                     )
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function69 (type $21) (param $0 i32) (param $1 i32) (param $2 (ref null $type36)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type36 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function70 (type $20) (param $0 (ref $type37)) (param $1 i32) (param $2 i32) (param $3 (ref null $type36)) (param $4 i64) (result i64)
  (local $5 (ref $type39))
  (if (result i64)
   (ref.is_null
    (local.get $3)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $5
     (struct.get $type36 0
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (global.get $ready201)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global201)
     )
    )
    (if (result i64)
     (call $function71
      (local.get $0)
      (local.get $5)
     )
     (then
      (local.get $4)
     )
     (else
      (local.set $3
       (struct.get $type36 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function70
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.sub
        (local.get $4)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function71 (param $0 (ref $type37)) (param $1 (ref $type39)) (result i32)
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type39)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type39)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready132)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready132)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $0)
      )
     )
     (then
      (unreachable)
     )
    )
    (ref.eq
     (struct.get $type39 0
      (ref.cast (ref $type39)
       (local.get $0)
      )
     )
     (struct.get $type39 0
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function72 (type $18) (param $0 i64) (param $1 (ref $type37)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref $type37))
  (local $5 (ref $type27))
  (local $6 (ref $type39))
  (if (result (ref $type37))
   (i64.eqz
    (local.get $4)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type34 0
      (struct.get $type39 0
       (ref.cast (ref $type39)
        (local.get $1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (drop
     (if (result i32)
      (if (result i32)
       (ref.test (ref $type29)
        (local.get $5)
       )
       (then
        (drop
         (ref.cast (ref $type29)
          (local.get $5)
         )
        )
        (i32.const 0)
       )
       (else
        (i32.const 1)
       )
      )
      (then
       (call $function73
        (local.get $0)
        (i32.const 0)
        (i32.const 1)
        (local.get $1)
       )
      )
      (else
       (if
        (i32.eqz
         (global.get $ready139)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global139)
        )
       )
       (if
        (i32.eqz
         (ref.test (ref $type39)
          (local.get $1)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function81
        (local.get $4)
        (i32.const 0)
        (i32.const 1)
        (local.tee $6
         (ref.cast (ref $type39)
          (local.get $1)
         )
        )
        (struct.get $type40 0
         (struct.get $type39 1
          (local.get $6)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function72
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function73 (type $17) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 (ref $type37)) (result i32)
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type32))
  (local $7 (ref $type27))
  (local $8 (ref $type27))
  (local $9 (ref $type28))
  (local $10 i64)
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type39)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type39)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type34 0
      (struct.get $type39 0
       (ref.cast (ref $type39)
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (if
     (if (result i32)
      (ref.test (ref $type29)
       (local.get $7)
      )
      (then
       (drop
        (ref.cast (ref $type29)
         (local.get $7)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (call $function74
        (ref.as_non_null
         (global.get $global109)
        )
        (block (result (ref (exact $type28)))
         (if
          (i32.eqz
           (global.get $ready208)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global208)
          )
         )
         (struct.new_default $type28)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready219)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global219)
       )
      )
      (call $function78
       (local.get $3)
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type34 0
      (struct.get $type39 0
       (ref.cast (ref $type39)
        (local.get $3)
       )
      )
     )
    )
    (local.set $9
     (struct.new_default $type28)
    )
    (local.set $7
     (if (result (ref $type27))
      (i64.eqz
       (local.get $0)
      )
      (then
       (local.get $9)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready109)
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (call $function74
         (ref.as_non_null
          (global.get $global109)
         )
         (block (result (ref $type28))
          (if
           (i32.eqz
            (global.get $ready208)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global208)
           )
          )
          (local.get $9)
         )
        )
       )
       (if (result (ref $type27))
        (i64.eqz
         (local.tee $10
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $4)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready109)
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (call $function74
           (ref.as_non_null
            (global.get $global109)
           )
           (block (result (ref $type29))
            (if
             (i32.eqz
              (global.get $ready208)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global208)
             )
            )
            (local.get $4)
           )
          )
         )
         (if (result (ref $type27))
          (i64.eqz
           (local.tee $10
            (i64.sub
             (local.get $10)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $4)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready109)
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (call $function74
             (ref.as_non_null
              (global.get $global109)
             )
             (block (result (ref $type29))
              (if
               (i32.eqz
                (global.get $ready208)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global208)
               )
              )
              (local.get $4)
             )
            )
           )
           (if (result (ref $type27))
            (i64.eqz
             (local.tee $10
              (i64.sub
               (local.get $10)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $4)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready109)
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (call $function74
               (ref.as_non_null
                (global.get $global109)
               )
               (block (result (ref $type29))
                (if
                 (i32.eqz
                  (global.get $ready208)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global208)
                 )
                )
                (local.get $4)
               )
              )
             )
             (if (result (ref $type27))
              (i64.eqz
               (local.tee $10
                (i64.sub
                 (local.get $10)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $4)
              )
              (else
               (if
                (i32.eqz
                 (global.get $ready109)
                )
                (then
                 (unreachable)
                )
               )
               (local.set $4
                (call $function74
                 (ref.as_non_null
                  (global.get $global109)
                 )
                 (block (result (ref $type29))
                  (if
                   (i32.eqz
                    (global.get $ready208)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global208)
                   )
                  )
                  (local.get $4)
                 )
                )
               )
               (if (result (ref $type27))
                (i64.eqz
                 (local.tee $10
                  (i64.sub
                   (local.get $10)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $4)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready109)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (call $function74
                   (ref.as_non_null
                    (global.get $global109)
                   )
                   (block (result (ref $type29))
                    (if
                     (i32.eqz
                      (global.get $ready208)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global208)
                     )
                    )
                    (local.get $4)
                   )
                  )
                 )
                 (if (result (ref $type27))
                  (i64.eqz
                   (local.tee $10
                    (i64.sub
                     (local.get $10)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $4)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready109)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $4
                    (call $function74
                     (ref.as_non_null
                      (global.get $global109)
                     )
                     (block (result (ref $type29))
                      (if
                       (i32.eqz
                        (global.get $ready208)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global208)
                       )
                      )
                      (local.get $4)
                     )
                    )
                   )
                   (if (result (ref $type27))
                    (i64.eqz
                     (local.tee $10
                      (i64.sub
                       (local.get $10)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (if
                      (i32.eqz
                       (global.get $ready109)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $4
                      (call $function74
                       (ref.as_non_null
                        (global.get $global109)
                       )
                       (block (result (ref $type29))
                        (if
                         (i32.eqz
                          (global.get $ready208)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global208)
                         )
                        )
                        (local.get $4)
                       )
                      )
                     )
                     (if (result (ref $type27))
                      (i64.eqz
                       (local.tee $10
                        (i64.sub
                         (local.get $10)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $4)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready109)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $4
                        (call $function74
                         (ref.as_non_null
                          (global.get $global109)
                         )
                         (block (result (ref $type29))
                          (if
                           (i32.eqz
                            (global.get $ready208)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global208)
                           )
                          )
                          (local.get $4)
                         )
                        )
                       )
                       (if (result (ref $type27))
                        (i64.eqz
                         (local.tee $10
                          (i64.sub
                           (local.get $10)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $4)
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready109)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $6
                          (ref.as_non_null
                           (global.get $global109)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready208)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global208)
                          )
                         )
                         (call $function80
                          (i32.const 0)
                          (i32.const 1)
                          (i64.sub
                           (local.get $10)
                           (i64.const 1)
                          )
                          (call $function74
                           (local.get $6)
                           (local.get $4)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready141)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global141)
     )
    )
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (drop
     (if (result (ref $type27))
      (if (result i32)
       (ref.test (ref $type29)
        (local.get $8)
       )
       (then
        (drop
         (ref.cast (ref $type29)
          (local.get $8)
         )
        )
        (i32.const 0)
       )
       (else
        (i32.const 1)
       )
      )
      (then
       (local.get $7)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready127)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global127)
        )
       )
       (if
        (i32.eqz
         (ref.test (ref $type29)
          (local.get $8)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function52
        (local.tee $5
         (ref.cast (ref $type29)
          (local.get $8)
         )
        )
        (local.get $7)
        (i32.const 0)
        (i32.const 1)
        (local.get $5)
        (struct.get $type34 0
         (struct.get $type29 1
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready139)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type40 0
      (struct.get $type39 1
       (ref.cast (ref $type39)
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function73
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function74 (type $16) (param $0 (ref $type32)) (param $1 (ref $type27)) (result (ref $type29))
  (local $2 (ref $type29))
  (local $3 (ref $type67))
  (if
   (i32.eqz
    (global.get $ready212)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global212)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.new $type29
    (struct.new $type30
     (local.get $0)
    )
    (struct.new $type34
     (local.get $1)
    )
   )
  )
  (if
   (struct.get $type65 0
    (global.get $global150)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type67 0
     (ref.as_non_null
      (global.get $global153)
     )
     (block (result (ref (exact $type26)))
      (if
       (i32.eqz
        (global.get $ready153)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type26
       (local.get $2)
       (struct.get $type67 0
        (global.get $global153)
       )
      )
     )
    )
    (call $foreign0
     (i64.const 1)
    )
    (if
     (i32.eqz
      (global.get $ready215)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global215)
     )
    )
    (drop
     (call $function76
      (local.get $2)
     )
    )
   )
  )
  (local.get $2)
 )
 (func $function76 (type $call72) (param $0 (ref $type29)) (result i32)
  (local $1 (ref $type31))
  (local $2 (ref null $type26))
  (local $3 (ref $type27))
  (local $scratch (ref null $type26))
  (if
   (i32.eqz
    (global.get $ready151)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global151)
   )
  )
  (if
   (i32.eqz
    (global.get $ready153)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type67 0
    (global.get $global153)
   )
  )
  (if
   (i32.eqz
    (global.get $ready154)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global154)
   )
  )
  (call $foreign0
   (call $function55
    (local.get $0)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (local.set $1
   (struct.get $type30 0
    (struct.get $type29 0
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready217)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (if
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (call $foreign0
     (i64.const 0)
    )
   )
   (else
    (call $foreign0
     (i64.const 1)
    )
    (if
     (ref.test (ref $type32)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (call $foreign0
   (call $function55
    (struct.get $type34 0
     (struct.get $type29 1
      (local.get $0)
     )
    )
    (block (result (ref null $type26))
     (if
      (i32.eqz
       (global.get $ready151)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global151)
      )
     )
     (if
      (i32.eqz
       (global.get $ready153)
      )
      (then
       (unreachable)
      )
     )
     (local.set $scratch
      (struct.get $type67 0
       (global.get $global153)
      )
     )
     (if
      (i32.eqz
       (global.get $ready154)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global154)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (i32.const 0)
 )
 (func $function78 (param $0 (ref $type37)) (param $1 (ref $type27))
  (local $2 (ref null $type36))
  (local $3 (ref null $type26))
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (if
   (struct.get $type65 0
    (global.get $global150)
   )
   (then
    (call $foreign0
     (i64.const 2)
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (if
     (i32.eqz
      (global.get $ready185)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type66 0
      (global.get $global185)
     )
    )
    (if
     (i32.eqz
      (global.get $ready190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (call $foreign0
     (call $function67
      (local.get $0)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready151)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global151)
     )
    )
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type67 0
      (global.get $global153)
     )
    )
    (if
     (i32.eqz
      (global.get $ready154)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global154)
     )
    )
    (call $foreign0
     (call $function55
      (local.get $1)
      (local.get $3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready222)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global222)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type39)
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type34 0
   (struct.get $type39 0
    (ref.cast (ref $type39)
     (local.get $0)
    )
   )
   (local.get $1)
  )
 )
 (func $function80 (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref $type29)) (result (ref $type27))
  (local $4 (ref $type32))
  (if (result (ref $type29))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function74
      (ref.as_non_null
       (global.get $global109)
      )
      (block (result (ref $type29))
       (if
        (i32.eqz
         (global.get $ready208)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global208)
        )
       )
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function80
     (local.get $0)
     (local.get $1)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
     (local.get $3)
    )
   )
  )
 )
 (func $function81 (type $11) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 (ref $type37)) (param $4 (ref $type37)) (result i32)
  (local $5 (ref $type27))
  (local $6 (ref $type27))
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type39)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type39)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type34 0
      (struct.get $type39 0
       (ref.cast (ref $type39)
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready233)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global233)
     )
    )
    (local.set $5
     (if (result (ref $type27))
      (i64.eqz
       (local.tee $7
        (i64.div_s
         (call $function83
          (i32.const 0)
          (i32.const 1)
          (local.get $5)
          (i64.const 0)
         )
         (i64.const 2)
        )
       )
      )
      (then
       (if
        (i32.eqz
         (global.get $ready219)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global219)
        )
       )
       (call $function78
        (local.get $3)
        (struct.new_default $type28)
       )
       (if
        (i32.eqz
         (global.get $ready137)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (if
        (i32.eqz
         (ref.test (ref $type39)
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.get $type34 0
        (struct.get $type39 0
         (ref.cast (ref $type39)
          (local.get $3)
         )
        )
       )
      )
      (else
       (if
        (i32.eqz
         (global.get $ready137)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (if
        (i32.eqz
         (ref.test (ref $type39)
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function84
        (local.get $0)
        (i32.const 0)
        (i32.const 1)
        (local.get $7)
        (struct.get $type34 0
         (struct.get $type39 0
          (ref.cast (ref $type39)
           (local.get $3)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type34 0
      (struct.get $type39 0
       (ref.cast (ref $type39)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready233)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global233)
     )
    )
    (local.set $7
     (call $function83
      (i32.const 0)
      (i32.const 1)
      (local.get $6)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (call $function53
     (call $function87
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.div_s
       (local.get $7)
       (i64.const 2)
      )
      (struct.get $type34 0
       (struct.get $type39 0
        (ref.cast (ref $type39)
         (local.get $4)
        )
       )
      )
     )
     (block (result (ref $type27))
      (if
       (i32.eqz
        (global.get $ready147)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global147)
       )
      )
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (global.get $ready139)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type40 0
      (struct.get $type39 1
       (ref.cast (ref $type39)
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready139)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type40 0
      (struct.get $type39 1
       (ref.cast (ref $type39)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function83 (type $10) (param $0 i32) (param $1 i32) (param $2 (ref $type27)) (param $3 i64) (result i64)
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $2)
    )
    (then
     (drop
      (ref.cast (ref $type29)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type34 0
      (struct.get $type29 1
       (ref.cast (ref $type29)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function84 (type $9) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref $type27)) (result (ref $type27))
  (local $5 (ref $type33))
  (local $6 (ref $type27))
  (local $7 (ref null $type26))
  (local $scratch (ref $type27))
  (if (result (ref $type27))
   (i64.eq
    (local.get $3)
    (i64.const 1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (struct.get $type34 0
      (struct.get $type29 1
       (ref.cast (ref $type29)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready147)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (call $function53
     (local.get $4)
     (struct.new_default $type28)
    )
    (local.get $scratch)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready242)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global242)
     )
    )
    (if
     (i32.eqz
      (global.get $ready150)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.new $type33
      (local.get $0)
     )
    )
    (if
     (struct.get $type65 0
      (global.get $global150)
     )
     (then
      (call $foreign0
       (i64.const 3)
      )
      (if
       (i32.eqz
        (global.get $ready151)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global151)
       )
      )
      (if
       (i32.eqz
        (global.get $ready153)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (struct.get $type67 0
        (global.get $global153)
       )
      )
      (if
       (i32.eqz
        (global.get $ready154)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global154)
       )
      )
      (call $foreign0
       (call $function55
        (local.get $4)
        (local.get $7)
       )
      )
      (if
       (i32.eqz
        (global.get $ready217)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global217)
       )
      )
      (if
       (i32.eqz
        (global.get $ready110)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (call $foreign0
       (i64.const 1)
      )
      (call $foreign0
       (struct.get $type33 0
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready245)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global245)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type30 0
     (struct.get $type29 0
      (ref.cast (ref $type29)
       (local.get $4)
      )
     )
     (local.get $5)
    )
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type34 0
      (struct.get $type29 1
       (ref.cast (ref $type29)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function87 (type $9) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref $type27)) (result (ref $type27))
  (local $5 (ref $type33))
  (local $6 (ref null $type26))
  (if
   (i32.eqz
    (global.get $ready252)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global252)
   )
  )
  (if (result (ref $type27))
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready242)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global242)
     )
    )
    (if
     (i32.eqz
      (global.get $ready150)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.new $type33
      (local.get $0)
     )
    )
    (if
     (struct.get $type65 0
      (global.get $global150)
     )
     (then
      (call $foreign0
       (i64.const 3)
      )
      (if
       (i32.eqz
        (global.get $ready151)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global151)
       )
      )
      (if
       (i32.eqz
        (global.get $ready153)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.get $type67 0
        (global.get $global153)
       )
      )
      (if
       (i32.eqz
        (global.get $ready154)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global154)
       )
      )
      (call $foreign0
       (call $function55
        (local.get $4)
        (local.get $6)
       )
      )
      (if
       (i32.eqz
        (global.get $ready217)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global217)
       )
      )
      (if
       (i32.eqz
        (global.get $ready110)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (call $foreign0
       (i64.const 1)
      )
      (call $foreign0
       (struct.get $type33 0
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready245)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global245)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type30 0
     (struct.get $type29 0
      (ref.cast (ref $type29)
       (local.get $4)
      )
     )
     (local.get $5)
    )
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type34 0
      (struct.get $type29 1
       (ref.cast (ref $type29)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function89 (type $call72) (param $0 (ref $type29)) (result i32)
  (if
   (i32.eqz
    (global.get $ready233)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global233)
   )
  )
  (call $foreign0
   (call $function83
    (i32.const 0)
    (i32.const 1)
    (local.get $0)
    (i64.const 0)
   )
  )
  (return_call $function90
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
  )
 )
 (func $function90 (type $8) (param $0 i32) (param $1 i32) (param $2 (ref $type27)) (result i32)
  (local $3 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $2)
    )
    (then
     (drop
      (ref.cast (ref $type29)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type30 0
      (struct.get $type29 0
       (ref.cast (ref $type29)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready217)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global217)
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (if (result i32)
      (ref.test (ref $type32)
       (local.get $3)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (call $foreign0
       (i64.const 0)
      )
     )
     (else
      (call $foreign0
       (i64.const 1)
      )
      (if
       (ref.test (ref $type32)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign0
       (struct.get $type33 0
        (ref.cast (ref $type33)
         (local.get $3)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type29)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type34 0
      (struct.get $type29 1
       (ref.cast (ref $type29)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function90
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function91 (type $call71) (param $0 (ref $type39)) (result i32)
  (call $foreign0
   (i64.const 9)
  )
  (if
   (i32.eqz
    (global.get $ready260)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global260)
   )
  )
  (call $foreign0
   (call $function93
    (i32.const 0)
    (i32.const 1)
    (local.get $0)
    (i64.const 0)
   )
  )
  (return_call $function94
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
  )
 )
 (func $function93 (type $7) (param $0 i32) (param $1 i32) (param $2 (ref $type37)) (param $3 i64) (result i64)
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type39)
     (local.get $2)
    )
    (then
     (drop
      (ref.cast (ref $type39)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready139)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type40 0
      (struct.get $type39 1
       (ref.cast (ref $type39)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function93
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function94 (type $6) (param $0 i32) (param $1 i32) (param $2 (ref $type37)) (result i32)
  (local $3 (ref $type27))
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type39)
     (local.get $2)
    )
    (then
     (drop
      (ref.cast (ref $type39)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type34 0
      (struct.get $type39 0
       (ref.cast (ref $type39)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready254)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global254)
     )
    )
    (if
     (i32.eqz
      (global.get $ready233)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global233)
     )
    )
    (call $foreign0
     (call $function83
      (i32.const 0)
      (i32.const 1)
      (local.get $3)
      (i64.const 0)
     )
    )
    (drop
     (call $function90
      (i32.const 0)
      (i32.const 1)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (global.get $ready139)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type39)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type40 0
      (struct.get $type39 1
       (ref.cast (ref $type39)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function94
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function95 (type $call10) (result i32)
  (local $0 (ref null $type36))
  (local $1 (ref null $type26))
  (local $2 (ref $type71))
  (local $3 (ref $type72))
  (call $foreign0
   (i64.const 10)
  )
  (if
   (i32.eqz
    (global.get $ready186)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global186)
   )
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (struct.get $type66 0
    (global.get $global185)
   )
  )
  (if
   (i32.eqz
    (global.get $ready268)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global268)
   )
  )
  (if
   (i32.eqz
    (global.get $ready193)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global193)
   )
  )
  (call $foreign0
   (call $function68
    (local.get $0)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call71
       (struct.get $type36 0
        (local.get $0)
       )
       (struct.get $type71 0
        (local.get $2)
       )
      )
     )
     (if (result i32)
      (ref.is_null
       (local.tee $0
        (struct.get $type36 1
         (local.get $0)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call71
         (struct.get $type36 0
          (local.get $0)
         )
         (struct.get $type71 0
          (local.get $2)
         )
        )
       )
       (if (result i32)
        (ref.is_null
         (local.tee $0
          (struct.get $type36 1
           (local.get $0)
          )
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call71
           (struct.get $type36 0
            (local.get $0)
           )
           (struct.get $type71 0
            (local.get $2)
           )
          )
         )
         (if (result i32)
          (ref.is_null
           (local.tee $0
            (struct.get $type36 1
             (local.get $0)
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call71
             (struct.get $type36 0
              (local.get $0)
             )
             (struct.get $type71 0
              (local.get $2)
             )
            )
           )
           (if (result i32)
            (ref.is_null
             (local.tee $0
              (struct.get $type36 1
               (local.get $0)
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call71
               (struct.get $type36 0
                (local.get $0)
               )
               (struct.get $type71 0
                (local.get $2)
               )
              )
             )
             (if (result i32)
              (ref.is_null
               (local.tee $0
                (struct.get $type36 1
                 (local.get $0)
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call71
                 (struct.get $type36 0
                  (local.get $0)
                 )
                 (struct.get $type71 0
                  (local.get $2)
                 )
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.tee $0
                  (struct.get $type36 1
                   (local.get $0)
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call71
                   (struct.get $type36 0
                    (local.get $0)
                   )
                   (struct.get $type71 0
                    (local.get $2)
                   )
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.tee $0
                    (struct.get $type36 1
                     (local.get $0)
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call71
                     (struct.get $type36 0
                      (local.get $0)
                     )
                     (struct.get $type71 0
                      (local.get $2)
                     )
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.tee $0
                      (struct.get $type36 1
                       (local.get $0)
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call71
                       (struct.get $type36 0
                        (local.get $0)
                       )
                       (struct.get $type71 0
                        (local.get $2)
                       )
                      )
                     )
                     (call $function97
                      (local.get $2)
                      (i32.const 0)
                      (i32.const 1)
                      (struct.get $type36 1
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready215)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (if
   (i32.eqz
    (global.get $ready153)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type67 0
    (global.get $global153)
   )
  )
  (if
   (i32.eqz
    (global.get $ready273)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global273)
   )
  )
  (if
   (i32.eqz
    (global.get $ready157)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global157)
   )
  )
  (call $foreign0
   (call $function56
    (local.get $1)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call72
      (struct.get $type26 0
       (local.get $1)
      )
      (struct.get $type72 0
       (local.get $3)
      )
     )
    )
    (if (result i32)
     (ref.is_null
      (local.tee $1
       (struct.get $type26 1
        (local.get $1)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (call_ref $call72
        (struct.get $type26 0
         (local.get $1)
        )
        (struct.get $type72 0
         (local.get $3)
        )
       )
      )
      (if (result i32)
       (ref.is_null
        (local.tee $1
         (struct.get $type26 1
          (local.get $1)
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (call_ref $call72
          (struct.get $type26 0
           (local.get $1)
          )
          (struct.get $type72 0
           (local.get $3)
          )
         )
        )
        (if (result i32)
         (ref.is_null
          (local.tee $1
           (struct.get $type26 1
            (local.get $1)
           )
          )
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (call_ref $call72
            (struct.get $type26 0
             (local.get $1)
            )
            (struct.get $type72 0
             (local.get $3)
            )
           )
          )
          (if (result i32)
           (ref.is_null
            (local.tee $1
             (struct.get $type26 1
              (local.get $1)
             )
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (call_ref $call72
              (struct.get $type26 0
               (local.get $1)
              )
              (struct.get $type72 0
               (local.get $3)
              )
             )
            )
            (if (result i32)
             (ref.is_null
              (local.tee $1
               (struct.get $type26 1
                (local.get $1)
               )
              )
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (call_ref $call72
                (struct.get $type26 0
                 (local.get $1)
                )
                (struct.get $type72 0
                 (local.get $3)
                )
               )
              )
              (if (result i32)
               (ref.is_null
                (local.tee $1
                 (struct.get $type26 1
                  (local.get $1)
                 )
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (call_ref $call72
                  (struct.get $type26 0
                   (local.get $1)
                  )
                  (struct.get $type72 0
                   (local.get $3)
                  )
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.tee $1
                   (struct.get $type26 1
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (call_ref $call72
                    (struct.get $type26 0
                     (local.get $1)
                    )
                    (struct.get $type72 0
                     (local.get $3)
                    )
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.tee $1
                     (struct.get $type26 1
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (call_ref $call72
                      (struct.get $type26 0
                       (local.get $1)
                      )
                      (struct.get $type72 0
                       (local.get $3)
                      )
                     )
                    )
                    (return_call $function99
                     (local.get $3)
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type26 1
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function97 (type $4) (param $0 (ref $type71)) (param $1 i32) (param $2 i32) (param $3 (ref null $type36)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call71
      (struct.get $type36 0
       (local.get $3)
      )
      (struct.get $type71 0
       (local.get $0)
      )
     )
    )
    (local.set $3
     (struct.get $type36 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function97
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function99 (type $3) (param $0 (ref $type72)) (param $1 i32) (param $2 i32) (param $3 (ref null $type26)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call72
      (struct.get $type26 0
       (local.get $3)
      )
      (struct.get $type72 0
       (local.get $0)
      )
     )
    )
    (local.set $3
     (struct.get $type26 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type37))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready278)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global278)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type65 0
   (global.get $global150)
   (i64.eq
    (local.get $2)
    (i64.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (local.set $3
   (call $function61
    (local.get $0)
    (local.get $1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready258)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global258)
   )
  )
  (call $foreign0
   (i64.const 9)
  )
  (if
   (i32.eqz
    (global.get $ready260)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global260)
   )
  )
  (call $foreign0
   (call $function93
    (i32.const 0)
    (i32.const 1)
    (local.get $3)
    (i64.const 0)
   )
  )
  (drop
   (call $function94
    (i32.const 0)
    (i32.const 1)
    (local.get $3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (if
   (struct.get $type65 0
    (global.get $global150)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready267)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global267)
     )
    )
    (drop
     (call $function95)
    )
   )
  )
  (i64.const 1)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global157
   (struct.new_default $type25)
  )
  (global.set $ready157
   (i32.const 1)
  )
  (global.set $global193
   (struct.new_default $type35)
  )
  (global.set $ready193
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type32)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global182
   (struct.new_default $type41)
  )
  (global.set $ready182
   (i32.const 1)
  )
  (global.set $global212
   (struct.new_default $type42)
  )
  (global.set $ready212
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type43)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type44)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global125
   (struct.new_default $type45)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type46)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type47)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type48)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global222
   (struct.new_default $type49)
  )
  (global.set $ready222
   (i32.const 1)
  )
  (global.set $global245
   (struct.new_default $type50)
  )
  (global.set $ready245
   (i32.const 1)
  )
  (global.set $global168
   (struct.new_default $type51)
  )
  (global.set $ready168
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type52)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global252
   (struct.new_default $type53)
  )
  (global.set $ready252
   (i32.const 1)
  )
  (global.set $global233
   (struct.new_default $type54)
  )
  (global.set $ready233
   (i32.const 1)
  )
  (global.set $global260
   (struct.new_default $type55)
  )
  (global.set $ready260
   (i32.const 1)
  )
  (global.set $global165
   (struct.new_default $type61)
  )
  (global.set $ready165
   (i32.const 1)
  )
  (global.set $global201
   (struct.new_default $type62)
  )
  (global.set $ready201
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type63)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global171
   (struct.new_default $type64)
  )
  (global.set $ready171
   (i32.const 1)
  )
  (global.set $global150
   (struct.new_default $type65)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $global185
   (struct.new_default $type66)
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global153
   (struct.new_default $type67)
  )
  (global.set $ready153
   (i32.const 1)
  )
  (global.set $global154
   (struct.new_default $type68)
  )
  (global.set $ready154
   (i32.const 1)
  )
  (global.set $global190
   (struct.new_default $type69)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global188
   (struct.new_default $type55)
  )
  (global.set $ready188
   (i32.const 1)
  )
  (global.set $global151
   (struct.new_default $type54)
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $global217
   (struct.new_default $type70)
  )
  (global.set $ready217
   (i32.const 1)
  )
  (global.set $global186
   (struct.new $type71
    (ref.func $function65)
   )
  )
  (global.set $ready186
   (i32.const 1)
  )
  (global.set $global215
   (struct.new $type72
    (ref.func $function76)
   )
  )
  (global.set $ready215
   (i32.const 1)
  )
  (global.set $global178
   (struct.new_default $type41)
  )
  (global.set $ready178
   (i32.const 1)
  )
  (global.set $global208
   (struct.new_default $type42)
  )
  (global.set $ready208
   (i32.const 1)
  )
  (global.set $global219
   (struct.new_default $type49)
  )
  (global.set $ready219
   (i32.const 1)
  )
  (global.set $global242
   (struct.new_default $type50)
  )
  (global.set $ready242
   (i32.const 1)
  )
  (global.set $global147
   (struct.new_default $type51)
  )
  (global.set $ready147
   (i32.const 1)
  )
  (global.set $global254
   (struct.new $type72
    (ref.func $function89)
   )
  )
  (global.set $ready254
   (i32.const 1)
  )
  (global.set $global258
   (struct.new $type71
    (ref.func $function91)
   )
  )
  (global.set $ready258
   (i32.const 1)
  )
  (global.set $global268
   (struct.new_default $type73)
  )
  (global.set $ready268
   (i32.const 1)
  )
  (global.set $global273
   (struct.new_default $type74)
  )
  (global.set $ready273
   (i32.const 1)
  )
  (global.set $global267
   (struct.new_default $type10)
  )
  (global.set $ready267
   (i32.const 1)
  )
  (global.set $global278
   (struct.new_default $type75)
  )
  (global.set $ready278
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

