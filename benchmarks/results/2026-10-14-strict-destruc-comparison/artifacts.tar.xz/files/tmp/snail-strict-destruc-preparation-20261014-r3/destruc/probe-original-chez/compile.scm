(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-destruc-preparation-20261014-r3/destruc/probe-original-chez/program.scm" "/tmp/snail-strict-destruc-preparation-20261014-r3/destruc/probe-original-chez/program.so"))
