(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-general-specialization-20261012/build/strict-ack-current-20261014/ack/program.scm" "/tmp/snail-general-specialization-20261012/build/strict-ack-current-20261014/ack/program.so"))
