
/tmp/snail-general-specialization-20261012/build/strict-ack-current-20261014/ack-native:     file format elf64-x86-64


Disassembly of section .text:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
