
/tmp/snail-general-specialization-20261012/build/strict-ack-current-20261014/ack-native:     file format elf64-x86-64


Disassembly of section .text:

0000000000047cc0 <f.5>:
   47cc0:	push   %rbx
   47cc1:	sub    $0x10,%rsp
   47cc5:	mov    %rsi,%rax
   47cc8:	mov    %rdi,%rbx
   47ccb:	sub    $0x1,%rbx
   47ccf:	jb     47d3d <f.5+0x7d>
   47cd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   47ce0:	movzbl 0x79c9(%rip),%ecx        # 4f6b0 <g.3>
   47ce7:	test   %rax,%rax
   47cea:	je     47d20 <f.5+0x60>
   47cec:	test   $0x1,%cl
   47cef:	je     47d48 <f.5+0x88>
   47cf1:	cmpq   $0x0,0x79af(%rip)        # 4f6a8 <g.2>
   47cf9:	je     47d48 <f.5+0x88>
   47cfb:	dec    %rax
   47cfe:	mov    %rax,%rsi
   47d01:	call   47cc0 <f.5>
   47d06:	sub    $0x8,%rsp
   47d0a:	cmpb   $0x0,0x799f(%rip)        # 4f6b0 <g.3>
   47d11:	je     47d48 <f.5+0x88>
   47d13:	cmpq   $0x0,0x798d(%rip)        # 4f6a8 <g.2>
   47d1b:	jne    47d34 <f.5+0x74>
   47d1d:	jmp    47d48 <f.5+0x88>
   47d1f:	nop
   47d20:	test   $0x1,%cl
   47d23:	je     47d48 <f.5+0x88>
   47d25:	mov    $0x1,%eax
   47d2a:	cmpq   $0x0,0x7976(%rip)        # 4f6a8 <g.2>
   47d32:	je     47d48 <f.5+0x88>
   47d34:	mov    %rbx,%rdi
   47d37:	sub    $0x1,%rbx
   47d3b:	jae    47ce0 <f.5+0x20>
   47d3d:	inc    %rax
   47d40:	add    $0x10,%rsp
   47d44:	pop    %rbx
   47d45:	ret    $0x8
   47d48:	call   47f30 <native_trap>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
