(module
 (type $0 (func (param i64) (result i64)))
 (rec
  (type $call27 (func (param i64 i64) (result i64)))
  (type $2 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $call28 (func (param i64) (result i64)))
  (type $type28 (struct))
  (type $type27 (struct))
 )
 (type $6 (func (param i32) (result i64)))
 (type $7 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $global119 (mut (ref null $type27)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global109 (mut i64) (i64.const 0))
 (global $global110 (mut i64) (i64.const 0))
 (global $global111 (mut (ref null $type28)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call28) (param $0 i64) (result i64)
  (local $1 i64)
  (local $2 i64)
  (local $scratch i64)
  (local $scratch_4 i64)
  (local $scratch_5 i64)
  (local $scratch_6 i64)
  (local $scratch_7 i64)
  (local $scratch_8 i64)
  (local $scratch_9 i64)
  (local $scratch_10 i64)
  (local $scratch_11 i64)
  (local $scratch_12 i64)
  (local $scratch_13 i64)
  (local $scratch_14 i64)
  (local $scratch_15 i64)
  (local $scratch_16 i64)
  (local $scratch_17 i64)
  (local $scratch_18 i64)
  (local $scratch_19 i64)
  (local $scratch_20 i64)
  (local $scratch_21 i64)
  (local $scratch_22 i64)
  (local $scratch_23 i64)
  (local $scratch_24 i64)
  (local $scratch_25 i64)
  (local $scratch_26 i64)
  (local $scratch_27 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (local.set $1
     (call $function44
      (call $foreign0
       (global.get $global109)
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global116)
        )
       )
       (local.set $scratch
        (call $foreign0
         (global.get $global110)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global119)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if (result i64)
     (i64.gt_s
      (local.get $0)
      (i64.const 1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (local.set $1
       (call $function44
        (call $foreign0
         (global.get $global109)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global116)
          )
         )
         (local.set $scratch_4
          (call $foreign0
           (global.get $global110)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global119)
          )
         )
         (local.get $scratch_4)
        )
       )
      )
      (if (result i64)
       (i64.gt_s
        (local.get $0)
        (i64.const 2)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global116)
         )
        )
        (local.set $1
         (call $function44
          (call $foreign0
           (global.get $global109)
          )
          (block (result i64)
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (local.set $scratch_5
            (call $foreign0
             (global.get $global110)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global119)
            )
           )
           (local.get $scratch_5)
          )
         )
        )
        (if (result i64)
         (i64.gt_s
          (local.get $0)
          (i64.const 3)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global116)
           )
          )
          (local.set $1
           (call $function44
            (call $foreign0
             (global.get $global109)
            )
            (block (result i64)
             (drop
              (ref.as_non_null
               (global.get $global116)
              )
             )
             (local.set $scratch_6
              (call $foreign0
               (global.get $global110)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global119)
              )
             )
             (local.get $scratch_6)
            )
           )
          )
          (if (result i64)
           (i64.gt_s
            (local.get $0)
            (i64.const 4)
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global116)
             )
            )
            (local.set $1
             (call $function44
              (call $foreign0
               (global.get $global109)
              )
              (block (result i64)
               (drop
                (ref.as_non_null
                 (global.get $global116)
                )
               )
               (local.set $scratch_7
                (call $foreign0
                 (global.get $global110)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global119)
                )
               )
               (local.get $scratch_7)
              )
             )
            )
            (if (result i64)
             (i64.gt_s
              (local.get $0)
              (i64.const 5)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global116)
               )
              )
              (local.set $1
               (call $function44
                (call $foreign0
                 (global.get $global109)
                )
                (block (result i64)
                 (drop
                  (ref.as_non_null
                   (global.get $global116)
                  )
                 )
                 (local.set $scratch_8
                  (call $foreign0
                   (global.get $global110)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global119)
                  )
                 )
                 (local.get $scratch_8)
                )
               )
              )
              (if (result i64)
               (i64.gt_s
                (local.get $0)
                (i64.const 6)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global116)
                 )
                )
                (local.set $1
                 (call $function44
                  (call $foreign0
                   (global.get $global109)
                  )
                  (block (result i64)
                   (drop
                    (ref.as_non_null
                     (global.get $global116)
                    )
                   )
                   (local.set $scratch_9
                    (call $foreign0
                     (global.get $global110)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global119)
                    )
                   )
                   (local.get $scratch_9)
                  )
                 )
                )
                (if (result i64)
                 (i64.gt_s
                  (local.get $0)
                  (i64.const 7)
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global116)
                   )
                  )
                  (local.set $1
                   (call $function44
                    (call $foreign0
                     (global.get $global109)
                    )
                    (block (result i64)
                     (drop
                      (ref.as_non_null
                       (global.get $global116)
                      )
                     )
                     (local.set $scratch_10
                      (call $foreign0
                       (global.get $global110)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global119)
                      )
                     )
                     (local.get $scratch_10)
                    )
                   )
                  )
                  (if (result i64)
                   (i64.gt_s
                    (local.get $0)
                    (i64.const 8)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global116)
                     )
                    )
                    (local.set $1
                     (call $function44
                      (call $foreign0
                       (global.get $global109)
                      )
                      (block (result i64)
                       (drop
                        (ref.as_non_null
                         (global.get $global116)
                        )
                       )
                       (local.set $scratch_11
                        (call $foreign0
                         (global.get $global110)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global119)
                        )
                       )
                       (local.get $scratch_11)
                      )
                     )
                    )
                    (if (result i64)
                     (i64.gt_s
                      (local.get $0)
                      (i64.const 9)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global116)
                       )
                      )
                      (local.set $1
                       (call $function44
                        (call $foreign0
                         (global.get $global109)
                        )
                        (block (result i64)
                         (drop
                          (ref.as_non_null
                           (global.get $global116)
                          )
                         )
                         (local.set $scratch_12
                          (call $foreign0
                           (global.get $global110)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global119)
                          )
                         )
                         (local.get $scratch_12)
                        )
                       )
                      )
                      (if (result i64)
                       (i64.gt_s
                        (local.get $0)
                        (i64.const 10)
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global116)
                         )
                        )
                        (local.set $1
                         (call $function44
                          (call $foreign0
                           (global.get $global109)
                          )
                          (block (result i64)
                           (drop
                            (ref.as_non_null
                             (global.get $global116)
                            )
                           )
                           (local.set $scratch_13
                            (call $foreign0
                             (global.get $global110)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global119)
                            )
                           )
                           (local.get $scratch_13)
                          )
                         )
                        )
                        (if (result i64)
                         (i64.gt_s
                          (local.get $0)
                          (i64.const 11)
                         )
                         (then
                          (drop
                           (ref.as_non_null
                            (global.get $global116)
                           )
                          )
                          (local.set $1
                           (call $function44
                            (call $foreign0
                             (global.get $global109)
                            )
                            (block (result i64)
                             (drop
                              (ref.as_non_null
                               (global.get $global116)
                              )
                             )
                             (local.set $scratch_14
                              (call $foreign0
                               (global.get $global110)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global119)
                              )
                             )
                             (local.get $scratch_14)
                            )
                           )
                          )
                          (if (result i64)
                           (i64.gt_s
                            (local.get $0)
                            (i64.const 12)
                           )
                           (then
                            (drop
                             (ref.as_non_null
                              (global.get $global116)
                             )
                            )
                            (local.set $1
                             (call $function44
                              (call $foreign0
                               (global.get $global109)
                              )
                              (block (result i64)
                               (drop
                                (ref.as_non_null
                                 (global.get $global116)
                                )
                               )
                               (local.set $scratch_15
                                (call $foreign0
                                 (global.get $global110)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global119)
                                )
                               )
                               (local.get $scratch_15)
                              )
                             )
                            )
                            (if (result i64)
                             (i64.gt_s
                              (local.get $0)
                              (i64.const 13)
                             )
                             (then
                              (drop
                               (ref.as_non_null
                                (global.get $global116)
                               )
                              )
                              (local.set $1
                               (call $function44
                                (call $foreign0
                                 (global.get $global109)
                                )
                                (block (result i64)
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global116)
                                  )
                                 )
                                 (local.set $scratch_16
                                  (call $foreign0
                                   (global.get $global110)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global119)
                                  )
                                 )
                                 (local.get $scratch_16)
                                )
                               )
                              )
                              (if (result i64)
                               (i64.gt_s
                                (local.get $0)
                                (i64.const 14)
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global116)
                                 )
                                )
                                (local.set $1
                                 (call $function44
                                  (call $foreign0
                                   (global.get $global109)
                                  )
                                  (block (result i64)
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global116)
                                    )
                                   )
                                   (local.set $scratch_17
                                    (call $foreign0
                                     (global.get $global110)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global119)
                                    )
                                   )
                                   (local.get $scratch_17)
                                  )
                                 )
                                )
                                (if (result i64)
                                 (i64.gt_s
                                  (local.get $0)
                                  (i64.const 15)
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global116)
                                   )
                                  )
                                  (local.set $1
                                   (call $function44
                                    (call $foreign0
                                     (global.get $global109)
                                    )
                                    (block (result i64)
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global116)
                                      )
                                     )
                                     (local.set $scratch_18
                                      (call $foreign0
                                       (global.get $global110)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global119)
                                      )
                                     )
                                     (local.get $scratch_18)
                                    )
                                   )
                                  )
                                  (if (result i64)
                                   (i64.gt_s
                                    (local.get $0)
                                    (i64.const 16)
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global116)
                                     )
                                    )
                                    (local.set $1
                                     (call $function44
                                      (call $foreign0
                                       (global.get $global109)
                                      )
                                      (block (result i64)
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global116)
                                        )
                                       )
                                       (local.set $scratch_19
                                        (call $foreign0
                                         (global.get $global110)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global119)
                                        )
                                       )
                                       (local.get $scratch_19)
                                      )
                                     )
                                    )
                                    (if (result i64)
                                     (i64.gt_s
                                      (local.get $0)
                                      (i64.const 17)
                                     )
                                     (then
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global116)
                                       )
                                      )
                                      (local.set $1
                                       (call $function44
                                        (call $foreign0
                                         (global.get $global109)
                                        )
                                        (block (result i64)
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global116)
                                          )
                                         )
                                         (local.set $scratch_20
                                          (call $foreign0
                                           (global.get $global110)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global119)
                                          )
                                         )
                                         (local.get $scratch_20)
                                        )
                                       )
                                      )
                                      (if (result i64)
                                       (i64.gt_s
                                        (local.get $0)
                                        (i64.const 18)
                                       )
                                       (then
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global116)
                                         )
                                        )
                                        (local.set $1
                                         (call $function44
                                          (call $foreign0
                                           (global.get $global109)
                                          )
                                          (block (result i64)
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global116)
                                            )
                                           )
                                           (local.set $scratch_21
                                            (call $foreign0
                                             (global.get $global110)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global119)
                                            )
                                           )
                                           (local.get $scratch_21)
                                          )
                                         )
                                        )
                                        (if (result i64)
                                         (i64.gt_s
                                          (local.get $0)
                                          (i64.const 19)
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global116)
                                           )
                                          )
                                          (local.set $1
                                           (call $function44
                                            (call $foreign0
                                             (global.get $global109)
                                            )
                                            (block (result i64)
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global116)
                                              )
                                             )
                                             (local.set $scratch_22
                                              (call $foreign0
                                               (global.get $global110)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global119)
                                              )
                                             )
                                             (local.get $scratch_22)
                                            )
                                           )
                                          )
                                          (if (result i64)
                                           (i64.gt_s
                                            (local.get $0)
                                            (i64.const 20)
                                           )
                                           (then
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global116)
                                             )
                                            )
                                            (local.set $1
                                             (call $function44
                                              (call $foreign0
                                               (global.get $global109)
                                              )
                                              (block (result i64)
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global116)
                                                )
                                               )
                                               (local.set $scratch_23
                                                (call $foreign0
                                                 (global.get $global110)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global119)
                                                )
                                               )
                                               (local.get $scratch_23)
                                              )
                                             )
                                            )
                                            (if (result i64)
                                             (i64.gt_s
                                              (local.get $0)
                                              (i64.const 21)
                                             )
                                             (then
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global116)
                                               )
                                              )
                                              (local.set $1
                                               (call $function44
                                                (call $foreign0
                                                 (global.get $global109)
                                                )
                                                (block (result i64)
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global116)
                                                  )
                                                 )
                                                 (local.set $scratch_24
                                                  (call $foreign0
                                                   (global.get $global110)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global119)
                                                  )
                                                 )
                                                 (local.get $scratch_24)
                                                )
                                               )
                                              )
                                              (if (result i64)
                                               (i64.gt_s
                                                (local.get $0)
                                                (i64.const 22)
                                               )
                                               (then
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global116)
                                                 )
                                                )
                                                (local.set $1
                                                 (call $function44
                                                  (call $foreign0
                                                   (global.get $global109)
                                                  )
                                                  (block (result i64)
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global116)
                                                    )
                                                   )
                                                   (local.set $scratch_25
                                                    (call $foreign0
                                                     (global.get $global110)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global119)
                                                    )
                                                   )
                                                   (local.get $scratch_25)
                                                  )
                                                 )
                                                )
                                                (if (result i64)
                                                 (i64.gt_s
                                                  (local.get $0)
                                                  (i64.const 23)
                                                 )
                                                 (then
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global116)
                                                   )
                                                  )
                                                  (local.set $1
                                                   (call $function44
                                                    (call $foreign0
                                                     (global.get $global109)
                                                    )
                                                    (block (result i64)
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global116)
                                                      )
                                                     )
                                                     (local.set $scratch_26
                                                      (call $foreign0
                                                       (global.get $global110)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global119)
                                                      )
                                                     )
                                                     (local.get $scratch_26)
                                                    )
                                                   )
                                                  )
                                                  (if (result i64)
                                                   (i64.gt_s
                                                    (local.get $0)
                                                    (i64.const 24)
                                                   )
                                                   (then
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global116)
                                                     )
                                                    )
                                                    (return_call $function42
                                                     (local.get $0)
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (i64.const 25)
                                                     (call $function44
                                                      (call $function43
                                                       (global.get $global109)
                                                      )
                                                      (block (result i64)
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global116)
                                                        )
                                                       )
                                                       (local.set $scratch_27
                                                        (call $function43
                                                         (global.get $global110)
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global119)
                                                        )
                                                       )
                                                       (local.get $scratch_27)
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (local.get $1)
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (else
                                                (local.get $1)
                                               )
                                              )
                                             )
                                             (else
                                              (local.get $1)
                                             )
                                            )
                                           )
                                           (else
                                            (local.get $1)
                                           )
                                          )
                                         )
                                         (else
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (else
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (else
                                      (local.get $1)
                                     )
                                    )
                                   )
                                   (else
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (else
                                  (local.get $1)
                                 )
                                )
                               )
                               (else
                                (local.get $1)
                               )
                              )
                             )
                             (else
                              (local.get $1)
                             )
                            )
                           )
                           (else
                            (local.get $1)
                           )
                          )
                         )
                         (else
                          (local.get $1)
                         )
                        )
                       )
                       (else
                        (local.get $1)
                       )
                      )
                     )
                     (else
                      (local.get $1)
                     )
                    )
                   )
                   (else
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
               (else
                (local.get $1)
               )
              )
             )
             (else
              (local.get $1)
             )
            )
           )
           (else
            (local.get $1)
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
       (else
        (local.get $1)
       )
      )
     )
     (else
      (local.get $1)
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function42 (type $2) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (local.set $4
     (call $function44
      (call $function43
       (global.get $global109)
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global116)
        )
       )
       (local.set $scratch
        (call $function43
         (global.get $global110)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global119)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $function43 (param $0 i64) (result i64)
  (call $foreign0
   (local.get $0)
  )
 )
 (func $function44 (type $call27) (param $0 i64) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.add
     (local.get $1)
     (i64.const 1)
    )
   )
   (else
    (if
     (i64.eqz
      (local.get $1)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready119)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (return_call $function44
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
       (i64.const 1)
      )
     )
     (else
      (if
       (i32.eqz
        (global.get $ready119)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (local.set $1
       (call $function44
        (local.get $0)
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready119)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (return_call $function44
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
       (local.get $1)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (return_call $function41
   (local.get $0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type27)
  )
  (global.set $global119
   (struct.new_default $type27)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global109
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global110
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global111
   (struct.new_default $type28)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

