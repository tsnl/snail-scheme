#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <errno.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

extern int64_t ack_inputs[2];
extern uint64_t ack_barriers;
extern int ack_validate;
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern void guest_main(void) __asm__("wasm.main");
extern int64_t bench(int64_t) __asm__("wasm.bench");

static int64_t integer(const char *text) {
    char *end;
    errno = 0;
    int64_t value = strtoll(text, &end, 10);
    assert(!errno && end != text && !*end);
    return value;
}

static double seconds_between(struct timespec start, struct timespec end) {
    return (double)(end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
}

int main(int argc, char **argv) {
    assert(argc == 6 && (!strcmp(argv[5], "--validate") || !strcmp(argv[5], "--time")));
    int64_t count = integer(argv[1]), expected = integer(argv[4]);
    assert(count >= 0);
    ack_inputs[0] = integer(argv[2]); ack_inputs[1] = integer(argv[3]);
    ack_validate = !strcmp(argv[5], "--validate");
    native_host_init(argc, argv); native_module_init(); guest_main();
    struct timespec start, end;
    if (!ack_validate) assert(!clock_gettime(CLOCK_MONOTONIC, &start));
    int64_t result = bench(count);
    assert(result == expected);
    if (!ack_validate) assert(!clock_gettime(CLOCK_MONOTONIC, &end));
    if (ack_validate) assert(ack_barriers == 2 * (uint64_t)count);
    printf("{\"result\":\"%" PRId64 "\",\"barriers\":%" PRIu64 ",\"seconds\":", result, ack_barriers);
    if (ack_validate) printf("null}\n");
    else printf("%.9f}\n", seconds_between(start, end));
    return native_finish(0);
}
