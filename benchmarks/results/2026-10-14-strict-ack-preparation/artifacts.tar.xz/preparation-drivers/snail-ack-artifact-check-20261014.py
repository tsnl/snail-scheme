"""Compare archived/current Ackermann artifacts under the same default V8 host."""

import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile

ROOT = Path('/tmp/snail-general-specialization-20261012')
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import matrix_port

report = ROOT / 'benchmarks/results/2026-10-13-strict-kernels'
current = ROOT / 'build/strict-ack-current-20261014'
output = current / 'archive-comparison'
output.mkdir(exist_ok=False)
manifest = json.loads((report / 'manifest.json').read_text())
archive = report / 'artifacts.tar.xz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['archive_sha256']
identities = {}
with tarfile.open(archive) as bundle:
    for name in ('strict.wasm', 'strict.wasm.raw.wasm', 'strict.optimized.wat', 'strict.scm', 'spec.json'):
        member = 'strict-suite/ack/' + name
        entry = bundle.getmember(member)
        assert entry.isfile()
        contents = bundle.extractfile(entry).read()
        sha = hashlib.sha256(contents).hexdigest()
        assert sha == manifest['files'][member]
        (output / ('old-' + name)).write_bytes(contents)
        identities[member] = sha
assert (output / 'old-strict.scm').read_bytes() == (current / 'ack/strict.scm').read_bytes()
assert (output / 'old-spec.json').read_bytes() == (current / 'ack/spec.json').read_bytes()
node = '/nix/store/lfaydgacdyngci7p60s8wwvgdm74fjkx-nodejs-24.19.0/bin/node'
guard = ('NODE_OPTIONS', 'NODE_V8_COVERAGE', 'NODE_DEBUG', 'NODE_DEBUG_NATIVE', 'LD_PRELOAD')
assert all(name not in os.environ for name in guard)
result = dict(source_and_spec_identical=True, archive_identities=identities,
              node_sha256=hashlib.sha256(Path(node).read_bytes()).hexdigest(),
              environment={name: os.environ.get(name) for name in guard}, checks=[])
for label, wasm in [('archived-raw', output / 'old-strict.wasm.raw.wasm'),
                    ('archived-optimized', output / 'old-strict.wasm'),
                    ('current-optimized', current / 'ack/strict.wasm')]:
    command = [node, current / 'host.mjs', wasm, current / 'ack/spec.json', '--validate']
    record = matrix_port.execute(command, current, dict(os.environ), timeout=120)
    result['checks'].append(dict(label=label, wasm_sha256=hashlib.sha256(wasm.read_bytes()).hexdigest(), **record))
    (output / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(label, record.get('returncode'), record.get('stdout', '').strip(), record.get('stderr', '')[:120], flush=True)
