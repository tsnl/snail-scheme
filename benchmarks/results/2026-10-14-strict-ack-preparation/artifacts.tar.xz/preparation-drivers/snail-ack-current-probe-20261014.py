"""Recheck the full Ackermann case, using the suite's owned-process executor."""

import sys

sys.path.insert(0, '/tmp/snail-general-specialization-20261012/benchmarks/strict-suite')
import matrix_port
import measure


def execute(command, cwd, environment, timeout=300, stdin=None):
    return matrix_port.execute(command, cwd, environment, timeout, stdin)


measure.execute = execute
measure.main()
