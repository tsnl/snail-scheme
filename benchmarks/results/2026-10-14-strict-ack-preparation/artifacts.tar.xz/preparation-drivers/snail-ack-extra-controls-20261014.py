import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/tmp/snail-general-specialization-20261012')
BASE = ROOT / 'build/strict-ack-current-20261014'
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import matrix_port

NODE = '/nix/store/lfaydgacdyngci7p60s8wwvgdm74fjkx-nodejs-24.19.0/bin/node'
CHEZ = '/nix/store/bzqpmy5kmvf0xn4xh5ixzkw00w9srh07-chez-scheme-10.4.1/bin/scheme'
BINARYEN = Path('/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin')
RECORDS = []


def run(label, command, cwd=BASE, stdin=None, required=True, environment=None):
    record = matrix_port.execute(command, cwd, environment or dict(os.environ), timeout=300, stdin=stdin)
    record.update(label=label, cwd=str(cwd), stdin=stdin, diagnostic=True)
    RECORDS.append(record)
    (BASE / 'extra-controls.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    assert not record.get('timeout') and not record.get('executing_descendants'), record
    if required:
        assert record.get('returncode') == 0, record
    print(label, record.get('returncode'), flush=True)
    return record


assert not (BASE / 'extra-controls.json').exists()
for variable in ('NODE_OPTIONS', 'NODE_V8_COVERAGE', 'LD_PRELOAD'):
    assert variable not in os.environ, variable
native_builds = list(BASE.glob('ack-native.native-*'))
assert len(native_builds) == 1
shutil.copy2(native_builds[0] / 'optimized.wasm', BASE / 'ack/native-final.wasm')
run('native-final-v8-full', [NODE, BASE / 'host.mjs', BASE / 'ack/native-final.wasm', BASE / 'ack/spec.json', '--validate'])
run('original-chez-full', [CHEZ, '--program', BASE / 'ack/program.so'], stdin=(BASE / 'ack/input.txt').read_text())

target = BASE / 'rust-reference'
original = ROOT / 'benchmarks/wasm-reference'
shutil.copytree(original / 'src', target / 'src')
for name in ('Cargo.toml', 'Cargo.lock', 'run-wasi.mjs'):
    shutil.copy2(original / name, target / name)
environment = dict(os.environ, CARGO_TARGET_DIR=str(target / 'target'), BINARYEN_CORES='1')
for label, args in [('native-build', ['rustc', '--offline', '--release', '--bin', 'ack', '--', '--emit=asm,llvm-ir']),
                    ('wasm-build', ['rustc', '--offline', '--release', '--target', 'wasm32-wasip1', '--bin', 'ack', '--', '--emit=llvm-ir'])]:
    run('rust-' + label, ['cargo', *args], cwd=target, environment=environment)
shutil.copy2(target / 'target/release/ack', target / 'ack.native')
shutil.copy2(target / 'target/wasm32-wasip1/release/ack.wasm', target / 'ack.raw.wasm')
run('rust-binaryen', [BINARYEN / 'wasm-opt', '-O3', '-g', *matrix_port.RUST_WASM_FEATURES,
                       target / 'ack.raw.wasm', '-o', target / 'ack.wasm'], environment=environment)
run('rust-disassembly', [BINARYEN / 'wasm-dis', target / 'ack.wasm', '-o', target / 'ack.wat'], environment=environment)
systems = [('rust-native', [target / 'ack.native']),
           ('rust-raw-wasm', [NODE, '--disable-warning=ExperimentalWarning', target / 'run-wasi.mjs', target / 'ack.raw.wasm']),
           ('rust-optimized-wasm', [NODE, '--disable-warning=ExperimentalWarning', target / 'run-wasi.mjs', target / 'ack.wasm'])]
for label, command in systems:
    for count, m, n, expected in [(1, 3, 4, 125), (2, 3, 12, 32765)]:
        record = run(label + ('-full' if count == 2 else '-small'), command, cwd=target,
                     stdin=f'{count}\n{m}\n{n}\n{expected}\n', required=count != 2)
        if record['returncode'] == 0:
            assert record['stdout'].splitlines()[0] == f'Result: {expected}', record
        elif count == 2:
            assert 'call stack size' in record['stderr'] or 'call stack exhausted' in record['stderr'], record
paths = [BASE / 'ack/strict.scm', BASE / 'ack/strict.wasm', BASE / 'ack/native-final.wasm',
         BASE / 'ack-native', target / 'ack.native', target / 'ack.raw.wasm', target / 'ack.wasm']
(BASE / 'extra-control-identities.json').write_text(json.dumps(
    {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}, indent=2) + '\n')
