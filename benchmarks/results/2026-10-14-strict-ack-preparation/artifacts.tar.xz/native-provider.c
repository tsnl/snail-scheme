#include "native-provider.h"
#include <assert.h>

int64_t ack_inputs[2];
uint64_t ack_barriers;
int ack_validate;

int64_t input_i64(int32_t index) {
    assert(index >= 0 && index < 2);
    return ack_inputs[index];
}

int64_t hide_i64(int64_t value) {
    if (ack_validate) ack_barriers++;
    return value;
}
