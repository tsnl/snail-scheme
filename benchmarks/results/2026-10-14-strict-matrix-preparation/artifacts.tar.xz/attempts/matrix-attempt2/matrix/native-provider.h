#include <stdint.h>
int64_t input_i64(int32_t);
int64_t expected_i64(int64_t);
int64_t hide_i64(int64_t);
void write_character(uint32_t);
void emit_i64(int64_t);
