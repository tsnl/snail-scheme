import fs from 'node:fs';
const [artifact, mode, columns, size] = process.argv.slice(2);
const imports = {benchmark: {
  emit_i64: value => process.stdout.write(value.toString() + '\n'),
  write_character: value => fs.writeSync(1, String.fromCodePoint(value)),
}};
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), imports);
instance.exports.main();
if (instance.exports.probe(BigInt(mode), BigInt(columns), BigInt(size)) !== 1n)
  throw new Error('probe did not finish');
