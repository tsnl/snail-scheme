(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-matrix-20261014/build/matrix-attempt2/matrix/program.scm" "/tmp/snail-strict-matrix-20261014/build/matrix-attempt2/matrix/program.so"))
