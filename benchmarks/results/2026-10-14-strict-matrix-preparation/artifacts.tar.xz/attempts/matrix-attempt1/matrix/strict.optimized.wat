(module
 (rec
  (type $type44 (sub (struct)))
  (type $type97 (sub (struct)))
  (type $type39 (sub (struct (field i32))))
  (type $type35 (sub (struct)))
  (type $type49 (sub (struct)))
  (type $environment86 (struct (field i32)))
  (type $6 (func (param i64 i32 i32 i64 (ref null $type54)) (result i64)))
  (type $7 (func (param i64) (result (ref null $type30))))
  (type $call112 (func (param i64) (result (ref null $type32))))
  (type $call113 (func (param i64) (result (ref null $type54))))
  (type $10 (func (param i64 (ref $type16) i32 i32 i64) (result (ref $type16))))
  (type $call5 (func (result i64)))
  (type $12 (func (param i64 (ref $type103) (ref $type93) i32 i32 i32 i64 (ref null $type32) i32 i32 (ref null $type32) (ref $type104)) (result (ref $type104))))
  (type $environment171 (struct (field (ref $type94))))
  (type $14 (func (param i64 (ref $type103) (ref $type93) i32 i32 i32 i64 (ref $type32) (ref null $type32) (ref $type104)) (result (ref $type104))))
  (type $environment166 (struct (field (ref $type84))))
  (type $environment167 (struct (field (ref $type84))))
  (type $17 (func (param i64 (ref $type84) (ref null $type32)) (result (ref null $type32))))
  (type $18 (func (param (ref null $type30) i32 i32 (ref null $type110)) (result i32)))
  (type $environment163 (struct (field (ref null $type110))))
  (type $environment162 (struct (field (ref $type109)) (field (ref null $type30))))
  (type $type109 (struct (field (ref $call109)) (field (ref struct))))
  (type $22 (func (param i32 i32 i64 (ref null $type32) (ref $type109) i64 (ref null $type110)) (result (ref null $type110))))
  (type $type110 (struct (field (ref $type94)) (field (ref null $type110))))
  (type $type94 (struct (field (ref $call94)) (field (ref struct))))
  (type $environment159 (struct (field (ref $type93)) (field (ref null $type30))))
  (type $call109 (func (param (ref struct) (ref null $type32) (ref null $type110)) (result (ref null $type110))))
  (type $environment110 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type55))))
  (type $type93 (struct (field (ref $environment110))))
  (type $call105 (func (param i64 i64) (result (ref null $type54))))
  (type $30 (func (param i32 i32 (ref null $type32) i64) (result i64)))
  (type $call31 (func (param (ref null $type32)) (result i64)))
  (type $type104 (struct (field i64) (field i64) (field (ref null $type54))))
  (type $call103 (func (param (ref null $type32) (ref $type104)) (result (ref $type104))))
  (type $34 (func (param i64 i32 i32 i64) (result i64)))
  (type $35 (func (param i64 (ref $type44) (ref $type47) i32 i32 i32 i64) (result i64)))
  (type $36 (func (param i64 i32 i32 (ref $type44)) (result i32)))
  (type $type47 (struct (field (mut (ref $type44)))))
  (type $type46 (sub $type44 (struct (field i64) (field (ref $type47)))))
  (type $environment141 (struct (field i64) (field (ref $type12))))
  (type $type99 (sub $type97 (struct)))
  (type $environment139 (struct (field i64)))
  (type $type96 (struct))
  (type $environment138 (struct (field i64)))
  (type $environment137 (struct (field i64)))
  (type $environment136 (struct (field i64)))
  (type $environment135 (struct (field i64) (field i32)))
  (type $type98 (sub $type97 (struct (field i64))))
  (type $48 (func (param (ref $type96) i32 i32 i64 i64 i64 i64 i64 i64) (result (ref $type97))))
  (type $environment114 (struct (field (ref $type60)) (field (ref $type60)) (field i64)))
  (type $50 (func (param (ref $type61) (ref $type60) (ref $type33) (ref $type60) i32 i32 (ref null $type30) (ref null $type32)) (result i32)))
  (type $environment111 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref null $type32))))
  (type $call94 (func (param (ref struct) (ref null $type30)) (result i32)))
  (type $call59 (func (param (ref $type60) (ref null $type30) (ref null $type30)) (result (ref null $type30))))
  (type $environment107 (struct (field (ref $type60)) (field (ref $type60)) (field i64)))
  (type $call58 (func (param (ref $type33) (ref null $type30)) (result (ref null $type30))))
  (type $call56 (func (param (ref $type57) (ref null $type32)) (result (ref null $type32))))
  (type $environment105 (struct (field i64)))
  (type $environment106 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref null $type30))))
  (type $environment103 (struct (field (ref $type60)) (field i64)))
  (type $call57 (func (param structref (ref null $type30)) (result (ref null $type30))))
  (type $environment101 (struct (field i64)))
  (type $type57 (struct (field (ref $call57)) (field structref)))
  (type $63 (func (param i64 i64 (ref $type61) (ref $type60) (ref $type33) (ref $type60) (ref $type33) i32 i32 i32 i32 (ref null $type32) (ref null $type32)) (result (ref null $type32))))
  (type $environment98 (struct (field i64) (field i64) (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type33))))
  (type $65 (func (param i64 (ref $type33) (ref $type12) i32 i32 i64) (result i32)))
  (type $66 (func (param i64 (ref $type33)) (result (ref $type12))))
  (type $67 (func (param i32 i32 (ref null $type32) (ref $type32)) (result (ref null $type32))))
  (type $call55 (func (param (ref null $environment98) (ref null $type32)) (result (ref null $type32))))
  (type $69 (func (param (ref $type33) (ref $type77) i32 i32 (ref null $type32) (ref null $type32) (ref null $type30) (ref null $type30) i32 i32 i32 (ref null $type30) (ref null $type30)) (result i32)))
  (type $70 (func (param (ref $type33) (ref $type77) i32 i32 (ref null $type32) (ref null $type32) i32 i32 i32 (ref null $type30) (ref null $type30) (ref null $type30) (ref null $type30)) (result i32)))
  (type $environment93 (struct (field (ref $type80)) (field (ref $type80)) (field (ref $type114)) (field (ref $type35)) (field (ref null $type32))))
  (type $environment85 (struct (field (ref $type80)) (field (ref $type80)) (field (ref $type114)) (field (ref $type35)) (field (ref null $type32))))
  (type $73 (func (param (ref $type80) (ref $type80) (ref $type114) (ref $type35) (ref null $type32) (ref null $type32)) (result i32)))
  (type $74 (func (param i64 i32 i32 i64) (result (ref null $type30))))
  (type $75 (func (param i64 i64 i64 (ref $type12) i32 i32 i64 (ref null $type30) (ref null $type30)) (result i32)))
  (type $76 (func (param i64 (ref $type12) i32 i32 i64) (result (ref $type12))))
  (type $environment79 (struct (field (ref $type12))))
  (type $type12 (array (mut i64)))
  (type $call80 (func (param (ref $environment75) (ref null $type30)) (result (ref $type33))))
  (type $80 (func (param i32 i32 (ref null $type30) i64) (result i64)))
  (type $type80 (struct (field (ref $environment75))))
  (type $environment75 (struct (field (ref null $type30)) (field i64) (field i64) (field i64)))
  (type $83 (func (param (ref null $type32) i32 i32 (ref $type35)) (result i32)))
  (type $84 (func (param (ref $type84) i32 i32 (ref null $type32) (ref null $type32)) (result (ref null $type32))))
  (type $call84 (func (param structref (ref null $type30) (ref null $type32)) (result (ref null $type32))))
  (type $86 (func (param (ref null $type32) (ref $type84)) (result (ref null $type32))))
  (type $type42 (sub $type39 (struct (field i32))))
  (type $type84 (struct (field (ref $call84)) (field structref)))
  (type $type41 (sub $type39 (struct (field i32) (field (ref $type35)))))
  (type $type40 (sub $type39 (struct (field i32) (field (ref null $type30)))))
  (type $call38 (func (param (ref $environment64) i64) (result (ref $type39))))
  (type $type37 (sub $type35 (struct (field (ref $type38)))))
  (type $type38 (struct (field (ref $environment64))))
  (type $environment64 (struct (field (ref $type114)) (field (ref null $type32)) (field (ref null $type32))))
  (type $type114 (struct (field i32)))
  (type $call77 (func (param structref (ref null $type32)) (result i32)))
  (type $call73 (func (param i64)))
  (type $98 (func (param i64)))
  (type $99 (func (param (ref $type16) i32 i32 i64) (result i32)))
  (type $100 (func (result i32)))
  (type $type51 (sub $type49 (struct (field (ref $type16)))))
  (type $type50 (sub $type49 (struct (field (ref null $type32)))))
  (type $call70 (func (param (ref null $type54) (ref null $type54)) (result i32)))
  (type $type32 (struct (field (ref null $type30)) (field (ref null $type32))))
  (type $call68 (func (param (ref null $type32) (ref null $type32)) (result i32)))
  (type $type30 (struct (field i64) (field (ref null $type30))))
  (type $call67 (func (param (ref null $type30) (ref null $type30)) (result i32)))
  (type $108 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $call60 (func (param structref i64 i64) (result i64)))
  (type $call61 (func (param (ref null $environment135) i64) (result i32)))
  (type $call33 (func (param structref i64) (result i64)))
  (type $112 (func (param (ref $type16) (ref $type16) i32 i32 i64) (result i32)))
  (type $type18 (array (mut (ref null $type17))))
  (type $114 (func (param (ref $type16) i32) (result (ref $type17))))
  (type $type54 (struct (field (ref $type49)) (field (ref null $type54))))
  (type $type108 (struct))
  (type $type106 (struct))
  (type $type103 (struct))
  (type $type102 (struct))
  (type $type101 (struct))
  (type $type92 (struct))
  (type $type89 (struct))
  (type $type95 (struct))
  (type $type90 (struct))
  (type $type86 (struct))
  (type $type79 (struct))
  (type $type78 (struct))
  (type $type77 (struct (field (ref $call77)) (field structref)))
  (type $type76 (struct))
  (type $type75 (struct))
  (type $type73 (struct))
  (type $type71 (struct))
  (type $type69 (struct))
  (type $type66 (struct))
  (type $type65 (struct))
  (type $type53 (struct))
  (type $type43 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type15 (struct))
  (type $type113 (struct))
  (type $type105 (struct))
  (type $type81 (struct (field (ref $environment86))))
  (type $type74 (struct))
  (type $type70 (struct))
  (type $type68 (struct))
  (type $type52 (struct))
  (type $type31 (struct))
  (type $type11 (struct))
  (type $type107 (struct))
  (type $type82 (struct))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type48 (struct))
  (type $type34 (struct))
  (type $type55 (struct (field (ref $call55)) (field (ref null $environment98))))
  (type $type33 (struct (field (ref $call33)) (field structref)))
  (type $type83 (struct))
  (type $type60 (struct (field (ref $call60)) (field structref)))
  (type $type61 (struct (field (ref $call61)) (field (ref null $environment135))))
  (type $type112 (struct))
  (type $type85 (struct))
  (type $type72 (struct))
  (type $type67 (struct))
  (type $type58 (struct))
  (type $type5 (struct))
  (type $type59 (struct))
  (type $type56 (struct))
  (type $type111 (struct (field (mut i64))))
  (type $type16 (struct (field i32) (field i32) (field (ref $type17)) (field (ref null $type18))))
  (type $type17 (array (mut i32)))
  (type $type45 (sub $type44 (struct)))
  (type $type36 (sub $type35 (struct)))
 )
 (type $175 (func (param i64) (result i64)))
 (type $176 (func (param i32)))
 (type $177 (func (param i32) (result i64)))
 (type $178 (func))
 (import "benchmark" "write_character" (func $foreign0 (param i32)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign2 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign3 (param i32) (result i64)))
 (global $global536 (mut (ref null $type111)) (ref.null none))
 (global $ready536 (mut i32) (i32.const 0))
 (global $global305 (mut (ref null $type56)) (ref.null none))
 (global $ready305 (mut i32) (i32.const 0))
 (global $global328 (mut (ref null $type59)) (ref.null none))
 (global $ready328 (mut i32) (i32.const 0))
 (global $global537 (mut (ref null $type5)) (ref.null none))
 (global $ready537 (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global316 (mut (ref null $type58)) (ref.null none))
 (global $ready316 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type67)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type72)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global554 (mut (ref null $type85)) (ref.null none))
 (global $ready554 (mut i32) (i32.const 0))
 (global $global551 (mut (ref null $type112)) (ref.null none))
 (global $ready551 (mut i32) (i32.const 0))
 (global $global368 (mut (ref null $type61)) (ref.null none))
 (global $ready368 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type60)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global184 (mut (ref null $type83)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type33)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global269 (mut (ref null $type55)) (ref.null none))
 (global $ready269 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type61)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global559 (mut (ref null $type60)) (ref.null none))
 (global $ready559 (mut i32) (i32.const 0))
 (global $execution (mut i32) (i32.const 0))
 (global $empty36 (ref $type36) (struct.new_default $type36))
 (global $global194 (mut (ref null $type34)) (ref.null none))
 (global $ready194 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type48)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global202 (mut (ref null $type62)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global211 (mut (ref null $type63)) (ref.null none))
 (global $ready211 (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type64)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type82)) (ref.null none))
 (global $ready175 (mut i32) (i32.const 0))
 (global $global509 (mut (ref null $type107)) (ref.null none))
 (global $ready509 (mut i32) (i32.const 0))
 (global $empty45 (ref $type45) (struct.new_default $type45))
 (global $global218 (mut (ref null $type11)) (ref.null none))
 (global $ready218 (mut i32) (i32.const 0))
 (global $global462 (mut (ref null $type31)) (ref.null none))
 (global $ready462 (mut i32) (i32.const 0))
 (global $global239 (mut (ref null $type52)) (ref.null none))
 (global $ready239 (mut i32) (i32.const 0))
 (global $global280 (mut (ref null $type63)) (ref.null none))
 (global $ready280 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type68)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type70)) (ref.null none))
 (global $ready148 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type60)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global435 (mut (ref null $type74)) (ref.null none))
 (global $ready435 (mut i32) (i32.const 0))
 (global $global247 (mut (ref null $type81)) (ref.null none))
 (global $ready247 (mut i32) (i32.const 0))
 (global $global472 (mut (ref null $type105)) (ref.null none))
 (global $ready472 (mut i32) (i32.const 0))
 (global $global548 (mut (ref null $type113)) (ref.null none))
 (global $ready548 (mut i32) (i32.const 0))
 (global $global544 (mut i64) (i64.const 0))
 (global $ready544 (mut i32) (i32.const 0))
 (global $global545 (mut i64) (i64.const 0))
 (global $ready545 (mut i32) (i32.const 0))
 (global $global546 (mut i32) (i32.const 0))
 (global $ready546 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type15)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type28)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global205 (mut (ref null $type29)) (ref.null none))
 (global $ready205 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type43)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global351 (mut (ref null $type31)) (ref.null none))
 (global $ready351 (mut i32) (i32.const 0))
 (global $global470 (mut (ref null $type53)) (ref.null none))
 (global $ready470 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type61)) (ref.null none))
 (global $ready123 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type60)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type65)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type66)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type69)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global151 (mut (ref null $type71)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (global $global157 (mut (ref null $type73)) (ref.null none))
 (global $ready157 (mut i32) (i32.const 0))
 (global $global447 (mut (ref null $type75)) (ref.null none))
 (global $ready447 (mut i32) (i32.const 0))
 (global $global449 (mut (ref null $type76)) (ref.null none))
 (global $ready449 (mut i32) (i32.const 0))
 (global $global173 (mut (ref null $type77)) (ref.null none))
 (global $ready173 (mut i32) (i32.const 0))
 (global $global198 (mut (ref null $type78)) (ref.null none))
 (global $ready198 (mut i32) (i32.const 0))
 (global $global229 (mut (ref null $type79)) (ref.null none))
 (global $ready229 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type85)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global283 (mut (ref null $type86)) (ref.null none))
 (global $ready283 (mut i32) (i32.const 0))
 (global $global408 (mut (ref null $type90)) (ref.null none))
 (global $ready408 (mut i32) (i32.const 0))
 (global $global384 (mut (ref null $type95)) (ref.null none))
 (global $ready384 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type89)) (ref.null none))
 (global $ready289 (mut i32) (i32.const 0))
 (global $global333 (mut (ref null $type92)) (ref.null none))
 (global $ready333 (mut i32) (i32.const 0))
 (global $global406 (mut (ref null $type101)) (ref.null none))
 (global $ready406 (mut i32) (i32.const 0))
 (global $global431 (mut (ref null $type33)) (ref.null none))
 (global $ready431 (mut i32) (i32.const 0))
 (global $global452 (mut (ref null $type33)) (ref.null none))
 (global $ready452 (mut i32) (i32.const 0))
 (global $global475 (mut (ref null $type102)) (ref.null none))
 (global $ready475 (mut i32) (i32.const 0))
 (global $global457 (mut (ref null $type103)) (ref.null none))
 (global $ready457 (mut i32) (i32.const 0))
 (global $global525 (mut (ref null $type106)) (ref.null none))
 (global $ready525 (mut i32) (i32.const 0))
 (global $global488 (mut (ref null $type108)) (ref.null none))
 (global $ready488 (mut i32) (i32.const 0))
 (global $global539 (mut (ref null $type15)) (ref.null none))
 (global $ready539 (mut i32) (i32.const 0))
 (global $global547 (mut (ref null $type54)) (ref.null none))
 (global $ready547 (mut i32) (i32.const 0))
 (global $global557 (mut (ref null $type33)) (ref.null none))
 (global $ready557 (mut i32) (i32.const 0))
 (global $string0 (ref $type16) (struct.new $type16
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type17 37
   (i32.const 103)
   (i32.const 101)
   (i32.const 110)
   (i32.const 45)
   (i32.const 112)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 115)
   (i32.const 58)
   (i32.const 32)
   (i32.const 66)
   (i32.const 97)
   (i32.const 100)
   (i32.const 32)
   (i32.const 109)
   (i32.const 115)
   (i32.const 103)
   (i32.const 58)
   (i32.const 32)
   (i32.const 126)
   (i32.const 97)
   (i32.const 59)
   (i32.const 32)
   (i32.const 109)
   (i32.const 101)
   (i32.const 115)
   (i32.const 115)
   (i32.const 97)
   (i32.const 103)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type16) (struct.new $type16
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type17 3
   (i32.const 46)
   (i32.const 46)
   (i32.const 46)
  )
  (ref.null none)
 ))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-block (type $114) (param $0 (ref $type16)) (param $1 i32) (result (ref $type17))
  (if (result (ref $type17))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type16 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type18
      (struct.get $type16 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function40 (type $112) (param $0 (ref $type16)) (param $1 (ref $type16)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type16 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type17
       (if (result (ref $type17))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type16 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type18
           (struct.get $type16 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type16 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type17
        (if (result (ref $type17))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type16 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type18
            (struct.get $type16 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (i64.sub
   (i64.const 0)
   (local.get $1)
  )
 )
 (func $function44 (type $call61) (param $0 (ref null $environment135)) (param $1 i64) (result i32)
  (i32.const 1)
 )
 (func $function45 (type $call61) (param $0 (ref null $environment135)) (param $1 i64) (result i32)
  (i64.eqz
   (i64.and
    (local.get $1)
    (i64.const 1)
   )
  )
 )
 (func $function46 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.get $2)
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $3
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (local.set $2
         (i64.mul
          (local.get $1)
          (local.get $1)
         )
        )
        (if (result i64)
         (i64.eqz
          (local.tee $3
           (i64.sub
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $2)
         )
         (else
          (local.set $2
           (i64.mul
            (local.get $1)
            (local.get $2)
           )
          )
          (if (result i64)
           (i64.eqz
            (local.tee $3
             (i64.sub
              (local.get $3)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $2)
           )
           (else
            (local.set $2
             (i64.mul
              (local.get $1)
              (local.get $2)
             )
            )
            (if (result i64)
             (i64.eqz
              (local.tee $3
               (i64.sub
                (local.get $3)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $2)
             )
             (else
              (local.set $2
               (i64.mul
                (local.get $1)
                (local.get $2)
               )
              )
              (if (result i64)
               (i64.eqz
                (local.tee $3
                 (i64.sub
                  (local.get $3)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $2)
               )
               (else
                (local.set $2
                 (i64.mul
                  (local.get $1)
                  (local.get $2)
                 )
                )
                (if (result i64)
                 (i64.eqz
                  (local.tee $3
                   (i64.sub
                    (local.get $3)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (local.set $2
                   (i64.mul
                    (local.get $1)
                    (local.get $2)
                   )
                  )
                  (if (result i64)
                   (i64.eqz
                    (local.tee $3
                     (i64.sub
                      (local.get $3)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (local.set $2
                     (i64.mul
                      (local.get $1)
                      (local.get $2)
                     )
                    )
                    (if (result i64)
                     (i64.eqz
                      (local.tee $3
                       (i64.sub
                        (local.get $3)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (local.set $2
                       (i64.mul
                        (local.get $1)
                        (local.get $2)
                       )
                      )
                      (if (result i64)
                       (i64.eqz
                        (local.tee $3
                         (i64.sub
                          (local.get $3)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $2)
                       )
                       (else
                        (return_call $function47
                         (local.get $1)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.sub
                          (local.get $3)
                          (i64.const 1)
                         )
                         (i64.mul
                          (local.get $1)
                          (local.get $2)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function47 (type $108) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function47
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (i64.mul
      (local.get $0)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function51 (type $call67) (param $0 (ref null $type30)) (param $1 (ref null $type30)) (result i32)
  (local $scratch (ref null $type30))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type30 0
         (local.get $0)
        )
        (struct.get $type30 0
         (local.get $1)
        )
       )
       (then
        (return_call $function51
         (struct.get $type30 1
          (local.get $0)
         )
         (block (result (ref null $type30))
          (local.set $scratch
           (struct.get $type30 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready139)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function52 (type $call68) (param $0 (ref null $type32)) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref null $type30))
  (local $3 (ref null $type30))
  (local $scratch (ref null $type30))
  (local $scratch_5 (ref null $type32))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $3
       (struct.get $type32 0
        (local.get $0)
       )
      )
      (local.set $2
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready139)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global139)
       )
      )
      (if (result i32)
       (if (result i32)
        (ref.is_null
         (local.get $3)
        )
        (then
         (ref.is_null
          (local.get $2)
         )
        )
        (else
         (if (result i32)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i64.eq
             (struct.get $type30 0
              (local.get $3)
             )
             (struct.get $type30 0
              (local.get $2)
             )
            )
            (then
             (local.set $3
              (struct.get $type30 1
               (local.get $3)
              )
             )
             (local.set $2
              (struct.get $type30 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready139)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global139)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $3)
              )
              (then
               (ref.is_null
                (local.get $2)
               )
              )
              (else
               (if (result i32)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i64.eq
                   (struct.get $type30 0
                    (local.get $3)
                   )
                   (struct.get $type30 0
                    (local.get $2)
                   )
                  )
                  (then
                   (local.set $3
                    (struct.get $type30 1
                     (local.get $3)
                    )
                   )
                   (local.set $2
                    (struct.get $type30 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready139)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global139)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (ref.is_null
                      (local.get $2)
                     )
                    )
                    (else
                     (if (result i32)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i64.eq
                         (struct.get $type30 0
                          (local.get $3)
                         )
                         (struct.get $type30 0
                          (local.get $2)
                         )
                        )
                        (then
                         (local.set $3
                          (struct.get $type30 1
                           (local.get $3)
                          )
                         )
                         (local.set $2
                          (struct.get $type30 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready139)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global139)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (ref.is_null
                            (local.get $2)
                           )
                          )
                          (else
                           (if (result i32)
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if (result i32)
                              (i64.eq
                               (struct.get $type30 0
                                (local.get $3)
                               )
                               (struct.get $type30 0
                                (local.get $2)
                               )
                              )
                              (then
                               (local.set $3
                                (struct.get $type30 1
                                 (local.get $3)
                                )
                               )
                               (local.set $2
                                (struct.get $type30 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready139)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global139)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                )
                                (else
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (if (result i32)
                                    (i64.eq
                                     (struct.get $type30 0
                                      (local.get $3)
                                     )
                                     (struct.get $type30 0
                                      (local.get $2)
                                     )
                                    )
                                    (then
                                     (local.set $3
                                      (struct.get $type30 1
                                       (local.get $3)
                                      )
                                     )
                                     (local.set $2
                                      (struct.get $type30 1
                                       (local.get $2)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready139)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global139)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                      )
                                      (else
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $2)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (if (result i32)
                                          (i64.eq
                                           (struct.get $type30 0
                                            (local.get $3)
                                           )
                                           (struct.get $type30 0
                                            (local.get $2)
                                           )
                                          )
                                          (then
                                           (local.set $3
                                            (struct.get $type30 1
                                             (local.get $3)
                                            )
                                           )
                                           (local.set $2
                                            (struct.get $type30 1
                                             (local.get $2)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready139)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global139)
                                            )
                                           )
                                           (if (result i32)
                                            (ref.is_null
                                             (local.get $3)
                                            )
                                            (then
                                             (ref.is_null
                                              (local.get $2)
                                             )
                                            )
                                            (else
                                             (if (result i32)
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (i32.const 0)
                                              )
                                              (else
                                               (if (result i32)
                                                (i64.eq
                                                 (struct.get $type30 0
                                                  (local.get $3)
                                                 )
                                                 (struct.get $type30 0
                                                  (local.get $2)
                                                 )
                                                )
                                                (then
                                                 (local.set $3
                                                  (struct.get $type30 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (local.set $2
                                                  (struct.get $type30 1
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready139)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global139)
                                                  )
                                                 )
                                                 (if (result i32)
                                                  (ref.is_null
                                                   (local.get $3)
                                                  )
                                                  (then
                                                   (ref.is_null
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (else
                                                   (if (result i32)
                                                    (ref.is_null
                                                     (local.get $2)
                                                    )
                                                    (then
                                                     (i32.const 0)
                                                    )
                                                    (else
                                                     (if (result i32)
                                                      (i64.eq
                                                       (struct.get $type30 0
                                                        (local.get $3)
                                                       )
                                                       (struct.get $type30 0
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (then
                                                       (local.set $3
                                                        (struct.get $type30 1
                                                         (local.get $3)
                                                        )
                                                       )
                                                       (local.set $2
                                                        (struct.get $type30 1
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (global.get $ready139)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global139)
                                                        )
                                                       )
                                                       (if (result i32)
                                                        (ref.is_null
                                                         (local.get $3)
                                                        )
                                                        (then
                                                         (ref.is_null
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (else
                                                         (if (result i32)
                                                          (ref.is_null
                                                           (local.get $2)
                                                          )
                                                          (then
                                                           (i32.const 0)
                                                          )
                                                          (else
                                                           (if (result i32)
                                                            (i64.eq
                                                             (struct.get $type30 0
                                                              (local.get $3)
                                                             )
                                                             (struct.get $type30 0
                                                              (local.get $2)
                                                             )
                                                            )
                                                            (then
                                                             (local.set $3
                                                              (struct.get $type30 1
                                                               (local.get $3)
                                                              )
                                                             )
                                                             (local.set $2
                                                              (struct.get $type30 1
                                                               (local.get $2)
                                                              )
                                                             )
                                                             (if
                                                              (i32.eqz
                                                               (global.get $ready139)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (drop
                                                              (ref.as_non_null
                                                               (global.get $global139)
                                                              )
                                                             )
                                                             (if (result i32)
                                                              (ref.is_null
                                                               (local.get $3)
                                                              )
                                                              (then
                                                               (ref.is_null
                                                                (local.get $2)
                                                               )
                                                              )
                                                              (else
                                                               (if (result i32)
                                                                (ref.is_null
                                                                 (local.get $2)
                                                                )
                                                                (then
                                                                 (i32.const 0)
                                                                )
                                                                (else
                                                                 (if (result i32)
                                                                  (i64.eq
                                                                   (struct.get $type30 0
                                                                    (local.get $3)
                                                                   )
                                                                   (struct.get $type30 0
                                                                    (local.get $2)
                                                                   )
                                                                  )
                                                                  (then
                                                                   (call $function51
                                                                    (struct.get $type30 1
                                                                     (local.get $3)
                                                                    )
                                                                    (block (result (ref null $type30))
                                                                     (local.set $scratch
                                                                      (struct.get $type30 1
                                                                       (local.get $2)
                                                                      )
                                                                     )
                                                                     (if
                                                                      (i32.eqz
                                                                       (global.get $ready139)
                                                                      )
                                                                      (then
                                                                       (unreachable)
                                                                      )
                                                                     )
                                                                     (drop
                                                                      (ref.as_non_null
                                                                       (global.get $global139)
                                                                      )
                                                                     )
                                                                     (local.get $scratch)
                                                                    )
                                                                   )
                                                                  )
                                                                  (else
                                                                   (i32.const 0)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (else
                                     (i32.const 0)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
         )
        )
       )
       (then
        (return_call $function52
         (struct.get $type32 1
          (local.get $0)
         )
         (block (result (ref null $type32))
          (local.set $scratch_5
           (struct.get $type32 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready142)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global142)
           )
          )
          (local.get $scratch_5)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function54 (type $call70) (param $0 (ref null $type54)) (param $1 (ref null $type54)) (result i32)
  (local $2 (ref $type49))
  (local $3 (ref $type49))
  (local $4 (ref $type16))
  (local $5 (ref $type16))
  (local $6 (ref null $type32))
  (local $7 (ref null $type32))
  (local $scratch (ref null $type32))
  (local $scratch_9 (ref null $type54))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $3
       (struct.get $type54 0
        (local.get $0)
       )
      )
      (local.set $2
       (struct.get $type54 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready145)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global145)
       )
      )
      (if
       (i32.eqz
        (global.get $ready116)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (if (result i32)
       (if (result i32)
        (if (result i32)
         (ref.test (ref $type50)
          (local.get $3)
         )
         (then
          (drop
           (ref.cast (ref $type50)
            (local.get $3)
           )
          )
          (i32.const 1)
         )
         (else
          (drop
           (ref.cast (ref $type51)
            (local.get $3)
           )
          )
          (i32.const 0)
         )
        )
        (then
         (if
          (i32.eqz
           (global.get $ready116)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global116)
          )
         )
         (if (result i32)
          (if (result i32)
           (ref.test (ref $type50)
            (local.get $2)
           )
           (then
            (drop
             (ref.cast (ref $type50)
              (local.get $2)
             )
            )
            (i32.const 1)
           )
           (else
            (drop
             (ref.cast (ref $type51)
              (local.get $2)
             )
            )
            (i32.const 0)
           )
          )
          (then
           (if
            (i32.eqz
             (ref.test (ref $type50)
              (local.get $3)
             )
            )
            (then
             (unreachable)
            )
           )
           (call $function52
            (struct.get $type50 0
             (ref.cast (ref $type50)
              (local.get $3)
             )
            )
            (block (result (ref null $type32))
             (if
              (i32.eqz
               (ref.test (ref $type50)
                (local.get $2)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $scratch
              (struct.get $type50 0
               (ref.cast (ref $type50)
                (local.get $2)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready142)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global142)
              )
             )
             (local.get $scratch)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (if
          (i32.eqz
           (global.get $ready116)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global116)
          )
         )
         (if (result i32)
          (if (result i32)
           (ref.test (ref $type50)
            (local.get $2)
           )
           (then
            (drop
             (ref.cast (ref $type50)
              (local.get $2)
             )
            )
            (i32.const 1)
           )
           (else
            (drop
             (ref.cast (ref $type51)
              (local.get $2)
             )
            )
            (i32.const 0)
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (if
            (ref.test (ref $type50)
             (local.get $3)
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.get $type51 0
             (ref.cast (ref $type51)
              (local.get $3)
             )
            )
           )
           (if
            (ref.test (ref $type50)
             (local.get $2)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $type51 0
             (ref.cast (ref $type51)
              (local.get $2)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready103)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global103)
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (struct.get $type16 1
               (local.get $4)
              )
             )
             (i64.extend_i32_u
              (struct.get $type16 1
               (local.get $5)
              )
             )
            )
            (then
             (call $function40
              (local.get $4)
              (local.get $5)
              (i32.const 0)
              (i32.const 1)
              (i64.const 0)
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
         )
        )
       )
       (then
        (return_call $function54
         (struct.get $type54 1
          (local.get $0)
         )
         (block (result (ref null $type54))
          (local.set $scratch_9
           (struct.get $type54 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready148)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global148)
           )
          )
          (local.get $scratch_9)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function55 (type $100) (result i32)
  (local $0 (ref $type17))
  (local $1 (ref $type16))
  (call $foreign0
   (array.get $type17
    (struct.get $type16 2
     (local.tee $1
      (global.get $string0)
     )
    )
    (i32.const 0)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.tee $0
     (struct.get $type16 2
      (local.get $1)
     )
    )
    (i32.const 1)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.get $0)
    (i32.const 2)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.get $0)
    (i32.const 3)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.get $0)
    (i32.const 4)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.get $0)
    (i32.const 5)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.get $0)
    (i32.const 6)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.get $0)
    (i32.const 7)
   )
  )
  (call $foreign0
   (array.get $type17
    (local.get $0)
    (i32.const 8)
   )
  )
  (call $foreign0
   (array.get $type17
    (call $string-block
     (local.get $1)
     (i32.const 9)
    )
    (i32.const 9)
   )
  )
  (return_call $function56
   (local.get $1)
   (i32.const 0)
   (i32.const 1)
   (i64.const 10)
  )
 )
 (func $function56 (type $99) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (array.get $type17
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function57 (type $98) (param $0 i64)
  (if
   (i64.ge_s
    (local.get $0)
    (i64.const 10)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (call $function57
     (i64.div_s
      (local.get $0)
      (i64.const 10)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (i64.add
      (i64.rem_s
       (local.get $0)
       (i64.const 10)
      )
      (i64.const 48)
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (call $foreign0
   (i32.wrap_i64
    (local.get $0)
   )
  )
 )
 (func $function58 (type $call73) (param $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (if
   (i32.eqz
    (global.get $ready151)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global151)
   )
  )
  (drop
   (call $function55)
  )
  (if
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (call $foreign0
     (i32.const 45)
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type33 1
      (global.get $global109)
     )
    )
    (local.set $0
     (i64.sub
      (i64.const 0)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (if
   (i64.ge_s
    (local.get $0)
    (i64.const 10)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (if
     (i64.ge_s
      (local.tee $2
       (i64.div_s
        (local.get $0)
        (i64.const 10)
       )
      )
      (i64.const 10)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (if
       (i64.ge_s
        (local.tee $3
         (i64.div_s
          (local.get $2)
          (i64.const 10)
         )
        )
        (i64.const 10)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready155)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global155)
         )
        )
        (if
         (i64.ge_s
          (local.tee $4
           (i64.div_s
            (local.get $3)
            (i64.const 10)
           )
          )
          (i64.const 10)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready155)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global155)
           )
          )
          (if
           (i64.ge_s
            (local.tee $5
             (i64.div_s
              (local.get $4)
              (i64.const 10)
             )
            )
            (i64.const 10)
           )
           (then
            (if
             (i32.eqz
              (global.get $ready155)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global155)
             )
            )
            (if
             (i64.ge_s
              (local.tee $6
               (i64.div_s
                (local.get $5)
                (i64.const 10)
               )
              )
              (i64.const 10)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready155)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global155)
               )
              )
              (if
               (i64.ge_s
                (local.tee $7
                 (i64.div_s
                  (local.get $6)
                  (i64.const 10)
                 )
                )
                (i64.const 10)
               )
               (then
                (if
                 (i32.eqz
                  (global.get $ready155)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global155)
                 )
                )
                (if
                 (i64.ge_s
                  (local.tee $8
                   (i64.div_s
                    (local.get $7)
                    (i64.const 10)
                   )
                  )
                  (i64.const 10)
                 )
                 (then
                  (if
                   (i32.eqz
                    (global.get $ready155)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global155)
                   )
                  )
                  (if
                   (i64.ge_s
                    (local.tee $9
                     (i64.div_s
                      (local.get $8)
                      (i64.const 10)
                     )
                    )
                    (i64.const 10)
                   )
                   (then
                    (if
                     (i32.eqz
                      (global.get $ready155)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global155)
                     )
                    )
                    (if
                     (i64.ge_s
                      (local.tee $1
                       (i64.div_s
                        (local.get $9)
                        (i64.const 10)
                       )
                      )
                      (i64.const 10)
                     )
                     (then
                      (if
                       (i32.eqz
                        (global.get $ready155)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global155)
                       )
                      )
                      (call $function57
                       (i64.div_s
                        (local.get $1)
                        (i64.const 10)
                       )
                      )
                     )
                    )
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (i64.add
                        (i64.rem_s
                         (local.get $1)
                         (i64.const 10)
                        )
                        (i64.const 48)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $1)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $1)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign0
                     (i32.wrap_i64
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if
                   (i64.gt_u
                    (local.tee $1
                     (i64.add
                      (i64.rem_s
                       (local.get $9)
                       (i64.const 10)
                      )
                      (i64.const 48)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $1)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $1)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign0
                   (i32.wrap_i64
                    (local.get $1)
                   )
                  )
                 )
                )
                (if
                 (i64.gt_u
                  (local.tee $1
                   (i64.add
                    (i64.rem_s
                     (local.get $8)
                     (i64.const 10)
                    )
                    (i64.const 48)
                   )
                  )
                  (i64.const 1114111)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i64.le_u
                   (local.get $1)
                   (i64.const 57343)
                  )
                  (i64.ge_u
                   (local.get $1)
                   (i64.const 55296)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign0
                 (i32.wrap_i64
                  (local.get $1)
                 )
                )
               )
              )
              (if
               (i64.gt_u
                (local.tee $1
                 (i64.add
                  (i64.rem_s
                   (local.get $7)
                   (i64.const 10)
                  )
                  (i64.const 48)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $1)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $1)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (call $foreign0
               (i32.wrap_i64
                (local.get $1)
               )
              )
             )
            )
            (if
             (i64.gt_u
              (local.tee $1
               (i64.add
                (i64.rem_s
                 (local.get $6)
                 (i64.const 10)
                )
                (i64.const 48)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $1)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $1)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (call $foreign0
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
          (if
           (i64.gt_u
            (local.tee $1
             (i64.add
              (i64.rem_s
               (local.get $5)
               (i64.const 10)
              )
              (i64.const 48)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (call $foreign0
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
        (if
         (i64.gt_u
          (local.tee $1
           (i64.add
            (i64.rem_s
             (local.get $4)
             (i64.const 10)
            )
            (i64.const 48)
           )
          )
          (i64.const 1114111)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.and
          (i64.le_u
           (local.get $1)
           (i64.const 57343)
          )
          (i64.ge_u
           (local.get $1)
           (i64.const 55296)
          )
         )
         (then
          (unreachable)
         )
        )
        (call $foreign0
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (i64.add
          (i64.rem_s
           (local.get $3)
           (i64.const 10)
          )
          (i64.const 48)
         )
        )
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $1)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $1)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (call $foreign0
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (i64.rem_s
         (local.get $2)
         (i64.const 10)
        )
        (i64.const 48)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $1)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $1)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (i64.add
      (i64.rem_s
       (local.get $0)
       (i64.const 10)
      )
      (i64.const 48)
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (call $foreign0
   (i32.wrap_i64
    (local.get $0)
   )
  )
  (call $foreign0
   (i32.const 10)
  )
  (unreachable)
 )
 (func $function59 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global121)
   )
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global121)
   )
  )
  (if (result i64)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i64.div_s
     (local.get $1)
     (local.get $2)
    )
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
     (then
      (if (result i64)
       (i64.eq
        (local.get $1)
        (i64.mul
         (local.get $2)
         (local.tee $3
          (i64.div_s
           (local.get $1)
           (local.get $2)
          )
         )
        )
       )
       (then
        (local.get $3)
       )
       (else
        (i64.add
         (local.get $3)
         (i64.const 1)
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $1)
        (i64.mul
         (local.get $2)
         (local.tee $3
          (i64.div_s
           (local.get $1)
           (local.get $2)
          )
         )
        )
       )
       (then
        (local.get $3)
       )
       (else
        (i64.sub
         (local.get $3)
         (i64.const 1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function60 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global121)
   )
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global121)
   )
  )
  (if (result i64)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i64.rem_s
     (local.get $1)
     (local.get $2)
    )
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
     (then
      (if (result i64)
       (i64.eqz
        (local.tee $1
         (i64.sub
          (local.get $1)
          (i64.mul
           (local.get $2)
           (i64.div_s
            (local.get $1)
            (local.get $2)
           )
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (i64.sub
         (local.get $1)
         (local.get $2)
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $1
         (i64.sub
          (local.get $1)
          (i64.mul
           (local.get $2)
           (i64.div_s
            (local.get $1)
            (local.get $2)
           )
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (i64.add
         (local.get $1)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function61 (type $call77) (param $0 structref) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref $type114))
  (if
   (i32.eqz
    (global.get $ready175)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (local.set $2
   (struct.new $type114
    (i32.const 1)
   )
  )
  (return_call $function67
   (local.get $1)
   (i32.const 0)
   (i32.const 1)
   (if (result (ref $type35))
    (ref.is_null
     (local.get $1)
    )
    (then
     (global.get $empty36)
    )
    (else
     (struct.new $type37
      (struct.new $type38
       (struct.new $environment64
        (local.get $2)
        (local.get $1)
        (ref.null none)
       )
      )
     )
    )
   )
  )
 )
 (func $function64 (type $call38) (param $0 (ref $environment64)) (param $1 i64) (result (ref $type39))
  (local $2 (ref null $type32))
  (local $3 (ref null $type32))
  (local $4 (ref $type32))
  (local $5 (ref null $type30))
  (local $6 (ref $type114))
  (if (result (ref $type39))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.new $type40
     (i32.const 0)
     (struct.get $type32 0
      (struct.get $environment64 1
       (local.get $0)
      )
     )
    )
   )
   (else
    (if (result (ref $type39))
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (local.set $3
       (struct.get $type32 1
        (local.tee $2
         (struct.get $environment64 1
          (local.get $0)
         )
        )
       )
      )
      (local.set $5
       (struct.get $type32 0
        (local.get $2)
       )
      )
      (struct.new $type41
       (i32.const 1)
       (if (result (ref $type35))
        (ref.is_null
         (local.get $3)
        )
        (then
         (global.get $empty36)
        )
        (else
         (struct.new $type37
          (struct.new $type38
           (struct.new $environment64
            (struct.get $environment64 0
             (local.get $0)
            )
            (local.get $3)
            (struct.new $type32
             (local.get $5)
             (struct.get $environment64 2
              (local.get $0)
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type39))
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (local.set $2
         (struct.get $type32 1
          (struct.get $environment64 1
           (local.get $0)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready184)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global184)
         )
        )
        (if
         (i32.eqz
          (ref.is_null
           (local.tee $3
            (struct.get $environment64 2
             (local.get $0)
            )
           )
          )
         )
         (then
          (local.set $4
           (struct.new $type32
            (struct.get $type32 0
             (local.get $3)
            )
            (local.get $2)
           )
          )
          (local.set $2
           (if (result (ref null $type32))
            (ref.is_null
             (local.tee $2
              (struct.get $type32 1
               (local.get $3)
              )
             )
            )
            (then
             (local.get $4)
            )
            (else
             (local.set $4
              (struct.new $type32
               (struct.get $type32 0
                (local.get $2)
               )
               (local.get $4)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.tee $2
                (struct.get $type32 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $4)
              )
              (else
               (local.set $4
                (struct.new $type32
                 (struct.get $type32 0
                  (local.get $2)
                 )
                 (local.get $4)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.tee $2
                  (struct.get $type32 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $4)
                )
                (else
                 (local.set $4
                  (struct.new $type32
                   (struct.get $type32 0
                    (local.get $2)
                   )
                   (local.get $4)
                  )
                 )
                 (if (result (ref null $type32))
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type32 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $4)
                  )
                  (else
                   (local.set $4
                    (struct.new $type32
                     (struct.get $type32 0
                      (local.get $2)
                     )
                     (local.get $4)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type32 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (local.set $4
                      (struct.new $type32
                       (struct.get $type32 0
                        (local.get $2)
                       )
                       (local.get $4)
                      )
                     )
                     (if (result (ref null $type32))
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type32 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $4)
                      )
                      (else
                       (local.set $4
                        (struct.new $type32
                         (struct.get $type32 0
                          (local.get $2)
                         )
                         (local.get $4)
                        )
                       )
                       (if (result (ref null $type32))
                        (ref.is_null
                         (local.tee $2
                          (struct.get $type32 1
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (local.get $4)
                        )
                        (else
                         (local.set $4
                          (struct.new $type32
                           (struct.get $type32 0
                            (local.get $2)
                           )
                           (local.get $4)
                          )
                         )
                         (if (result (ref null $type32))
                          (ref.is_null
                           (local.tee $2
                            (struct.get $type32 1
                             (local.get $2)
                            )
                           )
                          )
                          (then
                           (local.get $4)
                          )
                          (else
                           (call $function66
                            (struct.new $type84
                             (ref.func $primitive0)
                             (ref.null none)
                            )
                            (i32.const 0)
                            (i32.const 1)
                            (struct.get $type32 1
                             (local.get $2)
                            )
                            (call $primitive0
                             (ref.null none)
                             (struct.get $type32 0
                              (local.get $2)
                             )
                             (local.get $4)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready175)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global175)
         )
        )
        (local.set $6
         (struct.new $type114
          (i32.const 1)
         )
        )
        (struct.new $type41
         (i32.const 1)
         (if (result (ref $type35))
          (ref.is_null
           (local.get $2)
          )
          (then
           (global.get $empty36)
          )
          (else
           (struct.new $type37
            (struct.new $type38
             (struct.new $environment64
              (local.get $6)
              (local.get $2)
              (ref.null none)
             )
            )
           )
          )
         )
        )
       )
       (else
        (if (result (ref $type42))
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (drop
           (struct.get $type32 0
            (local.tee $2
             (struct.get $environment64 1
              (local.get $0)
             )
            )
           )
          )
          (local.set $3
           (struct.get $type32 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (global.get $ready184)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global184)
           )
          )
          (drop
           (if (result (ref null $type32))
            (ref.is_null
             (local.tee $2
              (struct.get $environment64 2
               (local.get $0)
              )
             )
            )
            (then
             (local.get $3)
            )
            (else
             (local.set $4
              (struct.new $type32
               (struct.get $type32 0
                (local.get $2)
               )
               (local.get $3)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.tee $2
                (struct.get $type32 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $4)
              )
              (else
               (local.set $4
                (struct.new $type32
                 (struct.get $type32 0
                  (local.get $2)
                 )
                 (local.get $4)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.tee $2
                  (struct.get $type32 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $4)
                )
                (else
                 (local.set $4
                  (struct.new $type32
                   (struct.get $type32 0
                    (local.get $2)
                   )
                   (local.get $4)
                  )
                 )
                 (if (result (ref null $type32))
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type32 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $4)
                  )
                  (else
                   (local.set $4
                    (struct.new $type32
                     (struct.get $type32 0
                      (local.get $2)
                     )
                     (local.get $4)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type32 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (local.set $4
                      (struct.new $type32
                       (struct.get $type32 0
                        (local.get $2)
                       )
                       (local.get $4)
                      )
                     )
                     (if (result (ref null $type32))
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type32 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $4)
                      )
                      (else
                       (local.set $4
                        (struct.new $type32
                         (struct.get $type32 0
                          (local.get $2)
                         )
                         (local.get $4)
                        )
                       )
                       (if (result (ref null $type32))
                        (ref.is_null
                         (local.tee $2
                          (struct.get $type32 1
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (local.get $4)
                        )
                        (else
                         (local.set $4
                          (struct.new $type32
                           (struct.get $type32 0
                            (local.get $2)
                           )
                           (local.get $4)
                          )
                         )
                         (if (result (ref null $type32))
                          (ref.is_null
                           (local.tee $2
                            (struct.get $type32 1
                             (local.get $2)
                            )
                           )
                          )
                          (then
                           (local.get $4)
                          )
                          (else
                           (local.set $4
                            (struct.new $type32
                             (struct.get $type32 0
                              (local.get $2)
                             )
                             (local.get $4)
                            )
                           )
                           (if (result (ref null $type32))
                            (ref.is_null
                             (local.tee $2
                              (struct.get $type32 1
                               (local.get $2)
                              )
                             )
                            )
                            (then
                             (local.get $4)
                            )
                            (else
                             (call $function66
                              (struct.new $type84
                               (ref.func $primitive0)
                               (ref.null none)
                              )
                              (i32.const 0)
                              (i32.const 1)
                              (struct.get $type32 1
                               (local.get $2)
                              )
                              (call $primitive0
                               (ref.null none)
                               (struct.get $type32 0
                                (local.get $2)
                               )
                               (local.get $4)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (struct.new $type42
           (i32.const 2)
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready157)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global157)
           )
          )
          (call $function58
           (local.get $1)
          )
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function65 (type $86) (param $0 (ref null $type32)) (param $1 (ref $type84)) (result (ref null $type32))
  (local $2 (ref null $type32))
  (local $3 (ref null $type32))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $3
     (struct.get $type32 1
      (local.get $0)
     )
    )
    (local.set $2
     (call_ref $call84
      (struct.get $type84 1
       (local.get $1)
      )
      (struct.get $type32 0
       (local.get $0)
      )
      (ref.null none)
      (struct.get $type84 0
       (local.get $1)
      )
     )
    )
    (if (result (ref null $type32))
     (ref.is_null
      (local.get $3)
     )
     (then
      (local.get $2)
     )
     (else
      (local.set $0
       (struct.get $type32 1
        (local.get $3)
       )
      )
      (local.set $2
       (call_ref $call84
        (struct.get $type84 1
         (local.get $1)
        )
        (struct.get $type32 0
         (local.get $3)
        )
        (local.get $2)
        (struct.get $type84 0
         (local.get $1)
        )
       )
      )
      (if (result (ref null $type32))
       (ref.is_null
        (local.get $0)
       )
       (then
        (local.get $2)
       )
       (else
        (local.set $3
         (struct.get $type32 1
          (local.get $0)
         )
        )
        (local.set $2
         (call_ref $call84
          (struct.get $type84 1
           (local.get $1)
          )
          (struct.get $type32 0
           (local.get $0)
          )
          (local.get $2)
          (struct.get $type84 0
           (local.get $1)
          )
         )
        )
        (if (result (ref null $type32))
         (ref.is_null
          (local.get $3)
         )
         (then
          (local.get $2)
         )
         (else
          (local.set $0
           (struct.get $type32 1
            (local.get $3)
           )
          )
          (local.set $2
           (call_ref $call84
            (struct.get $type84 1
             (local.get $1)
            )
            (struct.get $type32 0
             (local.get $3)
            )
            (local.get $2)
            (struct.get $type84 0
             (local.get $1)
            )
           )
          )
          (if (result (ref null $type32))
           (ref.is_null
            (local.get $0)
           )
           (then
            (local.get $2)
           )
           (else
            (local.set $3
             (struct.get $type32 1
              (local.get $0)
             )
            )
            (local.set $2
             (call_ref $call84
              (struct.get $type84 1
               (local.get $1)
              )
              (struct.get $type32 0
               (local.get $0)
              )
              (local.get $2)
              (struct.get $type84 0
               (local.get $1)
              )
             )
            )
            (if (result (ref null $type32))
             (ref.is_null
              (local.get $3)
             )
             (then
              (local.get $2)
             )
             (else
              (local.set $0
               (struct.get $type32 1
                (local.get $3)
               )
              )
              (local.set $2
               (call_ref $call84
                (struct.get $type84 1
                 (local.get $1)
                )
                (struct.get $type32 0
                 (local.get $3)
                )
                (local.get $2)
                (struct.get $type84 0
                 (local.get $1)
                )
               )
              )
              (if (result (ref null $type32))
               (ref.is_null
                (local.get $0)
               )
               (then
                (local.get $2)
               )
               (else
                (local.set $3
                 (struct.get $type32 1
                  (local.get $0)
                 )
                )
                (local.set $2
                 (call_ref $call84
                  (struct.get $type84 1
                   (local.get $1)
                  )
                  (struct.get $type32 0
                   (local.get $0)
                  )
                  (local.get $2)
                  (struct.get $type84 0
                   (local.get $1)
                  )
                 )
                )
                (if (result (ref null $type32))
                 (ref.is_null
                  (local.get $3)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (local.set $0
                   (struct.get $type32 1
                    (local.get $3)
                   )
                  )
                  (local.set $3
                   (call_ref $call84
                    (struct.get $type84 1
                     (local.get $1)
                    )
                    (struct.get $type32 0
                     (local.get $3)
                    )
                    (local.get $2)
                    (struct.get $type84 0
                     (local.get $1)
                    )
                   )
                  )
                  (if (result (ref null $type32))
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (return_call $function66
                     (local.get $1)
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type32 1
                      (local.get $0)
                     )
                     (call_ref $call84
                      (struct.get $type84 1
                       (local.get $1)
                      )
                      (struct.get $type32 0
                       (local.get $0)
                      )
                      (local.get $3)
                      (struct.get $type84 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function66 (type $84) (param $0 (ref $type84)) (param $1 i32) (param $2 i32) (param $3 (ref null $type32)) (param $4 (ref null $type32)) (result (ref null $type32))
  (local $5 (ref null $type32))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (local.set $5
     (struct.get $type32 1
      (local.get $3)
     )
    )
    (local.set $3
     (call_ref $call84
      (struct.get $type84 1
       (local.get $0)
      )
      (struct.get $type32 0
       (local.get $3)
      )
      (local.get $4)
      (struct.get $type84 0
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function66
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $5)
     (local.get $3)
    )
   )
  )
 )
 (func $function67 (type $83) (param $0 (ref null $type32)) (param $1 i32) (param $2 i32) (param $3 (ref $type35)) (result i32)
  (local $4 (ref null $type30))
  (local $5 (ref null $type30))
  (local $6 (ref null $type30))
  (local $7 (ref $type39))
  (local $8 (ref null $type32))
  (local $9 (ref $type35))
  (local $10 i64)
  (if
   (i32.eqz
    (global.get $ready194)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global194)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type36)
     (local.get $3)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type37)
       (local.get $3)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready198)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global198)
     )
    )
    (if
     (i32.eqz
      (global.get $ready202)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (if
     (ref.test (ref $type36)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (struct.get $type39 0
      (local.tee $7
       (call $function64
        (struct.get $type38 0
         (struct.get $type37 0
          (ref.cast (ref $type37)
           (local.get $3)
          )
         )
        )
        (i64.const 0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type40 1
      (ref.cast (ref $type40)
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready205)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global205)
     )
    )
    (local.set $10
     (if (result i64)
      (ref.is_null
       (local.get $5)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $4
          (struct.get $type30 1
           (local.get $5)
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $4
            (struct.get $type30 1
             (local.get $4)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $4
              (struct.get $type30 1
               (local.get $4)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $4
                (struct.get $type30 1
                 (local.get $4)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $4
                  (struct.get $type30 1
                   (local.get $4)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $4
                    (struct.get $type30 1
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $4
                      (struct.get $type30 1
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $4
                        (struct.get $type30 1
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (call $function72
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type30 1
                         (local.get $4)
                        )
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.set $8
     (struct.get $type32 1
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready211)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (if
     (ref.test (ref $type36)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type39 0
       (local.tee $7
        (call $function64
         (struct.get $type38 0
          (struct.get $type37 0
           (ref.cast (ref $type37)
            (local.get $3)
           )
          )
         )
         (i64.const 2)
        )
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.get $type41 1
      (ref.cast (ref $type41)
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready229)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global229)
     )
    )
    (if
     (i32.eqz
      (global.get $ready235)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global235)
     )
    )
    (local.set $6
     (if (result (ref null $type30))
      (i64.eqz
       (local.get $10)
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type30
        (i64.const 0)
        (if (result (ref null $type30))
         (i64.eq
          (local.get $10)
          (i64.const 1)
         )
         (then
          (ref.null none)
         )
         (else
          (struct.new $type30
           (i64.const 1)
           (if (result (ref null $type30))
            (i64.eq
             (local.get $10)
             (i64.const 2)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type30
              (i64.const 2)
              (if (result (ref null $type30))
               (i64.eq
                (local.get $10)
                (i64.const 3)
               )
               (then
                (ref.null none)
               )
               (else
                (struct.new $type30
                 (i64.const 3)
                 (if (result (ref null $type30))
                  (i64.eq
                   (local.get $10)
                   (i64.const 4)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type30
                    (i64.const 4)
                    (if (result (ref null $type30))
                     (i64.eq
                      (local.get $10)
                      (i64.const 5)
                     )
                     (then
                      (ref.null none)
                     )
                     (else
                      (struct.new $type30
                       (i64.const 5)
                       (if (result (ref null $type30))
                        (i64.eq
                         (local.get $10)
                         (i64.const 6)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type30
                          (i64.const 6)
                          (if (result (ref null $type30))
                           (i64.eq
                            (local.get $10)
                            (i64.const 7)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (struct.new $type30
                             (i64.const 7)
                             (call $function82
                              (local.get $10)
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 8)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready239)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global239)
     )
    )
    (if (result i32)
     (call $function84
      (struct.new $type80
       (struct.new $environment75
        (local.get $5)
        (local.get $10)
        (i64.const 1)
        (i64.const -1)
       )
      )
      (struct.new $type80
       (struct.new $environment75
        (local.get $5)
        (local.get $10)
        (i64.const -1)
        (i64.const 1)
       )
      )
      (struct.new $type114
       (i32.const 1)
      )
      (local.get $9)
      (local.get $8)
      (struct.new $type32
       (local.get $6)
       (ref.null none)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready280)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global280)
       )
      )
      (if
       (ref.test (ref $type36)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type39 0
         (local.tee $7
          (call $function64
           (struct.get $type38 0
            (struct.get $type37 0
             (ref.cast (ref $type37)
              (local.get $3)
             )
            )
           )
           (i64.const 1)
          )
         )
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type41 1
        (ref.cast (ref $type41)
         (local.get $7)
        )
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function67
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 1)
   )
  )
 )
 (func $function72 (type $80) (param $0 i32) (param $1 i32) (param $2 (ref null $type30)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type30 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function72
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function75 (type $call80) (param $0 (ref $environment75)) (param $1 (ref null $type30)) (result (ref $type33))
  (local $2 (ref $type12))
  (local $3 (ref $type12))
  (local $4 i64)
  (local $5 i32)
  (if
   (i32.eqz
    (global.get $ready218)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global218)
   )
  )
  (drop
   (call $function78
    (local.tee $4
     (struct.get $environment75 1
      (local.get $0)
     )
    )
    (struct.get $environment75 2
     (local.get $0)
    )
    (struct.get $environment75 3
     (local.get $0)
    )
    (local.tee $3
     (if (result (ref $type12))
      (if (result i32)
       (local.tee $5
        (i64.lt_s
         (local.get $4)
         (i64.const 0)
        )
       )
       (then
        (local.get $5)
       )
       (else
        (i64.gt_s
         (local.get $4)
         (i64.const 4294967295)
        )
       )
      )
      (then
       (unreachable)
      )
      (else
       (if (result (ref $type12))
        (i64.eqz
         (local.get $4)
        )
        (then
         (array.new_fixed $type12 0)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready55)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global55)
          )
         )
         (if
          (i64.gt_u
           (local.get $4)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $4)
           )
          )
         )
         (if (result (ref $type12))
          (i64.eq
           (local.get $4)
           (i64.const 1)
          )
          (then
           (local.get $2)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready55)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global55)
            )
           )
           (array.set $type12
            (local.get $2)
            (i32.const 1)
            (i64.const 0)
           )
           (if (result (ref $type12))
            (i64.eq
             (local.get $4)
             (i64.const 2)
            )
            (then
             (local.get $2)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready55)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global55)
              )
             )
             (array.set $type12
              (local.get $2)
              (i32.const 2)
              (i64.const 0)
             )
             (if (result (ref $type12))
              (i64.eq
               (local.get $4)
               (i64.const 3)
              )
              (then
               (local.get $2)
              )
              (else
               (if
                (i32.eqz
                 (global.get $ready55)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global55)
                )
               )
               (array.set $type12
                (local.get $2)
                (i32.const 3)
                (i64.const 0)
               )
               (if (result (ref $type12))
                (i64.eq
                 (local.get $4)
                 (i64.const 4)
                )
                (then
                 (local.get $2)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready55)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global55)
                  )
                 )
                 (array.set $type12
                  (local.get $2)
                  (i32.const 4)
                  (i64.const 0)
                 )
                 (if (result (ref $type12))
                  (i64.eq
                   (local.get $4)
                   (i64.const 5)
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready55)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global55)
                    )
                   )
                   (array.set $type12
                    (local.get $2)
                    (i32.const 5)
                    (i64.const 0)
                   )
                   (if (result (ref $type12))
                    (i64.eq
                     (local.get $4)
                     (i64.const 6)
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (if
                      (i32.eqz
                       (global.get $ready55)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global55)
                      )
                     )
                     (array.set $type12
                      (local.get $2)
                      (i32.const 6)
                      (i64.const 0)
                     )
                     (if (result (ref $type12))
                      (i64.eq
                       (local.get $4)
                       (i64.const 7)
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready55)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global55)
                        )
                       )
                       (array.set $type12
                        (local.get $2)
                        (i32.const 7)
                        (i64.const 0)
                       )
                       (if (result (ref $type12))
                        (i64.eq
                         (local.get $4)
                         (i64.const 8)
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready55)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global55)
                          )
                         )
                         (array.set $type12
                          (local.get $2)
                          (i32.const 8)
                          (i64.const 0)
                         )
                         (if (result (ref $type12))
                          (i64.eq
                           (local.get $4)
                           (i64.const 9)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (if
                            (i32.eqz
                             (global.get $ready55)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global55)
                            )
                           )
                           (array.set $type12
                            (local.get $2)
                            (i32.const 9)
                            (i64.const 0)
                           )
                           (call $function77
                            (local.get $4)
                            (local.get $2)
                            (i32.const 0)
                            (i32.const 1)
                            (i64.const 10)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (struct.get $environment75 0
     (local.get $0)
    )
    (local.get $1)
   )
  )
  (struct.new $type33
   (ref.func $function79)
   (struct.new $environment79
    (local.get $3)
   )
  )
 )
 (func $function77 (type $76) (param $0 i64) (param $1 (ref $type12)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref $type12))
  (if (result (ref $type12))
   (i64.eq
    (local.get $0)
    (local.get $4)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready55)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global55)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function78 (type $75) (param $0 i64) (param $1 i64) (param $2 i64) (param $3 (ref $type12)) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 (ref null $type30)) (param $8 (ref null $type30)) (result i32)
  (local $9 i64)
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $9
     (select
      (local.get $1)
      (local.get $2)
      (i64.eq
       (struct.get $type30 0
        (local.get $7)
       )
       (struct.get $type30 0
        (local.get $8)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $3)
     (i32.wrap_i64
      (local.get $6)
     )
     (local.get $9)
    )
    (local.set $7
     (struct.get $type30 1
      (local.get $7)
     )
    )
    (local.set $8
     (struct.get $type30 1
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function78
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (local.get $7)
     (local.get $8)
    )
   )
  )
 )
 (func $function79 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type12
   (struct.get $environment79 0
    (ref.cast (ref $environment79)
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function82 (type $74) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result (ref null $type30))
  (if (result (ref null $type30))
   (i64.eq
    (local.get $0)
    (local.get $3)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (local.get $3)
     (call $function82
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (i64.add
       (local.get $3)
       (i64.const 1)
      )
     )
    )
   )
  )
 )
 (func $function84 (type $73) (param $0 (ref $type80)) (param $1 (ref $type80)) (param $2 (ref $type114)) (param $3 (ref $type35)) (param $4 (ref null $type32)) (param $5 (ref null $type32)) (result i32)
  (local $6 (ref $type39))
  (local $7 (ref null $type30))
  (local $8 (ref $type33))
  (local $9 i32)
  (if
   (i32.eqz
    (global.get $ready194)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global194)
   )
  )
  (if (result i32)
   (local.tee $9
    (i32.eqz
     (if (result i32)
      (ref.test (ref $type36)
       (local.get $3)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type37)
         (local.get $3)
        )
       )
       (i32.const 1)
      )
     )
    )
   )
   (then
    (local.get $9)
   )
   (else
    (local.set $7
     (struct.get $type32 0
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready202)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (if
     (ref.test (ref $type36)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (struct.get $type39 0
      (local.tee $6
       (call $function64
        (struct.get $type38 0
         (struct.get $type37 0
          (ref.cast (ref $type37)
           (local.get $3)
          )
         )
        )
        (i64.const 0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call $function88
      (call $function75
       (struct.get $type80 0
        (local.get $0)
       )
       (struct.get $type40 1
        (ref.cast (ref $type40)
         (local.get $6)
        )
       )
      )
      (block (result (ref (exact $type77)))
       (if
        (i32.eqz
         (global.get $ready247)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type81 0
         (global.get $global247)
        )
       )
       (struct.new $type77
        (ref.func $function85)
        (struct.new $environment85
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $4)
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
      (local.get $5)
      (ref.null none)
      (i32.const 0)
      (i32.const 1)
      (i32.const 0)
      (struct.get $type32 0
       (local.get $5)
      )
      (local.get $7)
      (ref.null none)
      (ref.null none)
     )
     (then
      (local.set $7
       (struct.get $type32 0
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (global.get $ready202)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global202)
       )
      )
      (if
       (ref.test (ref $type36)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (if
       (struct.get $type39 0
        (local.tee $6
         (call $function64
          (struct.get $type38 0
           (struct.get $type37 0
            (ref.cast (ref $type37)
             (local.get $3)
            )
           )
          )
          (i64.const 0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (call $function88
        (call $function75
         (struct.get $type80 0
          (local.get $1)
         )
         (struct.get $type40 1
          (ref.cast (ref $type40)
           (local.get $6)
          )
         )
        )
        (block (result (ref (exact $type77)))
         (if
          (i32.eqz
           (global.get $ready247)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (struct.get $type81 0
           (global.get $global247)
          )
         )
         (struct.new $type77
          (ref.func $function93)
          (struct.new $environment93
           (local.get $0)
           (local.get $1)
           (local.get $2)
           (local.get $3)
           (local.get $4)
          )
         )
        )
        (i32.const 0)
        (i32.const 1)
        (local.get $5)
        (ref.null none)
        (i32.const 0)
        (i32.const 1)
        (i32.const 0)
        (struct.get $type32 0
         (local.get $5)
        )
        (local.get $7)
        (ref.null none)
        (ref.null none)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready280)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global280)
         )
        )
        (if
         (ref.test (ref $type36)
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.ne
          (struct.get $type39 0
           (local.tee $6
            (call $function64
             (struct.get $type38 0
              (struct.get $type37 0
               (ref.cast (ref $type37)
                (local.get $3)
               )
              )
             )
             (i64.const 1)
            )
           )
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type41 1
          (ref.cast (ref $type41)
           (local.get $6)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready194)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global194)
         )
        )
        (if (result i32)
         (local.tee $9
          (i32.eqz
           (if (result i32)
            (ref.test (ref $type36)
             (local.get $3)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (ref.cast (ref $type37)
               (local.get $3)
              )
             )
             (i32.const 1)
            )
           )
          )
         )
         (then
          (local.get $9)
         )
         (else
          (return_call $function84
           (local.get $0)
           (local.get $1)
           (local.get $2)
           (local.get $3)
           (local.get $4)
           (local.get $5)
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function85 (type $call77) (param $0 structref) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref $environment85))
  (local $3 (ref $type35))
  (local $4 (ref $type39))
  (local $5 (ref null $type32))
  (local.set $3
   (struct.get $environment85 3
    (ref.cast (ref $environment85)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready211)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global211)
   )
  )
  (if
   (ref.test (ref $type36)
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type39 0
     (local.tee $4
      (call $function64
       (struct.get $type38 0
        (struct.get $type37 0
         (ref.cast (ref $type37)
          (local.get $3)
         )
        )
       )
       (i64.const 2)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type32 1
    (struct.get $environment85 4
     (local.tee $2
      (ref.cast (ref $environment85)
       (local.get $0)
      )
     )
    )
   )
  )
  (return_call $function84
   (struct.get $environment85 0
    (local.get $2)
   )
   (struct.get $environment85 1
    (local.get $2)
   )
   (struct.get $environment85 2
    (local.get $2)
   )
   (struct.get $type41 1
    (ref.cast (ref $type41)
     (local.get $4)
    )
   )
   (local.get $5)
   (local.get $1)
  )
 )
 (func $function88 (type $70) (param $0 (ref $type33)) (param $1 (ref $type77)) (param $2 i32) (param $3 i32) (param $4 (ref null $type32)) (param $5 (ref null $type32)) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 (ref null $type30)) (param $10 (ref null $type30)) (param $11 (ref null $type30)) (param $12 (ref null $type30)) (result i32)
  (local $13 i64)
  (local $14 i64)
  (if (result i32)
   (ref.is_null
    (local.get $9)
   )
   (then
    (return_call $function89
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $11)
     (local.get $12)
     (i32.const 0)
     (i32.const 1)
     (local.get $8)
     (local.get $10)
     (local.get $12)
    )
   )
   (else
    (if (result i32)
     (i64.eq
      (local.tee $14
       (call_ref $call33
        (struct.get $type33 1
         (local.get $0)
        )
        (local.tee $13
         (struct.get $type30 0
          (local.get $9)
         )
        )
        (struct.get $type33 0
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
     (then
      (if (result i32)
       (i64.eq
        (struct.get $type30 0
         (local.get $10)
        )
        (i64.const 1)
       )
       (then
        (local.set $9
         (struct.get $type30 1
          (local.get $9)
         )
        )
        (local.set $10
         (struct.get $type30 1
          (local.get $10)
         )
        )
        (if
         (i32.eqz
          (local.get $7)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function88
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $4)
         (local.get $5)
         (local.get $6)
         (local.get $7)
         (local.get $8)
         (local.get $9)
         (local.get $10)
         (struct.new $type30
          (local.get $13)
          (local.get $11)
         )
         (local.get $12)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $14)
        (i64.const -1)
       )
       (then
        (local.set $9
         (struct.get $type30 1
          (local.get $9)
         )
        )
        (if
         (i32.eqz
          (local.get $7)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function88
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $4)
         (local.get $5)
         (local.get $6)
         (local.get $7)
         (local.get $8)
         (local.get $9)
         (local.get $10)
         (local.get $11)
         (struct.new $type30
          (local.get $13)
          (local.get $12)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
   )
  )
 )
 (func $function89 (type $69) (param $0 (ref $type33)) (param $1 (ref $type77)) (param $2 i32) (param $3 i32) (param $4 (ref null $type32)) (param $5 (ref null $type32)) (param $6 (ref null $type30)) (param $7 (ref null $type30)) (param $8 i32) (param $9 i32) (param $10 i32) (param $11 (ref null $type30)) (param $12 (ref null $type30)) (result i32)
  (local $13 (ref $type32))
  (local $14 i32)
  (if (result i32)
   (ref.is_null
    (local.get $12)
   )
   (then
    (if
     (i32.eqz
      (ref.is_null
       (local.get $6)
      )
     )
     (then
      (local.set $5
       (struct.new $type32
        (local.get $6)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (ref.is_null
       (local.get $7)
      )
     )
     (then
      (local.set $5
       (struct.new $type32
        (local.get $7)
        (local.get $5)
       )
      )
     )
    )
    (if
     (ref.is_null
      (local.tee $4
       (struct.get $type32 1
        (local.get $4)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready269)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type55 1
        (global.get $global269)
       )
      )
      (return_call_ref $call77
       (struct.get $type77 1
        (local.get $1)
       )
       (if (result (ref null $type32))
        (ref.is_null
         (local.get $5)
        )
        (then
         (ref.null none)
        )
        (else
         (local.set $13
          (struct.new $type32
           (struct.get $type32 0
            (local.get $5)
           )
           (ref.null none)
          )
         )
         (if (result (ref null $type32))
          (ref.is_null
           (local.tee $4
            (struct.get $type32 1
             (local.get $5)
            )
           )
          )
          (then
           (local.get $13)
          )
          (else
           (local.set $13
            (struct.new $type32
             (struct.get $type32 0
              (local.get $4)
             )
             (local.get $13)
            )
           )
           (if (result (ref null $type32))
            (ref.is_null
             (local.tee $4
              (struct.get $type32 1
               (local.get $4)
              )
             )
            )
            (then
             (local.get $13)
            )
            (else
             (local.set $13
              (struct.new $type32
               (struct.get $type32 0
                (local.get $4)
               )
               (local.get $13)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.tee $4
                (struct.get $type32 1
                 (local.get $4)
                )
               )
              )
              (then
               (local.get $13)
              )
              (else
               (local.set $13
                (struct.new $type32
                 (struct.get $type32 0
                  (local.get $4)
                 )
                 (local.get $13)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.tee $4
                  (struct.get $type32 1
                   (local.get $4)
                  )
                 )
                )
                (then
                 (local.get $13)
                )
                (else
                 (local.set $13
                  (struct.new $type32
                   (struct.get $type32 0
                    (local.get $4)
                   )
                   (local.get $13)
                  )
                 )
                 (if (result (ref null $type32))
                  (ref.is_null
                   (local.tee $4
                    (struct.get $type32 1
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (local.get $13)
                  )
                  (else
                   (local.set $13
                    (struct.new $type32
                     (struct.get $type32 0
                      (local.get $4)
                     )
                     (local.get $13)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.tee $4
                      (struct.get $type32 1
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (local.get $13)
                    )
                    (else
                     (local.set $13
                      (struct.new $type32
                       (struct.get $type32 0
                        (local.get $4)
                       )
                       (local.get $13)
                      )
                     )
                     (if (result (ref null $type32))
                      (ref.is_null
                       (local.tee $4
                        (struct.get $type32 1
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (local.get $13)
                      )
                      (else
                       (local.set $13
                        (struct.new $type32
                         (struct.get $type32 0
                          (local.get $4)
                         )
                         (local.get $13)
                        )
                       )
                       (if (result (ref null $type32))
                        (ref.is_null
                         (local.tee $4
                          (struct.get $type32 1
                           (local.get $4)
                          )
                         )
                        )
                        (then
                         (local.get $13)
                        )
                        (else
                         (call $function92
                          (i32.const 0)
                          (i32.const 1)
                          (struct.get $type32 1
                           (local.get $4)
                          )
                          (struct.new $type32
                           (struct.get $type32 0
                            (local.get $4)
                           )
                           (local.get $13)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (struct.get $type77 0
        (local.get $1)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function88
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (i32.const 0)
       (i32.const 1)
       (local.get $10)
       (struct.get $type32 0
        (local.get $4)
       )
       (local.get $11)
       (ref.null none)
       (ref.null none)
      )
     )
    )
    (unreachable)
   )
   (else
    (if (result i32)
     (local.tee $14
      (i64.eq
       (struct.get $type30 0
        (local.get $11)
       )
       (i64.const 1)
      )
     )
     (then
      (local.get $14)
     )
     (else
      (local.set $11
       (struct.get $type30 1
        (local.get $11)
       )
      )
      (local.set $12
       (struct.get $type30 1
        (local.get $12)
       )
      )
      (if
       (i32.eqz
        (local.get $9)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function89
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $11)
       (local.get $12)
      )
     )
    )
   )
  )
 )
 (func $function91 (type $call55) (param $0 (ref null $environment98)) (param $1 (ref null $type32)) (result (ref null $type32))
  (local $2 (ref $type32))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $2
     (struct.new $type32
      (struct.get $type32 0
       (local.get $1)
      )
      (ref.null none)
     )
    )
    (if (result (ref $type32))
     (ref.is_null
      (local.tee $1
       (struct.get $type32 1
        (local.get $1)
       )
      )
     )
     (then
      (local.get $2)
     )
     (else
      (local.set $2
       (struct.new $type32
        (struct.get $type32 0
         (local.get $1)
        )
        (local.get $2)
       )
      )
      (if (result (ref $type32))
       (ref.is_null
        (local.tee $1
         (struct.get $type32 1
          (local.get $1)
         )
        )
       )
       (then
        (local.get $2)
       )
       (else
        (local.set $2
         (struct.new $type32
          (struct.get $type32 0
           (local.get $1)
          )
          (local.get $2)
         )
        )
        (if (result (ref $type32))
         (ref.is_null
          (local.tee $1
           (struct.get $type32 1
            (local.get $1)
           )
          )
         )
         (then
          (local.get $2)
         )
         (else
          (local.set $2
           (struct.new $type32
            (struct.get $type32 0
             (local.get $1)
            )
            (local.get $2)
           )
          )
          (if (result (ref $type32))
           (ref.is_null
            (local.tee $1
             (struct.get $type32 1
              (local.get $1)
             )
            )
           )
           (then
            (local.get $2)
           )
           (else
            (local.set $2
             (struct.new $type32
              (struct.get $type32 0
               (local.get $1)
              )
              (local.get $2)
             )
            )
            (if (result (ref $type32))
             (ref.is_null
              (local.tee $1
               (struct.get $type32 1
                (local.get $1)
               )
              )
             )
             (then
              (local.get $2)
             )
             (else
              (local.set $2
               (struct.new $type32
                (struct.get $type32 0
                 (local.get $1)
                )
                (local.get $2)
               )
              )
              (if (result (ref $type32))
               (ref.is_null
                (local.tee $1
                 (struct.get $type32 1
                  (local.get $1)
                 )
                )
               )
               (then
                (local.get $2)
               )
               (else
                (local.set $2
                 (struct.new $type32
                  (struct.get $type32 0
                   (local.get $1)
                  )
                  (local.get $2)
                 )
                )
                (if (result (ref $type32))
                 (ref.is_null
                  (local.tee $1
                   (struct.get $type32 1
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (local.set $2
                   (struct.new $type32
                    (struct.get $type32 0
                     (local.get $1)
                    )
                    (local.get $2)
                   )
                  )
                  (if (result (ref $type32))
                   (ref.is_null
                    (local.tee $1
                     (struct.get $type32 1
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (return_call $function92
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type32 1
                      (local.get $1)
                     )
                     (struct.new $type32
                      (struct.get $type32 0
                       (local.get $1)
                      )
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function92 (type $67) (param $0 i32) (param $1 i32) (param $2 (ref null $type32)) (param $3 (ref $type32)) (result (ref null $type32))
  (local $4 (ref null $type32))
  (local $5 (ref null $type30))
  (if (result (ref $type32))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type32 1
      (local.get $2)
     )
    )
    (local.set $5
     (struct.get $type32 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function92
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (struct.new $type32
      (local.get $5)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function93 (type $call77) (param $0 structref) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref $environment93))
  (local $3 (ref $type35))
  (local $4 (ref $type39))
  (local $5 (ref null $type32))
  (local.set $3
   (struct.get $environment93 3
    (ref.cast (ref $environment93)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready211)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global211)
   )
  )
  (if
   (ref.test (ref $type36)
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type39 0
     (local.tee $4
      (call $function64
       (struct.get $type38 0
        (struct.get $type37 0
         (ref.cast (ref $type37)
          (local.get $3)
         )
        )
       )
       (i64.const 2)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type32 1
    (struct.get $environment93 4
     (local.tee $2
      (ref.cast (ref $environment93)
       (local.get $0)
      )
     )
    )
   )
  )
  (return_call $function84
   (struct.get $environment93 0
    (local.get $2)
   )
   (struct.get $environment93 1
    (local.get $2)
   )
   (struct.get $environment93 2
    (local.get $2)
   )
   (struct.get $type41 1
    (ref.cast (ref $type41)
     (local.get $4)
    )
   )
   (local.get $5)
   (local.get $1)
  )
 )
 (func $function95 (type $66) (param $0 i64) (param $1 (ref $type33)) (result (ref $type12))
  (local $2 (ref $type12))
  (local $3 (ref $type12))
  (local $4 i32)
  (if
   (i32.eqz
    (global.get $ready218)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global218)
   )
  )
  (local.set $3
   (if (result (ref $type12))
    (if (result i32)
     (local.tee $4
      (i64.lt_s
       (local.get $0)
       (i64.const 0)
      )
     )
     (then
      (local.get $4)
     )
     (else
      (i64.gt_s
       (local.get $0)
       (i64.const 4294967295)
      )
     )
    )
    (then
     (unreachable)
    )
    (else
     (if (result (ref $type12))
      (i64.eqz
       (local.get $0)
      )
      (then
       (array.new_fixed $type12 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready55)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global55)
        )
       )
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (array.new_default $type12
         (i32.wrap_i64
          (local.get $0)
         )
        )
       )
       (if (result (ref $type12))
        (i64.eq
         (local.get $0)
         (i64.const 1)
        )
        (then
         (local.get $2)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready55)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global55)
          )
         )
         (array.set $type12
          (local.get $2)
          (i32.const 1)
          (i64.const 0)
         )
         (if (result (ref $type12))
          (i64.eq
           (local.get $0)
           (i64.const 2)
          )
          (then
           (local.get $2)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready55)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global55)
            )
           )
           (array.set $type12
            (local.get $2)
            (i32.const 2)
            (i64.const 0)
           )
           (if (result (ref $type12))
            (i64.eq
             (local.get $0)
             (i64.const 3)
            )
            (then
             (local.get $2)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready55)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global55)
              )
             )
             (array.set $type12
              (local.get $2)
              (i32.const 3)
              (i64.const 0)
             )
             (if (result (ref $type12))
              (i64.eq
               (local.get $0)
               (i64.const 4)
              )
              (then
               (local.get $2)
              )
              (else
               (if
                (i32.eqz
                 (global.get $ready55)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global55)
                )
               )
               (array.set $type12
                (local.get $2)
                (i32.const 4)
                (i64.const 0)
               )
               (if (result (ref $type12))
                (i64.eq
                 (local.get $0)
                 (i64.const 5)
                )
                (then
                 (local.get $2)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready55)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global55)
                  )
                 )
                 (array.set $type12
                  (local.get $2)
                  (i32.const 5)
                  (i64.const 0)
                 )
                 (if (result (ref $type12))
                  (i64.eq
                   (local.get $0)
                   (i64.const 6)
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready55)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global55)
                    )
                   )
                   (array.set $type12
                    (local.get $2)
                    (i32.const 6)
                    (i64.const 0)
                   )
                   (if (result (ref $type12))
                    (i64.eq
                     (local.get $0)
                     (i64.const 7)
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (if
                      (i32.eqz
                       (global.get $ready55)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global55)
                      )
                     )
                     (array.set $type12
                      (local.get $2)
                      (i32.const 7)
                      (i64.const 0)
                     )
                     (if (result (ref $type12))
                      (i64.eq
                       (local.get $0)
                       (i64.const 8)
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready55)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global55)
                        )
                       )
                       (array.set $type12
                        (local.get $2)
                        (i32.const 8)
                        (i64.const 0)
                       )
                       (if (result (ref $type12))
                        (i64.eq
                         (local.get $0)
                         (i64.const 9)
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready55)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global55)
                          )
                         )
                         (array.set $type12
                          (local.get $2)
                          (i32.const 9)
                          (i64.const 0)
                         )
                         (call $function77
                          (local.get $0)
                          (local.get $2)
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 10)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (if (result i32)
    (i64.eqz
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (array.set $type12
      (local.get $3)
      (i32.const 0)
      (call_ref $call33
       (struct.get $type33 1
        (local.get $1)
       )
       (i64.const 0)
       (struct.get $type33 0
        (local.get $1)
       )
      )
     )
     (if (result i32)
      (i64.eq
       (local.get $0)
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (array.set $type12
        (local.get $3)
        (i32.const 1)
        (call_ref $call33
         (struct.get $type33 1
          (local.get $1)
         )
         (i64.const 1)
         (struct.get $type33 0
          (local.get $1)
         )
        )
       )
       (if (result i32)
        (i64.eq
         (local.get $0)
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (array.set $type12
          (local.get $3)
          (i32.const 2)
          (call_ref $call33
           (struct.get $type33 1
            (local.get $1)
           )
           (i64.const 2)
           (struct.get $type33 0
            (local.get $1)
           )
          )
         )
         (if (result i32)
          (i64.eq
           (local.get $0)
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (array.set $type12
            (local.get $3)
            (i32.const 3)
            (call_ref $call33
             (struct.get $type33 1
              (local.get $1)
             )
             (i64.const 3)
             (struct.get $type33 0
              (local.get $1)
             )
            )
           )
           (if (result i32)
            (i64.eq
             (local.get $0)
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (array.set $type12
              (local.get $3)
              (i32.const 4)
              (call_ref $call33
               (struct.get $type33 1
                (local.get $1)
               )
               (i64.const 4)
               (struct.get $type33 0
                (local.get $1)
               )
              )
             )
             (if (result i32)
              (i64.eq
               (local.get $0)
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (array.set $type12
                (local.get $3)
                (i32.const 5)
                (call_ref $call33
                 (struct.get $type33 1
                  (local.get $1)
                 )
                 (i64.const 5)
                 (struct.get $type33 0
                  (local.get $1)
                 )
                )
               )
               (if (result i32)
                (i64.eq
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (array.set $type12
                  (local.get $3)
                  (i32.const 6)
                  (call_ref $call33
                   (struct.get $type33 1
                    (local.get $1)
                   )
                   (i64.const 6)
                   (struct.get $type33 0
                    (local.get $1)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (array.set $type12
                    (local.get $3)
                    (i32.const 7)
                    (call_ref $call33
                     (struct.get $type33 1
                      (local.get $1)
                     )
                     (i64.const 7)
                     (struct.get $type33 0
                      (local.get $1)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (array.set $type12
                      (local.get $3)
                      (i32.const 8)
                      (call_ref $call33
                       (struct.get $type33 1
                        (local.get $1)
                       )
                       (i64.const 8)
                       (struct.get $type33 0
                        (local.get $1)
                       )
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (local.get $0)
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (array.set $type12
                        (local.get $3)
                        (i32.const 9)
                        (call_ref $call33
                         (struct.get $type33 1
                          (local.get $1)
                         )
                         (i64.const 9)
                         (struct.get $type33 0
                          (local.get $1)
                         )
                        )
                       )
                       (call $function96
                        (local.get $0)
                        (local.get $1)
                        (local.get $3)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 10)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $3)
 )
 (func $function96 (type $65) (param $0 i64) (param $1 (ref $type33)) (param $2 (ref $type12)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $6
     (call_ref $call33
      (struct.get $type33 1
       (local.get $1)
      )
      (local.get $5)
      (struct.get $type33 0
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $2)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function96
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function98 (type $call55) (param $0 (ref null $environment98)) (param $1 (ref null $type32)) (result (ref null $type32))
  (local $2 (ref $environment98))
  (local $3 (ref $type61))
  (local $4 (ref $type60))
  (local $5 (ref $type60))
  (local $6 (ref $type33))
  (local $7 (ref $type33))
  (local $8 i32)
  (local.set $2
   (ref.as_non_null
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $environment98 2
    (local.get $2)
   )
  )
  (local.set $4
   (struct.get $environment98 3
    (local.get $2)
   )
  )
  (local.set $6
   (struct.get $environment98 4
    (local.get $2)
   )
  )
  (local.set $5
   (struct.get $environment98 5
    (local.get $2)
   )
  )
  (local.set $7
   (struct.get $environment98 6
    (local.get $2)
   )
  )
  (if (result nullref)
   (if (result i32)
    (local.tee $8
     (ref.is_null
      (local.get $1)
     )
    )
    (then
     (local.get $8)
    )
    (else
     (ref.is_null
      (struct.get $type32 0
       (local.get $1)
      )
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (return_call $function100
     (i64.const 0)
     (i64.const 1)
     (local.get $3)
     (local.get $4)
     (local.get $6)
     (local.get $5)
     (local.get $7)
     (i32.const 0)
     (i32.const 1)
     (i32.const 0)
     (i32.const 1)
     (local.get $1)
     (ref.null none)
    )
   )
  )
 )
 (func $function100 (type $63) (param $0 i64) (param $1 i64) (param $2 (ref $type61)) (param $3 (ref $type60)) (param $4 (ref $type33)) (param $5 (ref $type60)) (param $6 (ref $type33)) (param $7 i32) (param $8 i32) (param $9 i32) (param $10 i32) (param $11 (ref null $type32)) (param $12 (ref null $type32)) (result (ref null $type32))
  (local $13 (ref null $type30))
  (local $14 (ref null $type30))
  (local $15 (ref $type57))
  (local $16 (ref $type33))
  (local $17 (ref $type84))
  (local $18 (ref null $type32))
  (local $19 (ref null $type32))
  (local $20 i64)
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $11)
   )
   (then
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (if (result (ref null $type32))
      (if (result i32)
       (local.tee $9
        (ref.is_null
         (local.get $12)
        )
       )
       (then
        (local.get $9)
       )
       (else
        (ref.is_null
         (struct.get $type32 0
          (local.get $12)
         )
        )
       )
      )
      (then
       (ref.null none)
      )
      (else
       (call $function100
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (local.get $7)
        (local.get $8)
        (i32.const 0)
        (i32.const 1)
        (local.get $12)
        (ref.null none)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready305)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global305)
     )
    )
    (if (result (ref null $type32))
     (ref.is_null
      (local.get $11)
     )
     (then
      (ref.null none)
     )
     (else
      (struct.new $type32
       (call_ref $call57
        (struct.get $type57 1
         (local.tee $15
          (struct.new $type57
           (ref.func $function101)
           (struct.new $environment101
            (local.get $0)
           )
          )
         )
        )
        (struct.get $type32 0
         (local.get $11)
        )
        (struct.get $type57 0
         (local.get $15)
        )
       )
       (block (result (ref null $type32))
        (local.set $11
         (struct.get $type32 1
          (local.get $11)
         )
        )
        (if
         (i32.eqz
          (global.get $ready305)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global305)
         )
        )
        (if (result (ref null $type32))
         (ref.is_null
          (local.get $11)
         )
         (then
          (ref.null none)
         )
         (else
          (struct.new $type32
           (call_ref $call57
            (struct.get $type57 1
             (local.get $15)
            )
            (struct.get $type32 0
             (local.get $11)
            )
            (struct.get $type57 0
             (local.get $15)
            )
           )
           (block (result (ref null $type32))
            (local.set $11
             (struct.get $type32 1
              (local.get $11)
             )
            )
            (if
             (i32.eqz
              (global.get $ready305)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global305)
             )
            )
            (if (result (ref null $type32))
             (ref.is_null
              (local.get $11)
             )
             (then
              (ref.null none)
             )
             (else
              (struct.new $type32
               (call_ref $call57
                (struct.get $type57 1
                 (local.get $15)
                )
                (struct.get $type32 0
                 (local.get $11)
                )
                (struct.get $type57 0
                 (local.get $15)
                )
               )
               (block (result (ref null $type32))
                (local.set $11
                 (struct.get $type32 1
                  (local.get $11)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready305)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global305)
                 )
                )
                (if (result (ref null $type32))
                 (ref.is_null
                  (local.get $11)
                 )
                 (then
                  (ref.null none)
                 )
                 (else
                  (struct.new $type32
                   (call_ref $call57
                    (struct.get $type57 1
                     (local.get $15)
                    )
                    (struct.get $type32 0
                     (local.get $11)
                    )
                    (struct.get $type57 0
                     (local.get $15)
                    )
                   )
                   (block (result (ref null $type32))
                    (local.set $11
                     (struct.get $type32 1
                      (local.get $11)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready305)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global305)
                     )
                    )
                    (if (result (ref null $type32))
                     (ref.is_null
                      (local.get $11)
                     )
                     (then
                      (ref.null none)
                     )
                     (else
                      (struct.new $type32
                       (call_ref $call57
                        (struct.get $type57 1
                         (local.get $15)
                        )
                        (struct.get $type32 0
                         (local.get $11)
                        )
                        (struct.get $type57 0
                         (local.get $15)
                        )
                       )
                       (block (result (ref null $type32))
                        (local.set $11
                         (struct.get $type32 1
                          (local.get $11)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready305)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global305)
                         )
                        )
                        (if (result (ref null $type32))
                         (ref.is_null
                          (local.get $11)
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (struct.new $type32
                           (call_ref $call57
                            (struct.get $type57 1
                             (local.get $15)
                            )
                            (struct.get $type32 0
                             (local.get $11)
                            )
                            (struct.get $type57 0
                             (local.get $15)
                            )
                           )
                           (block (result (ref null $type32))
                            (local.set $11
                             (struct.get $type32 1
                              (local.get $11)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready305)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global305)
                             )
                            )
                            (if (result (ref null $type32))
                             (ref.is_null
                              (local.get $11)
                             )
                             (then
                              (ref.null none)
                             )
                             (else
                              (struct.new $type32
                               (call_ref $call57
                                (struct.get $type57 1
                                 (local.get $15)
                                )
                                (struct.get $type32 0
                                 (local.get $11)
                                )
                                (struct.get $type57 0
                                 (local.get $15)
                                )
                               )
                               (block (result (ref null $type32))
                                (local.set $11
                                 (struct.get $type32 1
                                  (local.get $11)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready305)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global305)
                                 )
                                )
                                (if (result (ref null $type32))
                                 (ref.is_null
                                  (local.get $11)
                                 )
                                 (then
                                  (ref.null none)
                                 )
                                 (else
                                  (struct.new $type32
                                   (call_ref $call57
                                    (struct.get $type57 1
                                     (local.get $15)
                                    )
                                    (struct.get $type32 0
                                     (local.get $11)
                                    )
                                    (struct.get $type57 0
                                     (local.get $15)
                                    )
                                   )
                                   (block (result (ref null $type32))
                                    (local.set $11
                                     (struct.get $type32 1
                                      (local.get $11)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready305)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global305)
                                     )
                                    )
                                    (if (result (ref null $type32))
                                     (ref.is_null
                                      (local.get $11)
                                     )
                                     (then
                                      (ref.null none)
                                     )
                                     (else
                                      (struct.new $type32
                                       (call_ref $call57
                                        (struct.get $type57 1
                                         (local.get $15)
                                        )
                                        (struct.get $type32 0
                                         (local.get $11)
                                        )
                                        (struct.get $type57 0
                                         (local.get $15)
                                        )
                                       )
                                       (block (result (ref null $type32))
                                        (local.set $11
                                         (struct.get $type32 1
                                          (local.get $11)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready305)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global305)
                                         )
                                        )
                                        (if (result (ref null $type32))
                                         (ref.is_null
                                          (local.get $11)
                                         )
                                         (then
                                          (ref.null none)
                                         )
                                         (else
                                          (struct.new $type32
                                           (call_ref $call57
                                            (struct.get $type57 1
                                             (local.get $15)
                                            )
                                            (struct.get $type32 0
                                             (local.get $11)
                                            )
                                            (struct.get $type57 0
                                             (local.get $15)
                                            )
                                           )
                                           (block (result (ref null $type32))
                                            (local.set $11
                                             (struct.get $type32 1
                                              (local.get $11)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready305)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global305)
                                             )
                                            )
                                            (call $function102
                                             (local.get $15)
                                             (local.get $11)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (local.set $20
     (struct.get $type30 0
      (local.tee $13
       (struct.get $type32 0
        (local.get $11)
       )
      )
     )
    )
    (local.set $13
     (struct.get $type30 1
      (local.get $13)
     )
    )
    (local.set $11
     (struct.get $type32 1
      (local.get $11)
     )
    )
    (if (result (ref $type32))
     (call_ref $call61
      (struct.get $type61 1
       (local.get $2)
      )
      (local.get $20)
      (struct.get $type61 0
       (local.get $2)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $10)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function100
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $11)
       (struct.new $type32
        (local.get $13)
        (local.get $12)
       )
      )
     )
     (else
      (local.set $20
       (call_ref $call33
        (struct.get $type33 1
         (local.get $6)
        )
        (local.get $20)
        (struct.get $type33 0
         (local.get $6)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready316)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global316)
       )
      )
      (local.set $14
       (if (result (ref null $type30))
        (ref.is_null
         (local.get $13)
        )
        (then
         (ref.null none)
        )
        (else
         (struct.new $type30
          (call_ref $call33
           (struct.get $type33 1
            (local.tee $16
             (struct.new $type33
              (ref.func $function103)
              (struct.new $environment103
               (local.get $5)
               (local.get $20)
              )
             )
            )
           )
           (struct.get $type30 0
            (local.get $13)
           )
           (struct.get $type33 0
            (local.get $16)
           )
          )
          (block (result (ref null $type30))
           (local.set $13
            (struct.get $type30 1
             (local.get $13)
            )
           )
           (if
            (i32.eqz
             (global.get $ready316)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global316)
            )
           )
           (if (result (ref null $type30))
            (ref.is_null
             (local.get $13)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type30
              (call_ref $call33
               (struct.get $type33 1
                (local.get $16)
               )
               (struct.get $type30 0
                (local.get $13)
               )
               (struct.get $type33 0
                (local.get $16)
               )
              )
              (block (result (ref null $type30))
               (local.set $13
                (struct.get $type30 1
                 (local.get $13)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready316)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global316)
                )
               )
               (if (result (ref null $type30))
                (ref.is_null
                 (local.get $13)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type30
                  (call_ref $call33
                   (struct.get $type33 1
                    (local.get $16)
                   )
                   (struct.get $type30 0
                    (local.get $13)
                   )
                   (struct.get $type33 0
                    (local.get $16)
                   )
                  )
                  (block (result (ref null $type30))
                   (local.set $13
                    (struct.get $type30 1
                     (local.get $13)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready316)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global316)
                    )
                   )
                   (if (result (ref null $type30))
                    (ref.is_null
                     (local.get $13)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type30
                      (call_ref $call33
                       (struct.get $type33 1
                        (local.get $16)
                       )
                       (struct.get $type30 0
                        (local.get $13)
                       )
                       (struct.get $type33 0
                        (local.get $16)
                       )
                      )
                      (block (result (ref null $type30))
                       (local.set $13
                        (struct.get $type30 1
                         (local.get $13)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready316)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global316)
                        )
                       )
                       (if (result (ref null $type30))
                        (ref.is_null
                         (local.get $13)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type30
                          (call_ref $call33
                           (struct.get $type33 1
                            (local.get $16)
                           )
                           (struct.get $type30 0
                            (local.get $13)
                           )
                           (struct.get $type33 0
                            (local.get $16)
                           )
                          )
                          (block (result (ref null $type30))
                           (local.set $13
                            (struct.get $type30 1
                             (local.get $13)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready316)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global316)
                            )
                           )
                           (if (result (ref null $type30))
                            (ref.is_null
                             (local.get $13)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type30
                              (call_ref $call33
                               (struct.get $type33 1
                                (local.get $16)
                               )
                               (struct.get $type30 0
                                (local.get $13)
                               )
                               (struct.get $type33 0
                                (local.get $16)
                               )
                              )
                              (block (result (ref null $type30))
                               (local.set $13
                                (struct.get $type30 1
                                 (local.get $13)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready316)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global316)
                                )
                               )
                               (if (result (ref null $type30))
                                (ref.is_null
                                 (local.get $13)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type30
                                  (call_ref $call33
                                   (struct.get $type33 1
                                    (local.get $16)
                                   )
                                   (struct.get $type30 0
                                    (local.get $13)
                                   )
                                   (struct.get $type33 0
                                    (local.get $16)
                                   )
                                  )
                                  (block (result (ref null $type30))
                                   (local.set $13
                                    (struct.get $type30 1
                                     (local.get $13)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready316)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global316)
                                    )
                                   )
                                   (if (result (ref null $type30))
                                    (ref.is_null
                                     (local.get $13)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type30
                                      (call_ref $call33
                                       (struct.get $type33 1
                                        (local.get $16)
                                       )
                                       (struct.get $type30 0
                                        (local.get $13)
                                       )
                                       (struct.get $type33 0
                                        (local.get $16)
                                       )
                                      )
                                      (block (result (ref null $type30))
                                       (local.set $13
                                        (struct.get $type30 1
                                         (local.get $13)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready316)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global316)
                                        )
                                       )
                                       (if (result (ref null $type30))
                                        (ref.is_null
                                         (local.get $13)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type30
                                          (call_ref $call33
                                           (struct.get $type33 1
                                            (local.get $16)
                                           )
                                           (struct.get $type30 0
                                            (local.get $13)
                                           )
                                           (struct.get $type33 0
                                            (local.get $16)
                                           )
                                          )
                                          (block (result (ref null $type30))
                                           (local.set $13
                                            (struct.get $type30 1
                                             (local.get $13)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready316)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global316)
                                            )
                                           )
                                           (if (result (ref null $type30))
                                            (ref.is_null
                                             (local.get $13)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type30
                                              (call_ref $call33
                                               (struct.get $type33 1
                                                (local.get $16)
                                               )
                                               (struct.get $type30 0
                                                (local.get $13)
                                               )
                                               (struct.get $type33 0
                                                (local.get $16)
                                               )
                                              )
                                              (block (result (ref null $type30))
                                               (local.set $13
                                                (struct.get $type30 1
                                                 (local.get $13)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready316)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global316)
                                                )
                                               )
                                               (call $function104
                                                (local.get $16)
                                                (local.get $13)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready184)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global184)
       )
      )
      (local.set $11
       (if (result (ref null $type32))
        (ref.is_null
         (local.get $11)
        )
        (then
         (local.get $12)
        )
        (else
         (local.set $18
          (struct.get $type32 1
           (local.get $11)
          )
         )
         (local.set $11
          (call_ref $call84
           (struct.get $type84 1
            (local.tee $17
             (struct.new $type84
              (ref.func $function106)
              (struct.new $environment106
               (local.get $2)
               (local.get $3)
               (local.get $4)
               (local.get $5)
               (local.get $14)
              )
             )
            )
           )
           (struct.get $type32 0
            (local.get $11)
           )
           (local.get $12)
           (struct.get $type84 0
            (local.get $17)
           )
          )
         )
         (if (result (ref null $type32))
          (ref.is_null
           (local.get $18)
          )
          (then
           (local.get $11)
          )
          (else
           (local.set $19
            (struct.get $type32 1
             (local.get $18)
            )
           )
           (local.set $11
            (call_ref $call84
             (struct.get $type84 1
              (local.get $17)
             )
             (struct.get $type32 0
              (local.get $18)
             )
             (local.get $11)
             (struct.get $type84 0
              (local.get $17)
             )
            )
           )
           (if (result (ref null $type32))
            (ref.is_null
             (local.get $19)
            )
            (then
             (local.get $11)
            )
            (else
             (local.set $18
              (struct.get $type32 1
               (local.get $19)
              )
             )
             (local.set $11
              (call_ref $call84
               (struct.get $type84 1
                (local.get $17)
               )
               (struct.get $type32 0
                (local.get $19)
               )
               (local.get $11)
               (struct.get $type84 0
                (local.get $17)
               )
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.get $18)
              )
              (then
               (local.get $11)
              )
              (else
               (local.set $19
                (struct.get $type32 1
                 (local.get $18)
                )
               )
               (local.set $11
                (call_ref $call84
                 (struct.get $type84 1
                  (local.get $17)
                 )
                 (struct.get $type32 0
                  (local.get $18)
                 )
                 (local.get $11)
                 (struct.get $type84 0
                  (local.get $17)
                 )
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.get $19)
                )
                (then
                 (local.get $11)
                )
                (else
                 (local.set $18
                  (struct.get $type32 1
                   (local.get $19)
                  )
                 )
                 (local.set $11
                  (call_ref $call84
                   (struct.get $type84 1
                    (local.get $17)
                   )
                   (struct.get $type32 0
                    (local.get $19)
                   )
                   (local.get $11)
                   (struct.get $type84 0
                    (local.get $17)
                   )
                  )
                 )
                 (if (result (ref null $type32))
                  (ref.is_null
                   (local.get $18)
                  )
                  (then
                   (local.get $11)
                  )
                  (else
                   (local.set $19
                    (struct.get $type32 1
                     (local.get $18)
                    )
                   )
                   (local.set $11
                    (call_ref $call84
                     (struct.get $type84 1
                      (local.get $17)
                     )
                     (struct.get $type32 0
                      (local.get $18)
                     )
                     (local.get $11)
                     (struct.get $type84 0
                      (local.get $17)
                     )
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.get $19)
                    )
                    (then
                     (local.get $11)
                    )
                    (else
                     (local.set $18
                      (struct.get $type32 1
                       (local.get $19)
                      )
                     )
                     (local.set $11
                      (call_ref $call84
                       (struct.get $type84 1
                        (local.get $17)
                       )
                       (struct.get $type32 0
                        (local.get $19)
                       )
                       (local.get $11)
                       (struct.get $type84 0
                        (local.get $17)
                       )
                      )
                     )
                     (if (result (ref null $type32))
                      (ref.is_null
                       (local.get $18)
                      )
                      (then
                       (local.get $11)
                      )
                      (else
                       (local.set $19
                        (struct.get $type32 1
                         (local.get $18)
                        )
                       )
                       (local.set $11
                        (call_ref $call84
                         (struct.get $type84 1
                          (local.get $17)
                         )
                         (struct.get $type32 0
                          (local.get $18)
                         )
                         (local.get $11)
                         (struct.get $type84 0
                          (local.get $17)
                         )
                        )
                       )
                       (if (result (ref null $type32))
                        (ref.is_null
                         (local.get $19)
                        )
                        (then
                         (local.get $11)
                        )
                        (else
                         (call $function66
                          (local.get $17)
                          (i32.const 0)
                          (i32.const 1)
                          (struct.get $type32 1
                           (local.get $19)
                          )
                          (call_ref $call84
                           (struct.get $type84 1
                            (local.get $17)
                           )
                           (struct.get $type32 0
                            (local.get $19)
                           )
                           (local.get $11)
                           (struct.get $type84 0
                            (local.get $17)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $8)
       )
       (then
        (unreachable)
       )
      )
      (local.set $11
       (if (result (ref null $type32))
        (if (result i32)
         (local.tee $9
          (ref.is_null
           (local.get $11)
          )
         )
         (then
          (local.get $9)
         )
         (else
          (ref.is_null
           (struct.get $type32 0
            (local.get $11)
           )
          )
         )
        )
        (then
         (ref.null none)
        )
        (else
         (call $function100
          (local.get $0)
          (local.get $1)
          (local.get $2)
          (local.get $3)
          (local.get $4)
          (local.get $5)
          (local.get $6)
          (local.get $7)
          (local.get $8)
          (i32.const 0)
          (i32.const 1)
          (local.get $11)
          (ref.null none)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready305)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global305)
       )
      )
      (struct.new $type32
       (struct.new $type30
        (local.get $1)
        (local.get $14)
       )
       (if (result (ref null $type32))
        (ref.is_null
         (local.get $11)
        )
        (then
         (ref.null none)
        )
        (else
         (struct.new $type32
          (call_ref $call57
           (struct.get $type57 1
            (local.tee $15
             (struct.new $type57
              (ref.func $function105)
              (struct.new $environment105
               (local.get $0)
              )
             )
            )
           )
           (struct.get $type32 0
            (local.get $11)
           )
           (struct.get $type57 0
            (local.get $15)
           )
          )
          (block (result (ref null $type32))
           (local.set $11
            (struct.get $type32 1
             (local.get $11)
            )
           )
           (if
            (i32.eqz
             (global.get $ready305)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global305)
            )
           )
           (if (result (ref null $type32))
            (ref.is_null
             (local.get $11)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type32
              (call_ref $call57
               (struct.get $type57 1
                (local.get $15)
               )
               (struct.get $type32 0
                (local.get $11)
               )
               (struct.get $type57 0
                (local.get $15)
               )
              )
              (block (result (ref null $type32))
               (local.set $11
                (struct.get $type32 1
                 (local.get $11)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready305)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global305)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.get $11)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type32
                  (call_ref $call57
                   (struct.get $type57 1
                    (local.get $15)
                   )
                   (struct.get $type32 0
                    (local.get $11)
                   )
                   (struct.get $type57 0
                    (local.get $15)
                   )
                  )
                  (block (result (ref null $type32))
                   (local.set $11
                    (struct.get $type32 1
                     (local.get $11)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready305)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global305)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.get $11)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type32
                      (call_ref $call57
                       (struct.get $type57 1
                        (local.get $15)
                       )
                       (struct.get $type32 0
                        (local.get $11)
                       )
                       (struct.get $type57 0
                        (local.get $15)
                       )
                      )
                      (block (result (ref null $type32))
                       (local.set $11
                        (struct.get $type32 1
                         (local.get $11)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready305)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global305)
                        )
                       )
                       (if (result (ref null $type32))
                        (ref.is_null
                         (local.get $11)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type32
                          (call_ref $call57
                           (struct.get $type57 1
                            (local.get $15)
                           )
                           (struct.get $type32 0
                            (local.get $11)
                           )
                           (struct.get $type57 0
                            (local.get $15)
                           )
                          )
                          (block (result (ref null $type32))
                           (local.set $11
                            (struct.get $type32 1
                             (local.get $11)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready305)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global305)
                            )
                           )
                           (if (result (ref null $type32))
                            (ref.is_null
                             (local.get $11)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type32
                              (call_ref $call57
                               (struct.get $type57 1
                                (local.get $15)
                               )
                               (struct.get $type32 0
                                (local.get $11)
                               )
                               (struct.get $type57 0
                                (local.get $15)
                               )
                              )
                              (block (result (ref null $type32))
                               (local.set $11
                                (struct.get $type32 1
                                 (local.get $11)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready305)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global305)
                                )
                               )
                               (if (result (ref null $type32))
                                (ref.is_null
                                 (local.get $11)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type32
                                  (call_ref $call57
                                   (struct.get $type57 1
                                    (local.get $15)
                                   )
                                   (struct.get $type32 0
                                    (local.get $11)
                                   )
                                   (struct.get $type57 0
                                    (local.get $15)
                                   )
                                  )
                                  (block (result (ref null $type32))
                                   (local.set $11
                                    (struct.get $type32 1
                                     (local.get $11)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready305)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global305)
                                    )
                                   )
                                   (if (result (ref null $type32))
                                    (ref.is_null
                                     (local.get $11)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type32
                                      (call_ref $call57
                                       (struct.get $type57 1
                                        (local.get $15)
                                       )
                                       (struct.get $type32 0
                                        (local.get $11)
                                       )
                                       (struct.get $type57 0
                                        (local.get $15)
                                       )
                                      )
                                      (block (result (ref null $type32))
                                       (local.set $11
                                        (struct.get $type32 1
                                         (local.get $11)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready305)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global305)
                                        )
                                       )
                                       (if (result (ref null $type32))
                                        (ref.is_null
                                         (local.get $11)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type32
                                          (call_ref $call57
                                           (struct.get $type57 1
                                            (local.get $15)
                                           )
                                           (struct.get $type32 0
                                            (local.get $11)
                                           )
                                           (struct.get $type57 0
                                            (local.get $15)
                                           )
                                          )
                                          (block (result (ref null $type32))
                                           (local.set $11
                                            (struct.get $type32 1
                                             (local.get $11)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready305)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global305)
                                            )
                                           )
                                           (if (result (ref null $type32))
                                            (ref.is_null
                                             (local.get $11)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type32
                                              (call_ref $call57
                                               (struct.get $type57 1
                                                (local.get $15)
                                               )
                                               (struct.get $type32 0
                                                (local.get $11)
                                               )
                                               (struct.get $type57 0
                                                (local.get $15)
                                               )
                                              )
                                              (block (result (ref null $type32))
                                               (local.set $11
                                                (struct.get $type32 1
                                                 (local.get $11)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready305)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global305)
                                                )
                                               )
                                               (call $function102
                                                (local.get $15)
                                                (local.get $11)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function101 (type $call57) (param $0 structref) (param $1 (ref null $type30)) (result (ref null $type30))
  (struct.new $type30
   (struct.get $environment101 0
    (ref.cast (ref $environment101)
     (local.get $0)
    )
   )
   (local.get $1)
  )
 )
 (func $function102 (type $call56) (param $0 (ref $type57)) (param $1 (ref null $type32)) (result (ref null $type32))
  (local $2 (ref null $type30))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type32
     (call_ref $call57
      (struct.get $type57 1
       (local.get $0)
      )
      (struct.get $type32 0
       (local.get $1)
      )
      (struct.get $type57 0
       (local.get $0)
      )
     )
     (block (result (ref null $type32))
      (local.set $1
       (struct.get $type32 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready305)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global305)
       )
      )
      (call $function102
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function103 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment103))
  (local $3 (ref $type60))
  (return_call_ref $call60
   (struct.get $type60 1
    (local.tee $3
     (struct.get $environment103 0
      (local.tee $2
       (ref.cast (ref $environment103)
        (local.get $0)
       )
      )
     )
    )
   )
   (struct.get $environment103 1
    (local.get $2)
   )
   (local.get $1)
   (struct.get $type60 0
    (local.get $3)
   )
  )
 )
 (func $function104 (type $call58) (param $0 (ref $type33)) (param $1 (ref null $type30)) (result (ref null $type30))
  (local $2 i64)
  (if (result (ref null $type30))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type30
     (call_ref $call33
      (struct.get $type33 1
       (local.get $0)
      )
      (struct.get $type30 0
       (local.get $1)
      )
      (struct.get $type33 0
       (local.get $0)
      )
     )
     (block (result (ref null $type30))
      (local.set $1
       (struct.get $type30 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready316)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global316)
       )
      )
      (call $function104
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function105 (type $call57) (param $0 structref) (param $1 (ref null $type30)) (result (ref null $type30))
  (struct.new $type30
   (struct.get $environment105 0
    (ref.cast (ref $environment105)
     (local.get $0)
    )
   )
   (local.get $1)
  )
 )
 (func $function106 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref null $type30))
  (local $4 (ref null $type30))
  (local $5 (ref $type60))
  (local $6 (ref $environment106))
  (local $7 (ref $type61))
  (local $8 (ref $type33))
  (local $9 i64)
  (local.set $3
   (struct.get $type30 1
    (local.get $1)
   )
  )
  (struct.new $type32
   (if (result (ref null $type30))
    (call_ref $call61
     (struct.get $type61 1
      (local.tee $7
       (struct.get $environment106 0
        (ref.cast (ref $environment106)
         (local.get $0)
        )
       )
      )
     )
     (local.tee $9
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (struct.get $type61 0
      (local.get $7)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (local.set $9
      (call_ref $call33
       (struct.get $type33 1
        (local.tee $8
         (struct.get $environment106 2
          (local.tee $6
           (ref.cast (ref $environment106)
            (local.get $0)
           )
          )
         )
        )
       )
       (local.get $9)
       (struct.get $type33 0
        (local.get $8)
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready328)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global328)
      )
     )
     (if (result (ref null $type30))
      (ref.is_null
       (local.get $3)
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type30
        (call_ref $call60
         (struct.get $type60 1
          (local.tee $5
           (struct.new $type60
            (ref.func $function107)
            (struct.new $environment107
             (struct.get $environment106 1
              (local.get $6)
             )
             (struct.get $environment106 3
              (local.get $6)
             )
             (local.get $9)
            )
           )
          )
         )
         (struct.get $type30 0
          (local.get $3)
         )
         (struct.get $type30 0
          (local.tee $1
           (struct.get $environment106 4
            (local.get $6)
           )
          )
         )
         (struct.get $type60 0
          (local.get $5)
         )
        )
        (block (result (ref null $type30))
         (local.set $3
          (struct.get $type30 1
           (local.get $3)
          )
         )
         (local.set $1
          (struct.get $type30 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready328)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global328)
          )
         )
         (if (result (ref null $type30))
          (ref.is_null
           (local.get $3)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type30
            (call_ref $call60
             (struct.get $type60 1
              (local.get $5)
             )
             (struct.get $type30 0
              (local.get $3)
             )
             (struct.get $type30 0
              (local.get $1)
             )
             (struct.get $type60 0
              (local.get $5)
             )
            )
            (block (result (ref null $type30))
             (local.set $3
              (struct.get $type30 1
               (local.get $3)
              )
             )
             (local.set $1
              (struct.get $type30 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready328)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global328)
              )
             )
             (if (result (ref null $type30))
              (ref.is_null
               (local.get $3)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type30
                (call_ref $call60
                 (struct.get $type60 1
                  (local.get $5)
                 )
                 (struct.get $type30 0
                  (local.get $3)
                 )
                 (struct.get $type30 0
                  (local.get $1)
                 )
                 (struct.get $type60 0
                  (local.get $5)
                 )
                )
                (block (result (ref null $type30))
                 (local.set $3
                  (struct.get $type30 1
                   (local.get $3)
                  )
                 )
                 (local.set $1
                  (struct.get $type30 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready328)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global328)
                  )
                 )
                 (if (result (ref null $type30))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type30
                    (call_ref $call60
                     (struct.get $type60 1
                      (local.get $5)
                     )
                     (struct.get $type30 0
                      (local.get $3)
                     )
                     (struct.get $type30 0
                      (local.get $1)
                     )
                     (struct.get $type60 0
                      (local.get $5)
                     )
                    )
                    (block (result (ref null $type30))
                     (local.set $3
                      (struct.get $type30 1
                       (local.get $3)
                      )
                     )
                     (local.set $1
                      (struct.get $type30 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready328)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global328)
                      )
                     )
                     (if (result (ref null $type30))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type30
                        (call_ref $call60
                         (struct.get $type60 1
                          (local.get $5)
                         )
                         (struct.get $type30 0
                          (local.get $3)
                         )
                         (struct.get $type30 0
                          (local.get $1)
                         )
                         (struct.get $type60 0
                          (local.get $5)
                         )
                        )
                        (block (result (ref null $type30))
                         (local.set $3
                          (struct.get $type30 1
                           (local.get $3)
                          )
                         )
                         (local.set $1
                          (struct.get $type30 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready328)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global328)
                          )
                         )
                         (if (result (ref null $type30))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type30
                            (call_ref $call60
                             (struct.get $type60 1
                              (local.get $5)
                             )
                             (struct.get $type30 0
                              (local.get $3)
                             )
                             (struct.get $type30 0
                              (local.get $1)
                             )
                             (struct.get $type60 0
                              (local.get $5)
                             )
                            )
                            (block (result (ref null $type30))
                             (local.set $3
                              (struct.get $type30 1
                               (local.get $3)
                              )
                             )
                             (local.set $1
                              (struct.get $type30 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready328)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global328)
                              )
                             )
                             (if (result (ref null $type30))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type30
                                (call_ref $call60
                                 (struct.get $type60 1
                                  (local.get $5)
                                 )
                                 (struct.get $type30 0
                                  (local.get $3)
                                 )
                                 (struct.get $type30 0
                                  (local.get $1)
                                 )
                                 (struct.get $type60 0
                                  (local.get $5)
                                 )
                                )
                                (block (result (ref null $type30))
                                 (local.set $3
                                  (struct.get $type30 1
                                   (local.get $3)
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type30 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready328)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global328)
                                  )
                                 )
                                 (if (result (ref null $type30))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type30
                                    (call_ref $call60
                                     (struct.get $type60 1
                                      (local.get $5)
                                     )
                                     (struct.get $type30 0
                                      (local.get $3)
                                     )
                                     (struct.get $type30 0
                                      (local.get $1)
                                     )
                                     (struct.get $type60 0
                                      (local.get $5)
                                     )
                                    )
                                    (block (result (ref null $type30))
                                     (local.set $4
                                      (struct.get $type30 1
                                       (local.get $3)
                                      )
                                     )
                                     (local.set $3
                                      (struct.get $type30 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready328)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global328)
                                      )
                                     )
                                     (if (result (ref null $type30))
                                      (ref.is_null
                                       (local.get $4)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (struct.new $type30
                                        (call_ref $call60
                                         (struct.get $type60 1
                                          (local.get $5)
                                         )
                                         (struct.get $type30 0
                                          (local.get $4)
                                         )
                                         (struct.get $type30 0
                                          (local.get $3)
                                         )
                                         (struct.get $type60 0
                                          (local.get $5)
                                         )
                                        )
                                        (block (result (ref null $type30))
                                         (local.set $1
                                          (struct.get $type30 1
                                           (local.get $4)
                                          )
                                         )
                                         (local.set $4
                                          (struct.get $type30 1
                                           (local.get $3)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready328)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global328)
                                          )
                                         )
                                         (if (result (ref null $type30))
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (struct.new $type30
                                            (call_ref $call60
                                             (struct.get $type60 1
                                              (local.get $5)
                                             )
                                             (struct.get $type30 0
                                              (local.get $1)
                                             )
                                             (struct.get $type30 0
                                              (local.get $4)
                                             )
                                             (struct.get $type60 0
                                              (local.get $5)
                                             )
                                            )
                                            (block (result (ref null $type30))
                                             (local.set $3
                                              (struct.get $type30 1
                                               (local.get $1)
                                              )
                                             )
                                             (local.set $1
                                              (struct.get $type30 1
                                               (local.get $4)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready328)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global328)
                                              )
                                             )
                                             (call $function108
                                              (local.get $5)
                                              (local.get $3)
                                              (local.get $1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.get $2)
  )
 )
 (func $function107 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type60))
  (local $4 (ref $environment107))
  (local.set $2
   (call_ref $call60
    (struct.get $type60 1
     (local.tee $3
      (struct.get $environment107 1
       (local.tee $4
        (ref.cast (ref $environment107)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $environment107 2
     (local.get $4)
    )
    (local.get $2)
    (struct.get $type60 0
     (local.get $3)
    )
   )
  )
  (return_call_ref $call60
   (struct.get $type60 1
    (local.tee $3
     (struct.get $environment107 0
      (local.get $4)
     )
    )
   )
   (local.get $1)
   (local.get $2)
   (struct.get $type60 0
    (local.get $3)
   )
  )
 )
 (func $function108 (type $call59) (param $0 (ref $type60)) (param $1 (ref null $type30)) (param $2 (ref null $type30)) (result (ref null $type30))
  (local $3 i64)
  (if (result (ref null $type30))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type30
     (call_ref $call60
      (struct.get $type60 1
       (local.get $0)
      )
      (struct.get $type30 0
       (local.get $1)
      )
      (struct.get $type30 0
       (local.get $2)
      )
      (struct.get $type60 0
       (local.get $0)
      )
     )
     (block (result (ref null $type30))
      (local.set $1
       (struct.get $type30 1
        (local.get $1)
       )
      )
      (local.set $2
       (struct.get $type30 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready328)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global328)
       )
      )
      (call $function108
       (local.get $0)
       (local.get $1)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function111 (type $call94) (param $0 (ref struct)) (param $1 (ref null $type30)) (result i32)
  (local $2 (ref $environment111))
  (return_call $function112
   (struct.get $environment111 0
    (local.tee $2
     (ref.cast (ref $environment111)
      (local.get $0)
     )
    )
   )
   (struct.get $environment111 1
    (local.get $2)
   )
   (struct.get $environment111 2
    (local.get $2)
   )
   (struct.get $environment111 3
    (local.get $2)
   )
   (i32.const 0)
   (i32.const 1)
   (local.get $1)
   (struct.get $environment111 4
    (local.get $2)
   )
  )
 )
 (func $function112 (type $50) (param $0 (ref $type61)) (param $1 (ref $type60)) (param $2 (ref $type33)) (param $3 (ref $type60)) (param $4 i32) (param $5 i32) (param $6 (ref null $type30)) (param $7 (ref null $type32)) (result i32)
  (local $8 (ref null $type30))
  (local $9 (ref null $type30))
  (local $10 (ref null $type30))
  (local $11 (ref $type60))
  (local $12 (ref $type57))
  (local $13 (ref null $type32))
  (local $14 i64)
  (local $15 i32)
  (if (result i32)
   (ref.is_null
    (local.get $6)
   )
   (then
    (i32.const 1)
   )
   (else
    (local.set $8
     (struct.get $type30 1
      (local.get $6)
     )
    )
    (if (result i32)
     (call_ref $call61
      (struct.get $type61 1
       (local.get $0)
      )
      (local.tee $14
       (struct.get $type30 0
        (local.get $6)
       )
      )
      (struct.get $type61 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (if (result i32)
         (local.tee $15
          (ref.is_null
           (local.get $7)
          )
         )
         (then
          (local.get $15)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready351)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global351)
           )
          )
          (call_ref $call61
           (struct.get $type61 1
            (local.get $0)
           )
           (struct.get $type30 0
            (struct.get $type32 0
             (local.get $7)
            )
           )
           (struct.get $type61 0
            (local.get $0)
           )
          )
         )
        )
       )
       (then
        (local.set $7
         (struct.get $type32 1
          (local.get $7)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready305)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global305)
       )
      )
      (local.set $13
       (if (result (ref null $type32))
        (ref.is_null
         (local.get $7)
        )
        (then
         (ref.null none)
        )
        (else
         (struct.new $type32
          (struct.get $type30 1
           (struct.get $type32 0
            (local.get $7)
           )
          )
          (block (result (ref null $type32))
           (local.set $7
            (struct.get $type32 1
             (local.get $7)
            )
           )
           (if
            (i32.eqz
             (global.get $ready305)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global305)
            )
           )
           (local.set $12
            (struct.new $type57
             (ref.func $primitive1)
             (ref.null none)
            )
           )
           (if (result (ref null $type32))
            (ref.is_null
             (local.get $7)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type32
              (struct.get $type30 1
               (struct.get $type32 0
                (local.get $7)
               )
              )
              (block (result (ref null $type32))
               (local.set $7
                (struct.get $type32 1
                 (local.get $7)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready305)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global305)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.get $7)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type32
                  (struct.get $type30 1
                   (struct.get $type32 0
                    (local.get $7)
                   )
                  )
                  (block (result (ref null $type32))
                   (local.set $7
                    (struct.get $type32 1
                     (local.get $7)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready305)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global305)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.get $7)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type32
                      (struct.get $type30 1
                       (struct.get $type32 0
                        (local.get $7)
                       )
                      )
                      (block (result (ref null $type32))
                       (local.set $7
                        (struct.get $type32 1
                         (local.get $7)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready305)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global305)
                        )
                       )
                       (if (result (ref null $type32))
                        (ref.is_null
                         (local.get $7)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type32
                          (struct.get $type30 1
                           (struct.get $type32 0
                            (local.get $7)
                           )
                          )
                          (block (result (ref null $type32))
                           (local.set $7
                            (struct.get $type32 1
                             (local.get $7)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready305)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global305)
                            )
                           )
                           (if (result (ref null $type32))
                            (ref.is_null
                             (local.get $7)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type32
                              (struct.get $type30 1
                               (struct.get $type32 0
                                (local.get $7)
                               )
                              )
                              (block (result (ref null $type32))
                               (local.set $7
                                (struct.get $type32 1
                                 (local.get $7)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready305)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global305)
                                )
                               )
                               (if (result (ref null $type32))
                                (ref.is_null
                                 (local.get $7)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type32
                                  (struct.get $type30 1
                                   (struct.get $type32 0
                                    (local.get $7)
                                   )
                                  )
                                  (block (result (ref null $type32))
                                   (local.set $7
                                    (struct.get $type32 1
                                     (local.get $7)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready305)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global305)
                                    )
                                   )
                                   (if (result (ref null $type32))
                                    (ref.is_null
                                     (local.get $7)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type32
                                      (struct.get $type30 1
                                       (struct.get $type32 0
                                        (local.get $7)
                                       )
                                      )
                                      (block (result (ref null $type32))
                                       (local.set $7
                                        (struct.get $type32 1
                                         (local.get $7)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready305)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global305)
                                        )
                                       )
                                       (if (result (ref null $type32))
                                        (ref.is_null
                                         (local.get $7)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type32
                                          (struct.get $type30 1
                                           (struct.get $type32 0
                                            (local.get $7)
                                           )
                                          )
                                          (block (result (ref null $type32))
                                           (local.set $7
                                            (struct.get $type32 1
                                             (local.get $7)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready305)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global305)
                                            )
                                           )
                                           (if (result (ref null $type32))
                                            (ref.is_null
                                             (local.get $7)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type32
                                              (call $primitive1
                                               (ref.null none)
                                               (struct.get $type32 0
                                                (local.get $7)
                                               )
                                              )
                                              (block (result (ref null $type32))
                                               (local.set $7
                                                (struct.get $type32 1
                                                 (local.get $7)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready305)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global305)
                                                )
                                               )
                                               (call $function102
                                                (local.get $12)
                                                (local.get $7)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $5)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function112
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $8)
       (local.get $13)
      )
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.get $7)
       )
       (then
        (i32.const 0)
       )
       (else
        (local.set $9
         (struct.get $type30 1
          (local.tee $6
           (struct.get $type32 0
            (local.get $7)
           )
          )
         )
        )
        (local.set $7
         (struct.get $type32 1
          (local.get $7)
         )
        )
        (if (result i32)
         (call_ref $call61
          (struct.get $type61 1
           (local.get $0)
          )
          (struct.get $type30 0
           (local.get $6)
          )
          (struct.get $type61 0
           (local.get $0)
          )
         )
         (then
          (i32.const 0)
         )
         (else
          (local.set $14
           (call_ref $call33
            (struct.get $type33 1
             (local.get $2)
            )
            (local.get $14)
            (struct.get $type33 0
             (local.get $2)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready328)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global328)
           )
          )
          (local.set $10
           (if (result (ref null $type30))
            (ref.is_null
             (local.get $8)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type30
              (call_ref $call60
               (struct.get $type60 1
                (local.tee $11
                 (struct.new $type60
                  (ref.func $function114)
                  (struct.new $environment114
                   (local.get $1)
                   (local.get $3)
                   (local.get $14)
                  )
                 )
                )
               )
               (struct.get $type30 0
                (local.get $8)
               )
               (struct.get $type30 0
                (local.get $9)
               )
               (struct.get $type60 0
                (local.get $11)
               )
              )
              (block (result (ref null $type30))
               (local.set $6
                (struct.get $type30 1
                 (local.get $8)
                )
               )
               (local.set $8
                (struct.get $type30 1
                 (local.get $9)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready328)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global328)
                )
               )
               (if (result (ref null $type30))
                (ref.is_null
                 (local.get $6)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type30
                  (call_ref $call60
                   (struct.get $type60 1
                    (local.get $11)
                   )
                   (struct.get $type30 0
                    (local.get $6)
                   )
                   (struct.get $type30 0
                    (local.get $8)
                   )
                   (struct.get $type60 0
                    (local.get $11)
                   )
                  )
                  (block (result (ref null $type30))
                   (local.set $6
                    (struct.get $type30 1
                     (local.get $6)
                    )
                   )
                   (local.set $8
                    (struct.get $type30 1
                     (local.get $8)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready328)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global328)
                    )
                   )
                   (if (result (ref null $type30))
                    (ref.is_null
                     (local.get $6)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type30
                      (call_ref $call60
                       (struct.get $type60 1
                        (local.get $11)
                       )
                       (struct.get $type30 0
                        (local.get $6)
                       )
                       (struct.get $type30 0
                        (local.get $8)
                       )
                       (struct.get $type60 0
                        (local.get $11)
                       )
                      )
                      (block (result (ref null $type30))
                       (local.set $6
                        (struct.get $type30 1
                         (local.get $6)
                        )
                       )
                       (local.set $8
                        (struct.get $type30 1
                         (local.get $8)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready328)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global328)
                        )
                       )
                       (if (result (ref null $type30))
                        (ref.is_null
                         (local.get $6)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type30
                          (call_ref $call60
                           (struct.get $type60 1
                            (local.get $11)
                           )
                           (struct.get $type30 0
                            (local.get $6)
                           )
                           (struct.get $type30 0
                            (local.get $8)
                           )
                           (struct.get $type60 0
                            (local.get $11)
                           )
                          )
                          (block (result (ref null $type30))
                           (local.set $6
                            (struct.get $type30 1
                             (local.get $6)
                            )
                           )
                           (local.set $8
                            (struct.get $type30 1
                             (local.get $8)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready328)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global328)
                            )
                           )
                           (if (result (ref null $type30))
                            (ref.is_null
                             (local.get $6)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type30
                              (call_ref $call60
                               (struct.get $type60 1
                                (local.get $11)
                               )
                               (struct.get $type30 0
                                (local.get $6)
                               )
                               (struct.get $type30 0
                                (local.get $8)
                               )
                               (struct.get $type60 0
                                (local.get $11)
                               )
                              )
                              (block (result (ref null $type30))
                               (local.set $6
                                (struct.get $type30 1
                                 (local.get $6)
                                )
                               )
                               (local.set $8
                                (struct.get $type30 1
                                 (local.get $8)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready328)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global328)
                                )
                               )
                               (if (result (ref null $type30))
                                (ref.is_null
                                 (local.get $6)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type30
                                  (call_ref $call60
                                   (struct.get $type60 1
                                    (local.get $11)
                                   )
                                   (struct.get $type30 0
                                    (local.get $6)
                                   )
                                   (struct.get $type30 0
                                    (local.get $8)
                                   )
                                   (struct.get $type60 0
                                    (local.get $11)
                                   )
                                  )
                                  (block (result (ref null $type30))
                                   (local.set $6
                                    (struct.get $type30 1
                                     (local.get $6)
                                    )
                                   )
                                   (local.set $8
                                    (struct.get $type30 1
                                     (local.get $8)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready328)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global328)
                                    )
                                   )
                                   (if (result (ref null $type30))
                                    (ref.is_null
                                     (local.get $6)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type30
                                      (call_ref $call60
                                       (struct.get $type60 1
                                        (local.get $11)
                                       )
                                       (struct.get $type30 0
                                        (local.get $6)
                                       )
                                       (struct.get $type30 0
                                        (local.get $8)
                                       )
                                       (struct.get $type60 0
                                        (local.get $11)
                                       )
                                      )
                                      (block (result (ref null $type30))
                                       (local.set $6
                                        (struct.get $type30 1
                                         (local.get $6)
                                        )
                                       )
                                       (local.set $8
                                        (struct.get $type30 1
                                         (local.get $8)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready328)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global328)
                                        )
                                       )
                                       (if (result (ref null $type30))
                                        (ref.is_null
                                         (local.get $6)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type30
                                          (call_ref $call60
                                           (struct.get $type60 1
                                            (local.get $11)
                                           )
                                           (struct.get $type30 0
                                            (local.get $6)
                                           )
                                           (struct.get $type30 0
                                            (local.get $8)
                                           )
                                           (struct.get $type60 0
                                            (local.get $11)
                                           )
                                          )
                                          (block (result (ref null $type30))
                                           (local.set $6
                                            (struct.get $type30 1
                                             (local.get $6)
                                            )
                                           )
                                           (local.set $8
                                            (struct.get $type30 1
                                             (local.get $8)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready328)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global328)
                                            )
                                           )
                                           (if (result (ref null $type30))
                                            (ref.is_null
                                             (local.get $6)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type30
                                              (call_ref $call60
                                               (struct.get $type60 1
                                                (local.get $11)
                                               )
                                               (struct.get $type30 0
                                                (local.get $6)
                                               )
                                               (struct.get $type30 0
                                                (local.get $8)
                                               )
                                               (struct.get $type60 0
                                                (local.get $11)
                                               )
                                              )
                                              (block (result (ref null $type30))
                                               (local.set $6
                                                (struct.get $type30 1
                                                 (local.get $6)
                                                )
                                               )
                                               (local.set $8
                                                (struct.get $type30 1
                                                 (local.get $8)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready328)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global328)
                                                )
                                               )
                                               (if (result (ref null $type30))
                                                (ref.is_null
                                                 (local.get $6)
                                                )
                                                (then
                                                 (ref.null none)
                                                )
                                                (else
                                                 (struct.new $type30
                                                  (call_ref $call60
                                                   (struct.get $type60 1
                                                    (local.get $11)
                                                   )
                                                   (struct.get $type30 0
                                                    (local.get $6)
                                                   )
                                                   (struct.get $type30 0
                                                    (local.get $8)
                                                   )
                                                   (struct.get $type60 0
                                                    (local.get $11)
                                                   )
                                                  )
                                                  (block (result (ref null $type30))
                                                   (local.set $6
                                                    (struct.get $type30 1
                                                     (local.get $6)
                                                    )
                                                   )
                                                   (local.set $8
                                                    (struct.get $type30 1
                                                     (local.get $8)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready328)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global328)
                                                    )
                                                   )
                                                   (call $function108
                                                    (local.get $11)
                                                    (local.get $6)
                                                    (local.get $8)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready305)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global305)
           )
          )
          (local.set $13
           (if (result (ref null $type32))
            (ref.is_null
             (local.get $7)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type32
              (struct.get $type30 1
               (struct.get $type32 0
                (local.get $7)
               )
              )
              (block (result (ref null $type32))
               (local.set $7
                (struct.get $type32 1
                 (local.get $7)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready305)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global305)
                )
               )
               (local.set $12
                (struct.new $type57
                 (ref.func $primitive1)
                 (ref.null none)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.get $7)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type32
                  (struct.get $type30 1
                   (struct.get $type32 0
                    (local.get $7)
                   )
                  )
                  (block (result (ref null $type32))
                   (local.set $7
                    (struct.get $type32 1
                     (local.get $7)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready305)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global305)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.get $7)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type32
                      (struct.get $type30 1
                       (struct.get $type32 0
                        (local.get $7)
                       )
                      )
                      (block (result (ref null $type32))
                       (local.set $7
                        (struct.get $type32 1
                         (local.get $7)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready305)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global305)
                        )
                       )
                       (if (result (ref null $type32))
                        (ref.is_null
                         (local.get $7)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type32
                          (struct.get $type30 1
                           (struct.get $type32 0
                            (local.get $7)
                           )
                          )
                          (block (result (ref null $type32))
                           (local.set $7
                            (struct.get $type32 1
                             (local.get $7)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready305)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global305)
                            )
                           )
                           (if (result (ref null $type32))
                            (ref.is_null
                             (local.get $7)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type32
                              (struct.get $type30 1
                               (struct.get $type32 0
                                (local.get $7)
                               )
                              )
                              (block (result (ref null $type32))
                               (local.set $7
                                (struct.get $type32 1
                                 (local.get $7)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready305)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global305)
                                )
                               )
                               (if (result (ref null $type32))
                                (ref.is_null
                                 (local.get $7)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type32
                                  (struct.get $type30 1
                                   (struct.get $type32 0
                                    (local.get $7)
                                   )
                                  )
                                  (block (result (ref null $type32))
                                   (local.set $7
                                    (struct.get $type32 1
                                     (local.get $7)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready305)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global305)
                                    )
                                   )
                                   (if (result (ref null $type32))
                                    (ref.is_null
                                     (local.get $7)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type32
                                      (struct.get $type30 1
                                       (struct.get $type32 0
                                        (local.get $7)
                                       )
                                      )
                                      (block (result (ref null $type32))
                                       (local.set $7
                                        (struct.get $type32 1
                                         (local.get $7)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready305)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global305)
                                        )
                                       )
                                       (if (result (ref null $type32))
                                        (ref.is_null
                                         (local.get $7)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type32
                                          (struct.get $type30 1
                                           (struct.get $type32 0
                                            (local.get $7)
                                           )
                                          )
                                          (block (result (ref null $type32))
                                           (local.set $7
                                            (struct.get $type32 1
                                             (local.get $7)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready305)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global305)
                                            )
                                           )
                                           (if (result (ref null $type32))
                                            (ref.is_null
                                             (local.get $7)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type32
                                              (struct.get $type30 1
                                               (struct.get $type32 0
                                                (local.get $7)
                                               )
                                              )
                                              (block (result (ref null $type32))
                                               (local.set $7
                                                (struct.get $type32 1
                                                 (local.get $7)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready305)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global305)
                                                )
                                               )
                                               (if (result (ref null $type32))
                                                (ref.is_null
                                                 (local.get $7)
                                                )
                                                (then
                                                 (ref.null none)
                                                )
                                                (else
                                                 (struct.new $type32
                                                  (call $primitive1
                                                   (ref.null none)
                                                   (struct.get $type32 0
                                                    (local.get $7)
                                                   )
                                                  )
                                                  (block (result (ref null $type32))
                                                   (local.set $7
                                                    (struct.get $type32 1
                                                     (local.get $7)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready305)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global305)
                                                    )
                                                   )
                                                   (call $function102
                                                    (local.get $12)
                                                    (local.get $7)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (local.get $5)
           )
           (then
            (unreachable)
           )
          )
          (return_call $function112
           (local.get $0)
           (local.get $1)
           (local.get $2)
           (local.get $3)
           (local.get $4)
           (local.get $5)
           (local.get $10)
           (local.get $13)
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function114 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type60))
  (local $4 (ref $environment114))
  (local.set $2
   (call_ref $call60
    (struct.get $type60 1
     (local.tee $3
      (struct.get $environment114 1
       (local.tee $4
        (ref.cast (ref $environment114)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $environment114 2
     (local.get $4)
    )
    (local.get $2)
    (struct.get $type60 0
     (local.get $3)
    )
   )
  )
  (return_call_ref $call60
   (struct.get $type60 1
    (local.tee $3
     (struct.get $environment114 0
      (local.get $4)
     )
    )
   )
   (local.get $1)
   (local.get $2)
   (struct.get $type60 0
    (local.get $3)
   )
  )
 )
 (func $function119 (type $call61) (param $0 (ref null $environment135)) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function128 (type $48) (param $0 (ref $type96)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (param $5 i64) (param $6 i64) (param $7 i64) (param $8 i64) (result (ref $type97))
  (local $9 i64)
  (if
   (i32.eqz
    (global.get $ready368)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global368)
   )
  )
  (if (result (ref $type98))
   (i64.eqz
    (local.get $6)
   )
   (then
    (struct.new $type98
     (local.get $4)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready159)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (call $function59
      (struct.get $type60 1
       (global.get $global159)
      )
      (local.get $3)
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function128
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (i64.sub
      (local.get $3)
      (i64.mul
       (local.get $6)
       (local.get $9)
      )
     )
     (i64.sub
      (local.get $4)
      (i64.mul
       (local.get $7)
       (local.get $9)
      )
     )
     (i64.sub
      (local.get $5)
      (i64.mul
       (local.get $8)
       (local.get $9)
      )
     )
    )
   )
  )
 )
 (func $function135 (type $call61) (param $0 (ref null $environment135)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $scratch i64)
  (local.set $2
   (struct.get $environment135 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (i64.eqz
   (block (result i64)
    (local.set $scratch
     (call $function60
      (struct.get $type60 1
       (global.get $global166)
      )
      (local.get $1)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready368)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type61 1
      (global.get $global368)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function136 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local.set $3
   (struct.get $environment136 0
    (ref.cast (ref $environment136)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function60
   (struct.get $type60 1
    (global.get $global166)
   )
   (i64.add
    (local.get $1)
    (local.get $2)
   )
   (local.get $3)
  )
 )
 (func $function137 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $environment137 0
    (ref.cast (ref $environment137)
     (local.get $0)
    )
   )
  )
  (drop
   (struct.get $type33 1
    (global.get $global109)
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function60
   (struct.get $type60 1
    (global.get $global166)
   )
   (i64.sub
    (i64.const 0)
    (local.get $1)
   )
   (local.get $2)
  )
 )
 (func $function138 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local.set $3
   (struct.get $environment138 0
    (ref.cast (ref $environment138)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function60
   (struct.get $type60 1
    (global.get $global166)
   )
   (i64.mul
    (local.get $1)
    (local.get $2)
   )
   (local.get $3)
  )
 )
 (func $function139 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 (ref $type97))
  (local.set $2
   (struct.get $environment139 0
    (ref.cast (ref $environment139)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready384)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global384)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type98)
     (local.tee $3
      (if (result (ref $type97))
       (i64.ge_s
        (local.tee $1
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (if (result (ref $type97))
         (i64.ge_s
          (local.get $2)
          (i64.const 0)
         )
         (then
          (call $function128
           (struct.new_default $type96)
           (i32.const 0)
           (i32.const 1)
           (local.get $1)
           (i64.const 1)
           (i64.const 0)
           (local.get $2)
           (i64.const 0)
           (i64.const 1)
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready109)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (struct.get $type33 1
            (global.get $global109)
           )
          )
          (struct.new_default $type99)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready109)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (struct.get $type33 1
          (global.get $global109)
         )
        )
        (struct.new_default $type99)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type98 0
   (ref.cast (ref $type98)
    (local.get $3)
   )
  )
 )
 (func $function141 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment141))
  (local $3 i64)
  (local.set $3
   (struct.get $environment141 0
    (local.tee $2
     (ref.cast (ref $environment141)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (i64.sub
      (call $function60
       (struct.get $type60 1
        (global.get $global166)
       )
       (local.get $1)
       (local.get $3)
      )
      (i64.const 1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type12
   (struct.get $environment141 1
    (local.get $2)
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function143 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type46))
  (if
   (i32.eqz
    (global.get $ready131)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (if
   (i32.eqz
    (global.get $ready435)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global435)
   )
  )
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 2)
   )
   (then
    (i64.const 2)
   )
   (else
    (return_call $function147
     (local.get $1)
     (local.tee $2
      (struct.new $type46
       (i64.const 2)
       (struct.new $type47
        (global.get $empty45)
       )
      )
     )
     (struct.new $type47
      (local.get $2)
     )
     (i32.const 0)
     (i32.const 0)
     (i32.const 1)
     (i64.const 3)
    )
   )
  )
 )
 (func $function146 (type $36) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 (ref $type44)) (result i32)
  (local $4 i64)
  (local $5 i32)
  (local $scratch i64)
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (if (result i32)
   (local.tee $5
    (if (result i32)
     (ref.test (ref $type45)
      (local.get $3)
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type46)
        (local.get $3)
       )
      )
      (i32.const 0)
     )
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (local.tee $5
      (i64.gt_s
       (i64.mul
        (local.tee $4
         (struct.get $type46 0
          (ref.cast (ref $type46)
           (local.get $3)
          )
         )
        )
        (local.get $4)
       )
       (local.get $0)
      )
     )
     (then
      (local.get $5)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i64.eqz
        (block (result i64)
         (local.set $scratch
          (call $function60
           (struct.get $type60 1
            (global.get $global166)
           )
           (local.get $0)
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (global.get $ready368)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (struct.get $type61 1
           (global.get $global368)
          )
         )
         (local.get $scratch)
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready134)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global134)
         )
        )
        (if
         (ref.test (ref $type45)
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type47 0
          (struct.get $type46 1
           (ref.cast (ref $type46)
            (local.get $3)
           )
          )
         )
        )
        (if
         (i32.eqz
          (local.get $2)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function146
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function147 (type $35) (param $0 i64) (param $1 (ref $type44)) (param $2 (ref $type47)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (result i64)
  (local $7 (ref $type44))
  (local $8 (ref $type46))
  (block $block
   (return
    (if (result i64)
     (call $function146
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (local.get $1)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready131)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global131)
       )
      )
      (if
       (i32.eqz
        (global.get $ready447)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global447)
       )
      )
      (if
       (i32.eqz
        (global.get $ready136)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global136)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.tee $7
         (struct.get $type47 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type47 0
       (struct.get $type46 1
        (ref.cast (ref $type46)
         (local.get $7)
        )
       )
       (local.tee $8
        (struct.new $type46
         (local.get $6)
         (struct.new $type47
          (global.get $empty45)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready449)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global449)
       )
      )
      (struct.set $type47 0
       (local.get $2)
       (local.get $8)
      )
      (br_if $block
       (i64.ge_s
        (local.get $0)
        (local.get $6)
       )
      )
      (local.get $6)
     )
     (else
      (br $block)
     )
    )
   )
  )
  (if
   (i32.eqz
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function147
   (local.get $0)
   (local.get $1)
   (local.get $2)
   (local.get $3)
   (local.get $4)
   (local.get $5)
   (i64.add
    (local.get $6)
    (i64.const 2)
   )
  )
 )
 (func $function150 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function59
    (struct.get $type60 1
     (global.get $global159)
    )
    (local.get $1)
    (i64.const 2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function46
    (struct.get $type60 1
     (global.get $global125)
    )
    (local.get $1)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global123)
   )
  )
  (if (result i64)
   (i64.eqz
    (i64.and
     (local.get $1)
     (i64.const 1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (i64.mul
     (if (result i64)
      (i64.le_s
       (local.get $1)
       (i64.const 0)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (i64.le_s
         (local.get $1)
         (i64.const 1)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i64.le_s
           (local.get $1)
           (i64.const 4)
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i64.le_s
             (local.get $1)
             (i64.const 9)
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i64.le_s
               (local.get $1)
               (i64.const 16)
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (i64.le_s
                 (local.get $1)
                 (i64.const 25)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (i64.le_s
                   (local.get $1)
                   (i64.const 36)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (i64.le_s
                     (local.get $1)
                     (i64.const 49)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (i64.le_s
                       (local.get $1)
                       (i64.const 64)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (if (result i64)
                        (i64.le_s
                         (local.get $1)
                         (i64.const 81)
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (call $function151
                          (local.get $1)
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 10)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function151 (type $34) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (if (result i64)
   (i64.le_s
    (local.get $0)
    (i64.mul
     (local.get $3)
     (local.get $3)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function151
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function152 (type $call103) (param $0 (ref null $type32)) (param $1 (ref $type104)) (result (ref $type104))
  (local $2 (ref null $type32))
  (local $3 (ref null $type54))
  (local $4 i64)
  (local $5 i64)
  (if
   (i32.eqz
    (global.get $ready462)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global462)
   )
  )
  (if (result (ref $type104))
   (i64.lt_s
    (local.tee $4
     (if (result i64)
      (ref.is_null
       (local.get $0)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $2
          (struct.get $type32 1
           (local.get $0)
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $2
            (struct.get $type32 1
             (local.get $2)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $2
              (struct.get $type32 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type32 1
                 (local.get $2)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type32 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type32 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type32 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type32 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (call $function154
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type32 1
                         (local.get $2)
                        )
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.tee $5
     (struct.get $type104 0
      (local.get $1)
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if (result (ref $type104))
     (i64.eq
      (local.get $4)
      (local.get $5)
     )
     (then
      (local.set $3
       (struct.get $type104 2
        (local.get $1)
       )
      )
      (struct.new $type104
       (local.get $5)
       (local.tee $4
        (i64.add
         (struct.get $type104 1
          (local.get $1)
         )
         (i64.const 1)
        )
       )
       (if (result (ref null $type54))
        (i64.lt_s
         (local.get $4)
         (i64.const 3000)
        )
        (then
         (struct.new $type54
          (struct.new $type50
           (local.get $0)
          )
          (local.get $3)
         )
        )
        (else
         (if (result (ref null $type54))
          (i64.eq
           (local.get $4)
           (i64.const 3000)
          )
          (then
           (struct.new $type54
            (struct.new $type51
             (global.get $string1)
            )
            (local.get $3)
           )
          )
          (else
           (local.get $3)
          )
         )
        )
       )
      )
     )
     (else
      (if
       (i32.eqz
        (global.get $ready470)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global470)
       )
      )
      (struct.new $type104
       (local.get $4)
       (i64.const 1)
       (struct.new $type54
        (struct.new $type50
         (local.get $0)
        )
        (ref.null none)
       )
      )
     )
    )
   )
  )
 )
 (func $function153 (type $call31) (param $0 (ref null $type32)) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $0
       (struct.get $type32 1
        (local.get $0)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $0
         (struct.get $type32 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $0
           (struct.get $type32 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $0
             (struct.get $type32 1
              (local.get $0)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $0
               (struct.get $type32 1
                (local.get $0)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $0
                 (struct.get $type32 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type32 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type32 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (return_call $function154
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type32 1
                      (local.get $0)
                     )
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function154 (type $30) (param $0 i32) (param $1 i32) (param $2 (ref null $type32)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type32 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function154
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function156 (type $call105) (param $0 i64) (param $1 i64) (result (ref null $type54))
  (local $2 i64)
  (local $3 (ref null $type32))
  (local $4 (ref $type103))
  (local $5 (ref $type46))
  (local $6 (ref $type33))
  (local $7 (ref $type33))
  (local $8 (ref null $type30))
  (local $9 (ref $type61))
  (local $10 (ref $type60))
  (local $11 (ref $type60))
  (if
   (i32.eqz
    (global.get $ready457)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (ref.as_non_null
    (global.get $global457)
   )
  )
  (if
   (i32.eqz
    (global.get $ready475)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global475)
   )
  )
  (if
   (i32.eqz
    (global.get $ready452)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function150
    (struct.get $type33 1
     (global.get $global452)
    )
    (local.get $1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready431)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type33 1
    (global.get $global431)
   )
  )
  (if
   (i32.eqz
    (global.get $ready131)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (if
   (i32.eqz
    (global.get $ready435)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global435)
   )
  )
  (local.set $2
   (if (result i64)
    (i64.lt_s
     (local.get $2)
     (i64.const 2)
    )
    (then
     (i64.const 2)
    )
    (else
     (call $function147
      (local.get $2)
      (local.tee $5
       (struct.new $type46
        (i64.const 2)
        (struct.new $type47
         (global.get $empty45)
        )
       )
      )
      (struct.new $type47
       (local.get $5)
      )
      (i32.const 0)
      (i32.const 0)
      (i32.const 1)
      (i64.const 3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready406)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global406)
   )
  )
  (if
   (i32.eqz
    (global.get $ready333)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global333)
   )
  )
  (if
   (i32.eqz
    (global.get $ready408)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global408)
   )
  )
  (if
   (i32.eqz
    (global.get $ready283)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global283)
   )
  )
  (local.set $6
   (struct.new $type33
    (ref.func $function141)
    (struct.new $environment141
     (local.get $2)
     (call $function95
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
      (struct.new $type33
       (ref.func $function139)
       (struct.new $environment139
        (local.get $2)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global289)
   )
  )
  (if
   (i32.eqz
    (global.get $ready509)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global509)
   )
  )
  (local.set $8
   (struct.get $type32 0
    (local.tee $3
     (call $function65
      (call $function165
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
       (struct.new $type84
        (ref.func $primitive0)
        (ref.null none)
       )
       (ref.null none)
      )
      (block (result (ref (exact $type84)))
       (if
        (i32.eqz
         (global.get $ready184)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global184)
        )
       )
       (struct.new $type84
        (ref.func $function168)
        (ref.null none)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready239)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global239)
   )
  )
  (struct.get $type104 2
   (call $function169
    (local.get $1)
    (local.get $4)
    (struct.new $type93
     (struct.new $environment110
      (local.tee $9
       (struct.new $type61
        (ref.func $function135)
        (struct.new $environment135
         (local.get $2)
         (i32.const 0)
        )
       )
      )
      (local.tee $10
       (struct.new $type60
        (ref.func $function136)
        (struct.new $environment136
         (local.get $2)
        )
       )
      )
      (local.tee $7
       (struct.new $type33
        (ref.func $function137)
        (struct.new $environment137
         (local.get $2)
        )
       )
      )
      (local.tee $11
       (struct.new $type60
        (ref.func $function138)
        (struct.new $environment138
         (local.get $2)
        )
       )
      )
      (struct.new $type55
       (ref.func $function98)
       (struct.new $environment98
        (i64.const 0)
        (i64.const 1)
        (local.get $9)
        (local.get $10)
        (local.get $7)
        (local.get $11)
        (local.get $6)
       )
      )
     )
    )
    (i32.const 0)
    (i32.const 0)
    (i32.const 1)
    (i64.const 1)
    (struct.new $type32
     (local.get $8)
     (ref.null none)
    )
    (struct.get $type32 1
     (local.get $3)
    )
    (struct.new $type104
     (i64.const -1)
     (i64.const -1)
     (ref.null none)
    )
   )
  )
 )
 (func $function159 (type $call109) (param $0 (ref struct)) (param $1 (ref null $type32)) (param $2 (ref null $type110)) (result (ref null $type110))
  (local $3 (ref $environment110))
  (local $4 (ref $environment159))
  (local $5 (ref $type55))
  (struct.new $type110
   (struct.new $type94
    (ref.func $function111)
    (struct.new $environment111
     (struct.get $environment110 0
      (local.tee $3
       (struct.get $type93 0
        (struct.get $environment159 0
         (local.tee $4
          (ref.cast (ref $environment159)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (struct.get $environment110 1
      (local.get $3)
     )
     (struct.get $environment110 2
      (local.get $3)
     )
     (struct.get $environment110 3
      (local.get $3)
     )
     (call_ref $call55
      (struct.get $type55 1
       (local.tee $5
        (struct.get $environment110 4
         (local.get $3)
        )
       )
      )
      (struct.new $type32
       (struct.get $environment159 1
        (local.get $4)
       )
       (local.get $1)
      )
      (struct.get $type55 0
       (local.get $5)
      )
     )
    )
   )
   (local.get $2)
  )
 )
 (func $function161 (type $22) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref null $type32)) (param $4 (ref $type109)) (param $5 i64) (param $6 (ref null $type110)) (result (ref null $type110))
  (local $7 (ref null $type30))
  (if
   (i32.eqz
    (global.get $ready368)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global368)
   )
  )
  (if
   (i64.eqz
    (local.get $5)
   )
   (then
    (return_call_ref $call109
     (struct.get $type109 1
      (local.get $4)
     )
     (local.get $3)
     (local.get $6)
     (struct.get $type109 0
      (local.get $4)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready368)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type61 1
      (global.get $global368)
     )
    )
    (if
     (i64.eqz
      (local.get $2)
     )
     (then
      (return_call_ref $call109
       (struct.get $type109 1
        (local.get $4)
       )
       (ref.null none)
       (local.get $6)
       (struct.get $type109 0
        (local.get $4)
       )
      )
     )
     (else
      (local.set $7
       (struct.get $type32 0
        (local.get $3)
       )
      )
      (local.set $3
       (struct.get $type32 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (call $function161
        (local.get $0)
        (local.get $1)
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
        (local.get $3)
        (struct.new $type109
         (ref.func $function162)
         (struct.new $environment162
          (local.get $4)
          (local.get $7)
         )
        )
        (local.get $5)
        (local.get $6)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function161
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
       (local.get $6)
      )
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function162 (type $call109) (param $0 (ref struct)) (param $1 (ref null $type32)) (param $2 (ref null $type110)) (result (ref null $type110))
  (local $3 (ref $environment162))
  (local $4 (ref $type109))
  (return_call_ref $call109
   (struct.get $type109 1
    (local.tee $4
     (struct.get $environment162 0
      (local.tee $3
       (ref.cast (ref $environment162)
        (local.get $0)
       )
      )
     )
    )
   )
   (struct.new $type32
    (struct.get $environment162 1
     (local.get $3)
    )
    (local.get $1)
   )
   (local.get $2)
   (struct.get $type109 0
    (local.get $4)
   )
  )
 )
 (func $function163 (type $call94) (param $0 (ref struct)) (param $1 (ref null $type30)) (result i32)
  (local $2 (ref null $type110))
  (local $3 (ref $type94))
  (local $4 i32)
  (if (result i32)
   (ref.is_null
    (local.tee $2
     (struct.get $environment163 0
      (ref.cast (ref $environment163)
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $4
      (call_ref $call94
       (struct.get $type94 1
        (local.tee $3
         (struct.get $type110 0
          (local.get $2)
         )
        )
       )
       (local.get $1)
       (struct.get $type94 0
        (local.get $3)
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.tee $2
         (struct.get $type110 1
          (local.get $2)
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (local.tee $4
          (call_ref $call94
           (struct.get $type94 1
            (local.tee $3
             (struct.get $type110 0
              (local.get $2)
             )
            )
           )
           (local.get $1)
           (struct.get $type94 0
            (local.get $3)
           )
          )
         )
         (then
          (local.get $4)
         )
         (else
          (if (result i32)
           (ref.is_null
            (local.tee $2
             (struct.get $type110 1
              (local.get $2)
             )
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (local.tee $4
              (call_ref $call94
               (struct.get $type94 1
                (local.tee $3
                 (struct.get $type110 0
                  (local.get $2)
                 )
                )
               )
               (local.get $1)
               (struct.get $type94 0
                (local.get $3)
               )
              )
             )
             (then
              (local.get $4)
             )
             (else
              (if (result i32)
               (ref.is_null
                (local.tee $2
                 (struct.get $type110 1
                  (local.get $2)
                 )
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (local.tee $4
                  (call_ref $call94
                   (struct.get $type94 1
                    (local.tee $3
                     (struct.get $type110 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $1)
                   (struct.get $type94 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (local.get $4)
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.tee $2
                     (struct.get $type110 1
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (local.tee $4
                      (call_ref $call94
                       (struct.get $type94 1
                        (local.tee $3
                         (struct.get $type110 0
                          (local.get $2)
                         )
                        )
                       )
                       (local.get $1)
                       (struct.get $type94 0
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (local.get $4)
                     )
                     (else
                      (if (result i32)
                       (ref.is_null
                        (local.tee $2
                         (struct.get $type110 1
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (local.tee $4
                          (call_ref $call94
                           (struct.get $type94 1
                            (local.tee $3
                             (struct.get $type110 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $1)
                           (struct.get $type94 0
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (if (result i32)
                           (ref.is_null
                            (local.tee $2
                             (struct.get $type110 1
                              (local.get $2)
                             )
                            )
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (local.tee $4
                              (call_ref $call94
                               (struct.get $type94 1
                                (local.tee $3
                                 (struct.get $type110 0
                                  (local.get $2)
                                 )
                                )
                               )
                               (local.get $1)
                               (struct.get $type94 0
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (local.get $4)
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.tee $2
                                 (struct.get $type110 1
                                  (local.get $2)
                                 )
                                )
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (local.tee $4
                                  (call_ref $call94
                                   (struct.get $type94 1
                                    (local.tee $3
                                     (struct.get $type110 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $1)
                                   (struct.get $type94 0
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $4)
                                 )
                                 (else
                                  (if (result i32)
                                   (ref.is_null
                                    (local.tee $2
                                     (struct.get $type110 1
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (local.tee $4
                                      (call_ref $call94
                                       (struct.get $type94 1
                                        (local.tee $3
                                         (struct.get $type110 0
                                          (local.get $2)
                                         )
                                        )
                                       )
                                       (local.get $1)
                                       (struct.get $type94 0
                                        (local.get $3)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $4)
                                     )
                                     (else
                                      (if (result i32)
                                       (ref.is_null
                                        (local.tee $2
                                         (struct.get $type110 1
                                          (local.get $2)
                                         )
                                        )
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if (result i32)
                                         (local.tee $4
                                          (call_ref $call94
                                           (struct.get $type94 1
                                            (local.tee $3
                                             (struct.get $type110 0
                                              (local.get $2)
                                             )
                                            )
                                           )
                                           (local.get $1)
                                           (struct.get $type94 0
                                            (local.get $3)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $4)
                                         )
                                         (else
                                          (return_call $function164
                                           (local.get $1)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (struct.get $type110 1
                                            (local.get $2)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function164 (type $18) (param $0 (ref null $type30)) (param $1 i32) (param $2 i32) (param $3 (ref null $type110)) (result i32)
  (local $4 (ref $type94))
  (local $5 i32)
  (if (result i32)
   (ref.is_null
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $5
      (call_ref $call94
       (struct.get $type94 1
        (local.tee $4
         (struct.get $type110 0
          (local.get $3)
         )
        )
       )
       (local.get $0)
       (struct.get $type94 0
        (local.get $4)
       )
      )
     )
     (then
      (local.get $5)
     )
     (else
      (local.set $3
       (struct.get $type110 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function164
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function165 (type $17) (param $0 i64) (param $1 (ref $type84)) (param $2 (ref null $type32)) (result (ref null $type32))
  (if
   (i32.eqz
    (global.get $ready368)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global368)
   )
  )
  (if
   (i64.eqz
    (local.get $0)
   )
   (then
    (return_call_ref $call84
     (struct.get $type84 1
      (local.get $1)
     )
     (ref.null none)
     (local.get $2)
     (struct.get $type84 0
      (local.get $1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready509)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global509)
     )
    )
    (local.set $2
     (call $function165
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
      (struct.new $type84
       (ref.func $function167)
       (struct.new $environment167
        (local.get $1)
       )
      )
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready509)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global509)
     )
    )
    (return_call $function165
     (i64.sub
      (local.get $0)
      (i64.const 1)
     )
     (struct.new $type84
      (ref.func $function166)
      (struct.new $environment166
       (local.get $1)
      )
     )
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function166 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref $type84))
  (return_call_ref $call84
   (struct.get $type84 1
    (local.tee $3
     (struct.get $environment166 0
      (ref.cast (ref $environment166)
       (local.get $0)
      )
     )
    )
   )
   (struct.new $type30
    (i64.const -1)
    (local.get $1)
   )
   (local.get $2)
   (struct.get $type84 0
    (local.get $3)
   )
  )
 )
 (func $function167 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref $type84))
  (return_call_ref $call84
   (struct.get $type84 1
    (local.tee $3
     (struct.get $environment167 0
      (ref.cast (ref $environment167)
       (local.get $0)
      )
     )
    )
   )
   (struct.new $type30
    (i64.const 1)
    (local.get $1)
   )
   (local.get $2)
   (struct.get $type84 0
    (local.get $3)
   )
  )
 )
 (func $function168 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (struct.new $type32
   (struct.new $type30
    (i64.const 1)
    (local.get $1)
   )
   (local.get $2)
  )
 )
 (func $function169 (type $14) (param $0 i64) (param $1 (ref $type103)) (param $2 (ref $type93)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 (ref $type32)) (param $8 (ref null $type32)) (param $9 (ref $type104)) (result (ref $type104))
  (local $10 (ref $environment110))
  (local $11 (ref $type32))
  (local $12 (ref $type55))
  (local $13 (ref $type109))
  (local $14 (ref null $type32))
  (local $15 (ref $type94))
  (local $16 i64)
  (local $17 i64)
  (local.set $15
   (if (result (ref $type94))
    (i64.gt_s
     (local.get $0)
     (local.get $6)
    )
    (then
     (struct.new $type94
      (ref.func $function111)
      (struct.new $environment111
       (struct.get $environment110 0
        (local.tee $10
         (struct.get $type93 0
          (local.get $2)
         )
        )
       )
       (struct.get $environment110 1
        (local.get $10)
       )
       (struct.get $environment110 2
        (local.get $10)
       )
       (struct.get $environment110 3
        (local.get $10)
       )
       (call_ref $call55
        (struct.get $type55 1
         (local.tee $12
          (struct.get $environment110 4
           (local.get $10)
          )
         )
        )
        (local.get $7)
        (struct.get $type55 0
         (local.get $12)
        )
       )
      )
     )
    )
    (else
     (if
      (i32.eqz
       (global.get $ready488)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global488)
      )
     )
     (if
      (i32.eqz
       (global.get $ready462)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global462)
      )
     )
     (local.set $13
      (struct.new $type109
       (ref.func $function159)
       (struct.new $environment159
        (local.get $2)
        (struct.get $type32 0
         (local.get $7)
        )
       )
      )
     )
     (struct.new $type94
      (ref.func $function163)
      (struct.new $environment163
       (if (result (ref null $type110))
        (i64.lt_s
         (local.tee $17
          (call $function153
           (local.tee $14
            (struct.get $type32 1
             (local.get $7)
            )
           )
          )
         )
         (local.tee $16
          (i64.sub
           (local.get $0)
           (i64.const 2)
          )
         )
        )
        (then
         (ref.null none)
        )
        (else
         (call $function161
          (i32.const 0)
          (i32.const 1)
          (local.get $16)
          (local.get $14)
          (local.get $13)
          (i64.sub
           (local.get $17)
           (local.get $16)
          )
          (ref.null none)
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready525)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (if
   (i32.eqz
    (global.get $ready184)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global184)
   )
  )
  (local.set $8
   (call $function65
    (local.get $8)
    (struct.new $type84
     (ref.func $function171)
     (struct.new $environment171
      (local.get $15)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready269)
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.is_null
    (local.tee $8
     (call $function91
      (struct.get $type55 1
       (global.get $global269)
      )
      (local.get $8)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready269)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type55 1
      (global.get $global269)
     )
    )
    (local.set $11
     (struct.new $type32
      (struct.get $type32 0
       (local.get $7)
      )
      (ref.null none)
     )
    )
    (return_call $function152
     (if (result (ref null $type32))
      (ref.is_null
       (local.tee $8
        (struct.get $type32 1
         (local.get $7)
        )
       )
      )
      (then
       (local.get $11)
      )
      (else
       (local.set $7
        (struct.new $type32
         (struct.get $type32 0
          (local.get $8)
         )
         (local.get $11)
        )
       )
       (if (result (ref null $type32))
        (ref.is_null
         (local.tee $8
          (struct.get $type32 1
           (local.get $8)
          )
         )
        )
        (then
         (local.get $7)
        )
        (else
         (local.set $7
          (struct.new $type32
           (struct.get $type32 0
            (local.get $8)
           )
           (local.get $7)
          )
         )
         (if (result (ref null $type32))
          (ref.is_null
           (local.tee $8
            (struct.get $type32 1
             (local.get $8)
            )
           )
          )
          (then
           (local.get $7)
          )
          (else
           (local.set $7
            (struct.new $type32
             (struct.get $type32 0
              (local.get $8)
             )
             (local.get $7)
            )
           )
           (if (result (ref null $type32))
            (ref.is_null
             (local.tee $8
              (struct.get $type32 1
               (local.get $8)
              )
             )
            )
            (then
             (local.get $7)
            )
            (else
             (local.set $7
              (struct.new $type32
               (struct.get $type32 0
                (local.get $8)
               )
               (local.get $7)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.tee $8
                (struct.get $type32 1
                 (local.get $8)
                )
               )
              )
              (then
               (local.get $7)
              )
              (else
               (local.set $7
                (struct.new $type32
                 (struct.get $type32 0
                  (local.get $8)
                 )
                 (local.get $7)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.tee $8
                  (struct.get $type32 1
                   (local.get $8)
                  )
                 )
                )
                (then
                 (local.get $7)
                )
                (else
                 (local.set $7
                  (struct.new $type32
                   (struct.get $type32 0
                    (local.get $8)
                   )
                   (local.get $7)
                  )
                 )
                 (if (result (ref null $type32))
                  (ref.is_null
                   (local.tee $8
                    (struct.get $type32 1
                     (local.get $8)
                    )
                   )
                  )
                  (then
                   (local.get $7)
                  )
                  (else
                   (local.set $7
                    (struct.new $type32
                     (struct.get $type32 0
                      (local.get $8)
                     )
                     (local.get $7)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.tee $8
                      (struct.get $type32 1
                       (local.get $8)
                      )
                     )
                    )
                    (then
                     (local.get $7)
                    )
                    (else
                     (call $function92
                      (i32.const 0)
                      (i32.const 1)
                      (struct.get $type32 1
                       (local.get $8)
                      )
                      (struct.new $type32
                       (struct.get $type32 0
                        (local.get $8)
                       )
                       (local.get $7)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (local.get $9)
    )
   )
   (else
    (return_call $function172
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (i32.const 0)
     (i32.const 1)
     (local.get $8)
     (local.get $9)
    )
   )
  )
  (unreachable)
 )
 (func $function171 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref $type94))
  (if (result (ref null $type32))
   (call_ref $call94
    (struct.get $type94 1
     (local.tee $3
      (struct.get $environment171 0
       (ref.cast (ref $environment171)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $type94 0
     (local.get $3)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (struct.new $type32
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function172 (type $12) (param $0 i64) (param $1 (ref $type103)) (param $2 (ref $type93)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 (ref null $type32)) (param $8 i32) (param $9 i32) (param $10 (ref null $type32)) (param $11 (ref $type104)) (result (ref $type104))
  (local $12 (ref $type32))
  (local $13 (ref $type32))
  (local $14 (ref null $type32))
  (local $15 (ref null $type30))
  (local $16 (ref $type114))
  (if (result (ref $type104))
   (ref.is_null
    (local.get $10)
   )
   (then
    (local.get $11)
   )
   (else
    (local.set $14
     (struct.get $type32 1
      (local.get $10)
     )
    )
    (local.set $12
     (struct.new $type32
      (struct.get $type32 0
       (local.tee $13
        (struct.new $type32
         (struct.get $type32 0
          (local.get $10)
         )
         (block (result (ref null $type32))
          (if
           (i32.eqz
            (global.get $ready269)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (struct.get $type55 1
            (global.get $global269)
           )
          )
          (local.get $7)
         )
        )
       )
      )
      (ref.null none)
     )
    )
    (local.set $10
     (if (result (ref null $type32))
      (ref.is_null
       (local.tee $10
        (struct.get $type32 1
         (local.get $13)
        )
       )
      )
      (then
       (local.get $12)
      )
      (else
       (local.set $12
        (struct.new $type32
         (struct.get $type32 0
          (local.get $10)
         )
         (local.get $12)
        )
       )
       (if (result (ref null $type32))
        (ref.is_null
         (local.tee $10
          (struct.get $type32 1
           (local.get $10)
          )
         )
        )
        (then
         (local.get $12)
        )
        (else
         (local.set $12
          (struct.new $type32
           (struct.get $type32 0
            (local.get $10)
           )
           (local.get $12)
          )
         )
         (if (result (ref null $type32))
          (ref.is_null
           (local.tee $10
            (struct.get $type32 1
             (local.get $10)
            )
           )
          )
          (then
           (local.get $12)
          )
          (else
           (local.set $12
            (struct.new $type32
             (struct.get $type32 0
              (local.get $10)
             )
             (local.get $12)
            )
           )
           (if (result (ref null $type32))
            (ref.is_null
             (local.tee $10
              (struct.get $type32 1
               (local.get $10)
              )
             )
            )
            (then
             (local.get $12)
            )
            (else
             (local.set $12
              (struct.new $type32
               (struct.get $type32 0
                (local.get $10)
               )
               (local.get $12)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.tee $10
                (struct.get $type32 1
                 (local.get $10)
                )
               )
              )
              (then
               (local.get $12)
              )
              (else
               (local.set $12
                (struct.new $type32
                 (struct.get $type32 0
                  (local.get $10)
                 )
                 (local.get $12)
                )
               )
               (if (result (ref null $type32))
                (ref.is_null
                 (local.tee $10
                  (struct.get $type32 1
                   (local.get $10)
                  )
                 )
                )
                (then
                 (local.get $12)
                )
                (else
                 (local.set $12
                  (struct.new $type32
                   (struct.get $type32 0
                    (local.get $10)
                   )
                   (local.get $12)
                  )
                 )
                 (if (result (ref null $type32))
                  (ref.is_null
                   (local.tee $10
                    (struct.get $type32 1
                     (local.get $10)
                    )
                   )
                  )
                  (then
                   (local.get $12)
                  )
                  (else
                   (local.set $12
                    (struct.new $type32
                     (struct.get $type32 0
                      (local.get $10)
                     )
                     (local.get $12)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.tee $10
                      (struct.get $type32 1
                       (local.get $10)
                      )
                     )
                    )
                    (then
                     (local.get $12)
                    )
                    (else
                     (call $function92
                      (i32.const 0)
                      (i32.const 1)
                      (struct.get $type32 1
                       (local.get $10)
                      )
                      (struct.new $type32
                       (struct.get $type32 0
                        (local.get $10)
                       )
                       (local.get $12)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready173)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type77 1
      (global.get $global173)
     )
    )
    (if
     (i32.eqz
      (global.get $ready175)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global175)
     )
    )
    (local.set $16
     (struct.new $type114
      (i32.const 1)
     )
    )
    (if
     (call $function67
      (local.get $10)
      (i32.const 0)
      (i32.const 1)
      (if (result (ref $type35))
       (ref.is_null
        (local.get $10)
       )
       (then
        (global.get $empty36)
       )
       (else
        (struct.new $type37
         (struct.new $type38
          (struct.new $environment64
           (local.get $16)
           (local.get $10)
           (ref.null none)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $5)
       )
       (then
        (unreachable)
       )
      )
      (local.set $11
       (call $function169
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $4)
        (local.get $5)
        (i64.add
         (local.get $6)
         (i64.const 1)
        )
        (local.get $13)
        (local.get $14)
        (local.get $11)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function172
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (local.get $14)
     (local.get $11)
    )
   )
  )
 )
 (func $function173 (type $call5) (result i64)
  (local $0 i64)
  (local $1 (ref $type111))
  (local $scratch i64)
  (if
   (i32.eqz
    (global.get $ready536)
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch
   (call $foreign1
    (struct.get $type111 0
     (global.get $global536)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready536)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type111 0
   (ref.as_non_null
    (global.get $global536)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready536)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (struct.get $type111 0
      (global.get $global536)
     )
     (i64.const 1)
    )
   )
  )
  (local.get $scratch)
 )
 (func $function175 (type $10) (param $0 i64) (param $1 (ref $type16)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref $type16))
  (local $5 i64)
  (local $6 i32)
  (local $7 (ref $type111))
  (if (result (ref $type16))
   (i64.eq
    (local.get $0)
    (local.get $4)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready537)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global537)
     )
    )
    (if
     (i32.eqz
      (global.get $ready536)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call $foreign1
      (struct.get $type111 0
       (global.get $global536)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready536)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type111 0
     (ref.as_non_null
      (global.get $global536)
     )
     (block (result i64)
      (if
       (i32.eqz
        (global.get $ready536)
       )
       (then
        (unreachable)
       )
      )
      (i64.add
       (struct.get $type111 0
        (global.get $global536)
       )
       (i64.const 1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 2
        (local.get $1)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 3
          (local.get $1)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function175
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function176 (type $call113) (param $0 i64) (result (ref null $type54))
  (local $1 i64)
  (local $2 i64)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 (ref $type111))
  (local $9 (ref null $type30))
  (local $10 (ref null $type18))
  (local $11 (ref $type49))
  (local $scratch i64)
  (local $scratch_13 i64)
  (local $scratch_14 i64)
  (local $scratch_15 i64)
  (local $scratch_16 i64)
  (local $scratch_17 i64)
  (local $scratch_18 i64)
  (local $scratch_19 i64)
  (local $scratch_20 i64)
  (local $scratch_21 i64)
  (local $scratch_22 i64)
  (if (result (ref null $type54))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready537)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global537)
     )
    )
    (if
     (i32.eqz
      (global.get $ready536)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type54
     (if (result (ref $type49))
      (i64.eqz
       (block (result i64)
        (local.set $scratch
         (call $foreign1
          (struct.get $type111 0
           (global.get $global536)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready536)
         )
         (then
          (unreachable)
         )
        )
        (struct.set $type111 0
         (ref.as_non_null
          (global.get $global536)
         )
         (block (result i64)
          (if
           (i32.eqz
            (global.get $ready536)
           )
           (then
            (unreachable)
           )
          )
          (i64.add
           (struct.get $type111 0
            (global.get $global536)
           )
           (i64.const 1)
          )
         )
        )
        (local.get $scratch)
       )
      )
      (then
       (if
        (i32.eqz
         (global.get $ready537)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global537)
        )
       )
       (if
        (i32.eqz
         (global.get $ready536)
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (call $foreign1
         (struct.get $type111 0
          (global.get $global536)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready536)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type111 0
        (ref.as_non_null
         (global.get $global536)
        )
        (block (result i64)
         (if
          (i32.eqz
           (global.get $ready536)
          )
          (then
           (unreachable)
          )
         )
         (i64.add
          (struct.get $type111 0
           (global.get $global536)
          )
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready551)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global551)
        )
       )
       (struct.new $type50
        (if (result (ref null $type32))
         (i64.eqz
          (local.get $1)
         )
         (then
          (ref.null none)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready537)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global537)
           )
          )
          (if
           (i32.eqz
            (global.get $ready536)
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type32
           (call $function178
            (block (result i64)
             (local.set $scratch_13
              (call $foreign1
               (struct.get $type111 0
                (global.get $global536)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready536)
              )
              (then
               (unreachable)
              )
             )
             (struct.set $type111 0
              (ref.as_non_null
               (global.get $global536)
              )
              (block (result i64)
               (if
                (i32.eqz
                 (global.get $ready536)
                )
                (then
                 (unreachable)
                )
               )
               (i64.add
                (struct.get $type111 0
                 (global.get $global536)
                )
                (i64.const 1)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready554)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global554)
              )
             )
             (local.get $scratch_13)
            )
           )
           (block (result (ref null $type32))
            (if
             (i32.eqz
              (global.get $ready551)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global551)
             )
            )
            (if (result (ref null $type32))
             (i64.eqz
              (local.tee $1
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
             )
             (then
              (ref.null none)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready537)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global537)
               )
              )
              (if
               (i32.eqz
                (global.get $ready536)
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type32
               (call $function178
                (block (result i64)
                 (local.set $scratch_14
                  (call $foreign1
                   (struct.get $type111 0
                    (global.get $global536)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready536)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (struct.set $type111 0
                  (ref.as_non_null
                   (global.get $global536)
                  )
                  (block (result i64)
                   (if
                    (i32.eqz
                     (global.get $ready536)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (i64.add
                    (struct.get $type111 0
                     (global.get $global536)
                    )
                    (i64.const 1)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready554)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global554)
                  )
                 )
                 (local.get $scratch_14)
                )
               )
               (block (result (ref null $type32))
                (if
                 (i32.eqz
                  (global.get $ready551)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global551)
                 )
                )
                (if (result (ref null $type32))
                 (i64.eqz
                  (local.tee $1
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (ref.null none)
                 )
                 (else
                  (if
                   (i32.eqz
                    (global.get $ready537)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global537)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready536)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type32
                   (call $function178
                    (block (result i64)
                     (local.set $scratch_15
                      (call $foreign1
                       (struct.get $type111 0
                        (global.get $global536)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready536)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (struct.set $type111 0
                      (ref.as_non_null
                       (global.get $global536)
                      )
                      (block (result i64)
                       (if
                        (i32.eqz
                         (global.get $ready536)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (i64.add
                        (struct.get $type111 0
                         (global.get $global536)
                        )
                        (i64.const 1)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready554)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global554)
                      )
                     )
                     (local.get $scratch_15)
                    )
                   )
                   (block (result (ref null $type32))
                    (if
                     (i32.eqz
                      (global.get $ready551)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global551)
                     )
                    )
                    (if (result (ref null $type32))
                     (i64.eqz
                      (local.tee $1
                       (i64.sub
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (ref.null none)
                     )
                     (else
                      (if
                       (i32.eqz
                        (global.get $ready537)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global537)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready536)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (struct.new $type32
                       (call $function178
                        (block (result i64)
                         (local.set $scratch_16
                          (call $foreign1
                           (struct.get $type111 0
                            (global.get $global536)
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready536)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (struct.set $type111 0
                          (ref.as_non_null
                           (global.get $global536)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready536)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (i64.add
                            (struct.get $type111 0
                             (global.get $global536)
                            )
                            (i64.const 1)
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready554)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global554)
                          )
                         )
                         (local.get $scratch_16)
                        )
                       )
                       (block (result (ref null $type32))
                        (if
                         (i32.eqz
                          (global.get $ready551)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global551)
                         )
                        )
                        (if (result (ref null $type32))
                         (i64.eqz
                          (local.tee $1
                           (i64.sub
                            (local.get $1)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (if
                           (i32.eqz
                            (global.get $ready537)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global537)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready536)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type32
                           (call $function178
                            (block (result i64)
                             (local.set $scratch_17
                              (call $foreign1
                               (struct.get $type111 0
                                (global.get $global536)
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready536)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (struct.set $type111 0
                              (ref.as_non_null
                               (global.get $global536)
                              )
                              (block (result i64)
                               (if
                                (i32.eqz
                                 (global.get $ready536)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (i64.add
                                (struct.get $type111 0
                                 (global.get $global536)
                                )
                                (i64.const 1)
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready554)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global554)
                              )
                             )
                             (local.get $scratch_17)
                            )
                           )
                           (block (result (ref null $type32))
                            (if
                             (i32.eqz
                              (global.get $ready551)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global551)
                             )
                            )
                            (if (result (ref null $type32))
                             (i64.eqz
                              (local.tee $1
                               (i64.sub
                                (local.get $1)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (ref.null none)
                             )
                             (else
                              (if
                               (i32.eqz
                                (global.get $ready537)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global537)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready536)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (struct.new $type32
                               (call $function178
                                (block (result i64)
                                 (local.set $scratch_18
                                  (call $foreign1
                                   (struct.get $type111 0
                                    (global.get $global536)
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready536)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (struct.set $type111 0
                                  (ref.as_non_null
                                   (global.get $global536)
                                  )
                                  (block (result i64)
                                   (if
                                    (i32.eqz
                                     (global.get $ready536)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (i64.add
                                    (struct.get $type111 0
                                     (global.get $global536)
                                    )
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready554)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global554)
                                  )
                                 )
                                 (local.get $scratch_18)
                                )
                               )
                               (block (result (ref null $type32))
                                (if
                                 (i32.eqz
                                  (global.get $ready551)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global551)
                                 )
                                )
                                (if (result (ref null $type32))
                                 (i64.eqz
                                  (local.tee $1
                                   (i64.sub
                                    (local.get $1)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                 (then
                                  (ref.null none)
                                 )
                                 (else
                                  (if
                                   (i32.eqz
                                    (global.get $ready537)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global537)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready536)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type32
                                   (call $function178
                                    (block (result i64)
                                     (local.set $scratch_19
                                      (call $foreign1
                                       (struct.get $type111 0
                                        (global.get $global536)
                                       )
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready536)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (struct.set $type111 0
                                      (ref.as_non_null
                                       (global.get $global536)
                                      )
                                      (block (result i64)
                                       (if
                                        (i32.eqz
                                         (global.get $ready536)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (i64.add
                                        (struct.get $type111 0
                                         (global.get $global536)
                                        )
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready554)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global554)
                                      )
                                     )
                                     (local.get $scratch_19)
                                    )
                                   )
                                   (block (result (ref null $type32))
                                    (if
                                     (i32.eqz
                                      (global.get $ready551)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global551)
                                     )
                                    )
                                    (if (result (ref null $type32))
                                     (i64.eqz
                                      (local.tee $1
                                       (i64.sub
                                        (local.get $1)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                     (then
                                      (ref.null none)
                                     )
                                     (else
                                      (if
                                       (i32.eqz
                                        (global.get $ready537)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global537)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready536)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (struct.new $type32
                                       (call $function178
                                        (block (result i64)
                                         (local.set $scratch_20
                                          (call $foreign1
                                           (struct.get $type111 0
                                            (global.get $global536)
                                           )
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready536)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (struct.set $type111 0
                                          (ref.as_non_null
                                           (global.get $global536)
                                          )
                                          (block (result i64)
                                           (if
                                            (i32.eqz
                                             (global.get $ready536)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (i64.add
                                            (struct.get $type111 0
                                             (global.get $global536)
                                            )
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready554)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global554)
                                          )
                                         )
                                         (local.get $scratch_20)
                                        )
                                       )
                                       (block (result (ref null $type32))
                                        (if
                                         (i32.eqz
                                          (global.get $ready551)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global551)
                                         )
                                        )
                                        (if (result (ref null $type32))
                                         (i64.eqz
                                          (local.tee $1
                                           (i64.sub
                                            (local.get $1)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                         (then
                                          (ref.null none)
                                         )
                                         (else
                                          (if
                                           (i32.eqz
                                            (global.get $ready537)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global537)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready536)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (struct.new $type32
                                           (call $function178
                                            (block (result i64)
                                             (local.set $scratch_21
                                              (call $foreign1
                                               (struct.get $type111 0
                                                (global.get $global536)
                                               )
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready536)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (struct.set $type111 0
                                              (ref.as_non_null
                                               (global.get $global536)
                                              )
                                              (block (result i64)
                                               (if
                                                (i32.eqz
                                                 (global.get $ready536)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (i64.add
                                                (struct.get $type111 0
                                                 (global.get $global536)
                                                )
                                                (i64.const 1)
                                               )
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready554)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global554)
                                              )
                                             )
                                             (local.get $scratch_21)
                                            )
                                           )
                                           (block (result (ref null $type32))
                                            (if
                                             (i32.eqz
                                              (global.get $ready551)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global551)
                                             )
                                            )
                                            (if (result (ref null $type32))
                                             (i64.eqz
                                              (local.tee $1
                                               (i64.sub
                                                (local.get $1)
                                                (i64.const 1)
                                               )
                                              )
                                             )
                                             (then
                                              (ref.null none)
                                             )
                                             (else
                                              (if
                                               (i32.eqz
                                                (global.get $ready537)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global537)
                                               )
                                              )
                                              (struct.new $type32
                                               (call $function178
                                                (block (result i64)
                                                 (local.set $scratch_22
                                                  (call $function173)
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready554)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global554)
                                                  )
                                                 )
                                                 (local.get $scratch_22)
                                                )
                                               )
                                               (block (result (ref null $type32))
                                                (if
                                                 (i32.eqz
                                                  (global.get $ready551)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global551)
                                                 )
                                                )
                                                (call $function177
                                                 (i64.sub
                                                  (local.get $1)
                                                  (i64.const 1)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (else
       (if
        (i32.eqz
         (global.get $ready537)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global537)
        )
       )
       (if
        (i32.eqz
         (global.get $ready536)
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (call $foreign1
         (struct.get $type111 0
          (global.get $global536)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready536)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type111 0
        (ref.as_non_null
         (global.get $global536)
        )
        (block (result i64)
         (if
          (i32.eqz
           (global.get $ready536)
          )
          (then
           (unreachable)
          )
         )
         (i64.add
          (struct.get $type111 0
           (global.get $global536)
          )
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready539)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global539)
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
       )
       (if
        (local.tee $4
         (i32.sub
          (local.tee $3
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (local.tee $6
           (select
            (i32.const 8192)
            (local.get $3)
            (i32.ge_u
             (local.get $3)
             (i32.const 8192)
            )
           )
          )
         )
        )
        (then
         (local.set $10
          (array.new_default $type18
           (i32.shr_u
            (i32.sub
             (local.get $3)
             (i32.const 1)
            )
            (i32.const 13)
           )
          )
         )
         (loop $label
          (array.set $type18
           (local.get $10)
           (local.get $5)
           (array.new_default $type17
            (local.tee $7
             (select
              (i32.const 8192)
              (local.get $4)
              (i32.ge_u
               (local.get $4)
               (i32.const 8192)
              )
             )
            )
           )
          )
          (local.set $5
           (i32.add
            (local.get $5)
            (i32.const 1)
           )
          )
          (br_if $label
           (local.tee $4
            (i32.sub
             (local.get $4)
             (local.get $7)
            )
           )
          )
         )
        )
       )
       (struct.new $type51
        (call $function175
         (local.get $1)
         (struct.new $type16
          (i32.const 1)
          (local.get $3)
          (array.new_default $type17
           (local.get $6)
          )
          (local.get $10)
         )
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
      )
     )
     (block (result (ref null $type54))
      (if
       (i32.eqz
        (global.get $ready548)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global548)
       )
      )
      (call $function176
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function177 (type $call112) (param $0 i64) (result (ref null $type32))
  (local $1 i64)
  (local $2 (ref null $type30))
  (local $scratch i64)
  (if (result (ref null $type32))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready537)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global537)
     )
    )
    (struct.new $type32
     (call $function178
      (block (result i64)
       (local.set $scratch
        (call $function173)
       )
       (if
        (i32.eqz
         (global.get $ready554)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global554)
        )
       )
       (local.get $scratch)
      )
     )
     (block (result (ref null $type32))
      (if
       (i32.eqz
        (global.get $ready551)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global551)
       )
      )
      (call $function177
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function178 (type $7) (param $0 i64) (result (ref null $type30))
  (local $1 i64)
  (local $2 (ref $type111))
  (if (result (ref null $type30))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready537)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global537)
     )
    )
    (if
     (i32.eqz
      (global.get $ready536)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (call $foreign1
      (struct.get $type111 0
       (global.get $global536)
      )
     )
     (block (result (ref null $type30))
      (if
       (i32.eqz
        (global.get $ready536)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type111 0
       (ref.as_non_null
        (global.get $global536)
       )
       (block (result i64)
        (if
         (i32.eqz
          (global.get $ready536)
         )
         (then
          (unreachable)
         )
        )
        (i64.add
         (struct.get $type111 0
          (global.get $global536)
         )
         (i64.const 1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready554)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global554)
       )
      )
      (call $function178
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function179 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (if (result i64)
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready546)
     )
     (then
      (unreachable)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (global.get $global546)
      (i32.const 0)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready544)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready559)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type60 1
      (global.get $global559)
     )
    )
    (local.set $2
     (call $foreign2
      (global.get $global544)
     )
    )
    (if
     (i32.eqz
      (global.get $ready545)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready559)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type60 1
      (global.get $global559)
     )
    )
    (local.set $3
     (call $foreign2
      (global.get $global545)
     )
    )
    (if
     (i32.eqz
      (global.get $ready472)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global472)
     )
    )
    (return_call $function181
     (local.get $1)
     (i32.const 0)
     (i32.const 1)
     (i64.const 1)
     (call $function156
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function180 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign2
   (local.get $2)
  )
 )
 (func $function181 (type $6) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref null $type54)) (result i64)
  (local $5 i64)
  (local $6 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready544)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready559)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type60 1
      (global.get $global559)
     )
    )
    (local.set $4
     (call $function156
      (call $foreign2
       (global.get $global544)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready545)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready559)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type60 1
         (global.get $global559)
        )
       )
       (local.set $scratch
        (call $foreign2
         (global.get $global545)
        )
       )
       (if
        (i32.eqz
         (global.get $ready472)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global472)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function181
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready546)
     )
     (then
      (unreachable)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (global.get $global546)
       (then
        (i32.const 0)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready547)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready148)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global148)
         )
        )
        (call $function54
         (local.get $4)
         (global.get $global547)
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $primitive0 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (struct.new $type32
   (local.get $1)
   (local.get $2)
  )
 )
 (func $primitive1 (type $call57) (param $0 structref) (param $1 (ref null $type30)) (result (ref null $type30))
  (struct.get $type30 1
   (local.get $1)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready557)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function179
   (struct.get $type33 1
    (global.get $global557)
   )
   (local.get $0)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 (ref $type111))
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $ready55
   (i32.const 1)
  )
  (global.set $global218
   (struct.new_default $type11)
  )
  (global.set $ready218
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type15)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type28)
  )
  (global.set $ready103
   (i32.const 1)
  )
  (global.set $global205
   (struct.new_default $type29)
  )
  (global.set $ready205
   (i32.const 1)
  )
  (global.set $global462
   (struct.new_default $type31)
  )
  (global.set $ready462
   (i32.const 1)
  )
  (global.set $global109
   (struct.new $type33
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global194
   (struct.new_default $type34)
  )
  (global.set $ready194
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type43)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type48)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global351
   (struct.new_default $type31)
  )
  (global.set $ready351
   (i32.const 1)
  )
  (global.set $global239
   (struct.new_default $type52)
  )
  (global.set $ready239
   (i32.const 1)
  )
  (global.set $global470
   (struct.new_default $type53)
  )
  (global.set $ready470
   (i32.const 1)
  )
  (global.set $global269
   (struct.new $type55
    (ref.func $function91)
    (ref.null none)
   )
  )
  (global.set $ready269
   (i32.const 1)
  )
  (global.set $global305
   (struct.new_default $type56)
  )
  (global.set $ready305
   (i32.const 1)
  )
  (global.set $global316
   (struct.new_default $type58)
  )
  (global.set $ready316
   (i32.const 1)
  )
  (global.set $global328
   (struct.new_default $type59)
  )
  (global.set $ready328
   (i32.const 1)
  )
  (global.set $global121
   (struct.new $type61
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global368
   (struct.new $type61
    (ref.func $function119)
    (ref.null none)
   )
  )
  (global.set $ready368
   (i32.const 1)
  )
  (global.set $global123
   (struct.new $type61
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $ready123
   (i32.const 1)
  )
  (global.set $global125
   (struct.new $type60
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global202
   (struct.new_default $type62)
  )
  (global.set $ready202
   (i32.const 1)
  )
  (global.set $global280
   (struct.new_default $type63)
  )
  (global.set $ready280
   (i32.const 1)
  )
  (global.set $global211
   (struct.new_default $type63)
  )
  (global.set $ready211
   (i32.const 1)
  )
  (global.set $global131
   (struct.new_default $type64)
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type65)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type66)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type67)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type68)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global145
   (struct.new_default $type69)
  )
  (global.set $ready145
   (i32.const 1)
  )
  (global.set $global148
   (struct.new_default $type70)
  )
  (global.set $ready148
   (i32.const 1)
  )
  (global.set $global151
   (struct.new_default $type71)
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type72)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global157
   (struct.new_default $type73)
  )
  (global.set $ready157
   (i32.const 1)
  )
  (global.set $global559
   (struct.new $type60
    (ref.func $function180)
    (ref.null none)
   )
  )
  (global.set $ready559
   (i32.const 1)
  )
  (global.set $global159
   (struct.new $type60
    (ref.func $function59)
    (ref.null none)
   )
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global166
   (struct.new $type60
    (ref.func $function60)
    (ref.null none)
   )
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global435
   (struct.new_default $type74)
  )
  (global.set $ready435
   (i32.const 1)
  )
  (global.set $global447
   (struct.new_default $type75)
  )
  (global.set $ready447
   (i32.const 1)
  )
  (global.set $global449
   (struct.new_default $type76)
  )
  (global.set $ready449
   (i32.const 1)
  )
  (global.set $global173
   (struct.new $type77
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $ready173
   (i32.const 1)
  )
  (global.set $global198
   (struct.new_default $type78)
  )
  (global.set $ready198
   (i32.const 1)
  )
  (global.set $global229
   (struct.new_default $type79)
  )
  (global.set $ready229
   (i32.const 1)
  )
  (global.set $global247
   (struct.new $type81
    (struct.new_default $environment86)
   )
  )
  (global.set $ready247
   (i32.const 1)
  )
  (global.set $global175
   (struct.new_default $type82)
  )
  (global.set $ready175
   (i32.const 1)
  )
  (global.set $global184
   (struct.new_default $type83)
  )
  (global.set $ready184
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type85)
  )
  (global.set $ready235
   (i32.const 1)
  )
  (global.set $global283
   (struct.new_default $type86)
  )
  (global.set $ready283
   (i32.const 1)
  )
  (global.set $global408
   (struct.new_default $type90)
  )
  (global.set $ready408
   (i32.const 1)
  )
  (global.set $global384
   (struct.new_default $type95)
  )
  (global.set $ready384
   (i32.const 1)
  )
  (global.set $global289
   (struct.new_default $type89)
  )
  (global.set $ready289
   (i32.const 1)
  )
  (global.set $global333
   (struct.new_default $type92)
  )
  (global.set $ready333
   (i32.const 1)
  )
  (global.set $global406
   (struct.new_default $type101)
  )
  (global.set $ready406
   (i32.const 1)
  )
  (global.set $global431
   (struct.new $type33
    (ref.func $function143)
    (ref.null none)
   )
  )
  (global.set $ready431
   (i32.const 1)
  )
  (global.set $global452
   (struct.new $type33
    (ref.func $function150)
    (ref.null none)
   )
  )
  (global.set $ready452
   (i32.const 1)
  )
  (global.set $global475
   (struct.new_default $type102)
  )
  (global.set $ready475
   (i32.const 1)
  )
  (global.set $global457
   (struct.new_default $type103)
  )
  (global.set $ready457
   (i32.const 1)
  )
  (global.set $global472
   (struct.new_default $type105)
  )
  (global.set $ready472
   (i32.const 1)
  )
  (global.set $global525
   (struct.new_default $type106)
  )
  (global.set $ready525
   (i32.const 1)
  )
  (global.set $global509
   (struct.new_default $type107)
  )
  (global.set $ready509
   (i32.const 1)
  )
  (global.set $global488
   (struct.new_default $type108)
  )
  (global.set $ready488
   (i32.const 1)
  )
  (global.set $global536
   (struct.new_default $type111)
  )
  (global.set $ready536
   (i32.const 1)
  )
  (global.set $global537
   (struct.new_default $type5)
  )
  (global.set $ready537
   (i32.const 1)
  )
  (global.set $global554
   (struct.new_default $type85)
  )
  (global.set $ready554
   (i32.const 1)
  )
  (global.set $global551
   (struct.new_default $type112)
  )
  (global.set $ready551
   (i32.const 1)
  )
  (global.set $global548
   (struct.new_default $type113)
  )
  (global.set $ready548
   (i32.const 1)
  )
  (global.set $global539
   (struct.new_default $type15)
  )
  (global.set $ready539
   (i32.const 1)
  )
  (global.set $global544
   (call $foreign3
    (i32.const 0)
   )
  )
  (global.set $ready544
   (i32.const 1)
  )
  (global.set $global545
   (call $foreign3
    (i32.const 1)
   )
  )
  (global.set $ready545
   (i32.const 1)
  )
  (global.set $global546
   (i64.eq
    (call $foreign3
     (i32.const 2)
    )
    (i64.const 1)
   )
  )
  (global.set $ready546
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready537)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global537)
   )
  )
  (if
   (i32.eqz
    (global.get $ready536)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global547
   (call $function176
    (block (result i64)
     (local.set $scratch
      (call $foreign1
       (struct.get $type111 0
        (global.get $global536)
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready536)
      )
      (then
       (unreachable)
      )
     )
     (struct.set $type111 0
      (ref.as_non_null
       (global.get $global536)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready536)
        )
        (then
         (unreachable)
        )
       )
       (i64.add
        (struct.get $type111 0
         (global.get $global536)
        )
        (i64.const 1)
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready548)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global548)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (global.set $ready547
   (i32.const 1)
  )
  (global.set $global557
   (struct.new $type33
    (ref.func $function179)
    (ref.null none)
   )
  )
  (global.set $ready557
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

