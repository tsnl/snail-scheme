"""Preserve Matrix's modular search, continuation order, and shared list tails."""

import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

from data_ports import form


# ---- Each preparation process owns a bounded process group ----

def group_members(group):
    members = []
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields = path.read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] not in ('Z', 'X'):
                members.append(int(path.parent.name))
        except (OSError, ValueError, IndexError):
            pass
    return members


def clean_group(group):
    deadline = time.monotonic() + 5
    while True:
        try:
            os.killpg(group, signal.SIGKILL)
        except ProcessLookupError:
            pass
        members = group_members(group)
        if not members or time.monotonic() >= deadline:
            return members
        time.sleep(0.02)


def execute(command, cwd, environment, timeout=1200, stdin=None):
    started, command = time.perf_counter(), list(map(str, command))
    try:
        child = subprocess.Popen(command, cwd=cwd, env=environment, text=True,
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, start_new_session=True)
    except OSError as error:
        return dict(command=command, error=str(error), process_seconds=time.perf_counter() - started)
    return finish_process(child, command, started, timeout, stdin)


def finish_process(child, command, started, timeout, stdin):
    expired, stdout, stderr = False, '', ''
    try:
        stdout, stderr = child.communicate(stdin, timeout=timeout)
    except subprocess.TimeoutExpired:
        expired = True
        clean_group(child.pid)
        stdout, stderr = child.communicate(timeout=10)
    finally:
        remaining = clean_group(child.pid)
    return dict(command=command, returncode=child.returncode, stdout=stdout, stderr=stderr,
                timeout=expired, process_group=child.pid, executing_descendants=remaining,
                process_seconds=time.perf_counter() - started)


# ---- Explicit alternatives for the source's mixed pairs and messages ----

STRICT_TYPES = '''(define-data (Permutation T)
  (no-permutation)
  (permutation (dispatch (-> I64 (PermutationReply T)) permutation-dispatch)))
(define-data (PermutationReply T)
  (current-object (value T current-value))
  (next-permutation (value (Permutation T) next-value))
  (remaining-objects (value (List T) remaining-values)))
(define-data (GcdResult T)
  (gcd-value (value T gcd-result-value))
  (gcd-negative (sign I64 gcd-sign) (magnitude I64 gcd-magnitude)))
(define-data PrimeList
  (no-primes)
  (prime-node (value I64 prime-value) (tail (Ref PrimeList) prime-tail)))
(define-data Answer
  (matrix-answer (value (List (List I64)) answer-matrix))
  (marker-answer (value String answer-marker)))
(define-data Best
  (best (size I64 best-size) (count I64 best-count) (answers (List Answer) best-answers)))
(: permutation? (All (T) (-> (Permutation T) Bool)))
(define (permutation? value)
  (match value ((no-permutation) #f) ((permutation dispatch) #t)))
(define (prime-null? value)
  (match value ((no-primes) #t) ((prime-node head tail) #f)))
(define (matrix-answer? value)
  (match value ((matrix-answer matrix) #t) ((marker-answer text) #f)))
'''
CHEZ_TYPES = '''(define-syntax : (syntax-rules () ((_ . signature) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define (ref value) (vector value))
(define (ref-get value) (vector-ref value 0))
(define (ref-set! cell value) (vector-set! cell 0 value))
(define ref-eq? eq?)
(define (unit) (if #f #f))
(define (unreachable) (error 'matrix "invalid typed Matrix value"))
(define (no-permutation) #f)
(define (permutation dispatch) dispatch)
(define permutation-dispatch values)
(define permutation? procedure?)
(define (current-object value) (vector 0 value))
(define (next-permutation value) (vector 1 value))
(define (remaining-objects value) (vector 2 value))
(define (current-value value) (vector-ref value 1))
(define next-value current-value)
(define remaining-values current-value)
(define (gcd-value value) (vector 0 value))
(define gcd-result-value current-value)
(define (gcd-negative sign magnitude) (vector 1 sign magnitude))
(define (gcd-sign value) (vector-ref value 1))
(define (gcd-magnitude value) (vector-ref value 2))
(define (no-primes) '())
(define (prime-node value tail) (cons value tail))
(define prime-value car)
(define prime-tail cdr)
(define prime-null? null?)
(define (matrix-answer value) (vector 0 value))
(define (marker-answer value) (vector 1 value))
(define answer-matrix current-value)
(define answer-marker current-value)
(define (matrix-answer? value) (= (vector-ref value 0) 0))
(define (best size count answers) (vector size count answers))
(define (best-size value) (vector-ref value 0))
(define (best-count value) (vector-ref value 1))
(define (best-answers value) (vector-ref value 2))
'''
CONTROL = '''(define-syntax case
  (syntax-rules (else)
    ((_ key) (unreachable))
    ((_ key (else body ...)) (begin body ...))
    ((_ key ((datum ...) body ...) rest ...)
     (let ((value key))
       (if (or (= value datum) ...) (begin body ...) (case value rest ...))))))
(define-syntax map
  (syntax-rules ()
    ((_ procedure values) (map-one procedure values))
    ((_ procedure first second) (map-two procedure first second))))
'''
COMMON = ''';; These lists are persistent. Only the prime-list tail and last box
;; are mutable; the predicate closure continues to see the original head.
(: list (All (T) (-> (Rest T) (List T))))
(define (list . values) values)
(: reverse (All (T) (-> (List T) (List T))))
(define (reverse values)
  (let loop ((tail values) (result '()))
    (if (null? tail) result (loop (cdr tail) (cons (car tail) result)))))
(: map-one (All (A B) (-> (-> A B) (List A) (List B))))
(define (map-one procedure values)
  (if (null? values) '()
      (let ((head (procedure (car values))))
        (cons head (map-one procedure (cdr values))))))
(: map-two (All (A B C) (-> (-> A B C) (List A) (List B) (List C))))
(define (map-two procedure first second)
  (if (null? first) '()
      (let ((head (procedure (car first) (car second))))
        (cons head (map-two procedure (cdr first) (cdr second))))))
(: exact-integer? (-> I64 Bool))
(define (exact-integer? value) #t)
(define (zero? value) (= value 0))
(define (even? value) (= (remainder value 2) 0))
(: expt (-> I64 I64 I64))
(define (expt base exponent)
  (if (< exponent 0) (unreachable)
      (let loop ((left exponent) (value 1))
        (if (= left 0) value (loop (- left 1) (* value base))))))
(: perm-now (All (T) (-> (Permutation T) T)))
(define (perm-now value) (current-value ((permutation-dispatch value) 0)))
(: perm-brother (All (T) (-> (Permutation T) (Permutation T))))
(define (perm-brother value) (next-value ((permutation-dispatch value) 1)))
(: perm-child (All (T) (-> (Permutation T) (Permutation T))))
(define (perm-child value) (next-value ((permutation-dispatch value) 2)))
(: perm-puke (All (T) (-> (Permutation T) (List T))))
(define (perm-puke value) (remaining-values ((permutation-dispatch value) 3)))
(define (prime-cons head tail) (prime-node head (ref tail)))
(define (prime-cdr value) (ref-get (prime-tail value)))
(define (prime-set-cdr! value tail) (ref-set! (prime-tail value) tail))
(: same-row? (-> (List I64) (List I64) Bool))
(define (same-row? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (= (car left) (car right))
           (same-row? (cdr left) (cdr right)))))
(: same-matrix? (-> (List (List I64)) (List (List I64)) Bool))
(define (same-matrix? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (same-row? (car left) (car right))
           (same-matrix? (cdr left) (cdr right)))))
(define (same-answer? left right)
  (if (matrix-answer? left)
      (and (matrix-answer? right) (same-matrix? (answer-matrix left) (answer-matrix right)))
      (and (not (matrix-answer? right)) (string=? (answer-marker left) (answer-marker right)))))
(define (same-answers? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (same-answer? (car left) (car right))
           (same-answers? (cdr left) (cdr right)))))
'''
DIAGNOSTICS = '''(define-extern write-character "benchmark" "write_character" (-> Char Unit))
(define (matrix-write-text text)
  (let loop ((index 0))
    (unless (= index (string-length text))
      (write-character (string-ref text index)) (loop (+ index 1)))))
(define (matrix-write-natural value)
  (unless (< value 10) (matrix-write-natural (quotient value 10)))
  (write-character (integer->char (+ 48 (remainder value 10)))))
(define (permutation-error code)
  (matrix-write-text "gen-perms: Bad msg: ~a; message code ")
  (if (< code 0)
      (begin (write-character #\\-) (matrix-write-natural (- code)))
      (matrix-write-natural code))
  (write-character #\\newline)
  (unreachable))
'''


# ---- Contracts constrain numbers without changing the algorithm ----

ROW = '(List I64)'
MATRIX = f'(List {ROW})'
FIELD = 'I64 I64 (-> I64 Bool) (-> I64 I64 I64) (-> I64 I64) (-> I64 I64 I64) (-> I64 I64)'
CONTRACTS = f'''(: div (-> I64 I64 I64))
(: mod (-> I64 I64 I64))
(: maximal? (-> {MATRIX} Bool))
(: zunda (-> (Permutation {ROW}) {MATRIX} Bool))
(: zebra (-> (Permutation {ROW}) (-> {ROW} (-> I64 I64))
               (-> {ROW} (-> I64 I64)) {MATRIX} I64 Bool))
(: zulu (-> {ROW} (-> I64 I64) {MATRIX} (-> {MATRIX} Bool) Bool))
(: all? (All (T) (-> (-> T Bool) (List T) Bool)))
(: gen-perms (All (T) (-> (List T) (Permutation T))))
(: fold (All (A S) (-> (List A) (-> A S S) S S)))
(: miota (-> I64 {ROW}))
(: proc->vector (-> I64 (-> I64 I64) (Vector I64)))
(: make-modular (All (T) (-> I64 (-> (-> {FIELD} T) T))))
(: extended-gcd (All (T) (-> I64 I64 (-> I64 I64 I64 T) (GcdResult T))))
(: make-row-reduce (-> {FIELD} (-> {MATRIX} {MATRIX})))
(: make-in-row-space? (-> {FIELD} (-> {MATRIX} (-> {ROW} Bool))))
(: make-modular-row-reduce (-> I64 (-> {MATRIX} {MATRIX})))
(: make-modular-in-row-space? (-> I64 (-> {MATRIX} (-> {ROW} Bool))))
(: find-prime (-> I64 I64))
(: det-upper-bound (-> I64 I64))
(: go (All (S) (-> I64 I64 (-> {MATRIX} S S) S S)))
(: go-folder (-> {MATRIX} Best Best))
(: really-go (-> I64 I64 (List Answer)))
(: remove-in-order (All (T) (-> (-> T Bool) (List T) (List T))))
(: fold-over-rows (All (S) (-> I64 (-> {ROW} S S) S S)))
(: fold-over-subs-of-size (All (T S) (-> (List T) I64 (-> (List T) S S) S S)))
'''


# ---- Counted reversible edits preserve the complete source kernel ----

def adaptation(source):
    ledger = []

    def edit(before, after, count=1, reason='concrete representation'):
        nonlocal source
        if source.count(before) != count:
            raise ValueError(f'expected {count} occurrences of {before!r}, got {source.count(before)}')
        ledger.append(dict(before=before, after=after, count=count, reason=reason))
        source = source.replace(before, after)

    edit("(define (chez-box x) (cons x '()))", '(define (chez-box x) (ref x))')
    edit('(define (chez-unbox x) (car x))', '(define (chez-unbox x) (ref-get x))')
    edit('(define (chez-set-box! x y) (set-car! x y))', '(define (chez-set-box! x y) (ref-set! x y))')
    edit('(if first-row-perm', '(if (permutation? first-row-perm)')
    for name, count in (('row-perm', 1), ('new-row-perm', 1)):
        edit(f'(not {name})', f'(not (permutation? {name}))', count)
    for variable, message, count in (('first-row-perm', 'brother', 1), ('first-row-perm', 'now', 1),
                                     ('first-row-perm', 'child', 1), ('row-perm', 'now', 2),
                                     ('row-perm', 'child', 2), ('row-perm', 'brother', 1)):
        edit(f"({variable} '{message})", f'(perm-{message} {variable})', count)
    permutation = form(source, '(define gen-perms')
    changed = permutation.replace('#f', '(no-permutation)').replace('(lambda (msg)', '(permutation (lambda (msg)')
    changed = changed.replace('((now)\n               (car zulu-future))', '((0)\n               (current-object (car zulu-future)))')
    changed = changed.replace('((brother)\n               (_-*-', '((1)\n               (next-permutation (_-*-')
    changed = changed.replace('past)))', 'past))))')
    changed = changed.replace('((child)\n               (gen-perms', '((2)\n               (next-permutation (gen-perms')
    changed = changed.replace('(fold past cons (cdr zulu-future))))', '(fold past cons (cdr zulu-future)))))', 1)
    changed = changed.replace('((puke)\n               (cons', '((3)\n               (remaining-objects (cons')
    changed = changed.replace('(fold past cons (cdr zulu-future))))\n              (else', '(fold past cons (cdr zulu-future)))))\n              (else')
    changed = changed.replace('(error \'gen-perms "Bad msg: ~a" msg)', '(permutation-error msg)') + ')'
    edit(permutation, changed, reason='retain lazy message closure; explicitly tag each reply and the absent cursor')
    edit('((= i number-of-cols))', '((= i number-of-cols) (unit))', reason='omitted do result is Unit')
    edit('((= i size))', '((= i size) (unit))', reason='omitted do result is Unit')
    edit('(cons -1 (- x))', '(gcd-negative -1 (- x))', reason='preserve original negative-input improper pair and skipped continuation')
    edit('(cont p p-a p-b)', '(gcd-value (cont p p-a p-b))')
    edit('(extended-gcd (+ i 1)\n                                                 modulus\n                                                 (lambda (gcd inverse ignore)\n                                                   inverse))',
         '(gcd-result-value (extended-gcd (+ i 1)\n                                                 modulus\n                                                 (lambda (gcd inverse ignore)\n                                                   inverse)))')
    prime = form(source, '(define find-prime')
    changed = prime.replace('(list 2)', '(prime-cons 2 (no-primes))').replace('(list trial)', '(prime-cons trial (no-primes))')
    for before, after in (('null?', 'prime-null?'), ('car', 'prime-value'), ('cdr', 'prime-cdr'), ('set-cdr!', 'prime-set-cdr!')):
        changed = re.sub(r'\(' + re.escape(before) + r'(?=\s)', '(' + after, changed)
    edit(prime, changed, reason='mutable prime spine retains original head and last-node aliases')
    edit('(car bsize.blen.blist)', '(best-size bsize.blen.blist)')
    edit('(cadr bsize.blen.blist)', '(best-count bsize.blen.blist)')
    edit('(cddr bsize.blen.blist)', '(best-answers bsize.blen.blist)')
    edit('(cons bsize\n                        (cons blen', '(best bsize\n                        blen')
    edit('(cons mat blist)', '(cons (matrix-answer mat) blist)')
    edit('(cons "..." blist)', '(cons (marker-answer "...") blist)')
    edit('                                     blist)))))', '                                     blist))))')
    edit('(list size 1 mat)', '(best size 1 (list (matrix-answer mat)))')
    edit('(cddr\n     (go number-of-cols', '(best-answers\n     (go number-of-cols')
    edit('(list -1 -1)', "(best -1 -1 '())")
    return source, ledger


def kernel(source):
    return CONTRACTS + adaptation(source)[0]


# ---- Complete expected values are read before the original worker ----

INPUTS = '''(define-extern native-expected-i64 "benchmark" "expected_i64" (-> I64 I64))
(define expected-cursor (ref 0))
(define (read-expected-integer)
  (let ((value (native-expected-i64 (ref-get expected-cursor))))
    (ref-set! expected-cursor (+ 1 (ref-get expected-cursor))) value))
(define (read-expected-row count)
  (if (= count 0) '()
      (let ((head (read-expected-integer))) (cons head (read-expected-row (- count 1))))))
(define (read-expected-matrix count)
  (if (= count 0) '()
      (let ((head (read-expected-row (read-expected-integer))))
        (cons head (read-expected-matrix (- count 1))))))
(define (read-expected-answers count)
  (if (= count 0) '()
      (let ((head (if (= (read-expected-integer) 0)
                      (matrix-answer (read-expected-matrix (read-expected-integer)))
                      (marker-answer (read-expected-string (read-expected-integer))))))
        (cons head (read-expected-answers (- count 1))))))
(define (read-expected-string count)
  (let ((value (make-string count)))
    (let loop ((index 0))
      (if (= index count) value
          (begin (string-set! value index (integer->char (read-expected-integer)))
                 (loop (+ index 1)))))))
(define input0 (native-input-i64 (ann 0 I32)))
(define input1 (native-input-i64 (ann 1 I32)))
(define expected-false? (= (native-input-i64 (ann 2 I32)) 1))
(define expected (read-expected-answers (read-expected-integer)))
'''
WORKER = '''(if (<= count 0) (if expected-false? 1 0)
  (let loop ((i 1) (result (really-go (hide count input0) (hide count input1))))
    (if (< i count)
        (loop (+ i 1) (really-go (hide count input0) (hide count input1)))
        (if (and (not expected-false?) (same-answers? result expected)) 1 0))))'''
CHEZ_BOUNDARY = '''(define (matrix-read-answers value)
  (and value (map-one (lambda (answer)
                       (if (string? answer) (marker-answer answer) (matrix-answer answer))) value)))
(define (matrix-same-result? value expected)
  (if value (and expected (same-answers? value expected)) (not expected)))
(define (permutation-error code)
  (display "gen-perms: Bad msg: ~a; message code ") (display code) (newline)
  (unreachable))
'''


def encode_answers(answers):
    if answers is False:
        return [0]
    encoded = [len(answers)]
    for answer in answers:
        if isinstance(answer, str):
            encoded.extend([1, len(answer), *map(ord, answer)])
        else:
            encoded.extend([0, len(answer)])
            for row in answer:
                encoded.extend([len(row), *row])
    return encoded


def specification(data):
    from measure import input_values
    count, columns, size, answers = input_values(data.decode())
    return dict(name='matrix', count=count, inputs=[columns, size, 0],
                expected=encode_answers(answers), original_expected=answers,
                result_kind='i64-list-values', barriers_per_iteration=2)


def adapt_chez_harness(source, reverse=False):
    replacements = [('(output (read))', '(output (matrix-read-answers (read)))'),
                    ('(equal? result output)', '(matrix-same-result? result output)')]
    for before, after in replacements:
        before, after = (after, before) if reverse else (before, after)
        if source.count(before) != 1:
            raise ValueError('Matrix harness boundary must occur once: ' + before)
        source = source.replace(before, after)
    return source


# ---- Supplemental observations exercise callbacks and shared identities ----

PROBE_COMMON = '''(define (emit-bool value) (emit-i64 (if value 1 0)))
(: emit-list (All (T) (-> (-> T Unit) (List T) Unit)))
(define (emit-list emit values)
  (emit-i64 (length values))
  (let loop ((tail values))
    (unless (null? tail) (emit (car tail)) (loop (cdr tail)))))
(define (emit-row value) (emit-list emit-i64 value))
(define (emit-matrix value) (emit-list emit-row value))
(define (emit-refs value) (emit-list (lambda (cell) (emit-i64 (ref-get cell))) value))
(define (emit-answer value)
  (if (probe-matrix-answer? value)
      (begin (emit-i64 0) (emit-matrix (probe-answer-matrix value)))
      (begin (emit-i64 1) (emit-list (lambda (char) (emit-i64 (char->integer char)))
                                  (string->list (probe-answer-marker value))))))
(define (emit-best value)
  (emit-i64 (probe-best-size value)) (emit-i64 (probe-best-count value))
  (emit-list emit-answer (probe-best-answers value)))
(define (observe-primes primes last)
  (emit-i64 900)
  (let loop ((tail primes))
    (unless (probe-prime-null? tail)
      (emit-i64 (probe-prime-value tail)) (loop (probe-prime-cdr tail))))
  (emit-i64 0) (emit-i64 (probe-prime-value last))
  (let loop ((tail primes))
    (if (probe-prime-null? (probe-prime-cdr tail))
        (emit-bool (probe-prime-same? tail last))
        (loop (probe-prime-cdr tail)))))
(define (probe-numbers)
  (fold (list -7 -6 0 6 7)
        (lambda (x state)
          (fold (list -3 3)
                (lambda (y state) (emit-i64 (div x y)) (emit-i64 (mod x y)) state) state)) 0)
  (fold (list 0 1 2 3 4 5 6)
        (lambda (size state) (emit-i64 (det-upper-bound size)) state) 0)
  (fold (list 30 -30)
        (lambda (a state)
          (fold (list 21 -21)
                (lambda (b state)
                  (emit-gcd (extended-gcd a b (lambda (g x y)
                    (emit-i64 901) (emit-i64 g) (emit-i64 x) (emit-i64 y) (+ g 40)))) state) state)) 0)
  ((make-modular 7)
   (lambda (zero one zero? add negate multiply reciprocal)
     (emit-i64 zero) (emit-i64 one) (emit-bool (zero? -14))
     (emit-i64 (add -4 3)) (emit-i64 (negate 3)) (emit-i64 (multiply -3 4))
     (fold (list 1 2 3 4 5 6) (lambda (value state) (emit-i64 (reciprocal value)) state) 0))))
(define (probe-row-and-subset-order)
  (emit-i64 (fold-over-rows 3 (lambda (row count) (emit-row row) (+ count 1)) 0))
  (let ((universe (list 10 20 30 40)))
    (fold (list 0 1 2 3 4 5)
          (lambda (size state)
            (emit-i64 size)
            (emit-i64 (fold-over-subs-of-size universe size
                       (lambda (subset count) (emit-row subset) (+ count 1)) 0)) state) 0)))
(define (probe-permutation-tree cursor)
  (when (probe-permutation? cursor)
    (emit-i64 (ref-get (probe-perm-now cursor)))
    (emit-refs (probe-perm-puke cursor))
    (probe-permutation-tree (probe-perm-child cursor))
    (probe-permutation-tree (probe-perm-brother cursor))))
(define (probe-order-and-aliases)
  (probe-row-and-subset-order)
  (let* ((first (ref 1)) (second (ref 2)) (third (ref 3))
         (values (list first second third)) (cursor (gen-perms values)))
    (probe-permutation-tree cursor)
    (ref-set! (probe-perm-now (probe-perm-brother cursor)) 20)
    (emit-refs values)
    (emit-bool (ref-eq? (probe-perm-now cursor) first))
    (emit-bool (ref-eq? (probe-perm-now (probe-perm-child cursor)) second))
    (let ((selected (remove-in-order (lambda (cell)
                      (emit-i64 902) (emit-i64 (ref-get cell)) (= (ref-get cell) 20)) values)))
      (emit-refs selected)
      (emit-bool (ref-eq? (car selected) first))
      (emit-bool (ref-eq? (car (cdr selected)) third)))
    (emit-bool (all? (lambda (cell) (emit-i64 903) (emit-i64 (ref-get cell))
                      (< (ref-get cell) 10)) values)))
  (emit-bool (all? (lambda (value) (unreachable)) (ann '() (List I64))))
  (let ((values (proc->vector 4 (lambda (index)
                  (emit-i64 904) (emit-i64 index) (* index index)))))
    (emit-row (vector->list values))))
(define (probe-linear-algebra)
  (let ((reduce (make-modular-row-reduce 7)))
    (emit-matrix (reduce '()))
    (emit-matrix (reduce (list (list 0 0 0) (list 0 0 0))))
    (emit-matrix (reduce (list (list 0 2 4) (list 3 1 -1) (list 6 2 -2))))
    (emit-matrix (reduce (list (list 1 1 1) (list 1 -1 1) (list 1 1 -1)))))
  (let ((test ((make-modular-in-row-space? 7) (list (list 1 2 3) (list 2 4 6)))))
    (fold (list (list 0 0 0) (list 3 6 9) (list 1 1 1) (list -1 -2 -3))
          (lambda (row state) (emit-bool (test row)) state) 0))
  (fold probe-maximal-matrices
        (lambda (matrix state) (emit-bool (maximal? matrix)) state) 0))
(define (probe-collector)
  (let* ((matrix (list (list 1)))
         (old (probe-best 1 2998 (list (probe-matrix-answer (list (list -1))))))
         (added (go-folder matrix old))
         (marked (go-folder matrix added))
         (capped (go-folder matrix marked)))
    (emit-best (go-folder '() old))
    (emit-best added) (emit-best marked) (emit-best capped)
    (emit-best (go-folder (list (list 1) (list -1)) capped))
    (emit-best (go-folder matrix (probe-best -1 -1 '())))))
(define (probe-zulu)
  (fold (list (list 1 1 1) (list 1 -1 -1) (list 1 1 -1))
        (lambda (row state)
          (let ((values (list->vector row)))
            (emit-bool (zulu (list 1 1 -1) (lambda (index) (vector-ref values index))
                         (list (list 0 1 2))
                         (lambda (partitions) (emit-i64 905) (emit-matrix partitions) #t)))) state) 0))
(: probe (-> I64 I64 I64 I64))
(define (probe mode columns size)
  (cond ((= mode 0) (emit-list emit-answer (really-go columns size)))
        ((= mode 1) (probe-numbers))
        ((= mode 2) (probe-order-and-aliases))
        ((= mode 3) (probe-linear-algebra))
        ((= mode 4) (probe-collector))
        ((= mode 5) (emit-i64 (find-prime columns)))
        ((= mode 6) (probe-zulu))
        ((= mode 7) (probe-bad-message))
        ((= mode 8)
         (emit-i64 (go columns size (lambda (matrix count)
                       (emit-matrix matrix) (+ count 1)) 0)))
        (else (emit-list emit-answer (really-go columns size))
              (emit-list emit-answer (really-go columns size))))
  1)
'''
STRICT_PROBE = '''(define-extern emit-i64 "benchmark" "emit_i64" (-> I64 Unit))
(define probe-matrix-answer? matrix-answer?)
(define probe-answer-matrix answer-matrix)
(define probe-answer-marker answer-marker)
(define probe-matrix-answer matrix-answer)
(define probe-best best)
(define probe-best-size best-size)
(define probe-best-count best-count)
(define probe-best-answers best-answers)
(define probe-prime-null? prime-null?)
(define probe-prime-value prime-value)
(define probe-prime-cdr prime-cdr)
(define (probe-prime-same? left right) (ref-eq? (prime-tail left) (prime-tail right)))
(define probe-permutation? permutation?)
(define probe-perm-now perm-now)
(define probe-perm-brother perm-brother)
(define probe-perm-child perm-child)
(define probe-perm-puke perm-puke)
(define (emit-gcd value)
  (match value
    ((gcd-value answer) (emit-i64 0) (emit-i64 answer))
    ((gcd-negative sign magnitude) (emit-i64 1) (emit-i64 sign) (emit-i64 magnitude))))
(define (probe-bad-message)
  ((permutation-dispatch (gen-perms (list 1))) 99)
  (unit))
'''
ORIGINAL_PROBE = '''(define-syntax : (syntax-rules () ((_ . signature) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define (unit) (if #f #f))
(define (unreachable) (error 'matrix-probe "unexpected evaluation"))
(define (ref value) (vector value))
(define (ref-get cell) (vector-ref cell 0))
(define (ref-set! cell value) (vector-set! cell 0 value))
(define ref-eq? eq?)
(define (probe-matrix-answer? value) (not (string? value)))
(define probe-answer-matrix values)
(define probe-answer-marker values)
(define probe-matrix-answer values)
(define (probe-best size count answers) (cons size (cons count answers)))
(define probe-best-size car)
(define probe-best-count cadr)
(define probe-best-answers cddr)
(define probe-prime-null? null?)
(define probe-prime-value car)
(define probe-prime-cdr cdr)
(define probe-prime-same? eq?)
(define (probe-permutation? value) (if value #t #f))
(define (probe-perm-now value) (value 'now))
(define (probe-perm-brother value) (value 'brother))
(define (probe-perm-child value) (value 'child))
(define (probe-perm-puke value) (value 'puke))
(define (emit-gcd value)
  (if (pair? value)
      (begin (emit-i64 1) (emit-i64 (car value)) (emit-i64 (cdr value)))
      (begin (emit-i64 0) (emit-i64 value))))
(define (probe-bad-message) ((gen-perms '(1)) 'unsupported-message))
'''


def maximal_fixtures():
    first, rest = [1, 1, 1], [[1, 1, -1], [1, -1, 1], [1, -1, -1]]
    return [[first], [first, first], *[[first, row] for row in rest],
            *[[first, *rows] for rows in itertools.permutations(rest, 2)], [first, *rest]]


def scheme_value(value):
    if isinstance(value, bool):
        return '#t' if value else '#f'
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, int):
        return str(value)
    return '(' + ' '.join(map(scheme_value, value)) + ')'


def scheme_list(value):
    if isinstance(value, int):
        return str(value)
    return '(list ' + ' '.join(map(scheme_list, value)) + ')'


def observed_kernel(source):
    before = '(chez-set-box! last entry)'
    if source.count(before) != 1:
        raise ValueError('one prime append site is required')
    return source.replace(before, '(begin ' + before + ' (observe-primes primes (chez-unbox last)))')


def strict_probe(original, prelude):
    return (prelude + STRICT_TYPES + CONTROL + COMMON + DIAGNOSTICS + STRICT_PROBE
            + observed_kernel(kernel(original)) +
            '(define probe-maximal-matrices ' + scheme_list(maximal_fixtures()) + ')\n' + PROBE_COMMON + '(unit)\n')


def chez_probe(original, adapted):
    interface = STRICT_PROBE.replace('(define-extern emit-i64 "benchmark" "emit_i64" (-> I64 Unit))\n', '')
    interface = interface.replace(form(interface, '(define (emit-gcd '), '''(define (emit-gcd value)
  (if (= (vector-ref value 0) 0)
      (begin (emit-i64 0) (emit-i64 (gcd-result-value value)))
      (begin (emit-i64 1) (emit-i64 (gcd-sign value)) (emit-i64 (gcd-magnitude value)))))''')
    helpers = CHEZ_TYPES + CONTROL + COMMON + CHEZ_BOUNDARY + interface if adapted else ORIGINAL_PROBE
    source = observed_kernel(kernel(original) if adapted else original)
    return ('(import (chezscheme))\n' + helpers +
            '(define (emit-i64 value) (write value) (newline))\n' + source +
            '(define probe-maximal-matrices ' + scheme_list(maximal_fixtures()) + ')\n' + PROBE_COMMON +
            '(probe (read) (read) (read))\n')
