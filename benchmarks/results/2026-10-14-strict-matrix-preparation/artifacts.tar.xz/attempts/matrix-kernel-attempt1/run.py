import json
import os
from pathlib import Path
import shutil
import sys
import traceback

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import matrix_port
import measure

tools = json.loads((ROOT / 'build/matrix-capabilities/tools.json').read_text())
environment = dict(os.environ, **tools, BINARYEN_CORES='1')
for name in ('matrix_port.py', 'measure.py', 'host.mjs'):
    shutil.copy2(ROOT / 'benchmarks/strict-suite' / name, HERE / name)
try:
    upstream = (ROOT / 'benchmarks/r7rs-benchmarks/src/matrix.scm').read_text()
    data = (ROOT / 'benchmarks/r7rs-benchmarks/inputs/matrix.input').read_bytes()
    (HERE / 'upstream.scm').write_text(upstream)
    (HERE / 'input.txt').write_bytes(data)
    spec = measure.case_specification('matrix', data)
    measure.save(HERE / 'spec.json', spec)
    (HERE / 'strict.scm').write_text(measure.strict_program('matrix', spec, upstream))
    measure.save(HERE / 'adaptation.json', matrix_port.adaptation(measure.upstream_kernel(upstream))[1])
    record = matrix_port.execute([ROOT / 'scripts/build-strict', '--export', 'bench', HERE / 'strict.scm', HERE / 'strict.wasm'], ROOT, environment)
    measure.save(HERE / 'build.json', record)
    print(json.dumps(record), flush=True)
    measure.require_success(record)
    measure.save(HERE / 'spec-one.json', dict(spec, count=1))
    for suffix in ('.raw.wasm', ''):
        record = matrix_port.execute([tools['NODE'], HERE / 'host.mjs', HERE / ('strict.wasm' + suffix), HERE / 'spec-one.json', '--validate'], HERE, environment)
        measure.save(HERE / ('raw.json' if suffix else 'optimized.json'), record)
        print(json.dumps(record), flush=True)
        measure.require_success(record)
except Exception as error:
    measure.save(HERE / 'failure.json', dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    raise
