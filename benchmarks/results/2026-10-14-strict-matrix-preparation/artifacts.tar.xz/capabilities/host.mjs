import fs from 'node:fs'; const {instance} = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]), {}); console.log(instance.exports.main().toString());
