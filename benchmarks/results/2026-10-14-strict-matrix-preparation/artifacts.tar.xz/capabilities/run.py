import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import matrix_port

HERE = Path(__file__).resolve().parent
TOOLS = dict(CHIBI='/nix/store/rymbc3gyix886hxf3ns6cr7smmc9swy2-chibi-scheme-0.12/bin/chibi-scheme',
             NODE='/nix/store/lfaydgacdyngci7p60s8wwvgdm74fjkx-nodejs-24.19.0/bin/node',
             WASM_AS='/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin/wasm-as',
             WASM_OPT='/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin/wasm-opt',
             WASM_DIS='/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin/wasm-dis',
             WASM_MERGE='/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin/wasm-merge',
             CHEZ='/nix/store/bzqpmy5kmvf0xn4xh5ixzkw00w9srh07-chez-scheme-10.4.1/bin/scheme')
ENV = dict(os.environ, **TOOLS, BINARYEN_CORES='1')
(HERE / 'tools.json').write_text(json.dumps(TOOLS, indent=2) + '\n')
source = '''(import (snail strict))
''' + matrix_port.STRICT_TYPES + matrix_port.CONTROL + matrix_port.COMMON + '''
(: sample (-> I64 I64))
(define (sample value)
  (let* ((tail (prime-cons 2 (no-primes)))
         (alias tail)
         (last (ref tail))
         (entry (prime-cons value (no-primes)))
         (cursor (permutation (lambda (message)
                    (if (= message 0) (current-object value)
                        (next-permutation (no-permutation)))))))
    (prime-set-cdr! (ref-get last) entry)
    (ref-set! last entry)
    (if (and (permutation? cursor) (not (permutation? (perm-child cursor)))
             (ref-eq? (prime-tail (prime-cdr alias)) (prime-tail (ref-get last))))
        (+ (perm-now cursor) (prime-value (prime-cdr alias))) 0)))
(sample 21)
'''
(HERE / 'strict.scm').write_text(source)
(HERE / 'host.mjs').write_text("import fs from 'node:fs'; const {instance} = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]), {}); console.log(instance.exports.main().toString());\n")
command = [ROOT / 'scripts/build-strict', HERE / 'strict.scm', HERE / 'strict.wasm']
record = matrix_port.execute(command, ROOT, ENV, timeout=120)
(HERE / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
if record.get('returncode') != 0:
    raise SystemExit(1)
for suffix in ('.raw.wasm', ''):
    record = matrix_port.execute([TOOLS['NODE'], HERE / 'host.mjs', HERE / ('strict.wasm' + suffix)], HERE, ENV, timeout=30)
    (HERE / ('run-raw.json' if suffix else 'run-optimized.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if record.get('returncode') != 0 or record['stdout'] != '42\n':
        raise SystemExit(1)
