import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
tools = json.loads((ROOT / 'build/matrix-capabilities/tools.json').read_text())
os.environ.update(tools, BINARYEN_CORES='1')
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import measure

sys.argv = [str(ROOT / 'benchmarks/strict-suite/measure.py'), 'prepare', '--output',
            str(ROOT / 'build' / sys.argv[1]), '--benchmarks', 'matrix', '--compiler-basis', '3dcce40']
measure.main()
