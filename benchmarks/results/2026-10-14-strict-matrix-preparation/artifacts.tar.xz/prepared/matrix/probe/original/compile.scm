(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-matrix-20261014/build/matrix-attempt5/matrix/probe/original/program.scm" "/tmp/snail-strict-matrix-20261014/build/matrix-attempt5/matrix/probe/original/program.so"))
