#include "native-provider.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern void guest_main(void) __asm__("wasm.main");
void load_inputs(const char *);
uint64_t barrier_count(void);
extern int64_t probe(int64_t, int64_t, int64_t) __asm__("wasm.probe");
int main(int argc, char **argv) {
    native_host_init(argc, argv); native_module_init();
    assert(argc == 4);
    guest_main();
    assert(probe(strtoll(argv[1], NULL, 10), strtoll(argv[2], NULL, 10), strtoll(argv[3], NULL, 10)) == 1);
    return native_finish(0);
}
