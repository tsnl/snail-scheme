(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-matrix-20261014/build/matrix-attempt5/matrix/probe/adapted/program.scm" "/tmp/snail-strict-matrix-20261014/build/matrix-attempt5/matrix/probe/adapted/program.so"))
