#include "native-provider.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
static int64_t inputs[3], *expected, expected_count;
static uint64_t barriers;
void load_inputs(const char *path) {
    FILE *file = fopen(path, "r"); assert(file);
    for (int index = 0; index < 3; index++) assert(fscanf(file, "%" SCNd64, &inputs[index]) == 1);
    assert(fscanf(file, "%" SCNd64, &expected_count) == 1);
    assert(expected_count > 0 && expected_count < 1000000);
    expected = malloc((size_t)expected_count * sizeof(*expected)); assert(expected);
    for (int64_t index = 0; index < expected_count; index++)
        assert(fscanf(file, "%" SCNd64, &expected[index]) == 1);
    int64_t extra; assert(fscanf(file, "%" SCNd64, &extra) == EOF); fclose(file);
}
int64_t input_i64(int32_t index) { assert(index >= 0 && index < 3); return inputs[index]; }
int64_t expected_i64(int64_t index) { assert(index >= 0 && index < expected_count); return expected[index]; }
int64_t hide_i64(int64_t value) { barriers++; return value; }
uint64_t barrier_count(void) { return barriers; }
void emit_i64(int64_t value) { printf("%" PRId64 "\n", value); }
void write_character(uint32_t value) {
    if (value < 128) { putchar(value); fflush(stdout); return; }
    unsigned width = value < 2048 ? 2 : value < 65536 ? 3 : 4;
    unsigned first[] = {0, 0, 192, 224, 240};
    putchar(first[width] | (value >> (6 * (width - 1))));
    for (unsigned index = width - 1; index; index--)
        putchar(128 | ((value >> (6 * (index - 1))) & 63));
    fflush(stdout);
}
