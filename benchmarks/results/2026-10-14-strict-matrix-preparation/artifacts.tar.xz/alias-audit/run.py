"""Observe immutable spine identity in the two Chez source controls only."""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import matrix_port as port
import measure as driver

TOOLS = json.loads((ROOT / 'build/matrix-capabilities/tools.json').read_text())
ENV = dict(os.environ, **TOOLS, BINARYEN_CORES='1')
source = (ROOT / 'build/matrix-attempt5/matrix/original-kernel.scm').read_text()
body = '''
(define (check value) (write (if value 1 0)) (newline))
(let* ((a (list 1)) (b (list 2)) (c (list 3))
       (rows (list a b c)) (cursor (gen-perms rows))
       (sibling (probe-perm-brother cursor)) (child (probe-perm-child cursor))
       (puke (probe-perm-puke cursor)) (sibling-puke (probe-perm-puke sibling)))
  (check (eq? (probe-perm-now cursor) a))
  (check (eq? (probe-perm-now cursor) (probe-perm-now cursor)))
  (check (eq? (probe-perm-now sibling) b))
  (check (eq? (probe-perm-now child) b))
  (check (not (eq? puke rows)))
  (check (eq? (cdr puke) (cdr rows)))
  (check (eq? (cddr sibling-puke) (cddr rows)))
  (fold-over-subs-of-size rows 3 (lambda (subset state) (check (eq? subset rows)) state) 0)
  (fold-over-subs-of-size rows 2
    (lambda (subset state)
      (when (eq? (car subset) b) (check (eq? subset (cdr rows)))) state) 0)
  (let ((selected (remove-in-order (lambda (row) (eq? row b)) rows)))
    (check (not (eq? selected rows)))
    (check (not (eq? (cdr selected) (cddr rows))))
    (check (eq? (car selected) a))
    (check (eq? (cadr selected) c)))
  (let* ((matrix (list a b))
         (old (probe-best 2 1 (list (probe-matrix-answer matrix))))
         (same (go-folder (list a) old)) (added (go-folder matrix old)))
    (check (eq? same old))
    (check (eq? (cdr (probe-best-answers added)) (probe-best-answers old)))
    (check (eq? (probe-answer-matrix (car (probe-best-answers added))) matrix))))
'''
records = []
for system, adapted in (('original', False), ('adapted', True)):
    target = HERE / system
    target.mkdir()
    full = port.chez_probe(source, adapted)
    invocation = '(let* ((mode (read)) (columns (read)) (size (read))) (probe mode columns size))\n'
    if full.count(invocation) != 1:
        raise ValueError('one observation entry is required')
    (target / 'program.scm').write_text(full.replace(invocation, body))
    command = [TOOLS['CHEZ'], '--script', target / 'program.scm']
    record = port.execute(command, target, ENV, timeout=30)
    records.append(dict(record, system=system))
    driver.save(HERE / 'validation.json', records)
    driver.require_success(record)
    if record['stderr'] or list(map(int, record['stdout'].split())) != [1] * 16:
        raise ValueError('Chez immutable-spine alias observation differs')
driver.save(HERE / 'scope.json', dict(checks_per_system=16,
    scope='original and identically adapted Chez only; strict probes establish element Ref aliases and mutable prime-tail aliases',
    frozen_preparation='matrix-attempt5', sources={str(path.relative_to(HERE)): driver.digest(path)
        for path in HERE.rglob('*') if path.is_file()}))
print('32 Chez spine/element/state identity checks passed')
