(import (except (chezscheme) div mod))
(define (exact-integer? value) (and (exact? value) (integer? value)))
(define-syntax : (syntax-rules () ((_ . signature) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define (ref value) (vector value))
(define (ref-get value) (vector-ref value 0))
(define (ref-set! cell value) (vector-set! cell 0 value))
(define ref-eq? eq?)
(define (unit) (if #f #f))
(define (unreachable) (error 'matrix "invalid typed Matrix value"))
(define (no-permutation) #f)
(define (permutation dispatch) dispatch)
(define permutation-dispatch values)
(define permutation? procedure?)
(define (current-object value) (vector 0 value))
(define (next-permutation value) (vector 1 value))
(define (remaining-objects value) (vector 2 value))
(define (current-value value) (vector-ref value 1))
(define next-value current-value)
(define remaining-values current-value)
(define (gcd-value value) (vector 0 value))
(define gcd-result-value current-value)
(define (gcd-negative sign magnitude) (vector 1 sign magnitude))
(define (gcd-sign value) (vector-ref value 1))
(define (gcd-magnitude value) (vector-ref value 2))
(define (no-primes) '())
(define (prime-node value tail) (cons value tail))
(define prime-value car)
(define prime-tail cdr)
(define prime-null? null?)
(define (matrix-answer value) (vector 0 value))
(define (marker-answer value) (vector 1 value))
(define answer-matrix current-value)
(define answer-marker current-value)
(define (matrix-answer? value) (= (vector-ref value 0) 0))
(define (best size count answers) (vector size count answers))
(define (best-size value) (vector-ref value 0))
(define (best-count value) (vector-ref value 1))
(define (best-answers value) (vector-ref value 2))
;; These lists are persistent. Only the prime-list tail and last box
;; are mutable; the predicate closure continues to see the original head.

(: list (All (T) (-> (Rest T) (List T))))

(: reverse (All (T) (-> (List T) (List T))))

(: map-one (All (A B) (-> (-> A B) (List A) (List B))))
(define (map-one procedure values)
  (if (null? values) '()
      (let ((head (procedure (car values))))
        (cons head (map-one procedure (cdr values))))))
(: map-two (All (A B C) (-> (-> A B C) (List A) (List B) (List C))))
(define (map-two procedure first second)
  (if (null? first) '()
      (let ((head (procedure (car first) (car second))))
        (cons head (map-two procedure (cdr first) (cdr second))))))
(: exact-integer? (-> I64 Bool))



(: expt (-> I64 I64 I64))

(: perm-now (All (T) (-> (Permutation T) T)))
(define (perm-now value) (current-value ((permutation-dispatch value) 0)))
(: perm-brother (All (T) (-> (Permutation T) (Permutation T))))
(define (perm-brother value) (next-value ((permutation-dispatch value) 1)))
(: perm-child (All (T) (-> (Permutation T) (Permutation T))))
(define (perm-child value) (next-value ((permutation-dispatch value) 2)))
(: perm-puke (All (T) (-> (Permutation T) (List T))))
(define (perm-puke value) (remaining-values ((permutation-dispatch value) 3)))
(define (prime-cons head tail) (prime-node head (ref tail)))
(define (prime-cdr value) (ref-get (prime-tail value)))
(define (prime-set-cdr! value tail) (ref-set! (prime-tail value) tail))
(: same-row? (-> (List I64) (List I64) Bool))
(define (same-row? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (= (car left) (car right))
           (same-row? (cdr left) (cdr right)))))
(: same-matrix? (-> (List (List I64)) (List (List I64)) Bool))
(define (same-matrix? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (same-row? (car left) (car right))
           (same-matrix? (cdr left) (cdr right)))))
(define (same-answer? left right)
  (if (matrix-answer? left)
      (and (matrix-answer? right) (same-matrix? (answer-matrix left) (answer-matrix right)))
      (and (not (matrix-answer? right)) (string=? (answer-marker left) (answer-marker right)))))
(define (same-answers? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (same-answer? (car left) (car right))
           (same-answers? (cdr left) (cdr right)))))
(define (matrix-read-answers value)
  (and value (map-one (lambda (answer)
                       (if (string? answer) (marker-answer answer) (matrix-answer answer))) value)))
(define (matrix-same-result? value expected)
  (if value (and expected (same-answers? value expected)) (not expected)))
(define (permutation-error code)
  (display "gen-perms: Bad msg: ~a; message code ") (display code) (newline)
  (flush-output-port (current-output-port))
  (unreachable))
(define probe-matrix-answer? matrix-answer?)
(define probe-answer-matrix answer-matrix)
(define probe-answer-marker answer-marker)
(define probe-matrix-answer matrix-answer)
(define probe-marker-answer marker-answer)
(define probe-same-answers? same-answers?)
(define probe-best best)
(define probe-best-size best-size)
(define probe-best-count best-count)
(define probe-best-answers best-answers)
(define probe-prime-null? prime-null?)
(define probe-prime-value prime-value)
(define probe-prime-cdr prime-cdr)
(define (probe-prime-same? left right) (ref-eq? (prime-tail left) (prime-tail right)))
(define probe-permutation? permutation?)
(define probe-perm-now perm-now)
(define probe-perm-brother perm-brother)
(define probe-perm-child perm-child)
(define probe-perm-puke perm-puke)
(define (emit-gcd value)
  (if (= (vector-ref value 0) 0)
      (begin (emit-i64 0) (emit-i64 (gcd-result-value value)))
      (begin (emit-i64 1) (emit-i64 (gcd-sign value)) (emit-i64 (gcd-magnitude value)))))
(define (probe-bad-message)
  ((permutation-dispatch (gen-perms (list 1))) 99)
  (unit))
(define (emit-i64 value) (write value) (newline))
(: div (-> I64 I64 I64))
(: mod (-> I64 I64 I64))
(: maximal? (-> (List (List I64)) Bool))
(: zunda (-> (Permutation (List I64)) (List (List I64)) Bool))
(: zebra (-> (Permutation (List I64)) (-> (List I64) (-> I64 I64))
               (-> (List I64) (-> I64 I64)) (List (List I64)) I64 Bool))
(: zulu (-> (List I64) (-> I64 I64) (List (List I64)) (-> (List (List I64)) Bool) Bool))
(: all? (All (T) (-> (-> T Bool) (List T) Bool)))
(: gen-perms (All (T) (-> (List T) (Permutation T))))
(: fold (All (A S) (-> (List A) (-> A S S) S S)))
(: miota (-> I64 (List I64)))
(: proc->vector (-> I64 (-> I64 I64) (Vector I64)))
(: make-modular (All (T) (-> I64 (-> (-> I64 I64 (-> I64 Bool) (-> I64 I64 I64) (-> I64 I64) (-> I64 I64 I64) (-> I64 I64) T) T))))
(: extended-gcd (All (T) (-> I64 I64 (-> I64 I64 I64 T) (GcdResult T))))
(: make-row-reduce (-> I64 I64 (-> I64 Bool) (-> I64 I64 I64) (-> I64 I64) (-> I64 I64 I64) (-> I64 I64) (-> (List (List I64)) (List (List I64)))))
(: make-in-row-space? (-> I64 I64 (-> I64 Bool) (-> I64 I64 I64) (-> I64 I64) (-> I64 I64 I64) (-> I64 I64) (-> (List (List I64)) (-> (List I64) Bool))))
(: make-modular-row-reduce (-> I64 (-> (List (List I64)) (List (List I64)))))
(: make-modular-in-row-space? (-> I64 (-> (List (List I64)) (-> (List I64) Bool))))
(: find-prime (-> I64 I64))
(: det-upper-bound (-> I64 I64))
(: go (All (S) (-> I64 I64 (-> (List (List I64)) S S) S S)))
(: go-folder (-> (List (List I64)) Best Best))
(: really-go (-> I64 I64 (List Answer)))
(: remove-in-order (All (T) (-> (-> T Bool) (List T) (List T))))
(: fold-over-rows (All (S) (-> I64 (-> (List I64) S S) S S)))
(: fold-over-subs-of-size (All (T S) (-> (List T) I64 (-> (List T) S S) S S)))
;;; MATRIX -- Obtained from Andrew Wright.


;;; We need R6RS div and mod for this benchmark.

(define (div x y)
  (cond ((and (exact-integer? x)
              (exact-integer? y)
              (>= x 0))
         (quotient x y))
        ((< y 0)
         ;; x < 0, y < 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               q
               (+ q 1))))
        (else
         ;; x < 0, y > 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               q
               (- q 1))))))

(define (mod x y)
  (cond ((and (exact-integer? x)
              (exact-integer? y)
              (>= x 0))
         (remainder x y))
        ((< y 0)
         ;; x < 0, y < 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               0
               (- r y))))
        (else
         ;; x < 0, y > 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               0
               (+ r y))))))

;; Chez-Scheme compatibility stuff:

(define (chez-box x) (ref x))
(define (chez-unbox x) (ref-get x))
(define (chez-set-box! x y) (ref-set! x y))

;; Test that a matrix with entries in {+1, -1} is maximal among the matricies
;; obtainable by
;;       re-ordering the rows
;;       re-ordering the columns
;;       negating any subset of the columns
;;       negating any subset of the rows
;; Where we compare two matricies by lexicographically comparing the first row,
;; then the next to last, etc., and we compare a row by lexicographically
;; comparing the first entry, the second entry, etc., and we compare two
;; entries by +1 > -1.
;; Note, this scheme obeys the useful fact that if (append mat1 mat2) is
;; maximal, then so is mat1.  Thus, we can build up maximal matricies
;; row by row.
;;
;; Once you have chosen the row re-ordering so that you know which row goes
;; last, the set of columns to negate is fixed (since the last row must be
;; all +1's).
;;
;; Note, the column ordering is really totally determined as follows:
;;       all columns for which the second row is +1 must come before all
;;               columns for which the second row is -1.
;;       among columns for which the second row is +1, all columns for which
;;               the third row is +1 come before those for which the third is
;;               -1, and similarly for columns in which the second row is -1.
;;       etc
;; Thus, each succeeding row sorts columns withing refinings equivalence
;; classes.
;;
;; Maximal? assumes that mat has atleast one row, and that the first row
;; is all +1's.
(define maximal?
  (lambda (mat)
    (let pick-first-row
        ((first-row-perm
          (gen-perms mat)))
      (if (permutation? first-row-perm)
          (and (zunda first-row-perm mat)
               (pick-first-row (perm-brother first-row-perm)))
          #t))))

(define zunda
  (lambda (first-row-perm mat)
    (let* ((first-row
            (perm-now first-row-perm))
           (number-of-cols
            (length first-row))
           (make-row->func
            (lambda (if-equal if-different)
              (lambda (row)
                (let ((vec
                       (make-vector number-of-cols)))
                  (do ((i 0 (+ i 1))
                       (first first-row
                              (cdr first))
                       (row row
                            (cdr row)))
                      ((= i number-of-cols) (unit))
                    (vector-set! vec
                                 i
                                 (if (= (car first) (car row))
                                     if-equal
                                     if-different)))
                  (lambda (i)
                    (vector-ref vec i))))))
           (mat
            (cdr mat)))
      (zebra (perm-child first-row-perm)
             (make-row->func 1 -1)
             (make-row->func -1 1)
             mat
             number-of-cols))))


(define zebra
  (lambda (row-perm row->func+ row->func- mat number-of-cols)
    (let _-*-
        ((row-perm
          row-perm)
         (mat
          mat)
         (partitions
          (list (miota number-of-cols))))
      (or (not (permutation? row-perm))
          (and
           (zulu (car mat)
                 (row->func+ (perm-now row-perm))
                 partitions
                 (lambda (new-partitions)
                   (_-*- (perm-child row-perm)
                         (cdr mat)
                         new-partitions)))
           (zulu (car mat)
                 (row->func- (perm-now row-perm))
                 partitions
                 (lambda (new-partitions)
                   (_-*- (perm-child row-perm)
                         (cdr mat)
                         new-partitions)))
           (let ((new-row-perm
                  (perm-brother row-perm)))
             (or (not (permutation? new-row-perm))
                 (_-*- new-row-perm
                       mat
                       partitions))))))))


(define zulu
  (let ((cons-if-not-null
         (lambda (lhs rhs)
           (if (null? lhs)
               rhs
               (cons lhs rhs)))))
    (lambda (old-row new-row-func partitions equal-cont)
      (let _-*-
          ((p-in
            partitions)
           (old-row
            old-row)
           (rev-p-out
            '()))
        (let _-split-
            ((partition
              (car p-in))
             (old-row
              old-row)
             (plus
              '())
             (minus
              '()))
          (if (null? partition)
              (let _-minus-
                  ((old-row
                    old-row)
                   (m
                    minus))
                (if (null? m)
                    (let ((rev-p-out
                           (cons-if-not-null
                            minus
                            (cons-if-not-null
                             plus
                             rev-p-out)))
                          (p-in
                           (cdr p-in)))
                      (if (null? p-in)
                          (equal-cont (reverse rev-p-out))
                          (_-*- p-in old-row rev-p-out)))
                    (or (= 1 (car old-row))
                        (_-minus- (cdr old-row)
                                  (cdr m)))))
              (let ((next
                     (car partition)))
                (case (new-row-func next)
                  ((1)
                   (and (= 1 (car old-row))
                        (_-split- (cdr partition)
                                  (cdr old-row)
                                  (cons next plus)
                                  minus)))
                  ((-1)
                   (_-split- (cdr partition)
                             old-row
                             plus
                             (cons next minus)))))))))))

(define all?
  (lambda (ok? lst)
    (let _-*-
        ((lst
          lst))
      (or (null? lst)
          (and (ok? (car lst))
               (_-*- (cdr lst)))))))

(define gen-perms
  (lambda (objects)
    (let _-*-
        ((zulu-future
          objects)
         (past
          '()))
      (if (null? zulu-future)
          (no-permutation)
          (permutation (lambda (msg)
            (case msg
              ((0)
               (current-object (car zulu-future)))
              ((1)
               (next-permutation (_-*- (cdr zulu-future)
                     (cons (car zulu-future)
                           past))))
              ((2)
               (next-permutation (gen-perms
                (fold past cons (cdr zulu-future)))))
              ((3)
               (remaining-objects (cons (car zulu-future)
                     (fold past cons (cdr zulu-future)))))
              (else
               (permutation-error msg)))))))))

(define fold
  (lambda (lst folder state)
    (let _-*-
        ((lst
          lst)
         (state
          state))
      (if (null? lst)
          state
          (_-*- (cdr lst)
                (folder (car lst)
                        state))))))

(define miota
  (lambda (len)
    (let _-*-
        ((i 0))
      (if (= i len)
          '()
          (cons i
                (_-*- (+ i 1)))))))

(define proc->vector
  (lambda (size proc)
    (let ((res
           (make-vector size)))
      (do ((i 0
              (+ i 1)))
          ((= i size) (unit))
        (vector-set! res
                     i
                     (proc i)))
      res)))

;; Given a prime number P, return a procedure which, given a `maker' procedure,
;; calls it on the operations for the field Z/PZ.
(define make-modular
  (lambda (modulus)
    (let* ((reduce
            (lambda (x)
              (mod x modulus)))
           (coef-zero?
            (lambda (x)
              (zero? (reduce x))))
           (coef-+
            (lambda (x y)
              (reduce (+ x y))))
           (coef-negate
            (lambda (x)
              (reduce (- x))))
           (coef-*
            (lambda (x y)
              (reduce (* x y))))
           (coef-recip
            (let ((inverses
                   (proc->vector (- modulus 1)
                                 (lambda (i)
                                   (gcd-result-value (extended-gcd (+ i 1)
                                                 modulus
                                                 (lambda (gcd inverse ignore)
                                                   inverse)))))))
              ;; Coef-recip.
              (lambda (x)
                (let ((x
                       (reduce x)))
                  (vector-ref inverses (- x 1)))))))
      (lambda (maker)
        (maker 0;; coef-zero
               1;; coef-one
               coef-zero?
               coef-+
               coef-negate
               coef-*
               coef-recip)))))

;; Extended Euclidean algorithm.
;; (extended-gcd a b cont) computes the gcd of a and b, and expresses it
;; as a linear combination of a and b.  It returns calling cont via
;;       (cont gcd a-coef b-coef)
;; where gcd is the GCD and is equal to a-coef * a + b-coef * b.
(define (extended-gcd a b cont)
  (let ((n->sgn/abs
         (lambda (x cont)
           (if (>= x 0)
               (cont 1 x)
               (gcd-negative -1 (- x))))))
    (n->sgn/abs a
                  (lambda (p-a p)
                    (n->sgn/abs b
                                (lambda (q-b q)
                                  (let _-*-
                                      ((p
                                        p)
                                       (p-a
                                        p-a)
                                       (p-b
                                        0)
                                       (q
                                        q)
                                       (q-a
                                        0)
                                       (q-b
                                        q-b))
                                    (if (zero? q)
                                        (gcd-value (cont p p-a p-b))
                                        (let ((mult
                                               (div p q)))
                                          (_-*- q
                                                q-a
                                                q-b
                                                (- p (* mult q))
                                                (- p-a (* mult q-a))
                                                (- p-b (* mult q-b))))))))))))

;; Given elements and operations on the base field, return a procedure which
;; computes the row-reduced version of a matrix over that field.  The result
;; is a list of rows where the first non-zero entry in each row is a 1 (in
;; the coefficient field) and occurs to the right of all the leading non-zero
;; entries of previous rows.  In particular, the number of rows is the rank
;; of the original matrix, and they have the same row-space.
;; The items related to the base field which are needed are:
;;       coef-zero       additive identity
;;       coef-one        multiplicative identity
;;       coef-zero?      test for additive identity
;;       coef-+          addition (two args)
;;       coef-negate     additive inverse
;;       coef-*          multiplication (two args)
;;       coef-recip      multiplicative inverse
;; Note, matricies are stored as lists of rows (i.e., lists of lists).
(define make-row-reduce
  (lambda (coef-zero coef-one coef-zero? coef-+ coef-negate coef-* coef-recip)
    (lambda (mat)
      (let _-*-
          ((mat
            mat))
        (if (or (null? mat)
                (null? (car mat)))
            '()
            (let _-**-
                ((in
                  mat)
                 (out
                  '()))
              (if (null? in)
                  (map
                   (lambda (x)
                     (cons coef-zero x))
                   (_-*- out))
                  (let* ((prow
                          (car in))
                         (pivot
                          (car prow))
                         (prest
                          (cdr prow))
                         (in
                          (cdr in)))
                    (if (coef-zero? pivot)
                        (_-**- in
                               (cons prest out))
                        (let ((zap-row
                               (map
                                (let ((mult
                                       (coef-recip pivot)))
                                  (lambda (x)
                                    (coef-* mult x)))
                                prest)))
                          (cons (cons coef-one zap-row)
                                (map
                                 (lambda (x)
                                   (cons coef-zero x))
                                 (_-*-
                                  (fold in
                                        (lambda (row mat)
                                          (cons
                                           (let ((first-col
                                                  (car row))
                                                 (rest-row
                                                  (cdr row)))
                                             (if (coef-zero? first-col)
                                                 rest-row
                                                 (map
                                                  (let ((mult
                                                         (coef-negate first-col)))
                                                    (lambda (f z)
                                                      (coef-+ f
                                                              (coef-* mult z))))
                                                  rest-row
                                                  zap-row)))
                                           mat))
                                        out))))))))))))))


;; Given elements and operations on the base field, return a procedure which
;; when given a matrix and a vector tests to see if the vector is in the
;; row-space of the matrix.  This returned function is curried.
;; The items related to the base field which are needed are:
;;       coef-zero       additive identity
;;       coef-one        multiplicative identity
;;       coef-zero?      test for additive identity
;;       coef-+          addition (two args)
;;       coef-negate     additive inverse
;;       coef-*          multiplication (two args)
;;       coef-recip      multiplicative inverse
;; Note, matricies are stored as lists of rows (i.e., lists of lists).
(define make-in-row-space?
  (lambda (coef-zero coef-one coef-zero? coef-+ coef-negate coef-* coef-recip)
    (let ((row-reduce
           (make-row-reduce coef-zero
                            coef-one
                            coef-zero?
                            coef-+
                            coef-negate
                            coef-*
                            coef-recip)))
      (lambda (mat)
        (let ((mat
               (row-reduce mat)))
          (lambda (row)
            (let _-*-
                ((row
                  row)
                 (mat
                  mat))
              (if (null? row)
                  #t
                  (let ((r-first
                         (car row))
                        (r-rest
                         (cdr row)))
                    (cond ((coef-zero? r-first)
                           (_-*- r-rest
                                 (map cdr
                                      (if (or (null? mat)
                                              (coef-zero? (caar mat)))
                                          mat
                                          (cdr mat)))))
                          ((null? mat)
                           #f)
                          (else
                           (let* ((zap-row
                                   (car mat))
                                  (z-first
                                   (car zap-row))
                                  (z-rest
                                   (cdr zap-row))
                                  (mat
                                   (cdr mat)))
                             (if (coef-zero? z-first)
                                 #f
                                 (_-*-
                                  (map
                                   (let ((mult
                                          (coef-negate r-first)))
                                     (lambda (r z)
                                       (coef-+ r
                                               (coef-* mult z))))
                                   r-rest
                                   z-rest)
                                  (map cdr mat)))))))))))))))


;; Given a prime number, return a procedure which takes integer matricies
;; and returns their row-reduced form, modulo the prime.
(define make-modular-row-reduce
  (lambda (modulus)
    ((make-modular modulus)
     make-row-reduce)))


(define make-modular-in-row-space?
  (lambda (modulus)
    ((make-modular modulus)
     make-in-row-space?)))



;; Usual utilities.



;; Given a bound, find a prime greater than the bound.
(define find-prime
  (lambda (bound)
    (let* ((primes
            (prime-cons 2 (no-primes)))
           (last
            (chez-box primes))
           (is-next-prime?
            (lambda (trial)
              (let _-*-
                  ((primes
                    primes))
                (or (prime-null? primes)
                    (let ((p
                           (prime-value primes)))
                      (or (< trial (* p p))
                          (and (not (zero? (mod trial p)))
                               (_-*- (prime-cdr primes))))))))))
      (if (> 2 bound)
          2
          (let _-*-
              ((trial
                3))
            (if (is-next-prime? trial)
                (let ((entry
                       (prime-cons trial (no-primes))))
                  (prime-set-cdr! (chez-unbox last) entry)
                  (begin (chez-set-box! last entry) (observe-primes primes (chez-unbox last)))
                  (if (> trial bound)
                      trial
                      (_-*- (+ trial 2))))
                (_-*- (+ trial 2))))))))

;; Given the size of a square matrix consisting only of +1's and -1's,
;; return an upper bound on the determinant.
(define det-upper-bound
  (lambda (size)
    (let ((main-part
           (expt size
                 (div size 2))))
      (if (even? size)
          main-part
          (* main-part
             (do ((i 0 (+ i 1)))
                 ((>= (* i i) size)
                  i)))))))

;; Fold over all maximal matrices.
(define go
  (lambda (number-of-cols inv-size folder state)
    (let* ((in-row-space?
            (make-modular-in-row-space?
             (find-prime
              (det-upper-bound inv-size))))
           (make-tester
            (lambda (mat)
              (let ((tests
                     (let ((old-mat
                            (cdr mat))
                           (new-row
                            (car mat)))
                       (fold-over-subs-of-size old-mat
                                               (- inv-size 2)
                                               (lambda (sub tests)
                                                 (cons
                                                  (in-row-space?
                                                   (cons new-row sub))
                                                  tests))
                                               '()))))
                (lambda (row)
                  (let _-*-
                      ((tests
                        tests))
                    (and (not (null? tests))
                         (or ((car tests) row)
                             (_-*- (cdr tests)))))))))
           (all-rows;; all rows starting with +1 in decreasing order
            (fold
             (fold-over-rows (- number-of-cols 1)
                             cons
                             '())
             (lambda (row rows)
               (cons (cons 1 row)
                     rows))
             '())))
      (let _-*-
          ((number-of-rows
            1)
           (rev-mat
            (list
             (car all-rows)))
           (possible-future
            (cdr all-rows))
           (state
            state))
        (let ((zulu-future
               (remove-in-order
                (if (< number-of-rows inv-size)
                    (in-row-space? rev-mat)
                    (make-tester rev-mat))
                possible-future)))
          (if (null? zulu-future)
              (folder (reverse rev-mat)
                      state)
              (let _-**-
                  ((zulu-future
                    zulu-future)
                   (state
                    state))
                (if (null? zulu-future)
                    state
                    (let ((rest-of-future
                           (cdr zulu-future)))
                      (_-**- rest-of-future
                             (let* ((first
                                     (car zulu-future))
                                    (new-rev-mat
                                     (cons first rev-mat)))
                               (if (maximal? (reverse new-rev-mat))
                                   (_-*- (+ number-of-rows 1)
                                         new-rev-mat
                                         rest-of-future
                                         state)
                                   state))))))))))))

(define go-folder
  (lambda (mat bsize.blen.blist)
    (let ((bsize
           (best-size bsize.blen.blist))
          (size
           (length mat)))
      (if (< size bsize)
          bsize.blen.blist
          (let ((blen
                 (best-count bsize.blen.blist))
                (blist
                 (best-answers bsize.blen.blist)))
            (if (= size bsize)
                (let ((blen
                       (+ blen 1)))
                  ;;                       (if
                  ;;                          (let _-*-
                  ;;                               ((blen
                  ;;                                   blen))
                  ;;                             (or (< blen 10)
                  ;;                                 (and (zero? (mod blen 10))
                  ;;                                      (_-*- (div blen 10)))))
                  ;;
                  ;;                          (begin
                  ;;                             (display blen)
                  ;;                             (display " of size ")
                  ;;                             (display bsize)
                  ;;                             (newline)))

                  (best bsize
                        blen
                              (cond ((< blen 3000)
                                     (cons (matrix-answer mat) blist))
                                    ((= blen 3000)
                                     (cons (marker-answer "...") blist))
                                    (else
                                     blist))))
                ;;                    (begin
                ;;                       (newline)
                ;;                       (display "First of size ")
                ;;                       (display size)
                ;;                       (display ":")
                ;;                       (newline)
                ;;                       (for-each
                ;;                          (lambda (row)
                ;;                             (display " ")
                ;;                             (for-each
                ;;                                (lambda (e)
                ;;                                   (case e
                ;;                                      ((1)
                ;;                                         (display "  1"))
                ;;                                      ((-1)
                ;;                                         (display " -1"))))
                ;;                                row)
                ;;                             (newline))
                ;;                          mat)

                (best size 1 (list (matrix-answer mat)))))))))

(define really-go
  (lambda (number-of-cols inv-size)
    (best-answers
     (go number-of-cols
         inv-size
         go-folder
         (best -1 -1 '())))))

(define remove-in-order
  (lambda (remove? lst)
    (reverse
     (fold lst
           (lambda (e lst)
             (if (remove? e)
                 lst
                 (cons e lst)))
           '()))))

;; The first fold-over-rows is slower than the second one, but folds
;; over rows in lexical order (large to small).
(define fold-over-rows
  (lambda (number-of-cols folder state)
    (if (zero? number-of-cols)
        (folder '()
                state)
        (fold-over-rows (- number-of-cols 1)
                        (lambda (tail state)
                          (folder (cons -1 tail)
                                  state))
                        (fold-over-rows (- number-of-cols 1)
                                        (lambda (tail state)
                                          (folder (cons 1 tail)
                                                  state))
                                        state)))))

;; Fold over subsets of a given size.
(define fold-over-subs-of-size
  (lambda (universe size folder state)
    (let ((usize
           (length universe)))
      (if (< usize size)
          state
          (let _-*-
              ((size
                size)
               (universe
                universe)
               (folder
                folder)
               (csize
                (- usize size))
               (state
                state))
            (cond ((zero? csize)
                   (folder universe state))
                  ((zero? size)
                   (folder '() state))
                  (else
                   (let ((first-u
                          (car universe))
                         (rest-u
                          (cdr universe)))
                     (_-*- size
                           rest-u
                           folder
                           (- csize 1)
                           (_-*- (- size 1)
                                 rest-u
                                 (lambda (tail state)
                                   (folder (cons first-u tail)
                                           state))
                                 csize
                                 state))))))))))

(define probe-maximal-matrices (list (list (list 1 1 1)) (list (list 1 1 1) (list 1 1 1)) (list (list 1 1 1) (list 1 1 -1)) (list (list 1 1 1) (list 1 -1 1)) (list (list 1 1 1) (list 1 -1 -1)) (list (list 1 1 1) (list 1 1 -1) (list 1 -1 1)) (list (list 1 1 1) (list 1 1 -1) (list 1 -1 -1)) (list (list 1 1 1) (list 1 -1 1) (list 1 1 -1)) (list (list 1 1 1) (list 1 -1 1) (list 1 -1 -1)) (list (list 1 1 1) (list 1 -1 -1) (list 1 1 -1)) (list (list 1 1 1) (list 1 -1 -1) (list 1 -1 1)) (list (list 1 1 1) (list 1 1 -1) (list 1 -1 1) (list 1 -1 -1))))
(define (emit-bool value) (emit-i64 (if value 1 0)))
(: emit-list (All (T) (-> (-> T Unit) (List T) Unit)))
(define (emit-list emit values)
  (emit-i64 (length values))
  (let loop ((tail values))
    (unless (null? tail) (emit (car tail)) (loop (cdr tail)))))
(define (emit-row value) (emit-list emit-i64 value))
(define (emit-matrix value) (emit-list emit-row value))
(define (emit-refs value) (emit-list (lambda (cell) (emit-i64 (ref-get cell))) value))
(define (emit-answer value)
  (if (probe-matrix-answer? value)
      (begin (emit-i64 0) (emit-matrix (probe-answer-matrix value)))
      (begin (emit-i64 1) (emit-list (lambda (char) (emit-i64 (char->integer char)))
                                  (string->list (probe-answer-marker value))))))
(define (emit-best value)
  (emit-i64 (probe-best-size value)) (emit-i64 (probe-best-count value))
  (emit-list emit-answer (probe-best-answers value)))
(define (observe-primes primes last)
  (emit-i64 900)
  (let loop ((tail primes))
    (unless (probe-prime-null? tail)
      (emit-i64 (probe-prime-value tail)) (loop (probe-prime-cdr tail))))
  (emit-i64 0) (emit-i64 (probe-prime-value last))
  (let loop ((tail primes))
    (if (probe-prime-null? (probe-prime-cdr tail))
        (emit-bool (probe-prime-same? tail last))
        (loop (probe-prime-cdr tail)))))
(define (probe-numbers)
  (fold (list -7 -6 0 6 7)
        (lambda (x state)
          (fold (list -3 3)
                (lambda (y state) (emit-i64 (div x y)) (emit-i64 (mod x y)) state) state)) 0)
  (fold (list 0 1 2 3 4 5 6)
        (lambda (size state) (emit-i64 (det-upper-bound size)) state) 0)
  (fold (list 30 -30)
        (lambda (a state)
          (fold (list 21 -21)
                (lambda (b state)
                  (emit-gcd (extended-gcd a b (lambda (g x y)
                    (emit-i64 901) (emit-i64 g) (emit-i64 x) (emit-i64 y) (+ g 40)))) state) state)) 0)
  ((make-modular 7)
   (lambda (zero one zero? add negate multiply reciprocal)
     (emit-i64 zero) (emit-i64 one) (emit-bool (zero? -14))
     (emit-i64 (add -4 3)) (emit-i64 (negate 3)) (emit-i64 (multiply -3 4))
     (fold (list 1 2 3 4 5 6) (lambda (value state) (emit-i64 (reciprocal value)) state) 0))))
(define (probe-row-and-subset-order)
  (emit-i64 (fold-over-rows 3 (lambda (row count) (emit-row row) (+ count 1)) 0))
  (let ((universe (list 10 20 30 40)))
    (fold (list 0 1 2 3 4 5)
          (lambda (size state)
            (emit-i64 size)
            (emit-i64 (fold-over-subs-of-size universe size
                       (lambda (subset count) (emit-row subset) (+ count 1)) 0)) state) 0)))
(define (probe-permutation-tree cursor)
  (when (probe-permutation? cursor)
    (emit-i64 (ref-get (probe-perm-now cursor)))
    (emit-refs (probe-perm-puke cursor))
    (probe-permutation-tree (probe-perm-child cursor))
    (probe-permutation-tree (probe-perm-brother cursor))))
(define (probe-order-and-aliases)
  (probe-row-and-subset-order)
  (let* ((first (ref 1)) (second (ref 2)) (third (ref 3))
         (values (list first second third)) (cursor (gen-perms values)))
    (probe-permutation-tree cursor)
    (ref-set! (probe-perm-now (probe-perm-brother cursor)) 20)
    (emit-refs values)
    (emit-bool (ref-eq? (probe-perm-now cursor) first))
    (emit-bool (ref-eq? (probe-perm-now (probe-perm-child cursor)) second))
    (let ((selected (remove-in-order (lambda (cell)
                      (emit-i64 902) (emit-i64 (ref-get cell)) (= (ref-get cell) 20)) values)))
      (emit-refs selected)
      (emit-bool (ref-eq? (car selected) first))
      (emit-bool (ref-eq? (car (cdr selected)) third)))
    (emit-bool (all? (lambda (cell) (emit-i64 903) (emit-i64 (ref-get cell))
                      (< (ref-get cell) 10)) values)))
  (emit-bool (all? (lambda (value) (unreachable)) (ann '() (List I64))))
  (let ((values (proc->vector 4 (lambda (index)
                  (emit-i64 904) (emit-i64 index) (* index index)))))
    (emit-row (vector->list values))))
(define (probe-linear-algebra)
  (let ((reduce (make-modular-row-reduce 7)))
    (emit-matrix (reduce '()))
    (emit-matrix (reduce (list (list 0 0 0) (list 0 0 0))))
    (emit-matrix (reduce (list (list 0 2 4) (list 3 1 -1) (list 6 2 -2))))
    (emit-matrix (reduce (list (list 1 1 1) (list 1 -1 1) (list 1 1 -1)))))
  (let ((test ((make-modular-in-row-space? 7) (list (list 1 2 3) (list 2 4 6)))))
    (fold (list (list 0 0 0) (list 3 6 9) (list 1 1 1) (list -1 -2 -3))
          (lambda (row state) (emit-bool (test row)) state) 0))
  (fold probe-maximal-matrices
        (lambda (matrix state) (emit-bool (maximal? matrix)) state) 0))
(define (probe-collector)
  (let* ((matrix (list (list 1)))
         (old (let loop ((left 2998) (state (probe-best -1 -1 '())))
                (if (= left 0) state (loop (- left 1) (go-folder matrix state)))))
         (added (go-folder matrix old))
         (marked (go-folder matrix added))
         (capped (go-folder matrix marked)))
    (emit-best (go-folder '() old))
    (emit-best added) (emit-best marked) (emit-best capped)
    (emit-bool (probe-same-answers? (probe-best-answers marked) (probe-best-answers capped)))
    (emit-bool (probe-same-answers? (list (probe-marker-answer "..."))
                                   (list (probe-marker-answer "..x"))))
    (emit-best (go-folder (list (list 1) (list -1)) capped))
    (emit-best (go-folder matrix (probe-best -1 -1 '())))))
(define (probe-zulu)
  (fold (list (list 1 1 1) (list 1 -1 -1) (list 1 1 -1))
        (lambda (row state)
          (let ((values (list->vector row)))
            (emit-bool (zulu (list 1 1 -1) (lambda (index) (vector-ref values index))
                         (list (list 0 1 2))
                         (lambda (partitions) (emit-i64 905) (emit-matrix partitions) #t)))) state) 0))
(: probe (-> I64 I64 I64 I64))
(define (probe mode columns size)
  (cond ((= mode 0) (emit-list emit-answer (really-go columns size)))
        ((= mode 1) (probe-numbers) (unit))
        ((= mode 2) (probe-order-and-aliases))
        ((= mode 3) (probe-linear-algebra) (unit))
        ((= mode 4) (probe-collector))
        ((= mode 5) (emit-i64 (find-prime columns)))
        ((= mode 6) (probe-zulu) (unit))
        ((= mode 7) (probe-bad-message))
        ((= mode 8)
         (emit-i64 (go columns size (lambda (matrix count)
                       (emit-matrix matrix) (+ count 1)) 0)))
        (else (emit-list emit-answer (really-go columns size))
              (emit-list emit-answer (really-go columns size))))
  1)

(define (check value) (write (if value 1 0)) (newline))
(let* ((a (list 1)) (b (list 2)) (c (list 3))
       (rows (list a b c)) (cursor (gen-perms rows))
       (sibling (probe-perm-brother cursor)) (child (probe-perm-child cursor))
       (puke (probe-perm-puke cursor)) (sibling-puke (probe-perm-puke sibling)))
  (check (eq? (probe-perm-now cursor) a))
  (check (eq? (probe-perm-now cursor) (probe-perm-now cursor)))
  (check (eq? (probe-perm-now sibling) b))
  (check (eq? (probe-perm-now child) b))
  (check (not (eq? puke rows)))
  (check (eq? (cdr puke) (cdr rows)))
  (check (eq? (cddr sibling-puke) (cddr rows)))
  (fold-over-subs-of-size rows 3 (lambda (subset state) (check (eq? subset rows)) state) 0)
  (fold-over-subs-of-size rows 2
    (lambda (subset state)
      (when (eq? (car subset) b) (check (eq? subset (cdr rows)))) state) 0)
  (let ((selected (remove-in-order (lambda (row) (eq? row b)) rows)))
    (check (not (eq? selected rows)))
    (check (not (eq? (cdr selected) (cddr rows))))
    (check (eq? (car selected) a))
    (check (eq? (cadr selected) c)))
  (let* ((matrix (list a b))
         (old (probe-best 2 1 (list (probe-matrix-answer matrix))))
         (same (go-folder (list a) old)) (added (go-folder matrix old)))
    (check (eq? same old))
    (check (eq? (cdr (probe-best-answers added)) (probe-best-answers old)))
    (check (eq? (probe-answer-matrix (car (probe-best-answers added))) matrix))))
