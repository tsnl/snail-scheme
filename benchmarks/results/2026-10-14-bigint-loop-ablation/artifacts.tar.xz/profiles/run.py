#!/usr/bin/env python3
"""Profile frozen full workloads; these instrumented clocks are not comparisons."""

import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PLAN = Path('/tmp/snail-general-specialization-20261012/benchmarks/results/2026-10-14-strict-integer-measurement-preparation/timing-plan.json')


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def verify_inputs(config):
    for path, expected in config['artifact_sha256'].items():
        actual = hashlib.sha256(Path(path).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('changed frozen artifact: ' + path)


def check_output(plan, name, record):
    work = plan['workloads'][name]
    prefix = work['output'] + f'+!CSVLINE!+snail-integer,{name}:{work["count"]},'
    if record['returncode'] or record['stderr'] or not record['stdout'].startswith(prefix):
        raise ValueError('complete profiled workload failed: ' + name)
    tail = record['stdout'][len(prefix):]
    if not re.fullmatch(r'[0-9.eE+\-]+\n', tail) or not math.isfinite(float(tail)) or float(tail) <= 0:
        raise ValueError('unexpected diagnostic clock framing')


def profile(plan, name):
    config = plan['systems'][name]['production-v8']
    target = ROOT / name
    target.mkdir(exist_ok=False)
    verify_inputs(config)
    node, *args = config['command']
    command = [plan['taskset'], '-c', '5', node, '--cpu-prof', '--cpu-prof-interval=1000',
               '--cpu-prof-dir=' + str(target), '--cpu-prof-name=full.cpuprofile', *args]
    record = dict(command=command, cwd=config['cwd'], diagnostic_only=True,
                  environment=plan['environment'], artifacts=config['artifact_sha256'])
    save(target / 'record.json', record)
    started = time.perf_counter()
    run = subprocess.run(command, cwd=config['cwd'], env={**os.environ, **plan['environment']},
                         text=True, capture_output=True, timeout=60, start_new_session=True)
    record.update(returncode=run.returncode, stdout=run.stdout, stderr=run.stderr,
                  process_seconds=time.perf_counter() - started)
    save(target / 'record.json', record)
    verify_inputs(config)
    check_output(plan, name, record)
    print(name, 'complete original output validated; CPU profile saved', flush=True)


if __name__ == '__main__':
    plan = json.loads(PLAN.read_text())
    for name in ('pi', 'chudnovsky'):
        profile(plan, name)
