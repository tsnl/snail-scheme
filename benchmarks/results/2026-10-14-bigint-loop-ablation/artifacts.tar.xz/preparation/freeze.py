"""Freeze already-validated artifacts before the coordinated clean comparison."""

import json
from pathlib import Path

import measure

root = Path(__file__).resolve().parent
source = json.loads(measure.DRIVER.with_name('timing-plan.json').read_text())
plan = {key: source[key] for key in ('cpu', 'taskset', 'supervisor', 'environment',
                                    'inherited_environment', 'workloads')}
plan.update(timeout_seconds=60, systems={}, schedule=measure.schedule(), identities={},
            changed_mechanism='Only function85 self-tail call becomes a local backedge; scalar temporaries preserve argument order.',
            optimizer_control='Second optimization uses unchanged production Binaryen flags; all five variants are retained.',
            compiler_basis='b9bfe878e8f5c99f5f91feeeab56e8e441b92587',
            production_module_basis='Original frozen integer comparison controls; no Scheme source or input changes.')
for config in json.loads((root / 'commands.json').read_text()):
    plan['systems'].setdefault(config['name'], {})[config['variant']] = config
    plan['identities'].update(config['artifact_sha256'])
paths = [*root.glob('*.py'), root / 'commands.json', measure.DRIVER,
         Path(plan['supervisor']) / 'matrix_port.py', Path(plan['supervisor']) / 'data_ports.py']
for name in measure.WORKLOADS:
    paths += [root / name / 'transformation.json', *sorted((root / name).glob('*.wat'))]
plan['identities'].update({str(path): measure.driver.digest(path) for path in paths})
measure.driver.save(root / 'timing-plan.json', plan)
measure.verify(plan)
print('Frozen', len(plan['identities']), 'identities and', len(plan['schedule']), 'scheduled samples')
