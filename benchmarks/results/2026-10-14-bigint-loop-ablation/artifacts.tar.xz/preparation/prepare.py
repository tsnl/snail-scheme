"""Build checked loop probes; diagnostic execution is not a timing campaign."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

from transform import transform

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
PLAN = REPO / 'benchmarks/results/2026-10-14-strict-integer-measurement-preparation/timing-plan.json'
BIN = Path('/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin')
FEATURES = ['--mvp-features', '--enable-gc', '--enable-reference-types', '--enable-tail-call',
            '--enable-mutable-globals', '--enable-sign-ext', '--enable-bulk-memory',
            '--enable-nontrapping-float-to-int']
OPTIMIZE = ['-O3', '--closed-world', '--always-inline-max-function-size=40', '--converge']


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def execute(command, target, label, expected=0):
    record = supervisor.execute(command, target, environment, timeout=60, stdin='')
    record.update(cwd=str(target), environment=plan['environment'], diagnostic_only=True)
    save(target / (label + '.json'), record)
    assert not record.get('error') and not record['timeout'] and not record['executing_descendants'], record
    assert record['returncode'] == expected, record
    return record


def prepare(name):
    config = plan['systems'][name]['production-v8']
    for path, expected in config['artifact_sha256'].items():
        assert digest(path) == expected
    node, host, baseline, spec, _ = config['command']
    target = ROOT / name
    target.mkdir(exist_ok=False)
    execute([BIN / 'wasm-dis', baseline, '-o', target / 'original.wat'], target, 'disassemble-original')
    original = (target / 'original.wat').read_text()
    transformed, proof = transform(original)
    (target / 'backedge.wat').write_text(transformed)
    save(target / 'transformation.json', proof)
    shutil.copy2(baseline, target / 'original.wasm')
    execute([BIN / 'wasm-as', '-g', *FEATURES, target / 'backedge.wat', '-o', target / 'backedge.wasm'], target, 'assemble-backedge')
    execute([BIN / 'wasm-as', '-g', *FEATURES, target / 'original.wat', '-o', target / 'original-roundtrip.wasm'], target, 'assemble-original-roundtrip')
    for variant in ('original-roundtrip', 'backedge'):
        execute([BIN / 'wasm-opt', '-g', *FEATURES, *OPTIMIZE, target / (variant + '.wasm'),
                 '-o', target / (variant + '-optimized.wasm')], target, variant + '-optimize')
    for variant in ('original', 'original-roundtrip', 'original-roundtrip-optimized', 'backedge', 'backedge-optimized'):
        module = target / (variant + '.wasm')
        execute([BIN / 'wasm-dis', module, '-o', target / (variant + '.wat')], target, variant + '-disassemble')
        record = execute([node, host, module, spec], target, variant + '-full')
        assert record['stdout'] == plan['workloads'][name]['output'] and not record['stderr']
        commands.append(dict(name=name, variant=variant, command=[node, host, str(module), spec, '--time'],
            cwd=config['cwd'], artifact_sha256={str(p): digest(p) for p in (node, host, module, spec)}))
        print(name, variant, 'full original result and repetition count pass', flush=True)


if __name__ == '__main__':
    plan = json.loads(PLAN.read_text())
    sys.path.insert(0, plan['supervisor'])
    import matrix_port as supervisor
    environment = {**os.environ, **plan['environment']}
    commands = []
    for name in ('pi', 'chudnovsky'):
        prepare(name)
    save(ROOT / 'commands.json', commands)
