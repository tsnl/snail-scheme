"""Measure the frozen five-way loop ablation using existing process supervision."""

import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import signal
import statistics

ROOT = Path(__file__).resolve().parent
VARIANTS = ('original', 'original-roundtrip', 'original-roundtrip-optimized', 'backedge', 'backedge-optimized')
WORKLOADS = ('pi', 'chudnovsky')
DRIVER = ROOT.parent.parent / 'benchmarks/results/2026-10-14-strict-integer-measurement-preparation/measure.py'
spec = importlib.util.spec_from_file_location('integer_measurement', DRIVER)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)


def schedule():
    return [dict(benchmark=name, system=VARIANTS[(position + max(0, round_number)) % 5],
                 position=position, round=round_number, retained=round_number >= 0)
            for name in WORKLOADS for round_number in range(-1, 10) for position in range(5)]


def verify(plan):
    if plan['schedule'] != schedule() or plan['cpu'] != 5 or plan['timeout_seconds'] != 60:
        raise ValueError('frozen schedule or execution policy differs')
    driver.verify_environment(plan)
    for path, expected in plan['identities'].items():
        if driver.digest(path) != expected:
            raise ValueError('frozen identity differs: ' + path)
    return driver.load_supervisor(plan)


def sample(plan, row, path, supervisor, diagnostic):
    config = plan['systems'][row['benchmark']][row['system']]
    record = dict(row, command=[plan['taskset'], '-c', '5', *config['command']], cwd=config['cwd'],
                  started=datetime.now(timezone.utc).isoformat(), status='starting',
                  environment=plan['environment'], inherited_environment=plan['inherited_environment'],
                  diagnostic_only=diagnostic)
    driver.save(path, record)
    try:
        driver.run_owned(plan, config, record, path, supervisor)
        driver.check_stop()
        seconds = driver.workload_seconds(plan, row, record)
        if seconds <= 0:
            raise ValueError('nonpositive workload clock')
        record.update(workload_seconds=seconds, status='valid')
    except BaseException as error:
        record.update(error=repr(error), status='failed')
        raise
    finally:
        driver.save(path, record)
    return record


def summarize(rows):
    result = {}
    for name in WORKLOADS:
        result[name] = {}
        for variant in VARIANTS:
            chosen = [r for r in rows if r['benchmark'] == name and r['system'] == variant and r['retained']]
            assert len(chosen) == 10 and all(sum(r['position'] == i for r in chosen) == 2 for i in range(5))
            times = [r['workload_seconds'] for r in chosen]
            result[name][variant] = dict(samples=10, median=statistics.median(times), range=[min(times), max(times)])
    return result


def execute(plan, output, diagnostic):
    supervisor = verify(plan)
    output.mkdir(exist_ok=False)
    report = dict(plan=plan, complete=False, diagnostic_only=diagnostic, samples=[])
    driver.save(output / 'host-before.json', driver.host_snapshot(plan['cpu']))
    rows = [r for r in schedule() if r['round'] == -1] if diagnostic else schedule()
    try:
        for index, row in enumerate(rows):
            verify(plan)
            report['pending_sample'] = dict(index=index, **row)
            driver.save(output / 'campaign.json', report)
            record = sample(plan, row, output / f'sample-{index:03}.json', supervisor, diagnostic)
            report['samples'].append(record)
            driver.save(output / 'campaign.json', report)
            print(index, row['benchmark'], row['system'], 'complete output verified', flush=True)
        verify(plan)
        if not diagnostic:
            report['summary'] = summarize(report['samples'])
        report.update(complete=True)
        report.pop('pending_sample')
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        driver.save(output / 'host-after.json', driver.host_snapshot(plan['cpu']))
        driver.save(output / 'campaign.json', report)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument('--run', action='store_true')
    actions.add_argument('--diagnose', action='store_true')
    parser.add_argument('--output', type=Path)
    options = parser.parse_args()
    plan = json.loads((ROOT / 'timing-plan.json').read_text())
    verify(plan)
    if options.run or options.diagnose:
        if options.output is None:
            parser.error('execution requires a fresh --output directory')
        signal.signal(signal.SIGTERM, driver.request_stop)
        signal.signal(signal.SIGINT, driver.request_stop)
        execute(plan, options.output, options.diagnose)
    else:
        print('Verified110-process schedule and all frozen identities; no guest started')
