"""Capture actual default-tier V8 code for measured loop probes; no timing claims."""

import hashlib
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
PREP = ROOT / 'tail-backedge-controlled'
plan = json.loads((PREP / 'timing-plan.json').read_text())
sys.path.insert(0, plan['supervisor'])
import matrix_port

target = ROOT / 'loop-code-captures'
target.mkdir(exist_ok=False)
for name in ('pi', 'chudnovsky'):
    for variant, function in (('backedge', 'function85'), ('backedge-optimized', 'function88')):
        config = plan['systems'][name][variant]
        node, host, module, spec, _ = config['command']
        text = Path(module).with_suffix('.wat').read_text()
        index = len(re.findall(r'\(import .*\(func ', text)) + re.findall(r'^ \(func (\$[^ ]+)', text, re.M).index('$' + function)
        command = [plan['taskset'], '-c', '5', node, '--print-wasm-code',
                   '--print-wasm-code-function-index=' + str(index), host, module, spec]
        record = matrix_port.execute(command, config['cwd'], {**os.environ, **plan['environment']}, timeout=60, stdin='')
        record.update(diagnostic_only=True, cwd=config['cwd'], environment=plan['environment'],
                      function=function, index=index, module_sha256=hashlib.sha256(Path(module).read_bytes()).hexdigest())
        (target / (name + '-' + variant + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        (target / (name + '-' + variant + '.txt')).write_text(record['stdout'])
        assert record['returncode'] == 0 and not record['stderr'] and not record['timeout'] and not record['executing_descendants']
        assert record['stdout'].endswith(plan['workloads'][name]['output'])
        print(name, variant, function, index, 'complete result validated; code captured', flush=True)
