"""Exercise unchanged frozen positive and negative workload specifications."""

import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PLAN = ROOT.parent.parent / 'benchmarks/results/2026-10-14-strict-integer-measurement-preparation/timing-plan.json'
plan = json.loads(PLAN.read_text())
sys.path.insert(0, plan['supervisor'])
import matrix_port

for config in json.loads((ROOT / 'commands.json').read_text()):
    node, host, module, specification, _ = config['command']
    target = ROOT / config['name']
    for label in ('count-0', 'count-1', 'count-2', 'wrong-result', 'wrong-final'):
        source = Path(specification).with_name(label + '.spec.json')
        command = [node, host, module, str(source)]
        record = matrix_port.execute(command, config['cwd'], {**os.environ, **plan['environment']}, timeout=60, stdin='')
        record.update(cwd=config['cwd'], diagnostic_only=True, specification=json.loads(source.read_text()))
        (target / (config['variant'] + '-' + label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        assert not record.get('error') and record['returncode'] == 0 and not record['timeout']
        assert not record['executing_descendants'] and not record['stderr']
        assert record['stdout'] == record['specification']['output']
    print(config['name'], config['variant'], 'count 0/1/2 and two complete-output predicate negatives pass', flush=True)
