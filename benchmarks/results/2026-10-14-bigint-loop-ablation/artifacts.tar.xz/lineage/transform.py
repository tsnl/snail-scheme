"""Diagnostic: replace one exact, scalar-updating self-tail call with a loop.

This deliberately targets a frozen function, not arbitrary compiler output.
Every arithmetic operation, initialization guard and array check is retained.
"""

import hashlib
import re


def parse(text):
    stack = [[]]
    for token in re.findall(r'[()]|[^\s()]+', text):
        if token == '(':
            stack.append([])
        elif token == ')':
            value = stack.pop()
            stack[-1].append(value)
        else:
            stack[-1].append(token)
    assert len(stack) == 1 and len(stack[0]) == 1
    return stack[0][0]


def render(node):
    return '(' + ' '.join(map(render, node)) + ')' if isinstance(node, list) else node


def function_extent(text):
    start = text.index('(func $function85 ')
    depth = 0
    for end in range(start, len(text)):
        depth += (text[end] == '(') - (text[end] == ')')
        if depth == 0:
            return start, end + 1
    raise ValueError('unterminated target function')


def transform(text):
    start, end = function_extent(text)
    original = text[start:end]
    assert not any(token in original for token in ('"', ';', '$backedge', '$next7', '$next8'))
    function = parse(original)
    parameters = [node for node in function if isinstance(node, list) and node[0] == 'param']
    assert [node[1] for node in parameters] == ['$' + str(i) for i in range(9)]
    assert [node[2] for node in parameters[2:]] == ['i64', 'i64', 'i64', 'i32', 'i32', 'i64', 'i64']
    assert [node for node in function if isinstance(node, list) and node[0] == 'result'] == [['result', 'i32']]
    assert function[-1][0] == 'if'
    calls = []

    def replace(node):
        if not isinstance(node, list):
            return node
        if node[:2] == ['return_call', '$function85']:
            assert node[2:9] == [['local.get', '$' + str(i)] for i in range(7)]
            assert len(node) == 11
            assert node[9] == ['i64.add', ['local.get', '$7'], ['i64.const', '1']]
            calls.append(node)
            return ['block', ['local.set', '$next7', node[9]], ['local.set', '$next8', node[10]],
                    ['local.set', '$7', ['local.get', '$next7']],
                    ['local.set', '$8', ['local.get', '$next8']], ['br', '$backedge']]
        return [replace(child) for child in node]

    body = replace(function[-1])
    assert len(calls) == 1
    transformed = function[:-1] + [['local', '$next7', 'i64'], ['local', '$next8', 'i64'],
                                  ['loop', '$backedge', ['result', 'i32'], body]]
    replacement = render(transformed)
    result = text[:start] + replacement + text[end:]
    assert result[:start] == text[:start] and result[start + len(replacement):] == text[end:]
    return result, dict(function='function85', changed_calls=1,
        original_function_sha256=hashlib.sha256(original.encode()).hexdigest(),
        replacement_function_sha256=hashlib.sha256(replacement.encode()).hexdigest(),
        original_tail_call=calls[0])
