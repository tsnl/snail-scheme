import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).parent
binaryen = Path('/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin')
node = '/nix/store/lfaydgacdyngci7p60s8wwvgdm74fjkx-nodejs-24.19.0/bin/node'
runtime = Path('/tmp/snail-strict-ray-20261014/build/wasm-runtime/wasm32-wasip1/release/snail_runtime.wasm')
features = ['--mvp-features', '--enable-gc', '--enable-reference-types', '--enable-tail-call', '--enable-mutable-globals', '--enable-sign-ext', '--enable-bulk-memory', '--enable-nontrapping-float-to-int']
(root / 'strict.wat').write_text('''(module
  (import "snail.library" "snail:initialize-environment" (func $environment))
  (func (export "main") (result i64) (call $environment) (i64.const 42)))
''')
(root / 'diagnostics.wat').write_text('''(module
  (import "snail.library" "snail:report-error" (func $report (param i32 i32)))
  (export "diagnostics/report-error" (func $report)))
''')
commands = []
def run(command):
    result = subprocess.run(list(map(str, command)), text=True, capture_output=True)
    commands.append(dict(command=list(map(str, command)), status=result.returncode,
                         stdout=result.stdout, stderr=result.stderr))
    (root / 'prune-proof-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if result.returncode:
        raise SystemExit(result.stderr)

for name in ('strict', 'diagnostics'):
    run([binaryen / 'wasm-as', *features, root / (name + '.wat'), '-o', root / (name + '.wasm')])
run([binaryen / 'wasm-merge', *features, root / 'strict.wasm', 'snail.abi', runtime, 'snail.library', root / 'diagnostics.wasm', 'snail.platform', '-o', root / 'merged.wasm'])
run([binaryen / 'wasm-dis', root / 'merged.wasm', '-o', root / 'merged.wat'])
exports = re.findall(r'\(export "([^"]+)"', (root / 'merged.wat').read_text())
removed = [name for name in exports if name not in ('main', '_initialize', 'memory')]
run([binaryen / 'wasm-opt', *features, '--remove-exports', '--pass-arg=remove-exports@snail:*,diagnostics/*', '--remove-unused-module-elements', root / 'merged.wasm', '-o', root / 'linked.wasm'])
run([binaryen / 'wasm-dis', root / 'linked.wasm', '-o', root / 'linked.wat'])
(root / 'check.mjs').write_text('''import assert from 'node:assert/strict';
import fs from 'node:fs';
import {WASI} from 'node:wasi';
const module = new WebAssembly.Module(fs.readFileSync(new URL('./linked.wasm', import.meta.url)));
const imports = WebAssembly.Module.imports(module);
assert(imports.every(item => item.module === 'wasi_snapshot_preview1'));
const wasi = new WASI({version: 'preview1', args: [], env: {}, preopens: {'.': process.cwd()}});
const instance = new WebAssembly.Instance(module, {wasi_snapshot_preview1: wasi.wasiImport});
wasi.initialize(instance);
assert.equal(instance.exports.main(), 42n);
console.log(JSON.stringify({imports, exports: WebAssembly.Module.exports(module), result: '42'}));
''')
run([node, root / 'check.mjs'])
print(commands[-1]['stdout'])
