(module
  (import "snail.library" "snail:initialize-environment" (func $environment))
  (func (export "main") (result i64) (call $environment) (i64.const 42)))
