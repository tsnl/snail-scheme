(module
  (import "snail.library" "snail:report-error" (func $report (param i32 i32)))
  (export "diagnostics/report-error" (func $report)))
