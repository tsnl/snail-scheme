import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

root = Path('/tmp/snail-strict-ray-20261014')
directory = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('r7rs', root / 'benchmarks/r7rs.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
files = runner.suite_sources()
(directory / 'outputs').mkdir(exist_ok=True)
(directory / 'program.scm').write_text(runner.source_text(files, 'ray', 'chez'))
(directory / 'input.txt').write_bytes(files['inputs/ray.input'])
os.environ['CHEZ'] = '/nix/store/bzqpmy5kmvf0xn4xh5ixzkw00w9srh07-chez-scheme-10.4.1/bin/scheme'
build, command = runner.chez_commands(directory, str(directory / 'program.scm'))
records = {}
for name, invocation, data in [('build', build, None), ('correctness', command, files['inputs/ray.input'])]:
    result = runner.execute(invocation, directory, 300, data)
    records[name] = dict(result, command=invocation, purpose='correctness only; not a performance sample')
    (directory / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    if result['status'] != 'ok':
        raise SystemExit(result)
image = directory / 'outputs/ray.output'
pixels = runner.check_ray_image(directory)
shutil.copyfile(image, directory / 'reference.pgm')
report = dict(upstream_revision=runner.REVISION, count=50, resolution=1,
              image_bytes=image.stat().st_size, image_sha256=hashlib.sha256(image.read_bytes()).hexdigest(),
              pixels_sha256=pixels,
              files={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.iterdir() if p.is_file()})
(directory / 'reference.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('count', 'resolution', 'image_bytes', 'image_sha256', 'pixels_sha256')}))
