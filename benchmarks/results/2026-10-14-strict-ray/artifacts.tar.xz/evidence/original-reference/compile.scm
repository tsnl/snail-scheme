(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-ray-evidence-20261014/original-reference/program.scm" "/tmp/snail-strict-ray-evidence-20261014/original-reference/program.so"))
