"""Freeze Ray preparation and bounded prerequisite evidence as regular files."""

import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path('/tmp/snail-strict-ray-20261014')
prepared = Path('/tmp/snail-strict-ray-preparation-20261014-r2')
evidence = Path('/tmp/snail-strict-ray-evidence-20261014')
report = root / 'benchmarks/results/2026-10-14-strict-ray'
files = {}


def include(directory, prefix, accept=lambda path: True):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and accept(path):
            files[prefix + '/' + str(path.relative_to(directory))] = path


include(prepared, 'preparation')
include(evidence, 'evidence')
include(Path('/tmp/snail-strict-ray-prerequisites-20261014'), 'pruning-proof')
include(root / 'build/strict-io', 'io-contracts',
        lambda path: path.name == 'runtime.json' or path.relative_to(root / 'build/strict-io').parts[0].startswith(('output', 'main-trap')))
include(root / 'build/strict-extern', 'round-contracts',
        lambda path: path.name.startswith(('round', 'provider')) or path.name == 'results.json')
include(root / 'build/strict-round', 'round-rejections')
for path in [*root.glob('tests/**/*round*.scm'), *root.glob('tests/strict-io/*'),
             root / 'tests/strict-extern/run.mjs', root / 'tests/strict-extern/cases.json',
             root / 'scripts/test-strict-io', root / 'scripts/test-strict-extern']:
    files['contract-source/' + str(path.relative_to(root))] = path

manifest = dict(source_commit='024b3d1d7d6758de9266a7802a25849537fc7e57',
                compiler_basis='053a8d85860be536095247e3217db60c45908a70', files={})
archive = report / 'artifacts.tar.xz'
with tarfile.open(archive, 'w:xz', preset=4) as bundle:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest['files'][name] = hashlib.sha256(data).hexdigest()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
        bundle.addfile(entry, io.BytesIO(data))
manifest['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
manifest['archive_bytes'] = archive.stat().st_size
(report / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(files=len(files), archive_bytes=manifest['archive_bytes'], archive_sha256=manifest['archive_sha256'])))
