"""Run the separately assembled Ray observer; these are not timing samples."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

prepared, destination = map(Path, sys.argv[1:])
metadata = json.loads((prepared / 'prepared.json').read_text())
specification = json.loads((prepared / 'ray/spec.json').read_text())
source = (prepared / 'ray-host.mjs').read_text()
source = source.replace('const setupBarriers = barriers;', '''const setupBarriers = barriers;
  const counters = Object.entries(instance.exports).filter(([name]) => name.startsWith('observed:'));
  const setupCounters = Object.fromEntries(counters.map(([name, value]) => [name, value.value]));''')
source = source.replace("setup_barriers: mode === '--validate' ? setupBarriers : null};", '''setup_barriers: mode === '--validate' ? setupBarriers : null};
  observation.counters = Object.fromEntries(counters.map(([name, value]) =>
    [name.slice(9), (value.value - setupCounters[name]).toString()]));''')
(destination / 'host.mjs').write_text(source)
(destination / 'outputs').mkdir(exist_ok=True)
records, observations = [], []
for count in (1, 2, 50):
    spec = destination / f'count-{count}.json'
    spec.write_text(json.dumps(dict(specification, count=count, trace=True), indent=2) + '\n')
    (destination / 'outputs/ray.output').unlink(missing_ok=True)
    command = [metadata['tools']['NODE']['path'], '--disable-warning=ExperimentalWarning',
               str(destination / 'host.mjs'), str(destination / 'observed.wasm'), str(spec), '--validate']
    run = subprocess.run(command, cwd=destination, capture_output=True, text=True)
    records.append(dict(command=command, returncode=run.returncode, stdout=run.stdout,
                        stderr=run.stderr, count=count, purpose='diagnostics only; not a performance sample'))
    (destination / 'executions.json').write_text(json.dumps(records, indent=2) + '\n')
    run.check_returncode()
    observations.append(json.loads(run.stdout))

keys = [key for key in observations[0]['counters'] if key.startswith(('sqrt:', 'nearest:', 'allocation:'))
        or key == 'function:$function70']
for count, observation in zip((1, 2, 50), observations):
    for key in keys:
        assert int(observation['counters'][key]) == count * int(observations[0]['counters'][key]), (count, key)
    events = []
    for index in range(count):
        if index:
            events.append(['path_unlink_file', 0])
        events.extend((['path_open', 0], ['fd_close', 0]))
    assert observation['events'] == events

image = hashlib.sha256((destination / 'outputs/ray.output').read_bytes()).hexdigest()
assert image == specification['image_sha256']
canonical = observations[-1]['counters']
for key, expected in (('function:$function70', 17000000), ('nearest:$function66:1', 500000),
                      ('allocation:$type50', 1650), ('allocation:$type49', 320350),
                      ('sqrt:$function70:2', 405300), ('sqrt:$function70:3', 405300)):
    assert int(canonical[key]) == expected, key
summary = dict(checked_counters=keys, geometry_and_gc_site_counters_scale_exactly=True,
               counts=[1, 2, 50], image_sha256=image, canonical_sphere_visits=16500000,
               canonical_pixels=500000, canonical_sphere_products=1650,
               canonical_hit_improvements=320350, canonical_candidate_distances=405300,
               file_events_exact=True)
(destination / 'scaling.json').write_text(json.dumps(summary, indent=2) + '\n')
