(import (chezscheme))
(write (+ 1e16 -1e16 1.0)) (newline)
(write (+ 1e16 1.0 -1e16 1.0)) (newline)
(write (nan? (* 1e308 1e308 0.0))) (newline)
