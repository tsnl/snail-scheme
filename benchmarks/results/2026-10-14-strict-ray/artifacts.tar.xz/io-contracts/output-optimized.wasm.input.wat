(module
 (type $0 (func))
 (rec
  (type $1 (func (param i64 (ref $type30))))
  (type $type31 (struct (field (mut i32))))
  (type $type30 (struct (field (ref $type31))))
  (type $4 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
  (type $5 (func (param (ref $type14) i64 i32 i32 i64) (result i32)))
  (type $6 (func (param (ref $type14)) (result i32)))
  (type $7 (func (param (ref $type14) i32) (result (ref $type15))))
  (type $type10 (struct))
  (type $type8 (struct))
  (type $type7 (struct))
  (type $type5 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type37 (struct))
  (type $type35 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type14 (struct (field i32) (field (ref $type15))))
  (type $type15 (array (mut i32)))
 )
 (type $26 (func (result i32)))
 (type $27 (func (param i32)))
 (type $28 (func (result i64)))
 (type $29 (func (param i32 i32)))
 (type $30 (func (param i64) (result i64)))
 (type $31 (func (result f64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign5 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign6 (param i32 i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 10)
  (array.new_fixed $type15 10
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 955)
   (i32.const 128512)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 0)
   (i32.const 955)
   (i32.const 128512)
   (i32.const 1114111)
  )
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 10)
  (array.new_fixed $type15 10
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 117)
   (i32.const 108)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string4 (ref $type14) (struct.new $type14
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 97)
   (i32.const 110)
   (i32.const 115)
   (i32.const 119)
   (i32.const 101)
   (i32.const 114)
  )
 ))
 (global $string5 (ref $type14) (struct.new $type14
  (i32.const 9)
  (array.new_fixed $type15 9
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 97)
   (i32.const 115)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string6 (ref $type14) (struct.new $type14
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 111)
   (i32.const 110)
   (i32.const 99)
   (i32.const 101)
  )
 ))
 (global $string7 (ref $type14) (struct.new $type14
  (i32.const 14)
  (array.new_fixed $type15 14
   (i32.const 115)
   (i32.const 101)
   (i32.const 108)
   (i32.const 102)
   (i32.const 45)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string8 (ref $type14) (struct.new $type14
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
  )
 ))
 (global $string9 (ref $type14) (struct.new $type14
  (i32.const 11)
  (array.new_fixed $type15 11
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string10 (ref $type14) (struct.new $type14
  (i32.const 16)
  (array.new_fixed $type15 16
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 47)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string11 (ref $type14) (struct.new $type14
  (i32.const 8)
  (array.new_fixed $type15 8
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 0)
   (i32.const 112)
   (i32.const 97)
   (i32.const 116)
   (i32.const 104)
  )
 ))
 (global $string12 (ref $type14) (struct.new $type14
  (i32.const 10)
  (array.new_fixed $type15 10
   (i32.const 97)
   (i32.const 98)
   (i32.const 115)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string13 (ref $type14) (struct.new $type14
  (i32.const 8)
  (array.new_fixed $type15 8
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 112)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string14 (ref $type14) (struct.new $type14
  (i32.const 8)
  (array.new_fixed $type15 8
   (i32.const 98)
   (i32.const 117)
   (i32.const 102)
   (i32.const 102)
   (i32.const 101)
   (i32.const 114)
   (i32.const 101)
   (i32.const 100)
  )
 ))
 (global $string15 (ref $type14) (struct.new $type14
  (i32.const 9)
  (array.new_fixed $type15 9
   (i32.const 102)
   (i32.const 105)
   (i32.const 114)
   (i32.const 115)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string16 (ref $type14) (struct.new $type14
  (i32.const 10)
  (array.new_fixed $type15 10
   (i32.const 115)
   (i32.const 101)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 100)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
 ))
 (global $string17 (ref $type14) (struct.new $type14
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 115)
   (i32.const 101)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 100)
  )
 ))
 (global $string18 (ref $type14) (struct.new $type14
  (i32.const 5)
  (array.new_fixed $type15 5
   (i32.const 102)
   (i32.const 105)
   (i32.const 114)
   (i32.const 115)
   (i32.const 116)
  )
 ))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type28)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type33)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global154 (mut (ref null $type35)) (ref.null none))
 (global $ready154 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type37)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global176 (mut (ref null $type39)) (ref.null none))
 (global $ready176 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type40)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type41)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type32)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type42)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type42)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type43)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type5)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global152 (mut (ref null $type7)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type8)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global160 (mut (ref null $type10)) (ref.null none))
 (global $ready160 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type10)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type5)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type10)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global174 (mut (ref null $type10)) (ref.null none))
 (global $ready174 (mut i32) (i32.const 0))
 (global $global181 (mut (ref null $type8)) (ref.null none))
 (global $ready181 (mut i32) (i32.const 0))
 (global $global182 (mut (ref null $type10)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type10)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type10)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type10)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global189 (mut (ref null $type10)) (ref.null none))
 (global $ready189 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type10)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (export "format-number" (func $export0))
 (export "unicode" (func $export1))
 (export "callback-result" (func $export2))
 (export "exists" (func $export3))
 (export "remove" (func $export4))
 (export "close-alias" (func $export5))
 (export "callback-close" (func $export6))
 (export "escaped-alias" (func $export7))
 (export "missing-directory" (func $export8))
 (export "nul-path" (func $export9))
 (export "delete-absent" (func $export10))
 (export "callback-trap" (func $export11))
 (export "close-failure" (func $export12))
 (export "invalid-character" (func $export13))
 (export "invalid-handle" (func $export14))
 (export "interrupted-path" (func $export15))
 (export "main" (func $main))
 (func $string-block (type $7) (param $0 (ref $type14)) (param $1 i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 1
     (local.get $0)
    )
   )
   (else
    (unreachable)
   )
  )
 )
 (func $function41 (type $6) (param $0 (ref $type14)) (result i32)
  (local $1 i64)
  (call $foreign0)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type14 0
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (struct.get $type14 1
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 0
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (array.get $type15
        (struct.get $type14 1
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (array.get $type15
          (struct.get $type14 1
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 0
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (array.get $type15
            (struct.get $type14 1
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 0
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (array.get $type15
              (struct.get $type14 1
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 0
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (array.get $type15
                (struct.get $type14 1
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 0
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (array.get $type15
                  (struct.get $type14 1
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 0
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (array.get $type15
                    (struct.get $type14 1
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 0
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (array.get $type15
                      (struct.get $type14 1
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 0
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (array.get $type15
                        (struct.get $type14 1
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type14 0
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign1
                         (array.get $type15
                          (struct.get $type14 1
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type14 0
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign1
                           (array.get $type15
                            (struct.get $type14 1
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type14 0
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign1
                             (array.get $type15
                              (struct.get $type14 1
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type14 0
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign1
                               (array.get $type15
                                (struct.get $type14 1
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type14 0
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign1
                                 (array.get $type15
                                  (call $string-block
                                   (local.get $0)
                                   (i32.const 14)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (return_call $function42
                                 (local.get $0)
                                 (local.get $1)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $5) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function49 (type $4) (param $0 (ref $type14)) (param $1 (ref $type30)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (else
        (unreachable)
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $1) (param $0 i64) (param $1 (ref $type30))
  (local $2 i64)
  (if
   (i64.ne
    (local.tee $2
     (i64.div_s
      (local.get $0)
      (i64.const 10)
     )
    )
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready138)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global138)
     )
    )
    (call $function52
     (local.get $2)
     (local.get $1)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (i64.sub
      (i64.const 48)
      (i64.rem_s
       (local.get $0)
       (i64.const 10)
      )
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (i32.wrap_i64
    (local.get $0)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type30))
  (local $2 (ref $type31))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $1
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (i32.const 45)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (call $function52
   (select
    (i64.sub
     (i64.const 0)
     (local.get $0)
    )
    (local.get $0)
    (i64.gt_s
     (local.get $0)
     (i64.const 0)
    )
   )
   (local.get $1)
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (i32.const 10)
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type31 0
      (local.tee $2
       (struct.get $type30 0
        (local.get $1)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $3)
    )
   )
  )
  (local.get $0)
 )
 (func $export1 (result i64)
  (local $0 (ref $type30))
  (local $1 (ref $type31))
  (local $2 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string1)
   )
  )
  (local.set $0
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string2)
    (local.get $0)
    (i64.const 4)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $0)
    )
   )
   (i32.const 10)
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $2
     (struct.get $type31 0
      (local.tee $1
       (struct.get $type30 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
  (i64.const 42)
 )
 (func $export2 (result f64)
  (local $0 (ref $type30))
  (local $1 (ref $type31))
  (local $2 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready152)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (if
   (i32.eqz
    (global.get $ready154)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global154)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string3)
   )
  )
  (local.set $0
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string4)
    (local.get $0)
    (i64.const 6)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $2
     (struct.get $type31 0
      (local.tee $1
       (struct.get $type30 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
  (f64.const 1.25)
 )
 (func $export3 (result i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global159)
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string1)
   )
  )
  (i32.eq
   (call $foreign2)
   (i32.const 1)
  )
 )
 (func $export4
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready160)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global160)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string1)
   )
  )
  (call $foreign3)
 )
 (func $export5
  (local $0 (ref $type30))
  (local $1 (ref $type31))
  (local $2 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string5)
   )
  )
  (local.set $0
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string6)
    (local.get $0)
    (i64.const 4)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $2
     (struct.get $type31 0
      (local.tee $1
       (struct.get $type30 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $2
     (struct.get $type31 0
      (local.tee $1
       (struct.get $type30 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
 )
 (func $export6 (result i64)
  (local $0 (ref $type30))
  (local $1 (ref $type31))
  (local $2 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready164)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string7)
   )
  )
  (local.set $0
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string8)
    (local.get $0)
    (i64.const 6)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $2
     (struct.get $type31 0
      (local.tee $1
       (struct.get $type30 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $2
     (struct.get $type31 0
      (local.tee $1
       (struct.get $type30 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
  (i64.const 19)
 )
 (func $export7
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (if
   (i32.eqz
    (global.get $ready169)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string9)
   )
  )
  (local.set $0
   (call $foreign4)
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign5
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign5
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (local.get $0)
   (i32.const 120)
  )
 )
 (func $export8
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready174)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global174)
   )
  )
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string10)
   )
  )
  (local.set $0
   (call $foreign4)
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (local.get $0)
   (i32.const 120)
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign5
     (local.get $0)
    )
   )
  )
 )
 (func $export9 (result i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready181)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global181)
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string11)
   )
  )
  (i32.eq
   (call $foreign2)
   (i32.const 1)
  )
 )
 (func $export10
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string12)
   )
  )
  (call $foreign3)
 )
 (func $export11
  (local $0 (ref $type30))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string13)
   )
  )
  (local.set $0
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string14)
    (local.get $0)
    (i64.const 8)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (unreachable)
 )
 (func $export12
  (local $0 (ref $type30))
  (local $1 (ref $type30))
  (local $2 (ref $type31))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global185)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string15)
   )
  )
  (local.set $0
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string16)
   )
  )
  (local.set $1
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string18)
    (local.get $0)
    (i64.const 5)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string17)
    (local.get $1)
    (i64.const 6)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type31 0
      (local.tee $2
       (struct.get $type30 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $3)
    )
   )
  )
 )
 (func $export13
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready188)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global188)
   )
  )
  (call $foreign0)
  (call $foreign1
   (i32.const 55296)
  )
 )
 (func $export14
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready189)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global189)
   )
  )
  (call $foreign5
   (i32.const -1)
  )
 )
 (func $export15
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready190)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global190)
   )
  )
  (call $foreign0)
  (call $foreign1
   (i32.const 65)
  )
  (unreachable)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type28)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type27)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type29)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type32)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global145
   (struct.new_default $type33)
  )
  (global.set $ready145
   (i32.const 1)
  )
  (global.set $global154
   (struct.new_default $type35)
  )
  (global.set $ready154
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type37)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global176
   (struct.new_default $type39)
  )
  (global.set $ready176
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type40)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type41)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type32)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type42)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type42)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type43)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global150
   (struct.new_default $type5)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $global152
   (struct.new_default $type7)
  )
  (global.set $ready152
   (i32.const 1)
  )
  (global.set $global159
   (struct.new_default $type8)
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global160
   (struct.new_default $type10)
  )
  (global.set $ready160
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type10)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type5)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type10)
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global174
   (struct.new_default $type10)
  )
  (global.set $ready174
   (i32.const 1)
  )
  (global.set $global181
   (struct.new_default $type8)
  )
  (global.set $ready181
   (i32.const 1)
  )
  (global.set $global182
   (struct.new_default $type10)
  )
  (global.set $ready182
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type10)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global185
   (struct.new_default $type10)
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global188
   (struct.new_default $type10)
  )
  (global.set $ready188
   (i32.const 1)
  )
  (global.set $global189
   (struct.new_default $type10)
  )
  (global.set $ready189
   (i32.const 1)
  )
  (global.set $global190
   (struct.new_default $type10)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

