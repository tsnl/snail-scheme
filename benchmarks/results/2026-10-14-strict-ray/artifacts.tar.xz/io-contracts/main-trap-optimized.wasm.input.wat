(module
 (rec
  (type $type31 (struct (field i32)))
  (type $1 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
  (type $type30 (struct (field (ref $type31))))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type29 (struct))
  (type $type27 (struct))
  (type $type14 (struct))
  (type $type15 (array (mut i32)))
 )
 (type $9 (func))
 (type $10 (func (param i32)))
 (type $11 (func (result i32)))
 (type $12 (func (param i32 i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign6 (param i32 i32)))
 (global $global$0 (ref $type15) (array.new_fixed $type15 28
  (i32.const 98)
  (i32.const 117)
  (i32.const 102)
  (i32.const 102)
  (i32.const 101)
  (i32.const 114)
  (i32.const 101)
  (i32.const 100)
  (i32.const 32)
  (i32.const 98)
  (i32.const 101)
  (i32.const 102)
  (i32.const 111)
  (i32.const 114)
  (i32.const 101)
  (i32.const 32)
  (i32.const 109)
  (i32.const 97)
  (i32.const 105)
  (i32.const 110)
  (i32.const 32)
  (i32.const 116)
  (i32.const 114)
  (i32.const 97)
  (i32.const 112)
  (i32.const 112)
  (i32.const 101)
  (i32.const 100)
 ))
 (global $string0 (ref $type14) (struct.new_default $type14))
 (global $global$2 (ref $type15) (array.new_fixed $type15 13
  (i32.const 109)
  (i32.const 97)
  (i32.const 105)
  (i32.const 110)
  (i32.const 45)
  (i32.const 116)
  (i32.const 114)
  (i32.const 97)
  (i32.const 112)
  (i32.const 46)
  (i32.const 116)
  (i32.const 120)
  (i32.const 116)
 ))
 (global $execution (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $global124 (mut (ref null $type33)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type34)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type30)) (ref.null none))
 (export "main" (func $main))
 (func $function49 (type $1) (param $0 (ref $type14)) (param $1 (ref $type30)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (select
       (i64.const 28)
       (i64.const 13)
       (ref.eq
        (local.get $0)
        (global.get $string0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (select (result (ref $type15))
         (global.get $global$0)
         (global.get $global$2)
         (ref.eq
          (local.get $0)
          (global.get $string0)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $main
  (local $0 (ref $type15))
  (local $1 (ref $type30))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $global118
   (struct.new_default $type29)
  )
  (global.set $global124
   (struct.new_default $type33)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type34)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (call $foreign0)
  (call $foreign1
   (array.get $type15
    (local.tee $0
     (global.get $global$2)
    )
    (i32.const 0)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.get $0)
    (i32.const 1)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.get $0)
    (i32.const 2)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.get $0)
    (i32.const 3)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 4)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 5)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 6)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 7)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 8)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 9)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 10)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 11)
   )
  )
  (call $foreign1
   (array.get $type15
    (global.get $global$2)
    (i32.const 12)
   )
  )
  (global.set $global142
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string0)
    (local.get $1)
    (i64.const 28)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (unreachable)
 )
)

