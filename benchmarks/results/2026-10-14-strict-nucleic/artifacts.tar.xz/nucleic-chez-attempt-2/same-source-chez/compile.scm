(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-nucleic-20261014/build/nucleic-chez-attempt-2/same-source-chez/program.scm" "/tmp/snail-strict-nucleic-20261014/build/nucleic-chez-attempt-2/same-source-chez/program.so"))
