import json
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path('benchmarks/strict-suite').resolve()))
import measure as driver
import nucleic_port as port
runner=driver.upstream_runner()
files=runner.suite_sources()
tools=driver.tool_paths(['nucleic'])
environment={**os.environ,**tools,'BINARYEN_CORES':'1'}
out=Path('build/nucleic-chez-attempt-2').resolve()
spec=port.specification(files['inputs/nucleic.input'])
driver.write_case_sources('nucleic',files,out,spec,runner)
driver.build_chez(out,runner,environment,'chez-build.json')
driver.prepare_adapted_chez('nucleic',out,runner,environment)
driver.validate_chez(out,runner,tools,environment,spec)
port.source_proof(out,driver)
original=(out/'original-kernel.scm').read_text()
adapted=(out/'adapted-kernel.scm').read_text()
for label,kernel in [('original',None),('adapted',adapted)]:
    target=out/('probe-'+label)
    target.mkdir()
    (target/'program.scm').write_text(port.chez_probe(original,kernel))
    driver.build_chez(target,runner,environment,'build.json')
checks=[]
for command in range(7):
    expected=None
    for system in ('original','adapted'):
        record=port.probe_execution(out,system,command,tools,environment,driver)
        driver.save(out/f'probe-{system}-{command}.json',record)
        driver.require_success(record)
        actual=port.probe_values(record,system)
        expected=actual if expected is None else expected
        tolerance=0 if command in (0,4) else 1e-11
        assert not record['stderr'] and port.same_values(actual,expected,tolerance),(command,system)
        port.validate_comparator(expected,tolerance)
    checks.append(dict(command=command,observations=len(expected)))
    print(checks[-1],flush=True)
driver.save(out/'probe-summary.json',checks)
checks=[]
for label,count,expected,accepted in port.predicate_fixtures():
    case=dict(spec,count=count,inputs=[0,expected],expected=int(accepted))
    for system in ('original','adapted'):
        record=port.predicate_execution(out,system,case,None,tools,environment,driver)
        checks.append(dict(record,system=system,label=label,accepted=accepted))
        driver.save(out/'predicate-validation.json',checks)
        driver.require_success(record)
        actual=runner.parse_result(record['stdout'],'chez','nucleic')['status']=='ok'
        assert not record['stderr'] and actual==accepted,(label,system,record)
print('PASS both Chez controls, full counts, complete ordered results and numeric predicate',flush=True)
