import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/tmp/snail-strict-nucleic-20261014')
out = root / 'build/nucleic-copy-diagnostic'
modules = out / 'src/snail-scheme'
modules.mkdir(parents=True, exist_ok=True)
for path in (root / 'src').iterdir():
    if path.name != 'snail-scheme':
        (out / 'src' / path.name).symlink_to(path, target_is_directory=path.is_dir())
for path in (root / 'src/snail-scheme').iterdir():
    if path.name not in ('expand.sld', 'chromium-trace.sld', 'strict-compiler.sld', 'strict-infer.sld', 'ir.sld'):
        (modules / path.name).symlink_to(path, target_is_directory=path.is_dir())
original = (root / 'src/snail-scheme/expand.sld').read_text()
source = original.replace('(scheme cxr)', '(scheme cxr) (scheme write)', 1)
before = '''        (lambda (values transformers)
          (make-value-binding (cdr (pending-definition-binding pending))
                              (build values transformers) (syntax-loc form)))))'''
after = '''        (lambda (values transformers)
          (let ((name (value-definition-name (cdr (pending-definition-binding pending)))))
            (write (list 'start name) (current-error-port)) (newline (current-error-port))
            (let ((result (make-value-binding (cdr (pending-definition-binding pending))
                                             (build values transformers) (syntax-loc form))))
              (write (list 'finish name) (current-error-port)) (newline (current-error-port))
              result)))))'''
assert source.count(before) == 1
source = source.replace(before, after)
source = source.replace('(attach-declarations! (apply append chunks))', '(write \'attach-start (current-error-port)) (newline (current-error-port)) (attach-declarations! (apply append chunks)) (write \'attach-finish (current-error-port)) (newline (current-error-port))')
source = source.replace('(runtime-items items) loc)', '(begin (write \'runtime-start (current-error-port)) (newline (current-error-port)) (let ((result (runtime-items items))) (write \'runtime-finish (current-error-port)) (newline (current-error-port)) result)) loc)')
source = source.replace('(expand-expression form (append values macros outer) transformers fuel)', '(begin (write (list \'expression-start (syntax-loc form)) (current-error-port)) (newline (current-error-port)) (let ((result (expand-expression form (append values macros outer) transformers fuel))) (write \'expression-finish (current-error-port)) (newline (current-error-port)) result))')
(modules / 'expand.sld').write_text(source)

trace = (root / 'src/snail-scheme/chromium-trace.sld').read_text()
trace = trace.replace('(write-trace-span name start (current-jiffy) port)', "(write (list 'span-return name) (current-error-port)) (newline (current-error-port)) (write-trace-span name start (current-jiffy) port) (write (list 'span-written name) (current-error-port)) (newline (current-error-port))")
(modules / 'chromium-trace.sld').write_text(trace)
compiler = (root / 'src/snail-scheme/strict-compiler.sld').read_text()
compiler = compiler.replace('(syntax-list->ir-library (read-forms path) (library-loader root) (list core))', "(let ((result (syntax-list->ir-library (read-forms path) (library-loader root) (list core)))) (write 'expanded (current-error-port)) (newline (current-error-port)) result)")
compiler = compiler.replace('(infer-program items (primitive-bindings core) (library:library-loc program))', "(begin (write 'infer-start (current-error-port)) (newline (current-error-port)) (let ((result (infer-program items (primitive-bindings core) (library:library-loc program)))) (write 'infer-end (current-error-port)) (newline (current-error-port)) result))")
(modules / 'strict-compiler.sld').write_text(compiler)

infer = (root / 'src/snail-scheme/strict-infer.sld').read_text()
infer = infer.replace('(scheme base) (scheme cxr)', '(scheme base) (scheme cxr) (scheme write)')
infer = infer.replace('(copy-ir-graph (list items primitive-bindings))', "(begin (write 'copy-start (current-error-port)) (newline (current-error-port)) (let ((result (copy-ir-graph (list items primitive-bindings)))) (write 'copy-end (current-error-port)) (newline (current-error-port)) result))")
infer = infer.replace('(define (check-initializer! binding scope)', "(define (check-initializer! binding scope) (write (list 'check (ir:value-definition-name binding)) (current-error-port)) (newline (current-error-port))")
(modules / 'strict-infer.sld').write_text(infer)

ir = (root / 'src/snail-scheme/ir.sld').read_text()
ir = ir.replace('(import (scheme base)', '(import (scheme base) (scheme time) (scheme write)', 1)
ir = ir.replace("(let ((copies '()))", "(let ((copies '()) (count 0))", 1)
ir = ir.replace("(set! copies (cons (cons original copy) copies)) copy)", "(set! count (+ count 1)) (when (= (modulo count 1000) 0) (write (list 'copied count (current-second)) (current-error-port)) (newline (current-error-port))) (set! copies (cons (cons original copy) copies)) copy)", 1)
(modules / 'ir.sld').write_text(ir)
command = ['chibi-scheme', '-I', str(out / 'src'), str(root / 'tests/build-strict-program.scm'),
           str(root), str(root / 'build/nucleic-attempt-2/strict.scm'), str(out / 'strict.wasm'), 'bench']
started = time.perf_counter()
record = dict(command=command, timeout_seconds=60)
with (out / 'stdout').open('w') as stdout, (out / 'stderr').open('w') as stderr:
    process = subprocess.Popen(command, cwd=root, env={**os.environ, 'BINARYEN_CORES': '1'}, stdout=stdout, stderr=stderr)
    (out / 'pid').write_text(str(process.pid) + '\n')
    try:
        record['returncode'] = process.wait(timeout=60)
    except subprocess.TimeoutExpired:
        process.terminate()
        process.wait(timeout=5)
        record['error'] = 'bounded diagnostic timeout'
record['process_seconds'] = time.perf_counter() - started
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(record)
