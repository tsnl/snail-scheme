import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/tmp/snail-strict-nucleic-20261014')
out = root / 'build/nucleic-expansion-diagnostic-2'
modules = out / 'src/snail-scheme'
modules.mkdir(parents=True, exist_ok=True)
for path in (root / 'src').iterdir():
    if path.name != 'snail-scheme':
        (out / 'src' / path.name).symlink_to(path, target_is_directory=path.is_dir())
for path in (root / 'src/snail-scheme').iterdir():
    if path.name != 'expand.sld':
        (modules / path.name).symlink_to(path, target_is_directory=path.is_dir())
original = (root / 'src/snail-scheme/expand.sld').read_text()
source = original.replace('(scheme cxr)', '(scheme cxr) (scheme write)', 1)
before = '''        (lambda (values transformers)
          (make-value-binding (cdr (pending-definition-binding pending))
                              (build values transformers) (syntax-loc form)))))'''
after = '''        (lambda (values transformers)
          (let ((name (value-definition-name (cdr (pending-definition-binding pending)))))
            (write (list 'start name) (current-error-port)) (newline (current-error-port))
            (let ((result (make-value-binding (cdr (pending-definition-binding pending))
                                             (build values transformers) (syntax-loc form))))
              (write (list 'finish name) (current-error-port)) (newline (current-error-port))
              result)))))'''
assert source.count(before) == 1
source = source.replace(before, after)
source = source.replace('(attach-declarations! (apply append chunks))', '(write \'attach-start (current-error-port)) (newline (current-error-port)) (attach-declarations! (apply append chunks)) (write \'attach-finish (current-error-port)) (newline (current-error-port))')
source = source.replace('(runtime-items items) loc)', '(begin (write \'runtime-start (current-error-port)) (newline (current-error-port)) (let ((result (runtime-items items))) (write \'runtime-finish (current-error-port)) (newline (current-error-port)) result)) loc)')
source = source.replace('(expand-expression form (append values macros outer) transformers fuel)', '(begin (write (list \'expression-start (syntax-loc form)) (current-error-port)) (newline (current-error-port)) (let ((result (expand-expression form (append values macros outer) transformers fuel))) (write \'expression-finish (current-error-port)) (newline (current-error-port)) result))')
(modules / 'expand.sld').write_text(source)
command = ['chibi-scheme', '-I', str(out / 'src'), str(root / 'tests/build-strict-program.scm'),
           str(root), str(root / 'build/nucleic-attempt-2/strict.scm'), str(out / 'strict.wasm'), 'bench']
started = time.perf_counter()
record = dict(command=command, timeout_seconds=120)
with (out / 'stdout').open('w') as stdout, (out / 'stderr').open('w') as stderr:
    process = subprocess.Popen(command, cwd=root, env={**os.environ, 'BINARYEN_CORES': '1'}, stdout=stdout, stderr=stderr)
    (out / 'pid').write_text(str(process.pid) + '\n')
    try:
        record['returncode'] = process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        process.terminate()
        process.wait(timeout=5)
        record['error'] = 'bounded diagnostic timeout'
record['process_seconds'] = time.perf_counter() - started
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(record)
