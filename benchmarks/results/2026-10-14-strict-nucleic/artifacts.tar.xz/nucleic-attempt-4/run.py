import json
import os
from pathlib import Path
import signal
import subprocess
import time
root = Path('/tmp/snail-strict-nucleic-20261014')
out = root / 'build/nucleic-attempt-4'
command = [str(root / 'scripts/build-strict'), '--export', 'bench', str(out / 'strict.scm'), str(out / 'strict.wasm')]
record = dict(command=command, timeout_seconds=300)
started = time.perf_counter()
with (out / 'stdout').open('w') as stdout, (out / 'stderr').open('w') as stderr:
    process = subprocess.Popen(command, cwd=root, env={**os.environ, 'BINARYEN_CORES': '1'}, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        record['returncode'] = process.wait(timeout=300)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=5)
        record['error'] = 'bounded compilation timeout'
record['process_seconds'] = time.perf_counter() - started
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(record)
