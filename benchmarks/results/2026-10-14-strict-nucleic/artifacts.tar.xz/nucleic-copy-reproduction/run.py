import json
from pathlib import Path
import subprocess
import time
root = Path('/tmp/snail-strict-nucleic-20261014')
out = root / 'build/nucleic-copy-reproduction'
command = ['chibi-scheme', '-I', str(root / 'src'), str(out / 'copy-linear.scm')]
record = dict(command=command, timeout_seconds=60)
started = time.perf_counter()
with (out / 'stdout').open('w') as stdout, (out / 'stderr').open('w') as stderr:
    process = subprocess.Popen(command, cwd=root, stdout=stdout, stderr=stderr)
    try:
        record['returncode'] = process.wait(timeout=60)
    except subprocess.TimeoutExpired:
        process.terminate()
        process.wait(timeout=5)
        record['error'] = 'bounded reproduction timeout'
record['process_seconds'] = time.perf_counter() - started
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(record)
