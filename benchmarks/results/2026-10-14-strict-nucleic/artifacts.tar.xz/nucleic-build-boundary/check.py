"""Exercise only process groups created by this supervisor boundary check."""
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time

root = Path.cwd()
sys.path.insert(0, str(root / 'benchmarks/strict-suite'))
import nucleic_port
here = root / 'build/nucleic-build-boundary'
old_spec = importlib.util.spec_from_file_location('old_nucleic_port', root / 'build/nucleic-prepared-attempt-1/nucleic_port.py')
old = importlib.util.module_from_spec(old_spec)
old_spec.loader.exec_module(old)
child = '''import json,os,signal,sys,time
signal.signal(signal.SIGTERM, signal.SIG_IGN)
with open(sys.argv[1], 'w') as output:
 json.dump(dict(child=os.getpid(), group=os.getpgrp()), output)
time.sleep(30)
'''
leader = '''import pathlib,subprocess,sys,time
subprocess.Popen([sys.executable, '-c', sys.argv[1], sys.argv[2]], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
while not pathlib.Path(sys.argv[2]).exists(): time.sleep(.001)
print('resistant child ready with closed output pipes', flush=True)
time.sleep(30)
'''

def save(name, record):
    (here / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')

def state(pid):
    try:
        return Path(f'/proc/{pid}/stat').read_text().split(') ')[1].split()[0]
    except FileNotFoundError:
        return 'absent'

for label, module in [('old-closed-pipes', old), ('fixed-closed-pipes', nucleic_port)]:
    identity = here / (label + '-identity.json')
    identity.unlink(missing_ok=True)
    command = [sys.executable, '-c', leader, child, str(identity)]
    record = module.build_record(command, root, os.environ.copy(), timeout=.4)
    process = json.loads(identity.read_text())
    time.sleep(.02)
    record['child_state_after_return'] = state(process['child'])
    if label.startswith('old'):
        assert record['child_state_after_return'] not in ('absent', 'Z')
        os.killpg(process['group'], signal.SIGKILL)
    for _ in range(100):
        if state(process['child']) in ('absent', 'Z'): break
        time.sleep(.01)
    record['child_terminal_state'] = state(process['child'])
    assert record['child_terminal_state'] in ('absent', 'Z')
    assert 'error' in record and record['returncode'] == -signal.SIGTERM
    save(label, record)
    print(label, record['child_state_after_return'], record['child_terminal_state'])

for label, script, expected in [('fixed-success', 'print("complete")', 0), ('fixed-failure', 'import sys; print("failure",file=sys.stderr); sys.exit(7)', 7)]:
    record = nucleic_port.build_record([sys.executable, '-c', script], root, os.environ.copy(), timeout=1)
    assert record['returncode'] == expected and 'error' not in record
    save(label, record)
print('PASS: success, nonzero exit, and timeout with closed-stream resistant child')
