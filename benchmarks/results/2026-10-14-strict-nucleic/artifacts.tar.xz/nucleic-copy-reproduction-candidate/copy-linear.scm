(import (scheme base) (scheme write) (scheme time) (snail-scheme ir))

;; Complete independent nodes share one vector payload. Copying owns the nodes
;; and payload while preserving that shared payload's identity within the copy.
(define (make-graph count)
  (let ((payload (vector 1.0 2.0 3.0)))
    (let loop ((left count) (nodes '()))
      (if (= left 0) nodes
          (loop (- left 1) (cons (make-literal payload #f) nodes))))))

(define (check-copy count)
  (let* ((original (make-graph count)) (started (current-jiffy))
         (copy (copy-ir-graph original))
         (seconds (/ (- (current-jiffy) started) (inexact (jiffies-per-second)))))
    (unless (and (= (length copy) count) (not (eq? (car copy) (car original)))
                 (not (eq? (literal-value (car copy)) (literal-value (car original))))
                 (eq? (literal-value (car copy)) (literal-value (cadr copy))))
      (error "IR copy did not preserve owned shared payloads"))
    (write (list count seconds)) (newline) (flush-output-port (current-output-port))))

(for-each check-copy '(100 1000 5000 10000 20000))
