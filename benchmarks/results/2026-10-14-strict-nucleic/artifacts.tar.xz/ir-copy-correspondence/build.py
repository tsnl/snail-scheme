import json
import os
from pathlib import Path
import subprocess
import sys
root = Path('/tmp/snail-strict-nucleic-20261014')
out = root / 'build/ir-copy-correspondence' / sys.argv[1]
out.mkdir(exist_ok=True)
for name, relative, exports in [
    ('data', 'tests/strict/data-mutual-containers.scm', []),
    ('overload', 'tests/strict/overload-generic.scm', []),
    ('math', 'tests/strict-math.scm', ['--export', 'trigonometry'])]:
    command = [str(root / 'scripts/build-strict'), *exports, str(root / relative), str(out / (name + '.wasm'))]
    run = subprocess.run(command, cwd=root, env={**os.environ, 'BINARYEN_CORES': '1'}, capture_output=True, text=True, timeout=120)
    (out / (name + '.json')).write_text(json.dumps(dict(command=command, returncode=run.returncode, stdout=run.stdout, stderr=run.stderr), indent=2) + '\n')
    if run.returncode: raise RuntimeError(run.stderr)
    print(name, flush=True)
