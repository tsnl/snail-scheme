import json
import os
from pathlib import Path
import signal
import subprocess
import time
root=Path('/tmp/snail-strict-nucleic-20261014')
out=root/'build/ir-dependency-reproduction'
for depth in (10,14,18):
    source=out/f'diamond-{depth}.scm'
    source.write_text('(import (snail strict))\n(define a0 1)\n'+''.join(f'(define a{i} (+ a{i-1} a{i-1}))\n' for i in range(1,depth+1))+f'a{depth}\n')
    command=[str(root/'scripts/build-strict'),str(source),str(out/f'diamond-{depth}.wasm')]
    record=dict(command=command,depth=depth,expected=1<<depth,timeout_seconds=60)
    started=time.perf_counter()
    with (out/f'diamond-{depth}.stdout').open('w') as stdout,(out/f'diamond-{depth}.stderr').open('w') as stderr:
        process=subprocess.Popen(command,cwd=root,env={**os.environ,'BINARYEN_CORES':'1'},stdout=stdout,stderr=stderr,start_new_session=True)
        try: record['returncode']=process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            process.wait(timeout=5)
            record['error']='bounded reproduction timeout'
    record['process_seconds']=time.perf_counter()-started
    (out/f'diamond-{depth}.json').write_text(json.dumps(record,indent=2)+'\n')
    print(record,flush=True)
    if 'error' in record: break
