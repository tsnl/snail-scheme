(import (snail-scheme ir))
(test-ir)
