import hashlib
import json
from pathlib import Path
import subprocess

root=Path('/tmp/snail-strict-nucleic-20261014')
old=['nucleic-expansion-diagnostic','nucleic-expansion-diagnostic-2','nucleic-expansion-diagnostic-3','nucleic-expansion-diagnostic-4','nucleic-copy-diagnostic']
new=['nucleic-inference-diagnostic','nucleic-scheduling-diagnostic']
for name in old+new:
    basis='6dadbea' if name in old else '37cac19'
    directory=root/'build'/name
    paths=subprocess.check_output(['git','ls-tree','-r','--name-only',basis,'src'],cwd=root,text=True).splitlines()
    links=[path for path in directory.rglob('*') if path.is_symlink()]
    for path in links:
        prefix=str(path.relative_to(directory))
        entries=[entry for entry in paths if entry==prefix or entry.startswith(prefix+'/')]
        if not entries:
            raise ValueError('untracked linked diagnostic source: '+prefix)
        path.unlink()
        for entry in entries:
            target=directory/entry
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(subprocess.check_output(['git','show',basis+':'+entry],cwd=root))
    hashes={str(path.relative_to(directory)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted((directory/'src').rglob('*')) if path.is_file()}
    record=dict(compiler_basis=basis,materialized_links=len(links),files=hashes,
                note='Original diagnostic modules retain their instrumented bytes; previously linked unchanged modules are materialized from the compiler basis used by the attempt.')
    (directory/'source-basis.json').write_text(json.dumps(record,indent=2)+'\n')
    print(name,basis,len(hashes))
