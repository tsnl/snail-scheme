"""Derive bounded quicksort diagnostics from archived observations; run no workload."""

from collections import Counter
from pathlib import Path
import json
import re
import sys

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/tmp/strict-quicksort-profile-20261013')


# ---- Whole-process CPU samples and GC trace fields ----


def read_json(path):
    return json.loads(path.read_text())


def cpu_samples(path):
    profile = read_json(path)
    names = {node['id']: node['callFrame']['functionName'] for node in profile['nodes']}
    counts = Counter(names[sample] for sample in profile['samples'])
    deltas = Counter()
    for sample, delta in zip(profile['samples'], profile['timeDeltas']):
        deltas[names[sample]] += delta
    return dict(sample_count=len(profile['samples']),
                profile_duration_us=profile['endTime'] - profile['startTime'],
                self_samples=[dict(name=name, count=count, percent=100 * count / len(profile['samples']),
                                   time_delta_sum_us=deltas[name]) for name, count in counts.most_common()])


def gc_events(path):
    return [dict(re.findall(r'([a-zA-Z_.]+)=([^ ]+)', line))
            for line in path.read_text().splitlines() if ' gc=' in line]


def gc_trace_summary(events):
    return dict(event_count=len(events), types=dict(Counter(event['gc'] for event in events)),
                allocated_field_sum_bytes=sum(int(event['allocated']) for event in events),
                displayed_pause_field_sum_ms=sum(float(event['pause']) for event in events),
                displayed_scavenge_field_sum_ms=sum(float(event.get('scavenge', 0)) for event in events),
                zero_displayed_pause_count=sum(float(event['pause']) == 0 for event in events),
                scope='Whole process, without workload anchors; allocated is a heap object-size delta, '
                      'not an exact per-site allocation counter. The final post-GC tail is absent.',
                pause_precision='pause is printed to 0.1 ms; its sum is not a precise pause total. '
                                'scavenge is a separate rounded 0.01 ms phase field.')


def process_profile(directory):
    output = (directory / 'stdout.txt').read_text().splitlines()
    result = [json.loads(line) for line in output if line.startswith('{')]
    assert len(result) == 1 and result[0]['result'] == '1'
    command = read_json(directory / 'command.json')
    assert command['returncode'] == 0 and command['NODE_OPTIONS'] is None
    return dict(command=command, cpu=cpu_samples(next(directory.glob('*.cpuprofile'))),
                gc=gc_trace_summary(gc_events(directory / 'stdout.txt')),
                result=result[0], diagnostic_seconds_only=True)


# ---- Generated machine allocation paths ----


def function_code_blocks(path):
    source = path.read_text()
    pattern = r'--- WebAssembly code ---\nname: function54\nindex: 27\nkind: wasm function\ncompiler: ([^\n]+)'
    return {match.group(1): source[match.start():source.index('--- End code ---', match.end())
                                                 + len('--- End code ---')] + '\n'
            for match in re.finditer(pattern, source)}


def machine_instructions(code):
    pattern = r'^0x[0-9a-f]+\s+([0-9a-f]+)\s+[0-9a-f]+\s+(.+)$'
    return [(int(match.group(1), 16), match.group(2), match.group(0))
            for match in re.finditer(pattern, code, re.M)]


def allocation_path(instructions, index):
    window = instructions[index:index + 15]
    size = next(int(match.group(1), 16) for _, instruction, _ in window
                if (match := re.search(r'leaq .*\+0x(18|20|30|38)\]', instruction)))
    branch = next((offset, instruction) for offset, instruction, _ in window if instruction.startswith('jna '))
    target = int(re.search(r'<\+0x([0-9a-f]+)>', branch[1]).group(1), 16)
    slow_index = next(i for i, (offset, _, _) in enumerate(instructions) if offset == target)
    slow = instructions[slow_index:slow_index + 18]
    assert any(f'movl rdx,0x{size:x}' in instruction for _, instruction, _ in slow)
    return dict(top_load_offset=f'0x{instructions[index][0]:x}', size_bytes=size,
                slow_path_offset=f'0x{target:x}', fast_path_excerpt=[line for _, _, line in window],
                slow_path_excerpt=[line for _, _, line in slow])


def machine_allocation_audit(directory):
    blocks = function_code_blocks(directory / 'function54.txt')
    instructions = machine_instructions(blocks['TurboFan'])
    paths = [allocation_path(instructions, index) for index, (_, instruction, _) in enumerate(instructions)
             if 'movq ' in instruction and '[rsi+0x47]' in instruction]
    source_ordinals = [0, 3, 2, 1, 4, 6, 5, 7, 9, 8]
    assert len(paths) == len(source_ordinals) == 10
    for path, ordinal in zip(paths, source_ordinals):
        path['source_site_ordinal'] = ordinal
    return dict(function='function54', wasm_index=27, compiler='TurboFan',
                retained_allocation_paths=paths, bytes_per_nontrivial_partition=sum(path['size_bytes'] for path in paths),
                scope='Static generated code from the original binary, not dynamic allocation executions or tier counts. '
                      'The global print flag emitted all functions; the index 27 blocks were extracted afterward.')


# ---- Entered construction instructions and preserved sort work ----


def count_observations(directory):
    observations = read_json(directory / 'full-counts.json')
    for row in observations:
        assert row['returncode'] == 0 and row['counts']['result'] == '1'
        assert row['counts']['barriers'] == 0 and row['counts']['setup_barriers'] == 3
    return {row['label']: {name: int(value) for name, value in row['counts']['timed_counts'].items()}
            for row in observations}


def construction_totals(counts):
    totals = Counter()
    for name, value in counts.items():
        if name.startswith('site:'):
            totals[name.split(':')[1]] += value
    return {name: total for name, total in totals.items() if total}


def construction_audit(root):
    original = count_observations(root / 'counts')
    ablation = count_observations(root / 'allocation-ablation-counts')
    sites = [site for site in read_json(root / 'counts/sites.json') if site['function'] == '$function54']
    for label in original:
        preserved = {name: value for name, value in original[label].items() if not name.startswith('site:function54:')}
        assert preserved == ablation[label]
    full = original['canonical-count']
    assert all(full[site['export']] == 16_705_000 for site in sites)
    return dict(site_counts=[dict(site, entered=full[site['export']]) for site in sites],
                original_totals=construction_totals(full),
                ablation_totals=construction_totals(ablation['canonical-count']),
                preserved_entries={name: value for name, value in full.items() if name.startswith('entry:') and value},
                per_sort_nontrivial_partitions=6682, canonical_count=2500,
                all_nonpartition_site_and_all_entry_counts_match=True,
                scope='Counters count entered Wasm construction instructions before operand evaluation; '
                      'successful canonical runs have no traps. These are separate instrumented binaries.')


def validate_recorded_checks(root):
    checks = []
    for variant in ['counts', 'allocation-ablation', 'allocation-ablation-counts']:
        for row in read_json(root / variant / 'validation.json'):
            assert row['returncode'] == int(row['expected_rejection'])
            checks.append(dict(variant=variant, label=row['label'], expected_rejection=row['expected_rejection']))
    for variant in ['counts', 'allocation-ablation-counts']:
        for row in read_json(root / variant / 'full-counts.json'):
            assert row['returncode'] == 0 and row['counts']['result'] == '1'
            checks.append(dict(variant=variant, label='canonical data, count ' + row['label']))
    for row in read_json(root / 'canonical-values-validation.json'):
        assert row['returncode'] == 0 and json.loads(row['stdout'])['result'] == '1'
        checks.append(dict(variant=row['variant'], label='all 10000 canonical values'))
    return checks


# ---- Derived evidence, with observation scopes retained ----

profiles = {name: process_profile(ROOT / name) for name in
            ['cpu-gc', 'cpu-gc-sequential', 'allocation-ablation/cpu-gc']}
machine = machine_allocation_audit(ROOT / 'machine')
constructions = construction_audit(ROOT)
checks = validate_recorded_checks(ROOT)
evidence = dict(profiles=profiles, machine=machine, constructions=constructions,
                validation=dict(expected_outcomes=len(checks), checks=checks),
                construction_size_model_bytes=machine['bytes_per_nontrivial_partition'] * 16_705_000,
                model_limit='Static TurboFan sizes multiplied by separately instrumented path counts; '
                            'not an exact observed total of physical allocations in the original execution.')
(ROOT / 'analysis.json').write_text(json.dumps(evidence, indent=2) + '\n')
for compiler, block in function_code_blocks(ROOT / 'machine/function54.txt').items():
    (ROOT / f'machine/function54-{compiler}.txt').write_text(block)
print(json.dumps(dict(validation_outcomes=len(checks), partition_construction_requests=167_050_000,
                      static_bytes_per_partition=machine['bytes_per_nontrivial_partition'],
                      original_trace_bytes=profiles['cpu-gc-sequential']['gc']['allocated_field_sum_bytes'],
                      ablation_trace_bytes=profiles['allocation-ablation/cpu-gc']['gc']['allocated_field_sum_bytes'])))
