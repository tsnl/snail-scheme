"""Executed final provenance checks; no canonical workload or performance run."""

from pathlib import Path
import hashlib
import json
import subprocess
import os
import re
import shutil
import datetime

root = Path('/tmp/strict-quicksort-profile-20261013')
repository = Path('/tmp/snail-strict-quicksort-profile-20261013')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def spans(source):
    out = {}
    for match in re.finditer(r'^ \(func (\$[^\s()]+)', source, re.M):
        depth = 0
        for index in range(match.start() + 1, len(source)):
            depth += (source[index] == '(') - (source[index] == ')')
            if depth == 0:
                out[match.group(1)] = (match.start(), index + 1)
                break
    return out


def outside(source, locations):
    for name, (start, end) in reversed(list(locations.items())):
        source = source[:start] + f' (func {name} [BODY])' + source[end:]
    return source


# ---- Original identities and compiler preservation ----

prepared = json.loads((root / 'original/prepared.json').read_text())
tools = {name: dict(tool, verified_sha256=sha(Path(tool['path']))) for name, tool in prepared['tools'].items()}
assert all(tool['sha256'] == tool['verified_sha256'] for tool in tools.values())
compiler = {name: sha(repository / name) for name in prepared['compiler_files']}
assert compiler == prepared['compiler_files']
expected = {
    'quicksort/strict.scm': '0882c2650b8da9471c86d1fe35007c7352a1f62d914988f204cc36901b5b5da1',
    'quicksort/strict.wasm': 'e947322337325a79d278ffb0d7f3cb95340d54ab50e8b98a95a49868d8ece282',
    'quicksort/strict.wasm.raw.wasm': 'a5f10fc95f3995437d3ddb000533632cd7f7d65ad6a3eb1be435c82a7e3938d5',
    'quicksort/strict.optimized.wat': 'b4bd71979597302ba9e03c2ca29ab244d943f2bd5be54146af57ada6c2baf6ad',
    'host.mjs': 'ea2fd98ef42744fa3ff9a0d186e8683ae7368da10591f1f102c1e2f561b9a8c2',
    'measure.py': '6c8c7273119e90203ec6b4c61acb7ffdf3afcb1c6480cfded62eb199d662ad30',
    'r7rs.py': '7d8aea265a966a650f0d0a6c5d023d36598c1a8f35b1992d9248f2998f317b09',
}
actual = {name: sha(root / 'original' / name) for name in expected}
assert actual == expected
frozen = Path('/tmp/strict-quicksort-frozen-final-5894df7')
copied = {str(p.relative_to(frozen)): sha(p) for p in frozen.rglob('*') if p.is_file()}
assert all(sha(root / 'original' / name) == value for name, value in copied.items())
extras = sorted(str(p.relative_to(root / 'original')) for p in (root / 'original').rglob('*')
                if p.is_file() and str(p.relative_to(root / 'original')) not in copied)
assert extras == []


# ---- Original WAT reassembly and the exact intervention ----

env = dict(os.environ)
env.pop('NODE_OPTIONS', None)
env['BINARYEN_CORES'] = '1'
check_dir = root / 'verification'
flags = ['-g', '--mvp-features', '--enable-gc', '--enable-reference-types', '--enable-tail-call',
         '--enable-mutable-globals', '--enable-sign-ext', '--enable-bulk-memory',
         '--enable-nontrapping-float-to-int']
command = [tools['WASM_AS']['path'], str(root / 'original/quicksort/strict.optimized.wat'),
           '-o', str(check_dir / 'original-reassembled.wasm'), *flags]
result = subprocess.run(command, env=env, capture_output=True, text=True)
assert result.returncode == 0
assembly = dict(command=command, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr,
                BINARYEN_CORES=1, sha256=sha(check_dir / 'original-reassembled.wasm'),
                original_sha256=actual['quicksort/strict.wasm'])
assembly['byte_identical'] = assembly['sha256'] == assembly['original_sha256']
(check_dir / 'original-reassembly.json').write_text(json.dumps(assembly, indent=2) + '\n')
a = (root / 'original/quicksort/strict.optimized.wat').read_text()
b = (root / 'allocation-ablation/module.wat').read_text()
a_spans, b_spans = spans(a), spans(b)
assert a_spans.keys() == b_spans.keys()
changed = [name for name in a_spans if a[slice(*a_spans[name])] != b[slice(*b_spans[name])]]
assert changed == ['$function54', '$function56', '$function57', '$function58']
assert outside(a, a_spans) == outside(b, b_spans)
audit = dict(changed_functions=changed, unchanged_functions=len(a_spans) - len(changed),
             unchanged_function_sha256={name: hashlib.sha256(a[slice(*bounds)].encode()).hexdigest()
                                       for name, bounds in a_spans.items() if name not in changed},
             outside_function_bodies_identical=True, original_reassembly=assembly)
(root / 'preservation-audit.json').write_text(json.dumps(audit, indent=2) + '\n')


# ---- Deterministic fixture generation and derived evidence ----

replay = Path('/tmp/strict-quicksort-profile-generator-replay-20261013')
replay.mkdir()
(replay / 'original/quicksort').mkdir(parents=True)
shutil.copy2(root / 'original/quicksort/strict.optimized.wat', replay / 'original/quicksort/strict.optimized.wat')
shutil.copy2(root / 'original/host.mjs', replay / 'original/host.mjs')
generator = (root / 'generate-fixtures.py').read_text()
needle = "ROOT = Path('/tmp/strict-quicksort-profile-20261013')"
assert generator.count(needle) == 1
exec(compile(generator.replace(needle, f'ROOT = Path({str(replay)!r})'),
             str(root / 'generate-fixtures.py'), 'exec'), {'__name__': '__main__'})
reproduced = [str(p.relative_to(replay)) for p in replay.rglob('*')
              if p.is_file() and p.relative_to(replay).parts[0] != 'original']
assert all(sha(replay / name) == sha(root / name) for name in reproduced)
(check_dir / 'generator-replay.json').write_text(json.dumps(dict(
    executed_generator_sha256=sha(root / 'generate-fixtures.py'), root_path_only_rebound=str(replay),
    files_verified={name: sha(root / name) for name in sorted(reproduced)}), indent=2) + '\n')
command = [tools['PYTHON']['path'], str(root / 'analyze-evidence.py'), str(root)]
result = subprocess.run(command, env=env, capture_output=True, text=True)
assert result.returncode == 0
(check_dir / 'analysis-command.json').write_text(json.dumps(dict(
    command=command, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr), indent=2) + '\n')
provenance = dict(
    freeze_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    investigation_base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository, text=True).strip(),
    preparation_compiler=prepared['compiler_commit'], driver_commit='86d49d4d7f36b00f48724f3fe63854a2afe2413d',
    upstream_commit=prepared['upstream_commit'], original_source_files=actual,
    original_payload_files_verified=len(copied), compiler_files_verified=len(compiler), tools=tools,
    default_v8=True, NODE_OPTIONS=None, cpu=5,
    profile_scope='Whole process without timer anchors; other workers could execute correctness work.',
    comparative_timing_claim=False)
(root / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
print(json.dumps(dict(original_payload_files=len(copied), compiler_files=len(compiler),
                      generator_files=len(reproduced), reassembled_byte_identical=assembly['byte_identical'],
                      reassembly_sha256=assembly['sha256'], changed_functions=changed,
                      analysis=result.stdout.strip())))
