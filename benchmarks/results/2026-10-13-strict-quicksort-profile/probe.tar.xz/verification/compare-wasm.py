"""Compare original/reassembled sections and function bytes, without execution."""

from pathlib import Path
import hashlib
import json
import re

ROOT = Path('/tmp/strict-quicksort-profile-20261013')


# ---- Wasm binary framing ----


def unsigned(data, index):
    value = shift = 0
    while True:
        byte = data[index]
        index += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, index
        shift += 7


def string(data, index):
    length, index = unsigned(data, index)
    return data[index:index + length].decode(), index + length


def sections(data):
    assert data[:8] == b'\x00asm\x01\x00\x00\x00'
    index, output = 8, {}
    while index < len(data):
        kind = data[index]
        length, start = unsigned(data, index + 1)
        payload = data[start:start + length]
        name = string(payload, 0)[0] if kind == 0 else str(kind)
        assert (kind, name) not in output
        output[(kind, name)] = payload
        index = start + length
    return output


def function_bodies(payload):
    count, index = unsigned(payload, 0)
    bodies = []
    for _ in range(count):
        length, index = unsigned(payload, index)
        bodies.append(payload[index:index + length])
        index += length
    assert index == len(payload)
    return bodies


def body_layout(body):
    count, index = unsigned(body, 0)
    types = []
    for _ in range(count):
        number, index = unsigned(body, index)
        end = unsigned(body, index + 1)[1] if body[index] in [0x63, 0x64] else index + 1
        types.extend([body[index:end].hex()] * number)
        index = end
    return dict(local_types=types, local_encoding=body[:index].hex(), instructions=body[index:])


def features(payload):
    if payload is None:
        return None
    _, index = string(payload, 0)
    count, index = unsigned(payload, index)
    result = []
    for _ in range(count):
        prefix = chr(payload[index])
        name, index = string(payload, index + 1)
        result.append(prefix + name)
    return result


def identity(data):
    return dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())


# ---- Section differences and named function bodies ----

original = sections((ROOT / 'original/quicksort/strict.wasm').read_bytes())
control = sections((ROOT / 'verification/original-reassembled.wasm').read_bytes())
assert original.keys() == control.keys()
differences = [dict(kind=kind, name=name, original=identity(original[(kind, name)]),
                    reassembled=identity(control[(kind, name)]))
               for kind, name in original if original[(kind, name)] != control[(kind, name)]]
source = (ROOT / 'original/quicksort/strict.optimized.wat').read_text()
imports = len(re.findall(r'^ \(import .*\(func ', source, re.M))
names = re.findall(r'^ \(func (\$[^\s()]+)', source, re.M)
original_bodies = function_bodies(original[(10, '10')])
control_bodies = function_bodies(control[(10, '10')])
assert len(original_bodies) == len(control_bodies) == len(names)
body_changes = [dict(function=name, wasm_index=imports + index,
                     original=identity(a), reassembled=identity(b))
                for index, (name, a, b) in enumerate(zip(names, original_bodies, control_bodies)) if a != b]
identical = {name: dict(wasm_index=imports + index, **identity(a))
             for index, (name, a, b) in enumerate(zip(names, original_bodies, control_bodies)) if a == b}
assert identical['$function54']['wasm_index'] == 27
layouts = [(name, body_layout(a), body_layout(b)) for name, a, b in zip(names, original_bodies, control_bodies)]
layout_changes = [dict(function=name, local_types_equal=a['local_types'] == b['local_types'],
                       instructions_equal=a['instructions'] == b['instructions'],
                       original_local_encoding=a['local_encoding'], reassembled_local_encoding=b['local_encoding'],
                       original_instructions=identity(a['instructions']), reassembled_instructions=identity(b['instructions']))
                  for name, a, b in layouts if a != b]
report = dict(section_differences=differences, function_body_differences=body_changes,
              local_and_instruction_differences=layout_changes,
              byte_identical_function_bodies=identical,
              target_features_original=features(original.get((0, 'target_features'))),
              target_features_reassembled=features(control.get((0, 'target_features'))),
              interpretation='Reassembly is not a metadata-only binary difference. See each function body, '
                             'expanded local type sequence and instruction comparison below. The WAT '
                             'difference is separately archived. Retain this unmodified control for '
                             'any future separately coordinated clean comparison.')
(ROOT / 'verification/original-reassembly-sections.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(section_differences=[item['name'] for item in differences],
                      function_body_differences=[item['function'] for item in body_changes],
                      instruction_differences=[item['function'] for item in layout_changes if not item['instructions_equal']],
                      local_type_differences=[item['function'] for item in layout_changes if not item['local_types_equal']],
                      byte_identical_function_count=len(identical),
                      features_original=report['target_features_original'],
                      features_reassembled=report['target_features_reassembled'])))
