"""Build diagnostic WAT fixtures without changing the compiler or measured payload."""

from pathlib import Path
import difflib
import json
import re

ROOT = Path('/tmp/strict-quicksort-profile-20261013')
SOURCE = (ROOT / 'original/quicksort/strict.optimized.wat').read_text()


# ---- Construction sites and instruction-entry counters ----


def expression_end(source, start):
    depth = 0
    for index in range(start, len(source)):
        depth += (source[index] == '(') - (source[index] == ')')
        if depth == 0:
            return index + 1
    raise ValueError('unclosed generated WAT expression')


def function_spans(source):
    return [(match.group(1), match.start(), expression_end(source, match.start() + 1))
            for match in re.finditer(r'^ \(func (\$[^\s()]+)', source, re.M)]


def body_start(source, start):
    index = source.index('\n', start)
    while True:
        index += len(source[index:]) - len(source[index:].lstrip())
        if not source.startswith('(local ', index):
            return index
        index = expression_end(source, index)


def counter_update(name):
    return f'(global.set {name} (i64.add (global.get {name}) (i64.const 1)))'


def instrument(source):
    # Counters precede constructor operand evaluation and count entered source
    # operations, not physical allocations. Canonical checks must complete with
    # no traps. Numeric globals add no extra GC roots or JS callbacks.
    events, declarations, sites = {}, [], []
    imports = len(re.findall(r'^ \(import .*\(func ', source, re.M))
    for position, (function, start, stop) in enumerate(function_spans(source)):
        entry = f'$probe_entry_{position}'
        declarations.append(f'(global {entry} (export "entry:{function[1:]}") (mut i64) (i64.const 0))')
        events.setdefault(body_start(source, start), []).append(counter_update(entry) + '\n')
        pattern = r'\((struct\.new(?:_default)?|array\.new(?:_fixed|_default)?) (\$[^\s()]+)'
        for ordinal, match in enumerate(re.finditer(pattern, source[start:stop])):
            begin, end = start + match.start(), expression_end(source, start + match.start())
            name = f'$probe_site_{len(sites)}'
            exported = f'site:{function[1:]}:{ordinal}'
            declarations.append(f'(global {name} (export "{exported}") (mut i64) (i64.const 0))')
            events.setdefault(begin, []).append(f'(block (result (ref {match.group(2)})) {counter_update(name)} ')
            events.setdefault(end, []).insert(0, ')')
            sites.append(dict(export=exported, function=function, wasm_index=imports + position,
                              ordinal=ordinal, operation=match.group(1), type=match.group(2),
                              original_line=source[:begin].count('\n') + 1))
    events.setdefault(function_spans(source)[0][1], []).insert(0, '\n'.join(declarations) + '\n')
    result, previous = [], 0
    for position in sorted(events):
        result += [source[previous:position], ''.join(events[position])]
        previous = position
    return ''.join(result) + source[previous:], sites


def write_variant(directory, text):
    directory.mkdir()
    (directory / 'module.wat').write_text(text)
    patch = difflib.unified_diff(SOURCE.splitlines(True), text.splitlines(True),
                                 fromfile='frozen-optimized.wat', tofile=directory.name + '.wat')
    (directory / 'patch.diff').write_text(''.join(patch))


# ---- Direct-parameter allocation ablation ----

# The original private scan/partition closures never escape their partition
# invocation. This fixture passes the captured data as scalar/reference
# parameters. It changes readiness/field loads and calling convention too;
# diagnostic time differences cannot isolate allocation costs.
DIRECT_SCANS = ''' (func $function56 (param $v (ref $type12)) (param $right i64) (param $pivot i64) (param $i i64) (result i64)
  (local.set $i (i64.add (local.get $i) (i64.const 1)))
  (if (result i64)
   (if (result i32) (i64.lt_s (local.get $i) (local.get $right))
    (then
     (if (i64.gt_u (local.get $i) (i64.const 4294967295)) (then (unreachable)))
     (i64.lt_s (array.get $type12 (local.get $v) (i32.wrap_i64 (local.get $i))) (local.get $pivot)))
    (else (i32.const 0)))
   (then (return_call $function56 (local.get $v) (local.get $right) (local.get $pivot) (local.get $i)))
   (else (local.get $i))))
 (func $function57 (param $v (ref $type12)) (param $left i64) (param $pivot i64) (param $j i64) (result i64)
  (local.set $j (i64.sub (local.get $j) (i64.const 1)))
  (if (result i64)
   (if (result i32) (i64.gt_s (local.get $j) (local.get $left))
    (then
     (if (i64.gt_u (local.get $j) (i64.const 4294967295)) (then (unreachable)))
     (i64.lt_s (local.get $pivot) (array.get $type12 (local.get $v) (i32.wrap_i64 (local.get $j)))))
    (else (i32.const 0)))
   (then (return_call $function57 (local.get $v) (local.get $left) (local.get $pivot) (local.get $j)))
   (else (local.get $j))))
 (func $function58 (param $v (ref $type12)) (param $left i64) (param $right i64) (param $pivot i64) (param $i i64) (param $j i64) (result i64)
  (local $tmp i64)
  (local.set $i (call $function56 (local.get $v) (local.get $right) (local.get $pivot) (local.get $i)))
  (local.set $j (call $function57 (local.get $v) (local.get $left) (local.get $pivot) (local.get $j)))
  (if (i64.gt_u (local.get $i) (i64.const 4294967295)) (then (unreachable)))
  (if (i64.gt_u (local.get $j) (i64.const 4294967295)) (then (unreachable)))
  (local.set $tmp (array.get $type12 (local.get $v) (i32.wrap_i64 (local.get $i))))
  (array.set $type12 (local.get $v) (i32.wrap_i64 (local.get $i)) (array.get $type12 (local.get $v) (i32.wrap_i64 (local.get $j))))
  (array.set $type12 (local.get $v) (i32.wrap_i64 (local.get $j)) (local.get $tmp))
  (if (result i64) (i64.lt_s (local.get $i) (local.get $j))
   (then (return_call $function58 (local.get $v) (local.get $left) (local.get $right) (local.get $pivot) (local.get $i) (local.get $j)))
   (else
    (array.set $type12 (local.get $v) (i32.wrap_i64 (local.get $j)) (array.get $type12 (local.get $v) (i32.wrap_i64 (local.get $i))))
    (array.set $type12 (local.get $v) (i32.wrap_i64 (local.get $i)) (array.get $type12 (local.get $v) (i32.wrap_i64 (local.get $right))))
    (array.set $type12 (local.get $v) (i32.wrap_i64 (local.get $right)) (local.get $tmp))
    (local.get $i))))
'''


def allocation_ablation(source):
    spans = {name: (start, stop) for name, start, stop in function_spans(source)}
    start, stop = spans['$function54']
    helper = source[start:stop]
    helper = helper.replace('  (local $9 (ref $type37))', '  (local $pivot i64)')
    scaffold_start = helper.index('    (struct.set $type52 1')
    scaffold_stop = helper.index('    (if\n     (i64.lt_s\n      (i64.sub', scaffold_start)
    direct_data = '''    (local.set $7 (struct.get $environment54 0 (local.get $0)))
    (local.set $pivot (array.get $type12 (local.get $7) (i32.wrap_i64 (local.get $2))))
'''
    helper = helper[:scaffold_start] + direct_data + helper[scaffold_stop:]
    call_start = helper.index('(call $function58')
    call_stop = expression_end(helper, call_start)
    direct_call = '''(call $function58 (local.get $7) (local.get $1) (local.get $2) (local.get $pivot)
         (i64.sub (local.get $1) (i64.const 1)) (local.get $2))'''
    helper = helper[:call_start] + direct_call + helper[call_stop:]
    changes = [(start, stop, helper), (spans['$function56'][0], spans['$function58'][1], DIRECT_SCANS.rstrip())]
    for begin, end, text in sorted(changes, reverse=True):
        source = source[:begin] + text + source[end:]
    return source


# ---- Exact patches and host-side counter snapshots ----

counts, sites = instrument(SOURCE)
write_variant(ROOT / 'counts', counts)
(ROOT / 'counts/sites.json').write_text(json.dumps(sites, indent=2) + '\n')
ablated = allocation_ablation(SOURCE)
write_variant(ROOT / 'allocation-ablation', ablated)
ablated_counts, ablated_sites = instrument(ablated)
write_variant(ROOT / 'allocation-ablation-counts', ablated_counts)
(ROOT / 'allocation-ablation-counts/sites.json').write_text(json.dumps(ablated_sites, indent=2) + '\n')
host = (ROOT / 'original/host.mjs').read_text()
marker = 'instance.exports.main();'
assert host.count(marker) == 1
snapshot = '''const constructionGlobals = Object.entries(instance.exports).filter(([name]) => name.startsWith('site:') || name.startsWith('entry:'));
const snapshotCounts = () => Object.fromEntries(constructionGlobals.map(([name, global]) => [name, global.value.toString()]));
const setupCounts = snapshotCounts();
for (const [, global] of constructionGlobals) global.value = 0n;'''
host = host.replace(marker, marker + '\n' + snapshot)
marker = "  setup_barriers: mode === '--validate' ? setupBarriers : null}));"
assert host.count(marker) == 1
host = host.replace(marker, "  setup_barriers: mode === '--validate' ? setupBarriers : null, setup_counts: setupCounts, timed_counts: snapshotCounts()}));")
(ROOT / 'counter-host.mjs').write_text(host)
patch = difflib.unified_diff((ROOT / 'original/host.mjs').read_text().splitlines(True), host.splitlines(True),
                             fromfile='frozen-host.mjs', tofile='counter-host.mjs')
(ROOT / 'counter-host.patch').write_text(''.join(patch))
print('Generated counter and allocation-ablation diagnostic fixtures; original compiler, source and binary unchanged.')
