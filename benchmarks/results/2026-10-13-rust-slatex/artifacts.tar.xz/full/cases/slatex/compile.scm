(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-full-reference-20261013/build/rust-slatex-current-full/cases/slatex/program.scm" "/tmp/snail-rust-full-reference-20261013/build/rust-slatex-current-full/cases/slatex/program.so"))
