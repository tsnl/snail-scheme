"""Audit completed Maze evidence and retain the exact preparation sources."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/tmp/snail-strict-maze-20261014')
OUT = Path('/tmp/snail-maze-preparation-20261014')
CASE = OUT / 'maze'
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import measure
import maze_port

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def retained(path):
    return path.is_file() and not ({'target', '__pycache__'} & set(path.relative_to(OUT).parts))

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

runner = measure.upstream_runner()
files = runner.suite_sources()
reconstructed = OUT / 'source-reconstruction'
reconstructed.mkdir()
maze_port.write_sources(files, reconstructed, runner, measure)
source_names = ['upstream.scm', 'upstream-kernel.scm', 'adapted-kernel.scm',
                'strict.scm', 'chez/program.scm', 'chez-adapted/program.scm']
for name in source_names:
    assert (reconstructed / name).read_bytes() == (CASE / name).read_bytes(), name
assert (CASE / 'input.txt').read_bytes() == files['inputs/maze.input']
assert (CASE / 'observations/strict.scm').read_text() == maze_port.strict_probe(files['src/maze.scm'].decode(), measure)

failed = CASE / 'commands/strict-compile-attempt-1'
text = (CASE / 'strict.scm').read_text()
before, after = '(= (datum-kind value) 1)', '(datum-boolean? value)'
assert text.count(before) == 1
(failed / 'strict.scm').write_text(text.replace(before, after))
save(failed / 'source-reconstruction.json', dict(note='Reconstructed from the final source by reversing the sole reader API correction.',
    before=before, after=after, sha256=digest(failed / 'strict.scm')))

rust = CASE / 'controls/rust'
for label, profile in [('native', 'release'), ('wasm', 'wasm32-wasip1/release')]:
    modules = list((rust / 'target' / profile / 'deps').glob('maze-*.ll'))
    assert len(modules) == 1
    shutil.copy2(modules[0], rust / ('maze-' + label + '.ll'))

for folder in ('src', 'scripts'):
    shutil.copytree(ROOT / folder, OUT / 'compiler-source' / folder,
                    ignore=shutil.ignore_patterns('__pycache__'))
for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'tests/build-strict-program.scm',
             'benchmarks/r7rs.py', 'benchmarks/r7rs-chez.scm'):
    target = OUT / 'compiler-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / name, target)
for folder in ('strict-reader', 'strict-maze'):
    shutil.copytree(ROOT / 'tests' / folder, OUT / 'compiler-source/tests' / folder)
supervisor = OUT / 'supervisor'
supervisor.mkdir()
for path in (ROOT / 'benchmarks/strict-suite').iterdir():
    if path.is_file():
        shutil.copy2(path, supervisor / path.name)

records = []
development_failures = [
    'maze/commands/strict-compile-attempt-1/record.json',
    'maze/dimension-oracles-attempt-1/commands/1x1/record.json',
    'maze/observations-attempt-1/commands/strict-build/record.json',
    'maze/observations/commands/chez-compile-attempt-1/record.json',
]
for path in CASE.rglob('record.json'):
    if 'commands' not in path.parts:
        continue
    value = json.loads(path.read_text())
    assert 'returncode' in value and not value.get('timeout') and not value.get('executing_descendants'), path
    name = str(path.relative_to(OUT))
    if value['returncode'] != 0 and name not in development_failures:
        assert '/controls/rust/commands/' in name and any(word in name for word in
            ('wrong-character', 'wrong-order', 'missing-character', 'extra-character')), name
        assert 'assertion' in value['stderr']
    records.append(dict(path=name, returncode=value['returncode']))

for label in ('once', 'full-count'):
    target = CASE / 'observations' / label
    traces = [(target / (name + '.trace')).read_text() for name in ('chez', 'chez-adapted', 'raw', 'optimized', 'native')]
    assert len(set(traces)) == 1
    maze_port.validate_trace(target, traces[0], 1 if label == 'once' else 10000, measure)

final = json.loads((CASE / 'controls/native/final-module.json').read_text())
assert digest(Path(final['path'])) == final['sha256'] == digest(CASE / 'controls/native/native-final.wasm')
assert 'count++;' not in (CASE / 'controls/native/native-provider.c').read_text()
checks = json.loads((CASE / 'validation.json').read_text())
assert len(checks) == 17 and all(len(case['systems']) == 5 for case in checks)

tools = measure.tool_paths(('maze',))
tool_ids = {key: dict(path=value, sha256=digest(Path(value))) for key, value in tools.items()}
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
controls = CASE / 'controls/prepared.json'
save(controls, dict(status='ready', timing='No clean timing has been performed.',
    hashes={str(path.relative_to(controls.parent)): digest(path)
            for path in controls.parent.rglob('*') if retained(path) and path != controls}))
save(OUT / 'author-audit.json', dict(adapter_commit=commit, source_reconstruction_equal=source_names,
    schema_edits=68, five_system_fixtures=17, five_system_observations=2, rust_executions=21,
    exact_native_final_wasm_verified=True, clean_native_opacity_counters=False,
    development_failure_records=development_failures, records=records,
    note='The initial exact-edit generation guard also caught a parent pattern duplicated in an upstream comment; no executable was generated. The match was scoped to the DFS initializer.'))
save(OUT / 'prepared.json', dict(status='correctness-prepared', timing='Not measured',
    compiler_basis='27604d44652f74169104d25c3a3edc8a0bb653ca', adapter_commit=commit,
    upstream_commit=runner.REVISION, tools=tool_ids,
    artifacts={str(path.relative_to(OUT)): digest(path) for path in OUT.rglob('*')
               if retained(path) and path.name != 'prepared.json'},
    source_adaptation='68 counted reversible ledger entries; complete shared adapted kernel and original Chez controls',
    excluded_caches=['maze/controls/rust/target'],
    relocations=['dimension-oracles -> dimension-oracles-attempt-1',
                 'observations -> observations-attempt-1',
                 'observations/commands/chez-compile -> observations/commands/chez-compile-attempt-1',
                 'controls/native -> controls/native-counting-diagnostic']))
print(json.dumps(dict(status='audited', adapter_commit=commit, command_records=len(records),
                      fixtures=len(checks), artifact_files=len(json.loads((OUT/'prepared.json').read_text())['artifacts']))))
