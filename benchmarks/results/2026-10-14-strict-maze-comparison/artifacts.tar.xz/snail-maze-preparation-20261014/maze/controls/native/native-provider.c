#include "native-provider.h"
static uint64_t count;
int32_t barrier(void) { return 1; }
uint64_t reader_barriers(void) { return count; }
