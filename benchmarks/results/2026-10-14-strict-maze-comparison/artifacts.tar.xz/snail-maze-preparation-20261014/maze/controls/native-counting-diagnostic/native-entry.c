#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "native-provider.h"
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern uint64_t native_resource_release_count(void);
extern void guest_main(void) __asm__("wasm.main");
extern int64_t configured_count(void) __asm__("wasm.configured-count");
extern int64_t bench(int64_t) __asm__("wasm.bench");
int main(int argc, char **argv) {
    native_host_init(argc, argv);
    native_module_init();
    guest_main();
    uint64_t setup = native_resource_release_count();
    int64_t count = configured_count();
    struct timespec start, finish;
    if (clock_gettime(CLOCK_MONOTONIC, &start)) return native_finish(3);
    int64_t result = bench(count);
    if (clock_gettime(CLOCK_MONOTONIC, &finish)) return native_finish(4);
    double seconds = finish.tv_sec - start.tv_sec + (finish.tv_nsec - start.tv_nsec) * 1e-9;
    uint64_t worker = native_resource_release_count() - setup;
    int status = native_finish(0);
    printf("{\"seconds\":%.9f,\"result\":%" PRId64 ",\"barriers\":%" PRIu64 ",\"setup_closed\":%" PRIu64
           ",\"worker_closed\":%" PRIu64 ",\"closed\":%" PRIu64 "}\n",
           seconds, result, reader_barriers(), setup, worker, native_resource_release_count());
    return status;
}
