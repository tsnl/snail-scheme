(import (chezscheme))
(define (exact-integer? z) (and (exact? z) (integer? z)))
(define-syntax : (syntax-rules () ((_ . signature) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define-syntax define-data
  (lambda (form)
    (syntax-case form ()
      ((_ name variant ...)
       (datum->syntax #'name
         (cons 'begin
           (apply append
             (map (lambda (variant)
                    (let ((tag (car variant)) (fields (cdr variant)))
                      (cons `(define (,tag ,@(map car fields)) (vector ',tag ,@(map car fields)))
                        (let loop ((fields fields) (index 1))
                          (if (null? fields) '()
                              (append
                                (if (= (length (car fields)) 3)
                                    `((define (,(caddar fields) value)
                                        (unless (eq? (vector-ref value 0) ',tag)
                                          (error ',tag "wrong typed variant" value))
                                        (vector-ref value ,index))) '())
                                (loop (cdr fields) (+ index 1))))))))
                  (syntax->datum #'(variant ...))))))))))
(define-syntax match
  (lambda (form)
    (syntax-case form ()
      ((context value arm ...)
       (let ((temporary (syntax->datum (car (generate-temporaries #'(value))))))
         (datum->syntax #'context
           `(let ((,temporary ,(syntax->datum #'value)))
              (cond
                ,@(map (lambda (arm)
                         (let ((pattern (car arm)))
                           `((eq? (vector-ref ,temporary 0) ',(car pattern))
                             (let ,(let loop ((names (cdr pattern)) (index 1))
                                     (if (null? names) '()
                                         (cons `(,(car names) (vector-ref ,temporary ,index))
                                           (loop (cdr names) (+ index 1)))))
                               ,@(cdr arm)))))
                       (syntax->datum #'(arm ...)))
                (else (error 'match "invalid typed variant" ,temporary))))))))))
(define (unit) (if #f #f))
(define (unreachable) (error 'reader "unreachable typed branch"))
(define (ref value) (vector value))
(define (ref-get value) (vector-ref value 0))
(define (ref-set! cell value) (vector-set! cell 0 value))
(define ref-eq? eq?)
(define vector-eq? eq?)
(define string-eq? eq?)
(define bytevector-eq? eq?)
(define i32-eq eqv?)
(define i32->i64 values)
(define i64->i32 values)
(define i64->f64 inexact)
(define (string-copy! target at source start end)
  (do ((index start (+ index 1))) ((= index end))
    (string-set! target (+ at (- index start)) (string-ref source index))))
(define-data Optional (absent) (present (value T optional-value)))
(define-data Reachable
  (reachable-record (size (Ref I64) reachable-size)
                    (next (Ref (Optional Reachable)) reachable-next)))
(define-data Coordinate (coordinate (x I64 coordinate-x) (y I64 coordinate-y)))
(define-data Cell
  (uninitialized-cell)
  (cell-record (reachable (Ref Reachable) cell-reachable-field)
               (id (Ref Coordinate) cell-id-field)
               (walls (Ref I64) cell-walls-field)
               (parent (Ref (Optional Cell)) cell-parent-field)
               (mark (Ref Bool) cell-mark-field)))
(define-data Wall
  (wall-record (owner (Ref Cell) wall-owner-field)
               (neighbor (Ref Cell) wall-neighbor-field)
               (bit (Ref I64) wall-bit-field)))
(define-data HexArray
  (harr-record (rows (Ref I64) harr-rows-field)
               (columns (Ref I64) harr-columns-field)
               (elements (Ref (Vector Cell)) harr-elements-field)))
(define-data Entrances
  (entrances (top (Optional I64) entrance-top) (bottom (Optional I64) entrance-bottom)))
(define-data LongestPath
  (longest-path (length I64 longest-length)
                (top (Optional I64) longest-top) (bottom (Optional I64) longest-bottom)))
(define-data Maze
  (maze-result (cells HexArray maze-cells) (entrance I64 maze-entrance) (exit I64 maze-exit)))
(define-data Output
  (initial-output) (character-output (characters (List Char) output-characters)) (other-output))
(: present? (All (T) (-> (Optional T) Bool)))
(define (present? value) (match value ((absent) #f) ((present item) #t)))
(define (same-set? left right) (ref-eq? (reachable-size left) (reachable-size right)))
(define (same-set-next? left next)
  (and (present? next) (same-set? left (optional-value next))))
;; A fresh field Ref supplies stable identity even if that field is mutated.
(define (same-cell? left right) (ref-eq? (cell-walls-field left) (cell-walls-field right)))
(define (same-cell-parent? cell parent)
  (and (present? parent) (same-cell? cell (optional-value parent))))
(define (maze-zero? value) (= value 0))
(define (maze-odd? value) (not (= (remainder value 2) 0)))
(: maze-exact-integer? (-> I64 Bool))
(define (maze-exact-integer? value) #t)
(: maze-reverse (All (T) (-> (List T) (List T))))
(define (maze-reverse values)
  (let loop ((values values) (result '()))
    (if (null? values) result (loop (cdr values) (cons (car values) result)))))
;; This is only the source's immediate lexical escape: stop before the next
;; vector lookup or index update. No continuation escapes or can be resumed.
(: vector-until-rev (All (T) (-> (-> T Bool) (Vector T) Unit)))
(define (vector-until-rev procedure values)
  (let loop ((index (- (vector-length values) 1)))
    (when (>= index 0)
      (unless (procedure (vector-ref values index)) (loop (- index 1))))))
(define (same-characters? actual expected)
  (if (null? actual) (null? expected)
      (and (not (null? expected)) (char=? (car actual) (car expected))
           (same-characters? (cdr actual) (cdr expected)))))
(define (same-output? actual expected)
  (match actual
    ((initial-output) (match expected ((initial-output) #t)
      ((character-output chars) #f) ((other-output) #f)))
    ((character-output chars) (match expected ((initial-output) #f)
      ((character-output wanted) (same-characters? chars wanted)) ((other-output) #f)))
    ((other-output) #f)))
(define (chez-output value)
  (cond ((eq? value #f) (initial-output))
        ((and (list? value) (for-all char? value)) (character-output value))
        (else (other-output))))
(define (original-output value)
  (match value ((initial-output) #f) ((character-output chars) chars) ((other-output) #t)))
(define (emit-i64 value) (display "i:") (display value) (newline))
(define (emit-char value) (display "c:") (display (char->integer value)) (newline))
;; These observations use the same original or adapted Maze operations.
;; Representation selectors read links directly; observing them never compresses
;; a union-find path or changes a maze parent.

;; ---- Work counters and complete ordered wall observations ----

(define probe-counts (make-vector 16 0))
(define probe-snapshots (ref #f))
(define (probe-tick index)
  (vector-set! probe-counts index (+ (vector-ref probe-counts index) 1)))
(define (probe-reset)
  (let loop ((index 0))
    (unless (= index 16) (vector-set! probe-counts index 0) (loop (+ index 1)))))
(define (probe-assert label passed)
  (emit-i64 label) (emit-i64 (if passed 1 0))
  (unless passed (unreachable)))
(define (probe-work)
  (emit-i64 200)
  (let loop ((index 0))
    (unless (= index 16) (emit-i64 (vector-ref probe-counts index)) (loop (+ index 1)))))
(define (probe-wall wall)
  (emit-i64 (probe-x (wall:owner wall))) (emit-i64 (probe-y (wall:owner wall)))
  (emit-i64 (probe-x (wall:neighbor wall))) (emit-i64 (probe-y (wall:neighbor wall)))
  (emit-i64 (wall:bit wall)))
(define (probe-wall-vector stage walls)
  (when (ref-get probe-snapshots)
    (emit-i64 stage) (emit-i64 (vector-length walls))
    (let loop ((index 0))
      (unless (= index (vector-length walls))
        (probe-wall (vector-ref walls index)) (loop (+ index 1)))))
  walls)
(define (probe-visit wall)
  (probe-tick 9)
  (when (ref-get probe-snapshots) (emit-i64 102) (probe-wall wall)))
(define (probe-set-id set cells)
  (let loop ((index 0))
    (if (= index (vector-length cells)) -1
        (if (probe-set-same? set (cell:reachable (vector-ref cells index))) index
            (loop (+ index 1))))))
(define (probe-parent-id cell columns)
  (if (probe-parent-present? cell)
      (let ((parent (probe-parent-cell cell)))
        (+ (* columns (quotient (probe-y parent) 2)) (quotient (probe-x parent) 3))) -1))
(define (probe-cell-state cell cells columns)
  (emit-i64 (probe-x cell)) (emit-i64 (probe-y cell))
  (emit-i64 (cell:walls cell)) (emit-i64 (if (cell:mark cell) 1 0))
  (emit-i64 (probe-parent-id cell columns))
  (let ((set (cell:reachable cell)))
    (emit-i64 (probe-set-size-field set))
    (emit-i64 (if (probe-set-linked? set) (probe-set-id (probe-set-next set) cells) -1))))
(define (probe-grid stage grid)
  (when (ref-get probe-snapshots)
    (emit-i64 stage) (emit-i64 (harr:nrows grid)) (emit-i64 (harr:ncols grid))
    (let ((cells (harr:elts grid)))
      (let loop ((index 0))
        (unless (= index (vector-length cells))
          (probe-cell-state (vector-ref cells index) cells (harr:ncols grid))
          (loop (+ index 1)))))))
(define (probe-after-dig grid walls)
  (when (ref-get probe-snapshots)
    (emit-i64 103) (emit-i64 (vector-length walls))
    (emit-i64 (vector-ref probe-counts 9))
    (emit-i64 (- (vector-length walls) (vector-ref probe-counts 9))))
  (probe-grid 104 grid))
(define (probe-finished-maze grid entrance exit)
  (when (ref-get probe-snapshots) (emit-i64 105) (emit-i64 entrance) (emit-i64 exit))
  (probe-grid 106 grid))
(define (probe-characters chars)
  (emit-i64 107)
  (let loop ((chars chars))
    (unless (null? chars) (emit-char (car chars)) (loop (cdr chars)))))

;; ---- Signed integer helpers, deterministic RNG, and set identity ----

(define (probe-integers)
  (let outer ((x -9))
    (unless (> x 9)
      (let inner ((y -4))
        (unless (> y 4)
          (unless (= y 0) (emit-i64 (div x y)) (emit-i64 (mod x y)))
          (emit-i64 (bitwise-and x y)) (inner (+ y 1))))
      (outer (+ x 1))))
  (let ((state (random-state 20)))
    (let loop ((index 0))
      (unless (= index 10) (emit-i64 (rand state)) (loop (+ index 1))))))
(define (probe-union-find)
  (let* ((a (base-set 1)) (b (base-set 1)) (c (base-set 2)))
    (probe-assert 1 (not (probe-set-same? a b)))
    (union! a b)
    (probe-assert 2 (and (probe-set-same? (probe-set-next a) b) (= (set-size a) 2)))
    (union! b c)
    (probe-assert 3 (and (probe-set-same? (probe-set-next b) c)
                         (probe-set-same? (probe-set-next a) b)))
    (probe-assert 4 (probe-set-same? (get-set-root a) c))
    (probe-assert 5 (and (probe-set-same? (probe-set-next a) c)
                         (probe-set-same? (probe-set-next b) c) (= (set-size a) 4)))))
(define (probe-cell-aliases)
  (let* ((grid (gen-maze-array 2 2)) (cell (href/rc grid 0 0))
         (wall (make-wall cell (href/rc grid 0 1) 1)))
    (probe-assert 6 (probe-cell-same? cell (wall:owner wall)))
    (set-cell:walls (wall:owner wall) 23)
    (probe-assert 7 (= (cell:walls (href/rc grid 0 0)) 23))
    (set-wall:neighbor wall cell)
    (probe-assert 8 (probe-cell-same? cell (wall:neighbor wall)))))

;; ---- A separate complete snapshot precedes full-count counter execution ----

(define (probe-run count rows columns expected)
  (probe-integers) (probe-union-find) (probe-cell-aliases)
  (probe-reset) (ref-set! probe-snapshots #t)
  (let ((result (run rows columns))) (probe-characters result))
  (ref-set! probe-snapshots #f) (probe-work) (probe-reset)
  (let loop ((index 0) (result (initial-output)))
    (if (< index count)
        (loop (+ index 1) (character-output (run rows columns)))
        (begin (probe-work) (if (same-output? result expected) 1 0)))))
;;; MAZE -- Constructs a maze on a hexagonal grid, written by Olin Shivers.


;;; R6RS procedures needed by this benchmark.

(define (bitwise-not x)
  (- (- x) 1))

(define (bitwise-and x y)
  (probe-tick 4);; two arguments are enough for this benchmark
  (cond ((= x 0) 0)
        ((= y 0) 0)
        ((= x -1) y)
        ((= y -1) x)
        (else
         (let ((z (bitwise-and (div x 2) (div y 2))))
           (if (and (odd? x) (odd? y))
               (+ z z 1)
               (+ z z))))))

(define (div x y)
  (probe-tick 5)
  (cond ((and (exact-integer? x)
              (exact-integer? y)
              (>= x 0))
         (quotient x y))
        ((< y 0)
         ;; x < 0, y < 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               q
               (+ q 1))))
        (else
         ;; x < 0, y > 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               q
               (- q 1))))))

(define (mod x y)
  (probe-tick 6)
  (cond ((and (exact-integer? x)
              (exact-integer? y)
              (>= x 0))
         (remainder x y))
        ((< y 0)
         ;; x < 0, y < 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               0
               (- r y))))
        (else
         ;; x < 0, y > 0
         (let* ((q (quotient x y))
                (r (- x (* q y))))
           (if (= r 0)
               0
               (+ r y))))))

;;; End of R6RS procedures.

;;------------------------------------------------------------------------------
;; Was file "rand.scm".

;; Minimal Standard Random Number Generator
;; Park & Miller, CACM 31(10), Oct 1988, 32 bit integer version.
;; better constants, as proposed by Park.
;; By Ozan Yigit

;;; Rehacked by Olin 4/1995.

(define (random-state n)
  (cons n #f))

(define (rand state)
  (probe-tick 3)
  (let ((seed (car state))
        (A 2813);; 48271
        (M 8388607);; 2147483647
        (Q 2787);; 44488
        (R 2699));; 3399
    (let* ((hi (div seed Q))
           (lo (mod seed Q))
           (test (- (* A lo) (* R hi)))
           (val (if (> test 0) test (+ test M))))
      (set-car! state val)
      val)))

(define (random-int n state)
  (mod (rand state) n))

;; poker test
;; seed 1
;; cards 0-9 inclusive (random 10)
;; five cards per hand
;; 10000 hands
;;
;; Poker Hand     Example    Probability  Calculated
;; 5 of a kind    (aaaaa)      0.0001      0
;; 4 of a kind    (aaaab)      0.0045      0.0053
;; Full house     (aaabb)      0.009       0.0093
;; 3 of a kind    (aaabc)      0.072       0.0682
;; two pairs      (aabbc)      0.108       0.1104
;; Pair           (aabcd)      0.504       0.501
;; Bust           (abcde)      0.3024      0.3058

;; (define (random n)
;;   (let* ((M 2147483647)
;;        (slop (modulo M n)))
;;     (let loop ((r (rand)))
;;       (if (> r slop)
;;         (modulo r n)
;;         (loop (rand))))))
;;
;; (define (rngtest)
;;   (display "implementation ")
;;   (srand 1)
;;   (let loop ((n 0))
;;     (if (< n 10000)
;;         (begin
;;          (rand)
;;          (loop (1+ n)))))
;;   (if (= *seed* 399268537)
;;       (display "looks correct.")
;;       (begin
;;        (display "failed.")
;;        (newline)
;;        (display "   current seed ") (display *seed*)
;;        (newline)
;;        (display "   correct seed 399268537")))
;;   (newline))

;;------------------------------------------------------------------------------
;; Was file "uf.scm".

;;; Tarjan's amortised union-find data structure.
;;; Copyright (c) 1995 by Olin Shivers.

;;; This data structure implements disjoint sets of elements.
;;; Four operations are supported. The implementation is extremely
;;; fast -- any sequence of N operations can be performed in time
;;; so close to linear it's laughable how close it is. See your
;;; intro data structures book for more. The operations are:
;;;
;;; - (base-set nelts) -> set
;;;   Returns a new set, of size NELTS.
;;;
;;; - (set-size s) -> integer
;;;   Returns the number of elements in set S.
;;;
;;; - (union! set1 set2)
;;;   Unions the two sets -- SET1 and SET2 are now considered the same set
;;;   by SET-EQUAL?.
;;;
;;; - (set-equal? set1 set2)
;;;   Returns true <==> the two sets are the same.

;;; Representation: a set is a cons cell. Every set has a "representative"
;;; cons cell, reached by chasing cdr links until we find the cons with
;;; cdr = (). Set equality is determined by comparing representatives using
;;; EQ?. A representative's car contains the number of elements in the set.

;;; The speed of the algorithm comes because when we chase links to find
;;; representatives, we collapse links by changing all the cells in the path
;;; we followed to point directly to the representative, so that next time
;;; we walk the cdr-chain, we'll go directly to the representative in one hop.


(define (base-set nelts) (cons nelts '()))

;;; Sets are chained together through cdr links. Last guy in the chain
;;; is the root of the set.

(define (get-set-root s)
  (probe-tick 7)
  (let lp ((r s));; Find the last pair
    (let ((next (cdr r)));; in the list. That's
      (cond ((pair? next) (lp next));; the root r.

            (else
             (if (not (eq? r s));; Now zip down the list again,
                 (let lp ((x s));; changing everyone's cdr to r.
                   (let ((next (cdr x)))
                     (cond ((not (eq? r next))
                            (begin (probe-tick 15) (set-cdr! x r))
                            (lp next))))))
             r)))));; Then return r.

(define (set-equal? s1 s2) (eq? (get-set-root s1) (get-set-root s2)))

(define (set-size s) (car (get-set-root s)))

(define (union! s1 s2)
  (probe-tick 8)
  (let* ((r1 (get-set-root s1))
         (r2 (get-set-root s2))
         (n1 (set-size r1))
         (n2 (set-size r2))
         (n  (+ n1 n2)))

    (cond ((> n1 n2)
           (set-cdr! r2 r1)
           (set-car! r1 n))
          (else
           (set-cdr! r1 r2)
           (set-car! r2 n)))))

;;------------------------------------------------------------------------------
;; Was file "maze.scm".

;;; Building mazes with union/find disjoint sets.
;;; Copyright (c) 1995 by Olin Shivers.

;;; This is the algorithmic core of the maze constructor.
;;; External dependencies:
;;; - RANDOM-INT
;;; - Union/find code
;;; - bitwise logical functions

;; (define-record wall
;;   owner;; Cell that owns this wall.
;;   neighbor;; The other cell bordering this wall.
;;   bit);; Integer -- a bit identifying this wall in OWNER's cell.

;; (define-record cell
;;   reachable;; Union/find set -- all reachable cells.
;;   id;; Identifying info (e.g., the coords of the cell).
;;   (walls -1);; A bitset telling which walls are still standing.
;;   (parent #f);; For DFS spanning tree construction.
;;   (mark #f));; For marking the solution path.

(define (make-wall owner neighbor bit)
  (probe-tick 2)
  (vector 'wall owner neighbor bit))

(define (wall:owner o)          (vector-ref o 1))
(define (set-wall:owner o v)    (vector-set! o 1 v))
(define (wall:neighbor o)       (vector-ref o 2))
(define (set-wall:neighbor o v) (vector-set! o 2 v))
(define (wall:bit o)            (vector-ref o 3))
(define (set-wall:bit o v)      (vector-set! o 3 v))

(define (make-cell reachable id)
  (probe-tick 1)
  (vector 'cell reachable id -1 #f #f))

(define (cell:reachable o)       (vector-ref o 1))
(define (set-cell:reachable o v) (vector-set! o 1 v))
(define (cell:id o)              (vector-ref o 2))
(define (set-cell:id o v)        (vector-set! o 2 v))
(define (cell:walls o)           (vector-ref o 3))
(define (set-cell:walls o v)     (vector-set! o 3 v))
(define (cell:parent o)          (vector-ref o 4))
(define (set-cell:parent o v)
  (probe-tick 13)    (vector-set! o 4 v))
(define (cell:mark o)            (vector-ref o 5))
(define (set-cell:mark o v)
  (probe-tick 14)      (vector-set! o 5 v))

;;; Iterates in reverse order.

(define (vector-for-each-rev proc v)
  (let lp ((i (- (vector-length v) 1)))
    (cond ((>= i 0)
           (proc (vector-ref v i))
           (lp (- i 1))))))

;;; Randomly permute a vector.

(define (permute-vec! v random-state)
  (let lp ((i (- (vector-length v) 1)))
    (cond ((> i 1)
           (let ((elt-i (vector-ref v i))
                 (j (random-int i random-state)));; j in [0,i)
             (vector-set! v i (vector-ref v j))
             (vector-set! v j elt-i))
           (lp (- i 1)))))
  (probe-wall-vector 101 v)
  v)


;;; This is the core of the algorithm.

(define (dig-maze walls ncells)
  (call-with-current-continuation
   (lambda (quit)
     (vector-for-each-rev
      (lambda (wall)
        (probe-visit wall);; For each wall,
        (let* ((c1   (wall:owner wall));; find the cells on
               (set1 (cell:reachable c1))

               (c2   (wall:neighbor wall));; each side of the wall
               (set2 (cell:reachable c2)))

;;; If there is no path from c1 to c2, knock down the
;;; wall and union the two sets of reachable cells.
;;; If the new set of reachable cells is the whole set
;;; of cells, quit.
          (if (not (set-equal? set1 set2))
              (let ((walls (cell:walls c1))
                    (wall-mask (bitwise-not (wall:bit wall))))
                (union! set1 set2)
                (set-cell:walls c1 (bitwise-and walls wall-mask))
                (if (= (set-size set1) ncells) (quit #f))))))
      walls))))


;;; Some simple DFS routines useful for determining path length
;;; through the maze.

;;; Build a DFS tree from ROOT.
;;; (DO-CHILDREN proc maze node) applies PROC to each of NODE's children.
;;; We assume there are no loops in the maze; if this is incorrect, the
;;; algorithm will diverge.

(define (dfs-maze maze root do-children)
  (let search ((node root) (parent #f))
    (set-cell:parent node parent)
    (do-children (lambda (child)
                   (if (not (eq? child parent))
                       (search child node)))
                 maze node)))

;;; Move the root to NEW-ROOT.

(define (reroot-maze new-root)
  (probe-tick 10)
  (let lp ((node new-root) (new-parent #f))
    (let ((old-parent (cell:parent node)))
      (set-cell:parent node new-parent)
      (if old-parent (lp old-parent node)))))

;;; How far from CELL to the root?

(define (path-length cell)
  (probe-tick 11)
  (do ((len 0 (+ len 1))
       (node (cell:parent cell) (cell:parent node)))
      ((not node) len)))

;;; Mark the nodes from NODE back to root. Used to mark the winning path.

(define (mark-path node)
  (let lp ((node node))
    (set-cell:mark node #t)
    (cond ((cell:parent node) => lp))))

;;------------------------------------------------------------------------------
;; Was file "harr.scm".

;;; Hex arrays
;;; Copyright (c) 1995 by Olin Shivers.

;;; External dependencies:
;;; - define-record

;;;        ___       ___       ___
;;;       /   \     /   \     /   \
;;;   ___/  A  \___/  A  \___/  A  \___
;;;  /   \     /   \     /   \     /   \
;;; /  A  \___/  A  \___/  A  \___/  A  \
;;; \     /   \     /   \     /   \     /
;;;  \___/     \___/     \___/     \___/
;;;  /   \     /   \     /   \     /   \
;;; /     \___/     \___/     \___/     \
;;; \     /   \     /   \     /   \     /
;;;  \___/     \___/     \___/     \___/
;;;  /   \     /   \     /   \     /   \
;;; /     \___/     \___/     \___/     \
;;; \     /   \     /   \     /   \     /
;;;  \___/     \___/     \___/     \___/

;;; Hex arrays are indexed by the (x,y) coord of the center of the hexagonal
;;; element. Hexes are three wide and two high; e.g., to get from the center
;;; of an elt to its {NW, N, NE} neighbors, add {(-3,1), (0,2), (3,1)}
;;; respectively.
;;;
;;; Hex arrays are represented with a matrix, essentially made by shoving the
;;; odd columns down a half-cell so things line up. The mapping is as follows:
;;;     Center coord      row/column
;;;     ------------      ----------
;;;     (x,  y)        -> (y/2, x/3)
;;;     (3c, 2r + c&1) <- (r,   c)


;; (define-record harr
;;   nrows
;;   ncols
;;   elts)

(define (make-harr nrows ncols elts)
  (vector 'harr nrows ncols elts))

(define (harr:nrows o)       (vector-ref o 1))
(define (set-harr:nrows o v) (vector-set! o 1 v))
(define (harr:ncols o)       (vector-ref o 2))
(define (set-harr:ncols o v) (vector-set! o 2 v))
(define (harr:elts o)        (vector-ref o 3))
(define (set-harr:elts o v)  (vector-set! o 3 v))

(define (harr r c)
  (make-harr r c (make-vector (* r c))))



(define (href ha x y)
  (let ((r (div y 2))
        (c (div x 3)))
    (vector-ref (harr:elts ha)
                (+ (* (harr:ncols ha) r) c))))

(define (hset! ha x y val)
  (let ((r (div y 2))
        (c (div x 3)))
    (vector-set! (harr:elts ha)
                 (+ (* (harr:ncols ha) r) c)
                 val)))

(define (href/rc ha r c)
  (vector-ref (harr:elts ha)
              (+ (* (harr:ncols ha) r) c)))

;;; Create a nrows x ncols hex array. The elt centered on coord (x, y)
;;; is the value returned by (PROC x y).

(define (harr-tabulate nrows ncols proc)
  (let ((v (make-vector (* nrows ncols))))

    (do ((r (- nrows 1) (- r 1)))
        ((< r 0))
      (do ((c 0 (+ c 1))
           (i (* r ncols) (+ i 1)))
          ((= c ncols))
        (vector-set! v i (proc (* 3 c) (+ (* 2 r) (bitwise-and c 1))))))

    (make-harr nrows ncols v)))


(define (harr-for-each proc harr)
  (vector-for-each-rev proc (harr:elts harr)))

;;------------------------------------------------------------------------------
;; Was file "hex.scm".

;;; Hexagonal hackery for maze generation.
;;; Copyright (c) 1995 by Olin Shivers.

;;; External dependencies:
;;; - cell and wall records
;;; - Functional Postscript for HEXES->PATH
;;; - logical functions for bit hacking
;;; - hex array code.

;;; To have the maze span (0,0) to (1,1):
;;; (scale (/ (+ 1 (* 3 ncols))) (/ (+ 1 (* 2 nrows)))
;;;        (translate (point 2 1) maze))

;;; Every elt of the hex array manages his SW, S, and SE wall.
;;; Terminology: - An even column is one whose column index is even. That
;;;                means the first, third, ... columns (indices 0, 2, ...).
;;;              - An odd column is one whose column index is odd. That
;;;                means the second, fourth... columns (indices 1, 3, ...).
;;;              The even/odd flip-flop is confusing; be careful to keep it
;;;              straight. The *even* columns are the low ones. The *odd*
;;;              columns are the high ones.
;;;    _   _
;;;  _/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/
;;;  0 1 2 3

(define south-west 1)
(define south      2)
(define south-east 4)

(define (gen-maze-array r c)
  (harr-tabulate r c (lambda (x y) (make-cell (base-set 1) (cons x y)))))

;;; This could be made more efficient.
(define (make-wall-vec harr)
  (let* ((nrows (harr:nrows harr))
         (ncols (harr:ncols harr))
         (xmax (* 3 (- ncols 1)))

;;; Accumulate walls.
         (walls '())
         (add-wall (lambda (o n b);; owner neighbor bit
                     (set! walls (cons (make-wall o n b) walls)))))

;;; Do everything but the bottom row.
    (do ((x (* (- ncols 1) 3) (- x 3)))
        ((< x 0))
      (do ((y (+ (* (- nrows 1) 2) (bitwise-and x 1))
              (- y 2)))
          ((<= y 1));; Don't do bottom row.
        (let ((hex (href harr x y)))
          (if (not (zero? x))
              (add-wall hex (href harr (- x 3) (- y 1)) south-west))
          (add-wall hex (href harr x (- y 2)) south)
          (if (< x xmax)
              (add-wall hex (href harr (+ x 3) (- y 1)) south-east)))))

;;; Do the SE and SW walls of the odd columns on the bottom row.
;;; If the rightmost bottom hex lies in an odd column, however,
;;; don't add it's SE wall -- it's a corner hex, and has no SE neighbor.
    (if (> ncols 1)
        (let ((rmoc-x (+ 3 (* 6 (div (- ncols 2) 2)))))
;;; Do rightmost odd col.
          (let ((rmoc-hex (href harr rmoc-x 1)))
            (if (< rmoc-x xmax);; Not  a corner -- do E wall.
                (add-wall rmoc-hex (href harr xmax 0) south-east))
            (add-wall rmoc-hex (href harr (- rmoc-x 3) 0) south-west))

          (do ((x (- rmoc-x 6);; Do the rest of the bottom row's odd cols.
                  (- x 6)))
              ((< x 3));; 3 is X coord of leftmost odd column.
            (add-wall (href harr x 1) (href harr (- x 3) 0) south-west)
            (add-wall (href harr x 1) (href harr (+ x 3) 0) south-east))))

    (probe-wall-vector 100 (list->vector walls))))


;;; Find the cell ctop from the top row, and the cell cbot from the bottom
;;; row such that cbot is furthest from ctop.
;;; Return [ctop-x, ctop-y, cbot-x, cbot-y].

(define (pick-entrances harr)
  (dfs-maze harr (href/rc harr 0 0) for-each-hex-child)
  (let ((nrows (harr:nrows harr))
        (ncols (harr:ncols harr)))
    (let tp-lp ((max-len -1)
                (entrance #f)
                (exit #f)
                (tcol (- ncols 1)))
      (if (< tcol 0) (vector entrance exit)
          (let ((top-cell (href/rc harr (- nrows 1) tcol)))
            (reroot-maze top-cell)
            (let ((result
                   (let bt-lp ((max-len max-len)
                               (entrance entrance)
                               (exit exit)
                               (bcol (- ncols 1)))
                     ;;                     (format #t "~a ~a ~a ~a~%" max-len entrance exit bcol)
                     (if (< bcol 0) (vector max-len entrance exit)
                         (let ((this-len (path-length (href/rc harr 0 bcol))))
                           (if (> this-len max-len)
                               (bt-lp this-len tcol bcol (- bcol 1))
                               (bt-lp max-len  entrance exit (- bcol 1))))))))
              (let ((max-len (vector-ref result 0))
                    (entrance (vector-ref result 1))
                    (exit (vector-ref result 2)))
                (tp-lp max-len entrance exit (- tcol 1)))))))))



;;; Apply PROC to each node reachable from CELL.
(define (for-each-hex-child proc harr cell)
  (let* ((walls (cell:walls cell))
         (id (cell:id cell))
         (x (car id))
         (y (cdr id))
         (nr (harr:nrows harr))
         (nc (harr:ncols harr))
         (maxy (* 2 (- nr 1)))
         (maxx (* 3 (- nc 1))))
    (if (not (bit-test walls south-west)) (proc (href harr (- x 3) (- y 1))))
    (if (not (bit-test walls south))      (proc (href harr x       (- y 2))))
    (if (not (bit-test walls south-east)) (proc (href harr (+ x 3) (- y 1))))

;;; NW neighbor, if there is one (we may be in col 1, or top row/odd col)
    (if (and (> x 0);; Not in first column.
             (or (<= y maxy);; Not on top row or
                 (zero? (mod x 6))));; not in an odd column.
        (let ((nw (href harr (- x 3) (+ y 1))))
          (if (not (bit-test (cell:walls nw) south-east)) (proc nw))))

;;; N neighbor, if there is one (we may be on top row).
    (if (< y maxy);; Not on top row
        (let ((n (href harr x (+ y 2))))
          (if (not (bit-test (cell:walls n) south)) (proc n))))

;;; NE neighbor, if there is one (we may be in last col, or top row/odd col)
    (if (and (< x maxx);; Not in last column.
             (or (<= y maxy);; Not on top row or
                 (zero? (mod x 6))));; not in an odd column.
        (let ((ne (href harr (+ x 3) (+ y 1))))
          (if (not (bit-test (cell:walls ne) south-west)) (proc ne))))))



;;; The top-level
(define (make-maze nrows ncols)
  (let* ((cells (gen-maze-array nrows ncols))
         (walls (permute-vec! (make-wall-vec cells) (random-state 20))))
    (dig-maze walls (* nrows ncols))
    (probe-after-dig cells walls)
    (let ((result (pick-entrances cells)))
      (let ((entrance (vector-ref result 0))
            (exit (vector-ref result 1)))
        (let* ((exit-cell (href/rc cells 0 exit))
               (walls (cell:walls exit-cell)))
          (reroot-maze (href/rc cells (- nrows 1) entrance))
          (mark-path exit-cell)
          (set-cell:walls exit-cell (bitwise-and walls (bitwise-not south)))
          (begin (probe-finished-maze cells entrance exit) (vector cells entrance exit)))))))


(define (pmaze nrows ncols)
  (let ((result (make-maze nrows ncols)))
    (let ((cells (vector-ref result 0))
          (entrance (vector-ref result 1))
          (exit (vector-ref result 2)))
      (print-hexmaze cells entrance))))

;;------------------------------------------------------------------------------
;; Was file "hexprint.scm".

;;; Print out a hex array with characters.
;;; Copyright (c) 1995 by Olin Shivers.

;;; External dependencies:
;;; - hex array code
;;; - hex cell code

;;;    _   _
;;;  _/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/

;;; Top part of top row looks like this:
;;;    _   _  _   _
;;;  _/ \_/ \/ \_/ \
;;; /

(define output #f);; the list of all characters written out, in reverse order.

(define (write-ch c)
  (probe-tick 12)
  (set! output (cons c output)))

(define (print-hexmaze harr entrance)
  (let* ((nrows  (harr:nrows harr))
         (ncols  (harr:ncols harr))
         (ncols2 (* 2 (div ncols 2))))

;;; Print out the flat tops for the top row's odd cols.
    (do ((c 1 (+ c 2)))
        ((>= c ncols))
      ;;     (display "   ")
      (write-ch #\space)
      (write-ch #\space)
      (write-ch #\space)
      (write-ch (if (= c entrance) #\space #\_)))
    ;;   (newline)
    (write-ch #\newline)

;;; Print out the slanted tops for the top row's odd cols
;;; and the flat tops for the top row's even cols.
    (write-ch #\space)
    (do ((c 0 (+ c 2)))
        ((>= c ncols2))
      ;;     (format #t "~a/~a\\"
      ;;             (if (= c entrance) #\space #\_)
      ;;             (dot/space harr (- nrows 1) (+ c 1)))
      (write-ch (if (= c entrance) #\space #\_))
      (write-ch #\/)
      (write-ch (dot/space harr (- nrows 1) (+ c 1)))
      (write-ch #\\))
    (if (odd? ncols)
        (write-ch (if (= entrance (- ncols 1)) #\space #\_)))
    ;;   (newline)
    (write-ch #\newline)

    (do ((r (- nrows 1) (- r 1)))
        ((< r 0))

;;; Do the bottoms for row r's odd cols.
      (write-ch #\/)
      (do ((c 1 (+ c 2)))
          ((>= c ncols2))
;;; The dot/space for the even col just behind c.
        (write-ch (dot/space harr r (- c 1)))
        (display-hexbottom (cell:walls (href/rc harr r c))))

      (cond ((odd? ncols)
             (write-ch (dot/space harr r (- ncols 1)))
             (write-ch #\\)))
      ;;     (newline)
      (write-ch #\newline)

;;; Do the bottoms for row r's even cols.
      (do ((c 0 (+ c 2)))
          ((>= c ncols2))
        (display-hexbottom (cell:walls (href/rc harr r c)))
;;; The dot/space is for the odd col just after c, on row below.
        (write-ch (dot/space harr (- r 1) (+ c 1))))

      (cond ((odd? ncols)
             (display-hexbottom (cell:walls (href/rc harr r (- ncols 1)))))
            ((not (zero? r)) (write-ch #\\)))
      ;;     (newline)
      (write-ch #\newline))))

(define (bit-test j bit)
  (not (zero? (bitwise-and j bit))))

;;; Return a . if harr[r,c] is marked, otherwise a space.
;;; We use the dot to mark the solution path.
(define (dot/space harr r c)
  (if (and (>= r 0) (cell:mark (href/rc harr r c))) #\. #\space))

;;; Print a \_/ hex bottom.
(define (display-hexbottom hexwalls)
  (write-ch (if (bit-test hexwalls south-west) #\\ #\space))
  (write-ch (if (bit-test hexwalls south     ) #\_ #\space))
  (write-ch (if (bit-test hexwalls south-east) #\/ #\space)))

;;;    _   _
;;;  _/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \_/
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \
;;; / \_/ \_/
;;; \_/ \_/ \_/

;;------------------------------------------------------------------------------

(define (run nrows ncols)
  (probe-tick 0)
  (set! output '())
  (pmaze nrows ncols)
  (reverse output))

(define (probe-x cell) (car (cell:id cell)))
(define (probe-y cell) (cdr (cell:id cell)))
(define probe-set-same? eq?)
(define probe-cell-same? eq?)
(define (probe-set-linked? set) (pair? (cdr set)))
(define probe-set-next cdr)
(define probe-set-size-field car)
(define (probe-parent-present? cell) (if (cell:parent cell) #t #f))
(define probe-parent-cell cell:parent)
(let* ((count (read)) (rows (read)) (columns (read)) (expected (chez-output (read))))
  (let ((result (probe-run count rows columns expected)))
    (display "result:") (write result) (newline)))
