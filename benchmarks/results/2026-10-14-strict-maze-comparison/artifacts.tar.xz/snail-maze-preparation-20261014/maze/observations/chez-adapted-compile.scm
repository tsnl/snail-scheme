(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-maze-preparation-20261014/maze/observations/chez-adapted.scm" "/tmp/snail-maze-preparation-20261014/maze/observations/chez-adapted.so"))
