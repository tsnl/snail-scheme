(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-maze-preparation-20261014/maze/chez/program.scm" "/tmp/snail-maze-preparation-20261014/maze/chez/program.so"))
