(module
 (rec
  (type $type300 (sub (struct)))
  (type $type42 (sub (struct)))
  (type $type167 (sub (struct (field i32))))
  (type $type55 (sub (struct)))
  (type $type49 (sub (struct)))
  (type $type217 (sub (struct)))
  (type $type223 (sub (struct (field i32))))
  (type $type205 (sub (struct (field i32))))
  (type $type172 (sub (struct)))
  (type $type122 (sub (struct (field i32))))
  (type $type13 (sub (struct (field i32))))
  (type $type113 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type28 (sub (struct)))
  (type $14 (func (param i64 i32 i32 i64 (ref $type167)) (result i64)))
  (type $call165 (func (param (ref $type160)) (result (ref $type166))))
  (type $16 (func (param i32 i32 (ref $type13) (ref null $type61)) (result (ref $type167))))
  (type $17 (func (param i32 i32 (ref null $type61) (ref $type61)) (result (ref null $type61))))
  (type $type295 (struct))
  (type $call311 (func (param i64 i64) (result (ref null $type61))))
  (type $call310 (func (param i64) (result i32)))
  (type $21 (func (param (ref $type283) i64 i64 i32 i32 i64) (result i32)))
  (type $22 (func (param (ref $type283) i64 i64 i64 i32 i32 i64) (result i32)))
  (type $23 (func (param i64 i64 i32 i32 i64) (result i32)))
  (type $24 (func (param (ref $type59) (ref $type47) i32 i32 i64) (result i32)))
  (type $type302 (sub $type300 (struct (field i64))))
  (type $26 (func (param (ref $type283) i64 i32 i32 i64 (ref $type300) (ref $type300) i64) (result (ref $type315))))
  (type $type299 (struct (field (ref $type300)) (field (ref $type300))))
  (type $type315 (struct (field i64) (field (ref $type300)) (field (ref $type300))))
  (type $29 (func (param (ref $type283) i64 i64 i32 i32 i64 (ref $type300) (ref $type300) i64) (result (ref $type299))))
  (type $call285 (func (param (ref $type278) (ref $type283) (ref $type44)) (result i32)))
  (type $31 (func (param (ref $type59) i32 i32 (ref null $type39) i64) (result (ref $type59))))
  (type $32 (func (param i32 i32 (ref null $type39) i64) (result i64)))
  (type $33 (func (param (ref $type283) (ref $type314) i32 i32 i32 i64) (result i32)))
  (type $34 (func (param (ref $type283) i64 (ref $type314) i32 i64 i32 i32 i64) (result i32)))
  (type $35 (func (param (ref $type283) i64 i64 (ref $type314) i32 i32 i32 i64) (result i32)))
  (type $type314 (struct (field (mut (ref null $type39)))))
  (type $type39 (struct (field (ref $type40)) (field (ref null $type39))))
  (type $call297 (func (param (ref $type283)) (result (ref $type59))))
  (type $type52 (struct (field (ref $type53))))
  (type $type53 (struct (field i64) (field i64)))
  (type $41 (func (param i64 (ref $type295) (ref $type279) i64 i32 i32 i64 i64) (result i32)))
  (type $42 (func (param i64 (ref $type295) (ref $type279) i32 i32 i64) (result i32)))
  (type $type284 (struct (field (ref $type279))))
  (type $type279 (array (mut (ref $type42))))
  (type $45 (func (param i64 i64 (ref $type295)) (result (ref $type283))))
  (type $46 (func (param i32 i32 (ref $type42)) (result i32)))
  (type $47 (func (param i32 i32 i64 (ref $type55)) (result i64)))
  (type $call271 (func (param (ref $type42)) (result i64)))
  (type $49 (func (param i32 i32 (ref $type42) (ref $type55)) (result i32)))
  (type $environment277 (struct (field (ref $type283)) (field (ref $type285)) (field (ref $type313)) (field (ref $type44)) (field (ref $type55))))
  (type $type313 (struct (field i32)))
  (type $type283 (struct (field (ref $type47)) (field (ref $type47)) (field (ref $type284))))
  (type $call278 (func (param (ref null $environment277) (ref $type42)) (result i32)))
  (type $54 (func (param (ref $type250) (ref $type59) i32 i32 i64) (result i32)))
  (type $type45 (struct (field (ref $type46))))
  (type $type41 (struct (field (ref $type42))))
  (type $type40 (struct (field (ref $type41)) (field (ref $type41)) (field (ref $type47))))
  (type $call250 (func (param (ref $environment272) (ref $type40)) (result i32)))
  (type $type59 (array (mut (ref $type40))))
  (type $environment272 (struct (field i64)))
  (type $type250 (struct (field (ref $environment272))))
  (type $call281 (func (param (ref $type59) i64) (result i32)))
  (type $type58 (struct (field (mut i32))))
  (type $64 (func (param (ref $type42))))
  (type $type54 (struct (field (mut (ref $type55)))))
  (type $type44 (sub $type42 (struct (field (ref $type45)) (field (ref $type52)) (field (ref $type47)) (field (ref $type54)) (field (ref $type58)))))
  (type $call273 (func (param (ref $type42)) (result (ref $type55))))
  (type $68 (func (param (ref $type46) i32 i32 (ref $type46)) (result i32)))
  (type $type48 (struct (field (mut (ref $type49)))))
  (type $70 (func (param (ref $type46) i32 i32 (ref $type46)) (result (ref $type46))))
  (type $call253 (func (param i64 i64) (result i64)))
  (type $type169 (sub $type167 (struct (field i32) (field (ref null $type61)))))
  (type $call252 (func (param (ref $type167) (ref $type167)) (result i32)))
  (type $type61 (struct (field i32) (field (ref null $type61))))
  (type $call251 (func (param (ref null $type61) (ref null $type61)) (result i32)))
  (type $type57 (sub $type55 (struct (field (ref $type42)))))
  (type $call243 (func (param (ref $type55)) (result i32)))
  (type $type46 (struct (field (ref $type47)) (field (ref $type48))))
  (type $type51 (sub $type49 (struct (field (ref $type46)))))
  (type $call245 (func (param (ref $type46) (ref $type49)) (result i32)))
  (type $call241 (func (param (ref null $type12) (ref $type36) i64) (result (ref $type122))))
  (type $82 (func (param (ref $type34) i32 i32 (ref null $type12) i64) (result (ref $type34))))
  (type $83 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $84 (func (param i32 i32 (ref null $type12) (ref $type12)) (result (ref null $type12))))
  (type $call237 (func (param (ref null $type12) (ref $type13)) (result (ref $type13))))
  (type $type36 (struct (field (ref $type37))))
  (type $type37 (array (mut i8)))
  (type $type34 (array (mut (ref $type13))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $90 (func (param (ref $type160) i64 (ref null $type12)) (result (ref $type122))))
  (type $call232 (func (param (ref $type160) (ref $type205)) (result (ref $type122))))
  (type $92 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type223))))
  (type $93 (func (param (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $94 (func (param (ref $type160) (ref $type197) i32 i32) (result (ref $type18))))
  (type $call195 (func (param i64) (result i32)))
  (type $call203 (func (param (ref $type160) i64) (result i32)))
  (type $97 (func (param (ref $type197) i32)))
  (type $call228 (func (param (ref $type160) i64) (result (ref $type223))))
  (type $call230 (func (param (ref $type160) i64 i64) (result (ref $type223))))
  (type $call220 (func (param (ref $type160) i32 (ref $type197)) (result (ref $type217))))
  (type $type219 (sub $type217 (struct (field (ref $type18)))))
  (type $type218 (sub $type217 (struct (field (ref $type18)))))
  (type $call215 (func (param (ref $type160) i32 i32) (result (ref $type205))))
  (type $call162 (func (param (ref $type160)) (result i32)))
  (type $call192 (func (param (ref $type160)) (result i64)))
  (type $type226 (sub $type223 (struct (field i32) (field (ref $type18)))))
  (type $type224 (sub $type223 (struct (field i32) (field i32))))
  (type $type198 (struct (field (mut (ref $type18)))))
  (type $type206 (sub $type205 (struct (field i32) (field (ref $type13)))))
  (type $type212 (sub $type205 (struct (field i32) (field (ref $type18)))))
  (type $type211 (sub $type205 (struct (field i32) (field (ref $type18)))))
  (type $type210 (sub $type205 (struct (field i32) (field i64))))
  (type $type174 (sub $type172 (struct (field i32))))
  (type $type158 (struct (field (mut i32))))
  (type $type160 (struct (field (ref $type158))))
  (type $type197 (struct (field (ref $type198)) (field (ref $type47))))
  (type $call204 (func (param (ref $type160)) (result (ref $type205))))
  (type $type125 (sub $type122 (struct (field i32) (field (ref $type18)))))
  (type $type124 (sub $type122 (struct (field i32) (field (ref $type13)))))
  (type $call189 (func (param (ref $type122)) (result (ref $type13))))
  (type $121 (func (param (ref $type18) i64 i32 i32 i64) (result i32)))
  (type $type35 (sub $type13 (struct (field i32))))
  (type $type33 (sub $type13 (struct (field i32))))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $type21 (sub $type13 (struct (field i32))))
  (type $type17 (sub $type13 (struct (field i32))))
  (type $type16 (sub $type13 (struct (field i32) (field i32))))
  (type $type15 (sub $type13 (struct (field i32) (field i32))))
  (type $call132 (func (param (ref $type13)) (result i64)))
  (type $type31 (sub $type13 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $type32 (struct (field (ref $type13))))
  (type $132 (func (param (ref $type13) (ref $type13)) (result (ref $type31))))
  (type $type116 (sub $type113 (struct (field i32) (field (ref $type18)))))
  (type $type27 (sub $type24 (struct (field i32))))
  (type $type30 (sub $type28 (struct)))
  (type $type29 (sub $type28 (struct)))
  (type $type26 (sub $type24 (struct (field i32))))
  (type $type115 (sub $type113 (struct (field i32) (field (ref $type24)))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $call112 (func (param i32 i32) (result (ref $type113))))
  (type $141 (func (param i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $142 (func (param (ref $type18) i32 i64 i32 i32 i64) (result i32)))
  (type $call102 (func (param (ref $type18)) (result i32)))
  (type $144 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $call73 (func (param (ref $type18) (ref null $type71) i64) (result i32)))
  (type $146 (func (param i32 i32 (ref null $type71) i64) (result i64)))
  (type $type71 (struct (field (ref $type18)) (field (ref null $type71))))
  (type $call70 (func (param (ref $type71)) (result (ref $type18))))
  (type $149 (func (param (ref $type18) i64 (ref $type18) i64)))
  (type $150 (func (param (ref $type18) i32) (result (ref $type19))))
  (type $type20 (array (mut (ref null $type19))))
  (type $152 (func (param i32) (result (ref $type18))))
  (type $type165 (struct))
  (type $type312 (struct))
  (type $type311 (struct))
  (type $type288 (struct))
  (type $type305 (struct))
  (type $type303 (struct))
  (type $type285 (struct))
  (type $type298 (struct))
  (type $type297 (struct))
  (type $type291 (struct))
  (type $type294 (struct))
  (type $type286 (struct))
  (type $type282 (struct))
  (type $type281 (struct))
  (type $type280 (struct))
  (type $type269 (struct))
  (type $type267 (struct))
  (type $type266 (struct))
  (type $type264 (struct))
  (type $type262 (struct))
  (type $type260 (struct))
  (type $type257 (struct))
  (type $type256 (struct))
  (type $type255 (struct))
  (type $type254 (struct))
  (type $type252 (struct))
  (type $type249 (struct))
  (type $type247 (struct))
  (type $type246 (struct))
  (type $type240 (struct))
  (type $type239 (struct))
  (type $type238 (struct))
  (type $type236 (struct))
  (type $type235 (struct))
  (type $type233 (struct))
  (type $type231 (struct))
  (type $type227 (struct))
  (type $type222 (struct))
  (type $type221 (struct))
  (type $type216 (struct))
  (type $type214 (struct))
  (type $type213 (struct))
  (type $type200 (struct))
  (type $type164 (struct))
  (type $type163 (struct))
  (type $type159 (struct))
  (type $type155 (struct))
  (type $type133 (struct))
  (type $type128 (struct))
  (type $type126 (struct))
  (type $type121 (struct))
  (type $type117 (struct))
  (type $type111 (struct))
  (type $type75 (struct))
  (type $type72 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type38 (struct))
  (type $type11 (struct))
  (type $type278 (struct (field (ref $call278)) (field (ref null $environment277))))
  (type $type272 (struct))
  (type $type248 (struct))
  (type $type241 (struct))
  (type $type230 (struct))
  (type $type229 (struct))
  (type $type88 (struct))
  (type $type228 (struct))
  (type $type220 (struct))
  (type $type215 (struct))
  (type $type162 (struct))
  (type $type201 (struct))
  (type $type130 (struct))
  (type $type112 (struct))
  (type $type110 (struct))
  (type $type105 (struct))
  (type $type70 (struct))
  (type $type69 (struct))
  (type $type310 (struct))
  (type $type274 (struct))
  (type $type259 (struct))
  (type $type234 (struct))
  (type $type202 (struct))
  (type $type166 (struct (field i64) (field i64) (field i64) (field (ref $type167))))
  (type $type309 (struct))
  (type $type275 (struct))
  (type $type203 (struct))
  (type $type196 (struct))
  (type $type189 (struct))
  (type $type68 (struct))
  (type $type132 (struct))
  (type $type276 (struct))
  (type $type245 (struct))
  (type $type242 (struct))
  (type $type199 (struct))
  (type $type261 (struct))
  (type $type258 (struct))
  (type $type251 (struct))
  (type $type244 (struct))
  (type $type194 (struct))
  (type $type190 (struct))
  (type $type103 (struct))
  (type $type73 (struct))
  (type $type232 (struct))
  (type $type308 (struct))
  (type $type271 (struct))
  (type $type127 (struct))
  (type $type192 (struct))
  (type $type5 (struct))
  (type $type237 (struct))
  (type $type204 (struct))
  (type $type129 (struct))
  (type $type102 (struct))
  (type $type64 (struct))
  (type $type195 (struct))
  (type $type273 (struct))
  (type $type243 (struct))
  (type $type74 (struct))
  (type $type307 (struct))
  (type $type292 (struct))
  (type $type176 (struct))
  (type $type306 (struct (field (mut (ref null $type61)))))
  (type $type191 (struct))
  (type $type47 (struct (field (mut i64))))
  (type $type175 (struct))
  (type $type289 (struct))
  (type $type287 (struct))
  (type $type253 (struct))
  (type $type193 (struct))
  (type $type301 (sub $type300 (struct)))
  (type $type225 (sub $type223 (struct (field i32))))
  (type $type209 (sub $type205 (struct (field i32))))
  (type $type208 (sub $type205 (struct (field i32))))
  (type $type207 (sub $type205 (struct (field i32))))
  (type $type170 (sub $type167 (struct (field i32))))
  (type $type123 (sub $type122 (struct (field i32))))
  (type $type114 (sub $type113 (struct (field i32))))
  (type $type50 (sub $type49 (struct)))
  (type $type43 (sub $type42 (struct)))
  (type $type168 (sub $type167 (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
  (type $type56 (sub $type55 (struct)))
  (type $type173 (sub $type172 (struct)))
 )
 (type $297 (func (param i32) (result i32)))
 (type $298 (func (result i32)))
 (type $299 (func (param i32)))
 (type $300 (func (param i32 i32) (result i32)))
 (type $301 (func))
 (type $302 (func (param i32 i32)))
 (type $303 (func (param i32 i32) (result f64)))
 (type $304 (func (param i32 i32) (result i64)))
 (type $305 (func (param (ref $type13) (ref $type31)) (result (ref $type31))))
 (type $306 (func (param (ref null $type12) (ref $type31)) (result (ref $type13))))
 (type $307 (func (param i64) (result i64)))
 (type $308 (func (result i64)))
 (import "snail.library" "snail:datum/token-open" (func $foreign0 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign1 (param i32 i32)))
 (import "snail.library" "snail:datum/fail" (func $foreign2 (param i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign3 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign4 (param i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign5 (param i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign8 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign9 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign10 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign11 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign12 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign13 (param i32) (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign15))
 (import "snail.library" "snail:io/path-character" (func $foreign16 (param i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign20 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign21 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign22 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign23 (param i32) (result i32)))
 (import "snail.library" "snail:datum/whitespace" (func $foreign25 (param i32) (result i32)))
 (import "benchmark" "barrier" (func $foreign26 (result i32)))
 (global $global628 (mut (ref null $type193)) (ref.null none))
 (global $global918 (mut (ref null $type253)) (ref.null none))
 (global $global1066 (mut (ref null $type287)) (ref.null none))
 (global $global1071 (mut (ref null $type289)) (ref.null none))
 (global $global558 (mut (ref null $type175)) (ref.null none))
 (global $empty173 (ref $type173) (struct.new_default $type173))
 (global $global351 (mut (ref null $type47)) (ref.null none))
 (global $global622 (mut (ref null $type191)) (ref.null none))
 (global $global1228 (mut (ref null $type306)) (ref.null none))
 (global $global560 (mut (ref null $type176)) (ref.null none))
 (global $global1079 (mut (ref null $type292)) (ref.null none))
 (global $global1226 (mut (ref null $type307)) (ref.null none))
 (global $global103 (mut (ref null $type74)) (ref.null none))
 (global $global892 (mut (ref null $type243)) (ref.null none))
 (global $global914 (mut (ref null $type253)) (ref.null none))
 (global $global1008 (mut (ref null $type273)) (ref.null none))
 (global $global1137 (mut (ref null $type195)) (ref.null none))
 (global $global1092 (mut (ref null $type292)) (ref.null none))
 (global $global61 (mut (ref null $type64)) (ref.null none))
 (global $global246 (mut (ref null $type102)) (ref.null none))
 (global $global359 (mut (ref null $type129)) (ref.null none))
 (global $global617 (mut (ref null $type204)) (ref.null none))
 (global $global808 (mut (ref null $type237)) (ref.null none))
 (global $global352 (mut (ref null $type5)) (ref.null none))
 (global $global562 (mut (ref null $type176)) (ref.null none))
 (global $global642 (mut (ref null $type192)) (ref.null none))
 (global $global620 (mut (ref null $type192)) (ref.null none))
 (global $ready808 (mut i32) (i32.const 0))
 (global $global354 (mut (ref null $type127)) (ref.null none))
 (global $global1003 (mut (ref null $type271)) (ref.null none))
 (global $global1168 (mut (ref null $type308)) (ref.null none))
 (global $ready617 (mut i32) (i32.const 0))
 (global $global792 (mut (ref null $type232)) (ref.null none))
 (global $global98 (mut (ref null $type73)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global252 (mut (ref null $type103)) (ref.null none))
 (global $global615 (mut (ref null $type190)) (ref.null none))
 (global $global639 (mut (ref null $type194)) (ref.null none))
 (global $ready792 (mut i32) (i32.const 0))
 (global $global876 (mut (ref null $type244)) (ref.null none))
 (global $global900 (mut (ref null $type251)) (ref.null none))
 (global $global950 (mut (ref null $type258)) (ref.null none))
 (global $global971 (mut (ref null $type261)) (ref.null none))
 (global $global701 (mut (ref null $type199)) (ref.null none))
 (global $global882 (mut (ref null $type242)) (ref.null none))
 (global $global879 (mut (ref null $type245)) (ref.null none))
 (global $ready900 (mut i32) (i32.const 0))
 (global $global1015 (mut (ref null $type276)) (ref.null none))
 (global $ready1168 (mut i32) (i32.const 0))
 (global $global372 (mut (ref null $type132)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $empty56 (ref $type56) (struct.new_default $type56))
 (global $global81 (mut (ref null $type68)) (ref.null none))
 (global $global610 (mut (ref null $type189)) (ref.null none))
 (global $global652 (mut (ref null $type196)) (ref.null none))
 (global $global725 (mut (ref null $type203)) (ref.null none))
 (global $global896 (mut (ref null $type195)) (ref.null none))
 (global $global925 (mut (ref null $type253)) (ref.null none))
 (global $global1013 (mut (ref null $type275)) (ref.null none))
 (global $global1061 (mut (ref null $type287)) (ref.null none))
 (global $global1231 (mut (ref null $type309)) (ref.null none))
 (global $ready1231 (mut i32) (i32.const 0))
 (global $global1269 (mut (ref null $type166)) (ref.null none))
 (global $global748 (mut (ref null $type202)) (ref.null none))
 (global $ready725 (mut i32) (i32.const 0))
 (global $global799 (mut (ref null $type234)) (ref.null none))
 (global $global961 (mut (ref null $type259)) (ref.null none))
 (global $global1010 (mut (ref null $type274)) (ref.null none))
 (global $global1239 (mut (ref null $type310)) (ref.null none))
 (global $ready1239 (mut i32) (i32.const 0))
 (global $global1251 (mut (ref null $type132)) (ref.null none))
 (global $string2 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 58)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 117)
   (i32.const 114)
   (i32.const 115)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 32)
   (i32.const 118)
   (i32.const 105)
   (i32.const 101)
   (i32.const 119)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 104)
   (i32.const 97)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $global88 (mut (ref null $type69)) (ref.null none))
 (global $global90 (mut (ref null $type70)) (ref.null none))
 (global $global258 (mut (ref null $type105)) (ref.null none))
 (global $global296 (mut (ref null $type110)) (ref.null none))
 (global $global305 (mut (ref null $type112)) (ref.null none))
 (global $global362 (mut (ref null $type130)) (ref.null none))
 (global $global626 (mut (ref null $type195)) (ref.null none))
 (global $global733 (mut (ref null $type195)) (ref.null none))
 (global $global658 (mut (ref null $type201)) (ref.null none))
 (global $global756 (mut (ref null $type69)) (ref.null none))
 (global $global631 (mut (ref null $type162)) (ref.null none))
 (global $global644 (mut (ref null $type215)) (ref.null none))
 (global $ready644 (mut i32) (i32.const 0))
 (global $global653 (mut (ref null $type220)) (ref.null none))
 (global $ready653 (mut i32) (i32.const 0))
 (global $global691 (mut (ref null $type162)) (ref.null none))
 (global $global686 (mut (ref null $type228)) (ref.null none))
 (global $ready686 (mut i32) (i32.const 0))
 (global $global678 (mut (ref null $type88)) (ref.null none))
 (global $global674 (mut (ref null $type195)) (ref.null none))
 (global $global671 (mut (ref null $type229)) (ref.null none))
 (global $global666 (mut (ref null $type230)) (ref.null none))
 (global $ready666 (mut i32) (i32.const 0))
 (global $ready799 (mut i32) (i32.const 0))
 (global $global833 (mut (ref null $type241)) (ref.null none))
 (global $ready833 (mut i32) (i32.const 0))
 (global $global898 (mut (ref null $type195)) (ref.null none))
 (global $global1246 (mut (ref null $type248)) (ref.null none))
 (global $global912 (mut (ref null $type88)) (ref.null none))
 (global $ready918 (mut i32) (i32.const 0))
 (global $global1005 (mut (ref null $type272)) (ref.null none))
 (global $global1041 (mut (ref null $type278)) (ref.null none))
 (global $global1281 (mut (ref null $type253)) (ref.null none))
 (global $string14 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 85)
   (i32.const 110)
   (i32.const 105)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $empty168 (ref $type168) (struct.new $type168
  (i32.const 0)
 ))
 (global $global816 (mut (ref null $type11)) (ref.null none))
 (global $global1143 (mut (ref null $type38)) (ref.null none))
 (global $global819 (mut (ref null $type62)) (ref.null none))
 (global $ready819 (mut i32) (i32.const 0))
 (global $global1146 (mut (ref null $type63)) (ref.null none))
 (global $ready1146 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type72)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type75)) (ref.null none))
 (global $global299 (mut (ref null $type111)) (ref.null none))
 (global $global308 (mut (ref null $type117)) (ref.null none))
 (global $global340 (mut (ref null $type121)) (ref.null none))
 (global $global347 (mut (ref null $type126)) (ref.null none))
 (global $global357 (mut (ref null $type128)) (ref.null none))
 (global $global364 (mut (ref null $type130)) (ref.null none))
 (global $global386 (mut (ref null $type133)) (ref.null none))
 (global $global388 (mut (ref null $type133)) (ref.null none))
 (global $global390 (mut (ref null $type133)) (ref.null none))
 (global $global534 (mut (ref null $type155)) (ref.null none))
 (global $global545 (mut (ref null $type159)) (ref.null none))
 (global $global552 (mut (ref null $type162)) (ref.null none))
 (global $global549 (mut (ref null $type163)) (ref.null none))
 (global $ready549 (mut i32) (i32.const 0))
 (global $global1270 (mut (ref null $type164)) (ref.null none))
 (global $global705 (mut (ref null $type200)) (ref.null none))
 (global $ready705 (mut i32) (i32.const 0))
 (global $ready631 (mut i32) (i32.const 0))
 (global $global720 (mut (ref null $type204)) (ref.null none))
 (global $global636 (mut (ref null $type213)) (ref.null none))
 (global $ready636 (mut i32) (i32.const 0))
 (global $global717 (mut (ref null $type204)) (ref.null none))
 (global $ready717 (mut i32) (i32.const 0))
 (global $global774 (mut (ref null $type204)) (ref.null none))
 (global $ready774 (mut i32) (i32.const 0))
 (global $global776 (mut (ref null $type214)) (ref.null none))
 (global $ready776 (mut i32) (i32.const 0))
 (global $global787 (mut (ref null $type214)) (ref.null none))
 (global $ready787 (mut i32) (i32.const 0))
 (global $global649 (mut (ref null $type216)) (ref.null none))
 (global $ready649 (mut i32) (i32.const 0))
 (global $global711 (mut (ref null $type221)) (ref.null none))
 (global $ready711 (mut i32) (i32.const 0))
 (global $global694 (mut (ref null $type222)) (ref.null none))
 (global $ready694 (mut i32) (i32.const 0))
 (global $global660 (mut (ref null $type227)) (ref.null none))
 (global $ready660 (mut i32) (i32.const 0))
 (global $global681 (mut (ref null $type195)) (ref.null none))
 (global $ready681 (mut i32) (i32.const 0))
 (global $ready691 (mut i32) (i32.const 0))
 (global $global764 (mut (ref null $type231)) (ref.null none))
 (global $global730 (mut (ref null $type204)) (ref.null none))
 (global $ready730 (mut i32) (i32.const 0))
 (global $global753 (mut (ref null $type214)) (ref.null none))
 (global $ready753 (mut i32) (i32.const 0))
 (global $global762 (mut (ref null $type231)) (ref.null none))
 (global $ready762 (mut i32) (i32.const 0))
 (global $global870 (mut (ref null $type233)) (ref.null none))
 (global $ready870 (mut i32) (i32.const 0))
 (global $global860 (mut (ref null $type235)) (ref.null none))
 (global $ready860 (mut i32) (i32.const 0))
 (global $global846 (mut (ref null $type236)) (ref.null none))
 (global $ready846 (mut i32) (i32.const 0))
 (global $global811 (mut (ref null $type238)) (ref.null none))
 (global $global805 (mut (ref null $type239)) (ref.null none))
 (global $ready805 (mut i32) (i32.const 0))
 (global $global827 (mut (ref null $type240)) (ref.null none))
 (global $ready827 (mut i32) (i32.const 0))
 (global $global838 (mut (ref null $type132)) (ref.null none))
 (global $global886 (mut (ref null $type246)) (ref.null none))
 (global $global889 (mut (ref null $type247)) (ref.null none))
 (global $global1028 (mut (ref null $type249)) (ref.null none))
 (global $global903 (mut (ref null $type252)) (ref.null none))
 (global $ready914 (mut i32) (i32.const 0))
 (global $global932 (mut (ref null $type254)) (ref.null none))
 (global $global934 (mut (ref null $type255)) (ref.null none))
 (global $global945 (mut (ref null $type256)) (ref.null none))
 (global $global948 (mut (ref null $type257)) (ref.null none))
 (global $global958 (mut (ref null $type244)) (ref.null none))
 (global $global963 (mut (ref null $type260)) (ref.null none))
 (global $global975 (mut (ref null $type262)) (ref.null none))
 (global $global980 (mut (ref null $type262)) (ref.null none))
 (global $global985 (mut (ref null $type264)) (ref.null none))
 (global $global990 (mut (ref null $type266)) (ref.null none))
 (global $global993 (mut (ref null $type267)) (ref.null none))
 (global $global998 (mut (ref null $type269)) (ref.null none))
 (global $global1199 (mut (ref null $type280)) (ref.null none))
 (global $global1018 (mut (ref null $type281)) (ref.null none))
 (global $global1033 (mut (ref null $type282)) (ref.null none))
 (global $global1047 (mut (ref null $type271)) (ref.null none))
 (global $global1052 (mut (ref null $type278)) (ref.null none))
 (global $global1057 (mut (ref null $type286)) (ref.null none))
 (global $global1096 (mut (ref null $type294)) (ref.null none))
 (global $global1117 (mut (ref null $type291)) (ref.null none))
 (global $global1122 (mut (ref null $type297)) (ref.null none))
 (global $global1154 (mut (ref null $type298)) (ref.null none))
 (global $global1156 (mut (ref null $type285)) (ref.null none))
 (global $ready1156 (mut i32) (i32.const 0))
 (global $global1194 (mut (ref null $type303)) (ref.null none))
 (global $global1211 (mut (ref null $type305)) (ref.null none))
 (global $global1218 (mut (ref null $type288)) (ref.null none))
 (global $ready1218 (mut i32) (i32.const 0))
 (global $global1243 (mut (ref null $type311)) (ref.null none))
 (global $global1258 (mut (ref null $type312)) (ref.null none))
 (global $global1263 (mut (ref null $type165)) (ref.null none))
 (global $global1275 (mut (ref null $type5)) (ref.null none))
 (global $ready1275 (mut i32) (i32.const 0))
 (global $global1276 (mut (ref null $type88)) (ref.null none))
 (global $ready1276 (mut i32) (i32.const 0))
 (global $string1 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 71)
  (array.new_fixed $type19 71
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
   (i32.const 59)
   (i32.const 32)
   (i32.const 114)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 44)
  (array.new_fixed $type19 44
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 44)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 105)
   (i32.const 109)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string8 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 16)
  (array.new_fixed $type19 16
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 45)
   (i32.const 115)
   (i32.const 112)
   (i32.const 108)
   (i32.const 105)
   (i32.const 99)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type19 10
   (i32.const 113)
   (i32.const 117)
   (i32.const 97)
   (i32.const 115)
   (i32.const 105)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string11 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 109)
   (i32.const 98)
   (i32.const 111)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string12 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string13 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 104)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 99)
   (i32.const 105)
   (i32.const 109)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string15 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 110)
   (i32.const 117)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string16 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 99)
   (i32.const 101)
   (i32.const 101)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 83)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
  )
  (ref.null none)
 ))
 (global $string17 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 35)
  )
  (ref.null none)
 ))
 (global $string18 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 108)
   (i32.const 97)
   (i32.const 98)
   (i32.const 101)
   (i32.const 108)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string19 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 32)
   (i32.const 100)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string20 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 108)
   (i32.const 111)
   (i32.const 99)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string21 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string22 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string23 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string24 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 25)
  (array.new_fixed $type19 25
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string25 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 116)
   (i32.const 97)
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string26 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string27 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string28 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string29 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string30 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string31 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string32 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 98)
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string33 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string34 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 22)
  (array.new_fixed $type19 22
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string35 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type19 31
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 117)
   (i32.const 56)
   (i32.const 40)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string36 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string37 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $string38 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 35)
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string39 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string40 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string41 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $string42 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 14)
  (array.new_fixed $type19 14
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string43 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 104)
   (i32.const 101)
   (i32.const 115)
   (i32.const 105)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string44 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 112)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 100)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string45 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 115)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string46 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 91)
   (i32.const 48)
   (i32.const 44)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
   (i32.const 93)
  )
  (ref.null none)
 ))
 (global $string47 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string48 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 36)
  (array.new_fixed $type19 36
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string49 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 33)
  (array.new_fixed $type19 33
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string50 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string51 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 117)
   (i32.const 110)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string52 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string53 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string54 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 77)
   (i32.const 97)
   (i32.const 122)
   (i32.const 101)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 103)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string55 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $empty43 (ref $type43) (struct.new_default $type43))
 (global $empty50 (ref $type50) (struct.new_default $type50))
 (global $empty114 (ref $type114) (struct.new $type114
  (i32.const 0)
 ))
 (global $empty123 (ref $type123) (struct.new $type123
  (i32.const 0)
 ))
 (global $empty170 (ref $type170) (struct.new $type170
  (i32.const 2)
 ))
 (global $empty207 (ref $type207) (struct.new $type207
  (i32.const 1)
 ))
 (global $empty208 (ref $type208) (struct.new $type208
  (i32.const 2)
 ))
 (global $empty209 (ref $type209) (struct.new $type209
  (i32.const 3)
 ))
 (global $empty225 (ref $type225) (struct.new $type225
  (i32.const 1)
 ))
 (global $empty301 (ref $type301) (struct.new_default $type301))
 (export "bench" (func $export0))
 (export "configured-count" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $152) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $150) (param $0 (ref $type18)) (param $1 i32) (result (ref $type19))
  (if (result (ref $type19))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type18 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type20
      (struct.get $type18 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy (type $149) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref $type18)) (param $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ne
     (local.get $1)
     (i64.const 0)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $4
     (local.get $7)
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $6
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $6)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $4
           (i32.sub
            (local.get $4)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $8
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $9
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (loop $label1
     (if
      (local.get $9)
      (then
       (local.set $4
        (select
         (local.get $9)
         (local.tee $4
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $5
              (i32.and
               (local.get $8)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $4
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $10)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.gt_u
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i32.gt_u
          (local.get $4)
          (local.get $9)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $8)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $5)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $10)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $10)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $4)
       )
       (local.set $8
        (i32.add
         (local.get $4)
         (local.get $8)
        )
       )
       (local.set $10
        (i32.add
         (local.get $4)
         (local.get $10)
        )
       )
       (local.set $9
        (i32.sub
         (local.get $9)
         (local.get $4)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function35 (type $call70) (param $0 (ref $type71)) (result (ref $type18))
  (local $1 (ref null $type71))
  (local $2 (ref null $type71))
  (local $3 (ref null $type71))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 i64)
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $6
   (if (result i64)
    (i64.gt_u
     (local.tee $6
      (i64.extend_i32_u
       (struct.get $type18 1
        (struct.get $type71 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type71 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $3
        (struct.get $type71 1
         (local.get $1)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $6
          (i64.add
           (i64.extend_i32_u
            (struct.get $type18 1
             (struct.get $type71 0
              (local.get $1)
             )
            )
           )
           (local.get $6)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $2
            (struct.get $type71 1
             (local.get $3)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $6
              (i64.add
               (i64.extend_i32_u
                (struct.get $type18 1
                 (struct.get $type71 0
                  (local.get $3)
                 )
                )
               )
               (local.get $6)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $1
                (struct.get $type71 1
                 (local.get $2)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $6
                  (i64.add
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (struct.get $type71 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $6)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type71 1
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $6
                      (i64.add
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (struct.get $type71 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $6)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $1
                        (struct.get $type71 1
                         (local.get $2)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $6
                          (i64.add
                           (i64.extend_i32_u
                            (struct.get $type18 1
                             (struct.get $type71 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $6)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $2
                            (struct.get $type71 1
                             (local.get $1)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $6
                              (i64.add
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (struct.get $type71 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.get $6)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $1
                                (struct.get $type71 1
                                 (local.get $2)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $6
                                  (i64.add
                                   (i64.extend_i32_u
                                    (struct.get $type18 1
                                     (struct.get $type71 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (call $function37
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type71 1
                                     (local.get $1)
                                    )
                                    (i64.add
                                     (i64.extend_i32_u
                                      (struct.get $type18 1
                                       (struct.get $type71 0
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (local.get $6)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-new
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (call $string-copy
   (local.get $5)
   (i64.const 0)
   (local.tee $4
    (struct.get $type71 0
     (local.get $0)
    )
   )
   (local.tee $7
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $4)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $1
      (struct.get $type71 1
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $string-copy
      (local.get $5)
      (local.get $7)
      (local.tee $4
       (struct.get $type71 0
        (local.get $1)
       )
      )
      (local.tee $6
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (struct.get $type71 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready98)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global98)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $string-copy
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
        (local.tee $4
         (struct.get $type71 0
          (local.get $1)
         )
        )
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $4)
          )
         )
        )
       )
       (local.set $1
        (struct.get $type71 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready98)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global98)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $string-copy
          (local.get $5)
          (local.tee $7
           (i64.add
            (local.get $6)
            (local.get $7)
           )
          )
          (local.tee $4
           (struct.get $type71 0
            (local.get $1)
           )
          )
          (local.tee $6
           (i64.extend_i32_u
            (struct.get $type18 1
             (local.get $4)
            )
           )
          )
         )
         (local.set $1
          (struct.get $type71 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready98)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global98)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $string-copy
            (local.get $5)
            (local.tee $7
             (i64.add
              (local.get $6)
              (local.get $7)
             )
            )
            (local.tee $4
             (struct.get $type71 0
              (local.get $1)
             )
            )
            (local.tee $6
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (struct.get $type71 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready98)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global98)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $string-copy
              (local.get $5)
              (local.tee $7
               (i64.add
                (local.get $6)
                (local.get $7)
               )
              )
              (local.tee $4
               (struct.get $type71 0
                (local.get $1)
               )
              )
              (local.tee $6
               (i64.extend_i32_u
                (struct.get $type18 1
                 (local.get $4)
                )
               )
              )
             )
             (local.set $1
              (struct.get $type71 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready98)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global98)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $string-copy
                (local.get $5)
                (local.tee $7
                 (i64.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (local.tee $4
                 (struct.get $type71 0
                  (local.get $1)
                 )
                )
                (local.tee $6
                 (i64.extend_i32_u
                  (struct.get $type18 1
                   (local.get $4)
                  )
                 )
                )
               )
               (local.set $1
                (struct.get $type71 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready98)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global98)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $string-copy
                  (local.get $5)
                  (local.tee $7
                   (i64.add
                    (local.get $6)
                    (local.get $7)
                   )
                  )
                  (local.tee $4
                   (struct.get $type71 0
                    (local.get $1)
                   )
                  )
                  (local.tee $6
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type71 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready98)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global98)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $string-copy
                    (local.get $5)
                    (local.tee $7
                     (i64.add
                      (local.get $6)
                      (local.get $7)
                     )
                    )
                    (local.tee $4
                     (struct.get $type71 0
                      (local.get $1)
                     )
                    )
                    (local.tee $6
                     (i64.extend_i32_u
                      (struct.get $type18 1
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type71 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready98)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global98)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $string-copy
                      (local.get $5)
                      (local.tee $7
                       (i64.add
                        (local.get $6)
                        (local.get $7)
                       )
                      )
                      (local.tee $4
                       (struct.get $type71 0
                        (local.get $1)
                       )
                      )
                      (local.tee $6
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type71 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready98)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global98)
                      )
                     )
                     (call $function38
                      (local.get $5)
                      (local.get $1)
                      (i64.add
                       (local.get $6)
                       (local.get $7)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function37 (type $146) (param $0 i32) (param $1 i32) (param $2 (ref null $type71)) (param $3 i64) (result i64)
  (local $4 (ref null $type71))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type71 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.extend_i32_u
        (struct.get $type18 1
         (struct.get $type71 0
          (local.get $2)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call73) (param $0 (ref $type18)) (param $1 (ref null $type71)) (param $2 i64) (result i32)
  (local $3 (ref $type18))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type71 0
       (local.get $1)
      )
     )
     (local.tee $4
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $3)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type71 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function40 (type $144) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function80 (type $call102) (param $0 (ref $type18)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local.set $1
   (call $foreign0)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (local.get $1)
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (local.get $1)
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (local.get $1)
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $2)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (local.get $1)
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $2)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (local.get $1)
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (local.get $1)
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (local.get $1)
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (local.get $1)
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (local.get $1)
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (local.get $1)
                       (array.get $type19
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function81
                       (local.get $0)
                       (local.get $1)
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function81 (type $142) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (local.get $1)
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function96 (type $141) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign12
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function96
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function97 (type $call112) (param $0 i32) (param $1 i32) (result (ref $type113))
  (local $2 i64)
  (if (result (ref $type113))
   (local.get $1)
   (then
    (if (result (ref $type113))
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (struct.new $type115
       (i32.const 1)
       (struct.new $type25
        (i32.const 0)
        (call $foreign9
         (local.get $0)
         (i32.const 0)
        )
       )
      )
     )
     (else
      (if (result (ref $type113))
       (i32.eq
        (local.get $1)
        (i32.const 2)
       )
       (then
        (drop
         (call $foreign8
          (local.get $0)
          (i32.const 0)
         )
        )
        (struct.new $type115
         (i32.const 1)
         (struct.new $type26
          (i32.const 1)
         )
        )
       )
       (else
        (if (result (ref $type113))
         (i32.eq
          (local.get $1)
          (i32.const 3)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global296)
           )
          )
          (drop
           (if (result (ref $type28))
            (i32.eq
             (call $foreign10
              (local.get $0)
              (i32.const 0)
             )
             (i32.const 1)
            )
            (then
             (drop
              (call $foreign9
               (local.get $0)
               (i32.const 0)
              )
             )
             (struct.new_default $type29)
            )
            (else
             (drop
              (call $foreign8
               (local.get $0)
               (i32.const 0)
              )
             )
             (struct.new_default $type30)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global296)
           )
          )
          (drop
           (if (result (ref $type28))
            (i32.eq
             (call $foreign10
              (local.get $0)
              (i32.const 1)
             )
             (i32.const 1)
            )
            (then
             (drop
              (call $foreign9
               (local.get $0)
               (i32.const 1)
              )
             )
             (struct.new_default $type29)
            )
            (else
             (drop
              (call $foreign8
               (local.get $0)
               (i32.const 1)
              )
             )
             (struct.new_default $type30)
            )
           )
          )
          (struct.new $type115
           (i32.const 1)
           (struct.new $type27
            (i32.const 2)
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global299)
           )
          )
          (struct.new $type116
           (i32.const 2)
           (call $function96
            (local.get $0)
            (local.tee $2
             (i64.extend_i32_s
              (call $foreign11
               (local.get $0)
              )
             )
            )
            (block (result (ref $type18))
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (if
              (i64.gt_u
               (local.get $2)
               (i64.const 4294967294)
              )
              (then
               (unreachable)
              )
             )
             (call $string-new
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (global.get $empty114)
   )
  )
 )
 (func $function107 (param $0 (ref $type13)) (param $1 (ref $type31)) (result (ref $type31))
  (local $2 i64)
  (drop
   (ref.as_non_null
    (global.get $global354)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global352)
   )
  )
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type47 0
      (global.get $global351)
     )
    )
    (i64.const 9223372036854775807)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global252)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global246)
     )
    )
    (call $foreign2
     (call $function80
      (global.get $string2)
     )
    )
    (unreachable)
   )
   (else
    (struct.set $type47 0
     (global.get $global351)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
  (struct.new $type31
   (i32.const 6)
   (struct.new $type32
    (local.get $0)
   )
   (struct.new $type32
    (local.get $1)
   )
  )
 )
 (func $function112 (type $call132) (param $0 (ref $type13)) (result i64)
  (local $1 i32)
  (if (result i64)
   (local.tee $1
    (struct.get $type13 0
     (local.get $0)
    )
   )
   (then
    (if (result i64)
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type15)
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i32.eq
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (drop
         (ref.cast (ref $type16)
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (drop
           (ref.cast (ref $type17)
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (drop
             (ref.cast (ref $type21)
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (drop
               (ref.cast (ref $type23)
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (drop
                 (ref.cast (ref $type31)
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (drop
                   (ref.cast (ref $type33)
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (else
                  (drop
                   (ref.cast (ref $type35)
                    (local.get $0)
                   )
                  )
                  (i64.const 8)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function143 (result i32)
  (local $0 (ref $type19))
  (local $1 (ref $type18))
  (call $foreign15)
  (call $foreign16
   (array.get $type19
    (struct.get $type18 2
     (local.tee $1
      (global.get $string55)
     )
    )
    (i32.const 0)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.tee $0
     (struct.get $type18 2
      (local.get $1)
     )
    )
    (i32.const 1)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.get $0)
    (i32.const 2)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.get $0)
    (i32.const 3)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.get $0)
    (i32.const 4)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.get $0)
    (i32.const 5)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.get $0)
    (i32.const 6)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.get $0)
    (i32.const 7)
   )
  )
  (call $foreign16
   (array.get $type19
    (local.get $0)
    (i32.const 8)
   )
  )
  (i32.const 0)
 )
 (func $function168 (type $call189) (param $0 (ref $type122)) (result (ref $type13))
  (local $1 (ref $type18))
  (local $scratch (ref $type18))
  (if (result (ref $type13))
   (i32.eq
    (struct.get $type122 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (struct.get $type124 1
     (ref.cast (ref $type124)
      (local.get $0)
     )
    )
   )
   (else
    (if
     (struct.get $type122 0
      (local.get $0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global90)
       )
      )
      (call $foreign2
       (call $function80
        (block (result (ref $type18))
         (local.set $scratch
          (call $function35
           (struct.new $type71
            (global.get $string4)
            (struct.new $type71
             (struct.get $type125 1
              (ref.cast (ref $type125)
               (local.get $0)
              )
             )
             (ref.null none)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global252)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global246)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global252)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global246)
       )
      )
      (call $foreign2
       (call $function80
        (global.get $string5)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function170 (type $call204) (param $0 (ref $type160)) (result (ref $type205))
  (local $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type172))
  (local $8 (ref $type113))
  (local $9 (ref $type197))
  (local $10 (ref $type122))
  (local $11 (ref $type223))
  (local $12 (ref $type205))
  (drop
   (ref.as_non_null
    (global.get $global620)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global560)
   )
  )
  (local.set $2
   (call $foreign22
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (block $block
   (return
    (if (result (ref $type207))
     (i64.lt_s
      (local.tee $1
       (if (result i64)
        (ref.test (ref $type173)
         (local.tee $7
          (if (result (ref $type172))
           (i32.eq
            (local.get $2)
            (i32.const -1)
           )
           (then
            (global.get $empty173)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $1
               (i64.extend_i32_s
                (local.get $2)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $1)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $1)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type174
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type174 0
           (ref.cast (ref $type174)
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (global.get $empty207)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global626)
       )
      )
      (br_if $block
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $1)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $1)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (i32.eq
          (call $foreign25
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 1)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global628)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 59)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global631)
         )
        )
        (drop
         (call $function175
          (local.get $0)
         )
        )
        (br $block)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready636)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global636)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global628)
         )
        )
        (return
         (if (result (ref $type205))
          (i64.eq
           (local.get $1)
           (i64.const 40)
          )
          (then
           (struct.new $type210
            (i32.const 4)
            (i64.const 0)
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global628)
            )
           )
           (if (result (ref $type205))
            (i64.eq
             (local.get $1)
             (i64.const 41)
            )
            (then
             (global.get $empty208)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global628)
              )
             )
             (if (result (ref $type205))
              (i64.eq
               (local.get $1)
               (i64.const 39)
              )
              (then
               (struct.new $type211
                (i32.const 5)
                (global.get $string10)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global628)
                )
               )
               (if (result (ref $type205))
                (i64.eq
                 (local.get $1)
                 (i64.const 96)
                )
                (then
                 (struct.new $type211
                  (i32.const 5)
                  (global.get $string9)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global628)
                  )
                 )
                 (if (result (ref $type205))
                  (i64.eq
                   (local.get $1)
                   (i64.const 44)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global639)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global642)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global562)
                    )
                   )
                   (local.set $2
                    (call $foreign23
                     (struct.get $type158 0
                      (struct.get $type160 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global558)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global622)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global628)
                    )
                   )
                   (struct.new $type211
                    (i32.const 5)
                    (select (result (ref $type18))
                     (global.get $string8)
                     (global.get $string7)
                     (if (result i32)
                      (i64.eq
                       (if (result i64)
                        (ref.test (ref $type173)
                         (local.tee $7
                          (if (result (ref $type172))
                           (i32.eq
                            (local.get $2)
                            (i32.const -1)
                           )
                           (then
                            (global.get $empty173)
                           )
                           (else
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (i64.extend_i32_s
                                (local.get $2)
                               )
                              )
                              (i64.const 1114111)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if
                             (i32.and
                              (i64.le_u
                               (local.get $1)
                               (i64.const 57343)
                              )
                              (i64.ge_u
                               (local.get $1)
                               (i64.const 55296)
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (struct.new $type174
                             (i32.wrap_i64
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type174 0
                           (ref.cast (ref $type174)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 64)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global560)
                        )
                       )
                       (local.set $2
                        (call $foreign22
                         (struct.get $type158 0
                          (struct.get $type160 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global558)
                        )
                       )
                       (drop
                        (if (result (ref $type172))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty173)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type174
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global628)
                    )
                   )
                   (if (result (ref $type212))
                    (i64.eq
                     (local.get $1)
                     (i64.const 34)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready644)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global644)
                      )
                     )
                     (return_call $function179
                      (local.get $0)
                      (i32.const 34)
                      (i32.const 0)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global628)
                      )
                     )
                     (if (result (ref $type212))
                      (i64.eq
                       (local.get $1)
                       (i64.const 124)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready644)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global644)
                        )
                       )
                       (return_call $function179
                        (local.get $0)
                        (i32.const 124)
                        (i32.const 1)
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global628)
                        )
                       )
                       (if (result (ref $type212))
                        (i64.eq
                         (local.get $1)
                         (i64.const 35)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready717)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global717)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global620)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global560)
                          )
                         )
                         (local.set $2
                          (call $foreign22
                           (struct.get $type158 0
                            (struct.get $type160 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global558)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global622)
                          )
                         )
                         (return
                          (if (result (ref $type205))
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type173)
                               (local.tee $7
                                (if (result (ref $type172))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty173)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type174
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type174 0
                                 (ref.cast (ref $type174)
                                  (local.get $7)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (struct.new $type212
                             (i32.const 6)
                             (global.get $string21)
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global628)
                             )
                            )
                            (if (result (ref $type205))
                             (i64.eq
                              (local.get $1)
                              (i64.const 40)
                             )
                             (then
                              (struct.new $type210
                               (i32.const 4)
                               (i64.const 1)
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global628)
                               )
                              )
                              (if (result (ref $type205))
                               (i64.eq
                                (local.get $1)
                                (i64.const 59)
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global720)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global615)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready617)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global617)
                                 )
                                )
                                (local.set $12
                                 (call $function170
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready792)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global792)
                                 )
                                )
                                (if (result (ref $type212))
                                 (i32.eq
                                  (struct.get $type122 0
                                   (local.tee $10
                                    (call $function212
                                     (local.get $0)
                                     (local.get $12)
                                    )
                                   )
                                  )
                                  (i32.const 1)
                                 )
                                 (then
                                  (drop
                                   (ref.cast (ref $type124)
                                    (local.get $10)
                                   )
                                  )
                                  (br $block)
                                 )
                                 (else
                                  (if (result (ref $type212))
                                   (struct.get $type122 0
                                    (local.get $10)
                                   )
                                   (then
                                    (struct.new $type212
                                     (i32.const 6)
                                     (struct.get $type125 1
                                      (ref.cast (ref $type125)
                                       (local.get $10)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (struct.new $type212
                                     (i32.const 6)
                                     (global.get $string22)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global628)
                                 )
                                )
                                (if (result (ref $type205))
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 124)
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global725)
                                   )
                                  )
                                  (if (result (ref $type212))
                                   (call $function198
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global617)
                                     )
                                    )
                                    (return_call $function170
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (struct.new $type212
                                     (i32.const 6)
                                     (global.get $string20)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global628)
                                   )
                                  )
                                  (if (result (ref $type205))
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 92)
                                   )
                                   (then
                                    (if
                                     (i32.eqz
                                      (global.get $ready730)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global730)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global620)
                                     )
                                    )
                                    (if (result (ref $type205))
                                     (i64.lt_s
                                      (local.tee $1
                                       (call $function171
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (struct.new $type212
                                       (i32.const 6)
                                       (global.get $string23)
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global733)
                                       )
                                      )
                                      (if (result (ref $type206))
                                       (call $function200
                                        (local.get $1)
                                       )
                                       (then
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type206
                                         (i32.const 0)
                                         (struct.new $type16
                                          (i32.const 2)
                                          (i32.wrap_i64
                                           (local.get $1)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global748)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global652)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global61)
                                         )
                                        )
                                        (local.set $9
                                         (struct.new $type197
                                          (struct.new $type198
                                           (call $string-new
                                            (i32.const 32)
                                           )
                                          )
                                          (struct.new_default $type47)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global701)
                                         )
                                        )
                                        (call $function193
                                         (local.get $9)
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $4
                                         (call $function202
                                          (local.get $0)
                                          (local.get $9)
                                          (i32.const 0)
                                          (i32.const 1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready753)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global753)
                                         )
                                        )
                                        (return
                                         (if (result (ref $type205))
                                          (i64.eq
                                           (local.tee $1
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $4)
                                             )
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (then
                                           (if
                                            (i64.eqz
                                             (local.get $1)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (struct.new $type206
                                            (i32.const 0)
                                            (struct.new $type16
                                             (i32.const 2)
                                             (array.get $type19
                                              (struct.get $type18 2
                                               (local.get $4)
                                              )
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global756)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global88)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global81)
                                            )
                                           )
                                           (local.set $4
                                            (call $function205
                                             (if (result (ref $type18))
                                              (i64.lt_s
                                               (local.tee $1
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $4)
                                                 )
                                                )
                                               )
                                               (local.get $1)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global61)
                                                )
                                               )
                                               (if
                                                (i64.gt_u
                                                 (local.get $1)
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (call $string-copy
                                                (local.tee $5
                                                 (call $string-new
                                                  (i32.wrap_i64
                                                   (local.get $1)
                                                  )
                                                 )
                                                )
                                                (i64.const 0)
                                                (local.get $4)
                                                (local.get $1)
                                               )
                                               (local.get $5)
                                              )
                                             )
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.const 0)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready762)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global762)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global103)
                                            )
                                           )
                                           (if (result (ref $type205))
                                            (struct.get $type223 0
                                             (local.tee $11
                                              (if (result (ref $type223))
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 5)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string33)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                               (then
                                                (struct.new $type224
                                                 (i32.const 0)
                                                 (i32.const 7)
                                                )
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global103)
                                                 )
                                                )
                                                (if (result (ref $type223))
                                                 (if (result i32)
                                                  (i64.eq
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (local.get $4)
                                                    )
                                                   )
                                                   (i64.const 9)
                                                  )
                                                  (then
                                                   (call $function40
                                                    (local.get $4)
                                                    (global.get $string32)
                                                    (i32.const 0)
                                                    (i32.const 1)
                                                    (i64.const 0)
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                 (then
                                                  (struct.new $type224
                                                   (i32.const 0)
                                                   (i32.const 8)
                                                  )
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global103)
                                                   )
                                                  )
                                                  (if (result (ref $type223))
                                                   (if (result i32)
                                                    (i64.eq
                                                     (i64.extend_i32_u
                                                      (struct.get $type18 1
                                                       (local.get $4)
                                                      )
                                                     )
                                                     (i64.const 6)
                                                    )
                                                    (then
                                                     (call $function40
                                                      (local.get $4)
                                                      (global.get $string31)
                                                      (i32.const 0)
                                                      (i32.const 1)
                                                      (i64.const 0)
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                   (then
                                                    (struct.new $type224
                                                     (i32.const 0)
                                                     (i32.const 127)
                                                    )
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global103)
                                                     )
                                                    )
                                                    (if (result (ref $type223))
                                                     (if (result i32)
                                                      (i64.eq
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (i64.const 6)
                                                      )
                                                      (then
                                                       (call $function40
                                                        (local.get $4)
                                                        (global.get $string30)
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (i64.const 0)
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                     (then
                                                      (struct.new $type224
                                                       (i32.const 0)
                                                       (i32.const 27)
                                                      )
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global103)
                                                       )
                                                      )
                                                      (if (result (ref $type223))
                                                       (if (result i32)
                                                        (i64.eq
                                                         (i64.extend_i32_u
                                                          (struct.get $type18 1
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (i64.const 7)
                                                        )
                                                        (then
                                                         (call $function40
                                                          (local.get $4)
                                                          (global.get $string29)
                                                          (i32.const 0)
                                                          (i32.const 1)
                                                          (i64.const 0)
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                       (then
                                                        (struct.new $type224
                                                         (i32.const 0)
                                                         (i32.const 10)
                                                        )
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global103)
                                                         )
                                                        )
                                                        (if (result (ref $type223))
                                                         (if (result i32)
                                                          (i64.eq
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (local.get $4)
                                                            )
                                                           )
                                                           (i64.const 4)
                                                          )
                                                          (then
                                                           (call $function40
                                                            (local.get $4)
                                                            (global.get $string28)
                                                            (i32.const 0)
                                                            (i32.const 1)
                                                            (i64.const 0)
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                         (then
                                                          (struct.new_default $type224)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global103)
                                                           )
                                                          )
                                                          (if (result (ref $type223))
                                                           (if (result i32)
                                                            (i64.eq
                                                             (i64.extend_i32_u
                                                              (struct.get $type18 1
                                                               (local.get $4)
                                                              )
                                                             )
                                                             (i64.const 6)
                                                            )
                                                            (then
                                                             (call $function40
                                                              (local.get $4)
                                                              (global.get $string27)
                                                              (i32.const 0)
                                                              (i32.const 1)
                                                              (i64.const 0)
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                           (then
                                                            (struct.new $type224
                                                             (i32.const 0)
                                                             (i32.const 13)
                                                            )
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global103)
                                                             )
                                                            )
                                                            (if (result (ref $type223))
                                                             (if (result i32)
                                                              (i64.eq
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (local.get $4)
                                                                )
                                                               )
                                                               (i64.const 5)
                                                              )
                                                              (then
                                                               (call $function40
                                                                (local.get $4)
                                                                (global.get $string26)
                                                                (i32.const 0)
                                                                (i32.const 1)
                                                                (i64.const 0)
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                             (then
                                                              (struct.new $type224
                                                               (i32.const 0)
                                                               (i32.const 32)
                                                              )
                                                             )
                                                             (else
                                                              (drop
                                                               (ref.as_non_null
                                                                (global.get $global103)
                                                               )
                                                              )
                                                              (if (result (ref $type223))
                                                               (if (result i32)
                                                                (i64.eq
                                                                 (i64.extend_i32_u
                                                                  (struct.get $type18 1
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                 (i64.const 3)
                                                                )
                                                                (then
                                                                 (call $function40
                                                                  (local.get $4)
                                                                  (global.get $string25)
                                                                  (i32.const 0)
                                                                  (i32.const 1)
                                                                  (i64.const 0)
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                               (then
                                                                (struct.new $type224
                                                                 (i32.const 0)
                                                                 (i32.const 9)
                                                                )
                                                               )
                                                               (else
                                                                (if
                                                                 (i64.eqz
                                                                  (i64.extend_i32_u
                                                                   (struct.get $type18 1
                                                                    (local.get $4)
                                                                   )
                                                                  )
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (if (result (ref $type223))
                                                                 (i32.eq
                                                                  (array.get $type19
                                                                   (struct.get $type18 2
                                                                    (local.get $4)
                                                                   )
                                                                   (i32.const 0)
                                                                  )
                                                                  (i32.const 120)
                                                                 )
                                                                 (then
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global764)
                                                                   )
                                                                  )
                                                                  (call $function208
                                                                   (local.get $4)
                                                                   (i32.const 0)
                                                                   (i32.const 1)
                                                                   (i64.const 1)
                                                                   (i64.const 0)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (struct.new $type226
                                                                   (i32.const 2)
                                                                   (global.get $string24)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (if (result (ref $type212))
                                              (i32.eq
                                               (struct.get $type223 0
                                                (local.get $11)
                                               )
                                               (i32.const 2)
                                              )
                                              (then
                                               (struct.new $type212
                                                (i32.const 6)
                                                (struct.get $type226 1
                                                 (ref.cast (ref $type226)
                                                  (local.get $11)
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (unreachable)
                                              )
                                             )
                                            )
                                            (else
                                             (struct.new $type206
                                              (i32.const 0)
                                              (struct.new $type16
                                               (i32.const 2)
                                               (struct.get $type224 1
                                                (ref.cast (ref $type224)
                                                 (local.get $11)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global628)
                                     )
                                    )
                                    (if (result (ref $type205))
                                     (if (result i32)
                                      (local.tee $2
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 117)
                                       )
                                      )
                                      (then
                                       (local.get $2)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global628)
                                        )
                                       )
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 85)
                                       )
                                      )
                                     )
                                     (then
                                      (if
                                       (i32.eqz
                                        (global.get $ready774)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global774)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global639)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global642)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global562)
                                       )
                                      )
                                      (local.set $2
                                       (call $foreign23
                                        (struct.get $type158 0
                                         (struct.get $type160 0
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global558)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global622)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global628)
                                       )
                                      )
                                      (if (result (ref $type205))
                                       (if (result i32)
                                        (if (result i32)
                                         (i64.eq
                                          (if (result i64)
                                           (ref.test (ref $type173)
                                            (local.tee $7
                                             (if (result (ref $type172))
                                              (i32.eq
                                               (local.get $2)
                                               (i32.const -1)
                                              )
                                              (then
                                               (global.get $empty173)
                                              )
                                              (else
                                               (if
                                                (i64.gt_u
                                                 (local.tee $1
                                                  (i64.extend_i32_s
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (i64.const 1114111)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if
                                                (i32.and
                                                 (i64.le_u
                                                  (local.get $1)
                                                  (i64.const 57343)
                                                 )
                                                 (i64.ge_u
                                                  (local.get $1)
                                                  (i64.const 55296)
                                                 )
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (struct.new $type174
                                                (i32.wrap_i64
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i64.const -1)
                                           )
                                           (else
                                            (i64.extend_i32_u
                                             (struct.get $type174 0
                                              (ref.cast (ref $type174)
                                               (local.get $7)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 56)
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global560)
                                           )
                                          )
                                          (local.set $2
                                           (call $foreign22
                                            (struct.get $type158 0
                                             (struct.get $type160 0
                                              (local.get $0)
                                             )
                                            )
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global558)
                                           )
                                          )
                                          (drop
                                           (if (result (ref $type172))
                                            (i32.eq
                                             (local.get $2)
                                             (i32.const -1)
                                            )
                                            (then
                                             (global.get $empty173)
                                            )
                                            (else
                                             (if
                                              (i64.gt_u
                                               (local.tee $1
                                                (i64.extend_i32_s
                                                 (local.get $2)
                                                )
                                               )
                                               (i64.const 1114111)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.and
                                               (i64.le_u
                                                (local.get $1)
                                                (i64.const 57343)
                                               )
                                               (i64.ge_u
                                                (local.get $1)
                                                (i64.const 55296)
                                               )
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (struct.new $type174
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i32.const 1)
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                        (then
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global639)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global642)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global562)
                                          )
                                         )
                                         (local.set $2
                                          (call $foreign23
                                           (struct.get $type158 0
                                            (struct.get $type160 0
                                             (local.get $0)
                                            )
                                           )
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global558)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global622)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global628)
                                          )
                                         )
                                         (if (result i32)
                                          (i64.eq
                                           (if (result i64)
                                            (ref.test (ref $type173)
                                             (local.tee $7
                                              (if (result (ref $type172))
                                               (i32.eq
                                                (local.get $2)
                                                (i32.const -1)
                                               )
                                               (then
                                                (global.get $empty173)
                                               )
                                               (else
                                                (if
                                                 (i64.gt_u
                                                  (local.tee $1
                                                   (i64.extend_i32_s
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i64.const 1114111)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (if
                                                 (i32.and
                                                  (i64.le_u
                                                   (local.get $1)
                                                   (i64.const 57343)
                                                  )
                                                  (i64.ge_u
                                                   (local.get $1)
                                                   (i64.const 55296)
                                                  )
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (struct.new $type174
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (i64.const -1)
                                            )
                                            (else
                                             (i64.extend_i32_u
                                              (struct.get $type174 0
                                               (ref.cast (ref $type174)
                                                (local.get $7)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i64.const 40)
                                          )
                                          (then
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global560)
                                            )
                                           )
                                           (local.set $2
                                            (call $foreign22
                                             (struct.get $type158 0
                                              (struct.get $type160 0
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global558)
                                            )
                                           )
                                           (drop
                                            (if (result (ref $type172))
                                             (i32.eq
                                              (local.get $2)
                                              (i32.const -1)
                                             )
                                             (then
                                              (global.get $empty173)
                                             )
                                             (else
                                              (if
                                               (i64.gt_u
                                                (local.tee $1
                                                 (i64.extend_i32_s
                                                  (local.get $2)
                                                 )
                                                )
                                                (i64.const 1114111)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (if
                                               (i32.and
                                                (i64.le_u
                                                 (local.get $1)
                                                 (i64.const 57343)
                                                )
                                                (i64.ge_u
                                                 (local.get $1)
                                                 (i64.const 55296)
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (struct.new $type174
                                               (i32.wrap_i64
                                                (local.get $1)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i32.const 1)
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                       (then
                                        (struct.new $type210
                                         (i32.const 4)
                                         (i64.const 2)
                                        )
                                       )
                                       (else
                                        (struct.new $type212
                                         (i32.const 6)
                                         (global.get $string35)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global628)
                                       )
                                      )
                                      (if (result (ref $type205))
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 33)
                                       )
                                       (then
                                        (struct.new $type212
                                         (i32.const 6)
                                         (global.get $string19)
                                        )
                                       )
                                       (else
                                        (if (result (ref $type205))
                                         (i32.and
                                          (i64.le_s
                                           (local.get $1)
                                           (i64.const 57)
                                          )
                                          (i64.ge_s
                                           (local.get $1)
                                           (i64.const 48)
                                          )
                                         )
                                         (then
                                          (struct.new $type212
                                           (i32.const 6)
                                           (global.get $string18)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global748)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global652)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (local.set $9
                                           (struct.new $type197
                                            (struct.new $type198
                                             (call $string-new
                                              (i32.const 32)
                                             )
                                            )
                                            (struct.new_default $type47)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.get $1)
                                            (i64.const 1114111)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (if
                                           (i32.and
                                            (i64.le_u
                                             (local.get $1)
                                             (i64.const 57343)
                                            )
                                            (i64.ge_u
                                             (local.get $1)
                                             (i64.const 55296)
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global701)
                                           )
                                          )
                                          (call $function193
                                           (local.get $9)
                                           (i32.wrap_i64
                                            (local.get $1)
                                           )
                                          )
                                          (local.set $4
                                           (call $function202
                                            (local.get $0)
                                            (local.get $9)
                                            (i32.const 0)
                                            (i32.const 1)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global90)
                                           )
                                          )
                                          (local.set $5
                                           (call $function35
                                            (struct.new $type71
                                             (global.get $string17)
                                             (struct.new $type71
                                              (local.get $4)
                                              (ref.null none)
                                             )
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready776)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global776)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global756)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global88)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global81)
                                           )
                                          )
                                          (local.set $4
                                           (call $function205
                                            (if (result (ref $type18))
                                             (i64.lt_s
                                              (local.tee $1
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                              (local.get $1)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global61)
                                               )
                                              )
                                              (if
                                               (i64.gt_u
                                                (local.get $1)
                                                (i64.const 4294967294)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (call $string-copy
                                               (local.tee $6
                                                (call $string-new
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (i64.const 0)
                                               (local.get $5)
                                               (local.get $1)
                                              )
                                              (local.get $6)
                                             )
                                            )
                                            (i32.const 0)
                                            (i32.const 1)
                                            (i64.const 0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global103)
                                           )
                                          )
                                          (if (result (ref $type205))
                                           (if (result i32)
                                            (local.tee $2
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 2)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string39)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                            (then
                                             (local.get $2)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global103)
                                              )
                                             )
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 5)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string40)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (struct.new $type206
                                             (i32.const 0)
                                             (struct.new $type15
                                              (i32.const 1)
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global103)
                                             )
                                            )
                                            (if (result (ref $type205))
                                             (if (result i32)
                                              (local.tee $2
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 2)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string37)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                              (then
                                               (local.get $2)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global103)
                                                )
                                               )
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 6)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string38)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (struct.new $type206
                                               (i32.const 0)
                                               (struct.new $type15
                                                (i32.const 1)
                                                (i32.const 0)
                                               )
                                              )
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global308)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global246)
                                               )
                                              )
                                              (local.set $3
                                               (call $foreign13
                                                (local.tee $2
                                                 (call $function80
                                                  (local.get $5)
                                                 )
                                                )
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global305)
                                               )
                                              )
                                              (local.set $8
                                               (call $function97
                                                (local.get $2)
                                                (local.get $3)
                                               )
                                              )
                                              (call $foreign4
                                               (local.get $2)
                                              )
                                              (if (result (ref $type205))
                                               (i32.eq
                                                (struct.get $type113 0
                                                 (local.get $8)
                                                )
                                                (i32.const 1)
                                               )
                                               (then
                                                (struct.new $type206
                                                 (i32.const 0)
                                                 (struct.new $type23
                                                  (i32.const 5)
                                                  (struct.get $type115 1
                                                   (ref.cast (ref $type115)
                                                    (local.get $8)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (if (result (ref $type212))
                                                 (i32.eq
                                                  (struct.get $type113 0
                                                   (local.get $8)
                                                  )
                                                  (i32.const 2)
                                                 )
                                                 (then
                                                  (struct.new $type212
                                                   (i32.const 6)
                                                   (struct.get $type116 1
                                                    (ref.cast (ref $type116)
                                                     (local.get $8)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (struct.new $type212
                                                   (i32.const 6)
                                                   (global.get $string36)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global628)
                          )
                         )
                         (if (result (ref $type212))
                          (if (result i32)
                           (local.tee $2
                            (i64.eq
                             (local.get $1)
                             (i64.const 91)
                            )
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global628)
                             )
                            )
                            (if (result i32)
                             (local.tee $2
                              (i64.eq
                               (local.get $1)
                               (i64.const 93)
                              )
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global628)
                               )
                              )
                              (if (result i32)
                               (local.tee $2
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 123)
                                )
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global628)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 125)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (struct.new $type212
                            (i32.const 6)
                            (global.get $string6)
                           )
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global748)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global652)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global61)
                            )
                           )
                           (local.set $9
                            (struct.new $type197
                             (struct.new $type198
                              (call $string-new
                               (i32.const 32)
                              )
                             )
                             (struct.new_default $type47)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.get $1)
                             (i64.const 1114111)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.and
                             (i64.le_u
                              (local.get $1)
                              (i64.const 57343)
                             )
                             (i64.ge_u
                              (local.get $1)
                              (i64.const 55296)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global701)
                            )
                           )
                           (call $function193
                            (local.get $9)
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                           (local.set $4
                            (call $function202
                             (local.get $0)
                             (local.get $9)
                             (i32.const 0)
                             (i32.const 1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready787)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global787)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global103)
                            )
                           )
                           (return
                            (if (result (ref $type205))
                             (if (result i32)
                              (i64.eq
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                               (i64.const 1)
                              )
                              (then
                               (call $function40
                                (local.get $4)
                                (global.get $string41)
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                             (then
                              (global.get $empty209)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global347)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global246)
                               )
                              )
                              (if (result (ref $type205))
                               (i32.eq
                                (struct.get $type122 0
                                 (local.tee $10
                                  (if (result (ref $type122))
                                   (local.tee $3
                                    (call $foreign13
                                     (local.tee $2
                                      (call $function80
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global340)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global305)
                                     )
                                    )
                                    (local.set $8
                                     (call $function97
                                      (local.get $2)
                                      (local.get $3)
                                     )
                                    )
                                    (call $foreign4
                                     (local.get $2)
                                    )
                                    (if (result (ref $type122))
                                     (i32.eq
                                      (struct.get $type113 0
                                       (local.get $8)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (struct.new $type124
                                       (i32.const 1)
                                       (struct.new $type23
                                        (i32.const 5)
                                        (struct.get $type115 1
                                         (ref.cast (ref $type115)
                                          (local.get $8)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (if (result (ref $type125))
                                       (i32.eq
                                        (struct.get $type113 0
                                         (local.get $8)
                                        )
                                        (i32.const 2)
                                       )
                                       (then
                                        (struct.new $type125
                                         (i32.const 2)
                                         (struct.get $type116 1
                                          (ref.cast (ref $type116)
                                           (local.get $8)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (unreachable)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (if (result (ref $type122))
                                     (i32.eq
                                      (call $foreign3
                                       (local.get $2)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (drop
                                       (call $foreign5
                                        (local.get $2)
                                       )
                                      )
                                      (struct.new $type124
                                       (i32.const 1)
                                       (struct.new $type21
                                        (i32.const 4)
                                       )
                                      )
                                     )
                                     (else
                                      (call $foreign4
                                       (local.get $2)
                                      )
                                      (struct.new $type125
                                       (i32.const 2)
                                       (global.get $string1)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (i32.const 1)
                               )
                               (then
                                (struct.new $type206
                                 (i32.const 0)
                                 (struct.get $type124 1
                                  (ref.cast (ref $type124)
                                   (local.get $10)
                                  )
                                 )
                                )
                               )
                               (else
                                (if (result (ref $type212))
                                 (i32.eq
                                  (struct.get $type122 0
                                   (local.get $10)
                                  )
                                  (i32.const 2)
                                 )
                                 (then
                                  (struct.new $type212
                                   (i32.const 6)
                                   (struct.get $type125 1
                                    (ref.cast (ref $type125)
                                     (local.get $10)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (unreachable)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (unreachable)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready617)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global617)
   )
  )
  (return_call $function170
   (local.get $0)
  )
 )
 (func $function171 (type $call192) (param $0 (ref $type160)) (result i64)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type172))
  (drop
   (ref.as_non_null
    (global.get $global560)
   )
  )
  (local.set $2
   (call $foreign22
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (if (result i64)
   (ref.test (ref $type173)
    (local.tee $3
     (if (result (ref $type172))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty173)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type174
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (i64.const -1)
   )
   (else
    (i64.extend_i32_u
     (struct.get $type174 0
      (ref.cast (ref $type174)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function175 (type $call162) (param $0 (ref $type160)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local $3 (ref $type172))
  (drop
   (ref.as_non_null
    (global.get $global620)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global560)
   )
  )
  (local.set $1
   (call $foreign22
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $1
     (i64.lt_s
      (local.tee $2
       (if (result i64)
        (ref.test (ref $type173)
         (local.tee $3
          (if (result (ref $type172))
           (i32.eq
            (local.get $1)
            (i32.const -1)
           )
           (then
            (global.get $empty173)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $1)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type174
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type174 0
           (ref.cast (ref $type174)
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global628)
      )
     )
     (if (result i32)
      (local.tee $1
       (i64.eq
        (local.get $2)
        (i64.const 10)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global628)
        )
       )
       (i64.eq
        (local.get $2)
        (i64.const 13)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready631)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global631)
     )
    )
    (return_call $function175
     (local.get $0)
    )
   )
  )
 )
 (func $function179 (type $call215) (param $0 (ref $type160)) (param $1 i32) (param $2 i32) (result (ref $type205))
  (local $3 (ref $type217))
  (local $4 (ref $type197))
  (local $5 (ref $type18))
  (if
   (i32.eqz
    (global.get $ready649)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global649)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global652)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $4
   (struct.new $type197
    (struct.new $type198
     (call $string-new
      (i32.const 32)
     )
    )
    (struct.new_default $type47)
   )
  )
  (if
   (i32.eqz
    (global.get $ready653)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global653)
   )
  )
  (if (result (ref $type205))
   (ref.test (ref $type218)
    (local.tee $3
     (call $function182
      (local.get $0)
      (local.get $1)
      (local.get $4)
     )
    )
   )
   (then
    (local.set $5
     (struct.get $type218 0
      (ref.cast (ref $type218)
       (local.get $3)
      )
     )
    )
    (struct.new $type206
     (i32.const 0)
     (if (result (ref $type13))
      (local.get $2)
      (then
       (drop
        (ref.as_non_null
         (global.get $global258)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global246)
        )
       )
       (drop
        (call $foreign5
         (call $function80
          (local.get $5)
         )
        )
       )
       (struct.new $type21
        (i32.const 4)
       )
      )
      (else
       (struct.new $type17
        (i32.const 3)
       )
      )
     )
    )
   )
   (else
    (struct.new $type212
     (i32.const 6)
     (struct.get $type219 0
      (ref.cast (ref $type219)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function182 (type $call220) (param $0 (ref $type160)) (param $1 i32) (param $2 (ref $type197)) (result (ref $type217))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type172))
  (local $6 (ref $type223))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global620)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global560)
   )
  )
  (local.set $4
   (call $foreign22
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (block $block
   (return
    (if (result (ref $type217))
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type173)
         (local.tee $5
          (if (result (ref $type172))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty173)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $3)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $3)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type174
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type174 0
           (ref.cast (ref $type174)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (struct.new $type219
       (global.get $string11)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global628)
       )
      )
      (if (result (ref $type217))
       (i64.eq
        (i64.extend_i32_u
         (local.get $1)
        )
        (local.get $3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global658)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global81)
         )
        )
        (local.set $7
         (struct.get $type198 0
          (struct.get $type197 0
           (local.get $2)
          )
         )
        )
        (struct.new $type218
         (if (result (ref $type18))
          (if (result i32)
           (local.tee $1
            (i64.lt_s
             (local.tee $3
              (struct.get $type47 0
               (struct.get $type197 1
                (local.get $2)
               )
              )
             )
             (i64.const 0)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (i64.lt_s
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $7)
              )
             )
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global61)
            )
           )
           (if
            (i64.gt_u
             (local.get $3)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
           )
           (call $string-copy
            (local.tee $8
             (call $string-new
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 0)
            (local.get $7)
            (local.get $3)
           )
           (local.get $8)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global628)
         )
        )
        (if (result (ref $type219))
         (i64.eq
          (local.get $3)
          (i64.const 92)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready660)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global660)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global620)
           )
          )
          (local.set $3
           (call $function171
            (local.get $0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global628)
           )
          )
          (local.set $6
           (if (result (ref $type223))
            (i64.eq
             (local.get $3)
             (i64.const 97)
            )
            (then
             (struct.new $type224
              (i32.const 0)
              (i32.const 7)
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global628)
              )
             )
             (if (result (ref $type223))
              (i64.eq
               (local.get $3)
               (i64.const 98)
              )
              (then
               (struct.new $type224
                (i32.const 0)
                (i32.const 8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global628)
                )
               )
               (if (result (ref $type223))
                (i64.eq
                 (local.get $3)
                 (i64.const 116)
                )
                (then
                 (struct.new $type224
                  (i32.const 0)
                  (i32.const 9)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global628)
                  )
                 )
                 (if (result (ref $type223))
                  (i64.eq
                   (local.get $3)
                   (i64.const 110)
                  )
                  (then
                   (struct.new $type224
                    (i32.const 0)
                    (i32.const 10)
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global628)
                    )
                   )
                   (if (result (ref $type223))
                    (i64.eq
                     (local.get $3)
                     (i64.const 114)
                    )
                    (then
                     (struct.new $type224
                      (i32.const 0)
                      (i32.const 13)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global628)
                      )
                     )
                     (if (result (ref $type223))
                      (if (result i32)
                       (local.tee $4
                        (i64.eq
                         (local.get $3)
                         (i64.const 34)
                        )
                       )
                       (then
                        (local.get $4)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global628)
                         )
                        )
                        (if (result i32)
                         (local.tee $4
                          (i64.eq
                           (local.get $3)
                           (i64.const 124)
                          )
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global628)
                           )
                          )
                          (i64.eq
                           (local.get $3)
                           (i64.const 92)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $3)
                         (i64.const 1114111)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.and
                         (i64.le_u
                          (local.get $3)
                          (i64.const 57343)
                         )
                         (i64.ge_u
                          (local.get $3)
                          (i64.const 55296)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (struct.new $type224
                        (i32.const 0)
                        (i32.wrap_i64
                         (local.get $3)
                        )
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global628)
                        )
                       )
                       (if (result (ref $type223))
                        (i64.eq
                         (local.get $3)
                         (i64.const 120)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready666)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global666)
                          )
                         )
                         (call $function185
                          (local.get $0)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (else
                         (if (result (ref $type223))
                          (if (result i32)
                           (i32.eq
                            (local.get $1)
                            (i32.const 34)
                           )
                           (then
                            (if
                             (i32.eqz
                              (global.get $ready681)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global681)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global628)
                             )
                            )
                            (if (result i32)
                             (local.tee $4
                              (i64.eq
                               (local.get $3)
                               (i64.const 32)
                              )
                             )
                             (then
                              (local.get $4)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global628)
                               )
                              )
                              (if (result i32)
                               (local.tee $4
                                (i64.eq
                                 (local.get $3)
                                 (i64.const 9)
                                )
                               )
                               (then
                                (local.get $4)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global628)
                                 )
                                )
                                (if (result i32)
                                 (local.tee $4
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 10)
                                  )
                                 )
                                 (then
                                  (local.get $4)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global628)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                          (then
                           (if
                            (i32.eqz
                             (global.get $ready686)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global686)
                            )
                           )
                           (call $function190
                            (local.get $0)
                            (local.get $3)
                           )
                          )
                          (else
                           (struct.new $type226
                            (i32.const 2)
                            (global.get $string12)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready694)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global694)
           )
          )
          (if (result (ref $type219))
           (local.tee $4
            (struct.get $type223 0
             (local.get $6)
            )
           )
           (then
            (if (result (ref $type219))
             (i32.eq
              (local.get $4)
              (i32.const 1)
             )
             (then
              (br $block)
             )
             (else
              (struct.new $type219
               (struct.get $type226 1
                (ref.cast (ref $type226)
                 (local.get $6)
                )
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global701)
             )
            )
            (call $function193
             (local.get $2)
             (struct.get $type224 1
              (ref.cast (ref $type224)
               (local.get $6)
              )
             )
            )
            (br $block)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready711)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global711)
           )
          )
          (local.set $4
           (if (result i32)
            (if (result i32)
             (i32.eq
              (local.get $1)
              (i32.const 34)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global628)
               )
              )
              (i64.eq
               (local.get $3)
               (i64.const 13)
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global639)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global642)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global562)
              )
             )
             (local.set $4
              (call $foreign23
               (struct.get $type158 0
                (struct.get $type160 0
                 (local.get $0)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global558)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global622)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global628)
              )
             )
             (if
              (i64.eq
               (if (result i64)
                (ref.test (ref $type173)
                 (local.tee $5
                  (if (result (ref $type172))
                   (i32.eq
                    (local.get $4)
                    (i32.const -1)
                   )
                   (then
                    (global.get $empty173)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (i64.extend_i32_s
                        (local.get $4)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $3)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $3)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (struct.new $type174
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type174 0
                   (ref.cast (ref $type174)
                    (local.get $5)
                   )
                  )
                 )
                )
               )
               (i64.const 10)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global560)
                )
               )
               (local.set $4
                (call $foreign22
                 (struct.get $type158 0
                  (struct.get $type160 0
                   (local.get $0)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global558)
                )
               )
               (drop
                (if (result (ref $type172))
                 (i32.eq
                  (local.get $4)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty173)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.extend_i32_s
                      (local.get $4)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $3)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $3)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type174
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 10)
            )
            (else
             (if
              (i64.gt_u
               (local.get $3)
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $3)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $3)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global701)
           )
          )
          (call $function193
           (local.get $2)
           (local.get $4)
          )
          (if
           (i32.eqz
            (global.get $ready653)
           )
           (then
            (unreachable)
           )
          )
          (br $block)
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global653)
   )
  )
  (return_call $function182
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $function185 (type $call230) (param $0 (ref $type160)) (param $1 i64) (param $2 i64) (result (ref $type223))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type172))
  (drop
   (ref.as_non_null
    (global.get $global620)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global560)
   )
  )
  (local.set $4
   (call $foreign22
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global628)
   )
  )
  (if (result (ref $type223))
   (i64.eq
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type173)
       (local.tee $5
        (if (result (ref $type172))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty173)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $3)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $3)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type174
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type174 0
         (ref.cast (ref $type174)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 59)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global671)
     )
    )
    (if (result (ref $type223))
     (if (result i32)
      (i64.gt_s
       (local.get $2)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global674)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $4
             (i64.lt_s
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (local.get $4)
            )
            (else
             (i64.gt_s
              (local.get $1)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $1)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $1)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type224
       (i32.const 0)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (else
      (struct.new $type226
       (i32.const 2)
       (global.get $string14)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global678)
     )
    )
    (if (result (ref $type226))
     (if (result i32)
      (local.tee $4
       (i64.lt_s
        (local.tee $3
         (if (result i64)
          (i32.and
           (i64.le_s
            (local.get $3)
            (i64.const 57)
           )
           (i64.ge_s
            (local.get $3)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $3)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_s
              (local.get $3)
              (i64.const 70)
             )
             (i64.ge_s
              (local.get $3)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $3)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $3)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_s
                (local.get $3)
                (i64.const 102)
               )
               (i64.ge_s
                (local.get $3)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.gt_s
        (local.get $1)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type226
       (i32.const 2)
       (global.get $string13)
      )
     )
     (else
      (if
       (i32.eqz
        (global.get $ready666)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global666)
       )
      )
      (return_call $function185
       (local.get $0)
       (i64.add
        (local.get $3)
        (i64.shl
         (local.get $1)
         (i64.const 4)
        )
       )
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function190 (type $call228) (param $0 (ref $type160)) (param $1 i64) (result (ref $type223))
  (local $2 i32)
  (local $3 (ref $type172))
  (drop
   (ref.as_non_null
    (global.get $global628)
   )
  )
  (if (result (ref $type223))
   (if (result i32)
    (local.tee $2
     (i64.eq
      (local.get $1)
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global628)
      )
     )
     (i64.eq
      (local.get $1)
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global620)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global560)
     )
    )
    (local.set $2
     (call $foreign22
      (struct.get $type158 0
       (struct.get $type160 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global558)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global622)
     )
    )
    (local.set $1
     (if (result i64)
      (ref.test (ref $type173)
       (local.tee $3
        (if (result (ref $type172))
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
         (then
          (global.get $empty173)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $1
             (i64.extend_i32_s
              (local.get $2)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type174
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type174 0
         (ref.cast (ref $type174)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready686)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global686)
     )
    )
    (return_call $function190
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global628)
     )
    )
    (if (result (ref $type223))
     (if (result i32)
      (local.tee $2
       (i64.eq
        (local.get $1)
        (i64.const 10)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global628)
        )
       )
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global628)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global639)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global642)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global562)
         )
        )
        (local.set $2
         (call $foreign23
          (struct.get $type158 0
           (struct.get $type160 0
            (local.get $0)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global558)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global622)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global628)
         )
        )
        (if
         (i64.eq
          (if (result i64)
           (ref.test (ref $type173)
            (local.tee $3
             (if (result (ref $type172))
              (i32.eq
               (local.get $2)
               (i32.const -1)
              )
              (then
               (global.get $empty173)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $1
                  (i64.extend_i32_s
                   (local.get $2)
                  )
                 )
                 (i64.const 1114111)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.and
                 (i64.le_u
                  (local.get $1)
                  (i64.const 57343)
                 )
                 (i64.ge_u
                  (local.get $1)
                  (i64.const 55296)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (struct.new $type174
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (then
            (i64.const -1)
           )
           (else
            (i64.extend_i32_u
             (struct.get $type174 0
              (ref.cast (ref $type174)
               (local.get $3)
              )
             )
            )
           )
          )
          (i64.const 10)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global560)
           )
          )
          (local.set $2
           (call $foreign22
            (struct.get $type158 0
             (struct.get $type160 0
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global558)
           )
          )
          (drop
           (if (result (ref $type172))
            (i32.eq
             (local.get $2)
             (i32.const -1)
            )
            (then
             (global.get $empty173)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $1
                (i64.extend_i32_s
                 (local.get $2)
                )
               )
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $1)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $1)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (struct.new $type174
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global691)
       )
      )
      (drop
       (call $function191
        (local.get $0)
       )
      )
      (global.get $empty225)
     )
     (else
      (struct.new $type226
       (i32.const 2)
       (global.get $string15)
      )
     )
    )
   )
  )
 )
 (func $function191 (type $call162) (param $0 (ref $type160)) (result i32)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type172))
  (drop
   (ref.as_non_null
    (global.get $global642)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global562)
   )
  )
  (local.set $2
   (call $foreign23
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global628)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $2
     (i64.eq
      (if (result i64)
       (ref.test (ref $type173)
        (local.tee $3
         (if (result (ref $type172))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty173)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type174
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type174 0
          (ref.cast (ref $type174)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global642)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global562)
      )
     )
     (local.set $2
      (call $foreign23
       (struct.get $type158 0
        (struct.get $type160 0
         (local.get $0)
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global558)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global622)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global628)
      )
     )
     (i64.eq
      (if (result i64)
       (ref.test (ref $type173)
        (local.tee $3
         (if (result (ref $type172))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty173)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type174
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type174 0
          (ref.cast (ref $type174)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global560)
     )
    )
    (local.set $2
     (call $foreign22
      (struct.get $type158 0
       (struct.get $type160 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global558)
     )
    )
    (drop
     (if (result (ref $type172))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty173)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type174
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready691)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global691)
     )
    )
    (return_call $function191
     (local.get $0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function193 (type $97) (param $0 (ref $type197)) (param $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type198))
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type47 0
      (struct.get $type197 1
       (local.get $0)
      )
     )
    )
    (i64.extend_i32_u
     (struct.get $type18 1
      (struct.get $type198 0
       (struct.get $type197 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready705)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global705)
     )
    )
    (if
     (i64.ge_s
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global252)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global246)
       )
      )
      (call $foreign2
       (call $function80
        (global.get $string16)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (select
          (i64.const 4294967294)
          (i64.shl
           (local.get $2)
           (i64.const 1)
          )
          (i64.gt_s
           (local.get $2)
           (i64.const 2147483647)
          )
         )
        )
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $6
        (call $string-new
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i64.const 0)
       (struct.get $type198 0
        (local.tee $7
         (struct.get $type197 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
      (struct.set $type198 0
       (local.get $7)
       (local.get $6)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.tee $5
      (struct.get $type198 0
       (struct.get $type197 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $4
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $5)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $5)
       )
       (i32.sub
        (i32.shr_u
         (local.get $4)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $4)
    (i32.const 8191)
   )
   (local.get $1)
  )
  (struct.set $type47 0
   (struct.get $type197 1
    (local.get $0)
   )
   (i64.add
    (local.get $2)
    (i64.const 1)
   )
  )
 )
 (func $function198 (type $call203) (param $0 (ref $type160)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type172))
  (drop
   (ref.as_non_null
    (global.get $global620)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global560)
   )
  )
  (local.set $4
   (call $foreign22
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (if (result i32)
   (i64.lt_s
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type173)
       (local.tee $5
        (if (result (ref $type172))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty173)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $2
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $2)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $2)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type174
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type174 0
         (ref.cast (ref $type174)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global628)
     )
    )
    (if (result i32)
     (if (result i32)
      (i64.eq
       (local.get $3)
       (i64.const 35)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global639)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global642)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global562)
        )
       )
       (local.set $4
        (call $foreign23
         (struct.get $type158 0
          (struct.get $type160 0
           (local.get $0)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global558)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global622)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global628)
        )
       )
       (if (result i32)
        (i64.eq
         (if (result i64)
          (ref.test (ref $type173)
           (local.tee $5
            (if (result (ref $type172))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty173)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type174
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (i64.extend_i32_u
            (struct.get $type174 0
             (ref.cast (ref $type174)
              (local.get $5)
             )
            )
           )
          )
         )
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global560)
          )
         )
         (local.set $4
          (call $foreign22
           (struct.get $type158 0
            (struct.get $type160 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global558)
          )
         )
         (drop
          (if (result (ref $type172))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty173)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type174
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
         (i32.const 1)
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready725)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global725)
       )
      )
      (return_call $function198
       (local.get $0)
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global628)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (local.get $3)
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global639)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global642)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global562)
          )
         )
         (local.set $4
          (call $foreign23
           (struct.get $type158 0
            (struct.get $type160 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global558)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global622)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global628)
          )
         )
         (if (result i32)
          (i64.eq
           (if (result i64)
            (ref.test (ref $type173)
             (local.tee $5
              (if (result (ref $type172))
               (i32.eq
                (local.get $4)
                (i32.const -1)
               )
               (then
                (global.get $empty173)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $2
                   (i64.extend_i32_s
                    (local.get $4)
                   )
                  )
                  (i64.const 1114111)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i64.le_u
                   (local.get $2)
                   (i64.const 57343)
                  )
                  (i64.ge_u
                   (local.get $2)
                   (i64.const 55296)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (struct.new $type174
                 (i32.wrap_i64
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
            (then
             (i64.const -1)
            )
            (else
             (i64.extend_i32_u
              (struct.get $type174 0
               (ref.cast (ref $type174)
                (local.get $5)
               )
              )
             )
            )
           )
           (i64.const 35)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global560)
            )
           )
           (local.set $4
            (call $foreign22
             (struct.get $type158 0
              (struct.get $type160 0
               (local.get $0)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global558)
            )
           )
           (drop
            (if (result (ref $type172))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty173)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type174
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
           (i32.const 1)
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (if (result i32)
         (local.tee $4
          (i64.eq
           (local.get $1)
           (i64.const 1)
          )
         )
         (then
          (local.get $4)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready725)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global725)
           )
          )
          (return_call $function198
           (local.get $0)
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready725)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global725)
         )
        )
        (return_call $function198
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function200 (type $call195) (param $0 i64) (result i32)
  (local $1 i32)
  (if (result i32)
   (local.tee $1
    (i64.lt_s
     (local.get $0)
     (i64.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global626)
     )
    )
    (if (result i32)
     (local.tee $1
      (if (result i32)
       (i64.ge_s
        (local.get $0)
        (i64.const 0)
       )
       (then
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 1114111)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.and
          (i64.le_u
           (local.get $0)
           (i64.const 57343)
          )
          (i64.ge_u
           (local.get $0)
           (i64.const 55296)
          )
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (call $foreign25
          (i32.wrap_i64
           (local.get $0)
          )
         )
         (i32.const 1)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global628)
       )
      )
      (if (result i32)
       (local.tee $1
        (i64.eq
         (local.get $0)
         (i64.const 40)
        )
       )
       (then
        (local.get $1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global628)
         )
        )
        (if (result i32)
         (local.tee $1
          (i64.eq
           (local.get $0)
           (i64.const 41)
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global628)
           )
          )
          (if (result i32)
           (local.tee $1
            (i64.eq
             (local.get $0)
             (i64.const 34)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global628)
             )
            )
            (if (result i32)
             (local.tee $1
              (i64.eq
               (local.get $0)
               (i64.const 59)
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global628)
               )
              )
              (if (result i32)
               (local.tee $1
                (i64.eq
                 (local.get $0)
                 (i64.const 124)
                )
               )
               (then
                (local.get $1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global628)
                 )
                )
                (if (result i32)
                 (local.tee $1
                  (i64.eq
                   (local.get $0)
                   (i64.const 39)
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global628)
                   )
                  )
                  (if (result i32)
                   (local.tee $1
                    (i64.eq
                     (local.get $0)
                     (i64.const 96)
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global628)
                     )
                    )
                    (if (result i32)
                     (local.tee $1
                      (i64.eq
                       (local.get $0)
                       (i64.const 44)
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global628)
                       )
                      )
                      (if (result i32)
                       (local.tee $1
                        (i64.eq
                         (local.get $0)
                         (i64.const 91)
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global628)
                         )
                        )
                        (if (result i32)
                         (local.tee $1
                          (i64.eq
                           (local.get $0)
                           (i64.const 93)
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global628)
                           )
                          )
                          (if (result i32)
                           (local.tee $1
                            (i64.eq
                             (local.get $0)
                             (i64.const 123)
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global628)
                             )
                            )
                            (i64.eq
                             (local.get $0)
                             (i64.const 125)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function202 (type $94) (param $0 (ref $type160)) (param $1 (ref $type197)) (param $2 i32) (param $3 i32) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type172))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global642)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global562)
   )
  )
  (local.set $5
   (call $foreign23
    (struct.get $type158 0
     (struct.get $type160 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global558)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global622)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global733)
   )
  )
  (if (result (ref $type18))
   (call $function200
    (if (result i64)
     (ref.test (ref $type173)
      (local.tee $6
       (if (result (ref $type172))
        (i32.eq
         (local.get $5)
         (i32.const -1)
        )
        (then
         (global.get $empty173)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $4
            (i64.extend_i32_s
             (local.get $5)
            )
           )
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $4)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $4)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type174
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.extend_i32_u
       (struct.get $type174 0
        (ref.cast (ref $type174)
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global658)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (local.set $7
     (struct.get $type198 0
      (struct.get $type197 0
       (local.get $1)
      )
     )
    )
    (if (result (ref $type18))
     (if (result i32)
      (local.tee $2
       (i64.lt_s
        (local.tee $4
         (struct.get $type47 0
          (struct.get $type197 1
           (local.get $1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (i64.lt_s
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $7)
         )
        )
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $8
        (call $string-new
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i64.const 0)
       (local.get $7)
       (local.get $4)
      )
      (local.get $8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global620)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global560)
     )
    )
    (local.set $5
     (call $foreign22
      (struct.get $type158 0
       (struct.get $type160 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global558)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global622)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (if (result i64)
        (ref.test (ref $type173)
         (local.tee $6
          (if (result (ref $type172))
           (i32.eq
            (local.get $5)
            (i32.const -1)
           )
           (then
            (global.get $empty173)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $4
               (i64.extend_i32_s
                (local.get $5)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $4)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $4)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type174
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type174 0
           (ref.cast (ref $type174)
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $4)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $4)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global701)
     )
    )
    (call $function193
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function202
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function205 (type $93) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (if (result (ref $type18))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.ge_u
       (local.tee $4
        (i64.extend_i32_u
         (array.get $type19
          (if (result (ref $type19))
           (i32.lt_u
            (local.tee $5
             (i32.wrap_i64
              (local.get $3)
             )
            )
            (i32.const 8192)
           )
           (then
            (struct.get $type18 2
             (local.get $0)
            )
           )
           (else
            (ref.as_non_null
             (array.get $type20
              (struct.get $type18 3
               (local.get $0)
              )
              (i32.sub
               (i32.shr_u
                (local.get $5)
                (i32.const 13)
               )
               (i32.const 1)
              )
             )
            )
           )
          )
          (i32.and
           (local.get $5)
           (i32.const 8191)
          )
         )
        )
       )
       (i64.const 65)
      )
      (then
       (i64.le_u
        (local.get $4)
        (i64.const 90)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $4
         (i64.add
          (local.get $4)
          (i64.const 32)
         )
        )
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $0)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ge_u
        (local.get $3)
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function205
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function208 (type $92) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type223))
  (local $5 i64)
  (local $6 i32)
  (if (result (ref $type223))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global671)
     )
    )
    (if (result (ref $type223))
     (if (result i32)
      (i64.gt_s
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global674)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $4)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $4)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $1
             (i64.lt_s
              (local.get $4)
              (i64.const 55296)
             )
            )
            (then
             (local.get $1)
            )
            (else
             (i64.gt_s
              (local.get $4)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type224
       (i32.const 0)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (else
      (struct.new $type226
       (i32.const 2)
       (global.get $string14)
      )
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global678)
     )
    )
    (if (result (ref $type226))
     (if (result i32)
      (local.tee $6
       (i64.lt_s
        (local.tee $5
         (if (result i64)
          (i32.and
           (i64.le_u
            (local.tee $5
             (i64.extend_i32_u
              (array.get $type19
               (if (result (ref $type19))
                (i32.lt_u
                 (local.tee $6
                  (i32.wrap_i64
                   (local.get $3)
                  )
                 )
                 (i32.const 8192)
                )
                (then
                 (struct.get $type18 2
                  (local.get $0)
                 )
                )
                (else
                 (ref.as_non_null
                  (array.get $type20
                   (struct.get $type18 3
                    (local.get $0)
                   )
                   (i32.sub
                    (i32.shr_u
                     (local.get $6)
                     (i32.const 13)
                    )
                    (i32.const 1)
                   )
                  )
                 )
                )
               )
               (i32.and
                (local.get $6)
                (i32.const 8191)
               )
              )
             )
            )
            (i64.const 57)
           )
           (i64.ge_u
            (local.get $5)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $5)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_u
              (local.get $5)
              (i64.const 70)
             )
             (i64.ge_u
              (local.get $5)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $5)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $5)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_u
                (local.get $5)
                (i64.const 102)
               )
               (i64.ge_u
                (local.get $5)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $6)
      )
      (else
       (i64.gt_s
        (local.get $4)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type226
       (i32.const 2)
       (global.get $string34)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function208
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (i64.shl
         (local.get $4)
         (i64.const 4)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function212 (type $call232) (param $0 (ref $type160)) (param $1 (ref $type205)) (result (ref $type122))
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type122))
  (local $5 (ref $type18))
  (local $6 (ref $type13))
  (local $7 (ref $type31))
  (block $block
   (return
    (if (result (ref $type122))
     (local.tee $3
      (struct.get $type205 0
       (local.get $1)
      )
     )
     (then
      (if (result (ref $type122))
       (i32.eq
        (local.get $3)
        (i32.const 1)
       )
       (then
        (global.get $empty123)
       )
       (else
        (if (result (ref $type122))
         (i32.eq
          (struct.get $type205 0
           (local.get $1)
          )
          (i32.const 6)
         )
         (then
          (struct.new $type125
           (i32.const 2)
           (struct.get $type212 1
            (ref.cast (ref $type212)
             (local.get $1)
            )
           )
          )
         )
         (else
          (if (result (ref $type122))
           (i32.eq
            (struct.get $type205 0
             (local.get $1)
            )
            (i32.const 4)
           )
           (then
            (local.set $2
             (struct.get $type210 1
              (ref.cast (ref $type210)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready799)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global799)
             )
            )
            (return_call $function213
             (local.get $0)
             (local.get $2)
             (ref.null none)
            )
           )
           (else
            (if (result (ref $type122))
             (i32.eq
              (struct.get $type205 0
               (local.get $1)
              )
              (i32.const 5)
             )
             (then
              (local.set $5
               (struct.get $type211 1
                (ref.cast (ref $type211)
                 (local.get $1)
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready870)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global870)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global615)
               )
              )
              (if
               (i32.eqz
                (global.get $ready617)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global617)
               )
              )
              (local.set $1
               (call $function170
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (global.get $ready792)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global792)
               )
              )
              (if (result (ref $type122))
               (i32.eq
                (struct.get $type122 0
                 (local.tee $4
                  (call $function212
                   (local.get $0)
                   (local.get $1)
                  )
                 )
                )
                (i32.const 1)
               )
               (then
                (local.set $6
                 (struct.get $type124 1
                  (ref.cast (ref $type124)
                   (local.get $4)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global258)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global246)
                 )
                )
                (drop
                 (call $foreign5
                  (call $function80
                   (local.get $5)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global359)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global354)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global352)
                 )
                )
                (br_if $block
                 (i64.eq
                  (local.tee $2
                   (struct.get $type47 0
                    (global.get $global351)
                   )
                  )
                  (i64.const 9223372036854775807)
                 )
                )
                (struct.set $type47 0
                 (global.get $global351)
                 (i64.add
                  (local.get $2)
                  (i64.const 1)
                 )
                )
                (local.set $7
                 (struct.new $type31
                  (i32.const 6)
                  (struct.new $type32
                   (local.get $6)
                  )
                  (struct.new $type32
                   (global.get $empty14)
                  )
                 )
                )
                (br_if $block
                 (i64.eq
                  (local.tee $2
                   (struct.get $type47 0
                    (global.get $global351)
                   )
                  )
                  (i64.const 9223372036854775807)
                 )
                )
                (struct.set $type47 0
                 (global.get $global351)
                 (i64.add
                  (local.get $2)
                  (i64.const 1)
                 )
                )
                (struct.new $type124
                 (i32.const 1)
                 (struct.new $type31
                  (i32.const 6)
                  (struct.new $type32
                   (struct.new $type21
                    (i32.const 4)
                   )
                  )
                  (struct.new $type32
                   (local.get $7)
                  )
                 )
                )
               )
               (else
                (if (result (ref $type125))
                 (struct.get $type122 0
                  (local.get $4)
                 )
                 (then
                  (struct.new $type125
                   (i32.const 2)
                   (struct.get $type125 1
                    (ref.cast (ref $type125)
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (else
                  (struct.new $type125
                   (i32.const 2)
                   (global.get $string53)
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type125))
               (i32.eq
                (struct.get $type205 0
                 (local.get $1)
                )
                (i32.const 2)
               )
               (then
                (struct.new $type125
                 (i32.const 2)
                 (global.get $string43)
                )
               )
               (else
                (struct.new $type125
                 (i32.const 2)
                 (global.get $string42)
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type124
       (i32.const 1)
       (struct.get $type206 1
        (ref.cast (ref $type206)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global252)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (call $foreign2
   (call $function80
    (global.get $string2)
   )
  )
  (unreachable)
 )
 (func $function213 (type $90) (param $0 (ref $type160)) (param $1 i64) (param $2 (ref null $type12)) (result (ref $type122))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type31))
  (local $6 (ref $type12))
  (local $7 (ref $type13))
  (local $8 (ref $type205))
  (local $9 (ref $type34))
  (local $10 (ref $type32))
  (local $11 (ref $type122))
  (local $12 (ref $type14))
  (local $13 i32)
  (local $scratch (ref $type31))
  (local $scratch_15 (ref $type31))
  (drop
   (ref.as_non_null
    (global.get $global617)
   )
  )
  (block $block
   (return
    (if (result (ref $type122))
     (i32.eq
      (struct.get $type205 0
       (local.tee $8
        (call $function170
         (local.get $0)
        )
       )
      )
      (i32.const 2)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready805)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global805)
       )
      )
      (if (result (ref $type124))
       (i64.eqz
        (local.get $1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global808)
         )
        )
        (local.set $12
         (global.get $empty14)
        )
        (struct.new $type124
         (i32.const 1)
         (if (result (ref $type13))
          (ref.is_null
           (local.get $2)
          )
          (then
           (local.get $12)
          )
          (else
           (local.set $4
            (struct.get $type12 1
             (local.get $2)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global359)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global354)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global352)
            )
           )
           (local.set $10
            (struct.new $type32
             (struct.get $type12 0
              (local.get $2)
             )
            )
           )
           (br_if $block
            (i64.eq
             (local.tee $1
              (struct.get $type47 0
               (global.get $global351)
              )
             )
             (i64.const 9223372036854775807)
            )
           )
           (struct.set $type47 0
            (global.get $global351)
            (i64.add
             (local.get $1)
             (i64.const 1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready808)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global808)
            )
           )
           (local.set $5
            (struct.new $type31
             (i32.const 6)
             (local.get $10)
             (struct.new $type32
              (local.get $12)
             )
            )
           )
           (if (result (ref $type13))
            (ref.is_null
             (local.get $4)
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $3
              (struct.get $type12 1
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global359)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global354)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global352)
              )
             )
             (local.set $10
              (struct.new $type32
               (struct.get $type12 0
                (local.get $4)
               )
              )
             )
             (br_if $block
              (i64.eq
               (local.tee $1
                (struct.get $type47 0
                 (global.get $global351)
                )
               )
               (i64.const 9223372036854775807)
              )
             )
             (struct.set $type47 0
              (global.get $global351)
              (i64.add
               (local.get $1)
               (i64.const 1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready808)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global808)
              )
             )
             (local.set $5
              (struct.new $type31
               (i32.const 6)
               (local.get $10)
               (struct.new $type32
                (local.get $5)
               )
              )
             )
             (if (result (ref $type13))
              (ref.is_null
               (local.get $3)
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $4
                (struct.get $type12 1
                 (local.get $3)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global359)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global354)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global352)
                )
               )
               (local.set $10
                (struct.new $type32
                 (struct.get $type12 0
                  (local.get $3)
                 )
                )
               )
               (br_if $block
                (i64.eq
                 (local.tee $1
                  (struct.get $type47 0
                   (global.get $global351)
                  )
                 )
                 (i64.const 9223372036854775807)
                )
               )
               (struct.set $type47 0
                (global.get $global351)
                (i64.add
                 (local.get $1)
                 (i64.const 1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready808)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global808)
                )
               )
               (local.set $5
                (struct.new $type31
                 (i32.const 6)
                 (local.get $10)
                 (struct.new $type32
                  (local.get $5)
                 )
                )
               )
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $3
                  (struct.get $type12 1
                   (local.get $4)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global359)
                  )
                 )
                 (local.set $7
                  (struct.get $type12 0
                   (local.get $4)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global354)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global352)
                  )
                 )
                 (br_if $block
                  (i64.eq
                   (local.tee $1
                    (struct.get $type47 0
                     (global.get $global351)
                    )
                   )
                   (i64.const 9223372036854775807)
                  )
                 )
                 (struct.set $type47 0
                  (global.get $global351)
                  (i64.add
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready808)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global808)
                  )
                 )
                 (local.set $5
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (local.get $7)
                   )
                   (struct.new $type32
                    (local.get $5)
                   )
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $4
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global359)
                    )
                   )
                   (local.set $7
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global354)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global352)
                    )
                   )
                   (br_if $block
                    (i64.eq
                     (local.tee $1
                      (struct.get $type47 0
                       (global.get $global351)
                      )
                     )
                     (i64.const 9223372036854775807)
                    )
                   )
                   (struct.set $type47 0
                    (global.get $global351)
                    (i64.add
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready808)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global808)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (local.get $7)
                     )
                     (struct.new $type32
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global359)
                      )
                     )
                     (local.set $7
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global354)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global352)
                      )
                     )
                     (br_if $block
                      (i64.eq
                       (local.tee $1
                        (struct.get $type47 0
                         (global.get $global351)
                        )
                       )
                       (i64.const 9223372036854775807)
                      )
                     )
                     (struct.set $type47 0
                      (global.get $global351)
                      (i64.add
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready808)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global808)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (struct.new $type32
                        (local.get $7)
                       )
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $4
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global359)
                        )
                       )
                       (local.set $7
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global354)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global352)
                        )
                       )
                       (br_if $block
                        (i64.eq
                         (local.tee $1
                          (struct.get $type47 0
                           (global.get $global351)
                          )
                         )
                         (i64.const 9223372036854775807)
                        )
                       )
                       (struct.set $type47 0
                        (global.get $global351)
                        (i64.add
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready808)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global808)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (struct.new $type32
                          (local.get $7)
                         )
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $3
                          (struct.get $type12 1
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global359)
                          )
                         )
                         (local.set $7
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global354)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global352)
                          )
                         )
                         (if
                          (i64.eq
                           (local.tee $1
                            (struct.get $type47 0
                             (global.get $global351)
                            )
                           )
                           (i64.const 9223372036854775807)
                          )
                          (then
                           (br $block)
                          )
                          (else
                           (struct.set $type47 0
                            (global.get $global351)
                            (i64.add
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready808)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global808)
                          )
                         )
                         (local.set $5
                          (struct.new $type31
                           (i32.const 6)
                           (struct.new $type32
                            (local.get $7)
                           )
                           (struct.new $type32
                            (local.get $5)
                           )
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (call $function215
                            (struct.get $type12 1
                             (local.get $3)
                            )
                            (block (result (ref $type31))
                             (drop
                              (ref.as_non_null
                               (global.get $global359)
                              )
                             )
                             (local.set $scratch
                              (call $function107
                               (struct.get $type12 0
                                (local.get $3)
                               )
                               (local.get $5)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready808)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global808)
                              )
                             )
                             (local.get $scratch)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (else
        (if (result (ref $type124))
         (i64.eq
          (local.get $1)
          (i64.const 1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global811)
           )
          )
          (local.set $4
           (if (result (ref null $type12))
            (ref.is_null
             (local.get $2)
            )
            (then
             (ref.null none)
            )
            (else
             (local.set $6
              (struct.new $type12
               (struct.get $type12 0
                (local.get $2)
               )
               (ref.null none)
              )
             )
             (if (result (ref null $type12))
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $6
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $3)
                 )
                 (local.get $6)
                )
               )
               (if (result (ref null $type12))
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (local.get $6)
                )
                (else
                 (local.set $6
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $3)
                   )
                   (local.get $6)
                  )
                 )
                 (if (result (ref null $type12))
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $6
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $3)
                     )
                     (local.get $6)
                    )
                   )
                   (if (result (ref null $type12))
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (local.get $6)
                    )
                    (else
                     (local.set $6
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $3)
                       )
                       (local.get $6)
                      )
                     )
                     (if (result (ref null $type12))
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $6
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $3)
                         )
                         (local.get $6)
                        )
                       )
                       (if (result (ref null $type12))
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (local.get $6)
                        )
                        (else
                         (local.set $6
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (local.get $6)
                          )
                         )
                         (if (result (ref null $type12))
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $6
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $3)
                             )
                             (local.get $6)
                            )
                           )
                           (if (result (ref null $type12))
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (local.get $6)
                            )
                            (else
                             (call $function217
                              (i32.const 0)
                              (i32.const 1)
                              (struct.get $type12 1
                               (local.get $3)
                              )
                              (struct.new $type12
                               (struct.get $type12 0
                                (local.get $3)
                               )
                               (local.get $6)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global816)
           )
          )
          (drop
           (if (result (ref $type34))
            (ref.is_null
             (local.get $4)
            )
            (then
             (array.new_fixed $type34 0)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready819)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global819)
              )
             )
             (if
              (i64.gt_u
               (local.tee $1
                (if (result i64)
                 (ref.is_null
                  (local.get $4)
                 )
                 (then
                  (i64.const 0)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $3
                     (struct.get $type12 1
                      (local.get $4)
                     )
                    )
                   )
                   (then
                    (i64.const 1)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $3
                       (struct.get $type12 1
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (i64.const 2)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $3
                         (struct.get $type12 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (i64.const 3)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $3
                           (struct.get $type12 1
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (i64.const 4)
                         )
                         (else
                          (if (result i64)
                           (ref.is_null
                            (local.tee $3
                             (struct.get $type12 1
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (i64.const 5)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $3
                               (struct.get $type12 1
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (i64.const 6)
                             )
                             (else
                              (if (result i64)
                               (ref.is_null
                                (local.tee $3
                                 (struct.get $type12 1
                                  (local.get $3)
                                 )
                                )
                               )
                               (then
                                (i64.const 7)
                               )
                               (else
                                (call $function220
                                 (i32.const 0)
                                 (i32.const 1)
                                 (struct.get $type12 1
                                  (local.get $3)
                                 )
                                 (i64.const 8)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (local.set $9
              (array.new $type34
               (struct.get $type12 0
                (local.get $4)
               )
               (i32.wrap_i64
                (local.get $1)
               )
              )
             )
             (if (result (ref $type34))
              (ref.is_null
               (local.get $4)
              )
              (then
               (local.get $9)
              )
              (else
               (array.set $type34
                (local.get $9)
                (i32.const 0)
                (struct.get $type12 0
                 (local.get $4)
                )
               )
               (if (result (ref $type34))
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $4)
                  )
                 )
                )
                (then
                 (local.get $9)
                )
                (else
                 (array.set $type34
                  (local.get $9)
                  (i32.const 1)
                  (struct.get $type12 0
                   (local.get $3)
                  )
                 )
                 (if (result (ref $type34))
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (local.get $9)
                  )
                  (else
                   (array.set $type34
                    (local.get $9)
                    (i32.const 2)
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (if (result (ref $type34))
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (local.get $9)
                    )
                    (else
                     (array.set $type34
                      (local.get $9)
                      (i32.const 3)
                      (struct.get $type12 0
                       (local.get $3)
                      )
                     )
                     (if (result (ref $type34))
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (local.get $9)
                      )
                      (else
                       (array.set $type34
                        (local.get $9)
                        (i32.const 4)
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (if (result (ref $type34))
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (local.get $9)
                        )
                        (else
                         (array.set $type34
                          (local.get $9)
                          (i32.const 5)
                          (struct.get $type12 0
                           (local.get $3)
                          )
                         )
                         (if (result (ref $type34))
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (local.get $9)
                          )
                          (else
                           (array.set $type34
                            (local.get $9)
                            (i32.const 6)
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (if (result (ref $type34))
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (local.get $9)
                            )
                            (else
                             (array.set $type34
                              (local.get $9)
                              (i32.const 7)
                              (struct.get $type12 0
                               (local.get $3)
                              )
                             )
                             (if (result (ref $type34))
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (local.get $9)
                              )
                              (else
                               (array.set $type34
                                (local.get $9)
                                (i32.const 8)
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (call $function221
                                (local.get $9)
                                (i32.const 0)
                                (i32.const 1)
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                                (i64.const 9)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global357)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global352)
           )
          )
          (br_if $block
           (i64.eq
            (local.tee $1
             (struct.get $type47 0
              (global.get $global351)
             )
            )
            (i64.const 9223372036854775807)
           )
          )
          (struct.set $type47 0
           (global.get $global351)
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (struct.new $type124
           (i32.const 1)
           (struct.new $type33
            (i32.const 7)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready827)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global827)
           )
          )
          (local.set $1
           (if (result i64)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i64.const 0)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $2)
                )
               )
              )
              (then
               (i64.const 1)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 2)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 3)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 4)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 5)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 6)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 7)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 8)
                            )
                            (else
                             (call $function223
                              (i32.const 0)
                              (i32.const 1)
                              (struct.get $type12 1
                               (local.get $3)
                              )
                              (i64.const 9)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global109)
           )
          )
          (if
           (i64.gt_u
            (local.get $1)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready833)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global833)
           )
          )
          (return_call $function224
           (local.get $2)
           (struct.new $type36
            (array.new_default $type37
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (local.get $1)
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type122))
       (i32.eq
        (struct.get $type205 0
         (local.get $8)
        )
        (i32.const 1)
       )
       (then
        (struct.new $type125
         (i32.const 2)
         (global.get $string45)
        )
       )
       (else
        (if (result (ref $type122))
         (i32.eq
          (struct.get $type205 0
           (local.get $8)
          )
          (i32.const 3)
         )
         (then
          (if (result (ref $type122))
           (i32.and
            (i32.eqz
             (ref.is_null
              (local.get $2)
             )
            )
            (i64.eqz
             (local.get $1)
            )
           )
           (then
            (if
             (i32.eqz
              (global.get $ready846)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global846)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global615)
             )
            )
            (if
             (i32.eqz
              (global.get $ready617)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global617)
             )
            )
            (local.set $8
             (call $function170
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready792)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global792)
             )
            )
            (if (result (ref $type122))
             (i32.eq
              (struct.get $type122 0
               (local.tee $11
                (call $function212
                 (local.get $0)
                 (local.get $8)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (local.set $7
               (struct.get $type124 1
                (ref.cast (ref $type124)
                 (local.get $11)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global617)
               )
              )
              (if (result (ref $type122))
               (i32.eq
                (struct.get $type205 0
                 (local.tee $8
                  (call $function170
                   (local.get $0)
                  )
                 )
                )
                (i32.const 2)
               )
               (then
                (if
                 (i32.eqz
                  (global.get $ready808)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global808)
                 )
                )
                (struct.new $type124
                 (i32.const 1)
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (local.get $7)
                  )
                  (else
                   (local.set $4
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global359)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global354)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global352)
                    )
                   )
                   (local.set $10
                    (struct.new $type32
                     (struct.get $type12 0
                      (local.get $2)
                     )
                    )
                   )
                   (br_if $block
                    (i64.eq
                     (local.tee $1
                      (struct.get $type47 0
                       (global.get $global351)
                      )
                     )
                     (i64.const 9223372036854775807)
                    )
                   )
                   (struct.set $type47 0
                    (global.get $global351)
                    (i64.add
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready808)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global808)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (local.get $10)
                     (struct.new $type32
                      (local.get $7)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global359)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global354)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global352)
                      )
                     )
                     (local.set $10
                      (struct.new $type32
                       (struct.get $type12 0
                        (local.get $4)
                       )
                      )
                     )
                     (br_if $block
                      (i64.eq
                       (local.tee $1
                        (struct.get $type47 0
                         (global.get $global351)
                        )
                       )
                       (i64.const 9223372036854775807)
                      )
                     )
                     (struct.set $type47 0
                      (global.get $global351)
                      (i64.add
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready808)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global808)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (local.get $10)
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $4
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global359)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global354)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global352)
                        )
                       )
                       (local.set $10
                        (struct.new $type32
                         (struct.get $type12 0
                          (local.get $3)
                         )
                        )
                       )
                       (br_if $block
                        (i64.eq
                         (local.tee $1
                          (struct.get $type47 0
                           (global.get $global351)
                          )
                         )
                         (i64.const 9223372036854775807)
                        )
                       )
                       (struct.set $type47 0
                        (global.get $global351)
                        (i64.add
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready808)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global808)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (local.get $10)
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $3
                          (struct.get $type12 1
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global359)
                          )
                         )
                         (local.set $7
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global354)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global352)
                          )
                         )
                         (br_if $block
                          (i64.eq
                           (local.tee $1
                            (struct.get $type47 0
                             (global.get $global351)
                            )
                           )
                           (i64.const 9223372036854775807)
                          )
                         )
                         (struct.set $type47 0
                          (global.get $global351)
                          (i64.add
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready808)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global808)
                          )
                         )
                         (local.set $5
                          (struct.new $type31
                           (i32.const 6)
                           (struct.new $type32
                            (local.get $7)
                           )
                           (struct.new $type32
                            (local.get $5)
                           )
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $4
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global359)
                            )
                           )
                           (local.set $7
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global354)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global352)
                            )
                           )
                           (br_if $block
                            (i64.eq
                             (local.tee $1
                              (struct.get $type47 0
                               (global.get $global351)
                              )
                             )
                             (i64.const 9223372036854775807)
                            )
                           )
                           (struct.set $type47 0
                            (global.get $global351)
                            (i64.add
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready808)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global808)
                            )
                           )
                           (local.set $5
                            (struct.new $type31
                             (i32.const 6)
                             (struct.new $type32
                              (local.get $7)
                             )
                             (struct.new $type32
                              (local.get $5)
                             )
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $3
                              (struct.get $type12 1
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global359)
                              )
                             )
                             (local.set $7
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global354)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global352)
                              )
                             )
                             (br_if $block
                              (i64.eq
                               (local.tee $1
                                (struct.get $type47 0
                                 (global.get $global351)
                                )
                               )
                               (i64.const 9223372036854775807)
                              )
                             )
                             (struct.set $type47 0
                              (global.get $global351)
                              (i64.add
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready808)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global808)
                              )
                             )
                             (local.set $5
                              (struct.new $type31
                               (i32.const 6)
                               (struct.new $type32
                                (local.get $7)
                               )
                               (struct.new $type32
                                (local.get $5)
                               )
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $4
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global359)
                                )
                               )
                               (local.set $7
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global354)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global352)
                                )
                               )
                               (br_if $block
                                (i64.eq
                                 (local.tee $1
                                  (struct.get $type47 0
                                   (global.get $global351)
                                  )
                                 )
                                 (i64.const 9223372036854775807)
                                )
                               )
                               (struct.set $type47 0
                                (global.get $global351)
                                (i64.add
                                 (local.get $1)
                                 (i64.const 1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready808)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global808)
                                )
                               )
                               (local.set $5
                                (struct.new $type31
                                 (i32.const 6)
                                 (struct.new $type32
                                  (local.get $7)
                                 )
                                 (struct.new $type32
                                  (local.get $5)
                                 )
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global359)
                                  )
                                 )
                                 (local.set $7
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global354)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global352)
                                  )
                                 )
                                 (if
                                  (i64.eq
                                   (local.tee $1
                                    (struct.get $type47 0
                                     (global.get $global351)
                                    )
                                   )
                                   (i64.const 9223372036854775807)
                                  )
                                  (then
                                   (br $block)
                                  )
                                  (else
                                   (struct.set $type47 0
                                    (global.get $global351)
                                    (i64.add
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready808)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global808)
                                  )
                                 )
                                 (local.set $5
                                  (struct.new $type31
                                   (i32.const 6)
                                   (struct.new $type32
                                    (local.get $7)
                                   )
                                   (struct.new $type32
                                    (local.get $5)
                                   )
                                  )
                                 )
                                 (if (result (ref $type13))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (call $function215
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                    (block (result (ref $type31))
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global359)
                                      )
                                     )
                                     (local.set $scratch_15
                                      (call $function107
                                       (struct.get $type12 0
                                        (local.get $3)
                                       )
                                       (local.get $5)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready808)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global808)
                                      )
                                     )
                                     (local.get $scratch_15)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (if (result (ref $type125))
                 (i32.eq
                  (struct.get $type205 0
                   (local.get $8)
                  )
                  (i32.const 6)
                 )
                 (then
                  (struct.new $type125
                   (i32.const 2)
                   (struct.get $type212 1
                    (ref.cast (ref $type212)
                     (local.get $8)
                    )
                   )
                  )
                 )
                 (else
                  (if (result (ref $type125))
                   (local.tee $13
                    (struct.get $type205 0
                     (local.get $8)
                    )
                   )
                   (then
                    (if (result (ref $type125))
                     (i32.eq
                      (local.get $13)
                      (i32.const 1)
                     )
                     (then
                      (struct.new $type125
                       (i32.const 2)
                       (global.get $string51)
                      )
                     )
                     (else
                      (if (result (ref $type125))
                       (i32.eq
                        (struct.get $type205 0
                         (local.get $8)
                        )
                        (i32.const 3)
                       )
                       (then
                        (struct.new $type125
                         (i32.const 2)
                         (global.get $string50)
                        )
                       )
                       (else
                        (if (result (ref $type125))
                         (i32.eq
                          (struct.get $type205 0
                           (local.get $8)
                          )
                          (i32.const 4)
                         )
                         (then
                          (drop
                           (ref.cast (ref $type210)
                            (local.get $8)
                           )
                          )
                          (struct.new $type125
                           (i32.const 2)
                           (global.get $string49)
                          )
                         )
                         (else
                          (drop
                           (ref.cast (ref $type211)
                            (local.get $8)
                           )
                          )
                          (struct.new $type125
                           (i32.const 2)
                           (global.get $string48)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (drop
                     (ref.cast (ref $type206)
                      (local.get $8)
                     )
                    )
                    (struct.new $type125
                     (i32.const 2)
                     (global.get $string52)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type125))
               (struct.get $type122 0
                (local.get $11)
               )
               (then
                (struct.new $type125
                 (i32.const 2)
                 (struct.get $type125 1
                  (ref.cast (ref $type125)
                   (local.get $11)
                  )
                 )
                )
               )
               (else
                (struct.new $type125
                 (i32.const 2)
                 (global.get $string47)
                )
               )
              )
             )
            )
           )
           (else
            (struct.new $type125
             (i32.const 2)
             (global.get $string44)
            )
           )
          )
         )
         (else
          (if (result (ref $type125))
           (i32.eq
            (struct.get $type205 0
             (local.get $8)
            )
            (i32.const 6)
           )
           (then
            (struct.new $type125
             (i32.const 2)
             (struct.get $type212 1
              (ref.cast (ref $type212)
               (local.get $8)
              )
             )
            )
           )
           (else
            (if (result (ref $type125))
             (local.tee $13
              (struct.get $type205 0
               (local.get $8)
              )
             )
             (then
              (if
               (i32.eq
                (local.get $13)
                (i32.const 4)
               )
               (then
                (drop
                 (ref.cast (ref $type210)
                  (local.get $8)
                 )
                )
               )
               (else
                (drop
                 (ref.cast (ref $type211)
                  (local.get $8)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global792)
               )
              )
              (local.set $11
               (call $function212
                (local.get $0)
                (local.get $8)
               )
              )
              (if
               (i32.eqz
                (global.get $ready860)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global860)
               )
              )
              (if (result (ref $type125))
               (i32.eq
                (struct.get $type122 0
                 (local.get $11)
                )
                (i32.const 1)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global799)
                 )
                )
                (return_call $function213
                 (local.get $0)
                 (local.get $1)
                 (struct.new $type12
                  (struct.get $type124 1
                   (ref.cast (ref $type124)
                    (local.get $11)
                   )
                  )
                  (local.get $2)
                 )
                )
               )
               (else
                (if (result (ref $type125))
                 (i32.eq
                  (struct.get $type122 0
                   (local.get $11)
                  )
                  (i32.const 2)
                 )
                 (then
                  (struct.new $type125
                   (i32.const 2)
                   (struct.get $type125 1
                    (ref.cast (ref $type125)
                     (local.get $11)
                    )
                   )
                  )
                 )
                 (else
                  (unreachable)
                 )
                )
               )
              )
             )
             (else
              (local.set $6
               (struct.new $type12
                (struct.get $type206 1
                 (ref.cast (ref $type206)
                  (local.get $8)
                 )
                )
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready799)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global799)
               )
              )
              (return_call $function213
               (local.get $0)
               (local.get $1)
               (local.get $6)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global252)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (call $foreign2
   (call $function80
    (global.get $string2)
   )
  )
  (unreachable)
 )
 (func $function215 (param $0 (ref null $type12)) (param $1 (ref $type31)) (result (ref $type13))
  (local $2 (ref null $type12))
  (local $scratch (ref $type31))
  (if (result (ref $type31))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function215
     (struct.get $type12 1
      (local.get $0)
     )
     (block (result (ref $type31))
      (drop
       (ref.as_non_null
        (global.get $global359)
       )
      )
      (local.set $scratch
       (call $function107
        (struct.get $type12 0
         (local.get $0)
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready808)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global808)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function217 (type $84) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 (ref $type12)) (result (ref null $type12))
  (local $4 (ref null $type12))
  (if (result (ref $type12))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $3
     (struct.new $type12
      (struct.get $type12 0
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function217
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function220 (type $83) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function220
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function221 (type $82) (param $0 (ref $type34)) (param $1 i32) (param $2 i32) (param $3 (ref null $type12)) (param $4 i64) (result (ref $type34))
  (local $5 (ref $type13))
  (if (result (ref $type34))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (local.set $5
     (struct.get $type12 0
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type34
     (local.get $0)
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $5)
    )
    (local.set $3
     (struct.get $type12 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function221
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function223 (type $83) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function223
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function224 (type $call241) (param $0 (ref null $type12)) (param $1 (ref $type36)) (param $2 i64) (result (ref $type122))
  (local $3 (ref $type24))
  (local $4 (ref $type13))
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if (result (ref $type122))
   (ref.is_null
    (local.get $0)
   )
   (then
    (struct.new $type124
     (i32.const 1)
     (struct.new $type35
      (i32.const 8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global838)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global386)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global372)
     )
    )
    (if (result (ref $type125))
     (if (result i32)
      (local.tee $7
       (i64.lt_s
        (local.tee $5
         (if (result i64)
          (i64.eq
           (call $function112
            (local.tee $4
             (struct.get $type12 0
              (local.get $0)
             )
            )
           )
           (i64.const 5)
          )
          (then
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $4)
             )
             (i32.const 5)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (struct.get $type24 0
             (local.tee $3
              (struct.get $type23 1
               (ref.cast (ref $type23)
                (local.get $4)
               )
              )
             )
            )
            (then
             (if
              (i32.eq
               (struct.get $type24 0
                (local.get $3)
               )
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type26)
                 (local.get $3)
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type27)
                 (local.get $3)
                )
               )
              )
             )
             (i64.const -1)
            )
            (else
             (struct.get $type25 1
              (ref.cast (ref $type25)
               (local.get $3)
              )
             )
            )
           )
          )
          (else
           (i64.const -1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $7)
      )
      (else
       (i64.gt_s
        (local.get $5)
        (i64.const 255)
       )
      )
     )
     (then
      (struct.new $type125
       (i32.const 2)
       (global.get $string46)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.tee $6
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type37
       (struct.get $type36 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
      (return_call $function224
       (struct.get $type12 1
        (local.get $0)
       )
       (block (result (ref $type36))
        (if
         (i32.eqz
          (global.get $ready833)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global833)
         )
        )
        (local.get $1)
       )
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function230 (type $call245) (param $0 (ref $type46)) (param $1 (ref $type49)) (result i32)
  (drop
   (ref.as_non_null
    (global.get $global882)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type50)
     (local.get $1)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type51)
       (local.get $1)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (ref.test (ref $type50)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global876)
     )
    )
    (ref.eq
     (struct.get $type46 0
      (local.get $0)
     )
     (struct.get $type46 0
      (struct.get $type51 0
       (ref.cast (ref $type51)
        (local.get $1)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function234 (type $call243) (param $0 (ref $type55)) (result i32)
  (if (result i32)
   (ref.test (ref $type56)
    (local.get $0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $type57)
      (local.get $0)
     )
    )
    (i32.const 1)
   )
  )
 )
 (func $function237 (type $call251) (param $0 (ref null $type61)) (param $1 (ref null $type61)) (result i32)
  (local $scratch (ref null $type61))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i32.eq
        (struct.get $type61 0
         (local.get $0)
        )
        (struct.get $type61 0
         (local.get $1)
        )
       )
       (then
        (return_call $function237
         (struct.get $type61 1
          (local.get $0)
         )
         (block (result (ref null $type61))
          (local.set $scratch
           (struct.get $type61 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready900)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global900)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function238 (type $call252) (param $0 (ref $type167)) (param $1 (ref $type167)) (result i32)
  (local $2 (ref null $type61))
  (local $3 (ref null $type61))
  (local $4 i32)
  (local $scratch (ref null $type61))
  (if (result i32)
   (local.tee $4
    (struct.get $type167 0
     (local.get $0)
    )
   )
   (then
    (if (result i32)
     (i32.eq
      (local.get $4)
      (i32.const 1)
     )
     (then
      (local.set $3
       (struct.get $type169 1
        (ref.cast (ref $type169)
         (local.get $0)
        )
       )
      )
      (if (result i32)
       (local.tee $4
        (struct.get $type167 0
         (local.get $1)
        )
       )
       (then
        (if (result i32)
         (i32.eq
          (local.get $4)
          (i32.const 1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global900)
           )
          )
          (local.set $2
           (struct.get $type169 1
            (ref.cast (ref $type169)
             (local.get $1)
            )
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $3)
           )
           (then
            (ref.is_null
             (local.get $2)
            )
           )
           (else
            (if (result i32)
             (ref.is_null
              (local.get $2)
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i32.eq
                (struct.get $type61 0
                 (local.get $3)
                )
                (struct.get $type61 0
                 (local.get $2)
                )
               )
               (then
                (local.set $3
                 (struct.get $type61 1
                  (local.get $3)
                 )
                )
                (local.set $2
                 (struct.get $type61 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready900)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global900)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $3)
                 )
                 (then
                  (ref.is_null
                   (local.get $2)
                  )
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (i32.eq
                      (struct.get $type61 0
                       (local.get $3)
                      )
                      (struct.get $type61 0
                       (local.get $2)
                      )
                     )
                     (then
                      (local.set $3
                       (struct.get $type61 1
                        (local.get $3)
                       )
                      )
                      (local.set $2
                       (struct.get $type61 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready900)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global900)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $3)
                       )
                       (then
                        (ref.is_null
                         (local.get $2)
                        )
                       )
                       (else
                        (if (result i32)
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i32.eq
                            (struct.get $type61 0
                             (local.get $3)
                            )
                            (struct.get $type61 0
                             (local.get $2)
                            )
                           )
                           (then
                            (local.set $3
                             (struct.get $type61 1
                              (local.get $3)
                             )
                            )
                            (local.set $2
                             (struct.get $type61 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready900)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global900)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $3)
                             )
                             (then
                              (ref.is_null
                               (local.get $2)
                              )
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (i32.eq
                                  (struct.get $type61 0
                                   (local.get $3)
                                  )
                                  (struct.get $type61 0
                                   (local.get $2)
                                  )
                                 )
                                 (then
                                  (local.set $3
                                   (struct.get $type61 1
                                    (local.get $3)
                                   )
                                  )
                                  (local.set $2
                                   (struct.get $type61 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready900)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global900)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $3)
                                   )
                                   (then
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                   )
                                   (else
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $2)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if (result i32)
                                       (i32.eq
                                        (struct.get $type61 0
                                         (local.get $3)
                                        )
                                        (struct.get $type61 0
                                         (local.get $2)
                                        )
                                       )
                                       (then
                                        (local.set $3
                                         (struct.get $type61 1
                                          (local.get $3)
                                         )
                                        )
                                        (local.set $2
                                         (struct.get $type61 1
                                          (local.get $2)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready900)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global900)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $3)
                                         )
                                         (then
                                          (ref.is_null
                                           (local.get $2)
                                          )
                                         )
                                         (else
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (i32.eq
                                              (struct.get $type61 0
                                               (local.get $3)
                                              )
                                              (struct.get $type61 0
                                               (local.get $2)
                                              )
                                             )
                                             (then
                                              (local.set $3
                                               (struct.get $type61 1
                                                (local.get $3)
                                               )
                                              )
                                              (local.set $2
                                               (struct.get $type61 1
                                                (local.get $2)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready900)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global900)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $3)
                                               )
                                               (then
                                                (ref.is_null
                                                 (local.get $2)
                                                )
                                               )
                                               (else
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $2)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i32.eq
                                                    (struct.get $type61 0
                                                     (local.get $3)
                                                    )
                                                    (struct.get $type61 0
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (then
                                                    (local.set $3
                                                     (struct.get $type61 1
                                                      (local.get $3)
                                                     )
                                                    )
                                                    (local.set $2
                                                     (struct.get $type61 1
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready900)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global900)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $3)
                                                     )
                                                     (then
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $2)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i32.eq
                                                          (struct.get $type61 0
                                                           (local.get $3)
                                                          )
                                                          (struct.get $type61 0
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (then
                                                          (local.set $3
                                                           (struct.get $type61 1
                                                            (local.get $3)
                                                           )
                                                          )
                                                          (local.set $2
                                                           (struct.get $type61 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready900)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global900)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $3)
                                                           )
                                                           (then
                                                            (ref.is_null
                                                             (local.get $2)
                                                            )
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $2)
                                                             )
                                                             (then
                                                              (i32.const 0)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i32.eq
                                                                (struct.get $type61 0
                                                                 (local.get $3)
                                                                )
                                                                (struct.get $type61 0
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (then
                                                                (local.set $3
                                                                 (struct.get $type61 1
                                                                  (local.get $3)
                                                                 )
                                                                )
                                                                (local.set $2
                                                                 (struct.get $type61 1
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                                (if
                                                                 (i32.eqz
                                                                  (global.get $ready900)
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global900)
                                                                 )
                                                                )
                                                                (if (result i32)
                                                                 (ref.is_null
                                                                  (local.get $3)
                                                                 )
                                                                 (then
                                                                  (ref.is_null
                                                                   (local.get $2)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (if (result i32)
                                                                   (ref.is_null
                                                                    (local.get $2)
                                                                   )
                                                                   (then
                                                                    (i32.const 0)
                                                                   )
                                                                   (else
                                                                    (if (result i32)
                                                                     (i32.eq
                                                                      (struct.get $type61 0
                                                                       (local.get $3)
                                                                      )
                                                                      (struct.get $type61 0
                                                                       (local.get $2)
                                                                      )
                                                                     )
                                                                     (then
                                                                      (return_call $function237
                                                                       (struct.get $type61 1
                                                                        (local.get $3)
                                                                       )
                                                                       (block (result (ref null $type61))
                                                                        (local.set $scratch
                                                                         (struct.get $type61 1
                                                                          (local.get $2)
                                                                         )
                                                                        )
                                                                        (if
                                                                         (i32.eqz
                                                                          (global.get $ready900)
                                                                         )
                                                                         (then
                                                                          (unreachable)
                                                                         )
                                                                        )
                                                                        (drop
                                                                         (ref.as_non_null
                                                                          (global.get $global900)
                                                                         )
                                                                        )
                                                                        (local.get $scratch)
                                                                       )
                                                                      )
                                                                     )
                                                                     (else
                                                                      (i32.const 0)
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                               (else
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (else
                                                          (i32.const 0)
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (i32.const 0)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (i32.const 0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (if (result i32)
     (local.tee $4
      (struct.get $type167 0
       (local.get $1)
      )
     )
     (then
      (if
       (i32.eq
        (local.get $4)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type169)
          (local.get $1)
         )
        )
       )
      )
      (i32.const 0)
     )
     (else
      (i32.const 1)
     )
    )
   )
  )
 )
 (func $function240 (type $call253) (param $0 i64) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.get $1)
     )
     (then
      (i64.const 0)
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $0)
        (i64.const -1)
       )
       (then
        (local.get $1)
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $1)
          (i64.const -1)
         )
         (then
          (local.get $0)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready918)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global918)
           )
          )
          (select
           (i64.add
            (local.tee $2
             (i64.add
              (local.tee $2
               (call $function240
                (call $function241
                 (local.get $0)
                 (i64.const 2)
                )
                (block (result i64)
                 (if
                  (i32.eqz
                   (global.get $ready918)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global918)
                  )
                 )
                 (local.set $scratch
                  (call $function241
                   (local.get $1)
                   (i64.const 2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready914)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global914)
                  )
                 )
                 (local.get $scratch)
                )
               )
              )
              (local.get $2)
             )
            )
            (i64.const 1)
           )
           (local.get $2)
           (block (result i32)
            (drop
             (ref.as_non_null
              (global.get $global896)
             )
            )
            (i32.and
             (i32.wrap_i64
              (i64.and
               (local.get $1)
               (i64.const 1)
              )
             )
             (i32.wrap_i64
              (i64.and
               (local.get $0)
               (i64.const 1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function241 (type $call253) (param $0 i64) (param $1 i64) (result i64)
  (local $2 i64)
  (drop
   (ref.as_non_null
    (global.get $global898)
   )
  )
  (if (result i64)
   (i64.ge_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (i64.div_s
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if (result i64)
       (i64.eq
        (local.get $0)
        (i64.mul
         (local.get $1)
         (local.tee $2
          (i64.div_s
           (local.get $0)
           (local.get $1)
          )
         )
        )
       )
       (then
        (local.get $2)
       )
       (else
        (i64.add
         (local.get $2)
         (i64.const 1)
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $0)
        (i64.mul
         (local.get $1)
         (local.tee $2
          (i64.div_s
           (local.get $0)
           (local.get $1)
          )
         )
        )
       )
       (then
        (local.get $2)
       )
       (else
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function242 (type $call253) (param $0 i64) (param $1 i64) (result i64)
  (drop
   (ref.as_non_null
    (global.get $global898)
   )
  )
  (if (result i64)
   (i64.ge_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (i64.rem_s
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.mul
           (local.get $1)
           (i64.div_s
            (local.get $0)
            (local.get $1)
           )
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (i64.sub
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.mul
           (local.get $1)
           (i64.div_s
            (local.get $0)
            (local.get $1)
           )
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (i64.add
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function248 (type $70) (param $0 (ref $type46)) (param $1 i32) (param $2 i32) (param $3 (ref $type46)) (result (ref $type46))
  (local $4 (ref $type49))
  (local $5 (ref $type49))
  (drop
   (ref.as_non_null
    (global.get $global882)
   )
  )
  (if (result (ref $type46))
   (if (result i32)
    (ref.test (ref $type50)
     (local.tee $4
      (struct.get $type48 0
       (struct.get $type46 1
        (local.get $3)
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type51)
       (local.get $4)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (ref.test (ref $type50)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type51 0
      (ref.cast (ref $type51)
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function248
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global876)
     )
    )
    (drop
     (if (result i32)
      (ref.eq
       (struct.get $type46 0
        (local.get $3)
       )
       (struct.get $type46 0
        (local.get $0)
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global879)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global882)
        )
       )
       (if (result i32)
        (if (result i32)
         (if (result i32)
          (ref.test (ref $type50)
           (local.tee $4
            (struct.get $type48 0
             (struct.get $type46 1
              (local.get $0)
             )
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.cast (ref $type51)
             (local.get $4)
            )
           )
           (i32.const 1)
          )
         )
         (then
          (if
           (ref.test (ref $type50)
            (local.get $4)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global876)
           )
          )
          (ref.eq
           (struct.get $type46 0
            (local.get $3)
           )
           (struct.get $type46 0
            (struct.get $type51 0
             (ref.cast (ref $type51)
              (local.get $4)
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (struct.set $type48 0
          (struct.get $type46 1
           (local.get $0)
          )
          (struct.new $type51
           (local.get $3)
          )
         )
         (if
          (ref.test (ref $type50)
           (local.get $4)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global879)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global882)
          )
         )
         (if (result i32)
          (if (result i32)
           (if (result i32)
            (ref.test (ref $type50)
             (local.tee $4
              (struct.get $type48 0
               (struct.get $type46 1
                (local.tee $0
                 (struct.get $type51 0
                  (ref.cast (ref $type51)
                   (local.get $4)
                  )
                 )
                )
               )
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (ref.cast (ref $type51)
               (local.get $4)
              )
             )
             (i32.const 1)
            )
           )
           (then
            (if
             (ref.test (ref $type50)
              (local.get $4)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global876)
             )
            )
            (ref.eq
             (struct.get $type46 0
              (local.get $3)
             )
             (struct.get $type46 0
              (struct.get $type51 0
               (ref.cast (ref $type51)
                (local.get $4)
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (struct.set $type48 0
            (struct.get $type46 1
             (local.get $0)
            )
            (struct.new $type51
             (local.get $3)
            )
           )
           (if
            (ref.test (ref $type50)
             (local.get $4)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global879)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global882)
            )
           )
           (if (result i32)
            (if (result i32)
             (if (result i32)
              (ref.test (ref $type50)
               (local.tee $4
                (struct.get $type48 0
                 (struct.get $type46 1
                  (local.tee $0
                   (struct.get $type51 0
                    (ref.cast (ref $type51)
                     (local.get $4)
                    )
                   )
                  )
                 )
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.cast (ref $type51)
                 (local.get $4)
                )
               )
               (i32.const 1)
              )
             )
             (then
              (if
               (ref.test (ref $type50)
                (local.get $4)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global876)
               )
              )
              (ref.eq
               (struct.get $type46 0
                (local.get $3)
               )
               (struct.get $type46 0
                (struct.get $type51 0
                 (ref.cast (ref $type51)
                  (local.get $4)
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (struct.set $type48 0
              (struct.get $type46 1
               (local.get $0)
              )
              (struct.new $type51
               (local.get $3)
              )
             )
             (if
              (ref.test (ref $type50)
               (local.get $4)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global879)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global882)
              )
             )
             (if (result i32)
              (if (result i32)
               (if (result i32)
                (ref.test (ref $type50)
                 (local.tee $4
                  (struct.get $type48 0
                   (struct.get $type46 1
                    (local.tee $0
                     (struct.get $type51 0
                      (ref.cast (ref $type51)
                       (local.get $4)
                      )
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (ref.cast (ref $type51)
                   (local.get $4)
                  )
                 )
                 (i32.const 1)
                )
               )
               (then
                (if
                 (ref.test (ref $type50)
                  (local.get $4)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global876)
                 )
                )
                (ref.eq
                 (struct.get $type46 0
                  (local.get $3)
                 )
                 (struct.get $type46 0
                  (struct.get $type51 0
                   (ref.cast (ref $type51)
                    (local.get $4)
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (struct.set $type48 0
                (struct.get $type46 1
                 (local.get $0)
                )
                (struct.new $type51
                 (local.get $3)
                )
               )
               (if
                (ref.test (ref $type50)
                 (local.get $4)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global879)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global882)
                )
               )
               (if (result i32)
                (if (result i32)
                 (if (result i32)
                  (ref.test (ref $type50)
                   (local.tee $4
                    (struct.get $type48 0
                     (struct.get $type46 1
                      (local.tee $0
                       (struct.get $type51 0
                        (ref.cast (ref $type51)
                         (local.get $4)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type51)
                     (local.get $4)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (then
                  (if
                   (ref.test (ref $type50)
                    (local.get $4)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global876)
                   )
                  )
                  (ref.eq
                   (struct.get $type46 0
                    (local.get $3)
                   )
                   (struct.get $type46 0
                    (struct.get $type51 0
                     (ref.cast (ref $type51)
                      (local.get $4)
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (struct.set $type48 0
                  (struct.get $type46 1
                   (local.get $0)
                  )
                  (struct.new $type51
                   (local.get $3)
                  )
                 )
                 (if
                  (ref.test (ref $type50)
                   (local.get $4)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global879)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global882)
                  )
                 )
                 (if (result i32)
                  (if (result i32)
                   (if (result i32)
                    (ref.test (ref $type50)
                     (local.tee $4
                      (struct.get $type48 0
                       (struct.get $type46 1
                        (local.tee $0
                         (struct.get $type51 0
                          (ref.cast (ref $type51)
                           (local.get $4)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (ref.cast (ref $type51)
                       (local.get $4)
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (then
                    (if
                     (ref.test (ref $type50)
                      (local.get $4)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global876)
                     )
                    )
                    (ref.eq
                     (struct.get $type46 0
                      (local.get $3)
                     )
                     (struct.get $type46 0
                      (struct.get $type51 0
                       (ref.cast (ref $type51)
                        (local.get $4)
                       )
                      )
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (struct.set $type48 0
                    (struct.get $type46 1
                     (local.get $0)
                    )
                    (struct.new $type51
                     (local.get $3)
                    )
                   )
                   (if
                    (ref.test (ref $type50)
                     (local.get $4)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global879)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global882)
                    )
                   )
                   (if (result i32)
                    (if (result i32)
                     (if (result i32)
                      (ref.test (ref $type50)
                       (local.tee $4
                        (struct.get $type48 0
                         (struct.get $type46 1
                          (local.tee $0
                           (struct.get $type51 0
                            (ref.cast (ref $type51)
                             (local.get $4)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (ref.cast (ref $type51)
                         (local.get $4)
                        )
                       )
                       (i32.const 1)
                      )
                     )
                     (then
                      (if
                       (ref.test (ref $type50)
                        (local.get $4)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global876)
                       )
                      )
                      (ref.eq
                       (struct.get $type46 0
                        (local.get $3)
                       )
                       (struct.get $type46 0
                        (struct.get $type51 0
                         (ref.cast (ref $type51)
                          (local.get $4)
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (struct.set $type48 0
                      (struct.get $type46 1
                       (local.get $0)
                      )
                      (struct.new $type51
                       (local.get $3)
                      )
                     )
                     (if
                      (ref.test (ref $type50)
                       (local.get $4)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global879)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global882)
                      )
                     )
                     (if (result i32)
                      (if (result i32)
                       (if (result i32)
                        (ref.test (ref $type50)
                         (local.tee $4
                          (struct.get $type48 0
                           (struct.get $type46 1
                            (local.tee $0
                             (struct.get $type51 0
                              (ref.cast (ref $type51)
                               (local.get $4)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (ref.cast (ref $type51)
                           (local.get $4)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                       (then
                        (if
                         (ref.test (ref $type50)
                          (local.get $4)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global876)
                         )
                        )
                        (ref.eq
                         (struct.get $type46 0
                          (local.get $3)
                         )
                         (struct.get $type46 0
                          (struct.get $type51 0
                           (ref.cast (ref $type51)
                            (local.get $4)
                           )
                          )
                         )
                        )
                       )
                       (else
                        (i32.const 0)
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (struct.set $type48 0
                        (struct.get $type46 1
                         (local.get $0)
                        )
                        (struct.new $type51
                         (local.get $3)
                        )
                       )
                       (if
                        (ref.test (ref $type50)
                         (local.get $4)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global879)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global882)
                        )
                       )
                       (if (result i32)
                        (if (result i32)
                         (if (result i32)
                          (ref.test (ref $type50)
                           (local.tee $4
                            (local.tee $5
                             (struct.get $type48 0
                              (struct.get $type46 1
                               (local.tee $0
                                (struct.get $type51 0
                                 (ref.cast (ref $type51)
                                  (local.get $4)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (ref.cast (ref $type51)
                             (local.get $4)
                            )
                           )
                           (i32.const 1)
                          )
                         )
                         (then
                          (if
                           (ref.test (ref $type50)
                            (local.get $4)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global876)
                           )
                          )
                          (ref.eq
                           (struct.get $type46 0
                            (local.get $3)
                           )
                           (struct.get $type46 0
                            (struct.get $type51 0
                             (ref.cast (ref $type51)
                              (local.get $4)
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (struct.set $type48 0
                          (struct.get $type46 1
                           (local.get $0)
                          )
                          (struct.new $type51
                           (local.get $3)
                          )
                         )
                         (if
                          (ref.test (ref $type50)
                           (local.get $5)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global879)
                          )
                         )
                         (if (result i32)
                          (call $function230
                           (local.get $3)
                           (local.tee $4
                            (struct.get $type48 0
                             (struct.get $type46 1
                              (local.tee $0
                               (struct.get $type51 0
                                (ref.cast (ref $type51)
                                 (local.get $5)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (struct.set $type48 0
                            (struct.get $type46 1
                             (local.get $0)
                            )
                            (struct.new $type51
                             (local.get $3)
                            )
                           )
                           (if
                            (ref.test (ref $type50)
                             (local.get $4)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (call $function249
                            (local.get $3)
                            (i32.const 0)
                            (i32.const 1)
                            (struct.get $type51 0
                             (ref.cast (ref $type51)
                              (local.get $4)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.get $3)
   )
  )
 )
 (func $function249 (type $68) (param $0 (ref $type46)) (param $1 i32) (param $2 i32) (param $3 (ref $type46)) (result i32)
  (local $4 (ref $type49))
  (drop
   (ref.as_non_null
    (global.get $global879)
   )
  )
  (if (result i32)
   (call $function230
    (local.get $0)
    (local.tee $4
     (struct.get $type48 0
      (struct.get $type46 1
       (local.get $3)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type48 0
     (struct.get $type46 1
      (local.get $3)
     )
     (struct.new $type51
      (local.get $0)
     )
    )
    (if
     (ref.test (ref $type50)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type51 0
      (ref.cast (ref $type51)
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function249
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function267 (type $call273) (param $0 (ref $type42)) (result (ref $type55))
  (if
   (ref.test (ref $type43)
    (local.get $0)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type54 0
   (struct.get $type44 3
    (ref.cast (ref $type44)
     (local.get $0)
    )
   )
  )
 )
 (func $function270 (type $64) (param $0 (ref $type42))
  (if
   (ref.test (ref $type43)
    (local.get $0)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type58 0
   (struct.get $type44 4
    (ref.cast (ref $type44)
     (local.get $0)
    )
   )
   (i32.const 1)
  )
 )
 (func $function271 (type $call281) (param $0 (ref $type59)) (param $1 i64) (result i32)
  (local $2 (ref $type250))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global1028)
   )
  )
  (if (result i32)
   (i64.ge_s
    (local.tee $3
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call $function272
      (struct.get $type250 0
       (local.tee $2
        (struct.new $type250
         (struct.new $environment272
          (local.get $1)
         )
        )
       )
      )
      (array.get $type59
       (local.get $0)
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.ge_s
        (local.tee $1
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (call $function272
          (struct.get $type250 0
           (local.get $2)
          )
          (array.get $type59
           (local.get $0)
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (then
          (i32.const 0)
         )
         (else
          (if (result i32)
           (i64.ge_s
            (local.tee $1
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (if
             (i64.gt_u
              (local.get $1)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (if (result i32)
             (call $function272
              (struct.get $type250 0
               (local.get $2)
              )
              (array.get $type59
               (local.get $0)
               (i32.wrap_i64
                (local.get $1)
               )
              )
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i64.ge_s
                (local.tee $1
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (if
                 (i64.gt_u
                  (local.get $1)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i32)
                 (call $function272
                  (struct.get $type250 0
                   (local.get $2)
                  )
                  (array.get $type59
                   (local.get $0)
                   (i32.wrap_i64
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if (result i32)
                   (i64.ge_s
                    (local.tee $1
                     (i64.sub
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (if
                     (i64.gt_u
                      (local.get $1)
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if (result i32)
                     (call $function272
                      (struct.get $type250 0
                       (local.get $2)
                      )
                      (array.get $type59
                       (local.get $0)
                       (i32.wrap_i64
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if (result i32)
                       (i64.ge_s
                        (local.tee $1
                         (i64.sub
                          (local.get $1)
                          (i64.const 1)
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (if
                         (i64.gt_u
                          (local.get $1)
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if (result i32)
                         (call $function272
                          (struct.get $type250 0
                           (local.get $2)
                          )
                          (array.get $type59
                           (local.get $0)
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i64.ge_s
                            (local.tee $1
                             (i64.sub
                              (local.get $1)
                              (i64.const 1)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (if
                             (i64.gt_u
                              (local.get $1)
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if (result i32)
                             (call $function272
                              (struct.get $type250 0
                               (local.get $2)
                              )
                              (array.get $type59
                               (local.get $0)
                               (i32.wrap_i64
                                (local.get $1)
                               )
                              )
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if (result i32)
                               (i64.ge_s
                                (local.tee $1
                                 (i64.sub
                                  (local.get $1)
                                  (i64.const 1)
                                 )
                                )
                                (i64.const 0)
                               )
                               (then
                                (if
                                 (i64.gt_u
                                  (local.get $1)
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (if (result i32)
                                 (call $function272
                                  (struct.get $type250 0
                                   (local.get $2)
                                  )
                                  (array.get $type59
                                   (local.get $0)
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (if (result i32)
                                   (i64.ge_s
                                    (local.tee $1
                                     (i64.sub
                                      (local.get $1)
                                      (i64.const 1)
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                   (then
                                    (if
                                     (i64.gt_u
                                      (local.get $1)
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (if (result i32)
                                     (call $function272
                                      (struct.get $type250 0
                                       (local.get $2)
                                      )
                                      (array.get $type59
                                       (local.get $0)
                                       (i32.wrap_i64
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (return_call $function274
                                       (local.get $2)
                                       (local.get $0)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (i64.sub
                                        (local.get $1)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (i32.const 0)
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (i32.const 0)
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                       (else
                        (i32.const 0)
                       )
                      )
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function272 (type $call250) (param $0 (ref $environment272)) (param $1 (ref $type40)) (result i32)
  (local $2 (ref $type46))
  (local $3 (ref $type46))
  (local $4 (ref $type46))
  (local $5 (ref $type46))
  (local $6 (ref $type42))
  (local $7 (ref $type42))
  (local $8 (ref $type44))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $scratch (ref $type46))
  (local $scratch_15 i64)
  (drop
   (ref.as_non_null
    (global.get $global975)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global980)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global993)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global958)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.tee $6
     (struct.get $type41 0
      (struct.get $type40 0
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.tee $7
     (struct.get $type41 0
      (struct.get $type40 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (local.tee $3
    (struct.get $type45 0
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $7)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global950)
   )
  )
  (if (result i32)
   (ref.eq
    (struct.get $type46 0
     (block (result (ref $type46))
      (local.set $scratch
       (call $function248
        (local.tee $4
         (struct.get $type45 0
          (struct.get $type44 0
           (ref.cast (ref $type44)
            (local.get $6)
           )
          )
         )
        )
        (i32.const 0)
        (i32.const 1)
        (local.get $4)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global950)
       )
      )
      (local.set $2
       (call $function248
        (local.get $2)
        (i32.const 0)
        (i32.const 1)
        (local.get $2)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global876)
       )
      )
      (local.get $scratch)
     )
    )
    (struct.get $type46 0
     (local.get $2)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1003)
     )
    )
    (if
     (ref.test (ref $type43)
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (call $function240
      (struct.get $type47 0
       (struct.get $type44 2
        (local.tee $8
         (ref.cast (ref $type44)
          (local.get $6)
         )
        )
       )
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global985)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global912)
        )
       )
       (local.set $scratch_15
        (i64.sub
         (i64.const -1)
         (struct.get $type47 0
          (struct.get $type40 2
           (local.get $1)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global963)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global950)
        )
       )
       (local.set $2
        (call $function248
         (local.get $4)
         (i32.const 0)
         (i32.const 1)
         (local.get $4)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global950)
        )
       )
       (local.set $3
        (call $function248
         (local.get $3)
         (i32.const 0)
         (i32.const 1)
         (local.get $3)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global961)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global950)
        )
       )
       (local.set $9
        (i64.add
         (local.tee $12
          (struct.get $type47 0
           (struct.get $type46 0
            (call $function248
             (local.get $2)
             (i32.const 0)
             (i32.const 1)
             (local.get $2)
            )
           )
          )
         )
         (block (result i64)
          (drop
           (ref.as_non_null
            (global.get $global961)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global950)
           )
          )
          (local.tee $13
           (struct.get $type47 0
            (struct.get $type46 0
             (call $function248
              (local.get $3)
              (i32.const 0)
              (i32.const 1)
              (local.get $3)
             )
            )
           )
          )
         )
        )
       )
       (if
        (i64.gt_s
         (local.get $12)
         (local.get $13)
        )
        (then
         (struct.set $type48 0
          (struct.get $type46 1
           (local.get $3)
          )
          (struct.new $type51
           (local.get $2)
          )
         )
         (struct.set $type47 0
          (struct.get $type46 0
           (local.get $2)
          )
          (local.get $9)
         )
        )
        (else
         (struct.set $type48 0
          (struct.get $type46 1
           (local.get $2)
          )
          (struct.new $type51
           (local.get $3)
          )
         )
         (struct.set $type47 0
          (struct.get $type46 0
           (local.get $3)
          )
          (local.get $9)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global914)
        )
       )
       (local.get $scratch_15)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1005)
     )
    )
    (struct.set $type47 0
     (struct.get $type44 2
      (local.get $8)
     )
     (local.get $9)
    )
    (drop
     (ref.as_non_null
      (global.get $global961)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global950)
     )
    )
    (i64.eq
     (struct.get $type47 0
      (struct.get $type46 0
       (call $function248
        (local.get $4)
        (i32.const 0)
        (i32.const 1)
        (local.get $4)
       )
      )
     )
     (struct.get $environment272 0
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function274 (type $54) (param $0 (ref $type250)) (param $1 (ref $type59)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.ge_s
    (local.get $4)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call $function272
      (struct.get $type250 0
       (local.get $0)
      )
      (array.get $type59
       (local.get $1)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function274
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.sub
        (local.get $4)
        (i64.const 1)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function277 (type $call278) (param $0 (ref null $environment277)) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $type55))
  (local $3 (ref $type42))
  (local $4 (ref $type57))
  (local $5 (ref $type283))
  (local $6 (ref $type44))
  (local $7 (ref $type47))
  (local $8 (ref $type285))
  (local $9 (ref $type313))
  (drop
   (ref.as_non_null
    (global.get $global889)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global892)
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type56)
      (local.tee $2
       (struct.get $environment277 4
        (local.get $0)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.cast (ref $type57)
        (local.get $2)
       )
      )
      (i32.const 1)
     )
    )
    (then
     (if
      (ref.test (ref $type56)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global886)
      )
     )
     (local.set $3
      (struct.get $type57 0
       (ref.cast (ref $type57)
        (local.get $2)
       )
      )
     )
     (if
      (ref.test (ref $type43)
       (local.get $1)
      )
      (then
       (unreachable)
      )
     )
     (ref.eq
      (struct.get $type44 2
       (ref.cast (ref $type44)
        (local.get $1)
       )
      )
      (block (result (ref $type47))
       (if
        (ref.test (ref $type43)
         (local.get $3)
        )
        (then
         (unreachable)
        )
       )
       (struct.get $type44 2
        (ref.cast (ref $type44)
         (local.get $3)
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $4
     (struct.new $type57
      (struct.get $environment277 3
       (local.get $0)
      )
     )
    )
    (drop
     (struct.get $environment277 2
      (local.get $0)
     )
    )
    (local.set $5
     (struct.get $environment277 0
      (local.get $0)
     )
    )
    (local.set $8
     (struct.get $environment277 1
      (local.get $0)
     )
    )
    (local.set $9
     (struct.get $environment277 2
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1010)
     )
    )
    (if
     (ref.test (ref $type43)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type54 0
     (struct.get $type44 3
      (local.tee $6
       (ref.cast (ref $type44)
        (local.get $1)
       )
      )
     )
     (local.get $4)
    )
    (return_call $function314
     (struct.new $type278
      (ref.func $function277)
      (struct.new $environment277
       (local.get $5)
       (local.get $8)
       (local.get $9)
       (local.get $6)
       (local.get $4)
      )
     )
     (local.get $5)
     (local.get $6)
    )
   )
  )
 )
 (func $function278 (type $call278) (param $0 (ref null $environment277)) (param $1 (ref $type42)) (result i32)
  (return_call $function279
   (i32.const 0)
   (i32.const 1)
   (local.get $1)
   (global.get $empty56)
  )
 )
 (func $function279 (type $49) (param $0 i32) (param $1 i32) (param $2 (ref $type42)) (param $3 (ref $type55)) (result i32)
  (local $4 (ref $type55))
  (local $5 (ref $type44))
  (drop
   (ref.as_non_null
    (global.get $global1008)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type54 0
    (struct.get $type44 3
     (local.tee $5
      (ref.cast (ref $type44)
       (local.get $2)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1010)
   )
  )
  (struct.set $type54 0
   (struct.get $type44 3
    (local.get $5)
   )
   (local.get $3)
  )
  (drop
   (ref.as_non_null
    (global.get $global892)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $4)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $4)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (ref.test (ref $type56)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type57 0
      (ref.cast (ref $type57)
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function279
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (struct.new $type57
      (local.get $5)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function280 (type $call271) (param $0 (ref $type42)) (result i64)
  (local $1 (ref $type55))
  (local $2 (ref $type55))
  (drop
   (ref.as_non_null
    (global.get $global1008)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global892)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.get $0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type56)
     (local.tee $1
      (struct.get $type54 0
       (struct.get $type44 3
        (ref.cast (ref $type44)
         (local.get $0)
        )
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $1)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (ref.test (ref $type56)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1008)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global892)
     )
    )
    (if
     (ref.test (ref $type43)
      (local.tee $0
       (struct.get $type57 0
        (ref.cast (ref $type57)
         (local.get $1)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (ref.test (ref $type56)
       (local.tee $1
        (struct.get $type54 0
         (struct.get $type44 3
          (ref.cast (ref $type44)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (if
       (ref.test (ref $type56)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1008)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global892)
       )
      )
      (if
       (ref.test (ref $type43)
        (local.tee $0
         (struct.get $type57 0
          (ref.cast (ref $type57)
           (local.get $1)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if (result i64)
       (if (result i32)
        (ref.test (ref $type56)
         (local.tee $1
          (struct.get $type54 0
           (struct.get $type44 3
            (ref.cast (ref $type44)
             (local.get $0)
            )
           )
          )
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (ref.cast (ref $type57)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
       )
       (then
        (if
         (ref.test (ref $type56)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1008)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global892)
         )
        )
        (if
         (ref.test (ref $type43)
          (local.tee $0
           (struct.get $type57 0
            (ref.cast (ref $type57)
             (local.get $1)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if (result i64)
         (if (result i32)
          (ref.test (ref $type56)
           (local.tee $1
            (struct.get $type54 0
             (struct.get $type44 3
              (ref.cast (ref $type44)
               (local.get $0)
              )
             )
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.cast (ref $type57)
             (local.get $1)
            )
           )
           (i32.const 1)
          )
         )
         (then
          (if
           (ref.test (ref $type56)
            (local.get $1)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1008)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global892)
           )
          )
          (if
           (ref.test (ref $type43)
            (local.tee $0
             (struct.get $type57 0
              (ref.cast (ref $type57)
               (local.get $1)
              )
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (if (result i64)
           (if (result i32)
            (ref.test (ref $type56)
             (local.tee $1
              (struct.get $type54 0
               (struct.get $type44 3
                (ref.cast (ref $type44)
                 (local.get $0)
                )
               )
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (ref.cast (ref $type57)
               (local.get $1)
              )
             )
             (i32.const 1)
            )
           )
           (then
            (if
             (ref.test (ref $type56)
              (local.get $1)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1008)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global892)
             )
            )
            (if
             (ref.test (ref $type43)
              (local.tee $0
               (struct.get $type57 0
                (ref.cast (ref $type57)
                 (local.get $1)
                )
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (if (result i64)
             (if (result i32)
              (ref.test (ref $type56)
               (local.tee $1
                (struct.get $type54 0
                 (struct.get $type44 3
                  (ref.cast (ref $type44)
                   (local.get $0)
                  )
                 )
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.cast (ref $type57)
                 (local.get $1)
                )
               )
               (i32.const 1)
              )
             )
             (then
              (if
               (ref.test (ref $type56)
                (local.get $1)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1008)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global892)
               )
              )
              (if
               (ref.test (ref $type43)
                (local.tee $0
                 (struct.get $type57 0
                  (ref.cast (ref $type57)
                   (local.get $1)
                  )
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (if (result i64)
               (if (result i32)
                (ref.test (ref $type56)
                 (local.tee $1
                  (struct.get $type54 0
                   (struct.get $type44 3
                    (ref.cast (ref $type44)
                     (local.get $0)
                    )
                   )
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (ref.cast (ref $type57)
                   (local.get $1)
                  )
                 )
                 (i32.const 1)
                )
               )
               (then
                (if
                 (ref.test (ref $type56)
                  (local.get $1)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global1008)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global892)
                 )
                )
                (if
                 (ref.test (ref $type43)
                  (local.tee $0
                   (struct.get $type57 0
                    (ref.cast (ref $type57)
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i64)
                 (if (result i32)
                  (ref.test (ref $type56)
                   (local.tee $1
                    (struct.get $type54 0
                     (struct.get $type44 3
                      (ref.cast (ref $type44)
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type57)
                     (local.get $1)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (then
                  (if
                   (ref.test (ref $type56)
                    (local.get $1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global1008)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global892)
                   )
                  )
                  (if
                   (ref.test (ref $type43)
                    (local.tee $0
                     (struct.get $type57 0
                      (ref.cast (ref $type57)
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if (result i64)
                   (if (result i32)
                    (ref.test (ref $type56)
                     (local.tee $2
                      (local.tee $1
                       (struct.get $type54 0
                        (struct.get $type44 3
                         (ref.cast (ref $type44)
                          (local.get $0)
                         )
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (ref.cast (ref $type57)
                       (local.get $2)
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (then
                    (if
                     (ref.test (ref $type56)
                      (local.get $1)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global1008)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global892)
                     )
                    )
                    (if
                     (ref.test (ref $type43)
                      (local.tee $0
                       (struct.get $type57 0
                        (ref.cast (ref $type57)
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if (result i64)
                     (call $function234
                      (local.tee $1
                       (struct.get $type54 0
                        (struct.get $type44 3
                         (ref.cast (ref $type44)
                          (local.get $0)
                         )
                        )
                       )
                      )
                     )
                     (then
                      (if
                       (ref.test (ref $type56)
                        (local.get $1)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global1008)
                       )
                      )
                      (return_call $function281
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                       (call $function267
                        (struct.get $type57 0
                         (ref.cast (ref $type57)
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i64.const 9)
                     )
                    )
                   )
                   (else
                    (i64.const 8)
                   )
                  )
                 )
                 (else
                  (i64.const 7)
                 )
                )
               )
               (else
                (i64.const 6)
               )
              )
             )
             (else
              (i64.const 5)
             )
            )
           )
           (else
            (i64.const 4)
           )
          )
         )
         (else
          (i64.const 3)
         )
        )
       )
       (else
        (i64.const 2)
       )
      )
     )
     (else
      (i64.const 1)
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function281 (type $47) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref $type55)) (result i64)
  (drop
   (ref.as_non_null
    (global.get $global892)
   )
  )
  (if (result i64)
   (call $function234
    (local.get $3)
   )
   (then
    (if
     (ref.test (ref $type56)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1008)
     )
    )
    (local.set $3
     (call $function267
      (struct.get $type57 0
       (ref.cast (ref $type57)
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function281
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
     (local.get $3)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function282 (type $call278) (param $0 (ref null $environment277)) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $type55))
  (local $3 (ref $type44))
  (local $4 (ref $type42))
  (drop
   (ref.as_non_null
    (global.get $global1015)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type58 0
   (struct.get $type44 4
    (local.tee $3
     (ref.cast (ref $type44)
      (local.get $1)
     )
    )
   )
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global1008)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global892)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type56)
     (local.tee $2
      (struct.get $type54 0
       (struct.get $type44 3
        (local.get $3)
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $2)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (ref.test (ref $type56)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1015)
     )
    )
    (if
     (ref.test (ref $type43)
      (local.tee $1
       (struct.get $type57 0
        (ref.cast (ref $type57)
         (local.get $2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type58 0
     (struct.get $type44 4
      (local.tee $3
       (ref.cast (ref $type44)
        (local.get $1)
       )
      )
     )
     (i32.const 1)
    )
    (drop
     (ref.as_non_null
      (global.get $global1008)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global892)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type56)
       (local.tee $2
        (struct.get $type54 0
         (struct.get $type44 3
          (local.get $3)
         )
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $2)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (if
       (ref.test (ref $type56)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1015)
       )
      )
      (if
       (ref.test (ref $type43)
        (local.tee $1
         (struct.get $type57 0
          (ref.cast (ref $type57)
           (local.get $2)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type58 0
       (struct.get $type44 4
        (local.tee $3
         (ref.cast (ref $type44)
          (local.get $1)
         )
        )
       )
       (i32.const 1)
      )
      (drop
       (ref.as_non_null
        (global.get $global1008)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global892)
       )
      )
      (if (result i32)
       (if (result i32)
        (ref.test (ref $type56)
         (local.tee $2
          (struct.get $type54 0
           (struct.get $type44 3
            (local.get $3)
           )
          )
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (ref.cast (ref $type57)
           (local.get $2)
          )
         )
         (i32.const 1)
        )
       )
       (then
        (if
         (ref.test (ref $type56)
          (local.get $2)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1015)
         )
        )
        (if
         (ref.test (ref $type43)
          (local.tee $1
           (struct.get $type57 0
            (ref.cast (ref $type57)
             (local.get $2)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (struct.set $type58 0
         (struct.get $type44 4
          (local.tee $3
           (ref.cast (ref $type44)
            (local.get $1)
           )
          )
         )
         (i32.const 1)
        )
        (drop
         (ref.as_non_null
          (global.get $global1008)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global892)
         )
        )
        (if (result i32)
         (if (result i32)
          (ref.test (ref $type56)
           (local.tee $2
            (struct.get $type54 0
             (struct.get $type44 3
              (local.get $3)
             )
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.cast (ref $type57)
             (local.get $2)
            )
           )
           (i32.const 1)
          )
         )
         (then
          (if
           (ref.test (ref $type56)
            (local.get $2)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1015)
           )
          )
          (if
           (ref.test (ref $type43)
            (local.tee $1
             (struct.get $type57 0
              (ref.cast (ref $type57)
               (local.get $2)
              )
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.set $type58 0
           (struct.get $type44 4
            (local.tee $3
             (ref.cast (ref $type44)
              (local.get $1)
             )
            )
           )
           (i32.const 1)
          )
          (drop
           (ref.as_non_null
            (global.get $global1008)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global892)
           )
          )
          (if (result i32)
           (if (result i32)
            (ref.test (ref $type56)
             (local.tee $2
              (struct.get $type54 0
               (struct.get $type44 3
                (local.get $3)
               )
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (ref.cast (ref $type57)
               (local.get $2)
              )
             )
             (i32.const 1)
            )
           )
           (then
            (if
             (ref.test (ref $type56)
              (local.get $2)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1015)
             )
            )
            (if
             (ref.test (ref $type43)
              (local.tee $1
               (struct.get $type57 0
                (ref.cast (ref $type57)
                 (local.get $2)
                )
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.set $type58 0
             (struct.get $type44 4
              (local.tee $3
               (ref.cast (ref $type44)
                (local.get $1)
               )
              )
             )
             (i32.const 1)
            )
            (drop
             (ref.as_non_null
              (global.get $global1008)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global892)
             )
            )
            (if (result i32)
             (if (result i32)
              (ref.test (ref $type56)
               (local.tee $2
                (struct.get $type54 0
                 (struct.get $type44 3
                  (local.get $3)
                 )
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.cast (ref $type57)
                 (local.get $2)
                )
               )
               (i32.const 1)
              )
             )
             (then
              (if
               (ref.test (ref $type56)
                (local.get $2)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1015)
               )
              )
              (if
               (ref.test (ref $type43)
                (local.tee $1
                 (struct.get $type57 0
                  (ref.cast (ref $type57)
                   (local.get $2)
                  )
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.set $type58 0
               (struct.get $type44 4
                (local.tee $3
                 (ref.cast (ref $type44)
                  (local.get $1)
                 )
                )
               )
               (i32.const 1)
              )
              (drop
               (ref.as_non_null
                (global.get $global1008)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global892)
               )
              )
              (if (result i32)
               (if (result i32)
                (ref.test (ref $type56)
                 (local.tee $2
                  (struct.get $type54 0
                   (struct.get $type44 3
                    (ref.cast (ref $type44)
                     (local.get $3)
                    )
                   )
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (ref.cast (ref $type57)
                   (local.get $2)
                  )
                 )
                 (i32.const 1)
                )
               )
               (then
                (if
                 (ref.test (ref $type56)
                  (local.get $2)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global1015)
                 )
                )
                (if
                 (ref.test (ref $type43)
                  (local.tee $1
                   (struct.get $type57 0
                    (ref.cast (ref $type57)
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (struct.set $type58 0
                 (struct.get $type44 4
                  (ref.cast (ref $type44)
                   (local.get $1)
                  )
                 )
                 (i32.const 1)
                )
                (drop
                 (ref.as_non_null
                  (global.get $global1008)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global892)
                 )
                )
                (if
                 (ref.test (ref $type43)
                  (local.get $1)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result i32)
                 (if (result i32)
                  (ref.test (ref $type56)
                   (local.tee $2
                    (struct.get $type54 0
                     (struct.get $type44 3
                      (ref.cast (ref $type44)
                       (local.get $1)
                      )
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type57)
                     (local.get $2)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (then
                  (if
                   (ref.test (ref $type56)
                    (local.get $2)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global1015)
                   )
                  )
                  (if
                   (ref.test (ref $type43)
                    (local.tee $4
                     (local.tee $1
                      (struct.get $type57 0
                       (ref.cast (ref $type57)
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.set $type58 0
                   (struct.get $type44 4
                    (ref.cast (ref $type44)
                     (local.get $4)
                    )
                   )
                   (i32.const 1)
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global1008)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global892)
                   )
                  )
                  (if
                   (ref.test (ref $type43)
                    (local.get $1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if (result i32)
                   (if (result i32)
                    (ref.test (ref $type56)
                     (local.tee $2
                      (struct.get $type54 0
                       (struct.get $type44 3
                        (ref.cast (ref $type44)
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (ref.cast (ref $type57)
                       (local.get $2)
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (then
                    (if
                     (ref.test (ref $type56)
                      (local.get $2)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global1015)
                     )
                    )
                    (call $function270
                     (local.tee $1
                      (struct.get $type57 0
                       (ref.cast (ref $type57)
                        (local.get $2)
                       )
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global1008)
                     )
                    )
                    (local.set $2
                     (call $function267
                      (local.get $1)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global892)
                     )
                    )
                    (if (result i32)
                     (call $function234
                      (local.get $2)
                     )
                     (then
                      (if
                       (ref.test (ref $type56)
                        (local.get $2)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (return_call $function283
                       (i32.const 0)
                       (i32.const 1)
                       (struct.get $type57 0
                        (ref.cast (ref $type57)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function283 (type $46) (param $0 i32) (param $1 i32) (param $2 (ref $type42)) (result i32)
  (local $3 (ref $type55))
  (drop
   (ref.as_non_null
    (global.get $global1015)
   )
  )
  (call $function270
   (local.get $2)
  )
  (drop
   (ref.as_non_null
    (global.get $global1008)
   )
  )
  (local.set $3
   (call $function267
    (local.get $2)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global892)
   )
  )
  (if (result i32)
   (call $function234
    (local.get $3)
   )
   (then
    (if
     (ref.test (ref $type56)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type57 0
      (ref.cast (ref $type57)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function283
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function295 (type $45) (param $0 i64) (param $1 i64) (param $2 (ref $type295)) (result (ref $type283))
  (local $3 i64)
  (local $4 (ref $type279))
  (if
   (i64.gt_u
    (local.tee $3
     (i64.mul
      (local.get $0)
      (local.get $1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (array.new $type279
    (global.get $empty43)
    (i32.wrap_i64
     (local.get $3)
    )
   )
  )
  (drop
   (if (result i32)
    (i64.lt_s
     (local.tee $3
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
     )
     (i64.const 0)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call $function297
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $3)
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
       (i64.mul
        (local.get $1)
        (local.get $3)
       )
      )
     )
     (if (result i32)
      (i64.lt_s
       (local.tee $3
        (i64.sub
         (local.get $3)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call $function297
         (local.get $1)
         (local.get $2)
         (local.get $4)
         (local.get $3)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
         (i64.mul
          (local.get $1)
          (local.get $3)
         )
        )
       )
       (if (result i32)
        (i64.lt_s
         (local.tee $3
          (i64.sub
           (local.get $3)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call $function297
           (local.get $1)
           (local.get $2)
           (local.get $4)
           (local.get $3)
           (i32.const 0)
           (i32.const 1)
           (i64.const 0)
           (i64.mul
            (local.get $1)
            (local.get $3)
           )
          )
         )
         (if (result i32)
          (i64.lt_s
           (local.tee $3
            (i64.sub
             (local.get $3)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call $function297
             (local.get $1)
             (local.get $2)
             (local.get $4)
             (local.get $3)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.mul
              (local.get $1)
              (local.get $3)
             )
            )
           )
           (if (result i32)
            (i64.lt_s
             (local.tee $3
              (i64.sub
               (local.get $3)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call $function297
               (local.get $1)
               (local.get $2)
               (local.get $4)
               (local.get $3)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.mul
                (local.get $1)
                (local.get $3)
               )
              )
             )
             (if (result i32)
              (i64.lt_s
               (local.tee $3
                (i64.sub
                 (local.get $3)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call $function297
                 (local.get $1)
                 (local.get $2)
                 (local.get $4)
                 (local.get $3)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.const 0)
                 (i64.mul
                  (local.get $1)
                  (local.get $3)
                 )
                )
               )
               (if (result i32)
                (i64.lt_s
                 (local.tee $3
                  (i64.sub
                   (local.get $3)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call $function297
                   (local.get $1)
                   (local.get $2)
                   (local.get $4)
                   (local.get $3)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.const 0)
                   (i64.mul
                    (local.get $1)
                    (local.get $3)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.lt_s
                   (local.tee $3
                    (i64.sub
                     (local.get $3)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call $function297
                     (local.get $1)
                     (local.get $2)
                     (local.get $4)
                     (local.get $3)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.const 0)
                     (i64.mul
                      (local.get $1)
                      (local.get $3)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.lt_s
                     (local.tee $3
                      (i64.sub
                       (local.get $3)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call $function297
                       (local.get $1)
                       (local.get $2)
                       (local.get $4)
                       (local.get $3)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 0)
                       (i64.mul
                        (local.get $1)
                        (local.get $3)
                       )
                      )
                     )
                     (if (result i32)
                      (i64.lt_s
                       (local.tee $3
                        (i64.sub
                         (local.get $3)
                         (i64.const 1)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (call $function297
                         (local.get $1)
                         (local.get $2)
                         (local.get $4)
                         (local.get $3)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.const 0)
                         (i64.mul
                          (local.get $1)
                          (local.get $3)
                         )
                        )
                       )
                       (call $function296
                        (local.get $1)
                        (local.get $2)
                        (local.get $4)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.sub
                         (local.get $3)
                         (i64.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1057)
   )
  )
  (struct.new $type283
   (struct.new $type47
    (local.get $0)
   )
   (struct.new $type47
    (local.get $1)
   )
   (struct.new $type284
    (local.get $4)
   )
  )
 )
 (func $function296 (type $42) (param $0 i64) (param $1 (ref $type295)) (param $2 (ref $type279)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (if (result i32)
   (i64.lt_s
    (local.get $5)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function297
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $5)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.mul
       (local.get $0)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function296
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function297 (type $41) (param $0 i64) (param $1 (ref $type295)) (param $2 (ref $type279)) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result i32)
  (local $8 i64)
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global914)
     )
    )
    (local.set $8
     (i64.add
      (call $function240
       (local.get $6)
       (i64.const 1)
      )
      (i64.shl
       (local.get $3)
       (i64.const 1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global948)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global990)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type279
     (local.get $2)
     (i32.wrap_i64
      (local.get $7)
     )
     (struct.new $type44
      (struct.new $type45
       (struct.new $type46
        (struct.new $type47
         (i64.const 1)
        )
        (struct.new $type48
         (global.get $empty50)
        )
       )
      )
      (struct.new $type52
       (struct.new $type53
        (i64.mul
         (local.get $6)
         (i64.const 3)
        )
        (local.get $8)
       )
      )
      (struct.new $type47
       (i64.const -1)
      )
      (struct.new $type54
       (global.get $empty56)
      )
      (struct.new_default $type58)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function297
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.add
      (local.get $7)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function303 (type $call297) (param $0 (ref $type283)) (result (ref $type59))
  (local $1 (ref null $type39))
  (local $2 (ref null $type39))
  (local $3 (ref $type59))
  (local $4 (ref $type314))
  (local $5 (ref $type42))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global1061)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1066)
   )
  )
  (drop
   (call $function305
    (local.get $0)
    (struct.get $type47 0
     (struct.get $type283 0
      (local.get $0)
     )
    )
    (local.tee $9
     (i64.mul
      (i64.sub
       (local.tee $6
        (struct.get $type47 0
         (struct.get $type283 1
          (local.get $0)
         )
        )
       )
       (i64.const 1)
      )
      (i64.const 3)
     )
    )
    (local.tee $4
     (struct.new_default $type314)
    )
    (i32.const 0)
    (i32.const 0)
    (i32.const 1)
    (i64.mul
     (i64.sub
      (local.get $6)
      (i64.const 1)
     )
     (i64.const 3)
    )
   )
  )
  (drop
   (if (result i32)
    (i64.gt_s
     (local.get $6)
     (i64.const 1)
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (local.set $8
      (i64.add
       (i64.mul
        (call $function241
         (i64.sub
          (local.get $6)
          (i64.const 2)
         )
         (i64.const 2)
        )
        (i64.const 6)
       )
       (i64.const 3)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1079)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (local.set $7
      (call $function241
       (i64.const 1)
       (i64.const 2)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (if
      (i64.gt_u
       (local.tee $6
        (i64.add
         (call $function241
          (local.get $8)
          (i64.const 3)
         )
         (block (result i64)
          (drop
           (ref.as_non_null
            (global.get $global1071)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1066)
           )
          )
          (i64.mul
           (local.get $7)
           (struct.get $type47 0
            (struct.get $type283 1
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (local.set $5
      (array.get $type279
       (struct.get $type284 0
        (struct.get $type283 2
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
     (if
      (i64.lt_s
       (local.get $8)
       (local.get $9)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global1079)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global918)
        )
       )
       (local.set $7
        (call $function241
         (i64.const 0)
         (i64.const 2)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global918)
        )
       )
       (if
        (i64.gt_u
         (local.tee $6
          (i64.add
           (call $function241
            (local.get $9)
            (i64.const 3)
           )
           (block (result i64)
            (drop
             (ref.as_non_null
              (global.get $global1071)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1066)
             )
            )
            (i64.mul
             (local.get $7)
             (struct.get $type47 0
              (struct.get $type283 1
               (local.get $0)
              )
             )
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global971)
        )
       )
       (struct.set $type314 0
        (local.get $4)
        (struct.new $type39
         (struct.new $type40
          (struct.new $type41
           (local.get $5)
          )
          (struct.new $type41
           (array.get $type279
            (struct.get $type284 0
             (struct.get $type283 2
              (local.get $0)
             )
            )
            (i32.wrap_i64
             (local.get $6)
            )
           )
          )
          (struct.new $type47
           (i64.const 4)
          )
         )
         (struct.get $type314 0
          (local.get $4)
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1079)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (local.set $7
      (call $function241
       (i64.const 0)
       (i64.const 2)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (if
      (i64.gt_u
       (local.tee $6
        (i64.add
         (call $function241
          (i64.sub
           (local.get $8)
           (i64.const 3)
          )
          (i64.const 3)
         )
         (block (result i64)
          (drop
           (ref.as_non_null
            (global.get $global1071)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1066)
           )
          )
          (i64.mul
           (local.get $7)
           (struct.get $type47 0
            (struct.get $type283 1
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global971)
      )
     )
     (struct.set $type314 0
      (local.get $4)
      (struct.new $type39
       (struct.new $type40
        (struct.new $type41
         (local.get $5)
        )
        (struct.new $type41
         (array.get $type279
          (struct.get $type284 0
           (struct.get $type283 2
            (local.get $0)
           )
          )
          (i32.wrap_i64
           (local.get $6)
          )
         )
        )
        (struct.new $type47
         (i64.const 1)
        )
       )
       (struct.get $type314 0
        (local.get $4)
       )
      )
     )
     (call $function308
      (local.get $0)
      (local.get $4)
      (i32.const 0)
      (i32.const 0)
      (i32.const 1)
      (i64.sub
       (local.get $8)
       (i64.const 6)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1143)
   )
  )
  (if (result (ref $type59))
   (ref.is_null
    (local.tee $2
     (struct.get $type314 0
      (local.get $4)
     )
    )
   )
   (then
    (array.new_fixed $type59 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready1146)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1146)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (if (result i64)
        (ref.is_null
         (local.get $2)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $1
            (struct.get $type39 1
             (local.get $2)
            )
           )
          )
          (then
           (i64.const 1)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $1
              (struct.get $type39 1
               (local.get $1)
              )
             )
            )
            (then
             (i64.const 2)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $1
                (struct.get $type39 1
                 (local.get $1)
                )
               )
              )
              (then
               (i64.const 3)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $1
                  (struct.get $type39 1
                   (local.get $1)
                  )
                 )
                )
                (then
                 (i64.const 4)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $1
                    (struct.get $type39 1
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i64.const 5)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $1
                      (struct.get $type39 1
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (i64.const 6)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $1
                        (struct.get $type39 1
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i64.const 7)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $1
                          (struct.get $type39 1
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (i64.const 8)
                        )
                        (else
                         (call $function311
                          (i32.const 0)
                          (i32.const 1)
                          (struct.get $type39 1
                           (local.get $1)
                          )
                          (i64.const 9)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.new $type59
      (struct.get $type39 0
       (local.get $2)
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
    (if (result (ref $type59))
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (array.set $type59
       (local.get $3)
       (i32.const 0)
       (struct.get $type39 0
        (local.get $2)
       )
      )
      (if (result (ref $type59))
       (ref.is_null
        (local.tee $1
         (struct.get $type39 1
          (local.get $2)
         )
        )
       )
       (then
        (local.get $3)
       )
       (else
        (array.set $type59
         (local.get $3)
         (i32.const 1)
         (struct.get $type39 0
          (local.get $1)
         )
        )
        (if (result (ref $type59))
         (ref.is_null
          (local.tee $1
           (struct.get $type39 1
            (local.get $1)
           )
          )
         )
         (then
          (local.get $3)
         )
         (else
          (array.set $type59
           (local.get $3)
           (i32.const 2)
           (struct.get $type39 0
            (local.get $1)
           )
          )
          (if (result (ref $type59))
           (ref.is_null
            (local.tee $1
             (struct.get $type39 1
              (local.get $1)
             )
            )
           )
           (then
            (local.get $3)
           )
           (else
            (array.set $type59
             (local.get $3)
             (i32.const 3)
             (struct.get $type39 0
              (local.get $1)
             )
            )
            (if (result (ref $type59))
             (ref.is_null
              (local.tee $1
               (struct.get $type39 1
                (local.get $1)
               )
              )
             )
             (then
              (local.get $3)
             )
             (else
              (array.set $type59
               (local.get $3)
               (i32.const 4)
               (struct.get $type39 0
                (local.get $1)
               )
              )
              (if (result (ref $type59))
               (ref.is_null
                (local.tee $1
                 (struct.get $type39 1
                  (local.get $1)
                 )
                )
               )
               (then
                (local.get $3)
               )
               (else
                (array.set $type59
                 (local.get $3)
                 (i32.const 5)
                 (struct.get $type39 0
                  (local.get $1)
                 )
                )
                (if (result (ref $type59))
                 (ref.is_null
                  (local.tee $1
                   (struct.get $type39 1
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (array.set $type59
                   (local.get $3)
                   (i32.const 6)
                   (struct.get $type39 0
                    (local.get $1)
                   )
                  )
                  (if (result (ref $type59))
                   (ref.is_null
                    (local.tee $1
                     (struct.get $type39 1
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (array.set $type59
                     (local.get $3)
                     (i32.const 7)
                     (struct.get $type39 0
                      (local.get $1)
                     )
                    )
                    (if (result (ref $type59))
                     (ref.is_null
                      (local.tee $1
                       (struct.get $type39 1
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (local.get $3)
                     )
                     (else
                      (array.set $type59
                       (local.get $3)
                       (i32.const 8)
                       (struct.get $type39 0
                        (local.get $1)
                       )
                      )
                      (return_call $function312
                       (local.get $3)
                       (i32.const 0)
                       (i32.const 1)
                       (struct.get $type39 1
                        (local.get $1)
                       )
                       (i64.const 9)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function305 (type $35) (param $0 (ref $type283)) (param $1 i64) (param $2 i64) (param $3 (ref $type314)) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (result i32)
  (if (result i32)
   (i64.lt_s
    (local.get $7)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global914)
     )
    )
    (drop
     (call $function306
      (local.get $0)
      (local.get $2)
      (local.get $3)
      (local.get $4)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (i64.add
       (call $function240
        (local.get $7)
        (i64.const 1)
       )
       (i64.shl
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
        (i64.const 1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function305
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.sub
      (local.get $7)
      (i64.const 3)
     )
    )
   )
  )
 )
 (func $function306 (type $34) (param $0 (ref $type283)) (param $1 i64) (param $2 (ref $type314)) (param $3 i32) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i64) (result i32)
  (local $8 i64)
  (local $9 i64)
  (local $10 (ref $type42))
  (if (result i32)
   (i64.le_s
    (local.get $7)
    (i64.const 1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1079)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $8
     (call $function241
      (local.get $7)
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (call $function241
         (local.get $4)
         (i64.const 3)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (i64.mul
          (local.get $8)
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (array.get $type279
      (struct.get $type284 0
       (struct.get $type283 2
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $8)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1137)
     )
    )
    (if
     (i64.ne
      (local.get $4)
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1079)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global918)
       )
      )
      (local.set $8
       (call $function241
        (i64.sub
         (local.get $7)
         (i64.const 1)
        )
        (i64.const 2)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global918)
       )
      )
      (if
       (i64.gt_u
        (local.tee $8
         (i64.add
          (call $function241
           (i64.sub
            (local.get $4)
            (i64.const 3)
           )
           (i64.const 3)
          )
          (block (result i64)
           (drop
            (ref.as_non_null
             (global.get $global1071)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1066)
            )
           )
           (i64.mul
            (local.get $8)
            (struct.get $type47 0
             (struct.get $type283 1
              (local.get $0)
             )
            )
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global971)
       )
      )
      (struct.set $type314 0
       (local.get $2)
       (struct.new $type39
        (struct.new $type40
         (struct.new $type41
          (local.get $10)
         )
         (struct.new $type41
          (array.get $type279
           (struct.get $type284 0
            (struct.get $type283 2
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (struct.new $type47
          (i64.const 1)
         )
        )
        (struct.get $type314 0
         (local.get $2)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1079)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $8
     (call $function241
      (i64.sub
       (local.get $7)
       (i64.const 2)
      )
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (call $function241
         (local.get $4)
         (i64.const 3)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (i64.mul
          (local.get $8)
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global971)
     )
    )
    (struct.set $type314 0
     (local.get $2)
     (struct.new $type39
      (struct.new $type40
       (struct.new $type41
        (local.get $10)
       )
       (struct.new $type41
        (array.get $type279
         (struct.get $type284 0
          (struct.get $type283 2
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
       (struct.new $type47
        (i64.const 2)
       )
      )
      (struct.get $type314 0
       (local.get $2)
      )
     )
    )
    (if
     (i64.gt_s
      (local.get $1)
      (local.get $4)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1079)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global918)
       )
      )
      (local.set $8
       (call $function241
        (i64.sub
         (local.get $7)
         (i64.const 1)
        )
        (i64.const 2)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global918)
       )
      )
      (if
       (i64.gt_u
        (local.tee $8
         (i64.add
          (call $function241
           (i64.add
            (local.get $4)
            (i64.const 3)
           )
           (i64.const 3)
          )
          (block (result i64)
           (drop
            (ref.as_non_null
             (global.get $global1071)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1066)
            )
           )
           (i64.mul
            (local.get $8)
            (struct.get $type47 0
             (struct.get $type283 1
              (local.get $0)
             )
            )
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global971)
       )
      )
      (struct.set $type314 0
       (local.get $2)
       (struct.new $type39
        (struct.new $type40
         (struct.new $type41
          (local.get $10)
         )
         (struct.new $type41
          (array.get $type279
           (struct.get $type284 0
            (struct.get $type283 2
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (struct.new $type47
          (i64.const 4)
         )
        )
        (struct.get $type314 0
         (local.get $2)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function306
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.sub
      (local.get $7)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function308 (type $33) (param $0 (ref $type283)) (param $1 (ref $type314)) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 (ref $type42))
  (if (result i32)
   (i64.lt_s
    (local.get $5)
    (i64.const 3)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1079)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $6
     (call $function241
      (i64.const 1)
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (call $function241
         (local.get $5)
         (i64.const 3)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (i64.mul
          (local.get $6)
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (array.get $type279
      (struct.get $type284 0
       (struct.get $type283 2
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1079)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $6
     (call $function241
      (i64.const 0)
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (call $function241
         (i64.sub
          (local.get $5)
          (i64.const 3)
         )
         (i64.const 3)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (i64.mul
          (local.get $6)
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global971)
     )
    )
    (struct.set $type314 0
     (local.get $1)
     (struct.new $type39
      (struct.new $type40
       (struct.new $type41
        (local.get $8)
       )
       (struct.new $type41
        (array.get $type279
         (struct.get $type284 0
          (struct.get $type283 2
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
       (struct.new $type47
        (i64.const 1)
       )
      )
      (struct.get $type314 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1079)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $6
     (call $function241
      (i64.const 1)
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (call $function241
         (local.get $5)
         (i64.const 3)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (i64.mul
          (local.get $6)
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (array.get $type279
      (struct.get $type284 0
       (struct.get $type283 2
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1079)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $6
     (call $function241
      (i64.const 0)
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (call $function241
         (i64.add
          (local.get $5)
          (i64.const 3)
         )
         (i64.const 3)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (i64.mul
          (local.get $6)
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global971)
     )
    )
    (struct.set $type314 0
     (local.get $1)
     (struct.new $type39
      (struct.new $type40
       (struct.new $type41
        (local.get $8)
       )
       (struct.new $type41
        (array.get $type279
         (struct.get $type284 0
          (struct.get $type283 2
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
       (struct.new $type47
        (i64.const 4)
       )
      )
      (struct.get $type314 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function308
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 6)
     )
    )
   )
  )
 )
 (func $function311 (type $32) (param $0 i32) (param $1 i32) (param $2 (ref null $type39)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type39 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function311
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function312 (type $31) (param $0 (ref $type59)) (param $1 i32) (param $2 i32) (param $3 (ref null $type39)) (param $4 i64) (result (ref $type59))
  (local $5 (ref $type40))
  (if (result (ref $type59))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (local.set $5
     (struct.get $type39 0
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type59
     (local.get $0)
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $5)
    )
    (local.set $3
     (struct.get $type39 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function312
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function314 (type $call285) (param $0 (ref $type278)) (param $1 (ref $type283)) (param $2 (ref $type44)) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i32)
  (local $11 (ref $type42))
  (local $12 (ref $type53))
  (local $scratch i64)
  (local $scratch_14 i64)
  (local $scratch_15 i64)
  (local $scratch_16 i64)
  (local $scratch_17 i64)
  (local $scratch_18 i64)
  (local $scratch_19 i64)
  (local $scratch_20 i64)
  (drop
   (ref.as_non_null
    (global.get $global1003)
   )
  )
  (local.set $6
   (struct.get $type47 0
    (struct.get $type44 2
     (local.get $2)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global998)
   )
  )
  (local.set $4
   (struct.get $type53 0
    (local.tee $12
     (struct.get $type52 0
      (struct.get $type44 1
       (local.get $2)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1061)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1066)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1168)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (i64.shl
    (i64.sub
     (struct.get $type47 0
      (struct.get $type283 0
       (local.get $1)
      )
     )
     (block (result i64)
      (local.set $9
       (struct.get $type47 0
        (struct.get $type283 1
         (local.get $1)
        )
       )
      )
      (local.set $7
       (struct.get $type53 1
        (local.get $12)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1168)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global914)
       )
      )
      (drop
       (if (result i32)
        (i64.eqz
         (block (result i64)
          (local.set $scratch
           (call $function240
            (local.get $6)
            (i64.const 1)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1137)
           )
          )
          (local.get $scratch)
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1079)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global918)
          )
         )
         (local.set $5
          (call $function241
           (i64.sub
            (local.get $7)
            (i64.const 1)
           )
           (i64.const 2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global918)
          )
         )
         (if
          (i64.gt_u
           (local.tee $5
            (i64.add
             (call $function241
              (i64.sub
               (local.get $4)
               (i64.const 3)
              )
              (i64.const 3)
             )
             (block (result i64)
              (drop
               (ref.as_non_null
                (global.get $global1071)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1066)
               )
              )
              (i64.mul
               (local.get $5)
               (struct.get $type47 0
                (struct.get $type283 1
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call278
          (struct.get $type278 1
           (local.get $0)
          )
          (array.get $type279
           (struct.get $type284 0
            (struct.get $type283 2
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (struct.get $type278 0
           (local.get $0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready1168)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1168)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global914)
       )
      )
      (drop
       (if (result i32)
        (i64.eqz
         (block (result i64)
          (local.set $scratch_14
           (call $function240
            (local.get $6)
            (i64.const 2)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1137)
           )
          )
          (local.get $scratch_14)
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1079)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global918)
          )
         )
         (local.set $5
          (call $function241
           (i64.sub
            (local.get $7)
            (i64.const 2)
           )
           (i64.const 2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global918)
          )
         )
         (if
          (i64.gt_u
           (local.tee $5
            (i64.add
             (call $function241
              (local.get $4)
              (i64.const 3)
             )
             (block (result i64)
              (drop
               (ref.as_non_null
                (global.get $global1071)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1066)
               )
              )
              (i64.mul
               (local.get $5)
               (struct.get $type47 0
                (struct.get $type283 1
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call278
          (struct.get $type278 1
           (local.get $0)
          )
          (array.get $type279
           (struct.get $type284 0
            (struct.get $type283 2
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (struct.get $type278 0
           (local.get $0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready1168)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1168)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global914)
       )
      )
      (drop
       (if (result i32)
        (i64.eqz
         (block (result i64)
          (local.set $scratch_15
           (call $function240
            (local.get $6)
            (i64.const 4)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1137)
           )
          )
          (local.get $scratch_15)
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1079)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global918)
          )
         )
         (local.set $6
          (call $function241
           (i64.sub
            (local.get $7)
            (i64.const 1)
           )
           (i64.const 2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global918)
          )
         )
         (if
          (i64.gt_u
           (local.tee $6
            (i64.add
             (call $function241
              (i64.add
               (local.get $4)
               (i64.const 3)
              )
              (i64.const 3)
             )
             (block (result i64)
              (drop
               (ref.as_non_null
                (global.get $global1071)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1066)
               )
              )
              (i64.mul
               (local.get $6)
               (struct.get $type47 0
                (struct.get $type283 1
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call278
          (struct.get $type278 1
           (local.get $0)
          )
          (array.get $type279
           (struct.get $type284 0
            (struct.get $type283 2
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $6)
           )
          )
          (struct.get $type278 0
           (local.get $0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (i64.const 1)
   )
  )
  (drop
   (if (result i32)
    (if (result i32)
     (i64.gt_s
      (local.get $4)
      (i64.const 0)
     )
     (then
      (if (result i32)
       (local.tee $10
        (i64.ge_s
         (local.get $6)
         (local.get $7)
        )
       )
       (then
        (local.get $10)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global925)
         )
        )
        (i64.eqz
         (block (result i64)
          (local.set $scratch_16
           (call $function242
            (local.get $4)
            (i64.const 6)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1137)
           )
          )
          (local.get $scratch_16)
         )
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global1079)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (local.set $3
      (call $function241
       (i64.add
        (local.get $7)
        (i64.const 1)
       )
       (i64.const 2)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (if
      (i64.gt_u
       (local.tee $3
        (i64.add
         (call $function241
          (i64.sub
           (local.get $4)
           (i64.const 3)
          )
          (i64.const 3)
         )
         (block (result i64)
          (drop
           (ref.as_non_null
            (global.get $global1071)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1066)
           )
          )
          (i64.mul
           (local.get $3)
           (struct.get $type47 0
            (struct.get $type283 1
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1003)
      )
     )
     (if
      (ref.test (ref $type43)
       (local.tee $11
        (array.get $type279
         (struct.get $type284 0
          (struct.get $type283 2
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (i64.eqz
       (block (result i64)
        (local.set $scratch_17
         (call $function240
          (struct.get $type47 0
           (struct.get $type44 2
            (ref.cast (ref $type44)
             (local.get $11)
            )
           )
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready1168)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1168)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global914)
            )
           )
           (i64.const 4)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1137)
         )
        )
        (local.get $scratch_17)
       )
      )
      (then
       (call_ref $call278
        (struct.get $type278 1
         (local.get $0)
        )
        (local.get $11)
        (struct.get $type278 0
         (local.get $0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (drop
   (if (result i32)
    (i64.gt_s
     (local.get $6)
     (local.get $7)
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global1079)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (local.set $3
      (call $function241
       (i64.add
        (local.get $7)
        (i64.const 2)
       )
       (i64.const 2)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global918)
      )
     )
     (if
      (i64.gt_u
       (local.tee $3
        (i64.add
         (call $function241
          (local.get $4)
          (i64.const 3)
         )
         (block (result i64)
          (drop
           (ref.as_non_null
            (global.get $global1071)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1066)
           )
          )
          (i64.mul
           (local.get $3)
           (struct.get $type47 0
            (struct.get $type283 1
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1003)
      )
     )
     (if
      (ref.test (ref $type43)
       (local.tee $11
        (array.get $type279
         (struct.get $type284 0
          (struct.get $type283 2
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (i64.eqz
       (block (result i64)
        (local.set $scratch_18
         (call $function240
          (struct.get $type47 0
           (struct.get $type44 2
            (ref.cast (ref $type44)
             (local.get $11)
            )
           )
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready1168)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1168)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global914)
            )
           )
           (i64.const 2)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1137)
         )
        )
        (local.get $scratch_18)
       )
      )
      (then
       (call_ref $call278
        (struct.get $type278 1
         (local.get $0)
        )
        (local.get $11)
        (struct.get $type278 0
         (local.get $0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (i64.gt_s
     (i64.mul
      (i64.sub
       (local.get $9)
       (i64.const 1)
      )
      (i64.const 3)
     )
     (local.get $4)
    )
    (then
     (if (result i32)
      (local.tee $10
       (i64.ge_s
        (local.get $6)
        (local.get $7)
       )
      )
      (then
       (local.get $10)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global925)
        )
       )
       (i64.eqz
        (block (result i64)
         (local.set $scratch_19
          (call $function242
           (local.get $4)
           (i64.const 6)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1137)
          )
         )
         (local.get $scratch_19)
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1079)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $7
     (call $function241
      (i64.add
       (local.get $7)
       (i64.const 1)
      )
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (i64.add
        (call $function241
         (i64.add
          (local.get $4)
          (i64.const 3)
         )
         (i64.const 3)
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (i64.mul
          (local.get $7)
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1003)
     )
    )
    (if
     (ref.test (ref $type43)
      (local.tee $11
       (array.get $type279
        (struct.get $type284 0
         (struct.get $type283 2
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eqz
      (block (result i64)
       (local.set $scratch_20
        (call $function240
         (struct.get $type47 0
          (struct.get $type44 2
           (ref.cast (ref $type44)
            (local.get $11)
           )
          )
         )
         (block (result i64)
          (if
           (i32.eqz
            (global.get $ready1168)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1168)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global914)
           )
          )
          (i64.const 1)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1137)
        )
       )
       (local.get $scratch_20)
      )
     )
     (then
      (return_call_ref $call278
       (struct.get $type278 1
        (local.get $0)
       )
       (local.get $11)
       (struct.get $type278 0
        (local.get $0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function316 (type $29) (param $0 (ref $type283)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 (ref $type300)) (param $7 (ref $type300)) (param $8 i64) (result (ref $type299))
  (local $9 (ref $type315))
  (local $10 i64)
  (if (result (ref $type299))
   (i64.lt_s
    (local.get $8)
    (i64.const 0)
   )
   (then
    (struct.new $type299
     (local.get $6)
     (local.get $7)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1092)
     )
    )
    (drop
     (struct.get $type278 1
      (global.get $global1041)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1071)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1066)
     )
    )
    (if
     (i64.gt_u
      (local.tee $10
       (i64.add
        (local.get $8)
        (i64.mul
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
         (struct.get $type47 0
          (struct.get $type283 1
           (local.get $0)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function279
      (i32.const 0)
      (i32.const 1)
      (array.get $type279
       (struct.get $type284 0
        (struct.get $type283 2
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $10)
       )
      )
      (global.get $empty56)
     )
    )
    (local.set $5
     (struct.get $type315 0
      (local.tee $9
       (call $function317
        (local.get $0)
        (local.get $8)
        (i32.const 0)
        (i32.const 1)
        (local.get $5)
        (local.get $6)
        (local.get $7)
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function316
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (struct.get $type315 1
      (local.get $9)
     )
     (struct.get $type315 2
      (local.get $9)
     )
     (i64.sub
      (local.get $8)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function317 (type $26) (param $0 (ref $type283)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 (ref $type300)) (param $6 (ref $type300)) (param $7 i64) (result (ref $type315))
  (local $8 i64)
  (if (result (ref $type315))
   (i64.lt_s
    (local.get $7)
    (i64.const 0)
   )
   (then
    (struct.new $type315
     (local.get $4)
     (local.get $5)
     (local.get $6)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1092)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1047)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1071)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1066)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $4)
      (local.tee $8
       (call $function280
        (array.get $type279
         (struct.get $type284 0
          (struct.get $type283 2
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $7)
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function317
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $8)
       (struct.new $type302
        (local.get $1)
       )
       (struct.new $type302
        (local.get $7)
       )
       (i64.sub
        (local.get $7)
        (i64.const 1)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function317
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (i64.sub
        (local.get $7)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function320 (type $24) (param $0 (ref $type59)) (param $1 (ref $type47)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i64)
  (local $6 i64)
  (local $7 (ref $type40))
  (local $8 (ref $type40))
  (if (result i32)
   (i64.gt_s
    (local.get $4)
    (i64.const 1)
   )
   (then
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (array.get $type59
      (local.get $0)
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global945)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global934)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global918)
     )
    )
    (local.set $6
     (call $function241
      (local.tee $5
       (struct.get $type47 0
        (local.get $1)
       )
      )
      (i64.const 2787)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global925)
     )
    )
    (if
     (i64.le_s
      (local.tee $5
       (i64.sub
        (i64.mul
         (call $function242
          (local.get $5)
          (i64.const 2787)
         )
         (i64.const 2813)
        )
        (i64.mul
         (local.get $6)
         (i64.const 2699)
        )
       )
      )
      (i64.const 0)
     )
     (then
      (local.set $5
       (i64.add
        (local.get $5)
        (i64.const 8388607)
       )
      )
     )
    )
    (struct.set $type47 0
     (local.get $1)
     (local.get $5)
    )
    (drop
     (ref.as_non_null
      (global.get $global925)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (call $function242
        (local.get $5)
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (array.get $type59
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type59
     (local.get $0)
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $8)
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type59
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function320
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function323 (type $23) (param $0 i64) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 (ref $type306))
  (if (result i32)
   (i64.le_s
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $5
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (i32.const 32)
      (struct.get $type306 0
       (local.get $5)
      )
     )
    )
    (struct.set $type306 0
     (local.get $5)
     (struct.new $type61
      (i32.const 32)
      (struct.get $type306 0
       (local.get $5)
      )
     )
    )
    (struct.set $type306 0
     (local.get $5)
     (struct.new $type61
      (i32.const 32)
      (struct.get $type306 0
       (local.get $5)
      )
     )
    )
    (struct.set $type306 0
     (local.get $5)
     (struct.new $type61
      (select
       (i32.const 32)
       (i32.const 95)
       (i64.eq
        (local.get $0)
        (local.get $4)
       )
      )
      (struct.get $type306 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function323
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function325 (type $22) (param $0 (ref $type283)) (param $1 i64) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (result i32)
  (local $7 (ref $type306))
  (local $8 (ref $type42))
  (local $9 i64)
  (local $10 i64)
  (if (result i32)
   (i64.le_s
    (local.get $3)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $7
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (select
       (i32.const 32)
       (i32.const 95)
       (i64.eq
        (local.get $1)
        (local.get $6)
       )
      )
      (struct.get $type306 0
       (local.get $7)
      )
     )
    )
    (struct.set $type306 0
     (local.get $7)
     (struct.new $type61
      (i32.const 47)
      (struct.get $type306 0
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready1231)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1231)
     )
    )
    (local.set $9
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $7
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (select
       (i32.const 46)
       (i32.const 32)
       (if (result i32)
        (i64.ge_s
         (local.tee $10
          (i64.sub
           (local.get $2)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1092)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1013)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (if
          (i64.gt_u
           (local.tee $9
            (i64.add
             (local.get $9)
             (i64.mul
              (local.get $10)
              (struct.get $type47 0
               (struct.get $type283 1
                (local.get $0)
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (ref.test (ref $type43)
           (local.tee $8
            (array.get $type279
             (struct.get $type284 0
              (struct.get $type283 2
               (local.get $0)
              )
             )
             (i32.wrap_i64
              (local.get $9)
             )
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.get $type58 0
          (struct.get $type44 4
           (ref.cast (ref $type44)
            (local.get $8)
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (struct.get $type306 0
       (local.get $7)
      )
     )
    )
    (struct.set $type306 0
     (local.get $7)
     (struct.new $type61
      (i32.const 92)
      (struct.get $type306 0
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function325
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function327 (type $21) (param $0 (ref $type283)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 (ref $type306))
  (local $7 (ref $type42))
  (local $8 i64)
  (local $scratch i64)
  (if (result i32)
   (i64.lt_s
    (local.get $5)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $6
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (i32.const 47)
      (struct.get $type306 0
       (local.get $6)
      )
     )
    )
    (drop
     (call $function328
      (local.get $0)
      (local.get $2)
      (local.get $5)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global896)
     )
    )
    (if
     (i32.wrap_i64
      (i64.and
       (local.get $1)
       (i64.const 1)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready1231)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1231)
       )
      )
      (local.set $8
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1226)
       )
      )
      (struct.set $type306 0
       (local.tee $6
        (ref.as_non_null
         (global.get $global1228)
        )
       )
       (struct.new $type61
        (select
         (i32.const 46)
         (i32.const 32)
         (if (result i32)
          (i64.ge_s
           (local.get $5)
           (i64.const 0)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global1092)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1013)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1071)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1066)
            )
           )
           (if
            (i64.gt_u
             (local.tee $8
              (i64.add
               (local.get $8)
               (i64.mul
                (local.get $5)
                (struct.get $type47 0
                 (struct.get $type283 1
                  (local.get $0)
                 )
                )
               )
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (if
            (ref.test (ref $type43)
             (local.tee $7
              (array.get $type279
               (struct.get $type284 0
                (struct.get $type283 2
                 (local.get $0)
                )
               )
               (i32.wrap_i64
                (local.get $8)
               )
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.get $type58 0
            (struct.get $type44 4
             (ref.cast (ref $type44)
              (local.get $7)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (struct.get $type306 0
         (local.get $6)
        )
       )
      )
      (struct.set $type306 0
       (local.get $6)
       (struct.new $type61
        (i32.const 92)
        (struct.get $type306 0
         (local.get $6)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $6
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (i32.const 10)
      (struct.get $type306 0
       (local.get $6)
      )
     )
    )
    (drop
     (call $function330
      (local.get $0)
      (local.get $2)
      (local.get $5)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global896)
     )
    )
    (drop
     (if (result i32)
      (i32.wrap_i64
       (i64.and
        (local.get $1)
        (i64.const 1)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global1092)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1003)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1071)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1066)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (i64.add
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
           (i64.mul
            (local.get $5)
            (struct.get $type47 0
             (struct.get $type283 1
              (local.get $0)
             )
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (ref.test (ref $type43)
         (local.tee $7
          (array.get $type279
           (struct.get $type284 0
            (struct.get $type283 2
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function329
        (block (result i64)
         (local.set $scratch
          (struct.get $type47 0
           (struct.get $type44 2
            (ref.cast (ref $type44)
             (local.get $7)
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready1239)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1239)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global1137)
        )
       )
       (if
        (i64.ne
         (local.get $5)
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1226)
          )
         )
         (struct.set $type306 0
          (local.tee $6
           (ref.as_non_null
            (global.get $global1228)
           )
          )
          (struct.new $type61
           (i32.const 92)
           (struct.get $type306 0
            (local.get $6)
           )
          )
         )
        )
       )
       (i32.const 0)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $6
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (i32.const 10)
      (struct.get $type306 0
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function327
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function328 (type $21) (param $0 (ref $type283)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 (ref $type42))
  (local $8 (ref $type306))
  (local $scratch i64)
  (if (result i32)
   (i64.le_s
    (local.get $1)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready1231)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1231)
     )
    )
    (local.set $6
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $8
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (select
       (i32.const 46)
       (i32.const 32)
       (if (result i32)
        (i64.ge_s
         (local.get $2)
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1092)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1013)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (if
          (i64.gt_u
           (local.tee $6
            (i64.add
             (local.get $6)
             (i64.mul
              (local.get $2)
              (struct.get $type47 0
               (struct.get $type283 1
                (local.get $0)
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (ref.test (ref $type43)
           (local.tee $7
            (array.get $type279
             (struct.get $type284 0
              (struct.get $type283 2
               (local.get $0)
              )
             )
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.get $type58 0
          (struct.get $type44 4
           (ref.cast (ref $type44)
            (local.get $7)
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (struct.get $type306 0
       (local.get $8)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1092)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1003)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1071)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1066)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (local.get $5)
        (i64.mul
         (local.get $2)
         (struct.get $type47 0
          (struct.get $type283 1
           (local.get $0)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type43)
      (local.tee $7
       (array.get $type279
        (struct.get $type284 0
         (struct.get $type283 2
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function329
      (block (result i64)
       (local.set $scratch
        (struct.get $type47 0
         (struct.get $type44 2
          (ref.cast (ref $type44)
           (local.get $7)
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready1239)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1239)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function328
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function329 (type $call310) (param $0 i64) (result i32)
  (local $1 (ref $type306))
  (local $2 i64)
  (drop
   (ref.as_non_null
    (global.get $global1168)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global914)
   )
  )
  (local.set $2
   (call $function240
    (local.get $0)
    (i64.const 1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1226)
   )
  )
  (struct.set $type306 0
   (local.tee $1
    (ref.as_non_null
     (global.get $global1228)
    )
   )
   (struct.new $type61
    (select
     (i32.const 32)
     (i32.const 92)
     (i64.eqz
      (local.get $2)
     )
    )
    (struct.get $type306 0
     (local.get $1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1168)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global914)
   )
  )
  (local.set $2
   (call $function240
    (local.get $0)
    (i64.const 2)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1226)
   )
  )
  (struct.set $type306 0
   (local.tee $1
    (ref.as_non_null
     (global.get $global1228)
    )
   )
   (struct.new $type61
    (select
     (i32.const 32)
     (i32.const 95)
     (i64.eqz
      (local.get $2)
     )
    )
    (struct.get $type306 0
     (local.get $1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1168)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global914)
   )
  )
  (local.set $0
   (call $function240
    (local.get $0)
    (i64.const 4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1226)
   )
  )
  (struct.set $type306 0
   (local.tee $1
    (ref.as_non_null
     (global.get $global1228)
    )
   )
   (struct.new $type61
    (select
     (i32.const 32)
     (i32.const 47)
     (i64.eqz
      (local.get $0)
     )
    )
    (struct.get $type306 0
     (local.get $1)
    )
   )
  )
  (i32.const 0)
 )
 (func $function330 (type $21) (param $0 (ref $type283)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 (ref $type42))
  (local $9 (ref $type306))
  (local $scratch i64)
  (if (result i32)
   (i64.le_s
    (local.get $1)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1092)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1003)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1071)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1066)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (local.get $5)
        (i64.mul
         (local.get $2)
         (struct.get $type47 0
          (struct.get $type283 1
           (local.get $0)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type43)
      (local.tee $8
       (array.get $type279
        (struct.get $type284 0
         (struct.get $type283 2
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function329
      (block (result i64)
       (local.set $scratch
        (struct.get $type47 0
         (struct.get $type44 2
          (ref.cast (ref $type44)
           (local.get $8)
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready1239)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1239)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready1231)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1231)
     )
    )
    (local.set $6
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $9
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (select
       (i32.const 46)
       (i32.const 32)
       (if (result i32)
        (i64.ge_s
         (local.tee $7
          (i64.sub
           (local.get $2)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1092)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1013)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1071)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1066)
          )
         )
         (if
          (i64.gt_u
           (local.tee $6
            (i64.add
             (local.get $6)
             (i64.mul
              (local.get $7)
              (struct.get $type47 0
               (struct.get $type283 1
                (local.get $0)
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (ref.test (ref $type43)
           (local.tee $8
            (array.get $type279
             (struct.get $type284 0
              (struct.get $type283 2
               (local.get $0)
              )
             )
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.get $type58 0
          (struct.get $type44 4
           (ref.cast (ref $type44)
            (local.get $8)
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (struct.get $type306 0
       (local.get $9)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function330
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function331 (type $call311) (param $0 i64) (param $1 i64) (result (ref null $type61))
  (local $2 (ref null $type61))
  (local $3 (ref $type61))
  (local $4 (ref $type283))
  (local $5 (ref $type42))
  (local $6 (ref $type306))
  (local $7 (ref $type59))
  (local $8 (ref $type300))
  (local $9 (ref $type44))
  (local $10 (ref $type285))
  (local $11 (ref $type56))
  (local $12 (ref $type301))
  (local $13 (ref $type299))
  (local $14 i64)
  (local $15 i64)
  (struct.set $type306 0
   (global.get $global1228)
   (ref.null none)
  )
  (drop
   (ref.as_non_null
    (global.get $global1211)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1194)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1117)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1096)
   )
  )
  (local.set $4
   (call $function295
    (local.get $0)
    (local.get $1)
    (struct.new_default $type295)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1122)
   )
  )
  (local.set $7
   (call $function303
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global932)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1199)
   )
  )
  (drop
   (call $function320
    (local.get $7)
    (struct.new $type47
     (i64.const 20)
    )
    (i32.const 0)
    (i32.const 1)
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $7)
      )
     )
     (i64.const 1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1018)
   )
  )
  (drop
   (call $function271
    (local.get $7)
    (i64.mul
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1154)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1092)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1071)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1066)
   )
  )
  (local.set $5
   (array.get $type279
    (struct.get $type284 0
     (struct.get $type283 2
      (local.get $4)
     )
    )
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1033)
   )
  )
  (local.set $10
   (ref.as_non_null
    (global.get $global1156)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1010)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type54 0
   (struct.get $type44 3
    (local.tee $9
     (ref.cast (ref $type44)
      (local.get $5)
     )
    )
   )
   (local.tee $11
    (global.get $empty56)
   )
  )
  (drop
   (call $function314
    (struct.new $type278
     (ref.func $function277)
     (struct.new $environment277
      (local.get $4)
      (local.get $10)
      (struct.new $type313
       (i32.const 1)
      )
      (local.get $9)
      (local.get $11)
     )
    )
    (local.get $4)
    (local.get $9)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1061)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1066)
   )
  )
  (if
   (ref.test (ref $type301)
    (local.tee $8
     (struct.get $type299 0
      (local.tee $13
       (call $function316
        (local.get $4)
        (struct.get $type47 0
         (struct.get $type283 0
          (local.get $4)
         )
        )
        (local.tee $1
         (struct.get $type47 0
          (struct.get $type283 1
           (local.get $4)
          )
         )
        )
        (i32.const 0)
        (i32.const 1)
        (i64.const -1)
        (local.tee $12
         (global.get $empty301)
        )
        (local.get $12)
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type302 0
    (ref.cast (ref $type302)
     (local.get $8)
    )
   )
  )
  (if
   (ref.test (ref $type301)
    (local.tee $8
     (struct.get $type299 1
      (local.get $13)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1092)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1003)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1071)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1066)
   )
  )
  (if
   (i64.gt_u
    (local.tee $14
     (struct.get $type302 0
      (ref.cast (ref $type302)
       (local.get $8)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.tee $5
     (array.get $type279
      (struct.get $type284 0
       (struct.get $type283 2
        (local.get $4)
       )
      )
      (i32.wrap_i64
       (local.get $14)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (call $function240
    (struct.get $type47 0
     (struct.get $type44 2
      (ref.cast (ref $type44)
       (local.get $5)
      )
     )
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global1092)
      )
     )
     (drop
      (struct.get $type278 1
       (global.get $global1041)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1071)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1066)
      )
     )
     (if
      (i64.gt_u
       (local.tee $0
        (i64.add
         (local.get $1)
         (i64.mul
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
          (struct.get $type47 0
           (struct.get $type283 1
            (local.get $4)
           )
          )
         )
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (call $function279
       (i32.const 0)
       (i32.const 1)
       (array.get $type279
        (struct.get $type284 0
         (struct.get $type283 2
          (local.get $4)
         )
        )
        (i32.wrap_i64
         (local.get $0)
        )
       )
       (global.get $empty56)
      )
     )
     (drop
      (call $function282
       (struct.get $type278 1
        (global.get $global1052)
       )
       (local.get $5)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global912)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global914)
      )
     )
     (i64.const -3)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1005)
   )
  )
  (if
   (ref.test (ref $type43)
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type47 0
   (struct.get $type44 2
    (ref.cast (ref $type44)
     (local.get $5)
    )
   )
   (local.get $0)
  )
  (if
   (i32.eqz
    (global.get $ready1218)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1218)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1061)
   )
  )
  (local.set $14
   (struct.get $type47 0
    (struct.get $type283 0
     (local.get $4)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1066)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global918)
   )
  )
  (local.set $15
   (i64.shl
    (call $function241
     (local.tee $0
      (struct.get $type47 0
       (struct.get $type283 1
        (local.get $4)
       )
      )
     )
     (i64.const 2)
    )
    (i64.const 1)
   )
  )
  (drop
   (call $function323
    (local.get $1)
    (local.get $0)
    (i32.const 0)
    (i32.const 1)
    (i64.const 1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1226)
   )
  )
  (struct.set $type306 0
   (local.tee $6
    (ref.as_non_null
     (global.get $global1228)
    )
   )
   (struct.new $type61
    (i32.const 10)
    (struct.get $type306 0
     (local.get $6)
    )
   )
  )
  (struct.set $type306 0
   (local.get $6)
   (struct.new $type61
    (i32.const 32)
    (struct.get $type306 0
     (local.get $6)
    )
   )
  )
  (drop
   (call $function325
    (local.get $4)
    (local.get $1)
    (local.get $14)
    (local.get $15)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global896)
   )
  )
  (if
   (i32.wrap_i64
    (i64.and
     (local.get $0)
     (i64.const 1)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1226)
     )
    )
    (struct.set $type306 0
     (local.tee $6
      (ref.as_non_null
       (global.get $global1228)
      )
     )
     (struct.new $type61
      (select
       (i32.const 32)
       (i32.const 95)
       (i64.eq
        (i64.sub
         (local.get $0)
         (i64.const 1)
        )
        (local.get $1)
       )
      )
      (struct.get $type306 0
       (local.get $6)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1226)
   )
  )
  (struct.set $type306 0
   (local.tee $6
    (ref.as_non_null
     (global.get $global1228)
    )
   )
   (struct.new $type61
    (i32.const 10)
    (struct.get $type306 0
     (local.get $6)
    )
   )
  )
  (drop
   (call $function327
    (local.get $4)
    (local.get $0)
    (local.get $15)
    (i32.const 0)
    (i32.const 1)
    (i64.sub
     (local.get $14)
     (i64.const 1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1246)
   )
  )
  (if (result (ref null $type61))
   (ref.is_null
    (local.tee $2
     (struct.get $type306 0
      (global.get $global1228)
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $3
     (struct.new $type61
      (struct.get $type61 0
       (local.get $2)
      )
      (ref.null none)
     )
    )
    (if (result (ref $type61))
     (ref.is_null
      (local.tee $2
       (struct.get $type61 1
        (local.get $2)
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $3
       (struct.new $type61
        (struct.get $type61 0
         (local.get $2)
        )
        (local.get $3)
       )
      )
      (if (result (ref $type61))
       (ref.is_null
        (local.tee $2
         (struct.get $type61 1
          (local.get $2)
         )
        )
       )
       (then
        (local.get $3)
       )
       (else
        (local.set $3
         (struct.new $type61
          (struct.get $type61 0
           (local.get $2)
          )
          (local.get $3)
         )
        )
        (if (result (ref $type61))
         (ref.is_null
          (local.tee $2
           (struct.get $type61 1
            (local.get $2)
           )
          )
         )
         (then
          (local.get $3)
         )
         (else
          (local.set $3
           (struct.new $type61
            (struct.get $type61 0
             (local.get $2)
            )
            (local.get $3)
           )
          )
          (if (result (ref $type61))
           (ref.is_null
            (local.tee $2
             (struct.get $type61 1
              (local.get $2)
             )
            )
           )
           (then
            (local.get $3)
           )
           (else
            (local.set $3
             (struct.new $type61
              (struct.get $type61 0
               (local.get $2)
              )
              (local.get $3)
             )
            )
            (if (result (ref $type61))
             (ref.is_null
              (local.tee $2
               (struct.get $type61 1
                (local.get $2)
               )
              )
             )
             (then
              (local.get $3)
             )
             (else
              (local.set $3
               (struct.new $type61
                (struct.get $type61 0
                 (local.get $2)
                )
                (local.get $3)
               )
              )
              (if (result (ref $type61))
               (ref.is_null
                (local.tee $2
                 (struct.get $type61 1
                  (local.get $2)
                 )
                )
               )
               (then
                (local.get $3)
               )
               (else
                (local.set $3
                 (struct.new $type61
                  (struct.get $type61 0
                   (local.get $2)
                  )
                  (local.get $3)
                 )
                )
                (if (result (ref $type61))
                 (ref.is_null
                  (local.tee $2
                   (struct.get $type61 1
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (local.set $3
                   (struct.new $type61
                    (struct.get $type61 0
                     (local.get $2)
                    )
                    (local.get $3)
                   )
                  )
                  (if (result (ref $type61))
                   (ref.is_null
                    (local.tee $2
                     (struct.get $type61 1
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (return_call $function333
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type61 1
                      (local.get $2)
                     )
                     (struct.new $type61
                      (struct.get $type61 0
                       (local.get $2)
                      )
                      (local.get $3)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function333 (type $17) (param $0 i32) (param $1 i32) (param $2 (ref null $type61)) (param $3 (ref $type61)) (result (ref null $type61))
  (local $4 (ref null $type61))
  (local $5 i32)
  (if (result (ref $type61))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type61 1
      (local.get $2)
     )
    )
    (local.set $5
     (struct.get $type61 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function333
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (struct.new $type61
      (local.get $5)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function336 (type $16) (param $0 i32) (param $1 i32) (param $2 (ref $type13)) (param $3 (ref null $type61)) (result (ref $type167))
  (local $4 (ref $type61))
  (local $5 (ref null $type61))
  (local $6 (ref $type31))
  (local $7 (ref $type13))
  (local $8 i32)
  (drop
   (ref.as_non_null
    (global.get $global388)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global372)
   )
  )
  (if (result (ref $type167))
   (i64.eqz
    (call $function112
     (local.get $2)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1246)
     )
    )
    (struct.new $type169
     (i32.const 1)
     (if (result (ref null $type61))
      (ref.is_null
       (local.get $3)
      )
      (then
       (ref.null none)
      )
      (else
       (local.set $4
        (struct.new $type61
         (struct.get $type61 0
          (local.get $3)
         )
         (ref.null none)
        )
       )
       (if (result (ref null $type61))
        (ref.is_null
         (local.tee $5
          (struct.get $type61 1
           (local.get $3)
          )
         )
        )
        (then
         (local.get $4)
        )
        (else
         (local.set $4
          (struct.new $type61
           (struct.get $type61 0
            (local.get $5)
           )
           (local.get $4)
          )
         )
         (if (result (ref null $type61))
          (ref.is_null
           (local.tee $5
            (struct.get $type61 1
             (local.get $5)
            )
           )
          )
          (then
           (local.get $4)
          )
          (else
           (local.set $4
            (struct.new $type61
             (struct.get $type61 0
              (local.get $5)
             )
             (local.get $4)
            )
           )
           (if (result (ref null $type61))
            (ref.is_null
             (local.tee $5
              (struct.get $type61 1
               (local.get $5)
              )
             )
            )
            (then
             (local.get $4)
            )
            (else
             (local.set $4
              (struct.new $type61
               (struct.get $type61 0
                (local.get $5)
               )
               (local.get $4)
              )
             )
             (if (result (ref null $type61))
              (ref.is_null
               (local.tee $5
                (struct.get $type61 1
                 (local.get $5)
                )
               )
              )
              (then
               (local.get $4)
              )
              (else
               (local.set $4
                (struct.new $type61
                 (struct.get $type61 0
                  (local.get $5)
                 )
                 (local.get $4)
                )
               )
               (if (result (ref null $type61))
                (ref.is_null
                 (local.tee $5
                  (struct.get $type61 1
                   (local.get $5)
                  )
                 )
                )
                (then
                 (local.get $4)
                )
                (else
                 (local.set $4
                  (struct.new $type61
                   (struct.get $type61 0
                    (local.get $5)
                   )
                   (local.get $4)
                  )
                 )
                 (if (result (ref null $type61))
                  (ref.is_null
                   (local.tee $5
                    (struct.get $type61 1
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (local.get $4)
                  )
                  (else
                   (local.set $4
                    (struct.new $type61
                     (struct.get $type61 0
                      (local.get $5)
                     )
                     (local.get $4)
                    )
                   )
                   (if (result (ref null $type61))
                    (ref.is_null
                     (local.tee $5
                      (struct.get $type61 1
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (local.set $4
                      (struct.new $type61
                       (struct.get $type61 0
                        (local.get $5)
                       )
                       (local.get $4)
                      )
                     )
                     (if (result (ref null $type61))
                      (ref.is_null
                       (local.tee $5
                        (struct.get $type61 1
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (local.get $4)
                      )
                      (else
                       (call $function333
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type61 1
                         (local.get $5)
                        )
                        (struct.new $type61
                         (struct.get $type61 0
                          (local.get $5)
                         )
                         (local.get $4)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global390)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global372)
     )
    )
    (if (result (ref $type170))
     (if (result i32)
      (i64.eq
       (call $function112
        (local.get $2)
       )
       (i64.const 6)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global362)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global372)
        )
       )
       (if
        (i32.ne
         (struct.get $type13 0
          (local.get $2)
         )
         (i32.const 6)
        )
        (then
         (unreachable)
        )
       )
       (i64.eq
        (call $function112
         (struct.get $type32 0
          (struct.get $type31 1
           (ref.cast (ref $type31)
            (local.get $2)
           )
          )
         )
        )
        (i64.const 2)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global364)
       )
      )
      (if
       (i32.ne
        (struct.get $type13 0
         (local.get $2)
        )
        (i32.const 6)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type32 0
        (struct.get $type31 2
         (local.tee $6
          (ref.cast (ref $type31)
           (local.get $2)
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global362)
       )
      )
      (if
       (i32.ne
        (struct.get $type13 0
         (local.tee $7
          (struct.get $type32 0
           (struct.get $type31 1
            (local.get $6)
           )
          )
         )
        )
        (i32.const 2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (struct.get $type16 1
        (ref.cast (ref $type16)
         (local.get $7)
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function336
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (struct.new $type61
        (local.get $8)
        (local.get $3)
       )
      )
     )
     (else
      (global.get $empty170)
     )
    )
   )
  )
 )
 (func $function341 (type $14) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref $type167)) (result i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 (ref null $type61))
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1281)
     )
    )
    (local.set $7
     (call $function331
      (struct.get $type166 1
       (global.get $global1269)
      )
      (block (result i64)
       (if
        (i32.eqz
         (call $foreign26)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1281)
        )
       )
       (local.set $scratch
        (struct.get $type166 2
         (global.get $global1269)
        )
       )
       (if
        (i32.eqz
         (call $foreign26)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1243)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function341
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (struct.new $type169
      (i32.const 1)
      (local.get $7)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global903)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (call $function238
       (local.get $4)
       (struct.get $type166 3
        (global.get $global1269)
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1276)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1276)
   )
  )
  (return_call $function341
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (global.get $empty168)
  )
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1275)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1275)
   )
  )
  (struct.get $type166 0
   (global.get $global1269)
  )
 )
 (func $main
  (local $0 (ref $type13))
  (local $1 (ref null $type160))
  (local $2 (ref null $type160))
  (local $3 (ref null $type24))
  (local $4 (ref $type205))
  (local $5 (ref $type122))
  (local $6 (ref $type166))
  (local $7 (ref $type158))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i32)
  (local $scratch (ref $type122))
  (local $scratch_13 (ref $type122))
  (local $scratch_14 (ref $type122))
  (local $scratch_15 (ref $type122))
  (local $scratch_16 (ref $type166))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global816
   (struct.new_default $type11)
  )
  (global.set $global1143
   (struct.new_default $type38)
  )
  (global.set $global819
   (struct.new_default $type62)
  )
  (global.set $ready819
   (i32.const 1)
  )
  (global.set $global1146
   (struct.new_default $type63)
  )
  (global.set $ready1146
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type64)
  )
  (global.set $global81
   (struct.new_default $type68)
  )
  (global.set $global88
   (struct.new_default $type69)
  )
  (global.set $global90
   (struct.new_default $type70)
  )
  (global.set $global93
   (struct.new_default $type72)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type73)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type74)
  )
  (global.set $global109
   (struct.new_default $type75)
  )
  (global.set $global246
   (struct.new_default $type102)
  )
  (global.set $global252
   (struct.new_default $type103)
  )
  (global.set $global258
   (struct.new_default $type105)
  )
  (global.set $global296
   (struct.new_default $type110)
  )
  (global.set $global299
   (struct.new_default $type111)
  )
  (global.set $global305
   (struct.new_default $type112)
  )
  (global.set $global308
   (struct.new_default $type117)
  )
  (global.set $global340
   (struct.new_default $type121)
  )
  (global.set $global347
   (struct.new_default $type126)
  )
  (global.set $global351
   (struct.new $type47
    (i64.const 1)
   )
  )
  (global.set $global352
   (struct.new_default $type5)
  )
  (global.set $global354
   (struct.new_default $type127)
  )
  (global.set $global357
   (struct.new_default $type128)
  )
  (global.set $global359
   (struct.new_default $type129)
  )
  (global.set $global362
   (struct.new_default $type130)
  )
  (global.set $global364
   (struct.new_default $type130)
  )
  (global.set $global372
   (struct.new_default $type132)
  )
  (global.set $global386
   (struct.new_default $type133)
  )
  (global.set $global388
   (struct.new_default $type133)
  )
  (global.set $global390
   (struct.new_default $type133)
  )
  (global.set $global534
   (struct.new_default $type155)
  )
  (global.set $global545
   (struct.new_default $type159)
  )
  (global.set $global552
   (struct.new_default $type162)
  )
  (global.set $global549
   (struct.new_default $type163)
  )
  (global.set $ready549
   (i32.const 1)
  )
  (global.set $global1270
   (struct.new_default $type164)
  )
  (global.set $global558
   (struct.new_default $type175)
  )
  (global.set $global560
   (struct.new_default $type176)
  )
  (global.set $global562
   (struct.new_default $type176)
  )
  (global.set $global610
   (struct.new_default $type189)
  )
  (global.set $global615
   (struct.new_default $type190)
  )
  (global.set $global622
   (struct.new_default $type191)
  )
  (global.set $global642
   (struct.new_default $type192)
  )
  (global.set $global620
   (struct.new_default $type192)
  )
  (global.set $global628
   (struct.new_default $type193)
  )
  (global.set $global639
   (struct.new_default $type194)
  )
  (global.set $global626
   (struct.new_default $type195)
  )
  (global.set $global733
   (struct.new_default $type195)
  )
  (global.set $global652
   (struct.new_default $type196)
  )
  (global.set $global701
   (struct.new_default $type199)
  )
  (global.set $global705
   (struct.new_default $type200)
  )
  (global.set $ready705
   (i32.const 1)
  )
  (global.set $global658
   (struct.new_default $type201)
  )
  (global.set $global748
   (struct.new_default $type202)
  )
  (global.set $global756
   (struct.new_default $type69)
  )
  (global.set $global631
   (struct.new_default $type162)
  )
  (global.set $ready631
   (i32.const 1)
  )
  (global.set $global725
   (struct.new_default $type203)
  )
  (global.set $ready725
   (i32.const 1)
  )
  (global.set $global720
   (struct.new_default $type204)
  )
  (global.set $global617
   (struct.new_default $type204)
  )
  (global.set $ready617
   (i32.const 1)
  )
  (global.set $global636
   (struct.new_default $type213)
  )
  (global.set $ready636
   (i32.const 1)
  )
  (global.set $global717
   (struct.new_default $type204)
  )
  (global.set $ready717
   (i32.const 1)
  )
  (global.set $global774
   (struct.new_default $type204)
  )
  (global.set $ready774
   (i32.const 1)
  )
  (global.set $global776
   (struct.new_default $type214)
  )
  (global.set $ready776
   (i32.const 1)
  )
  (global.set $global787
   (struct.new_default $type214)
  )
  (global.set $ready787
   (i32.const 1)
  )
  (global.set $global644
   (struct.new_default $type215)
  )
  (global.set $ready644
   (i32.const 1)
  )
  (global.set $global649
   (struct.new_default $type216)
  )
  (global.set $ready649
   (i32.const 1)
  )
  (global.set $global653
   (struct.new_default $type220)
  )
  (global.set $ready653
   (i32.const 1)
  )
  (global.set $global711
   (struct.new_default $type221)
  )
  (global.set $ready711
   (i32.const 1)
  )
  (global.set $global694
   (struct.new_default $type222)
  )
  (global.set $ready694
   (i32.const 1)
  )
  (global.set $global660
   (struct.new_default $type227)
  )
  (global.set $ready660
   (i32.const 1)
  )
  (global.set $global681
   (struct.new_default $type195)
  )
  (global.set $ready681
   (i32.const 1)
  )
  (global.set $global691
   (struct.new_default $type162)
  )
  (global.set $ready691
   (i32.const 1)
  )
  (global.set $global686
   (struct.new_default $type228)
  )
  (global.set $ready686
   (i32.const 1)
  )
  (global.set $global678
   (struct.new_default $type88)
  )
  (global.set $global674
   (struct.new_default $type195)
  )
  (global.set $global671
   (struct.new_default $type229)
  )
  (global.set $global666
   (struct.new_default $type230)
  )
  (global.set $ready666
   (i32.const 1)
  )
  (global.set $global764
   (struct.new_default $type231)
  )
  (global.set $global730
   (struct.new_default $type204)
  )
  (global.set $ready730
   (i32.const 1)
  )
  (global.set $global753
   (struct.new_default $type214)
  )
  (global.set $ready753
   (i32.const 1)
  )
  (global.set $global762
   (struct.new_default $type231)
  )
  (global.set $ready762
   (i32.const 1)
  )
  (global.set $global792
   (struct.new_default $type232)
  )
  (global.set $ready792
   (i32.const 1)
  )
  (global.set $global870
   (struct.new_default $type233)
  )
  (global.set $ready870
   (i32.const 1)
  )
  (global.set $global799
   (struct.new_default $type234)
  )
  (global.set $ready799
   (i32.const 1)
  )
  (global.set $global860
   (struct.new_default $type235)
  )
  (global.set $ready860
   (i32.const 1)
  )
  (global.set $global846
   (struct.new_default $type236)
  )
  (global.set $ready846
   (i32.const 1)
  )
  (global.set $global808
   (struct.new_default $type237)
  )
  (global.set $ready808
   (i32.const 1)
  )
  (global.set $global811
   (struct.new_default $type238)
  )
  (global.set $global805
   (struct.new_default $type239)
  )
  (global.set $ready805
   (i32.const 1)
  )
  (global.set $global827
   (struct.new_default $type240)
  )
  (global.set $ready827
   (i32.const 1)
  )
  (global.set $global838
   (struct.new_default $type132)
  )
  (global.set $global833
   (struct.new_default $type241)
  )
  (global.set $ready833
   (i32.const 1)
  )
  (global.set $global882
   (struct.new_default $type242)
  )
  (global.set $global892
   (struct.new_default $type243)
  )
  (global.set $global876
   (struct.new_default $type244)
  )
  (global.set $global879
   (struct.new_default $type245)
  )
  (global.set $global886
   (struct.new_default $type246)
  )
  (global.set $global889
   (struct.new_default $type247)
  )
  (global.set $global1137
   (struct.new_default $type195)
  )
  (global.set $global896
   (struct.new_default $type195)
  )
  (global.set $global898
   (struct.new_default $type195)
  )
  (global.set $global1246
   (struct.new_default $type248)
  )
  (global.set $global1028
   (struct.new_default $type249)
  )
  (global.set $global900
   (struct.new_default $type251)
  )
  (global.set $ready900
   (i32.const 1)
  )
  (global.set $global903
   (struct.new_default $type252)
  )
  (global.set $global912
   (struct.new_default $type88)
  )
  (global.set $global914
   (struct.new_default $type253)
  )
  (global.set $ready914
   (i32.const 1)
  )
  (global.set $global918
   (struct.new_default $type253)
  )
  (global.set $ready918
   (i32.const 1)
  )
  (global.set $global925
   (struct.new_default $type253)
  )
  (global.set $global932
   (struct.new_default $type254)
  )
  (global.set $global934
   (struct.new_default $type255)
  )
  (global.set $global945
   (struct.new_default $type256)
  )
  (global.set $global948
   (struct.new_default $type257)
  )
  (global.set $global950
   (struct.new_default $type258)
  )
  (global.set $global958
   (struct.new_default $type244)
  )
  (global.set $global961
   (struct.new_default $type259)
  )
  (global.set $global963
   (struct.new_default $type260)
  )
  (global.set $global971
   (struct.new_default $type261)
  )
  (global.set $global975
   (struct.new_default $type262)
  )
  (global.set $global980
   (struct.new_default $type262)
  )
  (global.set $global985
   (struct.new_default $type264)
  )
  (global.set $global990
   (struct.new_default $type266)
  )
  (global.set $global993
   (struct.new_default $type267)
  )
  (global.set $global998
   (struct.new_default $type269)
  )
  (global.set $global1003
   (struct.new_default $type271)
  )
  (global.set $global1005
   (struct.new_default $type272)
  )
  (global.set $global1008
   (struct.new_default $type273)
  )
  (global.set $global1010
   (struct.new_default $type274)
  )
  (global.set $global1013
   (struct.new_default $type275)
  )
  (global.set $global1015
   (struct.new_default $type276)
  )
  (global.set $global1199
   (struct.new_default $type280)
  )
  (global.set $global1018
   (struct.new_default $type281)
  )
  (global.set $global1033
   (struct.new_default $type282)
  )
  (global.set $global1041
   (struct.new $type278
    (ref.func $function278)
    (ref.null none)
   )
  )
  (global.set $global1047
   (struct.new_default $type271)
  )
  (global.set $global1052
   (struct.new $type278
    (ref.func $function282)
    (ref.null none)
   )
  )
  (global.set $global1057
   (struct.new_default $type286)
  )
  (global.set $global1061
   (struct.new_default $type287)
  )
  (global.set $global1066
   (struct.new_default $type287)
  )
  (global.set $global1071
   (struct.new_default $type289)
  )
  (global.set $global1079
   (struct.new_default $type292)
  )
  (global.set $global1092
   (struct.new_default $type292)
  )
  (global.set $global1096
   (struct.new_default $type294)
  )
  (global.set $global1117
   (struct.new_default $type291)
  )
  (global.set $global1122
   (struct.new_default $type297)
  )
  (global.set $global1154
   (struct.new_default $type298)
  )
  (global.set $global1156
   (struct.new_default $type285)
  )
  (global.set $ready1156
   (i32.const 1)
  )
  (global.set $global1194
   (struct.new_default $type303)
  )
  (global.set $global1211
   (struct.new_default $type305)
  )
  (global.set $global1228
   (struct.new_default $type306)
  )
  (global.set $global1226
   (struct.new_default $type307)
  )
  (global.set $global1218
   (struct.new_default $type288)
  )
  (global.set $ready1218
   (i32.const 1)
  )
  (global.set $global1168
   (struct.new_default $type308)
  )
  (global.set $ready1168
   (i32.const 1)
  )
  (global.set $global1231
   (struct.new_default $type309)
  )
  (global.set $ready1231
   (i32.const 1)
  )
  (global.set $global1239
   (struct.new_default $type310)
  )
  (global.set $ready1239
   (i32.const 1)
  )
  (global.set $global1243
   (struct.new_default $type311)
  )
  (global.set $global1251
   (struct.new_default $type132)
  )
  (global.set $global1258
   (struct.new_default $type312)
  )
  (global.set $global1263
   (struct.new_default $type165)
  )
  (drop
   (ref.as_non_null
    (global.get $global1263)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1270)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global545)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global534)
   )
  )
  (drop
   (call $function143)
  )
  (global.set $global1269
   (block (result (ref $type166))
    (local.set $scratch_16
     (block $block1 (result (ref $type166))
      (local.set $1
       (ref.as_non_null
        (local.tee $2
         (struct.new $type160
          (struct.new $type158
           (call $foreign20)
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global615)
       )
      )
      (if
       (i32.eqz
        (global.get $ready617)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global617)
       )
      )
      (local.set $4
       (call $function170
        (ref.as_non_null
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready792)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global792)
       )
      )
      (local.set $0
       (call $function168
        (block (result (ref $type122))
         (local.set $scratch
          (call $function212
           (ref.as_non_null
            (local.get $1)
           )
           (local.get $4)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global610)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1251)
       )
      )
      (if
       (i32.ne
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 5)
       )
       (then
        (unreachable)
       )
      )
      (block $block
       (br_if $block
        (struct.get $type24 0
         (local.tee $3
          (struct.get $type23 1
           (ref.cast (ref $type23)
            (local.get $0)
           )
          )
         )
        )
       )
       (br $block1
        (struct.new $type166
         (struct.get $type25 1
          (ref.cast (ref $type25)
           (local.get $3)
          )
         )
         (block (result i64)
          (drop
           (ref.as_non_null
            (global.get $global615)
           )
          )
          (if
           (i32.eqz
            (global.get $ready617)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global617)
           )
          )
          (local.set $4
           (call $function170
            (ref.as_non_null
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready792)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global792)
           )
          )
          (local.set $0
           (call $function168
            (block (result (ref $type122))
             (local.set $scratch_13
              (call $function212
               (ref.as_non_null
                (local.get $1)
               )
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global610)
              )
             )
             (local.get $scratch_13)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1251)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 5)
           )
           (then
            (unreachable)
           )
          )
          (br_if $block
           (struct.get $type24 0
            (local.tee $3
             (struct.get $type23 1
              (ref.cast (ref $type23)
               (local.get $0)
              )
             )
            )
           )
          )
          (struct.get $type25 1
           (ref.cast (ref $type25)
            (local.get $3)
           )
          )
         )
         (block (result i64)
          (drop
           (ref.as_non_null
            (global.get $global615)
           )
          )
          (if
           (i32.eqz
            (global.get $ready617)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global617)
           )
          )
          (local.set $4
           (call $function170
            (ref.as_non_null
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready792)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global792)
           )
          )
          (local.set $0
           (call $function168
            (block (result (ref $type122))
             (local.set $scratch_14
              (call $function212
               (ref.as_non_null
                (local.get $1)
               )
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global610)
              )
             )
             (local.get $scratch_14)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1251)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 5)
           )
           (then
            (unreachable)
           )
          )
          (br_if $block
           (struct.get $type24 0
            (local.tee $3
             (struct.get $type23 1
              (ref.cast (ref $type23)
               (local.get $0)
              )
             )
            )
           )
          )
          (struct.get $type25 1
           (ref.cast (ref $type25)
            (local.get $3)
           )
          )
         )
         (block (result (ref $type167))
          (drop
           (ref.as_non_null
            (global.get $global615)
           )
          )
          (if
           (i32.eqz
            (global.get $ready617)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global617)
           )
          )
          (local.set $4
           (call $function170
            (ref.as_non_null
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready792)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global792)
           )
          )
          (local.set $0
           (call $function168
            (block (result (ref $type122))
             (local.set $scratch_15
              (call $function212
               (ref.as_non_null
                (local.get $1)
               )
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global610)
              )
             )
             (local.get $scratch_15)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1258)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global372)
           )
          )
          (if (result (ref $type167))
           (if (result i32)
            (i64.eq
             (call $function112
              (local.get $0)
             )
             (i64.const 1)
            )
            (then
             (if
              (i32.ne
               (struct.get $type13 0
                (local.get $0)
               )
               (i32.const 1)
              )
              (then
               (unreachable)
              )
             )
             (i32.eqz
              (struct.get $type15 1
               (ref.cast (ref $type15)
                (local.get $0)
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (global.get $empty168)
           )
           (else
            (call $function336
             (i32.const 0)
             (i32.const 1)
             (local.get $0)
             (ref.null none)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eq
        (struct.get $type24 0
         (local.get $3)
        )
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type26)
          (local.get $3)
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type27)
          (local.get $3)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global252)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global246)
       )
      )
      (call $foreign2
       (call $function80
        (global.get $string54)
       )
      )
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global552)
     )
    )
    (if
     (i32.eqz
      (global.get $ready549)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global549)
     )
    )
    (if
     (i32.ne
      (local.tee $11
       (struct.get $type158 0
        (local.tee $7
         (struct.get $type160 0
          (ref.as_non_null
           (local.get $1)
          )
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (struct.set $type158 0
       (local.get $7)
       (i32.const -1)
      )
      (call $foreign21
       (local.get $11)
      )
     )
    )
    (local.get $scratch_16)
   )
  )
  (global.set $global1275
   (struct.new_default $type5)
  )
  (global.set $ready1275
   (i32.const 1)
  )
  (global.set $global1281
   (struct.new_default $type253)
  )
  (global.set $global1276
   (struct.new_default $type88)
  )
  (global.set $ready1276
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

