"""Count reached Wasm sites without changing original operand order or traps.

This is a heavy diagnostic, never a benchmark artifact. Constructors and casts
are counted after they return; call sites are counted after the last operand is
evaluated, before entering the callee. Observer helpers allocate nothing and
return their argument unchanged. No extra reference locals retain past results.
"""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys


# ---- Located Wasm forms ----

class Form(list):
    def __init__(self, values=(), line=0):
        super().__init__(values)
        self.line = line


def parse(source):
    tokens = re.finditer(r'\(;[\s\S]*?;\)|;;[^\n]*|"(?:\\.|[^"\\])*"|[^\s()]+|[()]', source)
    stack, roots, cursor, line = [], [], 0, 1
    for match in tokens:
        line += source.count('\n', cursor, match.start()); cursor = match.start()
        value = match.group()
        if value.startswith((';;', '(;')):
            continue
        if value == '(':
            node = Form(line=line)
            (stack[-1] if stack else roots).append(node); stack.append(node)
        elif value == ')':
            stack.pop()
        else:
            stack[-1].append(value)
    assert not stack and len(roots) == 1
    return roots[0]


def render(value):
    if isinstance(value, str):
        return value
    return '(' + ' '.join(map(render, value)) + ')'


def forms(node, head):
    return [child for child in node if isinstance(child, Form) and child[0] == head]


def value_types(declaration):
    return [value for value in declaration[1:] if not (isinstance(value, str) and value.startswith('$'))]


def single_type(declaration):
    values = value_types(declaration)
    assert len(values) == 1, declaration
    return values[0]


# ---- Original module types ----

class ModuleTypes:
    def __init__(self, module):
        declarations = list(module[1:])
        for recursive in forms(module, 'rec'):
            declarations.extend(recursive[1:])
        self.types = {node[1]: node[2] for node in declarations if isinstance(node, Form) and node[0] == 'type'}
        self.globals = {node[1]: node[2][1] if isinstance(node[2], Form) and node[2][0] == 'mut' else node[2]
                        for node in forms(module, 'global')}
        self.functions = {node[1]: node for node in forms(module, 'func')}
        for imported in forms(module, 'import'):
            declaration = imported[-1]
            if declaration[0] == 'func':
                self.functions[declaration[1]] = declaration

    def function_result(self, name):
        function = self.functions[name]
        result = forms(function, 'result')
        if not result and forms(function, 'type'):
            result = forms(self.types[forms(function, 'type')[0][1]], 'result')
        return single_type(result[0]) if result else None

    def local_types(self, function):
        return {declaration[1]: single_type(declaration)
                for declaration in list(forms(function, 'param')) + list(forms(function, 'local'))}

    def expression_type(self, expression, locals):
        op = expression[0]
        if op in ('local.get', 'local.tee'):
            return locals[expression[1]]
        if op == 'global.get':
            return self.globals[expression[1]]
        if op == 'struct.get':
            field = self.types[expression[1]][int(expression[2]) + 1][-1]
            return field[1] if isinstance(field, Form) and field[0] == 'mut' else field
        if op.startswith(('struct.new', 'array.new')):
            return Form(['ref', Form(['exact', expression[1]])])
        if op == 'array.get':
            element = self.types[expression[1]][1]
            return element[1] if isinstance(element, Form) and element[0] == 'mut' else element
        if op == 'ref.cast':
            return expression[1]
        if op == 'ref.as_non_null':
            nullable = self.expression_type(expression[1], locals)
            if isinstance(nullable, str):
                return Form(['ref', {'structref': 'struct', 'eqref': 'eq', 'anyref': 'any'}[nullable]])
            return Form([part for part in nullable if part != 'null'])
        if op == 'ref.func':
            return Form(['ref', forms(self.functions[expression[1]], 'type')[0][1]])
        if op == 'ref.null':
            return Form(['ref', 'null', expression[1]])
        if op in ('block', 'if', 'loop'):
            return single_type(forms(expression, 'result')[0])
        if op == 'select':
            return self.expression_type(expression[1], locals)
        if op == 'call':
            return self.function_result(expression[1])
        if op == 'call_ref':
            return single_type(forms(self.types[expression[1]], 'result')[0])
        if op.startswith(('i32.', 'i64.', 'f32.', 'f64.')):
            if re.search(r'\.(eq|eqz|ne|lt|le|gt|ge)(_[su])?$', op):
                return 'i32'
            return op.split('.')[0]
        if op == 'ref.is_null':
            return 'i32'
        raise ValueError((op, render(expression)))


# ---- Allocation-free observers ----

def bump(number):
    name = '$__profile_' + str(number)
    return Form(['global.set', name, Form(['i64.add', Form(['global.get', name]), Form(['i64.const', '1'])])])


class Observers:
    def __init__(self, module, original_path):
        self.types = ModuleTypes(module)
        self.original_path = str(original_path)
        self.records, self.helpers = [], []
        self.function, self.locals = None, None

    def record(self, node, category, target=None):
        number = len(self.records)
        self.records.append(dict(id=number, function=self.function, category=category,
                                 opcode=node[0], target=target, wat_path=self.original_path,
                                 wat_line=node.line))
        return number

    def passthrough(self, expression, value_type, number):
        assert value_type is not None
        name = '$__observe_' + str(number)
        helper = Form(['func', name, Form(['param', '$value', value_type]),
                       Form(['result', value_type]), bump(number), Form(['local.get', '$value'])])
        self.helpers.append(helper)
        self.types.functions[name] = helper
        return Form(['call', name, expression], line=expression.line)

    def call_reached(self, node):
        number = self.record(node, 'call reached', node[1])
        if len(node) > 2:
            node[-1] = self.passthrough(node[-1], self.types.expression_type(node[-1], self.locals), number)
            return node
        result = self.types.function_result(node[1])
        declaration = [Form(['result', result])] if result else []
        return Form(['block', *declaration, bump(number), node], line=node.line)

    def rewrite(self, node):
        if not isinstance(node, Form):
            return node
        original = Form(node, line=node.line)
        node = Form([self.rewrite(child) for child in node], line=node.line)
        op = node[0]
        if op in ('call', 'call_ref', 'return_call', 'return_call_ref'):
            return self.call_reached(node)
        if op.startswith(('struct.new', 'array.new')):
            number = self.record(original, 'constructor completed', original[1])
            return self.passthrough(node, Form(['ref', Form(['exact', node[1]])]), number)
        if op in ('ref.cast', 'ref.as_non_null', 'ref.is_null'):
            number = self.record(original, 'reference operation completed', render(original[1]) if op == 'ref.cast' else None)
            return self.passthrough(node, self.types.expression_type(original, self.locals), number)
        if readiness_check(original):
            number = self.record(original, 'readiness evaluated', render(original[1][1]) if original[1][0] == 'i32.eqz' else None)
            node[1] = self.passthrough(node[1], 'i32', number)
        return node


def readiness_check(node):
    if len(node) != 3 or node[0] != 'if' or node[2] != Form(['then', Form(['unreachable'])]):
        return False
    condition = node[1]
    if len(condition) != 2 or condition[0] != 'i32.eqz':
        return False
    read = condition[1]
    return (read[0] == 'global.get' and read[1].startswith('$ready')) or (read[0] == 'struct.get' and read[2] == '0')


def erase_observers(node):
    if not isinstance(node, Form):
        return node
    if node[0] == 'call' and node[1].startswith('$__observe_'):
        return erase_observers(node[2])
    if node[0] == 'global.set' and node[1].startswith('$__profile_'):
        return None
    generated_block = node[0] == 'block' and any(isinstance(child, Form) and child[0] == 'global.set'
                                               and child[1].startswith('$__profile_') for child in node)
    children = [result for child in node if (result := erase_observers(child)) is not None]
    if generated_block:
        last = children[-1]
        if isinstance(last, Form) and last[0] in ('call', 'return_call'):
            return last
    return Form(children, line=node.line)


# ---- Build and structural validation ----

def observe(original_path, output_path):
    original = parse(original_path.read_text())
    module = parse(original_path.read_text())
    observers = Observers(module, original_path)
    for index, function in enumerate(module):
        if not isinstance(function, Form) or function[0] != 'func':
            continue
        observers.function = function[1]; observers.locals = observers.types.local_types(function)
        rewritten = observers.rewrite(function)
        number = observers.record(function, 'function entered', function[1])
        position = next((i for i, child in enumerate(rewritten[2:], 2)
                         if isinstance(child, Form) and child[0] not in ('type', 'param', 'result', 'local')), len(rewritten))
        rewritten.insert(position, bump(number)); module[index] = rewritten
        assert render(erase_observers(rewritten)) == render(function), function[1]
    declarations = []
    for record in observers.records:
        number = record['id']; name = '$__profile_' + str(number)
        declarations += [Form(['global', name, Form(['mut', 'i64']), Form(['i64.const', '0'])]),
                         Form(['export', json.dumps('counter' + str(number)), Form(['global', name])])]
    position = max((i for i, node in enumerate(module) if isinstance(node, Form) and node[0] == 'import'), default=0) + 1
    module[position:position] = declarations
    module.extend(observers.helpers)
    output_path.write_text('(module\n' + '\n'.join(' ' + render(child) for child in module[1:]) + '\n)\n')
    metadata = dict(original_wat=str(original_path), original_sha256=hashlib.sha256(original_path.read_bytes()).hexdigest(),
                    instrumented_wat=str(output_path), instrumented_sha256=hashlib.sha256(output_path.read_bytes()).hexdigest(),
                    structural_validation='Erasing observers exactly recovers every original function form.',
                    definitions='Completed constructors/reference operations; reached call opcode after operand evaluation; entered function; evaluated readiness condition. No allocator-event or uninstrumented-JIT allocation claim.',
                    counters=observers.records)
    output_path.with_suffix('.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(dict(output=str(output_path), counters=len(observers.records), categories=dict(Counter(x['category'] for x in observers.records)))))


if __name__ == '__main__':
    observe(Path(sys.argv[1]), Path(sys.argv[2]))
