(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-deriv-preparation-20261013-r2/deriv/chez-output-probe-original/program.scm" "/tmp/snail-strict-deriv-preparation-20261013-r2/deriv/chez-output-probe-original/program.so"))
