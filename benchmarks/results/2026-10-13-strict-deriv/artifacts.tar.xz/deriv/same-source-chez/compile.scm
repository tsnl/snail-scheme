(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-deriv-preparation-20261013-r2/deriv/same-source-chez/program.scm" "/tmp/snail-strict-deriv-preparation-20261013-r2/deriv/same-source-chez/program.so"))
