import os
from pathlib import Path
import sys
sys.path.insert(0, str(Path('benchmarks/strict-suite').resolve()))
import measure

paths = dict(CHIBI='/nix/store/rymbc3gyix886hxf3ns6cr7smmc9swy2-chibi-scheme-0.12/bin/chibi-scheme',
             NODE='/nix/store/lfaydgacdyngci7p60s8wwvgdm74fjkx-nodejs-24.19.0/bin/node',
             CHEZ='/nix/store/bzqpmy5kmvf0xn4xh5ixzkw00w9srh07-chez-scheme-10.4.1/bin/scheme',
             TASKSET='/run/current-system/sw/bin/taskset', BINARYEN_CORES='1')
for name in ('WASM_AS', 'WASM_OPT', 'WASM_DIS'):
    paths[name] = '/nix/store/nd1279k2zlbp23gfqcl0qp5xk40xlxr8-binaryen-132/bin/' + name.lower().replace('_', '-')
os.environ.update(paths)
directory = Path('build/mazefun-initial').resolve()
directory.mkdir(exist_ok=True)
source = Path('benchmarks/r7rs-benchmarks/src/mazefun.scm').read_text()
spec = measure.case_specification('mazefun', Path('benchmarks/r7rs-benchmarks/inputs/mazefun.input').read_bytes())
(directory/'strict.scm').write_text(measure.strict_program('mazefun', spec, source))
measure.save(directory/'spec.json', spec)
measure.build_strict(directory, paths, dict(os.environ))
print('built', flush=True)
measure.save(directory/'spec-one.json', dict(spec, count=1))
for suffix in ('.raw.wasm', ''):
    record = measure.execute([paths['NODE'], Path('benchmarks/strict-suite/host.mjs').resolve(),
                              directory/('strict.wasm'+suffix), directory/'spec-one.json', '--validate'],
                             directory, dict(os.environ))
    measure.save(directory/('check'+suffix+'.json'), record)
    measure.require_success(record)
    print('passed', suffix or 'optimized', flush=True)
