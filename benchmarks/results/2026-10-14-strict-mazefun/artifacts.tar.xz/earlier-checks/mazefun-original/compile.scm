(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-mazefun-20261014/build/mazefun-original/program.scm" "/tmp/snail-strict-mazefun-20261014/build/mazefun-original/program.so"))
