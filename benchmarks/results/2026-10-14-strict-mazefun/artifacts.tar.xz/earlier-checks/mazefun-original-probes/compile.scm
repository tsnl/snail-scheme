(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-mazefun-20261014/build/mazefun-original-probes/program.scm" "/tmp/snail-strict-mazefun-20261014/build/mazefun-original-probes/program.so"))
