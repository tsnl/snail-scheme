"""Exercise the frozen input reader and its Python error boundary."""

import json
import os
from pathlib import Path
import subprocess
import sys

prepared, destination = map(Path, sys.argv[1:])
sys.path.insert(0, str(prepared))
import mazefun_port

metadata = json.loads((prepared / 'prepared.json').read_text())
chez = metadata['tools']['CHEZ']['path']
os.environ['CHEZ'] = chez
source = destination / 'input-decoder.scm'
source.write_text(mazefun_port.INPUT_DECODER)
cases = {
    'empty': '',
    'missing-dimensions': '1\n',
    'missing-column': '1\n3\n',
    'missing-expectation': '1\n3\n3\n',
    'truncated-list': '1\n3\n3\n((_\n',
    'invalid-dot': '1\n3\n3\n(. _)\n',
    'symbol-count': 'one\n3\n3\n()\n',
    'inexact-count': '1.0\n3\n3\n()\n',
    'fractional-row': '1\n3/2\n3\n()\n',
    'boolean-column': '1\n3\n#t\n()\n',
    'overflow-count': '9223372036854775808\n3\n3\n()\n',
    'underflow-row': '1\n-9223372036854775809\n3\n()\n',
}
records = []
for label, data in cases.items():
    command = [chez, '--program', str(source)]
    run = subprocess.run(command, input=data, capture_output=True, text=True, timeout=30)
    assert run.returncode != 0 and run.stderr
    try:
        mazefun_port.specification(data.encode())
    except ValueError as error:
        assert str(error).startswith('mazefun input reader failed:')
    else:
        raise AssertionError('Python boundary accepted ' + label)
    records.append(dict(label=label, stdin=data, command=command, returncode=run.returncode,
                        stdout=run.stdout, stderr=run.stderr, python_rejected=True))

accepted = [('#x1\n#d3\n#e3.0\n|error|\n', 1, [3, 3], [1]),
            ('-9223372036854775808\n9223372036854775807\n-1\n#false\n',
             '-9223372036854775808', ['9223372036854775807', -1], [0])]
for data, count, inputs, expected in accepted:
    actual = mazefun_port.specification(data.encode())
    assert (actual['count'], actual['inputs'], actual['expected']) == (count, inputs, expected)
    records.append(dict(label='accepted-reader-spelling', stdin=data, specification=actual))
(destination / 'reader-checks.json').write_text(json.dumps(records, indent=2) + '\n')
print(f'Passed {len(cases)} rejected inputs and {len(accepted)} accepted reader boundary cases')
