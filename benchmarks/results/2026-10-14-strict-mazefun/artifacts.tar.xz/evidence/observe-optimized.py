"""Observe the exact optimized Mazefun artifact without reoptimization."""

import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

prepared, destination = map(Path, sys.argv[1:])
destination.mkdir(parents=True, exist_ok=True)
metadata = json.loads((prepared / 'prepared.json').read_text())
source = (prepared / 'mazefun/strict.optimized.wat').read_text()
insertions, counters, sites = collections.defaultdict(list), {}, collections.Counter()
locations = []
functions = list(re.finditer(r'(?m)^ \(func (\$[^\s()]+)', source))


def increment(key):
    cell = counters.setdefault(key, '$observed' + str(len(counters)))
    sites[key] += 1
    return f'(global.set {cell} (i64.add (global.get {cell}) (i64.const 1)))'


def closing(start):
    depth = 0
    for index in range(start, len(source)):
        depth += (source[index] == '(') - (source[index] == ')')
        if depth == 0:
            return index + 1
    raise ValueError('unclosed optimized expression')


headers = re.compile(r'(?m)^ \(func (\$[^\s()]+)[^\n]*\n(?:  \(local [^\n]*\)\n)*')
for match in headers.finditer(source):
    insertions[match.end()].append('  ' + increment('function:' + match[1]) + '\n')
operations = re.compile(r'\((struct.new(?:_default)?|struct.set) (\$[^\s()]+)(?: (\d+))?')
for match in operations.finditer(source):
    store = match[1] == 'struct.set'
    owner = next(item[1] for item in reversed(functions) if item.start() < match.start())
    key = 'store:' + match[2] + ':' + match[3] if store else 'constructor:' + match[2]
    key += ':' + owner
    locations.append(dict(key=key, line=source.count('\n', 0, match.start()) + 1))
    result = '' if store else ' (result (ref ' + match[2] + '))'
    insertions[match.start()].append('(block' + result + ' ' + increment(key) + ' ')
    insertions[closing(match.start())].append(')')
# Each executed remainder by 131072 is one original shuffle state advance.
for match in re.finditer(r'\(i64.rem_s\b', source):
    end = closing(match.start())
    expression = source[match.start():end]
    if not re.search(r'\(i64.const 131072\)\s*\)$', expression):
        continue
    insertions[match.start()].append('(block (result i64) ' + increment('shuffle-state-advance') + ' ')
    insertions[end].append(')')
    locations.append(dict(key='shuffle-state-advance', line=source.count('\n', 0, match.start()) + 1))

declarations = ''.join(f' (global {cell} (mut i64) (i64.const 0))\n'
                       f' (export "observed:{key}" (global {cell}))\n'
                       for key, cell in counters.items())
insertions[source.rfind(')')].append(declarations)
pieces, ranges, previous, size = [], [], 0, 0
for position, additions in sorted(insertions.items()):
    original = source[previous:position]
    pieces.append(original)
    size += len(original)
    added = ''.join(additions)
    pieces.append(added)
    ranges.append((size, size + len(added)))
    size += len(added)
    previous = position
pieces.append(source[previous:])
observed = ''.join(pieces)
restored = observed
for start, end in reversed(ranges):
    restored = restored[:start] + restored[end:]
assert restored == source
(destination / 'observed.wat').write_text(observed)
command = [metadata['tools']['WASM_AS']['path'], str(destination / 'observed.wat'),
           '--mvp-features', '--enable-gc', '--enable-reference-types', '--enable-tail-call',
           '--enable-mutable-globals', '--enable-sign-ext', '--enable-bulk-memory',
           '--enable-nontrapping-float-to-int', '-o', str(destination / 'observed.wasm')]
run = subprocess.run(command, capture_output=True, text=True)
(destination / 'build.json').write_text(json.dumps(dict(command=command, returncode=run.returncode,
    stdout=run.stdout, stderr=run.stderr), indent=2) + '\n')
run.check_returncode()
proof = dict(original_wat_sha256=hashlib.sha256(source.encode()).hexdigest(),
             original_wasm_sha256=hashlib.sha256((prepared / 'mazefun/strict.wasm').read_bytes()).hexdigest(),
             erased_text_exact_match=True, reoptimized=False, sites=dict(sites), locations=locations,
             counter_semantics="Function entry and constructor/shuffle expression entry; canonical checks return normally.",
             initialization_excluded=True)
(destination / 'source-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
