"""Bound retained-work claims to sites in the exact optimized artifact."""

from collections import Counter
import json
from pathlib import Path
import re
import sys

prepared, evidence = map(Path, sys.argv[1:])
sys.path.insert(0, str(prepared))
from data_ports import form

directory = evidence / 'retained'
proof = json.loads((directory / 'source-proof.json').read_text())
roles = {
    '$function48': 'same-row?: each Boolean mark and the row terminator',
    '$function49': 'same-grid?: each row and the outer terminator',
    '$function53': 'make-maze: parity, construction, shuffle, piercing and final map',
    '$function61': 'specialized increasing outer-list construction recursion',
    '$function63': 'candidate hole parity and coordinate construction callback',
    '$function68': 'right fold concatenating candidate row lists',
    '$function70': 'shuffle-aux: state advance, length, read, removal and recursion',
    '$function71': 'cavity-list length',
    '$function72': 'length accumulator recursion',
    '$function73': 'cavity-list indexed read',
    '$function74': 'list-remove-pos: copied prefix and shared remaining suffix',
    '$function75': 'pierce-randomly recursion remaining after ten inlined steps',
    '$function76': 'try-to-pierce: duplicate labels, ordered flood fold and pierce',
    '$function77': 'neighboring-cavities: bounds and open tests in up/down/left/right order',
    '$function82': 'outer-list indexed read',
    '$function86': 'left-fold callback beginning change-cavity',
    '$function88': 'change-cavity-aux: compare old label, persistent write, neighbor fold',
    '$function89': 'recursive flood left-fold callback',
    '$function91': 'list-write at cavity-list type',
    '$function92': 'list-write at outer-list type',
    '$function98': 'map open cells to one complete Boolean row',
    '$function99': 'row-map recursion remaining after inlining',
    '$function100': 'outer result-map recursion remaining after inlining',
    '$function106': 'runtime repetition, two returned opaque dimensions, final predicate',
}
source = (prepared / 'mazefun/strict.optimized.wat').read_text()
function_lines = {m[1]: source.count('\n', 0, m.start()) + 1
                  for m in re.finditer(r'(?m)^ \(func (\$[^\s()]+)', source)}
observations = []
for count in [1, 2, 10000]:
    record = json.loads((directory / f'run-{count}-canonical.json').read_text())
    assert record['returncode'] == 0 and not record['stderr']
    observed = json.loads(record['stdout'])
    counters = {key: int(value) for key, value in observed['observed'].items()}
    totals = Counter()
    for key, value in counters.items():
        if key.startswith('constructor:'):
            totals[key.split(':')[1]] += value
    observed['constructors_by_type'] = dict(totals)
    assert counters['function:$function53'] == count
    assert counters['shuffle-state-advance'] == 60 * count
    assert counters['function:$function76'] == 60 * count
    assert counters['function:$function48'] == 132
    assert counters['function:$function49'] == 12
    assert counters['function:$function106'] == count + 1
    if observations:
        once = observations[0]['observed']
        for key, value in counters.items():
            if key not in ['function:$function48', 'function:$function49',
                           'function:$function106', 'function:$export0']:
                assert value == int(once[key]) * count, key
    observations.append(observed)

invalid = json.loads(json.loads((directory / 'run-10000-3.json').read_text())['stdout'])
for key, value in observations[-1]['observed'].items():
    if key not in ['function:$function48', 'function:$function49']:
        assert invalid['observed'][key] == value, key
assert invalid['result'] == '0' and invalid['observed']['function:$function48'] == '0'
zero = json.loads(json.loads((directory / 'run-0-0.json').read_text())['stdout'])
assert all(int(value) == 0 for key, value in zero['observed'].items()
           if key not in ['function:$function106', 'function:$export0'])

original = (prepared / 'mazefun/original-kernel.scm').read_text()
adapted = (prepared / 'mazefun/adapted-kernel.scm').read_text()
definitions = re.findall(r'\(define ([^\s()]+)(\s)', original)
unchanged = [name for name, separator in definitions
             if form(original, '(define ' + name + separator)
             == form(adapted, '(define ' + name + separator)]
summary = dict(proof, optimized_bytes=(prepared / 'mazefun/strict.wasm').stat().st_size,
               canonical_exports=['bench', 'main'],
               function_roles={name: dict(line=function_lines[name], role=role)
                               for name, role in roles.items()},
               exact_original_definitions=unchanged,
               adapted_definitions=[name for name, _ in definitions if name not in unchanged],
               canonical_observations=observations, invalid_expectation=invalid, initial_false=zero,
               all_kernel_counters_scale=True, invalid_expectation_keeps_all_kernel_counters=True,
               canonical_disassembly_reproduced=True, clean_measurements=0,
               limitations='Counts are function/expression entries in a separate observer copy. '
               'They are not physical V8 GC allocations, uninstrumented native instruction counts, '
               'or performance samples. Optimizer inlining means residual function entries are '
               'not totals of every corresponding source call. Constructor expression entry '
               'precedes operand evaluation; these canonical runs finish without traps.')
(evidence / 'retention-audit.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Verified all kernel counters scale at 1/2/10000; invalid expected data preserves the full work')
