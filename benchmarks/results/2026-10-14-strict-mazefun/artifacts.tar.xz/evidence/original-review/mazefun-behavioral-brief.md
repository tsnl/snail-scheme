# Independent behavioral brief: functional maze benchmark

Explain a faithful strict typed port of an existing functional maze algorithm.
Use no tools, files, implementation, prior review or conversation history. Give
a high-level model, minimal typed data, direct pseudocode, invariants, edge cases
and a bounded evidence plan. Do not replace the algorithm with a faster maze
generator. The compiler already supports I64, Bool, homogeneous immutable lists,
nominal products, closed variants, rank-one polymorphism and concrete closures.

Inputs are an outer repetition count, two grid dimensions and a complete expected
result. The canonical workload repeats 10,000 times on an 11 by 11 grid. Both
dimensions pass through runtime opacity on every invocation. Initialization and
expected-result decoding precede the clock; every invocation and the final full
result predicate are timed. The outer runner starts with false, so a nonpositive
count retains false. An even dimension returns a distinguished error symbol.
For odd dimensions, the original increasing-index loops produce an empty outer
list for a negative first dimension, or empty rows for a negative second one.

The algorithm uses nested linked lists throughout, not arrays. Initial open
cells at even/even coordinates are labeled by their coordinate pairs. Other
cells are false. Candidate holes have opposite row/column parity and are listed
in row-major order. A deterministic shuffle starts its random state at zero on
each invocation. Each step computes (state * 3581 + 12751) modulo 131072, selects
that number modulo remaining-list length, copies the prefix while removing the
selected entry, and recurses. It performs no random step for an empty list.

Process shuffled holes in order, carrying the current functional grid. For a
hole, collect in-bounds open neighbors in up/down/left/right order. Compare their
cavity labels structurally by coordinate. If any label occurs more than once,
leave the grid unchanged. Otherwise, in neighbor order, flood-relabel each old
cavity to the hole's coordinate and then mark the hole open with that label.
Flooding reads the current cell label, compares it with the original old label,
and only on equality replaces that cell and recursively processes its current
open neighbors in up/down/left/right order. Updated grids flow through a left
fold, so later recursive work sees previous updates.

A functional cell write copies only the outer prefix through its selected row
and that row's prefix through the selected cell. Unchanged suffixes and other
rows remain shared. No mutation, disjoint-set replacement, vector conversion,
memoization or graph shortcuts are permitted in this port. List reads, lengths,
removals, appends, right/left folds and callback order remain the source algorithm.
For the canonical and bounded probes all integer operations fit I64.

After all holes, map open cells to the underscore symbol and closed cells to
the asterisk symbol. Check every row, every mark, every row end and the outer
list end against the supplied expected datum. This is not a count or checksum.
The strict port can give the finite symbols and coordinate/false combinations
concrete types, but must preserve their distinctions and the complete result.
General symbol interning and a generic dynamic interpreter are outside this
port. Original Chez is unchanged, and an adapted-source Chez control must use
the same kernel transformations with explicit representation costs disclosed.

Evidence must include actual raw and optimized Wasm and both Chez controls at
canonical inputs/count, plus complete outputs for small square and rectangular
grids, skinny grids, invalid even dimensions, negative odd dimensions, initial
false outcomes and deliberately wrong expected values/shapes. Separate probes
can observe shuffle order, hole decisions, cavity relabeling and functional
sharing; they must not add observers to the timed program. Inspect optimized
retained work before clean timing. Compilation/correctness durations are not
performance samples, and clean timings require a coordinated CPU window.

Distinguish required behavior from representation choices and unknown compiler
costs. Challenge unnecessary state or wrappers while preserving the algorithm.
