"""Check the bounded integration leaves all previous port generators unchanged."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

root, destination = map(Path, sys.argv[1:])
sys.path.insert(0, str(root / 'benchmarks/strict-suite'))
import measure

baseline_source = subprocess.check_output(['git', 'show', '53008a4:benchmarks/strict-suite/measure.py'], cwd=root, text=True)
baseline = types.ModuleType('baseline_measure')
baseline.__file__ = str(root / 'benchmarks/strict-suite/measure.py')
exec(compile(baseline_source, baseline.__file__, 'exec'), baseline.__dict__)
records = []
for name in baseline.NAMES:
    upstream = (root / f'benchmarks/r7rs-benchmarks/src/{name}.scm').read_text()
    data = (root / f'benchmarks/r7rs-benchmarks/inputs/{name}.input').read_bytes()
    spec = baseline.case_specification(name, data)
    assert measure.case_specification(name, data) == spec
    original = baseline.strict_program(name, spec, upstream)
    assert measure.strict_program(name, spec, upstream) == original
    records.append(dict(name=name, specification_equal=True, generated_source_equal=True,
                        generated_sha256=hashlib.sha256(original.encode()).hexdigest()))
(destination / 'previous-generators.json').write_text(json.dumps(records, indent=2) + '\n')
print(f'Passed unchanged specifications and strict sources for {len(records)} existing ports')
