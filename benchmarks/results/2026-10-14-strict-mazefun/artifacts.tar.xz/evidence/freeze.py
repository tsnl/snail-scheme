"""Freeze exact ready/failed preparations and the bounded Mazefun evidence."""

import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

root, prepared = map(Path, sys.argv[1:])
evidence = root / 'build/mazefun-evidence'
report = root / 'benchmarks/results/2026-10-14-strict-mazefun'
source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
metadata = json.loads((prepared / 'prepared.json').read_text())
files = {}


def include(path, prefix):
    entries = sorted(path.rglob('*')) if path.is_dir() else [path]
    for item in entries:
        if item.is_file() and '__pycache__' not in item.parts:
            suffix = str(item.relative_to(path)) if path.is_dir() else item.name
            name = str(Path(prefix) / suffix) if prefix else suffix
            assert name not in files, name
            files[name] = item.read_bytes()


include(prepared, '')
include(evidence, 'evidence')
for revision in [1, 2]:
    include(Path(f'/tmp/snail-strict-mazefun-preparation-20261014-r{revision}'),
            f'failed-attempts/preparation-r{revision}')
for name in ['mazefun-original', 'mazefun-original-probes', 'mazefun-initial']:
    include(root / 'build' / name, 'earlier-checks/' + name)
for name in ['mazefun-original-harness-checks.json', 'mazefun-harness-fixtures.json',
             'mazefun-dev.py']:
    include(root / 'build' / name, 'earlier-checks')
include(root / 'build/mazefun-behavioral-brief.md', 'evidence/original-review')
include(root / '.agents/skills/simplify/SKILL.md', 'evidence/original-review/simplify')
include(root / 'benchmarks/strict-suite/replay.py', 'evidence')
for name in ['README.md', 'review.md', 'protocol.md']:
    include(report / name, 'evidence/report')
for name in ['correctness-summary.json', 'retention-audit.json']:
    (report / name).write_bytes((evidence / name).read_bytes())
for filename in ['measure.py', 'mazefun_port.py']:
    committed = subprocess.check_output(['git', 'show', f'{source_commit}:benchmarks/strict-suite/{filename}'], cwd=root)
    assert committed == files[filename], filename

archive = report / 'artifacts.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as target:
    for name, data in sorted(files.items()):
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
        target.addfile(entry, io.BytesIO(data))
manifest = dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                files={name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
                source_commit=source_commit, compiler_commit=metadata['compiler_commit'],
                driver_commit_at_preparation=metadata['driver_commit'],
                driver_sha256=metadata['driver_sha256'], adapter_sha256=metadata['mazefun_port_sha256'],
                upstream_commit=metadata['upstream_commit'], preparation_directory=str(prepared),
                clean_measurements=0)
(report / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'Archived {len(files)} files; SHA-256 {manifest["archive_sha256"]}')
