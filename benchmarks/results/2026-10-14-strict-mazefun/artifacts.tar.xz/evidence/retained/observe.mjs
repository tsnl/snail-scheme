import fs from 'node:fs';
import assert from 'node:assert/strict';

const [artifact, specification, count, expectation = 'canonical'] = process.argv.slice(2);
const spec = JSON.parse(fs.readFileSync(specification, 'utf8'));
const expected = expectation === 'canonical' ? spec.expected : [Number(expectation)];
let hides = 0;
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), {benchmark: {
  expected_i64: index => BigInt(expected[Number(index)]),
  input_i64: index => BigInt(spec.inputs[index]),
  hide_i64: value => { hides++; return value; },
}});
instance.exports.main();
assert.equal(hides, 0);
const counters = Object.entries(instance.exports).filter(([name]) => name.startsWith('observed:'));
const before = Object.fromEntries(counters.map(([name, value]) => [name, value.value]));
const result = instance.exports.bench(BigInt(count));
assert.equal(hides, Math.max(0, Number(count)) * 2);
assert.equal(result, expectation === 'canonical' || (Number(count) <= 0 && expectation === '0') ? 1n : 0n);
const observed = Object.fromEntries(counters.map(([name, value]) =>
  [name.slice('observed:'.length), (value.value - before[name]).toString()]));
console.log(JSON.stringify({count, expectation, result: result.toString(), hides, observed}));
