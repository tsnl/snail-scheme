(module
 (rec
  (type $type35 (sub (struct (field i32))))
  (type $type29 (sub (struct)))
  (type $2 (func (param i64 i32 i32 i64 (ref $type35)) (result i64)))
  (type $call90 (func (param i64) (result (ref null $type40))))
  (type $call91 (func (param i64) (result (ref null $type39))))
  (type $call92 (func (result (ref $type35))))
  (type $call5 (func (result i64)))
  (type $call53 (func (param (ref $type54) (ref null $type33)) (result (ref null $type39))))
  (type $call52 (func (param (ref $type34) (ref null $type28)) (result (ref null $type40))))
  (type $call54 (func (param (ref $environment98) (ref null $type28)) (result (ref null $type40))))
  (type $10 (func (param (ref $type61) i32 i32 (ref null $type33) (ref null $type28)) (result (ref null $type33))))
  (type $call70 (func (param (ref null $type33) i64 (ref null $type28)) (result (ref $type33))))
  (type $call69 (func (param (ref null $type28) i64 (ref $type29)) (result (ref $type28))))
  (type $environment89 (struct (field (ref $type29)) (field (ref $type29))))
  (type $call87 (func (param (ref null $type33) (ref $type29) (ref $type29) (ref $type29)) (result (ref null $type33))))
  (type $call50 (func (param (ref $type51) (ref null $type28)) (result (ref null $type28))))
  (type $call51 (func (param (ref $environment84) (ref $type29)) (result (ref $type29))))
  (type $call68 (func (param (ref null $type33) i64) (result (ref null $type28))))
  (type $call75 (func (param (ref null $type33) i64 i64) (result (ref $type29))))
  (type $19 (func (param i32 i32 (ref null $type33) i64) (result i64)))
  (type $call88 (func (param (ref $type29) (ref null $type33)) (result (ref null $type28))))
  (type $call61 (func (param (ref struct) (ref null $type33) (ref $type29)) (result (ref null $type33))))
  (type $environment86 (struct (field (ref $type29))))
  (type $environment84 (struct (field (ref null $type33))))
  (type $type51 (struct (field (ref $environment84))))
  (type $type61 (struct (field (ref $call61)) (field (ref struct))))
  (type $call84 (func (param (ref $type29) (ref null $type33)) (result (ref null $type33))))
  (type $call85 (func (param (ref null $type28) (ref null $type33)) (result (ref null $type33))))
  (type $call71 (func (param (ref null $type28) i64) (result (ref null $type28))))
  (type $call67 (func (param (ref null $type28) i64) (result (ref $type29))))
  (type $30 (func (param i32 i32 (ref null $type28) i64) (result i64)))
  (type $call27 (func (param (ref null $type28)) (result i64)))
  (type $32 (func (param (ref null $type28) i64) (result (ref null $type28))))
  (type $33 (func (param (ref $type48) (ref null $type28) i32 i32 (ref null $type33)) (result (ref null $type28))))
  (type $call48 (func (param (ref null $type28) (ref null $type28)) (result (ref null $type28))))
  (type $environment63 (struct (field i64)))
  (type $36 (func (param i64 (ref $type65) i32 i32 i64) (result (ref null $type33))))
  (type $37 (func (param i64 (ref $type63) i32 i32 i64) (result (ref null $type28))))
  (type $environment57 (struct (field i64)))
  (type $type63 (struct (field (ref $environment57))))
  (type $call74 (func (param i64 i64) (result (ref $type29))))
  (type $type38 (sub $type35 (struct (field i32) (field (ref null $type39)))))
  (type $environment98 (struct (field (ref $type34))))
  (type $environment62 (struct (field i64)))
  (type $environment56 (struct (field i64) (field (ref $type74))))
  (type $type74 (struct))
  (type $type54 (struct (field (ref $environment98))))
  (type $call65 (func (param (ref struct) i64) (result (ref null $type28))))
  (type $type65 (struct (field (ref $call65)) (field (ref struct))))
  (type $type33 (struct (field (ref null $type28)) (field (ref null $type33))))
  (type $call82 (func (param i64 i64) (result (ref $type35))))
  (type $call72 (func (param (ref null $type28)) (result i32)))
  (type $type39 (struct (field (ref null $type40)) (field (ref null $type39))))
  (type $call56 (func (param (ref null $type39) (ref null $type39)) (result i32)))
  (type $type40 (struct (field i32) (field (ref null $type40))))
  (type $call55 (func (param (ref null $type40) (ref null $type40)) (result i32)))
  (type $type28 (struct (field (ref $type29)) (field (ref null $type28))))
  (type $call46 (func (param (ref $type29) (ref null $type28)) (result i32)))
  (type $call45 (func (param (ref $type29) (ref $type29)) (result i32)))
  (type $type31 (sub $type29 (struct (field i64) (field i64))))
  (type $call34 (func (param (ref $type29)) (result i32)))
  (type $type92 (struct))
  (type $type91 (struct))
  (type $type90 (struct))
  (type $type5 (struct))
  (type $type89 (struct (field (mut i64))))
  (type $type88 (struct))
  (type $type87 (struct))
  (type $type86 (struct))
  (type $type85 (struct))
  (type $type84 (struct))
  (type $type83 (struct))
  (type $type82 (struct))
  (type $type81 (struct))
  (type $type80 (struct))
  (type $type79 (struct))
  (type $type77 (struct))
  (type $type76 (struct))
  (type $type75 (struct))
  (type $type73 (struct))
  (type $type72 (struct))
  (type $type71 (struct))
  (type $type70 (struct))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type67 (struct))
  (type $type66 (struct))
  (type $type64 (struct))
  (type $type62 (struct))
  (type $type60 (struct))
  (type $type59 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (sub $type35 (struct (field i32))))
  (type $type37 (sub $type35 (struct (field i32))))
  (type $type36 (sub $type35 (struct (field i32))))
  (type $type34 (struct))
  (type $type30 (sub $type29 (struct)))
  (type $type32 (struct))
  (type $type27 (struct))
 )
 (type $113 (func (param i64) (result i64)))
 (type $114 (func (param i32) (result i64)))
 (type $115 (func))
 (import "benchmark" "expected_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global198 (mut (ref null $type27)) (ref.null none))
 (global $ready198 (mut i32) (i32.const 0))
 (global $global225 (mut (ref null $type32)) (ref.null none))
 (global $ready225 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type30)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type34)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global115 (mut (ref null $type36)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type37)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type41)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type42)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type43)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type44)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type44)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type45)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type46)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global178 (mut (ref null $type47)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (global $global182 (mut (ref null $type48)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global241 (mut (ref null $type49)) (ref.null none))
 (global $ready241 (mut i32) (i32.const 0))
 (global $global247 (mut (ref null $type50)) (ref.null none))
 (global $ready247 (mut i32) (i32.const 0))
 (global $global300 (mut (ref null $type52)) (ref.null none))
 (global $ready300 (mut i32) (i32.const 0))
 (global $global304 (mut (ref null $type53)) (ref.null none))
 (global $ready304 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type55)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type56)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type57)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global327 (mut (ref null $type58)) (ref.null none))
 (global $ready327 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type59)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global282 (mut (ref null $type60)) (ref.null none))
 (global $ready282 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type62)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type64)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global180 (mut (ref null $type66)) (ref.null none))
 (global $ready180 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type67)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global238 (mut (ref null $type68)) (ref.null none))
 (global $ready238 (mut i32) (i32.const 0))
 (global $global274 (mut (ref null $type69)) (ref.null none))
 (global $ready274 (mut i32) (i32.const 0))
 (global $global278 (mut (ref null $type70)) (ref.null none))
 (global $ready278 (mut i32) (i32.const 0))
 (global $global206 (mut (ref null $type71)) (ref.null none))
 (global $ready206 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type72)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global157 (mut (ref null $type73)) (ref.null none))
 (global $ready157 (mut i32) (i32.const 0))
 (global $global234 (mut (ref null $type75)) (ref.null none))
 (global $ready234 (mut i32) (i32.const 0))
 (global $global269 (mut (ref null $type76)) (ref.null none))
 (global $ready269 (mut i32) (i32.const 0))
 (global $global223 (mut (ref null $type77)) (ref.null none))
 (global $ready223 (mut i32) (i32.const 0))
 (global $global296 (mut (ref null $type79)) (ref.null none))
 (global $ready296 (mut i32) (i32.const 0))
 (global $ready148 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type80)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global191 (mut (ref null $type81)) (ref.null none))
 (global $ready191 (mut i32) (i32.const 0))
 (global $global193 (mut (ref null $type71)) (ref.null none))
 (global $ready193 (mut i32) (i32.const 0))
 (global $global151 (mut (ref null $type82)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (global $global294 (mut (ref null $type83)) (ref.null none))
 (global $ready294 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type84)) (ref.null none))
 (global $ready289 (mut i32) (i32.const 0))
 (global $global209 (mut (ref null $type85)) (ref.null none))
 (global $ready209 (mut i32) (i32.const 0))
 (global $global213 (mut (ref null $type84)) (ref.null none))
 (global $ready213 (mut i32) (i32.const 0))
 (global $global253 (mut (ref null $type86)) (ref.null none))
 (global $ready253 (mut i32) (i32.const 0))
 (global $global259 (mut (ref null $type87)) (ref.null none))
 (global $ready259 (mut i32) (i32.const 0))
 (global $global219 (mut (ref null $type88)) (ref.null none))
 (global $ready219 (mut i32) (i32.const 0))
 (global $global308 (mut (ref null $type89)) (ref.null none))
 (global $ready308 (mut i32) (i32.const 0))
 (global $global309 (mut (ref null $type5)) (ref.null none))
 (global $ready309 (mut i32) (i32.const 0))
 (global $global316 (mut (ref null $type90)) (ref.null none))
 (global $ready316 (mut i32) (i32.const 0))
 (global $global313 (mut (ref null $type91)) (ref.null none))
 (global $ready313 (mut i32) (i32.const 0))
 (global $global311 (mut (ref null $type92)) (ref.null none))
 (global $ready311 (mut i32) (i32.const 0))
 (global $global319 (mut i64) (i64.const 0))
 (global $ready319 (mut i32) (i32.const 0))
 (global $global320 (mut i64) (i64.const 0))
 (global $ready320 (mut i32) (i32.const 0))
 (global $global321 (mut (ref null $type35)) (ref.null none))
 (global $ready321 (mut i32) (i32.const 0))
 (global $global322 (mut (ref null $type80)) (ref.null none))
 (global $ready322 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call34) (param $0 (ref $type29)) (result i32)
  (global.set $observed0 (i64.add (global.get $observed0) (i64.const 1)))
  (if (result i32)
   (ref.test (ref $type30)
    (local.get $0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $type31)
      (local.get $0)
     )
    )
    (i32.const 1)
   )
  )
 )
 (func $function46 (type $call45) (param $0 (ref $type29)) (param $1 (ref $type29)) (result i32)
  (local $2 i64)
  (global.set $observed1 (i64.add (global.get $observed1) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type30)
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type31)
       (local.get $0)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type30)
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type31)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (if
       (ref.test (ref $type30)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type31 0
        (ref.cast (ref $type31)
         (local.get $0)
        )
       )
      )
      (if
       (ref.test (ref $type30)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i64.eq
        (struct.get $type31 0
         (ref.cast (ref $type31)
          (local.get $1)
         )
        )
        (local.get $2)
       )
       (then
        (if
         (ref.test (ref $type30)
          (local.get $0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $0)
          )
         )
        )
        (if
         (ref.test (ref $type30)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (i64.eq
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $1)
          )
         )
         (local.get $2)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (i32.eqz
     (if (result i32)
      (ref.test (ref $type30)
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type31)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function47 (type $call46) (param $0 (ref $type29)) (param $1 (ref null $type28)) (result i32)
  (local $2 (ref $type29))
  (local $3 i32)
  (global.set $observed2 (i64.add (global.get $observed2) (i64.const 1)))
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $2
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready129)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global129)
     )
    )
    (if (result i32)
     (local.tee $3
      (call $function46
       (local.get $0)
       (local.get $2)
      )
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready132)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global132)
       )
      )
      (return_call $function47
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function48 (type $call55) (param $0 (ref null $type40)) (param $1 (ref null $type40)) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $scratch (ref null $type40))
  (global.set $observed3 (i64.add (global.get $observed3) (i64.const 1)))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $3
       (struct.get $type40 0
        (local.get $0)
       )
      )
      (local.set $2
       (struct.get $type40 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready122)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (if (result i32)
       (select
        (local.get $2)
        (i32.eqz
         (local.get $2)
        )
        (local.get $3)
       )
       (then
        (return_call $function48
         (struct.get $type40 1
          (local.get $0)
         )
         (block (result (ref null $type40))
          (local.set $scratch
           (struct.get $type40 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready136)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global136)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function49 (type $call56) (param $0 (ref null $type39)) (param $1 (ref null $type39)) (result i32)
  (local $2 (ref null $type40))
  (local $3 (ref null $type40))
  (local $scratch (ref null $type40))
  (local $scratch_5 (ref null $type39))
  (global.set $observed4 (i64.add (global.get $observed4) (i64.const 1)))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (call $function48
        (struct.get $type39 0
         (local.get $0)
        )
        (block (result (ref null $type40))
         (local.set $scratch
          (struct.get $type39 0
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready136)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global136)
          )
         )
         (local.get $scratch)
        )
       )
       (then
        (return_call $function49
         (struct.get $type39 1
          (local.get $0)
         )
         (block (result (ref null $type39))
          (local.set $scratch_5
           (struct.get $type39 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready139)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (local.get $scratch_5)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $call72) (param $0 (ref null $type28)) (result i32)
  (local $1 (ref null $type28))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 i32)
  (local $scratch (ref null $type28))
  (global.set $observed5 (i64.add (global.get $observed5) (i64.const 1)))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $type28 0
      (local.get $0)
     )
    )
    (local.set $1
     (struct.get $type28 1
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready132)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (if (result i32)
     (local.tee $4
      (if (result i32)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i32.const 0)
       )
       (else
        (local.set $2
         (struct.get $type28 0
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready129)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global129)
         )
        )
        (if (result i32)
         (local.tee $4
          (call $function46
           (local.get $3)
           (local.get $2)
          )
         )
         (then
          (local.get $4)
         )
         (else
          (local.set $1
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready132)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global132)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i32.const 0)
           )
           (else
            (local.set $2
             (struct.get $type28 0
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (global.get $ready129)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global129)
             )
            )
            (if (result i32)
             (local.tee $4
              (call $function46
               (local.get $3)
               (local.get $2)
              )
             )
             (then
              (local.get $4)
             )
             (else
              (local.set $1
               (struct.get $type28 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready132)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global132)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i32.const 0)
               )
               (else
                (local.set $2
                 (struct.get $type28 0
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready129)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global129)
                 )
                )
                (if (result i32)
                 (local.tee $4
                  (call $function46
                   (local.get $3)
                   (local.get $2)
                  )
                 )
                 (then
                  (local.get $4)
                 )
                 (else
                  (local.set $1
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready132)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global132)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (local.set $2
                     (struct.get $type28 0
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready129)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global129)
                     )
                    )
                    (if (result i32)
                     (local.tee $4
                      (call $function46
                       (local.get $3)
                       (local.get $2)
                      )
                     )
                     (then
                      (local.get $4)
                     )
                     (else
                      (local.set $1
                       (struct.get $type28 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready132)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global132)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (local.set $2
                         (struct.get $type28 0
                          (local.get $1)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready129)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global129)
                         )
                        )
                        (if (result i32)
                         (local.tee $4
                          (call $function46
                           (local.get $3)
                           (local.get $2)
                          )
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (local.set $1
                           (struct.get $type28 1
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready132)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global132)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (local.set $2
                             (struct.get $type28 0
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready129)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global129)
                             )
                            )
                            (if (result i32)
                             (local.tee $4
                              (call $function46
                               (local.get $3)
                               (local.get $2)
                              )
                             )
                             (then
                              (local.get $4)
                             )
                             (else
                              (local.set $1
                               (struct.get $type28 1
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready132)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global132)
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (local.set $2
                                 (struct.get $type28 0
                                  (local.get $1)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready129)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global129)
                                 )
                                )
                                (if (result i32)
                                 (local.tee $4
                                  (call $function46
                                   (local.get $3)
                                   (local.get $2)
                                  )
                                 )
                                 (then
                                  (local.get $4)
                                 )
                                 (else
                                  (local.set $1
                                   (struct.get $type28 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready132)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global132)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (local.set $2
                                     (struct.get $type28 0
                                      (local.get $1)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready129)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global129)
                                     )
                                    )
                                    (if (result i32)
                                     (local.tee $4
                                      (call $function46
                                       (local.get $3)
                                       (local.get $2)
                                      )
                                     )
                                     (then
                                      (local.get $4)
                                     )
                                     (else
                                      (local.set $1
                                       (struct.get $type28 1
                                        (local.get $1)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready132)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global132)
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (local.set $2
                                         (struct.get $type28 0
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready129)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global129)
                                         )
                                        )
                                        (if (result i32)
                                         (local.tee $4
                                          (call $function46
                                           (local.get $3)
                                           (local.get $2)
                                          )
                                         )
                                         (then
                                          (local.get $4)
                                         )
                                         (else
                                          (local.set $1
                                           (struct.get $type28 1
                                            (local.get $1)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready132)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global132)
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (local.set $2
                                             (struct.get $type28 0
                                              (local.get $1)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready129)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global129)
                                             )
                                            )
                                            (if (result i32)
                                             (local.tee $4
                                              (call $function46
                                               (local.get $3)
                                               (local.get $2)
                                              )
                                             )
                                             (then
                                              (local.get $4)
                                             )
                                             (else
                                              (local.set $1
                                               (struct.get $type28 1
                                                (local.get $1)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready132)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global132)
                                               )
                                              )
                                              (call $function47
                                               (local.get $3)
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (return_call $function51
       (block (result (ref null $type28))
        (local.set $scratch
         (struct.get $type28 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready145)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global145)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function53 (type $call82) (param $0 i64) (param $1 i64) (result (ref $type35))
  (local $2 (ref null $type33))
  (local $3 (ref null $type33))
  (local $4 (ref null $type33))
  (local $5 (ref null $type28))
  (local $6 (ref null $type28))
  (local $7 (ref null $type28))
  (local $8 (ref $type29))
  (local $9 (ref null $type40))
  (local $10 (ref $call65))
  (local $11 (ref struct))
  (local $12 (ref $type54))
  (local $13 (ref $type65))
  (local $14 (ref $type48))
  (local $15 (ref $type34))
  (local $scratch (ref null $type33))
  (global.set $observed6 (i64.add (global.get $observed6) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if (result (ref $type35))
   (if (result i32)
    (i32.wrap_i64
     (i64.and
      (local.get $0)
      (i64.const 1)
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready127)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global127)
      )
     )
     (if
      (i32.eqz
       (global.get $ready125)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global125)
      )
     )
     (i32.wrap_i64
      (i64.and
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready157)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global157)
     )
    )
    (if
     (i32.eqz
      (global.get $ready169)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global169)
     )
    )
    (local.set $4
     (if (result (ref null $type33))
      (i64.gt_s
       (local.get $0)
       (i64.const 0)
      )
      (then
       (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
        (call_ref $call65
         (struct.get $type65 1
          (local.tee $13
           (block (result (ref $type65)) (global.set $observed45 (i64.add (global.get $observed45) (i64.const 1))) (struct.new $type65
            (ref.func $function56)
            (block (result (ref $environment56)) (global.set $observed46 (i64.add (global.get $observed46) (i64.const 1))) (struct.new $environment56
             (local.get $1)
             (block (result (ref $type74)) (global.set $observed47 (i64.add (global.get $observed47) (i64.const 1))) (struct.new_default $type74))
            ))
           ))
          )
         )
         (i64.const 0)
         (local.tee $10
          (struct.get $type65 0
           (local.get $13)
          )
         )
        )
        (if (result (ref null $type33))
         (i64.gt_s
          (local.get $0)
          (i64.const 1)
         )
         (then
          (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
           (call_ref $call65
            (local.tee $11
             (struct.get $type65 1
              (local.get $13)
             )
            )
            (i64.const 1)
            (local.get $10)
           )
           (if (result (ref null $type33))
            (i64.gt_s
             (local.get $0)
             (i64.const 2)
            )
            (then
             (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
              (call_ref $call65
               (local.get $11)
               (i64.const 2)
               (local.get $10)
              )
              (if (result (ref null $type33))
               (i64.gt_s
                (local.get $0)
                (i64.const 3)
               )
               (then
                (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                 (call_ref $call65
                  (local.get $11)
                  (i64.const 3)
                  (local.get $10)
                 )
                 (if (result (ref null $type33))
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 4)
                  )
                  (then
                   (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                    (call_ref $call65
                     (local.get $11)
                     (i64.const 4)
                     (local.get $10)
                    )
                    (if (result (ref null $type33))
                     (i64.gt_s
                      (local.get $0)
                      (i64.const 5)
                     )
                     (then
                      (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                       (call_ref $call65
                        (local.get $11)
                        (i64.const 5)
                        (local.get $10)
                       )
                       (if (result (ref null $type33))
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 6)
                        )
                        (then
                         (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                          (call_ref $call65
                           (local.get $11)
                           (i64.const 6)
                           (local.get $10)
                          )
                          (if (result (ref null $type33))
                           (i64.gt_s
                            (local.get $0)
                            (i64.const 7)
                           )
                           (then
                            (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                             (call_ref $call65
                              (local.get $11)
                              (i64.const 7)
                              (local.get $10)
                             )
                             (call $function61
                              (local.get $0)
                              (local.get $13)
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 8)
                             )
                            ))
                           )
                           (else
                            (ref.null none)
                           )
                          )
                         ))
                        )
                        (else
                         (ref.null none)
                        )
                       )
                      ))
                     )
                     (else
                      (ref.null none)
                     )
                    )
                   ))
                  )
                  (else
                   (ref.null none)
                  )
                 )
                ))
               )
               (else
                (ref.null none)
               )
              )
             ))
            )
            (else
             (ref.null none)
            )
           )
          ))
         )
         (else
          (ref.null none)
         )
        )
       ))
      )
      (else
       (ref.null none)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready169)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global169)
     )
    )
    (local.set $3
     (if (result (ref null $type33))
      (i64.gt_s
       (local.get $0)
       (i64.const 0)
      )
      (then
       (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
        (call_ref $call65
         (struct.get $type65 1
          (local.tee $13
           (block (result (ref $type65)) (global.set $observed45 (i64.add (global.get $observed45) (i64.const 1))) (struct.new $type65
            (ref.func $function62)
            (block (result (ref $environment62)) (global.set $observed48 (i64.add (global.get $observed48) (i64.const 1))) (struct.new $environment62
             (local.get $1)
            ))
           ))
          )
         )
         (i64.const 0)
         (local.tee $10
          (struct.get $type65 0
           (local.get $13)
          )
         )
        )
        (if (result (ref null $type33))
         (i64.gt_s
          (local.get $0)
          (i64.const 1)
         )
         (then
          (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
           (call_ref $call65
            (local.tee $11
             (struct.get $type65 1
              (local.get $13)
             )
            )
            (i64.const 1)
            (local.get $10)
           )
           (if (result (ref null $type33))
            (i64.gt_s
             (local.get $0)
             (i64.const 2)
            )
            (then
             (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
              (call_ref $call65
               (local.get $11)
               (i64.const 2)
               (local.get $10)
              )
              (if (result (ref null $type33))
               (i64.gt_s
                (local.get $0)
                (i64.const 3)
               )
               (then
                (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                 (call_ref $call65
                  (local.get $11)
                  (i64.const 3)
                  (local.get $10)
                 )
                 (if (result (ref null $type33))
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 4)
                  )
                  (then
                   (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                    (call_ref $call65
                     (local.get $11)
                     (i64.const 4)
                     (local.get $10)
                    )
                    (if (result (ref null $type33))
                     (i64.gt_s
                      (local.get $0)
                      (i64.const 5)
                     )
                     (then
                      (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                       (call_ref $call65
                        (local.get $11)
                        (i64.const 5)
                        (local.get $10)
                       )
                       (if (result (ref null $type33))
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 6)
                        )
                        (then
                         (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                          (call_ref $call65
                           (local.get $11)
                           (i64.const 6)
                           (local.get $10)
                          )
                          (if (result (ref null $type33))
                           (i64.gt_s
                            (local.get $0)
                            (i64.const 7)
                           )
                           (then
                            (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                             (call_ref $call65
                              (local.get $11)
                              (i64.const 7)
                              (local.get $10)
                             )
                             (if (result (ref null $type33))
                              (i64.gt_s
                               (local.get $0)
                               (i64.const 8)
                              )
                              (then
                               (block (result (ref $type33)) (global.set $observed44 (i64.add (global.get $observed44) (i64.const 1))) (struct.new $type33
                                (call_ref $call65
                                 (local.get $11)
                                 (i64.const 8)
                                 (local.get $10)
                                )
                                (call $function61
                                 (local.get $0)
                                 (local.get $13)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 9)
                                )
                               ))
                              )
                              (else
                               (ref.null none)
                              )
                             )
                            ))
                           )
                           (else
                            (ref.null none)
                           )
                          )
                         ))
                        )
                        (else
                         (ref.null none)
                        )
                       )
                      ))
                     )
                     (else
                      (ref.null none)
                     )
                    )
                   ))
                  )
                  (else
                   (ref.null none)
                  )
                 )
                ))
               )
               (else
                (ref.null none)
               )
              )
             ))
            )
            (else
             (ref.null none)
            )
           )
          ))
         )
         (else
          (ref.null none)
         )
        )
       ))
      )
      (else
       (ref.null none)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready180)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global180)
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (local.set $14
     (ref.as_non_null
      (global.get $global182)
     )
    )
    (if
     (i32.eqz
      (global.get $ready185)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global185)
     )
    )
    (local.set $7
     (call $function70
      (if (result (ref null $type28))
       (ref.is_null
        (local.get $3)
       )
       (then
        (ref.null none)
       )
       (else
        (local.set $5
         (struct.get $type33 0
          (local.get $3)
         )
        )
        (local.set $6
         (call $function68
          (local.get $14)
          (ref.null none)
          (i32.const 0)
          (i32.const 1)
          (struct.get $type33 1
           (local.get $3)
          )
         )
        )
        (if (result (ref null $type28))
         (ref.is_null
          (local.get $5)
         )
         (then
          (local.get $6)
         )
         (else
          (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
           (struct.get $type28 0
            (local.get $5)
           )
           (block (result (ref null $type28))
            (local.set $5
             (struct.get $type28 1
              (local.get $5)
             )
            )
            (if
             (i32.eqz
              (global.get $ready182)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global182)
             )
            )
            (if (result (ref null $type28))
             (ref.is_null
              (local.get $5)
             )
             (then
              (local.get $6)
             )
             (else
              (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
               (struct.get $type28 0
                (local.get $5)
               )
               (block (result (ref null $type28))
                (local.set $5
                 (struct.get $type28 1
                  (local.get $5)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready182)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global182)
                 )
                )
                (if (result (ref null $type28))
                 (ref.is_null
                  (local.get $5)
                 )
                 (then
                  (local.get $6)
                 )
                 (else
                  (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
                   (struct.get $type28 0
                    (local.get $5)
                   )
                   (block (result (ref null $type28))
                    (local.set $5
                     (struct.get $type28 1
                      (local.get $5)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready182)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global182)
                     )
                    )
                    (if (result (ref null $type28))
                     (ref.is_null
                      (local.get $5)
                     )
                     (then
                      (local.get $6)
                     )
                     (else
                      (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
                       (struct.get $type28 0
                        (local.get $5)
                       )
                       (block (result (ref null $type28))
                        (local.set $5
                         (struct.get $type28 1
                          (local.get $5)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready182)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global182)
                         )
                        )
                        (if (result (ref null $type28))
                         (ref.is_null
                          (local.get $5)
                         )
                         (then
                          (local.get $6)
                         )
                         (else
                          (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
                           (struct.get $type28 0
                            (local.get $5)
                           )
                           (block (result (ref null $type28))
                            (local.set $5
                             (struct.get $type28 1
                              (local.get $5)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready182)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global182)
                             )
                            )
                            (if (result (ref null $type28))
                             (ref.is_null
                              (local.get $5)
                             )
                             (then
                              (local.get $6)
                             )
                             (else
                              (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
                               (struct.get $type28 0
                                (local.get $5)
                               )
                               (block (result (ref null $type28))
                                (local.set $5
                                 (struct.get $type28 1
                                  (local.get $5)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready182)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global182)
                                 )
                                )
                                (if (result (ref null $type28))
                                 (ref.is_null
                                  (local.get $5)
                                 )
                                 (then
                                  (local.get $6)
                                 )
                                 (else
                                  (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                   (block (result (ref null $type28))
                                    (local.set $5
                                     (struct.get $type28 1
                                      (local.get $5)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready182)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global182)
                                     )
                                    )
                                    (if (result (ref null $type28))
                                     (ref.is_null
                                      (local.get $5)
                                     )
                                     (then
                                      (local.get $6)
                                     )
                                     (else
                                      (block (result (ref $type28)) (global.set $observed49 (i64.add (global.get $observed49) (i64.const 1))) (struct.new $type28
                                       (struct.get $type28 0
                                        (local.get $5)
                                       )
                                       (call $function66
                                        (struct.get $type28 1
                                         (local.get $5)
                                        )
                                        (block (result (ref null $type28))
                                         (if
                                          (i32.eqz
                                           (global.get $ready182)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global182)
                                          )
                                         )
                                         (local.get $6)
                                        )
                                       )
                                      ))
                                     )
                                    )
                                   )
                                  ))
                                 )
                                )
                               )
                              ))
                             )
                            )
                           )
                          ))
                         )
                        )
                       )
                      ))
                     )
                    )
                   )
                  ))
                 )
                )
               )
              ))
             )
            )
           )
          ))
         )
        )
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready191)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global191)
        )
       )
       (if
        (i32.eqz
         (global.get $ready148)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready193)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global193)
        )
       )
       (i64.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready209)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global209)
     )
    )
    (local.set $2
     (if (result (ref null $type33))
      (ref.is_null
       (local.get $7)
      )
      (then
       (local.get $4)
      )
      (else
       (local.set $6
        (struct.get $type28 1
         (local.get $7)
        )
       )
       (local.set $2
        (call $function76
         (struct.get $type28 0
          (local.get $7)
         )
         (block (result (ref null $type33))
          (if
           (i32.eqz
            (global.get $ready213)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global213)
           )
          )
          (local.get $4)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready209)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global209)
        )
       )
       (if (result (ref null $type33))
        (ref.is_null
         (local.get $6)
        )
        (then
         (local.get $2)
        )
        (else
         (local.set $5
          (struct.get $type28 1
           (local.get $6)
          )
         )
         (local.set $2
          (call $function76
           (struct.get $type28 0
            (local.get $6)
           )
           (block (result (ref null $type33))
            (if
             (i32.eqz
              (global.get $ready213)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global213)
             )
            )
            (local.get $2)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready209)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global209)
          )
         )
         (if (result (ref null $type33))
          (ref.is_null
           (local.get $5)
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $6
            (struct.get $type28 1
             (local.get $5)
            )
           )
           (local.set $2
            (call $function76
             (struct.get $type28 0
              (local.get $5)
             )
             (block (result (ref null $type33))
              (if
               (i32.eqz
                (global.get $ready213)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global213)
               )
              )
              (local.get $2)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready209)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global209)
            )
           )
           (if (result (ref null $type33))
            (ref.is_null
             (local.get $6)
            )
            (then
             (local.get $2)
            )
            (else
             (local.set $5
              (struct.get $type28 1
               (local.get $6)
              )
             )
             (local.set $2
              (call $function76
               (struct.get $type28 0
                (local.get $6)
               )
               (block (result (ref null $type33))
                (if
                 (i32.eqz
                  (global.get $ready213)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global213)
                 )
                )
                (local.get $2)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready209)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global209)
              )
             )
             (if (result (ref null $type33))
              (ref.is_null
               (local.get $5)
              )
              (then
               (local.get $2)
              )
              (else
               (local.set $6
                (struct.get $type28 1
                 (local.get $5)
                )
               )
               (local.set $2
                (call $function76
                 (struct.get $type28 0
                  (local.get $5)
                 )
                 (block (result (ref null $type33))
                  (if
                   (i32.eqz
                    (global.get $ready213)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global213)
                   )
                  )
                  (local.get $2)
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready209)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global209)
                )
               )
               (if (result (ref null $type33))
                (ref.is_null
                 (local.get $6)
                )
                (then
                 (local.get $2)
                )
                (else
                 (local.set $5
                  (struct.get $type28 1
                   (local.get $6)
                  )
                 )
                 (local.set $2
                  (call $function76
                   (struct.get $type28 0
                    (local.get $6)
                   )
                   (block (result (ref null $type33))
                    (if
                     (i32.eqz
                      (global.get $ready213)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global213)
                     )
                    )
                    (local.get $2)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready209)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global209)
                  )
                 )
                 (if (result (ref null $type33))
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $6
                    (struct.get $type28 1
                     (local.get $5)
                    )
                   )
                   (local.set $2
                    (call $function76
                     (struct.get $type28 0
                      (local.get $5)
                     )
                     (block (result (ref null $type33))
                      (if
                       (i32.eqz
                        (global.get $ready213)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global213)
                       )
                      )
                      (local.get $2)
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready209)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global209)
                    )
                   )
                   (if (result (ref null $type33))
                    (ref.is_null
                     (local.get $6)
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (local.set $5
                      (struct.get $type28 1
                       (local.get $6)
                      )
                     )
                     (local.set $2
                      (call $function76
                       (struct.get $type28 0
                        (local.get $6)
                       )
                       (block (result (ref null $type33))
                        (if
                         (i32.eqz
                          (global.get $ready213)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global213)
                         )
                        )
                        (local.get $2)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready209)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global209)
                      )
                     )
                     (if (result (ref null $type33))
                      (ref.is_null
                       (local.get $5)
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (local.set $6
                        (struct.get $type28 1
                         (local.get $5)
                        )
                       )
                       (local.set $2
                        (call $function76
                         (struct.get $type28 0
                          (local.get $5)
                         )
                         (block (result (ref null $type33))
                          (if
                           (i32.eqz
                            (global.get $ready213)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global213)
                           )
                          )
                          (local.get $2)
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready209)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global209)
                        )
                       )
                       (if (result (ref null $type33))
                        (ref.is_null
                         (local.get $6)
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (call $function75
                          (struct.get $type28 1
                           (local.get $6)
                          )
                          (block (result (ref null $type33))
                           (local.set $scratch
                            (call $function76
                             (struct.get $type28 0
                              (local.get $6)
                             )
                             (block (result (ref null $type33))
                              (if
                               (i32.eqz
                                (global.get $ready213)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global213)
                               )
                              )
                              (local.get $2)
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready209)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global209)
                            )
                           )
                           (local.get $scratch)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready294)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global294)
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (local.set $15
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (i32.eqz
      (global.get $ready296)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global296)
     )
    )
    (if
     (i32.eqz
      (global.get $ready304)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global304)
     )
    )
    (block (result (ref $type38)) (global.set $observed50 (i64.add (global.get $observed50) (i64.const 1))) (struct.new $type38
     (i32.const 2)
     (if (result (ref null $type39))
      (ref.is_null
       (local.get $2)
      )
      (then
       (ref.null none)
      )
      (else
       (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
        (call $function98
         (struct.get $type54 0
          (local.tee $12
           (block (result (ref $type54)) (global.set $observed52 (i64.add (global.get $observed52) (i64.const 1))) (struct.new $type54
            (block (result (ref $environment98)) (global.set $observed53 (i64.add (global.get $observed53) (i64.const 1))) (struct.new $environment98
             (local.get $15)
            ))
           ))
          )
         )
         (struct.get $type33 0
          (local.get $2)
         )
        )
        (block (result (ref null $type39))
         (local.set $2
          (struct.get $type33 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready304)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global304)
          )
         )
         (if (result (ref null $type39))
          (ref.is_null
           (local.get $2)
          )
          (then
           (ref.null none)
          )
          (else
           (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
            (call $function98
             (struct.get $type54 0
              (local.get $12)
             )
             (struct.get $type33 0
              (local.get $2)
             )
            )
            (block (result (ref null $type39))
             (local.set $2
              (struct.get $type33 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready304)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global304)
              )
             )
             (if (result (ref null $type39))
              (ref.is_null
               (local.get $2)
              )
              (then
               (ref.null none)
              )
              (else
               (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
                (call $function98
                 (struct.get $type54 0
                  (local.get $12)
                 )
                 (struct.get $type33 0
                  (local.get $2)
                 )
                )
                (block (result (ref null $type39))
                 (local.set $2
                  (struct.get $type33 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready304)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global304)
                  )
                 )
                 (if (result (ref null $type39))
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
                    (call $function98
                     (struct.get $type54 0
                      (local.get $12)
                     )
                     (struct.get $type33 0
                      (local.get $2)
                     )
                    )
                    (block (result (ref null $type39))
                     (local.set $2
                      (struct.get $type33 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready304)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global304)
                      )
                     )
                     (if (result (ref null $type39))
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
                        (call $function98
                         (struct.get $type54 0
                          (local.get $12)
                         )
                         (struct.get $type33 0
                          (local.get $2)
                         )
                        )
                        (block (result (ref null $type39))
                         (local.set $2
                          (struct.get $type33 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready304)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global304)
                          )
                         )
                         (if (result (ref null $type39))
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
                            (call $function98
                             (struct.get $type54 0
                              (local.get $12)
                             )
                             (struct.get $type33 0
                              (local.get $2)
                             )
                            )
                            (block (result (ref null $type39))
                             (local.set $2
                              (struct.get $type33 1
                               (local.get $2)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready304)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global304)
                              )
                             )
                             (if (result (ref null $type39))
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
                                (call $function98
                                 (struct.get $type54 0
                                  (local.get $12)
                                 )
                                 (struct.get $type33 0
                                  (local.get $2)
                                 )
                                )
                                (block (result (ref null $type39))
                                 (local.set $2
                                  (struct.get $type33 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready304)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global304)
                                  )
                                 )
                                 (if (result (ref null $type39))
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
                                    (call $function98
                                     (struct.get $type54 0
                                      (local.get $12)
                                     )
                                     (struct.get $type33 0
                                      (local.get $2)
                                     )
                                    )
                                    (block (result (ref null $type39))
                                     (local.set $2
                                      (struct.get $type33 1
                                       (local.get $2)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready304)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global304)
                                      )
                                     )
                                     (if (result (ref null $type39))
                                      (ref.is_null
                                       (local.get $2)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (block (result (ref $type39)) (global.set $observed51 (i64.add (global.get $observed51) (i64.const 1))) (struct.new $type39
                                        (call $function98
                                         (struct.get $type54 0
                                          (local.get $12)
                                         )
                                         (struct.get $type33 0
                                          (local.get $2)
                                         )
                                        )
                                        (block (result (ref null $type39))
                                         (local.set $2
                                          (struct.get $type33 1
                                           (local.get $2)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready304)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global304)
                                          )
                                         )
                                         (call $function100
                                          (local.get $12)
                                          (local.get $2)
                                         )
                                        )
                                       ))
                                      )
                                     )
                                    )
                                   ))
                                  )
                                 )
                                )
                               ))
                              )
                             )
                            )
                           ))
                          )
                         )
                        )
                       ))
                      )
                     )
                    )
                   ))
                  )
                 )
                )
               ))
              )
             )
            )
           ))
          )
         )
        )
       ))
      )
     )
    ))
   )
   (else
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (global.get $global116)
    )
   )
  )
 )
 (func $function54 (type $call74) (param $0 i64) (param $1 i64) (result (ref $type29))
  (global.set $observed7 (i64.add (global.get $observed7) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (i64.eqz
     (i64.and
      (local.get $0)
      (i64.const 1)
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready125)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global125)
      )
     )
     (i64.eqz
      (i64.and
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (block (result (ref $type31)) (global.set $observed54 (i64.add (global.get $observed54) (i64.const 1))) (struct.new $type31
     (local.get $0)
     (local.get $1)
    ))
   )
   (else
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (global.get $global109)
    )
   )
  )
 )
 (func $function56 (type $call65) (param $0 (ref struct)) (param $1 i64) (result (ref null $type28))
  (local $2 i64)
  (local $3 (ref $type63))
  (global.set $observed8 (i64.add (global.get $observed8) (i64.const 1)))
  (local.set $2
   (struct.get $environment56 0
    (ref.cast (ref $environment56)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (if (result (ref null $type28))
   (i64.gt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.set $1
     (struct.get $environment57 0
      (struct.get $type63 0
       (local.tee $3
        (block (result (ref $type63)) (global.set $observed55 (i64.add (global.get $observed55) (i64.const 1))) (struct.new $type63
         (block (result (ref $environment57)) (global.set $observed56 (i64.add (global.get $observed56) (i64.const 1))) (struct.new $environment57
          (local.get $1)
         ))
        ))
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
     (if (result (ref $type29))
      (if (result i32)
       (i64.eqz
        (i64.and
         (local.get $1)
         (i64.const 1)
        )
       )
       (then
        (if
         (i32.eqz
          (global.get $ready125)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global125)
         )
        )
        (i32.const 1)
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (block (result (ref $type31)) (global.set $observed58 (i64.add (global.get $observed58) (i64.const 1))) (struct.new $type31
        (local.get $1)
        (i64.const 0)
       ))
      )
      (else
       (if
        (i32.eqz
         (global.get $ready109)
        )
        (then
         (unreachable)
        )
       )
       (ref.as_non_null
        (global.get $global109)
       )
      )
     )
     (if (result (ref null $type28))
      (i64.gt_s
       (local.get $2)
       (i64.const 1)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready125)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global125)
        )
       )
       (if
        (i64.eqz
         (i64.and
          (struct.get $environment57 0
           (struct.get $type63 0
            (local.get $3)
           )
          )
          (i64.const 1)
         )
        )
        (then
         (if
          (i32.eqz
           (global.get $ready125)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global125)
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready109)
        )
        (then
         (unreachable)
        )
       )
       (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
        (ref.as_non_null
         (global.get $global109)
        )
        (if (result (ref null $type28))
         (i64.gt_s
          (local.get $2)
          (i64.const 2)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready125)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global125)
           )
          )
          (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
           (if (result (ref $type29))
            (if (result i32)
             (i64.eqz
              (i64.and
               (local.tee $1
                (struct.get $environment57 0
                 (struct.get $type63 0
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (then
              (if
               (i32.eqz
                (global.get $ready125)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global125)
               )
              )
              (i32.const 1)
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (block (result (ref $type31)) (global.set $observed58 (i64.add (global.get $observed58) (i64.const 1))) (struct.new $type31
              (local.get $1)
              (i64.const 2)
             ))
            )
            (else
             (if
              (i32.eqz
               (global.get $ready109)
              )
              (then
               (unreachable)
              )
             )
             (ref.as_non_null
              (global.get $global109)
             )
            )
           )
           (if (result (ref null $type28))
            (i64.gt_s
             (local.get $2)
             (i64.const 3)
            )
            (then
             (if
              (i32.eqz
               (global.get $ready125)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global125)
              )
             )
             (if
              (i64.eqz
               (i64.and
                (struct.get $environment57 0
                 (struct.get $type63 0
                  (local.get $3)
                 )
                )
                (i64.const 1)
               )
              )
              (then
               (if
                (i32.eqz
                 (global.get $ready125)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global125)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready109)
              )
              (then
               (unreachable)
              )
             )
             (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
              (ref.as_non_null
               (global.get $global109)
              )
              (if (result (ref null $type28))
               (i64.gt_s
                (local.get $2)
                (i64.const 4)
               )
               (then
                (if
                 (i32.eqz
                  (global.get $ready125)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global125)
                 )
                )
                (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
                 (if (result (ref $type29))
                  (if (result i32)
                   (i64.eqz
                    (i64.and
                     (local.tee $1
                      (struct.get $environment57 0
                       (struct.get $type63 0
                        (local.get $3)
                       )
                      )
                     )
                     (i64.const 1)
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (global.get $ready125)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global125)
                     )
                    )
                    (i32.const 1)
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                  (then
                   (block (result (ref $type31)) (global.set $observed58 (i64.add (global.get $observed58) (i64.const 1))) (struct.new $type31
                    (local.get $1)
                    (i64.const 4)
                   ))
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready109)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (ref.as_non_null
                    (global.get $global109)
                   )
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.gt_s
                   (local.get $2)
                   (i64.const 5)
                  )
                  (then
                   (if
                    (i32.eqz
                     (global.get $ready125)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global125)
                    )
                   )
                   (if
                    (i64.eqz
                     (i64.and
                      (struct.get $environment57 0
                       (struct.get $type63 0
                        (local.get $3)
                       )
                      )
                      (i64.const 1)
                     )
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready125)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global125)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready109)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
                    (ref.as_non_null
                     (global.get $global109)
                    )
                    (if (result (ref null $type28))
                     (i64.gt_s
                      (local.get $2)
                      (i64.const 6)
                     )
                     (then
                      (if
                       (i32.eqz
                        (global.get $ready125)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global125)
                       )
                      )
                      (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
                       (if (result (ref $type29))
                        (if (result i32)
                         (i64.eqz
                          (i64.and
                           (local.tee $1
                            (struct.get $environment57 0
                             (struct.get $type63 0
                              (local.get $3)
                             )
                            )
                           )
                           (i64.const 1)
                          )
                         )
                         (then
                          (if
                           (i32.eqz
                            (global.get $ready125)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global125)
                           )
                          )
                          (i32.const 1)
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                        (then
                         (block (result (ref $type31)) (global.set $observed58 (i64.add (global.get $observed58) (i64.const 1))) (struct.new $type31
                          (local.get $1)
                          (i64.const 6)
                         ))
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready109)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (ref.as_non_null
                          (global.get $global109)
                         )
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.gt_s
                         (local.get $2)
                         (i64.const 7)
                        )
                        (then
                         (if
                          (i64.eqz
                           (i64.and
                            (struct.get $environment57 0
                             (struct.get $type63 0
                              (local.get $3)
                             )
                            )
                            (block (result i64)
                             (if
                              (i32.eqz
                               (global.get $ready125)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global125)
                              )
                             )
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (if
                            (i32.eqz
                             (global.get $ready125)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global125)
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready109)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
                          (ref.as_non_null
                           (global.get $global109)
                          )
                          (if (result (ref null $type28))
                           (i64.gt_s
                            (local.get $2)
                            (i64.const 8)
                           )
                           (then
                            (block (result (ref $type28)) (global.set $observed57 (i64.add (global.get $observed57) (i64.const 1))) (struct.new $type28
                             (call $function54
                              (struct.get $environment57 0
                               (struct.get $type63 0
                                (local.get $3)
                               )
                              )
                              (i64.const 8)
                             )
                             (call $function59
                              (local.get $2)
                              (local.get $3)
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 9)
                             )
                            ))
                           )
                           (else
                            (ref.null none)
                           )
                          )
                         ))
                        )
                        (else
                         (ref.null none)
                        )
                       )
                      ))
                     )
                     (else
                      (ref.null none)
                     )
                    )
                   ))
                  )
                  (else
                   (ref.null none)
                  )
                 )
                ))
               )
               (else
                (ref.null none)
               )
              )
             ))
            )
            (else
             (ref.null none)
            )
           )
          ))
         )
         (else
          (ref.null none)
         )
        )
       ))
      )
      (else
       (ref.null none)
      )
     )
    ))
   )
   (else
    (ref.null none)
   )
  )
 )
 (func $function59 (type $37) (param $0 i64) (param $1 (ref $type63)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref null $type28))
  (local $5 (ref $type29))
  (global.set $observed9 (i64.add (global.get $observed9) (i64.const 1)))
  (if (result (ref null $type28))
   (i64.gt_s
    (local.get $0)
    (local.get $4)
   )
   (then
    (block (result (ref $type28)) (global.set $observed59 (i64.add (global.get $observed59) (i64.const 1))) (struct.new $type28
     (call $function54
      (struct.get $environment57 0
       (struct.get $type63 0
        (local.get $1)
       )
      )
      (local.get $4)
     )
     (block (result (ref null $type28))
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (call $function59
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
    ))
   )
   (else
    (ref.null none)
   )
  )
 )
 (func $function61 (type $36) (param $0 i64) (param $1 (ref $type65)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref null $type33))
  (local $5 (ref null $type28))
  (global.set $observed10 (i64.add (global.get $observed10) (i64.const 1)))
  (if (result (ref null $type33))
   (i64.gt_s
    (local.get $0)
    (local.get $4)
   )
   (then
    (block (result (ref $type33)) (global.set $observed60 (i64.add (global.get $observed60) (i64.const 1))) (struct.new $type33
     (call_ref $call65
      (struct.get $type65 1
       (local.get $1)
      )
      (local.get $4)
      (struct.get $type65 0
       (local.get $1)
      )
     )
     (block (result (ref null $type33))
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (call $function61
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
    ))
   )
   (else
    (ref.null none)
   )
  )
 )
 (func $function62 (type $call65) (param $0 (ref struct)) (param $1 i64) (result (ref null $type28))
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref $type29))
  (local $5 (ref $call65))
  (local $6 (ref $type65))
  (local $7 (ref null $type33))
  (local $8 (ref $type48))
  (local $9 i64)
  (global.set $observed11 (i64.add (global.get $observed11) (i64.const 1)))
  (local.set $9
   (struct.get $environment62 0
    (ref.cast (ref $environment62)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready169)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (local.set $7
   (if (result (ref null $type33))
    (i64.gt_s
     (local.get $9)
     (i64.const 0)
    )
    (then
     (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
      (call_ref $call65
       (struct.get $type65 1
        (local.tee $6
         (block (result (ref $type65)) (global.set $observed62 (i64.add (global.get $observed62) (i64.const 1))) (struct.new $type65
          (ref.func $function63)
          (block (result (ref $environment63)) (global.set $observed63 (i64.add (global.get $observed63) (i64.const 1))) (struct.new $environment63
           (local.get $1)
          ))
         ))
        )
       )
       (i64.const 0)
       (local.tee $5
        (struct.get $type65 0
         (local.get $6)
        )
       )
      )
      (if (result (ref null $type33))
       (i64.gt_s
        (local.get $9)
        (i64.const 1)
       )
       (then
        (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
         (call_ref $call65
          (local.tee $0
           (struct.get $type65 1
            (local.get $6)
           )
          )
          (i64.const 1)
          (local.get $5)
         )
         (if (result (ref null $type33))
          (i64.gt_s
           (local.get $9)
           (i64.const 2)
          )
          (then
           (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
            (call_ref $call65
             (local.get $0)
             (i64.const 2)
             (local.get $5)
            )
            (if (result (ref null $type33))
             (i64.gt_s
              (local.get $9)
              (i64.const 3)
             )
             (then
              (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
               (call_ref $call65
                (local.get $0)
                (i64.const 3)
                (local.get $5)
               )
               (if (result (ref null $type33))
                (i64.gt_s
                 (local.get $9)
                 (i64.const 4)
                )
                (then
                 (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
                  (call_ref $call65
                   (local.get $0)
                   (i64.const 4)
                   (local.get $5)
                  )
                  (if (result (ref null $type33))
                   (i64.gt_s
                    (local.get $9)
                    (i64.const 5)
                   )
                   (then
                    (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
                     (call_ref $call65
                      (local.get $0)
                      (i64.const 5)
                      (local.get $5)
                     )
                     (if (result (ref null $type33))
                      (i64.gt_s
                       (local.get $9)
                       (i64.const 6)
                      )
                      (then
                       (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
                        (call_ref $call65
                         (local.get $0)
                         (i64.const 6)
                         (local.get $5)
                        )
                        (if (result (ref null $type33))
                         (i64.gt_s
                          (local.get $9)
                          (i64.const 7)
                         )
                         (then
                          (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
                           (call_ref $call65
                            (local.get $0)
                            (i64.const 7)
                            (local.get $5)
                           )
                           (if (result (ref null $type33))
                            (i64.gt_s
                             (local.get $9)
                             (i64.const 8)
                            )
                            (then
                             (block (result (ref $type33)) (global.set $observed61 (i64.add (global.get $observed61) (i64.const 1))) (struct.new $type33
                              (call_ref $call65
                               (local.get $0)
                               (i64.const 8)
                               (local.get $5)
                              )
                              (call $function61
                               (local.get $9)
                               (local.get $6)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.const 9)
                              )
                             ))
                            )
                            (else
                             (ref.null none)
                            )
                           )
                          ))
                         )
                         (else
                          (ref.null none)
                         )
                        )
                       ))
                      )
                      (else
                       (ref.null none)
                      )
                     )
                    ))
                   )
                   (else
                    (ref.null none)
                   )
                  )
                 ))
                )
                (else
                 (ref.null none)
                )
               )
              ))
             )
             (else
              (ref.null none)
             )
            )
           ))
          )
          (else
           (ref.null none)
          )
         )
        ))
       )
       (else
        (ref.null none)
       )
      )
     ))
    )
    (else
     (ref.null none)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready180)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global180)
   )
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global185)
   )
  )
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $7)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $2
     (struct.get $type33 0
      (local.get $7)
     )
    )
    (local.set $3
     (call $function68
      (local.get $8)
      (ref.null none)
      (i32.const 0)
      (i32.const 1)
      (struct.get $type33 1
       (local.get $7)
      )
     )
    )
    (if (result (ref null $type28))
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
       (struct.get $type28 0
        (local.get $2)
       )
       (block (result (ref null $type28))
        (local.set $2
         (struct.get $type28 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready182)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global182)
         )
        )
        (if (result (ref null $type28))
         (ref.is_null
          (local.get $2)
         )
         (then
          (local.get $3)
         )
         (else
          (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
           (struct.get $type28 0
            (local.get $2)
           )
           (block (result (ref null $type28))
            (local.set $2
             (struct.get $type28 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready182)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global182)
             )
            )
            (if (result (ref null $type28))
             (ref.is_null
              (local.get $2)
             )
             (then
              (local.get $3)
             )
             (else
              (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
               (struct.get $type28 0
                (local.get $2)
               )
               (block (result (ref null $type28))
                (local.set $2
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready182)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global182)
                 )
                )
                (if (result (ref null $type28))
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
                   (struct.get $type28 0
                    (local.get $2)
                   )
                   (block (result (ref null $type28))
                    (local.set $2
                     (struct.get $type28 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready182)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global182)
                     )
                    )
                    (if (result (ref null $type28))
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (local.get $3)
                     )
                     (else
                      (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
                       (struct.get $type28 0
                        (local.get $2)
                       )
                       (block (result (ref null $type28))
                        (local.set $2
                         (struct.get $type28 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready182)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global182)
                         )
                        )
                        (if (result (ref null $type28))
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (local.get $3)
                         )
                         (else
                          (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
                           (struct.get $type28 0
                            (local.get $2)
                           )
                           (block (result (ref null $type28))
                            (local.set $2
                             (struct.get $type28 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready182)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global182)
                             )
                            )
                            (if (result (ref null $type28))
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (local.get $3)
                             )
                             (else
                              (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
                               (struct.get $type28 0
                                (local.get $2)
                               )
                               (block (result (ref null $type28))
                                (local.set $2
                                 (struct.get $type28 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready182)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global182)
                                 )
                                )
                                (if (result (ref null $type28))
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                 (then
                                  (local.get $3)
                                 )
                                 (else
                                  (block (result (ref $type28)) (global.set $observed64 (i64.add (global.get $observed64) (i64.const 1))) (struct.new $type28
                                   (struct.get $type28 0
                                    (local.get $2)
                                   )
                                   (call $function66
                                    (struct.get $type28 1
                                     (local.get $2)
                                    )
                                    (block (result (ref null $type28))
                                     (if
                                      (i32.eqz
                                       (global.get $ready182)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global182)
                                      )
                                     )
                                     (local.get $3)
                                    )
                                   )
                                  ))
                                 )
                                )
                               )
                              ))
                             )
                            )
                           )
                          ))
                         )
                        )
                       )
                      ))
                     )
                    )
                   )
                  ))
                 )
                )
               )
              ))
             )
            )
           )
          ))
         )
        )
       )
      ))
     )
    )
   )
  )
 )
 (func $function63 (type $call65) (param $0 (ref struct)) (param $1 i64) (result (ref null $type28))
  (local $2 i64)
  (local $3 i32)
  (global.set $observed12 (i64.add (global.get $observed12) (i64.const 1)))
  (local.set $2
   (struct.get $environment63 0
    (ref.cast (ref $environment63)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if
   (i32.eqz
    (global.get $ready122)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if (result (ref null $type28))
   (select
    (local.tee $3
     (i64.eqz
      (i64.and
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (i32.eqz
     (local.get $3)
    )
    (i64.eqz
     (i64.and
      (local.get $2)
      (i64.const 1)
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (block (result (ref $type28)) (global.set $observed65 (i64.add (global.get $observed65) (i64.const 1))) (struct.new $type28
     (block (result (ref $type31)) (global.set $observed66 (i64.add (global.get $observed66) (i64.const 1))) (struct.new $type31
      (struct.get $environment63 0
       (ref.cast (ref $environment63)
        (local.get $0)
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready178)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global178)
        )
       )
       (local.get $1)
      )
     ))
     (ref.null none)
    ))
   )
  )
 )
 (func $function66 (type $call48) (param $0 (ref null $type28)) (param $1 (ref null $type28)) (result (ref null $type28))
  (local $2 (ref $type29))
  (global.set $observed13 (i64.add (global.get $observed13) (i64.const 1)))
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (block (result (ref $type28)) (global.set $observed67 (i64.add (global.get $observed67) (i64.const 1))) (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (call $function66
      (struct.get $type28 1
       (local.get $0)
      )
      (block (result (ref null $type28))
       (if
        (i32.eqz
         (global.get $ready182)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global182)
        )
       )
       (local.get $1)
      )
     )
    ))
   )
  )
 )
 (func $function68 (type $33) (param $0 (ref $type48)) (param $1 (ref null $type28)) (param $2 i32) (param $3 i32) (param $4 (ref null $type33)) (result (ref null $type28))
  (local $5 (ref null $type28))
  (local $6 (ref $type29))
  (global.set $observed14 (i64.add (global.get $observed14) (i64.const 1)))
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $4)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $5
     (struct.get $type33 0
      (local.get $4)
     )
    )
    (local.set $4
     (struct.get $type33 1
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call $function68
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $3)
      (local.get $4)
     )
    )
    (if (result (ref null $type28))
     (ref.is_null
      (local.get $5)
     )
     (then
      (local.get $1)
     )
     (else
      (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
       (struct.get $type28 0
        (local.get $5)
       )
       (block (result (ref null $type28))
        (local.set $5
         (struct.get $type28 1
          (local.get $5)
         )
        )
        (if
         (i32.eqz
          (global.get $ready182)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global182)
         )
        )
        (if (result (ref null $type28))
         (ref.is_null
          (local.get $5)
         )
         (then
          (local.get $1)
         )
         (else
          (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
           (struct.get $type28 0
            (local.get $5)
           )
           (block (result (ref null $type28))
            (local.set $5
             (struct.get $type28 1
              (local.get $5)
             )
            )
            (if
             (i32.eqz
              (global.get $ready182)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global182)
             )
            )
            (if (result (ref null $type28))
             (ref.is_null
              (local.get $5)
             )
             (then
              (local.get $1)
             )
             (else
              (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
               (struct.get $type28 0
                (local.get $5)
               )
               (block (result (ref null $type28))
                (local.set $5
                 (struct.get $type28 1
                  (local.get $5)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready182)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global182)
                 )
                )
                (if (result (ref null $type28))
                 (ref.is_null
                  (local.get $5)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
                   (struct.get $type28 0
                    (local.get $5)
                   )
                   (block (result (ref null $type28))
                    (local.set $5
                     (struct.get $type28 1
                      (local.get $5)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready182)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global182)
                     )
                    )
                    (if (result (ref null $type28))
                     (ref.is_null
                      (local.get $5)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
                       (struct.get $type28 0
                        (local.get $5)
                       )
                       (block (result (ref null $type28))
                        (local.set $5
                         (struct.get $type28 1
                          (local.get $5)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready182)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global182)
                         )
                        )
                        (if (result (ref null $type28))
                         (ref.is_null
                          (local.get $5)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
                           (struct.get $type28 0
                            (local.get $5)
                           )
                           (block (result (ref null $type28))
                            (local.set $5
                             (struct.get $type28 1
                              (local.get $5)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready182)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global182)
                             )
                            )
                            (if (result (ref null $type28))
                             (ref.is_null
                              (local.get $5)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
                               (struct.get $type28 0
                                (local.get $5)
                               )
                               (block (result (ref null $type28))
                                (local.set $5
                                 (struct.get $type28 1
                                  (local.get $5)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready182)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global182)
                                 )
                                )
                                (if (result (ref null $type28))
                                 (ref.is_null
                                  (local.get $5)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                   (block (result (ref null $type28))
                                    (local.set $5
                                     (struct.get $type28 1
                                      (local.get $5)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready182)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global182)
                                     )
                                    )
                                    (if (result (ref null $type28))
                                     (ref.is_null
                                      (local.get $5)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (block (result (ref $type28)) (global.set $observed68 (i64.add (global.get $observed68) (i64.const 1))) (struct.new $type28
                                       (struct.get $type28 0
                                        (local.get $5)
                                       )
                                       (call $function66
                                        (struct.get $type28 1
                                         (local.get $5)
                                        )
                                        (block (result (ref null $type28))
                                         (if
                                          (i32.eqz
                                           (global.get $ready182)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global182)
                                          )
                                         )
                                         (local.get $1)
                                        )
                                       )
                                      ))
                                     )
                                    )
                                   )
                                  ))
                                 )
                                )
                               )
                              ))
                             )
                            )
                           )
                          ))
                         )
                        )
                       )
                      ))
                     )
                    )
                   )
                  ))
                 )
                )
               )
              ))
             )
            )
           )
          ))
         )
        )
       )
      ))
     )
    )
   )
  )
 )
 (func $function70 (type $32) (param $0 (ref null $type28)) (param $1 i64) (result (ref null $type28))
  (local $2 (ref null $type28))
  (local $3 (ref $type29))
  (local $4 (ref $type29))
  (local $5 i64)
  (local $6 i64)
  (global.set $observed15 (i64.add (global.get $observed15) (i64.const 1)))
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready149)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global149)
     )
    )
    (if
     (i32.eqz
      (global.get $ready198)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global198)
     )
    )
    (local.set $1
     (i64.rem_s
      (local.tee $6
       (block (result i64) (global.set $observed148 (i64.add (global.get $observed148) (i64.const 1))) (i64.rem_s
        (i64.add
         (i64.mul
          (local.get $1)
          (i64.const 3581)
         )
         (i64.const 12751)
        )
        (i64.const 131072)
       ))
      )
      (if (result i64)
       (ref.is_null
        (local.get $0)
       )
       (then
        (i64.const 0)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $2
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 1)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $2
             (struct.get $type28 1
              (local.get $2)
             )
            )
           )
           (then
            (i64.const 2)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $2
               (struct.get $type28 1
                (local.get $2)
               )
              )
             )
             (then
              (i64.const 3)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $2
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
               )
               (then
                (i64.const 4)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $2
                   (struct.get $type28 1
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (i64.const 5)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $2
                     (struct.get $type28 1
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (i64.const 6)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $2
                       (struct.get $type28 1
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (i64.const 7)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $2
                         (struct.get $type28 1
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (i64.const 8)
                       )
                       (else
                        (call $function72
                         (i32.const 0)
                         (i32.const 1)
                         (struct.get $type28 1
                          (local.get $2)
                         )
                         (i64.const 9)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready203)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
     (if (result (ref $type29))
      (i64.eqz
       (local.get $1)
      )
      (then
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (else
       (local.set $2
        (struct.get $type28 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready203)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global203)
        )
       )
       (if (result (ref $type29))
        (i64.eqz
         (local.tee $5
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type28 0
          (local.get $2)
         )
        )
        (else
         (local.set $2
          (struct.get $type28 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready203)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global203)
          )
         )
         (if (result (ref $type29))
          (i64.eqz
           (local.tee $5
            (i64.sub
             (local.get $5)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type28 0
            (local.get $2)
           )
          )
          (else
           (local.set $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready203)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global203)
            )
           )
           (if (result (ref $type29))
            (i64.eqz
             (local.tee $5
              (i64.sub
               (local.get $5)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type28 0
              (local.get $2)
             )
            )
            (else
             (local.set $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready203)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global203)
              )
             )
             (if (result (ref $type29))
              (i64.eqz
               (local.tee $5
                (i64.sub
                 (local.get $5)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type28 0
                (local.get $2)
               )
              )
              (else
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready203)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global203)
                )
               )
               (if (result (ref $type29))
                (i64.eqz
                 (local.tee $5
                  (i64.sub
                   (local.get $5)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
                (else
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready203)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global203)
                  )
                 )
                 (if (result (ref $type29))
                  (i64.eqz
                   (local.tee $5
                    (i64.sub
                     (local.get $5)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                  (else
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready203)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global203)
                    )
                   )
                   (if (result (ref $type29))
                    (i64.eqz
                     (local.tee $5
                      (i64.sub
                       (local.get $5)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                    (else
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready203)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global203)
                      )
                     )
                     (if (result (ref $type29))
                      (i64.eqz
                       (local.tee $5
                        (i64.sub
                         (local.get $5)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                      (else
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready203)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global203)
                        )
                       )
                       (if (result (ref $type29))
                        (i64.eqz
                         (local.tee $5
                          (i64.sub
                           (local.get $5)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type28 0
                          (local.get $2)
                         )
                        )
                        (else
                         (call $function73
                          (struct.get $type28 1
                           (local.get $2)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready203)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global203)
                            )
                           )
                           (i64.sub
                            (local.get $5)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (block (result (ref null $type28))
      (if
       (i32.eqz
        (global.get $ready206)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global206)
       )
      )
      (call $function70
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $1)
        )
        (then
         (struct.get $type28 1
          (local.get $0)
         )
        )
        (else
         (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
          (struct.get $type28 0
           (local.get $0)
          )
          (block (result (ref null $type28))
           (local.set $0
            (struct.get $type28 1
             (local.get $0)
            )
           )
           (if
            (i32.eqz
             (global.get $ready206)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global206)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $1
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type28 1
              (local.get $0)
             )
            )
            (else
             (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
              (struct.get $type28 0
               (local.get $0)
              )
              (block (result (ref null $type28))
               (local.set $0
                (struct.get $type28 1
                 (local.get $0)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready206)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global206)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $1
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type28 1
                  (local.get $0)
                 )
                )
                (else
                 (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                  (struct.get $type28 0
                   (local.get $0)
                  )
                  (block (result (ref null $type28))
                   (local.set $0
                    (struct.get $type28 1
                     (local.get $0)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready206)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global206)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $1
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type28 1
                      (local.get $0)
                     )
                    )
                    (else
                     (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                      (struct.get $type28 0
                       (local.get $0)
                      )
                      (block (result (ref null $type28))
                       (local.set $0
                        (struct.get $type28 1
                         (local.get $0)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready206)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global206)
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.eqz
                         (local.tee $1
                          (i64.sub
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type28 1
                          (local.get $0)
                         )
                        )
                        (else
                         (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                          (struct.get $type28 0
                           (local.get $0)
                          )
                          (block (result (ref null $type28))
                           (local.set $0
                            (struct.get $type28 1
                             (local.get $0)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready206)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global206)
                            )
                           )
                           (if (result (ref null $type28))
                            (i64.eqz
                             (local.tee $1
                              (i64.sub
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (struct.get $type28 1
                              (local.get $0)
                             )
                            )
                            (else
                             (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                              (struct.get $type28 0
                               (local.get $0)
                              )
                              (block (result (ref null $type28))
                               (local.set $0
                                (struct.get $type28 1
                                 (local.get $0)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready206)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global206)
                                )
                               )
                               (if (result (ref null $type28))
                                (i64.eqz
                                 (local.tee $1
                                  (i64.sub
                                   (local.get $1)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (then
                                 (struct.get $type28 1
                                  (local.get $0)
                                 )
                                )
                                (else
                                 (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                                  (struct.get $type28 0
                                   (local.get $0)
                                  )
                                  (block (result (ref null $type28))
                                   (local.set $0
                                    (struct.get $type28 1
                                     (local.get $0)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready206)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global206)
                                    )
                                   )
                                   (if (result (ref null $type28))
                                    (i64.eqz
                                     (local.tee $1
                                      (i64.sub
                                       (local.get $1)
                                       (i64.const 1)
                                      )
                                     )
                                    )
                                    (then
                                     (struct.get $type28 1
                                      (local.get $0)
                                     )
                                    )
                                    (else
                                     (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                                      (struct.get $type28 0
                                       (local.get $0)
                                      )
                                      (block (result (ref null $type28))
                                       (local.set $0
                                        (struct.get $type28 1
                                         (local.get $0)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready206)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global206)
                                        )
                                       )
                                       (if (result (ref null $type28))
                                        (i64.eqz
                                         (local.tee $1
                                          (i64.sub
                                           (local.get $1)
                                           (i64.const 1)
                                          )
                                         )
                                        )
                                        (then
                                         (struct.get $type28 1
                                          (local.get $0)
                                         )
                                        )
                                        (else
                                         (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                                          (struct.get $type28 0
                                           (local.get $0)
                                          )
                                          (block (result (ref null $type28))
                                           (local.set $0
                                            (struct.get $type28 1
                                             (local.get $0)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready206)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global206)
                                            )
                                           )
                                           (if (result (ref null $type28))
                                            (i64.eqz
                                             (local.tee $1
                                              (i64.sub
                                               (local.get $1)
                                               (i64.const 1)
                                              )
                                             )
                                            )
                                            (then
                                             (struct.get $type28 1
                                              (local.get $0)
                                             )
                                            )
                                            (else
                                             (block (result (ref $type28)) (global.set $observed69 (i64.add (global.get $observed69) (i64.const 1))) (struct.new $type28
                                              (struct.get $type28 0
                                               (local.get $0)
                                              )
                                              (call $function74
                                               (struct.get $type28 1
                                                (local.get $0)
                                               )
                                               (block (result i64)
                                                (if
                                                 (i32.eqz
                                                  (global.get $ready206)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global206)
                                                 )
                                                )
                                                (i64.sub
                                                 (local.get $1)
                                                 (i64.const 1)
                                                )
                                               )
                                              )
                                             ))
                                            )
                                           )
                                          )
                                         ))
                                        )
                                       )
                                      )
                                     ))
                                    )
                                   )
                                  )
                                 ))
                                )
                               )
                              )
                             ))
                            )
                           )
                          )
                         ))
                        )
                       )
                      )
                     ))
                    )
                   )
                  )
                 ))
                )
               )
              )
             ))
            )
           )
          )
         ))
        )
       )
       (block (result i64)
        (if
         (i32.eqz
          (global.get $ready193)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global193)
         )
        )
        (local.get $6)
       )
      )
     )
    ))
   )
  )
 )
 (func $function71 (type $call27) (param $0 (ref null $type28)) (result i64)
  (global.set $observed16 (i64.add (global.get $observed16) (i64.const 1)))
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $0
       (struct.get $type28 1
        (local.get $0)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $0
         (struct.get $type28 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $0
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $0
             (struct.get $type28 1
              (local.get $0)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $0
               (struct.get $type28 1
                (local.get $0)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $0
                 (struct.get $type28 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type28 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type28 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (return_call $function72
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type28 1
                      (local.get $0)
                     )
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function72 (type $30) (param $0 i32) (param $1 i32) (param $2 (ref null $type28)) (param $3 i64) (result i64)
  (global.set $observed17 (i64.add (global.get $observed17) (i64.const 1)))
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type28 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function72
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function73 (type $call67) (param $0 (ref null $type28)) (param $1 i64) (result (ref $type29))
  (global.set $observed18 (i64.add (global.get $observed18) (i64.const 1)))
  (if (result (ref $type29))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type28 0
     (local.get $0)
    )
   )
   (else
    (return_call $function73
     (struct.get $type28 1
      (local.get $0)
     )
     (block (result i64)
      (if
       (i32.eqz
        (global.get $ready203)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
 )
 (func $function74 (type $call71) (param $0 (ref null $type28)) (param $1 i64) (result (ref null $type28))
  (local $2 (ref $type29))
  (global.set $observed19 (i64.add (global.get $observed19) (i64.const 1)))
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type28 1
     (local.get $0)
    )
   )
   (else
    (block (result (ref $type28)) (global.set $observed70 (i64.add (global.get $observed70) (i64.const 1))) (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (call $function74
      (struct.get $type28 1
       (local.get $0)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready206)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global206)
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    ))
   )
  )
 )
 (func $function75 (type $call85) (param $0 (ref null $type28)) (param $1 (ref null $type33)) (result (ref null $type33))
  (local $2 (ref null $type28))
  (local $3 (ref $type29))
  (local $scratch (ref null $type33))
  (global.set $observed20 (i64.add (global.get $observed20) (i64.const 1)))
  (if (result (ref null $type33))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function75
     (struct.get $type28 1
      (local.get $0)
     )
     (block (result (ref null $type33))
      (local.set $scratch
       (call $function76
        (struct.get $type28 0
         (local.get $0)
        )
        (block (result (ref null $type33))
         (if
          (i32.eqz
           (global.get $ready213)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global213)
          )
         )
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready209)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global209)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function76 (type $call84) (param $0 (ref $type29)) (param $1 (ref null $type33)) (result (ref null $type33))
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref null $type28))
  (local $5 (ref null $type33))
  (local $6 (ref $type29))
  (local $7 (ref $type61))
  (local $8 (ref $type51))
  (local $9 (ref $type31))
  (local $10 (ref $type28))
  (local $11 i64)
  (local $12 i64)
  (local $scratch (ref null $type28))
  (global.set $observed21 (i64.add (global.get $observed21) (i64.const 1)))
  (if
   (ref.test (ref $type30)
    (local.get $0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.cast (ref $type31)
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready219)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global219)
   )
  )
  (local.set $3
   (call $function77
    (local.get $0)
    (local.get $1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready247)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global247)
   )
  )
  (if (result (ref null $type33))
   (call $function51
    (block (result (ref null $type28))
     (local.set $scratch
      (if (result (ref null $type28))
       (ref.is_null
        (local.get $3)
       )
       (then
        (ref.null none)
       )
       (else
        (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
         (call $function84
          (struct.get $type51 0
           (local.tee $8
            (block (result (ref $type51)) (global.set $observed72 (i64.add (global.get $observed72) (i64.const 1))) (struct.new $type51
             (block (result (ref $environment84)) (global.set $observed73 (i64.add (global.get $observed73) (i64.const 1))) (struct.new $environment84
              (local.get $1)
             ))
            ))
           )
          )
          (struct.get $type28 0
           (local.get $3)
          )
         )
         (block (result (ref null $type28))
          (local.set $2
           (struct.get $type28 1
            (local.get $3)
           )
          )
          (if
           (i32.eqz
            (global.get $ready247)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global247)
           )
          )
          (if (result (ref null $type28))
           (ref.is_null
            (local.get $2)
           )
           (then
            (ref.null none)
           )
           (else
            (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
             (call $function84
              (struct.get $type51 0
               (local.get $8)
              )
              (struct.get $type28 0
               (local.get $2)
              )
             )
             (block (result (ref null $type28))
              (local.set $2
               (struct.get $type28 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready247)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global247)
               )
              )
              (if (result (ref null $type28))
               (ref.is_null
                (local.get $2)
               )
               (then
                (ref.null none)
               )
               (else
                (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                 (call $function84
                  (struct.get $type51 0
                   (local.get $8)
                  )
                  (struct.get $type28 0
                   (local.get $2)
                  )
                 )
                 (block (result (ref null $type28))
                  (local.set $2
                   (struct.get $type28 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready247)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global247)
                   )
                  )
                  (if (result (ref null $type28))
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                     (call $function84
                      (struct.get $type51 0
                       (local.get $8)
                      )
                      (struct.get $type28 0
                       (local.get $2)
                      )
                     )
                     (block (result (ref null $type28))
                      (local.set $2
                       (struct.get $type28 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready247)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global247)
                       )
                      )
                      (if (result (ref null $type28))
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                         (call $function84
                          (struct.get $type51 0
                           (local.get $8)
                          )
                          (struct.get $type28 0
                           (local.get $2)
                          )
                         )
                         (block (result (ref null $type28))
                          (local.set $2
                           (struct.get $type28 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready247)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global247)
                           )
                          )
                          (if (result (ref null $type28))
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                             (call $function84
                              (struct.get $type51 0
                               (local.get $8)
                              )
                              (struct.get $type28 0
                               (local.get $2)
                              )
                             )
                             (block (result (ref null $type28))
                              (local.set $2
                               (struct.get $type28 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready247)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global247)
                               )
                              )
                              (if (result (ref null $type28))
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                 (call $function84
                                  (struct.get $type51 0
                                   (local.get $8)
                                  )
                                  (struct.get $type28 0
                                   (local.get $2)
                                  )
                                 )
                                 (block (result (ref null $type28))
                                  (local.set $2
                                   (struct.get $type28 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready247)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global247)
                                   )
                                  )
                                  (if (result (ref null $type28))
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (ref.null none)
                                   )
                                   (else
                                    (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                     (call $function84
                                      (struct.get $type51 0
                                       (local.get $8)
                                      )
                                      (struct.get $type28 0
                                       (local.get $2)
                                      )
                                     )
                                     (block (result (ref null $type28))
                                      (local.set $2
                                       (struct.get $type28 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready247)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global247)
                                       )
                                      )
                                      (if (result (ref null $type28))
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                       (then
                                        (ref.null none)
                                       )
                                       (else
                                        (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                         (call $function84
                                          (struct.get $type51 0
                                           (local.get $8)
                                          )
                                          (struct.get $type28 0
                                           (local.get $2)
                                          )
                                         )
                                         (block (result (ref null $type28))
                                          (local.set $2
                                           (struct.get $type28 1
                                            (local.get $2)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready247)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global247)
                                           )
                                          )
                                          (if (result (ref null $type28))
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (ref.null none)
                                           )
                                           (else
                                            (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                             (call $function84
                                              (struct.get $type51 0
                                               (local.get $8)
                                              )
                                              (struct.get $type28 0
                                               (local.get $2)
                                              )
                                             )
                                             (block (result (ref null $type28))
                                              (local.set $2
                                               (struct.get $type28 1
                                                (local.get $2)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready247)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global247)
                                               )
                                              )
                                              (call $function85
                                               (local.get $8)
                                               (local.get $2)
                                              )
                                             )
                                            ))
                                           )
                                          )
                                         )
                                        ))
                                       )
                                      )
                                     )
                                    ))
                                   )
                                  )
                                 )
                                ))
                               )
                              )
                             )
                            ))
                           )
                          )
                         )
                        ))
                       )
                      )
                     )
                    ))
                   )
                  )
                 )
                ))
               )
              )
             )
            ))
           )
          )
         )
        ))
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready145)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global145)
      )
     )
     (local.get $scratch)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready282)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global282)
     )
    )
    (if
     (i32.eqz
      (ref.is_null
       (local.get $3)
      )
     )
     (then
      (local.set $1
       (call_ref $call61
        (struct.get $type61 1
         (local.tee $7
          (block (result (ref $type61)) (global.set $observed74 (i64.add (global.get $observed74) (i64.const 1))) (struct.new $type61
           (ref.func $function86)
           (block (result (ref $environment86)) (global.set $observed75 (i64.add (global.get $observed75) (i64.const 1))) (struct.new $environment86
            (local.get $0)
           ))
          ))
         )
        )
        (local.get $1)
        (struct.get $type28 0
         (local.get $3)
        )
        (struct.get $type61 0
         (local.get $7)
        )
       )
      )
      (local.set $1
       (if (result (ref null $type33))
        (ref.is_null
         (local.tee $2
          (struct.get $type28 1
           (local.get $3)
          )
         )
        )
        (then
         (local.get $1)
        )
        (else
         (local.set $1
          (call_ref $call61
           (struct.get $type61 1
            (local.get $7)
           )
           (local.get $1)
           (struct.get $type28 0
            (local.get $2)
           )
           (struct.get $type61 0
            (local.get $7)
           )
          )
         )
         (if (result (ref null $type33))
          (ref.is_null
           (local.tee $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
          )
          (then
           (local.get $1)
          )
          (else
           (local.set $1
            (call_ref $call61
             (struct.get $type61 1
              (local.get $7)
             )
             (local.get $1)
             (struct.get $type28 0
              (local.get $2)
             )
             (struct.get $type61 0
              (local.get $7)
             )
            )
           )
           (if (result (ref null $type33))
            (ref.is_null
             (local.tee $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $1)
            )
            (else
             (local.set $1
              (call_ref $call61
               (struct.get $type61 1
                (local.get $7)
               )
               (local.get $1)
               (struct.get $type28 0
                (local.get $2)
               )
               (struct.get $type61 0
                (local.get $7)
               )
              )
             )
             (if (result (ref null $type33))
              (ref.is_null
               (local.tee $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $1
                (call_ref $call61
                 (struct.get $type61 1
                  (local.get $7)
                 )
                 (local.get $1)
                 (struct.get $type28 0
                  (local.get $2)
                 )
                 (struct.get $type61 0
                  (local.get $7)
                 )
                )
               )
               (if (result (ref null $type33))
                (ref.is_null
                 (local.tee $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $1)
                )
                (else
                 (local.set $1
                  (call_ref $call61
                   (struct.get $type61 1
                    (local.get $7)
                   )
                   (local.get $1)
                   (struct.get $type28 0
                    (local.get $2)
                   )
                   (struct.get $type61 0
                    (local.get $7)
                   )
                  )
                 )
                 (if (result (ref null $type33))
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (call_ref $call61
                     (struct.get $type61 1
                      (local.get $7)
                     )
                     (local.get $1)
                     (struct.get $type28 0
                      (local.get $2)
                     )
                     (struct.get $type61 0
                      (local.get $7)
                     )
                    )
                   )
                   (if (result (ref null $type33))
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (call_ref $call61
                       (struct.get $type61 1
                        (local.get $7)
                       )
                       (local.get $1)
                       (struct.get $type28 0
                        (local.get $2)
                       )
                       (struct.get $type61 0
                        (local.get $7)
                       )
                      )
                     )
                     (if (result (ref null $type33))
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function94
                        (local.get $7)
                        (i32.const 0)
                        (i32.const 1)
                        (call_ref $call61
                         (struct.get $type61 1
                          (local.get $7)
                         )
                         (local.get $1)
                         (struct.get $type28 0
                          (local.get $2)
                         )
                         (struct.get $type61 0
                          (local.get $7)
                         )
                        )
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready289)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global289)
     )
    )
    (if
     (ref.test (ref $type30)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (struct.get $type31 0
      (local.tee $9
       (ref.cast (ref $type31)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready269)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global269)
     )
    )
    (if
     (i32.eqz
      (global.get $ready238)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global238)
     )
    )
    (local.set $2
     (if (result (ref null $type28))
      (i64.eqz
       (local.get $12)
      )
      (then
       (struct.get $type33 0
        (local.get $1)
       )
      )
      (else
       (local.set $5
        (struct.get $type33 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready238)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global238)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.tee $11
          (i64.sub
           (local.get $12)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type33 0
          (local.get $5)
         )
        )
        (else
         (local.set $5
          (struct.get $type33 1
           (local.get $5)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $11
            (i64.sub
             (local.get $11)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $5)
           )
          )
          (else
           (local.set $5
            (struct.get $type33 1
             (local.get $5)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $11
              (i64.sub
               (local.get $11)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $5)
             )
            )
            (else
             (local.set $5
              (struct.get $type33 1
               (local.get $5)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $11
                (i64.sub
                 (local.get $11)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $5)
               )
              )
              (else
               (local.set $5
                (struct.get $type33 1
                 (local.get $5)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $11
                  (i64.sub
                   (local.get $11)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $5)
                 )
                )
                (else
                 (local.set $5
                  (struct.get $type33 1
                   (local.get $5)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $11
                    (i64.sub
                     (local.get $11)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $5)
                   )
                  )
                  (else
                   (local.set $5
                    (struct.get $type33 1
                     (local.get $5)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $11
                      (i64.sub
                       (local.get $11)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $5)
                     )
                    )
                    (else
                     (call $function82
                      (struct.get $type33 1
                       (local.get $5)
                      )
                      (block (result i64)
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (i64.sub
                        (local.get $11)
                        (i64.const 1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready274)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global274)
     )
    )
    (local.set $10
     (if (result (ref $type28))
      (i64.eqz
       (local.tee $11
        (struct.get $type31 1
         (local.get $9)
        )
       )
      )
      (then
       (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
        (local.get $9)
        (struct.get $type28 1
         (local.get $2)
        )
       ))
      )
      (else
       (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
        (struct.get $type28 0
         (local.get $2)
        )
        (block (result (ref $type28))
         (local.set $2
          (struct.get $type28 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready274)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global274)
          )
         )
         (if (result (ref $type28))
          (i64.eqz
           (local.tee $11
            (i64.sub
             (local.get $11)
             (i64.const 1)
            )
           )
          )
          (then
           (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
            (local.get $9)
            (struct.get $type28 1
             (local.get $2)
            )
           ))
          )
          (else
           (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
            (struct.get $type28 0
             (local.get $2)
            )
            (block (result (ref $type28))
             (local.set $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready274)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global274)
              )
             )
             (if (result (ref $type28))
              (i64.eqz
               (local.tee $11
                (i64.sub
                 (local.get $11)
                 (i64.const 1)
                )
               )
              )
              (then
               (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                (local.get $9)
                (struct.get $type28 1
                 (local.get $2)
                )
               ))
              )
              (else
               (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                (struct.get $type28 0
                 (local.get $2)
                )
                (block (result (ref $type28))
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready274)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global274)
                  )
                 )
                 (if (result (ref $type28))
                  (i64.eqz
                   (local.tee $11
                    (i64.sub
                     (local.get $11)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                    (local.get $9)
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   ))
                  )
                  (else
                   (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                    (struct.get $type28 0
                     (local.get $2)
                    )
                    (block (result (ref $type28))
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready274)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global274)
                      )
                     )
                     (if (result (ref $type28))
                      (i64.eqz
                       (local.tee $11
                        (i64.sub
                         (local.get $11)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                        (local.get $9)
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       ))
                      )
                      (else
                       (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                        (struct.get $type28 0
                         (local.get $2)
                        )
                        (block (result (ref $type28))
                         (local.set $2
                          (struct.get $type28 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready274)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global274)
                          )
                         )
                         (if (result (ref $type28))
                          (i64.eqz
                           (local.tee $11
                            (i64.sub
                             (local.get $11)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                            (local.get $9)
                            (struct.get $type28 1
                             (local.get $2)
                            )
                           ))
                          )
                          (else
                           (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                            (struct.get $type28 0
                             (local.get $2)
                            )
                            (block (result (ref $type28))
                             (local.set $2
                              (struct.get $type28 1
                               (local.get $2)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready274)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global274)
                              )
                             )
                             (if (result (ref $type28))
                              (i64.eqz
                               (local.tee $11
                                (i64.sub
                                 (local.get $11)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                (local.get $9)
                                (struct.get $type28 1
                                 (local.get $2)
                                )
                               ))
                              )
                              (else
                               (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                (struct.get $type28 0
                                 (local.get $2)
                                )
                                (block (result (ref $type28))
                                 (local.set $2
                                  (struct.get $type28 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready274)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global274)
                                  )
                                 )
                                 (if (result (ref $type28))
                                  (i64.eqz
                                   (local.tee $11
                                    (i64.sub
                                     (local.get $11)
                                     (i64.const 1)
                                    )
                                   )
                                  )
                                  (then
                                   (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                    (local.get $9)
                                    (struct.get $type28 1
                                     (local.get $2)
                                    )
                                   ))
                                  )
                                  (else
                                   (block (result (ref $type28)) (global.set $observed71 (i64.add (global.get $observed71) (i64.const 1))) (struct.new $type28
                                    (struct.get $type28 0
                                     (local.get $2)
                                    )
                                    (call $function91
                                     (struct.get $type28 1
                                      (local.get $2)
                                     )
                                     (block (result i64)
                                      (if
                                       (i32.eqz
                                        (global.get $ready274)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global274)
                                       )
                                      )
                                      (i64.sub
                                       (local.get $11)
                                       (i64.const 1)
                                      )
                                     )
                                     (local.get $9)
                                    )
                                   ))
                                  )
                                 )
                                )
                               ))
                              )
                             )
                            )
                           ))
                          )
                         )
                        )
                       ))
                      )
                     )
                    )
                   ))
                  )
                 )
                )
               ))
              )
             )
            )
           ))
          )
         )
        )
       ))
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready278)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global278)
     )
    )
    (if (result (ref $type33))
     (i64.eqz
      (local.get $12)
     )
     (then
      (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
       (local.get $10)
       (struct.get $type33 1
        (local.get $1)
       )
      ))
     )
     (else
      (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
       (struct.get $type33 0
        (local.get $1)
       )
       (block (result (ref $type33))
        (local.set $1
         (struct.get $type33 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready278)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global278)
         )
        )
        (if (result (ref $type33))
         (i64.eqz
          (local.tee $11
           (i64.sub
            (local.get $12)
            (i64.const 1)
           )
          )
         )
         (then
          (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
           (local.get $10)
           (struct.get $type33 1
            (local.get $1)
           )
          ))
         )
         (else
          (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
           (struct.get $type33 0
            (local.get $1)
           )
           (block (result (ref $type33))
            (local.set $1
             (struct.get $type33 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (global.get $ready278)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global278)
             )
            )
            (if (result (ref $type33))
             (i64.eqz
              (local.tee $11
               (i64.sub
                (local.get $11)
                (i64.const 1)
               )
              )
             )
             (then
              (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
               (local.get $10)
               (struct.get $type33 1
                (local.get $1)
               )
              ))
             )
             (else
              (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
               (struct.get $type33 0
                (local.get $1)
               )
               (block (result (ref $type33))
                (local.set $1
                 (struct.get $type33 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready278)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global278)
                 )
                )
                (if (result (ref $type33))
                 (i64.eqz
                  (local.tee $11
                   (i64.sub
                    (local.get $11)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                   (local.get $10)
                   (struct.get $type33 1
                    (local.get $1)
                   )
                  ))
                 )
                 (else
                  (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                   (struct.get $type33 0
                    (local.get $1)
                   )
                   (block (result (ref $type33))
                    (local.set $1
                     (struct.get $type33 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready278)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global278)
                     )
                    )
                    (if (result (ref $type33))
                     (i64.eqz
                      (local.tee $11
                       (i64.sub
                        (local.get $11)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                       (local.get $10)
                       (struct.get $type33 1
                        (local.get $1)
                       )
                      ))
                     )
                     (else
                      (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                       (struct.get $type33 0
                        (local.get $1)
                       )
                       (block (result (ref $type33))
                        (local.set $1
                         (struct.get $type33 1
                          (local.get $1)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready278)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global278)
                         )
                        )
                        (if (result (ref $type33))
                         (i64.eqz
                          (local.tee $11
                           (i64.sub
                            (local.get $11)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                           (local.get $10)
                           (struct.get $type33 1
                            (local.get $1)
                           )
                          ))
                         )
                         (else
                          (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                           (struct.get $type33 0
                            (local.get $1)
                           )
                           (block (result (ref $type33))
                            (local.set $1
                             (struct.get $type33 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready278)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global278)
                             )
                            )
                            (if (result (ref $type33))
                             (i64.eqz
                              (local.tee $11
                               (i64.sub
                                (local.get $11)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                               (local.get $10)
                               (struct.get $type33 1
                                (local.get $1)
                               )
                              ))
                             )
                             (else
                              (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                               (struct.get $type33 0
                                (local.get $1)
                               )
                               (block (result (ref $type33))
                                (local.set $1
                                 (struct.get $type33 1
                                  (local.get $1)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready278)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global278)
                                 )
                                )
                                (if (result (ref $type33))
                                 (i64.eqz
                                  (local.tee $11
                                   (i64.sub
                                    (local.get $11)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                 (then
                                  (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                                   (local.get $10)
                                   (struct.get $type33 1
                                    (local.get $1)
                                   )
                                  ))
                                 )
                                 (else
                                  (block (result (ref $type33)) (global.set $observed76 (i64.add (global.get $observed76) (i64.const 1))) (struct.new $type33
                                   (struct.get $type33 0
                                    (local.get $1)
                                   )
                                   (call $function92
                                    (struct.get $type33 1
                                     (local.get $1)
                                    )
                                    (block (result i64)
                                     (if
                                      (i32.eqz
                                       (global.get $ready278)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global278)
                                      )
                                     )
                                     (i64.sub
                                      (local.get $11)
                                      (i64.const 1)
                                     )
                                    )
                                    (local.get $10)
                                   )
                                  ))
                                 )
                                )
                               )
                              ))
                             )
                            )
                           )
                          ))
                         )
                        )
                       )
                      ))
                     )
                    )
                   )
                  ))
                 )
                )
               )
              ))
             )
            )
           )
          ))
         )
        )
       )
      ))
     )
    )
   )
  )
 )
 (func $function77 (type $call88) (param $0 (ref $type29)) (param $1 (ref null $type33)) (result (ref null $type28))
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref null $type28))
  (local $5 (ref null $type28))
  (local $6 (ref null $type28))
  (local $7 (ref null $type33))
  (local $8 (ref $type31))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $scratch (ref null $type28))
  (global.set $observed22 (i64.add (global.get $observed22) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready223)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global223)
   )
  )
  (if
   (i32.eqz
    (global.get $ready225)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global225)
   )
  )
  (local.set $5
   (if (result (ref null $type28))
    (if (result i32)
     (i64.gt_s
      (i64.sub
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $7
            (struct.get $type33 1
             (local.get $1)
            )
           )
          )
          (then
           (i64.const 1)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $7
              (struct.get $type33 1
               (local.get $7)
              )
             )
            )
            (then
             (i64.const 2)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $7
                (struct.get $type33 1
                 (local.get $7)
                )
               )
              )
              (then
               (i64.const 3)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $7
                  (struct.get $type33 1
                   (local.get $7)
                  )
                 )
                )
                (then
                 (i64.const 4)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $7
                    (struct.get $type33 1
                     (local.get $7)
                    )
                   )
                  )
                  (then
                   (i64.const 5)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $7
                      (struct.get $type33 1
                       (local.get $7)
                      )
                     )
                    )
                    (then
                     (i64.const 6)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $7
                        (struct.get $type33 1
                         (local.get $7)
                        )
                       )
                      )
                      (then
                       (i64.const 7)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $7
                          (struct.get $type33 1
                           (local.get $7)
                          )
                         )
                        )
                        (then
                         (i64.const 8)
                        )
                        (else
                         (call $function80
                          (i32.const 0)
                          (i32.const 1)
                          (struct.get $type33 1
                           (local.get $7)
                          )
                          (i64.const 9)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (block (result i64)
        (local.set $13
         (call $function71
          (block (result (ref null $type28))
           (local.set $scratch
            (struct.get $type33 0
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready198)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global198)
            )
           )
           (local.get $scratch)
          )
         )
        )
        (if
         (ref.test (ref $type30)
          (local.get $0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $11
         (struct.get $type31 0
          (local.tee $8
           (ref.cast (ref $type31)
            (local.get $0)
           )
          )
         )
        )
        (local.set $12
         (struct.get $type31 1
          (local.get $8)
         )
        )
        (local.set $4
         (if (result (ref null $type28))
          (if (result i32)
           (i64.gt_s
            (local.get $11)
            (i64.const 0)
           )
           (then
            (if
             (i32.eqz
              (global.get $ready234)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global234)
             )
            )
            (if
             (i32.eqz
              (global.get $ready238)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global238)
             )
            )
            (local.set $2
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $10
                (i64.sub
                 (local.get $11)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $1)
               )
              )
              (else
               (local.set $7
                (struct.get $type33 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $10
                  (i64.sub
                   (local.get $10)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $7)
                 )
                )
                (else
                 (local.set $7
                  (struct.get $type33 1
                   (local.get $7)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $10
                    (i64.sub
                     (local.get $10)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $7)
                   )
                  )
                  (else
                   (local.set $7
                    (struct.get $type33 1
                     (local.get $7)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $10
                      (i64.sub
                       (local.get $10)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $7)
                     )
                    )
                    (else
                     (local.set $7
                      (struct.get $type33 1
                       (local.get $7)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready238)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global238)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.tee $10
                        (i64.sub
                         (local.get $10)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type33 0
                        (local.get $7)
                       )
                      )
                      (else
                       (local.set $7
                        (struct.get $type33 1
                         (local.get $7)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.eqz
                         (local.tee $10
                          (i64.sub
                           (local.get $10)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type33 0
                          (local.get $7)
                         )
                        )
                        (else
                         (local.set $7
                          (struct.get $type33 1
                           (local.get $7)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready238)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global238)
                          )
                         )
                         (if (result (ref null $type28))
                          (i64.eqz
                           (local.tee $10
                            (i64.sub
                             (local.get $10)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (struct.get $type33 0
                            (local.get $7)
                           )
                          )
                          (else
                           (local.set $7
                            (struct.get $type33 1
                             (local.get $7)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready238)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global238)
                            )
                           )
                           (if (result (ref null $type28))
                            (i64.eqz
                             (local.tee $10
                              (i64.sub
                               (local.get $10)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (struct.get $type33 0
                              (local.get $7)
                             )
                            )
                            (else
                             (local.set $7
                              (struct.get $type33 1
                               (local.get $7)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready238)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global238)
                              )
                             )
                             (if (result (ref null $type28))
                              (i64.eqz
                               (local.tee $10
                                (i64.sub
                                 (local.get $10)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (struct.get $type33 0
                                (local.get $7)
                               )
                              )
                              (else
                               (call $function82
                                (struct.get $type33 1
                                 (local.get $7)
                                )
                                (block (result i64)
                                 (if
                                  (i32.eqz
                                   (global.get $ready238)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global238)
                                  )
                                 )
                                 (i64.sub
                                  (local.get $10)
                                  (i64.const 1)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready203)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global203)
             )
            )
            (local.set $0
             (if (result (ref $type29))
              (i64.eqz
               (local.get $12)
              )
              (then
               (struct.get $type28 0
                (local.get $2)
               )
              )
              (else
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready203)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global203)
                )
               )
               (if (result (ref $type29))
                (i64.eqz
                 (local.tee $10
                  (i64.sub
                   (local.get $12)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
                (else
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready203)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global203)
                  )
                 )
                 (if (result (ref $type29))
                  (i64.eqz
                   (local.tee $10
                    (i64.sub
                     (local.get $10)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                  (else
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready203)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global203)
                    )
                   )
                   (if (result (ref $type29))
                    (i64.eqz
                     (local.tee $10
                      (i64.sub
                       (local.get $10)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                    (else
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready203)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global203)
                      )
                     )
                     (if (result (ref $type29))
                      (i64.eqz
                       (local.tee $10
                        (i64.sub
                         (local.get $10)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                      (else
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready203)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global203)
                        )
                       )
                       (if (result (ref $type29))
                        (i64.eqz
                         (local.tee $10
                          (i64.sub
                           (local.get $10)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type28 0
                          (local.get $2)
                         )
                        )
                        (else
                         (local.set $2
                          (struct.get $type28 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready203)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global203)
                          )
                         )
                         (if (result (ref $type29))
                          (i64.eqz
                           (local.tee $10
                            (i64.sub
                             (local.get $10)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (struct.get $type28 0
                            (local.get $2)
                           )
                          )
                          (else
                           (local.set $2
                            (struct.get $type28 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready203)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global203)
                            )
                           )
                           (if (result (ref $type29))
                            (i64.eqz
                             (local.tee $10
                              (i64.sub
                               (local.get $10)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (struct.get $type28 0
                              (local.get $2)
                             )
                            )
                            (else
                             (local.set $2
                              (struct.get $type28 1
                               (local.get $2)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready203)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global203)
                              )
                             )
                             (if (result (ref $type29))
                              (i64.eqz
                               (local.tee $10
                                (i64.sub
                                 (local.get $10)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (struct.get $type28 0
                                (local.get $2)
                               )
                              )
                              (else
                               (call $function73
                                (struct.get $type28 1
                                 (local.get $2)
                                )
                                (block (result i64)
                                 (if
                                  (i32.eqz
                                   (global.get $ready203)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global203)
                                  )
                                 )
                                 (i64.sub
                                  (local.get $10)
                                  (i64.const 1)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready110)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global110)
             )
            )
            (if (result i32)
             (ref.test (ref $type30)
              (local.get $0)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (ref.cast (ref $type31)
                (local.get $0)
               )
              )
              (i32.const 1)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
          (then
           (if
            (i32.eqz
             (global.get $ready178)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global178)
            )
           )
           (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
            (block (result (ref $type31)) (global.set $observed78 (i64.add (global.get $observed78) (i64.const 1))) (struct.new $type31
             (i64.sub
              (local.get $11)
              (i64.const 1)
             )
             (local.get $12)
            ))
            (ref.null none)
           ))
          )
          (else
           (ref.null none)
          )
         )
        )
        (i64.const 1)
       )
      )
      (local.get $11)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready234)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global234)
       )
      )
      (if
       (i32.eqz
        (global.get $ready238)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global238)
       )
      )
      (local.set $2
       (if (result (ref null $type28))
        (i64.eqz
         (local.tee $9
          (i64.add
           (local.get $11)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type33 0
          (local.get $1)
         )
        )
        (else
         (local.set $7
          (struct.get $type33 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $9
            (i64.sub
             (local.get $9)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $7)
           )
          )
          (else
           (local.set $7
            (struct.get $type33 1
             (local.get $7)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $9
              (i64.sub
               (local.get $9)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $7)
             )
            )
            (else
             (local.set $7
              (struct.get $type33 1
               (local.get $7)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $9
                (i64.sub
                 (local.get $9)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $7)
               )
              )
              (else
               (local.set $7
                (struct.get $type33 1
                 (local.get $7)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $9
                  (i64.sub
                   (local.get $9)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $7)
                 )
                )
                (else
                 (local.set $7
                  (struct.get $type33 1
                   (local.get $7)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $9
                    (i64.sub
                     (local.get $9)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $7)
                   )
                  )
                  (else
                   (local.set $7
                    (struct.get $type33 1
                     (local.get $7)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $9
                      (i64.sub
                       (local.get $9)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $7)
                     )
                    )
                    (else
                     (local.set $7
                      (struct.get $type33 1
                       (local.get $7)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready238)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global238)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.tee $9
                        (i64.sub
                         (local.get $9)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type33 0
                        (local.get $7)
                       )
                      )
                      (else
                       (local.set $7
                        (struct.get $type33 1
                         (local.get $7)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.eqz
                         (local.tee $9
                          (i64.sub
                           (local.get $9)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type33 0
                          (local.get $7)
                         )
                        )
                        (else
                         (call $function82
                          (struct.get $type33 1
                           (local.get $7)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready238)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global238)
                            )
                           )
                           (i64.sub
                            (local.get $9)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready203)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (local.set $0
       (if (result (ref $type29))
        (i64.eqz
         (local.get $12)
        )
        (then
         (struct.get $type28 0
          (local.get $2)
         )
        )
        (else
         (local.set $2
          (struct.get $type28 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready203)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global203)
          )
         )
         (if (result (ref $type29))
          (i64.eqz
           (local.tee $9
            (i64.sub
             (local.get $12)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type28 0
            (local.get $2)
           )
          )
          (else
           (local.set $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready203)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global203)
            )
           )
           (if (result (ref $type29))
            (i64.eqz
             (local.tee $9
              (i64.sub
               (local.get $9)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type28 0
              (local.get $2)
             )
            )
            (else
             (local.set $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready203)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global203)
              )
             )
             (if (result (ref $type29))
              (i64.eqz
               (local.tee $9
                (i64.sub
                 (local.get $9)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type28 0
                (local.get $2)
               )
              )
              (else
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready203)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global203)
                )
               )
               (if (result (ref $type29))
                (i64.eqz
                 (local.tee $9
                  (i64.sub
                   (local.get $9)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
                (else
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready203)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global203)
                  )
                 )
                 (if (result (ref $type29))
                  (i64.eqz
                   (local.tee $9
                    (i64.sub
                     (local.get $9)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                  (else
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready203)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global203)
                    )
                   )
                   (if (result (ref $type29))
                    (i64.eqz
                     (local.tee $9
                      (i64.sub
                       (local.get $9)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                    (else
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready203)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global203)
                      )
                     )
                     (if (result (ref $type29))
                      (i64.eqz
                       (local.tee $9
                        (i64.sub
                         (local.get $9)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                      (else
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready203)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global203)
                        )
                       )
                       (if (result (ref $type29))
                        (i64.eqz
                         (local.tee $9
                          (i64.sub
                           (local.get $9)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type28 0
                          (local.get $2)
                         )
                        )
                        (else
                         (call $function73
                          (struct.get $type28 1
                           (local.get $2)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready203)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global203)
                            )
                           )
                           (i64.sub
                            (local.get $9)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready110)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (if (result i32)
       (ref.test (ref $type30)
        (local.get $0)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type31)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready178)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global178)
      )
     )
     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
      (block (result (ref $type31)) (global.set $observed78 (i64.add (global.get $observed78) (i64.const 1))) (struct.new $type31
       (i64.add
        (local.get $11)
        (i64.const 1)
       )
       (local.get $12)
      ))
      (ref.null none)
     ))
    )
    (else
     (ref.null none)
    )
   )
  )
  (local.set $6
   (if (result (ref null $type28))
    (if (result i32)
     (i64.gt_s
      (local.get $12)
      (i64.const 0)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready234)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global234)
       )
      )
      (if
       (i32.eqz
        (global.get $ready238)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global238)
       )
      )
      (local.set $2
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $11)
        )
        (then
         (struct.get $type33 0
          (local.get $1)
         )
        )
        (else
         (local.set $7
          (struct.get $type33 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $9
            (i64.sub
             (local.get $11)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $7)
           )
          )
          (else
           (local.set $7
            (struct.get $type33 1
             (local.get $7)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $9
              (i64.sub
               (local.get $9)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $7)
             )
            )
            (else
             (local.set $7
              (struct.get $type33 1
               (local.get $7)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $9
                (i64.sub
                 (local.get $9)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $7)
               )
              )
              (else
               (local.set $7
                (struct.get $type33 1
                 (local.get $7)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $9
                  (i64.sub
                   (local.get $9)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $7)
                 )
                )
                (else
                 (local.set $7
                  (struct.get $type33 1
                   (local.get $7)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $9
                    (i64.sub
                     (local.get $9)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $7)
                   )
                  )
                  (else
                   (local.set $7
                    (struct.get $type33 1
                     (local.get $7)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $9
                      (i64.sub
                       (local.get $9)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $7)
                     )
                    )
                    (else
                     (local.set $7
                      (struct.get $type33 1
                       (local.get $7)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready238)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global238)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.tee $9
                        (i64.sub
                         (local.get $9)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type33 0
                        (local.get $7)
                       )
                      )
                      (else
                       (local.set $7
                        (struct.get $type33 1
                         (local.get $7)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.eqz
                         (local.tee $9
                          (i64.sub
                           (local.get $9)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type33 0
                          (local.get $7)
                         )
                        )
                        (else
                         (call $function82
                          (struct.get $type33 1
                           (local.get $7)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready238)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global238)
                            )
                           )
                           (i64.sub
                            (local.get $9)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready203)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (local.set $0
       (if (result (ref $type29))
        (i64.eqz
         (local.tee $9
          (i64.sub
           (local.get $12)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type28 0
          (local.get $2)
         )
        )
        (else
         (local.set $2
          (struct.get $type28 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready203)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global203)
          )
         )
         (if (result (ref $type29))
          (i64.eqz
           (local.tee $9
            (i64.sub
             (local.get $9)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type28 0
            (local.get $2)
           )
          )
          (else
           (local.set $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready203)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global203)
            )
           )
           (if (result (ref $type29))
            (i64.eqz
             (local.tee $9
              (i64.sub
               (local.get $9)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type28 0
              (local.get $2)
             )
            )
            (else
             (local.set $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready203)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global203)
              )
             )
             (if (result (ref $type29))
              (i64.eqz
               (local.tee $9
                (i64.sub
                 (local.get $9)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type28 0
                (local.get $2)
               )
              )
              (else
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready203)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global203)
                )
               )
               (if (result (ref $type29))
                (i64.eqz
                 (local.tee $9
                  (i64.sub
                   (local.get $9)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
                (else
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready203)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global203)
                  )
                 )
                 (if (result (ref $type29))
                  (i64.eqz
                   (local.tee $9
                    (i64.sub
                     (local.get $9)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                  (else
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready203)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global203)
                    )
                   )
                   (if (result (ref $type29))
                    (i64.eqz
                     (local.tee $9
                      (i64.sub
                       (local.get $9)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                    (else
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready203)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global203)
                      )
                     )
                     (if (result (ref $type29))
                      (i64.eqz
                       (local.tee $9
                        (i64.sub
                         (local.get $9)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                      (else
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready203)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global203)
                        )
                       )
                       (if (result (ref $type29))
                        (i64.eqz
                         (local.tee $9
                          (i64.sub
                           (local.get $9)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type28 0
                          (local.get $2)
                         )
                        )
                        (else
                         (call $function73
                          (struct.get $type28 1
                           (local.get $2)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready203)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global203)
                            )
                           )
                           (i64.sub
                            (local.get $9)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready110)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (if (result i32)
       (ref.test (ref $type30)
        (local.get $0)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type31)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready178)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global178)
      )
     )
     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
      (block (result (ref $type31)) (global.set $observed78 (i64.add (global.get $observed78) (i64.const 1))) (struct.new $type31
       (local.get $11)
       (i64.sub
        (local.get $12)
        (i64.const 1)
       )
      ))
      (ref.null none)
     ))
    )
    (else
     (ref.null none)
    )
   )
  )
  (local.set $3
   (if (result (ref null $type28))
    (if (result i32)
     (i64.gt_s
      (i64.sub
       (local.get $13)
       (i64.const 1)
      )
      (local.get $12)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready234)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global234)
       )
      )
      (if
       (i32.eqz
        (global.get $ready238)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global238)
       )
      )
      (local.set $2
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $11)
        )
        (then
         (struct.get $type33 0
          (local.get $1)
         )
        )
        (else
         (local.set $1
          (struct.get $type33 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $9
            (i64.sub
             (local.get $11)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $1)
           )
          )
          (else
           (local.set $1
            (struct.get $type33 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $9
              (i64.sub
               (local.get $9)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $1)
             )
            )
            (else
             (local.set $1
              (struct.get $type33 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $9
                (i64.sub
                 (local.get $9)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $1)
               )
              )
              (else
               (local.set $1
                (struct.get $type33 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $9
                  (i64.sub
                   (local.get $9)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $1)
                 )
                )
                (else
                 (local.set $1
                  (struct.get $type33 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $9
                    (i64.sub
                     (local.get $9)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $1)
                   )
                  )
                  (else
                   (local.set $1
                    (struct.get $type33 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $9
                      (i64.sub
                       (local.get $9)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $1)
                     )
                    )
                    (else
                     (local.set $1
                      (struct.get $type33 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready238)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global238)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.tee $9
                        (i64.sub
                         (local.get $9)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type33 0
                        (local.get $1)
                       )
                      )
                      (else
                       (local.set $1
                        (struct.get $type33 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.eqz
                         (local.tee $9
                          (i64.sub
                           (local.get $9)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type33 0
                          (local.get $1)
                         )
                        )
                        (else
                         (call $function82
                          (struct.get $type33 1
                           (local.get $1)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready238)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global238)
                            )
                           )
                           (i64.sub
                            (local.get $9)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready203)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (local.set $0
       (if (result (ref $type29))
        (i64.eqz
         (local.tee $9
          (i64.add
           (local.get $12)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type28 0
          (local.get $2)
         )
        )
        (else
         (local.set $2
          (struct.get $type28 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready203)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global203)
          )
         )
         (if (result (ref $type29))
          (i64.eqz
           (local.tee $9
            (i64.sub
             (local.get $9)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type28 0
            (local.get $2)
           )
          )
          (else
           (local.set $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready203)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global203)
            )
           )
           (if (result (ref $type29))
            (i64.eqz
             (local.tee $9
              (i64.sub
               (local.get $9)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type28 0
              (local.get $2)
             )
            )
            (else
             (local.set $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready203)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global203)
              )
             )
             (if (result (ref $type29))
              (i64.eqz
               (local.tee $9
                (i64.sub
                 (local.get $9)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type28 0
                (local.get $2)
               )
              )
              (else
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready203)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global203)
                )
               )
               (if (result (ref $type29))
                (i64.eqz
                 (local.tee $9
                  (i64.sub
                   (local.get $9)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
                (else
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready203)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global203)
                  )
                 )
                 (if (result (ref $type29))
                  (i64.eqz
                   (local.tee $9
                    (i64.sub
                     (local.get $9)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                  (else
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready203)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global203)
                    )
                   )
                   (if (result (ref $type29))
                    (i64.eqz
                     (local.tee $9
                      (i64.sub
                       (local.get $9)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                    (else
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready203)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global203)
                      )
                     )
                     (if (result (ref $type29))
                      (i64.eqz
                       (local.tee $9
                        (i64.sub
                         (local.get $9)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                      (else
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready203)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global203)
                        )
                       )
                       (if (result (ref $type29))
                        (i64.eqz
                         (local.tee $9
                          (i64.sub
                           (local.get $9)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (struct.get $type28 0
                          (local.get $2)
                         )
                        )
                        (else
                         (call $function73
                          (struct.get $type28 1
                           (local.get $2)
                          )
                          (block (result i64)
                           (if
                            (i32.eqz
                             (global.get $ready203)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global203)
                            )
                           )
                           (i64.sub
                            (local.get $9)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready110)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (if (result i32)
       (ref.test (ref $type30)
        (local.get $0)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type31)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready178)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global178)
      )
     )
     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
      (block (result (ref $type31)) (global.set $observed78 (i64.add (global.get $observed78) (i64.const 1))) (struct.new $type31
       (local.get $11)
       (i64.add
        (local.get $12)
        (i64.const 1)
       )
      ))
      (ref.null none)
     ))
    )
    (else
     (ref.null none)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready241)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global241)
   )
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.get $6)
    )
   )
   (then
    (local.set $3
     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
      (struct.get $type28 0
       (local.get $6)
      )
      (block (result (ref null $type28))
       (local.set $2
        (struct.get $type28 1
         (local.get $6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready182)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global182)
        )
       )
       (if (result (ref null $type28))
        (ref.is_null
         (local.get $2)
        )
        (then
         (local.get $3)
        )
        (else
         (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
          (struct.get $type28 0
           (local.get $2)
          )
          (block (result (ref null $type28))
           (local.set $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready182)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global182)
            )
           )
           (if (result (ref null $type28))
            (ref.is_null
             (local.get $2)
            )
            (then
             (local.get $3)
            )
            (else
             (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
              (struct.get $type28 0
               (local.get $2)
              )
              (block (result (ref null $type28))
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready182)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global182)
                )
               )
               (if (result (ref null $type28))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $3)
                )
                (else
                 (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                  (struct.get $type28 0
                   (local.get $2)
                  )
                  (block (result (ref null $type28))
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready182)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global182)
                    )
                   )
                   (if (result (ref null $type28))
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (local.get $3)
                    )
                    (else
                     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                      (struct.get $type28 0
                       (local.get $2)
                      )
                      (block (result (ref null $type28))
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready182)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global182)
                        )
                       )
                       (if (result (ref null $type28))
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (local.get $3)
                        )
                        (else
                         (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                          (struct.get $type28 0
                           (local.get $2)
                          )
                          (block (result (ref null $type28))
                           (local.set $2
                            (struct.get $type28 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready182)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global182)
                            )
                           )
                           (if (result (ref null $type28))
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (local.get $3)
                            )
                            (else
                             (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                              (struct.get $type28 0
                               (local.get $2)
                              )
                              (block (result (ref null $type28))
                               (local.set $2
                                (struct.get $type28 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready182)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global182)
                                )
                               )
                               (if (result (ref null $type28))
                                (ref.is_null
                                 (local.get $2)
                                )
                                (then
                                 (local.get $3)
                                )
                                (else
                                 (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                                  (struct.get $type28 0
                                   (local.get $2)
                                  )
                                  (block (result (ref null $type28))
                                   (local.set $2
                                    (struct.get $type28 1
                                     (local.get $2)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready182)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global182)
                                    )
                                   )
                                   (if (result (ref null $type28))
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (local.get $3)
                                    )
                                    (else
                                     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                                      (struct.get $type28 0
                                       (local.get $2)
                                      )
                                      (call $function66
                                       (struct.get $type28 1
                                        (local.get $2)
                                       )
                                       (block (result (ref null $type28))
                                        (if
                                         (i32.eqz
                                          (global.get $ready182)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global182)
                                         )
                                        )
                                        (local.get $3)
                                       )
                                      )
                                     ))
                                    )
                                   )
                                  )
                                 ))
                                )
                               )
                              )
                             ))
                            )
                           )
                          )
                         ))
                        )
                       )
                      )
                     ))
                    )
                   )
                  )
                 ))
                )
               )
              )
             ))
            )
           )
          )
         ))
        )
       )
      )
     ))
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.get $5)
    )
   )
   (then
    (local.set $3
     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
      (struct.get $type28 0
       (local.get $5)
      )
      (block (result (ref null $type28))
       (local.set $2
        (struct.get $type28 1
         (local.get $5)
        )
       )
       (if
        (i32.eqz
         (global.get $ready182)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global182)
        )
       )
       (if (result (ref null $type28))
        (ref.is_null
         (local.get $2)
        )
        (then
         (local.get $3)
        )
        (else
         (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
          (struct.get $type28 0
           (local.get $2)
          )
          (block (result (ref null $type28))
           (local.set $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready182)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global182)
            )
           )
           (if (result (ref null $type28))
            (ref.is_null
             (local.get $2)
            )
            (then
             (local.get $3)
            )
            (else
             (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
              (struct.get $type28 0
               (local.get $2)
              )
              (block (result (ref null $type28))
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready182)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global182)
                )
               )
               (if (result (ref null $type28))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $3)
                )
                (else
                 (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                  (struct.get $type28 0
                   (local.get $2)
                  )
                  (block (result (ref null $type28))
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready182)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global182)
                    )
                   )
                   (if (result (ref null $type28))
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (local.get $3)
                    )
                    (else
                     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                      (struct.get $type28 0
                       (local.get $2)
                      )
                      (block (result (ref null $type28))
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready182)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global182)
                        )
                       )
                       (if (result (ref null $type28))
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (local.get $3)
                        )
                        (else
                         (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                          (struct.get $type28 0
                           (local.get $2)
                          )
                          (block (result (ref null $type28))
                           (local.set $2
                            (struct.get $type28 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready182)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global182)
                            )
                           )
                           (if (result (ref null $type28))
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (local.get $3)
                            )
                            (else
                             (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                              (struct.get $type28 0
                               (local.get $2)
                              )
                              (block (result (ref null $type28))
                               (local.set $2
                                (struct.get $type28 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready182)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global182)
                                )
                               )
                               (if (result (ref null $type28))
                                (ref.is_null
                                 (local.get $2)
                                )
                                (then
                                 (local.get $3)
                                )
                                (else
                                 (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                                  (struct.get $type28 0
                                   (local.get $2)
                                  )
                                  (block (result (ref null $type28))
                                   (local.set $2
                                    (struct.get $type28 1
                                     (local.get $2)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready182)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global182)
                                    )
                                   )
                                   (if (result (ref null $type28))
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (local.get $3)
                                    )
                                    (else
                                     (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                                      (struct.get $type28 0
                                       (local.get $2)
                                      )
                                      (call $function66
                                       (struct.get $type28 1
                                        (local.get $2)
                                       )
                                       (block (result (ref null $type28))
                                        (if
                                         (i32.eqz
                                          (global.get $ready182)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global182)
                                         )
                                        )
                                        (local.get $3)
                                       )
                                      )
                                     ))
                                    )
                                   )
                                  )
                                 ))
                                )
                               )
                              )
                             ))
                            )
                           )
                          )
                         ))
                        )
                       )
                      )
                     ))
                    )
                   )
                  )
                 ))
                )
               )
              )
             ))
            )
           )
          )
         ))
        )
       )
      )
     ))
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $4)
   )
   (then
    (local.get $3)
   )
   (else
    (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
     (struct.get $type28 0
      (local.get $4)
     )
     (block (result (ref null $type28))
      (local.set $2
       (struct.get $type28 1
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (global.get $ready182)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global182)
       )
      )
      (if (result (ref null $type28))
       (ref.is_null
        (local.get $2)
       )
       (then
        (local.get $3)
       )
       (else
        (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
         (struct.get $type28 0
          (local.get $2)
         )
         (block (result (ref null $type28))
          (local.set $2
           (struct.get $type28 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (global.get $ready182)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global182)
           )
          )
          (if (result (ref null $type28))
           (ref.is_null
            (local.get $2)
           )
           (then
            (local.get $3)
           )
           (else
            (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
             (struct.get $type28 0
              (local.get $2)
             )
             (block (result (ref null $type28))
              (local.set $2
               (struct.get $type28 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready182)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global182)
               )
              )
              (if (result (ref null $type28))
               (ref.is_null
                (local.get $2)
               )
               (then
                (local.get $3)
               )
               (else
                (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                 (struct.get $type28 0
                  (local.get $2)
                 )
                 (block (result (ref null $type28))
                  (local.set $2
                   (struct.get $type28 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready182)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global182)
                   )
                  )
                  (if (result (ref null $type28))
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                     (struct.get $type28 0
                      (local.get $2)
                     )
                     (block (result (ref null $type28))
                      (local.set $2
                       (struct.get $type28 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready182)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global182)
                       )
                      )
                      (if (result (ref null $type28))
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (local.get $3)
                       )
                       (else
                        (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                         (struct.get $type28 0
                          (local.get $2)
                         )
                         (block (result (ref null $type28))
                          (local.set $2
                           (struct.get $type28 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready182)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global182)
                           )
                          )
                          (if (result (ref null $type28))
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (local.get $3)
                           )
                           (else
                            (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                             (struct.get $type28 0
                              (local.get $2)
                             )
                             (block (result (ref null $type28))
                              (local.set $2
                               (struct.get $type28 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready182)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global182)
                               )
                              )
                              (if (result (ref null $type28))
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (local.get $3)
                               )
                               (else
                                (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                                 (struct.get $type28 0
                                  (local.get $2)
                                 )
                                 (block (result (ref null $type28))
                                  (local.set $2
                                   (struct.get $type28 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready182)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global182)
                                   )
                                  )
                                  (if (result (ref null $type28))
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (local.get $3)
                                   )
                                   (else
                                    (block (result (ref $type28)) (global.set $observed77 (i64.add (global.get $observed77) (i64.const 1))) (struct.new $type28
                                     (struct.get $type28 0
                                      (local.get $2)
                                     )
                                     (call $function66
                                      (struct.get $type28 1
                                       (local.get $2)
                                      )
                                      (block (result (ref null $type28))
                                       (if
                                        (i32.eqz
                                         (global.get $ready182)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global182)
                                        )
                                       )
                                       (local.get $3)
                                      )
                                     )
                                    ))
                                   )
                                  )
                                 )
                                ))
                               )
                              )
                             )
                            ))
                           )
                          )
                         )
                        ))
                       )
                      )
                     )
                    ))
                   )
                  )
                 )
                ))
               )
              )
             )
            ))
           )
          )
         )
        ))
       )
      )
     )
    ))
   )
  )
 )
 (func $function80 (type $19) (param $0 i32) (param $1 i32) (param $2 (ref null $type33)) (param $3 i64) (result i64)
  (global.set $observed23 (i64.add (global.get $observed23) (i64.const 1)))
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type33 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function80
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function81 (type $call75) (param $0 (ref null $type33)) (param $1 i64) (param $2 i64) (result (ref $type29))
  (local $3 (ref null $type28))
  (global.set $observed24 (i64.add (global.get $observed24) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready238)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global238)
   )
  )
  (local.set $3
   (if (result (ref null $type28))
    (i64.eqz
     (local.get $1)
    )
    (then
     (struct.get $type33 0
      (local.get $0)
     )
    )
    (else
     (local.set $0
      (struct.get $type33 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready238)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global238)
      )
     )
     (if (result (ref null $type28))
      (i64.eqz
       (local.tee $1
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
      )
      (then
       (struct.get $type33 0
        (local.get $0)
       )
      )
      (else
       (local.set $0
        (struct.get $type33 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready238)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global238)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.tee $1
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type33 0
          (local.get $0)
         )
        )
        (else
         (local.set $0
          (struct.get $type33 1
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $1
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $0)
           )
          )
          (else
           (local.set $0
            (struct.get $type33 1
             (local.get $0)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $1
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $0)
             )
            )
            (else
             (local.set $0
              (struct.get $type33 1
               (local.get $0)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $1
                (i64.sub
                 (local.get $1)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $0)
               )
              )
              (else
               (local.set $0
                (struct.get $type33 1
                 (local.get $0)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $1
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $0)
                 )
                )
                (else
                 (local.set $0
                  (struct.get $type33 1
                   (local.get $0)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $1
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $0)
                   )
                  )
                  (else
                   (local.set $0
                    (struct.get $type33 1
                     (local.get $0)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $1
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $0)
                     )
                    )
                    (else
                     (call $function82
                      (struct.get $type33 1
                       (local.get $0)
                      )
                      (block (result i64)
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (i64.sub
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready203)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global203)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (local.get $2)
   )
   (then
    (struct.get $type28 0
     (local.get $3)
    )
   )
   (else
    (local.set $3
     (struct.get $type28 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (global.get $ready203)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (local.tee $1
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
     )
     (then
      (struct.get $type28 0
       (local.get $3)
      )
     )
     (else
      (local.set $3
       (struct.get $type28 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (global.get $ready203)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (local.tee $1
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (then
        (struct.get $type28 0
         (local.get $3)
        )
       )
       (else
        (local.set $3
         (struct.get $type28 1
          (local.get $3)
         )
        )
        (if
         (i32.eqz
          (global.get $ready203)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global203)
         )
        )
        (if (result (ref $type29))
         (i64.eqz
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (then
          (struct.get $type28 0
           (local.get $3)
          )
         )
         (else
          (local.set $3
           (struct.get $type28 1
            (local.get $3)
           )
          )
          (if
           (i32.eqz
            (global.get $ready203)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global203)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (local.tee $1
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (then
            (struct.get $type28 0
             (local.get $3)
            )
           )
           (else
            (local.set $3
             (struct.get $type28 1
              (local.get $3)
             )
            )
            (if
             (i32.eqz
              (global.get $ready203)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global203)
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (local.tee $1
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
             )
             (then
              (struct.get $type28 0
               (local.get $3)
              )
             )
             (else
              (local.set $3
               (struct.get $type28 1
                (local.get $3)
               )
              )
              (if
               (i32.eqz
                (global.get $ready203)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global203)
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (local.tee $1
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
               )
               (then
                (struct.get $type28 0
                 (local.get $3)
                )
               )
               (else
                (local.set $3
                 (struct.get $type28 1
                  (local.get $3)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready203)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global203)
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (local.tee $1
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (struct.get $type28 0
                   (local.get $3)
                  )
                 )
                 (else
                  (local.set $3
                   (struct.get $type28 1
                    (local.get $3)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready203)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global203)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (local.tee $1
                     (i64.sub
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (struct.get $type28 0
                     (local.get $3)
                    )
                   )
                   (else
                    (return_call $function73
                     (struct.get $type28 1
                      (local.get $3)
                     )
                     (block (result i64)
                      (if
                       (i32.eqz
                        (global.get $ready203)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global203)
                       )
                      )
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function82 (type $call68) (param $0 (ref null $type33)) (param $1 i64) (result (ref null $type28))
  (global.set $observed25 (i64.add (global.get $observed25) (i64.const 1)))
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type33 0
     (local.get $0)
    )
   )
   (else
    (return_call $function82
     (struct.get $type33 1
      (local.get $0)
     )
     (block (result i64)
      (if
       (i32.eqz
        (global.get $ready238)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global238)
       )
      )
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
 )
 (func $function84 (type $call51) (param $0 (ref $environment84)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 i64)
  (local $3 (ref null $type33))
  (local $4 (ref null $type28))
  (local $5 (ref $type31))
  (global.set $observed26 (i64.add (global.get $observed26) (i64.const 1)))
  (if
   (ref.test (ref $type30)
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type31 0
    (local.tee $5
     (ref.cast (ref $type31)
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready234)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global234)
   )
  )
  (if
   (i32.eqz
    (global.get $ready238)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global238)
   )
  )
  (local.set $3
   (struct.get $environment84 0
    (local.get $0)
   )
  )
  (local.set $4
   (if (result (ref null $type28))
    (i64.eqz
     (local.get $2)
    )
    (then
     (struct.get $type33 0
      (local.get $3)
     )
    )
    (else
     (local.set $3
      (struct.get $type33 1
       (local.get $3)
      )
     )
     (if
      (i32.eqz
       (global.get $ready238)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global238)
      )
     )
     (if (result (ref null $type28))
      (i64.eqz
       (local.tee $2
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
       )
      )
      (then
       (struct.get $type33 0
        (local.get $3)
       )
      )
      (else
       (local.set $3
        (struct.get $type33 1
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (global.get $ready238)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global238)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.tee $2
          (i64.sub
           (local.get $2)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type33 0
          (local.get $3)
         )
        )
        (else
         (local.set $3
          (struct.get $type33 1
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $3)
           )
          )
          (else
           (local.set $3
            (struct.get $type33 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $2
              (i64.sub
               (local.get $2)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $3)
             )
            )
            (else
             (local.set $3
              (struct.get $type33 1
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $2
                (i64.sub
                 (local.get $2)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $3)
               )
              )
              (else
               (local.set $3
                (struct.get $type33 1
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $2
                  (i64.sub
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $3)
                 )
                )
                (else
                 (local.set $3
                  (struct.get $type33 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $2
                    (i64.sub
                     (local.get $2)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $3)
                   )
                  )
                  (else
                   (local.set $3
                    (struct.get $type33 1
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $2
                      (i64.sub
                       (local.get $2)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $3)
                     )
                    )
                    (else
                     (call $function82
                      (struct.get $type33 1
                       (local.get $3)
                      )
                      (block (result i64)
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready203)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global203)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (local.tee $2
     (struct.get $type31 1
      (local.get $5)
     )
    )
   )
   (then
    (struct.get $type28 0
     (local.get $4)
    )
   )
   (else
    (local.set $4
     (struct.get $type28 1
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready203)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (local.tee $2
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
     )
     (then
      (struct.get $type28 0
       (local.get $4)
      )
     )
     (else
      (local.set $4
       (struct.get $type28 1
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (global.get $ready203)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (local.tee $2
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (then
        (struct.get $type28 0
         (local.get $4)
        )
       )
       (else
        (local.set $4
         (struct.get $type28 1
          (local.get $4)
         )
        )
        (if
         (i32.eqz
          (global.get $ready203)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global203)
         )
        )
        (if (result (ref $type29))
         (i64.eqz
          (local.tee $2
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (then
          (struct.get $type28 0
           (local.get $4)
          )
         )
         (else
          (local.set $4
           (struct.get $type28 1
            (local.get $4)
           )
          )
          (if
           (i32.eqz
            (global.get $ready203)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global203)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (local.tee $2
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
           )
           (then
            (struct.get $type28 0
             (local.get $4)
            )
           )
           (else
            (local.set $4
             (struct.get $type28 1
              (local.get $4)
             )
            )
            (if
             (i32.eqz
              (global.get $ready203)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global203)
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (local.tee $2
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
             )
             (then
              (struct.get $type28 0
               (local.get $4)
              )
             )
             (else
              (local.set $4
               (struct.get $type28 1
                (local.get $4)
               )
              )
              (if
               (i32.eqz
                (global.get $ready203)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global203)
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (local.tee $2
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                )
               )
               (then
                (struct.get $type28 0
                 (local.get $4)
                )
               )
               (else
                (local.set $4
                 (struct.get $type28 1
                  (local.get $4)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready203)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global203)
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (local.tee $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (struct.get $type28 0
                   (local.get $4)
                  )
                 )
                 (else
                  (local.set $4
                   (struct.get $type28 1
                    (local.get $4)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready203)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global203)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (local.tee $2
                     (i64.sub
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (struct.get $type28 0
                     (local.get $4)
                    )
                   )
                   (else
                    (return_call $function73
                     (struct.get $type28 1
                      (local.get $4)
                     )
                     (block (result i64)
                      (if
                       (i32.eqz
                        (global.get $ready203)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global203)
                       )
                      )
                      (i64.sub
                       (local.get $2)
                       (i64.const 1)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function85 (type $call50) (param $0 (ref $type51)) (param $1 (ref null $type28)) (result (ref null $type28))
  (local $2 (ref $type29))
  (global.set $observed27 (i64.add (global.get $observed27) (i64.const 1)))
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (block (result (ref $type28)) (global.set $observed79 (i64.add (global.get $observed79) (i64.const 1))) (struct.new $type28
     (call $function84
      (struct.get $type51 0
       (local.get $0)
      )
      (struct.get $type28 0
       (local.get $1)
      )
     )
     (block (result (ref null $type28))
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready247)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global247)
       )
      )
      (call $function85
       (local.get $0)
       (local.get $1)
      )
     )
    ))
   )
  )
 )
 (func $function86 (type $call61) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 (ref $type29)) (result (ref null $type33))
  (local $3 (ref $type31))
  (local $4 (ref $type29))
  (local $5 i64)
  (global.set $observed28 (i64.add (global.get $observed28) (i64.const 1)))
  (local.set $4
   (struct.get $environment86 0
    (ref.cast (ref $environment86)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready253)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global253)
   )
  )
  (if
   (ref.test (ref $type30)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type31 0
    (local.tee $3
     (ref.cast (ref $type31)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready234)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global234)
   )
  )
  (local.set $2
   (call $function81
    (local.get $1)
    (local.get $5)
    (struct.get $type31 1
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready259)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global259)
   )
  )
  (return_call $function88
   (local.get $1)
   (local.get $3)
   (local.get $4)
   (local.get $2)
  )
 )
 (func $function88 (type $call87) (param $0 (ref null $type33)) (param $1 (ref $type29)) (param $2 (ref $type29)) (param $3 (ref $type29)) (result (ref null $type33))
  (local $4 (ref null $type28))
  (local $5 (ref null $type28))
  (local $6 (ref null $type33))
  (local $7 (ref $type61))
  (local $8 (ref $type28))
  (local $9 (ref $type31))
  (local $10 (ref $type33))
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (global.set $observed29 (i64.add (global.get $observed29) (i64.const 1)))
  (if
   (ref.test (ref $type30)
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $13
   (struct.get $type31 0
    (local.tee $9
     (ref.cast (ref $type31)
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready234)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global234)
   )
  )
  (if
   (i32.eqz
    (global.get $ready238)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global238)
   )
  )
  (local.set $4
   (if (result (ref null $type28))
    (i64.eqz
     (local.get $13)
    )
    (then
     (struct.get $type33 0
      (local.get $0)
     )
    )
    (else
     (local.set $6
      (struct.get $type33 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready238)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global238)
      )
     )
     (if (result (ref null $type28))
      (i64.eqz
       (local.tee $11
        (i64.sub
         (local.get $13)
         (i64.const 1)
        )
       )
      )
      (then
       (struct.get $type33 0
        (local.get $6)
       )
      )
      (else
       (local.set $6
        (struct.get $type33 1
         (local.get $6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready238)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global238)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.tee $11
          (i64.sub
           (local.get $11)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type33 0
          (local.get $6)
         )
        )
        (else
         (local.set $6
          (struct.get $type33 1
           (local.get $6)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $11
            (i64.sub
             (local.get $11)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $6)
           )
          )
          (else
           (local.set $6
            (struct.get $type33 1
             (local.get $6)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $11
              (i64.sub
               (local.get $11)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $6)
             )
            )
            (else
             (local.set $6
              (struct.get $type33 1
               (local.get $6)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $11
                (i64.sub
                 (local.get $11)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $6)
               )
              )
              (else
               (local.set $6
                (struct.get $type33 1
                 (local.get $6)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $11
                  (i64.sub
                   (local.get $11)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $6)
                 )
                )
                (else
                 (local.set $6
                  (struct.get $type33 1
                   (local.get $6)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $11
                    (i64.sub
                     (local.get $11)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $6)
                   )
                  )
                  (else
                   (local.set $6
                    (struct.get $type33 1
                     (local.get $6)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $11
                      (i64.sub
                       (local.get $11)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $6)
                     )
                    )
                    (else
                     (call $function82
                      (struct.get $type33 1
                       (local.get $6)
                      )
                      (block (result i64)
                       (if
                        (i32.eqz
                         (global.get $ready238)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global238)
                        )
                       )
                       (i64.sub
                        (local.get $11)
                        (i64.const 1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready203)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global203)
   )
  )
  (if (result (ref null $type33))
   (call $function46
    (if (result (ref $type29))
     (i64.eqz
      (local.tee $11
       (struct.get $type31 1
        (local.get $9)
       )
      )
     )
     (then
      (struct.get $type28 0
       (local.get $4)
      )
     )
     (else
      (local.set $4
       (struct.get $type28 1
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (global.get $ready203)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (local.tee $12
         (i64.sub
          (local.get $11)
          (i64.const 1)
         )
        )
       )
       (then
        (struct.get $type28 0
         (local.get $4)
        )
       )
       (else
        (local.set $4
         (struct.get $type28 1
          (local.get $4)
         )
        )
        (if
         (i32.eqz
          (global.get $ready203)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global203)
         )
        )
        (if (result (ref $type29))
         (i64.eqz
          (local.tee $12
           (i64.sub
            (local.get $12)
            (i64.const 1)
           )
          )
         )
         (then
          (struct.get $type28 0
           (local.get $4)
          )
         )
         (else
          (local.set $4
           (struct.get $type28 1
            (local.get $4)
           )
          )
          (if
           (i32.eqz
            (global.get $ready203)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global203)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (local.tee $12
             (i64.sub
              (local.get $12)
              (i64.const 1)
             )
            )
           )
           (then
            (struct.get $type28 0
             (local.get $4)
            )
           )
           (else
            (local.set $4
             (struct.get $type28 1
              (local.get $4)
             )
            )
            (if
             (i32.eqz
              (global.get $ready203)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global203)
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (local.tee $12
               (i64.sub
                (local.get $12)
                (i64.const 1)
               )
              )
             )
             (then
              (struct.get $type28 0
               (local.get $4)
              )
             )
             (else
              (local.set $4
               (struct.get $type28 1
                (local.get $4)
               )
              )
              (if
               (i32.eqz
                (global.get $ready203)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global203)
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (local.tee $12
                 (i64.sub
                  (local.get $12)
                  (i64.const 1)
                 )
                )
               )
               (then
                (struct.get $type28 0
                 (local.get $4)
                )
               )
               (else
                (local.set $4
                 (struct.get $type28 1
                  (local.get $4)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready203)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global203)
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (local.tee $12
                   (i64.sub
                    (local.get $12)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (struct.get $type28 0
                   (local.get $4)
                  )
                 )
                 (else
                  (local.set $4
                   (struct.get $type28 1
                    (local.get $4)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready203)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global203)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (local.tee $12
                     (i64.sub
                      (local.get $12)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (struct.get $type28 0
                     (local.get $4)
                    )
                   )
                   (else
                    (local.set $4
                     (struct.get $type28 1
                      (local.get $4)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready203)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global203)
                     )
                    )
                    (if (result (ref $type29))
                     (i64.eqz
                      (local.tee $12
                       (i64.sub
                        (local.get $12)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (struct.get $type28 0
                       (local.get $4)
                      )
                     )
                     (else
                      (call $function73
                       (struct.get $type28 1
                        (local.get $4)
                       )
                       (block (result i64)
                        (if
                         (i32.eqz
                          (global.get $ready203)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global203)
                         )
                        )
                        (i64.sub
                         (local.get $12)
                         (i64.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (block (result (ref $type29))
     (if
      (i32.eqz
       (global.get $ready129)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global129)
      )
     )
     (local.get $3)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready269)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global269)
     )
    )
    (if
     (i32.eqz
      (global.get $ready238)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global238)
     )
    )
    (local.set $4
     (if (result (ref null $type28))
      (i64.eqz
       (local.get $13)
      )
      (then
       (struct.get $type33 0
        (local.get $0)
       )
      )
      (else
       (local.set $6
        (struct.get $type33 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready238)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global238)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.tee $12
          (i64.sub
           (local.get $13)
           (i64.const 1)
          )
         )
        )
        (then
         (struct.get $type33 0
          (local.get $6)
         )
        )
        (else
         (local.set $6
          (struct.get $type33 1
           (local.get $6)
          )
         )
         (if
          (i32.eqz
           (global.get $ready238)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global238)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.tee $12
            (i64.sub
             (local.get $12)
             (i64.const 1)
            )
           )
          )
          (then
           (struct.get $type33 0
            (local.get $6)
           )
          )
          (else
           (local.set $6
            (struct.get $type33 1
             (local.get $6)
            )
           )
           (if
            (i32.eqz
             (global.get $ready238)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global238)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.tee $12
              (i64.sub
               (local.get $12)
               (i64.const 1)
              )
             )
            )
            (then
             (struct.get $type33 0
              (local.get $6)
             )
            )
            (else
             (local.set $6
              (struct.get $type33 1
               (local.get $6)
              )
             )
             (if
              (i32.eqz
               (global.get $ready238)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global238)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.tee $12
                (i64.sub
                 (local.get $12)
                 (i64.const 1)
                )
               )
              )
              (then
               (struct.get $type33 0
                (local.get $6)
               )
              )
              (else
               (local.set $6
                (struct.get $type33 1
                 (local.get $6)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready238)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global238)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.tee $12
                  (i64.sub
                   (local.get $12)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (struct.get $type33 0
                  (local.get $6)
                 )
                )
                (else
                 (local.set $6
                  (struct.get $type33 1
                   (local.get $6)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready238)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global238)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.tee $12
                    (i64.sub
                     (local.get $12)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $6)
                   )
                  )
                  (else
                   (local.set $6
                    (struct.get $type33 1
                     (local.get $6)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready238)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global238)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.tee $12
                      (i64.sub
                       (local.get $12)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $6)
                     )
                    )
                    (else
                     (local.set $6
                      (struct.get $type33 1
                       (local.get $6)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready238)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global238)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.tee $12
                        (i64.sub
                         (local.get $12)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (struct.get $type33 0
                        (local.get $6)
                       )
                      )
                      (else
                       (call $function82
                        (struct.get $type33 1
                         (local.get $6)
                        )
                        (block (result i64)
                         (if
                          (i32.eqz
                           (global.get $ready238)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global238)
                          )
                         )
                         (i64.sub
                          (local.get $12)
                          (i64.const 1)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready274)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global274)
     )
    )
    (local.set $8
     (if (result (ref $type28))
      (i64.eqz
       (local.get $11)
      )
      (then
       (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
        (local.get $2)
        (struct.get $type28 1
         (local.get $4)
        )
       ))
      )
      (else
       (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
        (struct.get $type28 0
         (local.get $4)
        )
        (block (result (ref $type28))
         (local.set $4
          (struct.get $type28 1
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (global.get $ready274)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global274)
          )
         )
         (if (result (ref $type28))
          (i64.eqz
           (local.tee $11
            (i64.sub
             (local.get $11)
             (i64.const 1)
            )
           )
          )
          (then
           (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
            (local.get $2)
            (struct.get $type28 1
             (local.get $4)
            )
           ))
          )
          (else
           (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
            (struct.get $type28 0
             (local.get $4)
            )
            (block (result (ref $type28))
             (local.set $4
              (struct.get $type28 1
               (local.get $4)
              )
             )
             (if
              (i32.eqz
               (global.get $ready274)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global274)
              )
             )
             (if (result (ref $type28))
              (i64.eqz
               (local.tee $11
                (i64.sub
                 (local.get $11)
                 (i64.const 1)
                )
               )
              )
              (then
               (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                (local.get $2)
                (struct.get $type28 1
                 (local.get $4)
                )
               ))
              )
              (else
               (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                (struct.get $type28 0
                 (local.get $4)
                )
                (block (result (ref $type28))
                 (local.set $4
                  (struct.get $type28 1
                   (local.get $4)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready274)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global274)
                  )
                 )
                 (if (result (ref $type28))
                  (i64.eqz
                   (local.tee $11
                    (i64.sub
                     (local.get $11)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                    (local.get $2)
                    (struct.get $type28 1
                     (local.get $4)
                    )
                   ))
                  )
                  (else
                   (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                    (struct.get $type28 0
                     (local.get $4)
                    )
                    (block (result (ref $type28))
                     (local.set $4
                      (struct.get $type28 1
                       (local.get $4)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready274)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global274)
                      )
                     )
                     (if (result (ref $type28))
                      (i64.eqz
                       (local.tee $11
                        (i64.sub
                         (local.get $11)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                        (local.get $2)
                        (struct.get $type28 1
                         (local.get $4)
                        )
                       ))
                      )
                      (else
                       (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                        (struct.get $type28 0
                         (local.get $4)
                        )
                        (block (result (ref $type28))
                         (local.set $4
                          (struct.get $type28 1
                           (local.get $4)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready274)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global274)
                          )
                         )
                         (if (result (ref $type28))
                          (i64.eqz
                           (local.tee $11
                            (i64.sub
                             (local.get $11)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                            (local.get $2)
                            (struct.get $type28 1
                             (local.get $4)
                            )
                           ))
                          )
                          (else
                           (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                            (struct.get $type28 0
                             (local.get $4)
                            )
                            (block (result (ref $type28))
                             (local.set $4
                              (struct.get $type28 1
                               (local.get $4)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready274)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global274)
                              )
                             )
                             (if (result (ref $type28))
                              (i64.eqz
                               (local.tee $11
                                (i64.sub
                                 (local.get $11)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                                (local.get $2)
                                (struct.get $type28 1
                                 (local.get $4)
                                )
                               ))
                              )
                              (else
                               (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                                (struct.get $type28 0
                                 (local.get $4)
                                )
                                (block (result (ref $type28))
                                 (local.set $4
                                  (struct.get $type28 1
                                   (local.get $4)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready274)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global274)
                                  )
                                 )
                                 (if (result (ref $type28))
                                  (i64.eqz
                                   (local.tee $11
                                    (i64.sub
                                     (local.get $11)
                                     (i64.const 1)
                                    )
                                   )
                                  )
                                  (then
                                   (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                                    (local.get $2)
                                    (struct.get $type28 1
                                     (local.get $4)
                                    )
                                   ))
                                  )
                                  (else
                                   (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                                    (struct.get $type28 0
                                     (local.get $4)
                                    )
                                    (block (result (ref $type28))
                                     (local.set $4
                                      (struct.get $type28 1
                                       (local.get $4)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready274)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global274)
                                      )
                                     )
                                     (if (result (ref $type28))
                                      (i64.eqz
                                       (local.tee $11
                                        (i64.sub
                                         (local.get $11)
                                         (i64.const 1)
                                        )
                                       )
                                      )
                                      (then
                                       (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                                        (local.get $2)
                                        (struct.get $type28 1
                                         (local.get $4)
                                        )
                                       ))
                                      )
                                      (else
                                       (block (result (ref $type28)) (global.set $observed80 (i64.add (global.get $observed80) (i64.const 1))) (struct.new $type28
                                        (struct.get $type28 0
                                         (local.get $4)
                                        )
                                        (call $function91
                                         (struct.get $type28 1
                                          (local.get $4)
                                         )
                                         (block (result i64)
                                          (if
                                           (i32.eqz
                                            (global.get $ready274)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global274)
                                           )
                                          )
                                          (i64.sub
                                           (local.get $11)
                                           (i64.const 1)
                                          )
                                         )
                                         (local.get $2)
                                        )
                                       ))
                                      )
                                     )
                                    )
                                   ))
                                  )
                                 )
                                )
                               ))
                              )
                             )
                            )
                           ))
                          )
                         )
                        )
                       ))
                      )
                     )
                    )
                   ))
                  )
                 )
                )
               ))
              )
             )
            )
           ))
          )
         )
        )
       ))
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready278)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global278)
     )
    )
    (local.set $10
     (if (result (ref $type33))
      (i64.eqz
       (local.get $13)
      )
      (then
       (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
        (local.get $8)
        (struct.get $type33 1
         (local.get $0)
        )
       ))
      )
      (else
       (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
        (struct.get $type33 0
         (local.get $0)
        )
        (block (result (ref $type33))
         (local.set $6
          (struct.get $type33 1
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready278)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global278)
          )
         )
         (if (result (ref $type33))
          (i64.eqz
           (local.tee $13
            (i64.sub
             (local.get $13)
             (i64.const 1)
            )
           )
          )
          (then
           (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
            (local.get $8)
            (struct.get $type33 1
             (local.get $6)
            )
           ))
          )
          (else
           (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
            (struct.get $type33 0
             (local.get $6)
            )
            (block (result (ref $type33))
             (local.set $6
              (struct.get $type33 1
               (local.get $6)
              )
             )
             (if
              (i32.eqz
               (global.get $ready278)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global278)
              )
             )
             (if (result (ref $type33))
              (i64.eqz
               (local.tee $13
                (i64.sub
                 (local.get $13)
                 (i64.const 1)
                )
               )
              )
              (then
               (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                (local.get $8)
                (struct.get $type33 1
                 (local.get $6)
                )
               ))
              )
              (else
               (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                (struct.get $type33 0
                 (local.get $6)
                )
                (block (result (ref $type33))
                 (local.set $6
                  (struct.get $type33 1
                   (local.get $6)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready278)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global278)
                  )
                 )
                 (if (result (ref $type33))
                  (i64.eqz
                   (local.tee $13
                    (i64.sub
                     (local.get $13)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                    (local.get $8)
                    (struct.get $type33 1
                     (local.get $6)
                    )
                   ))
                  )
                  (else
                   (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                    (struct.get $type33 0
                     (local.get $6)
                    )
                    (block (result (ref $type33))
                     (local.set $6
                      (struct.get $type33 1
                       (local.get $6)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready278)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global278)
                      )
                     )
                     (if (result (ref $type33))
                      (i64.eqz
                       (local.tee $13
                        (i64.sub
                         (local.get $13)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                        (local.get $8)
                        (struct.get $type33 1
                         (local.get $6)
                        )
                       ))
                      )
                      (else
                       (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                        (struct.get $type33 0
                         (local.get $6)
                        )
                        (block (result (ref $type33))
                         (local.set $6
                          (struct.get $type33 1
                           (local.get $6)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready278)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global278)
                          )
                         )
                         (if (result (ref $type33))
                          (i64.eqz
                           (local.tee $13
                            (i64.sub
                             (local.get $13)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                            (local.get $8)
                            (struct.get $type33 1
                             (local.get $6)
                            )
                           ))
                          )
                          (else
                           (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                            (struct.get $type33 0
                             (local.get $6)
                            )
                            (block (result (ref $type33))
                             (local.set $6
                              (struct.get $type33 1
                               (local.get $6)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready278)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global278)
                              )
                             )
                             (if (result (ref $type33))
                              (i64.eqz
                               (local.tee $13
                                (i64.sub
                                 (local.get $13)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                                (local.get $8)
                                (struct.get $type33 1
                                 (local.get $6)
                                )
                               ))
                              )
                              (else
                               (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                                (struct.get $type33 0
                                 (local.get $6)
                                )
                                (block (result (ref $type33))
                                 (local.set $6
                                  (struct.get $type33 1
                                   (local.get $6)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready278)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global278)
                                  )
                                 )
                                 (if (result (ref $type33))
                                  (i64.eqz
                                   (local.tee $13
                                    (i64.sub
                                     (local.get $13)
                                     (i64.const 1)
                                    )
                                   )
                                  )
                                  (then
                                   (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                                    (local.get $8)
                                    (struct.get $type33 1
                                     (local.get $6)
                                    )
                                   ))
                                  )
                                  (else
                                   (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                                    (struct.get $type33 0
                                     (local.get $6)
                                    )
                                    (block (result (ref $type33))
                                     (local.set $6
                                      (struct.get $type33 1
                                       (local.get $6)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready278)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global278)
                                      )
                                     )
                                     (if (result (ref $type33))
                                      (i64.eqz
                                       (local.tee $13
                                        (i64.sub
                                         (local.get $13)
                                         (i64.const 1)
                                        )
                                       )
                                      )
                                      (then
                                       (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                                        (local.get $8)
                                        (struct.get $type33 1
                                         (local.get $6)
                                        )
                                       ))
                                      )
                                      (else
                                       (block (result (ref $type33)) (global.set $observed81 (i64.add (global.get $observed81) (i64.const 1))) (struct.new $type33
                                        (struct.get $type33 0
                                         (local.get $6)
                                        )
                                        (call $function92
                                         (struct.get $type33 1
                                          (local.get $6)
                                         )
                                         (block (result i64)
                                          (if
                                           (i32.eqz
                                            (global.get $ready278)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global278)
                                           )
                                          )
                                          (i64.sub
                                           (local.get $13)
                                           (i64.const 1)
                                          )
                                         )
                                         (local.get $8)
                                        )
                                       ))
                                      )
                                     )
                                    )
                                   ))
                                  )
                                 )
                                )
                               ))
                              )
                             )
                            )
                           ))
                          )
                         )
                        )
                       ))
                      )
                     )
                    )
                   ))
                  )
                 )
                )
               ))
              )
             )
            )
           ))
          )
         )
        )
       ))
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready219)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global219)
     )
    )
    (local.set $5
     (call $function77
      (local.get $9)
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready282)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global282)
     )
    )
    (if (result (ref null $type33))
     (ref.is_null
      (local.get $5)
     )
     (then
      (local.get $10)
     )
     (else
      (local.set $0
       (call_ref $call61
        (struct.get $type61 1
         (local.tee $7
          (block (result (ref $type61)) (global.set $observed82 (i64.add (global.get $observed82) (i64.const 1))) (struct.new $type61
           (ref.func $function89)
           (block (result (ref $environment89)) (global.set $observed83 (i64.add (global.get $observed83) (i64.const 1))) (struct.new $environment89
            (local.get $2)
            (local.get $3)
           ))
          ))
         )
        )
        (local.get $10)
        (struct.get $type28 0
         (local.get $5)
        )
        (struct.get $type61 0
         (local.get $7)
        )
       )
      )
      (if (result (ref null $type33))
       (ref.is_null
        (local.tee $4
         (struct.get $type28 1
          (local.get $5)
         )
        )
       )
       (then
        (local.get $0)
       )
       (else
        (local.set $0
         (call_ref $call61
          (struct.get $type61 1
           (local.get $7)
          )
          (local.get $0)
          (struct.get $type28 0
           (local.get $4)
          )
          (struct.get $type61 0
           (local.get $7)
          )
         )
        )
        (if (result (ref null $type33))
         (ref.is_null
          (local.tee $4
           (struct.get $type28 1
            (local.get $4)
           )
          )
         )
         (then
          (local.get $0)
         )
         (else
          (local.set $0
           (call_ref $call61
            (struct.get $type61 1
             (local.get $7)
            )
            (local.get $0)
            (struct.get $type28 0
             (local.get $4)
            )
            (struct.get $type61 0
             (local.get $7)
            )
           )
          )
          (if (result (ref null $type33))
           (ref.is_null
            (local.tee $4
             (struct.get $type28 1
              (local.get $4)
             )
            )
           )
           (then
            (local.get $0)
           )
           (else
            (local.set $0
             (call_ref $call61
              (struct.get $type61 1
               (local.get $7)
              )
              (local.get $0)
              (struct.get $type28 0
               (local.get $4)
              )
              (struct.get $type61 0
               (local.get $7)
              )
             )
            )
            (if (result (ref null $type33))
             (ref.is_null
              (local.tee $4
               (struct.get $type28 1
                (local.get $4)
               )
              )
             )
             (then
              (local.get $0)
             )
             (else
              (local.set $0
               (call_ref $call61
                (struct.get $type61 1
                 (local.get $7)
                )
                (local.get $0)
                (struct.get $type28 0
                 (local.get $4)
                )
                (struct.get $type61 0
                 (local.get $7)
                )
               )
              )
              (if (result (ref null $type33))
               (ref.is_null
                (local.tee $4
                 (struct.get $type28 1
                  (local.get $4)
                 )
                )
               )
               (then
                (local.get $0)
               )
               (else
                (local.set $0
                 (call_ref $call61
                  (struct.get $type61 1
                   (local.get $7)
                  )
                  (local.get $0)
                  (struct.get $type28 0
                   (local.get $4)
                  )
                  (struct.get $type61 0
                   (local.get $7)
                  )
                 )
                )
                (if (result (ref null $type33))
                 (ref.is_null
                  (local.tee $4
                   (struct.get $type28 1
                    (local.get $4)
                   )
                  )
                 )
                 (then
                  (local.get $0)
                 )
                 (else
                  (local.set $0
                   (call_ref $call61
                    (struct.get $type61 1
                     (local.get $7)
                    )
                    (local.get $0)
                    (struct.get $type28 0
                     (local.get $4)
                    )
                    (struct.get $type61 0
                     (local.get $7)
                    )
                   )
                  )
                  (if (result (ref null $type33))
                   (ref.is_null
                    (local.tee $4
                     (struct.get $type28 1
                      (local.get $4)
                     )
                    )
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (local.set $0
                     (call_ref $call61
                      (struct.get $type61 1
                       (local.get $7)
                      )
                      (local.get $0)
                      (struct.get $type28 0
                       (local.get $4)
                      )
                      (struct.get $type61 0
                       (local.get $7)
                      )
                     )
                    )
                    (if (result (ref null $type33))
                     (ref.is_null
                      (local.tee $4
                       (struct.get $type28 1
                        (local.get $4)
                       )
                      )
                     )
                     (then
                      (local.get $0)
                     )
                     (else
                      (return_call $function94
                       (local.get $7)
                       (i32.const 0)
                       (i32.const 1)
                       (call_ref $call61
                        (struct.get $type61 1
                         (local.get $7)
                        )
                        (local.get $0)
                        (struct.get $type28 0
                         (local.get $4)
                        )
                        (struct.get $type61 0
                         (local.get $7)
                        )
                       )
                       (struct.get $type28 1
                        (local.get $4)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (local.get $0)
   )
  )
 )
 (func $function89 (type $call61) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 (ref $type29)) (result (ref null $type33))
  (local $3 (ref $environment89))
  (local $4 (ref $type29))
  (global.set $observed30 (i64.add (global.get $observed30) (i64.const 1)))
  (local.set $4
   (struct.get $environment89 0
    (local.tee $3
     (ref.cast (ref $environment89)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready259)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global259)
   )
  )
  (return_call $function88
   (local.get $1)
   (local.get $2)
   (local.get $4)
   (struct.get $environment89 1
    (local.get $3)
   )
  )
 )
 (func $function91 (type $call69) (param $0 (ref null $type28)) (param $1 i64) (param $2 (ref $type29)) (result (ref $type28))
  (local $3 (ref $type29))
  (global.set $observed31 (i64.add (global.get $observed31) (i64.const 1)))
  (if (result (ref $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (block (result (ref $type28)) (global.set $observed84 (i64.add (global.get $observed84) (i64.const 1))) (struct.new $type28
     (local.get $2)
     (struct.get $type28 1
      (local.get $0)
     )
    ))
   )
   (else
    (block (result (ref $type28)) (global.set $observed84 (i64.add (global.get $observed84) (i64.const 1))) (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (call $function91
      (struct.get $type28 1
       (local.get $0)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready274)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global274)
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (local.get $2)
     )
    ))
   )
  )
 )
 (func $function92 (type $call70) (param $0 (ref null $type33)) (param $1 i64) (param $2 (ref null $type28)) (result (ref $type33))
  (local $3 (ref null $type28))
  (global.set $observed32 (i64.add (global.get $observed32) (i64.const 1)))
  (if (result (ref $type33))
   (i64.eqz
    (local.get $1)
   )
   (then
    (block (result (ref $type33)) (global.set $observed85 (i64.add (global.get $observed85) (i64.const 1))) (struct.new $type33
     (local.get $2)
     (struct.get $type33 1
      (local.get $0)
     )
    ))
   )
   (else
    (block (result (ref $type33)) (global.set $observed85 (i64.add (global.get $observed85) (i64.const 1))) (struct.new $type33
     (struct.get $type33 0
      (local.get $0)
     )
     (call $function92
      (struct.get $type33 1
       (local.get $0)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready278)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global278)
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (local.get $2)
     )
    ))
   )
  )
 )
 (func $function94 (type $10) (param $0 (ref $type61)) (param $1 i32) (param $2 i32) (param $3 (ref null $type33)) (param $4 (ref null $type28)) (result (ref null $type33))
  (global.set $observed33 (i64.add (global.get $observed33) (i64.const 1)))
  (if (result (ref null $type33))
   (ref.is_null
    (local.get $4)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $3
     (call_ref $call61
      (struct.get $type61 1
       (local.get $0)
      )
      (local.get $3)
      (struct.get $type28 0
       (local.get $4)
      )
      (struct.get $type61 0
       (local.get $0)
      )
     )
    )
    (local.set $4
     (struct.get $type28 1
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function94
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function98 (type $call54) (param $0 (ref $environment98)) (param $1 (ref null $type28)) (result (ref null $type40))
  (local $2 i32)
  (local $3 (ref $type29))
  (local $4 (ref $type34))
  (global.set $observed34 (i64.add (global.get $observed34) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready300)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global300)
   )
  )
  (if (result (ref null $type40))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
     (if (result i32)
      (ref.test (ref $type30)
       (local.tee $3
        (struct.get $type28 0
         (local.get $1)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type31)
         (local.get $3)
        )
       )
       (i32.const 1)
      )
     )
     (block (result (ref null $type40))
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready300)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $environment98 0
        (local.get $0)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global300)
       )
      )
      (if (result (ref null $type40))
       (ref.is_null
        (local.get $1)
       )
       (then
        (ref.null none)
       )
       (else
        (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
         (if (result i32)
          (ref.test (ref $type30)
           (local.tee $3
            (struct.get $type28 0
             (local.get $1)
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.cast (ref $type31)
             (local.get $3)
            )
           )
           (i32.const 1)
          )
         )
         (block (result (ref null $type40))
          (local.set $1
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready300)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global300)
           )
          )
          (if (result (ref null $type40))
           (ref.is_null
            (local.get $1)
           )
           (then
            (ref.null none)
           )
           (else
            (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
             (if (result i32)
              (ref.test (ref $type30)
               (local.tee $3
                (struct.get $type28 0
                 (local.get $1)
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.cast (ref $type31)
                 (local.get $3)
                )
               )
               (i32.const 1)
              )
             )
             (block (result (ref null $type40))
              (local.set $1
               (struct.get $type28 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready300)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global300)
               )
              )
              (if (result (ref null $type40))
               (ref.is_null
                (local.get $1)
               )
               (then
                (ref.null none)
               )
               (else
                (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
                 (if (result i32)
                  (ref.test (ref $type30)
                   (local.tee $3
                    (struct.get $type28 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type31)
                     (local.get $3)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (block (result (ref null $type40))
                  (local.set $1
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready300)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global300)
                   )
                  )
                  (if (result (ref null $type40))
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
                     (if (result i32)
                      (ref.test (ref $type30)
                       (local.tee $3
                        (struct.get $type28 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (ref.cast (ref $type31)
                         (local.get $3)
                        )
                       )
                       (i32.const 1)
                      )
                     )
                     (block (result (ref null $type40))
                      (local.set $1
                       (struct.get $type28 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready300)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global300)
                       )
                      )
                      (if (result (ref null $type40))
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
                         (if (result i32)
                          (ref.test (ref $type30)
                           (local.tee $3
                            (struct.get $type28 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (ref.cast (ref $type31)
                             (local.get $3)
                            )
                           )
                           (i32.const 1)
                          )
                         )
                         (block (result (ref null $type40))
                          (local.set $1
                           (struct.get $type28 1
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready300)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global300)
                           )
                          )
                          (if (result (ref null $type40))
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
                             (if (result i32)
                              (ref.test (ref $type30)
                               (local.tee $3
                                (struct.get $type28 0
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (ref.cast (ref $type31)
                                 (local.get $3)
                                )
                               )
                               (i32.const 1)
                              )
                             )
                             (block (result (ref null $type40))
                              (local.set $1
                               (struct.get $type28 1
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready300)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global300)
                               )
                              )
                              (if (result (ref null $type40))
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
                                 (if (result i32)
                                  (ref.test (ref $type30)
                                   (local.tee $3
                                    (struct.get $type28 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (drop
                                    (ref.cast (ref $type31)
                                     (local.get $3)
                                    )
                                   )
                                   (i32.const 1)
                                  )
                                 )
                                 (block (result (ref null $type40))
                                  (local.set $1
                                   (struct.get $type28 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready300)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global300)
                                   )
                                  )
                                  (if (result (ref null $type40))
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                   (then
                                    (ref.null none)
                                   )
                                   (else
                                    (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
                                     (if (result i32)
                                      (ref.test (ref $type30)
                                       (local.tee $3
                                        (struct.get $type28 0
                                         (local.get $1)
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (drop
                                        (ref.cast (ref $type31)
                                         (local.get $3)
                                        )
                                       )
                                       (i32.const 1)
                                      )
                                     )
                                     (block (result (ref null $type40))
                                      (local.set $1
                                       (struct.get $type28 1
                                        (local.get $1)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready300)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global300)
                                       )
                                      )
                                      (if (result (ref null $type40))
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                       (then
                                        (ref.null none)
                                       )
                                       (else
                                        (block (result (ref $type40)) (global.set $observed86 (i64.add (global.get $observed86) (i64.const 1))) (struct.new $type40
                                         (call $function41
                                          (struct.get $type28 0
                                           (local.get $1)
                                          )
                                         )
                                         (block (result (ref null $type40))
                                          (local.set $1
                                           (struct.get $type28 1
                                            (local.get $1)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready300)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global300)
                                           )
                                          )
                                          (call $function99
                                           (local.get $4)
                                           (local.get $1)
                                          )
                                         )
                                        ))
                                       )
                                      )
                                     )
                                    ))
                                   )
                                  )
                                 )
                                ))
                               )
                              )
                             )
                            ))
                           )
                          )
                         )
                        ))
                       )
                      )
                     )
                    ))
                   )
                  )
                 )
                ))
               )
              )
             )
            ))
           )
          )
         )
        ))
       )
      )
     )
    ))
   )
  )
 )
 (func $function99 (type $call52) (param $0 (ref $type34)) (param $1 (ref null $type28)) (result (ref null $type40))
  (local $2 i32)
  (global.set $observed35 (i64.add (global.get $observed35) (i64.const 1)))
  (if (result (ref null $type40))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (block (result (ref $type40)) (global.set $observed87 (i64.add (global.get $observed87) (i64.const 1))) (struct.new $type40
     (call $function41
      (struct.get $type28 0
       (local.get $1)
      )
     )
     (block (result (ref null $type40))
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready300)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global300)
       )
      )
      (call $function99
       (local.get $0)
       (local.get $1)
      )
     )
    ))
   )
  )
 )
 (func $function100 (type $call53) (param $0 (ref $type54)) (param $1 (ref null $type33)) (result (ref null $type39))
  (local $2 (ref null $type40))
  (global.set $observed36 (i64.add (global.get $observed36) (i64.const 1)))
  (if (result (ref null $type39))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (block (result (ref $type39)) (global.set $observed88 (i64.add (global.get $observed88) (i64.const 1))) (struct.new $type39
     (call $function98
      (struct.get $type54 0
       (local.get $0)
      )
      (struct.get $type33 0
       (local.get $1)
      )
     )
     (block (result (ref null $type39))
      (local.set $1
       (struct.get $type33 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready304)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global304)
       )
      )
      (call $function100
       (local.get $0)
       (local.get $1)
      )
     )
    ))
   )
  )
 )
 (func $function101 (type $call5) (result i64)
  (local $0 i64)
  (local $1 (ref $type89))
  (local $scratch i64)
  (global.set $observed37 (i64.add (global.get $observed37) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready308)
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch
   (call $foreign0
    (struct.get $type89 0
     (global.get $global308)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready308)
   )
   (then
    (unreachable)
   )
  )
  (block (global.set $observed89 (i64.add (global.get $observed89) (i64.const 1))) (struct.set $type89 0
   (ref.as_non_null
    (global.get $global308)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready308)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (struct.get $type89 0
      (global.get $global308)
     )
     (i64.const 1)
    )
   )
  ))
  (local.get $scratch)
 )
 (func $function102 (type $call92) (result (ref $type35))
  (local $0 i64)
  (local $1 i64)
  (local $2 (ref $type89))
  (local $3 (ref null $type40))
  (local $scratch i64)
  (local $scratch_5 i64)
  (local $scratch_6 i64)
  (local $scratch_7 i64)
  (local $scratch_8 i64)
  (local $scratch_9 i64)
  (local $scratch_10 i64)
  (local $scratch_11 i64)
  (local $scratch_12 i64)
  (local $scratch_13 i64)
  (global.set $observed38 (i64.add (global.get $observed38) (i64.const 1)))
  (if
   (i32.eqz
    (global.get $ready309)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global309)
   )
  )
  (if
   (i32.eqz
    (global.get $ready308)
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (call $foreign0
    (struct.get $type89 0
     (global.get $global308)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready308)
   )
   (then
    (unreachable)
   )
  )
  (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
   (ref.as_non_null
    (global.get $global308)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready308)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (struct.get $type89 0
      (global.get $global308)
     )
     (i64.const 1)
    )
   )
  ))
  (if (result (ref $type35))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready115)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (global.get $global115)
    )
   )
   (else
    (if (result (ref $type35))
     (i64.eq
      (local.get $0)
      (i64.const 1)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready116)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (global.get $global116)
      )
     )
     (else
      (if (result (ref $type35))
       (i64.eq
        (local.get $0)
        (i64.const 2)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready309)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global309)
         )
        )
        (if
         (i32.eqz
          (global.get $ready308)
         )
         (then
          (unreachable)
         )
        )
        (local.set $0
         (call $foreign0
          (struct.get $type89 0
           (global.get $global308)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready308)
         )
         (then
          (unreachable)
         )
        )
        (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
         (ref.as_non_null
          (global.get $global308)
         )
         (block (result i64)
          (if
           (i32.eqz
            (global.get $ready308)
           )
           (then
            (unreachable)
           )
          )
          (i64.add
           (struct.get $type89 0
            (global.get $global308)
           )
           (i64.const 1)
          )
         )
        ))
        (if
         (i32.eqz
          (global.get $ready313)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global313)
         )
        )
        (block (result (ref $type38)) (global.set $observed91 (i64.add (global.get $observed91) (i64.const 1))) (struct.new $type38
         (i32.const 2)
         (if (result (ref null $type39))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready309)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global309)
            )
           )
           (if
            (i32.eqz
             (global.get $ready308)
            )
            (then
             (unreachable)
            )
           )
           (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
            (call $function104
             (block (result i64)
              (local.set $scratch
               (call $foreign0
                (struct.get $type89 0
                 (global.get $global308)
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready308)
               )
               (then
                (unreachable)
               )
              )
              (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
               (ref.as_non_null
                (global.get $global308)
               )
               (block (result i64)
                (if
                 (i32.eqz
                  (global.get $ready308)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i64.add
                 (struct.get $type89 0
                  (global.get $global308)
                 )
                 (i64.const 1)
                )
               )
              ))
              (if
               (i32.eqz
                (global.get $ready316)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global316)
               )
              )
              (local.get $scratch)
             )
            )
            (block (result (ref null $type39))
             (if
              (i32.eqz
               (global.get $ready313)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global313)
              )
             )
             (if (result (ref null $type39))
              (i64.eqz
               (local.tee $0
                (i64.sub
                 (local.get $0)
                 (i64.const 1)
                )
               )
              )
              (then
               (ref.null none)
              )
              (else
               (if
                (i32.eqz
                 (global.get $ready309)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global309)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready308)
                )
                (then
                 (unreachable)
                )
               )
               (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                (call $function104
                 (block (result i64)
                  (local.set $scratch_5
                   (call $foreign0
                    (struct.get $type89 0
                     (global.get $global308)
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready308)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                   (ref.as_non_null
                    (global.get $global308)
                   )
                   (block (result i64)
                    (if
                     (i32.eqz
                      (global.get $ready308)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i64.add
                     (struct.get $type89 0
                      (global.get $global308)
                     )
                     (i64.const 1)
                    )
                   )
                  ))
                  (if
                   (i32.eqz
                    (global.get $ready316)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global316)
                   )
                  )
                  (local.get $scratch_5)
                 )
                )
                (block (result (ref null $type39))
                 (if
                  (i32.eqz
                   (global.get $ready313)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global313)
                  )
                 )
                 (if (result (ref null $type39))
                  (i64.eqz
                   (local.tee $0
                    (i64.sub
                     (local.get $0)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready309)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global309)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready308)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                    (call $function104
                     (block (result i64)
                      (local.set $scratch_6
                       (call $foreign0
                        (struct.get $type89 0
                         (global.get $global308)
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready308)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                       (ref.as_non_null
                        (global.get $global308)
                       )
                       (block (result i64)
                        (if
                         (i32.eqz
                          (global.get $ready308)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (i64.add
                         (struct.get $type89 0
                          (global.get $global308)
                         )
                         (i64.const 1)
                        )
                       )
                      ))
                      (if
                       (i32.eqz
                        (global.get $ready316)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global316)
                       )
                      )
                      (local.get $scratch_6)
                     )
                    )
                    (block (result (ref null $type39))
                     (if
                      (i32.eqz
                       (global.get $ready313)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global313)
                      )
                     )
                     (if (result (ref null $type39))
                      (i64.eqz
                       (local.tee $0
                        (i64.sub
                         (local.get $0)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready309)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global309)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready308)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                        (call $function104
                         (block (result i64)
                          (local.set $scratch_7
                           (call $foreign0
                            (struct.get $type89 0
                             (global.get $global308)
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready308)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                           (ref.as_non_null
                            (global.get $global308)
                           )
                           (block (result i64)
                            (if
                             (i32.eqz
                              (global.get $ready308)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (i64.add
                             (struct.get $type89 0
                              (global.get $global308)
                             )
                             (i64.const 1)
                            )
                           )
                          ))
                          (if
                           (i32.eqz
                            (global.get $ready316)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global316)
                           )
                          )
                          (local.get $scratch_7)
                         )
                        )
                        (block (result (ref null $type39))
                         (if
                          (i32.eqz
                           (global.get $ready313)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global313)
                          )
                         )
                         (if (result (ref null $type39))
                          (i64.eqz
                           (local.tee $0
                            (i64.sub
                             (local.get $0)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (if
                            (i32.eqz
                             (global.get $ready309)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global309)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready308)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                            (call $function104
                             (block (result i64)
                              (local.set $scratch_8
                               (call $foreign0
                                (struct.get $type89 0
                                 (global.get $global308)
                                )
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready308)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                               (ref.as_non_null
                                (global.get $global308)
                               )
                               (block (result i64)
                                (if
                                 (i32.eqz
                                  (global.get $ready308)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (i64.add
                                 (struct.get $type89 0
                                  (global.get $global308)
                                 )
                                 (i64.const 1)
                                )
                               )
                              ))
                              (if
                               (i32.eqz
                                (global.get $ready316)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global316)
                               )
                              )
                              (local.get $scratch_8)
                             )
                            )
                            (block (result (ref null $type39))
                             (if
                              (i32.eqz
                               (global.get $ready313)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global313)
                              )
                             )
                             (if (result (ref null $type39))
                              (i64.eqz
                               (local.tee $0
                                (i64.sub
                                 (local.get $0)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (if
                                (i32.eqz
                                 (global.get $ready309)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global309)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready308)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                                (call $function104
                                 (block (result i64)
                                  (local.set $scratch_9
                                   (call $foreign0
                                    (struct.get $type89 0
                                     (global.get $global308)
                                    )
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready308)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                                   (ref.as_non_null
                                    (global.get $global308)
                                   )
                                   (block (result i64)
                                    (if
                                     (i32.eqz
                                      (global.get $ready308)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (i64.add
                                     (struct.get $type89 0
                                      (global.get $global308)
                                     )
                                     (i64.const 1)
                                    )
                                   )
                                  ))
                                  (if
                                   (i32.eqz
                                    (global.get $ready316)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global316)
                                   )
                                  )
                                  (local.get $scratch_9)
                                 )
                                )
                                (block (result (ref null $type39))
                                 (if
                                  (i32.eqz
                                   (global.get $ready313)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global313)
                                  )
                                 )
                                 (if (result (ref null $type39))
                                  (i64.eqz
                                   (local.tee $0
                                    (i64.sub
                                     (local.get $0)
                                     (i64.const 1)
                                    )
                                   )
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (if
                                    (i32.eqz
                                     (global.get $ready309)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global309)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready308)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                                    (call $function104
                                     (block (result i64)
                                      (local.set $scratch_10
                                       (call $foreign0
                                        (struct.get $type89 0
                                         (global.get $global308)
                                        )
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready308)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                                       (ref.as_non_null
                                        (global.get $global308)
                                       )
                                       (block (result i64)
                                        (if
                                         (i32.eqz
                                          (global.get $ready308)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (i64.add
                                         (struct.get $type89 0
                                          (global.get $global308)
                                         )
                                         (i64.const 1)
                                        )
                                       )
                                      ))
                                      (if
                                       (i32.eqz
                                        (global.get $ready316)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global316)
                                       )
                                      )
                                      (local.get $scratch_10)
                                     )
                                    )
                                    (block (result (ref null $type39))
                                     (if
                                      (i32.eqz
                                       (global.get $ready313)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global313)
                                      )
                                     )
                                     (if (result (ref null $type39))
                                      (i64.eqz
                                       (local.tee $0
                                        (i64.sub
                                         (local.get $0)
                                         (i64.const 1)
                                        )
                                       )
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (if
                                        (i32.eqz
                                         (global.get $ready309)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global309)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready308)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                                        (call $function104
                                         (block (result i64)
                                          (local.set $scratch_11
                                           (call $foreign0
                                            (struct.get $type89 0
                                             (global.get $global308)
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready308)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                                           (ref.as_non_null
                                            (global.get $global308)
                                           )
                                           (block (result i64)
                                            (if
                                             (i32.eqz
                                              (global.get $ready308)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (i64.add
                                             (struct.get $type89 0
                                              (global.get $global308)
                                             )
                                             (i64.const 1)
                                            )
                                           )
                                          ))
                                          (if
                                           (i32.eqz
                                            (global.get $ready316)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global316)
                                           )
                                          )
                                          (local.get $scratch_11)
                                         )
                                        )
                                        (block (result (ref null $type39))
                                         (if
                                          (i32.eqz
                                           (global.get $ready313)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global313)
                                          )
                                         )
                                         (if (result (ref null $type39))
                                          (i64.eqz
                                           (local.tee $0
                                            (i64.sub
                                             (local.get $0)
                                             (i64.const 1)
                                            )
                                           )
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (if
                                            (i32.eqz
                                             (global.get $ready309)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global309)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready308)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                                            (call $function104
                                             (block (result i64)
                                              (local.set $scratch_12
                                               (call $foreign0
                                                (struct.get $type89 0
                                                 (global.get $global308)
                                                )
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready308)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (block (global.set $observed90 (i64.add (global.get $observed90) (i64.const 1))) (struct.set $type89 0
                                               (ref.as_non_null
                                                (global.get $global308)
                                               )
                                               (block (result i64)
                                                (if
                                                 (i32.eqz
                                                  (global.get $ready308)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (i64.add
                                                 (struct.get $type89 0
                                                  (global.get $global308)
                                                 )
                                                 (i64.const 1)
                                                )
                                               )
                                              ))
                                              (if
                                               (i32.eqz
                                                (global.get $ready316)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global316)
                                               )
                                              )
                                              (local.get $scratch_12)
                                             )
                                            )
                                            (block (result (ref null $type39))
                                             (if
                                              (i32.eqz
                                               (global.get $ready313)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global313)
                                              )
                                             )
                                             (if (result (ref null $type39))
                                              (i64.eqz
                                               (local.tee $0
                                                (i64.sub
                                                 (local.get $0)
                                                 (i64.const 1)
                                                )
                                               )
                                              )
                                              (then
                                               (ref.null none)
                                              )
                                              (else
                                               (if
                                                (i32.eqz
                                                 (global.get $ready309)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global309)
                                                )
                                               )
                                               (block (result (ref $type39)) (global.set $observed92 (i64.add (global.get $observed92) (i64.const 1))) (struct.new $type39
                                                (call $function104
                                                 (block (result i64)
                                                  (local.set $scratch_13
                                                   (call $function101)
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready316)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global316)
                                                   )
                                                  )
                                                  (local.get $scratch_13)
                                                 )
                                                )
                                                (block (result (ref null $type39))
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready313)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global313)
                                                  )
                                                 )
                                                 (call $function103
                                                  (i64.sub
                                                   (local.get $0)
                                                   (i64.const 1)
                                                  )
                                                 )
                                                )
                                               ))
                                              )
                                             )
                                            )
                                           ))
                                          )
                                         )
                                        )
                                       ))
                                      )
                                     )
                                    )
                                   ))
                                  )
                                 )
                                )
                               ))
                              )
                             )
                            )
                           ))
                          )
                         )
                        )
                       ))
                      )
                     )
                    )
                   ))
                  )
                 )
                )
               ))
              )
             )
            )
           ))
          )
         )
        ))
       )
       (else
        (if
         (i32.eqz
          (global.get $ready117)
         )
         (then
          (unreachable)
         )
        )
        (ref.as_non_null
         (global.get $global117)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function103 (type $call91) (param $0 i64) (result (ref null $type39))
  (local $1 i64)
  (local $2 (ref null $type40))
  (local $scratch i64)
  (global.set $observed39 (i64.add (global.get $observed39) (i64.const 1)))
  (if (result (ref null $type39))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready309)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global309)
     )
    )
    (block (result (ref $type39)) (global.set $observed93 (i64.add (global.get $observed93) (i64.const 1))) (struct.new $type39
     (call $function104
      (block (result i64)
       (local.set $scratch
        (call $function101)
       )
       (if
        (i32.eqz
         (global.get $ready316)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global316)
        )
       )
       (local.get $scratch)
      )
     )
     (block (result (ref null $type39))
      (if
       (i32.eqz
        (global.get $ready313)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global313)
       )
      )
      (call $function103
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
    ))
   )
  )
 )
 (func $function104 (type $call90) (param $0 i64) (result (ref null $type40))
  (local $1 i64)
  (local $2 (ref $type89))
  (global.set $observed40 (i64.add (global.get $observed40) (i64.const 1)))
  (if (result (ref null $type40))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready309)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global309)
     )
    )
    (if
     (i32.eqz
      (global.get $ready308)
     )
     (then
      (unreachable)
     )
    )
    (block (result (ref $type40)) (global.set $observed94 (i64.add (global.get $observed94) (i64.const 1))) (struct.new $type40
     (i64.eq
      (call $foreign0
       (struct.get $type89 0
        (global.get $global308)
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready308)
        )
        (then
         (unreachable)
        )
       )
       (block (global.set $observed95 (i64.add (global.get $observed95) (i64.const 1))) (struct.set $type89 0
        (ref.as_non_null
         (global.get $global308)
        )
        (block (result i64)
         (if
          (i32.eqz
           (global.get $ready308)
          )
          (then
           (unreachable)
          )
         )
         (i64.add
          (struct.get $type89 0
           (global.get $global308)
          )
          (i64.const 1)
         )
        )
       ))
       (if
        (i32.eqz
         (global.get $ready316)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global316)
        )
       )
       (i64.const 1)
      )
     )
     (call $function104
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
     )
    ))
   )
  )
 )
 (func $function106 (type $2) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref $type35)) (result i64)
  (local $5 (ref $type35))
  (local $6 (ref null $type39))
  (local $7 (ref null $type39))
  (local $8 i64)
  (local $9 i64)
  (local $scratch i64)
  (local $scratch_11 (ref null $type39))
  (global.set $observed41 (i64.add (global.get $observed41) (i64.const 1)))
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready319)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready327)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (local.set $4
     (call $function53
      (call $foreign1
       (global.get $global319)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready320)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready327)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global327)
        )
       )
       (local.set $scratch
        (call $foreign1
         (global.get $global320)
        )
       )
       (if
        (i32.eqz
         (global.get $ready151)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global151)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function106
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready321)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (ref.as_non_null
      (global.get $global321)
     )
    )
    (if
     (i32.eqz
      (global.get $ready142)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global142)
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (local.set $0
     (if (result i64)
      (local.tee $1
       (struct.get $type35 0
        (local.get $4)
       )
      )
      (then
       (if (result i64)
        (i32.eq
         (local.get $1)
         (i32.const 1)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.eq
           (struct.get $type35 0
            (local.get $4)
           )
           (i32.const 2)
          )
          (then
           (drop
            (ref.cast (ref $type38)
             (local.get $4)
            )
           )
           (i64.const 2)
          )
          (else
           (i64.const 3)
          )
         )
        )
       )
      )
      (else
       (i64.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (i64.eq
        (if (result i64)
         (local.tee $1
          (struct.get $type35 0
           (local.get $5)
          )
         )
         (then
          (if (result i64)
           (i32.eq
            (local.get $1)
            (i32.const 1)
           )
           (then
            (i64.const 1)
           )
           (else
            (if (result i64)
             (i32.eq
              (struct.get $type35 0
               (local.get $5)
              )
              (i32.const 2)
             )
             (then
              (drop
               (ref.cast (ref $type38)
                (local.get $5)
               )
              )
              (i64.const 2)
             )
             (else
              (i64.const 3)
             )
            )
           )
          )
         )
         (else
          (i64.const 0)
         )
        )
        (local.get $0)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready118)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global118)
         )
        )
        (if (result i32)
         (i64.eq
          (if (result i64)
           (local.tee $1
            (struct.get $type35 0
             (local.get $4)
            )
           )
           (then
            (if (result i64)
             (i32.eq
              (local.get $1)
              (i32.const 1)
             )
             (then
              (i64.const 1)
             )
             (else
              (if (result i64)
               (i32.eq
                (struct.get $type35 0
                 (local.get $4)
                )
                (i32.const 2)
               )
               (then
                (drop
                 (ref.cast (ref $type38)
                  (local.get $4)
                 )
                )
                (i64.const 2)
               )
               (else
                (i64.const 3)
               )
              )
             )
            )
           )
           (else
            (i64.const 0)
           )
          )
          (i64.const 2)
         )
         (then
          (if
           (i32.ne
            (struct.get $type35 0
             (local.get $4)
            )
            (i32.const 2)
           )
           (then
            (unreachable)
           )
          )
          (call $function49
           (struct.get $type38 1
            (ref.cast (ref $type38)
             (local.get $4)
            )
           )
           (block (result (ref null $type39))
            (if
             (i32.ne
              (struct.get $type35 0
               (local.get $5)
              )
              (i32.const 2)
             )
             (then
              (unreachable)
             )
            )
            (local.set $scratch_11
             (struct.get $type38 1
              (ref.cast (ref $type38)
               (local.get $5)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready139)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global139)
             )
            )
            (local.get $scratch_11)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready118)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global118)
           )
          )
          (i64.ne
           (if (result i64)
            (local.tee $1
             (struct.get $type35 0
              (local.get $4)
             )
            )
            (then
             (if (result i64)
              (i32.eq
               (local.get $1)
               (i32.const 1)
              )
              (then
               (i64.const 1)
              )
              (else
               (if (result i64)
                (i32.eq
                 (struct.get $type35 0
                  (local.get $4)
                 )
                 (i32.const 2)
                )
                (then
                 (drop
                  (ref.cast (ref $type38)
                   (local.get $4)
                  )
                 )
                 (i64.const 2)
                )
                (else
                 (i64.const 3)
                )
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
           (i64.const 3)
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (global.set $observed42 (i64.add (global.get $observed42) (i64.const 1)))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready322)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global322)
   )
  )
  (if
   (i32.eqz
    (global.get $ready115)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function106
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (ref.as_non_null
    (global.get $global115)
   )
  )
 )
 (func $main
  (global.set $observed43 (i64.add (global.get $observed43) (i64.const 1)))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global198
   (block (result (ref $type27)) (global.set $observed96 (i64.add (global.get $observed96) (i64.const 1))) (struct.new_default $type27))
  )
  (global.set $ready198
   (i32.const 1)
  )
  (global.set $global225
   (block (result (ref $type32)) (global.set $observed97 (i64.add (global.get $observed97) (i64.const 1))) (struct.new_default $type32))
  )
  (global.set $ready225
   (i32.const 1)
  )
  (global.set $global109
   (block (result (ref $type30)) (global.set $observed98 (i64.add (global.get $observed98) (i64.const 1))) (struct.new_default $type30))
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global110
   (block (result (ref $type34)) (global.set $observed99 (i64.add (global.get $observed99) (i64.const 1))) (struct.new_default $type34))
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global115
   (block (result (ref $type36)) (global.set $observed100 (i64.add (global.get $observed100) (i64.const 1))) (struct.new_default $type36))
  )
  (global.set $ready115
   (i32.const 1)
  )
  (global.set $global116
   (block (result (ref $type37)) (global.set $observed101 (i64.add (global.get $observed101) (i64.const 1))) (struct.new $type37
    (i32.const 1)
   ))
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global117
   (block (result (ref $type41)) (global.set $observed102 (i64.add (global.get $observed102) (i64.const 1))) (struct.new $type41
    (i32.const 3)
   ))
  )
  (global.set $ready117
   (i32.const 1)
  )
  (global.set $global118
   (block (result (ref $type42)) (global.set $observed103 (i64.add (global.get $observed103) (i64.const 1))) (struct.new_default $type42))
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global122
   (block (result (ref $type43)) (global.set $observed104 (i64.add (global.get $observed104) (i64.const 1))) (struct.new_default $type43))
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global125
   (block (result (ref $type44)) (global.set $observed105 (i64.add (global.get $observed105) (i64.const 1))) (struct.new_default $type44))
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global127
   (block (result (ref $type44)) (global.set $observed105 (i64.add (global.get $observed105) (i64.const 1))) (struct.new_default $type44))
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global129
   (block (result (ref $type45)) (global.set $observed106 (i64.add (global.get $observed106) (i64.const 1))) (struct.new_default $type45))
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global132
   (block (result (ref $type46)) (global.set $observed107 (i64.add (global.get $observed107) (i64.const 1))) (struct.new_default $type46))
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global178
   (block (result (ref $type47)) (global.set $observed108 (i64.add (global.get $observed108) (i64.const 1))) (struct.new_default $type47))
  )
  (global.set $ready178
   (i32.const 1)
  )
  (global.set $global182
   (block (result (ref $type48)) (global.set $observed109 (i64.add (global.get $observed109) (i64.const 1))) (struct.new_default $type48))
  )
  (global.set $ready182
   (i32.const 1)
  )
  (global.set $global241
   (block (result (ref $type49)) (global.set $observed110 (i64.add (global.get $observed110) (i64.const 1))) (struct.new_default $type49))
  )
  (global.set $ready241
   (i32.const 1)
  )
  (global.set $global247
   (block (result (ref $type50)) (global.set $observed111 (i64.add (global.get $observed111) (i64.const 1))) (struct.new_default $type50))
  )
  (global.set $ready247
   (i32.const 1)
  )
  (global.set $global300
   (block (result (ref $type52)) (global.set $observed112 (i64.add (global.get $observed112) (i64.const 1))) (struct.new_default $type52))
  )
  (global.set $ready300
   (i32.const 1)
  )
  (global.set $global304
   (block (result (ref $type53)) (global.set $observed113 (i64.add (global.get $observed113) (i64.const 1))) (struct.new_default $type53))
  )
  (global.set $ready304
   (i32.const 1)
  )
  (global.set $global136
   (block (result (ref $type55)) (global.set $observed114 (i64.add (global.get $observed114) (i64.const 1))) (struct.new_default $type55))
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global139
   (block (result (ref $type56)) (global.set $observed115 (i64.add (global.get $observed115) (i64.const 1))) (struct.new_default $type56))
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global142
   (block (result (ref $type57)) (global.set $observed116 (i64.add (global.get $observed116) (i64.const 1))) (struct.new_default $type57))
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global327
   (block (result (ref $type58)) (global.set $observed117 (i64.add (global.get $observed117) (i64.const 1))) (struct.new_default $type58))
  )
  (global.set $ready327
   (i32.const 1)
  )
  (global.set $global185
   (block (result (ref $type59)) (global.set $observed118 (i64.add (global.get $observed118) (i64.const 1))) (struct.new_default $type59))
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global282
   (block (result (ref $type60)) (global.set $observed119 (i64.add (global.get $observed119) (i64.const 1))) (struct.new_default $type60))
  )
  (global.set $ready282
   (i32.const 1)
  )
  (global.set $global163
   (block (result (ref $type62)) (global.set $observed120 (i64.add (global.get $observed120) (i64.const 1))) (struct.new_default $type62))
  )
  (global.set $ready163
   (i32.const 1)
  )
  (global.set $global169
   (block (result (ref $type64)) (global.set $observed121 (i64.add (global.get $observed121) (i64.const 1))) (struct.new_default $type64))
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global180
   (block (result (ref $type66)) (global.set $observed122 (i64.add (global.get $observed122) (i64.const 1))) (struct.new_default $type66))
  )
  (global.set $ready180
   (i32.const 1)
  )
  (global.set $global203
   (block (result (ref $type67)) (global.set $observed123 (i64.add (global.get $observed123) (i64.const 1))) (struct.new_default $type67))
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global238
   (block (result (ref $type68)) (global.set $observed124 (i64.add (global.get $observed124) (i64.const 1))) (struct.new_default $type68))
  )
  (global.set $ready238
   (i32.const 1)
  )
  (global.set $global274
   (block (result (ref $type69)) (global.set $observed125 (i64.add (global.get $observed125) (i64.const 1))) (struct.new_default $type69))
  )
  (global.set $ready274
   (i32.const 1)
  )
  (global.set $global278
   (block (result (ref $type70)) (global.set $observed126 (i64.add (global.get $observed126) (i64.const 1))) (struct.new_default $type70))
  )
  (global.set $ready278
   (i32.const 1)
  )
  (global.set $global206
   (block (result (ref $type71)) (global.set $observed127 (i64.add (global.get $observed127) (i64.const 1))) (struct.new_default $type71))
  )
  (global.set $ready206
   (i32.const 1)
  )
  (global.set $global145
   (block (result (ref $type72)) (global.set $observed128 (i64.add (global.get $observed128) (i64.const 1))) (struct.new_default $type72))
  )
  (global.set $ready145
   (i32.const 1)
  )
  (global.set $global157
   (block (result (ref $type73)) (global.set $observed129 (i64.add (global.get $observed129) (i64.const 1))) (struct.new_default $type73))
  )
  (global.set $ready157
   (i32.const 1)
  )
  (global.set $global234
   (block (result (ref $type75)) (global.set $observed130 (i64.add (global.get $observed130) (i64.const 1))) (struct.new_default $type75))
  )
  (global.set $ready234
   (i32.const 1)
  )
  (global.set $global269
   (block (result (ref $type76)) (global.set $observed131 (i64.add (global.get $observed131) (i64.const 1))) (struct.new_default $type76))
  )
  (global.set $ready269
   (i32.const 1)
  )
  (global.set $global223
   (block (result (ref $type77)) (global.set $observed132 (i64.add (global.get $observed132) (i64.const 1))) (struct.new_default $type77))
  )
  (global.set $ready223
   (i32.const 1)
  )
  (global.set $global296
   (block (result (ref $type79)) (global.set $observed133 (i64.add (global.get $observed133) (i64.const 1))) (struct.new_default $type79))
  )
  (global.set $ready296
   (i32.const 1)
  )
  (global.set $ready148
   (i32.const 1)
  )
  (global.set $global149
   (block (result (ref $type80)) (global.set $observed134 (i64.add (global.get $observed134) (i64.const 1))) (struct.new_default $type80))
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global191
   (block (result (ref $type81)) (global.set $observed135 (i64.add (global.get $observed135) (i64.const 1))) (struct.new_default $type81))
  )
  (global.set $ready191
   (i32.const 1)
  )
  (global.set $global193
   (block (result (ref $type71)) (global.set $observed127 (i64.add (global.get $observed127) (i64.const 1))) (struct.new_default $type71))
  )
  (global.set $ready193
   (i32.const 1)
  )
  (global.set $global151
   (block (result (ref $type82)) (global.set $observed136 (i64.add (global.get $observed136) (i64.const 1))) (struct.new_default $type82))
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $global294
   (block (result (ref $type83)) (global.set $observed137 (i64.add (global.get $observed137) (i64.const 1))) (struct.new_default $type83))
  )
  (global.set $ready294
   (i32.const 1)
  )
  (global.set $global289
   (block (result (ref $type84)) (global.set $observed138 (i64.add (global.get $observed138) (i64.const 1))) (struct.new_default $type84))
  )
  (global.set $ready289
   (i32.const 1)
  )
  (global.set $global209
   (block (result (ref $type85)) (global.set $observed139 (i64.add (global.get $observed139) (i64.const 1))) (struct.new_default $type85))
  )
  (global.set $ready209
   (i32.const 1)
  )
  (global.set $global213
   (block (result (ref $type84)) (global.set $observed138 (i64.add (global.get $observed138) (i64.const 1))) (struct.new_default $type84))
  )
  (global.set $ready213
   (i32.const 1)
  )
  (global.set $global253
   (block (result (ref $type86)) (global.set $observed140 (i64.add (global.get $observed140) (i64.const 1))) (struct.new_default $type86))
  )
  (global.set $ready253
   (i32.const 1)
  )
  (global.set $global259
   (block (result (ref $type87)) (global.set $observed141 (i64.add (global.get $observed141) (i64.const 1))) (struct.new_default $type87))
  )
  (global.set $ready259
   (i32.const 1)
  )
  (global.set $global219
   (block (result (ref $type88)) (global.set $observed142 (i64.add (global.get $observed142) (i64.const 1))) (struct.new_default $type88))
  )
  (global.set $ready219
   (i32.const 1)
  )
  (global.set $global308
   (block (result (ref $type89)) (global.set $observed143 (i64.add (global.get $observed143) (i64.const 1))) (struct.new_default $type89))
  )
  (global.set $ready308
   (i32.const 1)
  )
  (global.set $global309
   (block (result (ref $type5)) (global.set $observed144 (i64.add (global.get $observed144) (i64.const 1))) (struct.new_default $type5))
  )
  (global.set $ready309
   (i32.const 1)
  )
  (global.set $global316
   (block (result (ref $type90)) (global.set $observed145 (i64.add (global.get $observed145) (i64.const 1))) (struct.new_default $type90))
  )
  (global.set $ready316
   (i32.const 1)
  )
  (global.set $global313
   (block (result (ref $type91)) (global.set $observed146 (i64.add (global.get $observed146) (i64.const 1))) (struct.new_default $type91))
  )
  (global.set $ready313
   (i32.const 1)
  )
  (global.set $global311
   (block (result (ref $type92)) (global.set $observed147 (i64.add (global.get $observed147) (i64.const 1))) (struct.new_default $type92))
  )
  (global.set $ready311
   (i32.const 1)
  )
  (global.set $global319
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $ready319
   (i32.const 1)
  )
  (global.set $global320
   (call $foreign2
    (i32.const 1)
   )
  )
  (global.set $ready320
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready311)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global311)
   )
  )
  (global.set $global321
   (call $function102)
  )
  (global.set $ready321
   (i32.const 1)
  )
  (global.set $global322
   (block (result (ref $type80)) (global.set $observed134 (i64.add (global.get $observed134) (i64.const 1))) (struct.new_default $type80))
  )
  (global.set $ready322
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
 (global $observed0 (mut i64) (i64.const 0))
 (export "observed:function:$function41" (global $observed0))
 (global $observed1 (mut i64) (i64.const 0))
 (export "observed:function:$function46" (global $observed1))
 (global $observed2 (mut i64) (i64.const 0))
 (export "observed:function:$function47" (global $observed2))
 (global $observed3 (mut i64) (i64.const 0))
 (export "observed:function:$function48" (global $observed3))
 (global $observed4 (mut i64) (i64.const 0))
 (export "observed:function:$function49" (global $observed4))
 (global $observed5 (mut i64) (i64.const 0))
 (export "observed:function:$function51" (global $observed5))
 (global $observed6 (mut i64) (i64.const 0))
 (export "observed:function:$function53" (global $observed6))
 (global $observed7 (mut i64) (i64.const 0))
 (export "observed:function:$function54" (global $observed7))
 (global $observed8 (mut i64) (i64.const 0))
 (export "observed:function:$function56" (global $observed8))
 (global $observed9 (mut i64) (i64.const 0))
 (export "observed:function:$function59" (global $observed9))
 (global $observed10 (mut i64) (i64.const 0))
 (export "observed:function:$function61" (global $observed10))
 (global $observed11 (mut i64) (i64.const 0))
 (export "observed:function:$function62" (global $observed11))
 (global $observed12 (mut i64) (i64.const 0))
 (export "observed:function:$function63" (global $observed12))
 (global $observed13 (mut i64) (i64.const 0))
 (export "observed:function:$function66" (global $observed13))
 (global $observed14 (mut i64) (i64.const 0))
 (export "observed:function:$function68" (global $observed14))
 (global $observed15 (mut i64) (i64.const 0))
 (export "observed:function:$function70" (global $observed15))
 (global $observed16 (mut i64) (i64.const 0))
 (export "observed:function:$function71" (global $observed16))
 (global $observed17 (mut i64) (i64.const 0))
 (export "observed:function:$function72" (global $observed17))
 (global $observed18 (mut i64) (i64.const 0))
 (export "observed:function:$function73" (global $observed18))
 (global $observed19 (mut i64) (i64.const 0))
 (export "observed:function:$function74" (global $observed19))
 (global $observed20 (mut i64) (i64.const 0))
 (export "observed:function:$function75" (global $observed20))
 (global $observed21 (mut i64) (i64.const 0))
 (export "observed:function:$function76" (global $observed21))
 (global $observed22 (mut i64) (i64.const 0))
 (export "observed:function:$function77" (global $observed22))
 (global $observed23 (mut i64) (i64.const 0))
 (export "observed:function:$function80" (global $observed23))
 (global $observed24 (mut i64) (i64.const 0))
 (export "observed:function:$function81" (global $observed24))
 (global $observed25 (mut i64) (i64.const 0))
 (export "observed:function:$function82" (global $observed25))
 (global $observed26 (mut i64) (i64.const 0))
 (export "observed:function:$function84" (global $observed26))
 (global $observed27 (mut i64) (i64.const 0))
 (export "observed:function:$function85" (global $observed27))
 (global $observed28 (mut i64) (i64.const 0))
 (export "observed:function:$function86" (global $observed28))
 (global $observed29 (mut i64) (i64.const 0))
 (export "observed:function:$function88" (global $observed29))
 (global $observed30 (mut i64) (i64.const 0))
 (export "observed:function:$function89" (global $observed30))
 (global $observed31 (mut i64) (i64.const 0))
 (export "observed:function:$function91" (global $observed31))
 (global $observed32 (mut i64) (i64.const 0))
 (export "observed:function:$function92" (global $observed32))
 (global $observed33 (mut i64) (i64.const 0))
 (export "observed:function:$function94" (global $observed33))
 (global $observed34 (mut i64) (i64.const 0))
 (export "observed:function:$function98" (global $observed34))
 (global $observed35 (mut i64) (i64.const 0))
 (export "observed:function:$function99" (global $observed35))
 (global $observed36 (mut i64) (i64.const 0))
 (export "observed:function:$function100" (global $observed36))
 (global $observed37 (mut i64) (i64.const 0))
 (export "observed:function:$function101" (global $observed37))
 (global $observed38 (mut i64) (i64.const 0))
 (export "observed:function:$function102" (global $observed38))
 (global $observed39 (mut i64) (i64.const 0))
 (export "observed:function:$function103" (global $observed39))
 (global $observed40 (mut i64) (i64.const 0))
 (export "observed:function:$function104" (global $observed40))
 (global $observed41 (mut i64) (i64.const 0))
 (export "observed:function:$function106" (global $observed41))
 (global $observed42 (mut i64) (i64.const 0))
 (export "observed:function:$export0" (global $observed42))
 (global $observed43 (mut i64) (i64.const 0))
 (export "observed:function:$main" (global $observed43))
 (global $observed44 (mut i64) (i64.const 0))
 (export "observed:constructor:$type33:$function53" (global $observed44))
 (global $observed45 (mut i64) (i64.const 0))
 (export "observed:constructor:$type65:$function53" (global $observed45))
 (global $observed46 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment56:$function53" (global $observed46))
 (global $observed47 (mut i64) (i64.const 0))
 (export "observed:constructor:$type74:$function53" (global $observed47))
 (global $observed48 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment62:$function53" (global $observed48))
 (global $observed49 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function53" (global $observed49))
 (global $observed50 (mut i64) (i64.const 0))
 (export "observed:constructor:$type38:$function53" (global $observed50))
 (global $observed51 (mut i64) (i64.const 0))
 (export "observed:constructor:$type39:$function53" (global $observed51))
 (global $observed52 (mut i64) (i64.const 0))
 (export "observed:constructor:$type54:$function53" (global $observed52))
 (global $observed53 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment98:$function53" (global $observed53))
 (global $observed54 (mut i64) (i64.const 0))
 (export "observed:constructor:$type31:$function54" (global $observed54))
 (global $observed55 (mut i64) (i64.const 0))
 (export "observed:constructor:$type63:$function56" (global $observed55))
 (global $observed56 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment57:$function56" (global $observed56))
 (global $observed57 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function56" (global $observed57))
 (global $observed58 (mut i64) (i64.const 0))
 (export "observed:constructor:$type31:$function56" (global $observed58))
 (global $observed59 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function59" (global $observed59))
 (global $observed60 (mut i64) (i64.const 0))
 (export "observed:constructor:$type33:$function61" (global $observed60))
 (global $observed61 (mut i64) (i64.const 0))
 (export "observed:constructor:$type33:$function62" (global $observed61))
 (global $observed62 (mut i64) (i64.const 0))
 (export "observed:constructor:$type65:$function62" (global $observed62))
 (global $observed63 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment63:$function62" (global $observed63))
 (global $observed64 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function62" (global $observed64))
 (global $observed65 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function63" (global $observed65))
 (global $observed66 (mut i64) (i64.const 0))
 (export "observed:constructor:$type31:$function63" (global $observed66))
 (global $observed67 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function66" (global $observed67))
 (global $observed68 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function68" (global $observed68))
 (global $observed69 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function70" (global $observed69))
 (global $observed70 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function74" (global $observed70))
 (global $observed71 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function76" (global $observed71))
 (global $observed72 (mut i64) (i64.const 0))
 (export "observed:constructor:$type51:$function76" (global $observed72))
 (global $observed73 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment84:$function76" (global $observed73))
 (global $observed74 (mut i64) (i64.const 0))
 (export "observed:constructor:$type61:$function76" (global $observed74))
 (global $observed75 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment86:$function76" (global $observed75))
 (global $observed76 (mut i64) (i64.const 0))
 (export "observed:constructor:$type33:$function76" (global $observed76))
 (global $observed77 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function77" (global $observed77))
 (global $observed78 (mut i64) (i64.const 0))
 (export "observed:constructor:$type31:$function77" (global $observed78))
 (global $observed79 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function85" (global $observed79))
 (global $observed80 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function88" (global $observed80))
 (global $observed81 (mut i64) (i64.const 0))
 (export "observed:constructor:$type33:$function88" (global $observed81))
 (global $observed82 (mut i64) (i64.const 0))
 (export "observed:constructor:$type61:$function88" (global $observed82))
 (global $observed83 (mut i64) (i64.const 0))
 (export "observed:constructor:$environment89:$function88" (global $observed83))
 (global $observed84 (mut i64) (i64.const 0))
 (export "observed:constructor:$type28:$function91" (global $observed84))
 (global $observed85 (mut i64) (i64.const 0))
 (export "observed:constructor:$type33:$function92" (global $observed85))
 (global $observed86 (mut i64) (i64.const 0))
 (export "observed:constructor:$type40:$function98" (global $observed86))
 (global $observed87 (mut i64) (i64.const 0))
 (export "observed:constructor:$type40:$function99" (global $observed87))
 (global $observed88 (mut i64) (i64.const 0))
 (export "observed:constructor:$type39:$function100" (global $observed88))
 (global $observed89 (mut i64) (i64.const 0))
 (export "observed:store:$type89:0:$function101" (global $observed89))
 (global $observed90 (mut i64) (i64.const 0))
 (export "observed:store:$type89:0:$function102" (global $observed90))
 (global $observed91 (mut i64) (i64.const 0))
 (export "observed:constructor:$type38:$function102" (global $observed91))
 (global $observed92 (mut i64) (i64.const 0))
 (export "observed:constructor:$type39:$function102" (global $observed92))
 (global $observed93 (mut i64) (i64.const 0))
 (export "observed:constructor:$type39:$function103" (global $observed93))
 (global $observed94 (mut i64) (i64.const 0))
 (export "observed:constructor:$type40:$function104" (global $observed94))
 (global $observed95 (mut i64) (i64.const 0))
 (export "observed:store:$type89:0:$function104" (global $observed95))
 (global $observed96 (mut i64) (i64.const 0))
 (export "observed:constructor:$type27:$main" (global $observed96))
 (global $observed97 (mut i64) (i64.const 0))
 (export "observed:constructor:$type32:$main" (global $observed97))
 (global $observed98 (mut i64) (i64.const 0))
 (export "observed:constructor:$type30:$main" (global $observed98))
 (global $observed99 (mut i64) (i64.const 0))
 (export "observed:constructor:$type34:$main" (global $observed99))
 (global $observed100 (mut i64) (i64.const 0))
 (export "observed:constructor:$type36:$main" (global $observed100))
 (global $observed101 (mut i64) (i64.const 0))
 (export "observed:constructor:$type37:$main" (global $observed101))
 (global $observed102 (mut i64) (i64.const 0))
 (export "observed:constructor:$type41:$main" (global $observed102))
 (global $observed103 (mut i64) (i64.const 0))
 (export "observed:constructor:$type42:$main" (global $observed103))
 (global $observed104 (mut i64) (i64.const 0))
 (export "observed:constructor:$type43:$main" (global $observed104))
 (global $observed105 (mut i64) (i64.const 0))
 (export "observed:constructor:$type44:$main" (global $observed105))
 (global $observed106 (mut i64) (i64.const 0))
 (export "observed:constructor:$type45:$main" (global $observed106))
 (global $observed107 (mut i64) (i64.const 0))
 (export "observed:constructor:$type46:$main" (global $observed107))
 (global $observed108 (mut i64) (i64.const 0))
 (export "observed:constructor:$type47:$main" (global $observed108))
 (global $observed109 (mut i64) (i64.const 0))
 (export "observed:constructor:$type48:$main" (global $observed109))
 (global $observed110 (mut i64) (i64.const 0))
 (export "observed:constructor:$type49:$main" (global $observed110))
 (global $observed111 (mut i64) (i64.const 0))
 (export "observed:constructor:$type50:$main" (global $observed111))
 (global $observed112 (mut i64) (i64.const 0))
 (export "observed:constructor:$type52:$main" (global $observed112))
 (global $observed113 (mut i64) (i64.const 0))
 (export "observed:constructor:$type53:$main" (global $observed113))
 (global $observed114 (mut i64) (i64.const 0))
 (export "observed:constructor:$type55:$main" (global $observed114))
 (global $observed115 (mut i64) (i64.const 0))
 (export "observed:constructor:$type56:$main" (global $observed115))
 (global $observed116 (mut i64) (i64.const 0))
 (export "observed:constructor:$type57:$main" (global $observed116))
 (global $observed117 (mut i64) (i64.const 0))
 (export "observed:constructor:$type58:$main" (global $observed117))
 (global $observed118 (mut i64) (i64.const 0))
 (export "observed:constructor:$type59:$main" (global $observed118))
 (global $observed119 (mut i64) (i64.const 0))
 (export "observed:constructor:$type60:$main" (global $observed119))
 (global $observed120 (mut i64) (i64.const 0))
 (export "observed:constructor:$type62:$main" (global $observed120))
 (global $observed121 (mut i64) (i64.const 0))
 (export "observed:constructor:$type64:$main" (global $observed121))
 (global $observed122 (mut i64) (i64.const 0))
 (export "observed:constructor:$type66:$main" (global $observed122))
 (global $observed123 (mut i64) (i64.const 0))
 (export "observed:constructor:$type67:$main" (global $observed123))
 (global $observed124 (mut i64) (i64.const 0))
 (export "observed:constructor:$type68:$main" (global $observed124))
 (global $observed125 (mut i64) (i64.const 0))
 (export "observed:constructor:$type69:$main" (global $observed125))
 (global $observed126 (mut i64) (i64.const 0))
 (export "observed:constructor:$type70:$main" (global $observed126))
 (global $observed127 (mut i64) (i64.const 0))
 (export "observed:constructor:$type71:$main" (global $observed127))
 (global $observed128 (mut i64) (i64.const 0))
 (export "observed:constructor:$type72:$main" (global $observed128))
 (global $observed129 (mut i64) (i64.const 0))
 (export "observed:constructor:$type73:$main" (global $observed129))
 (global $observed130 (mut i64) (i64.const 0))
 (export "observed:constructor:$type75:$main" (global $observed130))
 (global $observed131 (mut i64) (i64.const 0))
 (export "observed:constructor:$type76:$main" (global $observed131))
 (global $observed132 (mut i64) (i64.const 0))
 (export "observed:constructor:$type77:$main" (global $observed132))
 (global $observed133 (mut i64) (i64.const 0))
 (export "observed:constructor:$type79:$main" (global $observed133))
 (global $observed134 (mut i64) (i64.const 0))
 (export "observed:constructor:$type80:$main" (global $observed134))
 (global $observed135 (mut i64) (i64.const 0))
 (export "observed:constructor:$type81:$main" (global $observed135))
 (global $observed136 (mut i64) (i64.const 0))
 (export "observed:constructor:$type82:$main" (global $observed136))
 (global $observed137 (mut i64) (i64.const 0))
 (export "observed:constructor:$type83:$main" (global $observed137))
 (global $observed138 (mut i64) (i64.const 0))
 (export "observed:constructor:$type84:$main" (global $observed138))
 (global $observed139 (mut i64) (i64.const 0))
 (export "observed:constructor:$type85:$main" (global $observed139))
 (global $observed140 (mut i64) (i64.const 0))
 (export "observed:constructor:$type86:$main" (global $observed140))
 (global $observed141 (mut i64) (i64.const 0))
 (export "observed:constructor:$type87:$main" (global $observed141))
 (global $observed142 (mut i64) (i64.const 0))
 (export "observed:constructor:$type88:$main" (global $observed142))
 (global $observed143 (mut i64) (i64.const 0))
 (export "observed:constructor:$type89:$main" (global $observed143))
 (global $observed144 (mut i64) (i64.const 0))
 (export "observed:constructor:$type5:$main" (global $observed144))
 (global $observed145 (mut i64) (i64.const 0))
 (export "observed:constructor:$type90:$main" (global $observed145))
 (global $observed146 (mut i64) (i64.const 0))
 (export "observed:constructor:$type91:$main" (global $observed146))
 (global $observed147 (mut i64) (i64.const 0))
 (export "observed:constructor:$type92:$main" (global $observed147))
 (global $observed148 (mut i64) (i64.const 0))
 (export "observed:shuffle-state-advance" (global $observed148))
)

