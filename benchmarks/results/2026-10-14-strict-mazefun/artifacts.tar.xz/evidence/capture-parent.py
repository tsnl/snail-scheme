"""Keep later compiler compatibility separate from the frozen preparation."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

parent, prepared, evidence = map(Path, sys.argv[1:])
target = evidence / 'parent-integration'
target.mkdir()
origin = parent / 'build/mazefun-parent-review'
for path in origin.iterdir():
    if path.is_file():
        shutil.copy2(path, target / path.name)
metadata = json.loads((prepared / 'prepared.json').read_text())
compiler_files = {}
for name, old_hash in metadata['compiler_files'].items():
    data = (parent / name).read_bytes()
    compiler_files[name] = hashlib.sha256(data).hexdigest()
    if compiler_files[name] != old_hash:
        copy = target / 'changed-compiler-source' / name
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(data)
drift = json.loads((target / 'compiler-drift.json').read_text())
assert {item['path'] for item in drift} == {name for name, value in compiler_files.items()
                                         if value != metadata['compiler_files'][name]}
assert all(item['current'] == compiler_files[item['path']] for item in drift)
for filename in ['strict.scm', 'strict.wasm.raw.wasm', 'strict.wasm']:
    assert (target / filename).read_bytes() == (prepared / 'mazefun' / filename).read_bytes()
runs = json.loads((target / 'current-compiler-executions.json').read_text())
assert len(runs) == 2
for record in runs:
    assert record['returncode'] == 0 and not record['stderr'] and record['same_bytes']
    assert json.loads(record['stdout'])['barriers'] == 20000
host = (parent / 'benchmarks/strict-suite/host.mjs').read_bytes()
(target / 'host.mjs').write_bytes(host)
capture = dict(parent_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=parent, text=True).strip(),
               compiler_files=compiler_files, changed_files=[item['path'] for item in drift],
               canonical_source_and_binaries_identical=True, canonical_executions=2,
               host_sha256=hashlib.sha256(host).hexdigest(),
               provenance='Parent executed these checks; this finishing pass verified records, bytes and compiler drift.',
               clean_measurements=0)
(target / 'capture.json').write_text(json.dumps(capture, indent=2) + '\n')
summary_file = evidence / 'correctness-summary.json'
summary = json.loads(summary_file.read_text())
summary['supplemental_parent_canonical_executions'] = 2
summary['supplemental_parent_compiler_commit'] = capture['parent_commit']
summary_file.write_text(json.dumps(summary, indent=2) + '\n')
print('Captured two parent compatibility executions and the exact two compiler-source changes')
