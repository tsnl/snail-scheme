"""Verify recorded results and hashes without rerunning the prepared workloads."""

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

prepared, destination, source_commit = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
sys.path.insert(0, str(prepared))
import mazefun_port

runner_spec = importlib.util.spec_from_file_location('r7rs', prepared / 'r7rs.py')
runner = importlib.util.module_from_spec(runner_spec)
runner_spec.loader.exec_module(runner)


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def successful(record):
    assert record['returncode'] == 0 and not record['stderr'], record


metadata = load(prepared / 'prepared.json')
case = metadata['cases'][0]
directory = prepared / 'mazefun'
assert case['status'] == 'ready'
for name, expected in case['hashes'].items():
    assert digest(directory / name) == expected, name
for name, expected in metadata['compiler_files'].items():
    assert digest(prepared / 'compiler-source' / name) == expected, name
for record in metadata['tools'].values():
    assert digest(Path(record['path'])) == record['sha256'], record['path']

canonical = load(directory / 'validation.json')
for record in canonical:
    successful(record)
    observed = json.loads(record['stdout'])
    assert observed['result'] == '1'
    assert observed['barriers'] == 2 * record['specification']['count']
    assert observed['setup_barriers'] == 0
chez_canonical = load(directory / 'chez-validation.json')
for record in chez_canonical:
    successful(record)
    assert runner.parse_result(record['stdout'], 'chez', 'mazefun')['status'] == 'ok'
assert len(canonical) == len(chez_canonical) == 6

observations, grids = {}, {}
fixtures = [(0, n, m) for n, m in mazefun_port.output_fixtures()]
fixtures += [(1, n, m) for n, m in [(3, 3), (3, 5), (5, 3)]]
for command, n, m in fixtures:
    label = f'{command}-{n}-{m}'
    values = []
    for system in ['original', 'adapted']:
        record = load(directory / f'probe-{system}-chez/case-{label}.json')
        successful(record)
        values.append(list(map(int, record['stdout'].split())))
    for suffix in ['raw.wasm', 'optimized']:
        record = load(directory / f'probe-strict/case-{label}.{suffix}.json')
        successful(record)
        values.append(json.loads(record['stdout']))
    assert all(value == values[0] for value in values)
    observations[label] = len(values[0])
    if command == 0:
        grids[n, m] = values[0]
assert grids[11, 11] == case['spec']['expected']

predicate_fixtures = mazefun_port.harness_fixtures(grids)
for label, data, accepted in predicate_fixtures:
    records = load(directory / f'validation-{label}.json')
    assert len(records) == 2
    for record in records:
        assert record['accepted'] == accepted
        if accepted:
            successful(record)
        else:
            assert record['returncode'] != 0 and "actual: '0'" in record['stderr']
    for target in [directory, directory / 'same-source-chez']:
        record = load(target / f'chez-validation-{label}.json')
        successful(record)
        assert record['stdin'] == data and record['accepted'] == accepted
        assert (runner.parse_result(record['stdout'], 'chez', 'mazefun')['status'] == 'ok') == accepted
assert len(predicate_fixtures) == 36
for system in ['original', 'adapted']:
    record = load(directory / f'probe-{system}-chez/sharing.json')
    successful(record)
    assert list(map(int, record['stdout'].split())) == [1] * 15

adapted = (directory / 'same-source-chez/program.scm').read_text()
kernel = (directory / 'adapted-kernel.scm').read_text()
helpers = mazefun_port.CHEZ_TYPES + mazefun_port.COMMON + mazefun_port.CHEZ_BOUNDARY
assert adapted.count(helpers + kernel) == 1
restored = adapted.replace(helpers + kernel, (directory / 'original-kernel.scm').read_text())
assert mazefun_port.adapt_harness(restored, reverse=True) == (directory / 'program.scm').read_text()
strict = (directory / 'strict.scm').read_text()
assert strict.count(mazefun_port.COMMON) == 1 and strict.count(kernel) == 1

disassembled = destination / 'retained/canonical-redisassembled.wat'
command = [metadata['tools']['WASM_DIS']['path'], str(directory / 'strict.wasm'), '-o', str(disassembled)]
run = subprocess.run(command, text=True, capture_output=True, check=True)
assert disassembled.read_bytes() == (directory / 'strict.optimized.wat').read_bytes()
(destination / 'retained/disassemble.json').write_text(json.dumps(dict(
    command=command, returncode=run.returncode, stdout=run.stdout, stderr=run.stderr,
    exact_prepared_wat=True), indent=2) + '\n')

summary = dict(source_commit=source_commit, compiler_commit=metadata['compiler_commit'],
               driver_commit_at_preparation=metadata['driver_commit'],
               driver_sha256=metadata['driver_sha256'],
               adapter_sha256=metadata['mazefun_port_sha256'],
               compiler_files=len(metadata['compiler_files']), frozen_case_files=len(case['hashes']),
               canonical_executions=12, complete_output_executions=60, ordered_trace_executions=12,
               full_predicate_executions=144, behavior_executions=228,
               chez_sharing_executions=2, chez_sharing_assertions=30,
               wasm_reference_identity_probe=False, observations_per_form=observations,
               original_complete_output_matches_input=True, complete_source_reversal=True,
               rejected_reader_inputs=12, accepted_reader_boundary_cases=2,
               previous_unchanged_ports=30, make_test='passed', make_check='passed',
               python_compile='passed', clean_measurements=0)
(destination / 'correctness-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Verified 263 case hashes, 52 compiler sources, 228 behavior executions and 30 Chez identity assertions')
