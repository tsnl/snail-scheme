import fs from 'node:fs';
import assert from 'node:assert/strict';
const [artifact, command, n, m] = process.argv.slice(2);
const values = [];
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact),
  {probe: {emit: value => values.push(Number(value))}});
instance.exports.main();
if (command === 'sharing') {
  const e = instance.exports;
  const tail = row => e['sharing-row-tail'](row);
  const outerTail = grid => e['sharing-grid-tail'](grid);
  const grid = e['sharing-grid'](3n, 3n);
  const rows = [0n, 1n, 2n].map(index => e['sharing-row'](grid, index));
  const label = e['sharing-coordinate'](9n, 7n);
  const written = e['sharing-write'](grid, 1n, 1n, label);
  const row = e['sharing-row'](written, 1n);
  assert.notEqual(written, grid);
  assert.notEqual(outerTail(written), outerTail(grid));
  assert.equal(outerTail(outerTail(written)), outerTail(outerTail(grid)));
  assert.equal(e['sharing-row'](written, 0n), rows[0]);
  assert.equal(e['sharing-row'](written, 2n), rows[2]);
  assert.notEqual(row, rows[1]); assert.notEqual(tail(row), tail(rows[1]));
  assert.equal(tail(tail(row)), tail(tail(rows[1])));
  assert.equal(e['sharing-label'](row, 1n), label);
  assert.notEqual(e['sharing-label'](rows[1], 1n), label);
  const removed = e['sharing-remove'](rows[0], 1n);
  assert.notEqual(removed, rows[0]);
  assert.equal(tail(removed), tail(tail(rows[0])));
  assert.equal(e['sharing-remove'](rows[0], 0n), tail(rows[0]));
  const appended = e['sharing-append'](rows[0], rows[1]);
  assert.notEqual(appended, rows[0]);
  assert.equal(tail(tail(tail(appended))), rows[1]);
  console.log(JSON.stringify({sharing_checks:15}));
} else {
  assert.equal(instance.exports.probe(BigInt(command), BigInt(n), BigInt(m)), 1n);
  console.log(JSON.stringify(values));
}
