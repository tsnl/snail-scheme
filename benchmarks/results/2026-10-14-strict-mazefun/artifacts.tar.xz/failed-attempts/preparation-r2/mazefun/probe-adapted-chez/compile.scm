(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-mazefun-preparation-20261014-r2/mazefun/probe-adapted-chez/program.scm" "/tmp/snail-strict-mazefun-preparation-20261014-r2/mazefun/probe-adapted-chez/program.so"))
