# R7RS suite

Upstream `85f6acdc4cc4e2b857f307ba56bd0ba931dcccd1` · 3 rounds · original inputs

Build/startup excluded. Each successful result passed the upstream result predicate.

| Benchmark | baseline | candidate | chez |
| --- | ---: | ---: | ---: |
| [cat](plots/cat.svg) | 22.6103s | 22.3736s | 0.699943s |
| [lattice](plots/lattice.svg) | 24.9579s | 24.9432s | 1.15876s |
| [wc](plots/wc.svg) | 12.3415s | 12.4291s | 0.650613s |
| [graphs](plots/graphs.svg) | 12.3129s | 12.5154s | 0.764624s |
| [deriv](plots/deriv.svg) | 6.10357s | 6.01076s | 0.417413s |
