#!/usr/bin/env python3
"""Run the pinned R7RS suite through Snail Wasm/V8, Chez, Guile, and Chibi."""

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import re
import shutil
import signal
import statistics
import subprocess
import sys
import tempfile
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "85f6acdc4cc4e2b857f307ba56bd0ba931dcccd1"
SUITE = ROOT / "benchmarks/r7rs-benchmarks"
UPSTREAM = "https://github.com/ecraven/r7rs-benchmarks"
SYSTEMS = ("snail-wasm", "chez", "guile", "chibi")
EXPERIMENT_ENVIRONMENT = (
    "WASM_AS", "WASM_OPT", "WASM_DIS", "WASM_MERGE", "CHIBI",
    "CHEZ", "GUILE", "GUILD", "NODE", "CARGO", "RUSTC", "RUSTFLAGS", "BINARYEN_CORES",
    "SNAIL_REAL_WASM_MERGE", "BDWGC_INCLUDE", "BDWGC_LIB",
    "NODE_OPTIONS", "GUILE_AUTO_COMPILE",
)
# The pinned ray input renders 100 × 100 pixels. Chez, Guile, and Chibi agree.
RAY_PIXELS_SHA256 = "2504547e212cb609b776f06ac18c74915dac54a988e42f9584d0509c03f044eb"


# ---- Pinned sources and benchmark selection ----


def digest(data):
    return hashlib.sha256(data).hexdigest()


def suite_sources():
    if not (SUITE / ".git").exists():
        raise ValueError("run git submodule update --init benchmarks/r7rs-benchmarks")
    git = ["git", "-C", str(SUITE)]
    revision = subprocess.check_output([*git, "rev-parse", "HEAD"], text=True).strip()
    changes = subprocess.check_output([*git, "status", "--porcelain", "--untracked-files=no"])
    if revision != REVISION or changes:
        raise ValueError("benchmark submodule must be clean and pinned to " + REVISION)
    paths = subprocess.check_output([*git, "ls-files", "-z"], text=True).split("\0")
    return {name: (SUITE / name).read_bytes() for name in paths if name}


def benchmark_names(files):
    groups = re.findall(r'^\w+_BENCHMARKS="([^$"\n]+)"', files["bench"].decode(), re.MULTILINE)
    return list(dict.fromkeys(" ".join(groups).split()))


def select_benchmarks(selection, files):
    available = benchmark_names(files)
    names = available if selection == ["all"] else selection
    if len(names) != len(set(names)) or any(name not in available for name in names):
        raise ValueError("choose unique upstream benchmarks from: " + " ".join(available))
    return names


def input_data(data, count):
    if count is None:
        return data
    # Only the first integer (iteration count) changes; algorithm inputs stay fixed.
    result, changes = re.subn(
        rb"\A((?:\s|;[^\n]*(?:\n|$))*)\d+",
        lambda m: m[1] + str(count).encode(),
        data,
        count=1,
    )
    if changes != 1:
        raise ValueError("input does not start with an iteration count")
    return result


# ---- Build complete programs before measuring ----


def source_text(files, name, system):
    body = files[f"src/{name}.scm"].decode()
    if system == "chez":
        body, count = re.subn(r"^\(import [^\n]*\)\s*$", "", body, flags=re.MULTILINE)
        if count != 1:
            raise ValueError("expected one top-level R7RS import form")
        prelude = files["src/Petite-Chez-prelude.scm"].decode()
        prelude += (ROOT / "benchmarks/r7rs-chez.scm").read_text()
    else:
        prelude = ""
    implementation = "snail-scheme" if system.startswith("snail-") else system
    identification = f'(define (this-scheme-implementation-name) "{implementation}")\n'
    return (
        prelude
        + "\n"
        + body
        + "\n"
        + identification
        + files["src/common.scm"].decode()
        + "\n(run-benchmark)\n"
    )


def prepare_case(files, name, system, args):
    directory = args.output / "cases" / name / system
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "outputs").mkdir(exist_ok=True)
    inputs = directory / "inputs"
    if not inputs.exists():
        inputs.symlink_to(args.output / "inputs", target_is_directory=True)
    source = directory / "program.scm"
    source.write_text(source_text(files, name, system))
    data = input_data(files[f"inputs/{name}.input"], args.count)
    (directory / "input.txt").write_bytes(data)
    return {
        "benchmark": name,
        "system": system,
        "implementation": "snail-scheme" if system.startswith("snail-") else system,
        "directory": str(directory),
        "source_sha256": digest(source.read_bytes()),
        "input_sha256": digest(data),
        "samples": [],
        "status": "pending",
    }


def tool(name, default):
    value = shutil.which(os.environ.get(name, default))
    if value is None:
        raise FileNotFoundError(f"missing {name}: {os.environ.get(name, default)}")
    return value


def build_commands(case):
    directory, system = Path(case["directory"]), case["system"]
    source = str(directory / "program.scm")
    if system == "snail-wasm":
        return wasm_commands(directory, source)
    if system == "chez":
        return chez_commands(directory, source)
    if system == "guile":
        artifact = str(directory / "program.go")
        return [
            tool("GUILD", "guild"),
            "compile",
            "--r7rs",
            "-O2",
            "-o",
            artifact,
            source,
        ], [
            tool("GUILE", "guile"),
            "--no-auto-compile",
            "--r7rs",
            "-c",
            f"(load-compiled {json.dumps(artifact)})",
        ]
    return [], [tool("CHIBI", "chibi-scheme"), source]


def wasm_commands(directory, source):
    artifact = str(directory / "program.wasm")
    script = directory / "build.scm"
    quote = lambda value: json.dumps(str(value), ensure_ascii=False)
    script.write_text("(import (scheme base) (snail-scheme build) (snail-scheme chromium-trace))\n"
                      f'(with-chromium-trace-to {quote(directory / "build.trace.json")} (lambda ()\n'
                      f"(build-wasm {quote(ROOT)} {quote(source)} {quote(artifact)})))\n")
    return [tool("CHIBI", "chibi-scheme"), "-I", str(ROOT / "src"), str(script)], [
        tool("NODE", "node"), "--no-warnings",
        str(directory.parents[2] / "host/scripts/run-wasi.mjs"), artifact]


def chez_commands(directory, source):
    artifact = str(directory / "program.so")
    script = directory / "compile.scm"
    script.write_text(
        "(import (chezscheme))\n(parameterize ((optimize-level 2))\n"
        f"  (compile-program {json.dumps(source)} {json.dumps(artifact)}))\n"
    )
    chez = tool("CHEZ", "scheme")
    return [chez, "--script", str(script)], [chez, "--program", artifact]


def execute(command, directory, timeout, stdin=None, environment=None):
    started = time.monotonic()
    with subprocess.Popen(
        command,
        cwd=directory,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        start_new_session=True,
        env={**os.environ, **(environment or {})},
    ) as process:
        try:
            stdout, stderr = process.communicate(stdin, timeout=timeout)
            status = "ok" if process.returncode == 0 else "error"
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
            status = "timeout"
        except BaseException:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
            process.communicate()
            raise
    return {
        "status": status,
        "returncode": process.returncode,
        "wall_seconds": time.monotonic() - started,
        "stdout": stdout.decode(errors="replace"),
        "stderr": stderr.decode(errors="replace"),
    }


def build_case(case, timeout):
    try:
        build, command = build_commands(case)
    except FileNotFoundError as error:
        case.update(status="unavailable", diagnostic=str(error))
        return
    case.update(build_command=build, command=command)
    result = execute(build, case["directory"], timeout,
                     environment={"SNAIL_CAPTURE_DIRECTORY": case["directory"]}) if build else {"status": "ok"}
    case["build"] = result
    case["status"] = "ready" if result["status"] == "ok" else "build-" + result["status"]
    case["artifact_sha256"] = {
        p.name: digest(p.read_bytes())
        for p in Path(case["directory"]).iterdir()
        if p.is_file() and (p.name in ["program", "program.so", "program.go", "program.scm", "program.wasm"]
                            or p.suffix in (".ll", ".wasm", ".wat", ".scm", ".a", ".c"))
    }


# ---- Result validation and rotating rounds ----


def parse_result(output, system, benchmark):
    rows = [
        line.removeprefix("+!CSVLINE!+").split(",")
        for line in output.splitlines()
        if line.startswith("+!CSVLINE!+")
    ]
    if len(rows) != 1 or len(rows[0]) != 3:
        raise ValueError("expected one checked upstream timing record")
    implementation, name, duration = rows[0]
    if implementation != system or name.split(":", 1)[0] != benchmark:
        raise ValueError("timing record identifies a different implementation or benchmark")
    if duration == "INCORRECT":
        return {"status": "incorrect", "name": name}
    seconds = float(duration)
    if not math.isfinite(seconds) or seconds <= 0:
        raise ValueError(
            "timer must be finite and positive; use the full workload if below resolution"
        )
    return {"status": "ok", "seconds": seconds, "name": name}


def sample_case(case, timeout):
    data = (Path(case["directory"]) / "input.txt").read_bytes()
    if case["benchmark"] == "ray":
        (Path(case["directory"]) / "outputs/ray.output").unlink(missing_ok=True)
    result = execute(case["command"], case["directory"], timeout, data)
    if result["status"] == "ok":
        try:
            result.update(parse_result(result["stdout"], case.get("implementation", case["system"]), case["benchmark"]))
            if result["status"] == "ok" and case["benchmark"] == "ray":
                result["pixels_sha256"] = check_ray_image(Path(case["directory"]))
        except (ValueError, OSError) as error:
            result.update(status="invalid-output", diagnostic=str(error))
    return result


def check_ray_image(directory):
    # Upstream checks only the return symbol 'ok'; verify the actual rendered pixels.
    words = (directory / "outputs/ray.output").read_text().split()
    if words[:4] != ["P2", "100", "100", "255"] or len(words) != 10_004:
        raise ValueError("ray output must be a complete 100 × 100 grayscale PGM")
    checksum = digest(bytes(map(int, words[4:])))
    if checksum != RAY_PIXELS_SHA256:
        raise ValueError("ray pixels differ from the checked Chez/Guile/Chibi reference")
    return checksum


def measure_case(case, round_number, timeout):
    sample = sample_case(case, timeout)
    if round_number == 0:
        case["preliminary"] = sample
    else:
        case["samples"].append({**sample, "round": round_number})
    if sample["status"] != "ok":
        case["status"] = "runtime-" + sample["status"]


def measure(report, args):
    allowed = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {report["cpu"]})
    try:
        for index in range(args.rounds + 1):
            for name in report["benchmarks"]:
                cases = [case for case in report["cases"] if case["benchmark"] == name]
                offset = index % len(cases)
                for case in cases[offset:] + cases[:offset]:
                    if case["status"] == "ready":
                        report["active_attempt"] = [index, name, case["system"]]
                        save_report(report, args.output)
                        measure_case(case, index, args.timeout)
                        report["order"].append([index, name, case["system"]])
                        report["active_attempt"] = None
                        save_report(report, args.output)
                        print(f"{index}/{name}/{case['system']}: {case['preliminary']['status'] if index == 0 else case['samples'][-1]['status']}", flush=True)
                    else:
                        case.setdefault("blocked_attempts", []).append(
                            {"round": index, "reason": case["status"]})
            save_report(report, args.output)
            print(
                f"{'Preliminary' if index == 0 else 'Round ' + str(index)} complete",
                flush=True,
            )
    finally:
        os.sched_setaffinity(0, allowed)


def save_report(report, output):
    temporary = output / "results.json.tmp"
    temporary.write_text(json.dumps(report, indent=2) + "\n")
    temporary.replace(output / "results.json")


def experiment_environment():
    return {key: os.environ.get(key) for key in EXPERIMENT_ENVIRONMENT}


def validate_prepared(report):
    if report["complete"] or any(case["samples"] or case.get("preliminary") for case in report["cases"]):
        raise ValueError("matrix already contains timing attempts")
    if report["experiment_environment"] != experiment_environment():
        raise ValueError("prepared experiment environment changed")
    check_hashes(ROOT, report["compiler_sha256"])
    check_hashes(ROOT, report["harness_sha256"])
    check_hashes(Path(report["output"]) / "host", report["host_sha256"])
    for value in report["tools"].values():
        if value.get("path"):
            check_hashes(Path("/"), {value["path"]: value["sha256"]})
    check_hashes(Path(report["output"]), {name: value for name, value in report["input_sha256"].items()
                                         if name.startswith("inputs/")})
    for case in report["cases"]:
        check_hashes(Path(case["directory"]), {**case.get("artifact_sha256", {}),
                                              "input.txt": case["input_sha256"]})


def check_hashes(directory, expected):
    for name, checksum in expected.items():
        if digest((directory / name).read_bytes()) != checksum:
            raise ValueError("prepared input or artifact changed: " + str(directory / name))


# ---- Tables and plots from JSON ----


def results(report):
    if report.get("schema") != 1 or report.get("kind") != "r7rs" or not report.get("complete"):
        raise ValueError("expected a complete R7RS suite report")
    expected = {(name, system) for name in report["benchmarks"] for system in report["systems"]}
    actual = [(case["benchmark"], case["system"]) for case in report["cases"]]
    if set(actual) != expected or len(actual) != len(expected):
        raise ValueError("report does not contain the complete requested matrix")
    rows = []
    for case in report["cases"]:
        samples = case["samples"] if case["status"] == "passed" else []
        if case["status"] == "passed":
            validate_samples(case, report["rounds"])
        rows.append(
            {
                "benchmark": case["benchmark"],
                "system": case["system"],
                "status": case["status"],
                "median_seconds": statistics.median(s["seconds"] for s in samples)
                if samples
                else None,
            }
        )
    return rows


def validate_samples(case, rounds):
    if sorted(s["round"] for s in case["samples"]) != list(range(1, rounds + 1)):
        raise ValueError("missing or duplicate measured round")
    preliminary = case["preliminary"]
    for sample in [preliminary, *case["samples"]]:
        checked = parse_result(sample["stdout"], case.get("implementation", case["system"]), case["benchmark"])
        if (
            sample["returncode"] != 0
            or sample["status"] != "ok"
            or checked.get("seconds") != sample["seconds"]
            or checked["name"] != preliminary["name"]
        ):
            raise ValueError("saved timing differs from checked output or workload identity")


def table(report, rows, output):
    with (output / "summary.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [
        "# R7RS suite",
        "",
        (
            f"Upstream `{report['upstream_revision']}` · {report['rounds']} rounds · "
            f"{'original inputs' if report['count'] is None else 'SMOKE RUN: iteration count ' + str(report['count'])}"
        ),
        "",
        "Build/startup excluded. Each successful result passed the upstream result predicate.",
        "",
        "| Benchmark | " + " | ".join(report["systems"]) + " |",
        "| --- | " + " | ".join("---:" for _ in report["systems"]) + " |",
    ]
    cells = {
        (r["benchmark"], r["system"]): f"{r['median_seconds']:.6g}s"
        if r["median_seconds"] is not None
        else r["status"]
        for r in rows
    }
    lines += [
        "| ["
        + name
        + "](plots/"
        + name
        + ".svg) | "
        + " | ".join(cells[name, s] for s in report["systems"])
        + " |"
        for name in report["benchmarks"]
    ]
    (output / "summary.md").write_text("\n".join(lines) + "\n")


def plot(report, output):
    if __package__:
        from .plots import GRAY, ORANGE, duration_chart
    else:
        from plots import GRAY, ORANGE, duration_chart

    labels = {
        "snail-wasm": "Snail Scheme\nWasm / V8",
        "chez": "Chez Scheme\nsafe O2",
        "guile": "Guile\nbytecode O2",
        "chibi": "Chibi Scheme",
    }
    for name in report["benchmarks"]:
        cases = [case for case in report["cases"] if case["benchmark"] == name]
        series = [
            {
                "label": labels[case["system"]],
                "seconds": [sample["seconds"] for sample in case["samples"]],
                "color": ORANGE if case["system"] == "snail-wasm" else GRAY,
            }
            for case in cases
            if case["status"] == "passed"
        ]
        missing = [
            f"{labels[case['system']].replace(chr(10), ' ')}: {case['status']}"
            for case in cases
            if case["status"] != "passed"
        ]
        mode = "original inputs" if report["count"] is None else "SMOKE RUN · reduced iterations"
        runs = (
            f"Median of {report['rounds']} runs · whiskers: observed min–max"
            if report["rounds"] > 1
            else "One measured run · no variability estimate"
        )
        duration_chart(
            series,
            output / "plots" / name,
            title="Ray tracing · 33 spheres" if name == "ray" else f"R7RS · {name}",
            subtitle=mode + " · slowest to fastest",
            notes=[
                runs + " · build/startup excluded",
                "Compare heights within this chart; each benchmark has its own time scale.",
            ],
            missing=missing,
        )


def render(report, output):
    rows = results(report)
    table(report, rows, output)
    plot(report, output)
    print(
        f"{sum(r['status'] == 'passed' for r in rows)}/{len(rows)} cases passed; {output / 'summary.md'}"
    )


# ---- Command line and execution ----


def positive(text):
    value = int(text)
    if value <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return value


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "build/r7rs-report")
    parser.add_argument("--systems", nargs="+", choices=SYSTEMS, default=list(SYSTEMS))
    parser.add_argument("--benchmarks", nargs="+", default=["all"],
                        help="workloads to run; default: the entire pinned suite")
    parser.add_argument("--rounds", type=positive, default=3)
    parser.add_argument(
        "--count", type=positive, help="SMOKE ONLY: replace upstream iteration count"
    )
    parser.add_argument(
        "--timeout", type=positive, default=300, help="seconds per runtime invocation"
    )
    parser.add_argument("--build-timeout", type=positive, default=300)
    parser.add_argument("--prepare-only", action="store_true", help="build and freeze the matrix without timing")
    parser.add_argument("--measure", type=Path, help="measure a previously prepared matrix")
    parser.add_argument("--cpu", type=int, default=os.environ.get("BENCH_CPU"))
    parser.add_argument(
        "--allow-failures",
        action="store_true",
        help="exit zero after recording suite failures",
    )
    parser.add_argument(
        "--plot", type=Path, help="render saved JSON without downloading or executing"
    )
    return parser.parse_args(argv)


def metadata(args, files, names):
    return {
        "schema": 1,
        "kind": "r7rs",
        "complete": False,
        "output": str(args.output),
        "upstream": UPSTREAM,
        "upstream_revision": REVISION,
        "date": datetime.now(timezone.utc).isoformat(),
        "revision": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "platform": platform.platform(),
        "cpu": args.cpu,
        "allowed_cpus": sorted(os.sched_getaffinity(0)),
        "rounds": args.rounds,
        "count": args.count,
        "timeout": args.timeout,
        "build_timeout": args.build_timeout,
        "tools": tool_versions(),
        "host_sha256": freeze_host(args.output),
        "cpu_info": Path("/proc/cpuinfo").read_text().split("\n\n")[0],
        "environment": {k: v for k, v in os.environ.items() if k.startswith("GUILE_")},
        "benchmarks": names,
        "systems": args.systems,
        "cases": [],
        "order": [],
        "active_attempt": None,
        "experiment_environment": experiment_environment(),
        "runtime": "WasmGC on V8 with the selected platform and Rust-to-Wasm common library",
        "compiler_sha256": {str(p.relative_to(ROOT)): digest(p.read_bytes())
                            for base in ("src", "bootstrap") for p in sorted((ROOT / base).rglob("*"))
                            if p.is_file() and p.suffix in (".rs", ".sld", ".wat", ".c", ".h")},
        "build_environment": {key: os.environ.get(key) for key in
                              ("WASM_AS", "WASM_OPT", "WASM_DIS", "WASM_MERGE",
                               "RUSTFLAGS", "BINARYEN_CORES")},
        "input_sha256": {
            n: digest(data) for n, data in files.items() if n.startswith(("src/", "inputs/"))
        },
        "harness_sha256": {
            str(p.relative_to(ROOT)): digest(p.read_bytes())
            for p in [Path(__file__), ROOT / "benchmarks/r7rs-chez.scm",
                      ROOT / "benchmarks/capture-tool.py", ROOT / "scripts/run-wasi.mjs",
                      ROOT / "src/runtime/host.mjs"]
        },
    }


def tool_versions():
    result = {}
    for key, default in [
        ("CHEZ", "scheme"),
        ("GUILE", "guile"),
        ("GUILD", "guild"),
        ("CHIBI", "chibi-scheme"),
        ("CARGO", "cargo"),
        ("RUSTC", "rustc"),
        ("NODE", "node"),
        ("WASM_AS", "wasm-as"),
        ("WASM_MERGE", "wasm-merge"),
        ("WASM_OPT", "wasm-opt"),
        ("WASM_DIS", "wasm-dis"),
    ]:
        path = shutil.which(os.environ.get(key, default))
        result[key] = {"path": path}
        if path:
            result[key]["sha256"] = digest(Path(path).read_bytes())
            result[key]["version"] = execute(
                [path, "-V" if key == "CHIBI" else "--version"], ROOT, 10
            )
    if result["NODE"]["path"]:
        result["NODE"]["versions"] = execute(
            [result["NODE"]["path"], "-p", "JSON.stringify(process.versions)"], ROOT, 10)
    return result


def freeze_host(output):
    hashes = {}
    for name in ("scripts/run-wasi.mjs", "src/runtime/host.mjs", "src/runtime/build.mjs"):
        destination = output / "host" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((ROOT / name).read_bytes())
        hashes[name] = digest(destination.read_bytes())
    return hashes


def materialize_inputs(files, output):
    for path, data in files.items():
        if path.startswith("inputs/"):
            destination = output / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)


def run_suite(args, files):
    names = select_benchmarks(args.benchmarks, files)
    report = metadata(args, files, names)
    materialize_inputs(files, args.output)
    report["cases"] = [
        {"benchmark": name, "system": system, "status": "pending", "samples": []}
        for name in names
        for system in args.systems
    ]
    try:
        for case in report["cases"]:
            case.update(prepare_case(files, case["benchmark"], case["system"], args))
            build_case(case, args.build_timeout)
            print(
                f"Build {case['benchmark']}/{case['system']}: {case['status']}",
                flush=True,
            )
            save_report(report, args.output)
        if args.prepare_only:
            return report
        measure(report, args)
        for case in report["cases"]:
            if case["status"] == "ready":
                case["status"] = "passed"
        report["complete"] = True
    finally:
        save_report(report, args.output)
    return report


def main():
    args = arguments()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(args.output / "matplotlib-cache"))
    import matplotlib  # Check plotting dependencies before any benchmark runs.

    matplotlib.use("Agg")

    if args.plot:
        return render(json.loads(args.plot.read_text()), args.output)
    if args.measure:
        report = json.loads(args.measure.read_text())
        args.output = args.measure.resolve().parent
        validate_prepared(report)
        for key in ("cpu", "rounds", "timeout"):
            setattr(args, key, report[key])
        measure(report, args)
        for case in report["cases"]:
            if case["status"] == "ready":
                case["status"] = "passed"
        report["complete"] = True
        save_report(report, args.output)
        render(report, args.output)
        if not args.allow_failures and any(case["status"] != "passed" for case in report["cases"]):
            raise SystemExit(1)
        return
    allowed = sorted(os.sched_getaffinity(0))
    args.cpu = allowed[0] if args.cpu is None else args.cpu
    if args.cpu not in allowed or len(args.systems) != len(set(args.systems)):
        raise ValueError("choose an available CPU and unique systems")
    if (args.output / "results.json").exists():
        raise ValueError("choose a fresh output directory to preserve the existing experiment")
    report = run_suite(args, suite_sources())
    if args.prepare_only:
        print("Prepared matrix; no timing samples: " + str(args.output / "results.json"))
        return
    render(report, args.output)
    if not args.allow_failures and any(c["status"] != "passed" for c in report["cases"]):
        raise SystemExit(1)


# ---- Tests ----


class ResultsTests(unittest.TestCase):
    def test_default_run_selects_the_whole_suite_with_original_inputs(self):
        args = arguments([])
        files = {"bench": b'FIRST_BENCHMARKS="fib ray"\nSECOND_BENCHMARKS="ray gcbench"\n'}
        self.assertEqual(select_benchmarks(args.benchmarks, files), ["fib", "ray", "gcbench"])
        self.assertEqual(args.systems, list(SYSTEMS))
        self.assertIsNone(args.count)
        self.assertFalse(args.allow_failures)

    def test_ray_image_requires_reference_pixels(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "outputs").mkdir()
            image = root / "outputs/ray.output"
            for content in ["P2 100 100 255 0", "P2 100 100 255 " + "0 " * 10_000]:
                image.write_text(content)
                with (
                    self.subTest(content_length=len(content)),
                    self.assertRaises(ValueError),
                ):
                    check_ray_image(root)

    def test_checked_records(self):
        self.assertEqual(
            parse_result("+!CSVLINE!+chez,fib:40:5,0.1\n", "chez", "fib")["seconds"],
            0.1,
        )
        for output in [
            "",
            "+!CSVLINE!+guile,fib:40:5,0.1",
            "+!CSVLINE!+chez,tak,0.1",
            "+!CSVLINE!+chez,fib,nan",
            "+!CSVLINE!+chez,fib,0",
            "+!CSVLINE!+chez,fib,0.1\n+!CSVLINE!+chez,fib,0.2",
        ]:
            with self.subTest(output=output), self.assertRaises(ValueError):
                parse_result(output, "chez", "fib")
        self.assertEqual(
            parse_result("+!CSVLINE!+chez,fib,INCORRECT", "chez", "fib")["status"],
            "incorrect",
        )

    def test_smoke_input_preserves_problem(self):
        source = b"500\n1000000\n; expected answer\n1000000\n"
        self.assertEqual(input_data(source, 1), b"1\n1000000\n; expected answer\n1000000\n")
        self.assertEqual(input_data(source, None), source)
        self.assertEqual(
            input_data(b"; upstream comment\n  5\n40\n", 1),
            b"; upstream comment\n  1\n40\n",
        )

    def test_incomplete_report_rejected(self):
        with self.assertRaises(ValueError):
            results({"schema": 1, "complete": False})

    def test_matrix_preserves_failures(self):
        report = {
            "schema": 1,
            "kind": "r7rs",
            "complete": True,
            "rounds": 1,
            "systems": ["chez"],
            "benchmarks": ["fib"],
            "cases": [],
        }
        with self.assertRaises(ValueError):
            results(report)
        report["cases"] = [
            {
                "benchmark": "fib",
                "system": "chez",
                "status": "build-error",
                "samples": [],
            }
        ]
        self.assertIsNone(results(report)[0]["median_seconds"])
        report["cases"] *= 2
        with self.assertRaises(ValueError):
            results(report)

    def test_timeout_kills_descendants(self):
        with tempfile.TemporaryDirectory() as directory:
            child = "import time; time.sleep(30)"
            parent = (
                "import subprocess,sys,time; from pathlib import Path; "
                f"p=subprocess.Popen([sys.executable,'-c',{child!r}]); "
                "Path('pid').write_text(str(p.pid)); time.sleep(30)"
            )
            result = execute([sys.executable, "-c", parent], directory, 0.5)
            self.assertEqual(result["status"], "timeout")
            pid = (Path(directory) / "pid").read_text()
            status = Path(f"/proc/{pid}/stat")
            for _ in range(100):
                try:
                    if status.read_text().split()[2] in {"Z", "X"}:
                        return
                except FileNotFoundError:
                    return
                time.sleep(0.01)
            self.fail("benchmark descendant survived process-group timeout")


if __name__ == "__main__":
    main()
