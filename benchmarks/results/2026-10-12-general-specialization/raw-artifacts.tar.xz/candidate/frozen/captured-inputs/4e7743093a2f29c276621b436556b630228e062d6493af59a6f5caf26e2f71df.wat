(module
  (import "snail.abi" "snail_main" (func $main (result eqref)))
  (import "snail.library" "_initialize" (func $initialize))
  (import "snail.platform" "environment/initialize-environment" (func $environment))
  (func (export "_start") (call $initialize) (call $environment) (drop (call $main))))
