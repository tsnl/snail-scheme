"""Run the existing rejection and fold-equivalence checks in this checkout."""
import importlib.machinery
import importlib.util
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

loader = importlib.machinery.SourceFileLoader("typing_checks", str(Path("scripts/test-typing").resolve()))
spec = importlib.util.spec_from_loader(loader.name, loader)
checks = importlib.util.module_from_spec(spec)
loader.exec_module(checks)
checks.BUILD = Path("build/review-typing-tests").resolve()
checks.BUILD.mkdir(exist_ok=True)

for name, (program, diagnostic) in checks.REJECTED.items():
    if name == "poly-unused-variable":
        # The requested binder cleanup intentionally makes this source valid.
        # Its positive case is exercised by backend-specialization.scm.
        print("intentional acceptance covered by specialization fixture:", name, flush=True)
        continue
    source = checks.BUILD / (name + ".scm")
    source.write_text(checks.IMPORTS + program + "\n")
    result = checks.compile_program(source, checks.BUILD / (name + ".wasm"), "optimized")
    checks.require(result.returncode != 0 and diagnostic in result.stderr, "reject " + name, result)
    if name in ("poly-constant", "poly-unresolved"):
        checks.require(re.search(re.escape(str(source)) + r":\d+:\d+:", result.stderr),
                       "located diagnostic " + name, result)
    print("rejected as expected:", name, flush=True)

# Preserve every original assertion and source; only independent run_case calls
# execute concurrently. These are correctness checks, never timing samples.
original_run_case = checks.run_case
with ThreadPoolExecutor(max_workers=3) as pool:
    pending = []
    failures = []
    def queue_case(*arguments, **keywords):
        pending.append(pool.submit(original_run_case, *arguments, **keywords))
    checks.run_case = queue_case
    checks.check_streaming_folds()
    for future in as_completed(pending):
        try:
            future.result()
        except Exception as error:
            failures.append(str(error))
            print(str(error), flush=True)
    if failures:
        raise RuntimeError(f"{len(failures)} streaming-fold cases failed")
print("rejection and streaming-fold shard passed", flush=True)
