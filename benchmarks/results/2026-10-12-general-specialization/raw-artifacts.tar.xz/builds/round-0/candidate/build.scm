(import (scheme base) (snail-scheme build) (snail-scheme chromium-trace))
(with-chromium-trace-to "/tmp/snail-specialization-comparison-20261012/build/final-build-comparison/round-0/candidate/build.trace.json" (lambda ()
(build-wasm "/tmp/snail-v8-candidate-d2770ab-20261012" "/tmp/snail-v8-candidate-d2770ab-20261012/build/v8-worst-five/cases/graphs/snail-wasm/program.scm" "/tmp/snail-specialization-comparison-20261012/build/final-build-comparison/round-0/candidate/program.wasm")))
