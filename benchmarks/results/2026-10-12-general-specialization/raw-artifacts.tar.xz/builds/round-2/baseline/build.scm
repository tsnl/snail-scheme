(import (scheme base) (snail-scheme build) (snail-scheme chromium-trace))
(with-chromium-trace-to "/tmp/snail-specialization-comparison-20261012/build/final-build-comparison/round-2/baseline/build.trace.json" (lambda ()
(build-wasm "/tmp/snail-v8-gc-20261012" "/tmp/snail-v8-gc-20261012/build/v8-worst-five/cases/graphs/snail-wasm/program.scm" "/tmp/snail-specialization-comparison-20261012/build/final-build-comparison/round-2/baseline/program.wasm")))
