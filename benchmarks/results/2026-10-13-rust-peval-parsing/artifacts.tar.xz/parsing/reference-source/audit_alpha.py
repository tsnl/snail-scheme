"""Compare complete residual programs while preserving lexical binding meaning."""

import re
import unittest

# ---- Serialized residual programs ----


def read_program(text):
    tokens = iter(re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^()\s]+', text))
    result = read_term(next(tokens), tokens)
    if next(tokens, None) is not None:
        raise ValueError("extra audit datum")
    return result


def read_term(token, tokens):
    if token != "(":
        if token == ")":
            raise ValueError("unexpected audit delimiter")
        return token
    result = []
    while (token := next(tokens)) != ")":
        result.append(read_term(token, tokens))
    return result


# ---- Lexical alpha equivalence without renaming quoted or free symbols ----


def canonical_program(expression, environment, serial):
    if not isinstance(expression, list):
        return environment.get(expression, expression)
    if not expression or expression[0] == "quote":
        return expression
    if expression[0] == "lambda":
        names, nested = bind_names(expression[1], environment, serial)
        return ["lambda", names, canonical_program(expression[2], nested, serial)]
    if expression[0] in ("let", "letrec"):
        return canonical_binding(expression, environment, serial)
    return [canonical_program(item, environment, serial) for item in expression]


def bind_names(names, environment, serial):
    nested, renamed = dict(environment), []
    for name in names:
        identity = ("bound variable", serial[0])
        serial[0] += 1
        nested[name] = identity
        renamed.append(identity)
    return renamed, nested


def canonical_binding(expression, environment, serial):
    names, nested = bind_names([entry[0] for entry in expression[1]], environment, serial)
    values_env = nested if expression[0] == "letrec" else environment
    entries = [[name, canonical_program(entry[1], values_env, serial)]
               for name, entry in zip(names, expression[1])]
    return [expression[0], entries, canonical_program(expression[2], nested, serial)]


def alpha_equivalent(first, second):
    return canonical_program(read_program(first), {}, [0]) == canonical_program(read_program(second), {}, [0])


# ---- Tests ----


class AlphaAuditTests(unittest.TestCase):
    def test_nested_shadowing_and_recursive_bindings(self):
        self.assertTrue(alpha_equivalent("(lambda (x) (let ((x x)) x))",
                                         "(lambda (a) (let ((b a)) b))"))
        self.assertTrue(alpha_equivalent("(letrec ((f (lambda (x) (f x)))) (f y))",
                                         "(letrec ((g (lambda (a) (g a)))) (g y))"))

    def test_free_symbols_literals_and_capture_remain_distinct(self):
        self.assertFalse(alpha_equivalent("(lambda (x) (quote x))", "(lambda (a) (quote a))"))
        self.assertFalse(alpha_equivalent("(lambda (x) y)", "(lambda (a) z)"))
        self.assertFalse(alpha_equivalent("(lambda (x) (let ((x x)) x))",
                                          "(lambda (a) (let ((b a)) a))"))
        self.assertFalse(alpha_equivalent("(lambda (x) (lambda (y) x))",
                                          "(lambda (a) (lambda (a) a))"))
        self.assertFalse(alpha_equivalent("(lambda (x y) (pair x y))",
                                          "(lambda (a b) (pair b a))"))


if __name__ == "__main__":
    unittest.main()
