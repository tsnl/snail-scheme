(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-full-reference-20261013/build/rust-parsing-full/cases/parsing/program.scm" "/tmp/snail-rust-full-reference-20261013/build/rust-parsing-full/cases/parsing/program.so"))
