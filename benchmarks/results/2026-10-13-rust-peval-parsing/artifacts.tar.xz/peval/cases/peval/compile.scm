(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-full-reference-20261013/build/rust-peval-current-full/cases/peval/program.scm" "/tmp/snail-rust-full-reference-20261013/build/rust-peval-current-full/cases/peval/program.so"))
