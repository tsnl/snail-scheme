(display "Hello, world")
