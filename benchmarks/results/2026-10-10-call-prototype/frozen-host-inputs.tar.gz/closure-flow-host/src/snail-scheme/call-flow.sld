;; Throwaway call-target experiment. Values are finite sets of lambda identities
;; plus 'external (opaque values) and 'other (known non-procedures). Only a sole
;; lambda authorizes a direct call; the emitter still reads the actual closure.
(define-library (snail-scheme call-flow)
  (export call-flow-enabled analyze-call-flow call-flow-procedure call-flow-statistics)
  (import (scheme base) (scheme cxr) (scheme hash-table)
          (snail-scheme chromium-trace) (prefix (snail-scheme ir) ir:))
  (begin

    ;; ---- Monotone facts ----

    (define call-flow-enabled (make-parameter #f))
    (define call-flow-statistics (make-parameter '()))
    (define-record-type <flow>
      (make-flow values escaped changed?) flow?
      (values flow-values) (escaped flow-escaped set-flow-escaped!)
      (changed? flow-changed? set-flow-changed!))

    (define (values-at flow node)
      (hash-table-ref/default (flow-values flow) node '(external)))
    (define (reserve! flow node)
      (hash-table-set! (flow-values flow) node '()))
    (define (join! flow node members)
      (let ((previous (values-at flow node)))
        (let loop ((members members) (result previous))
          (cond ((null? members)
                 (unless (eq? previous result)
                   (hash-table-set! (flow-values flow) node result)
                   (set-flow-changed! flow #t)))
                ((memq (car members) result) (loop (cdr members) result))
                (else (loop (cdr members) (cons (car members) result)))))))

    ;; ---- Source inventory ----

    (define (children node)
      (cond ((ir:lambda? node) (list (ir:lambda-body node)))
            ((ir:block? node) (ir:block-items node))
            ((ir:value-binding? node) (list (ir:value-binding-initializer node)))
            ((ir:application? node)
             (append (ir:application-operands node) (list (ir:application-operator node))))
            ((ir:conditional? node)
             (append (list (ir:conditional-test node) (ir:conditional-consequent node))
                     (if (ir:conditional-opt-alternate node) (list (ir:conditional-opt-alternate node)) '())))
            ((ir:assignment? node) (list (ir:assignment-value node)))
            ((ir:annotation? node) (list (ir:annotation-expression node)))
            ((ir:instantiation? node) (list (ir:instantiation-expression node)))
            (else '())))
    (define (all-nodes items)
      (apply append (map (lambda (node) (cons node (all-nodes (children node)))) items)))
    (define (last-item items) (if (null? (cdr items)) (car items) (last-item (cdr items))))

    (define (reserve-node! node flow)
      (reserve! flow node)
      (cond ((ir:value-binding? node) (reserve! flow (ir:value-binding-definition node)))
            ((ir:lambda? node)
             (for-each (lambda (parameter) (reserve! flow parameter)) (ir:lambda-parameters node))
             (when (ir:lambda-opt-rest-parameter node)
               (reserve! flow (ir:lambda-opt-rest-parameter node))
               (join! flow (ir:lambda-opt-rest-parameter node) '(external))))))

    ;; ---- Opaque boundaries ----

    ;; Storing a closure in an unmodeled pair/vector or handing it to foreign
    ;; code permits later arbitrary calls. Returned closures escape transitively.
    ;; Code identity never substitutes an environment: the emitter extracts it
    ;; from the evaluated closure, including after operand side effects.
    (define (escape! members flow)
      (for-each
       (lambda (member)
         (when (and (ir:lambda? member) (not (memq member (flow-escaped flow))))
           (set-flow-escaped! flow (cons member (flow-escaped flow)))
           (set-flow-changed! flow #t)
           (for-each (lambda (parameter) (join! flow parameter '(external)))
                     (ir:lambda-parameters member)))) members))
    (define (opaque-call! node flow)
      (join! flow node '(external))
      (for-each (lambda (operand) (escape! (values-at flow operand) flow))
                (ir:application-operands node)))

    ;; ---- Scheme call edges ----

    (define (pass-arguments! parameters operands flow)
      (unless (null? parameters)
        (join! flow (car parameters) (values-at flow (car operands)))
        (pass-arguments! (cdr parameters) (cdr operands) flow)))
    (define (scheme-call! procedure node flow)
      (let* ((parameters (ir:lambda-parameters procedure)) (operands (ir:application-operands node))
             (count (length parameters)) (rest (ir:lambda-opt-rest-parameter procedure)))
        (when (if rest (>= (length operands) count) (= (length operands) count))
          (pass-arguments! parameters operands flow)
          (when rest
            (for-each (lambda (operand) (escape! (values-at flow operand) flow))
                      (list-tail operands count)))
          (join! flow node (values-at flow (ir:lambda-body procedure))))))
    (define (visit-call! node flow)
      (for-each (lambda (callee)
                  (cond ((ir:lambda? callee) (scheme-call! callee node flow))
                        ((eq? callee 'external) (opaque-call! node flow))))
                (values-at flow (ir:application-operator node))))

    ;; ---- Value flow ----

    ;; These equations ignore control reachability and join every assignment.
    ;; Empty means no successful value is known yet; uninitialized reads still
    ;; fail in the emitter. No result is used before the fixed point completes.
    (define (visit! node flow)
      (cond ((ir:lambda? node) (join! flow node (list node)))
            ((ir:name? node) (join! flow node (values-at flow (ir:name-definition node))))
            ((ir:literal? node) (join! flow node '(other)))
            ((ir:application? node) (visit-call! node flow))
            ((ir:block? node) (join! flow node (values-at flow (last-item (ir:block-items node)))))
            ((ir:value-binding? node)
             (join! flow (ir:value-binding-definition node) (values-at flow (ir:value-binding-initializer node)))
             (join! flow node '(other)))
            ((ir:assignment? node)
             (join! flow (ir:name-definition (ir:assignment-target node)) (values-at flow (ir:assignment-value node)))
             (join! flow node '(other)))
            ((ir:conditional? node)
             (join! flow node (values-at flow (ir:conditional-consequent node)))
             (join! flow node (if (ir:conditional-opt-alternate node)
                                  (values-at flow (ir:conditional-opt-alternate node)) '(other))))
            ((ir:annotation? node) (join! flow node (values-at flow (ir:annotation-expression node))))
            ((ir:instantiation? node) (join! flow node (values-at flow (ir:instantiation-expression node))))
            (else (join! flow node '(other)))))

    (define (solve! nodes outputs flow)
      (let loop ((round 1))
        (set-flow-changed! flow #f)
        (for-each (lambda (node) (visit! node flow)) nodes)
        (for-each (lambda (node) (escape! (values-at flow node) flow)) outputs)
        (for-each (lambda (procedure) (escape! (values-at flow (ir:lambda-body procedure)) flow))
                  (flow-escaped flow))
        (cond ((not (flow-changed? flow)) round)
              ((= round 256) #f)
              (else (loop (+ round 1))))))

    (define (call-flow-procedure flow node)
      (and flow
           (let ((members (values-at flow (ir:application-operator node))))
             (and (pair? members) (null? (cdr members)) (ir:lambda? (car members)) (car members)))))

    (define analyze-call-flow
      (chromium-trace
       "analyze-call-flow"
       (lambda (bodies entry)
         (if (not (call-flow-enabled)) #f
             (let* ((bodies (let nonempty ((rest bodies))
                              (cond ((null? rest) '()) ((null? (car rest)) (nonempty (cdr rest)))
                                    (else (cons (car rest) (nonempty (cdr rest)))))))
                    (nodes (all-nodes (apply append bodies)))
                    (flow (make-flow (make-hash-table eq?) '() #f)))
               (for-each (lambda (node) (reserve-node! node flow)) nodes)
               (let ((rounds (solve! nodes (append (map last-item bodies) (if entry (list entry) '())) flow)))
                 (call-flow-statistics (list (cons 'nodes (length nodes)) (cons 'rounds rounds)
                                             (cons 'escaped (length (flow-escaped flow)))))
                 (and rounds flow)))))))))
