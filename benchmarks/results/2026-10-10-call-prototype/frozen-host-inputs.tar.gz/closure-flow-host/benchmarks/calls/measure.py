#!/usr/bin/env python3
"""Freeze, build, and rotate full linked Scheme programs for call-flow ablations."""

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FEATURES = ["--mvp-features", "--enable-gc", "--enable-reference-types", "--enable-tail-call",
            "--enable-mutable-globals", "--enable-sign-ext", "--enable-bulk-memory",
            "--enable-nontrapping-float-to-int"]
WORKLOADS = {"callbacks": ("benchmarks/calls/callbacks.scm", 4096),
             "cpu": ("benchmarks/cpu.scm", 256), "memory": ("benchmarks/memory.scm", 64)}
VARIANTS = {"baseline": ("baseline", 40), "direct": ("direct", 40),
            "inline80": ("baseline", 80), "direct-inline80": ("direct", 80),
            "inline160": ("baseline", 160), "direct-inline160": ("direct", 160)}


# ---- Frozen inputs and command evidence ----


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command, cwd=ROOT, timeout=600):
    start = time.monotonic()
    completed = subprocess.run(list(map(str, command)), cwd=cwd, text=True,
                               capture_output=True, timeout=timeout)
    record = {"command": list(map(str, command)), "seconds": time.monotonic() - start,
              "status": completed.returncode, "stdout": completed.stdout, "stderr": completed.stderr}
    if completed.returncode:
        raise RuntimeError(json.dumps(record, indent=2))
    return record


def snapshot(destination):
    destination.mkdir()
    paths = [*ROOT.glob("src/**/*.sld"), *ROOT.glob("bootstrap/**/*.sld"), *ROOT.glob("src/**/*.rs")]
    paths += [*ROOT.glob("benchmarks/calls/*"), ROOT / "benchmarks/cpu.scm", ROOT / "benchmarks/memory.scm",
              ROOT / "benchmarks/compile-self.scm", ROOT / "scripts/run-wasi.mjs", ROOT / "src/runtime/host.mjs",
              ROOT / "Cargo.toml", ROOT / "Cargo.lock", ROOT / "rust-toolchain.toml"]
    for source in sorted(paths):
        if source.is_file():
            target = destination / source.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    return {str(path.relative_to(destination)): digest(path)
            for path in sorted(destination.rglob("*")) if path.is_file()}


def artifact(path):
    return {"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size}


def source_counts(path):
    workers = "\n".join(line for line in path.read_text().splitlines()
                        if re.match(r"\(func \$(function|library)", line))
    return {"direct_worker_calls": len(re.findall(r"\((?:return_)?call \$(?:function|checked)\d+", workers)),
            "generic_apply_calls": len(re.findall(r"\((?:return_)?call \$apply\b", workers)),
            "all_calls": len(re.findall(r"\((?:return_)?call ", workers)),
            "worker_definitions": len(re.findall(r"\(func \$function", workers))}


# ---- Production assembly/link and independent inlining setting ----


def prepare_entry(output, builds):
    wat, wasm = output / "entry.wat", output / "entry.wasm"
    wat.write_text('(module (import "snail.awi" "snail_main" (func $main (result eqref)))\n'
                   '(import "snail.rust" "_initialize" (func $initialize))\n'
                   '(func (export "_start") (call $initialize) (drop (call $main))))\n')
    builds.append(run(["wasm-as", "-g", *FEATURES, wat, "-o", wasm]))
    return wasm


def emit(workload, mode, source, output, frozen, builds):
    wat = output / f"{workload}-{mode}.wat"
    builds.append(run(["chibi-scheme", "-h512M", "-I", frozen / "src", frozen / "benchmarks/calls/emit.scm",
                       frozen, source, wat, mode]))
    return wat


def merge(wat, runtime, entry, builds):
    assembled, merged = wat.with_suffix(".assembled.wasm"), wat.with_suffix(".merged.wasm")
    builds.append(run(["wasm-as", "-g", *FEATURES, wat, "-o", assembled]))
    builds.append(run(["wasm-merge", "-g", *FEATURES, assembled, "snail.awi", runtime, "snail.rust",
                       entry, "snail.entry", "-o", merged]))
    return merged


def optimize(merged, output, threshold, builds):
    builds.append(run(["wasm-opt", "-g", *FEATURES, "--remove-exports",
                       "--pass-arg=remove-exports@_initialize", "-O3", "--closed-world",
                       f"--always-inline-max-function-size={threshold}", "--converge", merged, "-o", output]))
    return artifact(output)


def build_workload(name, source, output, frozen, runtime, entry):
    result = {"builds": [], "emission": {}, "variants": {}}
    for mode in ("baseline", "direct"):
        wat = emit(name, mode, source, output, frozen, result["builds"])
        result["emission"][mode] = {**artifact(wat), **source_counts(wat),
                                   "trace": json.loads(Path(str(wat) + ".trace.json").read_text())}
        merged = merge(wat, runtime, entry, result["builds"])
        for variant, (selected, threshold) in VARIANTS.items():
            if selected == mode:
                binary = output / f"{name}-{variant}.wasm"
                result["variants"][variant] = optimize(merged, binary, threshold, result["builds"])
    return result


# ---- Verified execution and rotating order ----


def sample(path, repetitions, cpu, frozen):
    record = run(["taskset", "-c", cpu, "node", "--no-warnings", frozen / "scripts/run-wasi.mjs",
                  path, repetitions])
    checksum = re.search(r"checksum: (\d+)", record["stdout"])
    elapsed = re.search(r"elapsed: ([\d.eE+-]+) s", record["stdout"])
    if not checksum or not elapsed or record["stderr"]:
        raise RuntimeError(f"invalid benchmark output: {record}")
    return {"seconds": float(elapsed[1]), "checksum": int(checksum[1]), "process_seconds": record["seconds"]}


def measure(workload, repetitions, args, frozen):
    names = list(VARIANTS)
    warmups = {name: sample(workload["variants"][name]["path"], repetitions, args.cpu, frozen) for name in names}
    expected = warmups["baseline"]["checksum"]
    workload.update(repetitions=repetitions, checksum=expected, warmups=warmups, samples=[])
    for round_index in range(args.rounds):
        order = names[round_index % len(names):] + names[:round_index % len(names)]
        for name in order:
            measured = sample(workload["variants"][name]["path"], repetitions, args.cpu, frozen)
            assert measured["checksum"] == expected, measured
            workload["samples"].append({"round": round_index + 1, "variant": name, **measured})
        print(f"rotating round {round_index + 1}/{args.rounds}", flush=True)
    assert all(record["checksum"] == expected for record in warmups.values())
    workload["medians"] = {name: statistics.median(item["seconds"] for item in workload["samples"]
                                                 if item["variant"] == name) for name in names}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--rounds", type=int, default=10)
    parser.add_argument("--cpu", type=int, default=3)
    parser.add_argument("--build-only", action="store_true")
    args = parser.parse_args()
    args.output = args.output.resolve()
    args.output.mkdir(exist_ok=False)
    frozen = args.output / "source"
    report = {"base_revision": run(["git", "rev-parse", "HEAD"])["stdout"].strip(),
              "source_diff": run(["git", "diff", "HEAD"])["stdout"], "source_hashes": snapshot(frozen),
              "platform": platform.platform(), "cpu": args.cpu, "rounds": args.rounds,
              "versions": {name: run([name, "-V" if name == "chibi-scheme" else "--version"])["stdout"] for name in ["node", "wasm-opt", "chibi-scheme"]},
              "timing": "Internal complete Scheme workload timer; excludes compilation/startup. V8 default tiering.",
              "warmup": "One discarded fresh process per variant; callback workload also repeats full work in process.",
              "builds": [], "workloads": {}}
    runtime = args.output / "runtime.wasm"
    shutil.copyfile(args.runtime, runtime)
    report["runtime"] = artifact(runtime)
    entry = prepare_entry(args.output, report["builds"])
    for name, (relative, repetitions) in WORKLOADS.items():
        workload = build_workload(name, frozen / relative, args.output, frozen, runtime, entry)
        report["workloads"][name] = workload
        print(f"built {name}", flush=True)
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    if not args.build_only:
        for name, (_, repetitions) in WORKLOADS.items():
            measure(report["workloads"][name], repetitions, args, frozen)
            (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
