;; A complete callback pipeline: create captured closures, traverse a shared
;; vector, and retain per-pass results. Only callback code identity is uniform;
;; environments differ on every pass. The closed-form sum is the oracle.
(import (scheme base) (scheme write) (scheme time) (scheme process-context))

;; ---- Callback computation ----

(define width 10000)
(define (input-vector n)
  (let ((items (make-vector n)))
    (let loop ((i 0))
      (if (= i n) items
          (begin (vector-set! items i i) (loop (+ i 1)))))))
(define items (input-vector width))
(define (make-transform scale bias) (lambda (value) (+ (* scale value) bias)))
(define (fold-transformed transform items)
  (let loop ((i 0) (answer 0))
    (if (= i (vector-length items)) answer
        (loop (+ i 1) (+ answer (transform (vector-ref items i)))))))
(define (expected scale bias)
  (+ (* scale (quotient (* width (- width 1)) 2)) (* bias width)))
(define (require-equal actual expected)
  (unless (= actual expected) (error "callback checksum mismatch" actual expected)))
(define (work count)
  (let loop ((remaining count) (checksum 0))
    (if (= remaining 0) checksum
        (let* ((scale (+ 1 (modulo remaining 7)))
               (bias (modulo remaining 11))
               (transform (make-transform scale bias))
               (alias transform)
               (answer (fold-transformed alias items)))
          (require-equal answer (expected scale bias))
          (loop (- remaining 1) (+ checksum answer))))))

;; ---- Timing the full Scheme program ----

(define count (string->number (cadr (command-line))))
(require-equal (fold-transformed (make-transform 2 3) items) (expected 2 3))
;; A full in-process warmup gives each variant the same completed workload.
(define warmup (work count))
(define start (current-jiffy))
(define checksum (work count))
(define seconds (/ (- (current-jiffy) start) (* 1.0 (jiffies-per-second))))
(require-equal checksum warmup)
(display "checksum: ") (write checksum) (newline)
(display "elapsed: ") (write seconds) (display " s") (newline)
