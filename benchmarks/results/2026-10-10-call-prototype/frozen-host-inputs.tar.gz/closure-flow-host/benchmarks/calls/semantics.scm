(import (scheme base) (scheme write) (scheme process-context) (snail typing))

;; ---- Environments, identity, mutation, and order ----

(define (check actual expected)
  (unless (equal? actual expected) (error "call experiment mismatch" actual expected)))
(define (factory value) (lambda (increment) (+ value increment)))
(define one (factory 1))
(define forty (factory 40))
(define alias one)
(check (alias 4) 5)
(check (forty 2) 42)
(check (eq? one alias) #t)
(check (eq? one forty) #f)
(define effects '())
(define (record value) (set! effects (cons value effects)) value)
(check ((begin (record 3) alias) (begin (record 1) 8)) 9)
(check effects '(3 1))
(define mutable one)
(check (mutable 2) 3)
(set! mutable forty)
(check (mutable 2) 42)
(set! mutable one)
(check (mutable (begin (set! mutable forty) 2)) 42)

;; ---- Callback flow and opaque boundaries ----

(define (invoke callback value) (callback value))
(define (id value) value)
(define (double value) (* value 2))
(define (opaque-holder callback) (list callback))
(define stored (car (opaque-holder invoke)))
(check (invoke id 7) 7)
(check (stored double 7) 14)
(define (callback-returner ignored) invoke)
(define escaped-return (apply callback-returner '(0)))
(check (escaped-return double 9) 18)
(define (rest-callback first . callbacks) ((car callbacks) first))
(check (rest-callback 5 double) 10)
(check (call-with-values (lambda () ((lambda () (values 2 3)))) +) 5)

;; ---- Deep tail transfer with an aliased callback ----

(define (bounce callback n) (callback n))
(define (tail n) (if (= n 0) 17 (bounce tail (- n 1))))
(check (tail 200000) 17)

;; ---- Checked entry and result failure controls ----

(: checked (-> i32 i32))
(define (checked value) value)
(define checked-alias checked)
(: wrong-result (-> i32 i32))
(define (wrong-result value) (car (list "bad")))
(define (checked-callback callback value) (callback value))
(define mode (cadr (command-line)))
(cond ((equal? mode "entry") (checked-callback checked-alias "bad"))
      ((equal? mode "result") (checked-callback wrong-result 1))
      ((equal? mode "values") (invoke (lambda (x) (values x x)) 1) (+ (invoke (lambda (x) (values x x)) 1) 1))
      ((equal? mode "uninitialized")
       (let () (define result (later 1)) (define later (lambda (x) x)) result))
      (else (display "call-flow semantics passed") (newline)))
