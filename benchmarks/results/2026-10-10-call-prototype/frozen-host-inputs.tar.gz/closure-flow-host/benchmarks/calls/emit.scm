;; Emit a frozen Scheme workload under one call-flow setting. The runtime and
;; Binaryen steps are separately timed by measure.py, outside workload timers.
(import (scheme base) (scheme write) (scheme process-context)
        (snail-scheme compiler) (snail-scheme call-flow)
        (snail-scheme chromium-trace))
(define arguments (cdr (command-line)))
(define root (list-ref arguments 0))
(define input (list-ref arguments 1))
(define output (list-ref arguments 2))
(define mode (list-ref arguments 3))
(with-chromium-trace-to
 (string-append output ".trace.json")
 (lambda ()
   (parameterize ((call-flow-enabled (equal? mode "direct")))
     (source-file->wat-file root input output
                            '((rust-call-with-result . "snail.rust"))
                            (list (string-append root "/tests/libraries"))))))

(write (call-flow-statistics)) (newline)
