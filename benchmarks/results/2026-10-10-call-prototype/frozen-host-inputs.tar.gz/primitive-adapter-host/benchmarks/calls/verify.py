#!/usr/bin/env python3
"""Check call-flow output against established backend and typing expectations."""

import argparse
import json
import runpy
import subprocess
from pathlib import Path

from measure import ROOT, emit, merge, optimize, prepare_entry

OUT = ROOT / "build/call-prototype/verification"


def execute(path, stdout, diagnostic="", arguments=()):
    command = ["node", "--no-warnings", ROOT / "scripts/run-wasi.mjs", path, *arguments]
    result = subprocess.run(list(map(str, command)), text=True, capture_output=True, timeout=120)
    assert (result.returncode != 0) == bool(diagnostic), (command, result)
    assert result.stdout == stdout, (command, result.stdout, result.stderr)
    assert diagnostic in result.stderr if diagnostic else result.stderr == "", result.stderr
    return {"command": list(map(str, command)), "status": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def build(name, source, mode, entry, report):
    wat = emit(name, mode, source, OUT, ROOT, report["builds"])
    merged = merge(wat, ROOT / "build/call-prototype/runtime.wasm", entry, report["builds"])
    binary = OUT / f"{name}-{mode}.wasm"
    optimize(merged, binary, 40, report["builds"])
    return binary


def main():
    global OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", default="direct")
    parser.add_argument("--output", type=Path, default=OUT)
    args = parser.parse_args()
    OUT = args.output.resolve()
    OUT.mkdir(exist_ok=True)
    (ROOT / "build/backend-tests").mkdir(exist_ok=True)
    report = {"builds": [], "checks": []}
    entry = prepare_entry(OUT, report["builds"])
    backend = runpy.run_path(str(ROOT / "scripts/test-backend"), run_name="fixture_expectations")
    for name, stdout in backend["SUCCESSES"].items():
        binary = build(name, ROOT / "tests/programs" / f"{name}.scm", args.mode, entry, report)
        report["checks"].append(execute(binary, stdout))
        print(f"passed {args.mode} Wasm {name}", flush=True)
    binary = build("backend-errors", ROOT / "tests/programs/backend-errors.scm", args.mode, entry, report)
    for argument, diagnostic in backend["ERRORS"].items():
        report["checks"].append(execute(binary, "", diagnostic, [argument]))
    for mode in ("baseline", args.mode):
        binary = build("semantics", ROOT / "benchmarks/calls/semantics.scm", mode, entry, report)
        for argument, stdout, diagnostic in [("ok", "call-flow semantics passed\n", ""),
                                             ("entry", "", "incorrect value type"),
                                             ("result", "", "incorrect value type"),
                                             ("values", "", "expected a single value"),
                                             ("uninitialized", "", "read of an uninitialized binding")]:
            report["checks"].append(execute(binary, stdout, diagnostic, [argument]))
    typing = runpy.run_path(str(ROOT / "scripts/test-typing"), run_name="typing_expectations")
    selected = [name for name in typing["CASES"] if name.startswith("tail-") or name.startswith("poly-")]
    for name in selected:
        program, stdout, diagnostic = typing["CASES"][name]
        source = OUT / f"{name}.scm"
        source.write_text(typing["IMPORTS"] + program + "\n")
        binary = build(name, source, args.mode, entry, report)
        report["checks"].append(execute(binary, stdout, diagnostic))
        print(f"passed {args.mode} typing {name}", flush=True)
    (OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"passed {len(report['checks'])} linked Wasm executions", flush=True)


if __name__ == "__main__":
    main()
