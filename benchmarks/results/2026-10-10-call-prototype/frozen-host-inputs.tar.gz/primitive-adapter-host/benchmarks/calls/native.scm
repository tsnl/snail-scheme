;; Execute the same optional call-target analysis through native code generation.
(import (scheme base) (scheme process-context) (snail-scheme native)
        (snail-scheme call-flow) (snail-scheme wasm) (snail-scheme chromium-trace))
(define arguments (cdr (command-line)))
(with-chromium-trace-to
 (string-append (list-ref arguments 2) ".trace.json")
 (lambda ()
   (parameterize ((call-flow-enabled (member (list-ref arguments 3) '("direct" "combined")))
                  (primitive-adapters-enabled (member (list-ref arguments 3) '("primitives" "combined"))))
     (build-native (list-ref arguments 0) (list-ref arguments 1) (list-ref arguments 2)))))
