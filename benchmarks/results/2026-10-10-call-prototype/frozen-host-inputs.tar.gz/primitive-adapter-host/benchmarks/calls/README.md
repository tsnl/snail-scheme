# Throwaway call optimization experiment

This branch is evidence gathering from production base `5ad489e`; it is not a
proposal to land the experimental pass. Production already emits direct workers
for immutable lambda bindings and runs Binaryen at inlining threshold 40 with
convergence. The prototype adds conservative information about aliases, callback
parameters, returned closures, and assigned bindings. Inlining thresholds 80 and
160 are separate Binaryen ablations.

## What the experiment changes

`src/snail-scheme/call-flow.sld` computes a finite set of possible lambda bodies
for each expression and binding. Scalar and opaque values have distinct markers.
The equations join all assignments and call arguments, including recursive call
edges. An opaque call or heap operation makes concrete closure arguments escape;
escaped procedures receive unknown arguments and their returned closures escape
transitively. Library results and the optional exported CLI handler seed the same
escape rule. A 256-round limit abandons the entire result if it cannot converge.

Only a singleton lambda set can add a direct call. The emitter still evaluates
all operands, then the actual operator, and extracts that closure's environment.
It retains initialization checks, argument normalization, declared entry/result
contracts, mutation, identity, and the existing proper tail-call machinery. An
arity mismatch or rest lambda uses the existing generic adapter. No representation
or numeric optimization changes, and no Scheme bodies are copied or rewritten.

The pass is disabled by default. `emit.scm` and `native.scm` enable it explicitly.
The simplify skill's independent behavioral review checked the escape invariant,
including closures hidden in containers, callbacks returning callbacks, and
exported entry points. The implementation follows that model; exhaustive IR
dispatch and the fixed-point operation remain cohesive rather than split solely
to meet a line count.

## Work and timing boundaries

The callback program creates a closure with different captured scale/bias values
on each traversal, aliases it, passes it to a higher-order fold, and checks an
independent closed-form answer after every traversal. The timed Scheme driver
performs 4,096 traversals of a preallocated 10,000-element vector. It is a focused
monomorphic-callback workload, not a prediction for arbitrary higher-order code.
It includes one complete in-process warmup before timing.

The unchanged `benchmarks/cpu.scm` and `benchmarks/memory.scm` programs are measured
at 256 and 64 repetitions respectively. Their existing untimed correctness checks
remain. The compiler uses `benchmarks/compile-self.scm` and an unchanged source
snapshot at `803d169`, which adds the independent append stack-usage and numeric
printing fixes needed for compiler self-compilation. The experimental pass is not
part of that input compiler; both executable variants compile the same frozen
production source and must match the Chibi reference WAT byte for byte.

Compilation and process startup are outside internal workload timers. V8 uses its
default tiering. Each executable starts in a fresh process. One full process run
per variant is discarded before samples. Main workloads use ten rotating rounds;
the compiler uses six alternating baseline/direct rounds. All timed processes are
pinned to logical CPU 3. The parent agent reserved a quiet window after its builds
and benchmarks completed; unrelated operating-system activity remains possible.

## Reproduction

With the tools and BDWGC paths described in `doc/backend.md` and `doc/native.md`,
build one unchanged Rust runtime, then:

```sh
python3 benchmarks/calls/measure.py \
  --runtime build/call-prototype/runtime.wasm \
  --output build/call-prototype/reproduction --build-only
python3 benchmarks/calls/verify.py
```

`measure.py` freezes source files before emission, assembles and merges the full
Rust-linked Wasm modules, and varies only call flow and the inlining threshold.
Its report contains commands, build durations, trace events, source/artifact
hashes, sizes, and static call counts. `sample.py` verifies those hashes before
sampling existing artifacts. It additionally expects native callback binaries
and the compiler artifacts prepared by `compiler-probe.py`; that script consumes
an archived `803d169` source tree and a runtime built from that same revision.
The separate preparation preserves the source baseline and avoids measuring
compilation concurrently with execution.

```sh
python3 benchmarks/calls/sample.py \
  --report build/call-prototype/reproduction/report.json \
  --cpu 3 --rounds 10 --compiler-rounds 6 \
  --competition-note 'Describe other work running on the host.'
```

## Correctness evidence

`make test`, `make check`, and `git diff --check` passed. The experiment executed
68 linked Wasm checks: the existing backend successes/errors, polymorphism and
typed-tail counterexamples, and a new semantics fixture under baseline/direct
and the larger inlining thresholds. The fixture exercises operand/operator order,
changing closure environments, identity, mutation, opaque callbacks, callbacks
returning callbacks, rest arguments, multiple values, initialization errors,
checked domains/results, and 200,000 tail transfers.

The native fixture also passed with `SNAIL_NATIVE_GC_INTERVAL=17`, including all
four expected failure modes. Both native callback programs executed and matched
the Scheme checksum. All three baseline workload WAT files are byte-identical to
emission by the production compiler. Every timed compiler output is checked
against the same Chibi reference digest.
