#!/usr/bin/env python3
"""Build both call-flow compiler variants over an unchanged frozen compiler source."""

import json
import subprocess
from pathlib import Path

from measure import ROOT, artifact, digest, emit, merge, optimize, prepare_entry, run, source_counts

OUT = ROOT / "build/call-prototype/compiler-probe"
SOURCE = ROOT / "build/call-prototype/compiler-source"


def main():
    OUT.mkdir(exist_ok=True)
    report = {"input_revision": "803d169fd56cfce87dc4b0d5a1a7d4ad82cb837c", "builds": [], "variants": {}}
    report["source_hashes"] = {str(p.relative_to(SOURCE)): digest(p) for p in sorted(SOURCE.rglob("*"))
                               if p.is_file() and p.suffix in (".scm", ".sld", ".rs", ".mjs")}
    report["runtime"] = artifact(ROOT / "build/call-prototype/compiler-runtime.wasm")
    entry = prepare_entry(OUT, report["builds"])
    reference = OUT / "reference.wat"
    report["builds"].append(run(["chibi-scheme", "-h512M", "-I", SOURCE / "src", SOURCE / "benchmarks/compile-self.scm",
                                SOURCE, SOURCE / "benchmarks/compile-self.scm", reference, "chibi-reference"]))
    report["reference"] = artifact(reference)
    for mode in ("baseline", "direct"):
        wat = OUT / f"compiler-{mode}.wat"
        report["builds"].append(run(["chibi-scheme", "-h512M", "-I", ROOT / "src", ROOT / "benchmarks/calls/emit.scm",
                                    SOURCE, SOURCE / "benchmarks/compile-self.scm", wat, mode]))
        merged = merge(wat, ROOT / "build/call-prototype/compiler-runtime.wasm", entry, report["builds"])
        binary = OUT / f"compiler-{mode}.wasm"
        optimize(merged, binary, 40, report["builds"])
        report["variants"][mode] = {"wat": artifact(wat), "counts": source_counts(wat), "binary": artifact(binary),
                                   "trace": json.loads(Path(str(wat) + ".trace.json").read_text())}
        (OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        print(f"built compiler {mode}", flush=True)
    print("compiler artifacts ready for a separate, quiet measurement", flush=True)


if __name__ == "__main__":
    main()
