#!/usr/bin/env python3
"""Measure frozen call experiment artifacts only after concurrent build work stops."""

import argparse
import json
import re
import statistics
from datetime import datetime, timezone
from pathlib import Path

from measure import ROOT, WORKLOADS, artifact, digest, measure, run


# ---- Immutable inputs ----


def require_artifact(record):
    assert digest(Path(record["path"])) == record["sha256"], record["path"]


def load_report(path):
    report = json.loads(path.read_text())
    for relative, expected in report["source_hashes"].items():
        assert digest(path.parent / "source" / relative) == expected, relative
    require_artifact(report["runtime"])
    for workload in report["workloads"].values():
        for variant in workload["variants"].values():
            require_artifact(variant)
    return report


def save(path, report):
    path.write_text(json.dumps(report, indent=2) + "\n")


# ---- Actual native callback program ----


def native_sample(command, cpu):
    execution = run(["taskset", "-c", cpu, *command, WORKLOADS["callbacks"][1]])
    seconds = re.search(r"elapsed: ([\d.eE+-]+) s", execution["stdout"])
    checksum = re.search(r"checksum: (\d+)", execution["stdout"])
    assert seconds and checksum and not execution["stderr"], execution
    return {"seconds": float(seconds[1]), "checksum": int(checksum[1]), "command": execution["command"]}


def native_benchmark(args):
    variants = {mode: artifact(ROOT / f"build/call-prototype/callbacks.native-{mode}")
                for mode in ("baseline", "direct")}
    result = {"variants": variants, "samples": [], "warmups": {}}
    for name, binary in variants.items():
        result["warmups"][name] = native_sample([binary["path"]], args.cpu)
    expected = result["warmups"]["baseline"]["checksum"]
    for index in range(args.rounds):
        for mode in (("direct", "baseline") if index % 2 else ("baseline", "direct")):
            sample = native_sample([variants[mode]["path"]], args.cpu)
            assert sample["checksum"] == expected
            result["samples"].append({"round": index + 1, "variant": mode, **sample})
    result["medians"] = medians(result["samples"], variants)
    return result


def medians(samples, names):
    return {name: statistics.median(sample["seconds"] for sample in samples if sample["variant"] == name)
            for name in names}


# ---- The compiled compiler, with byte-for-byte results ----


def compiler_sample(mode, report, cpu, label):
    directory = ROOT / "build/call-prototype/compiler-probe"
    source = ROOT / "build/call-prototype/compiler-source"
    output = directory / f"sample-{label}-{mode}.wat"
    binary = report["variants"][mode]["binary"]["path"]
    execution = run(["taskset", "-c", cpu, "node", "--no-warnings", ROOT / "scripts/run-wasi.mjs", binary,
                     source, source / "benchmarks/compile-self.scm", output, mode])
    timing = re.search(r"\+!CSVLINE!\+[^,]+,compiler-self,([\d.eE+-]+)", execution["stdout"])
    assert timing and not execution["stderr"], execution
    assert digest(output) == report["reference"]["sha256"], output
    return {"seconds": float(timing[1]), "command": execution["command"], "output_sha256": digest(output),
            "trace": str(output) + ".trace.json", "process_seconds": execution["seconds"]}


def compiler_benchmark(args):
    path = ROOT / "build/call-prototype/compiler-probe/report.json"
    report = json.loads(path.read_text())
    for record in report["variants"].values():
        require_artifact(record["binary"])
    for relative, expected in report["source_hashes"].items():
        assert digest(ROOT / "build/call-prototype/compiler-source" / relative) == expected
    report["cpu"], report["rounds"], report["samples"] = args.cpu, args.compiler_rounds, []
    report["warmups"] = {mode: compiler_sample(mode, report, args.cpu, "warmup") for mode in ("baseline", "direct")}
    for index in range(args.compiler_rounds):
        for mode in (("direct", "baseline") if index % 2 else ("baseline", "direct")):
            sample = compiler_sample(mode, report, args.cpu, index + 1)
            report["samples"].append({"round": index + 1, "variant": mode, **sample})
        save(path, report)
        print(f"compiler rotating round {index + 1}/{args.compiler_rounds}", flush=True)
    report["medians"] = medians(report["samples"], ("baseline", "direct"))
    save(path, report)
    return str(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--cpu", type=int, default=3)
    parser.add_argument("--rounds", type=int, default=10)
    parser.add_argument("--compiler-rounds", type=int, default=6)
    parser.add_argument("--competition-note", required=True)
    args = parser.parse_args()
    report = load_report(args.report)
    report.update(cpu=args.cpu, rounds=args.rounds, competition=args.competition_note,
                  measured_at=datetime.now(timezone.utc).isoformat(), loadavg_before=Path('/proc/loadavg').read_text(),
                  cpu_model=next(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
                                 if line.startswith('model name')))
    for name, (_, repetitions) in WORKLOADS.items():
        print(f"measuring {name}", flush=True)
        measure(report["workloads"][name], repetitions, args, args.report.parent / "source")
        save(args.report, report)
    report["native_callbacks"] = native_benchmark(args)
    save(args.report, report)
    report["compiler_report"] = compiler_benchmark(args)
    report["loadavg_after"] = Path('/proc/loadavg').read_text()
    save(args.report, report)


if __name__ == "__main__":
    main()
