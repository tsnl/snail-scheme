(func $function138 (type $7) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref null $type72)) (result i64)
  (local $5 (ref null $type72))
  (local $6 (ref null $type72))
  (local $7 (ref null $type72))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $scratch i64)
  (local $scratch_12 (ref null $type72))
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (local.set $4
     (call $function139
      (call $foreign4
       (global.get $global471)
      )
      (call $foreign4
       (global.get $global472)
      )
      (block (result i64)
       (local.set $scratch
        (call $foreign4
         (global.get $global473)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global485)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function138
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (struct.set $type79 0
     (global.get $global479)
     (local.get $4)
    )
    (drop
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (local.set $7
     (global.get $global474)
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (ref.is_null
        (local.get $4)
       )
       (then
        (ref.is_null
         (local.get $7)
        )
       )
       (else
        (if (result i32)
         (ref.is_null
          (local.get $7)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global533)
           )
          )
          (if (result i32)
           (call $function148
            (struct.get $type72 0
             (local.get $4)
            )
            (struct.get $type72 0
             (local.get $7)
            )
           )
           (then
            (local.set $6
             (struct.get $type72 1
              (local.get $4)
             )
            )
            (local.set $5
             (struct.get $type72 1
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (global.get $ready530)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global530)
             )
            )
            (if (result i32)
             (ref.is_null
              (local.get $6)
             )
             (then
              (ref.is_null
               (local.get $5)
              )
             )
             (else
              (if (result i32)
               (ref.is_null
                (local.get $5)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global533)
                 )
                )
                (if (result i32)
                 (call $function148
                  (struct.get $type72 0
                   (local.get $6)
                  )
                  (struct.get $type72 0
                   (local.get $5)
                  )
                 )
                 (then
                  (local.set $6
                   (struct.get $type72 1
                    (local.get $6)
                   )
                  )
                  (local.set $5
                   (struct.get $type72 1
                    (local.get $5)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready530)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global530)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $6)
                   )
                   (then
                    (ref.is_null
                     (local.get $5)
                    )
                   )
                   (else
                    (if (result i32)
                     (ref.is_null
                      (local.get $5)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global533)
                       )
                      )
                      (if (result i32)
                       (call $function148
                        (struct.get $type72 0
                         (local.get $6)
                        )
                        (struct.get $type72 0
                         (local.get $5)
                        )
                       )
                       (then
                        (local.set $6
                         (struct.get $type72 1
                          (local.get $6)
                         )
                        )
                        (local.set $5
                         (struct.get $type72 1
                          (local.get $5)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready530)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global530)
                         )
                        )
                        (if (result i32)
                         (ref.is_null
                          (local.get $6)
                         )
                         (then
                          (ref.is_null
                           (local.get $5)
                          )
                         )
                         (else
                          (if (result i32)
                           (ref.is_null
                            (local.get $5)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global533)
                             )
                            )
                            (if (result i32)
                             (call $function148
                              (struct.get $type72 0
                               (local.get $6)
                              )
                              (struct.get $type72 0
                               (local.get $5)
                              )
                             )
                             (then
                              (local.set $6
                               (struct.get $type72 1
                                (local.get $6)
                               )
                              )
                              (local.set $5
                               (struct.get $type72 1
                                (local.get $5)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready530)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global530)
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $6)
                               )
                               (then
                                (ref.is_null
                                 (local.get $5)
                                )
                               )
                               (else
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $5)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global533)
                                   )
                                  )
                                  (if (result i32)
                                   (call $function148
                                    (struct.get $type72 0
                                     (local.get $6)
                                    )
                                    (struct.get $type72 0
                                     (local.get $5)
                                    )
                                   )
                                   (then
                                    (local.set $6
                                     (struct.get $type72 1
                                      (local.get $6)
                                     )
                                    )
                                    (local.set $5
                                     (struct.get $type72 1
                                      (local.get $5)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready530)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global530)
                                     )
                                    )
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $6)
                                     )
                                     (then
                                      (ref.is_null
                                       (local.get $5)
                                      )
                                     )
                                     (else
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $5)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global533)
                                         )
                                        )
                                        (if (result i32)
                                         (call $function148
                                          (struct.get $type72 0
                                           (local.get $6)
                                          )
                                          (struct.get $type72 0
                                           (local.get $5)
                                          )
                                         )
                                         (then
                                          (local.set $6
                                           (struct.get $type72 1
                                            (local.get $6)
                                           )
                                          )
                                          (local.set $5
                                           (struct.get $type72 1
                                            (local.get $5)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready530)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global530)
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $6)
                                           )
                                           (then
                                            (ref.is_null
                                             (local.get $5)
                                            )
                                           )
                                           (else
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $5)
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global533)
                                               )
                                              )
                                              (if (result i32)
                                               (call $function148
                                                (struct.get $type72 0
                                                 (local.get $6)
                                                )
                                                (struct.get $type72 0
                                                 (local.get $5)
                                                )
                                               )
                                               (then
                                                (local.set $6
                                                 (struct.get $type72 1
                                                  (local.get $6)
                                                 )
                                                )
                                                (local.set $5
                                                 (struct.get $type72 1
                                                  (local.get $5)
                                                 )
                                                )
                                                (if
                                                 (i32.eqz
                                                  (global.get $ready530)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global530)
                                                 )
                                                )
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $6)
                                                 )
                                                 (then
                                                  (ref.is_null
                                                   (local.get $5)
                                                  )
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $5)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global533)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (call $function148
                                                      (struct.get $type72 0
                                                       (local.get $6)
                                                      )
                                                      (struct.get $type72 0
                                                       (local.get $5)
                                                      )
                                                     )
                                                     (then
                                                      (local.set $6
                                                       (struct.get $type72 1
                                                        (local.get $6)
                                                       )
                                                      )
                                                      (local.set $5
                                                       (struct.get $type72 1
                                                        (local.get $5)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (global.get $ready530)
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global530)
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $6)
                                                       )
                                                       (then
                                                        (ref.is_null
                                                         (local.get $5)
                                                        )
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (ref.is_null
                                                          (local.get $5)
                                                         )
                                                         (then
                                                          (i32.const 0)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global533)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (call $function148
                                                            (struct.get $type72 0
                                                             (local.get $6)
                                                            )
                                                            (struct.get $type72 0
                                                             (local.get $5)
                                                            )
                                                           )
                                                           (then
                                                            (local.set $6
                                                             (struct.get $type72 1
                                                              (local.get $6)
                                                             )
                                                            )
                                                            (local.set $5
                                                             (struct.get $type72 1
                                                              (local.get $5)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (global.get $ready530)
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global530)
                                                             )
                                                            )
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $6)
                                                             )
                                                             (then
                                                              (ref.is_null
                                                               (local.get $5)
                                                              )
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (ref.is_null
                                                                (local.get $5)
                                                               )
                                                               (then
                                                                (i32.const 0)
                                                               )
                                                               (else
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global533)
                                                                 )
                                                                )
                                                                (if (result i32)
                                                                 (call $function148
                                                                  (struct.get $type72 0
                                                                   (local.get $6)
                                                                  )
                                                                  (struct.get $type72 0
                                                                   (local.get $5)
                                                                  )
                                                                 )
                                                                 (then
                                                                  (call $function147
                                                                   (struct.get $type72 1
                                                                    (local.get $6)
                                                                   )
                                                                   (block (result (ref null $type72))
                                                                    (local.set $scratch_12
                                                                     (struct.get $type72 1
                                                                      (local.get $5)
                                                                     )
                                                                    )
                                                                    (if
                                                                     (i32.eqz
                                                                      (global.get $ready530)
                                                                     )
                                                                     (then
                                                                      (unreachable)
                                                                     )
                                                                    )
                                                                    (drop
                                                                     (ref.as_non_null
                                                                      (global.get $global530)
                                                                     )
                                                                    )
                                                                    (local.get $scratch_12)
                                                                   )
                                                                  )
                                                                 )
                                                                 (else
                                                                  (i32.const 0)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                           (else
                                                            (i32.const 0)
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (else
                                                      (i32.const 0)
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (i32.const 0)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (i32.const 0)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                             (else
                              (i32.const 0)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (i32.const 0)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
