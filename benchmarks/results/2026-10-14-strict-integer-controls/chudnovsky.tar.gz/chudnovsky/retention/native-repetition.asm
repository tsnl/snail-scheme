0000000000049640 <f.66>:
   49640:	55                   	push   rbp
   49641:	41 57                	push   r15
   49643:	41 56                	push   r14
   49645:	41 55                	push   r13
   49647:	41 54                	push   r12
   49649:	53                   	push   rbx
   4964a:	48 81 ec 88 01 00 00 	sub    rsp,0x188
   49651:	48 89 fb             	mov    rbx,rdi
   49654:	4c 8d 7c 24 70       	lea    r15,[rsp+0x70]
   49659:	31 c9                	xor    ecx,ecx
   4965b:	4c 8d 74 24 50       	lea    r14,[rsp+0x50]
   49660:	eb 30                	jmp    49692 <f.66+0x52>
   49662:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   49669:	1f 84 00 00 00 00 00 
   49670:	31 c9                	xor    ecx,ecx
   49672:	48 89 4c 24 68       	mov    QWORD PTR [rsp+0x68],rcx
   49677:	48 83 7c 24 58 00    	cmp    QWORD PTR [rsp+0x58],0x0
   4967d:	74 13                	je     49692 <f.66+0x52>
   4967f:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
   49684:	48 89 05 e5 0e 02 00 	mov    QWORD PTR [rip+0x20ee5],rax        # 6a570 <native_roots>
   4968b:	48 ff 0d 0e 0e 02 00 	dec    QWORD PTR [rip+0x20e0e]        # 6a4a0 <root_depth>
   49692:	48 c7 44 24 58 19 00 	mov    QWORD PTR [rsp+0x58],0x19
   49699:	00 00 
   4969b:	48 c7 44 24 60 00 00 	mov    QWORD PTR [rsp+0x60],0x0
   496a2:	00 00 
   496a4:	48 8b 05 c5 0e 02 00 	mov    rax,QWORD PTR [rip+0x20ec5]        # 6a570 <native_roots>
   496ab:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
   496b0:	4c 89 35 b9 0e 02 00 	mov    QWORD PTR [rip+0x20eb9],r14        # 6a570 <native_roots>
   496b7:	48 8b 05 e2 0d 02 00 	mov    rax,QWORD PTR [rip+0x20de2]        # 6a4a0 <root_depth>
   496be:	48 ff c0             	inc    rax
   496c1:	48 89 05 d8 0d 02 00 	mov    QWORD PTR [rip+0x20dd8],rax        # 6a4a0 <root_depth>
   496c8:	48 3b 05 d9 0d 02 00 	cmp    rax,QWORD PTR [rip+0x20dd9]        # 6a4a8 <peak_root_depth>
   496cf:	76 07                	jbe    496d8 <f.66+0x98>
   496d1:	48 89 05 d0 0d 02 00 	mov    QWORD PTR [rip+0x20dd0],rax        # 6a4a8 <peak_root_depth>
   496d8:	48 89 4c 24 68       	mov    QWORD PTR [rsp+0x68],rcx
   496dd:	0f 57 c0             	xorps  xmm0,xmm0
   496e0:	41 0f 11 07          	movups XMMWORD PTR [r15],xmm0
   496e4:	49 c7 47 10 00 00 00 	mov    QWORD PTR [r15+0x10],0x0
   496eb:	00 
   496ec:	48 83 eb 01          	sub    rbx,0x1
   496f0:	0f 82 7a 37 00 00    	jb     4ce70 <f.66+0x3830>
   496f6:	48 8b 3d 4b 0d 02 00 	mov    rdi,QWORD PTR [rip+0x20d4b]        # 6a448 <g.82>
   496fd:	48 c7 44 24 60 04 00 	mov    QWORD PTR [rsp+0x60],0x4
   49704:	00 00 
   49706:	e8 75 7c fc ff       	call   11380 <hide_i64>
   4970b:	48 89 c5             	mov    rbp,rax
   4970e:	48 8b 3d 3b 0d 02 00 	mov    rdi,QWORD PTR [rip+0x20d3b]        # 6a450 <g.83>
   49715:	48 c7 44 24 60 04 00 	mov    QWORD PTR [rsp+0x60],0x4
   4971c:	00 00 
   4971e:	e8 5d 7c fc ff       	call   11380 <hide_i64>
   49723:	49 89 c5             	mov    r13,rax
   49726:	48 8b 3d 2b 0d 02 00 	mov    rdi,QWORD PTR [rip+0x20d2b]        # 6a458 <g.84>
   4972d:	48 c7 44 24 60 04 00 	mov    QWORD PTR [rsp+0x60],0x4
   49734:	00 00 
   49736:	e8 45 7c fc ff       	call   11380 <hide_i64>
   4973b:	48 83 3d cd 0c 02 00 	cmp    QWORD PTR [rip+0x20ccd],0x0        # 6a410 <g.75>
   49742:	00 
   49743:	0f 84 87 45 00 00    	je     4dcd0 <f.66+0x4690>
   49749:	4c 39 ed             	cmp    rbp,r13
   4974c:	0f 8f 1e ff ff ff    	jg     49670 <f.66+0x30>
   49752:	48 83 3d ae 0c 02 00 	cmp    QWORD PTR [rip+0x20cae],0x0        # 6a408 <g.74>
   49759:	00 
   4975a:	0f 84 70 45 00 00    	je     4dcd0 <f.66+0x4690>
   49760:	49 89 c4             	mov    r12,rax
   49763:	48 c7 44 24 60 04 00 	mov    QWORD PTR [rsp+0x60],0x4
   4976a:	00 00 
   4976c:	48 89 ef             	mov    rdi,rbp
   4976f:	e8 7c 45 00 00       	call   4dcf0 <f.59>
   49774:	48 83 ec 08          	sub    rsp,0x8
   49778:	80 3d 99 0c 02 00 00 	cmp    BYTE PTR [rip+0x20c99],0x0        # 6a418 <g.76>
   4977f:	0f 84 4b 45 00 00    	je     4dcd0 <f.66+0x4690>
   49785:	48 83 3d 83 0c 02 00 	cmp    QWORD PTR [rip+0x20c83],0x0        # 6a410 <g.75>
   4978c:	00 
   4978d:	0f 84 3d 45 00 00    	je     4dcd0 <f.66+0x4690>
   49793:	49 89 c6             	mov    r14,rax
   49796:	4c 01 e5             	add    rbp,r12
   49799:	49 39 ed             	cmp    r13,rbp
   4979c:	7d 12                	jge    497b0 <f.66+0x170>
   4979e:	45 31 ed             	xor    r13d,r13d
   497a1:	e9 ca 34 00 00       	jmp    4cc70 <f.66+0x3630>
   497a6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   497ad:	00 00 00 
   497b0:	48 83 3d 50 0c 02 00 	cmp    QWORD PTR [rip+0x20c50],0x0        # 6a408 <g.74>
   497b7:	00 
   497b8:	0f 84 12 45 00 00    	je     4dcd0 <f.66+0x4690>
   497be:	4c 89 b4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r14
   497c5:	00 
   497c6:	48 c7 44 24 60 05 00 	mov    QWORD PTR [rsp+0x60],0x5
   497cd:	00 00 
   497cf:	48 89 ef             	mov    rdi,rbp
   497d2:	e8 19 45 00 00       	call   4dcf0 <f.59>
   497d7:	48 83 ec 08          	sub    rsp,0x8
   497db:	80 3d 36 0c 02 00 00 	cmp    BYTE PTR [rip+0x20c36],0x0        # 6a418 <g.76>
   497e2:	0f 84 e8 44 00 00    	je     4dcd0 <f.66+0x4690>
   497e8:	48 83 3d 20 0c 02 00 	cmp    QWORD PTR [rip+0x20c20],0x0        # 6a410 <g.75>
   497ef:	00 
   497f0:	0f 84 da 44 00 00    	je     4dcd0 <f.66+0x4690>
   497f6:	49 89 c7             	mov    r15,rax
   497f9:	4c 01 e5             	add    rbp,r12
   497fc:	49 39 ed             	cmp    r13,rbp
   497ff:	7d 08                	jge    49809 <f.66+0x1c9>
   49801:	45 31 e4             	xor    r12d,r12d
   49804:	e9 05 33 00 00       	jmp    4cb0e <f.66+0x34ce>
   49809:	48 83 3d f7 0b 02 00 	cmp    QWORD PTR [rip+0x20bf7],0x0        # 6a408 <g.74>
   49810:	00 
   49811:	0f 84 b9 44 00 00    	je     4dcd0 <f.66+0x4690>
   49817:	4c 89 7c 24 10       	mov    QWORD PTR [rsp+0x10],r15
   4981c:	4c 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r15
   49823:	00 
   49824:	4c 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r14
   4982b:	00 
   4982c:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   49833:	00 00 
   49835:	48 89 ef             	mov    rdi,rbp
   49838:	e8 b3 44 00 00       	call   4dcf0 <f.59>
   4983d:	48 83 ec 08          	sub    rsp,0x8
   49841:	80 3d d0 0b 02 00 00 	cmp    BYTE PTR [rip+0x20bd0],0x0        # 6a418 <g.76>
   49848:	0f 84 82 44 00 00    	je     4dcd0 <f.66+0x4690>
   4984e:	48 83 3d ba 0b 02 00 	cmp    QWORD PTR [rip+0x20bba],0x0        # 6a410 <g.75>
   49855:	00 
   49856:	0f 84 74 44 00 00    	je     4dcd0 <f.66+0x4690>
   4985c:	49 89 c7             	mov    r15,rax
   4985f:	4c 01 e5             	add    rbp,r12
   49862:	49 39 ed             	cmp    r13,rbp
   49865:	7d 08                	jge    4986f <f.66+0x22f>
   49867:	45 31 ed             	xor    r13d,r13d
   4986a:	e9 30 31 00 00       	jmp    4c99f <f.66+0x335f>
   4986f:	48 83 3d 91 0b 02 00 	cmp    QWORD PTR [rip+0x20b91],0x0        # 6a408 <g.74>
   49876:	00 
   49877:	0f 84 53 44 00 00    	je     4dcd0 <f.66+0x4690>
   4987d:	4c 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r15
   49884:	00 
   49885:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4988a:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49891:	00 
   49892:	4c 89 b4 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r14
   49899:	00 
   4989a:	48 c7 44 24 60 07 00 	mov    QWORD PTR [rsp+0x60],0x7
   498a1:	00 00 
   498a3:	48 89 ef             	mov    rdi,rbp
   498a6:	e8 45 44 00 00       	call   4dcf0 <f.59>
   498ab:	48 83 ec 08          	sub    rsp,0x8
   498af:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
   498b4:	80 3d 5d 0b 02 00 00 	cmp    BYTE PTR [rip+0x20b5d],0x0        # 6a418 <g.76>
   498bb:	0f 84 0f 44 00 00    	je     4dcd0 <f.66+0x4690>
   498c1:	48 83 3d 47 0b 02 00 	cmp    QWORD PTR [rip+0x20b47],0x0        # 6a410 <g.75>
   498c8:	00 
   498c9:	0f 84 01 44 00 00    	je     4dcd0 <f.66+0x4690>
   498cf:	4c 01 e5             	add    rbp,r12
   498d2:	49 39 ed             	cmp    r13,rbp
   498d5:	7d 0d                	jge    498e4 <f.66+0x2a4>
   498d7:	45 31 e4             	xor    r12d,r12d
   498da:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   498df:	e9 49 2f 00 00       	jmp    4c82d <f.66+0x31ed>
   498e4:	48 83 3d 1c 0b 02 00 	cmp    QWORD PTR [rip+0x20b1c],0x0        # 6a408 <g.74>
   498eb:	00 
   498ec:	0f 84 de 43 00 00    	je     4dcd0 <f.66+0x4690>
   498f2:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   498f7:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   498fe:	00 
   498ff:	4c 89 bc 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r15
   49906:	00 
   49907:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4990c:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49913:	00 
   49914:	4c 89 b4 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r14
   4991b:	00 
   4991c:	48 c7 44 24 60 08 00 	mov    QWORD PTR [rsp+0x60],0x8
   49923:	00 00 
   49925:	48 89 ef             	mov    rdi,rbp
   49928:	e8 c3 43 00 00       	call   4dcf0 <f.59>
   4992d:	48 83 ec 08          	sub    rsp,0x8
   49931:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
   49936:	80 3d db 0a 02 00 00 	cmp    BYTE PTR [rip+0x20adb],0x0        # 6a418 <g.76>
   4993d:	0f 84 8d 43 00 00    	je     4dcd0 <f.66+0x4690>
   49943:	48 83 3d c5 0a 02 00 	cmp    QWORD PTR [rip+0x20ac5],0x0        # 6a410 <g.75>
   4994a:	00 
   4994b:	0f 84 7f 43 00 00    	je     4dcd0 <f.66+0x4690>
   49951:	4c 01 e5             	add    rbp,r12
   49954:	49 39 ed             	cmp    r13,rbp
   49957:	7d 0d                	jge    49966 <f.66+0x326>
   49959:	45 31 ed             	xor    r13d,r13d
   4995c:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49961:	e9 43 2d 00 00       	jmp    4c6a9 <f.66+0x3069>
   49966:	48 83 3d 9a 0a 02 00 	cmp    QWORD PTR [rip+0x20a9a],0x0        # 6a408 <g.74>
   4996d:	00 
   4996e:	0f 84 5c 43 00 00    	je     4dcd0 <f.66+0x4690>
   49974:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49979:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49980:	00 
   49981:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49986:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4998d:	00 
   4998e:	4c 89 bc 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r15
   49995:	00 
   49996:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4999b:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   499a2:	00 
   499a3:	4c 89 b4 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r14
   499aa:	00 
   499ab:	48 c7 44 24 60 09 00 	mov    QWORD PTR [rsp+0x60],0x9
   499b2:	00 00 
   499b4:	48 89 ef             	mov    rdi,rbp
   499b7:	e8 34 43 00 00       	call   4dcf0 <f.59>
   499bc:	48 83 ec 08          	sub    rsp,0x8
   499c0:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
   499c5:	80 3d 4c 0a 02 00 00 	cmp    BYTE PTR [rip+0x20a4c],0x0        # 6a418 <g.76>
   499cc:	0f 84 fe 42 00 00    	je     4dcd0 <f.66+0x4690>
   499d2:	48 83 3d 36 0a 02 00 	cmp    QWORD PTR [rip+0x20a36],0x0        # 6a410 <g.75>
   499d9:	00 
   499da:	0f 84 f0 42 00 00    	je     4dcd0 <f.66+0x4690>
   499e0:	4c 01 e5             	add    rbp,r12
   499e3:	49 39 ed             	cmp    r13,rbp
   499e6:	7d 0d                	jge    499f5 <f.66+0x3b5>
   499e8:	45 31 e4             	xor    r12d,r12d
   499eb:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   499f0:	e9 23 2b 00 00       	jmp    4c518 <f.66+0x2ed8>
   499f5:	48 83 3d 0b 0a 02 00 	cmp    QWORD PTR [rip+0x20a0b],0x0        # 6a408 <g.74>
   499fc:	00 
   499fd:	0f 84 cd 42 00 00    	je     4dcd0 <f.66+0x4690>
   49a03:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49a08:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49a0f:	00 
   49a10:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49a15:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49a1c:	00 
   49a1d:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49a22:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49a29:	00 
   49a2a:	4c 89 bc 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r15
   49a31:	00 
   49a32:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   49a37:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   49a3e:	00 
   49a3f:	4c 89 b4 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r14
   49a46:	00 
   49a47:	48 c7 44 24 60 0a 00 	mov    QWORD PTR [rsp+0x60],0xa
   49a4e:	00 00 
   49a50:	48 89 ef             	mov    rdi,rbp
   49a53:	e8 98 42 00 00       	call   4dcf0 <f.59>
   49a58:	48 83 ec 08          	sub    rsp,0x8
   49a5c:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
   49a61:	80 3d b0 09 02 00 00 	cmp    BYTE PTR [rip+0x209b0],0x0        # 6a418 <g.76>
   49a68:	0f 84 62 42 00 00    	je     4dcd0 <f.66+0x4690>
   49a6e:	48 83 3d 9a 09 02 00 	cmp    QWORD PTR [rip+0x2099a],0x0        # 6a410 <g.75>
   49a75:	00 
   49a76:	0f 84 54 42 00 00    	je     4dcd0 <f.66+0x4690>
   49a7c:	4c 01 e5             	add    rbp,r12
   49a7f:	49 39 ed             	cmp    r13,rbp
   49a82:	7d 0d                	jge    49a91 <f.66+0x451>
   49a84:	45 31 ed             	xor    r13d,r13d
   49a87:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49a8c:	e9 e9 28 00 00       	jmp    4c37a <f.66+0x2d3a>
   49a91:	48 83 3d 6f 09 02 00 	cmp    QWORD PTR [rip+0x2096f],0x0        # 6a408 <g.74>
   49a98:	00 
   49a99:	0f 84 31 42 00 00    	je     4dcd0 <f.66+0x4690>
   49a9f:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   49aa4:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49aab:	00 
   49aac:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49ab1:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49ab8:	00 
   49ab9:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49abe:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49ac5:	00 
   49ac6:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49acb:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   49ad2:	00 
   49ad3:	4c 89 bc 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r15
   49ada:	00 
   49adb:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   49ae0:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   49ae7:	00 
   49ae8:	4c 89 b4 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r14
   49aef:	00 
   49af0:	48 c7 44 24 60 0b 00 	mov    QWORD PTR [rsp+0x60],0xb
   49af7:	00 00 
   49af9:	48 89 ef             	mov    rdi,rbp
   49afc:	e8 ef 41 00 00       	call   4dcf0 <f.59>
   49b01:	48 83 ec 08          	sub    rsp,0x8
   49b05:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
   49b0a:	80 3d 07 09 02 00 00 	cmp    BYTE PTR [rip+0x20907],0x0        # 6a418 <g.76>
   49b11:	0f 84 b9 41 00 00    	je     4dcd0 <f.66+0x4690>
   49b17:	48 83 3d f1 08 02 00 	cmp    QWORD PTR [rip+0x208f1],0x0        # 6a410 <g.75>
   49b1e:	00 
   49b1f:	0f 84 ab 41 00 00    	je     4dcd0 <f.66+0x4690>
   49b25:	4c 01 e5             	add    rbp,r12
   49b28:	49 39 ed             	cmp    r13,rbp
   49b2b:	7d 0d                	jge    49b3a <f.66+0x4fa>
   49b2d:	45 31 e4             	xor    r12d,r12d
   49b30:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49b35:	e9 95 26 00 00       	jmp    4c1cf <f.66+0x2b8f>
   49b3a:	48 83 3d c6 08 02 00 	cmp    QWORD PTR [rip+0x208c6],0x0        # 6a408 <g.74>
   49b41:	00 
   49b42:	0f 84 88 41 00 00    	je     4dcd0 <f.66+0x4690>
   49b48:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   49b4d:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49b54:	00 
   49b55:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   49b5a:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49b61:	00 
   49b62:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49b67:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49b6e:	00 
   49b6f:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49b74:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   49b7b:	00 
   49b7c:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49b81:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   49b88:	00 
   49b89:	4c 89 bc 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r15
   49b90:	00 
   49b91:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   49b96:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   49b9d:	00 
   49b9e:	4c 89 b4 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],r14
   49ba5:	00 
   49ba6:	48 c7 44 24 60 0c 00 	mov    QWORD PTR [rsp+0x60],0xc
   49bad:	00 00 
   49baf:	48 89 ef             	mov    rdi,rbp
   49bb2:	e8 39 41 00 00       	call   4dcf0 <f.59>
   49bb7:	48 83 ec 08          	sub    rsp,0x8
   49bbb:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
   49bc0:	80 3d 51 08 02 00 00 	cmp    BYTE PTR [rip+0x20851],0x0        # 6a418 <g.76>
   49bc7:	0f 84 03 41 00 00    	je     4dcd0 <f.66+0x4690>
   49bcd:	48 83 3d 3b 08 02 00 	cmp    QWORD PTR [rip+0x2083b],0x0        # 6a410 <g.75>
   49bd4:	00 
   49bd5:	0f 84 f5 40 00 00    	je     4dcd0 <f.66+0x4690>
   49bdb:	4c 01 e5             	add    rbp,r12
   49bde:	49 39 ed             	cmp    r13,rbp
   49be1:	7d 0d                	jge    49bf0 <f.66+0x5b0>
   49be3:	45 31 ed             	xor    r13d,r13d
   49be6:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49beb:	e9 25 24 00 00       	jmp    4c015 <f.66+0x29d5>
   49bf0:	48 83 3d 10 08 02 00 	cmp    QWORD PTR [rip+0x20810],0x0        # 6a408 <g.74>
   49bf7:	00 
   49bf8:	0f 84 d2 40 00 00    	je     4dcd0 <f.66+0x4690>
   49bfe:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   49c03:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49c0a:	00 
   49c0b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   49c10:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49c17:	00 
   49c18:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   49c1d:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49c24:	00 
   49c25:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49c2a:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   49c31:	00 
   49c32:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49c37:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   49c3e:	00 
   49c3f:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49c44:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   49c4b:	00 
   49c4c:	4c 89 bc 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r15
   49c53:	00 
   49c54:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   49c59:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   49c60:	00 
   49c61:	4c 89 b4 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],r14
   49c68:	00 
   49c69:	48 c7 44 24 60 0d 00 	mov    QWORD PTR [rsp+0x60],0xd
   49c70:	00 00 
   49c72:	48 89 ef             	mov    rdi,rbp
   49c75:	e8 76 40 00 00       	call   4dcf0 <f.59>
   49c7a:	48 83 ec 08          	sub    rsp,0x8
   49c7e:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
   49c83:	80 3d 8e 07 02 00 00 	cmp    BYTE PTR [rip+0x2078e],0x0        # 6a418 <g.76>
   49c8a:	0f 84 40 40 00 00    	je     4dcd0 <f.66+0x4690>
   49c90:	48 83 3d 78 07 02 00 	cmp    QWORD PTR [rip+0x20778],0x0        # 6a410 <g.75>
   49c97:	00 
   49c98:	0f 84 32 40 00 00    	je     4dcd0 <f.66+0x4690>
   49c9e:	4c 01 e5             	add    rbp,r12
   49ca1:	49 39 ed             	cmp    r13,rbp
   49ca4:	7d 0d                	jge    49cb3 <f.66+0x673>
   49ca6:	45 31 e4             	xor    r12d,r12d
   49ca9:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49cae:	e9 9b 21 00 00       	jmp    4be4e <f.66+0x280e>
   49cb3:	48 83 3d 4d 07 02 00 	cmp    QWORD PTR [rip+0x2074d],0x0        # 6a408 <g.74>
   49cba:	00 
   49cbb:	0f 84 0f 40 00 00    	je     4dcd0 <f.66+0x4690>
   49cc1:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   49cc6:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49ccd:	00 
   49cce:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   49cd3:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49cda:	00 
   49cdb:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   49ce0:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49ce7:	00 
   49ce8:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   49ced:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   49cf4:	00 
   49cf5:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49cfa:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   49d01:	00 
   49d02:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49d07:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   49d0e:	00 
   49d0f:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49d14:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   49d1b:	00 
   49d1c:	4c 89 bc 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],r15
   49d23:	00 
   49d24:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   49d29:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   49d30:	00 
   49d31:	4c 89 b4 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r14
   49d38:	00 
   49d39:	48 c7 44 24 60 0e 00 	mov    QWORD PTR [rsp+0x60],0xe
   49d40:	00 00 
   49d42:	48 89 ef             	mov    rdi,rbp
   49d45:	e8 a6 3f 00 00       	call   4dcf0 <f.59>
   49d4a:	48 83 ec 08          	sub    rsp,0x8
   49d4e:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
   49d55:	00 
   49d56:	80 3d bb 06 02 00 00 	cmp    BYTE PTR [rip+0x206bb],0x0        # 6a418 <g.76>
   49d5d:	0f 84 6d 3f 00 00    	je     4dcd0 <f.66+0x4690>
   49d63:	48 83 3d a5 06 02 00 	cmp    QWORD PTR [rip+0x206a5],0x0        # 6a410 <g.75>
   49d6a:	00 
   49d6b:	0f 84 5f 3f 00 00    	je     4dcd0 <f.66+0x4690>
   49d71:	4c 01 e5             	add    rbp,r12
   49d74:	49 39 ed             	cmp    r13,rbp
   49d77:	7d 0d                	jge    49d86 <f.66+0x746>
   49d79:	45 31 ed             	xor    r13d,r13d
   49d7c:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49d81:	e9 ee 1e 00 00       	jmp    4bc74 <f.66+0x2634>
   49d86:	48 83 3d 7a 06 02 00 	cmp    QWORD PTR [rip+0x2067a],0x0        # 6a408 <g.74>
   49d8d:	00 
   49d8e:	0f 84 3c 3f 00 00    	je     4dcd0 <f.66+0x4690>
   49d94:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   49d9b:	00 
   49d9c:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49da3:	00 
   49da4:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   49da9:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49db0:	00 
   49db1:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   49db6:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49dbd:	00 
   49dbe:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   49dc3:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   49dca:	00 
   49dcb:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   49dd0:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   49dd7:	00 
   49dd8:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49ddd:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   49de4:	00 
   49de5:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49dea:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   49df1:	00 
   49df2:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49df7:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   49dfe:	00 
   49dff:	4c 89 bc 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],r15
   49e06:	00 
   49e07:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   49e0c:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   49e13:	00 
   49e14:	4c 89 b4 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r14
   49e1b:	00 
   49e1c:	48 c7 44 24 60 0f 00 	mov    QWORD PTR [rsp+0x60],0xf
   49e23:	00 00 
   49e25:	48 89 ef             	mov    rdi,rbp
   49e28:	e8 c3 3e 00 00       	call   4dcf0 <f.59>
   49e2d:	48 83 ec 08          	sub    rsp,0x8
   49e31:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
   49e38:	00 
   49e39:	80 3d d8 05 02 00 00 	cmp    BYTE PTR [rip+0x205d8],0x0        # 6a418 <g.76>
   49e40:	0f 84 8a 3e 00 00    	je     4dcd0 <f.66+0x4690>
   49e46:	48 83 3d c2 05 02 00 	cmp    QWORD PTR [rip+0x205c2],0x0        # 6a410 <g.75>
   49e4d:	00 
   49e4e:	0f 84 7c 3e 00 00    	je     4dcd0 <f.66+0x4690>
   49e54:	4c 01 e5             	add    rbp,r12
   49e57:	49 39 ed             	cmp    r13,rbp
   49e5a:	7d 0d                	jge    49e69 <f.66+0x829>
   49e5c:	45 31 e4             	xor    r12d,r12d
   49e5f:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49e64:	e9 21 1c 00 00       	jmp    4ba8a <f.66+0x244a>
   49e69:	48 83 3d 97 05 02 00 	cmp    QWORD PTR [rip+0x20597],0x0        # 6a408 <g.74>
   49e70:	00 
   49e71:	0f 84 59 3e 00 00    	je     4dcd0 <f.66+0x4690>
   49e77:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   49e7e:	00 
   49e7f:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49e86:	00 
   49e87:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   49e8e:	00 
   49e8f:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49e96:	00 
   49e97:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   49e9c:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49ea3:	00 
   49ea4:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   49ea9:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   49eb0:	00 
   49eb1:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   49eb6:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   49ebd:	00 
   49ebe:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   49ec3:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   49eca:	00 
   49ecb:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49ed0:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   49ed7:	00 
   49ed8:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49edd:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   49ee4:	00 
   49ee5:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49eea:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   49ef1:	00 
   49ef2:	4c 89 bc 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r15
   49ef9:	00 
   49efa:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   49eff:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   49f06:	00 
   49f07:	4c 89 b4 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],r14
   49f0e:	00 
   49f0f:	48 c7 44 24 60 10 00 	mov    QWORD PTR [rsp+0x60],0x10
   49f16:	00 00 
   49f18:	48 89 ef             	mov    rdi,rbp
   49f1b:	e8 d0 3d 00 00       	call   4dcf0 <f.59>
   49f20:	48 83 ec 08          	sub    rsp,0x8
   49f24:	48 89 84 24 40 01 00 	mov    QWORD PTR [rsp+0x140],rax
   49f2b:	00 
   49f2c:	80 3d e5 04 02 00 00 	cmp    BYTE PTR [rip+0x204e5],0x0        # 6a418 <g.76>
   49f33:	0f 84 97 3d 00 00    	je     4dcd0 <f.66+0x4690>
   49f39:	48 83 3d cf 04 02 00 	cmp    QWORD PTR [rip+0x204cf],0x0        # 6a410 <g.75>
   49f40:	00 
   49f41:	0f 84 89 3d 00 00    	je     4dcd0 <f.66+0x4690>
   49f47:	4c 01 e5             	add    rbp,r12
   49f4a:	49 39 ed             	cmp    r13,rbp
   49f4d:	7d 0d                	jge    49f5c <f.66+0x91c>
   49f4f:	45 31 ed             	xor    r13d,r13d
   49f52:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   49f57:	e9 34 19 00 00       	jmp    4b890 <f.66+0x2250>
   49f5c:	48 83 3d a4 04 02 00 	cmp    QWORD PTR [rip+0x204a4],0x0        # 6a408 <g.74>
   49f63:	00 
   49f64:	0f 84 66 3d 00 00    	je     4dcd0 <f.66+0x4690>
   49f6a:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   49f71:	00 
   49f72:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   49f79:	00 
   49f7a:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   49f81:	00 
   49f82:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   49f89:	00 
   49f8a:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   49f91:	00 
   49f92:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   49f99:	00 
   49f9a:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   49f9f:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   49fa6:	00 
   49fa7:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   49fac:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   49fb3:	00 
   49fb4:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   49fb9:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   49fc0:	00 
   49fc1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   49fc6:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   49fcd:	00 
   49fce:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   49fd3:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   49fda:	00 
   49fdb:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   49fe0:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   49fe7:	00 
   49fe8:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   49fed:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   49ff4:	00 
   49ff5:	4c 89 bc 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r15
   49ffc:	00 
   49ffd:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a002:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a009:	00 
   4a00a:	4c 89 b4 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r14
   4a011:	00 
   4a012:	48 c7 44 24 60 11 00 	mov    QWORD PTR [rsp+0x60],0x11
   4a019:	00 00 
   4a01b:	48 89 ef             	mov    rdi,rbp
   4a01e:	e8 cd 3c 00 00       	call   4dcf0 <f.59>
   4a023:	48 83 ec 08          	sub    rsp,0x8
   4a027:	48 89 84 24 48 01 00 	mov    QWORD PTR [rsp+0x148],rax
   4a02e:	00 
   4a02f:	80 3d e2 03 02 00 00 	cmp    BYTE PTR [rip+0x203e2],0x0        # 6a418 <g.76>
   4a036:	0f 84 94 3c 00 00    	je     4dcd0 <f.66+0x4690>
   4a03c:	48 83 3d cc 03 02 00 	cmp    QWORD PTR [rip+0x203cc],0x0        # 6a410 <g.75>
   4a043:	00 
   4a044:	0f 84 86 3c 00 00    	je     4dcd0 <f.66+0x4690>
   4a04a:	4c 01 e5             	add    rbp,r12
   4a04d:	49 39 ed             	cmp    r13,rbp
   4a050:	7d 0d                	jge    4a05f <f.66+0xa1f>
   4a052:	45 31 e4             	xor    r12d,r12d
   4a055:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   4a05a:	e9 27 16 00 00       	jmp    4b686 <f.66+0x2046>
   4a05f:	48 83 3d a1 03 02 00 	cmp    QWORD PTR [rip+0x203a1],0x0        # 6a408 <g.74>
   4a066:	00 
   4a067:	0f 84 63 3c 00 00    	je     4dcd0 <f.66+0x4690>
   4a06d:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a074:	00 
   4a075:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a07c:	00 
   4a07d:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a084:	00 
   4a085:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a08c:	00 
   4a08d:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a094:	00 
   4a095:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a09c:	00 
   4a09d:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a0a4:	00 
   4a0a5:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a0ac:	00 
   4a0ad:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a0b2:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a0b9:	00 
   4a0ba:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a0bf:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a0c6:	00 
   4a0c7:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a0cc:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a0d3:	00 
   4a0d4:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a0d9:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a0e0:	00 
   4a0e1:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a0e6:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a0ed:	00 
   4a0ee:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a0f3:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a0fa:	00 
   4a0fb:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a100:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a107:	00 
   4a108:	4c 89 bc 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],r15
   4a10f:	00 
   4a110:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a115:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4a11c:	00 
   4a11d:	4c 89 b4 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r14
   4a124:	00 
   4a125:	48 c7 44 24 60 12 00 	mov    QWORD PTR [rsp+0x60],0x12
   4a12c:	00 00 
   4a12e:	48 89 ef             	mov    rdi,rbp
   4a131:	e8 ba 3b 00 00       	call   4dcf0 <f.59>
   4a136:	48 83 ec 08          	sub    rsp,0x8
   4a13a:	48 89 84 24 50 01 00 	mov    QWORD PTR [rsp+0x150],rax
   4a141:	00 
   4a142:	80 3d cf 02 02 00 00 	cmp    BYTE PTR [rip+0x202cf],0x0        # 6a418 <g.76>
   4a149:	0f 84 81 3b 00 00    	je     4dcd0 <f.66+0x4690>
   4a14f:	48 83 3d b9 02 02 00 	cmp    QWORD PTR [rip+0x202b9],0x0        # 6a410 <g.75>
   4a156:	00 
   4a157:	0f 84 73 3b 00 00    	je     4dcd0 <f.66+0x4690>
   4a15d:	4c 01 e5             	add    rbp,r12
   4a160:	49 39 ed             	cmp    r13,rbp
   4a163:	7d 0d                	jge    4a172 <f.66+0xb32>
   4a165:	45 31 ed             	xor    r13d,r13d
   4a168:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   4a16d:	e9 fa 12 00 00       	jmp    4b46c <f.66+0x1e2c>
   4a172:	48 83 3d 8e 02 02 00 	cmp    QWORD PTR [rip+0x2028e],0x0        # 6a408 <g.74>
   4a179:	00 
   4a17a:	0f 84 50 3b 00 00    	je     4dcd0 <f.66+0x4690>
   4a180:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4a187:	00 
   4a188:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a18f:	00 
   4a190:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a197:	00 
   4a198:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a19f:	00 
   4a1a0:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a1a7:	00 
   4a1a8:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a1af:	00 
   4a1b0:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a1b7:	00 
   4a1b8:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a1bf:	00 
   4a1c0:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a1c7:	00 
   4a1c8:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a1cf:	00 
   4a1d0:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a1d5:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a1dc:	00 
   4a1dd:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a1e2:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a1e9:	00 
   4a1ea:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a1ef:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a1f6:	00 
   4a1f7:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a1fc:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a203:	00 
   4a204:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a209:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a210:	00 
   4a211:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a216:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a21d:	00 
   4a21e:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a223:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a22a:	00 
   4a22b:	4c 89 bc 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r15
   4a232:	00 
   4a233:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a238:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4a23f:	00 
   4a240:	4c 89 b4 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],r14
   4a247:	00 
   4a248:	48 c7 44 24 60 13 00 	mov    QWORD PTR [rsp+0x60],0x13
   4a24f:	00 00 
   4a251:	48 89 ef             	mov    rdi,rbp
   4a254:	e8 97 3a 00 00       	call   4dcf0 <f.59>
   4a259:	48 83 ec 08          	sub    rsp,0x8
   4a25d:	48 89 84 24 58 01 00 	mov    QWORD PTR [rsp+0x158],rax
   4a264:	00 
   4a265:	80 3d ac 01 02 00 00 	cmp    BYTE PTR [rip+0x201ac],0x0        # 6a418 <g.76>
   4a26c:	0f 84 5e 3a 00 00    	je     4dcd0 <f.66+0x4690>
   4a272:	48 83 3d 96 01 02 00 	cmp    QWORD PTR [rip+0x20196],0x0        # 6a410 <g.75>
   4a279:	00 
   4a27a:	0f 84 50 3a 00 00    	je     4dcd0 <f.66+0x4690>
   4a280:	4c 01 e5             	add    rbp,r12
   4a283:	49 39 ed             	cmp    r13,rbp
   4a286:	7d 0d                	jge    4a295 <f.66+0xc55>
   4a288:	45 31 e4             	xor    r12d,r12d
   4a28b:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   4a290:	e9 ad 0f 00 00       	jmp    4b242 <f.66+0x1c02>
   4a295:	48 83 3d 6b 01 02 00 	cmp    QWORD PTR [rip+0x2016b],0x0        # 6a408 <g.74>
   4a29c:	00 
   4a29d:	0f 84 2d 3a 00 00    	je     4dcd0 <f.66+0x4690>
   4a2a3:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4a2aa:	00 
   4a2ab:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a2b2:	00 
   4a2b3:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4a2ba:	00 
   4a2bb:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a2c2:	00 
   4a2c3:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a2ca:	00 
   4a2cb:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a2d2:	00 
   4a2d3:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a2da:	00 
   4a2db:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a2e2:	00 
   4a2e3:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a2ea:	00 
   4a2eb:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a2f2:	00 
   4a2f3:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a2fa:	00 
   4a2fb:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a302:	00 
   4a303:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a308:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a30f:	00 
   4a310:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a315:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a31c:	00 
   4a31d:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a322:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a329:	00 
   4a32a:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a32f:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a336:	00 
   4a337:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a33c:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a343:	00 
   4a344:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a349:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a350:	00 
   4a351:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a356:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4a35d:	00 
   4a35e:	4c 89 bc 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r15
   4a365:	00 
   4a366:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a36b:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4a372:	00 
   4a373:	4c 89 b4 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r14
   4a37a:	00 
   4a37b:	48 c7 44 24 60 14 00 	mov    QWORD PTR [rsp+0x60],0x14
   4a382:	00 00 
   4a384:	48 89 ef             	mov    rdi,rbp
   4a387:	e8 64 39 00 00       	call   4dcf0 <f.59>
   4a38c:	48 83 ec 08          	sub    rsp,0x8
   4a390:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
   4a397:	00 
   4a398:	80 3d 79 00 02 00 00 	cmp    BYTE PTR [rip+0x20079],0x0        # 6a418 <g.76>
   4a39f:	0f 84 2b 39 00 00    	je     4dcd0 <f.66+0x4690>
   4a3a5:	48 83 3d 63 00 02 00 	cmp    QWORD PTR [rip+0x20063],0x0        # 6a410 <g.75>
   4a3ac:	00 
   4a3ad:	0f 84 1d 39 00 00    	je     4dcd0 <f.66+0x4690>
   4a3b3:	4c 01 e5             	add    rbp,r12
   4a3b6:	49 39 ed             	cmp    r13,rbp
   4a3b9:	7d 08                	jge    4a3c3 <f.66+0xd83>
   4a3bb:	45 31 ed             	xor    r13d,r13d
   4a3be:	e9 40 0c 00 00       	jmp    4b003 <f.66+0x19c3>
   4a3c3:	48 83 3d 3d 00 02 00 	cmp    QWORD PTR [rip+0x2003d],0x0        # 6a408 <g.74>
   4a3ca:	00 
   4a3cb:	0f 84 ff 38 00 00    	je     4dcd0 <f.66+0x4690>
   4a3d1:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4a3d8:	00 
   4a3d9:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a3e0:	00 
   4a3e1:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4a3e8:	00 
   4a3e9:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a3f0:	00 
   4a3f1:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4a3f8:	00 
   4a3f9:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a400:	00 
   4a401:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a408:	00 
   4a409:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a410:	00 
   4a411:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a418:	00 
   4a419:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a420:	00 
   4a421:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a428:	00 
   4a429:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a430:	00 
   4a431:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a438:	00 
   4a439:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a440:	00 
   4a441:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a446:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a44d:	00 
   4a44e:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a453:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a45a:	00 
   4a45b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a460:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a467:	00 
   4a468:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a46d:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a474:	00 
   4a475:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a47a:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a481:	00 
   4a482:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a487:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4a48e:	00 
   4a48f:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a494:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4a49b:	00 
   4a49c:	4c 89 bc 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],r15
   4a4a3:	00 
   4a4a4:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a4a9:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
   4a4b0:	00 
   4a4b1:	4c 89 b4 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r14
   4a4b8:	00 
   4a4b9:	48 c7 44 24 60 15 00 	mov    QWORD PTR [rsp+0x60],0x15
   4a4c0:	00 00 
   4a4c2:	48 89 ef             	mov    rdi,rbp
   4a4c5:	e8 26 38 00 00       	call   4dcf0 <f.59>
   4a4ca:	48 83 ec 08          	sub    rsp,0x8
   4a4ce:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
   4a4d5:	00 
   4a4d6:	80 3d 3b ff 01 00 00 	cmp    BYTE PTR [rip+0x1ff3b],0x0        # 6a418 <g.76>
   4a4dd:	0f 84 ed 37 00 00    	je     4dcd0 <f.66+0x4690>
   4a4e3:	48 83 3d 25 ff 01 00 	cmp    QWORD PTR [rip+0x1ff25],0x0        # 6a410 <g.75>
   4a4ea:	00 
   4a4eb:	0f 84 df 37 00 00    	je     4dcd0 <f.66+0x4690>
   4a4f1:	4c 01 e5             	add    rbp,r12
   4a4f4:	49 39 ed             	cmp    r13,rbp
   4a4f7:	7d 08                	jge    4a501 <f.66+0xec1>
   4a4f9:	45 31 e4             	xor    r12d,r12d
   4a4fc:	e9 b3 08 00 00       	jmp    4adb4 <f.66+0x1774>
   4a501:	48 83 3d ff fe 01 00 	cmp    QWORD PTR [rip+0x1feff],0x0        # 6a408 <g.74>
   4a508:	00 
   4a509:	0f 84 c1 37 00 00    	je     4dcd0 <f.66+0x4690>
   4a50f:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
   4a516:	00 
   4a517:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a51e:	00 
   4a51f:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4a526:	00 
   4a527:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a52e:	00 
   4a52f:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4a536:	00 
   4a537:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a53e:	00 
   4a53f:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4a546:	00 
   4a547:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a54e:	00 
   4a54f:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a556:	00 
   4a557:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a55e:	00 
   4a55f:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a566:	00 
   4a567:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a56e:	00 
   4a56f:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a576:	00 
   4a577:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a57e:	00 
   4a57f:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a586:	00 
   4a587:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a58e:	00 
   4a58f:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a594:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a59b:	00 
   4a59c:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a5a1:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a5a8:	00 
   4a5a9:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a5ae:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a5b5:	00 
   4a5b6:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a5bb:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a5c2:	00 
   4a5c3:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a5c8:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4a5cf:	00 
   4a5d0:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a5d5:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4a5dc:	00 
   4a5dd:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a5e2:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4a5e9:	00 
   4a5ea:	4c 89 bc 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r15
   4a5f1:	00 
   4a5f2:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a5f7:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
   4a5fe:	00 
   4a5ff:	4c 89 b4 24 10 01 00 	mov    QWORD PTR [rsp+0x110],r14
   4a606:	00 
   4a607:	48 c7 44 24 60 16 00 	mov    QWORD PTR [rsp+0x60],0x16
   4a60e:	00 00 
   4a610:	48 89 ef             	mov    rdi,rbp
   4a613:	e8 d8 36 00 00       	call   4dcf0 <f.59>
   4a618:	48 83 ec 08          	sub    rsp,0x8
   4a61c:	48 89 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rax
   4a623:	00 
   4a624:	80 3d ed fd 01 00 00 	cmp    BYTE PTR [rip+0x1fded],0x0        # 6a418 <g.76>
   4a62b:	0f 84 9f 36 00 00    	je     4dcd0 <f.66+0x4690>
   4a631:	48 83 3d d7 fd 01 00 	cmp    QWORD PTR [rip+0x1fdd7],0x0        # 6a410 <g.75>
   4a638:	00 
   4a639:	0f 84 91 36 00 00    	je     4dcd0 <f.66+0x4690>
   4a63f:	4c 01 e5             	add    rbp,r12
   4a642:	49 39 ed             	cmp    r13,rbp
   4a645:	7d 08                	jge    4a64f <f.66+0x100f>
   4a647:	45 31 ed             	xor    r13d,r13d
   4a64a:	e9 06 05 00 00       	jmp    4ab55 <f.66+0x1515>
   4a64f:	48 83 3d b1 fd 01 00 	cmp    QWORD PTR [rip+0x1fdb1],0x0        # 6a408 <g.74>
   4a656:	00 
   4a657:	0f 84 73 36 00 00    	je     4dcd0 <f.66+0x4690>
   4a65d:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
   4a664:	00 
   4a665:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a66c:	00 
   4a66d:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
   4a674:	00 
   4a675:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a67c:	00 
   4a67d:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4a684:	00 
   4a685:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a68c:	00 
   4a68d:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4a694:	00 
   4a695:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a69c:	00 
   4a69d:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4a6a4:	00 
   4a6a5:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a6ac:	00 
   4a6ad:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a6b4:	00 
   4a6b5:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a6bc:	00 
   4a6bd:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a6c4:	00 
   4a6c5:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a6cc:	00 
   4a6cd:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a6d4:	00 
   4a6d5:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a6dc:	00 
   4a6dd:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a6e4:	00 
   4a6e5:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a6ec:	00 
   4a6ed:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a6f2:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a6f9:	00 
   4a6fa:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a6ff:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a706:	00 
   4a707:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a70c:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a713:	00 
   4a714:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a719:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4a720:	00 
   4a721:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a726:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4a72d:	00 
   4a72e:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a733:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4a73a:	00 
   4a73b:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a740:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
   4a747:	00 
   4a748:	4c 89 bc 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r15
   4a74f:	00 
   4a750:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a755:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
   4a75c:	00 
   4a75d:	4c 89 b4 24 18 01 00 	mov    QWORD PTR [rsp+0x118],r14
   4a764:	00 
   4a765:	48 c7 44 24 60 17 00 	mov    QWORD PTR [rsp+0x60],0x17
   4a76c:	00 00 
   4a76e:	48 89 ef             	mov    rdi,rbp
   4a771:	e8 7a 35 00 00       	call   4dcf0 <f.59>
   4a776:	48 83 ec 08          	sub    rsp,0x8
   4a77a:	48 89 84 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rax
   4a781:	00 
   4a782:	80 3d 8f fc 01 00 00 	cmp    BYTE PTR [rip+0x1fc8f],0x0        # 6a418 <g.76>
   4a789:	0f 84 41 35 00 00    	je     4dcd0 <f.66+0x4690>
   4a78f:	48 83 3d 79 fc 01 00 	cmp    QWORD PTR [rip+0x1fc79],0x0        # 6a410 <g.75>
   4a796:	00 
   4a797:	0f 84 33 35 00 00    	je     4dcd0 <f.66+0x4690>
   4a79d:	4c 01 e5             	add    rbp,r12
   4a7a0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
   4a7a7:	00 
   4a7a8:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a7af:	00 
   4a7b0:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
   4a7b7:	00 
   4a7b8:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a7bf:	00 
   4a7c0:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
   4a7c7:	00 
   4a7c8:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a7cf:	00 
   4a7d0:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4a7d7:	00 
   4a7d8:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a7df:	00 
   4a7e0:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4a7e7:	00 
   4a7e8:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a7ef:	00 
   4a7f0:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4a7f7:	00 
   4a7f8:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a7ff:	00 
   4a800:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a807:	00 
   4a808:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a80f:	00 
   4a810:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a817:	00 
   4a818:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a81f:	00 
   4a820:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a827:	00 
   4a828:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a82f:	00 
   4a830:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a837:	00 
   4a838:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a83f:	00 
   4a840:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a845:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a84c:	00 
   4a84d:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a852:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a859:	00 
   4a85a:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a85f:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4a866:	00 
   4a867:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a86c:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4a873:	00 
   4a874:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a879:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4a880:	00 
   4a881:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a886:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
   4a88d:	00 
   4a88e:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a893:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
   4a89a:	00 
   4a89b:	4c 89 bc 24 80 01 00 	mov    QWORD PTR [rsp+0x180],r15
   4a8a2:	00 
   4a8a3:	4c 89 bc 24 10 01 00 	mov    QWORD PTR [rsp+0x110],r15
   4a8aa:	00 
   4a8ab:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a8b0:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
   4a8b7:	00 
   4a8b8:	4c 89 b4 24 20 01 00 	mov    QWORD PTR [rsp+0x120],r14
   4a8bf:	00 
   4a8c0:	48 c7 44 24 60 18 00 	mov    QWORD PTR [rsp+0x60],0x18
   4a8c7:	00 00 
   4a8c9:	48 89 ef             	mov    rdi,rbp
   4a8cc:	4c 89 ee             	mov    rsi,r13
   4a8cf:	4c 89 e2             	mov    rdx,r12
   4a8d2:	e8 b9 40 00 00       	call   4e990 <f.67>
   4a8d7:	48 83 ec 08          	sub    rsp,0x8
   4a8db:	49 89 c4             	mov    r12,rax
   4a8de:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
   4a8e5:	00 
   4a8e6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
   4a8ed:	00 
   4a8ee:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4a8f5:	00 
   4a8f6:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
   4a8fd:	00 
   4a8fe:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4a905:	00 
   4a906:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
   4a90d:	00 
   4a90e:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4a915:	00 
   4a916:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4a91d:	00 
   4a91e:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4a925:	00 
   4a926:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4a92d:	00 
   4a92e:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4a935:	00 
   4a936:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4a93d:	00 
   4a93e:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4a945:	00 
   4a946:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4a94d:	00 
   4a94e:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4a955:	00 
   4a956:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4a95d:	00 
   4a95e:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4a965:	00 
   4a966:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4a96d:	00 
   4a96e:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4a975:	00 
   4a976:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4a97d:	00 
   4a97e:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4a985:	00 
   4a986:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4a98b:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4a992:	00 
   4a993:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4a998:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4a99f:	00 
   4a9a0:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4a9a5:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4a9ac:	00 
   4a9ad:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4a9b2:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4a9b9:	00 
   4a9ba:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4a9bf:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
   4a9c6:	00 
   4a9c7:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4a9cc:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
   4a9d3:	00 
   4a9d4:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4a9d9:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
   4a9e0:	00 
   4a9e1:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
   4a9e8:	00 
   4a9e9:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
   4a9f0:	00 
   4a9f1:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4a9f6:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
   4a9fd:	00 
   4a9fe:	4c 89 b4 24 28 01 00 	mov    QWORD PTR [rsp+0x128],r14
   4aa05:	00 
   4aa06:	48 c7 44 24 60 19 00 	mov    QWORD PTR [rsp+0x60],0x19
   4aa0d:	00 00 
   4aa0f:	48 8b 0d 9a fa 01 00 	mov    rcx,QWORD PTR [rip+0x1fa9a]        # 6a4b0 <collection_interval>
   4aa16:	48 85 c9             	test   rcx,rcx
   4aa19:	74 32                	je     4aa4d <f.66+0x140d>
   4aa1b:	48 8b 05 96 fa 01 00 	mov    rax,QWORD PTR [rip+0x1fa96]        # 6a4b8 <allocations>
   4aa22:	48 ff c0             	inc    rax
   4aa25:	48 89 05 8c fa 01 00 	mov    QWORD PTR [rip+0x1fa8c],rax        # 6a4b8 <allocations>
   4aa2c:	48 89 c2             	mov    rdx,rax
   4aa2f:	48 09 ca             	or     rdx,rcx
   4aa32:	48 c1 ea 20          	shr    rdx,0x20
   4aa36:	74 07                	je     4aa3f <f.66+0x13ff>
   4aa38:	31 d2                	xor    edx,edx
   4aa3a:	48 f7 f1             	div    rcx
   4aa3d:	eb 04                	jmp    4aa43 <f.66+0x1403>
   4aa3f:	31 d2                	xor    edx,edx
   4aa41:	f7 f1                	div    ecx
   4aa43:	48 85 d2             	test   rdx,rdx
   4aa46:	75 05                	jne    4aa4d <f.66+0x140d>
   4aa48:	e8 d3 75 01 00       	call   62020 <native_gc_collect>
   4aa4d:	48 8b 05 ac f5 01 00 	mov    rax,QWORD PTR [rip+0x1f5ac]        # 6a000 <heap_bytes>
   4aa54:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4aa58:	48 83 f8 18          	cmp    rax,0x18
   4aa5c:	0f 82 73 32 00 00    	jb     4dcd5 <f.66+0x4695>
   4aa62:	48 8b 05 57 fa 01 00 	mov    rax,QWORD PTR [rip+0x1fa57]        # 6a4c0 <since_collection>
   4aa69:	48 3b 05 98 f5 01 00 	cmp    rax,QWORD PTR [rip+0x1f598]        # 6a008 <budget>
   4aa70:	72 05                	jb     4aa77 <f.66+0x1437>
   4aa72:	e8 a9 75 01 00       	call   62020 <native_gc_collect>
   4aa77:	48 8b 05 c2 fa 01 00 	mov    rax,QWORD PTR [rip+0x1fac2]        # 6a540 <cursor>
   4aa7e:	48 85 c0             	test   rax,rax
   4aa81:	74 10                	je     4aa93 <f.66+0x1453>
   4aa83:	48 8b 0d be fa 01 00 	mov    rcx,QWORD PTR [rip+0x1fabe]        # 6a548 <limit>
   4aa8a:	48 29 c1             	sub    rcx,rax
   4aa8d:	48 83 f9 1f          	cmp    rcx,0x1f
   4aa91:	77 44                	ja     4aad7 <f.66+0x1497>
   4aa93:	bf 20 00 00 00       	mov    edi,0x20
   4aa98:	e8 83 92 01 00       	call   63d20 <allocate_slow>
   4aa9d:	48 85 c0             	test   rax,rax
   4aaa0:	75 40                	jne    4aae2 <f.66+0x14a2>
   4aaa2:	e8 79 75 01 00       	call   62020 <native_gc_collect>
   4aaa7:	48 8b 05 92 fa 01 00 	mov    rax,QWORD PTR [rip+0x1fa92]        # 6a540 <cursor>
   4aaae:	48 85 c0             	test   rax,rax
   4aab1:	74 10                	je     4aac3 <f.66+0x1483>
   4aab3:	48 8b 0d 8e fa 01 00 	mov    rcx,QWORD PTR [rip+0x1fa8e]        # 6a548 <limit>
   4aaba:	48 29 c1             	sub    rcx,rax
   4aabd:	48 83 f9 1f          	cmp    rcx,0x1f
   4aac1:	77 14                	ja     4aad7 <f.66+0x1497>
   4aac3:	bf 20 00 00 00       	mov    edi,0x20
   4aac8:	e8 53 92 01 00       	call   63d20 <allocate_slow>
   4aacd:	48 85 c0             	test   rax,rax
   4aad0:	75 10                	jne    4aae2 <f.66+0x14a2>
   4aad2:	e9 fe 31 00 00       	jmp    4dcd5 <f.66+0x4695>
   4aad7:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4aadb:	48 89 0d 5e fa 01 00 	mov    QWORD PTR [rip+0x1fa5e],rcx        # 6a540 <cursor>
   4aae2:	48 89 c2             	mov    rdx,rax
   4aae5:	48 2b 15 4c fa 01 00 	sub    rdx,QWORD PTR [rip+0x1fa4c]        # 6a538 <arena>
   4aaec:	89 d1                	mov    ecx,edx
   4aaee:	c1 e9 04             	shr    ecx,0x4
   4aaf1:	be 01 00 00 00       	mov    esi,0x1
   4aaf6:	48 d3 e6             	shl    rsi,cl
   4aaf9:	48 89 d1             	mov    rcx,rdx
   4aafc:	48 c1 e9 0f          	shr    rcx,0xf
   4ab00:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4ab07:	48 03 0d e2 f9 01 00 	add    rcx,QWORD PTR [rip+0x1f9e2]        # 6a4f0 <blocks>
   4ab0e:	c1 ea 07             	shr    edx,0x7
   4ab11:	81 e2 f8 00 00 00    	and    edx,0xf8
   4ab17:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4ab1b:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4ab22:	48 83 05 96 f9 01 00 	add    QWORD PTR [rip+0x1f996],0x20        # 6a4c0 <since_collection>
   4ab29:	20 
   4ab2a:	48 83 05 96 f9 01 00 	add    QWORD PTR [rip+0x1f996],0x18        # 6a4c8 <allocated_bytes>
   4ab31:	18 
   4ab32:	48 ff 05 97 f9 01 00 	inc    QWORD PTR [rip+0x1f997]        # 6a4d0 <allocated_objects>
   4ab39:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4ab3d:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4ab44:	00 
   4ab45:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
   4ab4c:	00 
   4ab4d:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4ab51:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4ab55:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4ab5c:	00 
   4ab5d:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
   4ab64:	00 
   4ab65:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4ab6c:	00 
   4ab6d:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
   4ab74:	00 
   4ab75:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4ab7c:	00 
   4ab7d:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4ab84:	00 
   4ab85:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4ab8c:	00 
   4ab8d:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4ab94:	00 
   4ab95:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4ab9c:	00 
   4ab9d:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4aba4:	00 
   4aba5:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4abac:	00 
   4abad:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4abb4:	00 
   4abb5:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4abbc:	00 
   4abbd:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4abc4:	00 
   4abc5:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4abcc:	00 
   4abcd:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4abd4:	00 
   4abd5:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4abdc:	00 
   4abdd:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4abe4:	00 
   4abe5:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4abec:	00 
   4abed:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4abf2:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4abf9:	00 
   4abfa:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4abff:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4ac06:	00 
   4ac07:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4ac0c:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4ac13:	00 
   4ac14:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4ac19:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4ac20:	00 
   4ac21:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4ac26:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4ac2d:	00 
   4ac2e:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4ac33:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
   4ac3a:	00 
   4ac3b:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4ac40:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
   4ac47:	00 
   4ac48:	4c 89 bc 24 10 01 00 	mov    QWORD PTR [rsp+0x110],r15
   4ac4f:	00 
   4ac50:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4ac55:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
   4ac5c:	00 
   4ac5d:	4c 89 b4 24 20 01 00 	mov    QWORD PTR [rsp+0x120],r14
   4ac64:	00 
   4ac65:	48 c7 44 24 60 18 00 	mov    QWORD PTR [rsp+0x60],0x18
   4ac6c:	00 00 
   4ac6e:	48 8b 0d 3b f8 01 00 	mov    rcx,QWORD PTR [rip+0x1f83b]        # 6a4b0 <collection_interval>
   4ac75:	48 85 c9             	test   rcx,rcx
   4ac78:	74 32                	je     4acac <f.66+0x166c>
   4ac7a:	48 8b 05 37 f8 01 00 	mov    rax,QWORD PTR [rip+0x1f837]        # 6a4b8 <allocations>
   4ac81:	48 ff c0             	inc    rax
   4ac84:	48 89 05 2d f8 01 00 	mov    QWORD PTR [rip+0x1f82d],rax        # 6a4b8 <allocations>
   4ac8b:	48 89 c2             	mov    rdx,rax
   4ac8e:	48 09 ca             	or     rdx,rcx
   4ac91:	48 c1 ea 20          	shr    rdx,0x20
   4ac95:	74 07                	je     4ac9e <f.66+0x165e>
   4ac97:	31 d2                	xor    edx,edx
   4ac99:	48 f7 f1             	div    rcx
   4ac9c:	eb 04                	jmp    4aca2 <f.66+0x1662>
   4ac9e:	31 d2                	xor    edx,edx
   4aca0:	f7 f1                	div    ecx
   4aca2:	48 85 d2             	test   rdx,rdx
   4aca5:	75 05                	jne    4acac <f.66+0x166c>
   4aca7:	e8 74 73 01 00       	call   62020 <native_gc_collect>
   4acac:	48 8b 05 4d f3 01 00 	mov    rax,QWORD PTR [rip+0x1f34d]        # 6a000 <heap_bytes>
   4acb3:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4acb7:	48 83 f8 18          	cmp    rax,0x18
   4acbb:	0f 82 14 30 00 00    	jb     4dcd5 <f.66+0x4695>
   4acc1:	48 8b 05 f8 f7 01 00 	mov    rax,QWORD PTR [rip+0x1f7f8]        # 6a4c0 <since_collection>
   4acc8:	48 3b 05 39 f3 01 00 	cmp    rax,QWORD PTR [rip+0x1f339]        # 6a008 <budget>
   4accf:	72 05                	jb     4acd6 <f.66+0x1696>
   4acd1:	e8 4a 73 01 00       	call   62020 <native_gc_collect>
   4acd6:	48 8b 05 63 f8 01 00 	mov    rax,QWORD PTR [rip+0x1f863]        # 6a540 <cursor>
   4acdd:	48 85 c0             	test   rax,rax
   4ace0:	74 10                	je     4acf2 <f.66+0x16b2>
   4ace2:	48 8b 0d 5f f8 01 00 	mov    rcx,QWORD PTR [rip+0x1f85f]        # 6a548 <limit>
   4ace9:	48 29 c1             	sub    rcx,rax
   4acec:	48 83 f9 1f          	cmp    rcx,0x1f
   4acf0:	77 44                	ja     4ad36 <f.66+0x16f6>
   4acf2:	bf 20 00 00 00       	mov    edi,0x20
   4acf7:	e8 24 90 01 00       	call   63d20 <allocate_slow>
   4acfc:	48 85 c0             	test   rax,rax
   4acff:	75 40                	jne    4ad41 <f.66+0x1701>
   4ad01:	e8 1a 73 01 00       	call   62020 <native_gc_collect>
   4ad06:	48 8b 05 33 f8 01 00 	mov    rax,QWORD PTR [rip+0x1f833]        # 6a540 <cursor>
   4ad0d:	48 85 c0             	test   rax,rax
   4ad10:	74 10                	je     4ad22 <f.66+0x16e2>
   4ad12:	48 8b 0d 2f f8 01 00 	mov    rcx,QWORD PTR [rip+0x1f82f]        # 6a548 <limit>
   4ad19:	48 29 c1             	sub    rcx,rax
   4ad1c:	48 83 f9 1f          	cmp    rcx,0x1f
   4ad20:	77 14                	ja     4ad36 <f.66+0x16f6>
   4ad22:	bf 20 00 00 00       	mov    edi,0x20
   4ad27:	e8 f4 8f 01 00       	call   63d20 <allocate_slow>
   4ad2c:	48 85 c0             	test   rax,rax
   4ad2f:	75 10                	jne    4ad41 <f.66+0x1701>
   4ad31:	e9 9f 2f 00 00       	jmp    4dcd5 <f.66+0x4695>
   4ad36:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4ad3a:	48 89 0d ff f7 01 00 	mov    QWORD PTR [rip+0x1f7ff],rcx        # 6a540 <cursor>
   4ad41:	48 89 c2             	mov    rdx,rax
   4ad44:	48 2b 15 ed f7 01 00 	sub    rdx,QWORD PTR [rip+0x1f7ed]        # 6a538 <arena>
   4ad4b:	89 d1                	mov    ecx,edx
   4ad4d:	c1 e9 04             	shr    ecx,0x4
   4ad50:	be 01 00 00 00       	mov    esi,0x1
   4ad55:	48 d3 e6             	shl    rsi,cl
   4ad58:	48 89 d1             	mov    rcx,rdx
   4ad5b:	48 c1 e9 0f          	shr    rcx,0xf
   4ad5f:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4ad66:	48 03 0d 83 f7 01 00 	add    rcx,QWORD PTR [rip+0x1f783]        # 6a4f0 <blocks>
   4ad6d:	c1 ea 07             	shr    edx,0x7
   4ad70:	81 e2 f8 00 00 00    	and    edx,0xf8
   4ad76:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4ad7a:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4ad81:	48 83 05 37 f7 01 00 	add    QWORD PTR [rip+0x1f737],0x20        # 6a4c0 <since_collection>
   4ad88:	20 
   4ad89:	48 83 05 37 f7 01 00 	add    QWORD PTR [rip+0x1f737],0x18        # 6a4c8 <allocated_bytes>
   4ad90:	18 
   4ad91:	48 ff 05 38 f7 01 00 	inc    QWORD PTR [rip+0x1f738]        # 6a4d0 <allocated_objects>
   4ad98:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4ad9c:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4ada3:	00 
   4ada4:	48 8b 8c 24 70 01 00 	mov    rcx,QWORD PTR [rsp+0x170]
   4adab:	00 
   4adac:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4adb0:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4adb4:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4adbb:	00 
   4adbc:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
   4adc3:	00 
   4adc4:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4adcb:	00 
   4adcc:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4add3:	00 
   4add4:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4addb:	00 
   4addc:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4ade3:	00 
   4ade4:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4adeb:	00 
   4adec:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4adf3:	00 
   4adf4:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4adfb:	00 
   4adfc:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4ae03:	00 
   4ae04:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4ae0b:	00 
   4ae0c:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4ae13:	00 
   4ae14:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4ae1b:	00 
   4ae1c:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4ae23:	00 
   4ae24:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4ae2b:	00 
   4ae2c:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4ae33:	00 
   4ae34:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4ae3b:	00 
   4ae3c:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4ae41:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4ae48:	00 
   4ae49:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4ae4e:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4ae55:	00 
   4ae56:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4ae5b:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4ae62:	00 
   4ae63:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4ae68:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4ae6f:	00 
   4ae70:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4ae75:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4ae7c:	00 
   4ae7d:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4ae82:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4ae89:	00 
   4ae8a:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
   4ae8f:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
   4ae96:	00 
   4ae97:	4c 89 bc 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r15
   4ae9e:	00 
   4ae9f:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4aea4:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
   4aeab:	00 
   4aeac:	4c 89 b4 24 18 01 00 	mov    QWORD PTR [rsp+0x118],r14
   4aeb3:	00 
   4aeb4:	48 c7 44 24 60 17 00 	mov    QWORD PTR [rsp+0x60],0x17
   4aebb:	00 00 
   4aebd:	48 8b 0d ec f5 01 00 	mov    rcx,QWORD PTR [rip+0x1f5ec]        # 6a4b0 <collection_interval>
   4aec4:	48 85 c9             	test   rcx,rcx
   4aec7:	74 32                	je     4aefb <f.66+0x18bb>
   4aec9:	48 8b 05 e8 f5 01 00 	mov    rax,QWORD PTR [rip+0x1f5e8]        # 6a4b8 <allocations>
   4aed0:	48 ff c0             	inc    rax
   4aed3:	48 89 05 de f5 01 00 	mov    QWORD PTR [rip+0x1f5de],rax        # 6a4b8 <allocations>
   4aeda:	48 89 c2             	mov    rdx,rax
   4aedd:	48 09 ca             	or     rdx,rcx
   4aee0:	48 c1 ea 20          	shr    rdx,0x20
   4aee4:	74 07                	je     4aeed <f.66+0x18ad>
   4aee6:	31 d2                	xor    edx,edx
   4aee8:	48 f7 f1             	div    rcx
   4aeeb:	eb 04                	jmp    4aef1 <f.66+0x18b1>
   4aeed:	31 d2                	xor    edx,edx
   4aeef:	f7 f1                	div    ecx
   4aef1:	48 85 d2             	test   rdx,rdx
   4aef4:	75 05                	jne    4aefb <f.66+0x18bb>
   4aef6:	e8 25 71 01 00       	call   62020 <native_gc_collect>
   4aefb:	48 8b 05 fe f0 01 00 	mov    rax,QWORD PTR [rip+0x1f0fe]        # 6a000 <heap_bytes>
   4af02:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4af06:	48 83 f8 18          	cmp    rax,0x18
   4af0a:	0f 82 c5 2d 00 00    	jb     4dcd5 <f.66+0x4695>
   4af10:	48 8b 05 a9 f5 01 00 	mov    rax,QWORD PTR [rip+0x1f5a9]        # 6a4c0 <since_collection>
   4af17:	48 3b 05 ea f0 01 00 	cmp    rax,QWORD PTR [rip+0x1f0ea]        # 6a008 <budget>
   4af1e:	72 05                	jb     4af25 <f.66+0x18e5>
   4af20:	e8 fb 70 01 00       	call   62020 <native_gc_collect>
   4af25:	48 8b 05 14 f6 01 00 	mov    rax,QWORD PTR [rip+0x1f614]        # 6a540 <cursor>
   4af2c:	48 85 c0             	test   rax,rax
   4af2f:	74 10                	je     4af41 <f.66+0x1901>
   4af31:	48 8b 0d 10 f6 01 00 	mov    rcx,QWORD PTR [rip+0x1f610]        # 6a548 <limit>
   4af38:	48 29 c1             	sub    rcx,rax
   4af3b:	48 83 f9 1f          	cmp    rcx,0x1f
   4af3f:	77 44                	ja     4af85 <f.66+0x1945>
   4af41:	bf 20 00 00 00       	mov    edi,0x20
   4af46:	e8 d5 8d 01 00       	call   63d20 <allocate_slow>
   4af4b:	48 85 c0             	test   rax,rax
   4af4e:	75 40                	jne    4af90 <f.66+0x1950>
   4af50:	e8 cb 70 01 00       	call   62020 <native_gc_collect>
   4af55:	48 8b 05 e4 f5 01 00 	mov    rax,QWORD PTR [rip+0x1f5e4]        # 6a540 <cursor>
   4af5c:	48 85 c0             	test   rax,rax
   4af5f:	74 10                	je     4af71 <f.66+0x1931>
   4af61:	48 8b 0d e0 f5 01 00 	mov    rcx,QWORD PTR [rip+0x1f5e0]        # 6a548 <limit>
   4af68:	48 29 c1             	sub    rcx,rax
   4af6b:	48 83 f9 1f          	cmp    rcx,0x1f
   4af6f:	77 14                	ja     4af85 <f.66+0x1945>
   4af71:	bf 20 00 00 00       	mov    edi,0x20
   4af76:	e8 a5 8d 01 00       	call   63d20 <allocate_slow>
   4af7b:	48 85 c0             	test   rax,rax
   4af7e:	75 10                	jne    4af90 <f.66+0x1950>
   4af80:	e9 50 2d 00 00       	jmp    4dcd5 <f.66+0x4695>
   4af85:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4af89:	48 89 0d b0 f5 01 00 	mov    QWORD PTR [rip+0x1f5b0],rcx        # 6a540 <cursor>
   4af90:	48 89 c2             	mov    rdx,rax
   4af93:	48 2b 15 9e f5 01 00 	sub    rdx,QWORD PTR [rip+0x1f59e]        # 6a538 <arena>
   4af9a:	89 d1                	mov    ecx,edx
   4af9c:	c1 e9 04             	shr    ecx,0x4
   4af9f:	be 01 00 00 00       	mov    esi,0x1
   4afa4:	48 d3 e6             	shl    rsi,cl
   4afa7:	48 89 d1             	mov    rcx,rdx
   4afaa:	48 c1 e9 0f          	shr    rcx,0xf
   4afae:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4afb5:	48 03 0d 34 f5 01 00 	add    rcx,QWORD PTR [rip+0x1f534]        # 6a4f0 <blocks>
   4afbc:	c1 ea 07             	shr    edx,0x7
   4afbf:	81 e2 f8 00 00 00    	and    edx,0xf8
   4afc5:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4afc9:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4afd0:	48 83 05 e8 f4 01 00 	add    QWORD PTR [rip+0x1f4e8],0x20        # 6a4c0 <since_collection>
   4afd7:	20 
   4afd8:	48 83 05 e8 f4 01 00 	add    QWORD PTR [rip+0x1f4e8],0x18        # 6a4c8 <allocated_bytes>
   4afdf:	18 
   4afe0:	48 ff 05 e9 f4 01 00 	inc    QWORD PTR [rip+0x1f4e9]        # 6a4d0 <allocated_objects>
   4afe7:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4afeb:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4aff2:	00 
   4aff3:	48 8b 8c 24 68 01 00 	mov    rcx,QWORD PTR [rsp+0x168]
   4affa:	00 
   4affb:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4afff:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4b003:	48 8b 6c 24 18       	mov    rbp,QWORD PTR [rsp+0x18]
   4b008:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4b00f:	00 
   4b010:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
   4b017:	00 
   4b018:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4b01f:	00 
   4b020:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4b027:	00 
   4b028:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4b02f:	00 
   4b030:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4b037:	00 
   4b038:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4b03f:	00 
   4b040:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4b047:	00 
   4b048:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4b04f:	00 
   4b050:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4b057:	00 
   4b058:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4b05f:	00 
   4b060:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4b067:	00 
   4b068:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4b06f:	00 
   4b070:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4b077:	00 
   4b078:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4b07f:	00 
   4b080:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4b085:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4b08c:	00 
   4b08d:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4b092:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4b099:	00 
   4b09a:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4b09f:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4b0a6:	00 
   4b0a7:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4b0ac:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4b0b3:	00 
   4b0b4:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4b0b9:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4b0c0:	00 
   4b0c1:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4b0c6:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4b0cd:	00 
   4b0ce:	48 89 ac 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rbp
   4b0d5:	00 
   4b0d6:	4c 89 bc 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r15
   4b0dd:	00 
   4b0de:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4b0e3:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
   4b0ea:	00 
   4b0eb:	4c 89 b4 24 10 01 00 	mov    QWORD PTR [rsp+0x110],r14
   4b0f2:	00 
   4b0f3:	48 c7 44 24 60 16 00 	mov    QWORD PTR [rsp+0x60],0x16
   4b0fa:	00 00 
   4b0fc:	48 8b 0d ad f3 01 00 	mov    rcx,QWORD PTR [rip+0x1f3ad]        # 6a4b0 <collection_interval>
   4b103:	48 85 c9             	test   rcx,rcx
   4b106:	74 32                	je     4b13a <f.66+0x1afa>
   4b108:	48 8b 05 a9 f3 01 00 	mov    rax,QWORD PTR [rip+0x1f3a9]        # 6a4b8 <allocations>
   4b10f:	48 ff c0             	inc    rax
   4b112:	48 89 05 9f f3 01 00 	mov    QWORD PTR [rip+0x1f39f],rax        # 6a4b8 <allocations>
   4b119:	48 89 c2             	mov    rdx,rax
   4b11c:	48 09 ca             	or     rdx,rcx
   4b11f:	48 c1 ea 20          	shr    rdx,0x20
   4b123:	74 07                	je     4b12c <f.66+0x1aec>
   4b125:	31 d2                	xor    edx,edx
   4b127:	48 f7 f1             	div    rcx
   4b12a:	eb 04                	jmp    4b130 <f.66+0x1af0>
   4b12c:	31 d2                	xor    edx,edx
   4b12e:	f7 f1                	div    ecx
   4b130:	48 85 d2             	test   rdx,rdx
   4b133:	75 05                	jne    4b13a <f.66+0x1afa>
   4b135:	e8 e6 6e 01 00       	call   62020 <native_gc_collect>
   4b13a:	48 8b 05 bf ee 01 00 	mov    rax,QWORD PTR [rip+0x1eebf]        # 6a000 <heap_bytes>
   4b141:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4b145:	48 83 f8 18          	cmp    rax,0x18
   4b149:	0f 82 86 2b 00 00    	jb     4dcd5 <f.66+0x4695>
   4b14f:	48 8b 05 6a f3 01 00 	mov    rax,QWORD PTR [rip+0x1f36a]        # 6a4c0 <since_collection>
   4b156:	48 3b 05 ab ee 01 00 	cmp    rax,QWORD PTR [rip+0x1eeab]        # 6a008 <budget>
   4b15d:	72 05                	jb     4b164 <f.66+0x1b24>
   4b15f:	e8 bc 6e 01 00       	call   62020 <native_gc_collect>
   4b164:	48 8b 05 d5 f3 01 00 	mov    rax,QWORD PTR [rip+0x1f3d5]        # 6a540 <cursor>
   4b16b:	48 85 c0             	test   rax,rax
   4b16e:	74 10                	je     4b180 <f.66+0x1b40>
   4b170:	48 8b 0d d1 f3 01 00 	mov    rcx,QWORD PTR [rip+0x1f3d1]        # 6a548 <limit>
   4b177:	48 29 c1             	sub    rcx,rax
   4b17a:	48 83 f9 1f          	cmp    rcx,0x1f
   4b17e:	77 44                	ja     4b1c4 <f.66+0x1b84>
   4b180:	bf 20 00 00 00       	mov    edi,0x20
   4b185:	e8 96 8b 01 00       	call   63d20 <allocate_slow>
   4b18a:	48 85 c0             	test   rax,rax
   4b18d:	75 40                	jne    4b1cf <f.66+0x1b8f>
   4b18f:	e8 8c 6e 01 00       	call   62020 <native_gc_collect>
   4b194:	48 8b 05 a5 f3 01 00 	mov    rax,QWORD PTR [rip+0x1f3a5]        # 6a540 <cursor>
   4b19b:	48 85 c0             	test   rax,rax
   4b19e:	74 10                	je     4b1b0 <f.66+0x1b70>
   4b1a0:	48 8b 0d a1 f3 01 00 	mov    rcx,QWORD PTR [rip+0x1f3a1]        # 6a548 <limit>
   4b1a7:	48 29 c1             	sub    rcx,rax
   4b1aa:	48 83 f9 1f          	cmp    rcx,0x1f
   4b1ae:	77 14                	ja     4b1c4 <f.66+0x1b84>
   4b1b0:	bf 20 00 00 00       	mov    edi,0x20
   4b1b5:	e8 66 8b 01 00       	call   63d20 <allocate_slow>
   4b1ba:	48 85 c0             	test   rax,rax
   4b1bd:	75 10                	jne    4b1cf <f.66+0x1b8f>
   4b1bf:	e9 11 2b 00 00       	jmp    4dcd5 <f.66+0x4695>
   4b1c4:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4b1c8:	48 89 0d 71 f3 01 00 	mov    QWORD PTR [rip+0x1f371],rcx        # 6a540 <cursor>
   4b1cf:	48 89 c2             	mov    rdx,rax
   4b1d2:	48 2b 15 5f f3 01 00 	sub    rdx,QWORD PTR [rip+0x1f35f]        # 6a538 <arena>
   4b1d9:	89 d1                	mov    ecx,edx
   4b1db:	c1 e9 04             	shr    ecx,0x4
   4b1de:	be 01 00 00 00       	mov    esi,0x1
   4b1e3:	48 d3 e6             	shl    rsi,cl
   4b1e6:	48 89 d1             	mov    rcx,rdx
   4b1e9:	48 c1 e9 0f          	shr    rcx,0xf
   4b1ed:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4b1f4:	48 03 0d f5 f2 01 00 	add    rcx,QWORD PTR [rip+0x1f2f5]        # 6a4f0 <blocks>
   4b1fb:	c1 ea 07             	shr    edx,0x7
   4b1fe:	81 e2 f8 00 00 00    	and    edx,0xf8
   4b204:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4b208:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4b20f:	48 83 05 a9 f2 01 00 	add    QWORD PTR [rip+0x1f2a9],0x20        # 6a4c0 <since_collection>
   4b216:	20 
   4b217:	48 83 05 a9 f2 01 00 	add    QWORD PTR [rip+0x1f2a9],0x18        # 6a4c8 <allocated_bytes>
   4b21e:	18 
   4b21f:	48 ff 05 aa f2 01 00 	inc    QWORD PTR [rip+0x1f2aa]        # 6a4d0 <allocated_objects>
   4b226:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4b22a:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4b231:	00 
   4b232:	48 8b 8c 24 60 01 00 	mov    rcx,QWORD PTR [rsp+0x160]
   4b239:	00 
   4b23a:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4b23e:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4b242:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4b249:	00 
   4b24a:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
   4b251:	00 
   4b252:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4b259:	00 
   4b25a:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4b261:	00 
   4b262:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4b269:	00 
   4b26a:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4b271:	00 
   4b272:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4b279:	00 
   4b27a:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4b281:	00 
   4b282:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4b289:	00 
   4b28a:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4b291:	00 
   4b292:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4b299:	00 
   4b29a:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4b2a1:	00 
   4b2a2:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4b2a9:	00 
   4b2aa:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4b2af:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4b2b6:	00 
   4b2b7:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4b2bc:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4b2c3:	00 
   4b2c4:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4b2c9:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4b2d0:	00 
   4b2d1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4b2d6:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4b2dd:	00 
   4b2de:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4b2e3:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4b2ea:	00 
   4b2eb:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4b2f0:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4b2f7:	00 
   4b2f8:	48 89 ac 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rbp
   4b2ff:	00 
   4b300:	4c 89 bc 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],r15
   4b307:	00 
   4b308:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4b30d:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
   4b314:	00 
   4b315:	4c 89 b4 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r14
   4b31c:	00 
   4b31d:	48 c7 44 24 60 15 00 	mov    QWORD PTR [rsp+0x60],0x15
   4b324:	00 00 
   4b326:	48 8b 0d 83 f1 01 00 	mov    rcx,QWORD PTR [rip+0x1f183]        # 6a4b0 <collection_interval>
   4b32d:	48 85 c9             	test   rcx,rcx
   4b330:	74 32                	je     4b364 <f.66+0x1d24>
   4b332:	48 8b 05 7f f1 01 00 	mov    rax,QWORD PTR [rip+0x1f17f]        # 6a4b8 <allocations>
   4b339:	48 ff c0             	inc    rax
   4b33c:	48 89 05 75 f1 01 00 	mov    QWORD PTR [rip+0x1f175],rax        # 6a4b8 <allocations>
   4b343:	48 89 c2             	mov    rdx,rax
   4b346:	48 09 ca             	or     rdx,rcx
   4b349:	48 c1 ea 20          	shr    rdx,0x20
   4b34d:	74 07                	je     4b356 <f.66+0x1d16>
   4b34f:	31 d2                	xor    edx,edx
   4b351:	48 f7 f1             	div    rcx
   4b354:	eb 04                	jmp    4b35a <f.66+0x1d1a>
   4b356:	31 d2                	xor    edx,edx
   4b358:	f7 f1                	div    ecx
   4b35a:	48 85 d2             	test   rdx,rdx
   4b35d:	75 05                	jne    4b364 <f.66+0x1d24>
   4b35f:	e8 bc 6c 01 00       	call   62020 <native_gc_collect>
   4b364:	48 8b 05 95 ec 01 00 	mov    rax,QWORD PTR [rip+0x1ec95]        # 6a000 <heap_bytes>
   4b36b:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4b36f:	48 83 f8 18          	cmp    rax,0x18
   4b373:	0f 82 5c 29 00 00    	jb     4dcd5 <f.66+0x4695>
   4b379:	48 8b 05 40 f1 01 00 	mov    rax,QWORD PTR [rip+0x1f140]        # 6a4c0 <since_collection>
   4b380:	48 3b 05 81 ec 01 00 	cmp    rax,QWORD PTR [rip+0x1ec81]        # 6a008 <budget>
   4b387:	72 05                	jb     4b38e <f.66+0x1d4e>
   4b389:	e8 92 6c 01 00       	call   62020 <native_gc_collect>
   4b38e:	48 8b 05 ab f1 01 00 	mov    rax,QWORD PTR [rip+0x1f1ab]        # 6a540 <cursor>
   4b395:	48 85 c0             	test   rax,rax
   4b398:	74 10                	je     4b3aa <f.66+0x1d6a>
   4b39a:	48 8b 0d a7 f1 01 00 	mov    rcx,QWORD PTR [rip+0x1f1a7]        # 6a548 <limit>
   4b3a1:	48 29 c1             	sub    rcx,rax
   4b3a4:	48 83 f9 1f          	cmp    rcx,0x1f
   4b3a8:	77 44                	ja     4b3ee <f.66+0x1dae>
   4b3aa:	bf 20 00 00 00       	mov    edi,0x20
   4b3af:	e8 6c 89 01 00       	call   63d20 <allocate_slow>
   4b3b4:	48 85 c0             	test   rax,rax
   4b3b7:	75 40                	jne    4b3f9 <f.66+0x1db9>
   4b3b9:	e8 62 6c 01 00       	call   62020 <native_gc_collect>
   4b3be:	48 8b 05 7b f1 01 00 	mov    rax,QWORD PTR [rip+0x1f17b]        # 6a540 <cursor>
   4b3c5:	48 85 c0             	test   rax,rax
   4b3c8:	74 10                	je     4b3da <f.66+0x1d9a>
   4b3ca:	48 8b 0d 77 f1 01 00 	mov    rcx,QWORD PTR [rip+0x1f177]        # 6a548 <limit>
   4b3d1:	48 29 c1             	sub    rcx,rax
   4b3d4:	48 83 f9 1f          	cmp    rcx,0x1f
   4b3d8:	77 14                	ja     4b3ee <f.66+0x1dae>
   4b3da:	bf 20 00 00 00       	mov    edi,0x20
   4b3df:	e8 3c 89 01 00       	call   63d20 <allocate_slow>
   4b3e4:	48 85 c0             	test   rax,rax
   4b3e7:	75 10                	jne    4b3f9 <f.66+0x1db9>
   4b3e9:	e9 e7 28 00 00       	jmp    4dcd5 <f.66+0x4695>
   4b3ee:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4b3f2:	48 89 0d 47 f1 01 00 	mov    QWORD PTR [rip+0x1f147],rcx        # 6a540 <cursor>
   4b3f9:	48 89 c2             	mov    rdx,rax
   4b3fc:	48 2b 15 35 f1 01 00 	sub    rdx,QWORD PTR [rip+0x1f135]        # 6a538 <arena>
   4b403:	89 d1                	mov    ecx,edx
   4b405:	c1 e9 04             	shr    ecx,0x4
   4b408:	be 01 00 00 00       	mov    esi,0x1
   4b40d:	48 d3 e6             	shl    rsi,cl
   4b410:	48 89 d1             	mov    rcx,rdx
   4b413:	48 c1 e9 0f          	shr    rcx,0xf
   4b417:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4b41e:	48 03 0d cb f0 01 00 	add    rcx,QWORD PTR [rip+0x1f0cb]        # 6a4f0 <blocks>
   4b425:	c1 ea 07             	shr    edx,0x7
   4b428:	81 e2 f8 00 00 00    	and    edx,0xf8
   4b42e:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4b432:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4b439:	48 83 05 7f f0 01 00 	add    QWORD PTR [rip+0x1f07f],0x20        # 6a4c0 <since_collection>
   4b440:	20 
   4b441:	48 83 05 7f f0 01 00 	add    QWORD PTR [rip+0x1f07f],0x18        # 6a4c8 <allocated_bytes>
   4b448:	18 
   4b449:	48 ff 05 80 f0 01 00 	inc    QWORD PTR [rip+0x1f080]        # 6a4d0 <allocated_objects>
   4b450:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4b454:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4b45b:	00 
   4b45c:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
   4b463:	00 
   4b464:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4b468:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4b46c:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4b473:	00 
   4b474:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
   4b47b:	00 
   4b47c:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4b483:	00 
   4b484:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4b48b:	00 
   4b48c:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4b493:	00 
   4b494:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4b49b:	00 
   4b49c:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4b4a3:	00 
   4b4a4:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4b4ab:	00 
   4b4ac:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4b4b3:	00 
   4b4b4:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4b4bb:	00 
   4b4bc:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4b4c3:	00 
   4b4c4:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4b4c9:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4b4d0:	00 
   4b4d1:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4b4d6:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4b4dd:	00 
   4b4de:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4b4e3:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4b4ea:	00 
   4b4eb:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4b4f0:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4b4f7:	00 
   4b4f8:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4b4fd:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4b504:	00 
   4b505:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4b50a:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4b511:	00 
   4b512:	48 89 ac 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rbp
   4b519:	00 
   4b51a:	4c 89 bc 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r15
   4b521:	00 
   4b522:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4b527:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
   4b52e:	00 
   4b52f:	4c 89 b4 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r14
   4b536:	00 
   4b537:	48 c7 44 24 60 14 00 	mov    QWORD PTR [rsp+0x60],0x14
   4b53e:	00 00 
   4b540:	48 8b 0d 69 ef 01 00 	mov    rcx,QWORD PTR [rip+0x1ef69]        # 6a4b0 <collection_interval>
   4b547:	48 85 c9             	test   rcx,rcx
   4b54a:	74 32                	je     4b57e <f.66+0x1f3e>
   4b54c:	48 8b 05 65 ef 01 00 	mov    rax,QWORD PTR [rip+0x1ef65]        # 6a4b8 <allocations>
   4b553:	48 ff c0             	inc    rax
   4b556:	48 89 05 5b ef 01 00 	mov    QWORD PTR [rip+0x1ef5b],rax        # 6a4b8 <allocations>
   4b55d:	48 89 c2             	mov    rdx,rax
   4b560:	48 09 ca             	or     rdx,rcx
   4b563:	48 c1 ea 20          	shr    rdx,0x20
   4b567:	74 07                	je     4b570 <f.66+0x1f30>
   4b569:	31 d2                	xor    edx,edx
   4b56b:	48 f7 f1             	div    rcx
   4b56e:	eb 04                	jmp    4b574 <f.66+0x1f34>
   4b570:	31 d2                	xor    edx,edx
   4b572:	f7 f1                	div    ecx
   4b574:	48 85 d2             	test   rdx,rdx
   4b577:	75 05                	jne    4b57e <f.66+0x1f3e>
   4b579:	e8 a2 6a 01 00       	call   62020 <native_gc_collect>
   4b57e:	48 8b 05 7b ea 01 00 	mov    rax,QWORD PTR [rip+0x1ea7b]        # 6a000 <heap_bytes>
   4b585:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4b589:	48 83 f8 18          	cmp    rax,0x18
   4b58d:	0f 82 42 27 00 00    	jb     4dcd5 <f.66+0x4695>
   4b593:	48 8b 05 26 ef 01 00 	mov    rax,QWORD PTR [rip+0x1ef26]        # 6a4c0 <since_collection>
   4b59a:	48 3b 05 67 ea 01 00 	cmp    rax,QWORD PTR [rip+0x1ea67]        # 6a008 <budget>
   4b5a1:	72 05                	jb     4b5a8 <f.66+0x1f68>
   4b5a3:	e8 78 6a 01 00       	call   62020 <native_gc_collect>
   4b5a8:	48 8b 05 91 ef 01 00 	mov    rax,QWORD PTR [rip+0x1ef91]        # 6a540 <cursor>
   4b5af:	48 85 c0             	test   rax,rax
   4b5b2:	74 10                	je     4b5c4 <f.66+0x1f84>
   4b5b4:	48 8b 0d 8d ef 01 00 	mov    rcx,QWORD PTR [rip+0x1ef8d]        # 6a548 <limit>
   4b5bb:	48 29 c1             	sub    rcx,rax
   4b5be:	48 83 f9 1f          	cmp    rcx,0x1f
   4b5c2:	77 44                	ja     4b608 <f.66+0x1fc8>
   4b5c4:	bf 20 00 00 00       	mov    edi,0x20
   4b5c9:	e8 52 87 01 00       	call   63d20 <allocate_slow>
   4b5ce:	48 85 c0             	test   rax,rax
   4b5d1:	75 40                	jne    4b613 <f.66+0x1fd3>
   4b5d3:	e8 48 6a 01 00       	call   62020 <native_gc_collect>
   4b5d8:	48 8b 05 61 ef 01 00 	mov    rax,QWORD PTR [rip+0x1ef61]        # 6a540 <cursor>
   4b5df:	48 85 c0             	test   rax,rax
   4b5e2:	74 10                	je     4b5f4 <f.66+0x1fb4>
   4b5e4:	48 8b 0d 5d ef 01 00 	mov    rcx,QWORD PTR [rip+0x1ef5d]        # 6a548 <limit>
   4b5eb:	48 29 c1             	sub    rcx,rax
   4b5ee:	48 83 f9 1f          	cmp    rcx,0x1f
   4b5f2:	77 14                	ja     4b608 <f.66+0x1fc8>
   4b5f4:	bf 20 00 00 00       	mov    edi,0x20
   4b5f9:	e8 22 87 01 00       	call   63d20 <allocate_slow>
   4b5fe:	48 85 c0             	test   rax,rax
   4b601:	75 10                	jne    4b613 <f.66+0x1fd3>
   4b603:	e9 cd 26 00 00       	jmp    4dcd5 <f.66+0x4695>
   4b608:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4b60c:	48 89 0d 2d ef 01 00 	mov    QWORD PTR [rip+0x1ef2d],rcx        # 6a540 <cursor>
   4b613:	48 89 c2             	mov    rdx,rax
   4b616:	48 2b 15 1b ef 01 00 	sub    rdx,QWORD PTR [rip+0x1ef1b]        # 6a538 <arena>
   4b61d:	89 d1                	mov    ecx,edx
   4b61f:	c1 e9 04             	shr    ecx,0x4
   4b622:	be 01 00 00 00       	mov    esi,0x1
   4b627:	48 d3 e6             	shl    rsi,cl
   4b62a:	48 89 d1             	mov    rcx,rdx
   4b62d:	48 c1 e9 0f          	shr    rcx,0xf
   4b631:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4b638:	48 03 0d b1 ee 01 00 	add    rcx,QWORD PTR [rip+0x1eeb1]        # 6a4f0 <blocks>
   4b63f:	c1 ea 07             	shr    edx,0x7
   4b642:	81 e2 f8 00 00 00    	and    edx,0xf8
   4b648:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4b64c:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4b653:	48 83 05 65 ee 01 00 	add    QWORD PTR [rip+0x1ee65],0x20        # 6a4c0 <since_collection>
   4b65a:	20 
   4b65b:	48 83 05 65 ee 01 00 	add    QWORD PTR [rip+0x1ee65],0x18        # 6a4c8 <allocated_bytes>
   4b662:	18 
   4b663:	48 ff 05 66 ee 01 00 	inc    QWORD PTR [rip+0x1ee66]        # 6a4d0 <allocated_objects>
   4b66a:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4b66e:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4b675:	00 
   4b676:	48 8b 8c 24 50 01 00 	mov    rcx,QWORD PTR [rsp+0x150]
   4b67d:	00 
   4b67e:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4b682:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4b686:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4b68d:	00 
   4b68e:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
   4b695:	00 
   4b696:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4b69d:	00 
   4b69e:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4b6a5:	00 
   4b6a6:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4b6ad:	00 
   4b6ae:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4b6b5:	00 
   4b6b6:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4b6bd:	00 
   4b6be:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4b6c5:	00 
   4b6c6:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4b6cd:	00 
   4b6ce:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4b6d3:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4b6da:	00 
   4b6db:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4b6e0:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4b6e7:	00 
   4b6e8:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4b6ed:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4b6f4:	00 
   4b6f5:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4b6fa:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4b701:	00 
   4b702:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4b707:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4b70e:	00 
   4b70f:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4b714:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4b71b:	00 
   4b71c:	48 89 ac 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rbp
   4b723:	00 
   4b724:	4c 89 bc 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r15
   4b72b:	00 
   4b72c:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4b731:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
   4b738:	00 
   4b739:	4c 89 b4 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],r14
   4b740:	00 
   4b741:	48 c7 44 24 60 13 00 	mov    QWORD PTR [rsp+0x60],0x13
   4b748:	00 00 
   4b74a:	48 8b 0d 5f ed 01 00 	mov    rcx,QWORD PTR [rip+0x1ed5f]        # 6a4b0 <collection_interval>
   4b751:	48 85 c9             	test   rcx,rcx
   4b754:	74 32                	je     4b788 <f.66+0x2148>
   4b756:	48 8b 05 5b ed 01 00 	mov    rax,QWORD PTR [rip+0x1ed5b]        # 6a4b8 <allocations>
   4b75d:	48 ff c0             	inc    rax
   4b760:	48 89 05 51 ed 01 00 	mov    QWORD PTR [rip+0x1ed51],rax        # 6a4b8 <allocations>
   4b767:	48 89 c2             	mov    rdx,rax
   4b76a:	48 09 ca             	or     rdx,rcx
   4b76d:	48 c1 ea 20          	shr    rdx,0x20
   4b771:	74 07                	je     4b77a <f.66+0x213a>
   4b773:	31 d2                	xor    edx,edx
   4b775:	48 f7 f1             	div    rcx
   4b778:	eb 04                	jmp    4b77e <f.66+0x213e>
   4b77a:	31 d2                	xor    edx,edx
   4b77c:	f7 f1                	div    ecx
   4b77e:	48 85 d2             	test   rdx,rdx
   4b781:	75 05                	jne    4b788 <f.66+0x2148>
   4b783:	e8 98 68 01 00       	call   62020 <native_gc_collect>
   4b788:	48 8b 05 71 e8 01 00 	mov    rax,QWORD PTR [rip+0x1e871]        # 6a000 <heap_bytes>
   4b78f:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4b793:	48 83 f8 18          	cmp    rax,0x18
   4b797:	0f 82 38 25 00 00    	jb     4dcd5 <f.66+0x4695>
   4b79d:	48 8b 05 1c ed 01 00 	mov    rax,QWORD PTR [rip+0x1ed1c]        # 6a4c0 <since_collection>
   4b7a4:	48 3b 05 5d e8 01 00 	cmp    rax,QWORD PTR [rip+0x1e85d]        # 6a008 <budget>
   4b7ab:	72 05                	jb     4b7b2 <f.66+0x2172>
   4b7ad:	e8 6e 68 01 00       	call   62020 <native_gc_collect>
   4b7b2:	48 8b 05 87 ed 01 00 	mov    rax,QWORD PTR [rip+0x1ed87]        # 6a540 <cursor>
   4b7b9:	48 85 c0             	test   rax,rax
   4b7bc:	74 10                	je     4b7ce <f.66+0x218e>
   4b7be:	48 8b 0d 83 ed 01 00 	mov    rcx,QWORD PTR [rip+0x1ed83]        # 6a548 <limit>
   4b7c5:	48 29 c1             	sub    rcx,rax
   4b7c8:	48 83 f9 1f          	cmp    rcx,0x1f
   4b7cc:	77 44                	ja     4b812 <f.66+0x21d2>
   4b7ce:	bf 20 00 00 00       	mov    edi,0x20
   4b7d3:	e8 48 85 01 00       	call   63d20 <allocate_slow>
   4b7d8:	48 85 c0             	test   rax,rax
   4b7db:	75 40                	jne    4b81d <f.66+0x21dd>
   4b7dd:	e8 3e 68 01 00       	call   62020 <native_gc_collect>
   4b7e2:	48 8b 05 57 ed 01 00 	mov    rax,QWORD PTR [rip+0x1ed57]        # 6a540 <cursor>
   4b7e9:	48 85 c0             	test   rax,rax
   4b7ec:	74 10                	je     4b7fe <f.66+0x21be>
   4b7ee:	48 8b 0d 53 ed 01 00 	mov    rcx,QWORD PTR [rip+0x1ed53]        # 6a548 <limit>
   4b7f5:	48 29 c1             	sub    rcx,rax
   4b7f8:	48 83 f9 1f          	cmp    rcx,0x1f
   4b7fc:	77 14                	ja     4b812 <f.66+0x21d2>
   4b7fe:	bf 20 00 00 00       	mov    edi,0x20
   4b803:	e8 18 85 01 00       	call   63d20 <allocate_slow>
   4b808:	48 85 c0             	test   rax,rax
   4b80b:	75 10                	jne    4b81d <f.66+0x21dd>
   4b80d:	e9 c3 24 00 00       	jmp    4dcd5 <f.66+0x4695>
   4b812:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4b816:	48 89 0d 23 ed 01 00 	mov    QWORD PTR [rip+0x1ed23],rcx        # 6a540 <cursor>
   4b81d:	48 89 c2             	mov    rdx,rax
   4b820:	48 2b 15 11 ed 01 00 	sub    rdx,QWORD PTR [rip+0x1ed11]        # 6a538 <arena>
   4b827:	89 d1                	mov    ecx,edx
   4b829:	c1 e9 04             	shr    ecx,0x4
   4b82c:	be 01 00 00 00       	mov    esi,0x1
   4b831:	48 d3 e6             	shl    rsi,cl
   4b834:	48 89 d1             	mov    rcx,rdx
   4b837:	48 c1 e9 0f          	shr    rcx,0xf
   4b83b:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4b842:	48 03 0d a7 ec 01 00 	add    rcx,QWORD PTR [rip+0x1eca7]        # 6a4f0 <blocks>
   4b849:	c1 ea 07             	shr    edx,0x7
   4b84c:	81 e2 f8 00 00 00    	and    edx,0xf8
   4b852:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4b856:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4b85d:	48 83 05 5b ec 01 00 	add    QWORD PTR [rip+0x1ec5b],0x20        # 6a4c0 <since_collection>
   4b864:	20 
   4b865:	48 83 05 5b ec 01 00 	add    QWORD PTR [rip+0x1ec5b],0x18        # 6a4c8 <allocated_bytes>
   4b86c:	18 
   4b86d:	48 ff 05 5c ec 01 00 	inc    QWORD PTR [rip+0x1ec5c]        # 6a4d0 <allocated_objects>
   4b874:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4b878:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4b87f:	00 
   4b880:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
   4b887:	00 
   4b888:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4b88c:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4b890:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4b897:	00 
   4b898:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
   4b89f:	00 
   4b8a0:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4b8a7:	00 
   4b8a8:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4b8af:	00 
   4b8b0:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4b8b7:	00 
   4b8b8:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4b8bf:	00 
   4b8c0:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4b8c7:	00 
   4b8c8:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4b8cd:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4b8d4:	00 
   4b8d5:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4b8da:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4b8e1:	00 
   4b8e2:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4b8e7:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4b8ee:	00 
   4b8ef:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4b8f4:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4b8fb:	00 
   4b8fc:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4b901:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4b908:	00 
   4b909:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4b90e:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4b915:	00 
   4b916:	48 89 ac 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rbp
   4b91d:	00 
   4b91e:	4c 89 bc 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],r15
   4b925:	00 
   4b926:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4b92b:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
   4b932:	00 
   4b933:	4c 89 b4 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r14
   4b93a:	00 
   4b93b:	48 c7 44 24 60 12 00 	mov    QWORD PTR [rsp+0x60],0x12
   4b942:	00 00 
   4b944:	48 8b 0d 65 eb 01 00 	mov    rcx,QWORD PTR [rip+0x1eb65]        # 6a4b0 <collection_interval>
   4b94b:	48 85 c9             	test   rcx,rcx
   4b94e:	74 32                	je     4b982 <f.66+0x2342>
   4b950:	48 8b 05 61 eb 01 00 	mov    rax,QWORD PTR [rip+0x1eb61]        # 6a4b8 <allocations>
   4b957:	48 ff c0             	inc    rax
   4b95a:	48 89 05 57 eb 01 00 	mov    QWORD PTR [rip+0x1eb57],rax        # 6a4b8 <allocations>
   4b961:	48 89 c2             	mov    rdx,rax
   4b964:	48 09 ca             	or     rdx,rcx
   4b967:	48 c1 ea 20          	shr    rdx,0x20
   4b96b:	74 07                	je     4b974 <f.66+0x2334>
   4b96d:	31 d2                	xor    edx,edx
   4b96f:	48 f7 f1             	div    rcx
   4b972:	eb 04                	jmp    4b978 <f.66+0x2338>
   4b974:	31 d2                	xor    edx,edx
   4b976:	f7 f1                	div    ecx
   4b978:	48 85 d2             	test   rdx,rdx
   4b97b:	75 05                	jne    4b982 <f.66+0x2342>
   4b97d:	e8 9e 66 01 00       	call   62020 <native_gc_collect>
   4b982:	48 8b 05 77 e6 01 00 	mov    rax,QWORD PTR [rip+0x1e677]        # 6a000 <heap_bytes>
   4b989:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4b98d:	48 83 f8 18          	cmp    rax,0x18
   4b991:	0f 82 3e 23 00 00    	jb     4dcd5 <f.66+0x4695>
   4b997:	48 8b 05 22 eb 01 00 	mov    rax,QWORD PTR [rip+0x1eb22]        # 6a4c0 <since_collection>
   4b99e:	48 3b 05 63 e6 01 00 	cmp    rax,QWORD PTR [rip+0x1e663]        # 6a008 <budget>
   4b9a5:	72 05                	jb     4b9ac <f.66+0x236c>
   4b9a7:	e8 74 66 01 00       	call   62020 <native_gc_collect>
   4b9ac:	48 8b 05 8d eb 01 00 	mov    rax,QWORD PTR [rip+0x1eb8d]        # 6a540 <cursor>
   4b9b3:	48 85 c0             	test   rax,rax
   4b9b6:	74 10                	je     4b9c8 <f.66+0x2388>
   4b9b8:	48 8b 0d 89 eb 01 00 	mov    rcx,QWORD PTR [rip+0x1eb89]        # 6a548 <limit>
   4b9bf:	48 29 c1             	sub    rcx,rax
   4b9c2:	48 83 f9 1f          	cmp    rcx,0x1f
   4b9c6:	77 44                	ja     4ba0c <f.66+0x23cc>
   4b9c8:	bf 20 00 00 00       	mov    edi,0x20
   4b9cd:	e8 4e 83 01 00       	call   63d20 <allocate_slow>
   4b9d2:	48 85 c0             	test   rax,rax
   4b9d5:	75 40                	jne    4ba17 <f.66+0x23d7>
   4b9d7:	e8 44 66 01 00       	call   62020 <native_gc_collect>
   4b9dc:	48 8b 05 5d eb 01 00 	mov    rax,QWORD PTR [rip+0x1eb5d]        # 6a540 <cursor>
   4b9e3:	48 85 c0             	test   rax,rax
   4b9e6:	74 10                	je     4b9f8 <f.66+0x23b8>
   4b9e8:	48 8b 0d 59 eb 01 00 	mov    rcx,QWORD PTR [rip+0x1eb59]        # 6a548 <limit>
   4b9ef:	48 29 c1             	sub    rcx,rax
   4b9f2:	48 83 f9 1f          	cmp    rcx,0x1f
   4b9f6:	77 14                	ja     4ba0c <f.66+0x23cc>
   4b9f8:	bf 20 00 00 00       	mov    edi,0x20
   4b9fd:	e8 1e 83 01 00       	call   63d20 <allocate_slow>
   4ba02:	48 85 c0             	test   rax,rax
   4ba05:	75 10                	jne    4ba17 <f.66+0x23d7>
   4ba07:	e9 c9 22 00 00       	jmp    4dcd5 <f.66+0x4695>
   4ba0c:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4ba10:	48 89 0d 29 eb 01 00 	mov    QWORD PTR [rip+0x1eb29],rcx        # 6a540 <cursor>
   4ba17:	48 89 c2             	mov    rdx,rax
   4ba1a:	48 2b 15 17 eb 01 00 	sub    rdx,QWORD PTR [rip+0x1eb17]        # 6a538 <arena>
   4ba21:	89 d1                	mov    ecx,edx
   4ba23:	c1 e9 04             	shr    ecx,0x4
   4ba26:	be 01 00 00 00       	mov    esi,0x1
   4ba2b:	48 d3 e6             	shl    rsi,cl
   4ba2e:	48 89 d1             	mov    rcx,rdx
   4ba31:	48 c1 e9 0f          	shr    rcx,0xf
   4ba35:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4ba3c:	48 03 0d ad ea 01 00 	add    rcx,QWORD PTR [rip+0x1eaad]        # 6a4f0 <blocks>
   4ba43:	c1 ea 07             	shr    edx,0x7
   4ba46:	81 e2 f8 00 00 00    	and    edx,0xf8
   4ba4c:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4ba50:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4ba57:	48 83 05 61 ea 01 00 	add    QWORD PTR [rip+0x1ea61],0x20        # 6a4c0 <since_collection>
   4ba5e:	20 
   4ba5f:	48 83 05 61 ea 01 00 	add    QWORD PTR [rip+0x1ea61],0x18        # 6a4c8 <allocated_bytes>
   4ba66:	18 
   4ba67:	48 ff 05 62 ea 01 00 	inc    QWORD PTR [rip+0x1ea62]        # 6a4d0 <allocated_objects>
   4ba6e:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4ba72:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4ba79:	00 
   4ba7a:	48 8b 8c 24 40 01 00 	mov    rcx,QWORD PTR [rsp+0x140]
   4ba81:	00 
   4ba82:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4ba86:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4ba8a:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4ba91:	00 
   4ba92:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
   4ba99:	00 
   4ba9a:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4baa1:	00 
   4baa2:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4baa9:	00 
   4baaa:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4bab1:	00 
   4bab2:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4bab7:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4babe:	00 
   4babf:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4bac4:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4bacb:	00 
   4bacc:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4bad1:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4bad8:	00 
   4bad9:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4bade:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4bae5:	00 
   4bae6:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4baeb:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4baf2:	00 
   4baf3:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4baf8:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4baff:	00 
   4bb00:	48 89 ac 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rbp
   4bb07:	00 
   4bb08:	4c 89 bc 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r15
   4bb0f:	00 
   4bb10:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4bb15:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
   4bb1c:	00 
   4bb1d:	4c 89 b4 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r14
   4bb24:	00 
   4bb25:	48 c7 44 24 60 11 00 	mov    QWORD PTR [rsp+0x60],0x11
   4bb2c:	00 00 
   4bb2e:	48 8b 0d 7b e9 01 00 	mov    rcx,QWORD PTR [rip+0x1e97b]        # 6a4b0 <collection_interval>
   4bb35:	48 85 c9             	test   rcx,rcx
   4bb38:	74 32                	je     4bb6c <f.66+0x252c>
   4bb3a:	48 8b 05 77 e9 01 00 	mov    rax,QWORD PTR [rip+0x1e977]        # 6a4b8 <allocations>
   4bb41:	48 ff c0             	inc    rax
   4bb44:	48 89 05 6d e9 01 00 	mov    QWORD PTR [rip+0x1e96d],rax        # 6a4b8 <allocations>
   4bb4b:	48 89 c2             	mov    rdx,rax
   4bb4e:	48 09 ca             	or     rdx,rcx
   4bb51:	48 c1 ea 20          	shr    rdx,0x20
   4bb55:	74 07                	je     4bb5e <f.66+0x251e>
   4bb57:	31 d2                	xor    edx,edx
   4bb59:	48 f7 f1             	div    rcx
   4bb5c:	eb 04                	jmp    4bb62 <f.66+0x2522>
   4bb5e:	31 d2                	xor    edx,edx
   4bb60:	f7 f1                	div    ecx
   4bb62:	48 85 d2             	test   rdx,rdx
   4bb65:	75 05                	jne    4bb6c <f.66+0x252c>
   4bb67:	e8 b4 64 01 00       	call   62020 <native_gc_collect>
   4bb6c:	48 8b 05 8d e4 01 00 	mov    rax,QWORD PTR [rip+0x1e48d]        # 6a000 <heap_bytes>
   4bb73:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4bb77:	48 83 f8 18          	cmp    rax,0x18
   4bb7b:	0f 82 54 21 00 00    	jb     4dcd5 <f.66+0x4695>
   4bb81:	48 8b 05 38 e9 01 00 	mov    rax,QWORD PTR [rip+0x1e938]        # 6a4c0 <since_collection>
   4bb88:	48 3b 05 79 e4 01 00 	cmp    rax,QWORD PTR [rip+0x1e479]        # 6a008 <budget>
   4bb8f:	72 05                	jb     4bb96 <f.66+0x2556>
   4bb91:	e8 8a 64 01 00       	call   62020 <native_gc_collect>
   4bb96:	48 8b 05 a3 e9 01 00 	mov    rax,QWORD PTR [rip+0x1e9a3]        # 6a540 <cursor>
   4bb9d:	48 85 c0             	test   rax,rax
   4bba0:	74 10                	je     4bbb2 <f.66+0x2572>
   4bba2:	48 8b 0d 9f e9 01 00 	mov    rcx,QWORD PTR [rip+0x1e99f]        # 6a548 <limit>
   4bba9:	48 29 c1             	sub    rcx,rax
   4bbac:	48 83 f9 1f          	cmp    rcx,0x1f
   4bbb0:	77 44                	ja     4bbf6 <f.66+0x25b6>
   4bbb2:	bf 20 00 00 00       	mov    edi,0x20
   4bbb7:	e8 64 81 01 00       	call   63d20 <allocate_slow>
   4bbbc:	48 85 c0             	test   rax,rax
   4bbbf:	75 40                	jne    4bc01 <f.66+0x25c1>
   4bbc1:	e8 5a 64 01 00       	call   62020 <native_gc_collect>
   4bbc6:	48 8b 05 73 e9 01 00 	mov    rax,QWORD PTR [rip+0x1e973]        # 6a540 <cursor>
   4bbcd:	48 85 c0             	test   rax,rax
   4bbd0:	74 10                	je     4bbe2 <f.66+0x25a2>
   4bbd2:	48 8b 0d 6f e9 01 00 	mov    rcx,QWORD PTR [rip+0x1e96f]        # 6a548 <limit>
   4bbd9:	48 29 c1             	sub    rcx,rax
   4bbdc:	48 83 f9 1f          	cmp    rcx,0x1f
   4bbe0:	77 14                	ja     4bbf6 <f.66+0x25b6>
   4bbe2:	bf 20 00 00 00       	mov    edi,0x20
   4bbe7:	e8 34 81 01 00       	call   63d20 <allocate_slow>
   4bbec:	48 85 c0             	test   rax,rax
   4bbef:	75 10                	jne    4bc01 <f.66+0x25c1>
   4bbf1:	e9 df 20 00 00       	jmp    4dcd5 <f.66+0x4695>
   4bbf6:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4bbfa:	48 89 0d 3f e9 01 00 	mov    QWORD PTR [rip+0x1e93f],rcx        # 6a540 <cursor>
   4bc01:	48 89 c2             	mov    rdx,rax
   4bc04:	48 2b 15 2d e9 01 00 	sub    rdx,QWORD PTR [rip+0x1e92d]        # 6a538 <arena>
   4bc0b:	89 d1                	mov    ecx,edx
   4bc0d:	c1 e9 04             	shr    ecx,0x4
   4bc10:	be 01 00 00 00       	mov    esi,0x1
   4bc15:	48 d3 e6             	shl    rsi,cl
   4bc18:	48 89 d1             	mov    rcx,rdx
   4bc1b:	48 c1 e9 0f          	shr    rcx,0xf
   4bc1f:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4bc26:	48 03 0d c3 e8 01 00 	add    rcx,QWORD PTR [rip+0x1e8c3]        # 6a4f0 <blocks>
   4bc2d:	c1 ea 07             	shr    edx,0x7
   4bc30:	81 e2 f8 00 00 00    	and    edx,0xf8
   4bc36:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4bc3a:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4bc41:	48 83 05 77 e8 01 00 	add    QWORD PTR [rip+0x1e877],0x20        # 6a4c0 <since_collection>
   4bc48:	20 
   4bc49:	48 83 05 77 e8 01 00 	add    QWORD PTR [rip+0x1e877],0x18        # 6a4c8 <allocated_bytes>
   4bc50:	18 
   4bc51:	48 ff 05 78 e8 01 00 	inc    QWORD PTR [rip+0x1e878]        # 6a4d0 <allocated_objects>
   4bc58:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4bc5c:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4bc63:	00 
   4bc64:	48 8b 8c 24 38 01 00 	mov    rcx,QWORD PTR [rsp+0x138]
   4bc6b:	00 
   4bc6c:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4bc70:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4bc74:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4bc7b:	00 
   4bc7c:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
   4bc83:	00 
   4bc84:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4bc8b:	00 
   4bc8c:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4bc91:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4bc98:	00 
   4bc99:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4bc9e:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4bca5:	00 
   4bca6:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4bcab:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4bcb2:	00 
   4bcb3:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4bcb8:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4bcbf:	00 
   4bcc0:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4bcc5:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4bccc:	00 
   4bccd:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4bcd2:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4bcd9:	00 
   4bcda:	48 89 ac 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rbp
   4bce1:	00 
   4bce2:	4c 89 bc 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r15
   4bce9:	00 
   4bcea:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4bcef:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
   4bcf6:	00 
   4bcf7:	4c 89 b4 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],r14
   4bcfe:	00 
   4bcff:	48 c7 44 24 60 10 00 	mov    QWORD PTR [rsp+0x60],0x10
   4bd06:	00 00 
   4bd08:	48 8b 0d a1 e7 01 00 	mov    rcx,QWORD PTR [rip+0x1e7a1]        # 6a4b0 <collection_interval>
   4bd0f:	48 85 c9             	test   rcx,rcx
   4bd12:	74 32                	je     4bd46 <f.66+0x2706>
   4bd14:	48 8b 05 9d e7 01 00 	mov    rax,QWORD PTR [rip+0x1e79d]        # 6a4b8 <allocations>
   4bd1b:	48 ff c0             	inc    rax
   4bd1e:	48 89 05 93 e7 01 00 	mov    QWORD PTR [rip+0x1e793],rax        # 6a4b8 <allocations>
   4bd25:	48 89 c2             	mov    rdx,rax
   4bd28:	48 09 ca             	or     rdx,rcx
   4bd2b:	48 c1 ea 20          	shr    rdx,0x20
   4bd2f:	74 07                	je     4bd38 <f.66+0x26f8>
   4bd31:	31 d2                	xor    edx,edx
   4bd33:	48 f7 f1             	div    rcx
   4bd36:	eb 04                	jmp    4bd3c <f.66+0x26fc>
   4bd38:	31 d2                	xor    edx,edx
   4bd3a:	f7 f1                	div    ecx
   4bd3c:	48 85 d2             	test   rdx,rdx
   4bd3f:	75 05                	jne    4bd46 <f.66+0x2706>
   4bd41:	e8 da 62 01 00       	call   62020 <native_gc_collect>
   4bd46:	48 8b 05 b3 e2 01 00 	mov    rax,QWORD PTR [rip+0x1e2b3]        # 6a000 <heap_bytes>
   4bd4d:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4bd51:	48 83 f8 18          	cmp    rax,0x18
   4bd55:	0f 82 7a 1f 00 00    	jb     4dcd5 <f.66+0x4695>
   4bd5b:	48 8b 05 5e e7 01 00 	mov    rax,QWORD PTR [rip+0x1e75e]        # 6a4c0 <since_collection>
   4bd62:	48 3b 05 9f e2 01 00 	cmp    rax,QWORD PTR [rip+0x1e29f]        # 6a008 <budget>
   4bd69:	72 05                	jb     4bd70 <f.66+0x2730>
   4bd6b:	e8 b0 62 01 00       	call   62020 <native_gc_collect>
   4bd70:	48 8b 05 c9 e7 01 00 	mov    rax,QWORD PTR [rip+0x1e7c9]        # 6a540 <cursor>
   4bd77:	48 85 c0             	test   rax,rax
   4bd7a:	74 10                	je     4bd8c <f.66+0x274c>
   4bd7c:	48 8b 0d c5 e7 01 00 	mov    rcx,QWORD PTR [rip+0x1e7c5]        # 6a548 <limit>
   4bd83:	48 29 c1             	sub    rcx,rax
   4bd86:	48 83 f9 1f          	cmp    rcx,0x1f
   4bd8a:	77 44                	ja     4bdd0 <f.66+0x2790>
   4bd8c:	bf 20 00 00 00       	mov    edi,0x20
   4bd91:	e8 8a 7f 01 00       	call   63d20 <allocate_slow>
   4bd96:	48 85 c0             	test   rax,rax
   4bd99:	75 40                	jne    4bddb <f.66+0x279b>
   4bd9b:	e8 80 62 01 00       	call   62020 <native_gc_collect>
   4bda0:	48 8b 05 99 e7 01 00 	mov    rax,QWORD PTR [rip+0x1e799]        # 6a540 <cursor>
   4bda7:	48 85 c0             	test   rax,rax
   4bdaa:	74 10                	je     4bdbc <f.66+0x277c>
   4bdac:	48 8b 0d 95 e7 01 00 	mov    rcx,QWORD PTR [rip+0x1e795]        # 6a548 <limit>
   4bdb3:	48 29 c1             	sub    rcx,rax
   4bdb6:	48 83 f9 1f          	cmp    rcx,0x1f
   4bdba:	77 14                	ja     4bdd0 <f.66+0x2790>
   4bdbc:	bf 20 00 00 00       	mov    edi,0x20
   4bdc1:	e8 5a 7f 01 00       	call   63d20 <allocate_slow>
   4bdc6:	48 85 c0             	test   rax,rax
   4bdc9:	75 10                	jne    4bddb <f.66+0x279b>
   4bdcb:	e9 05 1f 00 00       	jmp    4dcd5 <f.66+0x4695>
   4bdd0:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4bdd4:	48 89 0d 65 e7 01 00 	mov    QWORD PTR [rip+0x1e765],rcx        # 6a540 <cursor>
   4bddb:	48 89 c2             	mov    rdx,rax
   4bdde:	48 2b 15 53 e7 01 00 	sub    rdx,QWORD PTR [rip+0x1e753]        # 6a538 <arena>
   4bde5:	89 d1                	mov    ecx,edx
   4bde7:	c1 e9 04             	shr    ecx,0x4
   4bdea:	be 01 00 00 00       	mov    esi,0x1
   4bdef:	48 d3 e6             	shl    rsi,cl
   4bdf2:	48 89 d1             	mov    rcx,rdx
   4bdf5:	48 c1 e9 0f          	shr    rcx,0xf
   4bdf9:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4be00:	48 03 0d e9 e6 01 00 	add    rcx,QWORD PTR [rip+0x1e6e9]        # 6a4f0 <blocks>
   4be07:	c1 ea 07             	shr    edx,0x7
   4be0a:	81 e2 f8 00 00 00    	and    edx,0xf8
   4be10:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4be14:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4be1b:	48 83 05 9d e6 01 00 	add    QWORD PTR [rip+0x1e69d],0x20        # 6a4c0 <since_collection>
   4be22:	20 
   4be23:	48 83 05 9d e6 01 00 	add    QWORD PTR [rip+0x1e69d],0x18        # 6a4c8 <allocated_bytes>
   4be2a:	18 
   4be2b:	48 ff 05 9e e6 01 00 	inc    QWORD PTR [rip+0x1e69e]        # 6a4d0 <allocated_objects>
   4be32:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4be36:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4be3d:	00 
   4be3e:	48 8b 8c 24 30 01 00 	mov    rcx,QWORD PTR [rsp+0x130]
   4be45:	00 
   4be46:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4be4a:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4be4e:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4be55:	00 
   4be56:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
   4be5b:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4be62:	00 
   4be63:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4be68:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4be6f:	00 
   4be70:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4be75:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4be7c:	00 
   4be7d:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4be82:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4be89:	00 
   4be8a:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4be8f:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4be96:	00 
   4be97:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4be9c:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4bea3:	00 
   4bea4:	48 89 ac 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rbp
   4beab:	00 
   4beac:	4c 89 bc 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],r15
   4beb3:	00 
   4beb4:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4beb9:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
   4bec0:	00 
   4bec1:	4c 89 b4 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r14
   4bec8:	00 
   4bec9:	48 c7 44 24 60 0f 00 	mov    QWORD PTR [rsp+0x60],0xf
   4bed0:	00 00 
   4bed2:	48 8b 0d d7 e5 01 00 	mov    rcx,QWORD PTR [rip+0x1e5d7]        # 6a4b0 <collection_interval>
   4bed9:	48 85 c9             	test   rcx,rcx
   4bedc:	74 32                	je     4bf10 <f.66+0x28d0>
   4bede:	48 8b 05 d3 e5 01 00 	mov    rax,QWORD PTR [rip+0x1e5d3]        # 6a4b8 <allocations>
   4bee5:	48 ff c0             	inc    rax
   4bee8:	48 89 05 c9 e5 01 00 	mov    QWORD PTR [rip+0x1e5c9],rax        # 6a4b8 <allocations>
   4beef:	48 89 c2             	mov    rdx,rax
   4bef2:	48 09 ca             	or     rdx,rcx
   4bef5:	48 c1 ea 20          	shr    rdx,0x20
   4bef9:	74 07                	je     4bf02 <f.66+0x28c2>
   4befb:	31 d2                	xor    edx,edx
   4befd:	48 f7 f1             	div    rcx
   4bf00:	eb 04                	jmp    4bf06 <f.66+0x28c6>
   4bf02:	31 d2                	xor    edx,edx
   4bf04:	f7 f1                	div    ecx
   4bf06:	48 85 d2             	test   rdx,rdx
   4bf09:	75 05                	jne    4bf10 <f.66+0x28d0>
   4bf0b:	e8 10 61 01 00       	call   62020 <native_gc_collect>
   4bf10:	48 8b 05 e9 e0 01 00 	mov    rax,QWORD PTR [rip+0x1e0e9]        # 6a000 <heap_bytes>
   4bf17:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4bf1b:	48 83 f8 18          	cmp    rax,0x18
   4bf1f:	0f 82 b0 1d 00 00    	jb     4dcd5 <f.66+0x4695>
   4bf25:	48 8b 05 94 e5 01 00 	mov    rax,QWORD PTR [rip+0x1e594]        # 6a4c0 <since_collection>
   4bf2c:	48 3b 05 d5 e0 01 00 	cmp    rax,QWORD PTR [rip+0x1e0d5]        # 6a008 <budget>
   4bf33:	72 05                	jb     4bf3a <f.66+0x28fa>
   4bf35:	e8 e6 60 01 00       	call   62020 <native_gc_collect>
   4bf3a:	48 8b 05 ff e5 01 00 	mov    rax,QWORD PTR [rip+0x1e5ff]        # 6a540 <cursor>
   4bf41:	48 85 c0             	test   rax,rax
   4bf44:	74 10                	je     4bf56 <f.66+0x2916>
   4bf46:	48 8b 0d fb e5 01 00 	mov    rcx,QWORD PTR [rip+0x1e5fb]        # 6a548 <limit>
   4bf4d:	48 29 c1             	sub    rcx,rax
   4bf50:	48 83 f9 1f          	cmp    rcx,0x1f
   4bf54:	77 44                	ja     4bf9a <f.66+0x295a>
   4bf56:	bf 20 00 00 00       	mov    edi,0x20
   4bf5b:	e8 c0 7d 01 00       	call   63d20 <allocate_slow>
   4bf60:	48 85 c0             	test   rax,rax
   4bf63:	75 40                	jne    4bfa5 <f.66+0x2965>
   4bf65:	e8 b6 60 01 00       	call   62020 <native_gc_collect>
   4bf6a:	48 8b 05 cf e5 01 00 	mov    rax,QWORD PTR [rip+0x1e5cf]        # 6a540 <cursor>
   4bf71:	48 85 c0             	test   rax,rax
   4bf74:	74 10                	je     4bf86 <f.66+0x2946>
   4bf76:	48 8b 0d cb e5 01 00 	mov    rcx,QWORD PTR [rip+0x1e5cb]        # 6a548 <limit>
   4bf7d:	48 29 c1             	sub    rcx,rax
   4bf80:	48 83 f9 1f          	cmp    rcx,0x1f
   4bf84:	77 14                	ja     4bf9a <f.66+0x295a>
   4bf86:	bf 20 00 00 00       	mov    edi,0x20
   4bf8b:	e8 90 7d 01 00       	call   63d20 <allocate_slow>
   4bf90:	48 85 c0             	test   rax,rax
   4bf93:	75 10                	jne    4bfa5 <f.66+0x2965>
   4bf95:	e9 3b 1d 00 00       	jmp    4dcd5 <f.66+0x4695>
   4bf9a:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4bf9e:	48 89 0d 9b e5 01 00 	mov    QWORD PTR [rip+0x1e59b],rcx        # 6a540 <cursor>
   4bfa5:	48 89 c2             	mov    rdx,rax
   4bfa8:	48 2b 15 89 e5 01 00 	sub    rdx,QWORD PTR [rip+0x1e589]        # 6a538 <arena>
   4bfaf:	89 d1                	mov    ecx,edx
   4bfb1:	c1 e9 04             	shr    ecx,0x4
   4bfb4:	be 01 00 00 00       	mov    esi,0x1
   4bfb9:	48 d3 e6             	shl    rsi,cl
   4bfbc:	48 89 d1             	mov    rcx,rdx
   4bfbf:	48 c1 e9 0f          	shr    rcx,0xf
   4bfc3:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4bfca:	48 03 0d 1f e5 01 00 	add    rcx,QWORD PTR [rip+0x1e51f]        # 6a4f0 <blocks>
   4bfd1:	c1 ea 07             	shr    edx,0x7
   4bfd4:	81 e2 f8 00 00 00    	and    edx,0xf8
   4bfda:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4bfde:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4bfe5:	48 83 05 d3 e4 01 00 	add    QWORD PTR [rip+0x1e4d3],0x20        # 6a4c0 <since_collection>
   4bfec:	20 
   4bfed:	48 83 05 d3 e4 01 00 	add    QWORD PTR [rip+0x1e4d3],0x18        # 6a4c8 <allocated_bytes>
   4bff4:	18 
   4bff5:	48 ff 05 d4 e4 01 00 	inc    QWORD PTR [rip+0x1e4d4]        # 6a4d0 <allocated_objects>
   4bffc:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4c000:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4c007:	00 
   4c008:	48 8b 4c 24 48       	mov    rcx,QWORD PTR [rsp+0x48]
   4c00d:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4c011:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4c015:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4c01c:	00 
   4c01d:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
   4c022:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4c029:	00 
   4c02a:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4c02f:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4c036:	00 
   4c037:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4c03c:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4c043:	00 
   4c044:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4c049:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4c050:	00 
   4c051:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4c056:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4c05d:	00 
   4c05e:	48 89 ac 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rbp
   4c065:	00 
   4c066:	4c 89 bc 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],r15
   4c06d:	00 
   4c06e:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4c073:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
   4c07a:	00 
   4c07b:	4c 89 b4 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r14
   4c082:	00 
   4c083:	48 c7 44 24 60 0e 00 	mov    QWORD PTR [rsp+0x60],0xe
   4c08a:	00 00 
   4c08c:	48 8b 0d 1d e4 01 00 	mov    rcx,QWORD PTR [rip+0x1e41d]        # 6a4b0 <collection_interval>
   4c093:	48 85 c9             	test   rcx,rcx
   4c096:	74 32                	je     4c0ca <f.66+0x2a8a>
   4c098:	48 8b 05 19 e4 01 00 	mov    rax,QWORD PTR [rip+0x1e419]        # 6a4b8 <allocations>
   4c09f:	48 ff c0             	inc    rax
   4c0a2:	48 89 05 0f e4 01 00 	mov    QWORD PTR [rip+0x1e40f],rax        # 6a4b8 <allocations>
   4c0a9:	48 89 c2             	mov    rdx,rax
   4c0ac:	48 09 ca             	or     rdx,rcx
   4c0af:	48 c1 ea 20          	shr    rdx,0x20
   4c0b3:	74 07                	je     4c0bc <f.66+0x2a7c>
   4c0b5:	31 d2                	xor    edx,edx
   4c0b7:	48 f7 f1             	div    rcx
   4c0ba:	eb 04                	jmp    4c0c0 <f.66+0x2a80>
   4c0bc:	31 d2                	xor    edx,edx
   4c0be:	f7 f1                	div    ecx
   4c0c0:	48 85 d2             	test   rdx,rdx
   4c0c3:	75 05                	jne    4c0ca <f.66+0x2a8a>
   4c0c5:	e8 56 5f 01 00       	call   62020 <native_gc_collect>
   4c0ca:	48 8b 05 2f df 01 00 	mov    rax,QWORD PTR [rip+0x1df2f]        # 6a000 <heap_bytes>
   4c0d1:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4c0d5:	48 83 f8 18          	cmp    rax,0x18
   4c0d9:	0f 82 f6 1b 00 00    	jb     4dcd5 <f.66+0x4695>
   4c0df:	48 8b 05 da e3 01 00 	mov    rax,QWORD PTR [rip+0x1e3da]        # 6a4c0 <since_collection>
   4c0e6:	48 3b 05 1b df 01 00 	cmp    rax,QWORD PTR [rip+0x1df1b]        # 6a008 <budget>
   4c0ed:	72 05                	jb     4c0f4 <f.66+0x2ab4>
   4c0ef:	e8 2c 5f 01 00       	call   62020 <native_gc_collect>
   4c0f4:	48 8b 05 45 e4 01 00 	mov    rax,QWORD PTR [rip+0x1e445]        # 6a540 <cursor>
   4c0fb:	48 85 c0             	test   rax,rax
   4c0fe:	74 10                	je     4c110 <f.66+0x2ad0>
   4c100:	48 8b 0d 41 e4 01 00 	mov    rcx,QWORD PTR [rip+0x1e441]        # 6a548 <limit>
   4c107:	48 29 c1             	sub    rcx,rax
   4c10a:	48 83 f9 1f          	cmp    rcx,0x1f
   4c10e:	77 44                	ja     4c154 <f.66+0x2b14>
   4c110:	bf 20 00 00 00       	mov    edi,0x20
   4c115:	e8 06 7c 01 00       	call   63d20 <allocate_slow>
   4c11a:	48 85 c0             	test   rax,rax
   4c11d:	75 40                	jne    4c15f <f.66+0x2b1f>
   4c11f:	e8 fc 5e 01 00       	call   62020 <native_gc_collect>
   4c124:	48 8b 05 15 e4 01 00 	mov    rax,QWORD PTR [rip+0x1e415]        # 6a540 <cursor>
   4c12b:	48 85 c0             	test   rax,rax
   4c12e:	74 10                	je     4c140 <f.66+0x2b00>
   4c130:	48 8b 0d 11 e4 01 00 	mov    rcx,QWORD PTR [rip+0x1e411]        # 6a548 <limit>
   4c137:	48 29 c1             	sub    rcx,rax
   4c13a:	48 83 f9 1f          	cmp    rcx,0x1f
   4c13e:	77 14                	ja     4c154 <f.66+0x2b14>
   4c140:	bf 20 00 00 00       	mov    edi,0x20
   4c145:	e8 d6 7b 01 00       	call   63d20 <allocate_slow>
   4c14a:	48 85 c0             	test   rax,rax
   4c14d:	75 10                	jne    4c15f <f.66+0x2b1f>
   4c14f:	e9 81 1b 00 00       	jmp    4dcd5 <f.66+0x4695>
   4c154:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4c158:	48 89 0d e1 e3 01 00 	mov    QWORD PTR [rip+0x1e3e1],rcx        # 6a540 <cursor>
   4c15f:	48 89 c2             	mov    rdx,rax
   4c162:	48 2b 15 cf e3 01 00 	sub    rdx,QWORD PTR [rip+0x1e3cf]        # 6a538 <arena>
   4c169:	89 d1                	mov    ecx,edx
   4c16b:	c1 e9 04             	shr    ecx,0x4
   4c16e:	be 01 00 00 00       	mov    esi,0x1
   4c173:	48 d3 e6             	shl    rsi,cl
   4c176:	48 89 d1             	mov    rcx,rdx
   4c179:	48 c1 e9 0f          	shr    rcx,0xf
   4c17d:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4c184:	48 03 0d 65 e3 01 00 	add    rcx,QWORD PTR [rip+0x1e365]        # 6a4f0 <blocks>
   4c18b:	c1 ea 07             	shr    edx,0x7
   4c18e:	81 e2 f8 00 00 00    	and    edx,0xf8
   4c194:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4c198:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4c19f:	48 83 05 19 e3 01 00 	add    QWORD PTR [rip+0x1e319],0x20        # 6a4c0 <since_collection>
   4c1a6:	20 
   4c1a7:	48 83 05 19 e3 01 00 	add    QWORD PTR [rip+0x1e319],0x18        # 6a4c8 <allocated_bytes>
   4c1ae:	18 
   4c1af:	48 ff 05 1a e3 01 00 	inc    QWORD PTR [rip+0x1e31a]        # 6a4d0 <allocated_objects>
   4c1b6:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4c1ba:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4c1c1:	00 
   4c1c2:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
   4c1c7:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4c1cb:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4c1cf:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4c1d6:	00 
   4c1d7:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
   4c1dc:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4c1e3:	00 
   4c1e4:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4c1e9:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4c1f0:	00 
   4c1f1:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4c1f6:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4c1fd:	00 
   4c1fe:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4c203:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4c20a:	00 
   4c20b:	48 89 ac 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rbp
   4c212:	00 
   4c213:	4c 89 bc 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r15
   4c21a:	00 
   4c21b:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4c220:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
   4c227:	00 
   4c228:	4c 89 b4 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],r14
   4c22f:	00 
   4c230:	48 c7 44 24 60 0d 00 	mov    QWORD PTR [rsp+0x60],0xd
   4c237:	00 00 
   4c239:	48 8b 0d 70 e2 01 00 	mov    rcx,QWORD PTR [rip+0x1e270]        # 6a4b0 <collection_interval>
   4c240:	48 85 c9             	test   rcx,rcx
   4c243:	74 30                	je     4c275 <f.66+0x2c35>
   4c245:	48 8b 05 6c e2 01 00 	mov    rax,QWORD PTR [rip+0x1e26c]        # 6a4b8 <allocations>
   4c24c:	48 ff c0             	inc    rax
   4c24f:	48 89 05 62 e2 01 00 	mov    QWORD PTR [rip+0x1e262],rax        # 6a4b8 <allocations>
   4c256:	48 89 c2             	mov    rdx,rax
   4c259:	48 09 ca             	or     rdx,rcx
   4c25c:	48 c1 ea 20          	shr    rdx,0x20
   4c260:	0f 84 f8 0b 00 00    	je     4ce5e <f.66+0x381e>
   4c266:	31 d2                	xor    edx,edx
   4c268:	48 f7 f1             	div    rcx
   4c26b:	48 85 d2             	test   rdx,rdx
   4c26e:	75 05                	jne    4c275 <f.66+0x2c35>
   4c270:	e8 ab 5d 01 00       	call   62020 <native_gc_collect>
   4c275:	48 8b 05 84 dd 01 00 	mov    rax,QWORD PTR [rip+0x1dd84]        # 6a000 <heap_bytes>
   4c27c:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4c280:	48 83 f8 18          	cmp    rax,0x18
   4c284:	0f 82 4b 1a 00 00    	jb     4dcd5 <f.66+0x4695>
   4c28a:	48 8b 05 2f e2 01 00 	mov    rax,QWORD PTR [rip+0x1e22f]        # 6a4c0 <since_collection>
   4c291:	48 3b 05 70 dd 01 00 	cmp    rax,QWORD PTR [rip+0x1dd70]        # 6a008 <budget>
   4c298:	72 05                	jb     4c29f <f.66+0x2c5f>
   4c29a:	e8 81 5d 01 00       	call   62020 <native_gc_collect>
   4c29f:	48 8b 05 9a e2 01 00 	mov    rax,QWORD PTR [rip+0x1e29a]        # 6a540 <cursor>
   4c2a6:	48 85 c0             	test   rax,rax
   4c2a9:	74 10                	je     4c2bb <f.66+0x2c7b>
   4c2ab:	48 8b 0d 96 e2 01 00 	mov    rcx,QWORD PTR [rip+0x1e296]        # 6a548 <limit>
   4c2b2:	48 29 c1             	sub    rcx,rax
   4c2b5:	48 83 f9 1f          	cmp    rcx,0x1f
   4c2b9:	77 44                	ja     4c2ff <f.66+0x2cbf>
   4c2bb:	bf 20 00 00 00       	mov    edi,0x20
   4c2c0:	e8 5b 7a 01 00       	call   63d20 <allocate_slow>
   4c2c5:	48 85 c0             	test   rax,rax
   4c2c8:	75 40                	jne    4c30a <f.66+0x2cca>
   4c2ca:	e8 51 5d 01 00       	call   62020 <native_gc_collect>
   4c2cf:	48 8b 05 6a e2 01 00 	mov    rax,QWORD PTR [rip+0x1e26a]        # 6a540 <cursor>
   4c2d6:	48 85 c0             	test   rax,rax
   4c2d9:	74 10                	je     4c2eb <f.66+0x2cab>
   4c2db:	48 8b 0d 66 e2 01 00 	mov    rcx,QWORD PTR [rip+0x1e266]        # 6a548 <limit>
   4c2e2:	48 29 c1             	sub    rcx,rax
   4c2e5:	48 83 f9 1f          	cmp    rcx,0x1f
   4c2e9:	77 14                	ja     4c2ff <f.66+0x2cbf>
   4c2eb:	bf 20 00 00 00       	mov    edi,0x20
   4c2f0:	e8 2b 7a 01 00       	call   63d20 <allocate_slow>
   4c2f5:	48 85 c0             	test   rax,rax
   4c2f8:	75 10                	jne    4c30a <f.66+0x2cca>
   4c2fa:	e9 d6 19 00 00       	jmp    4dcd5 <f.66+0x4695>
   4c2ff:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4c303:	48 89 0d 36 e2 01 00 	mov    QWORD PTR [rip+0x1e236],rcx        # 6a540 <cursor>
   4c30a:	48 89 c2             	mov    rdx,rax
   4c30d:	48 2b 15 24 e2 01 00 	sub    rdx,QWORD PTR [rip+0x1e224]        # 6a538 <arena>
   4c314:	89 d1                	mov    ecx,edx
   4c316:	c1 e9 04             	shr    ecx,0x4
   4c319:	be 01 00 00 00       	mov    esi,0x1
   4c31e:	48 d3 e6             	shl    rsi,cl
   4c321:	48 89 d1             	mov    rcx,rdx
   4c324:	48 c1 e9 0f          	shr    rcx,0xf
   4c328:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4c32f:	48 03 0d ba e1 01 00 	add    rcx,QWORD PTR [rip+0x1e1ba]        # 6a4f0 <blocks>
   4c336:	c1 ea 07             	shr    edx,0x7
   4c339:	81 e2 f8 00 00 00    	and    edx,0xf8
   4c33f:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4c343:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4c34a:	48 83 05 6e e1 01 00 	add    QWORD PTR [rip+0x1e16e],0x20        # 6a4c0 <since_collection>
   4c351:	20 
   4c352:	48 83 05 6e e1 01 00 	add    QWORD PTR [rip+0x1e16e],0x18        # 6a4c8 <allocated_bytes>
   4c359:	18 
   4c35a:	48 ff 05 6f e1 01 00 	inc    QWORD PTR [rip+0x1e16f]        # 6a4d0 <allocated_objects>
   4c361:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4c365:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4c36c:	00 
   4c36d:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
   4c372:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4c376:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4c37a:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4c381:	00 
   4c382:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
   4c387:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4c38e:	00 
   4c38f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4c394:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4c39b:	00 
   4c39c:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4c3a1:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4c3a8:	00 
   4c3a9:	48 89 ac 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rbp
   4c3b0:	00 
   4c3b1:	4c 89 bc 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r15
   4c3b8:	00 
   4c3b9:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4c3be:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
   4c3c5:	00 
   4c3c6:	4c 89 b4 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],r14
   4c3cd:	00 
   4c3ce:	48 c7 44 24 60 0c 00 	mov    QWORD PTR [rsp+0x60],0xc
   4c3d5:	00 00 
   4c3d7:	48 8b 0d d2 e0 01 00 	mov    rcx,QWORD PTR [rip+0x1e0d2]        # 6a4b0 <collection_interval>
   4c3de:	48 85 c9             	test   rcx,rcx
   4c3e1:	74 30                	je     4c413 <f.66+0x2dd3>
   4c3e3:	48 8b 05 ce e0 01 00 	mov    rax,QWORD PTR [rip+0x1e0ce]        # 6a4b8 <allocations>
   4c3ea:	48 ff c0             	inc    rax
   4c3ed:	48 89 05 c4 e0 01 00 	mov    QWORD PTR [rip+0x1e0c4],rax        # 6a4b8 <allocations>
   4c3f4:	48 89 c2             	mov    rdx,rax
   4c3f7:	48 09 ca             	or     rdx,rcx
   4c3fa:	48 c1 ea 20          	shr    rdx,0x20
   4c3fe:	0f 84 48 0a 00 00    	je     4ce4c <f.66+0x380c>
   4c404:	31 d2                	xor    edx,edx
   4c406:	48 f7 f1             	div    rcx
   4c409:	48 85 d2             	test   rdx,rdx
   4c40c:	75 05                	jne    4c413 <f.66+0x2dd3>
   4c40e:	e8 0d 5c 01 00       	call   62020 <native_gc_collect>
   4c413:	48 8b 05 e6 db 01 00 	mov    rax,QWORD PTR [rip+0x1dbe6]        # 6a000 <heap_bytes>
   4c41a:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4c41e:	48 83 f8 18          	cmp    rax,0x18
   4c422:	0f 82 ad 18 00 00    	jb     4dcd5 <f.66+0x4695>
   4c428:	48 8b 05 91 e0 01 00 	mov    rax,QWORD PTR [rip+0x1e091]        # 6a4c0 <since_collection>
   4c42f:	48 3b 05 d2 db 01 00 	cmp    rax,QWORD PTR [rip+0x1dbd2]        # 6a008 <budget>
   4c436:	72 05                	jb     4c43d <f.66+0x2dfd>
   4c438:	e8 e3 5b 01 00       	call   62020 <native_gc_collect>
   4c43d:	48 8b 05 fc e0 01 00 	mov    rax,QWORD PTR [rip+0x1e0fc]        # 6a540 <cursor>
   4c444:	48 85 c0             	test   rax,rax
   4c447:	74 10                	je     4c459 <f.66+0x2e19>
   4c449:	48 8b 0d f8 e0 01 00 	mov    rcx,QWORD PTR [rip+0x1e0f8]        # 6a548 <limit>
   4c450:	48 29 c1             	sub    rcx,rax
   4c453:	48 83 f9 1f          	cmp    rcx,0x1f
   4c457:	77 44                	ja     4c49d <f.66+0x2e5d>
   4c459:	bf 20 00 00 00       	mov    edi,0x20
   4c45e:	e8 bd 78 01 00       	call   63d20 <allocate_slow>
   4c463:	48 85 c0             	test   rax,rax
   4c466:	75 40                	jne    4c4a8 <f.66+0x2e68>
   4c468:	e8 b3 5b 01 00       	call   62020 <native_gc_collect>
   4c46d:	48 8b 05 cc e0 01 00 	mov    rax,QWORD PTR [rip+0x1e0cc]        # 6a540 <cursor>
   4c474:	48 85 c0             	test   rax,rax
   4c477:	74 10                	je     4c489 <f.66+0x2e49>
   4c479:	48 8b 0d c8 e0 01 00 	mov    rcx,QWORD PTR [rip+0x1e0c8]        # 6a548 <limit>
   4c480:	48 29 c1             	sub    rcx,rax
   4c483:	48 83 f9 1f          	cmp    rcx,0x1f
   4c487:	77 14                	ja     4c49d <f.66+0x2e5d>
   4c489:	bf 20 00 00 00       	mov    edi,0x20
   4c48e:	e8 8d 78 01 00       	call   63d20 <allocate_slow>
   4c493:	48 85 c0             	test   rax,rax
   4c496:	75 10                	jne    4c4a8 <f.66+0x2e68>
   4c498:	e9 38 18 00 00       	jmp    4dcd5 <f.66+0x4695>
   4c49d:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4c4a1:	48 89 0d 98 e0 01 00 	mov    QWORD PTR [rip+0x1e098],rcx        # 6a540 <cursor>
   4c4a8:	48 89 c2             	mov    rdx,rax
   4c4ab:	48 2b 15 86 e0 01 00 	sub    rdx,QWORD PTR [rip+0x1e086]        # 6a538 <arena>
   4c4b2:	89 d1                	mov    ecx,edx
   4c4b4:	c1 e9 04             	shr    ecx,0x4
   4c4b7:	be 01 00 00 00       	mov    esi,0x1
   4c4bc:	48 d3 e6             	shl    rsi,cl
   4c4bf:	48 89 d1             	mov    rcx,rdx
   4c4c2:	48 c1 e9 0f          	shr    rcx,0xf
   4c4c6:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4c4cd:	48 03 0d 1c e0 01 00 	add    rcx,QWORD PTR [rip+0x1e01c]        # 6a4f0 <blocks>
   4c4d4:	c1 ea 07             	shr    edx,0x7
   4c4d7:	81 e2 f8 00 00 00    	and    edx,0xf8
   4c4dd:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4c4e1:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4c4e8:	48 83 05 d0 df 01 00 	add    QWORD PTR [rip+0x1dfd0],0x20        # 6a4c0 <since_collection>
   4c4ef:	20 
   4c4f0:	48 83 05 d0 df 01 00 	add    QWORD PTR [rip+0x1dfd0],0x18        # 6a4c8 <allocated_bytes>
   4c4f7:	18 
   4c4f8:	48 ff 05 d1 df 01 00 	inc    QWORD PTR [rip+0x1dfd1]        # 6a4d0 <allocated_objects>
   4c4ff:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4c503:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4c50a:	00 
   4c50b:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
   4c510:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4c514:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4c518:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4c51f:	00 
   4c520:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
   4c525:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4c52c:	00 
   4c52d:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4c532:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4c539:	00 
   4c53a:	48 89 ac 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rbp
   4c541:	00 
   4c542:	4c 89 bc 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r15
   4c549:	00 
   4c54a:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4c54f:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
   4c556:	00 
   4c557:	4c 89 b4 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r14
   4c55e:	00 
   4c55f:	48 c7 44 24 60 0b 00 	mov    QWORD PTR [rsp+0x60],0xb
   4c566:	00 00 
   4c568:	48 8b 0d 41 df 01 00 	mov    rcx,QWORD PTR [rip+0x1df41]        # 6a4b0 <collection_interval>
   4c56f:	48 85 c9             	test   rcx,rcx
   4c572:	74 30                	je     4c5a4 <f.66+0x2f64>
   4c574:	48 8b 05 3d df 01 00 	mov    rax,QWORD PTR [rip+0x1df3d]        # 6a4b8 <allocations>
   4c57b:	48 ff c0             	inc    rax
   4c57e:	48 89 05 33 df 01 00 	mov    QWORD PTR [rip+0x1df33],rax        # 6a4b8 <allocations>
   4c585:	48 89 c2             	mov    rdx,rax
   4c588:	48 09 ca             	or     rdx,rcx
   4c58b:	48 c1 ea 20          	shr    rdx,0x20
   4c58f:	0f 84 a5 08 00 00    	je     4ce3a <f.66+0x37fa>
   4c595:	31 d2                	xor    edx,edx
   4c597:	48 f7 f1             	div    rcx
   4c59a:	48 85 d2             	test   rdx,rdx
   4c59d:	75 05                	jne    4c5a4 <f.66+0x2f64>
   4c59f:	e8 7c 5a 01 00       	call   62020 <native_gc_collect>
   4c5a4:	48 8b 05 55 da 01 00 	mov    rax,QWORD PTR [rip+0x1da55]        # 6a000 <heap_bytes>
   4c5ab:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4c5af:	48 83 f8 18          	cmp    rax,0x18
   4c5b3:	0f 82 1c 17 00 00    	jb     4dcd5 <f.66+0x4695>
   4c5b9:	48 8b 05 00 df 01 00 	mov    rax,QWORD PTR [rip+0x1df00]        # 6a4c0 <since_collection>
   4c5c0:	48 3b 05 41 da 01 00 	cmp    rax,QWORD PTR [rip+0x1da41]        # 6a008 <budget>
   4c5c7:	72 05                	jb     4c5ce <f.66+0x2f8e>
   4c5c9:	e8 52 5a 01 00       	call   62020 <native_gc_collect>
   4c5ce:	48 8b 05 6b df 01 00 	mov    rax,QWORD PTR [rip+0x1df6b]        # 6a540 <cursor>
   4c5d5:	48 85 c0             	test   rax,rax
   4c5d8:	74 10                	je     4c5ea <f.66+0x2faa>
   4c5da:	48 8b 0d 67 df 01 00 	mov    rcx,QWORD PTR [rip+0x1df67]        # 6a548 <limit>
   4c5e1:	48 29 c1             	sub    rcx,rax
   4c5e4:	48 83 f9 1f          	cmp    rcx,0x1f
   4c5e8:	77 44                	ja     4c62e <f.66+0x2fee>
   4c5ea:	bf 20 00 00 00       	mov    edi,0x20
   4c5ef:	e8 2c 77 01 00       	call   63d20 <allocate_slow>
   4c5f4:	48 85 c0             	test   rax,rax
   4c5f7:	75 40                	jne    4c639 <f.66+0x2ff9>
   4c5f9:	e8 22 5a 01 00       	call   62020 <native_gc_collect>
   4c5fe:	48 8b 05 3b df 01 00 	mov    rax,QWORD PTR [rip+0x1df3b]        # 6a540 <cursor>
   4c605:	48 85 c0             	test   rax,rax
   4c608:	74 10                	je     4c61a <f.66+0x2fda>
   4c60a:	48 8b 0d 37 df 01 00 	mov    rcx,QWORD PTR [rip+0x1df37]        # 6a548 <limit>
   4c611:	48 29 c1             	sub    rcx,rax
   4c614:	48 83 f9 1f          	cmp    rcx,0x1f
   4c618:	77 14                	ja     4c62e <f.66+0x2fee>
   4c61a:	bf 20 00 00 00       	mov    edi,0x20
   4c61f:	e8 fc 76 01 00       	call   63d20 <allocate_slow>
   4c624:	48 85 c0             	test   rax,rax
   4c627:	75 10                	jne    4c639 <f.66+0x2ff9>
   4c629:	e9 a7 16 00 00       	jmp    4dcd5 <f.66+0x4695>
   4c62e:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4c632:	48 89 0d 07 df 01 00 	mov    QWORD PTR [rip+0x1df07],rcx        # 6a540 <cursor>
   4c639:	48 89 c2             	mov    rdx,rax
   4c63c:	48 2b 15 f5 de 01 00 	sub    rdx,QWORD PTR [rip+0x1def5]        # 6a538 <arena>
   4c643:	89 d1                	mov    ecx,edx
   4c645:	c1 e9 04             	shr    ecx,0x4
   4c648:	be 01 00 00 00       	mov    esi,0x1
   4c64d:	48 d3 e6             	shl    rsi,cl
   4c650:	48 89 d1             	mov    rcx,rdx
   4c653:	48 c1 e9 0f          	shr    rcx,0xf
   4c657:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4c65e:	48 03 0d 8b de 01 00 	add    rcx,QWORD PTR [rip+0x1de8b]        # 6a4f0 <blocks>
   4c665:	c1 ea 07             	shr    edx,0x7
   4c668:	81 e2 f8 00 00 00    	and    edx,0xf8
   4c66e:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4c672:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4c679:	48 83 05 3f de 01 00 	add    QWORD PTR [rip+0x1de3f],0x20        # 6a4c0 <since_collection>
   4c680:	20 
   4c681:	48 83 05 3f de 01 00 	add    QWORD PTR [rip+0x1de3f],0x18        # 6a4c8 <allocated_bytes>
   4c688:	18 
   4c689:	48 ff 05 40 de 01 00 	inc    QWORD PTR [rip+0x1de40]        # 6a4d0 <allocated_objects>
   4c690:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4c694:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4c69b:	00 
   4c69c:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
   4c6a1:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4c6a5:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4c6a9:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4c6b0:	00 
   4c6b1:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
   4c6b6:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
   4c6bd:	00 
   4c6be:	48 89 ac 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rbp
   4c6c5:	00 
   4c6c6:	4c 89 bc 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r15
   4c6cd:	00 
   4c6ce:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4c6d3:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
   4c6da:	00 
   4c6db:	4c 89 b4 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r14
   4c6e2:	00 
   4c6e3:	48 c7 44 24 60 0a 00 	mov    QWORD PTR [rsp+0x60],0xa
   4c6ea:	00 00 
   4c6ec:	48 8b 0d bd dd 01 00 	mov    rcx,QWORD PTR [rip+0x1ddbd]        # 6a4b0 <collection_interval>
   4c6f3:	48 85 c9             	test   rcx,rcx
   4c6f6:	74 30                	je     4c728 <f.66+0x30e8>
   4c6f8:	48 8b 05 b9 dd 01 00 	mov    rax,QWORD PTR [rip+0x1ddb9]        # 6a4b8 <allocations>
   4c6ff:	48 ff c0             	inc    rax
   4c702:	48 89 05 af dd 01 00 	mov    QWORD PTR [rip+0x1ddaf],rax        # 6a4b8 <allocations>
   4c709:	48 89 c2             	mov    rdx,rax
   4c70c:	48 09 ca             	or     rdx,rcx
   4c70f:	48 c1 ea 20          	shr    rdx,0x20
   4c713:	0f 84 0f 07 00 00    	je     4ce28 <f.66+0x37e8>
   4c719:	31 d2                	xor    edx,edx
   4c71b:	48 f7 f1             	div    rcx
   4c71e:	48 85 d2             	test   rdx,rdx
   4c721:	75 05                	jne    4c728 <f.66+0x30e8>
   4c723:	e8 f8 58 01 00       	call   62020 <native_gc_collect>
   4c728:	48 8b 05 d1 d8 01 00 	mov    rax,QWORD PTR [rip+0x1d8d1]        # 6a000 <heap_bytes>
   4c72f:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4c733:	48 83 f8 18          	cmp    rax,0x18
   4c737:	0f 82 98 15 00 00    	jb     4dcd5 <f.66+0x4695>
   4c73d:	48 8b 05 7c dd 01 00 	mov    rax,QWORD PTR [rip+0x1dd7c]        # 6a4c0 <since_collection>
   4c744:	48 3b 05 bd d8 01 00 	cmp    rax,QWORD PTR [rip+0x1d8bd]        # 6a008 <budget>
   4c74b:	72 05                	jb     4c752 <f.66+0x3112>
   4c74d:	e8 ce 58 01 00       	call   62020 <native_gc_collect>
   4c752:	48 8b 05 e7 dd 01 00 	mov    rax,QWORD PTR [rip+0x1dde7]        # 6a540 <cursor>
   4c759:	48 85 c0             	test   rax,rax
   4c75c:	74 10                	je     4c76e <f.66+0x312e>
   4c75e:	48 8b 0d e3 dd 01 00 	mov    rcx,QWORD PTR [rip+0x1dde3]        # 6a548 <limit>
   4c765:	48 29 c1             	sub    rcx,rax
   4c768:	48 83 f9 1f          	cmp    rcx,0x1f
   4c76c:	77 44                	ja     4c7b2 <f.66+0x3172>
   4c76e:	bf 20 00 00 00       	mov    edi,0x20
   4c773:	e8 a8 75 01 00       	call   63d20 <allocate_slow>
   4c778:	48 85 c0             	test   rax,rax
   4c77b:	75 40                	jne    4c7bd <f.66+0x317d>
   4c77d:	e8 9e 58 01 00       	call   62020 <native_gc_collect>
   4c782:	48 8b 05 b7 dd 01 00 	mov    rax,QWORD PTR [rip+0x1ddb7]        # 6a540 <cursor>
   4c789:	48 85 c0             	test   rax,rax
   4c78c:	74 10                	je     4c79e <f.66+0x315e>
   4c78e:	48 8b 0d b3 dd 01 00 	mov    rcx,QWORD PTR [rip+0x1ddb3]        # 6a548 <limit>
   4c795:	48 29 c1             	sub    rcx,rax
   4c798:	48 83 f9 1f          	cmp    rcx,0x1f
   4c79c:	77 14                	ja     4c7b2 <f.66+0x3172>
   4c79e:	bf 20 00 00 00       	mov    edi,0x20
   4c7a3:	e8 78 75 01 00       	call   63d20 <allocate_slow>
   4c7a8:	48 85 c0             	test   rax,rax
   4c7ab:	75 10                	jne    4c7bd <f.66+0x317d>
   4c7ad:	e9 23 15 00 00       	jmp    4dcd5 <f.66+0x4695>
   4c7b2:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4c7b6:	48 89 0d 83 dd 01 00 	mov    QWORD PTR [rip+0x1dd83],rcx        # 6a540 <cursor>
   4c7bd:	48 89 c2             	mov    rdx,rax
   4c7c0:	48 2b 15 71 dd 01 00 	sub    rdx,QWORD PTR [rip+0x1dd71]        # 6a538 <arena>
   4c7c7:	89 d1                	mov    ecx,edx
   4c7c9:	c1 e9 04             	shr    ecx,0x4
   4c7cc:	be 01 00 00 00       	mov    esi,0x1
   4c7d1:	48 d3 e6             	shl    rsi,cl
   4c7d4:	48 89 d1             	mov    rcx,rdx
   4c7d7:	48 c1 e9 0f          	shr    rcx,0xf
   4c7db:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4c7e2:	48 03 0d 07 dd 01 00 	add    rcx,QWORD PTR [rip+0x1dd07]        # 6a4f0 <blocks>
   4c7e9:	c1 ea 07             	shr    edx,0x7
   4c7ec:	81 e2 f8 00 00 00    	and    edx,0xf8
   4c7f2:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4c7f6:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4c7fd:	48 83 05 bb dc 01 00 	add    QWORD PTR [rip+0x1dcbb],0x20        # 6a4c0 <since_collection>
   4c804:	20 
   4c805:	48 83 05 bb dc 01 00 	add    QWORD PTR [rip+0x1dcbb],0x18        # 6a4c8 <allocated_bytes>
   4c80c:	18 
   4c80d:	48 ff 05 bc dc 01 00 	inc    QWORD PTR [rip+0x1dcbc]        # 6a4d0 <allocated_objects>
   4c814:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4c818:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4c81f:	00 
   4c820:	48 8b 4c 24 20       	mov    rcx,QWORD PTR [rsp+0x20]
   4c825:	48 89 48 10          	mov    QWORD PTR [rax+0x10],rcx
   4c829:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4c82d:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4c834:	00 
   4c835:	48 89 ac 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rbp
   4c83c:	00 
   4c83d:	4c 89 bc 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r15
   4c844:	00 
   4c845:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4c84a:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
   4c851:	00 
   4c852:	4c 89 b4 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r14
   4c859:	00 
   4c85a:	48 c7 44 24 60 09 00 	mov    QWORD PTR [rsp+0x60],0x9
   4c861:	00 00 
   4c863:	48 8b 0d 46 dc 01 00 	mov    rcx,QWORD PTR [rip+0x1dc46]        # 6a4b0 <collection_interval>
   4c86a:	48 85 c9             	test   rcx,rcx
   4c86d:	74 30                	je     4c89f <f.66+0x325f>
   4c86f:	48 8b 05 42 dc 01 00 	mov    rax,QWORD PTR [rip+0x1dc42]        # 6a4b8 <allocations>
   4c876:	48 ff c0             	inc    rax
   4c879:	48 89 05 38 dc 01 00 	mov    QWORD PTR [rip+0x1dc38],rax        # 6a4b8 <allocations>
   4c880:	48 89 c2             	mov    rdx,rax
   4c883:	48 09 ca             	or     rdx,rcx
   4c886:	48 c1 ea 20          	shr    rdx,0x20
   4c88a:	0f 84 86 05 00 00    	je     4ce16 <f.66+0x37d6>
   4c890:	31 d2                	xor    edx,edx
   4c892:	48 f7 f1             	div    rcx
   4c895:	48 85 d2             	test   rdx,rdx
   4c898:	75 05                	jne    4c89f <f.66+0x325f>
   4c89a:	e8 81 57 01 00       	call   62020 <native_gc_collect>
   4c89f:	48 8b 05 5a d7 01 00 	mov    rax,QWORD PTR [rip+0x1d75a]        # 6a000 <heap_bytes>
   4c8a6:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4c8aa:	48 83 f8 18          	cmp    rax,0x18
   4c8ae:	0f 82 21 14 00 00    	jb     4dcd5 <f.66+0x4695>
   4c8b4:	48 8b 05 05 dc 01 00 	mov    rax,QWORD PTR [rip+0x1dc05]        # 6a4c0 <since_collection>
   4c8bb:	48 3b 05 46 d7 01 00 	cmp    rax,QWORD PTR [rip+0x1d746]        # 6a008 <budget>
   4c8c2:	72 05                	jb     4c8c9 <f.66+0x3289>
   4c8c4:	e8 57 57 01 00       	call   62020 <native_gc_collect>
   4c8c9:	48 8b 05 70 dc 01 00 	mov    rax,QWORD PTR [rip+0x1dc70]        # 6a540 <cursor>
   4c8d0:	48 85 c0             	test   rax,rax
   4c8d3:	74 10                	je     4c8e5 <f.66+0x32a5>
   4c8d5:	48 8b 0d 6c dc 01 00 	mov    rcx,QWORD PTR [rip+0x1dc6c]        # 6a548 <limit>
   4c8dc:	48 29 c1             	sub    rcx,rax
   4c8df:	48 83 f9 1f          	cmp    rcx,0x1f
   4c8e3:	77 44                	ja     4c929 <f.66+0x32e9>
   4c8e5:	bf 20 00 00 00       	mov    edi,0x20
   4c8ea:	e8 31 74 01 00       	call   63d20 <allocate_slow>
   4c8ef:	48 85 c0             	test   rax,rax
   4c8f2:	75 40                	jne    4c934 <f.66+0x32f4>
   4c8f4:	e8 27 57 01 00       	call   62020 <native_gc_collect>
   4c8f9:	48 8b 05 40 dc 01 00 	mov    rax,QWORD PTR [rip+0x1dc40]        # 6a540 <cursor>
   4c900:	48 85 c0             	test   rax,rax
   4c903:	74 10                	je     4c915 <f.66+0x32d5>
   4c905:	48 8b 0d 3c dc 01 00 	mov    rcx,QWORD PTR [rip+0x1dc3c]        # 6a548 <limit>
   4c90c:	48 29 c1             	sub    rcx,rax
   4c90f:	48 83 f9 1f          	cmp    rcx,0x1f
   4c913:	77 14                	ja     4c929 <f.66+0x32e9>
   4c915:	bf 20 00 00 00       	mov    edi,0x20
   4c91a:	e8 01 74 01 00       	call   63d20 <allocate_slow>
   4c91f:	48 85 c0             	test   rax,rax
   4c922:	75 10                	jne    4c934 <f.66+0x32f4>
   4c924:	e9 ac 13 00 00       	jmp    4dcd5 <f.66+0x4695>
   4c929:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4c92d:	48 89 0d 0c dc 01 00 	mov    QWORD PTR [rip+0x1dc0c],rcx        # 6a540 <cursor>
   4c934:	48 89 c2             	mov    rdx,rax
   4c937:	48 2b 15 fa db 01 00 	sub    rdx,QWORD PTR [rip+0x1dbfa]        # 6a538 <arena>
   4c93e:	89 d1                	mov    ecx,edx
   4c940:	c1 e9 04             	shr    ecx,0x4
   4c943:	be 01 00 00 00       	mov    esi,0x1
   4c948:	48 d3 e6             	shl    rsi,cl
   4c94b:	48 89 d1             	mov    rcx,rdx
   4c94e:	48 c1 e9 0f          	shr    rcx,0xf
   4c952:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4c959:	48 03 0d 90 db 01 00 	add    rcx,QWORD PTR [rip+0x1db90]        # 6a4f0 <blocks>
   4c960:	c1 ea 07             	shr    edx,0x7
   4c963:	81 e2 f8 00 00 00    	and    edx,0xf8
   4c969:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4c96d:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4c974:	48 83 05 44 db 01 00 	add    QWORD PTR [rip+0x1db44],0x20        # 6a4c0 <since_collection>
   4c97b:	20 
   4c97c:	48 83 05 44 db 01 00 	add    QWORD PTR [rip+0x1db44],0x18        # 6a4c8 <allocated_bytes>
   4c983:	18 
   4c984:	48 ff 05 45 db 01 00 	inc    QWORD PTR [rip+0x1db45]        # 6a4d0 <allocated_objects>
   4c98b:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4c98f:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4c996:	00 
   4c997:	48 89 68 10          	mov    QWORD PTR [rax+0x10],rbp
   4c99b:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4c99f:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4c9a6:	00 
   4c9a7:	4c 89 bc 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r15
   4c9ae:	00 
   4c9af:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
   4c9b4:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
   4c9bb:	00 
   4c9bc:	4c 89 b4 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r14
   4c9c3:	00 
   4c9c4:	48 c7 44 24 60 08 00 	mov    QWORD PTR [rsp+0x60],0x8
   4c9cb:	00 00 
   4c9cd:	48 8b 0d dc da 01 00 	mov    rcx,QWORD PTR [rip+0x1dadc]        # 6a4b0 <collection_interval>
   4c9d4:	48 85 c9             	test   rcx,rcx
   4c9d7:	74 30                	je     4ca09 <f.66+0x33c9>
   4c9d9:	48 8b 05 d8 da 01 00 	mov    rax,QWORD PTR [rip+0x1dad8]        # 6a4b8 <allocations>
   4c9e0:	48 ff c0             	inc    rax
   4c9e3:	48 89 05 ce da 01 00 	mov    QWORD PTR [rip+0x1dace],rax        # 6a4b8 <allocations>
   4c9ea:	48 89 c2             	mov    rdx,rax
   4c9ed:	48 09 ca             	or     rdx,rcx
   4c9f0:	48 c1 ea 20          	shr    rdx,0x20
   4c9f4:	0f 84 0a 04 00 00    	je     4ce04 <f.66+0x37c4>
   4c9fa:	31 d2                	xor    edx,edx
   4c9fc:	48 f7 f1             	div    rcx
   4c9ff:	48 85 d2             	test   rdx,rdx
   4ca02:	75 05                	jne    4ca09 <f.66+0x33c9>
   4ca04:	e8 17 56 01 00       	call   62020 <native_gc_collect>
   4ca09:	48 8b 05 f0 d5 01 00 	mov    rax,QWORD PTR [rip+0x1d5f0]        # 6a000 <heap_bytes>
   4ca10:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4ca14:	48 83 f8 18          	cmp    rax,0x18
   4ca18:	0f 82 b7 12 00 00    	jb     4dcd5 <f.66+0x4695>
   4ca1e:	48 8b 05 9b da 01 00 	mov    rax,QWORD PTR [rip+0x1da9b]        # 6a4c0 <since_collection>
   4ca25:	48 3b 05 dc d5 01 00 	cmp    rax,QWORD PTR [rip+0x1d5dc]        # 6a008 <budget>
   4ca2c:	72 05                	jb     4ca33 <f.66+0x33f3>
   4ca2e:	e8 ed 55 01 00       	call   62020 <native_gc_collect>
   4ca33:	48 8b 05 06 db 01 00 	mov    rax,QWORD PTR [rip+0x1db06]        # 6a540 <cursor>
   4ca3a:	48 85 c0             	test   rax,rax
   4ca3d:	74 10                	je     4ca4f <f.66+0x340f>
   4ca3f:	48 8b 0d 02 db 01 00 	mov    rcx,QWORD PTR [rip+0x1db02]        # 6a548 <limit>
   4ca46:	48 29 c1             	sub    rcx,rax
   4ca49:	48 83 f9 1f          	cmp    rcx,0x1f
   4ca4d:	77 44                	ja     4ca93 <f.66+0x3453>
   4ca4f:	bf 20 00 00 00       	mov    edi,0x20
   4ca54:	e8 c7 72 01 00       	call   63d20 <allocate_slow>
   4ca59:	48 85 c0             	test   rax,rax
   4ca5c:	75 40                	jne    4ca9e <f.66+0x345e>
   4ca5e:	e8 bd 55 01 00       	call   62020 <native_gc_collect>
   4ca63:	48 8b 05 d6 da 01 00 	mov    rax,QWORD PTR [rip+0x1dad6]        # 6a540 <cursor>
   4ca6a:	48 85 c0             	test   rax,rax
   4ca6d:	74 10                	je     4ca7f <f.66+0x343f>
   4ca6f:	48 8b 0d d2 da 01 00 	mov    rcx,QWORD PTR [rip+0x1dad2]        # 6a548 <limit>
   4ca76:	48 29 c1             	sub    rcx,rax
   4ca79:	48 83 f9 1f          	cmp    rcx,0x1f
   4ca7d:	77 14                	ja     4ca93 <f.66+0x3453>
   4ca7f:	bf 20 00 00 00       	mov    edi,0x20
   4ca84:	e8 97 72 01 00       	call   63d20 <allocate_slow>
   4ca89:	48 85 c0             	test   rax,rax
   4ca8c:	75 10                	jne    4ca9e <f.66+0x345e>
   4ca8e:	e9 42 12 00 00       	jmp    4dcd5 <f.66+0x4695>
   4ca93:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4ca97:	48 89 0d a2 da 01 00 	mov    QWORD PTR [rip+0x1daa2],rcx        # 6a540 <cursor>
   4ca9e:	48 89 c2             	mov    rdx,rax
   4caa1:	48 2b 15 90 da 01 00 	sub    rdx,QWORD PTR [rip+0x1da90]        # 6a538 <arena>
   4caa8:	89 d1                	mov    ecx,edx
   4caaa:	c1 e9 04             	shr    ecx,0x4
   4caad:	be 01 00 00 00       	mov    esi,0x1
   4cab2:	48 d3 e6             	shl    rsi,cl
   4cab5:	48 89 d1             	mov    rcx,rdx
   4cab8:	48 c1 e9 0f          	shr    rcx,0xf
   4cabc:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4cac3:	48 03 0d 26 da 01 00 	add    rcx,QWORD PTR [rip+0x1da26]        # 6a4f0 <blocks>
   4caca:	c1 ea 07             	shr    edx,0x7
   4cacd:	81 e2 f8 00 00 00    	and    edx,0xf8
   4cad3:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4cad7:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4cade:	48 83 05 da d9 01 00 	add    QWORD PTR [rip+0x1d9da],0x20        # 6a4c0 <since_collection>
   4cae5:	20 
   4cae6:	48 83 05 da d9 01 00 	add    QWORD PTR [rip+0x1d9da],0x18        # 6a4c8 <allocated_bytes>
   4caed:	18 
   4caee:	48 ff 05 db d9 01 00 	inc    QWORD PTR [rip+0x1d9db]        # 6a4d0 <allocated_objects>
   4caf5:	4c 8d 60 08          	lea    r12,[rax+0x8]
   4caf9:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4cb00:	00 
   4cb01:	4c 89 78 10          	mov    QWORD PTR [rax+0x10],r15
   4cb05:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4cb09:	4c 8b 7c 24 10       	mov    r15,QWORD PTR [rsp+0x10]
   4cb0e:	4c 89 a4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r12
   4cb15:	00 
   4cb16:	4c 89 bc 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r15
   4cb1d:	00 
   4cb1e:	4c 89 b4 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r14
   4cb25:	00 
   4cb26:	48 c7 44 24 60 07 00 	mov    QWORD PTR [rsp+0x60],0x7
   4cb2d:	00 00 
   4cb2f:	48 8b 0d 7a d9 01 00 	mov    rcx,QWORD PTR [rip+0x1d97a]        # 6a4b0 <collection_interval>
   4cb36:	48 85 c9             	test   rcx,rcx
   4cb39:	74 30                	je     4cb6b <f.66+0x352b>
   4cb3b:	48 8b 05 76 d9 01 00 	mov    rax,QWORD PTR [rip+0x1d976]        # 6a4b8 <allocations>
   4cb42:	48 ff c0             	inc    rax
   4cb45:	48 89 05 6c d9 01 00 	mov    QWORD PTR [rip+0x1d96c],rax        # 6a4b8 <allocations>
   4cb4c:	48 89 c2             	mov    rdx,rax
   4cb4f:	48 09 ca             	or     rdx,rcx
   4cb52:	48 c1 ea 20          	shr    rdx,0x20
   4cb56:	0f 84 96 02 00 00    	je     4cdf2 <f.66+0x37b2>
   4cb5c:	31 d2                	xor    edx,edx
   4cb5e:	48 f7 f1             	div    rcx
   4cb61:	48 85 d2             	test   rdx,rdx
   4cb64:	75 05                	jne    4cb6b <f.66+0x352b>
   4cb66:	e8 b5 54 01 00       	call   62020 <native_gc_collect>
   4cb6b:	48 8b 05 8e d4 01 00 	mov    rax,QWORD PTR [rip+0x1d48e]        # 6a000 <heap_bytes>
   4cb72:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4cb76:	48 83 f8 18          	cmp    rax,0x18
   4cb7a:	0f 82 55 11 00 00    	jb     4dcd5 <f.66+0x4695>
   4cb80:	48 8b 05 39 d9 01 00 	mov    rax,QWORD PTR [rip+0x1d939]        # 6a4c0 <since_collection>
   4cb87:	48 3b 05 7a d4 01 00 	cmp    rax,QWORD PTR [rip+0x1d47a]        # 6a008 <budget>
   4cb8e:	72 05                	jb     4cb95 <f.66+0x3555>
   4cb90:	e8 8b 54 01 00       	call   62020 <native_gc_collect>
   4cb95:	48 8b 05 a4 d9 01 00 	mov    rax,QWORD PTR [rip+0x1d9a4]        # 6a540 <cursor>
   4cb9c:	48 85 c0             	test   rax,rax
   4cb9f:	74 10                	je     4cbb1 <f.66+0x3571>
   4cba1:	48 8b 0d a0 d9 01 00 	mov    rcx,QWORD PTR [rip+0x1d9a0]        # 6a548 <limit>
   4cba8:	48 29 c1             	sub    rcx,rax
   4cbab:	48 83 f9 1f          	cmp    rcx,0x1f
   4cbaf:	77 44                	ja     4cbf5 <f.66+0x35b5>
   4cbb1:	bf 20 00 00 00       	mov    edi,0x20
   4cbb6:	e8 65 71 01 00       	call   63d20 <allocate_slow>
   4cbbb:	48 85 c0             	test   rax,rax
   4cbbe:	75 40                	jne    4cc00 <f.66+0x35c0>
   4cbc0:	e8 5b 54 01 00       	call   62020 <native_gc_collect>
   4cbc5:	48 8b 05 74 d9 01 00 	mov    rax,QWORD PTR [rip+0x1d974]        # 6a540 <cursor>
   4cbcc:	48 85 c0             	test   rax,rax
   4cbcf:	74 10                	je     4cbe1 <f.66+0x35a1>
   4cbd1:	48 8b 0d 70 d9 01 00 	mov    rcx,QWORD PTR [rip+0x1d970]        # 6a548 <limit>
   4cbd8:	48 29 c1             	sub    rcx,rax
   4cbdb:	48 83 f9 1f          	cmp    rcx,0x1f
   4cbdf:	77 14                	ja     4cbf5 <f.66+0x35b5>
   4cbe1:	bf 20 00 00 00       	mov    edi,0x20
   4cbe6:	e8 35 71 01 00       	call   63d20 <allocate_slow>
   4cbeb:	48 85 c0             	test   rax,rax
   4cbee:	75 10                	jne    4cc00 <f.66+0x35c0>
   4cbf0:	e9 e0 10 00 00       	jmp    4dcd5 <f.66+0x4695>
   4cbf5:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4cbf9:	48 89 0d 40 d9 01 00 	mov    QWORD PTR [rip+0x1d940],rcx        # 6a540 <cursor>
   4cc00:	48 89 c2             	mov    rdx,rax
   4cc03:	48 2b 15 2e d9 01 00 	sub    rdx,QWORD PTR [rip+0x1d92e]        # 6a538 <arena>
   4cc0a:	89 d1                	mov    ecx,edx
   4cc0c:	c1 e9 04             	shr    ecx,0x4
   4cc0f:	be 01 00 00 00       	mov    esi,0x1
   4cc14:	48 d3 e6             	shl    rsi,cl
   4cc17:	48 89 d1             	mov    rcx,rdx
   4cc1a:	48 c1 e9 0f          	shr    rcx,0xf
   4cc1e:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4cc25:	48 03 0d c4 d8 01 00 	add    rcx,QWORD PTR [rip+0x1d8c4]        # 6a4f0 <blocks>
   4cc2c:	c1 ea 07             	shr    edx,0x7
   4cc2f:	81 e2 f8 00 00 00    	and    edx,0xf8
   4cc35:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4cc39:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4cc40:	48 83 05 78 d8 01 00 	add    QWORD PTR [rip+0x1d878],0x20        # 6a4c0 <since_collection>
   4cc47:	20 
   4cc48:	48 83 05 78 d8 01 00 	add    QWORD PTR [rip+0x1d878],0x18        # 6a4c8 <allocated_bytes>
   4cc4f:	18 
   4cc50:	48 ff 05 79 d8 01 00 	inc    QWORD PTR [rip+0x1d879]        # 6a4d0 <allocated_objects>
   4cc57:	4c 8d 68 08          	lea    r13,[rax+0x8]
   4cc5b:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4cc62:	00 
   4cc63:	4c 89 78 10          	mov    QWORD PTR [rax+0x10],r15
   4cc67:	4c 89 60 18          	mov    QWORD PTR [rax+0x18],r12
   4cc6b:	4c 8d 7c 24 70       	lea    r15,[rsp+0x70]
   4cc70:	4c 89 ac 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r13
   4cc77:	00 
   4cc78:	4c 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r14
   4cc7f:	00 
   4cc80:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4cc87:	00 00 
   4cc89:	48 8b 0d 20 d8 01 00 	mov    rcx,QWORD PTR [rip+0x1d820]        # 6a4b0 <collection_interval>
   4cc90:	48 85 c9             	test   rcx,rcx
   4cc93:	74 30                	je     4ccc5 <f.66+0x3685>
   4cc95:	48 8b 05 1c d8 01 00 	mov    rax,QWORD PTR [rip+0x1d81c]        # 6a4b8 <allocations>
   4cc9c:	48 ff c0             	inc    rax
   4cc9f:	48 89 05 12 d8 01 00 	mov    QWORD PTR [rip+0x1d812],rax        # 6a4b8 <allocations>
   4cca6:	48 89 c2             	mov    rdx,rax
   4cca9:	48 09 ca             	or     rdx,rcx
   4ccac:	48 c1 ea 20          	shr    rdx,0x20
   4ccb0:	0f 84 2a 01 00 00    	je     4cde0 <f.66+0x37a0>
   4ccb6:	31 d2                	xor    edx,edx
   4ccb8:	48 f7 f1             	div    rcx
   4ccbb:	48 85 d2             	test   rdx,rdx
   4ccbe:	75 05                	jne    4ccc5 <f.66+0x3685>
   4ccc0:	e8 5b 53 01 00       	call   62020 <native_gc_collect>
   4ccc5:	48 8b 05 34 d3 01 00 	mov    rax,QWORD PTR [rip+0x1d334]        # 6a000 <heap_bytes>
   4cccc:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
   4ccd0:	48 83 f8 18          	cmp    rax,0x18
   4ccd4:	0f 82 fb 0f 00 00    	jb     4dcd5 <f.66+0x4695>
   4ccda:	48 8b 05 df d7 01 00 	mov    rax,QWORD PTR [rip+0x1d7df]        # 6a4c0 <since_collection>
   4cce1:	48 3b 05 20 d3 01 00 	cmp    rax,QWORD PTR [rip+0x1d320]        # 6a008 <budget>
   4cce8:	72 05                	jb     4ccef <f.66+0x36af>
   4ccea:	e8 31 53 01 00       	call   62020 <native_gc_collect>
   4ccef:	48 8b 05 4a d8 01 00 	mov    rax,QWORD PTR [rip+0x1d84a]        # 6a540 <cursor>
   4ccf6:	48 85 c0             	test   rax,rax
   4ccf9:	74 10                	je     4cd0b <f.66+0x36cb>
   4ccfb:	48 8b 0d 46 d8 01 00 	mov    rcx,QWORD PTR [rip+0x1d846]        # 6a548 <limit>
   4cd02:	48 29 c1             	sub    rcx,rax
   4cd05:	48 83 f9 1f          	cmp    rcx,0x1f
   4cd09:	77 44                	ja     4cd4f <f.66+0x370f>
   4cd0b:	bf 20 00 00 00       	mov    edi,0x20
   4cd10:	e8 0b 70 01 00       	call   63d20 <allocate_slow>
   4cd15:	48 85 c0             	test   rax,rax
   4cd18:	75 40                	jne    4cd5a <f.66+0x371a>
   4cd1a:	e8 01 53 01 00       	call   62020 <native_gc_collect>
   4cd1f:	48 8b 05 1a d8 01 00 	mov    rax,QWORD PTR [rip+0x1d81a]        # 6a540 <cursor>
   4cd26:	48 85 c0             	test   rax,rax
   4cd29:	74 10                	je     4cd3b <f.66+0x36fb>
   4cd2b:	48 8b 0d 16 d8 01 00 	mov    rcx,QWORD PTR [rip+0x1d816]        # 6a548 <limit>
   4cd32:	48 29 c1             	sub    rcx,rax
   4cd35:	48 83 f9 1f          	cmp    rcx,0x1f
   4cd39:	77 14                	ja     4cd4f <f.66+0x370f>
   4cd3b:	bf 20 00 00 00       	mov    edi,0x20
   4cd40:	e8 db 6f 01 00       	call   63d20 <allocate_slow>
   4cd45:	48 85 c0             	test   rax,rax
   4cd48:	75 10                	jne    4cd5a <f.66+0x371a>
   4cd4a:	e9 86 0f 00 00       	jmp    4dcd5 <f.66+0x4695>
   4cd4f:	48 8d 48 20          	lea    rcx,[rax+0x20]
   4cd53:	48 89 0d e6 d7 01 00 	mov    QWORD PTR [rip+0x1d7e6],rcx        # 6a540 <cursor>
   4cd5a:	48 89 c2             	mov    rdx,rax
   4cd5d:	48 2b 15 d4 d7 01 00 	sub    rdx,QWORD PTR [rip+0x1d7d4]        # 6a538 <arena>
   4cd64:	89 d1                	mov    ecx,edx
   4cd66:	c1 e9 04             	shr    ecx,0x4
   4cd69:	be 01 00 00 00       	mov    esi,0x1
   4cd6e:	48 d3 e6             	shl    rsi,cl
   4cd71:	48 89 d1             	mov    rcx,rdx
   4cd74:	48 c1 e9 0f          	shr    rcx,0xf
   4cd78:	48 69 c9 10 02 00 00 	imul   rcx,rcx,0x210
   4cd7f:	48 03 0d 6a d7 01 00 	add    rcx,QWORD PTR [rip+0x1d76a]        # 6a4f0 <blocks>
   4cd86:	c1 ea 07             	shr    edx,0x7
   4cd89:	81 e2 f8 00 00 00    	and    edx,0xf8
   4cd8f:	48 09 34 0a          	or     QWORD PTR [rdx+rcx*1],rsi
   4cd93:	48 c7 00 61 00 00 00 	mov    QWORD PTR [rax],0x61
   4cd9a:	48 83 05 1e d7 01 00 	add    QWORD PTR [rip+0x1d71e],0x20        # 6a4c0 <since_collection>
   4cda1:	20 
   4cda2:	48 83 05 1e d7 01 00 	add    QWORD PTR [rip+0x1d71e],0x18        # 6a4c8 <allocated_bytes>
   4cda9:	18 
   4cdaa:	48 ff 05 1f d7 01 00 	inc    QWORD PTR [rip+0x1d71f]        # 6a4d0 <allocated_objects>
   4cdb1:	48 8d 48 08          	lea    rcx,[rax+0x8]
   4cdb5:	48 c7 40 08 06 01 00 	mov    QWORD PTR [rax+0x8],0x106
   4cdbc:	00 
   4cdbd:	4c 89 70 10          	mov    QWORD PTR [rax+0x10],r14
   4cdc1:	4c 89 68 18          	mov    QWORD PTR [rax+0x18],r13
   4cdc5:	4c 8d 74 24 50       	lea    r14,[rsp+0x50]
   4cdca:	48 89 4c 24 68       	mov    QWORD PTR [rsp+0x68],rcx
   4cdcf:	48 83 7c 24 58 00    	cmp    QWORD PTR [rsp+0x58],0x0
   4cdd5:	0f 85 a4 c8 ff ff    	jne    4967f <f.66+0x3f>
   4cddb:	e9 b2 c8 ff ff       	jmp    49692 <f.66+0x52>
   4cde0:	31 d2                	xor    edx,edx
   4cde2:	f7 f1                	div    ecx
   4cde4:	48 85 d2             	test   rdx,rdx
   4cde7:	0f 85 d8 fe ff ff    	jne    4ccc5 <f.66+0x3685>
   4cded:	e9 ce fe ff ff       	jmp    4ccc0 <f.66+0x3680>
   4cdf2:	31 d2                	xor    edx,edx
   4cdf4:	f7 f1                	div    ecx
   4cdf6:	48 85 d2             	test   rdx,rdx
   4cdf9:	0f 85 6c fd ff ff    	jne    4cb6b <f.66+0x352b>
   4cdff:	e9 62 fd ff ff       	jmp    4cb66 <f.66+0x3526>
   4ce04:	31 d2                	xor    edx,edx
   4ce06:	f7 f1                	div    ecx
   4ce08:	48 85 d2             	test   rdx,rdx
   4ce0b:	0f 85 f8 fb ff ff    	jne    4ca09 <f.66+0x33c9>
   4ce11:	e9 ee fb ff ff       	jmp    4ca04 <f.66+0x33c4>
   4ce16:	31 d2                	xor    edx,edx
   4ce18:	f7 f1                	div    ecx
   4ce1a:	48 85 d2             	test   rdx,rdx
   4ce1d:	0f 85 7c fa ff ff    	jne    4c89f <f.66+0x325f>
   4ce23:	e9 72 fa ff ff       	jmp    4c89a <f.66+0x325a>
   4ce28:	31 d2                	xor    edx,edx
   4ce2a:	f7 f1                	div    ecx
   4ce2c:	48 85 d2             	test   rdx,rdx
   4ce2f:	0f 85 f3 f8 ff ff    	jne    4c728 <f.66+0x30e8>
   4ce35:	e9 e9 f8 ff ff       	jmp    4c723 <f.66+0x30e3>
   4ce3a:	31 d2                	xor    edx,edx
   4ce3c:	f7 f1                	div    ecx
   4ce3e:	48 85 d2             	test   rdx,rdx
   4ce41:	0f 85 5d f7 ff ff    	jne    4c5a4 <f.66+0x2f64>
   4ce47:	e9 53 f7 ff ff       	jmp    4c59f <f.66+0x2f5f>
   4ce4c:	31 d2                	xor    edx,edx
   4ce4e:	f7 f1                	div    ecx
   4ce50:	48 85 d2             	test   rdx,rdx
   4ce53:	0f 85 ba f5 ff ff    	jne    4c413 <f.66+0x2dd3>
   4ce59:	e9 b0 f5 ff ff       	jmp    4c40e <f.66+0x2dce>
   4ce5e:	31 d2                	xor    edx,edx
   4ce60:	f7 f1                	div    ecx
   4ce62:	48 85 d2             	test   rdx,rdx
   4ce65:	0f 85 0a f4 ff ff    	jne    4c275 <f.66+0x2c35>
   4ce6b:	e9 00 f4 ff ff       	jmp    4c270 <f.66+0x2c30>
   4ce70:	48 8b 05 f1 d5 01 00 	mov    rax,QWORD PTR [rip+0x1d5f1]        # 6a468 <g.86>
   4ce77:	48 85 c0             	test   rax,rax
   4ce7a:	0f 84 50 0e 00 00    	je     4dcd0 <f.66+0x4690>
   4ce80:	48 89 48 08          	mov    QWORD PTR [rax+0x8],rcx
   4ce84:	48 83 3d 9c d5 01 00 	cmp    QWORD PTR [rip+0x1d59c],0x0        # 6a428 <g.78>
   4ce8b:	00 
   4ce8c:	0f 84 3e 0e 00 00    	je     4dcd0 <f.66+0x4690>
   4ce92:	48 8b 0d c7 d5 01 00 	mov    rcx,QWORD PTR [rip+0x1d5c7]        # 6a460 <g.85>
   4ce99:	48 89 8c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rcx
   4cea0:	00 
   4cea1:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
   4cea6:	48 89 d0             	mov    rax,rdx
   4cea9:	48 09 c8             	or     rax,rcx
   4ceac:	0f 94 c0             	sete   al
   4ceaf:	48 85 d2             	test   rdx,rdx
   4ceb2:	74 52                	je     4cf06 <f.66+0x38c6>
   4ceb4:	48 85 c9             	test   rcx,rcx
   4ceb7:	74 4d                	je     4cf06 <f.66+0x38c6>
   4ceb9:	48 83 3d af d3 01 00 	cmp    QWORD PTR [rip+0x1d3af],0x0        # 6a270 <g.22>
   4cec0:	00 
   4cec1:	0f 84 09 0e 00 00    	je     4dcd0 <f.66+0x4690>
   4cec7:	48 83 3d 99 d3 01 00 	cmp    QWORD PTR [rip+0x1d399],0x0        # 6a268 <g.21>
   4cece:	00 
   4cecf:	0f 84 fb 0d 00 00    	je     4dcd0 <f.66+0x4690>
   4ced5:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4ced9:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4cedd:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4cee4:	00 
   4cee5:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4ceec:	00 
   4ceed:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4cef4:	00 00 
   4cef6:	e8 05 1d 00 00       	call   4ec00 <f.20>
   4cefb:	48 83 ec 08          	sub    rsp,0x8
   4ceff:	48 85 c0             	test   rax,rax
   4cf02:	74 34                	je     4cf38 <f.66+0x38f8>
   4cf04:	31 c0                	xor    eax,eax
   4cf06:	48 83 7c 24 58 00    	cmp    QWORD PTR [rsp+0x58],0x0
   4cf0c:	74 13                	je     4cf21 <f.66+0x38e1>
   4cf0e:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
   4cf13:	48 89 0d 56 d6 01 00 	mov    QWORD PTR [rip+0x1d656],rcx        # 6a570 <native_roots>
   4cf1a:	48 ff 0d 7f d5 01 00 	dec    QWORD PTR [rip+0x1d57f]        # 6a4a0 <root_depth>
   4cf21:	0f b6 c0             	movzx  eax,al
   4cf24:	48 81 c4 88 01 00 00 	add    rsp,0x188
   4cf2b:	5b                   	pop    rbx
   4cf2c:	41 5c                	pop    r12
   4cf2e:	41 5d                	pop    r13
   4cf30:	41 5e                	pop    r14
   4cf32:	41 5f                	pop    r15
   4cf34:	5d                   	pop    rbp
   4cf35:	c2 08 00             	ret    0x8
   4cf38:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
   4cf3d:	48 85 c0             	test   rax,rax
   4cf40:	0f 84 8a 0d 00 00    	je     4dcd0 <f.66+0x4690>
   4cf46:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4cf4a:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4cf4f:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
   4cf56:	00 
   4cf57:	48 85 c0             	test   rax,rax
   4cf5a:	0f 84 70 0d 00 00    	je     4dcd0 <f.66+0x4690>
   4cf60:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4cf64:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4cf69:	80 3d c0 d4 01 00 00 	cmp    BYTE PTR [rip+0x1d4c0],0x0        # 6a430 <g.79>
   4cf70:	0f 84 5a 0d 00 00    	je     4dcd0 <f.66+0x4690>
   4cf76:	48 83 3d aa d4 01 00 	cmp    QWORD PTR [rip+0x1d4aa],0x0        # 6a428 <g.78>
   4cf7d:	00 
   4cf7e:	0f 84 4c 0d 00 00    	je     4dcd0 <f.66+0x4690>
   4cf84:	48 89 c8             	mov    rax,rcx
   4cf87:	48 09 d0             	or     rax,rdx
   4cf8a:	0f 94 c0             	sete   al
   4cf8d:	48 85 c9             	test   rcx,rcx
   4cf90:	0f 84 70 ff ff ff    	je     4cf06 <f.66+0x38c6>
   4cf96:	48 85 d2             	test   rdx,rdx
   4cf99:	0f 84 67 ff ff ff    	je     4cf06 <f.66+0x38c6>
   4cf9f:	48 83 3d c9 d2 01 00 	cmp    QWORD PTR [rip+0x1d2c9],0x0        # 6a270 <g.22>
   4cfa6:	00 
   4cfa7:	0f 84 23 0d 00 00    	je     4dcd0 <f.66+0x4690>
   4cfad:	48 83 3d b3 d2 01 00 	cmp    QWORD PTR [rip+0x1d2b3],0x0        # 6a268 <g.21>
   4cfb4:	00 
   4cfb5:	0f 84 15 0d 00 00    	je     4dcd0 <f.66+0x4690>
   4cfbb:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4cfbf:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4cfc3:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4cfca:	00 
   4cfcb:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4cfd2:	00 
   4cfd3:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4cfda:	00 00 
   4cfdc:	e8 1f 1c 00 00       	call   4ec00 <f.20>
   4cfe1:	48 83 ec 08          	sub    rsp,0x8
   4cfe5:	48 85 c0             	test   rax,rax
   4cfe8:	0f 85 16 ff ff ff    	jne    4cf04 <f.66+0x38c4>
   4cfee:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4cff3:	48 85 c0             	test   rax,rax
   4cff6:	0f 84 d4 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4cffc:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d000:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d005:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d00a:	48 85 c0             	test   rax,rax
   4d00d:	0f 84 bd 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4d013:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d017:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d01c:	80 3d 0d d4 01 00 00 	cmp    BYTE PTR [rip+0x1d40d],0x0        # 6a430 <g.79>
   4d023:	0f 84 a7 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4d029:	48 83 3d f7 d3 01 00 	cmp    QWORD PTR [rip+0x1d3f7],0x0        # 6a428 <g.78>
   4d030:	00 
   4d031:	0f 84 99 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4d037:	48 89 c8             	mov    rax,rcx
   4d03a:	48 09 d0             	or     rax,rdx
   4d03d:	0f 94 c0             	sete   al
   4d040:	48 85 c9             	test   rcx,rcx
   4d043:	0f 84 bd fe ff ff    	je     4cf06 <f.66+0x38c6>
   4d049:	48 85 d2             	test   rdx,rdx
   4d04c:	0f 84 b4 fe ff ff    	je     4cf06 <f.66+0x38c6>
   4d052:	48 83 3d 16 d2 01 00 	cmp    QWORD PTR [rip+0x1d216],0x0        # 6a270 <g.22>
   4d059:	00 
   4d05a:	0f 84 70 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4d060:	48 83 3d 00 d2 01 00 	cmp    QWORD PTR [rip+0x1d200],0x0        # 6a268 <g.21>
   4d067:	00 
   4d068:	0f 84 62 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4d06e:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d072:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d076:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d07d:	00 
   4d07e:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d085:	00 
   4d086:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d08d:	00 00 
   4d08f:	e8 6c 1b 00 00       	call   4ec00 <f.20>
   4d094:	48 83 ec 08          	sub    rsp,0x8
   4d098:	48 85 c0             	test   rax,rax
   4d09b:	0f 85 63 fe ff ff    	jne    4cf04 <f.66+0x38c4>
   4d0a1:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d0a6:	48 85 c0             	test   rax,rax
   4d0a9:	0f 84 21 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4d0af:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d0b3:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d0b8:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d0bd:	48 85 c0             	test   rax,rax
   4d0c0:	0f 84 0a 0c 00 00    	je     4dcd0 <f.66+0x4690>
   4d0c6:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d0ca:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d0cf:	80 3d 5a d3 01 00 00 	cmp    BYTE PTR [rip+0x1d35a],0x0        # 6a430 <g.79>
   4d0d6:	0f 84 f4 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d0dc:	48 83 3d 44 d3 01 00 	cmp    QWORD PTR [rip+0x1d344],0x0        # 6a428 <g.78>
   4d0e3:	00 
   4d0e4:	0f 84 e6 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d0ea:	48 89 c8             	mov    rax,rcx
   4d0ed:	48 09 d0             	or     rax,rdx
   4d0f0:	0f 94 c0             	sete   al
   4d0f3:	48 85 c9             	test   rcx,rcx
   4d0f6:	0f 84 0a fe ff ff    	je     4cf06 <f.66+0x38c6>
   4d0fc:	48 85 d2             	test   rdx,rdx
   4d0ff:	0f 84 01 fe ff ff    	je     4cf06 <f.66+0x38c6>
   4d105:	48 83 3d 63 d1 01 00 	cmp    QWORD PTR [rip+0x1d163],0x0        # 6a270 <g.22>
   4d10c:	00 
   4d10d:	0f 84 bd 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d113:	48 83 3d 4d d1 01 00 	cmp    QWORD PTR [rip+0x1d14d],0x0        # 6a268 <g.21>
   4d11a:	00 
   4d11b:	0f 84 af 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d121:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d125:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d129:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d130:	00 
   4d131:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d138:	00 
   4d139:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d140:	00 00 
   4d142:	e8 b9 1a 00 00       	call   4ec00 <f.20>
   4d147:	48 83 ec 08          	sub    rsp,0x8
   4d14b:	48 85 c0             	test   rax,rax
   4d14e:	0f 85 b0 fd ff ff    	jne    4cf04 <f.66+0x38c4>
   4d154:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d159:	48 85 c0             	test   rax,rax
   4d15c:	0f 84 6e 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d162:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d166:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d16b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d170:	48 85 c0             	test   rax,rax
   4d173:	0f 84 57 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d179:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d17d:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d182:	80 3d a7 d2 01 00 00 	cmp    BYTE PTR [rip+0x1d2a7],0x0        # 6a430 <g.79>
   4d189:	0f 84 41 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d18f:	48 83 3d 91 d2 01 00 	cmp    QWORD PTR [rip+0x1d291],0x0        # 6a428 <g.78>
   4d196:	00 
   4d197:	0f 84 33 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d19d:	48 89 c8             	mov    rax,rcx
   4d1a0:	48 09 d0             	or     rax,rdx
   4d1a3:	0f 94 c0             	sete   al
   4d1a6:	48 85 c9             	test   rcx,rcx
   4d1a9:	0f 84 57 fd ff ff    	je     4cf06 <f.66+0x38c6>
   4d1af:	48 85 d2             	test   rdx,rdx
   4d1b2:	0f 84 4e fd ff ff    	je     4cf06 <f.66+0x38c6>
   4d1b8:	48 83 3d b0 d0 01 00 	cmp    QWORD PTR [rip+0x1d0b0],0x0        # 6a270 <g.22>
   4d1bf:	00 
   4d1c0:	0f 84 0a 0b 00 00    	je     4dcd0 <f.66+0x4690>
   4d1c6:	48 83 3d 9a d0 01 00 	cmp    QWORD PTR [rip+0x1d09a],0x0        # 6a268 <g.21>
   4d1cd:	00 
   4d1ce:	0f 84 fc 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d1d4:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d1d8:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d1dc:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d1e3:	00 
   4d1e4:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d1eb:	00 
   4d1ec:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d1f3:	00 00 
   4d1f5:	e8 06 1a 00 00       	call   4ec00 <f.20>
   4d1fa:	48 83 ec 08          	sub    rsp,0x8
   4d1fe:	48 85 c0             	test   rax,rax
   4d201:	0f 85 fd fc ff ff    	jne    4cf04 <f.66+0x38c4>
   4d207:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d20c:	48 85 c0             	test   rax,rax
   4d20f:	0f 84 bb 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d215:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d219:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d21e:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d223:	48 85 c0             	test   rax,rax
   4d226:	0f 84 a4 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d22c:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d230:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d235:	80 3d f4 d1 01 00 00 	cmp    BYTE PTR [rip+0x1d1f4],0x0        # 6a430 <g.79>
   4d23c:	0f 84 8e 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d242:	48 83 3d de d1 01 00 	cmp    QWORD PTR [rip+0x1d1de],0x0        # 6a428 <g.78>
   4d249:	00 
   4d24a:	0f 84 80 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d250:	48 89 c8             	mov    rax,rcx
   4d253:	48 09 d0             	or     rax,rdx
   4d256:	0f 94 c0             	sete   al
   4d259:	48 85 c9             	test   rcx,rcx
   4d25c:	0f 84 a4 fc ff ff    	je     4cf06 <f.66+0x38c6>
   4d262:	48 85 d2             	test   rdx,rdx
   4d265:	0f 84 9b fc ff ff    	je     4cf06 <f.66+0x38c6>
   4d26b:	48 83 3d fd cf 01 00 	cmp    QWORD PTR [rip+0x1cffd],0x0        # 6a270 <g.22>
   4d272:	00 
   4d273:	0f 84 57 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d279:	48 83 3d e7 cf 01 00 	cmp    QWORD PTR [rip+0x1cfe7],0x0        # 6a268 <g.21>
   4d280:	00 
   4d281:	0f 84 49 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d287:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d28b:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d28f:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d296:	00 
   4d297:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d29e:	00 
   4d29f:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d2a6:	00 00 
   4d2a8:	e8 53 19 00 00       	call   4ec00 <f.20>
   4d2ad:	48 83 ec 08          	sub    rsp,0x8
   4d2b1:	48 85 c0             	test   rax,rax
   4d2b4:	0f 85 4a fc ff ff    	jne    4cf04 <f.66+0x38c4>
   4d2ba:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d2bf:	48 85 c0             	test   rax,rax
   4d2c2:	0f 84 08 0a 00 00    	je     4dcd0 <f.66+0x4690>
   4d2c8:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d2cc:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d2d1:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d2d6:	48 85 c0             	test   rax,rax
   4d2d9:	0f 84 f1 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d2df:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d2e3:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d2e8:	80 3d 41 d1 01 00 00 	cmp    BYTE PTR [rip+0x1d141],0x0        # 6a430 <g.79>
   4d2ef:	0f 84 db 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d2f5:	48 83 3d 2b d1 01 00 	cmp    QWORD PTR [rip+0x1d12b],0x0        # 6a428 <g.78>
   4d2fc:	00 
   4d2fd:	0f 84 cd 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d303:	48 89 c8             	mov    rax,rcx
   4d306:	48 09 d0             	or     rax,rdx
   4d309:	0f 94 c0             	sete   al
   4d30c:	48 85 c9             	test   rcx,rcx
   4d30f:	0f 84 f1 fb ff ff    	je     4cf06 <f.66+0x38c6>
   4d315:	48 85 d2             	test   rdx,rdx
   4d318:	0f 84 e8 fb ff ff    	je     4cf06 <f.66+0x38c6>
   4d31e:	48 83 3d 4a cf 01 00 	cmp    QWORD PTR [rip+0x1cf4a],0x0        # 6a270 <g.22>
   4d325:	00 
   4d326:	0f 84 a4 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d32c:	48 83 3d 34 cf 01 00 	cmp    QWORD PTR [rip+0x1cf34],0x0        # 6a268 <g.21>
   4d333:	00 
   4d334:	0f 84 96 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d33a:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d33e:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d342:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d349:	00 
   4d34a:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d351:	00 
   4d352:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d359:	00 00 
   4d35b:	e8 a0 18 00 00       	call   4ec00 <f.20>
   4d360:	48 83 ec 08          	sub    rsp,0x8
   4d364:	48 85 c0             	test   rax,rax
   4d367:	0f 85 97 fb ff ff    	jne    4cf04 <f.66+0x38c4>
   4d36d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d372:	48 85 c0             	test   rax,rax
   4d375:	0f 84 55 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d37b:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d37f:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d384:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d389:	48 85 c0             	test   rax,rax
   4d38c:	0f 84 3e 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d392:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d396:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d39b:	80 3d 8e d0 01 00 00 	cmp    BYTE PTR [rip+0x1d08e],0x0        # 6a430 <g.79>
   4d3a2:	0f 84 28 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d3a8:	48 83 3d 78 d0 01 00 	cmp    QWORD PTR [rip+0x1d078],0x0        # 6a428 <g.78>
   4d3af:	00 
   4d3b0:	0f 84 1a 09 00 00    	je     4dcd0 <f.66+0x4690>
   4d3b6:	48 89 c8             	mov    rax,rcx
   4d3b9:	48 09 d0             	or     rax,rdx
   4d3bc:	0f 94 c0             	sete   al
   4d3bf:	48 85 c9             	test   rcx,rcx
   4d3c2:	0f 84 3e fb ff ff    	je     4cf06 <f.66+0x38c6>
   4d3c8:	48 85 d2             	test   rdx,rdx
   4d3cb:	0f 84 35 fb ff ff    	je     4cf06 <f.66+0x38c6>
   4d3d1:	48 83 3d 97 ce 01 00 	cmp    QWORD PTR [rip+0x1ce97],0x0        # 6a270 <g.22>
   4d3d8:	00 
   4d3d9:	0f 84 f1 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d3df:	48 83 3d 81 ce 01 00 	cmp    QWORD PTR [rip+0x1ce81],0x0        # 6a268 <g.21>
   4d3e6:	00 
   4d3e7:	0f 84 e3 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d3ed:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d3f1:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d3f5:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d3fc:	00 
   4d3fd:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d404:	00 
   4d405:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d40c:	00 00 
   4d40e:	e8 ed 17 00 00       	call   4ec00 <f.20>
   4d413:	48 83 ec 08          	sub    rsp,0x8
   4d417:	48 85 c0             	test   rax,rax
   4d41a:	0f 85 e4 fa ff ff    	jne    4cf04 <f.66+0x38c4>
   4d420:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d425:	48 85 c0             	test   rax,rax
   4d428:	0f 84 a2 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d42e:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d432:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d437:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d43c:	48 85 c0             	test   rax,rax
   4d43f:	0f 84 8b 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d445:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d449:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d44e:	80 3d db cf 01 00 00 	cmp    BYTE PTR [rip+0x1cfdb],0x0        # 6a430 <g.79>
   4d455:	0f 84 75 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d45b:	48 83 3d c5 cf 01 00 	cmp    QWORD PTR [rip+0x1cfc5],0x0        # 6a428 <g.78>
   4d462:	00 
   4d463:	0f 84 67 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d469:	48 89 c8             	mov    rax,rcx
   4d46c:	48 09 d0             	or     rax,rdx
   4d46f:	0f 94 c0             	sete   al
   4d472:	48 85 c9             	test   rcx,rcx
   4d475:	0f 84 8b fa ff ff    	je     4cf06 <f.66+0x38c6>
   4d47b:	48 85 d2             	test   rdx,rdx
   4d47e:	0f 84 82 fa ff ff    	je     4cf06 <f.66+0x38c6>
   4d484:	48 83 3d e4 cd 01 00 	cmp    QWORD PTR [rip+0x1cde4],0x0        # 6a270 <g.22>
   4d48b:	00 
   4d48c:	0f 84 3e 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d492:	48 83 3d ce cd 01 00 	cmp    QWORD PTR [rip+0x1cdce],0x0        # 6a268 <g.21>
   4d499:	00 
   4d49a:	0f 84 30 08 00 00    	je     4dcd0 <f.66+0x4690>
   4d4a0:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d4a4:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d4a8:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d4af:	00 
   4d4b0:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d4b7:	00 
   4d4b8:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d4bf:	00 00 
   4d4c1:	e8 3a 17 00 00       	call   4ec00 <f.20>
   4d4c6:	48 83 ec 08          	sub    rsp,0x8
   4d4ca:	48 85 c0             	test   rax,rax
   4d4cd:	0f 85 31 fa ff ff    	jne    4cf04 <f.66+0x38c4>
   4d4d3:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d4d8:	48 85 c0             	test   rax,rax
   4d4db:	0f 84 ef 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d4e1:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d4e5:	48 89 4c 24 78       	mov    QWORD PTR [rsp+0x78],rcx
   4d4ea:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d4ef:	48 85 c0             	test   rax,rax
   4d4f2:	0f 84 d8 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d4f8:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d4fc:	48 89 54 24 70       	mov    QWORD PTR [rsp+0x70],rdx
   4d501:	80 3d 28 cf 01 00 00 	cmp    BYTE PTR [rip+0x1cf28],0x0        # 6a430 <g.79>
   4d508:	0f 84 c2 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d50e:	48 83 3d 12 cf 01 00 	cmp    QWORD PTR [rip+0x1cf12],0x0        # 6a428 <g.78>
   4d515:	00 
   4d516:	0f 84 b4 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d51c:	48 89 c8             	mov    rax,rcx
   4d51f:	48 09 d0             	or     rax,rdx
   4d522:	0f 94 c0             	sete   al
   4d525:	48 85 c9             	test   rcx,rcx
   4d528:	0f 84 d8 f9 ff ff    	je     4cf06 <f.66+0x38c6>
   4d52e:	48 85 d2             	test   rdx,rdx
   4d531:	0f 84 cf f9 ff ff    	je     4cf06 <f.66+0x38c6>
   4d537:	48 83 3d 31 cd 01 00 	cmp    QWORD PTR [rip+0x1cd31],0x0        # 6a270 <g.22>
   4d53e:	00 
   4d53f:	0f 84 8b 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d545:	48 83 3d 1b cd 01 00 	cmp    QWORD PTR [rip+0x1cd1b],0x0        # 6a268 <g.21>
   4d54c:	00 
   4d54d:	0f 84 7d 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d553:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
   4d557:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
   4d55b:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d562:	00 
   4d563:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d56a:	00 
   4d56b:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d572:	00 00 
   4d574:	e8 87 16 00 00       	call   4ec00 <f.20>
   4d579:	48 83 ec 08          	sub    rsp,0x8
   4d57d:	48 85 c0             	test   rax,rax
   4d580:	0f 85 7e f9 ff ff    	jne    4cf04 <f.66+0x38c4>
   4d586:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d58b:	48 85 c0             	test   rax,rax
   4d58e:	0f 84 3c 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d594:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d598:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4d59d:	80 3d 8c ce 01 00 00 	cmp    BYTE PTR [rip+0x1ce8c],0x0        # 6a430 <g.79>
   4d5a4:	0f 84 26 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d5aa:	48 83 3d 76 ce 01 00 	cmp    QWORD PTR [rip+0x1ce76],0x0        # 6a428 <g.78>
   4d5b1:	00 
   4d5b2:	0f 84 18 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d5b8:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d5bd:	48 85 c0             	test   rax,rax
   4d5c0:	0f 84 0a 07 00 00    	je     4dcd0 <f.66+0x4690>
   4d5c6:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d5ca:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4d5cf:	48 89 d0             	mov    rax,rdx
   4d5d2:	48 09 c8             	or     rax,rcx
   4d5d5:	0f 94 c0             	sete   al
   4d5d8:	48 85 d2             	test   rdx,rdx
   4d5db:	0f 84 25 f9 ff ff    	je     4cf06 <f.66+0x38c6>
   4d5e1:	48 85 c9             	test   rcx,rcx
   4d5e4:	0f 84 1c f9 ff ff    	je     4cf06 <f.66+0x38c6>
   4d5ea:	48 83 3d 7e cc 01 00 	cmp    QWORD PTR [rip+0x1cc7e],0x0        # 6a270 <g.22>
   4d5f1:	00 
   4d5f2:	0f 84 d8 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d5f8:	48 83 3d 68 cc 01 00 	cmp    QWORD PTR [rip+0x1cc68],0x0        # 6a268 <g.21>
   4d5ff:	00 
   4d600:	0f 84 ca 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d606:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4d60a:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4d60e:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d615:	00 
   4d616:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d61d:	00 
   4d61e:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d625:	00 00 
   4d627:	e8 d4 15 00 00       	call   4ec00 <f.20>
   4d62c:	48 83 ec 08          	sub    rsp,0x8
   4d630:	48 85 c0             	test   rax,rax
   4d633:	0f 85 cb f8 ff ff    	jne    4cf04 <f.66+0x38c4>
   4d639:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d63e:	48 85 c0             	test   rax,rax
   4d641:	0f 84 89 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d647:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d64b:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4d650:	80 3d d9 cd 01 00 00 	cmp    BYTE PTR [rip+0x1cdd9],0x0        # 6a430 <g.79>
   4d657:	0f 84 73 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d65d:	48 83 3d c3 cd 01 00 	cmp    QWORD PTR [rip+0x1cdc3],0x0        # 6a428 <g.78>
   4d664:	00 
   4d665:	0f 84 65 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d66b:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d670:	48 85 c0             	test   rax,rax
   4d673:	0f 84 57 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d679:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d67d:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4d682:	48 89 d0             	mov    rax,rdx
   4d685:	48 09 c8             	or     rax,rcx
   4d688:	0f 94 c0             	sete   al
   4d68b:	48 85 d2             	test   rdx,rdx
   4d68e:	0f 84 72 f8 ff ff    	je     4cf06 <f.66+0x38c6>
   4d694:	48 85 c9             	test   rcx,rcx
   4d697:	0f 84 69 f8 ff ff    	je     4cf06 <f.66+0x38c6>
   4d69d:	48 83 3d cb cb 01 00 	cmp    QWORD PTR [rip+0x1cbcb],0x0        # 6a270 <g.22>
   4d6a4:	00 
   4d6a5:	0f 84 25 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d6ab:	48 83 3d b5 cb 01 00 	cmp    QWORD PTR [rip+0x1cbb5],0x0        # 6a268 <g.21>
   4d6b2:	00 
   4d6b3:	0f 84 17 06 00 00    	je     4dcd0 <f.66+0x4690>
   4d6b9:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4d6bd:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4d6c1:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d6c8:	00 
   4d6c9:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d6d0:	00 
   4d6d1:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d6d8:	00 00 
   4d6da:	e8 21 15 00 00       	call   4ec00 <f.20>
   4d6df:	48 83 ec 08          	sub    rsp,0x8
   4d6e3:	48 85 c0             	test   rax,rax
   4d6e6:	0f 85 18 f8 ff ff    	jne    4cf04 <f.66+0x38c4>
   4d6ec:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d6f1:	48 85 c0             	test   rax,rax
   4d6f4:	0f 84 d6 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d6fa:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d6fe:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4d703:	80 3d 26 cd 01 00 00 	cmp    BYTE PTR [rip+0x1cd26],0x0        # 6a430 <g.79>
   4d70a:	0f 84 c0 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d710:	48 83 3d 10 cd 01 00 	cmp    QWORD PTR [rip+0x1cd10],0x0        # 6a428 <g.78>
   4d717:	00 
   4d718:	0f 84 b2 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d71e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d723:	48 85 c0             	test   rax,rax
   4d726:	0f 84 a4 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d72c:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d730:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4d735:	48 89 d0             	mov    rax,rdx
   4d738:	48 09 c8             	or     rax,rcx
   4d73b:	0f 94 c0             	sete   al
   4d73e:	48 85 d2             	test   rdx,rdx
   4d741:	0f 84 bf f7 ff ff    	je     4cf06 <f.66+0x38c6>
   4d747:	48 85 c9             	test   rcx,rcx
   4d74a:	0f 84 b6 f7 ff ff    	je     4cf06 <f.66+0x38c6>
   4d750:	48 83 3d 18 cb 01 00 	cmp    QWORD PTR [rip+0x1cb18],0x0        # 6a270 <g.22>
   4d757:	00 
   4d758:	0f 84 72 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d75e:	48 83 3d 02 cb 01 00 	cmp    QWORD PTR [rip+0x1cb02],0x0        # 6a268 <g.21>
   4d765:	00 
   4d766:	0f 84 64 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d76c:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4d770:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4d774:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d77b:	00 
   4d77c:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d783:	00 
   4d784:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d78b:	00 00 
   4d78d:	e8 6e 14 00 00       	call   4ec00 <f.20>
   4d792:	48 83 ec 08          	sub    rsp,0x8
   4d796:	48 85 c0             	test   rax,rax
   4d799:	0f 85 65 f7 ff ff    	jne    4cf04 <f.66+0x38c4>
   4d79f:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d7a4:	48 85 c0             	test   rax,rax
   4d7a7:	0f 84 23 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d7ad:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d7b1:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4d7b6:	80 3d 73 cc 01 00 00 	cmp    BYTE PTR [rip+0x1cc73],0x0        # 6a430 <g.79>
   4d7bd:	0f 84 0d 05 00 00    	je     4dcd0 <f.66+0x4690>
   4d7c3:	48 83 3d 5d cc 01 00 	cmp    QWORD PTR [rip+0x1cc5d],0x0        # 6a428 <g.78>
   4d7ca:	00 
   4d7cb:	0f 84 ff 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d7d1:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d7d6:	48 85 c0             	test   rax,rax
   4d7d9:	0f 84 f1 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d7df:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d7e3:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4d7e8:	48 89 d0             	mov    rax,rdx
   4d7eb:	48 09 c8             	or     rax,rcx
   4d7ee:	0f 94 c0             	sete   al
   4d7f1:	48 85 d2             	test   rdx,rdx
   4d7f4:	0f 84 0c f7 ff ff    	je     4cf06 <f.66+0x38c6>
   4d7fa:	48 85 c9             	test   rcx,rcx
   4d7fd:	0f 84 03 f7 ff ff    	je     4cf06 <f.66+0x38c6>
   4d803:	48 83 3d 65 ca 01 00 	cmp    QWORD PTR [rip+0x1ca65],0x0        # 6a270 <g.22>
   4d80a:	00 
   4d80b:	0f 84 bf 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d811:	48 83 3d 4f ca 01 00 	cmp    QWORD PTR [rip+0x1ca4f],0x0        # 6a268 <g.21>
   4d818:	00 
   4d819:	0f 84 b1 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d81f:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4d823:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4d827:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d82e:	00 
   4d82f:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d836:	00 
   4d837:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d83e:	00 00 
   4d840:	e8 bb 13 00 00       	call   4ec00 <f.20>
   4d845:	48 83 ec 08          	sub    rsp,0x8
   4d849:	48 85 c0             	test   rax,rax
   4d84c:	0f 85 b2 f6 ff ff    	jne    4cf04 <f.66+0x38c4>
   4d852:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d857:	48 85 c0             	test   rax,rax
   4d85a:	0f 84 70 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d860:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d864:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4d869:	80 3d c0 cb 01 00 00 	cmp    BYTE PTR [rip+0x1cbc0],0x0        # 6a430 <g.79>
   4d870:	0f 84 5a 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d876:	48 83 3d aa cb 01 00 	cmp    QWORD PTR [rip+0x1cbaa],0x0        # 6a428 <g.78>
   4d87d:	00 
   4d87e:	0f 84 4c 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d884:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d889:	48 85 c0             	test   rax,rax
   4d88c:	0f 84 3e 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d892:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d896:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4d89b:	48 89 d0             	mov    rax,rdx
   4d89e:	48 09 c8             	or     rax,rcx
   4d8a1:	0f 94 c0             	sete   al
   4d8a4:	48 85 d2             	test   rdx,rdx
   4d8a7:	0f 84 59 f6 ff ff    	je     4cf06 <f.66+0x38c6>
   4d8ad:	48 85 c9             	test   rcx,rcx
   4d8b0:	0f 84 50 f6 ff ff    	je     4cf06 <f.66+0x38c6>
   4d8b6:	48 83 3d b2 c9 01 00 	cmp    QWORD PTR [rip+0x1c9b2],0x0        # 6a270 <g.22>
   4d8bd:	00 
   4d8be:	0f 84 0c 04 00 00    	je     4dcd0 <f.66+0x4690>
   4d8c4:	48 83 3d 9c c9 01 00 	cmp    QWORD PTR [rip+0x1c99c],0x0        # 6a268 <g.21>
   4d8cb:	00 
   4d8cc:	0f 84 fe 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d8d2:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4d8d6:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4d8da:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d8e1:	00 
   4d8e2:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d8e9:	00 
   4d8ea:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d8f1:	00 00 
   4d8f3:	e8 08 13 00 00       	call   4ec00 <f.20>
   4d8f8:	48 83 ec 08          	sub    rsp,0x8
   4d8fc:	48 85 c0             	test   rax,rax
   4d8ff:	0f 85 ff f5 ff ff    	jne    4cf04 <f.66+0x38c4>
   4d905:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d90a:	48 85 c0             	test   rax,rax
   4d90d:	0f 84 bd 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d913:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d917:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4d91c:	80 3d 0d cb 01 00 00 	cmp    BYTE PTR [rip+0x1cb0d],0x0        # 6a430 <g.79>
   4d923:	0f 84 a7 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d929:	48 83 3d f7 ca 01 00 	cmp    QWORD PTR [rip+0x1caf7],0x0        # 6a428 <g.78>
   4d930:	00 
   4d931:	0f 84 99 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d937:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d93c:	48 85 c0             	test   rax,rax
   4d93f:	0f 84 8b 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d945:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d949:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4d94e:	48 89 d0             	mov    rax,rdx
   4d951:	48 09 c8             	or     rax,rcx
   4d954:	0f 94 c0             	sete   al
   4d957:	48 85 d2             	test   rdx,rdx
   4d95a:	0f 84 a6 f5 ff ff    	je     4cf06 <f.66+0x38c6>
   4d960:	48 85 c9             	test   rcx,rcx
   4d963:	0f 84 9d f5 ff ff    	je     4cf06 <f.66+0x38c6>
   4d969:	48 83 3d ff c8 01 00 	cmp    QWORD PTR [rip+0x1c8ff],0x0        # 6a270 <g.22>
   4d970:	00 
   4d971:	0f 84 59 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d977:	48 83 3d e9 c8 01 00 	cmp    QWORD PTR [rip+0x1c8e9],0x0        # 6a268 <g.21>
   4d97e:	00 
   4d97f:	0f 84 4b 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d985:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4d989:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4d98d:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4d994:	00 
   4d995:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4d99c:	00 
   4d99d:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4d9a4:	00 00 
   4d9a6:	e8 55 12 00 00       	call   4ec00 <f.20>
   4d9ab:	48 83 ec 08          	sub    rsp,0x8
   4d9af:	48 85 c0             	test   rax,rax
   4d9b2:	0f 85 4c f5 ff ff    	jne    4cf04 <f.66+0x38c4>
   4d9b8:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4d9bd:	48 85 c0             	test   rax,rax
   4d9c0:	0f 84 0a 03 00 00    	je     4dcd0 <f.66+0x4690>
   4d9c6:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4d9ca:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4d9cf:	80 3d 5a ca 01 00 00 	cmp    BYTE PTR [rip+0x1ca5a],0x0        # 6a430 <g.79>
   4d9d6:	0f 84 f4 02 00 00    	je     4dcd0 <f.66+0x4690>
   4d9dc:	48 83 3d 44 ca 01 00 	cmp    QWORD PTR [rip+0x1ca44],0x0        # 6a428 <g.78>
   4d9e3:	00 
   4d9e4:	0f 84 e6 02 00 00    	je     4dcd0 <f.66+0x4690>
   4d9ea:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4d9ef:	48 85 c0             	test   rax,rax
   4d9f2:	0f 84 d8 02 00 00    	je     4dcd0 <f.66+0x4690>
   4d9f8:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4d9fc:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4da01:	48 89 d0             	mov    rax,rdx
   4da04:	48 09 c8             	or     rax,rcx
   4da07:	0f 94 c0             	sete   al
   4da0a:	48 85 d2             	test   rdx,rdx
   4da0d:	0f 84 f3 f4 ff ff    	je     4cf06 <f.66+0x38c6>
   4da13:	48 85 c9             	test   rcx,rcx
   4da16:	0f 84 ea f4 ff ff    	je     4cf06 <f.66+0x38c6>
   4da1c:	48 83 3d 4c c8 01 00 	cmp    QWORD PTR [rip+0x1c84c],0x0        # 6a270 <g.22>
   4da23:	00 
   4da24:	0f 84 a6 02 00 00    	je     4dcd0 <f.66+0x4690>
   4da2a:	48 83 3d 36 c8 01 00 	cmp    QWORD PTR [rip+0x1c836],0x0        # 6a268 <g.21>
   4da31:	00 
   4da32:	0f 84 98 02 00 00    	je     4dcd0 <f.66+0x4690>
   4da38:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4da3c:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4da40:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4da47:	00 
   4da48:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4da4f:	00 
   4da50:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4da57:	00 00 
   4da59:	e8 a2 11 00 00       	call   4ec00 <f.20>
   4da5e:	48 83 ec 08          	sub    rsp,0x8
   4da62:	48 85 c0             	test   rax,rax
   4da65:	0f 85 99 f4 ff ff    	jne    4cf04 <f.66+0x38c4>
   4da6b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4da70:	48 85 c0             	test   rax,rax
   4da73:	0f 84 57 02 00 00    	je     4dcd0 <f.66+0x4690>
   4da79:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4da7d:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4da82:	80 3d a7 c9 01 00 00 	cmp    BYTE PTR [rip+0x1c9a7],0x0        # 6a430 <g.79>
   4da89:	0f 84 41 02 00 00    	je     4dcd0 <f.66+0x4690>
   4da8f:	48 83 3d 91 c9 01 00 	cmp    QWORD PTR [rip+0x1c991],0x0        # 6a428 <g.78>
   4da96:	00 
   4da97:	0f 84 33 02 00 00    	je     4dcd0 <f.66+0x4690>
   4da9d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4daa2:	48 85 c0             	test   rax,rax
   4daa5:	0f 84 25 02 00 00    	je     4dcd0 <f.66+0x4690>
   4daab:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4daaf:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4dab4:	48 89 d0             	mov    rax,rdx
   4dab7:	48 09 c8             	or     rax,rcx
   4daba:	0f 94 c0             	sete   al
   4dabd:	48 85 d2             	test   rdx,rdx
   4dac0:	0f 84 40 f4 ff ff    	je     4cf06 <f.66+0x38c6>
   4dac6:	48 85 c9             	test   rcx,rcx
   4dac9:	0f 84 37 f4 ff ff    	je     4cf06 <f.66+0x38c6>
   4dacf:	48 83 3d 99 c7 01 00 	cmp    QWORD PTR [rip+0x1c799],0x0        # 6a270 <g.22>
   4dad6:	00 
   4dad7:	0f 84 f3 01 00 00    	je     4dcd0 <f.66+0x4690>
   4dadd:	48 83 3d 83 c7 01 00 	cmp    QWORD PTR [rip+0x1c783],0x0        # 6a268 <g.21>
   4dae4:	00 
   4dae5:	0f 84 e5 01 00 00    	je     4dcd0 <f.66+0x4690>
   4daeb:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4daef:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4daf3:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4dafa:	00 
   4dafb:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4db02:	00 
   4db03:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4db0a:	00 00 
   4db0c:	e8 ef 10 00 00       	call   4ec00 <f.20>
   4db11:	48 83 ec 08          	sub    rsp,0x8
   4db15:	48 85 c0             	test   rax,rax
   4db18:	0f 85 e6 f3 ff ff    	jne    4cf04 <f.66+0x38c4>
   4db1e:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4db23:	48 85 c0             	test   rax,rax
   4db26:	0f 84 a4 01 00 00    	je     4dcd0 <f.66+0x4690>
   4db2c:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4db30:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4db35:	80 3d f4 c8 01 00 00 	cmp    BYTE PTR [rip+0x1c8f4],0x0        # 6a430 <g.79>
   4db3c:	0f 84 8e 01 00 00    	je     4dcd0 <f.66+0x4690>
   4db42:	48 83 3d de c8 01 00 	cmp    QWORD PTR [rip+0x1c8de],0x0        # 6a428 <g.78>
   4db49:	00 
   4db4a:	0f 84 80 01 00 00    	je     4dcd0 <f.66+0x4690>
   4db50:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4db55:	48 85 c0             	test   rax,rax
   4db58:	0f 84 72 01 00 00    	je     4dcd0 <f.66+0x4690>
   4db5e:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4db62:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4db67:	48 89 d0             	mov    rax,rdx
   4db6a:	48 09 c8             	or     rax,rcx
   4db6d:	0f 94 c0             	sete   al
   4db70:	48 85 d2             	test   rdx,rdx
   4db73:	0f 84 8d f3 ff ff    	je     4cf06 <f.66+0x38c6>
   4db79:	48 85 c9             	test   rcx,rcx
   4db7c:	0f 84 84 f3 ff ff    	je     4cf06 <f.66+0x38c6>
   4db82:	48 83 3d e6 c6 01 00 	cmp    QWORD PTR [rip+0x1c6e6],0x0        # 6a270 <g.22>
   4db89:	00 
   4db8a:	0f 84 40 01 00 00    	je     4dcd0 <f.66+0x4690>
   4db90:	48 83 3d d0 c6 01 00 	cmp    QWORD PTR [rip+0x1c6d0],0x0        # 6a268 <g.21>
   4db97:	00 
   4db98:	0f 84 32 01 00 00    	je     4dcd0 <f.66+0x4690>
   4db9e:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4dba2:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4dba6:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4dbad:	00 
   4dbae:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4dbb5:	00 
   4dbb6:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4dbbd:	00 00 
   4dbbf:	e8 3c 10 00 00       	call   4ec00 <f.20>
   4dbc4:	48 83 ec 08          	sub    rsp,0x8
   4dbc8:	48 85 c0             	test   rax,rax
   4dbcb:	0f 85 33 f3 ff ff    	jne    4cf04 <f.66+0x38c4>
   4dbd1:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4dbd6:	48 85 c0             	test   rax,rax
   4dbd9:	0f 84 f1 00 00 00    	je     4dcd0 <f.66+0x4690>
   4dbdf:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
   4dbe3:	48 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],rcx
   4dbe8:	80 3d 41 c8 01 00 00 	cmp    BYTE PTR [rip+0x1c841],0x0        # 6a430 <g.79>
   4dbef:	0f 84 db 00 00 00    	je     4dcd0 <f.66+0x4690>
   4dbf5:	48 83 3d 2b c8 01 00 	cmp    QWORD PTR [rip+0x1c82b],0x0        # 6a428 <g.78>
   4dbfc:	00 
   4dbfd:	0f 84 cd 00 00 00    	je     4dcd0 <f.66+0x4690>
   4dc03:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4dc08:	48 85 c0             	test   rax,rax
   4dc0b:	0f 84 bf 00 00 00    	je     4dcd0 <f.66+0x4690>
   4dc11:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   4dc15:	48 89 54 24 78       	mov    QWORD PTR [rsp+0x78],rdx
   4dc1a:	48 89 d0             	mov    rax,rdx
   4dc1d:	48 09 c8             	or     rax,rcx
   4dc20:	0f 94 c0             	sete   al
   4dc23:	48 85 d2             	test   rdx,rdx
   4dc26:	0f 84 da f2 ff ff    	je     4cf06 <f.66+0x38c6>
   4dc2c:	48 85 c9             	test   rcx,rcx
   4dc2f:	0f 84 d1 f2 ff ff    	je     4cf06 <f.66+0x38c6>
   4dc35:	48 83 3d 33 c6 01 00 	cmp    QWORD PTR [rip+0x1c633],0x0        # 6a270 <g.22>
   4dc3c:	00 
   4dc3d:	0f 84 8d 00 00 00    	je     4dcd0 <f.66+0x4690>
   4dc43:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
   4dc47:	48 8b 71 08          	mov    rsi,QWORD PTR [rcx+0x8]
   4dc4b:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4dc52:	00 
   4dc53:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4dc5a:	00 
   4dc5b:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4dc62:	00 00 
   4dc64:	e8 f7 10 00 00       	call   4ed60 <f.21>
   4dc69:	48 83 ec 08          	sub    rsp,0x8
   4dc6d:	85 c0                	test   eax,eax
   4dc6f:	0f 84 8f f2 ff ff    	je     4cf04 <f.66+0x38c4>
   4dc75:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
   4dc7a:	48 85 c0             	test   rax,rax
   4dc7d:	74 51                	je     4dcd0 <f.66+0x4690>
   4dc7f:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   4dc83:	48 89 74 24 70       	mov    QWORD PTR [rsp+0x70],rsi
   4dc88:	80 3d a1 c7 01 00 00 	cmp    BYTE PTR [rip+0x1c7a1],0x0        # 6a430 <g.79>
   4dc8f:	74 3f                	je     4dcd0 <f.66+0x4690>
   4dc91:	48 83 3d 8f c7 01 00 	cmp    QWORD PTR [rip+0x1c78f],0x0        # 6a428 <g.78>
   4dc98:	00 
   4dc99:	74 35                	je     4dcd0 <f.66+0x4690>
   4dc9b:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
   4dca0:	48 85 c0             	test   rax,rax
   4dca3:	74 2b                	je     4dcd0 <f.66+0x4690>
   4dca5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   4dca9:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
   4dcb0:	00 
   4dcb1:	48 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rsi
   4dcb8:	00 
   4dcb9:	48 c7 44 24 60 06 00 	mov    QWORD PTR [rsp+0x60],0x6
   4dcc0:	00 00 
   4dcc2:	e8 49 11 00 00       	call   4ee10 <f.68>
   4dcc7:	48 83 ec 08          	sub    rsp,0x8
   4dccb:	e9 36 f2 ff ff       	jmp    4cf06 <f.66+0x38c6>
   4dcd0:	e8 2b 3d 01 00       	call   61a00 <native_trap>
   4dcd5:	48 8d 3d 26 7b fb ff 	lea    rdi,[rip+0xfffffffffffb7b26]        # 5802 <__abi_tag+0x54ce>
   4dcdc:	e8 2f 3c 01 00       	call   61910 <native_fail>
   4dce1:	cc                   	int3
   4dce2:	cc                   	int3
   4dce3:	cc                   	int3
   4dce4:	cc                   	int3
   4dce5:	cc                   	int3
   4dce6:	cc                   	int3
   4dce7:	cc                   	int3
   4dce8:	cc                   	int3
   4dce9:	cc                   	int3
   4dcea:	cc                   	int3
   4dceb:	cc                   	int3
   4dcec:	cc                   	int3
   4dced:	cc                   	int3
   4dcee:	cc                   	int3
   4dcef:	cc                   	int3

