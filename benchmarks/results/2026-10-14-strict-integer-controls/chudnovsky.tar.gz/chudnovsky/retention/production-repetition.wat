(func $function140 (type $2) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref null $type69)) (result i64)
  (local $5 (ref null $type69))
  (local $6 (ref null $type69))
  (local $7 (ref null $type69))
  (local $8 (ref $type29))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $scratch (ref null $type69))
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (local.set $9
     (call $foreign4
      (global.get $global499)
     )
    )
    (local.set $10
     (call $foreign4
      (global.get $global500)
     )
    )
    (local.set $11
     (call $foreign4
      (global.get $global501)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global511)
     )
    )
    (local.set $4
     (if (result (ref null $type69))
      (i64.gt_s
       (local.get $9)
       (local.get $10)
      )
      (then
       (ref.null none)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global472)
        )
       )
       (struct.new $type69
        (call $function130
         (local.get $9)
        )
        (block (result (ref null $type69))
         (if
          (i32.eqz
           (global.get $ready511)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global511)
          )
         )
         (if (result (ref null $type69))
          (i64.lt_s
           (local.get $10)
           (local.tee $9
            (i64.add
             (local.get $9)
             (local.get $11)
            )
           )
          )
          (then
           (ref.null none)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global472)
            )
           )
           (struct.new $type69
            (call $function130
             (local.get $9)
            )
            (block (result (ref null $type69))
             (if
              (i32.eqz
               (global.get $ready511)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global511)
              )
             )
             (if (result (ref null $type69))
              (i64.lt_s
               (local.get $10)
               (local.tee $9
                (i64.add
                 (local.get $9)
                 (local.get $11)
                )
               )
              )
              (then
               (ref.null none)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global472)
                )
               )
               (struct.new $type69
                (call $function130
                 (local.get $9)
                )
                (block (result (ref null $type69))
                 (if
                  (i32.eqz
                   (global.get $ready511)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global511)
                  )
                 )
                 (if (result (ref null $type69))
                  (i64.lt_s
                   (local.get $10)
                   (local.tee $9
                    (i64.add
                     (local.get $9)
                     (local.get $11)
                    )
                   )
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global472)
                    )
                   )
                   (struct.new $type69
                    (call $function130
                     (local.get $9)
                    )
                    (block (result (ref null $type69))
                     (if
                      (i32.eqz
                       (global.get $ready511)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global511)
                      )
                     )
                     (if (result (ref null $type69))
                      (i64.lt_s
                       (local.get $10)
                       (local.tee $9
                        (i64.add
                         (local.get $9)
                         (local.get $11)
                        )
                       )
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global472)
                        )
                       )
                       (struct.new $type69
                        (call $function130
                         (local.get $9)
                        )
                        (block (result (ref null $type69))
                         (if
                          (i32.eqz
                           (global.get $ready511)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global511)
                          )
                         )
                         (if (result (ref null $type69))
                          (i64.lt_s
                           (local.get $10)
                           (local.tee $9
                            (i64.add
                             (local.get $9)
                             (local.get $11)
                            )
                           )
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global472)
                            )
                           )
                           (struct.new $type69
                            (call $function130
                             (local.get $9)
                            )
                            (block (result (ref null $type69))
                             (if
                              (i32.eqz
                               (global.get $ready511)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global511)
                              )
                             )
                             (if (result (ref null $type69))
                              (i64.lt_s
                               (local.get $10)
                               (local.tee $9
                                (i64.add
                                 (local.get $9)
                                 (local.get $11)
                                )
                               )
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (drop
                                (ref.as_non_null
                                 (global.get $global472)
                                )
                               )
                               (struct.new $type69
                                (call $function130
                                 (local.get $9)
                                )
                                (block (result (ref null $type69))
                                 (if
                                  (i32.eqz
                                   (global.get $ready511)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global511)
                                  )
                                 )
                                 (if (result (ref null $type69))
                                  (i64.lt_s
                                   (local.get $10)
                                   (local.tee $9
                                    (i64.add
                                     (local.get $9)
                                     (local.get $11)
                                    )
                                   )
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global472)
                                    )
                                   )
                                   (struct.new $type69
                                    (call $function130
                                     (local.get $9)
                                    )
                                    (block (result (ref null $type69))
                                     (if
                                      (i32.eqz
                                       (global.get $ready511)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global511)
                                      )
                                     )
                                     (if (result (ref null $type69))
                                      (i64.lt_s
                                       (local.get $10)
                                       (local.tee $9
                                        (i64.add
                                         (local.get $9)
                                         (local.get $11)
                                        )
                                       )
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global472)
                                        )
                                       )
                                       (struct.new $type69
                                        (call $function130
                                         (local.get $9)
                                        )
                                        (block (result (ref null $type69))
                                         (if
                                          (i32.eqz
                                           (global.get $ready511)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global511)
                                          )
                                         )
                                         (if (result (ref null $type69))
                                          (i64.lt_s
                                           (local.get $10)
                                           (local.tee $9
                                            (i64.add
                                             (local.get $9)
                                             (local.get $11)
                                            )
                                           )
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global472)
                                            )
                                           )
                                           (struct.new $type69
                                            (call $function130
                                             (local.get $9)
                                            )
                                            (block (result (ref null $type69))
                                             (if
                                              (i32.eqz
                                               (global.get $ready511)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global511)
                                              )
                                             )
                                             (call $function141
                                              (i64.add
                                               (local.get $9)
                                               (local.get $11)
                                              )
                                              (local.get $10)
                                              (local.get $11)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function140
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (struct.set $type78 0
     (global.get $global505)
     (local.get $4)
    )
    (drop
     (ref.as_non_null
      (global.get $global515)
     )
    )
    (local.set $7
     (global.get $global502)
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (ref.is_null
        (local.get $4)
       )
       (then
        (ref.is_null
         (local.get $7)
        )
       )
       (else
        (if (result i32)
         (ref.is_null
          (local.get $7)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global175)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global171)
           )
          )
          (if (result i32)
           (i64.eqz
            (call $function59
             (struct.get $type69 0
              (local.get $4)
             )
             (struct.get $type69 0
              (local.get $7)
             )
            )
           )
           (then
            (local.set $6
             (struct.get $type69 1
              (local.get $4)
             )
            )
            (local.set $5
             (struct.get $type69 1
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (global.get $ready515)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global515)
             )
            )
            (if (result i32)
             (ref.is_null
              (local.get $6)
             )
             (then
              (ref.is_null
               (local.get $5)
              )
             )
             (else
              (if (result i32)
               (ref.is_null
                (local.get $5)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global175)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global171)
                 )
                )
                (if (result i32)
                 (i64.eqz
                  (call $function59
                   (struct.get $type69 0
                    (local.get $6)
                   )
                   (struct.get $type69 0
                    (local.get $5)
                   )
                  )
                 )
                 (then
                  (local.set $6
                   (struct.get $type69 1
                    (local.get $6)
                   )
                  )
                  (local.set $5
                   (struct.get $type69 1
                    (local.get $5)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready515)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global515)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $6)
                   )
                   (then
                    (ref.is_null
                     (local.get $5)
                    )
                   )
                   (else
                    (if (result i32)
                     (ref.is_null
                      (local.get $5)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global175)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global171)
                       )
                      )
                      (if (result i32)
                       (i64.eqz
                        (call $function59
                         (struct.get $type69 0
                          (local.get $6)
                         )
                         (struct.get $type69 0
                          (local.get $5)
                         )
                        )
                       )
                       (then
                        (local.set $6
                         (struct.get $type69 1
                          (local.get $6)
                         )
                        )
                        (local.set $5
                         (struct.get $type69 1
                          (local.get $5)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready515)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global515)
                         )
                        )
                        (if (result i32)
                         (ref.is_null
                          (local.get $6)
                         )
                         (then
                          (ref.is_null
                           (local.get $5)
                          )
                         )
                         (else
                          (if (result i32)
                           (ref.is_null
                            (local.get $5)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global175)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global171)
                             )
                            )
                            (if (result i32)
                             (i64.eqz
                              (call $function59
                               (struct.get $type69 0
                                (local.get $6)
                               )
                               (struct.get $type69 0
                                (local.get $5)
                               )
                              )
                             )
                             (then
                              (local.set $6
                               (struct.get $type69 1
                                (local.get $6)
                               )
                              )
                              (local.set $5
                               (struct.get $type69 1
                                (local.get $5)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready515)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global515)
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $6)
                               )
                               (then
                                (ref.is_null
                                 (local.get $5)
                                )
                               )
                               (else
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $5)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global175)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global171)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eqz
                                    (call $function59
                                     (struct.get $type69 0
                                      (local.get $6)
                                     )
                                     (struct.get $type69 0
                                      (local.get $5)
                                     )
                                    )
                                   )
                                   (then
                                    (local.set $6
                                     (struct.get $type69 1
                                      (local.get $6)
                                     )
                                    )
                                    (local.set $5
                                     (struct.get $type69 1
                                      (local.get $5)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready515)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global515)
                                     )
                                    )
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $6)
                                     )
                                     (then
                                      (ref.is_null
                                       (local.get $5)
                                      )
                                     )
                                     (else
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $5)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global175)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global171)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eqz
                                          (call $function59
                                           (struct.get $type69 0
                                            (local.get $6)
                                           )
                                           (struct.get $type69 0
                                            (local.get $5)
                                           )
                                          )
                                         )
                                         (then
                                          (local.set $6
                                           (struct.get $type69 1
                                            (local.get $6)
                                           )
                                          )
                                          (local.set $5
                                           (struct.get $type69 1
                                            (local.get $5)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready515)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global515)
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $6)
                                           )
                                           (then
                                            (ref.is_null
                                             (local.get $5)
                                            )
                                           )
                                           (else
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $5)
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global175)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global171)
                                               )
                                              )
                                              (if (result i32)
                                               (i64.eqz
                                                (call $function59
                                                 (struct.get $type69 0
                                                  (local.get $6)
                                                 )
                                                 (struct.get $type69 0
                                                  (local.get $5)
                                                 )
                                                )
                                               )
                                               (then
                                                (local.set $6
                                                 (struct.get $type69 1
                                                  (local.get $6)
                                                 )
                                                )
                                                (local.set $5
                                                 (struct.get $type69 1
                                                  (local.get $5)
                                                 )
                                                )
                                                (if
                                                 (i32.eqz
                                                  (global.get $ready515)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global515)
                                                 )
                                                )
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $6)
                                                 )
                                                 (then
                                                  (ref.is_null
                                                   (local.get $5)
                                                  )
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $5)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global175)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global171)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (i64.eqz
                                                      (call $function59
                                                       (struct.get $type69 0
                                                        (local.get $6)
                                                       )
                                                       (struct.get $type69 0
                                                        (local.get $5)
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (local.set $6
                                                       (struct.get $type69 1
                                                        (local.get $6)
                                                       )
                                                      )
                                                      (local.set $5
                                                       (struct.get $type69 1
                                                        (local.get $5)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (global.get $ready515)
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global515)
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $6)
                                                       )
                                                       (then
                                                        (ref.is_null
                                                         (local.get $5)
                                                        )
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (ref.is_null
                                                          (local.get $5)
                                                         )
                                                         (then
                                                          (i32.const 0)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global175)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global171)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (i64.eqz
                                                            (call $function59
                                                             (struct.get $type69 0
                                                              (local.get $6)
                                                             )
                                                             (struct.get $type69 0
                                                              (local.get $5)
                                                             )
                                                            )
                                                           )
                                                           (then
                                                            (local.set $6
                                                             (struct.get $type69 1
                                                              (local.get $6)
                                                             )
                                                            )
                                                            (local.set $5
                                                             (struct.get $type69 1
                                                              (local.get $5)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (global.get $ready515)
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global515)
                                                             )
                                                            )
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $6)
                                                             )
                                                             (then
                                                              (ref.is_null
                                                               (local.get $5)
                                                              )
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (ref.is_null
                                                                (local.get $5)
                                                               )
                                                               (then
                                                                (i32.const 0)
                                                               )
                                                               (else
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global175)
                                                                 )
                                                                )
                                                                (if (result i32)
                                                                 (call $function60
                                                                  (struct.get $type69 0
                                                                   (local.get $6)
                                                                  )
                                                                  (struct.get $type69 0
                                                                   (local.get $5)
                                                                  )
                                                                 )
                                                                 (then
                                                                  (call $function142
                                                                   (struct.get $type69 1
                                                                    (local.get $6)
                                                                   )
                                                                   (block (result (ref null $type69))
                                                                    (local.set $scratch
                                                                     (struct.get $type69 1
                                                                      (local.get $5)
                                                                     )
                                                                    )
                                                                    (if
                                                                     (i32.eqz
                                                                      (global.get $ready515)
                                                                     )
                                                                     (then
                                                                      (unreachable)
                                                                     )
                                                                    )
                                                                    (drop
                                                                     (ref.as_non_null
                                                                      (global.get $global515)
                                                                     )
                                                                    )
                                                                    (local.get $scratch)
                                                                   )
                                                                  )
                                                                 )
                                                                 (else
                                                                  (i32.const 0)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                           (else
                                                            (i32.const 0)
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (else
                                                      (i32.const 0)
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (i32.const 0)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (i32.const 0)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                             (else
                              (i32.const 0)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (i32.const 0)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
