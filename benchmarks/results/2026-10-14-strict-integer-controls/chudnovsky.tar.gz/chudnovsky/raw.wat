(module
 (rec
  (type $top-scalar (struct (field i32) (field i64)))
  (type $top-reference (struct (field i32) (field eqref)))
  (type $call0 (func (param eqref i64 f64) (result f64)))
  (type $type0 (struct (field (ref $call0)) (field eqref)))
  (type $call1 (func (param eqref f64 i64) (result f64)))
  (type $type1 (struct (field (ref $call1)) (field eqref)))
  (type $call2 (func (param eqref i64 f64) (result i32)))
  (type $type2 (struct (field (ref $call2)) (field eqref)))
  (type $call3 (func (param eqref f64 i64) (result i32)))
  (type $type3 (struct (field (ref $call3)) (field eqref)))
  (type $call4 (func (param eqref) (result i32)))
  (type $type4 (struct (field (ref $call4)) (field eqref)))
  (type $call5 (func (param eqref) (result i64)))
  (type $type5 (struct (field (ref $call5)) (field eqref)))
  (type $call6 (func (param eqref) (result f32)))
  (type $type6 (struct (field (ref $call6)) (field eqref)))
  (type $call7 (func (param eqref) (result f64)))
  (type $type7 (struct (field (ref $call7)) (field eqref)))
  (type $call8 (func (param eqref) (result i32)))
  (type $type8 (struct (field (ref $call8)) (field eqref)))
  (type $call9 (func (param eqref) (result i32)))
  (type $type9 (struct (field (ref $call9)) (field eqref)))
  (type $call10 (func (param eqref) (result i32)))
  (type $type10 (struct (field (ref $call10)) (field eqref)))
  (type $call11 (func (param eqref (ref null $type12)) (result i64)))
  (type $type11 (struct (field (ref $call11)) (field eqref)))
  (type $type12 (struct (field i32) (field (ref null $type12))))
  (type $call13 (func (param eqref (ref $type14)) (result (ref $type14))))
  (type $type13 (struct (field (ref $call13)) (field eqref)))
  (type $type14 (array (mut i32)))
  (type $call15 (func (param eqref i64) (result (ref $type16))))
  (type $type15 (struct (field (ref $call15)) (field eqref)))
  (type $type16 (struct (field i32) (field i32) (field (ref $type17)) (field (ref null $type18))))
  (type $type17 (array (mut i32)))
  (type $type18 (array (mut (ref null $type17))))
  (type $call19 (func (param eqref (ref null $type12)) (result (ref $type16))))
  (type $type19 (struct (field (ref $call19)) (field eqref)))
  (type $call20 (func (param eqref (ref null $type12)) (result (ref $type16))))
  (type $type20 (struct (field (ref $call20)) (field eqref)))
  (type $call21 (func (param eqref (ref $type16)) (result (ref null $type12))))
  (type $type21 (struct (field (ref $call21)) (field eqref)))
  (type $call22 (func (param eqref (ref $type16) i64 i64) (result (ref $type16))))
  (type $type22 (struct (field (ref $call22)) (field eqref)))
  (type $call23 (func (param eqref (ref $type16)) (result (ref $type16))))
  (type $type23 (struct (field (ref $call23)) (field eqref)))
  (type $call24 (func (param eqref (ref null $type25)) (result (ref $type16))))
  (type $type24 (struct (field (ref $call24)) (field eqref)))
  (type $type25 (struct (field (ref $type16)) (field (ref null $type25))))
  (type $call26 (func (param eqref (ref null $type25)) (result i64)))
  (type $type26 (struct (field (ref $call26)) (field eqref)))
  (type $call27 (func (param eqref (ref $type16) (ref null $type25) i64) (result i32)))
  (type $type27 (struct (field (ref $call27)) (field eqref)))
  (type $call28 (func (param eqref (ref $type16) (ref $type16)) (result i32)))
  (type $type28 (struct (field (ref $call28)) (field eqref)))
  (type $type29 (struct (field i32) (field (ref $type14))))
  (type $call30 (func (param eqref (ref $type14) i64) (result i64)))
  (type $type30 (struct (field (ref $call30)) (field eqref)))
  (type $call31 (func (param eqref (ref $type14) i64 i64) (result i32)))
  (type $type31 (struct (field (ref $call31)) (field eqref)))
  (type $call32 (func (param eqref i64) (result (ref $type14))))
  (type $type32 (struct (field (ref $call32)) (field eqref)))
  (type $call33 (func (param eqref (ref $type14)) (result i64)))
  (type $type33 (struct (field (ref $call33)) (field eqref)))
  (type $call34 (func (param eqref i32 (ref $type14)) (result (ref $type29))))
  (type $type34 (struct (field (ref $call34)) (field eqref)))
  (type $call35 (func (param eqref (ref $type29)) (result i32)))
  (type $type35 (struct (field (ref $call35)) (field eqref)))
  (type $call36 (func (param eqref (ref $type29)) (result (ref $type29))))
  (type $type36 (struct (field (ref $call36)) (field eqref)))
  (type $call37 (func (param eqref i64) (result i64)))
  (type $type37 (struct (field (ref $call37)) (field eqref)))
  (type $call38 (func (param eqref i64) (result (ref $type29))))
  (type $type38 (struct (field (ref $call38)) (field eqref)))
  (type $call39 (func (param eqref (ref $type29)) (result i64)))
  (type $type39 (struct (field (ref $call39)) (field eqref)))
  (type $call40 (func (param eqref (ref $type14) (ref $type14)) (result i64)))
  (type $type40 (struct (field (ref $call40)) (field eqref)))
  (type $call41 (func (param eqref (ref $type29) (ref $type29)) (result i64)))
  (type $type41 (struct (field (ref $call41)) (field eqref)))
  (type $call42 (func (param eqref (ref $type29) (ref $type29)) (result i32)))
  (type $type42 (struct (field (ref $call42)) (field eqref)))
  (type $call43 (func (param eqref (ref $type14) (ref $type14)) (result (ref $type14))))
  (type $type43 (struct (field (ref $call43)) (field eqref)))
  (type $call44 (func (param eqref i32 (ref $type14) (ref $type14)) (result (ref $type29))))
  (type $type44 (struct (field (ref $call44)) (field eqref)))
  (type $call45 (func (param eqref (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $type45 (struct (field (ref $call45)) (field eqref)))
  (type $call46 (func (param eqref (ref $type14) (ref $type14) i64 i64) (result i32)))
  (type $type46 (struct (field (ref $call46)) (field eqref)))
  (type $call47 (func (param eqref (ref $type14) i64) (result (ref $type14))))
  (type $type47 (struct (field (ref $call47)) (field eqref)))
  (type $call48 (func (param eqref (ref $type14) (ref $type14) i64) (result i64)))
  (type $type48 (struct (field (ref $call48)) (field eqref)))
  (type $call49 (func (param eqref (ref $type14) (ref $type14) i64 i64) (result i32)))
  (type $type49 (struct (field (ref $call49)) (field eqref)))
  (type $call50 (func (param eqref (ref $type14) (ref $type14) i64) (result i32)))
  (type $type50 (struct (field (ref $call50)) (field eqref)))
  (type $call51 (func (param eqref (ref $type14) (ref $type14) (ref $type14)) (result i32)))
  (type $type51 (struct (field (ref $call51)) (field eqref)))
  (type $call52 (func (param eqref (ref $type14) (ref $type14)) (result (ref $type53))))
  (type $type52 (struct (field (ref $call52)) (field eqref)))
  (type $type53 (struct (field (ref $type29)) (field (ref $type29))))
  (type $call54 (func (param eqref (ref $type29) (ref $type29)) (result (ref $type53))))
  (type $type54 (struct (field (ref $call54)) (field eqref)))
  (type $call55 (func (param eqref (ref $type16) i64 i64) (result i64)))
  (type $type55 (struct (field (ref $call55)) (field eqref)))
  (type $call56 (func (param eqref i64 i64) (result i64)))
  (type $type56 (struct (field (ref $call56)) (field eqref)))
  (type $call57 (func (param eqref (ref $type16) i64 i32) (result (ref $type29))))
  (type $type57 (struct (field (ref $call57)) (field eqref)))
  (type $call58 (func (param eqref (ref $type16)) (result (ref $type29))))
  (type $type58 (struct (field (ref $call58)) (field eqref)))
  (type $call59 (func (param eqref (ref $type14)) (result (ref null $type60))))
  (type $type59 (struct (field (ref $call59)) (field eqref)))
  (type $type60 (struct (field i64) (field (ref null $type60))))
  (type $call61 (func (param eqref (ref null $type60)) (result i64)))
  (type $type61 (struct (field (ref $call61)) (field eqref)))
  (type $call62 (func (param eqref (ref $type16) i64 i64 i64) (result i32)))
  (type $type62 (struct (field (ref $call62)) (field eqref)))
  (type $call63 (func (param eqref (ref $type16) i64 (ref null $type60) i64) (result i32)))
  (type $type63 (struct (field (ref $call63)) (field eqref)))
  (type $call64 (func (param eqref (ref $type29)) (result (ref $type16))))
  (type $type64 (struct (field (ref $call64)) (field eqref)))
  (type $call65 (func (param eqref (ref $type29) i64) (result (ref $type29))))
  (type $type65 (struct (field (ref $call65)) (field eqref)))
  (type $call66 (func (param eqref (ref $type29)) (result (ref $type67))))
  (type $type66 (struct (field (ref $call66)) (field eqref)))
  (type $type67 (struct (field (ref $type29)) (field (ref $type29))))
  (type $call68 (func (param eqref (ref null $type69)) (result (ref null $type69))))
  (type $type68 (struct (field (ref $call68)) (field eqref)))
  (type $type69 (struct (field (ref $type29)) (field (ref null $type69))))
  (type $call70 (func (param eqref (ref null $type69)) (result (ref $type29))))
  (type $type70 (struct (field (ref $call70)) (field eqref)))
  (type $call71 (func (param eqref f64) (result f64)))
  (type $type71 (struct (field (ref $call71)) (field eqref)))
  (type $call72 (func (param eqref (ref $type29) (ref $type29)) (result (ref null $type69))))
  (type $type72 (struct (field (ref $call72)) (field eqref)))
  (type $call73 (func (param eqref i64 i64 i64) (result (ref null $type69))))
  (type $type73 (struct (field (ref $call73)) (field eqref)))
  (type $call74 (func (param eqref (ref null $type69) (ref null $type69)) (result i32)))
  (type $type74 (struct (field (ref $call74)) (field eqref)))
  (type $call75 (func (param eqref (ref $type29)) (result i32)))
  (type $type75 (struct (field (ref $call75)) (field eqref)))
  (type $call76 (func (param eqref (ref $type75) (ref null $type69)) (result i32)))
  (type $type76 (struct (field (ref $call76)) (field eqref)))
  (type $call77 (func (param eqref (ref null $type69)) (result i32)))
  (type $type77 (struct (field (ref $call77)) (field eqref)))
  (type $type78 (struct (field (mut (ref null $type69)))))
  (type $environment0 (struct))
  (type $environment1 (struct))
  (type $environment2 (struct))
  (type $environment3 (struct))
  (type $environment4 (struct))
  (type $environment5 (struct))
  (type $environment6 (struct))
  (type $environment7 (struct))
  (type $environment8 (struct))
  (type $environment9 (struct))
  (type $environment10 (struct))
  (type $environment11 (struct))
  (type $environment12 (struct))
  (type $environment13 (struct))
  (type $environment14 (struct))
  (type $environment15 (struct))
  (type $environment16 (struct))
  (type $environment17 (struct))
  (type $environment18 (struct))
  (type $environment19 (struct))
  (type $environment20 (struct))
  (type $environment21 (struct))
  (type $environment22 (struct))
  (type $environment23 (struct))
  (type $environment24 (struct))
  (type $environment25 (struct))
  (type $environment26 (struct))
  (type $environment27 (struct))
  (type $environment28 (struct))
  (type $environment31 (struct))
  (type $environment33 (struct))
  (type $environment34 (struct))
  (type $environment35 (struct))
  (type $environment36 (struct))
  (type $environment38 (struct))
  (type $environment39 (struct))
  (type $environment41 (struct))
  (type $environment42 (struct))
  (type $environment43 (struct))
  (type $environment44 (struct))
  (type $environment46 (struct))
  (type $environment47 (struct))
  (type $environment48 (struct))
  (type $environment49 (struct))
  (type $environment50 (struct))
  (type $environment51 (struct))
  (type $environment53 (struct))
  (type $environment55 (struct))
  (type $environment57 (struct))
  (type $environment59 (struct))
  (type $environment60 (struct))
  (type $environment61 (struct))
  (type $environment62 (struct))
  (type $environment63 (struct))
  (type $environment64 (struct))
  (type $environment65 (struct))
  (type $environment66 (struct))
  (type $environment68 (struct))
  (type $environment70 (struct))
  (type $environment71 (struct))
  (type $environment72 (struct))
  (type $environment73 (struct))
  (type $environment75 (struct))
  (type $environment77 (struct))
  (type $environment78 (struct))
  (type $environment80 (struct))
  (type $environment82 (struct))
  (type $environment84 (struct))
  (type $environment86 (struct))
  (type $environment88 (struct))
  (type $environment89 (struct))
  (type $environment91 (struct))
  (type $environment92 (struct))
  (type $environment93 (struct))
  (type $environment94 (struct))
  (type $environment95 (struct))
  (type $environment96 (struct))
  (type $environment98 (struct))
  (type $environment100 (struct))
  (type $environment102 (struct))
  (type $environment103 (struct))
  (type $environment104 (struct))
  (type $environment106 (struct))
  (type $environment108 (struct))
  (type $environment110 (struct))
  (type $environment112 (struct))
  (type $environment113 (struct))
  (type $environment114 (struct))
  (type $environment115 (struct))
  (type $environment117 (struct))
  (type $environment118 (struct))
  (type $environment120 (struct))
  (type $environment121 (struct))
  (type $environment123 (struct))
  (type $environment124 (struct))
  (type $environment125 (struct))
  (type $environment126 (struct))
  (type $environment127 (struct))
  (type $environment128 (struct))
  (type $environment129 (struct))
  (type $environment130 (struct))
  (type $environment131 (struct))
  (type $environment133 (struct))
  (type $environment135 (struct))
  (type $environment136 (struct))
  (type $environment139 (struct))
  (type $environment141 (struct))
  (type $environment142 (struct))
  (type $environment143 (struct))
 )
 (type $257 (func (param i64) (result i64)))
 (type $258 (func (param i32 i32 i64 i64) (result i64)))
 (type $259 (func (param (ref $type16) i32 (ref $type16) i32 i32)))
 (type $260 (func (param (ref $type14) (ref $type14) i64 (ref $type14) i32 i32 i64 i64) (result (ref $type14))))
 (type $261 (func (param (ref $type14) (ref $type14) i64 i64 i64 i32 i32 i64 i64) (result i32)))
 (type $262 (func))
 (type $263 (func (param i64 i64) (result i32)))
 (type $264 (func (param i32)))
 (type $265 (func (result i64)))
 (type $266 (func (param i32) (result i64)))
 (type $267 (func (param i32 i32) (result i32)))
 (type $268 (func (param i32 i32) (result (ref $type16))))
 (type $269 (func (param (ref $type16) i32) (result (ref $type17))))
 (type $270 (func (param (ref $type16) i64 (ref $type16) i64 i64) (result i32)))
 (type $271 (func (param i32 i32 (ref null $type12) i64) (result i64)))
 (type $272 (func (param (ref $type16) i32 i32 (ref null $type12) i64) (result (ref $type16))))
 (type $273 (func (param (ref $type16) i32 i32 i64 (ref null $type12)) (result (ref null $type12))))
 (type $274 (func (param i32 i32 (ref null $type25) i64) (result i64)))
 (type $275 (func (param (ref $type16) (ref $type16) i32 i32 i64) (result i32)))
 (type $276 (func (param (ref $type14) i32 i32 i64) (result i64)))
 (type $277 (func (param i32 (ref $type14) i32 i32 i64 i64) (result (ref $type29))))
 (type $278 (func (param (ref $type14) i32 i64 i32 i32 i64 i64) (result i64)))
 (type $279 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i64)))
 (type $280 (func (param (ref $type14) (ref $type14) (ref $type14) i32 i32 i64) (result (ref $type14))))
 (type $281 (func (param (ref $type14) i64 i64 (ref $type14) i32 i32 i64 i64) (result (ref $type14))))
 (type $282 (func (param (ref $type14) (ref $type14) i64 i32 i32 i64 i64) (result i64)))
 (type $283 (func (param (ref $type14) (ref $type14) i64 i64 i64 i32 i32 i64 i64) (result i64)))
 (type $284 (func (param (ref $type14) (ref $type14) i64 i64 i32 i32 i64 i64) (result i32)))
 (type $285 (func (param (ref $type14) (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
 (type $286 (func (param (ref $type16) i64 i32 i32 i64 i64) (result i64)))
 (type $287 (func (param i64 i32 i32 i64 i64) (result i64)))
 (type $288 (func (param (ref $type16) i32 i64 i32 i32 i64 (ref $type29)) (result (ref $type29))))
 (type $289 (func (param i32 i32 (ref $type14) (ref null $type60)) (result (ref null $type60))))
 (type $290 (func (param i32 i32 (ref null $type60) i64) (result i64)))
 (type $291 (func (param (ref $type16) i32 i32 i64 i64 i64) (result i32)))
 (type $292 (func (param i32 i32 (ref $type29) (ref $type29) (ref $type29)) (result (ref $type29))))
 (type $293 (func (param (ref $type29) i32 i32 (ref $type29)) (result (ref $type29))))
 (type $294 (func (param i64 i64 (ref $type16) i32 i32 i64) (result (ref $type29))))
 (type $295 (func (param (ref $type16) i32 i32 i64) (result i32)))
 (type $296 (func (param (ref $type75) i32 i32 (ref null $type69) i32) (result i32)))
 (type $297 (func (param i32 i32 i64) (result (ref null $type69))))
 (type $298 (func (param i64 i32 i32 i64 (ref null $type69)) (result i64)))
 (import "benchmark" "expected_length" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "expected_character" (func $foreign1 (param i64 i64) (result i32)))
 (import "benchmark" "emit_character" (func $foreign2 (param i32)))
 (import "benchmark" "expected_count" (func $foreign3 (result i64)))
 (import "benchmark" "hide_i64" (func $foreign4 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign5 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global3 (mut (ref null $type1)) (ref.null none))
 (global $ready3 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type0)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global9 (mut (ref null $type1)) (ref.null none))
 (global $ready9 (mut i32) (i32.const 0))
 (global $global12 (mut (ref null $type0)) (ref.null none))
 (global $ready12 (mut i32) (i32.const 0))
 (global $global15 (mut (ref null $type1)) (ref.null none))
 (global $ready15 (mut i32) (i32.const 0))
 (global $global18 (mut (ref null $type0)) (ref.null none))
 (global $ready18 (mut i32) (i32.const 0))
 (global $global21 (mut (ref null $type1)) (ref.null none))
 (global $ready21 (mut i32) (i32.const 0))
 (global $global24 (mut (ref null $type2)) (ref.null none))
 (global $ready24 (mut i32) (i32.const 0))
 (global $global27 (mut (ref null $type3)) (ref.null none))
 (global $ready27 (mut i32) (i32.const 0))
 (global $global30 (mut (ref null $type2)) (ref.null none))
 (global $ready30 (mut i32) (i32.const 0))
 (global $global33 (mut (ref null $type3)) (ref.null none))
 (global $ready33 (mut i32) (i32.const 0))
 (global $global36 (mut (ref null $type2)) (ref.null none))
 (global $ready36 (mut i32) (i32.const 0))
 (global $global39 (mut (ref null $type3)) (ref.null none))
 (global $ready39 (mut i32) (i32.const 0))
 (global $global42 (mut (ref null $type2)) (ref.null none))
 (global $ready42 (mut i32) (i32.const 0))
 (global $global45 (mut (ref null $type3)) (ref.null none))
 (global $ready45 (mut i32) (i32.const 0))
 (global $global48 (mut (ref null $type2)) (ref.null none))
 (global $ready48 (mut i32) (i32.const 0))
 (global $global51 (mut (ref null $type3)) (ref.null none))
 (global $ready51 (mut i32) (i32.const 0))
 (global $global54 (mut (ref null $type4)) (ref.null none))
 (global $ready54 (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global56 (mut (ref null $type6)) (ref.null none))
 (global $ready56 (mut i32) (i32.const 0))
 (global $global57 (mut (ref null $type7)) (ref.null none))
 (global $ready57 (mut i32) (i32.const 0))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $ready58 (mut i32) (i32.const 0))
 (global $global59 (mut (ref null $type9)) (ref.null none))
 (global $ready59 (mut i32) (i32.const 0))
 (global $global60 (mut (ref null $type10)) (ref.null none))
 (global $ready60 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type11)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global368 (mut (ref null $type13)) (ref.null none))
 (global $ready368 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type15)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type19)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type20)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type21)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type22)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type23)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type24)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type26)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type27)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type28)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut i64) (i64.const 0))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut i64) (i64.const 0))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type29)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type30)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global115 (mut (ref null $type31)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type32)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type33)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type13)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type34)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type35)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type36)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type36)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global140 (mut (ref null $type37)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type38)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type39)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type40)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global171 (mut (ref null $type41)) (ref.null none))
 (global $ready171 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type42)) (ref.null none))
 (global $ready175 (mut i32) (i32.const 0))
 (global $global178 (mut (ref null $type42)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (global $global181 (mut (ref null $type42)) (ref.null none))
 (global $ready181 (mut i32) (i32.const 0))
 (global $global184 (mut (ref null $type42)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global187 (mut (ref null $type42)) (ref.null none))
 (global $ready187 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type30)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global193 (mut (ref null $type43)) (ref.null none))
 (global $ready193 (mut i32) (i32.const 0))
 (global $global202 (mut (ref null $type43)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global211 (mut (ref null $type44)) (ref.null none))
 (global $ready211 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type45)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global220 (mut (ref null $type45)) (ref.null none))
 (global $ready220 (mut i32) (i32.const 0))
 (global $global223 (mut (ref null $type46)) (ref.null none))
 (global $ready223 (mut i32) (i32.const 0))
 (global $global234 (mut (ref null $type43)) (ref.null none))
 (global $ready234 (mut i32) (i32.const 0))
 (global $global240 (mut (ref null $type45)) (ref.null none))
 (global $ready240 (mut i32) (i32.const 0))
 (global $global244 (mut (ref null $type47)) (ref.null none))
 (global $ready244 (mut i32) (i32.const 0))
 (global $global253 (mut (ref null $type48)) (ref.null none))
 (global $ready253 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type48)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global273 (mut (ref null $type49)) (ref.null none))
 (global $ready273 (mut i32) (i32.const 0))
 (global $global286 (mut (ref null $type50)) (ref.null none))
 (global $ready286 (mut i32) (i32.const 0))
 (global $global295 (mut (ref null $type48)) (ref.null none))
 (global $ready295 (mut i32) (i32.const 0))
 (global $global300 (mut (ref null $type51)) (ref.null none))
 (global $ready300 (mut i32) (i32.const 0))
 (global $global306 (mut (ref null $type52)) (ref.null none))
 (global $ready306 (mut i32) (i32.const 0))
 (global $global315 (mut (ref null $type54)) (ref.null none))
 (global $ready315 (mut i32) (i32.const 0))
 (global $global322 (mut (ref null $type54)) (ref.null none))
 (global $ready322 (mut i32) (i32.const 0))
 (global $global328 (mut (ref null $type45)) (ref.null none))
 (global $ready328 (mut i32) (i32.const 0))
 (global $global331 (mut (ref null $type45)) (ref.null none))
 (global $ready331 (mut i32) (i32.const 0))
 (global $global334 (mut (ref null $type55)) (ref.null none))
 (global $ready334 (mut i32) (i32.const 0))
 (global $global343 (mut (ref null $type56)) (ref.null none))
 (global $ready343 (mut i32) (i32.const 0))
 (global $global349 (mut (ref null $type57)) (ref.null none))
 (global $ready349 (mut i32) (i32.const 0))
 (global $global360 (mut (ref null $type58)) (ref.null none))
 (global $ready360 (mut i32) (i32.const 0))
 (global $global366 (mut (ref null $type59)) (ref.null none))
 (global $ready366 (mut i32) (i32.const 0))
 (global $global376 (mut (ref null $type37)) (ref.null none))
 (global $ready376 (mut i32) (i32.const 0))
 (global $global381 (mut (ref null $type61)) (ref.null none))
 (global $ready381 (mut i32) (i32.const 0))
 (global $global386 (mut (ref null $type62)) (ref.null none))
 (global $ready386 (mut i32) (i32.const 0))
 (global $global395 (mut (ref null $type63)) (ref.null none))
 (global $ready395 (mut i32) (i32.const 0))
 (global $global400 (mut (ref null $type64)) (ref.null none))
 (global $ready400 (mut i32) (i32.const 0))
 (global $global406 (mut (ref null $type36)) (ref.null none))
 (global $ready406 (mut i32) (i32.const 0))
 (global $global410 (mut (ref null $type45)) (ref.null none))
 (global $ready410 (mut i32) (i32.const 0))
 (global $global419 (mut (ref null $type65)) (ref.null none))
 (global $ready419 (mut i32) (i32.const 0))
 (global $global422 (mut (ref null $type37)) (ref.null none))
 (global $ready422 (mut i32) (i32.const 0))
 (global $global427 (mut (ref null $type36)) (ref.null none))
 (global $ready427 (mut i32) (i32.const 0))
 (global $global435 (mut (ref null $type36)) (ref.null none))
 (global $ready435 (mut i32) (i32.const 0))
 (global $global440 (mut (ref null $type66)) (ref.null none))
 (global $ready440 (mut i32) (i32.const 0))
 (global $global457 (mut (ref null $type68)) (ref.null none))
 (global $ready457 (mut i32) (i32.const 0))
 (global $global464 (mut (ref null $type70)) (ref.null none))
 (global $ready464 (mut i32) (i32.const 0))
 (global $global467 (mut (ref null $type70)) (ref.null none))
 (global $ready467 (mut i32) (i32.const 0))
 (global $global443 (mut (ref null $type71)) (ref.null none))
 (global $ready443 (mut i32) (i32.const 0))
 (global $global446 (mut (ref null $type38)) (ref.null none))
 (global $ready446 (mut i32) (i32.const 0))
 (global $global448 (mut (ref null $type29)) (ref.null none))
 (global $ready448 (mut i32) (i32.const 0))
 (global $global449 (mut (ref null $type29)) (ref.null none))
 (global $ready449 (mut i32) (i32.const 0))
 (global $global450 (mut (ref null $type29)) (ref.null none))
 (global $ready450 (mut i32) (i32.const 0))
 (global $global451 (mut (ref null $type29)) (ref.null none))
 (global $ready451 (mut i32) (i32.const 0))
 (global $global452 (mut (ref null $type29)) (ref.null none))
 (global $ready452 (mut i32) (i32.const 0))
 (global $global453 (mut (ref null $type72)) (ref.null none))
 (global $ready453 (mut i32) (i32.const 0))
 (global $global472 (mut (ref null $type38)) (ref.null none))
 (global $ready472 (mut i32) (i32.const 0))
 (global $global511 (mut (ref null $type73)) (ref.null none))
 (global $ready511 (mut i32) (i32.const 0))
 (global $global480 (mut (ref null $type38)) (ref.null none))
 (global $ready480 (mut i32) (i32.const 0))
 (global $global515 (mut (ref null $type74)) (ref.null none))
 (global $ready515 (mut i32) (i32.const 0))
 (global $global486 (mut (ref null $type75)) (ref.null none))
 (global $ready486 (mut i32) (i32.const 0))
 (global $global493 (mut (ref null $type76)) (ref.null none))
 (global $ready493 (mut i32) (i32.const 0))
 (global $global491 (mut (ref null $type77)) (ref.null none))
 (global $ready491 (mut i32) (i32.const 0))
 (global $global499 (mut i64) (i64.const 0))
 (global $ready499 (mut i32) (i32.const 0))
 (global $global500 (mut i64) (i64.const 0))
 (global $ready500 (mut i32) (i32.const 0))
 (global $global501 (mut i64) (i64.const 0))
 (global $ready501 (mut i32) (i32.const 0))
 (global $global502 (mut (ref null $type69)) (ref.null none))
 (global $ready502 (mut i32) (i32.const 0))
 (global $global505 (mut (ref null $type78)) (ref.null none))
 (global $ready505 (mut i32) (i32.const 0))
 (global $global506 (mut (ref null $type37)) (ref.null none))
 (global $ready506 (mut i32) (i32.const 0))
 (global $global518 (mut (ref null $type10)) (ref.null none))
 (global $ready518 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "observe" (func $export1))
 (export "main" (func $main))
 (func $string-min (param $a i32) (param $b i32) (result i32)
  (if (result i32)
   (i32.lt_u
    (local.get $a)
    (local.get $b)
   )
   (then
    (local.get $a)
   )
   (else
    (local.get $b)
   )
  )
 )
 (func $string-new (param $length i32) (param $fill i32) (result (ref $type16))
  (local $first (ref null $type17))
  (local $directory (ref null $type18))
  (local $remaining i32)
  (local $index i32)
  (local $size i32)
  (local.set $size
   (call $string-min
    (local.get $length)
    (i32.const 8192)
   )
  )
  (local.set $first
   (array.new $type17
    (local.get $fill)
    (local.get $size)
   )
  )
  (local.set $remaining
   (i32.sub
    (local.get $length)
    (local.get $size)
   )
  )
  (if
   (local.get $remaining)
   (then
    (local.set $directory
     (array.new_default $type18
      (i32.shr_u
       (i32.sub
        (local.get $length)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (local.set $size
      (call $string-min
       (local.get $remaining)
       (i32.const 8192)
      )
     )
     (array.set $type18
      (local.get $directory)
      (local.get $index)
      (array.new $type17
       (local.get $fill)
       (local.get $size)
      )
     )
     (local.set $index
      (i32.add
       (local.get $index)
       (i32.const 1)
      )
     )
     (local.set $remaining
      (i32.sub
       (local.get $remaining)
       (local.get $size)
      )
     )
     (br_if $label
      (local.get $remaining)
     )
    )
   )
  )
  (struct.new $type16
   (i32.const 1)
   (local.get $length)
   (ref.as_non_null
    (local.get $first)
   )
   (local.get $directory)
  )
 )
 (func $string-block (param $string (ref $type16)) (param $index i32) (result (ref $type17))
  (if (result (ref $type17))
   (i32.lt_u
    (local.get $index)
    (i32.const 8192)
   )
   (then
    (struct.get $type16 2
     (local.get $string)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type18
      (struct.get $type16 3
       (local.get $string)
      )
      (i32.sub
       (i32.shr_u
        (local.get $index)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy-forward (param $target (ref $type16)) (param $at i32) (param $source (ref $type16)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $at)
         (i32.const 8191)
        )
       )
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $start)
         (i32.const 8191)
        )
       )
      )
     )
    )
    (array.copy $type17 $type17
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $at
     (i32.add
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.add
      (local.get $start)
      (local.get $step)
     )
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy-backward (param $target (ref $type16)) (param $at i32) (param $source (ref $type16)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (local.set $at
   (i32.add
    (local.get $at)
    (local.get $remaining)
   )
  )
  (local.set $start
   (i32.add
    (local.get $start)
    (local.get $remaining)
   )
  )
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.add
        (i32.and
         (i32.sub
          (local.get $at)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
       (i32.add
        (i32.and
         (i32.sub
          (local.get $start)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
      )
     )
    )
    (local.set $at
     (i32.sub
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.sub
      (local.get $start)
      (local.get $step)
     )
    )
    (array.copy $type17 $type17
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy (param $target (ref $type16)) (param $at i64) (param $source (ref $type16)) (param $start i64) (param $end i64) (result i32)
  (if
   (i32.ne
    (struct.get $type16 0
     (local.get $target)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $at)
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $target)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $end)
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $source)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $start)
    (local.get $end)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $end)
     (local.get $start)
    )
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type16 1
       (local.get $target)
      )
     )
     (local.get $at)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (ref.eq
     (local.get $target)
     (local.get $source)
    )
    (i64.gt_u
     (local.get $at)
     (local.get $start)
    )
   )
   (then
    (call $string-copy-backward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
   (else
    (call $string-copy-forward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function0 (type $call0) (param $environment eqref) (param $argument1 i64) (param $argument2 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument1)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument2)
  )
  (f64.add
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function1 (type $call1) (param $environment eqref) (param $argument4 f64) (param $argument5 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument4)
  )
  (local.set $local2
   (local.get $argument5)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.add
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function2 (type $call0) (param $environment eqref) (param $argument7 i64) (param $argument8 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument7)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument8)
  )
  (f64.sub
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function3 (type $call1) (param $environment eqref) (param $argument10 f64) (param $argument11 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument10)
  )
  (local.set $local2
   (local.get $argument11)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.sub
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function4 (type $call0) (param $environment eqref) (param $argument13 i64) (param $argument14 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument13)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument14)
  )
  (f64.mul
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function5 (type $call1) (param $environment eqref) (param $argument16 f64) (param $argument17 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument16)
  )
  (local.set $local2
   (local.get $argument17)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.mul
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function6 (type $call0) (param $environment eqref) (param $argument19 i64) (param $argument20 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument19)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument20)
  )
  (f64.div
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function7 (type $call1) (param $environment eqref) (param $argument22 f64) (param $argument23 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument22)
  )
  (local.set $local2
   (local.get $argument23)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.div
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function8 (type $call2) (param $environment eqref) (param $argument25 i64) (param $argument26 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument25)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument26)
  )
  (f64.eq
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function9 (type $call3) (param $environment eqref) (param $argument28 f64) (param $argument29 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument28)
  )
  (local.set $local2
   (local.get $argument29)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function10 (type $call2) (param $environment eqref) (param $argument31 i64) (param $argument32 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument31)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument32)
  )
  (f64.lt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function11 (type $call3) (param $environment eqref) (param $argument34 f64) (param $argument35 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument34)
  )
  (local.set $local2
   (local.get $argument35)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.lt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function12 (type $call2) (param $environment eqref) (param $argument37 i64) (param $argument38 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument37)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument38)
  )
  (f64.le
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function13 (type $call3) (param $environment eqref) (param $argument40 f64) (param $argument41 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument40)
  )
  (local.set $local2
   (local.get $argument41)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.le
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function14 (type $call2) (param $environment eqref) (param $argument43 i64) (param $argument44 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument43)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument44)
  )
  (f64.gt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function15 (type $call3) (param $environment eqref) (param $argument46 f64) (param $argument47 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument46)
  )
  (local.set $local2
   (local.get $argument47)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.gt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function16 (type $call2) (param $environment eqref) (param $argument49 i64) (param $argument50 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument49)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument50)
  )
  (f64.ge
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function17 (type $call3) (param $environment eqref) (param $argument52 f64) (param $argument53 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument52)
  )
  (local.set $local2
   (local.get $argument53)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.ge
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function18 (type $call4) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function19 (type $call5) (param $environment eqref) (result i64)
  (i64.const 0)
 )
 (func $function20 (type $call6) (param $environment eqref) (result f32)
  (f32.const 0)
 )
 (func $function21 (type $call7) (param $environment eqref) (result f64)
  (f64.const 0)
 )
 (func $function22 (type $call8) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function23 (type $call9) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function24 (type $call10) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function25 (type $call15) (param $environment eqref) (param $argument62 i64) (result (ref $type16))
  (local $local0 i64)
  (local $local1 i32)
  (local.set $local0
   (local.get $argument62)
  )
  (local.set $local1
   (i32.const 0)
  )
  (if
   (i64.gt_u
    (local.get $local0)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (call $string-new
   (i32.wrap_i64
    (local.get $local0)
   )
   (local.get $local1)
  )
 )
 (func $function26 (type $call19) (param $environment eqref) (param $argument64 (ref null $type12)) (result (ref $type16))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type20))
  (local.set $local0
   (local.get $argument64)
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (return_call $function27
   (struct.get $type20 1
    (ref.as_non_null
     (local.get $local1)
    )
   )
   (local.get $local0)
  )
 )
 (func $function27 (type $call20) (param $environment eqref) (param $argument66 (ref null $type12)) (result (ref $type16))
  (local $local0 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local2 i64)
  (local $local7 i64)
  (local $local1 (ref null $type16))
  (local $local3 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local4 (ref null $type11))
  (local $local5 (ref null $type15))
  (local.set $local3
   (local.get $argument66)
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global68)
   )
  )
  (local.set $local2
   (call $function28
    (struct.get $type11 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type15 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local6
   (local.get $argument66)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function30
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local9)
   (local.get $local8)
   (local.get $local6)
   (local.get $local7)
  )
 )
 (func $function28 (type $call11) (param $environment eqref) (param $argument69 (ref null $type12)) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument69)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function29
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function29 (param $capture70 i32) (param $initialized70 i32) (param $argument71 (ref null $type12)) (param $argument72 i64) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local7 (ref null $type12))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local.set $local7
   (local.get $argument71)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local7)
   )
   (then
    (local.get $argument72)
   )
   (else
    (local.set $local5
     (local.get $argument72)
    )
    (local.set $local6
     (i64.const 4294967295)
    )
    (if (result i64)
     (i64.eq
      (local.get $local5)
      (local.get $local6)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local1
       (local.get $argument71)
      )
      (local.set $local0
       (struct.get $type12 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument72)
      )
      (local.set $local4
       (i64.const 1)
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized70)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture70)
      )
      (return_call $function29
       (local.get $capture70)
       (local.get $initialized70)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function30 (param $capture67 (ref $type16)) (param $capture73 i32) (param $initialized73 i32) (param $argument74 (ref null $type12)) (param $argument75 i64) (result (ref $type16))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local8 (ref null $type12))
  (local $local10 (ref null $type12))
  (local $local5 (ref null $type16))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i32)
  (local $local9 i32)
  (local.set $local10
   (local.get $argument74)
  )
  (if (result (ref $type16))
   (ref.is_null
    (local.get $local10)
   )
   (then
    (ref.as_non_null
     (local.get $capture67)
    )
   )
   (else
    (local.set $local5
     (ref.as_non_null
      (local.get $capture67)
     )
    )
    (local.set $local6
     (local.get $argument75)
    )
    (local.set $local8
     (local.get $argument74)
    )
    (local.set $local7
     (struct.get $type12 0
      (local.get $local8)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (array.set $type17
     (call $string-block
      (ref.as_non_null
       (local.get $local5)
      )
      (local.get $local9)
     )
     (i32.and
      (local.get $local9)
      (i32.const 8191)
     )
     (local.get $local7)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument74)
    )
    (local.set $local0
     (struct.get $type12 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument75)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized73)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture73)
    )
    (return_call $function30
     (ref.as_non_null
      (local.get $capture67)
     )
     (local.get $capture73)
     (local.get $initialized73)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function31 (type $call21) (param $environment eqref) (param $argument77 (ref $type16)) (result (ref null $type12))
  (local $local0 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local $local1 (ref null $type16))
  (local $local2 (ref null $type12))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument77)
   )
  )
  (local.set $local0
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local2
   (ref.null none)
  )
  (local.set $local4
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local4)
  )
  (return_call $function32
   (ref.as_non_null
    (local.get $argument77)
   )
   (local.get $local4)
   (local.get $local3)
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function32 (param $capture77 (ref $type16)) (param $capture78 i32) (param $initialized78 i32) (param $argument79 i64) (param $argument80 (ref null $type12)) (result (ref null $type12))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local4 i32)
  (local $local9 i32)
  (local $local3 (ref null $type12))
  (local $local10 (ref null $type12))
  (local $local5 (ref null $type16))
  (local.set $local11
   (local.get $argument79)
  )
  (local.set $local12
   (i64.const 0)
  )
  (if (result (ref null $type12))
   (i64.eq
    (local.get $local11)
    (local.get $local12)
   )
   (then
    (local.get $argument80)
   )
   (else
    (local.set $local1
     (local.get $argument79)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $capture77)
     )
    )
    (local.set $local7
     (local.get $argument79)
    )
    (local.set $local8
     (i64.const 1)
    )
    (local.set $local6
     (i64.sub
      (local.get $local7)
      (local.get $local8)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (local.set $local4
     (array.get $type17
      (call $string-block
       (ref.as_non_null
        (local.get $local5)
       )
       (local.get $local9)
      )
      (i32.and
       (local.get $local9)
       (i32.const 8191)
      )
     )
    )
    (local.set $local10
     (local.get $argument80)
    )
    (local.set $local3
     (struct.new $type12
      (local.get $local4)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture78)
    )
    (return_call $function32
     (ref.as_non_null
      (local.get $capture77)
     )
     (local.get $capture78)
     (local.get $initialized78)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function33 (type $call22) (param $environment eqref) (param $argument82 (ref $type16)) (param $argument83 i64) (param $argument84 i64) (result (ref $type16))
  (local $local0 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local16 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local1 (ref null $type16))
  (local $local6 (ref null $type16))
  (local $local8 (ref null $type16))
  (local $local21 (ref null $type16))
  (local $local5 (ref null $type15))
  (local.set $local13
   (local.get $argument83)
  )
  (local.set $local14
   (i64.const 0)
  )
  (local.set $local12
   (i64.lt_s
    (local.get $local13)
    (local.get $local14)
   )
  )
  (local.set $local11
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type16))
   (if (result i32)
    (local.get $local12)
    (then
     (if
      (i32.eqz
       (local.get $local11)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local12)
    )
    (else
     (local.set $local17
      (local.get $argument84)
     )
     (local.set $local18
      (local.get $argument83)
     )
     (local.set $local16
      (i64.lt_s
       (local.get $local17)
       (local.get $local18)
      )
     )
     (local.set $local15
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local15)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local16)
      (then
       (if
        (i32.eqz
         (local.get $local15)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local16)
      )
      (else
       (local.set $local19
        (local.get $argument84)
       )
       (local.set $local21
        (ref.as_non_null
         (local.get $argument82)
        )
       )
       (local.set $local20
        (i64.extend_i32_u
         (struct.get $type16 1
          (ref.as_non_null
           (local.get $local21)
          )
         )
        )
       )
       (i64.gt_s
        (local.get $local19)
        (local.get $local20)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local3
     (local.get $argument84)
    )
    (local.set $local4
     (local.get $argument83)
    )
    (local.set $local2
     (i64.sub
      (local.get $local3)
      (local.get $local4)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local1
     (call $function25
      (struct.get $type15 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local7
     (i64.const 0)
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $argument82)
     )
    )
    (local.set $local9
     (local.get $argument83)
    )
    (local.set $local10
     (local.get $argument84)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local6)
      )
      (local.get $local7)
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
 )
 (func $function34 (type $call23) (param $environment eqref) (param $argument89 (ref $type16)) (result (ref $type16))
  (local $local0 (ref null $type16))
  (local $local3 (ref null $type16))
  (local $local4 (ref null $type22))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument89)
   )
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument89)
   )
  )
  (local.set $local2
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (return_call $function33
   (struct.get $type22 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function35 (type $call24) (param $environment eqref) (param $argument91 (ref null $type25)) (result (ref $type16))
  (local $local0 i32)
  (local $local2 i64)
  (local $local8 i64)
  (local $local1 (ref null $type16))
  (local $local6 (ref null $type16))
  (local $local3 (ref null $type25))
  (local $local7 (ref null $type25))
  (local $local4 (ref null $type26))
  (local $local5 (ref null $type15))
  (local $local9 (ref null $type27))
  (local.set $local3
   (local.get $argument91)
  )
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $local2
   (call $function36
    (struct.get $type26 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type15 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (local.get $argument91)
  )
  (local.set $local8
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (call $function38
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (local.get $local7)
    (local.get $local8)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function36 (type $call26) (param $environment eqref) (param $argument94 (ref null $type25)) (result i64)
  (local $local0 (ref null $type25))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument94)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function37
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function37 (param $capture95 i32) (param $initialized95 i32) (param $argument96 (ref null $type25)) (param $argument97 i64) (result i64)
  (local $local0 (ref null $type25))
  (local $local1 (ref null $type25))
  (local $local6 (ref null $type25))
  (local $local7 (ref null $type25))
  (local $local5 (ref null $type16))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local.set $local8
   (local.get $argument97)
  )
  (local.set $local9
   (i64.const 4294967294)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local7
     (local.get $argument96)
    )
    (if (result i64)
     (ref.is_null
      (local.get $local7)
     )
     (then
      (local.get $argument97)
     )
     (else
      (local.set $local1
       (local.get $argument96)
      )
      (local.set $local0
       (struct.get $type25 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument97)
      )
      (local.set $local6
       (local.get $argument96)
      )
      (local.set $local5
       (struct.get $type25 0
        (local.get $local6)
       )
      )
      (local.set $local4
       (i64.extend_i32_u
        (struct.get $type16 1
         (ref.as_non_null
          (local.get $local5)
         )
        )
       )
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized95)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture95)
      )
      (return_call $function37
       (local.get $capture95)
       (local.get $initialized95)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call27) (param $environment eqref) (param $argument99 (ref $type16)) (param $argument100 (ref null $type25)) (param $argument101 i64) (result i32)
  (local $local0 i32)
  (local $local1 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local2 (ref null $type16))
  (local $local4 (ref null $type16))
  (local $local11 (ref null $type16))
  (local $local13 (ref null $type16))
  (local $local3 (ref null $type25))
  (local $local5 (ref null $type25))
  (local $local6 (ref null $type25))
  (local $local14 (ref null $type25))
  (local $local17 (ref null $type25))
  (local $local10 (ref null $type27))
  (local.set $local17
   (local.get $argument100)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local17)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (local.get $argument100)
    )
    (local.set $local2
     (struct.get $type25 0
      (local.get $local3)
     )
    )
    (local.set $local1
     (i64.extend_i32_u
      (struct.get $type16 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $argument99)
     )
    )
    (local.set $local12
     (local.get $argument101)
    )
    (local.set $local14
     (local.get $argument100)
    )
    (local.set $local13
     (struct.get $type25 0
      (local.get $local14)
     )
    )
    (local.set $local15
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local11)
      )
      (local.get $local12)
      (ref.as_non_null
       (local.get $local13)
      )
      (local.get $local15)
      (local.get $local16)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (local.get $argument99)
     )
    )
    (local.set $local6
     (local.get $argument100)
    )
    (local.set $local5
     (struct.get $type25 1
      (local.get $local6)
     )
    )
    (local.set $local8
     (local.get $argument101)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (local.get $local1)
    )
    (local.set $local7
     (i64.add
      (local.get $local8)
      (local.get $local9)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (struct.get $type27 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (ref.as_non_null
      (local.get $local4)
     )
     (local.get $local5)
     (local.get $local7)
    )
   )
  )
 )
 (func $function39 (type $call28) (param $environment eqref) (param $argument104 (ref $type16)) (param $argument105 (ref $type16)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 (ref null $type16))
  (local $local6 (ref null $type16))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument104)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $argument105)
   )
  )
  (local.set $local5
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local3)
    (local.get $local5)
   )
   (then
    (local.set $local0
     (i64.const 0)
    )
    (local.set $local2
     (i32.const 0)
    )
    (local.set $local1
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local2)
    )
    (return_call $function40
     (ref.as_non_null
      (local.get $argument104)
     )
     (ref.as_non_null
      (local.get $argument105)
     )
     (local.get $local2)
     (local.get $local1)
     (local.get $local0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function40 (param $capture104 (ref $type16)) (param $capture105 (ref $type16)) (param $capture106 i32) (param $initialized106 i32) (param $argument107 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local8 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local14 i64)
  (local $local4 (ref null $type16))
  (local $local9 (ref null $type16))
  (local $local13 (ref null $type16))
  (local.set $local2
   (local.get $argument107)
  )
  (local.set $local4
   (ref.as_non_null
    (local.get $capture104)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local1
   (i64.eq
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local9
     (ref.as_non_null
      (local.get $capture104)
     )
    )
    (local.set $local10
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local10)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (i32.wrap_i64
      (local.get $local10)
     )
    )
    (local.set $local8
     (array.get $type17
      (call $string-block
       (ref.as_non_null
        (local.get $local9)
       )
       (local.get $local11)
      )
      (i32.and
       (local.get $local11)
       (i32.const 8191)
      )
     )
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $capture105)
     )
    )
    (local.set $local14
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local14)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (i32.wrap_i64
      (local.get $local14)
     )
    )
    (local.set $local12
     (array.get $type17
      (call $string-block
       (ref.as_non_null
        (local.get $local13)
       )
       (local.get $local15)
      )
      (i32.and
       (local.get $local15)
       (i32.const 8191)
      )
     )
    )
    (if (result i32)
     (i32.eq
      (local.get $local8)
      (local.get $local12)
     )
     (then
      (local.set $local6
       (local.get $argument107)
      )
      (local.set $local7
       (i64.const 1)
      )
      (local.set $local5
       (i64.add
        (local.get $local6)
        (local.get $local7)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized106)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture106)
      )
      (return_call $function40
       (ref.as_non_null
        (local.get $capture104)
       )
       (ref.as_non_null
        (local.get $capture105)
       )
       (local.get $capture106)
       (local.get $initialized106)
       (local.get $local5)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call30) (param $environment eqref) (param $argument113 (ref $type14)) (param $argument114 i64) (result i64)
  (local $local0 i32)
  (local $local2 i64)
  (local $local1 (ref null $type14))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument113)
   )
  )
  (local.set $local2
   (local.get $argument114)
  )
  (local.set $local0
   (array.get $type14
    (ref.as_non_null
     (local.get $local1)
    )
    (block (result i32)
     (if
      (i64.gt_u
       (local.get $local2)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i32.wrap_i64
      (local.get $local2)
     )
    )
   )
  )
  (i64.extend_i32_s
   (local.get $local0)
  )
 )
 (func $function42 (type $call31) (param $environment eqref) (param $argument116 (ref $type14)) (param $argument117 i64) (param $argument118 i64) (result i32)
  (local $local0 (ref null $type14))
  (local $local1 i64)
  (local $local3 i64)
  (local $local2 i32)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument116)
   )
  )
  (local.set $local1
   (local.get $argument117)
  )
  (local.set $local3
   (local.get $argument118)
  )
  (local.set $local2
   (i32.wrap_i64
    (local.get $local3)
   )
  )
  (array.set $type14
   (ref.as_non_null
    (local.get $local0)
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local1)
    )
   )
   (local.get $local2)
  )
  (i32.const 0)
 )
 (func $function43 (type $call32) (param $environment eqref) (param $argument120 i64) (result (ref $type14))
  (local $local0 i64)
  (local $local1 i32)
  (local.set $local0
   (local.get $argument120)
  )
  (local.set $local1
   (i32.const 0)
  )
  (array.new $type14
   (local.get $local1)
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local0)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local0)
    )
   )
  )
 )
 (func $function44 (type $call33) (param $environment eqref) (param $argument122 (ref $type14)) (result i64)
  (local $local0 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local $local1 (ref null $type14))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument122)
   )
  )
  (local.set $local0
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function45
   (ref.as_non_null
    (local.get $argument122)
   )
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
  )
 )
 (func $function45 (param $capture122 (ref $type14)) (param $capture123 i32) (param $initialized123 i32) (param $argument124 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local $local7 i32)
  (local $local9 (ref null $type14))
  (local $local13 (ref null $type30))
  (local.set $local5
   (local.get $argument124)
  )
  (local.set $local6
   (i64.const 0)
  )
  (local.set $local4
   (i64.eq
    (local.get $local5)
    (local.get $local6)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (if (result i32)
    (local.get $local4)
    (then
     (if
      (i32.eqz
       (local.get $local3)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local4)
    )
    (else
     (local.set $local9
      (ref.as_non_null
       (local.get $capture122)
      )
     )
     (local.set $local11
      (local.get $argument124)
     )
     (local.set $local12
      (i64.const 1)
     )
     (local.set $local10
      (i64.sub
       (local.get $local11)
       (local.get $local12)
      )
     )
     (local.set $local13
      (ref.as_non_null
       (global.get $global112)
      )
     )
     (local.set $local8
      (call $function41
       (struct.get $type30 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
       (ref.as_non_null
        (local.get $local9)
       )
       (local.get $local10)
      )
     )
     (local.set $local14
      (i64.const 0)
     )
     (local.set $local7
      (i64.eq
       (local.get $local8)
       (local.get $local14)
      )
     )
     (i32.eqz
      (local.get $local7)
     )
    )
   )
   (then
    (local.get $argument124)
   )
   (else
    (local.set $local1
     (local.get $argument124)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized123)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture123)
    )
    (return_call $function45
     (ref.as_non_null
      (local.get $capture122)
     )
     (local.get $capture123)
     (local.get $initialized123)
     (local.get $local0)
    )
   )
  )
 )
 (func $function46 (type $call13) (param $environment eqref) (param $argument127 (ref $type14)) (result (ref $type14))
  (local $local0 i32)
  (local $local4 i32)
  (local $local1 i64)
  (local $local6 i64)
  (local $local9 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local2 (ref null $type14))
  (local $local5 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local10 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local3 (ref null $type33))
  (local $local7 (ref null $type32))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument127)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (local.set $local1
   (call $function44
    (struct.get $type33 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (local.get $local1)
  )
  (local.set $local15
   (ref.as_non_null
    (local.get $argument127)
   )
  )
  (local.set $local14
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local15)
     )
    )
   )
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $local13)
    (local.get $local14)
   )
   (then
    (ref.as_non_null
     (local.get $argument127)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (local.get $local1)
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (local.set $local5
     (call $function43
      (struct.get $type32 1
       (ref.as_non_null
        (local.get $local7)
       )
      )
      (local.get $local6)
     )
    )
    (local.set $local4
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.set $local9
     (i64.const 0)
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $argument127)
     )
    )
    (local.set $local11
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (local.get $local1)
    )
    (if
     (i64.lt_s
      (local.get $local12)
      (local.get $local11)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (ref.as_non_null
      (local.get $local8)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local9)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local9)
      )
     )
     (ref.as_non_null
      (local.get $local10)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local11)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (i64.sub
         (local.get $local12)
         (local.get $local11)
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (i64.sub
        (local.get $local12)
        (local.get $local11)
       )
      )
     )
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
 )
 (func $function47 (type $call34) (param $environment eqref) (param $argument131 i32) (param $argument132 (ref $type14)) (result (ref $type29))
  (local $local0 i32)
  (local $local4 i32)
  (local $local6 i64)
  (local $local8 i64)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type14))
  (local $local5 (ref null $type14))
  (local $local7 (ref null $type14))
  (local $local3 (ref null $type13))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument132)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (local.set $local1
   (call $function46
    (struct.get $type13 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local6
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
  (local.set $local8
   (i64.const 0)
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $local6)
    (local.get $local8)
   )
   (then
    (ref.as_non_null
     (global.get $global111)
    )
   )
   (else
    (local.set $local4
     (local.get $argument131)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (struct.new $type29
     (local.get $local4)
     (ref.as_non_null
      (local.get $local5)
     )
    )
   )
  )
 )
 (func $function48 (type $call35) (param $environment eqref) (param $argument135 (ref $type29)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type29))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument135)
   )
  )
  (local.set $local1
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local3
   (i64.const 0)
  )
  (i64.eq
   (local.get $local0)
   (local.get $local3)
  )
 )
 (func $function49 (type $call36) (param $environment eqref) (param $argument137 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type29))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument137)
   )
  )
  (if (result (ref $type29))
   (struct.get $type29 0
    (ref.as_non_null
     (local.get $local3)
    )
   )
   (then
    (local.set $local0
     (i32.const 0)
    )
    (local.set $local2
     (ref.as_non_null
      (local.get $argument137)
     )
    )
    (local.set $local1
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (struct.new $type29
     (local.get $local0)
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
   (else
    (ref.as_non_null
     (local.get $argument137)
    )
   )
  )
 )
 (func $function50 (type $call36) (param $environment eqref) (param $argument139 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 (ref null $type29))
  (local $local4 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local3 (ref null $type14))
  (local $local6 (ref null $type35))
  (local.set $local5
   (ref.as_non_null
    (local.get $argument139)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if (result (ref $type29))
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (ref.as_non_null
     (local.get $local5)
    )
   )
   (then
    (ref.as_non_null
     (local.get $argument139)
    )
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument139)
     )
    )
    (local.set $local1
     (struct.get $type29 0
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (i32.eqz
      (local.get $local1)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (local.get $argument139)
     )
    )
    (local.set $local3
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local4)
      )
     )
    )
    (struct.new $type29
     (local.get $local0)
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
 )
 (func $function51 (type $call37) (param $environment eqref) (param $argument141 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument141)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function52
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function52 (param $capture142 i32) (param $initialized142 i32) (param $argument143 i64) (param $argument144 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local.set $local6
   (local.get $argument143)
  )
  (local.set $local7
   (i64.const 0)
  )
  (if (result i64)
   (i64.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (local.get $argument144)
   )
   (else
    (local.set $local1
     (local.get $argument143)
    )
    (local.set $local2
     (i64.const 1073741824)
    )
    (local.set $local0
     (i64.div_s
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument144)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized142)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture142)
    )
    (return_call $function52
     (local.get $capture142)
     (local.get $initialized142)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function53 (type $call38) (param $environment eqref) (param $argument146 i64) (result (ref $type29))
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local10 i32)
  (local $local18 i32)
  (local $local19 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local11 (ref null $type14))
  (local $local14 (ref null $type37))
  (local $local15 (ref null $type32))
  (local.set $local2
   (local.get $argument146)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local1
   (i64.lt_s
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local8
   (local.get $argument146)
  )
  (local.set $local9
   (i64.const 0)
  )
  (local.set $local5
   (if (result i64)
    (i64.gt_s
     (local.get $local8)
     (local.get $local9)
    )
    (then
     (local.set $local6
      (i64.const 0)
     )
     (local.set $local7
      (local.get $argument146)
     )
     (i64.sub
      (local.get $local6)
      (local.get $local7)
     )
    )
    (else
     (local.get $argument146)
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (local.get $local5)
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global140)
   )
  )
  (local.set $local12
   (call $function51
    (struct.get $type37 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (local.get $local13)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local11
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (local.get $local12)
   )
  )
  (local.set $local10
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local16
   (local.get $local5)
  )
  (local.set $local17
   (i64.const 0)
  )
  (local.set $local19
   (i32.const 0)
  )
  (local.set $local18
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local18)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local19)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function54
   (local.get $local1)
   (block (result (ref $type14))
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (local.get $local19)
   (local.get $local18)
   (local.get $local16)
   (local.get $local17)
  )
 )
 (func $function54 (param $capture147 i32) (param $capture149 (ref $type14)) (param $capture150 i32) (param $initialized150 i32) (param $argument151 i64) (param $argument152 i64) (result (ref $type29))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local14 i32)
  (local $local6 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local13 (ref null $type31))
  (local $local16 (ref null $type34))
  (local.set $local17
   (local.get $argument151)
  )
  (local.set $local18
   (i64.const 0)
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $local17)
    (local.get $local18)
   )
   (then
    (local.set $local14
     (local.get $capture147)
    )
    (local.set $local15
     (ref.as_non_null
      (local.get $capture149)
     )
    )
    (local.set $local16
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (return_call $function47
     (struct.get $type34 1
      (ref.as_non_null
       (local.get $local16)
      )
     )
     (local.get $local14)
     (ref.as_non_null
      (local.get $local15)
     )
    )
   )
   (else
    (local.set $local6
     (ref.as_non_null
      (local.get $capture149)
     )
    )
    (local.set $local7
     (local.get $argument152)
    )
    (local.set $local9
     (i64.const 0)
    )
    (local.set $local11
     (local.get $argument151)
    )
    (local.set $local12
     (i64.const 1073741824)
    )
    (local.set $local10
     (i64.rem_s
      (local.get $local11)
      (local.get $local12)
     )
    )
    (local.set $local8
     (i64.sub
      (local.get $local9)
      (local.get $local10)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local6)
      )
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local1
     (local.get $argument151)
    )
    (local.set $local2
     (i64.const 1073741824)
    )
    (local.set $local0
     (i64.div_s
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument152)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized150)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture150)
    )
    (return_call $function54
     (local.get $capture147)
     (ref.as_non_null
      (local.get $capture149)
     )
     (local.get $capture150)
     (local.get $initialized150)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function55 (type $call39) (param $environment eqref) (param $argument154 (ref $type29)) (result i64)
  (local $local0 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local6 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local7 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local1 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local2 (ref null $type29))
  (local $local5 (ref null $type29))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument154)
   )
  )
  (local.set $local1
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument154)
   )
  )
  (local.set $local4
   (struct.get $type29 0
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (if (result i64)
    (local.get $local4)
    (then
     (i64.const -9223372036854775808)
    )
    (else
     (i64.const -9223372036854775807)
    )
   )
  )
  (local.set $local6
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local8
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local9)
     )
    )
   )
  )
  (local.set $local10
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local12
   (i32.const 0)
  )
  (local.set $local11
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local12)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function56
   (ref.as_non_null
    (local.get $local1)
   )
   (block (result i32)
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local4)
   )
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local7)
   )
   (local.get $local12)
   (local.get $local11)
   (local.get $local8)
   (local.get $local10)
  )
 )
 (func $function56 (param $capture155 (ref $type14)) (param $capture156 i32) (param $capture157 i64) (param $capture158 i32) (param $initialized158 i32) (param $argument159 i64) (param $argument160 i64) (result i64)
  (local $local0 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local2 (ref null $type14))
  (local $local6 (ref null $type30))
  (local.set $local23
   (local.get $argument159)
  )
  (local.set $local24
   (i64.const 0)
  )
  (if (result i64)
   (i64.eq
    (local.get $local23)
    (local.get $local24)
   )
   (then
    (if (result i64)
     (local.get $capture156)
     (then
      (local.get $argument160)
     )
     (else
      (local.set $local21
       (i64.const 0)
      )
      (local.set $local22
       (local.get $argument160)
      )
      (i64.sub
       (local.get $local21)
       (local.get $local22)
      )
     )
    )
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $capture155)
     )
    )
    (local.set $local4
     (local.get $argument159)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.sub
      (local.get $local4)
      (local.get $local5)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local1
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (local.get $local3)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local15
     (local.get $argument160)
    )
    (local.set $local18
     (local.get $capture157)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (local.get $local1)
    )
    (local.set $local17
     (i64.add
      (local.get $local18)
      (local.get $local19)
     )
    )
    (local.set $local20
     (i64.const 1073741824)
    )
    (local.set $local16
     (i64.div_s
      (local.get $local17)
      (local.get $local20)
     )
    )
    (if (result i64)
     (i64.lt_s
      (local.get $local15)
      (local.get $local16)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local8
       (local.get $argument159)
      )
      (local.set $local9
       (i64.const 1)
      )
      (local.set $local7
       (i64.sub
        (local.get $local8)
        (local.get $local9)
       )
      )
      (local.set $local12
       (local.get $argument160)
      )
      (local.set $local13
       (i64.const 1073741824)
      )
      (local.set $local11
       (i64.mul
        (local.get $local12)
        (local.get $local13)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local14
       (local.get $local1)
      )
      (local.set $local10
       (i64.sub
        (local.get $local11)
        (local.get $local14)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture158)
      )
      (return_call $function56
       (ref.as_non_null
        (local.get $capture155)
       )
       (local.get $capture156)
       (local.get $capture157)
       (local.get $capture158)
       (local.get $initialized158)
       (local.get $local7)
       (local.get $local10)
      )
     )
    )
   )
  )
 )
 (func $function57 (type $call40) (param $environment eqref) (param $argument163 (ref $type14)) (param $argument164 (ref $type14)) (result i64)
  (local $local0 i32)
  (local $local2 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local4 (ref null $type14))
  (local $local5 (ref null $type14))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument163)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument164)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local5)
     )
    )
   )
  )
  (local.set $local2
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (local.get $local1)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (local.get $local3)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local11)
    (local.get $local12)
   )
   (then
    (i64.const -1)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (local.get $local3)
    )
    (if (result i64)
     (i64.gt_s
      (local.get $local9)
      (local.get $local10)
     )
     (then
      (i64.const 1)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (local.get $local1)
      )
      (local.set $local8
       (i32.const 0)
      )
      (local.set $local7
       (i32.const 1)
      )
      (drop
       (i32.const 0)
      )
      (if
       (i32.eqz
        (local.get $local7)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $local8)
      )
      (return_call $function58
       (ref.as_non_null
        (local.get $argument163)
       )
       (ref.as_non_null
        (local.get $argument164)
       )
       (local.get $local8)
       (local.get $local7)
       (local.get $local6)
      )
     )
    )
   )
  )
 )
 (func $function58 (param $capture163 (ref $type14)) (param $capture164 (ref $type14)) (param $capture167 i32) (param $initialized167 i32) (param $argument168 i64) (result i64)
  (local $local0 i32)
  (local $local2 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local4 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local8 (ref null $type30))
  (local $local13 (ref null $type30))
  (local.set $local21
   (local.get $argument168)
  )
  (local.set $local22
   (i64.const 0)
  )
  (if (result i64)
   (i64.eq
    (local.get $local21)
    (local.get $local22)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture163)
     )
    )
    (local.set $local6
     (local.get $argument168)
    )
    (local.set $local7
     (i64.const 1)
    )
    (local.set $local5
     (i64.sub
      (local.get $local6)
      (local.get $local7)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local1
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (local.get $local5)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $capture164)
     )
    )
    (local.set $local11
     (local.get $argument168)
    )
    (local.set $local12
     (i64.const 1)
    )
    (local.set $local10
     (i64.sub
      (local.get $local11)
      (local.get $local12)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local3
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local9)
      )
      (local.get $local10)
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local20
     (local.get $local3)
    )
    (if (result i64)
     (i64.lt_s
      (local.get $local19)
      (local.get $local20)
     )
     (then
      (i64.const -1)
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local17
       (local.get $local1)
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local18
       (local.get $local3)
      )
      (if (result i64)
       (i64.gt_s
        (local.get $local17)
        (local.get $local18)
       )
       (then
        (i64.const 1)
       )
       (else
        (local.set $local15
         (local.get $argument168)
        )
        (local.set $local16
         (i64.const 1)
        )
        (local.set $local14
         (i64.sub
          (local.get $local15)
          (local.get $local16)
         )
        )
        (if
         (i32.eqz
          (local.get $initialized167)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (local.get $capture167)
        )
        (return_call $function58
         (ref.as_non_null
          (local.get $capture163)
         )
         (ref.as_non_null
          (local.get $capture164)
         )
         (local.get $capture167)
         (local.get $initialized167)
         (local.get $local14)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function59 (type $call41) (param $environment eqref) (param $argument172 (ref $type29)) (param $argument173 (ref $type29)) (result i64)
  (local $local0 i32)
  (local $local11 i32)
  (local $local1 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local $local2 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local3 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local9 (ref null $type29))
  (local $local10 (ref null $type29))
  (local $local13 (ref null $type29))
  (local $local15 (ref null $type29))
  (local $local6 (ref null $type40))
  (local.set $local13
   (ref.as_non_null
    (local.get $argument172)
   )
  )
  (local.set $local12
   (if (result i64)
    (struct.get $type29 0
     (ref.as_non_null
      (local.get $local13)
     )
    )
    (then
     (i64.const 1)
    )
    (else
     (i64.const 0)
    )
   )
  )
  (local.set $local15
   (ref.as_non_null
    (local.get $argument173)
   )
  )
  (local.set $local14
   (if (result i64)
    (struct.get $type29 0
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (then
     (i64.const 1)
    )
    (else
     (i64.const 0)
    )
   )
  )
  (local.set $local11
   (i64.eq
    (local.get $local12)
    (local.get $local14)
   )
  )
  (if (result i64)
   (i32.eqz
    (local.get $local11)
   )
   (then
    (local.set $local10
     (ref.as_non_null
      (local.get $argument172)
     )
    )
    (if (result i64)
     (struct.get $type29 0
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.const 1)
     )
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $argument172)
     )
    )
    (local.set $local2
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $argument173)
     )
    )
    (local.set $local4
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local5)
      )
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (local.set $local1
     (call $function57
      (struct.get $type40 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (ref.as_non_null
       (local.get $local4)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $argument172)
     )
    )
    (if (result i64)
     (struct.get $type29 0
      (ref.as_non_null
       (local.get $local9)
      )
     )
     (then
      (local.set $local7
       (i64.const 0)
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local8
       (local.get $local1)
      )
      (i64.sub
       (local.get $local7)
       (local.get $local8)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local1)
     )
    )
   )
  )
 )
 (func $function60 (type $call42) (param $environment eqref) (param $argument176 (ref $type29)) (param $argument177 (ref $type29)) (result i32)
  (local $local0 i64)
  (local $local4 i64)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type41))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument176)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument177)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (local.set $local0
   (call $function59
    (struct.get $type41 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (i64.const 0)
  )
  (i64.eq
   (local.get $local0)
   (local.get $local4)
  )
 )
 (func $function61 (type $call42) (param $environment eqref) (param $argument179 (ref $type29)) (param $argument180 (ref $type29)) (result i32)
  (local $local0 i64)
  (local $local4 i64)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type41))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument179)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument180)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (local.set $local0
   (call $function59
    (struct.get $type41 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (i64.const 0)
  )
  (i64.lt_s
   (local.get $local0)
   (local.get $local4)
  )
 )
 (func $function62 (type $call42) (param $environment eqref) (param $argument182 (ref $type29)) (param $argument183 (ref $type29)) (result i32)
  (local $local0 i64)
  (local $local4 i64)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type41))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument182)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument183)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (local.set $local0
   (call $function59
    (struct.get $type41 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (i64.const 0)
  )
  (i64.le_s
   (local.get $local0)
   (local.get $local4)
  )
 )
 (func $function63 (type $call42) (param $environment eqref) (param $argument185 (ref $type29)) (param $argument186 (ref $type29)) (result i32)
  (local $local0 i64)
  (local $local4 i64)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type41))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument185)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument186)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (local.set $local0
   (call $function59
    (struct.get $type41 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (i64.const 0)
  )
  (i64.gt_s
   (local.get $local0)
   (local.get $local4)
  )
 )
 (func $function64 (type $call42) (param $environment eqref) (param $argument188 (ref $type29)) (param $argument189 (ref $type29)) (result i32)
  (local $local0 i64)
  (local $local4 i64)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type41))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument188)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument189)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (local.set $local0
   (call $function59
    (struct.get $type41 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (i64.const 0)
  )
  (i64.ge_s
   (local.get $local0)
   (local.get $local4)
  )
 )
 (func $function65 (type $call30) (param $environment eqref) (param $argument191 (ref $type14)) (param $argument192 i64) (result i64)
  (local $local0 (ref null $type14))
  (local $local5 (ref null $type14))
  (local $local2 (ref null $type30))
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local.set $local3
   (local.get $argument192)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument191)
   )
  )
  (local.set $local4
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local5)
     )
    )
   )
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local3)
    (local.get $local4)
   )
   (then
    (local.set $local0
     (ref.as_non_null
      (local.get $argument191)
     )
    )
    (local.set $local1
     (local.get $argument192)
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (return_call $function41
     (struct.get $type30 1
      (ref.as_non_null
       (local.get $local2)
      )
     )
     (ref.as_non_null
      (local.get $local0)
     )
     (local.get $local1)
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function66 (type $call43) (param $environment eqref) (param $argument194 (ref $type14)) (param $argument195 (ref $type14)) (result (ref $type14))
  (local $local0 i32)
  (local $local8 i32)
  (local $local16 i32)
  (local $local17 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local5 (ref null $type14))
  (local $local7 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local13 (ref null $type32))
  (local.set $local5
   (ref.as_non_null
    (local.get $argument194)
   )
  )
  (local.set $local4
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local5)
     )
    )
   )
  )
  (local.set $local7
   (ref.as_non_null
    (local.get $argument195)
   )
  )
  (local.set $local6
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
  (local.set $local1
   (if (result i64)
    (i64.gt_s
     (local.get $local4)
     (local.get $local6)
    )
    (then
     (local.set $local3
      (ref.as_non_null
       (local.get $argument194)
      )
     )
     (i64.extend_i32_u
      (array.len
       (ref.as_non_null
        (local.get $local3)
       )
      )
     )
    )
    (else
     (local.set $local2
      (ref.as_non_null
       (local.get $argument195)
      )
     )
     (i64.extend_i32_u
      (array.len
       (ref.as_non_null
        (local.get $local2)
       )
      )
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (local.get $local1)
  )
  (local.set $local12
   (i64.const 1)
  )
  (local.set $local10
   (i64.add
    (local.get $local11)
    (local.get $local12)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local9
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local13)
     )
    )
    (local.get $local10)
   )
  )
  (local.set $local8
   (i32.const 1)
  )
  (local.set $local14
   (i64.const 0)
  )
  (local.set $local15
   (i64.const 0)
  )
  (local.set $local17
   (i32.const 0)
  )
  (local.set $local16
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local17)
  )
  (return_call $function67
   (ref.as_non_null
    (local.get $argument194)
   )
   (ref.as_non_null
    (local.get $argument195)
   )
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (local.get $local8)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local9)
    )
   )
   (local.get $local17)
   (local.get $local16)
   (local.get $local14)
   (local.get $local15)
  )
 )
 (func $function67 (param $capture194 (ref $type14)) (param $capture195 (ref $type14)) (param $capture196 i64) (param $capture197 (ref $type14)) (param $capture198 i32) (param $initialized198 i32) (param $argument199 i64) (param $argument200 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local28 i64)
  (local $local29 i64)
  (local $local4 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local18 (ref null $type14))
  (local $local24 (ref null $type14))
  (local $local6 (ref null $type30))
  (local $local10 (ref null $type30))
  (local $local23 (ref null $type31))
  (local $local27 (ref null $type31))
  (local.set $local28
   (local.get $argument199)
  )
  (local.set $local29
   (local.get $capture196)
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $local28)
    (local.get $local29)
   )
   (then
    (local.set $local24
     (ref.as_non_null
      (local.get $capture197)
     )
    )
    (local.set $local25
     (local.get $capture196)
    )
    (local.set $local26
     (local.get $argument200)
    )
    (local.set $local27
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local27)
       )
      )
      (ref.as_non_null
       (local.get $local24)
      )
      (local.get $local25)
      (local.get $local26)
     )
    )
    (ref.as_non_null
     (local.get $capture197)
    )
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture194)
     )
    )
    (local.set $local5
     (local.get $argument199)
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (local.set $local3
     (call $function65
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (local.get $local5)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $capture195)
     )
    )
    (local.set $local9
     (local.get $argument199)
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (local.set $local7
     (call $function65
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
     )
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local7)
     )
    )
    (local.set $local11
     (local.get $argument200)
    )
    (local.set $local1
     (i64.add
      (local.get $local2)
      (local.get $local11)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local18
     (ref.as_non_null
      (local.get $capture197)
     )
    )
    (local.set $local19
     (local.get $argument199)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local21
     (local.get $local1)
    )
    (local.set $local22
     (i64.const 1073741824)
    )
    (local.set $local20
     (i64.rem_s
      (local.get $local21)
      (local.get $local22)
     )
    )
    (local.set $local23
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local23)
       )
      )
      (ref.as_non_null
       (local.get $local18)
      )
      (local.get $local19)
      (local.get $local20)
     )
    )
    (local.set $local13
     (local.get $argument199)
    )
    (local.set $local14
     (i64.const 1)
    )
    (local.set $local12
     (i64.add
      (local.get $local13)
      (local.get $local14)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (local.set $local17
     (i64.const 1073741824)
    )
    (local.set $local15
     (i64.div_s
      (local.get $local16)
      (local.get $local17)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized198)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture198)
    )
    (return_call $function67
     (ref.as_non_null
      (local.get $capture194)
     )
     (ref.as_non_null
      (local.get $capture195)
     )
     (local.get $capture196)
     (ref.as_non_null
      (local.get $capture197)
     )
     (local.get $capture198)
     (local.get $initialized198)
     (local.get $local12)
     (local.get $local15)
    )
   )
  )
 )
 (func $function68 (type $call43) (param $environment eqref) (param $argument203 (ref $type14)) (param $argument204 (ref $type14)) (result (ref $type14))
  (local $local0 i32)
  (local $local3 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local1 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local2 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local6 (ref null $type32))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument203)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (local.get $local1)
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local4
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (local.get $local5)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local8
   (i64.const 0)
  )
  (local.set $local10
   (i32.const 0)
  )
  (local.set $local9
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local10)
  )
  (return_call $function69
   (ref.as_non_null
    (local.get $argument203)
   )
   (ref.as_non_null
    (local.get $argument204)
   )
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (local.get $local10)
   (local.get $local9)
   (local.get $local7)
   (local.get $local8)
  )
 )
 (func $function69 (param $capture203 (ref $type14)) (param $capture204 (ref $type14)) (param $capture205 i64) (param $capture206 (ref $type14)) (param $capture207 i32) (param $initialized207 i32) (param $argument208 i64) (param $argument209 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local26 i64)
  (local $local27 i64)
  (local $local4 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local18 (ref null $type14))
  (local $local6 (ref null $type30))
  (local $local10 (ref null $type30))
  (local $local25 (ref null $type31))
  (local.set $local26
   (local.get $argument208)
  )
  (local.set $local27
   (local.get $capture205)
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $local26)
    (local.get $local27)
   )
   (then
    (ref.as_non_null
     (local.get $capture206)
    )
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture203)
     )
    )
    (local.set $local5
     (local.get $argument208)
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local3
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (local.get $local5)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $capture204)
     )
    )
    (local.set $local9
     (local.get $argument208)
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (local.set $local7
     (call $function65
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
     )
    )
    (local.set $local2
     (i64.sub
      (local.get $local3)
      (local.get $local7)
     )
    )
    (local.set $local11
     (local.get $argument209)
    )
    (local.set $local1
     (i64.sub
      (local.get $local2)
      (local.get $local11)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local18
     (ref.as_non_null
      (local.get $capture206)
     )
    )
    (local.set $local19
     (local.get $argument208)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local23
     (local.get $local1)
    )
    (local.set $local24
     (i64.const 0)
    )
    (local.set $local20
     (if (result i64)
      (i64.lt_s
       (local.get $local23)
       (local.get $local24)
      )
      (then
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local21
        (local.get $local1)
       )
       (local.set $local22
        (i64.const 1073741824)
       )
       (i64.add
        (local.get $local21)
        (local.get $local22)
       )
      )
      (else
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local1)
      )
     )
    )
    (local.set $local25
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local25)
       )
      )
      (ref.as_non_null
       (local.get $local18)
      )
      (local.get $local19)
      (local.get $local20)
     )
    )
    (local.set $local13
     (local.get $argument208)
    )
    (local.set $local14
     (i64.const 1)
    )
    (local.set $local12
     (i64.add
      (local.get $local13)
      (local.get $local14)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (local.set $local17
     (i64.const 0)
    )
    (local.set $local15
     (if (result i64)
      (i64.lt_s
       (local.get $local16)
       (local.get $local17)
      )
      (then
       (i64.const 1)
      )
      (else
       (i64.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized207)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture207)
    )
    (return_call $function69
     (ref.as_non_null
      (local.get $capture203)
     )
     (ref.as_non_null
      (local.get $capture204)
     )
     (local.get $capture205)
     (ref.as_non_null
      (local.get $capture206)
     )
     (local.get $capture207)
     (local.get $initialized207)
     (local.get $local12)
     (local.get $local15)
    )
   )
  )
 )
 (func $function70 (type $call44) (param $environment eqref) (param $argument212 i32) (param $argument213 (ref $type14)) (param $argument214 (ref $type14)) (result (ref $type29))
  (local $local0 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local13 i64)
  (local $local17 i64)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local10 (ref null $type14))
  (local $local14 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local4 (ref null $type43))
  (local $local11 (ref null $type43))
  (local $local5 (ref null $type34))
  (local $local12 (ref null $type34))
  (local $local16 (ref null $type40))
  (local.set $local14
   (ref.as_non_null
    (local.get $argument213)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (local.get $argument214)
   )
  )
  (local.set $local16
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (local.set $local13
   (call $function57
    (struct.get $type40 1
     (ref.as_non_null
      (local.get $local16)
     )
    )
    (ref.as_non_null
     (local.get $local14)
    )
    (ref.as_non_null
     (local.get $local15)
    )
   )
  )
  (local.set $local17
   (i64.const 0)
  )
  (if (result (ref $type29))
   (i64.lt_s
    (local.get $local13)
    (local.get $local17)
   )
   (then
    (local.set $local7
     (local.get $argument212)
    )
    (local.set $local6
     (i32.eqz
      (local.get $local7)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $argument214)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $argument213)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (local.set $local8
     (call $function68
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local11)
       )
      )
      (ref.as_non_null
       (local.get $local9)
      )
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (return_call $function47
     (struct.get $type34 1
      (ref.as_non_null
       (local.get $local12)
      )
     )
     (local.get $local6)
     (ref.as_non_null
      (local.get $local8)
     )
    )
   )
   (else
    (local.set $local0
     (local.get $argument212)
    )
    (local.set $local2
     (ref.as_non_null
      (local.get $argument213)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (local.get $argument214)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (local.set $local1
     (call $function68
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (return_call $function47
     (struct.get $type34 1
      (ref.as_non_null
       (local.get $local5)
      )
     )
     (local.get $local0)
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
 )
 (func $function71 (type $call45) (param $environment eqref) (param $argument216 (ref $type29)) (param $argument217 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local2 i32)
  (local $local6 i32)
  (local $local11 i32)
  (local $local18 i32)
  (local $local1 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local13 (ref null $type14))
  (local $local14 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local4 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local7 (ref null $type29))
  (local $local12 (ref null $type29))
  (local $local19 (ref null $type29))
  (local $local20 (ref null $type29))
  (local $local21 (ref null $type29))
  (local $local10 (ref null $type44))
  (local $local16 (ref null $type43))
  (local $local17 (ref null $type34))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument216)
   )
  )
  (local.set $local1
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument217)
   )
  )
  (local.set $local3
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local2
   (i32.const 1)
  )
  (local.set $local21
   (ref.as_non_null
    (local.get $argument216)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (struct.get $type29 0
     (ref.as_non_null
      (local.get $local21)
     )
    )
    (then
     (local.set $local20
      (ref.as_non_null
       (local.get $argument217)
      )
     )
     (struct.get $type29 0
      (ref.as_non_null
       (local.get $local20)
      )
     )
    )
    (else
     (local.set $local19
      (ref.as_non_null
       (local.get $argument217)
      )
     )
     (local.set $local18
      (struct.get $type29 0
       (ref.as_non_null
        (local.get $local19)
       )
      )
     )
     (i32.eqz
      (local.get $local18)
     )
    )
   )
   (then
    (local.set $local12
     (ref.as_non_null
      (local.get $argument216)
     )
    )
    (local.set $local11
     (struct.get $type29 0
      (ref.as_non_null
       (local.get $local12)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.set $local16
     (ref.as_non_null
      (global.get $global193)
     )
    )
    (local.set $local13
     (call $function66
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local16)
       )
      )
      (ref.as_non_null
       (local.get $local14)
      )
      (ref.as_non_null
       (local.get $local15)
      )
     )
    )
    (local.set $local17
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (return_call $function47
     (struct.get $type34 1
      (ref.as_non_null
       (local.get $local17)
      )
     )
     (local.get $local11)
     (ref.as_non_null
      (local.get $local13)
     )
    )
   )
   (else
    (local.set $local7
     (ref.as_non_null
      (local.get $argument216)
     )
    )
    (local.set $local6
     (struct.get $type29 0
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (return_call $function70
     (struct.get $type44 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (local.get $local6)
     (ref.as_non_null
      (local.get $local8)
     )
     (ref.as_non_null
      (local.get $local9)
     )
    )
   )
  )
 )
 (func $function72 (type $call45) (param $environment eqref) (param $argument221 (ref $type29)) (param $argument222 (ref $type29)) (result (ref $type29))
  (local $local0 (ref null $type29))
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type36))
  (local $local4 (ref null $type45))
  (local.set $local0
   (ref.as_non_null
    (local.get $argument221)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument222)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (local.set $local1
   (call $function50
    (struct.get $type36 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (return_call $function71
   (struct.get $type45 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function73 (type $call46) (param $environment eqref) (param $argument224 (ref $type14)) (param $argument225 (ref $type14)) (param $argument226 i64) (param $argument227 i64) (result i32)
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local2 (ref null $type14))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument225)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local6
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local5)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local6)
  )
  (return_call $function74
   (ref.as_non_null
    (local.get $argument224)
   )
   (ref.as_non_null
    (local.get $argument225)
   )
   (local.get $argument226)
   (local.get $argument227)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local6)
   (local.get $local5)
   (local.get $local3)
   (local.get $local4)
  )
 )
 (func $function74 (param $capture224 (ref $type14)) (param $capture225 (ref $type14)) (param $capture226 i64) (param $capture227 i64) (param $capture228 i64) (param $capture229 i32) (param $initialized229 i32) (param $argument230 i64) (param $argument231 i64) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local15 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local27 i64)
  (local $local28 i64)
  (local $local31 i64)
  (local $local32 i64)
  (local $local33 i64)
  (local $local34 i64)
  (local $local36 i64)
  (local $local37 i64)
  (local $local10 (ref null $type14))
  (local $local14 (ref null $type14))
  (local $local24 (ref null $type14))
  (local $local30 (ref null $type14))
  (local $local12 (ref null $type30))
  (local $local16 (ref null $type30))
  (local $local29 (ref null $type31))
  (local $local35 (ref null $type31))
  (local.set $local36
   (local.get $argument230)
  )
  (local.set $local37
   (local.get $capture228)
  )
  (if (result i32)
   (i64.eq
    (local.get $local36)
    (local.get $local37)
   )
   (then
    (local.set $local30
     (ref.as_non_null
      (local.get $capture224)
     )
    )
    (local.set $local32
     (local.get $capture226)
    )
    (local.set $local33
     (local.get $capture228)
    )
    (local.set $local31
     (i64.add
      (local.get $local32)
      (local.get $local33)
     )
    )
    (local.set $local34
     (local.get $argument231)
    )
    (local.set $local35
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (return_call $function42
     (struct.get $type31 1
      (ref.as_non_null
       (local.get $local35)
      )
     )
     (ref.as_non_null
      (local.get $local30)
     )
     (local.get $local31)
     (local.get $local34)
    )
   )
   (else
    (local.set $local2
     (local.get $capture226)
    )
    (local.set $local3
     (local.get $argument230)
    )
    (local.set $local1
     (i64.add
      (local.get $local2)
      (local.get $local3)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local8
     (local.get $capture227)
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $capture225)
     )
    )
    (local.set $local11
     (local.get $argument230)
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local9
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local10)
      )
      (local.get $local11)
     )
    )
    (local.set $local7
     (i64.mul
      (local.get $local8)
      (local.get $local9)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (local.get $capture224)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (local.get $local1)
    )
    (local.set $local16
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local13
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local16)
       )
      )
      (ref.as_non_null
       (local.get $local14)
      )
      (local.get $local15)
     )
    )
    (local.set $local6
     (i64.add
      (local.get $local7)
      (local.get $local13)
     )
    )
    (local.set $local17
     (local.get $argument231)
    )
    (local.set $local5
     (i64.add
      (local.get $local6)
      (local.get $local17)
     )
    )
    (local.set $local4
     (i32.const 1)
    )
    (local.set $local24
     (ref.as_non_null
      (local.get $capture224)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local25
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local27
     (local.get $local5)
    )
    (local.set $local28
     (i64.const 1073741824)
    )
    (local.set $local26
     (i64.rem_s
      (local.get $local27)
      (local.get $local28)
     )
    )
    (local.set $local29
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local29)
       )
      )
      (ref.as_non_null
       (local.get $local24)
      )
      (local.get $local25)
      (local.get $local26)
     )
    )
    (local.set $local19
     (local.get $argument230)
    )
    (local.set $local20
     (i64.const 1)
    )
    (local.set $local18
     (i64.add
      (local.get $local19)
      (local.get $local20)
     )
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local22
     (local.get $local5)
    )
    (local.set $local23
     (i64.const 1073741824)
    )
    (local.set $local21
     (i64.div_s
      (local.get $local22)
      (local.get $local23)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized229)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture229)
    )
    (return_call $function74
     (ref.as_non_null
      (local.get $capture224)
     )
     (ref.as_non_null
      (local.get $capture225)
     )
     (local.get $capture226)
     (local.get $capture227)
     (local.get $capture228)
     (local.get $capture229)
     (local.get $initialized229)
     (local.get $local18)
     (local.get $local21)
    )
   )
  )
 )
 (func $function75 (type $call43) (param $environment eqref) (param $argument235 (ref $type14)) (param $argument236 (ref $type14)) (result (ref $type14))
  (local $local0 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local8 i64)
  (local $local1 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local7 (ref null $type32))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument235)
   )
  )
  (local.set $local3
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $argument236)
   )
  )
  (local.set $local5
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
  )
  (local.set $local2
   (i64.add
    (local.get $local3)
    (local.get $local5)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local1
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local8
   (i64.const 0)
  )
  (local.set $local10
   (i32.const 0)
  )
  (local.set $local9
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local10)
  )
  (return_call $function76
   (ref.as_non_null
    (local.get $argument235)
   )
   (ref.as_non_null
    (local.get $argument236)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
   (local.get $local10)
   (local.get $local9)
   (local.get $local8)
  )
 )
 (func $function76 (param $capture235 (ref $type14)) (param $capture236 (ref $type14)) (param $capture237 (ref $type14)) (param $capture238 i32) (param $initialized238 i32) (param $argument239 i64) (result (ref $type14))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local3 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local7 (ref null $type14))
  (local $local13 (ref null $type14))
  (local $local9 (ref null $type30))
  (local $local10 (ref null $type46))
  (local.set $local11
   (local.get $argument239)
  )
  (local.set $local13
   (ref.as_non_null
    (local.get $capture235)
   )
  )
  (local.set $local12
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local13)
     )
    )
   )
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $local11)
    (local.get $local12)
   )
   (then
    (ref.as_non_null
     (local.get $capture237)
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture237)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (local.get $capture236)
     )
    )
    (local.set $local5
     (local.get $argument239)
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $capture235)
     )
    )
    (local.set $local8
     (local.get $argument239)
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local6
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (ref.as_non_null
       (local.get $local7)
      )
      (local.get $local8)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global223)
     )
    )
    (drop
     (call $function73
      (struct.get $type46 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (local.get $local5)
      (local.get $local6)
     )
    )
    (local.set $local1
     (local.get $argument239)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized238)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture238)
    )
    (return_call $function76
     (ref.as_non_null
      (local.get $capture235)
     )
     (ref.as_non_null
      (local.get $capture236)
     )
     (ref.as_non_null
      (local.get $capture237)
     )
     (local.get $capture238)
     (local.get $initialized238)
     (local.get $local0)
    )
   )
  )
 )
 (func $function77 (type $call45) (param $environment eqref) (param $argument241 (ref $type29)) (param $argument242 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local2 i32)
  (local $local12 i32)
  (local $local13 i32)
  (local $local1 (ref null $type29))
  (local $local3 (ref null $type29))
  (local $local4 (ref null $type29))
  (local $local7 (ref null $type29))
  (local $local9 (ref null $type29))
  (local $local14 (ref null $type29))
  (local $local16 (ref null $type29))
  (local $local5 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local10 (ref null $type43))
  (local $local11 (ref null $type34))
  (local $local15 (ref null $type35))
  (local $local17 (ref null $type35))
  (local.set $local14
   (ref.as_non_null
    (local.get $argument241)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (local.set $local13
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (ref.as_non_null
     (local.get $local14)
    )
   )
  )
  (local.set $local12
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local12)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (local.get $local13)
    (then
     (if
      (i32.eqz
       (local.get $local12)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local13)
    )
    (else
     (local.set $local16
      (ref.as_non_null
       (local.get $argument242)
      )
     )
     (local.set $local17
      (ref.as_non_null
       (global.get $global134)
      )
     )
     (call $function48
      (struct.get $type35 1
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (ref.as_non_null
       (local.get $local16)
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global111)
    )
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $argument241)
     )
    )
    (local.set $local0
     (if (result i32)
      (struct.get $type29 0
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (then
       (local.set $local3
        (ref.as_non_null
         (local.get $argument242)
        )
       )
       (local.set $local2
        (struct.get $type29 0
         (ref.as_non_null
          (local.get $local3)
         )
        )
       )
       (i32.eqz
        (local.get $local2)
       )
      )
      (else
       (local.set $local1
        (ref.as_non_null
         (local.get $argument242)
        )
       )
       (struct.get $type29 0
        (ref.as_non_null
         (local.get $local1)
        )
       )
      )
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument241)
     )
    )
    (local.set $local6
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $argument242)
     )
    )
    (local.set $local8
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local9)
      )
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global234)
     )
    )
    (local.set $local5
     (call $function75
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (ref.as_non_null
       (local.get $local6)
      )
      (ref.as_non_null
       (local.get $local8)
      )
     )
    )
    (local.set $local11
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (return_call $function47
     (struct.get $type34 1
      (ref.as_non_null
       (local.get $local11)
      )
     )
     (local.get $local0)
     (ref.as_non_null
      (local.get $local5)
     )
    )
   )
  )
 )
 (func $function78 (type $call47) (param $environment eqref) (param $argument245 (ref $type14)) (param $argument246 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local3 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local1 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local2 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local8 (ref null $type32))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument245)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local7
   (i64.const 1)
  )
  (local.set $local5
   (i64.add
    (local.get $local6)
    (local.get $local7)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local4
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (local.get $local5)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (local.set $local9
   (i64.const 0)
  )
  (local.set $local10
   (i64.const 0)
  )
  (local.set $local12
   (i32.const 0)
  )
  (local.set $local11
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local12)
  )
  (return_call $function79
   (ref.as_non_null
    (local.get $argument245)
   )
   (local.get $argument246)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (local.get $local12)
   (local.get $local11)
   (local.get $local9)
   (local.get $local10)
  )
 )
 (func $function79 (param $capture245 (ref $type14)) (param $capture246 i64) (param $capture247 i64) (param $capture248 (ref $type14)) (param $capture249 i32) (param $initialized249 i32) (param $argument250 i64) (param $argument251 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local4 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local21 (ref null $type14))
  (local $local6 (ref null $type30))
  (local $local20 (ref null $type31))
  (local $local24 (ref null $type31))
  (local.set $local25
   (local.get $argument250)
  )
  (local.set $local26
   (local.get $capture247)
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $local25)
    (local.get $local26)
   )
   (then
    (local.set $local21
     (ref.as_non_null
      (local.get $capture248)
     )
    )
    (local.set $local22
     (local.get $capture247)
    )
    (local.set $local23
     (local.get $argument251)
    )
    (local.set $local24
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local24)
       )
      )
      (ref.as_non_null
       (local.get $local21)
      )
      (local.get $local22)
      (local.get $local23)
     )
    )
    (ref.as_non_null
     (local.get $capture248)
    )
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture245)
     )
    )
    (local.set $local5
     (local.get $argument250)
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local3
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (local.get $local5)
     )
    )
    (local.set $local7
     (local.get $capture246)
    )
    (local.set $local2
     (i64.mul
      (local.get $local3)
      (local.get $local7)
     )
    )
    (local.set $local8
     (local.get $argument251)
    )
    (local.set $local1
     (i64.add
      (local.get $local2)
      (local.get $local8)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local15
     (ref.as_non_null
      (local.get $capture248)
     )
    )
    (local.set $local16
     (local.get $argument250)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local1)
    )
    (local.set $local19
     (i64.const 1073741824)
    )
    (local.set $local17
     (i64.rem_s
      (local.get $local18)
      (local.get $local19)
     )
    )
    (local.set $local20
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local20)
       )
      )
      (ref.as_non_null
       (local.get $local15)
      )
      (local.get $local16)
      (local.get $local17)
     )
    )
    (local.set $local10
     (local.get $argument250)
    )
    (local.set $local11
     (i64.const 1)
    )
    (local.set $local9
     (i64.add
      (local.get $local10)
      (local.get $local11)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (local.get $local1)
    )
    (local.set $local14
     (i64.const 1073741824)
    )
    (local.set $local12
     (i64.div_s
      (local.get $local13)
      (local.get $local14)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized249)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture249)
    )
    (return_call $function79
     (ref.as_non_null
      (local.get $capture245)
     )
     (local.get $capture246)
     (local.get $capture247)
     (ref.as_non_null
      (local.get $capture248)
     )
     (local.get $capture249)
     (local.get $initialized249)
     (local.get $local9)
     (local.get $local12)
    )
   )
  )
 )
 (func $function80 (type $call48) (param $environment eqref) (param $argument254 (ref $type14)) (param $argument255 (ref $type14)) (param $argument256 i64) (result i64)
  (local $local0 i64)
  (local $local2 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local $local1 (ref null $type14))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument255)
   )
  )
  (local.set $local0
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local2
   (i64.const 0)
  )
  (local.set $local4
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local4)
  )
  (return_call $function81
   (ref.as_non_null
    (local.get $argument254)
   )
   (ref.as_non_null
    (local.get $argument255)
   )
   (local.get $argument256)
   (local.get $local4)
   (local.get $local3)
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function81 (param $capture254 (ref $type14)) (param $capture255 (ref $type14)) (param $capture256 i64) (param $capture257 i32) (param $initialized257 i32) (param $argument258 i64) (param $argument259 i64) (result i64)
  (local $local0 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local6 (ref null $type14))
  (local $local17 (ref null $type14))
  (local $local10 (ref null $type30))
  (local $local24 (ref null $type31))
  (local.set $local25
   (local.get $argument258)
  )
  (local.set $local26
   (i64.const 0)
  )
  (if (result i64)
   (i64.eq
    (local.get $local25)
    (local.get $local26)
   )
   (then
    (local.get $argument259)
   )
   (else
    (local.set $local3
     (local.get $argument259)
    )
    (local.set $local4
     (i64.const 1073741824)
    )
    (local.set $local2
     (i64.mul
      (local.get $local3)
      (local.get $local4)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $capture255)
     )
    )
    (local.set $local8
     (local.get $argument258)
    )
    (local.set $local9
     (i64.const 1)
    )
    (local.set $local7
     (i64.sub
      (local.get $local8)
      (local.get $local9)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local5
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (ref.as_non_null
       (local.get $local6)
      )
      (local.get $local7)
     )
    )
    (local.set $local1
     (i64.add
      (local.get $local2)
      (local.get $local5)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local17
     (ref.as_non_null
      (local.get $capture254)
     )
    )
    (local.set $local19
     (local.get $argument258)
    )
    (local.set $local20
     (i64.const 1)
    )
    (local.set $local18
     (i64.sub
      (local.get $local19)
      (local.get $local20)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local22
     (local.get $local1)
    )
    (local.set $local23
     (local.get $capture256)
    )
    (local.set $local21
     (i64.div_s
      (local.get $local22)
      (local.get $local23)
     )
    )
    (local.set $local24
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local24)
       )
      )
      (ref.as_non_null
       (local.get $local17)
      )
      (local.get $local18)
      (local.get $local21)
     )
    )
    (local.set $local12
     (local.get $argument258)
    )
    (local.set $local13
     (i64.const 1)
    )
    (local.set $local11
     (i64.sub
      (local.get $local12)
      (local.get $local13)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (local.get $local1)
    )
    (local.set $local16
     (local.get $capture256)
    )
    (local.set $local14
     (i64.rem_s
      (local.get $local15)
      (local.get $local16)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized257)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture257)
    )
    (return_call $function81
     (ref.as_non_null
      (local.get $capture254)
     )
     (ref.as_non_null
      (local.get $capture255)
     )
     (local.get $capture256)
     (local.get $capture257)
     (local.get $initialized257)
     (local.get $local11)
     (local.get $local14)
    )
   )
  )
 )
 (func $function82 (type $call48) (param $environment eqref) (param $argument262 (ref $type14)) (param $argument263 (ref $type14)) (param $argument264 i64) (result i64)
  (local $local0 i32)
  (local $local3 i32)
  (local $local10 i32)
  (local $local28 i32)
  (local $local32 i32)
  (local $local44 i32)
  (local $local45 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local29 i64)
  (local $local30 i64)
  (local $local31 i64)
  (local $local33 i64)
  (local $local34 i64)
  (local $local35 i64)
  (local $local36 i64)
  (local $local37 i64)
  (local $local38 i64)
  (local $local39 i64)
  (local $local40 i64)
  (local $local41 i64)
  (local $local42 i64)
  (local $local43 i64)
  (local $local2 (ref null $type14))
  (local $local5 (ref null $type14))
  (local $local14 (ref null $type14))
  (local $local21 (ref null $type14))
  (local $local9 (ref null $type30))
  (local $local18 (ref null $type30))
  (local $local27 (ref null $type30))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument263)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument263)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (local.get $local1)
  )
  (local.set $local8
   (i64.const 1)
  )
  (local.set $local6
   (i64.sub
    (local.get $local7)
    (local.get $local8)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (local.set $local4
   (call $function41
    (struct.get $type30 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local5)
    )
    (local.get $local6)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (local.set $local14
   (ref.as_non_null
    (local.get $argument262)
   )
  )
  (local.set $local16
   (local.get $argument264)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (local.get $local1)
  )
  (local.set $local15
   (i64.add
    (local.get $local16)
    (local.get $local17)
   )
  )
  (local.set $local18
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (local.set $local13
   (call $function41
    (struct.get $type30 1
     (ref.as_non_null
      (local.get $local18)
     )
    )
    (ref.as_non_null
     (local.get $local14)
    )
    (local.get $local15)
   )
  )
  (local.set $local19
   (i64.const 1073741824)
  )
  (local.set $local12
   (i64.mul
    (local.get $local13)
    (local.get $local19)
   )
  )
  (local.set $local21
   (ref.as_non_null
    (local.get $argument262)
   )
  )
  (local.set $local24
   (local.get $argument264)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local25
   (local.get $local1)
  )
  (local.set $local23
   (i64.add
    (local.get $local24)
    (local.get $local25)
   )
  )
  (local.set $local26
   (i64.const 1)
  )
  (local.set $local22
   (i64.sub
    (local.get $local23)
    (local.get $local26)
   )
  )
  (local.set $local27
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (local.set $local20
   (call $function41
    (struct.get $type30 1
     (ref.as_non_null
      (local.get $local27)
     )
    )
    (ref.as_non_null
     (local.get $local21)
    )
    (local.get $local22)
   )
  )
  (local.set $local11
   (i64.add
    (local.get $local12)
    (local.get $local20)
   )
  )
  (local.set $local10
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local10)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local30
   (local.get $local11)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local31
   (local.get $local4)
  )
  (local.set $local29
   (i64.div_s
    (local.get $local30)
    (local.get $local31)
   )
  )
  (local.set $local28
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local28)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local36
   (local.get $local29)
  )
  (local.set $local37
   (i64.const 1073741824)
  )
  (local.set $local33
   (if (result i64)
    (i64.ge_s
     (local.get $local36)
     (local.get $local37)
    )
    (then
     (local.set $local34
      (i64.const 1073741824)
     )
     (local.set $local35
      (i64.const 1)
     )
     (i64.sub
      (local.get $local34)
      (local.get $local35)
     )
    )
    (else
     (if
      (i32.eqz
       (local.get $local28)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local29)
    )
   )
  )
  (local.set $local32
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local32)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local38
   (local.get $local33)
  )
  (if
   (i32.eqz
    (local.get $local10)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local40
   (local.get $local11)
  )
  (if
   (i32.eqz
    (local.get $local32)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local42
   (local.get $local33)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local43
   (local.get $local4)
  )
  (local.set $local41
   (i64.mul
    (local.get $local42)
    (local.get $local43)
   )
  )
  (local.set $local39
   (i64.sub
    (local.get $local40)
    (local.get $local41)
   )
  )
  (drop
   (i32.const 0)
  )
  (local.set $local45
   (i32.const 0)
  )
  (local.set $local44
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local44)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local45)
  )
  (return_call $function83
   (ref.as_non_null
    (local.get $argument262)
   )
   (ref.as_non_null
    (local.get $argument263)
   )
   (local.get $argument264)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local4)
   )
   (local.get $local45)
   (local.get $local44)
   (local.get $local38)
   (local.get $local39)
  )
 )
 (func $function83 (param $capture262 (ref $type14)) (param $capture263 (ref $type14)) (param $capture264 i64) (param $capture265 i64) (param $capture266 i64) (param $capture270 i32) (param $initialized270 i32) (param $argument271 i64) (param $argument272 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local26 i64)
  (local $local27 i64)
  (local $local9 (ref null $type14))
  (local $local19 (ref null $type14))
  (local $local13 (ref null $type30))
  (local $local25 (ref null $type30))
  (local.set $local26
   (local.get $argument272)
  )
  (local.set $local27
   (i64.const 1073741824)
  )
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $local26)
     (local.get $local27)
    )
    (then
     (local.set $local7
      (local.get $argument271)
     )
     (local.set $local9
      (ref.as_non_null
       (local.get $capture263)
      )
     )
     (local.set $local11
      (local.get $capture265)
     )
     (local.set $local12
      (i64.const 2)
     )
     (local.set $local10
      (i64.sub
       (local.get $local11)
       (local.get $local12)
      )
     )
     (local.set $local13
      (ref.as_non_null
       (global.get $global112)
      )
     )
     (local.set $local8
      (call $function41
       (struct.get $type30 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
       (ref.as_non_null
        (local.get $local9)
       )
       (local.get $local10)
      )
     )
     (local.set $local6
      (i64.mul
       (local.get $local7)
       (local.get $local8)
      )
     )
     (local.set $local16
      (local.get $argument272)
     )
     (local.set $local17
      (i64.const 1073741824)
     )
     (local.set $local15
      (i64.mul
       (local.get $local16)
       (local.get $local17)
      )
     )
     (local.set $local19
      (ref.as_non_null
       (local.get $capture262)
      )
     )
     (local.set $local22
      (local.get $capture264)
     )
     (local.set $local23
      (local.get $capture265)
     )
     (local.set $local21
      (i64.add
       (local.get $local22)
       (local.get $local23)
      )
     )
     (local.set $local24
      (i64.const 2)
     )
     (local.set $local20
      (i64.sub
       (local.get $local21)
       (local.get $local24)
      )
     )
     (local.set $local25
      (ref.as_non_null
       (global.get $global112)
      )
     )
     (local.set $local18
      (call $function41
       (struct.get $type30 1
        (ref.as_non_null
         (local.get $local25)
        )
       )
       (ref.as_non_null
        (local.get $local19)
       )
       (local.get $local20)
      )
     )
     (local.set $local14
      (i64.add
       (local.get $local15)
       (local.get $local18)
      )
     )
     (i64.gt_s
      (local.get $local6)
      (local.get $local14)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $local1
     (local.get $argument271)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument272)
    )
    (local.set $local5
     (local.get $capture266)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized270)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture270)
    )
    (return_call $function83
     (ref.as_non_null
      (local.get $capture262)
     )
     (ref.as_non_null
      (local.get $capture263)
     )
     (local.get $capture264)
     (local.get $capture265)
     (local.get $capture266)
     (local.get $capture270)
     (local.get $initialized270)
     (local.get $local0)
     (local.get $local3)
    )
   )
   (else
    (local.get $argument271)
   )
  )
 )
 (func $function84 (type $call49) (param $environment eqref) (param $argument274 (ref $type14)) (param $argument275 (ref $type14)) (param $argument276 i64) (param $argument277 i64) (result i32)
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local2 (ref null $type14))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument275)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local6
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local5)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local6)
  )
  (return_call $function85
   (ref.as_non_null
    (local.get $argument274)
   )
   (ref.as_non_null
    (local.get $argument275)
   )
   (local.get $argument276)
   (local.get $argument277)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local6)
   (local.get $local5)
   (local.get $local3)
   (local.get $local4)
  )
 )
 (func $function85 (param $capture274 (ref $type14)) (param $capture275 (ref $type14)) (param $capture276 i64) (param $capture277 i64) (param $capture278 i64) (param $capture279 i32) (param $initialized279 i32) (param $argument280 i64) (param $argument281 i64) (result i32)
  (local $local0 i32)
  (local $local9 i32)
  (local $local40 i32)
  (local $local61 i32)
  (local $local62 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local27 i64)
  (local $local28 i64)
  (local $local29 i64)
  (local $local31 i64)
  (local $local32 i64)
  (local $local33 i64)
  (local $local34 i64)
  (local $local35 i64)
  (local $local36 i64)
  (local $local37 i64)
  (local $local38 i64)
  (local $local41 i64)
  (local $local42 i64)
  (local $local44 i64)
  (local $local45 i64)
  (local $local46 i64)
  (local $local48 i64)
  (local $local49 i64)
  (local $local50 i64)
  (local $local52 i64)
  (local $local53 i64)
  (local $local54 i64)
  (local $local55 i64)
  (local $local56 i64)
  (local $local57 i64)
  (local $local58 i64)
  (local $local59 i64)
  (local $local63 i64)
  (local $local64 i64)
  (local $local65 i64)
  (local $local66 i64)
  (local $local67 i64)
  (local $local68 i64)
  (local $local5 (ref null $type14))
  (local $local12 (ref null $type14))
  (local $local30 (ref null $type14))
  (local $local43 (ref null $type14))
  (local $local51 (ref null $type14))
  (local $local7 (ref null $type30))
  (local $local16 (ref null $type30))
  (local $local47 (ref null $type30))
  (local $local39 (ref null $type31))
  (local $local60 (ref null $type31))
  (local.set $local67
   (local.get $argument280)
  )
  (local.set $local68
   (local.get $capture278)
  )
  (if (result i32)
   (i64.eq
    (local.get $local67)
    (local.get $local68)
   )
   (then
    (local.set $local43
     (ref.as_non_null
      (local.get $capture274)
     )
    )
    (local.set $local45
     (local.get $capture276)
    )
    (local.set $local46
     (local.get $capture278)
    )
    (local.set $local44
     (i64.add
      (local.get $local45)
      (local.get $local46)
     )
    )
    (local.set $local47
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local42
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local47)
       )
      )
      (ref.as_non_null
       (local.get $local43)
      )
      (local.get $local44)
     )
    )
    (local.set $local48
     (local.get $argument281)
    )
    (local.set $local41
     (i64.sub
      (local.get $local42)
      (local.get $local48)
     )
    )
    (local.set $local40
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local40)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local63
     (local.get $local41)
    )
    (local.set $local64
     (i64.const -1)
    )
    (local.set $local62
     (i64.lt_s
      (local.get $local63)
      (local.get $local64)
     )
    )
    (local.set $local61
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (if (result i32)
       (local.get $local62)
       (then
        (if
         (i32.eqz
          (local.get $local61)
         )
         (then
          (unreachable)
         )
        )
        (local.get $local62)
       )
       (else
        (if
         (i32.eqz
          (local.get $local40)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local65
         (local.get $local41)
        )
        (local.set $local66
         (i64.const 0)
        )
        (i64.gt_s
         (local.get $local65)
         (local.get $local66)
        )
       )
      )
      (then
       (unreachable)
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $local51
     (ref.as_non_null
      (local.get $capture274)
     )
    )
    (local.set $local53
     (local.get $capture276)
    )
    (local.set $local54
     (local.get $capture278)
    )
    (local.set $local52
     (i64.add
      (local.get $local53)
      (local.get $local54)
     )
    )
    (if
     (i32.eqz
      (local.get $local40)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local58
     (local.get $local41)
    )
    (local.set $local59
     (i64.const 0)
    )
    (local.set $local55
     (if (result i64)
      (i64.lt_s
       (local.get $local58)
       (local.get $local59)
      )
      (then
       (if
        (i32.eqz
         (local.get $local40)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local56
        (local.get $local41)
       )
       (local.set $local57
        (i64.const 1073741824)
       )
       (i64.add
        (local.get $local56)
        (local.get $local57)
       )
      )
      (else
       (if
        (i32.eqz
         (local.get $local40)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local41)
      )
     )
    )
    (local.set $local60
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local60)
       )
      )
      (ref.as_non_null
       (local.get $local51)
      )
      (local.get $local52)
      (local.get $local55)
     )
    )
    (if
     (i32.eqz
      (local.get $local40)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local49
     (local.get $local41)
    )
    (local.set $local50
     (i64.const 0)
    )
    (i64.lt_s
     (local.get $local49)
     (local.get $local50)
    )
   )
   (else
    (local.set $local3
     (local.get $capture277)
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $capture275)
     )
    )
    (local.set $local6
     (local.get $argument280)
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local4
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local7)
       )
      )
      (ref.as_non_null
       (local.get $local5)
      )
      (local.get $local6)
     )
    )
    (local.set $local2
     (i64.mul
      (local.get $local3)
      (local.get $local4)
     )
    )
    (local.set $local8
     (local.get $argument281)
    )
    (local.set $local1
     (i64.add
      (local.get $local2)
      (local.get $local8)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $capture274)
     )
    )
    (local.set $local14
     (local.get $capture276)
    )
    (local.set $local15
     (local.get $argument280)
    )
    (local.set $local13
     (i64.add
      (local.get $local14)
      (local.get $local15)
     )
    )
    (local.set $local16
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local11
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local16)
       )
      )
      (ref.as_non_null
       (local.get $local12)
      )
      (local.get $local13)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local1)
    )
    (local.set $local19
     (i64.const 1073741824)
    )
    (local.set $local17
     (i64.rem_s
      (local.get $local18)
      (local.get $local19)
     )
    )
    (local.set $local10
     (i64.sub
      (local.get $local11)
      (local.get $local17)
     )
    )
    (local.set $local9
     (i32.const 1)
    )
    (local.set $local30
     (ref.as_non_null
      (local.get $capture274)
     )
    )
    (local.set $local32
     (local.get $capture276)
    )
    (local.set $local33
     (local.get $argument280)
    )
    (local.set $local31
     (i64.add
      (local.get $local32)
      (local.get $local33)
     )
    )
    (if
     (i32.eqz
      (local.get $local9)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local37
     (local.get $local10)
    )
    (local.set $local38
     (i64.const 0)
    )
    (local.set $local34
     (if (result i64)
      (i64.lt_s
       (local.get $local37)
       (local.get $local38)
      )
      (then
       (if
        (i32.eqz
         (local.get $local9)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local35
        (local.get $local10)
       )
       (local.set $local36
        (i64.const 1073741824)
       )
       (i64.add
        (local.get $local35)
        (local.get $local36)
       )
      )
      (else
       (if
        (i32.eqz
         (local.get $local9)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local10)
      )
     )
    )
    (local.set $local39
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local39)
       )
      )
      (ref.as_non_null
       (local.get $local30)
      )
      (local.get $local31)
      (local.get $local34)
     )
    )
    (local.set $local21
     (local.get $argument280)
    )
    (local.set $local22
     (i64.const 1)
    )
    (local.set $local20
     (i64.add
      (local.get $local21)
      (local.get $local22)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local25
     (local.get $local1)
    )
    (local.set $local26
     (i64.const 1073741824)
    )
    (local.set $local24
     (i64.div_s
      (local.get $local25)
      (local.get $local26)
     )
    )
    (if
     (i32.eqz
      (local.get $local9)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local28
     (local.get $local10)
    )
    (local.set $local29
     (i64.const 0)
    )
    (local.set $local27
     (if (result i64)
      (i64.lt_s
       (local.get $local28)
       (local.get $local29)
      )
      (then
       (i64.const 1)
      )
      (else
       (i64.const 0)
      )
     )
    )
    (local.set $local23
     (i64.add
      (local.get $local24)
      (local.get $local27)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized279)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture279)
    )
    (return_call $function85
     (ref.as_non_null
      (local.get $capture274)
     )
     (ref.as_non_null
      (local.get $capture275)
     )
     (local.get $capture276)
     (local.get $capture277)
     (local.get $capture278)
     (local.get $capture279)
     (local.get $initialized279)
     (local.get $local20)
     (local.get $local23)
    )
   )
  )
 )
 (func $function86 (type $call50) (param $environment eqref) (param $argument287 (ref $type14)) (param $argument288 (ref $type14)) (param $argument289 i64) (result i32)
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local2 (ref null $type14))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument288)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local6
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local5)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local6)
  )
  (return_call $function87
   (ref.as_non_null
    (local.get $argument287)
   )
   (ref.as_non_null
    (local.get $argument288)
   )
   (local.get $argument289)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local6)
   (local.get $local5)
   (local.get $local3)
   (local.get $local4)
  )
 )
 (func $function87 (param $capture287 (ref $type14)) (param $capture288 (ref $type14)) (param $capture289 i64) (param $capture290 i64) (param $capture291 i32) (param $initialized291 i32) (param $argument292 i64) (param $argument293 i64) (result i32)
  (local $local0 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local29 i64)
  (local $local30 i64)
  (local $local31 i64)
  (local $local32 i64)
  (local $local33 i64)
  (local $local34 i64)
  (local $local36 i64)
  (local $local37 i64)
  (local $local38 i64)
  (local $local40 i64)
  (local $local41 i64)
  (local $local43 i64)
  (local $local44 i64)
  (local $local4 (ref null $type14))
  (local $local10 (ref null $type14))
  (local $local20 (ref null $type14))
  (local $local28 (ref null $type14))
  (local $local35 (ref null $type14))
  (local $local8 (ref null $type30))
  (local $local12 (ref null $type30))
  (local $local39 (ref null $type30))
  (local $local27 (ref null $type31))
  (local $local42 (ref null $type31))
  (local.set $local43
   (local.get $argument292)
  )
  (local.set $local44
   (local.get $capture290)
  )
  (if (result i32)
   (i64.eq
    (local.get $local43)
    (local.get $local44)
   )
   (then
    (local.set $local28
     (ref.as_non_null
      (local.get $capture287)
     )
    )
    (local.set $local30
     (local.get $capture289)
    )
    (local.set $local31
     (local.get $capture290)
    )
    (local.set $local29
     (i64.add
      (local.get $local30)
      (local.get $local31)
     )
    )
    (local.set $local35
     (ref.as_non_null
      (local.get $capture287)
     )
    )
    (local.set $local37
     (local.get $capture289)
    )
    (local.set $local38
     (local.get $capture290)
    )
    (local.set $local36
     (i64.add
      (local.get $local37)
      (local.get $local38)
     )
    )
    (local.set $local39
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local34
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local39)
       )
      )
      (ref.as_non_null
       (local.get $local35)
      )
      (local.get $local36)
     )
    )
    (local.set $local40
     (local.get $argument293)
    )
    (local.set $local33
     (i64.add
      (local.get $local34)
      (local.get $local40)
     )
    )
    (local.set $local41
     (i64.const 1073741824)
    )
    (local.set $local32
     (i64.rem_s
      (local.get $local33)
      (local.get $local41)
     )
    )
    (local.set $local42
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (return_call $function42
     (struct.get $type31 1
      (ref.as_non_null
       (local.get $local42)
      )
     )
     (ref.as_non_null
      (local.get $local28)
     )
     (local.get $local29)
     (local.get $local32)
    )
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture287)
     )
    )
    (local.set $local6
     (local.get $capture289)
    )
    (local.set $local7
     (local.get $argument292)
    )
    (local.set $local5
     (i64.add
      (local.get $local6)
      (local.get $local7)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local3
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (local.get $local5)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $capture288)
     )
    )
    (local.set $local11
     (local.get $argument292)
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local9
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local10)
      )
      (local.get $local11)
     )
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local9)
     )
    )
    (local.set $local13
     (local.get $argument293)
    )
    (local.set $local1
     (i64.add
      (local.get $local2)
      (local.get $local13)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local20
     (ref.as_non_null
      (local.get $capture287)
     )
    )
    (local.set $local22
     (local.get $capture289)
    )
    (local.set $local23
     (local.get $argument292)
    )
    (local.set $local21
     (i64.add
      (local.get $local22)
      (local.get $local23)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local25
     (local.get $local1)
    )
    (local.set $local26
     (i64.const 1073741824)
    )
    (local.set $local24
     (i64.rem_s
      (local.get $local25)
      (local.get $local26)
     )
    )
    (local.set $local27
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local27)
       )
      )
      (ref.as_non_null
       (local.get $local20)
      )
      (local.get $local21)
      (local.get $local24)
     )
    )
    (local.set $local15
     (local.get $argument292)
    )
    (local.set $local16
     (i64.const 1)
    )
    (local.set $local14
     (i64.add
      (local.get $local15)
      (local.get $local16)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local1)
    )
    (local.set $local19
     (i64.const 1073741824)
    )
    (local.set $local17
     (i64.div_s
      (local.get $local18)
      (local.get $local19)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized291)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture291)
    )
    (return_call $function87
     (ref.as_non_null
      (local.get $capture287)
     )
     (ref.as_non_null
      (local.get $capture288)
     )
     (local.get $capture289)
     (local.get $capture290)
     (local.get $capture291)
     (local.get $initialized291)
     (local.get $local14)
     (local.get $local17)
    )
   )
  )
 )
 (func $function88 (type $call48) (param $environment eqref) (param $argument296 (ref $type14)) (param $argument297 (ref $type14)) (param $argument298 i64) (result i64)
  (local $local0 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local12 (ref null $type14))
  (local $local13 (ref null $type14))
  (local $local5 (ref null $type48))
  (local $local11 (ref null $type50))
  (local $local16 (ref null $type49))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument296)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (local.get $argument297)
   )
  )
  (local.set $local4
   (local.get $argument298)
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global261)
   )
  )
  (local.set $local1
   (call $function82
    (struct.get $type48 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
    (ref.as_non_null
     (local.get $local3)
    )
    (local.get $local4)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local12
   (ref.as_non_null
    (local.get $argument296)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (local.get $argument297)
   )
  )
  (local.set $local14
   (local.get $argument298)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (local.get $local1)
  )
  (local.set $local16
   (ref.as_non_null
    (global.get $global273)
   )
  )
  (if (result i64)
   (call $function84
    (struct.get $type49 1
     (ref.as_non_null
      (local.get $local16)
     )
    )
    (ref.as_non_null
     (local.get $local12)
    )
    (ref.as_non_null
     (local.get $local13)
    )
    (local.get $local14)
    (local.get $local15)
   )
   (then
    (local.set $local8
     (ref.as_non_null
      (local.get $argument296)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $argument297)
     )
    )
    (local.set $local10
     (local.get $argument298)
    )
    (local.set $local11
     (ref.as_non_null
      (global.get $global286)
     )
    )
    (drop
     (call $function86
      (struct.get $type50 1
       (ref.as_non_null
        (local.get $local11)
       )
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (ref.as_non_null
       (local.get $local9)
      )
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (local.get $local1)
    )
    (local.set $local7
     (i64.const 1)
    )
    (i64.sub
     (local.get $local6)
     (local.get $local7)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
  )
 )
 (func $function89 (type $call51) (param $environment eqref) (param $argument301 (ref $type14)) (param $argument302 (ref $type14)) (param $argument303 (ref $type14)) (result i32)
  (local $local0 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local $local1 (ref null $type14))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument301)
   )
  )
  (local.set $local0
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function90
   (ref.as_non_null
    (local.get $argument301)
   )
   (ref.as_non_null
    (local.get $argument302)
   )
   (ref.as_non_null
    (local.get $argument303)
   )
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
  )
 )
 (func $function90 (param $capture301 (ref $type14)) (param $capture302 (ref $type14)) (param $capture303 (ref $type14)) (param $capture304 i32) (param $initialized304 i32) (param $argument305 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local3 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local13 (ref null $type48))
  (local $local14 (ref null $type31))
  (local.set $local15
   (local.get $argument305)
  )
  (local.set $local16
   (i64.const 0)
  )
  (if (result i32)
   (i64.eq
    (local.get $local15)
    (local.get $local16)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture301)
     )
    )
    (local.set $local5
     (local.get $argument305)
    )
    (local.set $local6
     (i64.const 1)
    )
    (local.set $local4
     (i64.sub
      (local.get $local5)
      (local.get $local6)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $capture302)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $capture303)
     )
    )
    (local.set $local11
     (local.get $argument305)
    )
    (local.set $local12
     (i64.const 1)
    )
    (local.set $local10
     (i64.sub
      (local.get $local11)
      (local.get $local12)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global295)
     )
    )
    (local.set $local7
     (call $function88
      (struct.get $type48 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (ref.as_non_null
       (local.get $local9)
      )
      (local.get $local10)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function42
      (struct.get $type31 1
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (local.get $local4)
      (local.get $local7)
     )
    )
    (local.set $local1
     (local.get $argument305)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized304)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture304)
    )
    (return_call $function90
     (ref.as_non_null
      (local.get $capture301)
     )
     (ref.as_non_null
      (local.get $capture302)
     )
     (ref.as_non_null
      (local.get $capture303)
     )
     (local.get $capture304)
     (local.get $initialized304)
     (local.get $local0)
    )
   )
  )
 )
 (func $function91 (type $call52) (param $environment eqref) (param $argument307 (ref $type14)) (param $argument308 (ref $type14)) (result (ref $type53))
  (local $local0 i32)
  (local $local3 i32)
  (local $local14 i32)
  (local $local19 i32)
  (local $local26 i32)
  (local $local35 i32)
  (local $local40 i32)
  (local $local44 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local17 i64)
  (local $local23 i64)
  (local $local28 i64)
  (local $local29 i64)
  (local $local30 i64)
  (local $local32 i64)
  (local $local33 i64)
  (local $local37 i64)
  (local $local47 i64)
  (local $local50 i64)
  (local $local52 i64)
  (local $local54 i64)
  (local $local56 i64)
  (local $local57 i64)
  (local $local2 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local16 (ref null $type14))
  (local $local20 (ref null $type14))
  (local $local21 (ref null $type14))
  (local $local22 (ref null $type14))
  (local $local27 (ref null $type14))
  (local $local31 (ref null $type14))
  (local $local36 (ref null $type14))
  (local $local41 (ref null $type14))
  (local $local45 (ref null $type14))
  (local $local48 (ref null $type14))
  (local $local49 (ref null $type14))
  (local $local53 (ref null $type14))
  (local $local55 (ref null $type14))
  (local $local58 (ref null $type14))
  (local $local59 (ref null $type14))
  (local $local60 (ref null $type14))
  (local $local12 (ref null $type30))
  (local $local18 (ref null $type47))
  (local $local24 (ref null $type47))
  (local $local25 (ref null $type13))
  (local $local34 (ref null $type32))
  (local $local38 (ref null $type32))
  (local $local39 (ref null $type29))
  (local $local43 (ref null $type29))
  (local $local42 (ref null $type34))
  (local $local46 (ref null $type34))
  (local $local51 (ref null $type48))
  (local $local61 (ref null $type51))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument308)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (i64.const 1073741824)
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $argument308)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (local.get $local1)
  )
  (local.set $local11
   (i64.const 1)
  )
  (local.set $local9
   (i64.sub
    (local.get $local10)
    (local.get $local11)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (local.set $local7
   (call $function41
    (struct.get $type30 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local8)
    )
    (local.get $local9)
   )
  )
  (local.set $local13
   (i64.const 1)
  )
  (local.set $local6
   (i64.add
    (local.get $local7)
    (local.get $local13)
   )
  )
  (local.set $local4
   (i64.div_s
    (local.get $local5)
    (local.get $local6)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (local.set $local16
   (ref.as_non_null
    (local.get $argument307)
   )
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (local.get $local4)
  )
  (local.set $local18
   (ref.as_non_null
    (global.get $global244)
   )
  )
  (local.set $local15
   (call $function78
    (struct.get $type47 1
     (ref.as_non_null
      (local.get $local18)
     )
    )
    (ref.as_non_null
     (local.get $local16)
    )
    (local.get $local17)
   )
  )
  (local.set $local14
   (i32.const 1)
  )
  (local.set $local22
   (ref.as_non_null
    (local.get $argument308)
   )
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local23
   (local.get $local4)
  )
  (local.set $local24
   (ref.as_non_null
    (global.get $global244)
   )
  )
  (local.set $local21
   (call $function78
    (struct.get $type47 1
     (ref.as_non_null
      (local.get $local24)
     )
    )
    (ref.as_non_null
     (local.get $local22)
    )
    (local.get $local23)
   )
  )
  (local.set $local25
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (local.set $local20
   (call $function46
    (struct.get $type13 1
     (ref.as_non_null
      (local.get $local25)
     )
    )
    (ref.as_non_null
     (local.get $local21)
    )
   )
  )
  (local.set $local19
   (i32.const 1)
  )
  (local.set $local31
   (ref.as_non_null
    (local.get $argument307)
   )
  )
  (local.set $local30
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local31)
     )
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local32
   (local.get $local1)
  )
  (local.set $local29
   (i64.sub
    (local.get $local30)
    (local.get $local32)
   )
  )
  (local.set $local33
   (i64.const 1)
  )
  (local.set $local28
   (i64.add
    (local.get $local29)
    (local.get $local33)
   )
  )
  (local.set $local34
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local27
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local34)
     )
    )
    (local.get $local28)
   )
  )
  (local.set $local26
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local37
   (local.get $local1)
  )
  (local.set $local38
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local36
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local38)
     )
    )
    (local.get $local37)
   )
  )
  (local.set $local35
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local26)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local58
   (ref.as_non_null
    (local.get $local27)
   )
  )
  (if
   (i32.eqz
    (local.get $local14)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local59
   (ref.as_non_null
    (local.get $local15)
   )
  )
  (if
   (i32.eqz
    (local.get $local19)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local60
   (ref.as_non_null
    (local.get $local20)
   )
  )
  (local.set $local61
   (ref.as_non_null
    (global.get $global300)
   )
  )
  (drop
   (call $function89
    (struct.get $type51 1
     (ref.as_non_null
      (local.get $local61)
     )
    )
    (ref.as_non_null
     (local.get $local58)
    )
    (ref.as_non_null
     (local.get $local59)
    )
    (ref.as_non_null
     (local.get $local60)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local35)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local53
   (ref.as_non_null
    (local.get $local36)
   )
  )
  (local.set $local54
   (i64.const 0)
  )
  (if
   (i32.eqz
    (local.get $local14)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local55
   (ref.as_non_null
    (local.get $local15)
   )
  )
  (local.set $local56
   (i64.const 0)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local57
   (local.get $local1)
  )
  (if
   (i64.lt_s
    (local.get $local57)
    (local.get $local56)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type14 $type14
   (ref.as_non_null
    (local.get $local53)
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local54)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local54)
    )
   )
   (ref.as_non_null
    (local.get $local55)
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $local56)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $local56)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (i64.sub
       (local.get $local57)
       (local.get $local56)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (i64.sub
      (local.get $local57)
      (local.get $local56)
     )
    )
   )
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local35)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local48
   (ref.as_non_null
    (local.get $local36)
   )
  )
  (if
   (i32.eqz
    (local.get $local35)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local49
   (ref.as_non_null
    (local.get $local36)
   )
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local50
   (local.get $local4)
  )
  (local.set $local51
   (ref.as_non_null
    (global.get $global253)
   )
  )
  (local.set $local47
   (call $function80
    (struct.get $type48 1
     (ref.as_non_null
      (local.get $local51)
     )
    )
    (ref.as_non_null
     (local.get $local48)
    )
    (ref.as_non_null
     (local.get $local49)
    )
    (local.get $local50)
   )
  )
  (local.set $local52
   (i64.const 0)
  )
  (drop
   (if (result i32)
    (i64.eq
     (local.get $local47)
     (local.get $local52)
    )
    (then
     (i32.const 0)
    )
    (else
     (unreachable)
    )
   )
  )
  (local.set $local40
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local26)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local41
   (ref.as_non_null
    (local.get $local27)
   )
  )
  (local.set $local42
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (local.set $local39
   (call $function47
    (struct.get $type34 1
     (ref.as_non_null
      (local.get $local42)
     )
    )
    (local.get $local40)
    (ref.as_non_null
     (local.get $local41)
    )
   )
  )
  (local.set $local44
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local35)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local45
   (ref.as_non_null
    (local.get $local36)
   )
  )
  (local.set $local46
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (local.set $local43
   (call $function47
    (struct.get $type34 1
     (ref.as_non_null
      (local.get $local46)
     )
    )
    (local.get $local44)
    (ref.as_non_null
     (local.get $local45)
    )
   )
  )
  (struct.new $type53
   (ref.as_non_null
    (local.get $local39)
   )
   (ref.as_non_null
    (local.get $local43)
   )
  )
 )
 (func $function92 (type $call54) (param $environment eqref) (param $argument316 (ref $type29)) (param $argument317 (ref $type29)) (result (ref $type53))
  (local $local0 i32)
  (local $local2 i32)
  (local $local9 i32)
  (local $local14 i32)
  (local $local24 i32)
  (local $local11 i64)
  (local $local15 i64)
  (local $local18 i64)
  (local $local20 i64)
  (local $local28 i64)
  (local $local30 i64)
  (local $local32 i64)
  (local $local37 i64)
  (local $local41 i64)
  (local $local1 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local7 (ref null $type14))
  (local $local10 (ref null $type14))
  (local $local12 (ref null $type14))
  (local $local16 (ref null $type14))
  (local $local17 (ref null $type14))
  (local $local19 (ref null $type14))
  (local $local25 (ref null $type14))
  (local $local31 (ref null $type14))
  (local $local38 (ref null $type14))
  (local $local39 (ref null $type14))
  (local $local4 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local23 (ref null $type29))
  (local $local27 (ref null $type29))
  (local $local33 (ref null $type29))
  (local $local34 (ref null $type29))
  (local $local35 (ref null $type29))
  (local $local8 (ref null $type52))
  (local $local13 (ref null $type32))
  (local $local21 (ref null $type30))
  (local $local22 (ref null $type48))
  (local $local26 (ref null $type34))
  (local $local29 (ref null $type38))
  (local $local36 (ref null $type36))
  (local $local40 (ref null $type40))
  (local.set $local4
   (ref.as_non_null
    (local.get $argument316)
   )
  )
  (local.set $local1
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $argument317)
   )
  )
  (local.set $local3
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local2
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local38
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local39
   (ref.as_non_null
    (local.get $local3)
   )
  )
  (local.set $local40
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (local.set $local37
   (call $function57
    (struct.get $type40 1
     (ref.as_non_null
      (local.get $local40)
     )
    )
    (ref.as_non_null
     (local.get $local38)
    )
    (ref.as_non_null
     (local.get $local39)
    )
   )
  )
  (local.set $local41
   (i64.const 0)
  )
  (if (result (ref $type53))
   (i64.lt_s
    (local.get $local37)
    (local.get $local41)
   )
   (then
    (local.set $local33
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.set $local35
     (ref.as_non_null
      (local.get $argument316)
     )
    )
    (local.set $local36
     (ref.as_non_null
      (global.get $global136)
     )
    )
    (local.set $local34
     (call $function49
      (struct.get $type36 1
       (ref.as_non_null
        (local.get $local36)
       )
      )
      (ref.as_non_null
       (local.get $local35)
      )
     )
    )
    (struct.new $type53
     (ref.as_non_null
      (local.get $local33)
     )
     (ref.as_non_null
      (local.get $local34)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local31
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.set $local30
     (i64.extend_i32_u
      (array.len
       (ref.as_non_null
        (local.get $local31)
       )
      )
     )
    )
    (local.set $local32
     (i64.const 1)
    )
    (if (result (ref $type53))
     (i64.eq
      (local.get $local30)
      (local.get $local32)
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local12
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (local.set $local11
       (i64.extend_i32_u
        (array.len
         (ref.as_non_null
          (local.get $local12)
         )
        )
       )
      )
      (local.set $local13
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (local.set $local10
       (call $function43
        (struct.get $type32 1
         (ref.as_non_null
          (local.get $local13)
         )
        )
        (local.get $local11)
       )
      )
      (local.set $local9
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local9)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local16
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local17
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local19
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (local.set $local20
       (i64.const 0)
      )
      (local.set $local21
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (local.set $local18
       (call $function41
        (struct.get $type30 1
         (ref.as_non_null
          (local.get $local21)
         )
        )
        (ref.as_non_null
         (local.get $local19)
        )
        (local.get $local20)
       )
      )
      (local.set $local22
       (ref.as_non_null
        (global.get $global253)
       )
      )
      (local.set $local15
       (call $function80
        (struct.get $type48 1
         (ref.as_non_null
          (local.get $local22)
         )
        )
        (ref.as_non_null
         (local.get $local16)
        )
        (ref.as_non_null
         (local.get $local17)
        )
        (local.get $local18)
       )
      )
      (local.set $local14
       (i32.const 1)
      )
      (local.set $local24
       (i32.const 0)
      )
      (if
       (i32.eqz
        (local.get $local9)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local25
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (local.set $local26
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (local.set $local23
       (call $function47
        (struct.get $type34 1
         (ref.as_non_null
          (local.get $local26)
         )
        )
        (local.get $local24)
        (ref.as_non_null
         (local.get $local25)
        )
       )
      )
      (if
       (i32.eqz
        (local.get $local14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local28
       (local.get $local15)
      )
      (local.set $local29
       (ref.as_non_null
        (global.get $global145)
       )
      )
      (local.set $local27
       (call $function53
        (struct.get $type38 1
         (ref.as_non_null
          (local.get $local29)
         )
        )
        (local.get $local28)
       )
      )
      (struct.new $type53
       (ref.as_non_null
        (local.get $local23)
       )
       (ref.as_non_null
        (local.get $local27)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (local.set $local8
       (ref.as_non_null
        (global.get $global306)
       )
      )
      (return_call $function91
       (struct.get $type52 1
        (ref.as_non_null
         (local.get $local8)
        )
       )
       (ref.as_non_null
        (local.get $local6)
       )
       (ref.as_non_null
        (local.get $local7)
       )
      )
     )
    )
   )
  )
 )
 (func $function93 (type $call54) (param $environment eqref) (param $argument323 (ref $type29)) (param $argument324 (ref $type29)) (result (ref $type53))
  (local $local0 i32)
  (local $local5 i32)
  (local $local8 i32)
  (local $local15 i32)
  (local $local1 (ref null $type53))
  (local $local7 (ref null $type53))
  (local $local10 (ref null $type53))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type29))
  (local $local6 (ref null $type29))
  (local $local9 (ref null $type29))
  (local $local11 (ref null $type29))
  (local $local12 (ref null $type29))
  (local $local14 (ref null $type29))
  (local $local16 (ref null $type29))
  (local $local17 (ref null $type29))
  (local $local18 (ref null $type29))
  (local $local19 (ref null $type29))
  (local $local21 (ref null $type29))
  (local $local22 (ref null $type29))
  (local $local4 (ref null $type54))
  (local $local13 (ref null $type36))
  (local $local20 (ref null $type36))
  (local $local23 (ref null $type35))
  (local.set $local22
   (ref.as_non_null
    (local.get $argument324)
   )
  )
  (local.set $local23
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if (result (ref $type53))
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local23)
     )
    )
    (ref.as_non_null
     (local.get $local22)
    )
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument323)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (local.get $argument324)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global315)
     )
    )
    (local.set $local1
     (call $function92
      (struct.get $type54 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local6
     (struct.get $type53 0
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local5
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local9
     (struct.get $type53 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (local.set $local8
     (i32.const 1)
    )
    (local.set $local17
     (ref.as_non_null
      (local.get $argument323)
     )
    )
    (local.set $local11
     (if (result (ref $type29))
      (if (result i32)
       (struct.get $type29 0
        (ref.as_non_null
         (local.get $local17)
        )
       )
       (then
        (local.set $local16
         (ref.as_non_null
          (local.get $argument324)
         )
        )
        (local.set $local15
         (struct.get $type29 0
          (ref.as_non_null
           (local.get $local16)
          )
         )
        )
        (i32.eqz
         (local.get $local15)
        )
       )
       (else
        (local.set $local14
         (ref.as_non_null
          (local.get $argument324)
         )
        )
        (struct.get $type29 0
         (ref.as_non_null
          (local.get $local14)
         )
        )
       )
      )
      (then
       (if
        (i32.eqz
         (local.get $local5)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local12
        (ref.as_non_null
         (local.get $local6)
        )
       )
       (local.set $local13
        (ref.as_non_null
         (global.get $global138)
        )
       )
       (call $function50
        (struct.get $type36 1
         (ref.as_non_null
          (local.get $local13)
         )
        )
        (ref.as_non_null
         (local.get $local12)
        )
       )
      )
      (else
       (if
        (i32.eqz
         (local.get $local5)
        )
        (then
         (unreachable)
        )
       )
       (ref.as_non_null
        (local.get $local6)
       )
      )
     )
    )
    (local.set $local21
     (ref.as_non_null
      (local.get $argument323)
     )
    )
    (local.set $local18
     (if (result (ref $type29))
      (struct.get $type29 0
       (ref.as_non_null
        (local.get $local21)
       )
      )
      (then
       (if
        (i32.eqz
         (local.get $local8)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local19
        (ref.as_non_null
         (local.get $local9)
        )
       )
       (local.set $local20
        (ref.as_non_null
         (global.get $global138)
        )
       )
       (call $function50
        (struct.get $type36 1
         (ref.as_non_null
          (local.get $local20)
         )
        )
        (ref.as_non_null
         (local.get $local19)
        )
       )
      )
      (else
       (if
        (i32.eqz
         (local.get $local8)
        )
        (then
         (unreachable)
        )
       )
       (ref.as_non_null
        (local.get $local9)
       )
      )
     )
    )
    (struct.new $type53
     (ref.as_non_null
      (local.get $local11)
     )
     (ref.as_non_null
      (local.get $local18)
     )
    )
   )
  )
 )
 (func $function94 (type $call45) (param $environment eqref) (param $argument329 (ref $type29)) (param $argument330 (ref $type29)) (result (ref $type29))
  (local $local0 (ref null $type53))
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type54))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument329)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument330)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global322)
   )
  )
  (local.set $local0
   (call $function93
    (struct.get $type54 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (struct.get $type53 0
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function95 (type $call45) (param $environment eqref) (param $argument332 (ref $type29)) (param $argument333 (ref $type29)) (result (ref $type29))
  (local $local0 (ref null $type53))
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type54))
  (local.set $local1
   (ref.as_non_null
    (local.get $argument332)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (local.get $argument333)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global322)
   )
  )
  (local.set $local0
   (call $function93
    (struct.get $type54 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (struct.get $type53 1
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function96 (type $call55) (param $environment eqref) (param $argument335 (ref $type16)) (param $argument336 i64) (param $argument337 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument336)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function97
   (ref.as_non_null
    (local.get $argument335)
   )
   (local.get $argument337)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function97 (param $capture335 (ref $type16)) (param $capture337 i64) (param $capture338 i32) (param $initialized338 i32) (param $argument339 i64) (param $argument340 i64) (result i64)
  (local $local0 i32)
  (local $local3 i32)
  (local $local6 i32)
  (local $local16 i32)
  (local $local17 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local4 (ref null $type16))
  (local.set $local22
   (local.get $argument339)
  )
  (local.set $local23
   (local.get $capture337)
  )
  (if (result i64)
   (i64.eq
    (local.get $local22)
    (local.get $local23)
   )
   (then
    (local.get $argument340)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture335)
     )
    )
    (local.set $local5
     (local.get $argument339)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type17
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (local.set $local2
     (i64.extend_i32_u
      (local.get $local3)
     )
    )
    (local.set $local7
     (i64.const 48)
    )
    (local.set $local1
     (i64.sub
      (local.get $local2)
      (local.get $local7)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local1)
    )
    (local.set $local19
     (i64.const 0)
    )
    (local.set $local17
     (i64.lt_s
      (local.get $local18)
      (local.get $local19)
     )
    )
    (local.set $local16
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local16)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (local.get $local17)
      (then
       (if
        (i32.eqz
         (local.get $local16)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local17)
      )
      (else
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local20
        (local.get $local1)
       )
       (local.set $local21
        (i64.const 9)
       )
       (i64.gt_s
        (local.get $local20)
        (local.get $local21)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local9
       (local.get $argument339)
      )
      (local.set $local10
       (i64.const 1)
      )
      (local.set $local8
       (i64.add
        (local.get $local9)
        (local.get $local10)
       )
      )
      (local.set $local13
       (local.get $argument340)
      )
      (local.set $local14
       (i64.const 10)
      )
      (local.set $local12
       (i64.mul
        (local.get $local13)
        (local.get $local14)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local15
       (local.get $local1)
      )
      (local.set $local11
       (i64.add
        (local.get $local12)
        (local.get $local15)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized338)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture338)
      )
      (return_call $function97
       (ref.as_non_null
        (local.get $capture335)
       )
       (local.get $capture337)
       (local.get $capture338)
       (local.get $initialized338)
       (local.get $local8)
       (local.get $local11)
      )
     )
    )
   )
  )
 )
 (func $function98 (type $call56) (param $environment eqref) (param $argument344 i64) (param $argument345 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument345)
  )
  (local.set $local1
   (i64.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function99
   (local.get $argument344)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function99 (param $capture344 i64) (param $capture346 i32) (param $initialized346 i32) (param $argument347 i64) (param $argument348 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local.set $local6
   (local.get $argument347)
  )
  (local.set $local7
   (i64.const 0)
  )
  (if (result i64)
   (i64.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (local.get $argument348)
   )
   (else
    (local.set $local1
     (local.get $argument347)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument348)
    )
    (local.set $local5
     (local.get $capture344)
    )
    (local.set $local3
     (i64.mul
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized346)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture346)
    )
    (return_call $function99
     (local.get $capture344)
     (local.get $capture346)
     (local.get $initialized346)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function100 (type $call57) (param $environment eqref) (param $argument350 (ref $type16)) (param $argument351 i64) (param $argument352 i32) (result (ref $type29))
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local2 (ref null $type16))
  (local $local4 (ref null $type29))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument350)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local7
   (local.get $argument351)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (local.get $local1)
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local3
     (local.get $argument351)
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.set $local6
     (i32.const 0)
    )
    (local.set $local5
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local6)
    )
    (return_call $function101
     (ref.as_non_null
      (local.get $argument350)
     )
     (local.get $argument352)
     (block (result i64)
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $local1)
     )
     (local.get $local6)
     (local.get $local5)
     (local.get $local3)
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
 )
 (func $function101 (param $capture350 (ref $type16)) (param $capture352 i32) (param $capture353 i64) (param $capture354 i32) (param $initialized354 i32) (param $argument355 i64) (param $argument356 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local8 i32)
  (local $local10 i32)
  (local $local20 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local22 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local27 i64)
  (local $local30 i64)
  (local $local31 i64)
  (local $local32 i64)
  (local $local39 i64)
  (local $local40 i64)
  (local $local9 (ref null $type29))
  (local $local13 (ref null $type29))
  (local $local21 (ref null $type29))
  (local $local33 (ref null $type29))
  (local $local34 (ref null $type29))
  (local $local35 (ref null $type29))
  (local $local37 (ref null $type29))
  (local $local11 (ref null $type14))
  (local $local12 (ref null $type14))
  (local $local17 (ref null $type56))
  (local $local18 (ref null $type47))
  (local $local19 (ref null $type34))
  (local $local23 (ref null $type16))
  (local $local28 (ref null $type55))
  (local $local29 (ref null $type38))
  (local $local36 (ref null $type45))
  (local $local38 (ref null $type36))
  (local.set $local39
   (local.get $argument355)
  )
  (local.set $local40
   (local.get $capture353)
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $local39)
    (local.get $local40)
   )
   (then
    (if (result (ref $type29))
     (local.get $capture352)
     (then
      (local.set $local37
       (ref.as_non_null
        (local.get $argument356)
       )
      )
      (local.set $local38
       (ref.as_non_null
        (global.get $global138)
       )
      )
      (return_call $function50
       (struct.get $type36 1
        (ref.as_non_null
         (local.get $local38)
        )
       )
       (ref.as_non_null
        (local.get $local37)
       )
      )
     )
     (else
      (ref.as_non_null
       (local.get $argument356)
      )
     )
    )
   )
   (else
    (local.set $local5
     (local.get $capture353)
    )
    (local.set $local6
     (local.get $argument355)
    )
    (local.set $local4
     (i64.sub
      (local.get $local5)
      (local.get $local6)
     )
    )
    (local.set $local7
     (i64.const 9)
    )
    (local.set $local1
     (if (result i64)
      (i64.gt_s
       (local.get $local4)
       (local.get $local7)
      )
      (then
       (i64.const 9)
      )
      (else
       (local.set $local2
        (local.get $capture353)
       )
       (local.set $local3
        (local.get $argument355)
       )
       (i64.sub
        (local.get $local2)
        (local.get $local3)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local10
     (i32.const 0)
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $argument356)
     )
    )
    (local.set $local12
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local13)
      )
     )
    )
    (local.set $local15
     (i64.const 10)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (local.set $local17
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (local.set $local14
     (call $function98
      (struct.get $type56 1
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (local.get $local15)
      (local.get $local16)
     )
    )
    (local.set $local18
     (ref.as_non_null
      (global.get $global244)
     )
    )
    (local.set $local11
     (call $function78
      (struct.get $type47 1
       (ref.as_non_null
        (local.get $local18)
       )
      )
      (ref.as_non_null
       (local.get $local12)
      )
      (local.get $local14)
     )
    )
    (local.set $local19
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (local.set $local9
     (call $function47
      (struct.get $type34 1
       (ref.as_non_null
        (local.get $local19)
       )
      )
      (local.get $local10)
      (ref.as_non_null
       (local.get $local11)
      )
     )
    )
    (local.set $local8
     (i32.const 1)
    )
    (local.set $local23
     (ref.as_non_null
      (local.get $capture350)
     )
    )
    (local.set $local24
     (local.get $argument355)
    )
    (local.set $local26
     (local.get $argument355)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local27
     (local.get $local1)
    )
    (local.set $local25
     (i64.add
      (local.get $local26)
      (local.get $local27)
     )
    )
    (local.set $local28
     (ref.as_non_null
      (global.get $global334)
     )
    )
    (local.set $local22
     (call $function96
      (struct.get $type55 1
       (ref.as_non_null
        (local.get $local28)
       )
      )
      (ref.as_non_null
       (local.get $local23)
      )
      (local.get $local24)
      (local.get $local25)
     )
    )
    (local.set $local29
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local21
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local29)
       )
      )
      (local.get $local22)
     )
    )
    (local.set $local20
     (i32.const 1)
    )
    (local.set $local31
     (local.get $argument355)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local32
     (local.get $local1)
    )
    (local.set $local30
     (i64.add
      (local.get $local31)
      (local.get $local32)
     )
    )
    (if
     (i32.eqz
      (local.get $local8)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local34
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (if
     (i32.eqz
      (local.get $local20)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local35
     (ref.as_non_null
      (local.get $local21)
     )
    )
    (local.set $local36
     (ref.as_non_null
      (global.get $global215)
     )
    )
    (local.set $local33
     (call $function71
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local36)
       )
      )
      (ref.as_non_null
       (local.get $local34)
      )
      (ref.as_non_null
       (local.get $local35)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized354)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture354)
    )
    (return_call $function101
     (ref.as_non_null
      (local.get $capture350)
     )
     (local.get $capture352)
     (local.get $capture353)
     (local.get $capture354)
     (local.get $initialized354)
     (local.get $local30)
     (ref.as_non_null
      (local.get $local33)
     )
    )
   )
  )
 )
 (func $function102 (type $call58) (param $environment eqref) (param $argument361 (ref $type16)) (result (ref $type29))
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local13 i32)
  (local $local14 i32)
  (local $local17 i32)
  (local $local3 i64)
  (local $local16 i64)
  (local $local19 i64)
  (local $local21 i64)
  (local $local2 (ref null $type16))
  (local $local15 (ref null $type16))
  (local $local20 (ref null $type16))
  (local $local18 (ref null $type57))
  (local.set $local20
   (ref.as_non_null
    (local.get $argument361)
   )
  )
  (local.set $local19
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local20)
     )
    )
   )
  )
  (local.set $local21
   (i64.const 0)
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $local19)
    (local.get $local21)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument361)
     )
    )
    (local.set $local3
     (i64.const 0)
    )
    (if
     (i64.ge_u
      (local.get $local3)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (i32.wrap_i64
      (local.get $local3)
     )
    )
    (local.set $local1
     (array.get $type17
      (call $string-block
       (ref.as_non_null
        (local.get $local2)
       )
       (local.get $local4)
      )
      (i32.and
       (local.get $local4)
       (i32.const 8191)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (local.get $local1)
    )
    (local.set $local8
     (i32.const 45)
    )
    (local.set $local6
     (i32.eq
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local5
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (local.get $local6)
    )
    (local.set $local11
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local11)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (if (result i32)
      (local.get $local12)
      (then
       (if
        (i32.eqz
         (local.get $local11)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local12)
      )
      (else
       (if
        (i32.eqz
         (local.get $local0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local13
        (local.get $local1)
       )
       (local.set $local14
        (i32.const 43)
       )
       (i32.eq
        (local.get $local13)
        (local.get $local14)
       )
      )
     )
    )
    (local.set $local9
     (i32.const 1)
    )
    (local.set $local15
     (ref.as_non_null
      (local.get $argument361)
     )
    )
    (if
     (i32.eqz
      (local.get $local9)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (if (result i64)
      (local.get $local10)
      (then
       (i64.const 1)
      )
      (else
       (i64.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (local.get $local6)
    )
    (local.set $local18
     (ref.as_non_null
      (global.get $global349)
     )
    )
    (return_call $function100
     (struct.get $type57 1
      (ref.as_non_null
       (local.get $local18)
      )
     )
     (ref.as_non_null
      (local.get $local15)
     )
     (local.get $local16)
     (local.get $local17)
    )
   )
  )
 )
 (func $function103 (type $call59) (param $environment eqref) (param $argument367 (ref $type14)) (result (ref null $type60))
  (local $local0 (ref null $type14))
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type13))
  (local $local3 (ref null $type60))
  (local $local4 i32)
  (local $local5 i32)
  (local.set $local1
   (ref.as_non_null
    (local.get $argument367)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global368)
   )
  )
  (local.set $local0
   (call $function104
    (struct.get $type13 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (ref.null none)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function105
   (local.get $local5)
   (local.get $local4)
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local3)
  )
 )
 (func $function104 (type $call13) (param $environment eqref) (param $argument369 (ref $type14)) (result (ref $type14))
  (local $local0 i32)
  (local $local3 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local5 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local2 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local7 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local11 (ref null $type14))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument369)
   )
  )
  (local.set $local1
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (local.get $local1)
  )
  (local.set $local15
   (i64.const 0)
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $local14)
    (local.get $local15)
   )
   (then
    (array.new_fixed $type14 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (local.get $local1)
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument369)
     )
    )
    (local.set $local8
     (i64.const 0)
    )
    (local.set $local6
     (array.get $type14
      (ref.as_non_null
       (local.get $local7)
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local8)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local8)
       )
      )
     )
    )
    (local.set $local4
     (array.new $type14
      (local.get $local6)
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $local5)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $local5)
       )
      )
     )
    )
    (local.set $local3
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.set $local10
     (i64.const 0)
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $argument369)
     )
    )
    (local.set $local12
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (local.get $local1)
    )
    (if
     (i64.lt_s
      (local.get $local13)
      (local.get $local12)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (ref.as_non_null
      (local.get $local9)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local10)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local10)
      )
     )
     (ref.as_non_null
      (local.get $local11)
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $local12)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $local12)
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (i64.sub
         (local.get $local13)
         (local.get $local12)
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (i64.sub
        (local.get $local13)
        (local.get $local12)
       )
      )
     )
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
 )
 (func $function105 (param $capture372 i32) (param $initialized372 i32) (param $argument373 (ref $type14)) (param $argument374 (ref null $type60)) (result (ref null $type60))
  (local $local0 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local7 (ref null $type14))
  (local $local13 (ref null $type14))
  (local $local5 (ref null $type48))
  (local $local8 (ref null $type13))
  (local $local9 (ref null $type60))
  (local $local11 (ref null $type60))
  (local.set $local13
   (ref.as_non_null
    (local.get $argument373)
   )
  )
  (local.set $local12
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local13)
     )
    )
   )
  )
  (local.set $local14
   (i64.const 0)
  )
  (if (result (ref null $type60))
   (i64.eq
    (local.get $local12)
    (local.get $local14)
   )
   (then
    (local.get $argument374)
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument373)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (local.get $argument373)
     )
    )
    (local.set $local4
     (i64.const 1000000000)
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global253)
     )
    )
    (local.set $local1
     (call $function80
      (struct.get $type48 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (local.get $local4)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument373)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (local.set $local6
     (call $function46
      (struct.get $type13 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (local.get $local1)
    )
    (local.set $local11
     (local.get $argument374)
    )
    (local.set $local9
     (struct.new $type60
      (local.get $local10)
      (local.get $local11)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized372)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture372)
    )
    (return_call $function105
     (local.get $capture372)
     (local.get $initialized372)
     (ref.as_non_null
      (local.get $local6)
     )
     (local.get $local9)
    )
   )
  )
 )
 (func $function106 (type $call37) (param $environment eqref) (param $argument377 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument377)
  )
  (local.set $local1
   (i64.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function107
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function107 (param $capture378 i32) (param $initialized378 i32) (param $argument379 i64) (param $argument380 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local.set $local6
   (local.get $argument379)
  )
  (local.set $local7
   (i64.const 10)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (local.get $argument380)
   )
   (else
    (local.set $local1
     (local.get $argument379)
    )
    (local.set $local2
     (i64.const 10)
    )
    (local.set $local0
     (i64.div_s
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument380)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized378)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture378)
    )
    (return_call $function107
     (local.get $capture378)
     (local.get $initialized378)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function108 (type $call61) (param $environment eqref) (param $argument382 (ref null $type60)) (result i64)
  (local $local0 (ref null $type60))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument382)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function109
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function109 (param $capture383 i32) (param $initialized383 i32) (param $argument384 (ref null $type60)) (param $argument385 i64) (result i64)
  (local $local0 (ref null $type60))
  (local $local1 (ref null $type60))
  (local $local5 (ref null $type60))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local.set $local5
   (local.get $argument384)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local5)
   )
   (then
    (local.get $argument385)
   )
   (else
    (local.set $local1
     (local.get $argument384)
    )
    (local.set $local0
     (struct.get $type60 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument385)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized383)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture383)
    )
    (return_call $function109
     (local.get $capture383)
     (local.get $initialized383)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function110 (type $call62) (param $environment eqref) (param $argument387 (ref $type16)) (param $argument388 i64) (param $argument389 i64) (param $argument390 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local.set $local0
   (local.get $argument388)
  )
  (local.set $local1
   (local.get $argument390)
  )
  (local.set $local2
   (local.get $argument389)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local4)
  )
  (return_call $function111
   (ref.as_non_null
    (local.get $argument387)
   )
   (local.get $local4)
   (local.get $local3)
   (local.get $local0)
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function111 (param $capture387 (ref $type16)) (param $capture391 i32) (param $initialized391 i32) (param $argument392 i64) (param $argument393 i64) (param $argument394 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local13 i32)
  (local $local19 i32)
  (local $local9 (ref null $type16))
  (local.set $local20
   (local.get $argument393)
  )
  (local.set $local21
   (i64.const 0)
  )
  (if (result i32)
   (i64.eq
    (local.get $local20)
    (local.get $local21)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local9
     (ref.as_non_null
      (local.get $capture387)
     )
    )
    (local.set $local11
     (local.get $argument392)
    )
    (local.set $local12
     (i64.const 1)
    )
    (local.set $local10
     (i64.sub
      (local.get $local11)
      (local.get $local12)
     )
    )
    (local.set $local15
     (i64.const 48)
    )
    (local.set $local17
     (local.get $argument394)
    )
    (local.set $local18
     (i64.const 10)
    )
    (local.set $local16
     (i64.rem_s
      (local.get $local17)
      (local.get $local18)
     )
    )
    (local.set $local14
     (i64.add
      (local.get $local15)
      (local.get $local16)
     )
    )
    (if
     (i64.gt_u
      (local.get $local14)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local14)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local14)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (i32.wrap_i64
      (local.get $local14)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local10)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (i32.wrap_i64
      (local.get $local10)
     )
    )
    (array.set $type17
     (call $string-block
      (ref.as_non_null
       (local.get $local9)
      )
      (local.get $local19)
     )
     (i32.and
      (local.get $local19)
      (i32.const 8191)
     )
     (local.get $local13)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument392)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument393)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.sub
      (local.get $local4)
      (local.get $local5)
     )
    )
    (local.set $local7
     (local.get $argument394)
    )
    (local.set $local8
     (i64.const 10)
    )
    (local.set $local6
     (i64.div_s
      (local.get $local7)
      (local.get $local8)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized391)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture391)
    )
    (return_call $function111
     (ref.as_non_null
      (local.get $capture387)
     )
     (local.get $capture391)
     (local.get $initialized391)
     (local.get $local0)
     (local.get $local3)
     (local.get $local6)
    )
   )
  )
 )
 (func $function112 (type $call63) (param $environment eqref) (param $argument396 (ref $type16)) (param $argument397 i64) (param $argument398 (ref null $type60)) (param $argument399 i64) (result i32)
  (local $local0 (ref null $type16))
  (local $local8 (ref null $type16))
  (local $local4 (ref null $type60))
  (local $local5 (ref null $type60))
  (local $local13 (ref null $type60))
  (local $local16 (ref null $type60))
  (local $local7 (ref null $type63))
  (local $local15 (ref null $type62))
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local14 i64)
  (local.set $local16
   (local.get $argument398)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local16)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local8
     (ref.as_non_null
      (local.get $argument396)
     )
    )
    (local.set $local10
     (local.get $argument397)
    )
    (local.set $local11
     (local.get $argument399)
    )
    (local.set $local9
     (i64.add
      (local.get $local10)
      (local.get $local11)
     )
    )
    (local.set $local13
     (local.get $argument398)
    )
    (local.set $local12
     (struct.get $type60 0
      (local.get $local13)
     )
    )
    (local.set $local14
     (local.get $argument399)
    )
    (local.set $local15
     (ref.as_non_null
      (global.get $global386)
     )
    )
    (drop
     (call $function110
      (struct.get $type62 1
       (ref.as_non_null
        (local.get $local15)
       )
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
      (local.get $local12)
      (local.get $local14)
     )
    )
    (local.set $local0
     (ref.as_non_null
      (local.get $argument396)
     )
    )
    (local.set $local2
     (local.get $argument397)
    )
    (local.set $local3
     (local.get $argument399)
    )
    (local.set $local1
     (i64.add
      (local.get $local2)
      (local.get $local3)
     )
    )
    (local.set $local5
     (local.get $argument398)
    )
    (local.set $local4
     (struct.get $type60 1
      (local.get $local5)
     )
    )
    (local.set $local6
     (i64.const 9)
    )
    (if
     (i32.eqz
      (global.get $ready395)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global395)
     )
    )
    (return_call $function112
     (struct.get $type63 1
      (ref.as_non_null
       (local.get $local7)
      )
     )
     (ref.as_non_null
      (local.get $local0)
     )
     (local.get $local1)
     (local.get $local4)
     (local.get $local6)
    )
   )
  )
 )
 (func $function113 (type $call64) (param $environment eqref) (param $argument401 (ref $type29)) (result (ref $type16))
  (local $local0 i32)
  (local $local5 i32)
  (local $local10 i32)
  (local $local13 i32)
  (local $local34 i32)
  (local $local35 i32)
  (local $local37 i32)
  (local $local6 i64)
  (local $local7 i64)
  (local $local11 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local22 i64)
  (local $local25 i64)
  (local $local28 i64)
  (local $local30 i64)
  (local $local33 i64)
  (local $local1 (ref null $type60))
  (local $local8 (ref null $type60))
  (local $local23 (ref null $type60))
  (local $local29 (ref null $type60))
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type29))
  (local $local12 (ref null $type29))
  (local $local36 (ref null $type29))
  (local $local39 (ref null $type29))
  (local $local4 (ref null $type59))
  (local $local9 (ref null $type37))
  (local $local14 (ref null $type16))
  (local $local27 (ref null $type16))
  (local $local32 (ref null $type16))
  (local $local24 (ref null $type61))
  (local $local26 (ref null $type15))
  (local $local31 (ref null $type63))
  (local $local38 (ref null $type19))
  (local $local40 (ref null $type35))
  (local.set $local39
   (ref.as_non_null
    (local.get $argument401)
   )
  )
  (local.set $local40
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if (result (ref $type16))
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local40)
     )
    )
    (ref.as_non_null
     (local.get $local39)
    )
   )
   (then
    (local.set $local37
     (i32.const 48)
    )
    (local.set $local38
     (ref.as_non_null
      (global.get $global63)
     )
    )
    (return_call $function26
     (struct.get $type19 1
      (ref.as_non_null
       (local.get $local38)
      )
     )
     (struct.new $type12
      (local.get $local37)
      (ref.null none)
     )
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $argument401)
     )
    )
    (local.set $local2
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global366)
     )
    )
    (local.set $local1
     (call $function103
      (struct.get $type59 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (local.set $local7
     (struct.get $type60 0
      (local.get $local8)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global376)
     )
    )
    (local.set $local6
     (call $function106
      (struct.get $type37 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.get $local7)
     )
    )
    (local.set $local5
     (i32.const 1)
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $argument401)
     )
    )
    (local.set $local11
     (if (result i64)
      (struct.get $type29 0
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (i64.const 0)
      )
     )
    )
    (local.set $local10
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (local.get $local11)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (local.get $local6)
    )
    (local.set $local16
     (i64.add
      (local.get $local17)
      (local.get $local18)
     )
    )
    (local.set $local20
     (i64.const 9)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local23
     (local.get $local1)
    )
    (local.set $local24
     (ref.as_non_null
      (global.get $global381)
     )
    )
    (local.set $local22
     (call $function108
      (struct.get $type61 1
       (ref.as_non_null
        (local.get $local24)
       )
      )
      (local.get $local23)
     )
    )
    (local.set $local25
     (i64.const 1)
    )
    (local.set $local21
     (i64.sub
      (local.get $local22)
      (local.get $local25)
     )
    )
    (local.set $local19
     (i64.mul
      (local.get $local20)
      (local.get $local21)
     )
    )
    (local.set $local15
     (i64.add
      (local.get $local16)
      (local.get $local19)
     )
    )
    (local.set $local26
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local14
     (call $function25
      (struct.get $type15 1
       (ref.as_non_null
        (local.get $local26)
       )
      )
      (local.get $local15)
     )
    )
    (local.set $local13
     (i32.const 1)
    )
    (local.set $local36
     (ref.as_non_null
      (local.get $argument401)
     )
    )
    (drop
     (if (result i32)
      (struct.get $type29 0
       (ref.as_non_null
        (local.get $local36)
       )
      )
      (then
       (if
        (i32.eqz
         (local.get $local13)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local32
        (ref.as_non_null
         (local.get $local14)
        )
       )
       (local.set $local33
        (i64.const 0)
       )
       (local.set $local34
        (i32.const 45)
       )
       (if
        (i32.ne
         (struct.get $type16 0
          (ref.as_non_null
           (local.get $local32)
          )
         )
         (i32.const 1)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.ge_u
         (local.get $local33)
         (i64.extend_i32_u
          (struct.get $type16 1
           (ref.as_non_null
            (local.get $local32)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $local35
        (i32.wrap_i64
         (local.get $local33)
        )
       )
       (array.set $type17
        (call $string-block
         (ref.as_non_null
          (local.get $local32)
         )
         (local.get $local35)
        )
        (i32.and
         (local.get $local35)
         (i32.const 8191)
        )
        (local.get $local34)
       )
       (drop
        (i32.const 0)
       )
       (i32.const 0)
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local13)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local27
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local28
     (local.get $local11)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local29
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local30
     (local.get $local6)
    )
    (local.set $local31
     (ref.as_non_null
      (global.get $global395)
     )
    )
    (drop
     (call $function112
      (struct.get $type63 1
       (ref.as_non_null
        (local.get $local31)
       )
      )
      (ref.as_non_null
       (local.get $local27)
      )
      (local.get $local28)
      (local.get $local29)
      (local.get $local30)
     )
    )
    (if
     (i32.eqz
      (local.get $local13)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local14)
    )
   )
  )
 )
 (func $function114 (type $call36) (param $environment eqref) (param $argument407 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local3 i32)
  (local $local8 i32)
  (local $local5 i64)
  (local $local13 i64)
  (local $local1 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local11 (ref null $type14))
  (local $local12 (ref null $type14))
  (local $local2 (ref null $type29))
  (local $local7 (ref null $type32))
  (local $local10 (ref null $type34))
  (local $local14 (ref null $type48))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument407)
   )
  )
  (local.set $local1
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local5
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local4
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local5)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (local.get $local4)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local13
   (i64.const 2)
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global253)
   )
  )
  (drop
   (call $function80
    (struct.get $type48 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (ref.as_non_null
     (local.get $local11)
    )
    (ref.as_non_null
     (local.get $local12)
    )
    (local.get $local13)
   )
  )
  (local.set $local8
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $local4)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (return_call $function47
   (struct.get $type34 1
    (ref.as_non_null
     (local.get $local10)
    )
   )
   (local.get $local8)
   (ref.as_non_null
    (local.get $local9)
   )
  )
 )
 (func $function115 (type $call45) (param $environment eqref) (param $argument411 (ref $type29)) (param $argument412 (ref $type29)) (result (ref $type29))
  (local $local0 (ref null $type29))
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local7 (ref null $type29))
  (local $local4 (ref null $type38))
  (local $local3 i64)
  (local $local5 i32)
  (local $local6 i32)
  (local.set $local7
   (ref.as_non_null
    (local.get $argument412)
   )
  )
  (if (result (ref $type29))
   (struct.get $type29 0
    (ref.as_non_null
     (local.get $local7)
    )
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local0
     (ref.as_non_null
      (local.get $argument411)
     )
    )
    (local.set $local1
     (ref.as_non_null
      (local.get $argument412)
     )
    )
    (local.set $local3
     (i64.const 1)
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local2
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (local.get $local3)
     )
    )
    (local.set $local6
     (i32.const 0)
    )
    (local.set $local5
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local6)
    )
    (return_call $function116
     (local.get $local6)
     (local.get $local5)
     (ref.as_non_null
      (local.get $local0)
     )
     (ref.as_non_null
      (local.get $local1)
     )
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
 )
 (func $function116 (param $capture413 i32) (param $initialized413 i32) (param $argument414 (ref $type29)) (param $argument415 (ref $type29)) (param $argument416 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local2 i32)
  (local $local7 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local1 (ref null $type29))
  (local $local3 (ref null $type29))
  (local $local4 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local10 (ref null $type29))
  (local $local15 (ref null $type29))
  (local $local17 (ref null $type29))
  (local $local18 (ref null $type29))
  (local $local19 (ref null $type29))
  (local $local21 (ref null $type29))
  (local $local22 (ref null $type29))
  (local $local23 (ref null $type29))
  (local $local25 (ref null $type29))
  (local $local6 (ref null $type45))
  (local $local20 (ref null $type45))
  (local $local9 (ref null $type14))
  (local $local12 (ref null $type30))
  (local $local16 (ref null $type36))
  (local $local24 (ref null $type35))
  (local $local26 (ref null $type35))
  (local.set $local25
   (ref.as_non_null
    (local.get $argument415)
   )
  )
  (local.set $local26
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if (result (ref $type29))
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local26)
     )
    )
    (ref.as_non_null
     (local.get $local25)
    )
   )
   (then
    (ref.as_non_null
     (local.get $argument416)
    )
   )
   (else
    (local.set $local10
     (ref.as_non_null
      (local.get $argument415)
     )
    )
    (local.set $local9
     (struct.get $type29 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (local.set $local11
     (i64.const 0)
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $local8
     (call $function41
      (struct.get $type30 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local9)
      )
      (local.get $local11)
     )
    )
    (local.set $local13
     (i64.const 2)
    )
    (local.set $local7
     (i64.rem_s
      (local.get $local8)
      (local.get $local13)
     )
    )
    (local.set $local14
     (i64.const 0)
    )
    (local.set $local1
     (if (result (ref $type29))
      (i64.eq
       (local.get $local7)
       (local.get $local14)
      )
      (then
       (ref.as_non_null
        (local.get $argument416)
       )
      )
      (else
       (local.set $local4
        (ref.as_non_null
         (local.get $argument416)
        )
       )
       (local.set $local5
        (ref.as_non_null
         (local.get $argument414)
        )
       )
       (local.set $local6
        (ref.as_non_null
         (global.get $global240)
        )
       )
       (call $function77
        (struct.get $type45 1
         (ref.as_non_null
          (local.get $local6)
         )
        )
        (ref.as_non_null
         (local.get $local4)
        )
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local15
     (ref.as_non_null
      (local.get $argument415)
     )
    )
    (local.set $local16
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (local.set $local3
     (call $function114
      (struct.get $type36 1
       (ref.as_non_null
        (local.get $local16)
       )
      )
      (ref.as_non_null
       (local.get $local15)
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local23
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.set $local24
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (if (result (ref $type29))
     (call $function48
      (struct.get $type35 1
       (ref.as_non_null
        (local.get $local24)
       )
      )
      (ref.as_non_null
       (local.get $local23)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
     (else
      (local.set $local18
       (ref.as_non_null
        (local.get $argument414)
       )
      )
      (local.set $local19
       (ref.as_non_null
        (local.get $argument414)
       )
      )
      (local.set $local20
       (ref.as_non_null
        (global.get $global240)
       )
      )
      (local.set $local17
       (call $function77
        (struct.get $type45 1
         (ref.as_non_null
          (local.get $local20)
         )
        )
        (ref.as_non_null
         (local.get $local18)
        )
        (ref.as_non_null
         (local.get $local19)
        )
       )
      )
      (if
       (i32.eqz
        (local.get $local2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local21
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local22
       (ref.as_non_null
        (local.get $local1)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized413)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture413)
      )
      (return_call $function116
       (local.get $capture413)
       (local.get $initialized413)
       (ref.as_non_null
        (local.get $local17)
       )
       (ref.as_non_null
        (local.get $local21)
       )
       (ref.as_non_null
        (local.get $local22)
       )
      )
     )
    )
   )
  )
 )
 (func $function117 (type $call65) (param $environment eqref) (param $argument420 (ref $type29)) (param $argument421 i64) (result (ref $type29))
  (local $local0 (ref null $type29))
  (local $local1 (ref null $type29))
  (local $local3 (ref null $type38))
  (local $local4 (ref null $type45))
  (local $local2 i64)
  (local.set $local0
   (ref.as_non_null
    (local.get $argument420)
   )
  )
  (local.set $local2
   (local.get $argument421)
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (local.set $local1
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global410)
   )
  )
  (return_call $function115
   (struct.get $type45 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function118 (type $call37) (param $environment eqref) (param $argument423 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument423)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function119
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function119 (param $capture424 i32) (param $initialized424 i32) (param $argument425 i64) (param $argument426 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local.set $local6
   (local.get $argument425)
  )
  (local.set $local7
   (i64.const 0)
  )
  (if (result i64)
   (i64.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (local.get $argument426)
   )
   (else
    (local.set $local1
     (local.get $argument425)
    )
    (local.set $local2
     (i64.const 2)
    )
    (local.set $local0
     (i64.div_s
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local4
     (local.get $argument426)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized424)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture424)
    )
    (return_call $function119
     (local.get $capture424)
     (local.get $initialized424)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function120 (type $call36) (param $environment eqref) (param $argument428 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local3 i32)
  (local $local6 i32)
  (local $local21 i32)
  (local $local27 i32)
  (local $local31 i32)
  (local $local37 i32)
  (local $local4 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local22 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local25 i64)
  (local $local26 i64)
  (local $local28 i64)
  (local $local29 i64)
  (local $local30 i64)
  (local $local33 i64)
  (local $local34 i64)
  (local $local35 i64)
  (local $local41 i64)
  (local $local42 i64)
  (local $local43 i64)
  (local $local44 i64)
  (local $local45 i64)
  (local $local46 i64)
  (local $local1 (ref null $type14))
  (local $local5 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local32 (ref null $type14))
  (local $local38 (ref null $type14))
  (local $local40 (ref null $type14))
  (local $local2 (ref null $type29))
  (local $local19 (ref null $type30))
  (local $local20 (ref null $type37))
  (local $local36 (ref null $type32))
  (local $local39 (ref null $type34))
  (local $local47 (ref null $type56))
  (local $local48 (ref null $type31))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument428)
   )
  )
  (local.set $local1
   (struct.get $type29 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local4
   (i64.extend_i32_u
    (array.len
     (ref.as_non_null
      (local.get $local5)
     )
    )
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (local.get $local4)
  )
  (local.set $local11
   (i64.const 1)
  )
  (local.set $local9
   (i64.sub
    (local.get $local10)
    (local.get $local11)
   )
  )
  (local.set $local12
   (i64.const 30)
  )
  (local.set $local8
   (i64.mul
    (local.get $local9)
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (local.get $local4)
  )
  (local.set $local18
   (i64.const 1)
  )
  (local.set $local16
   (i64.sub
    (local.get $local17)
    (local.get $local18)
   )
  )
  (local.set $local19
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (local.set $local14
   (call $function41
    (struct.get $type30 1
     (ref.as_non_null
      (local.get $local19)
     )
    )
    (ref.as_non_null
     (local.get $local15)
    )
    (local.get $local16)
   )
  )
  (local.set $local20
   (ref.as_non_null
    (global.get $global422)
   )
  )
  (local.set $local13
   (call $function118
    (struct.get $type37 1
     (ref.as_non_null
      (local.get $local20)
     )
    )
    (local.get $local14)
   )
  )
  (local.set $local7
   (i64.add
    (local.get $local8)
    (local.get $local13)
   )
  )
  (local.set $local6
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local6)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local24
   (local.get $local7)
  )
  (local.set $local25
   (i64.const 1)
  )
  (local.set $local23
   (i64.add
    (local.get $local24)
    (local.get $local25)
   )
  )
  (local.set $local26
   (i64.const 2)
  )
  (local.set $local22
   (i64.div_s
    (local.get $local23)
    (local.get $local26)
   )
  )
  (local.set $local21
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local21)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local29
   (local.get $local22)
  )
  (local.set $local30
   (i64.const 30)
  )
  (local.set $local28
   (i64.div_s
    (local.get $local29)
    (local.get $local30)
   )
  )
  (local.set $local27
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local27)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local34
   (local.get $local28)
  )
  (local.set $local35
   (i64.const 1)
  )
  (local.set $local33
   (i64.add
    (local.get $local34)
    (local.get $local35)
   )
  )
  (local.set $local36
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (local.set $local32
   (call $function43
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local36)
     )
    )
    (local.get $local33)
   )
  )
  (local.set $local31
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local31)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local40
   (ref.as_non_null
    (local.get $local32)
   )
  )
  (if
   (i32.eqz
    (local.get $local27)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local41
   (local.get $local28)
  )
  (local.set $local43
   (i64.const 2)
  )
  (if
   (i32.eqz
    (local.get $local21)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local45
   (local.get $local22)
  )
  (local.set $local46
   (i64.const 30)
  )
  (local.set $local44
   (i64.rem_s
    (local.get $local45)
    (local.get $local46)
   )
  )
  (local.set $local47
   (ref.as_non_null
    (global.get $global343)
   )
  )
  (local.set $local42
   (call $function98
    (struct.get $type56 1
     (ref.as_non_null
      (local.get $local47)
     )
    )
    (local.get $local43)
    (local.get $local44)
   )
  )
  (local.set $local48
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (drop
   (call $function42
    (struct.get $type31 1
     (ref.as_non_null
      (local.get $local48)
     )
    )
    (ref.as_non_null
     (local.get $local40)
    )
    (local.get $local41)
    (local.get $local42)
   )
  )
  (local.set $local37
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local31)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local38
   (ref.as_non_null
    (local.get $local32)
   )
  )
  (local.set $local39
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (return_call $function47
   (struct.get $type34 1
    (ref.as_non_null
     (local.get $local39)
    )
   )
   (local.get $local37)
   (ref.as_non_null
    (local.get $local38)
   )
  )
 )
 (func $function121 (type $call36) (param $environment eqref) (param $argument436 (ref $type29)) (result (ref $type29))
  (local $local0 (ref null $type29))
  (local $local1 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local7 (ref null $type29))
  (local $local2 (ref null $type36))
  (local $local6 (ref null $type35))
  (local $local3 i32)
  (local $local4 i32)
  (local.set $local7
   (ref.as_non_null
    (local.get $argument436)
   )
  )
  (if (result (ref $type29))
   (struct.get $type29 0
    (ref.as_non_null
     (local.get $local7)
    )
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local5
     (ref.as_non_null
      (local.get $argument436)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (if (result (ref $type29))
     (call $function48
      (struct.get $type35 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local5)
      )
     )
     (then
      (ref.as_non_null
       (local.get $argument436)
      )
     )
     (else
      (local.set $local1
       (ref.as_non_null
        (local.get $argument436)
       )
      )
      (local.set $local2
       (ref.as_non_null
        (global.get $global427)
       )
      )
      (local.set $local0
       (call $function120
        (struct.get $type36 1
         (ref.as_non_null
          (local.get $local2)
         )
        )
        (ref.as_non_null
         (local.get $local1)
        )
       )
      )
      (local.set $local4
       (i32.const 0)
      )
      (local.set $local3
       (i32.const 1)
      )
      (drop
       (i32.const 0)
      )
      (if
       (i32.eqz
        (local.get $local3)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $local4)
      )
      (return_call $function122
       (ref.as_non_null
        (local.get $argument436)
       )
       (local.get $local4)
       (local.get $local3)
       (ref.as_non_null
        (local.get $local0)
       )
      )
     )
    )
   )
  )
 )
 (func $function122 (param $capture436 (ref $type29)) (param $capture437 i32) (param $initialized437 i32) (param $argument438 (ref $type29)) (result (ref $type29))
  (local $local0 i32)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type29))
  (local $local4 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local6 (ref null $type29))
  (local $local10 (ref null $type29))
  (local $local11 (ref null $type29))
  (local $local12 (ref null $type29))
  (local $local7 (ref null $type45))
  (local $local8 (ref null $type45))
  (local $local9 (ref null $type36))
  (local $local13 (ref null $type42))
  (local.set $local3
   (ref.as_non_null
    (local.get $argument438)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $capture436)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $argument438)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global328)
   )
  )
  (local.set $local4
   (call $function94
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (ref.as_non_null
     (local.get $local5)
    )
    (ref.as_non_null
     (local.get $local6)
    )
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (local.set $local2
   (call $function71
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (ref.as_non_null
     (local.get $local3)
    )
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global406)
   )
  )
  (local.set $local1
   (call $function114
    (struct.get $type36 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (local.get $argument438)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (global.get $global187)
   )
  )
  (if (result (ref $type29))
   (call $function64
    (struct.get $type42 1
     (ref.as_non_null
      (local.get $local13)
     )
    )
    (ref.as_non_null
     (local.get $local11)
    )
    (ref.as_non_null
     (local.get $local12)
    )
   )
   (then
    (ref.as_non_null
     (local.get $argument438)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized437)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture437)
    )
    (return_call $function122
     (ref.as_non_null
      (local.get $capture436)
     )
     (local.get $capture437)
     (local.get $initialized437)
     (ref.as_non_null
      (local.get $local10)
     )
    )
   )
  )
 )
 (func $function123 (type $call66) (param $environment eqref) (param $argument441 (ref $type29)) (result (ref $type67))
  (local $local0 i32)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local4 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local6 (ref null $type29))
  (local $local7 (ref null $type29))
  (local $local8 (ref null $type29))
  (local $local9 (ref null $type29))
  (local $local3 (ref null $type36))
  (local $local10 (ref null $type45))
  (local $local11 (ref null $type45))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument441)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global435)
   )
  )
  (local.set $local1
   (call $function121
    (struct.get $type36 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $argument441)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (local.set $local7
   (call $function77
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local10)
     )
    )
    (ref.as_non_null
     (local.get $local8)
    )
    (ref.as_non_null
     (local.get $local9)
    )
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global220)
   )
  )
  (local.set $local5
   (call $function72
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (ref.as_non_null
     (local.get $local7)
    )
   )
  )
  (struct.new $type67
   (ref.as_non_null
    (local.get $local4)
   )
   (ref.as_non_null
    (local.get $local5)
   )
  )
 )
 (func $function124 (type $call71) (param $environment eqref) (param $argument444 f64) (result f64)
  (local $local0 i32)
  (local $local1 f64)
  (local $local2 f64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local5 f64)
  (local $local6 f64)
  (local.set $local2
   (local.get $argument444)
  )
  (local.set $local1
   (f64.trunc
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (local.get $argument444)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (if (result f64)
   (f64.lt
    (local.get $local5)
    (local.get $local6)
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (local.get $local1)
    )
    (local.set $local4
     (f64.const 1)
    )
    (f64.sub
     (local.get $local3)
     (local.get $local4)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
  )
 )
 (func $function125 (type $call38) (param $environment eqref) (param $argument447 i64) (result (ref $type29))
  (local $local0 i64)
  (local $local6 i64)
  (local $local1 f64)
  (local $local2 f64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local5 f64)
  (local $local7 f64)
  (local $local8 (ref null $type71))
  (local $local9 (ref null $type38))
  (local.set $local3
   (f64.const 2)
  )
  (local.set $local6
   (local.get $argument447)
  )
  (local.set $local5
   (f64.convert_i64_s
    (local.get $local6)
   )
  )
  (local.set $local7
   (f64.const 14.181647462)
  )
  (local.set $local4
   (f64.div
    (local.get $local5)
    (local.get $local7)
   )
  )
  (local.set $local2
   (f64.add
    (local.get $local3)
    (local.get $local4)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global443)
   )
  )
  (local.set $local1
   (call $function124
    (struct.get $type71 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i64.trunc_f64_s
    (local.get $local1)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (return_call $function53
   (struct.get $type38 1
    (ref.as_non_null
     (local.get $local9)
    )
   )
   (local.get $local0)
  )
 )
 (func $function126 (type $call72) (param $environment eqref) (param $argument454 (ref $type29)) (param $argument455 (ref $type29)) (result (ref null $type69))
  (local $local0 i32)
  (local $local10 i32)
  (local $local15 i32)
  (local $local20 i32)
  (local $local23 i32)
  (local $local27 i32)
  (local $local31 i32)
  (local $local34 i32)
  (local $local38 i32)
  (local $local61 i32)
  (local $local7 i64)
  (local $local67 i64)
  (local $local72 i64)
  (local $local78 i64)
  (local $local83 i64)
  (local $local90 i64)
  (local $local95 i64)
  (local $local106 i64)
  (local $local111 i64)
  (local $local118 i64)
  (local $local134 i64)
  (local $local1 (ref null $type29))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type29))
  (local $local4 (ref null $type29))
  (local $local6 (ref null $type29))
  (local $local12 (ref null $type29))
  (local $local13 (ref null $type29))
  (local $local17 (ref null $type29))
  (local $local18 (ref null $type29))
  (local $local21 (ref null $type29))
  (local $local24 (ref null $type29))
  (local $local28 (ref null $type29))
  (local $local32 (ref null $type29))
  (local $local35 (ref null $type29))
  (local $local39 (ref null $type29))
  (local $local42 (ref null $type29))
  (local $local43 (ref null $type29))
  (local $local44 (ref null $type29))
  (local $local46 (ref null $type29))
  (local $local47 (ref null $type29))
  (local $local48 (ref null $type29))
  (local $local50 (ref null $type29))
  (local $local51 (ref null $type29))
  (local $local52 (ref null $type29))
  (local $local53 (ref null $type29))
  (local $local55 (ref null $type29))
  (local $local56 (ref null $type29))
  (local $local57 (ref null $type29))
  (local $local62 (ref null $type29))
  (local $local63 (ref null $type29))
  (local $local64 (ref null $type29))
  (local $local65 (ref null $type29))
  (local $local66 (ref null $type29))
  (local $local69 (ref null $type29))
  (local $local71 (ref null $type29))
  (local $local75 (ref null $type29))
  (local $local76 (ref null $type29))
  (local $local77 (ref null $type29))
  (local $local80 (ref null $type29))
  (local $local82 (ref null $type29))
  (local $local87 (ref null $type29))
  (local $local88 (ref null $type29))
  (local $local89 (ref null $type29))
  (local $local92 (ref null $type29))
  (local $local94 (ref null $type29))
  (local $local99 (ref null $type29))
  (local $local100 (ref null $type29))
  (local $local101 (ref null $type29))
  (local $local102 (ref null $type29))
  (local $local103 (ref null $type29))
  (local $local104 (ref null $type29))
  (local $local105 (ref null $type29))
  (local $local110 (ref null $type29))
  (local $local114 (ref null $type29))
  (local $local115 (ref null $type29))
  (local $local116 (ref null $type29))
  (local $local117 (ref null $type29))
  (local $local120 (ref null $type29))
  (local $local122 (ref null $type29))
  (local $local124 (ref null $type29))
  (local $local125 (ref null $type29))
  (local $local126 (ref null $type29))
  (local $local127 (ref null $type29))
  (local $local129 (ref null $type29))
  (local $local133 (ref null $type29))
  (local $local136 (ref null $type29))
  (local $local137 (ref null $type29))
  (local $local138 (ref null $type29))
  (local $local5 (ref null $type45))
  (local $local9 (ref null $type45))
  (local $local45 (ref null $type45))
  (local $local49 (ref null $type45))
  (local $local54 (ref null $type45))
  (local $local58 (ref null $type45))
  (local $local59 (ref null $type45))
  (local $local70 (ref null $type45))
  (local $local74 (ref null $type45))
  (local $local81 (ref null $type45))
  (local $local85 (ref null $type45))
  (local $local86 (ref null $type45))
  (local $local93 (ref null $type45))
  (local $local97 (ref null $type45))
  (local $local98 (ref null $type45))
  (local $local108 (ref null $type45))
  (local $local109 (ref null $type45))
  (local $local113 (ref null $type45))
  (local $local121 (ref null $type45))
  (local $local123 (ref null $type45))
  (local $local128 (ref null $type45))
  (local $local130 (ref null $type45))
  (local $local131 (ref null $type45))
  (local $local139 (ref null $type45))
  (local $local8 (ref null $type38))
  (local $local68 (ref null $type38))
  (local $local73 (ref null $type38))
  (local $local79 (ref null $type38))
  (local $local84 (ref null $type38))
  (local $local91 (ref null $type38))
  (local $local96 (ref null $type38))
  (local $local107 (ref null $type38))
  (local $local112 (ref null $type38))
  (local $local119 (ref null $type38))
  (local $local135 (ref null $type38))
  (local $local11 (ref null $type69))
  (local $local16 (ref null $type69))
  (local $local22 (ref null $type69))
  (local $local25 (ref null $type69))
  (local $local29 (ref null $type69))
  (local $local33 (ref null $type69))
  (local $local36 (ref null $type69))
  (local $local40 (ref null $type69))
  (local $local14 (ref null $type72))
  (local $local19 (ref null $type72))
  (local $local26 (ref null $type70))
  (local $local30 (ref null $type70))
  (local $local37 (ref null $type70))
  (local $local41 (ref null $type70))
  (local $local60 (ref null $type68))
  (local $local132 (ref null $type68))
  (local $local140 (ref null $type42))
  (local.set $local134
   (i64.const 1)
  )
  (local.set $local135
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (local.set $local133
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local135)
     )
    )
    (local.get $local134)
   )
  )
  (local.set $local137
   (ref.as_non_null
    (local.get $argument455)
   )
  )
  (local.set $local138
   (ref.as_non_null
    (local.get $argument454)
   )
  )
  (local.set $local139
   (ref.as_non_null
    (global.get $global220)
   )
  )
  (local.set $local136
   (call $function72
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local139)
     )
    )
    (ref.as_non_null
     (local.get $local137)
    )
    (ref.as_non_null
     (local.get $local138)
    )
   )
  )
  (local.set $local140
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (if (result (ref null $type69))
   (call $function60
    (struct.get $type42 1
     (ref.as_non_null
      (local.get $local140)
     )
    )
    (ref.as_non_null
     (local.get $local133)
    )
    (ref.as_non_null
     (local.get $local136)
    )
   )
   (then
    (local.set $local67
     (i64.const 6)
    )
    (local.set $local68
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local66
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local68)
       )
      )
      (local.get $local67)
     )
    )
    (local.set $local69
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (local.set $local70
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local65
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local70)
       )
      )
      (ref.as_non_null
       (local.get $local66)
      )
      (ref.as_non_null
       (local.get $local69)
      )
     )
    )
    (local.set $local72
     (i64.const 5)
    )
    (local.set $local73
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local71
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local73)
       )
      )
      (local.get $local72)
     )
    )
    (local.set $local74
     (ref.as_non_null
      (global.get $global220)
     )
    )
    (local.set $local64
     (call $function72
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local74)
       )
      )
      (ref.as_non_null
       (local.get $local65)
      )
      (ref.as_non_null
       (local.get $local71)
      )
     )
    )
    (local.set $local78
     (i64.const 2)
    )
    (local.set $local79
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local77
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local79)
       )
      )
      (local.get $local78)
     )
    )
    (local.set $local80
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (local.set $local81
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local76
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local81)
       )
      )
      (ref.as_non_null
       (local.get $local77)
      )
      (ref.as_non_null
       (local.get $local80)
      )
     )
    )
    (local.set $local83
     (i64.const 1)
    )
    (local.set $local84
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local82
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local84)
       )
      )
      (local.get $local83)
     )
    )
    (local.set $local85
     (ref.as_non_null
      (global.get $global220)
     )
    )
    (local.set $local75
     (call $function72
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local85)
       )
      )
      (ref.as_non_null
       (local.get $local76)
      )
      (ref.as_non_null
       (local.get $local82)
      )
     )
    )
    (local.set $local86
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local63
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local86)
       )
      )
      (ref.as_non_null
       (local.get $local64)
      )
      (ref.as_non_null
       (local.get $local75)
      )
     )
    )
    (local.set $local90
     (i64.const 6)
    )
    (local.set $local91
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local89
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local91)
       )
      )
      (local.get $local90)
     )
    )
    (local.set $local92
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (local.set $local93
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local88
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local93)
       )
      )
      (ref.as_non_null
       (local.get $local89)
      )
      (ref.as_non_null
       (local.get $local92)
      )
     )
    )
    (local.set $local95
     (i64.const 1)
    )
    (local.set $local96
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local94
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local96)
       )
      )
      (local.get $local95)
     )
    )
    (local.set $local97
     (ref.as_non_null
      (global.get $global220)
     )
    )
    (local.set $local87
     (call $function72
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local97)
       )
      )
      (ref.as_non_null
       (local.get $local88)
      )
      (ref.as_non_null
       (local.get $local94)
      )
     )
    )
    (local.set $local98
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local62
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local98)
       )
      )
      (ref.as_non_null
       (local.get $local63)
      )
      (ref.as_non_null
       (local.get $local87)
      )
     )
    )
    (local.set $local61
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local61)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local99
     (ref.as_non_null
      (local.get $local62)
     )
    )
    (local.set $local102
     (ref.as_non_null
      (global.get $global451)
     )
    )
    (local.set $local104
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (local.set $local106
     (i64.const 3)
    )
    (local.set $local107
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local105
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local107)
       )
      )
      (local.get $local106)
     )
    )
    (local.set $local108
     (ref.as_non_null
      (global.get $global410)
     )
    )
    (local.set $local103
     (call $function115
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local108)
       )
      )
      (ref.as_non_null
       (local.get $local104)
      )
      (ref.as_non_null
       (local.get $local105)
      )
     )
    )
    (local.set $local109
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local101
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local109)
       )
      )
      (ref.as_non_null
       (local.get $local102)
      )
      (ref.as_non_null
       (local.get $local103)
      )
     )
    )
    (local.set $local111
     (i64.const 24)
    )
    (local.set $local112
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local110
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local112)
       )
      )
      (local.get $local111)
     )
    )
    (local.set $local113
     (ref.as_non_null
      (global.get $global328)
     )
    )
    (local.set $local100
     (call $function94
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local113)
       )
      )
      (ref.as_non_null
       (local.get $local101)
      )
      (ref.as_non_null
       (local.get $local110)
      )
     )
    )
    (local.set $local118
     (i64.const -1)
    )
    (local.set $local119
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local117
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local119)
       )
      )
      (local.get $local118)
     )
    )
    (local.set $local120
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (local.set $local121
     (ref.as_non_null
      (global.get $global410)
     )
    )
    (local.set $local116
     (call $function115
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local121)
       )
      )
      (ref.as_non_null
       (local.get $local117)
      )
      (ref.as_non_null
       (local.get $local120)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local61)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local122
     (ref.as_non_null
      (local.get $local62)
     )
    )
    (local.set $local123
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local115
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local123)
       )
      )
      (ref.as_non_null
       (local.get $local116)
      )
      (ref.as_non_null
       (local.get $local122)
      )
     )
    )
    (local.set $local126
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (local.set $local127
     (ref.as_non_null
      (global.get $global449)
     )
    )
    (local.set $local128
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local125
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local128)
       )
      )
      (ref.as_non_null
       (local.get $local126)
      )
      (ref.as_non_null
       (local.get $local127)
      )
     )
    )
    (local.set $local129
     (ref.as_non_null
      (global.get $global448)
     )
    )
    (local.set $local130
     (ref.as_non_null
      (global.get $global215)
     )
    )
    (local.set $local124
     (call $function71
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local130)
       )
      )
      (ref.as_non_null
       (local.get $local125)
      )
      (ref.as_non_null
       (local.get $local129)
      )
     )
    )
    (local.set $local131
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local114
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local131)
       )
      )
      (ref.as_non_null
       (local.get $local115)
      )
      (ref.as_non_null
       (local.get $local124)
      )
     )
    )
    (local.set $local132
     (ref.as_non_null
      (global.get $global457)
     )
    )
    (return_call $function127
     (struct.get $type68 1
      (ref.as_non_null
       (local.get $local132)
      )
     )
     (struct.new $type69
      (ref.as_non_null
       (local.get $local99)
      )
      (struct.new $type69
       (ref.as_non_null
        (local.get $local100)
       )
       (struct.new $type69
        (ref.as_non_null
         (local.get $local114)
        )
        (ref.null none)
       )
      )
     )
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $argument454)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global215)
     )
    )
    (local.set $local2
     (call $function71
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (ref.as_non_null
       (local.get $local4)
      )
     )
    )
    (local.set $local7
     (i64.const 2)
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global145)
     )
    )
    (local.set $local6
     (call $function53
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (local.get $local7)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global328)
     )
    )
    (local.set $local1
     (call $function94
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (ref.as_non_null
       (local.get $local6)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $argument454)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready453)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global453)
     )
    )
    (local.set $local11
     (call $function126
      (struct.get $type72 1
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (ref.as_non_null
       (local.get $local12)
      )
      (ref.as_non_null
       (local.get $local13)
      )
     )
    )
    (local.set $local10
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local17
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local18
     (ref.as_non_null
      (local.get $argument455)
     )
    )
    (if
     (i32.eqz
      (global.get $ready453)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local19
     (ref.as_non_null
      (global.get $global453)
     )
    )
    (local.set $local16
     (call $function126
      (struct.get $type72 1
       (ref.as_non_null
        (local.get $local19)
       )
      )
      (ref.as_non_null
       (local.get $local17)
      )
      (ref.as_non_null
       (local.get $local18)
      )
     )
    )
    (local.set $local15
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local22
     (local.get $local11)
    )
    (local.set $local21
     (struct.get $type69 0
      (local.get $local22)
     )
    )
    (local.set $local20
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local25
     (local.get $local11)
    )
    (local.set $local26
     (ref.as_non_null
      (global.get $global464)
     )
    )
    (local.set $local24
     (call $function128
      (struct.get $type70 1
       (ref.as_non_null
        (local.get $local26)
       )
      )
      (local.get $local25)
     )
    )
    (local.set $local23
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local10)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local29
     (local.get $local11)
    )
    (local.set $local30
     (ref.as_non_null
      (global.get $global467)
     )
    )
    (local.set $local28
     (call $function129
      (struct.get $type70 1
       (ref.as_non_null
        (local.get $local30)
       )
      )
      (local.get $local29)
     )
    )
    (local.set $local27
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local15)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local33
     (local.get $local16)
    )
    (local.set $local32
     (struct.get $type69 0
      (local.get $local33)
     )
    )
    (local.set $local31
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local15)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local36
     (local.get $local16)
    )
    (local.set $local37
     (ref.as_non_null
      (global.get $global464)
     )
    )
    (local.set $local35
     (call $function128
      (struct.get $type70 1
       (ref.as_non_null
        (local.get $local37)
       )
      )
      (local.get $local36)
     )
    )
    (local.set $local34
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local15)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local40
     (local.get $local16)
    )
    (local.set $local41
     (ref.as_non_null
      (global.get $global467)
     )
    )
    (local.set $local39
     (call $function129
      (struct.get $type70 1
       (ref.as_non_null
        (local.get $local41)
       )
      )
      (local.get $local40)
     )
    )
    (local.set $local38
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local20)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local43
     (ref.as_non_null
      (local.get $local21)
     )
    )
    (if
     (i32.eqz
      (local.get $local31)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local44
     (ref.as_non_null
      (local.get $local32)
     )
    )
    (local.set $local45
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local42
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local45)
       )
      )
      (ref.as_non_null
       (local.get $local43)
      )
      (ref.as_non_null
       (local.get $local44)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local23)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local47
     (ref.as_non_null
      (local.get $local24)
     )
    )
    (if
     (i32.eqz
      (local.get $local34)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local48
     (ref.as_non_null
      (local.get $local35)
     )
    )
    (local.set $local49
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local46
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local49)
       )
      )
      (ref.as_non_null
       (local.get $local47)
      )
      (ref.as_non_null
       (local.get $local48)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local27)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local52
     (ref.as_non_null
      (local.get $local28)
     )
    )
    (if
     (i32.eqz
      (local.get $local34)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local53
     (ref.as_non_null
      (local.get $local35)
     )
    )
    (local.set $local54
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local51
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local54)
       )
      )
      (ref.as_non_null
       (local.get $local52)
      )
      (ref.as_non_null
       (local.get $local53)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local38)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local56
     (ref.as_non_null
      (local.get $local39)
     )
    )
    (if
     (i32.eqz
      (local.get $local20)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local57
     (ref.as_non_null
      (local.get $local21)
     )
    )
    (local.set $local58
     (ref.as_non_null
      (global.get $global240)
     )
    )
    (local.set $local55
     (call $function77
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local58)
       )
      )
      (ref.as_non_null
       (local.get $local56)
      )
      (ref.as_non_null
       (local.get $local57)
      )
     )
    )
    (local.set $local59
     (ref.as_non_null
      (global.get $global215)
     )
    )
    (local.set $local50
     (call $function71
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local59)
       )
      )
      (ref.as_non_null
       (local.get $local51)
      )
      (ref.as_non_null
       (local.get $local55)
      )
     )
    )
    (local.set $local60
     (ref.as_non_null
      (global.get $global457)
     )
    )
    (return_call $function127
     (struct.get $type68 1
      (ref.as_non_null
       (local.get $local60)
      )
     )
     (struct.new $type69
      (ref.as_non_null
       (local.get $local42)
      )
      (struct.new $type69
       (ref.as_non_null
        (local.get $local46)
       )
       (struct.new $type69
        (ref.as_non_null
         (local.get $local50)
        )
        (ref.null none)
       )
      )
     )
    )
   )
  )
 )
 (func $function127 (type $call68) (param $environment eqref) (param $argument458 (ref null $type69)) (result (ref null $type69))
  (local.get $argument458)
 )
 (func $function128 (type $call70) (param $environment eqref) (param $argument465 (ref null $type69)) (result (ref $type29))
  (local $local0 (ref null $type69))
  (local $local1 (ref null $type69))
  (local.set $local1
   (local.get $argument465)
  )
  (local.set $local0
   (struct.get $type69 1
    (local.get $local1)
   )
  )
  (struct.get $type69 0
   (local.get $local0)
  )
 )
 (func $function129 (type $call70) (param $environment eqref) (param $argument468 (ref null $type69)) (result (ref $type29))
  (local $local0 (ref null $type69))
  (local $local1 (ref null $type69))
  (local $local2 (ref null $type69))
  (local.set $local2
   (local.get $argument468)
  )
  (local.set $local1
   (struct.get $type69 1
    (local.get $local2)
   )
  )
  (local.set $local0
   (struct.get $type69 1
    (local.get $local1)
   )
  )
  (struct.get $type69 0
   (local.get $local0)
  )
 )
 (func $function130 (type $call38) (param $environment eqref) (param $argument473 i64) (result (ref $type29))
  (local $local0 i32)
  (local $local4 i32)
  (local $local16 i32)
  (local $local23 i32)
  (local $local26 i32)
  (local $local30 i32)
  (local $local2 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local19 i64)
  (local $local1 (ref null $type29))
  (local $local5 (ref null $type29))
  (local $local6 (ref null $type29))
  (local $local7 (ref null $type29))
  (local $local8 (ref null $type29))
  (local $local9 (ref null $type29))
  (local $local18 (ref null $type29))
  (local $local21 (ref null $type29))
  (local $local24 (ref null $type29))
  (local $local27 (ref null $type29))
  (local $local31 (ref null $type29))
  (local $local34 (ref null $type29))
  (local $local35 (ref null $type29))
  (local $local36 (ref null $type29))
  (local $local37 (ref null $type29))
  (local $local39 (ref null $type29))
  (local $local41 (ref null $type29))
  (local $local42 (ref null $type29))
  (local $local43 (ref null $type29))
  (local $local44 (ref null $type29))
  (local $local45 (ref null $type29))
  (local $local46 (ref null $type29))
  (local $local47 (ref null $type29))
  (local $local3 (ref null $type38))
  (local $local11 (ref null $type38))
  (local $local20 (ref null $type38))
  (local $local13 (ref null $type65))
  (local $local14 (ref null $type45))
  (local $local38 (ref null $type45))
  (local $local40 (ref null $type45))
  (local $local48 (ref null $type45))
  (local $local49 (ref null $type45))
  (local $local50 (ref null $type45))
  (local $local51 (ref null $type45))
  (local $local15 (ref null $type36))
  (local $local17 (ref null $type69))
  (local $local25 (ref null $type69))
  (local $local28 (ref null $type69))
  (local $local32 (ref null $type69))
  (local $local22 (ref null $type72))
  (local $local29 (ref null $type70))
  (local $local33 (ref null $type70))
  (local.set $local2
   (local.get $argument473)
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global446)
   )
  )
  (local.set $local1
   (call $function125
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global450)
   )
  )
  (local.set $local10
   (i64.const 100)
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (local.set $local9
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (local.get $local10)
   )
  )
  (local.set $local12
   (local.get $argument473)
  )
  (local.set $local13
   (ref.as_non_null
    (global.get $global419)
   )
  )
  (local.set $local8
   (call $function117
    (struct.get $type65 1
     (ref.as_non_null
      (local.get $local13)
     )
    )
    (ref.as_non_null
     (local.get $local9)
    )
    (local.get $local12)
   )
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (local.set $local6
   (call $function77
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (ref.as_non_null
     (local.get $local7)
    )
    (ref.as_non_null
     (local.get $local8)
    )
   )
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global435)
   )
  )
  (local.set $local5
   (call $function121
    (struct.get $type36 1
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (local.set $local19
   (i64.const 0)
  )
  (local.set $local20
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (local.set $local18
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local20)
     )
    )
    (local.get $local19)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local21
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local22
   (ref.as_non_null
    (global.get $global453)
   )
  )
  (local.set $local17
   (call $function126
    (struct.get $type72 1
     (ref.as_non_null
      (local.get $local22)
     )
    )
    (ref.as_non_null
     (local.get $local18)
    )
    (ref.as_non_null
     (local.get $local21)
    )
   )
  )
  (local.set $local16
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local25
   (local.get $local17)
  )
  (local.set $local24
   (struct.get $type69 0
    (local.get $local25)
   )
  )
  (local.set $local23
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local28
   (local.get $local17)
  )
  (local.set $local29
   (ref.as_non_null
    (global.get $global464)
   )
  )
  (local.set $local27
   (call $function128
    (struct.get $type70 1
     (ref.as_non_null
      (local.get $local29)
     )
    )
    (local.get $local28)
   )
  )
  (local.set $local26
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local32
   (local.get $local17)
  )
  (local.set $local33
   (ref.as_non_null
    (global.get $global467)
   )
  )
  (local.set $local31
   (call $function129
    (struct.get $type70 1
     (ref.as_non_null
      (local.get $local33)
     )
    )
    (local.get $local32)
   )
  )
  (local.set $local30
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local26)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local36
   (ref.as_non_null
    (local.get $local27)
   )
  )
  (local.set $local37
   (ref.as_non_null
    (global.get $global450)
   )
  )
  (local.set $local38
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (local.set $local35
   (call $function77
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local38)
     )
    )
    (ref.as_non_null
     (local.get $local36)
    )
    (ref.as_non_null
     (local.get $local37)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local39
   (ref.as_non_null
    (local.get $local5)
   )
  )
  (local.set $local40
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (local.set $local34
   (call $function77
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local40)
     )
    )
    (ref.as_non_null
     (local.get $local35)
    )
    (ref.as_non_null
     (local.get $local39)
    )
   )
  )
  (local.set $local42
   (ref.as_non_null
    (global.get $global452)
   )
  )
  (if
   (i32.eqz
    (local.get $local30)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local44
   (ref.as_non_null
    (local.get $local31)
   )
  )
  (if
   (i32.eqz
    (local.get $local26)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local46
   (ref.as_non_null
    (local.get $local27)
   )
  )
  (local.set $local47
   (ref.as_non_null
    (global.get $global448)
   )
  )
  (local.set $local48
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (local.set $local45
   (call $function77
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local48)
     )
    )
    (ref.as_non_null
     (local.get $local46)
    )
    (ref.as_non_null
     (local.get $local47)
    )
   )
  )
  (local.set $local49
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (local.set $local43
   (call $function71
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local49)
     )
    )
    (ref.as_non_null
     (local.get $local44)
    )
    (ref.as_non_null
     (local.get $local45)
    )
   )
  )
  (local.set $local50
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (local.set $local41
   (call $function77
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local50)
     )
    )
    (ref.as_non_null
     (local.get $local42)
    )
    (ref.as_non_null
     (local.get $local43)
    )
   )
  )
  (local.set $local51
   (ref.as_non_null
    (global.get $global328)
   )
  )
  (return_call $function94
   (struct.get $type45 1
    (ref.as_non_null
     (local.get $local51)
    )
   )
   (ref.as_non_null
    (local.get $local34)
   )
   (ref.as_non_null
    (local.get $local41)
   )
  )
 )
 (func $function131 (type $call38) (param $environment eqref) (param $argument481 i64) (result (ref $type29))
  (local $local0 i32)
  (local $local3 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local4 (ref null $type16))
  (local $local6 (ref null $type15))
  (local.set $local2
   (local.get $argument481)
  )
  (local.set $local1
   (call $foreign0
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (local.get $local1)
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local4
   (call $function25
    (struct.get $type15 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
    (local.get $local5)
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (return_call $function132
   (local.get $argument481)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (block (result (ref $type16))
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (local.get $local9)
   (local.get $local8)
   (local.get $local7)
  )
 )
 (func $function132 (param $capture481 i64) (param $capture482 i64) (param $capture483 (ref $type16)) (param $capture484 i32) (param $initialized484 i32) (param $argument485 i64) (result (ref $type29))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local5 i32)
  (local $local8 i32)
  (local $local3 (ref null $type16))
  (local $local9 (ref null $type16))
  (local $local10 (ref null $type58))
  (local.set $local11
   (local.get $argument485)
  )
  (local.set $local12
   (local.get $capture482)
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $local11)
    (local.get $local12)
   )
   (then
    (local.set $local9
     (ref.as_non_null
      (local.get $capture483)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global360)
     )
    )
    (return_call $function102
     (struct.get $type58 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (ref.as_non_null
      (local.get $local9)
     )
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture483)
     )
    )
    (local.set $local4
     (local.get $argument485)
    )
    (local.set $local6
     (local.get $capture481)
    )
    (local.set $local7
     (local.get $argument485)
    )
    (local.set $local5
     (call $foreign1
      (local.get $local6)
      (local.get $local7)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local4)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local3)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (i32.wrap_i64
      (local.get $local4)
     )
    )
    (array.set $type17
     (call $string-block
      (ref.as_non_null
       (local.get $local3)
      )
      (local.get $local8)
     )
     (i32.and
      (local.get $local8)
      (i32.const 8191)
     )
     (local.get $local5)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument485)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized484)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture484)
    )
    (return_call $function132
     (local.get $capture481)
     (local.get $capture482)
     (ref.as_non_null
      (local.get $capture483)
     )
     (local.get $capture484)
     (local.get $initialized484)
     (local.get $local0)
    )
   )
  )
 )
 (func $function133 (type $call75) (param $environment eqref) (param $argument487 (ref $type29)) (result i32)
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local4 i64)
  (local $local1 (ref null $type16))
  (local $local2 (ref null $type29))
  (local $local3 (ref null $type64))
  (local.set $local2
   (ref.as_non_null
    (local.get $argument487)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global400)
   )
  )
  (local.set $local1
   (call $function113
    (struct.get $type64 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local6
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local5)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local6)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function134
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local6)
   (local.get $local5)
   (local.get $local4)
  )
 )
 (func $function134 (param $capture488 (ref $type16)) (param $capture489 i32) (param $initialized489 i32) (param $argument490 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type16))
  (local $local9 (ref null $type16))
  (local.set $local7
   (local.get $argument490)
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $capture488)
   )
  )
  (local.set $local8
   (i64.extend_i32_u
    (struct.get $type16 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture488)
     )
    )
    (local.set $local5
     (local.get $argument490)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type16 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type17
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (call $foreign2
     (local.get $local3)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument490)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized489)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture489)
    )
    (return_call $function134
     (ref.as_non_null
      (local.get $capture488)
     )
     (local.get $capture489)
     (local.get $initialized489)
     (local.get $local0)
    )
   )
  )
 )
 (func $function135 (type $call77) (param $environment eqref) (param $argument492 (ref null $type69)) (result i32)
  (local $local0 (ref null $type75))
  (local $local1 (ref null $type69))
  (local $local2 (ref null $type76))
  (local.set $local0
   (ref.as_non_null
    (global.get $global486)
   )
  )
  (local.set $local1
   (local.get $argument492)
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global493)
   )
  )
  (return_call $function136
   (struct.get $type76 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
  )
 )
 (func $function136 (type $call76) (param $environment eqref) (param $argument494 (ref $type75)) (param $argument495 (ref null $type69)) (result i32)
  (local $local0 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local7 i64)
  (local $local2 (ref null $type69))
  (local.set $local7
   (i64.const 40)
  )
  (if
   (i64.gt_u
    (local.get $local7)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ge_u
     (local.get $local7)
     (i64.const 55296)
    )
    (i64.le_u
     (local.get $local7)
     (i64.const 57343)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (i32.wrap_i64
    (local.get $local7)
   )
  )
  (call $foreign2
   (local.get $local6)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local2
   (local.get $argument495)
  )
  (local.set $local3
   (i32.const 1)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (drop
   (call $function137
    (ref.as_non_null
     (local.get $argument494)
    )
    (local.get $local5)
    (local.get $local4)
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local1
   (i64.const 41)
  )
  (if
   (i64.gt_u
    (local.get $local1)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ge_u
     (local.get $local1)
     (i64.const 55296)
    )
    (i64.le_u
     (local.get $local1)
     (i64.const 57343)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (i32.wrap_i64
    (local.get $local1)
   )
  )
  (call $foreign2
   (local.get $local0)
  )
  (i32.const 0)
 )
 (func $function137 (param $capture494 (ref $type75)) (param $capture496 i32) (param $initialized496 i32) (param $argument497 (ref null $type69)) (param $argument498 i32) (result i32)
  (local $local0 (ref null $type69))
  (local $local1 (ref null $type69))
  (local $local4 (ref null $type69))
  (local $local7 (ref null $type69))
  (local $local3 (ref null $type29))
  (local $local5 (ref null $type75))
  (local $local2 i32)
  (local $local6 i32)
  (local.set $local7
   (local.get $argument497)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local7)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (if (result i32)
      (local.get $argument498)
      (then
       (i32.const 0)
      )
      (else
       (local.set $local6
        (i32.const 32)
       )
       (call $foreign2
        (local.get $local6)
       )
       (drop
        (i32.const 0)
       )
       (i32.const 0)
      )
     )
    )
    (local.set $local4
     (local.get $argument497)
    )
    (local.set $local3
     (struct.get $type69 0
      (local.get $local4)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $capture494)
     )
    )
    (drop
     (call_ref $call75
      (struct.get $type75 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (struct.get $type75 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
     )
    )
    (local.set $local1
     (local.get $argument497)
    )
    (local.set $local0
     (struct.get $type69 1
      (local.get $local1)
     )
    )
    (local.set $local2
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $initialized496)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture496)
    )
    (return_call $function137
     (ref.as_non_null
      (local.get $capture494)
     )
     (local.get $capture496)
     (local.get $initialized496)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function138 (param $capture503 i32) (param $initialized503 i32) (param $argument504 i64) (result (ref null $type69))
  (local $local0 (ref null $type29))
  (local $local2 (ref null $type38))
  (local $local3 (ref null $type69))
  (local $local1 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local.set $local7
   (local.get $argument504)
  )
  (local.set $local8
   (call $foreign3)
  )
  (if (result (ref null $type69))
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $local1
     (local.get $argument504)
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global480)
     )
    )
    (local.set $local0
     (call $function131
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (local.get $local1)
     )
    )
    (local.set $local5
     (local.get $argument504)
    )
    (local.set $local6
     (i64.const 1)
    )
    (local.set $local4
     (i64.add
      (local.get $local5)
      (local.get $local6)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized503)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture503)
    )
    (local.set $local3
     (call $function138
      (local.get $capture503)
      (local.get $initialized503)
      (local.get $local4)
     )
    )
    (struct.new $type69
     (ref.as_non_null
      (local.get $local0)
     )
     (local.get $local3)
    )
   )
  )
 )
 (func $function139 (type $call37) (param $environment eqref) (param $argument507 i64) (result i64)
  (local $local0 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local $local1 (ref null $type69))
  (local.set $local4
   (local.get $argument507)
  )
  (local.set $local5
   (i64.const 1)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local4)
    (local.get $local5)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $local0
     (i64.const 0)
    )
    (local.set $local1
     (ref.null none)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local3
     (i32.const 0)
    )
    (local.set $local2
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local3)
    )
    (return_call $function140
     (local.get $argument507)
     (local.get $local3)
     (local.get $local2)
     (local.get $local0)
     (local.get $local1)
    )
   )
  )
 )
 (func $function140 (param $capture507 i64) (param $capture508 i32) (param $initialized508 i32) (param $argument509 i64) (param $argument510 (ref null $type69)) (result i64)
  (local $local0 (ref null $type69))
  (local $local1 (ref null $type69))
  (local $local4 (ref null $type69))
  (local $local8 (ref null $type69))
  (local $local2 (ref null $type74))
  (local $local3 (ref null $type78))
  (local $local15 (ref null $type73))
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local.set $local16
   (local.get $argument509)
  )
  (local.set $local17
   (local.get $capture507)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local16)
    (local.get $local17)
   )
   (then
    (local.set $local6
     (local.get $argument509)
    )
    (local.set $local7
     (i64.const 1)
    )
    (local.set $local5
     (i64.add
      (local.get $local6)
      (local.get $local7)
     )
    )
    (local.set $local10
     (global.get $global499)
    )
    (local.set $local9
     (call $foreign4
      (local.get $local10)
     )
    )
    (local.set $local12
     (global.get $global500)
    )
    (local.set $local11
     (call $foreign4
      (local.get $local12)
     )
    )
    (local.set $local14
     (global.get $global501)
    )
    (local.set $local13
     (call $foreign4
      (local.get $local14)
     )
    )
    (local.set $local15
     (ref.as_non_null
      (global.get $global511)
     )
    )
    (local.set $local8
     (call $function141
      (struct.get $type73 1
       (ref.as_non_null
        (local.get $local15)
       )
      )
      (local.get $local9)
      (local.get $local11)
      (local.get $local13)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized508)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture508)
    )
    (return_call $function140
     (local.get $capture507)
     (local.get $capture508)
     (local.get $initialized508)
     (local.get $local5)
     (local.get $local8)
    )
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (global.get $global505)
     )
    )
    (local.set $local4
     (local.get $argument510)
    )
    (struct.set $type78 0
     (ref.as_non_null
      (local.get $local3)
     )
     (local.get $local4)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local0
     (local.get $argument510)
    )
    (local.set $local1
     (global.get $global502)
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global515)
     )
    )
    (if (result i64)
     (call $function142
      (struct.get $type74 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (local.get $local0)
      (local.get $local1)
     )
     (then
      (i64.const 1)
     )
     (else
      (i64.const 0)
     )
    )
   )
  )
 )
 (func $function141 (type $call73) (param $environment eqref) (param $argument512 i64) (param $argument513 i64) (param $argument514 i64) (result (ref null $type69))
  (local $local0 (ref null $type29))
  (local $local2 (ref null $type38))
  (local $local3 (ref null $type69))
  (local $local9 (ref null $type73))
  (local $local1 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local.set $local10
   (local.get $argument513)
  )
  (local.set $local11
   (local.get $argument512)
  )
  (if (result (ref null $type69))
   (i64.lt_s
    (local.get $local10)
    (local.get $local11)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $local1
     (local.get $argument512)
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global472)
     )
    )
    (local.set $local0
     (call $function130
      (struct.get $type38 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (local.get $local1)
     )
    )
    (local.set $local5
     (local.get $argument512)
    )
    (local.set $local6
     (local.get $argument514)
    )
    (local.set $local4
     (i64.add
      (local.get $local5)
      (local.get $local6)
     )
    )
    (local.set $local7
     (local.get $argument513)
    )
    (local.set $local8
     (local.get $argument514)
    )
    (if
     (i32.eqz
      (global.get $ready511)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global511)
     )
    )
    (local.set $local3
     (call $function141
      (struct.get $type73 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.get $local4)
      (local.get $local7)
      (local.get $local8)
     )
    )
    (struct.new $type69
     (ref.as_non_null
      (local.get $local0)
     )
     (local.get $local3)
    )
   )
  )
 )
 (func $function142 (type $call74) (param $environment eqref) (param $argument516 (ref null $type69)) (param $argument517 (ref null $type69)) (result i32)
  (local $local0 (ref null $type69))
  (local $local1 (ref null $type69))
  (local $local2 (ref null $type69))
  (local $local3 (ref null $type69))
  (local $local6 (ref null $type69))
  (local $local8 (ref null $type69))
  (local $local11 (ref null $type69))
  (local $local12 (ref null $type69))
  (local $local13 (ref null $type69))
  (local $local4 (ref null $type74))
  (local $local5 (ref null $type29))
  (local $local7 (ref null $type29))
  (local $local9 (ref null $type42))
  (local $local10 i32)
  (local.set $local13
   (local.get $argument516)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local13)
   )
   (then
    (local.set $local12
     (local.get $argument517)
    )
    (ref.is_null
     (local.get $local12)
    )
   )
   (else
    (local.set $local11
     (local.get $argument517)
    )
    (local.set $local10
     (ref.is_null
      (local.get $local11)
     )
    )
    (if (result i32)
     (i32.eqz
      (local.get $local10)
     )
     (then
      (local.set $local6
       (local.get $argument516)
      )
      (local.set $local5
       (struct.get $type69 0
        (local.get $local6)
       )
      )
      (local.set $local8
       (local.get $argument517)
      )
      (local.set $local7
       (struct.get $type69 0
        (local.get $local8)
       )
      )
      (local.set $local9
       (ref.as_non_null
        (global.get $global175)
       )
      )
      (if (result i32)
       (call $function60
        (struct.get $type42 1
         (ref.as_non_null
          (local.get $local9)
         )
        )
        (ref.as_non_null
         (local.get $local5)
        )
        (ref.as_non_null
         (local.get $local7)
        )
       )
       (then
        (local.set $local1
         (local.get $argument516)
        )
        (local.set $local0
         (struct.get $type69 1
          (local.get $local1)
         )
        )
        (local.set $local3
         (local.get $argument517)
        )
        (local.set $local2
         (struct.get $type69 1
          (local.get $local3)
         )
        )
        (if
         (i32.eqz
          (global.get $ready515)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local4
         (ref.as_non_null
          (global.get $global515)
         )
        )
        (return_call $function142
         (struct.get $type74 1
          (ref.as_non_null
           (local.get $local4)
          )
         )
         (local.get $local0)
         (local.get $local2)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function143 (type $call10) (param $environment eqref) (result i32)
  (local $local0 i32)
  (local $local1 (ref null $type75))
  (local $local2 (ref null $type69))
  (local $local3 (ref null $type78))
  (local $local4 (ref null $type76))
  (local.set $local1
   (ref.as_non_null
    (global.get $global486)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global505)
   )
  )
  (local.set $local2
   (struct.get $type78 0
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global493)
   )
  )
  (drop
   (call $function136
    (struct.get $type76 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 10)
  )
  (call $foreign2
   (local.get $local0)
  )
  (i32.const 0)
 )
 (func $export0 (param $argument0 i64) (result i64)
  (local $local0 (ref null $type37))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready506)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global506)
   )
  )
  (return_call $function139
   (struct.get $type37 1
    (ref.as_non_null
     (local.get $local0)
    )
   )
   (local.get $argument0)
  )
 )
 (func $export1
  (local $local0 (ref null $type10))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready518)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global518)
   )
  )
  (drop
   (call $function143
    (struct.get $type10 1
     (ref.as_non_null
      (local.get $local0)
     )
    )
   )
  )
 )
 (func $main
  (local $local0 (ref null $type69))
  (local $local8 (ref null $type38))
  (local $local11 (ref null $type38))
  (local $local14 (ref null $type38))
  (local $local17 (ref null $type38))
  (local $local19 (ref null $type38))
  (local $local21 (ref null $type38))
  (local $local9 (ref null $type29))
  (local $local12 (ref null $type29))
  (local $local15 (ref null $type45))
  (local $local23 (ref null $type14))
  (local $local1 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local16 i64)
  (local $local18 i64)
  (local $local20 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local22 i32)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new $type0
    (ref.func $function0)
    (ref.null none)
   )
  )
  (global.set $ready0
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global3
   (struct.new $type1
    (ref.func $function1)
    (ref.null none)
   )
  )
  (global.set $ready3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global6
   (struct.new $type0
    (ref.func $function2)
    (ref.null none)
   )
  )
  (global.set $ready6
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global9
   (struct.new $type1
    (ref.func $function3)
    (ref.null none)
   )
  )
  (global.set $ready9
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global12
   (struct.new $type0
    (ref.func $function4)
    (ref.null none)
   )
  )
  (global.set $ready12
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global15
   (struct.new $type1
    (ref.func $function5)
    (ref.null none)
   )
  )
  (global.set $ready15
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global18
   (struct.new $type0
    (ref.func $function6)
    (ref.null none)
   )
  )
  (global.set $ready18
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global21
   (struct.new $type1
    (ref.func $function7)
    (ref.null none)
   )
  )
  (global.set $ready21
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global24
   (struct.new $type2
    (ref.func $function8)
    (ref.null none)
   )
  )
  (global.set $ready24
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global27
   (struct.new $type3
    (ref.func $function9)
    (ref.null none)
   )
  )
  (global.set $ready27
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global30
   (struct.new $type2
    (ref.func $function10)
    (ref.null none)
   )
  )
  (global.set $ready30
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global33
   (struct.new $type3
    (ref.func $function11)
    (ref.null none)
   )
  )
  (global.set $ready33
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global36
   (struct.new $type2
    (ref.func $function12)
    (ref.null none)
   )
  )
  (global.set $ready36
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global39
   (struct.new $type3
    (ref.func $function13)
    (ref.null none)
   )
  )
  (global.set $ready39
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global42
   (struct.new $type2
    (ref.func $function14)
    (ref.null none)
   )
  )
  (global.set $ready42
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global45
   (struct.new $type3
    (ref.func $function15)
    (ref.null none)
   )
  )
  (global.set $ready45
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global48
   (struct.new $type2
    (ref.func $function16)
    (ref.null none)
   )
  )
  (global.set $ready48
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global51
   (struct.new $type3
    (ref.func $function17)
    (ref.null none)
   )
  )
  (global.set $ready51
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global54
   (struct.new $type4
    (ref.func $function18)
    (ref.null none)
   )
  )
  (global.set $ready54
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global55
   (struct.new $type5
    (ref.func $function19)
    (ref.null none)
   )
  )
  (global.set $ready55
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global56
   (struct.new $type6
    (ref.func $function20)
    (ref.null none)
   )
  )
  (global.set $ready56
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global57
   (struct.new $type7
    (ref.func $function21)
    (ref.null none)
   )
  )
  (global.set $ready57
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global58
   (struct.new $type8
    (ref.func $function22)
    (ref.null none)
   )
  )
  (global.set $ready58
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global59
   (struct.new $type9
    (ref.func $function23)
    (ref.null none)
   )
  )
  (global.set $ready59
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global60
   (struct.new $type10
    (ref.func $function24)
    (ref.null none)
   )
  )
  (global.set $ready60
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global68
   (struct.new $type11
    (ref.func $function28)
    (ref.null none)
   )
  )
  (global.set $ready68
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global368
   (struct.new $type13
    (ref.func $function104)
    (ref.null none)
   )
  )
  (global.set $ready368
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global61
   (struct.new $type15
    (ref.func $function25)
    (ref.null none)
   )
  )
  (global.set $ready61
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global63
   (struct.new $type19
    (ref.func $function26)
    (ref.null none)
   )
  )
  (global.set $ready63
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global65
   (struct.new $type20
    (ref.func $function27)
    (ref.null none)
   )
  )
  (global.set $ready65
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global76
   (struct.new $type21
    (ref.func $function31)
    (ref.null none)
   )
  )
  (global.set $ready76
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global81
   (struct.new $type22
    (ref.func $function33)
    (ref.null none)
   )
  )
  (global.set $ready81
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global88
   (struct.new $type23
    (ref.func $function34)
    (ref.null none)
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global90
   (struct.new $type24
    (ref.func $function35)
    (ref.null none)
   )
  )
  (global.set $ready90
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global93
   (struct.new $type26
    (ref.func $function36)
    (ref.null none)
   )
  )
  (global.set $ready93
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global98
   (struct.new $type27
    (ref.func $function38)
    (ref.null none)
   )
  )
  (global.set $ready98
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global103
   (struct.new $type28
    (ref.func $function39)
    (ref.null none)
   )
  )
  (global.set $ready103
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global109
   (i64.const 1073741824)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global110
   (i64.const 30)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local22
   (i32.const 0)
  )
  (local.set $local23
   (array.new_fixed $type14 0)
  )
  (global.set $global111
   (struct.new $type29
    (local.get $local22)
    (ref.as_non_null
     (local.get $local23)
    )
   )
  )
  (global.set $ready111
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global112
   (struct.new $type30
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready112
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global115
   (struct.new $type31
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $ready115
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global119
   (struct.new $type32
    (ref.func $function43)
    (ref.null none)
   )
  )
  (global.set $ready119
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global121
   (struct.new $type33
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $ready121
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global126
   (struct.new $type13
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready126
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global130
   (struct.new $type34
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $ready130
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global134
   (struct.new $type35
    (ref.func $function48)
    (ref.null none)
   )
  )
  (global.set $ready134
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global136
   (struct.new $type36
    (ref.func $function49)
    (ref.null none)
   )
  )
  (global.set $ready136
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global138
   (struct.new $type36
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready138
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global140
   (struct.new $type37
    (ref.func $function51)
    (ref.null none)
   )
  )
  (global.set $ready140
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global145
   (struct.new $type38
    (ref.func $function53)
    (ref.null none)
   )
  )
  (global.set $ready145
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global153
   (struct.new $type39
    (ref.func $function55)
    (ref.null none)
   )
  )
  (global.set $ready153
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global162
   (struct.new $type40
    (ref.func $function57)
    (ref.null none)
   )
  )
  (global.set $ready162
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global171
   (struct.new $type41
    (ref.func $function59)
    (ref.null none)
   )
  )
  (global.set $ready171
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global175
   (struct.new $type42
    (ref.func $function60)
    (ref.null none)
   )
  )
  (global.set $ready175
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global178
   (struct.new $type42
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $ready178
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global181
   (struct.new $type42
    (ref.func $function62)
    (ref.null none)
   )
  )
  (global.set $ready181
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global184
   (struct.new $type42
    (ref.func $function63)
    (ref.null none)
   )
  )
  (global.set $ready184
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global187
   (struct.new $type42
    (ref.func $function64)
    (ref.null none)
   )
  )
  (global.set $ready187
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global190
   (struct.new $type30
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $ready190
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global193
   (struct.new $type43
    (ref.func $function66)
    (ref.null none)
   )
  )
  (global.set $ready193
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global202
   (struct.new $type43
    (ref.func $function68)
    (ref.null none)
   )
  )
  (global.set $ready202
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global211
   (struct.new $type44
    (ref.func $function70)
    (ref.null none)
   )
  )
  (global.set $ready211
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global215
   (struct.new $type45
    (ref.func $function71)
    (ref.null none)
   )
  )
  (global.set $ready215
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global220
   (struct.new $type45
    (ref.func $function72)
    (ref.null none)
   )
  )
  (global.set $ready220
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global223
   (struct.new $type46
    (ref.func $function73)
    (ref.null none)
   )
  )
  (global.set $ready223
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global234
   (struct.new $type43
    (ref.func $function75)
    (ref.null none)
   )
  )
  (global.set $ready234
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global240
   (struct.new $type45
    (ref.func $function77)
    (ref.null none)
   )
  )
  (global.set $ready240
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global244
   (struct.new $type47
    (ref.func $function78)
    (ref.null none)
   )
  )
  (global.set $ready244
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global253
   (struct.new $type48
    (ref.func $function80)
    (ref.null none)
   )
  )
  (global.set $ready253
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global261
   (struct.new $type48
    (ref.func $function82)
    (ref.null none)
   )
  )
  (global.set $ready261
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global273
   (struct.new $type49
    (ref.func $function84)
    (ref.null none)
   )
  )
  (global.set $ready273
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global286
   (struct.new $type50
    (ref.func $function86)
    (ref.null none)
   )
  )
  (global.set $ready286
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global295
   (struct.new $type48
    (ref.func $function88)
    (ref.null none)
   )
  )
  (global.set $ready295
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global300
   (struct.new $type51
    (ref.func $function89)
    (ref.null none)
   )
  )
  (global.set $ready300
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global306
   (struct.new $type52
    (ref.func $function91)
    (ref.null none)
   )
  )
  (global.set $ready306
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global315
   (struct.new $type54
    (ref.func $function92)
    (ref.null none)
   )
  )
  (global.set $ready315
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global322
   (struct.new $type54
    (ref.func $function93)
    (ref.null none)
   )
  )
  (global.set $ready322
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global328
   (struct.new $type45
    (ref.func $function94)
    (ref.null none)
   )
  )
  (global.set $ready328
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global331
   (struct.new $type45
    (ref.func $function95)
    (ref.null none)
   )
  )
  (global.set $ready331
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global334
   (struct.new $type55
    (ref.func $function96)
    (ref.null none)
   )
  )
  (global.set $ready334
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global343
   (struct.new $type56
    (ref.func $function98)
    (ref.null none)
   )
  )
  (global.set $ready343
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global349
   (struct.new $type57
    (ref.func $function100)
    (ref.null none)
   )
  )
  (global.set $ready349
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global360
   (struct.new $type58
    (ref.func $function102)
    (ref.null none)
   )
  )
  (global.set $ready360
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global366
   (struct.new $type59
    (ref.func $function103)
    (ref.null none)
   )
  )
  (global.set $ready366
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global376
   (struct.new $type37
    (ref.func $function106)
    (ref.null none)
   )
  )
  (global.set $ready376
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global381
   (struct.new $type61
    (ref.func $function108)
    (ref.null none)
   )
  )
  (global.set $ready381
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global386
   (struct.new $type62
    (ref.func $function110)
    (ref.null none)
   )
  )
  (global.set $ready386
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global395
   (struct.new $type63
    (ref.func $function112)
    (ref.null none)
   )
  )
  (global.set $ready395
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global400
   (struct.new $type64
    (ref.func $function113)
    (ref.null none)
   )
  )
  (global.set $ready400
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global406
   (struct.new $type36
    (ref.func $function114)
    (ref.null none)
   )
  )
  (global.set $ready406
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global410
   (struct.new $type45
    (ref.func $function115)
    (ref.null none)
   )
  )
  (global.set $ready410
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global419
   (struct.new $type65
    (ref.func $function117)
    (ref.null none)
   )
  )
  (global.set $ready419
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global422
   (struct.new $type37
    (ref.func $function118)
    (ref.null none)
   )
  )
  (global.set $ready422
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global427
   (struct.new $type36
    (ref.func $function120)
    (ref.null none)
   )
  )
  (global.set $ready427
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global435
   (struct.new $type36
    (ref.func $function121)
    (ref.null none)
   )
  )
  (global.set $ready435
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global440
   (struct.new $type66
    (ref.func $function123)
    (ref.null none)
   )
  )
  (global.set $ready440
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global457
   (struct.new $type68
    (ref.func $function127)
    (ref.null none)
   )
  )
  (global.set $ready457
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global464
   (struct.new $type70
    (ref.func $function128)
    (ref.null none)
   )
  )
  (global.set $ready464
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global467
   (struct.new $type70
    (ref.func $function129)
    (ref.null none)
   )
  )
  (global.set $ready467
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global443
   (struct.new $type71
    (ref.func $function124)
    (ref.null none)
   )
  )
  (global.set $ready443
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global446
   (struct.new $type38
    (ref.func $function125)
    (ref.null none)
   )
  )
  (global.set $ready446
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local20
   (i64.const 13591409)
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local21
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (global.set $global448
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local21)
     )
    )
    (local.get $local20)
   )
  )
  (global.set $ready448
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local18
   (i64.const 545140134)
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local19
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (global.set $global449
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local19)
     )
    )
    (local.get $local18)
   )
  )
  (global.set $ready449
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local16
   (i64.const 640320)
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (global.set $global450
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (local.get $local16)
   )
  )
  (global.set $ready450
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local10
   (i64.const 640320)
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (local.set $local9
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (local.get $local10)
   )
  )
  (local.set $local13
   (i64.const 3)
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (local.set $local12
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (local.get $local13)
   )
  )
  (if
   (i32.eqz
    (global.get $ready410)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global410)
   )
  )
  (global.set $global451
   (call $function115
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local15)
     )
    )
    (ref.as_non_null
     (local.get $local9)
    )
    (ref.as_non_null
     (local.get $local12)
    )
   )
  )
  (global.set $ready451
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local7
   (i64.const 12)
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (global.set $global452
   (call $function53
    (struct.get $type38 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (local.get $local7)
   )
  )
  (global.set $ready452
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global453
   (struct.new $type72
    (ref.func $function126)
    (ref.null none)
   )
  )
  (global.set $ready453
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global472
   (struct.new $type38
    (ref.func $function130)
    (ref.null none)
   )
  )
  (global.set $ready472
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global511
   (struct.new $type73
    (ref.func $function141)
    (ref.null none)
   )
  )
  (global.set $ready511
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global480
   (struct.new $type38
    (ref.func $function131)
    (ref.null none)
   )
  )
  (global.set $ready480
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global515
   (struct.new $type74
    (ref.func $function142)
    (ref.null none)
   )
  )
  (global.set $ready515
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global486
   (struct.new $type75
    (ref.func $function133)
    (ref.null none)
   )
  )
  (global.set $ready486
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global493
   (struct.new $type76
    (ref.func $function136)
    (ref.null none)
   )
  )
  (global.set $ready493
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global491
   (struct.new $type77
    (ref.func $function135)
    (ref.null none)
   )
  )
  (global.set $ready491
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local6
   (i32.const 0)
  )
  (global.set $global499
   (call $foreign5
    (local.get $local6)
   )
  )
  (global.set $ready499
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 1)
  )
  (global.set $global500
   (call $foreign5
    (local.get $local5)
   )
  )
  (global.set $ready500
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 2)
  )
  (global.set $global501
   (call $foreign5
    (local.get $local4)
   )
  )
  (global.set $ready501
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (global.set $global502
   (call $function138
    (local.get $local3)
    (local.get $local2)
    (local.get $local1)
   )
  )
  (global.set $ready502
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local0
   (ref.null none)
  )
  (global.set $global505
   (struct.new $type78
    (local.get $local0)
   )
  )
  (global.set $ready505
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global506
   (struct.new $type37
    (ref.func $function139)
    (ref.null none)
   )
  )
  (global.set $ready506
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global518
   (struct.new $type10
    (ref.func $function143)
    (ref.null none)
   )
  )
  (global.set $ready518
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

