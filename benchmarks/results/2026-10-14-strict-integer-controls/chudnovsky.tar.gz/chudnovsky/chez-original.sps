(import (chezscheme))
(define (square value) (* value value))
;;; Compute digits of PI using a straightforward implementation of
;;; the Chudnovsky brothers algorithm; see
;;; http://www.craig-wood.com/nick/articles/pi-chudnovsky/



(define ch-A 13591409)
(define ch-B 545140134)
(define ch-C 640320)
(define ch-C^3 (expt 640320 3))
(define ch-D 12)

(define (ch-split a b)
  (if (= 1 (- b a))
      (let ((g (* (- (* 6 b) 5) (- (* 2 b) 1) (- (* 6 b) 1))))
        (list g
              (quotient (* ch-C^3 (expt b 3)) 24)
              (* (expt -1 b) g (+ (* b ch-B) ch-A))))
      (let* ((mid (quotient (+ a b) 2))
             (gpq1 (ch-split a mid))
             (gpq2 (ch-split mid b))
             (g1 (car gpq1)) (p1 (cadr gpq1)) (q1 (caddr gpq1))
             (g2 (car gpq2)) (p2 (cadr gpq2)) (q2 (caddr gpq2)))
        (list (* g1 g2)
              (* p1 p2)
              (+ (* q1 p2) (* q2 g1))))))

(define (integer-sqrt x)
  (call-with-values
   (lambda ()
     (exact-integer-sqrt x))
   (lambda (q r)
     q)))

(define (pi digits)
  (let* ((num-terms (exact (floor (+ 2 (/ digits 14.181647462)))))
         (sqrt-C (integer-sqrt (* ch-C (expt 100 digits)))))
    (let* ((gpq (ch-split 0 num-terms))
           (g (car gpq)) (p (cadr gpq)) (q (caddr gpq)))
      (quotient (* p ch-C sqrt-C) (* ch-D (+ q (* p ch-A)))))))

(define (pies n m s)
  (if (< m n)
      '()
      (cons (pi n)
            (pies (+ n s) m s))))

(define (hide r x)
  (call-with-values
   (lambda ()
     (values (vector values (lambda (x) x))
             (if (< r 100) 0 1)))
   (lambda (v i)
     ((vector-ref v i) x))))
(define count (read)) (define first (read)) (define last (read)) (define step (read))
(define expected-input (read)) (define expected expected-input)
(define timed? (member "--time" (command-line)))
(define before (and timed? (current-time 'time-monotonic)))
(define result
  (let loop ((index 0) (result '()))
    (if (< index count)
        (loop (+ index 1) (pies (hide count first) (hide count last) (hide count step))) result)))
(unless (equal? result expected) (error 'benchmark "complete result differs"))
(define after (and timed? (current-time 'time-monotonic)))
(write result) (newline)
(when timed?
  (let ((elapsed (time-difference after before)))
    (display "+!CSVLINE!+chez-integer,chudnovsky:") (display count) (display ",")
    (display (+ (time-second elapsed) (/ (time-nanosecond elapsed) 1e9))) (newline)))
