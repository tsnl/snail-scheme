(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-strict-big-integer-20261014/build/strict-integer-controls/chudnovsky/chez-adapted.sps" "/tmp/snail-strict-big-integer-20261014/build/strict-integer-controls/chudnovsky/chez-adapted.so"))
