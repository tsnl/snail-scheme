from pathlib import Path
import hashlib,json,os,shutil,sys,tarfile
ROOT=Path('/tmp/snail-strict-big-integer-20261014')
sys.path.insert(0,str(ROOT/'benchmarks/strict-suite'))
import integer_controls as c
out=Path(__file__).resolve().parent;report=ROOT/'benchmarks/results/2026-10-14-strict-integer-controls';env=dict(os.environ);env.pop('SNAIL_INTEGER_TIME',None)
frozen=c.freeze_preparation(out,env);c.record_tools(out,env);c.freeze_plan(out,env)
assert all(c.digest(ROOT/path)==identity for path,identity in frozen.items())
checked=[]
def record(path,expected,error=None):
    value=json.loads(path.read_text())
    assert not value['timeout'] and not value['executing_descendants'],path
    if error:
        assert value['returncode']!=0 and error in value['stderr'],path
    else:
        assert value['returncode']==0 and value['stdout']==expected,path
    checked.append(str(path.relative_to(out)))
for name in ('pi','chudnovsky'):
    directory=out/name;original=(directory/'original.scm').read_text();adapted=(directory/'adapted.scm').read_text();data=(directory/'input').read_text();spec=c.ports.specification(name,data)
    assert original==(c.ports.CORPUS/'src'/f'{name}.scm').read_text()
    assert data==(c.ports.CORPUS/'inputs'/f'{name}.input').read_text()
    assert c.ports.restore(adapted,json.loads((directory/'edits.json').read_text()))==original
    assert c.ports.strict_source(name,adapted)==(directory/'strict.scm').read_text()
    for mode in ('original','adapted','limbs'):
        assert c.chez_program(name,original,adapted,mode)==(directory/('chez-'+mode+'.sps')).read_text()
    probe=directory/'retained-results'
    assert c.retained_result_probe((directory/'strict.scm').read_text())[0]==(probe/'probe.scm').read_text()
    rust=out/'rust-reference';rust_source=(rust/'src/bin'/f'{name}.rs').read_text()
    assert c.ports.restore(rust_source,json.loads((rust/(name+'-reporting-edits.json')).read_text()))==(ROOT/'benchmarks/wasm-reference/src/bin'/f'{name}.rs').read_text()
    for label,control in c.control_specs(directory,spec):
        for target in ('raw','production','native-final','native'):
            record(directory/(target+'-'+label+'.json'),control['output'])
    for label,stdin,fails in c.text_inputs(name,data):
        for mode in ('original','adapted','limbs'):
            record(directory/('chez-'+mode+'-'+label+'.json'),spec['output'],'complete result differs' if fails else None)
        for target in ('native','raw','optimized'):
            record(rust/(name+'-'+target+'-'+label+'.json'),'Result: '+spec['output'],'assertion' if fails else None)
    for count in (0,1,2,spec['count']):
        for target in ('raw','optimized','native-final','native'):
            record(probe/(target+'-count-'+str(count)+'.json'),spec['output']*count)
    target=report/name;target.mkdir(exist_ok=True)
    (target/'complete.output').write_text(spec['output'])
    shutil.copy2(directory/'retention/observations.json',target/'retention.json')
    shutil.copy2(directory/'validated.json',target/'validated.json')
    for platform in ('release','wasm32-wasip1/release'):
        for suffix in ('ll','s'):
            for source in (rust/'target'/platform/'deps').glob(name+'-*.'+suffix):
                emitted=rust/'emitted'/platform/source.name;emitted.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,emitted)
assert len(checked)==152,len(checked)
plan=json.loads((out/'timing-plan.json').read_text());assert len(plan['commands'])==16
for row in plan['commands']:
    for path,identity in row['artifact_sha256'].items():assert c.digest(Path(path))==identity
c.ports.save(out/'plan-validation.json',dict(passed=True,commands=16,all_hashes_match=True,all_imports_resolve=True,no_measurement_started=True))
audit=dict(passed=True,validated_guest_records=checked,records=152,source_generation_unchanged=True,source_ledgers_restore_originals=True,
    final_component_negative_passed=True,production_retention_recorded=True,workload_clocks_started=False,
    continuation='Initial compiled Chez limb program rejected imported expt redefinition. Failed attempt is retained separately; all Chez programs were regenerated and revalidated. Previously completed Scheme artifacts remained byte-identical. Later changes only add the final-component case and freeze/metadata code; current generators reproduce every built kernel/program byte-for-byte.',
    historical_failures=['failed-compiled-chez-import/chez-limbs-compile.json','failed-tool-version/tool-chibi-long-version.json'])
c.ports.save(out/'evidence-audit.json',audit)
for name in ('timing-plan.json','tools.json','plan-validation.json','frozen-imports.json','frozen-sources.json','evidence-audit.json'):
    shutil.copy2(out/name,report/name)
archives={}
for name in ('pi','chudnovsky','rust-reference'):
    path=report/(name+'.tar.gz')
    with tarfile.open(path,'w:gz') as tar:
        def keep(info):
            return None if name=='rust-reference' and (info.name=='rust-reference/target' or info.name.startswith('rust-reference/target/')) else info
        tar.add(out/name,arcname=name,filter=keep)
    archives[path.name]=dict(sha256=c.digest(path),bytes=path.stat().st_size)
path=report/'preparation.tar.gz'
with tarfile.open(path,'w:gz') as tar:
    for source in sorted(out.iterdir()):
        if source.name not in ('pi','chudnovsky','rust-reference'):
            tar.add(source,arcname=source.name)
archives[path.name]=dict(sha256=c.digest(path),bytes=path.stat().st_size)
manifest=dict(compiler_and_runtime_commit='6f9ed95',library_commit='820e9f9',adapter_commit='1672d05',validation_followup_commit='35f4c55',native_inlining_origin='e2c05ce1cadb1267a2bfcf2bbd13d5a8af8634fb',
    corpus_revision=c.ports.REVISION,archives=archives,source_sha256=frozen,diagnostic_only=True,no_clean_timing=True,
    source_generation_and_attempt_audit='evidence-audit.json',planned_commands=16,validated_guest_records=152,
    artifact_location=str(out),retained_rust_cache_policy='Cargo build cache excluded; binaries, raw/optimized Wasm, emitted LLVM/assembly, source, lockfile and all command logs retained.')
c.ports.save(report/'manifest.json',manifest)
print(json.dumps(dict(passed=True,guest_records=152,planned_commands=16,archives=archives)))
