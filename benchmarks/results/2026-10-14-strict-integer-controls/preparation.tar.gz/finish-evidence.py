from pathlib import Path
import collections, hashlib, json, os, re, sys
ROOT=Path('/tmp/snail-strict-big-integer-20261014')
sys.path.insert(0,str(ROOT/'benchmarks/strict-suite'))
import integer_controls as c
out=Path(__file__).resolve().parent;env=dict(os.environ)
for name in ('pi','chudnovsky'):
    directory=out/name;data=(directory/'input').read_text();spec=c.ports.specification(name,data)
    controls=[item for item in c.control_specs(directory,spec) if item[0]=='wrong-final']
    for label,module in [('raw',directory/'production.wasm.raw.wasm'),('production',directory/'production.wasm'),('native-final',directory/'native-final.wasm')]:
        c.validate_wasm(directory,label,module,controls,env)
    c.validate_native(directory,'native',directory/'native',controls,env)
    label,stdin,fails=next(item for item in c.text_inputs(name,data) if item[0]=='wrong-final')
    for mode in ('original','adapted','limbs'):
        record=directory/('chez-'+mode+'-'+label+'.json')
        c.ports.execute([env['CHEZ'],'--program',directory/('chez-'+mode+'.so')],directory,record,env,stdin,expected='error')
        assert 'complete result differs' in json.loads(record.read_text())['stderr']
    rust=out/'rust-reference'
    for kind,command in [('native',[rust/(name+'-native')]),('raw',[env['NODE'],'--disable-warning=ExperimentalWarning',rust/'run-wasi.mjs',rust/(name+'.raw.wasm')]),('optimized',[env['NODE'],'--disable-warning=ExperimentalWarning',rust/'run-wasi.mjs',rust/(name+'.wasm')])]:
        record=rust/(name+'-'+kind+'-'+label+'.json')
        c.ports.execute(command,rust,record,env,stdin,expected='error')
        assert 'assertion' in json.loads(record.read_text())['stderr']
    print('PASS '+name+': final-component mismatch rejected by all controls',flush=True)
    inspection=directory/'retention';inspection.mkdir()
    assembly=c.ports.execute(['objdump','-d','-Mintel',directory/'native'],directory,inspection/'native-disassembly.json',env)
    (inspection/'native.asm').write_text(assembly)
    observations={}
    for label in ('production','native-final'):
        wat=(directory/(label+'.wat')).read_text()
        imports=re.findall(r'^ \(import .*?\(func (\$[^\s()]+)',wat,re.M)
        imported=re.search(r'\(import "benchmark" "hide_i64" \(func (\$[^\s()]+)',wat)[1]
        functions=re.findall(r'^ \(func (\$[^\s()]+) ',wat,re.M)
        candidates=[]
        for function in functions:
            body=c.ports.form(wat,'(func '+function+' ')
            if len(re.findall(r'\(call '+re.escape(imported)+r'\s',body))==3:
                candidates.append((function,body))
        function,body=candidates[0];assert len(candidates)==1,candidates
        index=len(imports)+functions.index(function)
        (inspection/(label+'-repetition.wat')).write_text(body+'\n')
        command=[env['NODE'],'--print-wasm-code','--print-wasm-code-function-index='+str(index),c.HERE/'integer-control-host.mjs',directory/(label+'.wasm'),directory/'full.spec.json']
        actual=c.ports.execute(command,directory,inspection/(label+'-v8-code.json'),env)
        assert actual.splitlines().count(spec['output'].strip())==1
        (inspection/(label+'-v8-code.txt')).write_text(actual)
        observations[label]=dict(module_sha256=c.digest(directory/(label+'.wasm')),function=function,function_index=index,
            calls=dict(collections.Counter(re.findall(r'\((?:return_)?call (\$[^\s()]+)',body))),
            import_return_dependence='The three hide_i64 return values are the arguments of the pies call inside the repetition branch.',
            runtime_flags=command[1:3],diagnostic_only=True)
    c.ports.save(inspection/'observations.json',observations)
    print('PASS '+name+': native and default-V8 code captured with full output preserved',flush=True)
