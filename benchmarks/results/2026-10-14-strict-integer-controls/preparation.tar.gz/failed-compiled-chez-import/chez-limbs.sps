(import (chezscheme))
(define-syntax : (syntax-rules () ((_ . rest) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define-syntax define-overload (syntax-rules () ((_ . rest) (begin))))
(define (unit) (void))
(define (unreachable) (error 'integer "invalid exact-integer operation"))
(define (checked-i64 value)
  (if (<= -9223372036854775808 value 9223372036854775807) value (error 'i64 "overflow" value)))
(define (checked-add a b) (checked-i64 (+ a b)))
(define (checked-subtract a b) (checked-i64 (- a b)))
(define (checked-multiply a b) (checked-i64 (* a b)))
(define (checked-quotient a b) (checked-i64 (quotient a b)))
(define (checked-remainder a b) (checked-i64 (remainder a b)))
(define (i64->i32 value)
  (if (<= -2147483648 value 2147483647) value (error 'i32 "overflow" value)))
(define i32->i64 i64->i32)
(define (empty-vector) (vector))
(define (limb-copy! target at source start end)
  (do ((index start (+ index 1))) ((= index end))
    (vector-set! target (+ at (- index start)) (vector-ref source index))))
(begin

    ;; ---- Canonical magnitude and private ownership ----

    ;; A limb is in [0, 2^30). I32 stores it without a sign bit; I64 holds
    ;; products, sums and carries. Zero alone has no limbs and no negative sign.
    ;; No constructor or limb accessor is exported. Sharing in abs/negate is
    ;; safe because every published array is readonly to all library operations.
    (define radix 1073741824)
    (define limb-bits 30)
    (define-record-type (Integer integer integer-value?) (fields (immutable negative integer-negative?) (immutable limbs integer-limbs)))
    (define-record-type (IntegerDivision division division?) (fields (immutable quotient division-quotient) (immutable remainder division-remainder)))
    (define-record-type (IntegerRoot root root?) (fields (immutable value root-value) (immutable remainder root-remainder)))
    (define zero (integer #f (ann (empty-vector) (Vector I32))))
    (: limb (-> (Vector I32) I64 I64))
    (define (limb digits index) (i32->i64 (vector-ref digits index)))
    (: put-limb! (-> (Vector I32) I64 I64 Unit))
    (define (put-limb! digits index value) (vector-set! digits index (i64->i32 value)))
    (: fresh-limbs (-> I64 (Vector I32)))
    (define (fresh-limbs count) (make-vector count (ann 0 I32)))
    (: significant-length (-> (Vector I32) I64))
    (define (significant-length digits)
      (let loop ((count (vector-length digits)))
        (if (or (= count 0) (not (= (limb digits (checked-subtract count 1)) 0))) count
            (loop (checked-subtract count 1)))))
    (: trimmed-limbs (-> (Vector I32) (Vector I32)))
    (define (trimmed-limbs digits)
      (let ((count (significant-length digits)))
        (if (= count (vector-length digits)) digits
            (let ((result (fresh-limbs count)))
              (limb-copy! result 0 digits 0 count) result))))
    (: publish (-> Bool (Vector I32) Integer))
    (define (publish negative digits)
      (let ((digits (trimmed-limbs digits)))
        (if (= (vector-length digits) 0) zero (integer negative digits))))
    (: integer-zero? (-> Integer Bool))
    (define (integer-zero? value) (= (vector-length (integer-limbs value)) 0))
    (: integer-abs (-> Integer Integer))
    (define (integer-abs value)
      (if (integer-negative? value) (integer #f (integer-limbs value)) value))
    (: integer-negate (-> Integer Integer))
    (define (integer-negate value)
      (if (integer-zero? value) value
          (integer (not (integer-negative? value)) (integer-limbs value))))

    ;; ---- Exact signed machine-integer conversion ----

    ;; Keeping the source nonpositive avoids negating I64_MIN. Each remainder
    ;; lies in (-radix, 0], so negating one limb is always representable.
    (: machine-limb-count (-> I64 I64))
    (define (machine-limb-count value)
      (let loop ((value value) (count 0))
        (if (= value 0) count (loop (checked-quotient value radix) (checked-add count 1)))))
    (: integer-from-i64 (-> I64 Integer))
    (define (integer-from-i64 value)
      (let* ((negative (< value 0)) (value (if (> value 0) (checked-subtract 0 value) value))
             (digits (fresh-limbs (machine-limb-count value))))
        (let loop ((value value) (index 0))
          (if (= value 0) (publish negative digits)
              (begin (put-limb! digits index (checked-subtract 0 (checked-remainder value radix)))
                     (loop (checked-quotient value radix) (checked-add index 1)))))))
    (: integer->i64 (-> Integer I64))
    (define (integer->i64 value)
      (let* ((digits (integer-limbs value)) (negative (integer-negative? value))
             (limit (if negative -9223372036854775808 -9223372036854775807)))
        (let loop ((count (vector-length digits)) (result 0))
          (if (= count 0) (if negative result (checked-subtract 0 result))
              (let ((digit (limb digits (checked-subtract count 1))))
                ;; quotient on this negative numerator is its mathematical ceiling.
                (if (< result (checked-quotient (checked-add limit digit) radix)) (unreachable)
                    (loop (checked-subtract count 1) (checked-subtract (checked-multiply result radix) digit))))))))

    ;; ---- Magnitude order and signed comparison ----

    (: magnitude-compare (-> (Vector I32) (Vector I32) I64))
    (define (magnitude-compare left right)
      (let ((a (vector-length left)) (b (vector-length right)))
        (if (< a b) -1 (if (> a b) 1
                           (let loop ((count a))
                             (if (= count 0) 0
                                 (let ((a (limb left (checked-subtract count 1))) (b (limb right (checked-subtract count 1))))
                                   (if (< a b) -1 (if (> a b) 1 (loop (checked-subtract count 1)))))))))))
    (: integer-compare (-> Integer Integer I64))
    (define (integer-compare left right)
      (if (not (= (if (integer-negative? left) 1 0) (if (integer-negative? right) 1 0)))
          (if (integer-negative? left) -1 1)
          (let ((order (magnitude-compare (integer-limbs left) (integer-limbs right))))
            (if (integer-negative? left) (checked-subtract 0 order) order))))
    (: integer=? (-> Integer Integer Bool))
    (define (integer=? left right) (= (integer-compare left right) 0))
    (: integer<? (-> Integer Integer Bool))
    (define (integer<? left right) (< (integer-compare left right) 0))
    (: integer<=? (-> Integer Integer Bool))
    (define (integer<=? left right) (<= (integer-compare left right) 0))
    (: integer>? (-> Integer Integer Bool))
    (define (integer>? left right) (> (integer-compare left right) 0))
    (: integer>=? (-> Integer Integer Bool))
    (define (integer>=? left right) (>= (integer-compare left right) 0))

    ;; ---- Addition and subtraction expose carry and borrow ----

    (: limb-or-zero (-> (Vector I32) I64 I64))
    (define (limb-or-zero digits index)
      (if (< index (vector-length digits)) (limb digits index) 0))
    (: magnitude-add (-> (Vector I32) (Vector I32) (Vector I32)))
    (define (magnitude-add left right)
      (let* ((count (if (> (vector-length left) (vector-length right))
                        (vector-length left) (vector-length right)))
             (result (fresh-limbs (checked-add count 1))))
        (let loop ((index 0) (carry 0))
          (if (= index count) (begin (put-limb! result count carry) result)
              (let ((sum (checked-add (checked-add (limb-or-zero left index) (limb-or-zero right index)) carry)))
                (put-limb! result index (checked-remainder sum radix))
                (loop (checked-add index 1) (checked-quotient sum radix)))))))
    ;; left >= right is established by the signed operation before entry.
    (: magnitude-subtract (-> (Vector I32) (Vector I32) (Vector I32)))
    (define (magnitude-subtract left right)
      (let* ((count (vector-length left)) (result (fresh-limbs count)))
        (let loop ((index 0) (borrow 0))
          (if (= index count) result
              (let ((difference (checked-subtract (checked-subtract (limb left index) (limb-or-zero right index)) borrow)))
                (put-limb! result index (if (< difference 0) (checked-add difference radix) difference))
                (loop (checked-add index 1) (if (< difference 0) 1 0)))))))
    (: signed-difference (-> Bool (Vector I32) (Vector I32) Integer))
    (define (signed-difference negative left right)
      (if (< (magnitude-compare left right) 0)
          (publish (not negative) (magnitude-subtract right left))
          (publish negative (magnitude-subtract left right))))
    (: integer-add (-> Integer Integer Integer))
    (define (integer-add left right)
      (let ((a (integer-limbs left)) (b (integer-limbs right)))
        (if (if (integer-negative? left) (integer-negative? right) (not (integer-negative? right)))
            (publish (integer-negative? left) (magnitude-add a b))
            (signed-difference (integer-negative? left) a b))))
    (: integer-subtract (-> Integer Integer Integer))
    (define (integer-subtract left right) (integer-add left (integer-negate right)))

    ;; ---- Schoolbook products with bounded I64 accumulation ----

    ;; (B-1)^2 + (B-1) + (B-1) = B^2-1 < 2^60. Therefore each
    ;; multiply/add/carry transition is exact before division by B. A row's
    ;; final carry goes into a previously untouched output position.
    (: multiply-row! (-> (Vector I32) (Vector I32) I64 I64 Unit))
    (define (multiply-row! result right offset factor)
      (let ((count (vector-length right)))
        (let loop ((index 0) (carry 0))
          (if (= index count) (put-limb! result (checked-add offset count) carry)
              (let* ((at (checked-add offset index))
                     (product (checked-add (checked-add (checked-multiply factor (limb right index)) (limb result at)) carry)))
                (put-limb! result at (checked-remainder product radix))
                (loop (checked-add index 1) (checked-quotient product radix)))))))
    (: magnitude-multiply (-> (Vector I32) (Vector I32) (Vector I32)))
    (define (magnitude-multiply left right)
      (let ((result (fresh-limbs (checked-add (vector-length left) (vector-length right)))))
        (let loop ((index 0))
          (if (= index (vector-length left)) result
              (begin (multiply-row! result right index (limb left index))
                     (loop (checked-add index 1)))))))
    (: integer-multiply (-> Integer Integer Integer))
    (define (integer-multiply left right)
      (if (or (integer-zero? left) (integer-zero? right)) zero
          (publish (if (integer-negative? left) (not (integer-negative? right))
                       (integer-negative? right))
                   (magnitude-multiply (integer-limbs left) (integer-limbs right)))))
    ;; factor is positive and below B. Keeping one extra limb is sufficient.
    (: magnitude-scale (-> (Vector I32) I64 (Vector I32)))
    (define (magnitude-scale digits factor)
      (let* ((count (vector-length digits)) (result (fresh-limbs (checked-add count 1))))
        (let loop ((index 0) (carry 0))
          (if (= index count) (begin (put-limb! result count carry) result)
              (let ((product (checked-add (checked-multiply (limb digits index) factor) carry)))
                (put-limb! result index (checked-remainder product radix))
                (loop (checked-add index 1) (checked-quotient product radix)))))))

    ;; ---- Single-limb division ----

    ;; A private quotient buffer may alias its source: traversal is high to low,
    ;; and each old limb is consumed before its slot is overwritten. The caller
    ;; never passes a published limb array as target. Return the scalar remainder.
    (: divide-small! (-> (Vector I32) (Vector I32) I64 I64))
    (define (divide-small! target source divisor)
      (let loop ((count (vector-length source)) (carry 0))
        (if (= count 0) carry
            (let ((value (checked-add (checked-multiply carry radix) (limb source (checked-subtract count 1)))))
              (put-limb! target (checked-subtract count 1) (checked-quotient value divisor))
              (loop (checked-subtract count 1) (checked-remainder value divisor))))))

    ;; ---- Normalized long division ----

    ;; Knuth's normalization makes the highest divisor limb >= B/2.
    ;; The two-high-limb estimate is never low and at most two high. Checking
    ;; the next limb reduces that error to at most one; full subtraction decides
    ;; the last correction. Every numerator/product is below B^2 = 2^60.
    (: estimate-digit (-> (Vector I32) (Vector I32) I64 I64))
    (define (estimate-digit dividend divisor offset)
      (let* ((count (vector-length divisor)) (high (limb divisor (checked-subtract count 1)))
             (numerator (checked-add (checked-multiply (limb dividend (checked-add offset count)) radix)
                           (limb dividend (checked-subtract (checked-add offset count) 1))))
             (trial (checked-quotient numerator high)) (trial (if (>= trial radix) (checked-subtract radix 1) trial)))
        (let correct ((trial trial) (residue (checked-subtract numerator (checked-multiply trial high))))
          (if (and (< residue radix)
                   (> (checked-multiply trial (limb divisor (checked-subtract count 2)))
                      (checked-add (checked-multiply residue radix) (limb dividend (checked-subtract (checked-add offset count) 2)))))
              (correct (checked-subtract trial 1) (checked-add residue high)) trial))))
    ;; carry is the high product word plus a possible subtraction borrow.
    ;; It is <= B-1, so product + carry <= B*(B-1). The signed low-word
    ;; difference lies in (-B, B); adding B after a borrow restores one limb.
    (: subtract-product! (-> (Vector I32) (Vector I32) I64 I64 Bool))
    (define (subtract-product! dividend divisor offset trial)
      (let ((count (vector-length divisor)))
        (let loop ((index 0) (carry 0))
          (if (= index count)
              (let ((high (checked-subtract (limb dividend (checked-add offset count)) carry)))
                (when (or (< high -1) (> high 0)) (unreachable))
                (put-limb! dividend (checked-add offset count) (if (< high 0) (checked-add high radix) high))
                (< high 0))
              (let* ((product (checked-add (checked-multiply trial (limb divisor index)) carry))
                     (difference (checked-subtract (limb dividend (checked-add offset index)) (checked-remainder product radix))))
                (put-limb! dividend (checked-add offset index) (if (< difference 0) (checked-add difference radix) difference))
                (loop (checked-add index 1) (checked-add (checked-quotient product radix) (if (< difference 0) 1 0))))))))
    (: add-back! (-> (Vector I32) (Vector I32) I64 Unit))
    (define (add-back! dividend divisor offset)
      (let ((count (vector-length divisor)))
        (let loop ((index 0) (carry 0))
          (if (= index count)
              (put-limb! dividend (checked-add offset count)
                         (checked-remainder (checked-add (limb dividend (checked-add offset count)) carry) radix))
              (let ((sum (checked-add (checked-add (limb dividend (checked-add offset index)) (limb divisor index)) carry)))
                (put-limb! dividend (checked-add offset index) (checked-remainder sum radix))
                (loop (checked-add index 1) (checked-quotient sum radix)))))))
    (: divide-position! (-> (Vector I32) (Vector I32) I64 I64))
    (define (divide-position! dividend divisor offset)
      (let ((trial (estimate-digit dividend divisor offset)))
        (if (subtract-product! dividend divisor offset trial)
            (begin (add-back! dividend divisor offset) (checked-subtract trial 1)) trial)))
    (: divide-normalized! (-> (Vector I32) (Vector I32) (Vector I32) Unit))
    (define (divide-normalized! quotient-digits dividend divisor)
      (let loop ((count (vector-length quotient-digits)))
        (unless (= count 0)
          (put-limb! quotient-digits (checked-subtract count 1) (divide-position! dividend divisor (checked-subtract count 1)))
          (loop (checked-subtract count 1)))))
    (: long-division (-> (Vector I32) (Vector I32) IntegerDivision))
    (define (long-division left right)
      (let* ((count (vector-length right))
             (scale (checked-quotient radix (checked-add (limb right (checked-subtract count 1)) 1)))
             (dividend (magnitude-scale left scale))
             (divisor (trimmed-limbs (magnitude-scale right scale)))
             (answer (fresh-limbs (checked-add (checked-subtract (vector-length left) count) 1)))
             (residue (fresh-limbs count)))
        (divide-normalized! answer dividend divisor)
        (limb-copy! residue 0 dividend 0 count)
        (unless (= (divide-small! residue residue scale) 0) (unreachable))
        (division (publish #f answer) (publish #f residue))))
    (: divide-magnitudes (-> Integer Integer IntegerDivision))
    (define (divide-magnitudes left right)
      (let ((a (integer-limbs left)) (b (integer-limbs right)))
        (if (< (magnitude-compare a b) 0) (division zero (integer-abs left))
            (if (= (vector-length b) 1)
                (let* ((answer (fresh-limbs (vector-length a)))
                       (residue (divide-small! answer a (limb b 0))))
                  (division (publish #f answer) (integer-from-i64 residue)))
                (long-division a b)))))
    (: integer-divide (-> Integer Integer IntegerDivision))
    (define (integer-divide left right)
      (if (integer-zero? right) (unreachable)
          (let* ((result (divide-magnitudes left right))
                 (q (division-quotient result)) (r (division-remainder result)))
            (division (if (if (integer-negative? left) (not (integer-negative? right))
                              (integer-negative? right)) (integer-negate q) q)
                      (if (integer-negative? left) (integer-negate r) r)))))
    (: integer-quotient (-> Integer Integer Integer))
    (define (integer-quotient left right) (division-quotient (integer-divide left right)))
    (: integer-remainder (-> Integer Integer Integer))
    (define (integer-remainder left right) (division-remainder (integer-divide left right)))

    ;; ---- Decimal text with independent mutable strings ----

    ;; Nine decimal digits fit in a limb. Grouped conversion does one linear
    ;; magnitude pass per chunk, rather than one per character. ASCII signs and
    ;; digits only are accepted; empty input, whitespace and prefixes trap.
    (: decimal-chunk (-> String I64 I64 I64))
    (define (decimal-chunk text start end)
      (let loop ((index start) (value 0))
        (if (= index end) value
            (let ((digit (checked-subtract (char->integer (string-ref text index)) 48)))
              (if (or (< digit 0) (> digit 9)) (unreachable)
                  (loop (checked-add index 1) (checked-add (checked-multiply value 10) digit)))))))
    (: machine-power (-> I64 I64 I64))
    (define (machine-power base exponent)
      (let loop ((left exponent) (value 1))
        (if (= left 0) value (loop (checked-subtract left 1) (checked-multiply value base)))))
    (: parse-decimal (-> String I64 Bool Integer))
    (define (parse-decimal text start negative)
      (let ((count (string-length text)))
        (if (= start count) (unreachable)
            (let loop ((at start) (value zero))
              (if (= at count) (if negative (integer-negate value) value)
                  (let* ((width (if (> (checked-subtract count at) 9) 9 (checked-subtract count at)))
                         (scaled (publish #f (magnitude-scale (integer-limbs value) (machine-power 10 width))))
                         (chunk (integer-from-i64 (decimal-chunk text at (checked-add at width)))))
                    (loop (checked-add at width) (integer-add scaled chunk))))))))
    (: integer-from-string (-> String Integer))
    (define (integer-from-string text)
      (if (= (string-length text) 0) (unreachable)
          (let* ((first (string-ref text 0)) (negative (char=? first #\-))
                 (signed (or negative (char=? first #\+))))
            (parse-decimal text (if signed 1 0) negative))))
    (: decimal-chunks (-> (Vector I32) (List I64)))
    (define (decimal-chunks digits)
      (let loop ((digits (vector-copy digits)) (chunks '()))
        (if (= (vector-length digits) 0) chunks
            (let ((chunk (divide-small! digits digits 1000000000)))
              (loop (trimmed-limbs digits) (cons chunk chunks))))))
    (: decimal-width (-> I64 I64))
    (define (decimal-width value)
      (let loop ((value value) (count 1))
        (if (< value 10) count (loop (checked-quotient value 10) (checked-add count 1)))))
    (: chunk-count (-> (List I64) I64))
    (define (chunk-count chunks)
      (let loop ((tail chunks) (count 0))
        (if (null? tail) count (loop (cdr tail) (checked-add count 1)))))
    (: write-chunk! (-> String I64 I64 I64 Unit))
    (define (write-chunk! text end value width)
      (let loop ((at end) (left width) (value value))
        (unless (= left 0)
          (string-set! text (checked-subtract at 1) (integer->char (checked-add 48 (checked-remainder value 10))))
          (loop (checked-subtract at 1) (checked-subtract left 1) (checked-quotient value 10)))))
    (: write-chunks! (-> String I64 (List I64) I64 Unit))
    (define (write-chunks! text at chunks width)
      (unless (null? chunks)
        (write-chunk! text (checked-add at width) (car chunks) width)
        (write-chunks! text (checked-add at width) (cdr chunks) 9)))
    (: integer->string (-> Integer String))
    (define (integer->string value)
      (if (integer-zero? value) (string #\0)
          (let* ((chunks (decimal-chunks (integer-limbs value)))
                 (width (decimal-width (car chunks))) (sign (if (integer-negative? value) 1 0))
                 (text (make-string (checked-add (checked-add sign width) (checked-multiply 9 (checked-subtract (chunk-count chunks) 1))))))
            (when (integer-negative? value) (string-set! text 0 #\-))
            (write-chunks! text sign chunks width) text)))

    ;; ---- Nonnegative exponentiation and floor square root ----

    (: half (-> Integer Integer))
    (define (half value)
      (let* ((digits (integer-limbs value)) (result (fresh-limbs (vector-length digits))))
        (divide-small! result digits 2) (publish #f result)))
    (: integer-expt (-> Integer Integer Integer))
    (define (integer-expt base exponent)
      (if (integer-negative? exponent) (unreachable)
          (let loop ((power base) (left exponent) (result (integer-from-i64 1)))
            (if (integer-zero? left) result
                (let ((result (if (= (checked-remainder (limb (integer-limbs left) 0) 2) 0) result
                                  (integer-multiply result power)))
                      (left (half left)))
                  (if (integer-zero? left) result
                      (loop (integer-multiply power power) left result)))))))
    (: integer-power (-> Integer I64 Integer))
    (define (integer-power base exponent) (integer-expt base (integer-from-i64 exponent)))
    (: leading-bits (-> I64 I64))
    (define (leading-bits value)
      (let loop ((value value) (count 0))
        (if (= value 0) count (loop (checked-quotient value 2) (checked-add count 1)))))
    (: sqrt-upper-bound (-> Integer Integer))
    (define (sqrt-upper-bound value)
      (let* ((digits (integer-limbs value)) (count (vector-length digits))
             (bits (checked-add (checked-multiply (checked-subtract count 1) limb-bits) (leading-bits (limb digits (checked-subtract count 1)))))
             (exponent (checked-quotient (checked-add bits 1) 2)) (at (checked-quotient exponent limb-bits))
             (result (fresh-limbs (checked-add at 1))))
        (put-limb! result at (machine-power 2 (checked-remainder exponent limb-bits)))
        (publish #f result)))
    (: integer-sqrt (-> Integer Integer))
    (define (integer-sqrt value)
      (if (integer-negative? value) (unreachable)
          (if (integer-zero? value) value
              (let loop ((estimate (sqrt-upper-bound value)))
                (let ((next (half (integer-add estimate (integer-quotient value estimate)))))
                  ;; Starting above the root makes every accepted estimate decrease.
                  ;; At floor(sqrt(n)), the next estimate can be larger (n=3).
                  (if (integer>=? next estimate) estimate (loop next)))))))
    (: integer-sqrt/remainder (-> Integer IntegerRoot))
    (define (integer-sqrt/remainder value)
      (let ((root-value (integer-sqrt value)))
        (root root-value (integer-subtract value (integer-multiply root-value root-value)))))

    ;; ---- Ordinary static numeric methods ----

    (define-overload + (-> Integer Integer Integer) integer-add)
    (define-overload - (-> Integer Integer Integer) integer-subtract)
    (define-overload - (-> Integer Integer) integer-negate)
    (define-overload * (-> Integer Integer Integer) integer-multiply)
    (define-overload = (-> Integer Integer Bool) integer=?)
    (define-overload < (-> Integer Integer Bool) integer<?)
    (define-overload <= (-> Integer Integer Bool) integer<=?)
    (define-overload > (-> Integer Integer Bool) integer>?)
    (define-overload >= (-> Integer Integer Bool) integer>=?)
    (define-overload quotient (-> Integer Integer Integer) integer-quotient)
    (define-overload remainder (-> Integer Integer Integer) integer-remainder))(define (same-integers? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (integer=? (car left) (car right))
           (same-integers? (cdr left) (cdr right)))))
(define (same-rows? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (same-integers? (car left) (car right))
           (same-rows? (cdr left) (cdr right)))))
(define (lift-list values) (map (lambda (value) (integer-from-string (number->string value))) values))
(define (square value) (integer-multiply value value))
(define (expt base exponent)
  (if (integer-value? exponent) (integer-expt base exponent) (integer-power base exponent)))
(define (term-count digits) (integer-from-i64 (exact (floor (+ 2 (/ digits 14.181647462))))))
;;; PI -- Compute PI using bignums.

;; See http://mathworld.wolfram.com/Pi.html for the various algorithms.



(define (square-root x) (integer-sqrt x))

(define (quartic-root x)
  (square-root (square-root x)))


;;; Compute pi using the 'brent-salamin' method.

(define (pi-brent-salamin nb-digits)
  (let ((one (expt (integer-from-i64 10) nb-digits)))
    (let loop ((a one)
               (b (square-root (integer-quotient (square one) (integer-from-i64 2))))
               (t (integer-quotient one (integer-from-i64 4)))
               (x (integer-from-i64 1)))
      (if (integer=? a b)
          (integer-quotient (square (integer-add a b)) (integer-multiply (integer-from-i64 4) t))
          (let ((new-a (integer-quotient (integer-add a b) (integer-from-i64 2))))
            (loop new-a
                  (square-root (integer-multiply a b))
                  (integer-subtract t
                     (integer-quotient
                      (integer-multiply x (square (integer-subtract new-a a)))
                      one))
                  (integer-multiply (integer-from-i64 2) x)))))))

;;; Compute pi using the quadratically converging 'borwein' method.

(define (pi-borwein2 nb-digits)
  (let* ((one (expt (integer-from-i64 10) nb-digits))
         (one^2 (square one))
         (one^4 (square one^2))
         (sqrt2 (square-root (integer-multiply one^2 (integer-from-i64 2))))
         (qurt2 (quartic-root (integer-multiply one^4 (integer-from-i64 2)))))
    (let loop ((x (integer-quotient
                   (integer-multiply one (integer-add sqrt2 one))
                   (integer-multiply (integer-from-i64 2) qurt2)))
               (y qurt2)
               (p (integer-add (integer-multiply (integer-from-i64 2) one) sqrt2)))
      (let ((new-p (integer-quotient (integer-multiply p (integer-add x one))
                             (integer-add y one))))
        (if (integer=? x one)
            new-p
            (let ((sqrt-x (square-root (integer-multiply one x))))
              (loop (integer-quotient
                     (integer-multiply one (integer-add x one))
                     (integer-multiply (integer-from-i64 2) sqrt-x))
                    (integer-quotient
                     (integer-multiply one (integer-add (integer-multiply x y) one^2))
                     (integer-multiply (integer-add y one) sqrt-x))
                    new-p)))))))

;;; Compute pi using the quartically converging 'borwein' method.

(define (pi-borwein4 nb-digits)
  (let* ((one (expt (integer-from-i64 10) nb-digits))
         (one^2 (square one))
         (one^4 (square one^2))
         (sqrt2 (square-root (integer-multiply one^2 (integer-from-i64 2)))))
    (let loop ((y (integer-subtract sqrt2 one))
               (a (integer-subtract (integer-multiply (integer-from-i64 6) one) (integer-multiply (integer-from-i64 4) sqrt2)))
               (x (integer-from-i64 8)))
      (if (integer=? y (integer-from-i64 0))
          (integer-quotient one^2 a)
          (let* ((t1 (quartic-root (integer-subtract one^4 (square (square y)))))
                 (t2 (integer-quotient
                      (integer-multiply one (integer-subtract one t1))
                      (integer-add one t1)))
                 (t3 (integer-quotient
                      (square (integer-quotient (square (integer-add one t2)) one))
                      one))
                 (t4 (integer-add one
                        (integer-add t2
                           (integer-quotient (square t2) one)))))
            (loop t2
                  (integer-quotient
                   (integer-subtract (integer-multiply t3 a) (integer-multiply x (integer-multiply t2 t4)))
                   one)
                  (integer-multiply (integer-from-i64 4) x)))))))

;;; Try it.

(define (pies n m s)
  (if (< m n)
      '()
      (let ((bs (pi-brent-salamin n))
            (b2 (pi-borwein2 n))
            (b4 (pi-borwein4 n)))
        (cons (list b2 (integer-subtract bs b2) (integer-subtract b4 b2))
              (pies (+ n s) m s)))))

(define (hide r x)
  (call-with-values
   (lambda ()
     (values (vector values (lambda (x) x))
             (if (< r 100) 0 1)))
   (lambda (v i)
     ((vector-ref v i) x))))
(define count (read)) (define first (read)) (define last (read)) (define step (read))
(define expected-input (read)) (define expected (map lift-list expected-input))
(define timed? (member "--time" (command-line)))
(define before (and timed? (current-time 'time-monotonic)))
(define result
  (let loop ((index 0) (result '()))
    (if (< index count)
        (loop (+ index 1) (pies (hide count first) (hide count last) (hide count step))) result)))
(unless (same-rows? result expected) (error 'benchmark "complete result differs"))
(define after (and timed? (current-time 'time-monotonic)))
(write (map (lambda (row) (map (lambda (value) (string->number (integer->string value))) row)) result)) (newline)
(when timed?
  (let ((elapsed (time-difference after before)))
    (display "+!CSVLINE!+chez-integer,pi:") (display count) (display ",")
    (display (+ (time-second elapsed) (/ (time-nanosecond elapsed) 1e9))) (newline)))
