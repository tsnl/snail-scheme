(module
(import "snail.library" "snail:io/read-code" (func $extern:read-code (param i32) (result i32)))
(import "snail.library" "snail:io/peek-code" (func $extern:peek-code (param i32) (result i32)))
(import "snail.library" "snail:io/write-code" (func $extern:write-code (param i32) (param i32) (result i32)))
(import "snail.library" "snail:io/close" (func $extern:close (param i32) (result i32)))
(import "snail.library" "snail:io/raise-error" (func $extern:raise-error))
(import "snail.library" "_initialize" (func $extern:initialize))
)
