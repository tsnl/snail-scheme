;; Declaration input for the standalone extern reader, not the gradual frontend.
(define-extern read-code "snail.library" "snail:io/read-code" (-> I32 I32))
(define-extern peek-code "snail.library" "snail:io/peek-code" (-> I32 I32))
(define-extern write-code "snail.library" "snail:io/write-code" (-> I32 Char I32))
(define-extern close "snail.library" "snail:io/close" (-> I32 I32))
(define-extern raise-error "snail.library" "snail:io/raise-error" (-> Unit))
(define-extern initialize "snail.library" "_initialize" (-> Unit))
