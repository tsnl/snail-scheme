;; Boundary-only diagnostic. Existing caller argument vectors and boxed chars
;; remain; only root/container traffic across the Rust service call is removed.
(func $builtin:read-char (param $arguments (ref $slots)) (result eqref)
  (local $root i32) (local $result eqref) (local $code i32)
  (if (i32.gt_u (array.len (local.get $arguments)) (i32.const 1))
    (then (call $fail (i32.const 4))))
  ;; Retain the owner across native I/O and any character allocation below.
  (local.set $root (call $abi_root (local.get $arguments)))
  (if (result eqref) (i32.eqz (array.len (local.get $arguments)))
    (then
      (local.set $result (call $abi_take (call $rust75 (local.get $root))))
      (call $abi_release (local.get $root)) (local.get $result))
    (else
      (local.set $code (call $extern:read-code
                            (call $prototype_port_id
                                  (array.get $slots (local.get $arguments) (i32.const 0)))))
      (if (i32.eq (local.get $code) (i32.const -2))
        (then (call $extern:raise-error) (unreachable)))
      (local.set $result
        (if (result eqref) (i32.eq (local.get $code) (i32.const -1))
          (then (global.get $eof)) (else (call $pack_character (local.get $code)))))
      (call $abi_release (local.get $root)) (local.get $result))))

(func $builtin:write-char (param $arguments (ref $slots)) (result eqref)
  (local $root i32) (local $result eqref) (local $code i32)
  (if (i32.or (i32.eqz (array.len (local.get $arguments)))
              (i32.gt_u (array.len (local.get $arguments)) (i32.const 2)))
    (then (call $fail (i32.const 4))))
  (local.set $root (call $abi_root (local.get $arguments)))
  (if (result eqref) (i32.eq (array.len (local.get $arguments)) (i32.const 1))
    (then
      (local.set $result (call $abi_take (call $rust90 (local.get $root))))
      (call $abi_release (local.get $root)) (local.get $result))
    (else
      ;; Character validation precedes port validation, matching the existing API.
      (local.set $code (call $character_value
                            (array.get $slots (local.get $arguments) (i32.const 0))))
      (if (i32.eq (call $extern:write-code
                       (call $prototype_port_id
                             (array.get $slots (local.get $arguments) (i32.const 1)))
                       (local.get $code)) (i32.const -2))
        (then (call $extern:raise-error) (unreachable)))
      (call $abi_release (local.get $root)) (global.get $unspecified))))
