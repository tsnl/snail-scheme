;; This explicit legacy bridge is used by the diagnostic, not by native externs.
(func $prototype_port_id (param $value eqref) (result i32)
  (local $port (ref $extension))
  (local.set $port (ref.cast (ref $extension) (local.get $value)))
  (if (i32.ne (struct.get $extension 0 (local.get $port)) (i32.const 1))
    (then (call $fail (i32.const 8))))
  (struct.get $extension 1 (local.get $port)))

(func (export "test/initialize") (call $extern:initialize))

;; Expose a positional adapter only to test EOF and error ordering in Node.
(func (export "test/catport") (param $input-root i32) (param $output-root i32) (result i32)
  (call $abi_root
        (call $function171 (ref.null eq)
              (call $abi_get (local.get $input-root)) (call $abi_get (local.get $output-root))
              (ref.null $result_context))))
