;; Diagnostic replacement for frozen catport's resolved function $function171.
;; The source still performs one read, EOF test and write per character.
;; Both GC wrappers have owned ABI roots across the whole loop. Scalar resource
;; IDs never keep a wrapper alive. Release the roots after EOF; errors are fatal.
(func $function171 (param $env eqref) (param $a0 eqref) (param $a1 eqref)
  (param $checks (ref null $result_context)) (result eqref)
  (local $input-root i32) (local $output-root i32) (local $input-id i32)
  (local $code i32)
  (local.set $input-root (call $abi_root (local.get $a0)))
  (local.set $output-root (call $abi_root (local.get $a1)))
  (local.set $input-id (call $prototype_port_id (local.get $a0)))
  (block $finished
    (loop $copy
      (local.set $code (call $extern:read-code (local.get $input-id)))
      (br_if $finished (i32.eq (local.get $code) (i32.const -1)))
      (if (i32.eq (local.get $code) (i32.const -2))
        (then (call $extern:raise-error) (unreachable)))
      ;; Validate output only after reading a character, as the Scheme source does.
      (if (i32.eq (call $extern:write-code
                       (call $prototype_port_id (local.get $a1)) (local.get $code))
                  (i32.const -2))
        (then (call $extern:raise-error) (unreachable)))
      (br $copy)))
  (call $abi_release (local.get $output-root))
  (call $abi_release (local.get $input-root))
  (global.get $unspecified))
