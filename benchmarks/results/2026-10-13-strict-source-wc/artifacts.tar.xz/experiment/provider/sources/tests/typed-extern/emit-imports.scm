(import (scheme base) (scheme cxr) (scheme file) (scheme read) (scheme process-context)
        (snail-scheme wasm-extern) (snail-scheme chromium-trace)
        (only (snail-scheme wasm) write-wasm))

;; ---- Declaration input and native import output ----

(define (read-externs port)
  (let ((form (read port)))
    (if (eof-object? form) '()
        (let* ((declaration (parse-extern form))
               (identifier (string->symbol
                            (string-append "$extern:" (symbol->string (extern-name declaration))))))
          (cons (extern-wasm-import declaration identifier) (read-externs port))))))

(with-chromium-trace-to
 (caddr (command-line))
 (lambda ()
   (write-wasm `(module ,@(call-with-input-file (cadr (command-line)) read-externs))
               (current-output-port))))
