(module
  (import "io" "read" (func $read (param f64) (result i32))))
