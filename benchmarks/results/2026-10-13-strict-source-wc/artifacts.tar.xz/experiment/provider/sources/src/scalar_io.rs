//! Native scalar port services, sharing the default provider's owned resources.
//! A resource ID is not a GC pointer and does not keep its Scheme wrapper alive.
//! Callers retain the owning wrapper through any allocation or callback, then
//! close explicitly. These operations neither allocate Scheme values nor call
//! Scheme; their Rust borrow ends before any deferred error is raised.

use crate::{fail_message, platform::with_port_id};
use std::cell::RefCell;

// ---- Scalar results and deferred diagnostics ----

pub(crate) const EOF: i32 = -1;
pub(crate) const ERROR: i32 = -2;

// A failure retains its diagnostic until the next failure or raise-error.
// There are no Scheme callbacks between returning ERROR and consuming it.
thread_local! { static LAST_ERROR: RefCell<Option<String>> = const { RefCell::new(None) }; }

fn scalar_result(result: Result<i32, String>) -> i32 {
    result.unwrap_or_else(|message| {
        LAST_ERROR.with_borrow_mut(|slot| *slot = Some(message));
        ERROR
    })
}

#[unsafe(export_name = "snail:io/raise-error")]
pub extern "C" fn raise_error() {
    let message = LAST_ERROR.with_borrow_mut(Option::take);
    fail_message(message.as_deref().unwrap_or("no pending scalar I/O error"))
}

// ---- Native character operations ----

#[unsafe(export_name = "snail:io/read-code")]
pub extern "C" fn read_code(id: u32) -> i32 {
    scalar_result(with_port_id(id, |port| {
        port.read_char()
            .map(|value| value.map_or(EOF, |c| c as i32))
    }))
}

#[unsafe(export_name = "snail:io/peek-code")]
pub extern "C" fn peek_code(id: u32) -> i32 {
    scalar_result(with_port_id(id, |port| {
        port.text_input()?
            .peek_char()
            .map(|value| value.map_or(EOF, |c| c as i32))
    }))
}

fn write_scalar(port: &mut crate::host::Port, code: u32) -> Result<i32, String> {
    let character = char::from_u32(code).ok_or("invalid Unicode scalar")?;
    let mut bytes = [0; 4];
    port.write(character.encode_utf8(&mut bytes))?;
    Ok(0)
}

#[unsafe(export_name = "snail:io/write-code")]
pub extern "C" fn write_code(id: u32, code: u32) -> i32 {
    scalar_result(with_port_id(id, |port| write_scalar(port, code)))
}

#[unsafe(export_name = "snail:io/close")]
pub extern "C" fn close(id: u32) -> i32 {
    scalar_result(with_port_id(id, |port| port.close().map(|()| 0)))
}

// ---- Tests ----

#[cfg(test)]
mod tests {
    use super::*;
    use crate::host::Port;

    #[test]
    fn character_codes_preserve_unicode_eof_and_lookahead() {
        let mut port = Port::input_string("\0λ😀\u{10ffff}".into());
        assert_eq!(port.text_input().unwrap().peek_char().unwrap(), Some('\0'));
        for expected in [0, 955, 128512, 1114111, EOF, EOF] {
            let result = port.read_char().map(|c| c.map_or(EOF, |c| c as i32));
            assert_eq!(scalar_result(result), expected);
        }
    }

    #[test]
    fn write_rejects_surrogates_and_out_of_range_codes() {
        let mut port = Port::output_string();
        for code in [0, 955, 128512, 1114111] {
            assert_eq!(write_scalar(&mut port, code), Ok(0));
        }
        assert_eq!(port.captured_output().unwrap(), "\0λ😀\u{10ffff}");
        for code in [0xd800, 0xdfff, 0x110000, u32::MAX] {
            assert_eq!(scalar_result(write_scalar(&mut port, code)), ERROR);
        }
    }

    #[test]
    fn closed_and_wrong_direction_ports_remain_errors() {
        let mut output = Port::output_string();
        assert_eq!(scalar_result(output.read_char().map(|_| 0)), ERROR);
        output.close().unwrap();
        assert_eq!(scalar_result(write_scalar(&mut output, 65)), ERROR);
        assert_eq!(output.captured_output().unwrap(), "");
        assert_eq!(
            LAST_ERROR.with_borrow(|slot| slot.clone()),
            Some("port is closed".into())
        );
    }
}
