(module
 (type $0 (func))
 (rec
  (type $call2 (func (param i32 i64 i64 i64 i32) (result i32)))
  (type $type3 (struct))
  (type $type2 (struct))
  (type $type1 (struct))
  (type $type0 (struct))
 )
 (type $6 (func (param i32) (result i32)))
 (type $7 (func (param i64 i64 i64)))
 (type $8 (func (param i32)))
 (import "snail.library" "snail:io/read-code" (func $foreign0 (param i32) (result i32)))
 (import "snail.library" "snail:io/raise-error" (func $foreign1))
 (import "snail.abi" "probe:counts" (func $foreign2 (param i64 i64 i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global3 (mut (ref null $type1)) (ref.null none))
 (global $ready3 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type2)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global15 (mut (ref null $type3)) (ref.null none))
 (global $ready15 (mut i32) (i32.const 0))
 (export "count-code" (func $export0))
 (export "main" (func $main))
 (func $function2 (type $call2) (param $0 i32) (param $1 i64) (param $2 i64) (param $3 i64) (param $4 i32) (result i32)
  (local $5 i32)
  (local $6 i32)
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eq
    (local.tee $6
     (call $foreign0
      (local.get $0)
     )
    )
    (i32.const -2)
   )
   (then
    (call $foreign1)
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global3)
   )
  )
  (if
   (i32.eqz
    (local.tee $5
     (i32.eq
      (local.get $6)
      (i32.const 32)
     )
    )
   )
   (then
    (local.set $5
     (i32.eq
      (local.get $6)
      (i32.const 10)
     )
    )
   )
  )
  (if (result i32)
   (i32.eq
    (local.get $6)
    (i32.const -1)
   )
   (then
    (call $foreign2
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready6)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global6)
     )
    )
    (return_call $function2
     (local.get $0)
     (select
      (i64.add
       (local.get $1)
       (i64.const 1)
      )
      (local.get $1)
      (i32.eq
       (local.get $6)
       (i32.const 10)
      )
     )
     (select
      (local.get $2)
      (i64.add
       (local.get $2)
       (i64.const 1)
      )
      (select
       (local.get $5)
       (local.get $4)
       (local.get $5)
      )
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (i32.eqz
      (local.get $5)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready15)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global15)
   )
  )
  (if
   (i32.eqz
    (global.get $ready6)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global6)
   )
  )
  (drop
   (call $function2
    (local.get $0)
    (i64.const 0)
    (i64.const 0)
    (i64.const 0)
    (i32.const 0)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type0)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global3
   (struct.new_default $type1)
  )
  (global.set $ready3
   (i32.const 1)
  )
  (global.set $global6
   (struct.new_default $type2)
  )
  (global.set $ready6
   (i32.const 1)
  )
  (global.set $global15
   (struct.new_default $type3)
  )
  (global.set $ready15
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

