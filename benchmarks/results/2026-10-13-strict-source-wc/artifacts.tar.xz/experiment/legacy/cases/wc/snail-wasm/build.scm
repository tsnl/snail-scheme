(import (scheme base) (snail-scheme build) (snail-scheme chromium-trace))
(with-chromium-trace-to "/tmp/snail-api-five-b218ce2-20261012/build/ordinary-five-prepared/cases/wc/snail-wasm/build.trace.json" (lambda ()
(build-wasm "/tmp/snail-api-five-b218ce2-20261012" "/tmp/snail-api-five-b218ce2-20261012/build/ordinary-five-prepared/cases/wc/snail-wasm/program.scm" "/tmp/snail-api-five-b218ce2-20261012/build/ordinary-five-prepared/cases/wc/snail-wasm/program.wasm")))
