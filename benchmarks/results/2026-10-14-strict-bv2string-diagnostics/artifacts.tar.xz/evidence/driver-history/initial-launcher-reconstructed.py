#!/usr/bin/env python3
"""Separate full bv2string sampling, GC events and native collector counters."""

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import time


# ---- Frozen inputs and diagnostic scope ----

ROOT = Path(__file__).resolve().parents[3]
BUILD = ROOT / 'build/bv2string-diagnostics'
OWNER = '/tmp/snail-strict-bv2string-20261014'
PREPARATION = OWNER + '/build/bv2string-attempt4'
CASE = PREPARATION + '/bv2string'
PLAN = OWNER + '/benchmarks/results/2026-10-14-strict-bv2string-preparation/timing-plan.json'
REMOVED = ('NODE_OPTIONS', 'NODE_V8_COVERAGE', 'NODE_DEBUG', 'NODE_DEBUG_NATIVE',
           'LD_PRELOAD', 'SNAIL_NATIVE_GC_INTERVAL', 'SNAIL_GC_STATS',
           'SNAIL_GC_HEAP_BYTES', 'SNAIL_GC_MIN_BYTES')


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def identity(path):
    return dict(path=str(path), sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())


def copied(path):
    return BUILD / 'inputs/files' / str(path).lstrip('/')


def verify_inputs():
    manifest, plan = load(BUILD / 'input-manifest.json'), load(copied(PLAN))
    for leaf, expected in manifest['files'].items():
        assert identity(BUILD / 'inputs' / leaf)['sha256'] == expected, leaf
    for path, expected in plan['identities'].items():
        actual = copied(path) if path.startswith(OWNER + '/') else Path(path)
        assert identity(actual)['sha256'] == expected, path
    assert plan['cpu'] in os.sched_getaffinity(0)
    return dict(copied_files=len(manifest['files']), clean_identities=len(plan['identities']), unchanged=True)


# ---- Additions erase exactly to the measured hosts ----

PROFILE_HEADER = '''import inspector from 'node:inspector';
const diagnosticsSession = new inspector.Session();
diagnosticsSession.connect();
const diagnosticsMarkers = {clock_domain: 'process.hrtime.bigint nanoseconds', sampling_interval_us: 1000};
const profiler = (method, parameters = {}) => new Promise((resolve, reject) => {
  diagnosticsSession.post(method, parameters, (error, value) => error ? reject(error) : resolve(value));
});
'''
PROFILE_START = '''await profiler('Profiler.enable');
await profiler('Profiler.setSamplingInterval', {interval: 1000});
diagnosticsMarkers.start_submission_ns = process.hrtime.bigint().toString();
await profiler('Profiler.start');
diagnosticsMarkers.start_acknowledgement_ns = process.hrtime.bigint().toString();
'''
PROFILE_STOP = '''const diagnosticsClockStop = process.hrtime.bigint();
const seconds = Number(diagnosticsClockStop - start) / 1e9;
diagnosticsMarkers.clock_start_ns = start.toString();
diagnosticsMarkers.clock_stop_ns = diagnosticsClockStop.toString();
diagnosticsMarkers.stop_submission_ns = process.hrtime.bigint().toString();
const diagnosticsProfile = (await profiler('Profiler.stop')).profile;
diagnosticsMarkers.stop_completion_ns = process.hrtime.bigint().toString();
diagnosticsSession.disconnect();
fs.writeFileSync(process.argv[5] + '/profile.cpuprofile', JSON.stringify(diagnosticsProfile));
fs.writeFileSync(process.argv[5] + '/profile-window.json', JSON.stringify(diagnosticsMarkers));'''

GC_HEADER = '''import { PerformanceObserver, performance, constants } from 'node:perf_hooks';
const diagnosticsEvents = [], diagnosticsBatches = [], diagnosticsMarkers = {clock_domain: 'performance.now milliseconds'};
const collectGC = (entries, delivery) => {
  const deliveredAt = performance.now();
  diagnosticsBatches.push({delivery, delivered_at_ms: deliveredAt, entries: entries.length});
  for (const entry of entries) diagnosticsEvents.push({name: entry.name, entry_type: entry.entryType,
    start_ms: entry.startTime, duration_ms: entry.duration, detail: entry.detail, delivered_at_ms: deliveredAt});
};
const diagnosticsObserver = new PerformanceObserver(list => collectGC(list.getEntries(), 'callback'));
'''
GC_START = '''diagnosticsObserver.observe({entryTypes: ['gc']});
diagnosticsMarkers.observer_started_ms = performance.now();
diagnosticsMarkers.clock_start_ms = performance.now();
'''
GC_STOP = '''const diagnosticsClockStop = process.hrtime.bigint();
const seconds = Number(diagnosticsClockStop - start) / 1e9;
diagnosticsMarkers.clock_stop_ms = performance.now();
diagnosticsMarkers.clock_start_ns = start.toString();
diagnosticsMarkers.clock_stop_ns = diagnosticsClockStop.toString();
diagnosticsMarkers.drain_started_ms = performance.now();
await new Promise(resolve => setImmediate(resolve));
await new Promise(resolve => setImmediate(resolve));
collectGC(diagnosticsObserver.takeRecords(), 'takeRecords');
diagnosticsMarkers.drain_stopped_ms = performance.now();
diagnosticsObserver.disconnect();
fs.writeFileSync(process.argv[5] + '/gc-events.json', JSON.stringify({markers: diagnosticsMarkers,
  batches: diagnosticsBatches, events: diagnosticsEvents, constants}));'''


def changed_host(original_path, target, changes):
    original, text = original_path.read_text(), original_path.read_text()
    for before, after in changes:
        assert text.count(before) == 1, before
        text = text.replace(before, after)
    restored = text
    for before, after in reversed(changes):
        assert restored.count(after) == 1, after
        restored = restored.replace(after, before)
    assert restored == original
    target.write_text(text)
    save(target.with_suffix('.proof.json'), dict(original=identity(original_path), derived=identity(target),
         exact_source_erasure=True, changes=changes, guest_changes=False))


def make_host(kind):
    header, start, stop = (PROFILE_HEADER, PROFILE_START, PROFILE_STOP) if kind == 'profile' else (GC_HEADER, GC_START, GC_STOP)
    changes = [('import fs', header + 'import fs'),
               ('instance.exports.main();', 'instance.exports.main();\ndiagnosticsMarkers.main_return_ns = process.hrtime.bigint().toString();'),
               ('const start = process.hrtime.bigint();', start + 'const start = process.hrtime.bigint();'),
               ('const seconds = Number(process.hrtime.bigint() - start) / 1e9;', stop)]
    target = BUILD / (kind + '-host.mjs')
    changed_host(copied(PREPARATION + '/host.mjs'), target, changes)
    return target


# ---- A bounded process owns regular capture files and all group members ----


def group_members(group):
    members = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            fields = (entry / 'stat').read_text().rpartition(') ')[2].split()
            if int(fields[2]) == group:
                members.append(dict(pid=int(entry.name), state=fields[0]))
        except (OSError, IndexError, ValueError):
            continue
    return members


def stop_group(child):
    before = group_members(child.pid)
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait(timeout=10)
    deadline = time.monotonic() + 10
    after = group_members(child.pid)
    while any(member['state'] not in ('Z', 'X') for member in after):
        if time.monotonic() >= deadline:
            raise RuntimeError('live owned descendants after SIGKILL: ' + repr(after))
        time.sleep(0.01)
        after = group_members(child.pid)
    return dict(before=before, after=after, live_members=[], zombies_dead_not_running=True)


def wait_bounded(child, directory, deadline):
    while child.poll() is None:
        if time.monotonic() >= deadline:
            return 'timeout'
        if any((directory / name).stat().st_size > 16 * 1024 * 1024 for name in ('stdout.bin', 'stderr.bin')):
            return 'capture-limit'
        time.sleep(0.02)
    return 'exited'


def execute(command, directory, environment=None, stdin=None):
    # One transaction keeps launch, capture, raw persistence and group cleanup together.
    env = {k: v for k, v in os.environ.items() if k not in REMOVED}
    env.update(environment or {})
    record = dict(command=list(map(str, command)), cwd=str(directory), status='started', clean_timing=False,
                  started_utc=datetime.now(timezone.utc).isoformat(), timeout_seconds=120,
                  environment={name: env.get(name) for name in (*REMOVED, 'LD_LIBRARY_PATH', 'LANG', 'LC_ALL', 'TZ')},
                  identities_before=verify_inputs())
    path, child, started = directory / 'attempt.json', None, time.monotonic()
    save(path, record)
    (directory / 'stdin.bin').write_bytes(stdin or b'')
    try:
        with (directory / 'stdin.bin').open('rb') as input_file, (directory / 'stdout.bin').open('wb') as out, (directory / 'stderr.bin').open('wb') as err:
            child = subprocess.Popen(record['command'], cwd=directory, env=env, stdin=input_file,
                                     stdout=out, stderr=err, start_new_session=True)
            record.update(pid=child.pid, process_group=child.pid, status='running')
            save(path, record)
            record['status'] = wait_bounded(child, directory, started + 120)
    except BaseException as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        if child is not None:
            record['cleanup'] = stop_group(child)
            record['returncode'] = child.returncode
        record.update(diagnostic_process_seconds=time.monotonic() - started,
                      stdout_raw=identity(directory / 'stdout.bin'), stderr_raw=identity(directory / 'stderr.bin'),
                      identities_after=verify_inputs())
        save(path, record)
    record.update(stdout=(directory / 'stdout.bin').read_text(), stderr=(directory / 'stderr.bin').read_text())
    save(path, record)
    return record


# ---- Full result validation precedes diagnostic interpretation ----


def require_success(record):
    assert record['status'] == 'exited' and record['returncode'] == 0, record
    assert record['cleanup']['live_members'] == [], record
    assert record['identities_before'] == record['identities_after'], record


def validate_snail(record, native=False):
    require_success(record)
    assert record['stdout'].endswith('\n') and len(record['stdout'].splitlines()) == 1
    result = json.loads(record['stdout'])
    expected = dict(result=1, barriers=0) if native else dict(result='1', barriers=None, setup_barriers=None)
    assert set(result) == set(expected) | {'seconds'}, result
    assert all(result[name] == value for name, value in expected.items()), result
    assert not isinstance(result['seconds'], bool) and math.isfinite(result['seconds']) and result['seconds'] > 0
    record.update(valid_full_result=True, diagnostic_workload_seconds=result['seconds'], full_count=100)


def profile_summary(path):
    profile = load(path)
    nodes = {node['id']: node for node in profile['nodes']}
    assert len(profile['samples']) == len(profile['timeDeltas']) > 0
    weights, hits = defaultdict(int), defaultdict(int)
    for sample, delta in zip(profile['samples'], profile['timeDeltas']):
        frame = nodes[sample]['callFrame']
        key = (frame['functionName'], frame['url'], frame['scriptId'], frame['lineNumber'], frame['columnNumber'])
        weights[key] += delta
        hits[key] += 1
    rows = [dict(function=key[0], url=key[1], script=key[2], line=key[3], column=key[4],
                 samples=hits[key], weighted_interval_us=weight) for key, weight in weights.items()]
    return dict(samples=len(profile['samples']), weighted_interval_us=sum(profile['timeDeltas']),
                profile_span_us=profile['endTime'] - profile['startTime'],
                first_delta_us=profile['timeDeltas'][0], last_delta_us=profile['timeDeltas'][-1],
                policy='exclusive leaf intervals merged by complete frame; boundary intervals retained whole; not continuous CPU execution',
                frames=sorted(rows, key=lambda row: row['weighted_interval_us'], reverse=True))


def run_host(kind):
    directory = BUILD / kind
    directory.mkdir(exist_ok=False)
    plan = load(copied(PLAN))
    command = [plan['taskset'], '-c', str(plan['cpu']), plan['systems']['strict-v8']['argv'][0],
               str(make_host(kind)), str(copied(CASE + '/strict.wasm')), str(copied(CASE + '/spec.json')),
               '--diagnostics', str(directory)]
    record = execute(command, directory)
    try:
        validate_snail(record)
        assert not record['stderr'], record
        if kind == 'profile':
            record['profile'] = identity(directory / 'profile.cpuprofile')
            record['window'] = load(directory / 'profile-window.json')
            save(directory / 'summary.json', profile_summary(directory / 'profile.cpuprofile'))
        else:
            record['gc_events'] = identity(directory / 'gc-events.json')
        record['status'] = 'valid'
    except BaseException as error:
        record['validation_error'] = repr(error)
        raise
    finally:
        save(directory / 'attempt.json', record)
    print(kind, 'PASS full100; original optimized guest unchanged; diagnostic only', flush=True)


def run_native_stats():
    directory = BUILD / 'native-stats'
    directory.mkdir(exist_ok=False)
    plan = load(copied(PLAN))
    command = [plan['taskset'], '-c', str(plan['cpu']), copied(CASE + '/timing-native/native'), '100']
    record = execute(command, directory, {'SNAIL_GC_STATS': '1'})
    try:
        validate_snail(record, native=True)
        assert re.fullmatch(r'immix-gc .*\n', record['stderr']), record
        fields = dict(item.split('=', 1) for item in record['stderr'].strip().split()[1:])
        record['gc_statistics'] = {name: float(value) if name.endswith('_s') else int(value) if value.isdecimal() else value
                                   for name, value in fields.items()}
        record['scope'] = 'whole process including initialization; bytes requested by collector, not RSS; GC clock reads enabled'
        record['status'] = 'valid'
    except BaseException as error:
        record['validation_error'] = repr(error)
        raise
    finally:
        save(directory / 'attempt.json', record)
    print('native-stats PASS full100; unchanged binary, default collector policy', flush=True)


# ---- Command entry ----


def main():
    global BUILD
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('verify', 'profile', 'gc', 'native-stats'))
    parser.add_argument('--build', type=Path, default=BUILD)
    options = parser.parse_args()
    BUILD = options.build.resolve()
    if options.action == 'verify':
        print(json.dumps(verify_inputs()))
    elif options.action == 'native-stats':
        run_native_stats()
    else:
        run_host(options.action)


if __name__ == '__main__':
    main()
