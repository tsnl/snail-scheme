(func $function74 (type $16) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i32)
  (local $7 i64)
  (local $scratch i32)
  (if (result i64)
   (i64.gt_s
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (local.get $4)
     )
     (then
      (local.get $5)
     )
     (else
      (if
       (i64.ge_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (if (result i64)
        (i64.lt_u
         (local.tee $7
          (i64.extend_i32_u
           (block (result i32)
            (local.set $scratch
             (array.get $type15
              (if (result (ref $type15))
               (i32.lt_u
                (local.tee $6
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
                (i32.const 8192)
               )
               (then
                (struct.get $type14 2
                 (local.get $0)
                )
               )
               (else
                (ref.as_non_null
                 (array.get $type16
                  (struct.get $type14 3
                   (local.get $0)
                  )
                  (i32.sub
                   (i32.shr_u
                    (local.get $6)
                    (i32.const 13)
                   )
                   (i32.const 1)
                  )
                 )
                )
               )
              )
              (i32.and
               (local.get $6)
               (i32.const 8191)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready229)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (struct.get $type42 1
              (global.get $global229)
             )
            )
            (local.get $scratch)
           )
          )
         )
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i64.lt_u
           (local.get $7)
           (i64.const 2048)
          )
          (then
           (i64.const 2)
          )
          (else
           (select
            (i64.const 3)
            (i64.const 4)
            (i64.lt_u
             (local.get $7)
             (i64.const 65536)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function74
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (local.get $7)
       )
      )
     )
    )
   )
  )
 )
