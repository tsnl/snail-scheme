import { PerformanceObserver, performance, constants } from 'node:perf_hooks';
const diagnosticsEvents = [], diagnosticsBatches = [], diagnosticsMarkers = {clock_domain: 'performance.now milliseconds'};
const collectGC = (entries, delivery) => {
  const deliveredAt = performance.now();
  diagnosticsBatches.push({delivery, delivered_at_ms: deliveredAt, entries: entries.length});
  for (const entry of entries) diagnosticsEvents.push({name: entry.name, entry_type: entry.entryType,
    start_ms: entry.startTime, duration_ms: entry.duration, detail: entry.detail, delivered_at_ms: deliveredAt});
};
const diagnosticsObserver = new PerformanceObserver(list => collectGC(list.getEntries(), 'callback'));
import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';

// Instantiate and prepare runtime inputs before starting the workload timer.
const [artifact, specification, mode] = process.argv.slice(2);
const config = JSON.parse(fs.readFileSync(specification, 'utf8'));
let barriers = 0;
const opacity = mode === '--validate' ? value => { barriers++; return value; } : value => value;
const imports = {benchmark: {
  write_character: scalar => fs.writeSync(1, String.fromCodePoint(scalar)),
  print_text: code => fs.writeSync(1, config.diagnostic_text[Number(code)]),
  print_size: (code, value) => {
    const [prefix, suffix] = config.diagnostic_sizes[Number(code)];
    fs.writeSync(1, prefix + value.toString() + suffix);
  },
  print_construction: (iters, depth) => fs.writeSync(1, `Creating ${iters} trees of depth ${depth}`),
  count: () => BigInt(config.count),
  input_i64: index => BigInt(config.inputs[index]),
  input_f64: index => Number(config.inputs[index]),
  vector_length: index => BigInt(config.inputs[index].length),
  vector_f64: (index, element) => Number(config.inputs[index][Number(element)]),
  vector_i64: (index, element) => BigInt(config.inputs[index][Number(element)]),
  expected_length: () => BigInt(config.expected.length),
  expected_i64: index => BigInt(config.expected[Number(index)]),
  expected_f64: index => Number(config.expected[Number(index)]),
  tolerance: () => Number(config.tolerance),
  hide_i64: opacity,
  hide_f64: opacity,
  barrier: () => opacity(1),
}};
if (config.math_provider) {
  const providerPath = path.resolve(path.dirname(artifact), config.math_provider);
  const module = new WebAssembly.Module(fs.readFileSync(providerPath));
  assert.deepEqual(WebAssembly.Module.imports(module), [], 'sine provider must implement its math inside Wasm');
  imports.math = new WebAssembly.Instance(module).exports;
}
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), imports);
// main installs staged procedures and generates quicksort's base vector here.
instance.exports.main();
diagnosticsMarkers.main_return_ns = process.hrtime.bigint().toString();
const setupBarriers = barriers;
if (mode === '--validate' && config.setup_barriers !== undefined)
  assert.equal(setupBarriers, config.setup_barriers);
barriers = 0;
diagnosticsObserver.observe({entryTypes: ['gc']});
diagnosticsMarkers.observer_started_ms = performance.now();
diagnosticsMarkers.clock_start_ms = performance.now();
const start = process.hrtime.bigint();
const result = instance.exports[config.export || 'bench'](BigInt(config.count));
const checkedFlag = ['i64-list-values', 'f64-vector-values', 'i64-vector-values'].includes(config.result_kind);
assert.equal(result.toString(), checkedFlag ? '1' : config.expected.toString());
const diagnosticsClockStop = process.hrtime.bigint();
const seconds = Number(diagnosticsClockStop - start) / 1e9;
diagnosticsMarkers.clock_stop_ms = performance.now();
diagnosticsMarkers.clock_start_ns = start.toString();
diagnosticsMarkers.clock_stop_ns = diagnosticsClockStop.toString();
diagnosticsMarkers.drain_started_ms = performance.now();
await new Promise(resolve => setImmediate(resolve));
await new Promise(resolve => setImmediate(resolve));
collectGC(diagnosticsObserver.takeRecords(), 'takeRecords');
diagnosticsMarkers.drain_stopped_ms = performance.now();
diagnosticsObserver.disconnect();
fs.writeFileSync(process.argv[5] + '/gc-events.json', JSON.stringify({markers: diagnosticsMarkers,
  batches: diagnosticsBatches, events: diagnosticsEvents, constants}));
if (mode === '--validate') assert.equal(barriers, config.barriers_per_iteration * Math.max(0, config.count));
console.log(JSON.stringify({seconds, result: result.toString(), barriers: mode === '--validate' ? barriers : null,
  setup_barriers: mode === '--validate' ? setupBarriers : null}));
