(func $function93 (type $3) (param $0 (ref $type42)) (param $1 i32) (param $2 i64) (param $3 (ref $type28)) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type28))
  (local $7 i64)
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call_ref $call42
      (struct.get $type42 1
       (local.get $0)
      )
      (i64.const 128)
      (struct.get $type42 0
       (local.get $0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function93
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
