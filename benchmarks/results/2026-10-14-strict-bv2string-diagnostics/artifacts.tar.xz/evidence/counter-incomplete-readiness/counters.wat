(module
 (rec
  (type $0 (func (param i32 i32 (ref null $type23) i64) (result i64)))
  (type $1 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $2 (func (param i64 i64 (ref $type42) i32 i32 i32 i32 i32 i32 i32 i64) (result i32)))
  (type $3 (func (param (ref $type42) i32 i64 (ref $type28) i32 i32 i64) (result (ref $type28))))
  (type $4 (func (param (ref $type63) (ref $type65) (ref $type64) (ref $type64) (ref $type64) (ref $type63) i64 i64 i64) (result i64)))
  (type $environment89 (struct (field (ref $type63)) (field (ref $type65)) (field (ref $type64)) (field (ref $type64)) (field (ref $type64)) (field (ref $type63))))
  (type $type63 (struct))
  (type $type64 (struct (field i64)))
  (type $type65 (struct (field (ref $type66))))
  (type $type66 (struct (field (mut i64))))
  (type $10 (func (param (ref $type65) (ref $type64) (ref $type64) (ref $type64)) (result i64)))
  (type $type23 (struct (field (ref null $type23))))
  (type $12 (func (param (ref $type14) i32 i32 i64) (result i32)))
  (type $13 (func (param (ref $type14)) (result i32)))
  (type $call55 (func (param (ref $type14)) (result (ref $type28))))
  (type $15 (func (param (ref $type28) (ref $type14) i64 i32 i32 i64 i64) (result i32)))
  (type $16 (func (param (ref $type14) i64 i32 i32 i64 i64) (result i64)))
  (type $17 (func (param (ref $type14) (ref $type28) i64 i32 i32 i64 i64) (result i32)))
  (type $18 (func (param (ref $type28) i64 i64 i32 i32 i64 i64) (result i32)))
  (type $call42 (func (param (ref null $environment89) i64) (result i64)))
  (type $type29 (array (mut i8)))
  (type $21 (func (param (ref $type28) i64 i32 i32 i64 i64) (result i64)))
  (type $type28 (struct (field (ref $type29))))
  (type $23 (func (param (ref $type28) i64) (result (ref $type14))))
  (type $24 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $26 (func (param (ref $type14) i32) (result (ref $type15))))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type60 (struct (field (mut (ref null $type23)))))
  (type $type59 (struct))
  (type $type10 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type24 (struct))
  (type $type55 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct (field (ref $call42)) (field (ref null $environment89))))
  (type $type33 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type13 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $54 (func (param i32)))
 (type $55 (func (param i64) (result i64)))
 (type $56 (func (param i32) (result i64)))
 (type $57 (func))
 (import "benchmark" "write_character" (func $foreign0 (param i32)))
 (import "benchmark" "hide_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type15 30
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
   (i32.const 70)
   (i32.const 65)
   (i32.const 73)
   (i32.const 76)
   (i32.const 69)
   (i32.const 68)
   (i32.const 32)
   (i32.const 84)
   (i32.const 69)
   (i32.const 83)
   (i32.const 84)
   (i32.const 32)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type15 31
   (i32.const 114)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 112)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 118)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type26)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type33)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global182 (mut (ref null $type42)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type42)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global193 (mut (ref null $type42)) (ref.null none))
 (global $ready193 (mut i32) (i32.const 0))
 (global $global177 (mut (ref null $type43)) (ref.null none))
 (global $ready177 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type44)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global184 (mut (ref null $type45)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type43)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global195 (mut (ref null $type46)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type47)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global207 (mut (ref null $type49)) (ref.null none))
 (global $ready207 (mut i32) (i32.const 0))
 (global $global229 (mut (ref null $type42)) (ref.null none))
 (global $ready229 (mut i32) (i32.const 0))
 (global $global222 (mut (ref null $type50)) (ref.null none))
 (global $ready222 (mut i32) (i32.const 0))
 (global $global209 (mut (ref null $type51)) (ref.null none))
 (global $ready209 (mut i32) (i32.const 0))
 (global $global231 (mut (ref null $type52)) (ref.null none))
 (global $ready231 (mut i32) (i32.const 0))
 (global $global217 (mut (ref null $type53)) (ref.null none))
 (global $ready217 (mut i32) (i32.const 0))
 (global $global244 (mut (ref null $type55)) (ref.null none))
 (global $ready244 (mut i32) (i32.const 0))
 (global $global323 (mut (ref null $type24)) (ref.null none))
 (global $ready323 (mut i32) (i32.const 0))
 (global $global246 (mut (ref null $type56)) (ref.null none))
 (global $ready246 (mut i32) (i32.const 0))
 (global $global281 (mut (ref null $type57)) (ref.null none))
 (global $ready281 (mut i32) (i32.const 0))
 (global $global256 (mut (ref null $type58)) (ref.null none))
 (global $ready256 (mut i32) (i32.const 0))
 (global $global260 (mut (ref null $type10)) (ref.null none))
 (global $ready260 (mut i32) (i32.const 0))
 (global $global320 (mut (ref null $type59)) (ref.null none))
 (global $ready320 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type60)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global262 (mut (ref null $type61)) (ref.null none))
 (global $ready262 (mut i32) (i32.const 0))
 (global $global266 (mut (ref null $type62)) (ref.null none))
 (global $ready266 (mut i32) (i32.const 0))
 (global $global312 (mut i64) (i64.const 0))
 (global $ready312 (mut i32) (i32.const 0))
 (global $global313 (mut i64) (i64.const 0))
 (global $ready313 (mut i32) (i32.const 0))
 (global $global314 (mut i64) (i64.const 0))
 (global $ready314 (mut i32) (i32.const 0))
 (global $global315 (mut (ref null $type42)) (ref.null none))
 (global $ready315 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-block (type $26) (param $0 (ref $type14)) (param $1 i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function40 (type $24) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $bv_f40_entries (i64.add (global.get $bv_f40_entries) (i64.const 1)))
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (block (result i32) (global.set $bv_f40_ordered_i64_predicates (i64.add (global.get $bv_f40_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     ))
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (block (result i32) (global.set $bv_f40_scalar_reads (i64.add (global.get $bv_f40_scalar_reads) (i64.const 1))) (array.get $type15
       (if (result (ref $type15))
        (i32.lt_u
         (local.tee $5
          (block (result i32) (global.set $bv_f40_index_or_byte_narrowings (i64.add (global.get $bv_f40_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
           (local.get $4)
          ))
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type14 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type16
           (struct.get $type14 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      ))
      (block (result i32)
       (if
        (block (result i32) (global.set $bv_f40_ordered_i64_predicates (i64.add (global.get $bv_f40_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $1)
          )
         )
        ))
        (then
         (unreachable)
        )
       )
       (block (result i32) (global.set $bv_f40_scalar_reads (i64.add (global.get $bv_f40_scalar_reads) (i64.const 1))) (array.get $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $5
           (block (result i32) (global.set $bv_f40_index_or_byte_narrowings (i64.add (global.get $bv_f40_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
            (local.get $4)
           ))
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       ))
      )
     )
     (then
      (if
       (block (result i32) (global.set $bv_f40_zero_predicates (i64.add (global.get $bv_f40_zero_predicates) (i64.const 1))) (i32.eqz
        (local.get $3)
       ))
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function57 (type $23) (param $0 (ref $type28)) (param $1 i64) (result (ref $type14))
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (local $8 (ref null $type16))
  (local $9 (ref $type14))
  (local $bv_length i32)
  (global.set $bv_f57_entries (i64.add (global.get $bv_f57_entries) (i64.const 1)))
  (if
   (block (result i32) (global.set $bv_f57_zero_predicates (i64.add (global.get $bv_f57_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready135)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $7
   (i64.extend_i32_u
    (array.len
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
  )
  (if
   (if (result i32)
    (local.tee $2
     (block (result i32) (global.set $bv_f57_ordered_i64_predicates (i64.add (global.get $bv_f57_ordered_i64_predicates) (i64.const 1))) (i64.lt_s
      (local.get $1)
      (i64.const 0)
     ))
    )
    (then
     (local.get $2)
    )
    (else
     (block (result i32) (global.set $bv_f57_ordered_i64_predicates (i64.add (global.get $bv_f57_ordered_i64_predicates) (i64.const 1))) (i64.gt_s
      (local.get $1)
      (local.get $7)
     ))
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (block (result i32) (global.set $bv_f57_zero_predicates (i64.add (global.get $bv_f57_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready169)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (local.set $7
   (call $function59
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (if
   (block (result i32) (global.set $bv_f57_zero_predicates (i64.add (global.get $bv_f57_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready61)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (block (result i32) (global.set $bv_f57_ordered_i64_predicates (i64.add (global.get $bv_f57_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
    (local.get $7)
    (i64.const 4294967294)
   ))
   (then
    (unreachable)
   )
  )
  (if
   (local.tee $3
    (i32.sub
     (local.tee $2
      (block (result i32) (global.set $bv_f57_index_or_byte_narrowings (i64.add (global.get $bv_f57_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
       (local.get $7)
      ))
     )
     (local.tee $5
      (select
       (i32.const 8192)
       (local.get $2)
       (i32.ge_u
        (local.get $2)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $8
     (array.new_default $type16 (block (result i32) (local.set $bv_length (i32.shr_u
       (i32.sub
        (local.get $2)
        (i32.const 1)
       )
       (i32.const 13)
      )) (global.set $bv_array_type16_requests (i64.add (global.get $bv_array_type16_requests) (i64.const 1))) (global.set $bv_array_type16_elements (i64.add (global.get $bv_array_type16_elements) (i64.extend_i32_u (local.get $bv_length)))) (local.get $bv_length)))
    )
    (loop $label
     (array.set $type16
      (local.get $8)
      (local.get $4)
      (array.new_default $type15 (block (result i32) (local.set $bv_length (local.tee $6
        (select
         (i32.const 8192)
         (local.get $3)
         (i32.ge_u
          (local.get $3)
          (i32.const 8192)
         )
        )
       )) (global.set $bv_array_type15_requests (i64.add (global.get $bv_array_type15_requests) (i64.const 1))) (global.set $bv_array_type15_elements (i64.add (global.get $bv_array_type15_elements) (i64.extend_i32_u (local.get $bv_length)))) (local.get $bv_length)))
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $3
       (i32.sub
        (local.get $3)
        (local.get $6)
       )
      )
     )
    )
   )
  )
  (if
   (block (result i32) (global.set $bv_f57_zero_predicates (i64.add (global.get $bv_f57_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready195)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (drop
   (call $function67
    (local.tee $9
     (struct.new $type14
      (i32.const 1)
      (local.get $2)
      (array.new_default $type15 (block (result i32) (local.set $bv_length (local.get $5)) (global.set $bv_array_type15_requests (i64.add (global.get $bv_array_type15_requests) (i64.const 1))) (global.set $bv_array_type15_elements (i64.add (global.get $bv_array_type15_elements) (i64.extend_i32_u (local.get $bv_length)))) (local.get $bv_length)))
      (local.get $8)
     )
    )
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (local.get $9)
 )
 (func $function59 (type $21) (param $0 (ref $type28)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (global.set $bv_f59_entries (i64.add (global.get $bv_f59_entries) (i64.const 1)))
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (block (result i32) (global.set $bv_f59_zero_predicates (i64.add (global.get $bv_f59_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready177)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (if
     (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $6
     (i64.extend_i32_u
      (block (result i32) (global.set $bv_f59_packed_reads (i64.add (global.get $bv_f59_packed_reads) (i64.const 1))) (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (block (result i32) (global.set $bv_f59_index_or_byte_narrowings (i64.add (global.get $bv_f59_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
        (local.get $4)
       ))
      ))
     )
    )
    (if
     (block (result i32) (global.set $bv_f59_zero_predicates (i64.add (global.get $bv_f59_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready182)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global182)
     )
    )
    (if
     (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.gt_s
      (local.tee $6
       (if (result i64)
        (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
         (local.get $6)
         (i64.const 128)
        ))
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
            (local.get $6)
            (i64.const 224)
           ))
           (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
            (local.get $6)
            (i64.const 194)
           ))
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
              (local.get $6)
              (i64.const 240)
             ))
             (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
              (local.get $6)
              (i64.const 224)
             ))
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
                (local.get $6)
                (i64.const 245)
               ))
               (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
                (local.get $6)
                (i64.const 240)
               ))
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $1)
       (local.get $4)
      )
     ))
     (then
      (unreachable)
     )
    )
    (if
     (block (result i32) (global.set $bv_f59_zero_predicates (i64.add (global.get $bv_f59_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready184)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (if
     (block (result i32) (global.set $bv_f59_ordered_i64_predicates (i64.add (global.get $bv_f59_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.extend_i32_u
      (block (result i32) (global.set $bv_f59_packed_reads (i64.add (global.get $bv_f59_packed_reads) (i64.const 1))) (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (block (result i32) (global.set $bv_f59_index_or_byte_narrowings (i64.add (global.get $bv_f59_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
        (local.get $4)
       ))
      ))
     )
    )
    (if
     (block (result i32) (global.set $bv_f59_zero_predicates (i64.add (global.get $bv_f59_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready188)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (drop
     (call $function64
      (local.get $0)
      (local.get $4)
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (local.get $7)
       (if (result i64)
        (i64.eq
         (local.get $6)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $6)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $6)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (block (result i32) (global.set $bv_f59_zero_predicates (i64.add (global.get $bv_f59_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $3)
     ))
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (local.get $6)
     )
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function61 (type $call42) (param $0 (ref null $environment89)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 128)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i32.and
      (i64.lt_s
       (local.get $1)
       (i64.const 224)
      )
      (i64.ge_s
       (local.get $1)
       (i64.const 194)
      )
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i32.and
        (i64.lt_s
         (local.get $1)
         (i64.const 240)
        )
        (i64.ge_s
         (local.get $1)
         (i64.const 224)
        )
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i32.and
          (i64.lt_s
           (local.get $1)
           (i64.const 245)
          )
          (i64.ge_s
           (local.get $1)
           (i64.const 240)
          )
         )
         (then
          (i64.const 4)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function63 (type $call42) (param $0 (ref null $environment89)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 2)
     )
     (then
      (i64.const 192)
     )
     (else
      (select
       (i64.const 224)
       (i64.const 240)
       (i64.eq
        (local.get $1)
        (i64.const 3)
       )
      )
     )
    )
   )
  )
 )
 (func $function64 (type $18) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready193)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global193)
     )
    )
    (if (result i32)
     (i64.gt_s
      (if (result i64)
       (i64.eq
        (local.get $2)
        (i64.const 1)
       )
       (then
        (i64.const 0)
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 2)
         )
         (then
          (i64.const 128)
         )
         (else
          (select
           (i64.const 2048)
           (i64.const 65536)
           (i64.eq
            (local.get $2)
            (i64.const 3)
           )
          )
         )
        )
       )
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $6)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $6)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready159)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global159)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (i64.add
        (local.get $1)
        (local.get $5)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (if (result i64)
      (if (result i32)
       (local.tee $8
        (i64.lt_u
         (local.tee $7
          (i64.extend_i32_u
           (array.get_u $type29
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
          )
         )
         (i64.const 128)
        )
       )
       (then
        (local.get $8)
       )
       (else
        (i64.gt_u
         (local.get $7)
         (i64.const 191)
        )
       )
      )
      (then
       (unreachable)
      )
      (else
       (i64.sub
        (local.get $7)
        (i64.const 128)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (i64.add
      (local.get $7)
      (i64.shl
       (local.get $6)
       (i64.const 6)
      )
     )
    )
   )
  )
 )
 (func $function65 (type $call42) (param $0 (ref null $environment89)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 2)
     )
     (then
      (i64.const 128)
     )
     (else
      (select
       (i64.const 2048)
       (i64.const 65536)
       (i64.eq
        (local.get $1)
        (i64.const 3)
       )
      )
     )
    )
   )
  )
 )
 (func $function67 (type $17) (param $0 (ref $type14)) (param $1 (ref $type28)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (local $10 i32)
  (global.set $bv_f67_entries (i64.add (global.get $bv_f67_entries) (i64.const 1)))
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (block (result i32) (global.set $bv_f67_zero_predicates (i64.add (global.get $bv_f67_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready177)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (if
     (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.extend_i32_u
      (block (result i32) (global.set $bv_f67_packed_reads (i64.add (global.get $bv_f67_packed_reads) (i64.const 1))) (array.get_u $type29
       (struct.get $type28 0
        (local.get $1)
       )
       (block (result i32) (global.set $bv_f67_index_or_byte_narrowings (i64.add (global.get $bv_f67_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
        (local.get $5)
       ))
      ))
     )
    )
    (if
     (block (result i32) (global.set $bv_f67_zero_predicates (i64.add (global.get $bv_f67_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready182)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global182)
     )
    )
    (if
     (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.gt_s
      (local.tee $7
       (if (result i64)
        (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
         (local.get $7)
         (i64.const 128)
        ))
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
            (local.get $7)
            (i64.const 224)
           ))
           (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
            (local.get $7)
            (i64.const 194)
           ))
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
              (local.get $7)
              (i64.const 240)
             ))
             (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
              (local.get $7)
              (i64.const 224)
             ))
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
                (local.get $7)
                (i64.const 245)
               ))
               (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
                (local.get $7)
                (i64.const 240)
               ))
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (local.get $5)
      )
     ))
     (then
      (unreachable)
     )
    )
    (if
     (block (result i32) (global.set $bv_f67_zero_predicates (i64.add (global.get $bv_f67_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready184)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (if
     (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $8
     (i64.extend_i32_u
      (block (result i32) (global.set $bv_f67_packed_reads (i64.add (global.get $bv_f67_packed_reads) (i64.const 1))) (array.get_u $type29
       (struct.get $type28 0
        (local.get $1)
       )
       (block (result i32) (global.set $bv_f67_index_or_byte_narrowings (i64.add (global.get $bv_f67_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
        (local.get $5)
       ))
      ))
     )
    )
    (if
     (block (result i32) (global.set $bv_f67_zero_predicates (i64.add (global.get $bv_f67_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready188)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (local.set $10
     (call $function64
      (local.get $1)
      (local.get $5)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (local.get $8)
       (if (result i64)
        (i64.eq
         (local.get $7)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $7)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $7)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (block (result i32) (global.set $bv_f67_ordered_i64_predicates (i64.add (global.get $bv_f67_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     ))
     (then
      (unreachable)
     )
    )
    (block (global.set $bv_f67_scalar_writes (i64.add (global.get $bv_f67_scalar_writes) (i64.const 1))) (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $9
        (block (result i32) (global.set $bv_f67_index_or_byte_narrowings (i64.add (global.get $bv_f67_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
         (local.get $6)
        ))
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $9)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $9)
      (i32.const 8191)
     )
     (local.get $10)
    ))
    (if
     (block (result i32) (global.set $bv_f67_zero_predicates (i64.add (global.get $bv_f67_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $4)
     ))
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (local.get $7)
     )
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $18) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (if (result i32)
   (i64.eq
    (local.get $5)
    (i64.const 1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 1)
         )
         (then
          (i64.const 0)
         )
         (else
          (if (result i64)
           (i64.eq
            (local.get $2)
            (i64.const 2)
           )
           (then
            (i64.const 192)
           )
           (else
            (select
             (i64.const 224)
             (i64.const 240)
             (i64.eq
              (local.get $2)
              (i64.const 3)
             )
            )
           )
          )
         )
        )
        (local.get $6)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $7
       (i64.add
        (i64.sub
         (local.get $5)
         (i64.const 1)
        )
        (local.get $1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (i64.rem_s
         (local.get $6)
         (i64.const 64)
        )
        (i64.const 128)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $6)
      (i64.const 64)
     )
    )
   )
  )
 )
 (func $function74 (type $16) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i32)
  (local $7 i64)
  (local $scratch i32)
  (global.set $bv_f74_entries (i64.add (global.get $bv_f74_entries) (i64.const 1)))
  (if (result i64)
   (block (result i32) (global.set $bv_f74_ordered_i64_predicates (i64.add (global.get $bv_f74_ordered_i64_predicates) (i64.const 1))) (i64.gt_s
    (local.get $5)
    (i64.const 4294967295)
   ))
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (local.get $4)
     )
     (then
      (local.get $5)
     )
     (else
      (if
       (block (result i32) (global.set $bv_f74_ordered_i64_predicates (i64.add (global.get $bv_f74_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
       ))
       (then
        (unreachable)
       )
      )
      (local.set $7
       (if (result i64)
        (block (result i32) (global.set $bv_f74_ordered_i64_predicates (i64.add (global.get $bv_f74_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
         (local.tee $7
          (i64.extend_i32_u
           (block (result i32)
            (local.set $scratch
             (block (result i32) (global.set $bv_f74_scalar_reads (i64.add (global.get $bv_f74_scalar_reads) (i64.const 1))) (array.get $type15
              (if (result (ref $type15))
               (i32.lt_u
                (local.tee $6
                 (block (result i32) (global.set $bv_f74_index_or_byte_narrowings (i64.add (global.get $bv_f74_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
                  (local.get $4)
                 ))
                )
                (i32.const 8192)
               )
               (then
                (struct.get $type14 2
                 (local.get $0)
                )
               )
               (else
                (ref.as_non_null
                 (array.get $type16
                  (struct.get $type14 3
                   (local.get $0)
                  )
                  (i32.sub
                   (i32.shr_u
                    (local.get $6)
                    (i32.const 13)
                   )
                   (i32.const 1)
                  )
                 )
                )
               )
              )
              (i32.and
               (local.get $6)
               (i32.const 8191)
              )
             ))
            )
            (if
             (block (result i32) (global.set $bv_f74_zero_predicates (i64.add (global.get $bv_f74_zero_predicates) (i64.const 1))) (i32.eqz
              (global.get $ready229)
             ))
             (then
              (unreachable)
             )
            )
            (drop
             (struct.get $type42 1
              (global.get $global229)
             )
            )
            (local.get $scratch)
           )
          )
         )
         (i64.const 128)
        ))
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (block (result i32) (global.set $bv_f74_ordered_i64_predicates (i64.add (global.get $bv_f74_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
           (local.get $7)
           (i64.const 2048)
          ))
          (then
           (i64.const 2)
          )
          (else
           (select
            (i64.const 3)
            (i64.const 4)
            (block (result i32) (global.set $bv_f74_ordered_i64_predicates (i64.add (global.get $bv_f74_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
             (local.get $7)
             (i64.const 65536)
            ))
           )
          )
         )
        )
       )
      )
      (if
       (block (result i32) (global.set $bv_f74_zero_predicates (i64.add (global.get $bv_f74_zero_predicates) (i64.const 1))) (i32.eqz
        (local.get $3)
       ))
       (then
        (unreachable)
       )
      )
      (return_call $function74
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (local.get $7)
       )
      )
     )
    )
   )
  )
 )
 (func $function75 (type $call42) (param $0 (ref null $environment89)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 128)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $1)
      (i64.const 2048)
     )
     (then
      (i64.const 2)
     )
     (else
      (select
       (i64.const 3)
       (i64.const 4)
       (i64.lt_s
        (local.get $1)
        (i64.const 65536)
       )
      )
     )
    )
   )
  )
 )
 (func $function77 (type $15) (param $0 (ref $type28)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (local $scratch i32)
  (global.set $bv_f77_entries (i64.add (global.get $bv_f77_entries) (i64.const 1)))
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (block (result i32) (global.set $bv_f77_ordered_i64_predicates (i64.add (global.get $bv_f77_ordered_i64_predicates) (i64.const 1))) (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $1)
       )
      )
     ))
     (then
      (unreachable)
     )
    )
    (local.set $7
     (if (result i64)
      (block (result i32) (global.set $bv_f77_ordered_i64_predicates (i64.add (global.get $bv_f77_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
       (local.tee $7
        (local.tee $8
         (i64.extend_i32_u
          (block (result i32)
           (local.set $scratch
            (block (result i32) (global.set $bv_f77_scalar_reads (i64.add (global.get $bv_f77_scalar_reads) (i64.const 1))) (array.get $type15
             (if (result (ref $type15))
              (i32.lt_u
               (local.tee $9
                (block (result i32) (global.set $bv_f77_index_or_byte_narrowings (i64.add (global.get $bv_f77_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
                 (local.get $5)
                ))
               )
               (i32.const 8192)
              )
              (then
               (struct.get $type14 2
                (local.get $1)
               )
              )
              (else
               (ref.as_non_null
                (array.get $type16
                 (struct.get $type14 3
                  (local.get $1)
                 )
                 (i32.sub
                  (i32.shr_u
                   (local.get $9)
                   (i32.const 13)
                  )
                  (i32.const 1)
                 )
                )
               )
              )
             )
             (i32.and
              (local.get $9)
              (i32.const 8191)
             )
            ))
           )
           (if
            (block (result i32) (global.set $bv_f77_zero_predicates (i64.add (global.get $bv_f77_zero_predicates) (i64.const 1))) (i32.eqz
             (global.get $ready229)
            ))
            (then
             (unreachable)
            )
           )
           (drop
            (struct.get $type42 1
             (global.get $global229)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
       (i64.const 128)
      ))
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (block (result i32) (global.set $bv_f77_ordered_i64_predicates (i64.add (global.get $bv_f77_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
         (local.get $7)
         (i64.const 2048)
        ))
        (then
         (i64.const 2)
        )
        (else
         (select
          (i64.const 3)
          (i64.const 4)
          (block (result i32) (global.set $bv_f77_ordered_i64_predicates (i64.add (global.get $bv_f77_ordered_i64_predicates) (i64.const 1))) (i64.lt_u
           (local.get $7)
           (i64.const 65536)
          ))
         )
        )
       )
      )
     )
    )
    (if
     (block (result i32) (global.set $bv_f77_zero_predicates (i64.add (global.get $bv_f77_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready209)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global209)
     )
    )
    (drop
     (call $function71
      (local.get $0)
      (local.get $6)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (local.get $7)
      (local.get $8)
     )
    )
    (if
     (block (result i32) (global.set $bv_f77_zero_predicates (i64.add (global.get $bv_f77_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $4)
     ))
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (i64.add
      (local.get $6)
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function79 (type $call55) (param $0 (ref $type14)) (result (ref $type28))
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $type28))
  (local $bv_length i32)
  (global.set $bv_f79_entries (i64.add (global.get $bv_f79_entries) (i64.const 1)))
  (if
   (block (result i32) (global.set $bv_f79_zero_predicates (i64.add (global.get $bv_f79_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready217)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (if
   (block (result i32) (global.set $bv_f79_zero_predicates (i64.add (global.get $bv_f79_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready135)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (block (result i32) (global.set $bv_f79_ordered_i64_predicates (i64.add (global.get $bv_f79_ordered_i64_predicates) (i64.const 1))) (i64.gt_s
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
    )
    (local.get $1)
   ))
   (then
    (unreachable)
   )
  )
  (if
   (block (result i32) (global.set $bv_f79_zero_predicates (i64.add (global.get $bv_f79_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready222)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global222)
   )
  )
  (local.set $2
   (call $function74
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (if
   (block (result i32) (global.set $bv_f79_zero_predicates (i64.add (global.get $bv_f79_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready109)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (if
   (block (result i32) (global.set $bv_f79_ordered_i64_predicates (i64.add (global.get $bv_f79_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   ))
   (then
    (unreachable)
   )
  )
  (if
   (block (result i32) (global.set $bv_f79_zero_predicates (i64.add (global.get $bv_f79_zero_predicates) (i64.const 1))) (i32.eqz
    (global.get $ready231)
   ))
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global231)
   )
  )
  (drop
   (call $function77
    (local.tee $3
     (struct.new $type28
      (array.new_default $type29 (block (result i32) (local.set $bv_length (block (result i32) (global.set $bv_f79_index_or_byte_narrowings (i64.add (global.get $bv_f79_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
        (local.get $2)
       ))) (global.set $bv_array_type29_requests (i64.add (global.get $bv_array_type29_requests) (i64.const 1))) (global.set $bv_array_type29_elements (i64.add (global.get $bv_array_type29_elements) (i64.extend_i32_u (local.get $bv_length)))) (local.get $bv_length)))
     )
    )
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (local.get $3)
 )
 (func $function83 (type $13) (param $0 (ref $type14)) (result i32)
  (if (result i32)
   (i64.eqz
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (array.get $type15
      (struct.get $type14 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign0
       (array.get $type15
        (struct.get $type14 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign0
         (array.get $type15
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign0
           (array.get $type15
            (struct.get $type14 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign0
             (array.get $type15
              (struct.get $type14 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign0
               (array.get $type15
                (struct.get $type14 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign0
                 (array.get $type15
                  (struct.get $type14 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign0
                   (array.get $type15
                    (struct.get $type14 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign0
                     (array.get $type15
                      (struct.get $type14 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign0
                       (array.get $type15
                        (struct.get $type14 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (struct.get $type14 1
                          (local.get $0)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type14 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign0
                         (array.get $type15
                          (struct.get $type14 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (struct.get $type14 1
                            (local.get $0)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type14 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign0
                           (array.get $type15
                            (struct.get $type14 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (struct.get $type14 1
                              (local.get $0)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type14 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign0
                             (array.get $type15
                              (struct.get $type14 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (struct.get $type14 1
                                (local.get $0)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type14 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign0
                               (array.get $type15
                                (struct.get $type14 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (struct.get $type14 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type14 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign0
                                 (array.get $type15
                                  (call $string-block
                                   (local.get $0)
                                   (i32.const 14)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (return_call $function84
                                 (local.get $0)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function84 (type $12) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (array.get $type15
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function86 (param $0 i32)
  (local $1 (ref $type60))
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready256)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global256)
     )
    )
    (drop
     (call $function83
      (global.get $string0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready256)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global256)
     )
    )
    (drop
     (call $function83
      (global.get $string1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready260)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global260)
     )
    )
    (call $foreign0
     (i32.const 10)
    )
    (if
     (i32.eqz
      (global.get $ready261)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type60 0
     (ref.as_non_null
      (global.get $global261)
     )
     (block (result (ref (exact $type23)))
      (if
       (i32.eqz
        (global.get $ready261)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type23
       (struct.get $type60 0
        (global.get $global261)
       )
      )
     )
    )
   )
  )
 )
 (func $function88 (type $10) (param $0 (ref $type65)) (param $1 (ref $type64)) (param $2 (ref $type64)) (param $3 (ref $type64)) (result i64)
  (local $4 (ref $type66))
  (struct.set $type66 0
   (local.tee $4
    (struct.get $type65 0
     (local.get $0)
    )
   )
   (i64.rem_s
    (i64.add
     (i64.mul
      (struct.get $type64 0
       (local.get $1)
      )
      (struct.get $type66 0
       (local.get $4)
      )
     )
     (struct.get $type64 0
      (local.get $2)
     )
    )
    (i64.add
     (struct.get $type64 0
      (local.get $3)
     )
     (i64.const 1)
    )
   )
  )
  (i64.rem_s
   (i64.div_s
    (struct.get $type66 0
     (local.get $4)
    )
    (i64.const 8)
   )
   (i64.const 16384)
  )
 )
 (func $function89 (type $call42) (param $0 (ref null $environment89)) (param $1 i64) (result i64)
  (local $2 (ref $type66))
  (local $3 (ref $type65))
  (local $4 (ref $type64))
  (local $5 (ref $type64))
  (local $6 (ref $type64))
  (local $7 (ref $type63))
  (local $8 (ref $type63))
  (local $9 i64)
  (local $10 i64)
  (global.set $bv_f89_entries (i64.add (global.get $bv_f89_entries) (i64.const 1)))
  (if (result i64)
   (block (result i32) (global.set $bv_f89_ordered_i64_predicates (i64.add (global.get $bv_f89_ordered_i64_predicates) (i64.const 1))) (i64.lt_s
    (local.get $1)
    (i64.const 16384)
   ))
   (then
    (drop
     (block (result (ref $type63)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 0
      (local.get $0)
     ))
    )
    (struct.set $type66 0
     (local.tee $2
      (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
       (local.tee $3
        (block (result (ref $type65)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 1
         (local.get $0)
        ))
       )
      ))
     )
     (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
      (i64.add
       (i64.mul
        (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
         (block (result (ref $type64)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 2
          (local.get $0)
         ))
        ))
        (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
         (local.get $2)
        ))
       )
       (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
        (block (result (ref $type64)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 3
         (local.get $0)
        ))
       ))
      )
      (i64.add
       (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
        (block (result (ref $type64)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 4
         (local.get $0)
        ))
       ))
       (i64.const 1)
      )
     ))
    )
    (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
     (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
      (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
       (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
        (local.get $3)
       ))
      ))
      (i64.const 8)
     ))
     (local.get $1)
    ))
   )
   (else
    (local.set $7
     (block (result (ref $type63)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 0
      (local.get $0)
     ))
    )
    (struct.set $type66 0
     (local.tee $2
      (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
       (local.tee $3
        (block (result (ref $type65)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 1
         (local.get $0)
        ))
       )
      ))
     )
     (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
      (i64.add
       (i64.mul
        (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
         (local.tee $4
          (block (result (ref $type64)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 2
           (local.get $0)
          ))
         )
        ))
        (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
         (local.get $2)
        ))
       )
       (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
        (local.tee $5
         (block (result (ref $type64)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 3
          (local.get $0)
         ))
        )
       ))
      )
      (i64.add
       (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
        (local.tee $6
         (block (result (ref $type64)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 4
          (local.get $0)
         ))
        )
       ))
       (i64.const 1)
      )
     ))
    )
    (local.set $8
     (block (result (ref $type63)) (global.set $bv_f89_capture_gets (i64.add (global.get $bv_f89_capture_gets) (i64.const 1))) (struct.get $environment89 5
      (local.get $0)
     ))
    )
    (if
     (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready281)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $9
     (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
      (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
       (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
        (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
         (local.get $3)
        ))
       ))
       (i64.const 8)
      ))
      (i64.const 16384)
     ))
    )
    (drop
     (ref.as_non_null
      (global.get $global281)
     )
    )
    (if (result i64)
     (i64.eqz
      (local.tee $10
       (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
        (local.get $1)
        (i64.const 16384)
       ))
      )
     )
     (then
      (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
       (local.get $9)
       (local.get $1)
      ))
     )
     (else
      (struct.set $type66 0
       (local.tee $2
        (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
         (local.get $3)
        ))
       )
       (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
        (i64.add
         (i64.mul
          (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
           (local.get $4)
          ))
          (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
           (local.get $2)
          ))
         )
         (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
          (local.get $5)
         ))
        )
        (i64.add
         (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
          (local.get $6)
         ))
         (i64.const 1)
        )
       ))
      )
      (if
       (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
        (global.get $ready281)
       ))
       (then
        (unreachable)
       )
      )
      (local.set $9
       (i64.add
        (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
         (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
          (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
           (local.get $2)
          ))
          (i64.const 8)
         ))
         (i64.const 16384)
        ))
        (i64.shl
         (local.get $9)
         (i64.const 14)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if (result i64)
       (i64.eqz
        (local.tee $10
         (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
          (local.get $10)
          (i64.const 16384)
         ))
        )
       )
       (then
        (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
         (local.get $9)
         (local.get $1)
        ))
       )
       (else
        (struct.set $type66 0
         (local.tee $2
          (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
           (local.get $3)
          ))
         )
         (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
          (i64.add
           (i64.mul
            (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
             (local.get $4)
            ))
            (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
             (local.get $2)
            ))
           )
           (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
            (local.get $5)
           ))
          )
          (i64.add
           (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
            (local.get $6)
           ))
           (i64.const 1)
          )
         ))
        )
        (if
         (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
          (global.get $ready281)
         ))
         (then
          (unreachable)
         )
        )
        (local.set $9
         (i64.add
          (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
           (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
            (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
             (local.get $2)
            ))
            (i64.const 8)
           ))
           (i64.const 16384)
          ))
          (i64.shl
           (local.get $9)
           (i64.const 14)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global281)
         )
        )
        (if (result i64)
         (i64.eqz
          (local.tee $10
           (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
            (local.get $10)
            (i64.const 16384)
           ))
          )
         )
         (then
          (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
           (local.get $9)
           (local.get $1)
          ))
         )
         (else
          (struct.set $type66 0
           (local.tee $2
            (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
             (local.get $3)
            ))
           )
           (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
            (i64.add
             (i64.mul
              (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
               (local.get $4)
              ))
              (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
               (local.get $2)
              ))
             )
             (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
              (local.get $5)
             ))
            )
            (i64.add
             (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
              (local.get $6)
             ))
             (i64.const 1)
            )
           ))
          )
          (if
           (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
            (global.get $ready281)
           ))
           (then
            (unreachable)
           )
          )
          (local.set $9
           (i64.add
            (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
             (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
              (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
               (local.get $2)
              ))
              (i64.const 8)
             ))
             (i64.const 16384)
            ))
            (i64.shl
             (local.get $9)
             (i64.const 14)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global281)
           )
          )
          (if (result i64)
           (i64.eqz
            (local.tee $10
             (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
              (local.get $10)
              (i64.const 16384)
             ))
            )
           )
           (then
            (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
             (local.get $9)
             (local.get $1)
            ))
           )
           (else
            (struct.set $type66 0
             (local.tee $2
              (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
               (local.get $3)
              ))
             )
             (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
              (i64.add
               (i64.mul
                (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                 (local.get $4)
                ))
                (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                 (local.get $2)
                ))
               )
               (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                (local.get $5)
               ))
              )
              (i64.add
               (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                (local.get $6)
               ))
               (i64.const 1)
              )
             ))
            )
            (if
             (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
              (global.get $ready281)
             ))
             (then
              (unreachable)
             )
            )
            (local.set $9
             (i64.add
              (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
               (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                 (local.get $2)
                ))
                (i64.const 8)
               ))
               (i64.const 16384)
              ))
              (i64.shl
               (local.get $9)
               (i64.const 14)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global281)
             )
            )
            (if (result i64)
             (i64.eqz
              (local.tee $10
               (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                (local.get $10)
                (i64.const 16384)
               ))
              )
             )
             (then
              (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
               (local.get $9)
               (local.get $1)
              ))
             )
             (else
              (struct.set $type66 0
               (local.tee $2
                (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
                 (local.get $3)
                ))
               )
               (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                (i64.add
                 (i64.mul
                  (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                   (local.get $4)
                  ))
                  (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                   (local.get $2)
                  ))
                 )
                 (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                  (local.get $5)
                 ))
                )
                (i64.add
                 (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                  (local.get $6)
                 ))
                 (i64.const 1)
                )
               ))
              )
              (if
               (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
                (global.get $ready281)
               ))
               (then
                (unreachable)
               )
              )
              (local.set $9
               (i64.add
                (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                 (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                  (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                   (local.get $2)
                  ))
                  (i64.const 8)
                 ))
                 (i64.const 16384)
                ))
                (i64.shl
                 (local.get $9)
                 (i64.const 14)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global281)
               )
              )
              (if (result i64)
               (i64.eqz
                (local.tee $10
                 (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                  (local.get $10)
                  (i64.const 16384)
                 ))
                )
               )
               (then
                (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                 (local.get $9)
                 (local.get $1)
                ))
               )
               (else
                (struct.set $type66 0
                 (local.tee $2
                  (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
                   (local.get $3)
                  ))
                 )
                 (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                  (i64.add
                   (i64.mul
                    (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                     (local.get $4)
                    ))
                    (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                     (local.get $2)
                    ))
                   )
                   (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                    (local.get $5)
                   ))
                  )
                  (i64.add
                   (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                    (local.get $6)
                   ))
                   (i64.const 1)
                  )
                 ))
                )
                (if
                 (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
                  (global.get $ready281)
                 ))
                 (then
                  (unreachable)
                 )
                )
                (local.set $9
                 (i64.add
                  (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                   (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                    (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                     (local.get $2)
                    ))
                    (i64.const 8)
                   ))
                   (i64.const 16384)
                  ))
                  (i64.shl
                   (local.get $9)
                   (i64.const 14)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global281)
                 )
                )
                (if (result i64)
                 (i64.eqz
                  (local.tee $10
                   (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                    (local.get $10)
                    (i64.const 16384)
                   ))
                  )
                 )
                 (then
                  (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                   (local.get $9)
                   (local.get $1)
                  ))
                 )
                 (else
                  (struct.set $type66 0
                   (local.tee $2
                    (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
                     (local.get $3)
                    ))
                   )
                   (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                    (i64.add
                     (i64.mul
                      (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                       (local.get $4)
                      ))
                      (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                       (local.get $2)
                      ))
                     )
                     (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                      (local.get $5)
                     ))
                    )
                    (i64.add
                     (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                      (local.get $6)
                     ))
                     (i64.const 1)
                    )
                   ))
                  )
                  (if
                   (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
                    (global.get $ready281)
                   ))
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $9
                   (i64.add
                    (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                     (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                      (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                       (local.get $2)
                      ))
                      (i64.const 8)
                     ))
                     (i64.const 16384)
                    ))
                    (i64.shl
                     (local.get $9)
                     (i64.const 14)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global281)
                   )
                  )
                  (if (result i64)
                   (i64.eqz
                    (local.tee $10
                     (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                      (local.get $10)
                      (i64.const 16384)
                     ))
                    )
                   )
                   (then
                    (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                     (local.get $9)
                     (local.get $1)
                    ))
                   )
                   (else
                    (struct.set $type66 0
                     (local.tee $2
                      (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
                       (local.get $3)
                      ))
                     )
                     (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                      (i64.add
                       (i64.mul
                        (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                         (local.get $4)
                        ))
                        (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                         (local.get $2)
                        ))
                       )
                       (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                        (local.get $5)
                       ))
                      )
                      (i64.add
                       (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                        (local.get $6)
                       ))
                       (i64.const 1)
                      )
                     ))
                    )
                    (if
                     (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
                      (global.get $ready281)
                     ))
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $9
                     (i64.add
                      (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                       (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                        (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                         (local.get $2)
                        ))
                        (i64.const 8)
                       ))
                       (i64.const 16384)
                      ))
                      (i64.shl
                       (local.get $9)
                       (i64.const 14)
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global281)
                     )
                    )
                    (if (result i64)
                     (i64.eqz
                      (local.tee $10
                       (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                        (local.get $10)
                        (i64.const 16384)
                       ))
                      )
                     )
                     (then
                      (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                       (local.get $9)
                       (local.get $1)
                      ))
                     )
                     (else
                      (local.set $10
                       (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                        (local.get $10)
                        (i64.const 16384)
                       ))
                      )
                      (struct.set $type66 0
                       (local.tee $2
                        (block (result (ref $type66)) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type65 0
                         (local.get $3)
                        ))
                       )
                       (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                        (i64.add
                         (i64.mul
                          (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                           (local.get $4)
                          ))
                          (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                           (local.get $2)
                          ))
                         )
                         (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                          (local.get $5)
                         ))
                        )
                        (i64.add
                         (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type64 0
                          (local.get $6)
                         ))
                         (i64.const 1)
                        )
                       ))
                      )
                      (local.set $9
                       (i64.add
                        (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                         (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                          (block (result i64) (global.set $bv_f89_cell_gets (i64.add (global.get $bv_f89_cell_gets) (i64.const 1))) (struct.get $type66 0
                           (local.get $2)
                          ))
                          (i64.const 8)
                         ))
                         (i64.const 16384)
                        ))
                        (i64.shl
                         (local.get $9)
                         (i64.const 14)
                        )
                       )
                      )
                      (if
                       (block (result i32) (global.set $bv_f89_zero_predicates (i64.add (global.get $bv_f89_zero_predicates) (i64.const 1))) (i32.eqz
                        (global.get $ready281)
                       ))
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global281)
                       )
                      )
                      (if (result i64)
                       (i64.eqz
                        (local.get $10)
                       )
                       (then
                        (block (result i64) (global.set $bv_f89_signed_remainders (i64.add (global.get $bv_f89_signed_remainders) (i64.const 1))) (i64.rem_s
                         (local.get $9)
                         (local.get $1)
                        ))
                       )
                       (else
                        (return_call $function90
                         (local.get $7)
                         (local.get $3)
                         (local.get $4)
                         (local.get $5)
                         (local.get $6)
                         (local.get $8)
                         (block (result i64) (global.set $bv_f89_signed_divisions (i64.add (global.get $bv_f89_signed_divisions) (i64.const 1))) (i64.div_s
                          (local.get $10)
                          (i64.const 16384)
                         ))
                         (i64.add
                          (call $function88
                           (local.get $3)
                           (local.get $4)
                           (local.get $5)
                           (local.get $6)
                          )
                          (i64.shl
                           (local.get $9)
                           (i64.const 14)
                          )
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function90 (type $4) (param $0 (ref $type63)) (param $1 (ref $type65)) (param $2 (ref $type64)) (param $3 (ref $type64)) (param $4 (ref $type64)) (param $5 (ref $type63)) (param $6 i64) (param $7 i64) (param $8 i64) (result i64)
  (if
   (i32.eqz
    (global.get $ready281)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global281)
   )
  )
  (if (result i64)
   (i64.eqz
    (local.get $6)
   )
   (then
    (i64.rem_s
     (local.get $7)
     (local.get $8)
    )
   )
   (else
    (return_call $function90
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.div_s
      (local.get $6)
      (i64.const 16384)
     )
     (i64.add
      (call $function88
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
      )
      (i64.shl
       (local.get $7)
       (i64.const 14)
      )
     )
     (local.get $8)
    )
   )
  )
 )
 (func $function93 (type $3) (param $0 (ref $type42)) (param $1 i32) (param $2 i64) (param $3 (ref $type28)) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type28))
  (local $7 i64)
  (global.set $bv_f93_entries (i64.add (global.get $bv_f93_entries) (i64.const 1)))
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (block (result i32) (global.set $bv_f93_zero_predicates (i64.add (global.get $bv_f93_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $1)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $7
     (block (result i64) (global.set $bv_f93_rng_closure_calls (i64.add (global.get $bv_f93_rng_closure_calls) (i64.const 1))) (call_ref $call42
      (struct.get $type42 1
       (local.get $0)
      )
      (i64.const 128)
      (struct.get $type42 0
       (local.get $0)
      )
     ))
    )
    (if
     (block (result i32) (global.set $bv_f93_ordered_i64_predicates (i64.add (global.get $bv_f93_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     ))
     (then
      (unreachable)
     )
    )
    (if
     (block (result i32) (global.set $bv_f93_ordered_i64_predicates (i64.add (global.get $bv_f93_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
      (local.get $7)
      (i64.const 255)
     ))
     (then
      (unreachable)
     )
    )
    (block (global.set $bv_f93_packed_writes (i64.add (global.get $bv_f93_packed_writes) (i64.const 1))) (array.set $type29
     (struct.get $type28 0
      (local.get $3)
     )
     (block (result i32) (global.set $bv_f93_index_or_byte_narrowings (i64.add (global.get $bv_f93_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
      (local.get $6)
     ))
     (block (result i32) (global.set $bv_f93_index_or_byte_narrowings (i64.add (global.get $bv_f93_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
      (local.get $7)
     ))
    ))
    (if
     (block (result i32) (global.set $bv_f93_zero_predicates (i64.add (global.get $bv_f93_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $5)
     ))
     (then
      (unreachable)
     )
    )
    (return_call $function93
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function99 (type $2) (param $0 i64) (param $1 i64) (param $2 (ref $type42)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i32) (param $10 i64) (result i32)
  (local $11 i64)
  (local $12 i32)
  (local $13 (ref $type28))
  (local $14 (ref $type28))
  (local $15 (ref $type14))
  (local $16 (ref $type14))
  (local $scratch i32)
  (local $bv_length i32)
  (global.set $bv_f99_entries (i64.add (global.get $bv_f99_entries) (i64.const 1)))
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $10)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $5)
     ))
     (then
      (unreachable)
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $3)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $11
     (block (result i64) (global.set $bv_f99_rng_closure_calls (i64.add (global.get $bv_f99_rng_closure_calls) (i64.const 1))) (call_ref $call42
      (struct.get $type42 1
       (local.get $2)
      )
      (local.get $1)
      (struct.get $type42 0
       (local.get $2)
      )
     ))
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready109)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_ordered_i64_predicates (i64.add (global.get $bv_f99_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
      (local.get $11)
      (i64.const 4294967295)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $13
     (call $function93
      (local.get $2)
      (local.get $3)
      (local.get $11)
      (struct.new $type28
       (array.new_default $type29 (block (result i32) (local.set $bv_length (block (result i32) (global.set $bv_f99_index_or_byte_narrowings (i64.add (global.get $bv_f99_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
         (local.get $11)
        ))) (global.set $bv_array_type29_requests (i64.add (global.get $bv_array_type29_requests) (i64.const 1))) (global.set $bv_array_type29_elements (i64.add (global.get $bv_array_type29_elements) (i64.extend_i32_u (local.get $bv_length)))) (local.get $bv_length)))
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready207)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready244)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global244)
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $7)
     ))
     (then
      (unreachable)
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready164)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (local.set $14
     (call $function79
      (local.tee $15
       (call $function57
        (local.get $13)
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 0
           (local.get $13)
          )
         )
        )
       )
      )
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready164)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (local.set $16
     (call $function57
      (local.get $14)
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 0
         (local.get $14)
        )
       )
      )
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready103)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global103)
     )
    )
    (call $function86
     (block (result i32)
      (local.set $scratch
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $15)
          )
         )
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $16)
          )
         )
        )
        (then
         (call $function40
          (local.get $15)
          (local.get $16)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (if
       (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
        (global.get $ready262)
       ))
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global262)
       )
      )
      (local.get $scratch)
     )
    )
    (if
     (block (result i32) (global.set $bv_f99_zero_predicates (i64.add (global.get $bv_f99_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $9)
     ))
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (i64.add
      (local.get $10)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function100 (type $call42) (param $0 (ref null $environment89)) (param $1 i64) (result i64)
  (return_call $function101
   (local.get $1)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $function101 (type $1) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 (ref null $type23))
  (local $6 (ref $type42))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type14))
  (local $10 (ref $type14))
  (local $11 i64)
  (local $12 i64)
  (local $13 i32)
  (local $scratch i32)
  (local $bv_length i32)
  (global.set $bv_f101_entries (i64.add (global.get $bv_f101_entries) (i64.const 1)))
  (if (result i64)
   (block (result i32) (global.set $bv_f101_ordered_i64_predicates (i64.add (global.get $bv_f101_ordered_i64_predicates) (i64.const 1))) (i64.gt_s
    (local.get $0)
    (local.get $3)
   ))
   (then
    (if
     (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready312)
     ))
     (then
      (unreachable)
     )
    )
    (if
     (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready320)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global320)
     )
    )
    (drop
     (call $function99
      (call $foreign1
       (global.get $global312)
      )
      (block (result i64)
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready313)
        ))
        (then
         (unreachable)
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready320)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global320)
        )
       )
       (call $foreign1
        (global.get $global313)
       )
      )
      (block (result (ref $type42))
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready266)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global266)
        )
       )
       (local.set $4
        (call $function89
         (struct.get $type42 1
          (local.tee $6
           (struct.new $type42
            (ref.func $function89)
            (struct.new $environment89
             (struct.new_default $type63)
             (struct.new $type65
              (struct.new $type66
               (i64.const 1)
              )
             )
             (struct.new $type64
              (i64.const 701)
             )
             (struct.new $type64
              (i64.const 743483)
             )
             (struct.new $type64
              (i64.const 524287)
             )
             (struct.new_default $type63)
            )
           )
          )
         )
         (i64.const 10)
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready109)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global109)
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_ordered_i64_predicates (i64.add (global.get $bv_f101_ordered_i64_predicates) (i64.const 1))) (i64.gt_u
         (local.get $4)
         (i64.const 4294967295)
        ))
        (then
         (unreachable)
        )
       )
       (local.set $7
        (call $function93
         (local.get $6)
         (i32.const 1)
         (local.get $4)
         (struct.new $type28
          (array.new_default $type29 (block (result i32) (local.set $bv_length (block (result i32) (global.set $bv_f101_index_or_byte_narrowings (i64.add (global.get $bv_f101_index_or_byte_narrowings) (i64.const 1))) (i32.wrap_i64
            (local.get $4)
           ))) (global.set $bv_array_type29_requests (i64.add (global.get $bv_array_type29_requests) (i64.const 1))) (global.set $bv_array_type29_elements (i64.add (global.get $bv_array_type29_elements) (i64.extend_i32_u (local.get $bv_length)))) (local.get $bv_length)))
         )
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready207)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global207)
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready244)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global244)
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready164)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global164)
        )
       )
       (local.set $8
        (call $function79
         (local.tee $9
          (call $function57
           (local.get $7)
           (i64.extend_i32_u
            (array.len
             (struct.get $type28 0
              (local.get $7)
             )
            )
           )
          )
         )
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready164)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global164)
        )
       )
       (local.set $10
        (call $function57
         (local.get $8)
         (i64.extend_i32_u
          (array.len
           (struct.get $type28 0
            (local.get $8)
           )
          )
         )
        )
       )
       (if
        (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
         (global.get $ready103)
        ))
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (call $function86
        (block (result i32)
         (local.set $scratch
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $9)
             )
            )
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $10)
             )
            )
           )
           (then
            (call $function40
             (local.get $9)
             (local.get $10)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (if
          (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
           (global.get $ready262)
          ))
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global262)
          )
         )
         (local.get $scratch)
        )
       )
       (local.get $6)
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready261)
     ))
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type60 0
      (global.get $global261)
     )
    )
    (if
     (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
      (global.get $ready323)
     ))
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global323)
     )
    )
    (local.set $4
     (if (result i64)
      (ref.is_null
       (local.get $5)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $5
          (struct.get $type23 0
           (local.get $5)
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $5
            (struct.get $type23 0
             (local.get $5)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $5
              (struct.get $type23 0
               (local.get $5)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $5
                (struct.get $type23 0
                 (local.get $5)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $5
                  (struct.get $type23 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $5
                    (struct.get $type23 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $5
                      (struct.get $type23 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $5
                        (struct.get $type23 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $5
                          (struct.get $type23 0
                           (local.get $5)
                          )
                         )
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $5
                            (struct.get $type23 0
                             (local.get $5)
                            )
                           )
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $5
                              (struct.get $type23 0
                               (local.get $5)
                              )
                             )
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $5
                                (struct.get $type23 0
                                 (local.get $5)
                                )
                               )
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $5
                                  (struct.get $type23 0
                                   (local.get $5)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (call $function104
                                  (i32.const 0)
                                  (i32.const 1)
                                  (struct.get $type23 0
                                   (local.get $5)
                                  )
                                  (i64.const 14)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
      (local.get $2)
     ))
     (then
      (unreachable)
     )
    )
    (return_call $function101
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (block (result i32) (global.set $bv_f101_ordered_i64_predicates (i64.add (global.get $bv_f101_ordered_i64_predicates) (i64.const 1))) (i64.gt_s
        (local.get $3)
        (i64.const 0)
       ))
       (then
        (if
         (block (result i32) (global.set $bv_f101_zero_predicates (i64.add (global.get $bv_f101_zero_predicates) (i64.const 1))) (i32.eqz
          (global.get $ready314)
         ))
         (then
          (unreachable)
         )
        )
        (i64.eq
         (global.get $global314)
         (local.get $4)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function104 (type $0) (param $0 i32) (param $1 i32) (param $2 (ref null $type23)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type23 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function104
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready315)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type42 1
    (global.get $global315)
   )
  )
  (return_call $function101
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type26)
  )
  (global.set $ready103
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type33)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global182
   (struct.new $type42
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $ready182
   (i32.const 1)
  )
  (global.set $global188
   (struct.new $type42
    (ref.func $function63)
    (ref.null none)
   )
  )
  (global.set $ready188
   (i32.const 1)
  )
  (global.set $global193
   (struct.new $type42
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $ready193
   (i32.const 1)
  )
  (global.set $global177
   (struct.new_default $type43)
  )
  (global.set $ready177
   (i32.const 1)
  )
  (global.set $global159
   (struct.new_default $type44)
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global184
   (struct.new_default $type45)
  )
  (global.set $ready184
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type43)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global195
   (struct.new_default $type46)
  )
  (global.set $ready195
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type47)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global207
   (struct.new_default $type49)
  )
  (global.set $ready207
   (i32.const 1)
  )
  (global.set $global229
   (struct.new $type42
    (ref.func $function75)
    (ref.null none)
   )
  )
  (global.set $ready229
   (i32.const 1)
  )
  (global.set $global222
   (struct.new_default $type50)
  )
  (global.set $ready222
   (i32.const 1)
  )
  (global.set $global209
   (struct.new_default $type51)
  )
  (global.set $ready209
   (i32.const 1)
  )
  (global.set $global231
   (struct.new_default $type52)
  )
  (global.set $ready231
   (i32.const 1)
  )
  (global.set $global217
   (struct.new_default $type53)
  )
  (global.set $ready217
   (i32.const 1)
  )
  (global.set $global244
   (struct.new_default $type55)
  )
  (global.set $ready244
   (i32.const 1)
  )
  (global.set $global323
   (struct.new_default $type24)
  )
  (global.set $ready323
   (i32.const 1)
  )
  (global.set $global246
   (struct.new_default $type56)
  )
  (global.set $ready246
   (i32.const 1)
  )
  (global.set $global281
   (struct.new_default $type57)
  )
  (global.set $ready281
   (i32.const 1)
  )
  (global.set $global256
   (struct.new_default $type58)
  )
  (global.set $ready256
   (i32.const 1)
  )
  (global.set $global260
   (struct.new_default $type10)
  )
  (global.set $ready260
   (i32.const 1)
  )
  (global.set $global320
   (struct.new_default $type59)
  )
  (global.set $ready320
   (i32.const 1)
  )
  (global.set $global261
   (struct.new_default $type60)
  )
  (global.set $ready261
   (i32.const 1)
  )
  (global.set $global262
   (struct.new_default $type61)
  )
  (global.set $ready262
   (i32.const 1)
  )
  (global.set $global266
   (struct.new_default $type62)
  )
  (global.set $ready266
   (i32.const 1)
  )
  (global.set $global312
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $ready312
   (i32.const 1)
  )
  (global.set $global313
   (call $foreign2
    (i32.const 1)
   )
  )
  (global.set $ready313
   (i32.const 1)
  )
  (global.set $global314
   (call $foreign2
    (i32.const 2)
   )
  )
  (global.set $ready314
   (i32.const 1)
  )
  (global.set $global315
   (struct.new $type42
    (ref.func $function100)
    (ref.null none)
   )
  )
  (global.set $ready315
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
 (global $bv_array_type15_elements (mut i64) (i64.const 0))
 (export "__diag_array_type15_elements" (global $bv_array_type15_elements))
 (global $bv_array_type15_requests (mut i64) (i64.const 0))
 (export "__diag_array_type15_requests" (global $bv_array_type15_requests))
 (global $bv_array_type16_elements (mut i64) (i64.const 0))
 (export "__diag_array_type16_elements" (global $bv_array_type16_elements))
 (global $bv_array_type16_requests (mut i64) (i64.const 0))
 (export "__diag_array_type16_requests" (global $bv_array_type16_requests))
 (global $bv_array_type29_elements (mut i64) (i64.const 0))
 (export "__diag_array_type29_elements" (global $bv_array_type29_elements))
 (global $bv_array_type29_requests (mut i64) (i64.const 0))
 (export "__diag_array_type29_requests" (global $bv_array_type29_requests))
 (global $bv_f101_entries (mut i64) (i64.const 0))
 (export "__diag_f101_entries" (global $bv_f101_entries))
 (global $bv_f101_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f101_index_or_byte_narrowings" (global $bv_f101_index_or_byte_narrowings))
 (global $bv_f101_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f101_ordered_i64_predicates" (global $bv_f101_ordered_i64_predicates))
 (global $bv_f101_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f101_zero_predicates" (global $bv_f101_zero_predicates))
 (global $bv_f40_entries (mut i64) (i64.const 0))
 (export "__diag_f40_entries" (global $bv_f40_entries))
 (global $bv_f40_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f40_index_or_byte_narrowings" (global $bv_f40_index_or_byte_narrowings))
 (global $bv_f40_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f40_ordered_i64_predicates" (global $bv_f40_ordered_i64_predicates))
 (global $bv_f40_scalar_reads (mut i64) (i64.const 0))
 (export "__diag_f40_scalar_reads" (global $bv_f40_scalar_reads))
 (global $bv_f40_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f40_zero_predicates" (global $bv_f40_zero_predicates))
 (global $bv_f57_entries (mut i64) (i64.const 0))
 (export "__diag_f57_entries" (global $bv_f57_entries))
 (global $bv_f57_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f57_index_or_byte_narrowings" (global $bv_f57_index_or_byte_narrowings))
 (global $bv_f57_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f57_ordered_i64_predicates" (global $bv_f57_ordered_i64_predicates))
 (global $bv_f57_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f57_zero_predicates" (global $bv_f57_zero_predicates))
 (global $bv_f59_entries (mut i64) (i64.const 0))
 (export "__diag_f59_entries" (global $bv_f59_entries))
 (global $bv_f59_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f59_index_or_byte_narrowings" (global $bv_f59_index_or_byte_narrowings))
 (global $bv_f59_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f59_ordered_i64_predicates" (global $bv_f59_ordered_i64_predicates))
 (global $bv_f59_packed_reads (mut i64) (i64.const 0))
 (export "__diag_f59_packed_reads" (global $bv_f59_packed_reads))
 (global $bv_f59_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f59_zero_predicates" (global $bv_f59_zero_predicates))
 (global $bv_f67_entries (mut i64) (i64.const 0))
 (export "__diag_f67_entries" (global $bv_f67_entries))
 (global $bv_f67_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f67_index_or_byte_narrowings" (global $bv_f67_index_or_byte_narrowings))
 (global $bv_f67_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f67_ordered_i64_predicates" (global $bv_f67_ordered_i64_predicates))
 (global $bv_f67_packed_reads (mut i64) (i64.const 0))
 (export "__diag_f67_packed_reads" (global $bv_f67_packed_reads))
 (global $bv_f67_scalar_writes (mut i64) (i64.const 0))
 (export "__diag_f67_scalar_writes" (global $bv_f67_scalar_writes))
 (global $bv_f67_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f67_zero_predicates" (global $bv_f67_zero_predicates))
 (global $bv_f74_entries (mut i64) (i64.const 0))
 (export "__diag_f74_entries" (global $bv_f74_entries))
 (global $bv_f74_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f74_index_or_byte_narrowings" (global $bv_f74_index_or_byte_narrowings))
 (global $bv_f74_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f74_ordered_i64_predicates" (global $bv_f74_ordered_i64_predicates))
 (global $bv_f74_scalar_reads (mut i64) (i64.const 0))
 (export "__diag_f74_scalar_reads" (global $bv_f74_scalar_reads))
 (global $bv_f74_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f74_zero_predicates" (global $bv_f74_zero_predicates))
 (global $bv_f77_entries (mut i64) (i64.const 0))
 (export "__diag_f77_entries" (global $bv_f77_entries))
 (global $bv_f77_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f77_index_or_byte_narrowings" (global $bv_f77_index_or_byte_narrowings))
 (global $bv_f77_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f77_ordered_i64_predicates" (global $bv_f77_ordered_i64_predicates))
 (global $bv_f77_scalar_reads (mut i64) (i64.const 0))
 (export "__diag_f77_scalar_reads" (global $bv_f77_scalar_reads))
 (global $bv_f77_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f77_zero_predicates" (global $bv_f77_zero_predicates))
 (global $bv_f79_entries (mut i64) (i64.const 0))
 (export "__diag_f79_entries" (global $bv_f79_entries))
 (global $bv_f79_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f79_index_or_byte_narrowings" (global $bv_f79_index_or_byte_narrowings))
 (global $bv_f79_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f79_ordered_i64_predicates" (global $bv_f79_ordered_i64_predicates))
 (global $bv_f79_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f79_zero_predicates" (global $bv_f79_zero_predicates))
 (global $bv_f89_capture_gets (mut i64) (i64.const 0))
 (export "__diag_f89_capture_gets" (global $bv_f89_capture_gets))
 (global $bv_f89_cell_gets (mut i64) (i64.const 0))
 (export "__diag_f89_cell_gets" (global $bv_f89_cell_gets))
 (global $bv_f89_entries (mut i64) (i64.const 0))
 (export "__diag_f89_entries" (global $bv_f89_entries))
 (global $bv_f89_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f89_ordered_i64_predicates" (global $bv_f89_ordered_i64_predicates))
 (global $bv_f89_signed_divisions (mut i64) (i64.const 0))
 (export "__diag_f89_signed_divisions" (global $bv_f89_signed_divisions))
 (global $bv_f89_signed_remainders (mut i64) (i64.const 0))
 (export "__diag_f89_signed_remainders" (global $bv_f89_signed_remainders))
 (global $bv_f89_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f89_zero_predicates" (global $bv_f89_zero_predicates))
 (global $bv_f93_entries (mut i64) (i64.const 0))
 (export "__diag_f93_entries" (global $bv_f93_entries))
 (global $bv_f93_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f93_index_or_byte_narrowings" (global $bv_f93_index_or_byte_narrowings))
 (global $bv_f93_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f93_ordered_i64_predicates" (global $bv_f93_ordered_i64_predicates))
 (global $bv_f93_packed_writes (mut i64) (i64.const 0))
 (export "__diag_f93_packed_writes" (global $bv_f93_packed_writes))
 (global $bv_f93_rng_closure_calls (mut i64) (i64.const 0))
 (export "__diag_f93_rng_closure_calls" (global $bv_f93_rng_closure_calls))
 (global $bv_f93_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f93_zero_predicates" (global $bv_f93_zero_predicates))
 (global $bv_f99_entries (mut i64) (i64.const 0))
 (export "__diag_f99_entries" (global $bv_f99_entries))
 (global $bv_f99_index_or_byte_narrowings (mut i64) (i64.const 0))
 (export "__diag_f99_index_or_byte_narrowings" (global $bv_f99_index_or_byte_narrowings))
 (global $bv_f99_ordered_i64_predicates (mut i64) (i64.const 0))
 (export "__diag_f99_ordered_i64_predicates" (global $bv_f99_ordered_i64_predicates))
 (global $bv_f99_rng_closure_calls (mut i64) (i64.const 0))
 (export "__diag_f99_rng_closure_calls" (global $bv_f99_rng_closure_calls))
 (global $bv_f99_zero_predicates (mut i64) (i64.const 0))
 (export "__diag_f99_zero_predicates" (global $bv_f99_zero_predicates))
)

