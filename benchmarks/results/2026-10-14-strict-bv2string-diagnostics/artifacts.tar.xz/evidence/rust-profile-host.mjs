import inspector from 'node:inspector';
const diagnosticsSession = new inspector.Session();
diagnosticsSession.connect();
const diagnosticsMarkers = {clock_domain: 'process.hrtime.bigint nanoseconds', sampling_interval_us: 100};
const profiler = (method, parameters = {}) => new Promise((resolve, reject) => {
  diagnosticsSession.post(method, parameters, (error, value) => error ? reject(error) : resolve(value));
});
import fs from 'node:fs';
import { readFile } from 'node:fs/promises';
import { WASI } from 'node:wasi';

// ---- Standalone WASI command ----

const [filename, ...args] = process.argv.slice(2);
if (!filename) throw new Error('usage: run-wasi.mjs MODULE.wasm [ARGUMENT ...]');
const wasi = new WASI({
  version: 'preview1',
  args: [filename, ...args],
  env: process.env,
  preopens: { '/': process.cwd() },
  returnOnExit: true,
});
const module = await WebAssembly.compile(await readFile(filename));
const instance = await WebAssembly.instantiate(module, wasi.getImportObject());
await profiler('Profiler.enable');
await profiler('Profiler.setSamplingInterval', {interval: 100});
diagnosticsMarkers.start_submission_ns = process.hrtime.bigint().toString();
await profiler('Profiler.start');
diagnosticsMarkers.start_acknowledgement_ns = process.hrtime.bigint().toString();
const start = process.hrtime.bigint();
process.exitCode = wasi.start(instance);
const diagnosticsClockStop = process.hrtime.bigint();
const seconds = Number(diagnosticsClockStop - start) / 1e9;
diagnosticsMarkers.clock_start_ns = start.toString();
diagnosticsMarkers.clock_stop_ns = diagnosticsClockStop.toString();
diagnosticsMarkers.stop_submission_ns = process.hrtime.bigint().toString();
const diagnosticsProfile = (await profiler('Profiler.stop')).profile;
diagnosticsMarkers.stop_completion_ns = process.hrtime.bigint().toString();
diagnosticsSession.disconnect();
fs.writeFileSync(new URL('./rust-profile/profile.cpuprofile', import.meta.url), JSON.stringify(diagnosticsProfile));
fs.writeFileSync(new URL('./rust-profile/profile-window.json', import.meta.url), JSON.stringify(diagnosticsMarkers));
