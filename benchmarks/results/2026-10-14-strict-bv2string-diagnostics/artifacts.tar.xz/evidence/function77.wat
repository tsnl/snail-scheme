(func $function77 (type $15) (param $0 (ref $type28)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (local $scratch i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (if (result i64)
      (i64.lt_u
       (local.tee $7
        (local.tee $8
         (i64.extend_i32_u
          (block (result i32)
           (local.set $scratch
            (array.get $type15
             (if (result (ref $type15))
              (i32.lt_u
               (local.tee $9
                (i32.wrap_i64
                 (local.get $5)
                )
               )
               (i32.const 8192)
              )
              (then
               (struct.get $type14 2
                (local.get $1)
               )
              )
              (else
               (ref.as_non_null
                (array.get $type16
                 (struct.get $type14 3
                  (local.get $1)
                 )
                 (i32.sub
                  (i32.shr_u
                   (local.get $9)
                   (i32.const 13)
                  )
                  (i32.const 1)
                 )
                )
               )
              )
             )
             (i32.and
              (local.get $9)
              (i32.const 8191)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready229)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (struct.get $type42 1
             (global.get $global229)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
       (i64.const 128)
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (i64.lt_u
         (local.get $7)
         (i64.const 2048)
        )
        (then
         (i64.const 2)
        )
        (else
         (select
          (i64.const 3)
          (i64.const 4)
          (i64.lt_u
           (local.get $7)
           (i64.const 65536)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready209)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global209)
     )
    )
    (drop
     (call $function71
      (local.get $0)
      (local.get $6)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (local.get $7)
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (i64.add
      (local.get $6)
      (local.get $7)
     )
    )
   )
  )
 )
