(func $function89 (type $call42) (param $0 (ref null $environment89)) (param $1 i64) (result i64)
  (local $2 (ref $type66))
  (local $3 (ref $type65))
  (local $4 (ref $type64))
  (local $5 (ref $type64))
  (local $6 (ref $type64))
  (local $7 (ref $type63))
  (local $8 (ref $type63))
  (local $9 i64)
  (local $10 i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 16384)
   )
   (then
    (drop
     (struct.get $environment89 0
      (local.get $0)
     )
    )
    (struct.set $type66 0
     (local.tee $2
      (struct.get $type65 0
       (local.tee $3
        (struct.get $environment89 1
         (local.get $0)
        )
       )
      )
     )
     (i64.rem_s
      (i64.add
       (i64.mul
        (struct.get $type64 0
         (struct.get $environment89 2
          (local.get $0)
         )
        )
        (struct.get $type66 0
         (local.get $2)
        )
       )
       (struct.get $type64 0
        (struct.get $environment89 3
         (local.get $0)
        )
       )
      )
      (i64.add
       (struct.get $type64 0
        (struct.get $environment89 4
         (local.get $0)
        )
       )
       (i64.const 1)
      )
     )
    )
    (i64.rem_s
     (i64.div_s
      (struct.get $type66 0
       (struct.get $type65 0
        (local.get $3)
       )
      )
      (i64.const 8)
     )
     (local.get $1)
    )
   )
   (else
    (local.set $7
     (struct.get $environment89 0
      (local.get $0)
     )
    )
    (struct.set $type66 0
     (local.tee $2
      (struct.get $type65 0
       (local.tee $3
        (struct.get $environment89 1
         (local.get $0)
        )
       )
      )
     )
     (i64.rem_s
      (i64.add
       (i64.mul
        (struct.get $type64 0
         (local.tee $4
          (struct.get $environment89 2
           (local.get $0)
          )
         )
        )
        (struct.get $type66 0
         (local.get $2)
        )
       )
       (struct.get $type64 0
        (local.tee $5
         (struct.get $environment89 3
          (local.get $0)
         )
        )
       )
      )
      (i64.add
       (struct.get $type64 0
        (local.tee $6
         (struct.get $environment89 4
          (local.get $0)
         )
        )
       )
       (i64.const 1)
      )
     )
    )
    (local.set $8
     (struct.get $environment89 5
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready281)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (i64.rem_s
      (i64.div_s
       (struct.get $type66 0
        (struct.get $type65 0
         (local.get $3)
        )
       )
       (i64.const 8)
      )
      (i64.const 16384)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global281)
     )
    )
    (if (result i64)
     (i64.eqz
      (local.tee $10
       (i64.div_s
        (local.get $1)
        (i64.const 16384)
       )
      )
     )
     (then
      (i64.rem_s
       (local.get $9)
       (local.get $1)
      )
     )
     (else
      (struct.set $type66 0
       (local.tee $2
        (struct.get $type65 0
         (local.get $3)
        )
       )
       (i64.rem_s
        (i64.add
         (i64.mul
          (struct.get $type64 0
           (local.get $4)
          )
          (struct.get $type66 0
           (local.get $2)
          )
         )
         (struct.get $type64 0
          (local.get $5)
         )
        )
        (i64.add
         (struct.get $type64 0
          (local.get $6)
         )
         (i64.const 1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready281)
       )
       (then
        (unreachable)
       )
      )
      (local.set $9
       (i64.add
        (i64.rem_s
         (i64.div_s
          (struct.get $type66 0
           (local.get $2)
          )
          (i64.const 8)
         )
         (i64.const 16384)
        )
        (i64.shl
         (local.get $9)
         (i64.const 14)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if (result i64)
       (i64.eqz
        (local.tee $10
         (i64.div_s
          (local.get $10)
          (i64.const 16384)
         )
        )
       )
       (then
        (i64.rem_s
         (local.get $9)
         (local.get $1)
        )
       )
       (else
        (struct.set $type66 0
         (local.tee $2
          (struct.get $type65 0
           (local.get $3)
          )
         )
         (i64.rem_s
          (i64.add
           (i64.mul
            (struct.get $type64 0
             (local.get $4)
            )
            (struct.get $type66 0
             (local.get $2)
            )
           )
           (struct.get $type64 0
            (local.get $5)
           )
          )
          (i64.add
           (struct.get $type64 0
            (local.get $6)
           )
           (i64.const 1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready281)
         )
         (then
          (unreachable)
         )
        )
        (local.set $9
         (i64.add
          (i64.rem_s
           (i64.div_s
            (struct.get $type66 0
             (local.get $2)
            )
            (i64.const 8)
           )
           (i64.const 16384)
          )
          (i64.shl
           (local.get $9)
           (i64.const 14)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global281)
         )
        )
        (if (result i64)
         (i64.eqz
          (local.tee $10
           (i64.div_s
            (local.get $10)
            (i64.const 16384)
           )
          )
         )
         (then
          (i64.rem_s
           (local.get $9)
           (local.get $1)
          )
         )
         (else
          (struct.set $type66 0
           (local.tee $2
            (struct.get $type65 0
             (local.get $3)
            )
           )
           (i64.rem_s
            (i64.add
             (i64.mul
              (struct.get $type64 0
               (local.get $4)
              )
              (struct.get $type66 0
               (local.get $2)
              )
             )
             (struct.get $type64 0
              (local.get $5)
             )
            )
            (i64.add
             (struct.get $type64 0
              (local.get $6)
             )
             (i64.const 1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready281)
           )
           (then
            (unreachable)
           )
          )
          (local.set $9
           (i64.add
            (i64.rem_s
             (i64.div_s
              (struct.get $type66 0
               (local.get $2)
              )
              (i64.const 8)
             )
             (i64.const 16384)
            )
            (i64.shl
             (local.get $9)
             (i64.const 14)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global281)
           )
          )
          (if (result i64)
           (i64.eqz
            (local.tee $10
             (i64.div_s
              (local.get $10)
              (i64.const 16384)
             )
            )
           )
           (then
            (i64.rem_s
             (local.get $9)
             (local.get $1)
            )
           )
           (else
            (struct.set $type66 0
             (local.tee $2
              (struct.get $type65 0
               (local.get $3)
              )
             )
             (i64.rem_s
              (i64.add
               (i64.mul
                (struct.get $type64 0
                 (local.get $4)
                )
                (struct.get $type66 0
                 (local.get $2)
                )
               )
               (struct.get $type64 0
                (local.get $5)
               )
              )
              (i64.add
               (struct.get $type64 0
                (local.get $6)
               )
               (i64.const 1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready281)
             )
             (then
              (unreachable)
             )
            )
            (local.set $9
             (i64.add
              (i64.rem_s
               (i64.div_s
                (struct.get $type66 0
                 (local.get $2)
                )
                (i64.const 8)
               )
               (i64.const 16384)
              )
              (i64.shl
               (local.get $9)
               (i64.const 14)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global281)
             )
            )
            (if (result i64)
             (i64.eqz
              (local.tee $10
               (i64.div_s
                (local.get $10)
                (i64.const 16384)
               )
              )
             )
             (then
              (i64.rem_s
               (local.get $9)
               (local.get $1)
              )
             )
             (else
              (struct.set $type66 0
               (local.tee $2
                (struct.get $type65 0
                 (local.get $3)
                )
               )
               (i64.rem_s
                (i64.add
                 (i64.mul
                  (struct.get $type64 0
                   (local.get $4)
                  )
                  (struct.get $type66 0
                   (local.get $2)
                  )
                 )
                 (struct.get $type64 0
                  (local.get $5)
                 )
                )
                (i64.add
                 (struct.get $type64 0
                  (local.get $6)
                 )
                 (i64.const 1)
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready281)
               )
               (then
                (unreachable)
               )
              )
              (local.set $9
               (i64.add
                (i64.rem_s
                 (i64.div_s
                  (struct.get $type66 0
                   (local.get $2)
                  )
                  (i64.const 8)
                 )
                 (i64.const 16384)
                )
                (i64.shl
                 (local.get $9)
                 (i64.const 14)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global281)
               )
              )
              (if (result i64)
               (i64.eqz
                (local.tee $10
                 (i64.div_s
                  (local.get $10)
                  (i64.const 16384)
                 )
                )
               )
               (then
                (i64.rem_s
                 (local.get $9)
                 (local.get $1)
                )
               )
               (else
                (struct.set $type66 0
                 (local.tee $2
                  (struct.get $type65 0
                   (local.get $3)
                  )
                 )
                 (i64.rem_s
                  (i64.add
                   (i64.mul
                    (struct.get $type64 0
                     (local.get $4)
                    )
                    (struct.get $type66 0
                     (local.get $2)
                    )
                   )
                   (struct.get $type64 0
                    (local.get $5)
                   )
                  )
                  (i64.add
                   (struct.get $type64 0
                    (local.get $6)
                   )
                   (i64.const 1)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready281)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $9
                 (i64.add
                  (i64.rem_s
                   (i64.div_s
                    (struct.get $type66 0
                     (local.get $2)
                    )
                    (i64.const 8)
                   )
                   (i64.const 16384)
                  )
                  (i64.shl
                   (local.get $9)
                   (i64.const 14)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global281)
                 )
                )
                (if (result i64)
                 (i64.eqz
                  (local.tee $10
                   (i64.div_s
                    (local.get $10)
                    (i64.const 16384)
                   )
                  )
                 )
                 (then
                  (i64.rem_s
                   (local.get $9)
                   (local.get $1)
                  )
                 )
                 (else
                  (struct.set $type66 0
                   (local.tee $2
                    (struct.get $type65 0
                     (local.get $3)
                    )
                   )
                   (i64.rem_s
                    (i64.add
                     (i64.mul
                      (struct.get $type64 0
                       (local.get $4)
                      )
                      (struct.get $type66 0
                       (local.get $2)
                      )
                     )
                     (struct.get $type64 0
                      (local.get $5)
                     )
                    )
                    (i64.add
                     (struct.get $type64 0
                      (local.get $6)
                     )
                     (i64.const 1)
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready281)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $9
                   (i64.add
                    (i64.rem_s
                     (i64.div_s
                      (struct.get $type66 0
                       (local.get $2)
                      )
                      (i64.const 8)
                     )
                     (i64.const 16384)
                    )
                    (i64.shl
                     (local.get $9)
                     (i64.const 14)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global281)
                   )
                  )
                  (if (result i64)
                   (i64.eqz
                    (local.tee $10
                     (i64.div_s
                      (local.get $10)
                      (i64.const 16384)
                     )
                    )
                   )
                   (then
                    (i64.rem_s
                     (local.get $9)
                     (local.get $1)
                    )
                   )
                   (else
                    (struct.set $type66 0
                     (local.tee $2
                      (struct.get $type65 0
                       (local.get $3)
                      )
                     )
                     (i64.rem_s
                      (i64.add
                       (i64.mul
                        (struct.get $type64 0
                         (local.get $4)
                        )
                        (struct.get $type66 0
                         (local.get $2)
                        )
                       )
                       (struct.get $type64 0
                        (local.get $5)
                       )
                      )
                      (i64.add
                       (struct.get $type64 0
                        (local.get $6)
                       )
                       (i64.const 1)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready281)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $9
                     (i64.add
                      (i64.rem_s
                       (i64.div_s
                        (struct.get $type66 0
                         (local.get $2)
                        )
                        (i64.const 8)
                       )
                       (i64.const 16384)
                      )
                      (i64.shl
                       (local.get $9)
                       (i64.const 14)
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global281)
                     )
                    )
                    (if (result i64)
                     (i64.eqz
                      (local.tee $10
                       (i64.div_s
                        (local.get $10)
                        (i64.const 16384)
                       )
                      )
                     )
                     (then
                      (i64.rem_s
                       (local.get $9)
                       (local.get $1)
                      )
                     )
                     (else
                      (local.set $10
                       (i64.div_s
                        (local.get $10)
                        (i64.const 16384)
                       )
                      )
                      (struct.set $type66 0
                       (local.tee $2
                        (struct.get $type65 0
                         (local.get $3)
                        )
                       )
                       (i64.rem_s
                        (i64.add
                         (i64.mul
                          (struct.get $type64 0
                           (local.get $4)
                          )
                          (struct.get $type66 0
                           (local.get $2)
                          )
                         )
                         (struct.get $type64 0
                          (local.get $5)
                         )
                        )
                        (i64.add
                         (struct.get $type64 0
                          (local.get $6)
                         )
                         (i64.const 1)
                        )
                       )
                      )
                      (local.set $9
                       (i64.add
                        (i64.rem_s
                         (i64.div_s
                          (struct.get $type66 0
                           (local.get $2)
                          )
                          (i64.const 8)
                         )
                         (i64.const 16384)
                        )
                        (i64.shl
                         (local.get $9)
                         (i64.const 14)
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready281)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global281)
                       )
                      )
                      (if (result i64)
                       (i64.eqz
                        (local.get $10)
                       )
                       (then
                        (i64.rem_s
                         (local.get $9)
                         (local.get $1)
                        )
                       )
                       (else
                        (return_call $function90
                         (local.get $7)
                         (local.get $3)
                         (local.get $4)
                         (local.get $5)
                         (local.get $6)
                         (local.get $8)
                         (i64.div_s
                          (local.get $10)
                          (i64.const 16384)
                         )
                         (i64.add
                          (call $function88
                           (local.get $3)
                           (local.get $4)
                           (local.get $5)
                           (local.get $6)
                          )
                          (i64.shl
                           (local.get $9)
                           (i64.const 14)
                          )
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
