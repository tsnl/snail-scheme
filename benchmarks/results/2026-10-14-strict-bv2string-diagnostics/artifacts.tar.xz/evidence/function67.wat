(func $function67 (type $17) (param $0 (ref $type14)) (param $1 (ref $type28)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (local $10 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready177)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global182)
     )
    )
    (if
     (i64.gt_s
      (local.tee $7
       (if (result i64)
        (i64.lt_u
         (local.get $7)
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $7)
            (i64.const 224)
           )
           (i64.ge_u
            (local.get $7)
            (i64.const 194)
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $7)
              (i64.const 240)
             )
             (i64.ge_u
              (local.get $7)
              (i64.const 224)
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (i64.lt_u
                (local.get $7)
                (i64.const 245)
               )
               (i64.ge_u
                (local.get $7)
                (i64.const 240)
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready184)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (local.set $10
     (call $function64
      (local.get $1)
      (local.get $5)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (local.get $8)
       (if (result i64)
        (i64.eq
         (local.get $7)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $7)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $7)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $9
        (i32.wrap_i64
         (local.get $6)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $9)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $9)
      (i32.const 8191)
     )
     (local.get $10)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (local.get $7)
     )
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
