"""Build and check this manual ablation; record correctness runs, never clean timings."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
from enumeration_ports import check_graphs

# ---- Commands with retained successes and failures ----


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def run(label, command):
    start = time.monotonic()
    result = subprocess.run([str(arg) for arg in command], cwd=ROOT, text=True, capture_output=True)
    record = dict(command=[str(arg) for arg in command], cwd=str(ROOT), returncode=result.returncode,
                  stdout=result.stdout, stderr=result.stderr, process_seconds=time.monotonic() - start,
                  purpose='correctness/preparation only; unsuitable for performance comparisons')
    write_json(HERE / 'commands' / (label + '.json'), record)
    print(label, 'passed' if result.returncode == 0 else 'FAILED', flush=True)
    if result.returncode:
        raise RuntimeError(f'{label} failed; see retained command record')
    return result.stdout


def verify_frozen_inputs():
    for item in json.loads((HERE / 'input-provenance.json').read_text()):
        actual = hashlib.sha256((HERE / item['path']).read_bytes()).hexdigest()
        if actual != item['sha256']:
            raise ValueError('frozen input changed: ' + item['path'])


def verify_oracles():
    cases = json.loads((HERE / 'oracles.json').read_text())
    checked = {f'values-{size}': check_graphs(cases[f'values-{size}']['expected'], size)
               for size in range(1, 5)}
    write_json(HERE / 'oracle-validation.json', checked)

# ---- Frozen compiler and target execution ----


def build(label, source, output, export):
    run('build-' + label, [ROOT / 'scripts/build-strict', '--export', export, HERE / source, HERE / output])


def source_map(label, source):
    output = run('map-' + label, [shutil.which('chibi-scheme'), '-I', ROOT / 'src',
                               HERE / 'function-map.scm', ROOT, HERE / source,
                               HERE / label / 'map.trace.json'])
    (HERE / label / 'function-map.scm').write_text(output)


def validate_module(label, artifact, specification):
    run(label, [shutil.which('node'), HERE / 'host.mjs', HERE / artifact, HERE / specification, '--validate'])


def check_small_graphs():
    for variant in ('baseline', 'variant'):
        for suffix in ('.raw.wasm', ''):
            for size in range(1, 5):
                label = f'small-{variant}-{size}-' + ('raw' if suffix else 'optimized')
                validate_module(label, f'probe/{variant}.wasm{suffix}', f'probe/spec-values-{size}.json')


def check_matrix_contracts():
    build('contracts', 'contracts.scm', 'contracts.wasm', 'contract-probe')
    for suffix in ('.raw.wasm', ''):
        for size in (0, 1, 3):
            label = f'contract-{size}-' + ('raw' if suffix else 'optimized')
            validate_module(label, 'contracts.wasm' + suffix, f'contracts-{size}.json')


def main():
    if sys.argv[1:] not in ([], ['--reuse-builds'], ['--contracts-only']):
        raise ValueError('supported options: --reuse-builds, --contracts-only')
    verify_frozen_inputs()
    if '--contracts-only' in sys.argv:
        check_matrix_contracts()
        return
    verify_oracles()
    if '--reuse-builds' not in sys.argv:
        build('variant', 'variant/strict.scm', 'variant/strict.wasm', 'bench')
        build('probe-baseline', 'probe/baseline.scm', 'probe/baseline.wasm', 'enumeration-probe')
        build('probe-variant', 'probe/strict.scm', 'probe/variant.wasm', 'enumeration-probe')
    source_map('baseline', 'baseline/strict.scm')
    source_map('variant', 'variant/strict.scm')
    run('disassemble-variant', [shutil.which('wasm-dis'), HERE / 'variant/strict.wasm',
                             '-o', HERE / 'variant/strict.optimized.wat'])
    check_small_graphs()
    validate_module('full-variant-raw', 'variant/strict.wasm.raw.wasm', 'spec.json')
    validate_module('full-variant-optimized', 'variant/strict.wasm', 'spec.json')
    validate_module('full-baseline-optimized', 'baseline/strict.wasm', 'spec.json')
    check_matrix_contracts()


if __name__ == '__main__':
    main()
