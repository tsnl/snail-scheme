(module
 (rec
  (type $0 (func (param i32 i32 (ref null $type24) i64) (result i64)))
  (type $type53 (struct))
  (type $2 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $3 (func (param i64 i64 (ref $type53) i64 (ref $type14) (ref $type18) (ref $type50) (ref $type25) (ref $type8) i32 i32 i64 (ref $type13) i32 i32 i64 i64 (ref null $type24)) (result (ref null $type24))))
  (type $4 (func (param i64 (ref $type25) i32 i32 i64) (result i32)))
  (type $5 (func (param (ref $type41) i32 i32 (ref null $type12)) (result i32)))
  (type $environment78 (struct (field i64)))
  (type $type41 (struct (field (ref $environment78))))
  (type $type8 (struct (field (ref $call8)) (field (ref $environment73))))
  (type $environment77 (struct (field (ref null $type12))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $11 (func (param i64 i64 (ref $type53) i64 (ref $type18) (ref $type8) (ref $type14) (ref $type13) i32 i32 i64 i64 (ref null $type17) (ref null $type12) (ref null $type24)) (result (ref null $type24))))
  (type $type24 (struct (field (ref null $type24))))
  (type $13 (func (param i64 i64 (ref $type53) i64 (ref $type14) (ref $type18) (ref $type50) (ref $type25) (ref $type8) i32 i32 i64 (ref null $type24)) (result (ref null $type24))))
  (type $environment74 (struct (field i64) (field (ref $type14))))
  (type $environment73 (struct (field i64) (field (ref $type14)) (field (ref $type48)) (field (ref $type49))))
  (type $call8 (func (param (ref $environment73)) (result i32)))
  (type $type48 (struct (field (ref $environment50))))
  (type $environment71 (struct (field (ref $type14)) (field (ref $type48)) (field (ref $type49))))
  (type $19 (func (param i64 (ref $type28) i32 i32 i64) (result i32)))
  (type $environment66 (struct (field (ref $type13)) (field (ref $type13))))
  (type $environment65 (struct (field i64) (field (ref $type14)) (field i64) (field (ref $type13))))
  (type $environment64 (struct (field i64) (field (ref $type14))))
  (type $call33 (func (param i64 (ref $type18)) (result (ref $type14))))
  (type $24 (func (param (ref $type35) i32 i32 (ref null $type17) (ref $type17)) (result (ref null $type17))))
  (type $environment59 (struct (field (ref $type43)) (field (ref $type46)) (field (ref $type56)) (field i64) (field (ref $type45)) (field (ref $type56)) (field (ref null $type17)) (field i64) (field (ref null $type17))))
  (type $call49 (func (param (ref null $environment74) (ref $type50) (ref $type45)) (result i32)))
  (type $type49 (struct (field (ref $call49)) (field (ref null $environment74))))
  (type $28 (func (param (ref $type43) (ref $type46) (ref $type56) (ref null $type17) i64 i32 (ref $type45)) (result i32)))
  (type $29 (func (param (ref $type14) (ref $type50) i64 i64 (ref $type13) (ref $type13) i32 i32 i64) (result i64)))
  (type $call45 (func (param (ref null $environment59) i32) (result i32)))
  (type $type35 (struct))
  (type $type44 (struct (field (ref $environment60))))
  (type $environment60 (struct (field (ref $type43)) (field (ref $type46)) (field (ref $type56)) (field (ref null $type17)) (field (ref null $type17)) (field (ref $type45))))
  (type $call43 (func (param (ref $environment51) i64 i64 i32 (ref $type44) (ref $type45)) (result i32)))
  (type $type45 (struct (field (ref $call45)) (field (ref null $environment59))))
  (type $environment54 (struct (field (ref $type50)) (field (ref $type49))))
  (type $environment50 (struct (field (ref $type18)) (field (ref $type50))))
  (type $environment51 (struct (field (ref $type50)) (field (ref $type14))))
  (type $type56 (struct (field i32)))
  (type $type46 (struct (field (ref $environment54))))
  (type $type43 (struct (field (ref $environment51))))
  (type $type50 (array (mut i64)))
  (type $call48 (func (param (ref $environment50) i64 (ref $type14) (ref $type49)) (result i32)))
  (type $44 (func (param i64 (ref $type37) (ref $type18) i32 i32 i64) (result i32)))
  (type $environment83 (struct (field (ref $type18))))
  (type $46 (func (param i64 (ref $type37)) (result (ref $type18))))
  (type $47 (func (param i32 i32 i64 (ref $type17)) (result (ref null $type17))))
  (type $call37 (func (param (ref null $environment83) i64) (result (ref null $type17))))
  (type $49 (func (param i64 (ref $type18) (ref $type14) i32 i32 i64) (result i32)))
  (type $50 (func (param i64 (ref $type14) i32 i32 i64) (result i32)))
  (type $call25 (func (param structref i64) (result i32)))
  (type $type14 (array (mut (ref $type13))))
  (type $53 (func (param i64) (result (ref $type14))))
  (type $call27 (func (param (ref $type28) (ref null $type17)) (result i32)))
  (type $call28 (func (param (ref struct) i64) (result i32)))
  (type $environment28 (struct (field (ref $type13))))
  (type $type18 (array (mut (ref null $type17))))
  (type $type28 (struct (field (ref $call28)) (field (ref struct))))
  (type $type17 (struct (field i64) (field (ref null $type17))))
  (type $60 (func (param i64 (ref $type18) i64) (result (ref $type13))))
  (type $type13 (array (mut i32)))
  (type $call30 (func (param i64) (result (ref $type13))))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type47 (struct))
  (type $type42 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct (field (ref $call37)) (field (ref null $environment83))))
  (type $type36 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (ref $call25)) (field structref)))
  (type $type23 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type15 (struct))
  (type $type11 (struct))
 )
 (type $88 (func (param i64) (result i64)))
 (type $89 (func (param i32) (result i64)))
 (type $90 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global80 (mut (ref null $type11)) (ref.null none))
 (global $ready80 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type15)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type19)) (ref.null none))
 (global $ready82 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type20)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global274 (mut (ref null $type23)) (ref.null none))
 (global $ready274 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type25)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type26)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global73 (mut (ref null $type27)) (ref.null none))
 (global $ready73 (mut i32) (i32.const 0))
 (global $global271 (mut (ref null $type29)) (ref.null none))
 (global $ready271 (mut i32) (i32.const 0))
 (global $global64 (mut (ref null $type30)) (ref.null none))
 (global $ready64 (mut i32) (i32.const 0))
 (global $global67 (mut (ref null $type31)) (ref.null none))
 (global $ready67 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type32)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global96 (mut (ref null $type33)) (ref.null none))
 (global $ready96 (mut i32) (i32.const 0))
 (global $global178 (mut (ref null $type34)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type36)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global105 (mut (ref null $type37)) (ref.null none))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global194 (mut (ref null $type38)) (ref.null none))
 (global $ready194 (mut i32) (i32.const 0))
 (global $global245 (mut (ref null $type39)) (ref.null none))
 (global $ready245 (mut i32) (i32.const 0))
 (global $global239 (mut (ref null $type40)) (ref.null none))
 (global $ready239 (mut i32) (i32.const 0))
 (global $global156 (mut (ref null $type42)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (global $global102 (mut (ref null $type47)) (ref.null none))
 (global $ready102 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type51)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global201 (mut (ref null $type52)) (ref.null none))
 (global $ready201 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type33)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global199 (mut (ref null $type54)) (ref.null none))
 (global $ready199 (mut i32) (i32.const 0))
 (global $global265 (mut i64) (i64.const 0))
 (global $ready265 (mut i32) (i32.const 0))
 (global $global266 (mut (ref null $type55)) (ref.null none))
 (global $ready266 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function26 (type $call30) (param $0 i64) (result (ref $type13))
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.new_default $type13
   (i32.wrap_i64
    (local.get $0)
   )
  )
 )
 (func $function27 (type $60) (param $0 i64) (param $1 (ref $type18)) (param $2 i64) (result (ref $type13))
  (local $3 (ref null $type17))
  (local $4 (ref $type28))
  (local $5 (ref $type13))
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type13
   (local.tee $5
    (array.new_default $type13
     (i32.wrap_i64
      (local.get $0)
     )
    )
   )
   (i32.wrap_i64
    (local.get $2)
   )
   (i32.const 1)
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (array.get $type18
    (local.get $1)
    (i32.wrap_i64
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready73)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global73)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.get $3)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call28
       (struct.get $type28 1
        (local.tee $4
         (struct.new $type28
          (ref.func $function28)
          (struct.new $environment28
           (local.get $5)
          )
         )
        )
       )
       (struct.get $type17 0
        (local.get $3)
       )
       (struct.get $type28 0
        (local.get $4)
       )
      )
     )
     (local.set $3
      (struct.get $type17 1
       (local.get $3)
      )
     )
     (if
      (i32.eqz
       (global.get $ready73)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global73)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $3)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call28
         (struct.get $type28 1
          (local.get $4)
         )
         (struct.get $type17 0
          (local.get $3)
         )
         (struct.get $type28 0
          (local.get $4)
         )
        )
       )
       (local.set $3
        (struct.get $type17 1
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (global.get $ready73)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global73)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $3)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call28
           (struct.get $type28 1
            (local.get $4)
           )
           (struct.get $type17 0
            (local.get $3)
           )
           (struct.get $type28 0
            (local.get $4)
           )
          )
         )
         (local.set $3
          (struct.get $type17 1
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (global.get $ready73)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global73)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call28
             (struct.get $type28 1
              (local.get $4)
             )
             (struct.get $type17 0
              (local.get $3)
             )
             (struct.get $type28 0
              (local.get $4)
             )
            )
           )
           (local.set $3
            (struct.get $type17 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (global.get $ready73)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global73)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $3)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call28
               (struct.get $type28 1
                (local.get $4)
               )
               (struct.get $type17 0
                (local.get $3)
               )
               (struct.get $type28 0
                (local.get $4)
               )
              )
             )
             (local.set $3
              (struct.get $type17 1
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (global.get $ready73)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global73)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call28
                 (struct.get $type28 1
                  (local.get $4)
                 )
                 (struct.get $type17 0
                  (local.get $3)
                 )
                 (struct.get $type28 0
                  (local.get $4)
                 )
                )
               )
               (local.set $3
                (struct.get $type17 1
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready73)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global73)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call28
                   (struct.get $type28 1
                    (local.get $4)
                   )
                   (struct.get $type17 0
                    (local.get $3)
                   )
                   (struct.get $type28 0
                    (local.get $4)
                   )
                  )
                 )
                 (local.set $3
                  (struct.get $type17 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready73)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global73)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call28
                     (struct.get $type28 1
                      (local.get $4)
                     )
                     (struct.get $type17 0
                      (local.get $3)
                     )
                     (struct.get $type28 0
                      (local.get $4)
                     )
                    )
                   )
                   (local.set $3
                    (struct.get $type17 1
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready73)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global73)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call28
                       (struct.get $type28 1
                        (local.get $4)
                       )
                       (struct.get $type17 0
                        (local.get $3)
                       )
                       (struct.get $type28 0
                        (local.get $4)
                       )
                      )
                     )
                     (local.set $3
                      (struct.get $type17 1
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready73)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global73)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (call_ref $call28
                         (struct.get $type28 1
                          (local.get $4)
                         )
                         (struct.get $type17 0
                          (local.get $3)
                         )
                         (struct.get $type28 0
                          (local.get $4)
                         )
                        )
                       )
                       (local.set $3
                        (struct.get $type17 1
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready73)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global73)
                        )
                       )
                       (call $function29
                        (local.get $4)
                        (local.get $3)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function28 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type13
   (struct.get $environment28 0
    (ref.cast (ref $environment28)
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (i32.const 0)
 )
 (func $function29 (type $call27) (param $0 (ref $type28)) (param $1 (ref null $type17)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.get $0)
      )
      (struct.get $type17 0
       (local.get $1)
      )
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type17 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready73)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global73)
     )
    )
    (return_call $function29
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function30 (type $53) (param $0 i64) (result (ref $type14))
  (local $1 (ref $type14))
  (local $2 i32)
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global78)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global80)
     )
    )
    (if
     (i32.eqz
      (global.get $ready82)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global82)
     )
    )
    (array.new_fixed $type14 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready64)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global64)
     )
    )
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (array.new $type14
      (array.new_default $type13
       (local.tee $2
        (i32.wrap_i64
         (local.get $0)
        )
       )
      )
      (local.get $2)
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.get $0)
       (i64.const 1)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready64)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global64)
        )
       )
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.set $type14
        (local.get $1)
        (i32.const 1)
        (array.new_default $type13
         (i32.wrap_i64
          (local.get $0)
         )
        )
       )
       (if (result i32)
        (i64.gt_s
         (local.get $0)
         (i64.const 2)
        )
        (then
         (if
          (i32.eqz
           (global.get $ready64)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global64)
          )
         )
         (if
          (i64.gt_u
           (local.get $0)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type14
          (local.get $1)
          (i32.const 2)
          (array.new_default $type13
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
         (if (result i32)
          (i64.gt_s
           (local.get $0)
           (i64.const 3)
          )
          (then
           (if
            (i32.eqz
             (global.get $ready64)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global64)
            )
           )
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.set $type14
            (local.get $1)
            (i32.const 3)
            (array.new_default $type13
             (i32.wrap_i64
              (local.get $0)
             )
            )
           )
           (if (result i32)
            (i64.gt_s
             (local.get $0)
             (i64.const 4)
            )
            (then
             (if
              (i32.eqz
               (global.get $ready64)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global64)
              )
             )
             (if
              (i64.gt_u
               (local.get $0)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (array.set $type14
              (local.get $1)
              (i32.const 4)
              (array.new_default $type13
               (i32.wrap_i64
                (local.get $0)
               )
              )
             )
             (if (result i32)
              (i64.gt_s
               (local.get $0)
               (i64.const 5)
              )
              (then
               (if
                (i32.eqz
                 (global.get $ready64)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global64)
                )
               )
               (if
                (i64.gt_u
                 (local.get $0)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (array.set $type14
                (local.get $1)
                (i32.const 5)
                (array.new_default $type13
                 (i32.wrap_i64
                  (local.get $0)
                 )
                )
               )
               (if (result i32)
                (i64.gt_s
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (if
                  (i32.eqz
                   (global.get $ready64)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global64)
                  )
                 )
                 (if
                  (i64.gt_u
                   (local.get $0)
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (array.set $type14
                  (local.get $1)
                  (i32.const 6)
                  (array.new_default $type13
                   (i32.wrap_i64
                    (local.get $0)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (if
                    (i32.eqz
                     (global.get $ready64)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global64)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.get $0)
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (array.set $type14
                    (local.get $1)
                    (i32.const 7)
                    (array.new_default $type13
                     (i32.wrap_i64
                      (local.get $0)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.gt_s
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready64)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global64)
                      )
                     )
                     (if
                      (i64.gt_u
                       (local.get $0)
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (array.set $type14
                      (local.get $1)
                      (i32.const 8)
                      (array.new_default $type13
                       (i32.wrap_i64
                        (local.get $0)
                       )
                      )
                     )
                     (if (result i32)
                      (i64.gt_s
                       (local.get $0)
                       (i64.const 9)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready64)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global64)
                        )
                       )
                       (if
                        (i64.gt_u
                         (local.get $0)
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (array.set $type14
                        (local.get $1)
                        (i32.const 9)
                        (array.new_default $type13
                         (i32.wrap_i64
                          (local.get $0)
                         )
                        )
                       )
                       (if (result i32)
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 10)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready64)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global64)
                          )
                         )
                         (array.set $type14
                          (local.get $1)
                          (i32.const 10)
                          (call $function26
                           (local.get $0)
                          )
                         )
                         (call $function37
                          (local.get $0)
                          (local.get $1)
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 11)
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.get $1)
   )
  )
 )
 (func $function31 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function37 (type $50) (param $0 i64) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 (ref $type13))
  (if (result i32)
   (i64.gt_s
    (local.get $0)
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready64)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global64)
     )
    )
    (local.set $5
     (call $function26
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $5)
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function37
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function39 (type $49) (param $0 i64) (param $1 (ref $type18)) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 (ref $type13))
  (if (result i32)
   (i64.gt_s
    (local.get $0)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready67)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global67)
     )
    )
    (local.set $6
     (call $function27
      (local.get $0)
      (local.get $1)
      (local.get $5)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $2)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function39
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function41 (type $call37) (param $0 (ref null $environment83)) (param $1 i64) (result (ref null $type17))
  (local $2 (ref $type17))
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global78)
   )
  )
  (if (result (ref null $type17))
   (i64.eqz
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global78)
     )
    )
    (local.set $2
     (struct.new $type17
      (local.tee $1
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (ref.null none)
     )
    )
    (if (result (ref $type17))
     (i64.eqz
      (local.get $1)
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready78)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type25 1
        (global.get $global78)
       )
      )
      (local.set $2
       (struct.new $type17
        (local.tee $1
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
      )
      (if (result (ref $type17))
       (i64.eqz
        (local.get $1)
       )
       (then
        (local.get $2)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready78)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (struct.get $type25 1
          (global.get $global78)
         )
        )
        (local.set $2
         (struct.new $type17
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
        )
        (if (result (ref $type17))
         (i64.eqz
          (local.get $1)
         )
         (then
          (local.get $2)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready78)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (struct.get $type25 1
            (global.get $global78)
           )
          )
          (local.set $2
           (struct.new $type17
            (local.tee $1
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
            (local.get $2)
           )
          )
          (if (result (ref $type17))
           (i64.eqz
            (local.get $1)
           )
           (then
            (local.get $2)
           )
           (else
            (if
             (i32.eqz
              (global.get $ready78)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (struct.get $type25 1
              (global.get $global78)
             )
            )
            (local.set $2
             (struct.new $type17
              (local.tee $1
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
              (local.get $2)
             )
            )
            (if (result (ref $type17))
             (i64.eqz
              (local.get $1)
             )
             (then
              (local.get $2)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready78)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (struct.get $type25 1
                (global.get $global78)
               )
              )
              (local.set $2
               (struct.new $type17
                (local.tee $1
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (local.get $2)
               )
              )
              (if (result (ref $type17))
               (i64.eqz
                (local.get $1)
               )
               (then
                (local.get $2)
               )
               (else
                (if
                 (i32.eqz
                  (global.get $ready78)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (struct.get $type25 1
                  (global.get $global78)
                 )
                )
                (local.set $2
                 (struct.new $type17
                  (local.tee $1
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (local.get $2)
                 )
                )
                (if (result (ref $type17))
                 (i64.eqz
                  (local.get $1)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (if
                   (i32.eqz
                    (global.get $ready78)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (struct.get $type25 1
                    (global.get $global78)
                   )
                  )
                  (local.set $2
                   (struct.new $type17
                    (local.tee $1
                     (i64.sub
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                    (local.get $2)
                   )
                  )
                  (if (result (ref $type17))
                   (i64.eqz
                    (local.get $1)
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (if
                     (i32.eqz
                      (global.get $ready78)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $2
                     (struct.new $type17
                      (local.tee $1
                       (i64.sub
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (local.get $2)
                     )
                    )
                    (if (result (ref $type17))
                     (call $function31
                      (struct.get $type25 1
                       (global.get $global78)
                      )
                      (local.get $1)
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (return_call $function42
                       (i32.const 0)
                       (i32.const 1)
                       (local.tee $1
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (struct.new $type17
                        (local.get $1)
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $47) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref $type17)) (result (ref null $type17))
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type17))
   (call $function31
    (struct.get $type25 1
     (global.get $global78)
    )
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.tee $2
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
     )
     (struct.new $type17
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function43 (type $46) (param $0 i64) (param $1 (ref $type37)) (result (ref $type18))
  (local $2 (ref $type18))
  (local $3 (ref null $environment83))
  (local $4 (ref $call37))
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global78)
   )
  )
  (if (result (ref $type18))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready114)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global114)
     )
    )
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (array.new_fixed $type18 0)
   )
   (else
    (local.set $2
     (array.new $type18
      (call_ref $call37
       (struct.get $type37 1
        (local.get $1)
       )
       (i64.const 0)
       (struct.get $type37 0
        (local.get $1)
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.get $0)
       (i64.const 1)
      )
      (then
       (array.set $type18
        (local.get $2)
        (i32.const 1)
        (call_ref $call37
         (local.tee $3
          (struct.get $type37 1
           (local.get $1)
          )
         )
         (i64.const 1)
         (local.tee $4
          (struct.get $type37 0
           (local.get $1)
          )
         )
        )
       )
       (if (result i32)
        (i64.gt_s
         (local.get $0)
         (i64.const 2)
        )
        (then
         (array.set $type18
          (local.get $2)
          (i32.const 2)
          (call_ref $call37
           (local.get $3)
           (i64.const 2)
           (local.get $4)
          )
         )
         (if (result i32)
          (i64.gt_s
           (local.get $0)
           (i64.const 3)
          )
          (then
           (array.set $type18
            (local.get $2)
            (i32.const 3)
            (call_ref $call37
             (local.get $3)
             (i64.const 3)
             (local.get $4)
            )
           )
           (if (result i32)
            (i64.gt_s
             (local.get $0)
             (i64.const 4)
            )
            (then
             (array.set $type18
              (local.get $2)
              (i32.const 4)
              (call_ref $call37
               (local.get $3)
               (i64.const 4)
               (local.get $4)
              )
             )
             (if (result i32)
              (i64.gt_s
               (local.get $0)
               (i64.const 5)
              )
              (then
               (array.set $type18
                (local.get $2)
                (i32.const 5)
                (call_ref $call37
                 (local.get $3)
                 (i64.const 5)
                 (local.get $4)
                )
               )
               (if (result i32)
                (i64.gt_s
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (array.set $type18
                  (local.get $2)
                  (i32.const 6)
                  (call_ref $call37
                   (local.get $3)
                   (i64.const 6)
                   (local.get $4)
                  )
                 )
                 (if (result i32)
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (array.set $type18
                    (local.get $2)
                    (i32.const 7)
                    (call_ref $call37
                     (local.get $3)
                     (i64.const 7)
                     (local.get $4)
                    )
                   )
                   (if (result i32)
                    (i64.gt_s
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (array.set $type18
                      (local.get $2)
                      (i32.const 8)
                      (call_ref $call37
                       (local.get $3)
                       (i64.const 8)
                       (local.get $4)
                      )
                     )
                     (if (result i32)
                      (i64.gt_s
                       (local.get $0)
                       (i64.const 9)
                      )
                      (then
                       (array.set $type18
                        (local.get $2)
                        (i32.const 9)
                        (call_ref $call37
                         (local.get $3)
                         (i64.const 9)
                         (local.get $4)
                        )
                       )
                       (if (result i32)
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 10)
                        )
                        (then
                         (array.set $type18
                          (local.get $2)
                          (i32.const 10)
                          (call_ref $call37
                           (local.get $3)
                           (i64.const 10)
                           (local.get $4)
                          )
                         )
                         (call $function49
                          (local.get $0)
                          (local.get $1)
                          (local.get $2)
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 11)
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.get $2)
   )
  )
 )
 (func $function49 (type $44) (param $0 i64) (param $1 (ref $type37)) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 (ref null $type17))
  (if (result i32)
   (i64.gt_s
    (local.get $0)
    (local.get $5)
   )
   (then
    (local.set $6
     (call_ref $call37
      (struct.get $type37 1
       (local.get $1)
      )
      (local.get $5)
      (struct.get $type37 0
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type18
     (local.get $2)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function50 (type $call48) (param $0 (ref $environment50)) (param $1 i64) (param $2 (ref $type14)) (param $3 (ref $type49)) (result i32)
  (local $4 (ref null $type17))
  (local $5 (ref $type50))
  (local $6 (ref $type43))
  (local $7 (ref $type56))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (array.get $type18
    (struct.get $environment50 0
     (local.get $0)
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (return_call $function57
   (struct.new $type43
    (struct.new $environment51
     (local.tee $5
      (struct.get $environment50 1
       (local.get $0)
      )
     )
     (local.get $2)
    )
   )
   (block (result (ref (exact $type46)))
    (local.set $7
     (struct.new $type56
      (i32.const 1)
     )
    )
    (struct.new $type46
     (struct.new $environment54
      (local.get $5)
      (local.get $3)
     )
    )
   )
   (local.get $7)
   (local.get $4)
   (i64.const 0)
   (i32.const 1)
   (struct.new $type45
    (ref.func $function56)
    (ref.null none)
   )
  )
 )
 (func $function51 (type $call43) (param $0 (ref $environment51)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 (ref $type44)) (param $5 (ref $type45)) (result i32)
  (local $6 (ref null $type17))
  (local $7 (ref null $type17))
  (local $8 (ref $type17))
  (local $9 (ref $environment60))
  (local $10 (ref $type14))
  (local $11 i64)
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $11
     (call $function53
      (local.tee $10
       (struct.get $environment51 1
        (local.get $0)
       )
      )
      (struct.get $environment51 0
       (local.get $0)
      )
      (local.get $2)
      (local.get $1)
      (array.get $type14
       (local.get $10)
       (i32.wrap_i64
        (local.get $2)
       )
      )
      (array.get $type14
       (local.get $10)
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eq
      (local.get $11)
      (i64.const 1)
     )
     (then
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type50
       (struct.get $environment51 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $1)
      )
      (if
       (i32.eqz
        (global.get $ready178)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (local.set $6
       (struct.get $environment60 3
        (local.tee $9
         (struct.get $type44 0
          (local.get $4)
         )
        )
       )
      )
      (local.set $7
       (struct.get $environment60 4
        (local.get $9)
       )
      )
      (return_call $function57
       (struct.get $environment60 0
        (local.get $9)
       )
       (struct.get $environment60 1
        (local.get $9)
       )
       (struct.get $environment60 2
        (local.get $9)
       )
       (if (result (ref null $type17))
        (ref.is_null
         (local.get $6)
        )
        (then
         (local.get $7)
        )
        (else
         (local.set $8
          (struct.new $type17
           (struct.get $type17 0
            (local.get $6)
           )
           (local.get $7)
          )
         )
         (if (result (ref null $type17))
          (ref.is_null
           (local.tee $6
            (struct.get $type17 1
             (local.get $6)
            )
           )
          )
          (then
           (local.get $8)
          )
          (else
           (local.set $8
            (struct.new $type17
             (struct.get $type17 0
              (local.get $6)
             )
             (local.get $8)
            )
           )
           (if (result (ref null $type17))
            (ref.is_null
             (local.tee $6
              (struct.get $type17 1
               (local.get $6)
              )
             )
            )
            (then
             (local.get $8)
            )
            (else
             (local.set $8
              (struct.new $type17
               (struct.get $type17 0
                (local.get $6)
               )
               (local.get $8)
              )
             )
             (if (result (ref null $type17))
              (ref.is_null
               (local.tee $6
                (struct.get $type17 1
                 (local.get $6)
                )
               )
              )
              (then
               (local.get $8)
              )
              (else
               (local.set $8
                (struct.new $type17
                 (struct.get $type17 0
                  (local.get $6)
                 )
                 (local.get $8)
                )
               )
               (if (result (ref null $type17))
                (ref.is_null
                 (local.tee $6
                  (struct.get $type17 1
                   (local.get $6)
                  )
                 )
                )
                (then
                 (local.get $8)
                )
                (else
                 (local.set $8
                  (struct.new $type17
                   (struct.get $type17 0
                    (local.get $6)
                   )
                   (local.get $8)
                  )
                 )
                 (if (result (ref null $type17))
                  (ref.is_null
                   (local.tee $6
                    (struct.get $type17 1
                     (local.get $6)
                    )
                   )
                  )
                  (then
                   (local.get $8)
                  )
                  (else
                   (local.set $8
                    (struct.new $type17
                     (struct.get $type17 0
                      (local.get $6)
                     )
                     (local.get $8)
                    )
                   )
                   (if (result (ref null $type17))
                    (ref.is_null
                     (local.tee $6
                      (struct.get $type17 1
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (local.get $8)
                    )
                    (else
                     (local.set $8
                      (struct.new $type17
                       (struct.get $type17 0
                        (local.get $6)
                       )
                       (local.get $8)
                      )
                     )
                     (if (result (ref null $type17))
                      (ref.is_null
                       (local.tee $6
                        (struct.get $type17 1
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (local.get $8)
                      )
                      (else
                       (local.set $8
                        (struct.new $type17
                         (struct.get $type17 0
                          (local.get $6)
                         )
                         (local.get $8)
                        )
                       )
                       (if (result (ref null $type17))
                        (ref.is_null
                         (local.tee $6
                          (struct.get $type17 1
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (local.get $8)
                        )
                        (else
                         (call $function62
                          (struct.new_default $type35)
                          (i32.const 0)
                          (i32.const 1)
                          (struct.get $type17 1
                           (local.get $6)
                          )
                          (struct.new $type17
                           (struct.get $type17 0
                            (local.get $6)
                           )
                           (local.get $8)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
       (local.get $3)
       (struct.get $environment60 5
        (local.get $9)
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $11)
        (i64.const 2)
       )
       (then
        (return_call_ref $call45
         (struct.get $type45 1
          (local.get $5)
         )
         (local.get $3)
         (struct.get $type45 0
          (local.get $5)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function53 (type $29) (param $0 (ref $type14)) (param $1 (ref $type50)) (param $2 i64) (param $3 i64) (param $4 (ref $type13)) (param $5 (ref $type13)) (param $6 i32) (param $7 i32) (param $8 i64) (result i64)
  (local $9 i32)
  (local $10 i32)
  (local $11 i64)
  (if (result i64)
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type13
      (local.get $4)
      (i32.wrap_i64
       (local.get $8)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (array.get $type50
        (local.get $1)
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (array.get $type13
      (local.get $5)
      (i32.wrap_i64
       (local.get $11)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if (result i64)
     (select
      (local.get $10)
      (i32.eqz
       (local.get $10)
      )
      (local.get $9)
     )
     (then
      (if
       (i64.gt_u
        (local.get $8)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $9
       (array.get $type13
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $8)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $10
       (array.get $type13
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $11)
         )
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if (result i64)
       (select
        (local.get $10)
        (i32.eqz
         (local.get $10)
        )
        (local.get $9)
       )
       (then
        (if
         (i32.eqz
          (local.get $7)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function53
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $4)
         (local.get $5)
         (local.get $6)
         (local.get $7)
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (else
        (select
         (i64.const 0)
         (i64.const 2)
         (local.get $9)
        )
       )
      )
     )
     (else
      (select
       (i64.const 0)
       (i64.const 2)
       (local.get $9)
      )
     )
    )
   )
  )
 )
 (func $function56 (type $call45) (param $0 (ref null $environment59)) (param $1 i32) (result i32)
  (local.get $1)
 )
 (func $function57 (type $28) (param $0 (ref $type43)) (param $1 (ref $type46)) (param $2 (ref $type56)) (param $3 (ref null $type17)) (param $4 i64) (param $5 i32) (param $6 (ref $type45)) (result i32)
  (local $7 i64)
  (local $8 (ref $environment54))
  (local $9 (ref $type49))
  (if
   (ref.is_null
    (local.get $3)
   )
   (then
    (return_call_ref $call49
     (struct.get $type49 1
      (local.tee $9
       (struct.get $environment54 1
        (local.tee $8
         (struct.get $type46 0
          (local.get $1)
         )
        )
       )
      )
     )
     (struct.get $environment54 0
      (local.get $8)
     )
     (local.get $6)
     (struct.get $type49 0
      (local.get $9)
     )
    )
   )
   (else
    (local.set $7
     (struct.get $type17 0
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (ref.is_null
       (local.tee $3
        (struct.get $type17 1
         (local.get $3)
        )
       )
      )
     )
     (then
      (local.set $6
       (struct.new $type45
        (ref.func $function59)
        (struct.new $environment59
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $4)
         (local.get $6)
         (struct.new $type56
          (i32.const 1)
         )
         (ref.null none)
         (local.get $7)
         (local.get $3)
        )
       )
      )
     )
    )
    (return_call $function51
     (struct.get $type43 0
      (local.get $0)
     )
     (local.get $7)
     (local.get $4)
     (local.get $5)
     (struct.new $type44
      (struct.new $environment60
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (ref.null none)
       (local.get $3)
       (local.get $6)
      )
     )
     (local.get $6)
    )
   )
  )
  (unreachable)
 )
 (func $function59 (type $call45) (param $0 (ref null $environment59)) (param $1 i32) (result i32)
  (local $2 (ref null $type17))
  (local $3 (ref null $type17))
  (local $4 (ref $type45))
  (local $5 (ref $type43))
  (local $6 (ref $type46))
  (local $7 (ref $type56))
  (local $8 (ref $type56))
  (local $9 (ref $type17))
  (local $10 i64)
  (local $11 i64)
  (local $scratch (ref null $type17))
  (local.set $2
   (struct.get $environment59 8
    (local.get $0)
   )
  )
  (local.set $9
   (struct.new $type17
    (struct.get $environment59 7
     (local.get $0)
    )
    (block (result (ref null $type17))
     (local.set $scratch
      (struct.get $environment59 6
       (local.get $0)
      )
     )
     (drop
      (struct.get $environment59 5
       (local.get $0)
      )
     )
     (local.set $5
      (struct.get $environment59 0
       (local.get $0)
      )
     )
     (local.set $6
      (struct.get $environment59 1
       (local.get $0)
      )
     )
     (local.set $7
      (struct.get $environment59 2
       (local.get $0)
      )
     )
     (local.set $11
      (struct.get $environment59 3
       (local.get $0)
      )
     )
     (local.set $4
      (struct.get $environment59 4
       (local.get $0)
      )
     )
     (local.set $8
      (struct.get $environment59 5
       (local.get $0)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (local.set $10
   (struct.get $type17 0
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.tee $2
      (struct.get $type17 1
       (local.get $2)
      )
     )
    )
   )
   (then
    (local.set $4
     (struct.new $type45
      (ref.func $function59)
      (struct.new $environment59
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $11)
       (local.get $4)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $2)
      )
     )
    )
   )
  )
  (return_call $function51
   (struct.get $type43 0
    (local.get $5)
   )
   (local.get $10)
   (local.get $11)
   (local.get $1)
   (struct.new $type44
    (struct.new $environment60
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (local.get $2)
     (local.get $4)
    )
   )
   (local.get $4)
  )
 )
 (func $function62 (type $24) (param $0 (ref $type35)) (param $1 i32) (param $2 i32) (param $3 (ref null $type17)) (param $4 (ref $type17)) (result (ref null $type17))
  (local $5 (ref null $type17))
  (if (result (ref $type17))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (local.set $5
     (struct.get $type17 1
      (local.get $3)
     )
    )
    (local.set $4
     (struct.new $type17
      (struct.get $type17 0
       (local.get $3)
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $5)
     (local.get $4)
    )
   )
  )
 )
 (func $function63 (type $call33) (param $0 i64) (param $1 (ref $type18)) (result (ref $type14))
  (local $2 (ref $type28))
  (local $3 (ref $type14))
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global78)
   )
  )
  (local.set $3
   (if (result (ref $type14))
    (i64.eqz
     (local.get $0)
    )
    (then
     (if
      (i32.eqz
       (global.get $ready80)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global80)
      )
     )
     (if
      (i32.eqz
       (global.get $ready82)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global82)
      )
     )
     (array.new_fixed $type14 0)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready67)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global67)
      )
     )
     (drop
      (call $function39
       (local.get $0)
       (local.get $1)
       (local.tee $3
        (array.new $type14
         (call $function27
          (local.get $0)
          (local.get $1)
          (i64.const 0)
         )
         (block (result i32)
          (if
           (i64.gt_u
            (local.get $0)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (i32.wrap_i64
           (local.get $0)
          )
         )
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 1)
      )
     )
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready194)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global194)
   )
  )
  (drop
   (if (result i32)
    (i64.eqz
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call28
       (struct.get $type28 1
        (local.tee $2
         (struct.new $type28
          (ref.func $function64)
          (struct.new $environment64
           (local.get $0)
           (local.get $3)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type28 0
        (local.get $2)
       )
      )
     )
     (if (result i32)
      (i64.eq
       (local.get $0)
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call28
         (struct.get $type28 1
          (local.get $2)
         )
         (i64.const 1)
         (struct.get $type28 0
          (local.get $2)
         )
        )
       )
       (if (result i32)
        (i64.eq
         (local.get $0)
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call28
           (struct.get $type28 1
            (local.get $2)
           )
           (i64.const 2)
           (struct.get $type28 0
            (local.get $2)
           )
          )
         )
         (if (result i32)
          (i64.eq
           (local.get $0)
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call28
             (struct.get $type28 1
              (local.get $2)
             )
             (i64.const 3)
             (struct.get $type28 0
              (local.get $2)
             )
            )
           )
           (if (result i32)
            (i64.eq
             (local.get $0)
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call28
               (struct.get $type28 1
                (local.get $2)
               )
               (i64.const 4)
               (struct.get $type28 0
                (local.get $2)
               )
              )
             )
             (if (result i32)
              (i64.eq
               (local.get $0)
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call28
                 (struct.get $type28 1
                  (local.get $2)
                 )
                 (i64.const 5)
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
               )
               (if (result i32)
                (i64.eq
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call28
                   (struct.get $type28 1
                    (local.get $2)
                   )
                   (i64.const 6)
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call28
                     (struct.get $type28 1
                      (local.get $2)
                     )
                     (i64.const 7)
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call28
                       (struct.get $type28 1
                        (local.get $2)
                       )
                       (i64.const 8)
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                     )
                     (call $function68
                      (local.get $0)
                      (local.get $2)
                      (i32.const 0)
                      (i32.const 1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $3)
 )
 (func $function64 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type28))
  (local $3 (ref $environment64))
  (local $4 (ref $type14))
  (local $5 i64)
  (local.set $5
   (struct.get $environment64 0
    (local.tee $3
     (ref.cast (ref $environment64)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready194)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global194)
   )
  )
  (local.set $2
   (struct.new $type28
    (ref.func $function65)
    (struct.new $environment65
     (struct.get $environment64 0
      (local.get $3)
     )
     (local.tee $4
      (struct.get $environment64 1
       (local.get $3)
      )
     )
     (local.get $1)
     (array.get $type14
      (local.get $4)
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.get $2)
      )
      (i64.const 0)
      (struct.get $type28 0
       (local.get $2)
      )
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $5)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (call_ref $call28
        (struct.get $type28 1
         (local.get $2)
        )
        (i64.const 1)
        (struct.get $type28 0
         (local.get $2)
        )
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $5)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (call_ref $call28
          (struct.get $type28 1
           (local.get $2)
          )
          (i64.const 2)
          (struct.get $type28 0
           (local.get $2)
          )
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $5)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (call_ref $call28
            (struct.get $type28 1
             (local.get $2)
            )
            (i64.const 3)
            (struct.get $type28 0
             (local.get $2)
            )
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $5)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (call_ref $call28
              (struct.get $type28 1
               (local.get $2)
              )
              (i64.const 4)
              (struct.get $type28 0
               (local.get $2)
              )
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $5)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (call_ref $call28
                (struct.get $type28 1
                 (local.get $2)
                )
                (i64.const 5)
                (struct.get $type28 0
                 (local.get $2)
                )
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $5)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (call_ref $call28
                  (struct.get $type28 1
                   (local.get $2)
                  )
                  (i64.const 6)
                  (struct.get $type28 0
                   (local.get $2)
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $5)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (call_ref $call28
                    (struct.get $type28 1
                     (local.get $2)
                    )
                    (i64.const 7)
                    (struct.get $type28 0
                     (local.get $2)
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $5)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (call_ref $call28
                      (struct.get $type28 1
                       (local.get $2)
                      )
                      (i64.const 8)
                      (struct.get $type28 0
                       (local.get $2)
                      )
                     )
                    )
                    (return_call $function68
                     (local.get $5)
                     (local.get $2)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function65 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type28))
  (local $3 (ref $environment65))
  (local $4 (ref $type13))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (array.get $type13
    (local.tee $4
     (array.get $type14
      (struct.get $environment65 1
       (local.tee $3
        (ref.cast (ref $environment65)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (block (result i32)
     (if
      (i64.gt_u
       (local.tee $1
        (struct.get $environment65 2
         (local.get $3)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready194)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global194)
     )
    )
    (if (result i32)
     (i64.eqz
      (local.tee $1
       (struct.get $environment65 0
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (call_ref $call28
        (struct.get $type28 1
         (local.tee $2
          (struct.new $type28
           (ref.func $function66)
           (struct.new $environment66
            (struct.get $environment65 3
             (local.get $3)
            )
            (local.get $4)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type28 0
         (local.get $2)
        )
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (call_ref $call28
          (struct.get $type28 1
           (local.get $2)
          )
          (i64.const 1)
          (struct.get $type28 0
           (local.get $2)
          )
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 2)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (call_ref $call28
            (struct.get $type28 1
             (local.get $2)
            )
            (i64.const 2)
            (struct.get $type28 0
             (local.get $2)
            )
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 3)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (call_ref $call28
              (struct.get $type28 1
               (local.get $2)
              )
              (i64.const 3)
              (struct.get $type28 0
               (local.get $2)
              )
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 4)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (call_ref $call28
                (struct.get $type28 1
                 (local.get $2)
                )
                (i64.const 4)
                (struct.get $type28 0
                 (local.get $2)
                )
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 5)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (call_ref $call28
                  (struct.get $type28 1
                   (local.get $2)
                  )
                  (i64.const 5)
                  (struct.get $type28 0
                   (local.get $2)
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 6)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (call_ref $call28
                    (struct.get $type28 1
                     (local.get $2)
                    )
                    (i64.const 6)
                    (struct.get $type28 0
                     (local.get $2)
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 7)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (call_ref $call28
                      (struct.get $type28 1
                       (local.get $2)
                      )
                      (i64.const 7)
                      (struct.get $type28 0
                       (local.get $2)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 8)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (call_ref $call28
                        (struct.get $type28 1
                         (local.get $2)
                        )
                        (i64.const 8)
                        (struct.get $type28 0
                         (local.get $2)
                        )
                       )
                      )
                      (return_call $function68
                       (local.get $1)
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 9)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function66 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get $type13
    (struct.get $environment66 0
     (ref.cast (ref $environment66)
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (struct.get $environment66 1
      (ref.cast (ref $environment66)
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
   )
  )
  (i32.const 0)
 )
 (func $function68 (type $19) (param $0 i64) (param $1 (ref $type28)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.get $1)
      )
      (local.get $4)
      (struct.get $type28 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function68
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment71))
  (return_call $function50
   (struct.get $type48 0
    (struct.get $environment71 1
     (local.tee $2
      (ref.cast (ref $environment71)
       (local.get $0)
      )
     )
    )
   )
   (local.get $1)
   (struct.get $environment71 0
    (local.get $2)
   )
   (struct.get $environment71 2
    (local.get $2)
   )
  )
 )
 (func $function72 (type $call49) (param $0 (ref null $environment74)) (param $1 (ref $type50)) (param $2 (ref $type45)) (result i32)
  (return_call_ref $call45
   (struct.get $type45 1
    (local.get $2)
   )
   (i32.const 1)
   (struct.get $type45 0
    (local.get $2)
   )
  )
 )
 (func $function73 (type $call8) (param $0 (ref $environment73)) (result i32)
  (unreachable)
 )
 (func $function74 (type $call49) (param $0 (ref null $environment74)) (param $1 (ref $type50)) (param $2 (ref $type45)) (result i32)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type14))
  (local $6 (ref $type13))
  (local.set $5
   (struct.get $environment74 1
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $environment74 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (call $function53
      (local.get $5)
      (local.get $1)
      (local.get $3)
      (local.get $3)
      (local.tee $6
       (array.get $type14
        (local.get $5)
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (if (result i32)
      (local.tee $4
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
      )
     )
     (then
      (return_call_ref $call45
       (struct.get $type45 1
        (local.get $2)
       )
       (i32.const 1)
       (struct.get $type45 0
        (local.get $2)
       )
      )
     )
     (else
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function75 (type $13) (param $0 i64) (param $1 i64) (param $2 (ref $type53)) (param $3 i64) (param $4 (ref $type14)) (param $5 (ref $type18)) (param $6 (ref $type50)) (param $7 (ref $type25)) (param $8 (ref $type8)) (param $9 i32) (param $10 i32) (param $11 i64) (param $12 (ref null $type24)) (result (ref null $type24))
  (if (result (ref null $type24))
   (call_ref $call25
    (struct.get $type25 1
     (local.get $7)
    )
    (local.get $11)
    (struct.get $type25 0
     (local.get $7)
    )
   )
   (then
    (if
     (i64.eq
      (local.get $3)
      (local.get $11)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready185)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global185)
       )
      )
      (return_call $function76
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $5)
       (local.get $8)
       (call $function63
        (local.get $3)
        (local.get $5)
       )
       (block (result (ref $type13))
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.get $type14
         (local.get $4)
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
       (i64.const 0)
       (ref.null none)
       (ref.null none)
       (local.get $12)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function84
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $11)
       (array.get $type14
        (local.get $4)
        (i32.wrap_i64
         (local.get $11)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
       (i64.const 0)
       (local.get $12)
      )
     )
    )
    (unreachable)
   )
   (else
    (local.get $12)
   )
  )
 )
 (func $function76 (type $11) (param $0 i64) (param $1 i64) (param $2 (ref $type53)) (param $3 i64) (param $4 (ref $type18)) (param $5 (ref $type8)) (param $6 (ref $type14)) (param $7 (ref $type13)) (param $8 i32) (param $9 i32) (param $10 i64) (param $11 i64) (param $12 (ref null $type17)) (param $13 (ref null $type12)) (param $14 (ref null $type24)) (result (ref null $type24))
  (local $15 (ref $type25))
  (local $16 (ref $environment73))
  (local $17 (ref $type12))
  (local $18 i32)
  (if (result (ref null $type24))
   (if (result i32)
    (local.tee $18
     (i64.eq
      (local.get $3)
      (local.get $10)
     )
    )
    (then
     (local.get $18)
    )
    (else
     (i64.eq
      (local.get $1)
      (local.get $11)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready245)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global245)
     )
    )
    (if (result (ref null $type24))
     (if (result i32)
      (if (result i32)
       (local.tee $8
        (i64.eqz
         (local.get $3)
        )
       )
       (then
        (local.get $8)
       )
       (else
        (if (result i32)
         (call_ref $call25
          (struct.get $type25 1
           (local.tee $15
            (struct.new $type25
             (ref.func $function77)
             (struct.new $environment77
              (local.get $13)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type25 0
           (local.get $15)
          )
         )
         (then
          (if (result i32)
           (local.tee $8
            (i64.eq
             (local.get $3)
             (i64.const 1)
            )
           )
           (then
            (local.get $8)
           )
           (else
            (if (result i32)
             (call_ref $call25
              (struct.get $type25 1
               (local.get $15)
              )
              (i64.const 1)
              (struct.get $type25 0
               (local.get $15)
              )
             )
             (then
              (if (result i32)
               (local.tee $8
                (i64.eq
                 (local.get $3)
                 (i64.const 2)
                )
               )
               (then
                (local.get $8)
               )
               (else
                (if (result i32)
                 (call_ref $call25
                  (struct.get $type25 1
                   (local.get $15)
                  )
                  (i64.const 2)
                  (struct.get $type25 0
                   (local.get $15)
                  )
                 )
                 (then
                  (if (result i32)
                   (local.tee $8
                    (i64.eq
                     (local.get $3)
                     (i64.const 3)
                    )
                   )
                   (then
                    (local.get $8)
                   )
                   (else
                    (if (result i32)
                     (call_ref $call25
                      (struct.get $type25 1
                       (local.get $15)
                      )
                      (i64.const 3)
                      (struct.get $type25 0
                       (local.get $15)
                      )
                     )
                     (then
                      (if (result i32)
                       (local.tee $8
                        (i64.eq
                         (local.get $3)
                         (i64.const 4)
                        )
                       )
                       (then
                        (local.get $8)
                       )
                       (else
                        (if (result i32)
                         (call_ref $call25
                          (struct.get $type25 1
                           (local.get $15)
                          )
                          (i64.const 4)
                          (struct.get $type25 0
                           (local.get $15)
                          )
                         )
                         (then
                          (if (result i32)
                           (local.tee $8
                            (i64.eq
                             (local.get $3)
                             (i64.const 5)
                            )
                           )
                           (then
                            (local.get $8)
                           )
                           (else
                            (if (result i32)
                             (call_ref $call25
                              (struct.get $type25 1
                               (local.get $15)
                              )
                              (i64.const 5)
                              (struct.get $type25 0
                               (local.get $15)
                              )
                             )
                             (then
                              (if (result i32)
                               (local.tee $8
                                (i64.eq
                                 (local.get $3)
                                 (i64.const 6)
                                )
                               )
                               (then
                                (local.get $8)
                               )
                               (else
                                (if (result i32)
                                 (call_ref $call25
                                  (struct.get $type25 1
                                   (local.get $15)
                                  )
                                  (i64.const 6)
                                  (struct.get $type25 0
                                   (local.get $15)
                                  )
                                 )
                                 (then
                                  (if (result i32)
                                   (local.tee $8
                                    (i64.eq
                                     (local.get $3)
                                     (i64.const 7)
                                    )
                                   )
                                   (then
                                    (local.get $8)
                                   )
                                   (else
                                    (if (result i32)
                                     (call_ref $call25
                                      (struct.get $type25 1
                                       (local.get $15)
                                      )
                                      (i64.const 7)
                                      (struct.get $type25 0
                                       (local.get $15)
                                      )
                                     )
                                     (then
                                      (if (result i32)
                                       (local.tee $8
                                        (i64.eq
                                         (local.get $3)
                                         (i64.const 8)
                                        )
                                       )
                                       (then
                                        (local.get $8)
                                       )
                                       (else
                                        (if (result i32)
                                         (call_ref $call25
                                          (struct.get $type25 1
                                           (local.get $15)
                                          )
                                          (i64.const 8)
                                          (struct.get $type25 0
                                           (local.get $15)
                                          )
                                         )
                                         (then
                                          (call $function82
                                           (local.get $3)
                                           (local.get $15)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 9)
                                          )
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (i32.const 0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                             (else
                              (i32.const 0)
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
      (then
       (call $function50
        (struct.get $type48 0
         (struct.get $environment73 2
          (local.tee $16
           (struct.get $type8 1
            (local.get $5)
           )
          )
         )
        )
        (struct.get $environment73 0
         (local.get $16)
        )
        (struct.get $environment73 1
         (local.get $16)
        )
        (struct.get $environment73 3
         (local.get $16)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type18
       (local.get $4)
       (i32.wrap_i64
        (local.get $3)
       )
       (local.get $12)
      )
      (if
       (i32.eqz
        (global.get $ready111)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global111)
       )
      )
      (drop
       (call $function43
        (local.get $0)
        (struct.new $type37
         (ref.func $function83)
         (struct.new $environment83
          (local.get $4)
         )
        )
       )
      )
      (struct.new $type24
       (local.get $14)
      )
     )
     (else
      (local.get $14)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (local.get $7)
     (i32.wrap_i64
      (local.get $10)
     )
     (i32.const 1)
    )
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $17
     (struct.new $type12
      (array.get $type14
       (local.get $6)
       (i32.wrap_i64
        (local.get $10)
       )
      )
      (local.get $13)
     )
    )
    (if
     (i32.eqz
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (local.set $14
     (call $function76
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $3)
      (local.get $4)
      (local.get $5)
      (local.get $6)
      (local.get $7)
      (local.get $8)
      (local.get $9)
      (i64.add
       (local.get $10)
       (i64.const 1)
      )
      (i64.add
       (local.get $11)
       (i64.const 1)
      )
      (struct.new $type17
       (local.get $10)
       (local.get $12)
      )
      (local.get $17)
      (local.get $14)
     )
    )
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (local.get $7)
     (i32.wrap_i64
      (local.get $10)
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function76
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (i64.add
      (local.get $10)
      (i64.const 1)
     )
     (local.get $11)
     (local.get $12)
     (local.get $13)
     (local.get $14)
    )
   )
  )
 )
 (func $function77 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref null $type12))
  (local $3 (ref $type13))
  (local $4 (ref $type41))
  (local $5 i32)
  (local.set $2
   (struct.get $environment77 0
    (ref.cast (ref $environment77)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready239)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global239)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $5
      (array.get $type13
       (struct.get $type12 0
        (local.get $2)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $1
           (struct.get $environment78 0
            (struct.get $type41 0
             (local.tee $4
              (struct.new $type41
               (struct.new $environment78
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (then
      (local.get $5)
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.tee $2
         (struct.get $type12 1
          (local.get $2)
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (local.tee $5
          (array.get $type13
           (struct.get $type12 0
            (local.get $2)
           )
           (block (result i32)
            (if
             (i64.gt_u
              (local.tee $1
               (struct.get $environment78 0
                (struct.get $type41 0
                 (local.get $4)
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
         (then
          (local.get $5)
         )
         (else
          (if (result i32)
           (ref.is_null
            (local.tee $2
             (struct.get $type12 1
              (local.get $2)
             )
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (local.tee $5
              (array.get $type13
               (struct.get $type12 0
                (local.get $2)
               )
               (block (result i32)
                (if
                 (i64.gt_u
                  (local.tee $1
                   (struct.get $environment78 0
                    (struct.get $type41 0
                     (local.get $4)
                    )
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
             (then
              (local.get $5)
             )
             (else
              (if (result i32)
               (ref.is_null
                (local.tee $2
                 (struct.get $type12 1
                  (local.get $2)
                 )
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (local.tee $5
                  (array.get $type13
                   (struct.get $type12 0
                    (local.get $2)
                   )
                   (block (result i32)
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (struct.get $environment78 0
                        (struct.get $type41 0
                         (local.get $4)
                        )
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i32.wrap_i64
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $5)
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.tee $2
                     (struct.get $type12 1
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (local.tee $5
                      (array.get $type13
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (block (result i32)
                        (if
                         (i64.gt_u
                          (local.tee $1
                           (struct.get $environment78 0
                            (struct.get $type41 0
                             (local.get $4)
                            )
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (i32.wrap_i64
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $5)
                     )
                     (else
                      (if (result i32)
                       (ref.is_null
                        (local.tee $2
                         (struct.get $type12 1
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (local.tee $5
                          (array.get $type13
                           (struct.get $type12 0
                            (local.get $2)
                           )
                           (block (result i32)
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (struct.get $environment78 0
                                (struct.get $type41 0
                                 (local.get $4)
                                )
                               )
                              )
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $5)
                         )
                         (else
                          (if (result i32)
                           (ref.is_null
                            (local.tee $2
                             (struct.get $type12 1
                              (local.get $2)
                             )
                            )
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (local.tee $5
                              (array.get $type13
                               (struct.get $type12 0
                                (local.get $2)
                               )
                               (block (result i32)
                                (if
                                 (i64.gt_u
                                  (local.tee $1
                                   (struct.get $environment78 0
                                    (struct.get $type41 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (i32.wrap_i64
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $5)
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.tee $2
                                 (struct.get $type12 1
                                  (local.get $2)
                                 )
                                )
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (local.tee $5
                                  (array.get $type13
                                   (struct.get $type12 0
                                    (local.get $2)
                                   )
                                   (block (result i32)
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (struct.get $environment78 0
                                        (struct.get $type41 0
                                         (local.get $4)
                                        )
                                       )
                                      )
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (i32.wrap_i64
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $5)
                                 )
                                 (else
                                  (if (result i32)
                                   (ref.is_null
                                    (local.tee $2
                                     (struct.get $type12 1
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (local.tee $5
                                      (array.get $type13
                                       (struct.get $type12 0
                                        (local.get $2)
                                       )
                                       (block (result i32)
                                        (if
                                         (i64.gt_u
                                          (local.tee $1
                                           (struct.get $environment78 0
                                            (struct.get $type41 0
                                             (local.get $4)
                                            )
                                           )
                                          )
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (i32.wrap_i64
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $5)
                                     )
                                     (else
                                      (return_call $function80
                                       (local.get $4)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (struct.get $type12 1
                                        (local.get $2)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function80 (type $5) (param $0 (ref $type41)) (param $1 i32) (param $2 i32) (param $3 (ref null $type12)) (result i32)
  (local $4 (ref $type13))
  (local $5 i64)
  (local $6 i32)
  (if (result i32)
   (ref.is_null
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $6
      (array.get $type13
       (struct.get $type12 0
        (local.get $3)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment78 0
            (struct.get $type41 0
             (local.get $0)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
     )
     (then
      (local.get $6)
     )
     (else
      (local.set $3
       (struct.get $type12 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function80
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function82 (type $4) (param $0 i64) (param $1 (ref $type25)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (local.get $0)
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if (result i32)
     (call_ref $call25
      (struct.get $type25 1
       (local.get $1)
      )
      (local.get $4)
      (struct.get $type25 0
       (local.get $1)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function82
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function83 (type $call37) (param $0 (ref null $environment83)) (param $1 i64) (result (ref null $type17))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type18
   (struct.get $environment83 0
    (local.get $0)
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function84 (type $3) (param $0 i64) (param $1 i64) (param $2 (ref $type53)) (param $3 i64) (param $4 (ref $type14)) (param $5 (ref $type18)) (param $6 (ref $type50)) (param $7 (ref $type25)) (param $8 (ref $type8)) (param $9 i32) (param $10 i32) (param $11 i64) (param $12 (ref $type13)) (param $13 i32) (param $14 i32) (param $15 i64) (param $16 i64) (param $17 (ref null $type24)) (result (ref null $type24))
  (local $18 i32)
  (local $19 i64)
  (local $20 (ref null $type17))
  (local $21 (ref $type13))
  (if (result (ref null $type24))
   (i64.eq
    (local.get $11)
    (local.get $15)
   )
   (then
    (if
     (i64.gt_u
      (local.get $11)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type50
     (local.get $6)
     (i32.wrap_i64
      (local.get $11)
     )
     (local.get $16)
    )
    (if
     (i32.eqz
      (local.get $10)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (local.get $10)
     (i64.add
      (local.get $11)
      (i64.const 1)
     )
     (local.get $17)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $14)
     )
     (then
      (unreachable)
     )
    )
    (local.set $17
     (call $function84
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $3)
      (local.get $4)
      (local.get $5)
      (local.get $6)
      (local.get $7)
      (local.get $8)
      (local.get $9)
      (local.get $10)
      (local.get $11)
      (local.get $12)
      (local.get $13)
      (local.get $14)
      (i64.add
       (local.get $15)
       (i64.const 1)
      )
      (local.get $16)
      (local.get $17)
     )
    )
    (if
     (i64.gt_u
      (local.get $15)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $21
     (array.get $type14
      (local.get $4)
      (i32.wrap_i64
       (local.get $15)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $15)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.tee $19
       (array.get $type50
        (local.get $6)
        (i32.wrap_i64
         (local.get $15)
        )
       )
      )
      (local.get $1)
     )
     (then
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type18
       (local.get $5)
       (local.tee $18
        (i32.wrap_i64
         (local.get $15)
        )
       )
       (struct.new $type17
        (local.get $11)
        (array.get $type18
         (local.get $5)
         (local.get $18)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (local.get $21)
       (i32.wrap_i64
        (local.get $11)
       )
       (i32.const 1)
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type50
       (local.get $6)
       (i32.wrap_i64
        (local.get $15)
       )
       (i64.add
        (local.get $19)
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (local.get $14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $17
       (call $function84
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (local.get $7)
        (local.get $8)
        (local.get $9)
        (local.get $10)
        (local.get $11)
        (local.get $12)
        (local.get $13)
        (local.get $14)
        (i64.add
         (local.get $15)
         (i64.const 1)
        )
        (local.get $16)
        (local.get $17)
       )
      )
      (if
       (i64.ne
        (local.get $1)
        (local.get $16)
       )
       (then
        (if
         (i64.gt_u
          (local.get $15)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type13
         (local.get $12)
         (i32.wrap_i64
          (local.get $15)
         )
         (i32.const 1)
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type18
         (local.get $5)
         (local.tee $18
          (i32.wrap_i64
           (local.get $11)
          )
         )
         (struct.new $type17
          (local.get $15)
          (array.get $type18
           (local.get $5)
           (local.get $18)
          )
         )
        )
        (if
         (i32.eqz
          (local.get $14)
         )
         (then
          (unreachable)
         )
        )
        (local.set $17
         (call $function84
          (local.get $0)
          (local.get $1)
          (local.get $2)
          (local.get $3)
          (local.get $4)
          (local.get $5)
          (local.get $6)
          (local.get $7)
          (local.get $8)
          (local.get $9)
          (local.get $10)
          (local.get $11)
          (local.get $12)
          (local.get $13)
          (local.get $14)
          (i64.add
           (local.get $15)
           (i64.const 1)
          )
          (i64.add
           (local.get $16)
           (i64.const 1)
          )
          (local.get $17)
         )
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $20
         (struct.get $type17 1
          (array.get $type18
           (local.get $5)
           (i32.wrap_i64
            (local.get $11)
           )
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type18
         (local.get $5)
         (i32.wrap_i64
          (local.get $11)
         )
         (local.get $20)
        )
        (if
         (i64.gt_u
          (local.get $15)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type13
         (local.get $12)
         (i32.wrap_i64
          (local.get $15)
         )
         (i32.const 0)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type50
       (local.get $6)
       (i32.wrap_i64
        (local.get $15)
       )
       (local.get $19)
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (local.get $21)
       (i32.wrap_i64
        (local.get $11)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $20
       (struct.get $type17 1
        (array.get $type18
         (local.get $5)
         (i32.wrap_i64
          (local.get $15)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type18
       (local.get $5)
       (i32.wrap_i64
        (local.get $15)
       )
       (local.get $20)
      )
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (local.get $16)
     )
     (then
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type18
       (local.get $5)
       (local.tee $18
        (i32.wrap_i64
         (local.get $11)
        )
       )
       (struct.new $type17
        (local.get $15)
        (array.get $type18
         (local.get $5)
         (local.get $18)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (local.get $12)
       (i32.wrap_i64
        (local.get $15)
       )
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $17
       (call $function84
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (local.get $7)
        (local.get $8)
        (local.get $9)
        (local.get $10)
        (local.get $11)
        (local.get $12)
        (local.get $13)
        (local.get $14)
        (i64.add
         (local.get $15)
         (i64.const 1)
        )
        (i64.add
         (local.get $16)
         (i64.const 1)
        )
        (local.get $17)
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (local.get $12)
       (i32.wrap_i64
        (local.get $15)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $20
       (struct.get $type17 1
        (array.get $type18
         (local.get $5)
         (i32.wrap_i64
          (local.get $11)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type18
       (local.get $5)
       (i32.wrap_i64
        (local.get $11)
       )
       (local.get $20)
      )
     )
    )
    (local.get $17)
   )
  )
 )
 (func $function86 (type $2) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 (ref null $type24))
  (local $6 (ref $type14))
  (local $7 (ref $type48))
  (local $8 (ref $type37))
  (local $9 (ref $type53))
  (local $10 i64)
  (local $11 i32)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready265)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready271)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global271)
     )
    )
    (local.set $4
     (call $foreign0
      (global.get $global265)
     )
    )
    (if
     (i32.eqz
      (global.get $ready199)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global199)
     )
    )
    (if
     (i32.eqz
      (global.get $ready201)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global201)
     )
    )
    (if
     (i32.eqz
      (global.get $ready76)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global76)
     )
    )
    (local.set $6
     (call $function30
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready102)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global102)
     )
    )
    (if
     (i32.eqz
      (global.get $ready105)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (ref.as_non_null
      (global.get $global105)
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.set $9
     (struct.new_default $type53)
    )
    (local.set $7
     (struct.new $type48
      (struct.new $environment50
       (call $function43
        (i64.add
         (local.tee $10
          (i64.sub
           (local.get $4)
           (i64.const 1)
          )
         )
         (i64.const 1)
        )
        (local.get $8)
       )
       (block (result (ref (exact $type50)))
        (if
         (i64.gt_u
          (local.get $10)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.new_default $type50
         (i32.wrap_i64
          (local.get $10)
         )
        )
       )
      )
     )
    )
    (local.set $5
     (call $function75
      (local.get $4)
      (i64.const 2)
      (local.get $9)
      (local.get $10)
      (local.get $6)
      (array.new_default $type18
       (local.tee $11
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (array.new_default $type50
       (local.get $11)
      )
      (struct.new $type25
       (ref.func $function71)
       (struct.new $environment71
        (local.get $6)
        (local.get $7)
        (struct.new $type49
         (ref.func $function72)
         (ref.null none)
        )
       )
      )
      (struct.new $type8
       (ref.func $function73)
       (struct.new $environment73
        (local.get $10)
        (local.get $6)
        (local.get $7)
        (struct.new $type49
         (ref.func $function74)
         (struct.new $environment74
          (local.get $10)
          (local.get $6)
         )
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (global.get $ready274)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global274)
     )
    )
    (local.set $4
     (if (result i64)
      (ref.is_null
       (local.get $5)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $5
          (struct.get $type24 0
           (local.get $5)
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $5
            (struct.get $type24 0
             (local.get $5)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $5
              (struct.get $type24 0
               (local.get $5)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $5
                (struct.get $type24 0
                 (local.get $5)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $5
                  (struct.get $type24 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $5
                    (struct.get $type24 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $5
                      (struct.get $type24 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $5
                        (struct.get $type24 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (call $function89
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type24 0
                         (local.get $5)
                        )
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function86
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $function89 (type $0) (param $0 i32) (param $1 i32) (param $2 (ref null $type24)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type24 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function89
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready266)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global266)
   )
  )
  (return_call $function86
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global80
   (struct.new_default $type11)
  )
  (global.set $ready80
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type15)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type19)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type20)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global274
   (struct.new_default $type23)
  )
  (global.set $ready274
   (i32.const 1)
  )
  (global.set $global78
   (struct.new $type25
    (ref.func $function31)
    (ref.null none)
   )
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type26)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global73
   (struct.new_default $type27)
  )
  (global.set $ready73
   (i32.const 1)
  )
  (global.set $global271
   (struct.new_default $type29)
  )
  (global.set $ready271
   (i32.const 1)
  )
  (global.set $global64
   (struct.new_default $type30)
  )
  (global.set $ready64
   (i32.const 1)
  )
  (global.set $global67
   (struct.new_default $type31)
  )
  (global.set $ready67
   (i32.const 1)
  )
  (global.set $global76
   (struct.new_default $type32)
  )
  (global.set $ready76
   (i32.const 1)
  )
  (global.set $global96
   (struct.new_default $type33)
  )
  (global.set $ready96
   (i32.const 1)
  )
  (global.set $global178
   (struct.new_default $type34)
  )
  (global.set $ready178
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type36)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global105
   (struct.new $type37
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global194
   (struct.new_default $type38)
  )
  (global.set $ready194
   (i32.const 1)
  )
  (global.set $global245
   (struct.new_default $type39)
  )
  (global.set $ready245
   (i32.const 1)
  )
  (global.set $global239
   (struct.new_default $type40)
  )
  (global.set $ready239
   (i32.const 1)
  )
  (global.set $global156
   (struct.new_default $type42)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $global102
   (struct.new_default $type47)
  )
  (global.set $ready102
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type51)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global201
   (struct.new_default $type52)
  )
  (global.set $ready201
   (i32.const 1)
  )
  (global.set $global185
   (struct.new_default $type33)
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global199
   (struct.new_default $type54)
  )
  (global.set $ready199
   (i32.const 1)
  )
  (global.set $global265
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready265
   (i32.const 1)
  )
  (global.set $global266
   (struct.new_default $type55)
  )
  (global.set $ready266
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

