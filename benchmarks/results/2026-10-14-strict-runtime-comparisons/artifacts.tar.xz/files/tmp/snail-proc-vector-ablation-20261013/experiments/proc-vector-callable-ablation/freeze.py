"""Freeze preparation evidence and unexecuted commands for a later timing window."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
COMMIT = '7ff18c01f4fc5407826e4815b30394ed437b2440'

# ---- Source and tool identities ----


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def git_output(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True).strip()


def compiler_identity():
    commit = git_output('rev-parse', 'HEAD')
    if commit != COMMIT or git_output('diff', '--name-only', '--', 'src', 'scripts/build-strict', 'tests/build-strict-program.scm'):
        raise ValueError('expected the untouched frozen compiler')
    files = git_output('ls-files', 'src', 'scripts/build-strict', 'tests/build-strict-program.scm').splitlines()
    return dict(commit=commit, tracked_source_hashes={name: digest(ROOT / name) for name in files})


def tool_identity(name, executable, version_flag):
    path = Path(executable).resolve()
    result = subprocess.run([str(path), version_flag], text=True, capture_output=True)
    return dict(name=name, path=str(path), sha256=digest(path), version_command=[str(path), version_flag],
                returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)


def tool_identities():
    names = ('chibi-scheme', 'node', 'wasm-as', 'wasm-opt', 'wasm-dis')
    return [tool_identity(name, shutil.which(name), '-V' if name == 'chibi-scheme' else '--version')
            for name in names] + [tool_identity('python', sys.executable, '--version')]

# ---- A handoff, with no workload execution ----


def timing_handoff():
    node = Path(shutil.which('node')).resolve()
    systems = {name: dict(artifact=str(HERE / name / 'strict.wasm'), sha256=digest(HERE / name / 'strict.wasm'),
                         command=[str(node), str(HERE / 'host.mjs'), str(HERE / name / 'strict.wasm'), str(HERE / 'spec.json')])
               for name in ('baseline', 'variant')}
    return dict(status='Prepared, unexecuted; pending fresh review and a coordinated quiet timing window.',
                cwd=str(ROOT), node=str(node), host=str(HERE / 'host.mjs'), host_sha256=digest(HERE / 'host.mjs'),
                spec=str(HERE / 'spec.json'), spec_sha256=digest(HERE / 'spec.json'),
                contract=json.loads((HERE / 'spec.json').read_text()), systems=systems,
                timing_driver=None, publication='Manual mechanism ablation; no production changes or clean measurements.')


def verify_correctness_records():
    files = [path for path in (HERE / 'commands').glob('*.json') if path.name.startswith(('small-', 'full-', 'contract-'))]
    if len(files) != 25 or any(json.loads(path.read_text())['returncode'] != 0 for path in files):
        raise ValueError('expected all 25 retained target correctness checks')
    return [str(path.relative_to(HERE)) for path in sorted(files)]


def manifest():
    files = [path for path in HERE.rglob('*') if path.is_file() and not path.is_symlink()
             and '__pycache__' not in path.parts and path.name != 'manifest.json']
    return dict(kind='Frozen manual mechanism ablation; no clean benchmark result.', compiler_commit=COMMIT,
                files={str(path.relative_to(HERE)): digest(path) for path in sorted(files)})


def main():
    compiler = compiler_identity()
    compiler['inherited_tool_options'] = {name: os.environ.get(name) for name in
                                        ('CHIBI', 'WASM_AS', 'WASM_OPT', 'WASM_DIS', 'NODE_OPTIONS')}
    compiler['tools'] = tool_identities()
    write_json('compiler-identities.json', compiler)
    write_json('correctness-summary.json', dict(passed=25, records=verify_correctness_records(), independent_review='pending'))
    write_json('next-window.json', timing_handoff())
    write_json('manifest.json', manifest())
    print('Frozen', len(json.loads((HERE / 'manifest.json').read_text())['files']), 'regular files; no workload commands executed.')


if __name__ == '__main__':
    main()
