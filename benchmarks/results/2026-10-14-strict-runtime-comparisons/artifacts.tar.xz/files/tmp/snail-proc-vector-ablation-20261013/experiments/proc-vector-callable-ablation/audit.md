# Callable specialization audit at 7ff18c0

A higher-order actual contributes its concrete `Function` argument/result
signature to specialization, without its closure/code identity or capture
layout. The complete specialization key is richer than a public signature:
within each concrete lexical site it contains the concrete type and required
quantified substitutions used by the body, captures, and class evidence.
See [`instance-substitutions` and `request-value`](audit-source/strict-specialize.sld#L105).
[`Function`](audit-source/strict-types.sld#L101) contains domains, rest type, and
result. This is typed monomorphization; it does not propagate an actual
callback's identity through a formal parameter.

Captured storage is concrete. Each code record has an individually typed
environment, while a signature-specific closure wrapper stores a code reference
and an `eqref` environment. See [closure emission](audit-source/strict-wasm.sld#L233).
Parameters have no closure initializer, so the backend's
[`known-function`](audit-source/strict-wasm.sld#L429) cannot recover their actual
code. Local call-only procedures have a separate direct convention carrying
captures and readiness state explicitly. This convention, identity propagation,
and body inlining are distinct operations.

The canonical optimized graphs module still shows the following paths. The
[source map](baseline/function-map.scm), [static structure](structure.json), and
frozen source identify code records independently of physical type numbers.

| Source operation | Callable alternatives | Optimized behavior |
| --- | --- | --- |
| `proc->vector`, vector of lists | `giota` (`$function27`, no captures) and edges-copy callback (`$function81`, captured vector) | `$function30`/`$function36` retain `$call33` indirect dispatch; see [WAT line 594](baseline/strict.optimized.wat#L594). |
| `proc->vector`, Boolean matrix | Initial row (`$function68`, size capture) and reachability row (`$function51`, size and outgoing-edge-vector captures) | `$function54`/`$function60` retain `$call35`; see [WAT line 2693](baseline/strict.optimized.wat#L2693). |
| `gnatural-for-each` and `list-for-each` in `make-reach?` | `$function52`, `$function61`, `$function62`, `$function63`, all `(-> I64 Unit)` with different captures | `$call28` survives in shared and inlined loops; see [list traversal](baseline/strict.optimized.wat#L2603) and [natural-number loop](baseline/strict.optimized.wat#L3606). |

Binaryen has already resolved some unique callees. Raw `call_ref` counts therefore
overstate the remaining opportunity. In particular, `deeper` has one reachable
body: Binaryen removes its code pointer and emits a direct call, while its
wrapper and environment survive. See [creation and invocation](baseline/strict.optimized.wat#L1627).

Existing combined diagnostics count 491,303,784 completed construction
instructions after setup. `$function44` and `$function46` account for
427,411,794, or 86.9954%, in the permutation continuation creation/resumption
path. Those instructions include wrappers, environments, readiness cells, and
list nodes. They are not native allocator events or bytes. The retained
[metadata and raw counters](audit-counters/counted.json),
[summary](audit-counter-summary.json), and
[derived observations](audit-observations.json) reproduce the attribution.
The diagnostic's original WAT hash equals the canonical optimized WAT hash.

`accross` selects the identity continuation or `$function46` according to
runtime traversal state. Its environment captures the preceding continuation:
see [WAT line 1608](baseline/strict.optimized.wat#L1608) and the
[source continuation tree](baseline/strict.scm#L216).
Devirtualizing a callback does not establish that this chain can disappear.
Keying on fully nested actual capture identities can grow specialization variants
across recursion. A finite descriptor must reuse code/capture schemas and retain
unknown or runtime-selected flows; eliminating the chain requires additional
control-flow and lifetime reasoning.

The two Boolean-matrix generator wrappers/environments account for 150,678
completions in that existing diagnostic. Their `$call35` generator invocations
account for 452,037 reached indirect calls. These counts help bound this selected
mechanism; they are not observations of the ablation or predictions of its clean
runtime. The current manual experiment deliberately leaves the dominant
continuation path alone.

The reported combined graphs median is 1.824846 seconds, adapted Chez 0.785504,
and Rust/Wasm 0.588629. The prior combined changes improved workload time 52.5%
and removed approximately two thirds of instrumented constructor completions.
These are existing results, not new ablation timings. Rust's
[explicit permutation recursion](audit-source/rust-graphs.rs#L81) and
[reachability loops](audit-source/rust-graphs.rs#L155) differ from the Scheme CPS
and callback source. The comparison does not isolate Rust callable traits or
prove that a new language feature is needed. Mperm's separate GC profile does
not establish the graphs bottleneck.

| Frozen identity | SHA-256 or commit |
| --- | --- |
| Compiler commit | `7ff18c01f4fc5407826e4815b30394ed437b2440` |
| Canonical strict source | `99c72152dfead34e40d8ad17e5d1cba5f99b96a16dd2a84b5df0d6a488a1d473` |
| Canonical optimized Wasm | `59b82bed680c003b92cf543be8d8658a7ab611fdb0e6dbb6de814698062a3196` |
| Canonical optimized WAT | `8298a5ffdf1533c369317891544aefb4fdb5f1b1085d6b40e61d4d44f86f3c7c` |

The canonical strict source also matches the frozen enumeration-preparation
source. [Input provenance](input-provenance.json) records exact original paths
and hashes; [the manifest](manifest.json) covers the copied audit source,
artifacts, counters, reports, and tools. The audit used an isolated worktree at
the frozen commit and did not edit the compiler, canonical adapter, or canonical
graphs source.
