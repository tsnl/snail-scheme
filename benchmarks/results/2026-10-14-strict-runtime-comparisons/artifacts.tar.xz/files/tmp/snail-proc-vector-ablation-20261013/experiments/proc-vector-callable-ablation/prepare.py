"""Prepare the bounded manual callable ablation from frozen local inputs."""

from pathlib import Path
import difflib
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / 'benchmarks/strict-suite'))
from data_ports import form
INITIAL = '''(proc->vector size
                          (lambda (from)
                            (make-vector size #f)))'''
REACH = '''(proc->vector size
                         (lambda (v)
                           (let ((from-v
                                  (make-vector size #f)))
                             (vector-set! from-v v #t)
                             (list-for-each
                              (lambda (x)
                                (vector-set! from-v x #t))
                              (vector-ref vertex->out v))
                             from-v)))'''

# ---- Two exact call-site replacements ----


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError('expected one exact occurrence of call site')
    return source.replace(old, new)


def specialize_source(source):
    source = replace_once(source, INITIAL, '(initial-boolean-matrix size)')
    source = replace_once(source, REACH, '(reachability-matrix size vertex->out)')
    marker = ';;; GRAPHS -- Obtained from Andrew Wright.'
    return replace_once(source, marker, (HERE / 'helpers.scm').read_text() + '\n' + marker)


def write_variant(source_path, output_path):
    original = source_path.read_text()
    variant = specialize_source(original)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(variant)
    patch = difflib.unified_diff(original.splitlines(True), variant.splitlines(True),
                                 fromfile=str(source_path.relative_to(HERE)),
                                 tofile=str(output_path.relative_to(HERE)))
    output_path.with_suffix('.patch').write_text(''.join(patch))
    return dict(path=str(output_path.relative_to(HERE)), sha256=hashlib.sha256(variant.encode()).hexdigest())


def write_contracts():
    source = (HERE / 'baseline/strict.scm').read_text()
    markers = ('(define (integer-zero?', '(define (list-for-each', '(define proc->vector')
    prelude = '(import (snail strict))\n' + '\n'.join(form(source, marker) for marker in markers)
    (HERE / 'contracts.scm').write_text(prelude + '\n' + (HERE / 'helpers.scm').read_text()
                                      + '\n' + (HERE / 'contracts-body.scm').read_text())
    for size in (0, 1, 3):
        specification = dict(name='matrix-contract', count=size, inputs=[], expected=1,
                             barriers_per_iteration=0, setup_barriers=0, export='contract-probe')
        (HERE / f'contracts-{size}.json').write_text(json.dumps(specification, indent=2) + '\n')


def main():
    variants = [write_variant(HERE / 'baseline/strict.scm', HERE / 'variant/strict.scm'),
                write_variant(HERE / 'probe/baseline.scm', HERE / 'probe/strict.scm')]
    (HERE / 'source-identities.json').write_text(json.dumps(variants, indent=2) + '\n')
    write_contracts()


if __name__ == '__main__':
    main()
