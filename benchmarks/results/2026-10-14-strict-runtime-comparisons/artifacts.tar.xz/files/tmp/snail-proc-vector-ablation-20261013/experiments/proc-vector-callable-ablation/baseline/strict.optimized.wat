(module
 (rec
  (type $0 (func (param i32 i32 (ref null $type24) i64) (result i64)))
  (type $type51 (struct))
  (type $2 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $3 (func (param i64 i64 (ref $type51) i64 (ref $type18) (ref $type14) (ref $type48) (ref $type25) (ref $type8) i32 i32 i64 (ref $type17) i32 i32 i64 i64 (ref null $type24)) (result (ref null $type24))))
  (type $4 (func (param i64 (ref $type25) i32 i32 i64) (result i32)))
  (type $5 (func (param (ref $type39) i32 i32 (ref null $type16)) (result i32)))
  (type $environment76 (struct (field i64)))
  (type $type39 (struct (field (ref $environment76))))
  (type $type8 (struct (field (ref $call8)) (field (ref $environment71))))
  (type $environment75 (struct (field (ref null $type16))))
  (type $type16 (struct (field (ref $type17)) (field (ref null $type16))))
  (type $11 (func (param i64 i64 (ref $type51) i64 (ref $type14) (ref $type8) (ref $type18) (ref $type17) i32 i32 i64 i64 (ref null $type13) (ref null $type16) (ref null $type24)) (result (ref null $type24))))
  (type $type24 (struct (field (ref null $type24))))
  (type $13 (func (param i64 i64 (ref $type51) i64 (ref $type18) (ref $type14) (ref $type48) (ref $type25) (ref $type8) i32 i32 i64 (ref null $type24)) (result (ref null $type24))))
  (type $environment72 (struct (field i64) (field (ref $type18))))
  (type $environment71 (struct (field i64) (field (ref $type18)) (field (ref $type46)) (field (ref $type47))))
  (type $call8 (func (param (ref $environment71)) (result i32)))
  (type $type46 (struct (field (ref $environment37))))
  (type $environment69 (struct (field (ref $type18)) (field (ref $type46)) (field (ref $type47))))
  (type $environment68 (struct (field i64)))
  (type $20 (func (param i64 (ref $type28) i32 i32 i64) (result i32)))
  (type $environment63 (struct (field (ref $type17)) (field (ref $type17))))
  (type $environment62 (struct (field i64) (field (ref $type18)) (field i64) (field (ref $type17))))
  (type $23 (func (param i64 (ref $type35) (ref $type18) i32 i32 i64) (result i32)))
  (type $24 (func (param i64 (ref $type35)) (result (ref $type18))))
  (type $call27 (func (param (ref $type28) (ref null $type13)) (result i32)))
  (type $environment52 (struct (field (ref $type17))))
  (type $call35 (func (param (ref struct) i64) (result (ref $type17))))
  (type $call28 (func (param (ref struct) i64) (result i32)))
  (type $environment61 (struct (field i64) (field (ref $type18))))
  (type $type35 (struct (field (ref $call35)) (field (ref struct))))
  (type $environment51 (struct (field i64) (field (ref $type14))))
  (type $type28 (struct (field (ref $call28)) (field (ref struct))))
  (type $call52 (func (param i64 (ref $type14)) (result (ref $type18))))
  (type $34 (func (param (ref $type31) i32 i32 (ref null $type13) (ref $type13)) (result (ref null $type13))))
  (type $environment46 (struct (field (ref $type41)) (field (ref $type44)) (field (ref $type55)) (field i64) (field (ref $type43)) (field (ref $type55)) (field (ref null $type13)) (field i64) (field (ref null $type13))))
  (type $call47 (func (param (ref null $environment72) (ref $type48) (ref $type43)) (result i32)))
  (type $type47 (struct (field (ref $call47)) (field (ref null $environment72))))
  (type $38 (func (param (ref $type41) (ref $type44) (ref $type55) (ref null $type13) i64 i32 (ref $type43)) (result i32)))
  (type $type17 (array (mut i32)))
  (type $40 (func (param (ref $type18) (ref $type48) i64 i64 (ref $type17) (ref $type17) i32 i32 i64) (result i64)))
  (type $call43 (func (param (ref null $environment46) i32) (result i32)))
  (type $type31 (struct))
  (type $type42 (struct (field (ref $environment47))))
  (type $type18 (array (mut (ref $type17))))
  (type $environment47 (struct (field (ref $type41)) (field (ref $type44)) (field (ref $type55)) (field (ref null $type13)) (field (ref null $type13)) (field (ref $type43))))
  (type $call41 (func (param (ref $environment38) i64 i64 i32 (ref $type42) (ref $type43)) (result i32)))
  (type $type43 (struct (field (ref $call43)) (field (ref null $environment46))))
  (type $environment41 (struct (field (ref $type48)) (field (ref $type47))))
  (type $environment37 (struct (field (ref $type14)) (field (ref $type48))))
  (type $environment38 (struct (field (ref $type48)) (field (ref $type18))))
  (type $type55 (struct (field i32)))
  (type $type44 (struct (field (ref $environment41))))
  (type $type41 (struct (field (ref $environment38))))
  (type $type48 (array (mut i64)))
  (type $call46 (func (param (ref $environment37) i64 (ref $type18) (ref $type47)) (result i32)))
  (type $56 (func (param i64 (ref $type33) (ref $type14) i32 i32 i64) (result i32)))
  (type $environment81 (struct (field (ref $type14))))
  (type $type14 (array (mut (ref null $type13))))
  (type $59 (func (param i64 (ref $type33)) (result (ref $type14))))
  (type $call25 (func (param structref i64) (result i32)))
  (type $61 (func (param i32 i32 i64 (ref $type13)) (result (ref null $type13))))
  (type $type13 (struct (field i64) (field (ref null $type13))))
  (type $call33 (func (param (ref null $environment81) i64) (result (ref null $type13))))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type45 (struct))
  (type $type40 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type33 (struct (field (ref $call33)) (field (ref null $environment81))))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (ref $call25)) (field structref)))
  (type $type23 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type15 (struct))
  (type $type11 (struct))
 )
 (type $87 (func (param i64) (result i64)))
 (type $88 (func (param i32) (result i64)))
 (type $89 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type11)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type15)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global80 (mut (ref null $type19)) (ref.null none))
 (global $ready80 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type20)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global264 (mut (ref null $type23)) (ref.null none))
 (global $ready264 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type25)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type26)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global156 (mut (ref null $type27)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type29)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type30)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global75 (mut (ref null $type32)) (ref.null none))
 (global $ready75 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type34)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global67 (mut (ref null $type33)) (ref.null none))
 (global $ready67 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type36)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type37)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global229 (mut (ref null $type38)) (ref.null none))
 (global $ready229 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type40)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global64 (mut (ref null $type45)) (ref.null none))
 (global $ready64 (mut i32) (i32.const 0))
 (global $global105 (mut (ref null $type49)) (ref.null none))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type50)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type52)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type53)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global255 (mut i64) (i64.const 0))
 (global $ready255 (mut i32) (i32.const 0))
 (global $global256 (mut (ref null $type54)) (ref.null none))
 (global $ready256 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function27 (type $call33) (param $0 (ref null $environment81)) (param $1 i64) (result (ref null $type13))
  (local $2 (ref $type13))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref null $type13))
   (i64.eqz
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready72)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global72)
     )
    )
    (local.set $2
     (struct.new $type13
      (local.tee $1
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (ref.null none)
     )
    )
    (if (result (ref $type13))
     (i64.eqz
      (local.get $1)
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready72)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type25 1
        (global.get $global72)
       )
      )
      (local.set $2
       (struct.new $type13
        (local.tee $1
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
      )
      (if (result (ref $type13))
       (i64.eqz
        (local.get $1)
       )
       (then
        (local.get $2)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready72)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (struct.get $type25 1
          (global.get $global72)
         )
        )
        (local.set $2
         (struct.new $type13
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
        )
        (if (result (ref $type13))
         (i64.eqz
          (local.get $1)
         )
         (then
          (local.get $2)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready72)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (struct.get $type25 1
            (global.get $global72)
           )
          )
          (local.set $2
           (struct.new $type13
            (local.tee $1
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
            (local.get $2)
           )
          )
          (if (result (ref $type13))
           (i64.eqz
            (local.get $1)
           )
           (then
            (local.get $2)
           )
           (else
            (if
             (i32.eqz
              (global.get $ready72)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (struct.get $type25 1
              (global.get $global72)
             )
            )
            (local.set $2
             (struct.new $type13
              (local.tee $1
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
              (local.get $2)
             )
            )
            (if (result (ref $type13))
             (i64.eqz
              (local.get $1)
             )
             (then
              (local.get $2)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready72)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (struct.get $type25 1
                (global.get $global72)
               )
              )
              (local.set $2
               (struct.new $type13
                (local.tee $1
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (local.get $2)
               )
              )
              (if (result (ref $type13))
               (i64.eqz
                (local.get $1)
               )
               (then
                (local.get $2)
               )
               (else
                (if
                 (i32.eqz
                  (global.get $ready72)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (struct.get $type25 1
                  (global.get $global72)
                 )
                )
                (local.set $2
                 (struct.new $type13
                  (local.tee $1
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (local.get $2)
                 )
                )
                (if (result (ref $type13))
                 (i64.eqz
                  (local.get $1)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (if
                   (i32.eqz
                    (global.get $ready72)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (struct.get $type25 1
                    (global.get $global72)
                   )
                  )
                  (local.set $2
                   (struct.new $type13
                    (local.tee $1
                     (i64.sub
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                    (local.get $2)
                   )
                  )
                  (if (result (ref $type13))
                   (i64.eqz
                    (local.get $1)
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (if
                     (i32.eqz
                      (global.get $ready72)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $2
                     (struct.new $type13
                      (local.tee $1
                       (i64.sub
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (local.get $2)
                     )
                    )
                    (if (result (ref $type13))
                     (call $function29
                      (struct.get $type25 1
                       (global.get $global72)
                      )
                      (local.get $1)
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (return_call $function28
                       (i32.const 0)
                       (i32.const 1)
                       (local.tee $1
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (struct.new $type13
                        (local.get $1)
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function28 (type $61) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref $type13)) (result (ref null $type13))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type13))
   (call $function29
    (struct.get $type25 1
     (global.get $global72)
    )
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function28
     (local.get $0)
     (local.get $1)
     (local.tee $2
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
     )
     (struct.new $type13
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function29 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function30 (type $59) (param $0 i64) (param $1 (ref $type33)) (result (ref $type14))
  (local $2 (ref $type14))
  (local $3 (ref null $environment81))
  (local $4 (ref $call33))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global78)
     )
    )
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global80)
     )
    )
    (array.new_fixed $type14 0)
   )
   (else
    (local.set $2
     (array.new $type14
      (call_ref $call33
       (struct.get $type33 1
        (local.get $1)
       )
       (i64.const 0)
       (struct.get $type33 0
        (local.get $1)
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.get $0)
       (i64.const 1)
      )
      (then
       (array.set $type14
        (local.get $2)
        (i32.const 1)
        (call_ref $call33
         (local.tee $3
          (struct.get $type33 1
           (local.get $1)
          )
         )
         (i64.const 1)
         (local.tee $4
          (struct.get $type33 0
           (local.get $1)
          )
         )
        )
       )
       (if (result i32)
        (i64.gt_s
         (local.get $0)
         (i64.const 2)
        )
        (then
         (array.set $type14
          (local.get $2)
          (i32.const 2)
          (call_ref $call33
           (local.get $3)
           (i64.const 2)
           (local.get $4)
          )
         )
         (if (result i32)
          (i64.gt_s
           (local.get $0)
           (i64.const 3)
          )
          (then
           (array.set $type14
            (local.get $2)
            (i32.const 3)
            (call_ref $call33
             (local.get $3)
             (i64.const 3)
             (local.get $4)
            )
           )
           (if (result i32)
            (i64.gt_s
             (local.get $0)
             (i64.const 4)
            )
            (then
             (array.set $type14
              (local.get $2)
              (i32.const 4)
              (call_ref $call33
               (local.get $3)
               (i64.const 4)
               (local.get $4)
              )
             )
             (if (result i32)
              (i64.gt_s
               (local.get $0)
               (i64.const 5)
              )
              (then
               (array.set $type14
                (local.get $2)
                (i32.const 5)
                (call_ref $call33
                 (local.get $3)
                 (i64.const 5)
                 (local.get $4)
                )
               )
               (if (result i32)
                (i64.gt_s
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (array.set $type14
                  (local.get $2)
                  (i32.const 6)
                  (call_ref $call33
                   (local.get $3)
                   (i64.const 6)
                   (local.get $4)
                  )
                 )
                 (if (result i32)
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (array.set $type14
                    (local.get $2)
                    (i32.const 7)
                    (call_ref $call33
                     (local.get $3)
                     (i64.const 7)
                     (local.get $4)
                    )
                   )
                   (if (result i32)
                    (i64.gt_s
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (array.set $type14
                      (local.get $2)
                      (i32.const 8)
                      (call_ref $call33
                       (local.get $3)
                       (i64.const 8)
                       (local.get $4)
                      )
                     )
                     (if (result i32)
                      (i64.gt_s
                       (local.get $0)
                       (i64.const 9)
                      )
                      (then
                       (array.set $type14
                        (local.get $2)
                        (i32.const 9)
                        (call_ref $call33
                         (local.get $3)
                         (i64.const 9)
                         (local.get $4)
                        )
                       )
                       (if (result i32)
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 10)
                        )
                        (then
                         (array.set $type14
                          (local.get $2)
                          (i32.const 10)
                          (call_ref $call33
                           (local.get $3)
                           (i64.const 10)
                           (local.get $4)
                          )
                         )
                         (call $function36
                          (local.get $0)
                          (local.get $1)
                          (local.get $2)
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 11)
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.get $2)
   )
  )
 )
 (func $function36 (type $56) (param $0 i64) (param $1 (ref $type33)) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 (ref null $type13))
  (if (result i32)
   (i64.gt_s
    (local.get $0)
    (local.get $5)
   )
   (then
    (local.set $6
     (call_ref $call33
      (struct.get $type33 1
       (local.get $1)
      )
      (local.get $5)
      (struct.get $type33 0
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $2)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function36
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function37 (type $call46) (param $0 (ref $environment37)) (param $1 i64) (param $2 (ref $type18)) (param $3 (ref $type47)) (result i32)
  (local $4 (ref null $type13))
  (local $5 (ref $type48))
  (local $6 (ref $type41))
  (local $7 (ref $type55))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (array.get $type14
    (struct.get $environment37 0
     (local.get $0)
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (return_call $function44
   (struct.new $type41
    (struct.new $environment38
     (local.tee $5
      (struct.get $environment37 1
       (local.get $0)
      )
     )
     (local.get $2)
    )
   )
   (block (result (ref (exact $type44)))
    (local.set $7
     (struct.new $type55
      (i32.const 1)
     )
    )
    (struct.new $type44
     (struct.new $environment41
      (local.get $5)
      (local.get $3)
     )
    )
   )
   (local.get $7)
   (local.get $4)
   (i64.const 0)
   (i32.const 1)
   (struct.new $type43
    (ref.func $function43)
    (ref.null none)
   )
  )
 )
 (func $function38 (type $call41) (param $0 (ref $environment38)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 (ref $type42)) (param $5 (ref $type43)) (result i32)
  (local $6 (ref null $type13))
  (local $7 (ref null $type13))
  (local $8 (ref $type13))
  (local $9 (ref $environment47))
  (local $10 (ref $type18))
  (local $11 i64)
  (if
   (i32.eqz
    (global.get $ready105)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global105)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $11
     (call $function40
      (local.tee $10
       (struct.get $environment38 1
        (local.get $0)
       )
      )
      (struct.get $environment38 0
       (local.get $0)
      )
      (local.get $2)
      (local.get $1)
      (array.get $type18
       (local.get $10)
       (i32.wrap_i64
        (local.get $2)
       )
      )
      (array.get $type18
       (local.get $10)
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eq
      (local.get $11)
      (i64.const 1)
     )
     (then
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type48
       (struct.get $environment38 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $1)
      )
      (if
       (i32.eqz
        (global.get $ready142)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global142)
       )
      )
      (local.set $6
       (struct.get $environment47 3
        (local.tee $9
         (struct.get $type42 0
          (local.get $4)
         )
        )
       )
      )
      (local.set $7
       (struct.get $environment47 4
        (local.get $9)
       )
      )
      (return_call $function44
       (struct.get $environment47 0
        (local.get $9)
       )
       (struct.get $environment47 1
        (local.get $9)
       )
       (struct.get $environment47 2
        (local.get $9)
       )
       (if (result (ref null $type13))
        (ref.is_null
         (local.get $6)
        )
        (then
         (local.get $7)
        )
        (else
         (local.set $8
          (struct.new $type13
           (struct.get $type13 0
            (local.get $6)
           )
           (local.get $7)
          )
         )
         (if (result (ref null $type13))
          (ref.is_null
           (local.tee $6
            (struct.get $type13 1
             (local.get $6)
            )
           )
          )
          (then
           (local.get $8)
          )
          (else
           (local.set $8
            (struct.new $type13
             (struct.get $type13 0
              (local.get $6)
             )
             (local.get $8)
            )
           )
           (if (result (ref null $type13))
            (ref.is_null
             (local.tee $6
              (struct.get $type13 1
               (local.get $6)
              )
             )
            )
            (then
             (local.get $8)
            )
            (else
             (local.set $8
              (struct.new $type13
               (struct.get $type13 0
                (local.get $6)
               )
               (local.get $8)
              )
             )
             (if (result (ref null $type13))
              (ref.is_null
               (local.tee $6
                (struct.get $type13 1
                 (local.get $6)
                )
               )
              )
              (then
               (local.get $8)
              )
              (else
               (local.set $8
                (struct.new $type13
                 (struct.get $type13 0
                  (local.get $6)
                 )
                 (local.get $8)
                )
               )
               (if (result (ref null $type13))
                (ref.is_null
                 (local.tee $6
                  (struct.get $type13 1
                   (local.get $6)
                  )
                 )
                )
                (then
                 (local.get $8)
                )
                (else
                 (local.set $8
                  (struct.new $type13
                   (struct.get $type13 0
                    (local.get $6)
                   )
                   (local.get $8)
                  )
                 )
                 (if (result (ref null $type13))
                  (ref.is_null
                   (local.tee $6
                    (struct.get $type13 1
                     (local.get $6)
                    )
                   )
                  )
                  (then
                   (local.get $8)
                  )
                  (else
                   (local.set $8
                    (struct.new $type13
                     (struct.get $type13 0
                      (local.get $6)
                     )
                     (local.get $8)
                    )
                   )
                   (if (result (ref null $type13))
                    (ref.is_null
                     (local.tee $6
                      (struct.get $type13 1
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (local.get $8)
                    )
                    (else
                     (local.set $8
                      (struct.new $type13
                       (struct.get $type13 0
                        (local.get $6)
                       )
                       (local.get $8)
                      )
                     )
                     (if (result (ref null $type13))
                      (ref.is_null
                       (local.tee $6
                        (struct.get $type13 1
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (local.get $8)
                      )
                      (else
                       (local.set $8
                        (struct.new $type13
                         (struct.get $type13 0
                          (local.get $6)
                         )
                         (local.get $8)
                        )
                       )
                       (if (result (ref null $type13))
                        (ref.is_null
                         (local.tee $6
                          (struct.get $type13 1
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (local.get $8)
                        )
                        (else
                         (call $function49
                          (struct.new_default $type31)
                          (i32.const 0)
                          (i32.const 1)
                          (struct.get $type13 1
                           (local.get $6)
                          )
                          (struct.new $type13
                           (struct.get $type13 0
                            (local.get $6)
                           )
                           (local.get $8)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
       (local.get $3)
       (struct.get $environment47 5
        (local.get $9)
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $11)
        (i64.const 2)
       )
       (then
        (return_call_ref $call43
         (struct.get $type43 1
          (local.get $5)
         )
         (local.get $3)
         (struct.get $type43 0
          (local.get $5)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function40 (type $40) (param $0 (ref $type18)) (param $1 (ref $type48)) (param $2 i64) (param $3 i64) (param $4 (ref $type17)) (param $5 (ref $type17)) (param $6 i32) (param $7 i32) (param $8 i64) (result i64)
  (local $9 i32)
  (local $10 i32)
  (local $11 i64)
  (if (result i64)
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type17
      (local.get $4)
      (i32.wrap_i64
       (local.get $8)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (array.get $type48
        (local.get $1)
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (array.get $type17
      (local.get $5)
      (i32.wrap_i64
       (local.get $11)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if (result i64)
     (select
      (local.get $10)
      (i32.eqz
       (local.get $10)
      )
      (local.get $9)
     )
     (then
      (if
       (i64.gt_u
        (local.get $8)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $9
       (array.get $type17
        (array.get $type18
         (local.get $0)
         (i32.wrap_i64
          (local.get $8)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $10
       (array.get $type17
        (array.get $type18
         (local.get $0)
         (i32.wrap_i64
          (local.get $11)
         )
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if (result i64)
       (select
        (local.get $10)
        (i32.eqz
         (local.get $10)
        )
        (local.get $9)
       )
       (then
        (if
         (i32.eqz
          (local.get $7)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function40
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $4)
         (local.get $5)
         (local.get $6)
         (local.get $7)
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (else
        (select
         (i64.const 0)
         (i64.const 2)
         (local.get $9)
        )
       )
      )
     )
     (else
      (select
       (i64.const 0)
       (i64.const 2)
       (local.get $9)
      )
     )
    )
   )
  )
 )
 (func $function43 (type $call43) (param $0 (ref null $environment46)) (param $1 i32) (result i32)
  (local.get $1)
 )
 (func $function44 (type $38) (param $0 (ref $type41)) (param $1 (ref $type44)) (param $2 (ref $type55)) (param $3 (ref null $type13)) (param $4 i64) (param $5 i32) (param $6 (ref $type43)) (result i32)
  (local $7 i64)
  (local $8 (ref $environment41))
  (local $9 (ref $type47))
  (if
   (ref.is_null
    (local.get $3)
   )
   (then
    (return_call_ref $call47
     (struct.get $type47 1
      (local.tee $9
       (struct.get $environment41 1
        (local.tee $8
         (struct.get $type44 0
          (local.get $1)
         )
        )
       )
      )
     )
     (struct.get $environment41 0
      (local.get $8)
     )
     (local.get $6)
     (struct.get $type47 0
      (local.get $9)
     )
    )
   )
   (else
    (local.set $7
     (struct.get $type13 0
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (ref.is_null
       (local.tee $3
        (struct.get $type13 1
         (local.get $3)
        )
       )
      )
     )
     (then
      (local.set $6
       (struct.new $type43
        (ref.func $function46)
        (struct.new $environment46
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $4)
         (local.get $6)
         (struct.new $type55
          (i32.const 1)
         )
         (ref.null none)
         (local.get $7)
         (local.get $3)
        )
       )
      )
     )
    )
    (return_call $function38
     (struct.get $type41 0
      (local.get $0)
     )
     (local.get $7)
     (local.get $4)
     (local.get $5)
     (struct.new $type42
      (struct.new $environment47
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (ref.null none)
       (local.get $3)
       (local.get $6)
      )
     )
     (local.get $6)
    )
   )
  )
  (unreachable)
 )
 (func $function46 (type $call43) (param $0 (ref null $environment46)) (param $1 i32) (result i32)
  (local $2 (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 (ref $type43))
  (local $5 (ref $type41))
  (local $6 (ref $type44))
  (local $7 (ref $type55))
  (local $8 (ref $type55))
  (local $9 (ref $type13))
  (local $10 i64)
  (local $11 i64)
  (local $scratch (ref null $type13))
  (local.set $2
   (struct.get $environment46 8
    (local.get $0)
   )
  )
  (local.set $9
   (struct.new $type13
    (struct.get $environment46 7
     (local.get $0)
    )
    (block (result (ref null $type13))
     (local.set $scratch
      (struct.get $environment46 6
       (local.get $0)
      )
     )
     (drop
      (struct.get $environment46 5
       (local.get $0)
      )
     )
     (local.set $5
      (struct.get $environment46 0
       (local.get $0)
      )
     )
     (local.set $6
      (struct.get $environment46 1
       (local.get $0)
      )
     )
     (local.set $7
      (struct.get $environment46 2
       (local.get $0)
      )
     )
     (local.set $11
      (struct.get $environment46 3
       (local.get $0)
      )
     )
     (local.set $4
      (struct.get $environment46 4
       (local.get $0)
      )
     )
     (local.set $8
      (struct.get $environment46 5
       (local.get $0)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (local.set $10
   (struct.get $type13 0
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.tee $2
      (struct.get $type13 1
       (local.get $2)
      )
     )
    )
   )
   (then
    (local.set $4
     (struct.new $type43
      (ref.func $function46)
      (struct.new $environment46
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $11)
       (local.get $4)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $2)
      )
     )
    )
   )
  )
  (return_call $function38
   (struct.get $type41 0
    (local.get $5)
   )
   (local.get $10)
   (local.get $11)
   (local.get $1)
   (struct.new $type42
    (struct.new $environment47
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (local.get $2)
     (local.get $4)
    )
   )
   (local.get $4)
  )
 )
 (func $function49 (type $34) (param $0 (ref $type31)) (param $1 i32) (param $2 i32) (param $3 (ref null $type13)) (param $4 (ref $type13)) (result (ref null $type13))
  (local $5 (ref null $type13))
  (if (result (ref $type13))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (local.set $5
     (struct.get $type13 1
      (local.get $3)
     )
    )
    (local.set $4
     (struct.new $type13
      (struct.get $type13 0
       (local.get $3)
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $5)
     (local.get $4)
    )
   )
  )
 )
 (func $function50 (type $call52) (param $0 i64) (param $1 (ref $type14)) (result (ref $type18))
  (local $2 (ref $type28))
  (local $3 (ref $type18))
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global159)
   )
  )
  (local.set $3
   (call $function54
    (local.get $0)
    (struct.new $type35
     (ref.func $function51)
     (struct.new $environment51
      (local.get $0)
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (drop
   (if (result i32)
    (i64.eqz
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call28
       (struct.get $type28 1
        (local.tee $2
         (struct.new $type28
          (ref.func $function61)
          (struct.new $environment61
           (local.get $0)
           (local.get $3)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type28 0
        (local.get $2)
       )
      )
     )
     (if (result i32)
      (i64.eq
       (local.get $0)
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call28
         (struct.get $type28 1
          (local.get $2)
         )
         (i64.const 1)
         (struct.get $type28 0
          (local.get $2)
         )
        )
       )
       (if (result i32)
        (i64.eq
         (local.get $0)
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call28
           (struct.get $type28 1
            (local.get $2)
           )
           (i64.const 2)
           (struct.get $type28 0
            (local.get $2)
           )
          )
         )
         (if (result i32)
          (i64.eq
           (local.get $0)
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call28
             (struct.get $type28 1
              (local.get $2)
             )
             (i64.const 3)
             (struct.get $type28 0
              (local.get $2)
             )
            )
           )
           (if (result i32)
            (i64.eq
             (local.get $0)
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call28
               (struct.get $type28 1
                (local.get $2)
               )
               (i64.const 4)
               (struct.get $type28 0
                (local.get $2)
               )
              )
             )
             (if (result i32)
              (i64.eq
               (local.get $0)
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call28
                 (struct.get $type28 1
                  (local.get $2)
                 )
                 (i64.const 5)
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
               )
               (if (result i32)
                (i64.eq
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call28
                   (struct.get $type28 1
                    (local.get $2)
                   )
                   (i64.const 6)
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call28
                     (struct.get $type28 1
                      (local.get $2)
                     )
                     (i64.const 7)
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call28
                       (struct.get $type28 1
                        (local.get $2)
                       )
                       (i64.const 8)
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                     )
                     (call $function65
                      (local.get $0)
                      (local.get $2)
                      (i32.const 0)
                      (i32.const 1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $3)
 )
 (func $function51 (type $call35) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (local $2 (ref null $type13))
  (local $3 (ref $type28))
  (local $4 (ref $type17))
  (local $5 i64)
  (if
   (i64.gt_u
    (local.tee $5
     (struct.get $environment51 0
      (ref.cast (ref $environment51)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (local.tee $4
    (array.new_default $type17
     (i32.wrap_i64
      (local.get $5)
     )
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (array.get $type14
    (struct.get $environment51 1
     (ref.cast (ref $environment51)
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.get $2)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call28
       (struct.get $type28 1
        (local.tee $3
         (struct.new $type28
          (ref.func $function52)
          (struct.new $environment52
           (local.get $4)
          )
         )
        )
       )
       (struct.get $type13 0
        (local.get $2)
       )
       (struct.get $type28 0
        (local.get $3)
       )
      )
     )
     (local.set $2
      (struct.get $type13 1
       (local.get $2)
      )
     )
     (if
      (i32.eqz
       (global.get $ready156)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global156)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $2)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call28
         (struct.get $type28 1
          (local.get $3)
         )
         (struct.get $type13 0
          (local.get $2)
         )
         (struct.get $type28 0
          (local.get $3)
         )
        )
       )
       (local.set $2
        (struct.get $type13 1
         (local.get $2)
        )
       )
       (if
        (i32.eqz
         (global.get $ready156)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global156)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call28
           (struct.get $type28 1
            (local.get $3)
           )
           (struct.get $type13 0
            (local.get $2)
           )
           (struct.get $type28 0
            (local.get $3)
           )
          )
         )
         (local.set $2
          (struct.get $type13 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready156)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global156)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call28
             (struct.get $type28 1
              (local.get $3)
             )
             (struct.get $type13 0
              (local.get $2)
             )
             (struct.get $type28 0
              (local.get $3)
             )
            )
           )
           (local.set $2
            (struct.get $type13 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready156)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global156)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call28
               (struct.get $type28 1
                (local.get $3)
               )
               (struct.get $type13 0
                (local.get $2)
               )
               (struct.get $type28 0
                (local.get $3)
               )
              )
             )
             (local.set $2
              (struct.get $type13 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready156)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global156)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call28
                 (struct.get $type28 1
                  (local.get $3)
                 )
                 (struct.get $type13 0
                  (local.get $2)
                 )
                 (struct.get $type28 0
                  (local.get $3)
                 )
                )
               )
               (local.set $2
                (struct.get $type13 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready156)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global156)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call28
                   (struct.get $type28 1
                    (local.get $3)
                   )
                   (struct.get $type13 0
                    (local.get $2)
                   )
                   (struct.get $type28 0
                    (local.get $3)
                   )
                  )
                 )
                 (local.set $2
                  (struct.get $type13 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready156)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global156)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call28
                     (struct.get $type28 1
                      (local.get $3)
                     )
                     (struct.get $type13 0
                      (local.get $2)
                     )
                     (struct.get $type28 0
                      (local.get $3)
                     )
                    )
                   )
                   (local.set $2
                    (struct.get $type13 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready156)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global156)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call28
                       (struct.get $type28 1
                        (local.get $3)
                       )
                       (struct.get $type13 0
                        (local.get $2)
                       )
                       (struct.get $type28 0
                        (local.get $3)
                       )
                      )
                     )
                     (local.set $2
                      (struct.get $type13 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready156)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global156)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (call_ref $call28
                         (struct.get $type28 1
                          (local.get $3)
                         )
                         (struct.get $type13 0
                          (local.get $2)
                         )
                         (struct.get $type28 0
                          (local.get $3)
                         )
                        )
                       )
                       (local.set $2
                        (struct.get $type13 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready156)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global156)
                        )
                       )
                       (call $function53
                        (local.get $3)
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $4)
 )
 (func $function52 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (struct.get $environment52 0
    (ref.cast (ref $environment52)
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (i32.const 0)
 )
 (func $function53 (type $call27) (param $0 (ref $type28)) (param $1 (ref null $type13)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.get $0)
      )
      (struct.get $type13 0
       (local.get $1)
      )
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready156)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global156)
     )
    )
    (return_call $function53
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function54 (type $24) (param $0 i64) (param $1 (ref $type35)) (result (ref $type18))
  (local $2 (ref $type18))
  (local $3 (ref struct))
  (local $4 (ref $call35))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref $type18))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready162)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (i32.eqz
      (global.get $ready164)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (array.new_fixed $type18 0)
   )
   (else
    (local.set $2
     (array.new $type18
      (call_ref $call35
       (struct.get $type35 1
        (local.get $1)
       )
       (i64.const 0)
       (struct.get $type35 0
        (local.get $1)
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.get $0)
       (i64.const 1)
      )
      (then
       (array.set $type18
        (local.get $2)
        (i32.const 1)
        (call_ref $call35
         (local.tee $3
          (struct.get $type35 1
           (local.get $1)
          )
         )
         (i64.const 1)
         (local.tee $4
          (struct.get $type35 0
           (local.get $1)
          )
         )
        )
       )
       (if (result i32)
        (i64.gt_s
         (local.get $0)
         (i64.const 2)
        )
        (then
         (array.set $type18
          (local.get $2)
          (i32.const 2)
          (call_ref $call35
           (local.get $3)
           (i64.const 2)
           (local.get $4)
          )
         )
         (if (result i32)
          (i64.gt_s
           (local.get $0)
           (i64.const 3)
          )
          (then
           (array.set $type18
            (local.get $2)
            (i32.const 3)
            (call_ref $call35
             (local.get $3)
             (i64.const 3)
             (local.get $4)
            )
           )
           (if (result i32)
            (i64.gt_s
             (local.get $0)
             (i64.const 4)
            )
            (then
             (array.set $type18
              (local.get $2)
              (i32.const 4)
              (call_ref $call35
               (local.get $3)
               (i64.const 4)
               (local.get $4)
              )
             )
             (if (result i32)
              (i64.gt_s
               (local.get $0)
               (i64.const 5)
              )
              (then
               (array.set $type18
                (local.get $2)
                (i32.const 5)
                (call_ref $call35
                 (local.get $3)
                 (i64.const 5)
                 (local.get $4)
                )
               )
               (if (result i32)
                (i64.gt_s
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (array.set $type18
                  (local.get $2)
                  (i32.const 6)
                  (call_ref $call35
                   (local.get $3)
                   (i64.const 6)
                   (local.get $4)
                  )
                 )
                 (if (result i32)
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (array.set $type18
                    (local.get $2)
                    (i32.const 7)
                    (call_ref $call35
                     (local.get $3)
                     (i64.const 7)
                     (local.get $4)
                    )
                   )
                   (if (result i32)
                    (i64.gt_s
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (array.set $type18
                      (local.get $2)
                      (i32.const 8)
                      (call_ref $call35
                       (local.get $3)
                       (i64.const 8)
                       (local.get $4)
                      )
                     )
                     (if (result i32)
                      (i64.gt_s
                       (local.get $0)
                       (i64.const 9)
                      )
                      (then
                       (array.set $type18
                        (local.get $2)
                        (i32.const 9)
                        (call_ref $call35
                         (local.get $3)
                         (i64.const 9)
                         (local.get $4)
                        )
                       )
                       (if (result i32)
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 10)
                        )
                        (then
                         (array.set $type18
                          (local.get $2)
                          (i32.const 10)
                          (call_ref $call35
                           (local.get $3)
                           (i64.const 10)
                           (local.get $4)
                          )
                         )
                         (call $function60
                          (local.get $0)
                          (local.get $1)
                          (local.get $2)
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 11)
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.get $2)
   )
  )
 )
 (func $function60 (type $23) (param $0 i64) (param $1 (ref $type35)) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 (ref $type17))
  (if (result i32)
   (i64.gt_s
    (local.get $0)
    (local.get $5)
   )
   (then
    (local.set $6
     (call_ref $call35
      (struct.get $type35 1
       (local.get $1)
      )
      (local.get $5)
      (struct.get $type35 0
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type18
     (local.get $2)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function60
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function61 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type28))
  (local $3 (ref $environment61))
  (local $4 (ref $type18))
  (local $5 i64)
  (local.set $5
   (struct.get $environment61 0
    (local.tee $3
     (ref.cast (ref $environment61)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (local.set $2
   (struct.new $type28
    (ref.func $function62)
    (struct.new $environment62
     (struct.get $environment61 0
      (local.get $3)
     )
     (local.tee $4
      (struct.get $environment61 1
       (local.get $3)
      )
     )
     (local.get $1)
     (array.get $type18
      (local.get $4)
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.get $2)
      )
      (i64.const 0)
      (struct.get $type28 0
       (local.get $2)
      )
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $5)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (call_ref $call28
        (struct.get $type28 1
         (local.get $2)
        )
        (i64.const 1)
        (struct.get $type28 0
         (local.get $2)
        )
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $5)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (call_ref $call28
          (struct.get $type28 1
           (local.get $2)
          )
          (i64.const 2)
          (struct.get $type28 0
           (local.get $2)
          )
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $5)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (call_ref $call28
            (struct.get $type28 1
             (local.get $2)
            )
            (i64.const 3)
            (struct.get $type28 0
             (local.get $2)
            )
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $5)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (call_ref $call28
              (struct.get $type28 1
               (local.get $2)
              )
              (i64.const 4)
              (struct.get $type28 0
               (local.get $2)
              )
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $5)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (call_ref $call28
                (struct.get $type28 1
                 (local.get $2)
                )
                (i64.const 5)
                (struct.get $type28 0
                 (local.get $2)
                )
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $5)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (call_ref $call28
                  (struct.get $type28 1
                   (local.get $2)
                  )
                  (i64.const 6)
                  (struct.get $type28 0
                   (local.get $2)
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $5)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (call_ref $call28
                    (struct.get $type28 1
                     (local.get $2)
                    )
                    (i64.const 7)
                    (struct.get $type28 0
                     (local.get $2)
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $5)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (call_ref $call28
                      (struct.get $type28 1
                       (local.get $2)
                      )
                      (i64.const 8)
                      (struct.get $type28 0
                       (local.get $2)
                      )
                     )
                    )
                    (return_call $function65
                     (local.get $5)
                     (local.get $2)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function62 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type28))
  (local $3 (ref $environment62))
  (local $4 (ref $type17))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (array.get $type17
    (local.tee $4
     (array.get $type18
      (struct.get $environment62 1
       (local.tee $3
        (ref.cast (ref $environment62)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (block (result i32)
     (if
      (i64.gt_u
       (local.tee $1
        (struct.get $environment62 2
         (local.get $3)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (if (result i32)
     (i64.eqz
      (local.tee $1
       (struct.get $environment62 0
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (call_ref $call28
        (struct.get $type28 1
         (local.tee $2
          (struct.new $type28
           (ref.func $function63)
           (struct.new $environment63
            (struct.get $environment62 3
             (local.get $3)
            )
            (local.get $4)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type28 0
         (local.get $2)
        )
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (call_ref $call28
          (struct.get $type28 1
           (local.get $2)
          )
          (i64.const 1)
          (struct.get $type28 0
           (local.get $2)
          )
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 2)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (call_ref $call28
            (struct.get $type28 1
             (local.get $2)
            )
            (i64.const 2)
            (struct.get $type28 0
             (local.get $2)
            )
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 3)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (call_ref $call28
              (struct.get $type28 1
               (local.get $2)
              )
              (i64.const 3)
              (struct.get $type28 0
               (local.get $2)
              )
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 4)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (call_ref $call28
                (struct.get $type28 1
                 (local.get $2)
                )
                (i64.const 4)
                (struct.get $type28 0
                 (local.get $2)
                )
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 5)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (call_ref $call28
                  (struct.get $type28 1
                   (local.get $2)
                  )
                  (i64.const 5)
                  (struct.get $type28 0
                   (local.get $2)
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 6)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (call_ref $call28
                    (struct.get $type28 1
                     (local.get $2)
                    )
                    (i64.const 6)
                    (struct.get $type28 0
                     (local.get $2)
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 7)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (call_ref $call28
                      (struct.get $type28 1
                       (local.get $2)
                      )
                      (i64.const 7)
                      (struct.get $type28 0
                       (local.get $2)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 8)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (call_ref $call28
                        (struct.get $type28 1
                         (local.get $2)
                        )
                        (i64.const 8)
                        (struct.get $type28 0
                         (local.get $2)
                        )
                       )
                      )
                      (return_call $function65
                       (local.get $1)
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 9)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function63 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get $type17
    (struct.get $environment63 0
     (ref.cast (ref $environment63)
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $environment63 1
      (ref.cast (ref $environment63)
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
   )
  )
  (i32.const 0)
 )
 (func $function65 (type $20) (param $0 i64) (param $1 (ref $type28)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.get $1)
      )
      (local.get $4)
      (struct.get $type28 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function65
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function68 (type $call35) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $environment68 0
      (ref.cast (ref $environment68)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.new_default $type17
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function69 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment69))
  (return_call $function37
   (struct.get $type46 0
    (struct.get $environment69 1
     (local.tee $2
      (ref.cast (ref $environment69)
       (local.get $0)
      )
     )
    )
   )
   (local.get $1)
   (struct.get $environment69 0
    (local.get $2)
   )
   (struct.get $environment69 2
    (local.get $2)
   )
  )
 )
 (func $function70 (type $call47) (param $0 (ref null $environment72)) (param $1 (ref $type48)) (param $2 (ref $type43)) (result i32)
  (return_call_ref $call43
   (struct.get $type43 1
    (local.get $2)
   )
   (i32.const 1)
   (struct.get $type43 0
    (local.get $2)
   )
  )
 )
 (func $function71 (type $call8) (param $0 (ref $environment71)) (result i32)
  (unreachable)
 )
 (func $function72 (type $call47) (param $0 (ref null $environment72)) (param $1 (ref $type48)) (param $2 (ref $type43)) (result i32)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type17))
  (local.set $5
   (struct.get $environment72 1
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $environment72 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready105)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global105)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (call $function40
      (local.get $5)
      (local.get $1)
      (local.get $3)
      (local.get $3)
      (local.tee $6
       (array.get $type18
        (local.get $5)
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (if (result i32)
      (local.tee $4
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
      )
     )
     (then
      (return_call_ref $call43
       (struct.get $type43 1
        (local.get $2)
       )
       (i32.const 1)
       (struct.get $type43 0
        (local.get $2)
       )
      )
     )
     (else
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function73 (type $13) (param $0 i64) (param $1 i64) (param $2 (ref $type51)) (param $3 i64) (param $4 (ref $type18)) (param $5 (ref $type14)) (param $6 (ref $type48)) (param $7 (ref $type25)) (param $8 (ref $type8)) (param $9 i32) (param $10 i32) (param $11 i64) (param $12 (ref null $type24)) (result (ref null $type24))
  (if (result (ref null $type24))
   (call_ref $call25
    (struct.get $type25 1
     (local.get $7)
    )
    (local.get $11)
    (struct.get $type25 0
     (local.get $7)
    )
   )
   (then
    (if
     (i64.eq
      (local.get $3)
      (local.get $11)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready149)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global149)
       )
      )
      (return_call $function74
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $5)
       (local.get $8)
       (call $function50
        (local.get $3)
        (local.get $5)
       )
       (block (result (ref $type17))
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.get $type18
         (local.get $4)
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
       (i64.const 0)
       (ref.null none)
       (ref.null none)
       (local.get $12)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function82
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $11)
       (array.get $type18
        (local.get $4)
        (i32.wrap_i64
         (local.get $11)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
       (i64.const 0)
       (local.get $12)
      )
     )
    )
    (unreachable)
   )
   (else
    (local.get $12)
   )
  )
 )
 (func $function74 (type $11) (param $0 i64) (param $1 i64) (param $2 (ref $type51)) (param $3 i64) (param $4 (ref $type14)) (param $5 (ref $type8)) (param $6 (ref $type18)) (param $7 (ref $type17)) (param $8 i32) (param $9 i32) (param $10 i64) (param $11 i64) (param $12 (ref null $type13)) (param $13 (ref null $type16)) (param $14 (ref null $type24)) (result (ref null $type24))
  (local $15 (ref $type25))
  (local $16 (ref $environment71))
  (local $17 (ref $type16))
  (local $18 i32)
  (if (result (ref null $type24))
   (if (result i32)
    (local.tee $18
     (i64.eq
      (local.get $3)
      (local.get $10)
     )
    )
    (then
     (local.get $18)
    )
    (else
     (i64.eq
      (local.get $1)
      (local.get $11)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready235)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global235)
     )
    )
    (if (result (ref null $type24))
     (if (result i32)
      (if (result i32)
       (local.tee $8
        (i64.eqz
         (local.get $3)
        )
       )
       (then
        (local.get $8)
       )
       (else
        (if (result i32)
         (call_ref $call25
          (struct.get $type25 1
           (local.tee $15
            (struct.new $type25
             (ref.func $function75)
             (struct.new $environment75
              (local.get $13)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type25 0
           (local.get $15)
          )
         )
         (then
          (if (result i32)
           (local.tee $8
            (i64.eq
             (local.get $3)
             (i64.const 1)
            )
           )
           (then
            (local.get $8)
           )
           (else
            (if (result i32)
             (call_ref $call25
              (struct.get $type25 1
               (local.get $15)
              )
              (i64.const 1)
              (struct.get $type25 0
               (local.get $15)
              )
             )
             (then
              (if (result i32)
               (local.tee $8
                (i64.eq
                 (local.get $3)
                 (i64.const 2)
                )
               )
               (then
                (local.get $8)
               )
               (else
                (if (result i32)
                 (call_ref $call25
                  (struct.get $type25 1
                   (local.get $15)
                  )
                  (i64.const 2)
                  (struct.get $type25 0
                   (local.get $15)
                  )
                 )
                 (then
                  (if (result i32)
                   (local.tee $8
                    (i64.eq
                     (local.get $3)
                     (i64.const 3)
                    )
                   )
                   (then
                    (local.get $8)
                   )
                   (else
                    (if (result i32)
                     (call_ref $call25
                      (struct.get $type25 1
                       (local.get $15)
                      )
                      (i64.const 3)
                      (struct.get $type25 0
                       (local.get $15)
                      )
                     )
                     (then
                      (if (result i32)
                       (local.tee $8
                        (i64.eq
                         (local.get $3)
                         (i64.const 4)
                        )
                       )
                       (then
                        (local.get $8)
                       )
                       (else
                        (if (result i32)
                         (call_ref $call25
                          (struct.get $type25 1
                           (local.get $15)
                          )
                          (i64.const 4)
                          (struct.get $type25 0
                           (local.get $15)
                          )
                         )
                         (then
                          (if (result i32)
                           (local.tee $8
                            (i64.eq
                             (local.get $3)
                             (i64.const 5)
                            )
                           )
                           (then
                            (local.get $8)
                           )
                           (else
                            (if (result i32)
                             (call_ref $call25
                              (struct.get $type25 1
                               (local.get $15)
                              )
                              (i64.const 5)
                              (struct.get $type25 0
                               (local.get $15)
                              )
                             )
                             (then
                              (if (result i32)
                               (local.tee $8
                                (i64.eq
                                 (local.get $3)
                                 (i64.const 6)
                                )
                               )
                               (then
                                (local.get $8)
                               )
                               (else
                                (if (result i32)
                                 (call_ref $call25
                                  (struct.get $type25 1
                                   (local.get $15)
                                  )
                                  (i64.const 6)
                                  (struct.get $type25 0
                                   (local.get $15)
                                  )
                                 )
                                 (then
                                  (if (result i32)
                                   (local.tee $8
                                    (i64.eq
                                     (local.get $3)
                                     (i64.const 7)
                                    )
                                   )
                                   (then
                                    (local.get $8)
                                   )
                                   (else
                                    (if (result i32)
                                     (call_ref $call25
                                      (struct.get $type25 1
                                       (local.get $15)
                                      )
                                      (i64.const 7)
                                      (struct.get $type25 0
                                       (local.get $15)
                                      )
                                     )
                                     (then
                                      (if (result i32)
                                       (local.tee $8
                                        (i64.eq
                                         (local.get $3)
                                         (i64.const 8)
                                        )
                                       )
                                       (then
                                        (local.get $8)
                                       )
                                       (else
                                        (if (result i32)
                                         (call_ref $call25
                                          (struct.get $type25 1
                                           (local.get $15)
                                          )
                                          (i64.const 8)
                                          (struct.get $type25 0
                                           (local.get $15)
                                          )
                                         )
                                         (then
                                          (call $function80
                                           (local.get $3)
                                           (local.get $15)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 9)
                                          )
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (i32.const 0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                             (else
                              (i32.const 0)
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
      (then
       (call $function37
        (struct.get $type46 0
         (struct.get $environment71 2
          (local.tee $16
           (struct.get $type8 1
            (local.get $5)
           )
          )
         )
        )
        (struct.get $environment71 0
         (local.get $16)
        )
        (struct.get $environment71 1
         (local.get $16)
        )
        (struct.get $environment71 3
         (local.get $16)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $4)
       (i32.wrap_i64
        (local.get $3)
       )
       (local.get $12)
      )
      (if
       (i32.eqz
        (global.get $ready75)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global75)
       )
      )
      (drop
       (call $function30
        (local.get $0)
        (struct.new $type33
         (ref.func $function81)
         (struct.new $environment81
          (local.get $4)
         )
        )
       )
      )
      (struct.new $type24
       (local.get $14)
      )
     )
     (else
      (local.get $14)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (local.get $7)
     (i32.wrap_i64
      (local.get $10)
     )
     (i32.const 1)
    )
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $17
     (struct.new $type16
      (array.get $type18
       (local.get $6)
       (i32.wrap_i64
        (local.get $10)
       )
      )
      (local.get $13)
     )
    )
    (if
     (i32.eqz
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (local.set $14
     (call $function74
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $3)
      (local.get $4)
      (local.get $5)
      (local.get $6)
      (local.get $7)
      (local.get $8)
      (local.get $9)
      (i64.add
       (local.get $10)
       (i64.const 1)
      )
      (i64.add
       (local.get $11)
       (i64.const 1)
      )
      (struct.new $type13
       (local.get $10)
       (local.get $12)
      )
      (local.get $17)
      (local.get $14)
     )
    )
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (local.get $7)
     (i32.wrap_i64
      (local.get $10)
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (i64.add
      (local.get $10)
      (i64.const 1)
     )
     (local.get $11)
     (local.get $12)
     (local.get $13)
     (local.get $14)
    )
   )
  )
 )
 (func $function75 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref null $type16))
  (local $3 (ref $type17))
  (local $4 (ref $type39))
  (local $5 i32)
  (local.set $2
   (struct.get $environment75 0
    (ref.cast (ref $environment75)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready229)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global229)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $5
      (array.get $type17
       (struct.get $type16 0
        (local.get $2)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $1
           (struct.get $environment76 0
            (struct.get $type39 0
             (local.tee $4
              (struct.new $type39
               (struct.new $environment76
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (then
      (local.get $5)
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.tee $2
         (struct.get $type16 1
          (local.get $2)
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (local.tee $5
          (array.get $type17
           (struct.get $type16 0
            (local.get $2)
           )
           (block (result i32)
            (if
             (i64.gt_u
              (local.tee $1
               (struct.get $environment76 0
                (struct.get $type39 0
                 (local.get $4)
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
         (then
          (local.get $5)
         )
         (else
          (if (result i32)
           (ref.is_null
            (local.tee $2
             (struct.get $type16 1
              (local.get $2)
             )
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (local.tee $5
              (array.get $type17
               (struct.get $type16 0
                (local.get $2)
               )
               (block (result i32)
                (if
                 (i64.gt_u
                  (local.tee $1
                   (struct.get $environment76 0
                    (struct.get $type39 0
                     (local.get $4)
                    )
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
             (then
              (local.get $5)
             )
             (else
              (if (result i32)
               (ref.is_null
                (local.tee $2
                 (struct.get $type16 1
                  (local.get $2)
                 )
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (local.tee $5
                  (array.get $type17
                   (struct.get $type16 0
                    (local.get $2)
                   )
                   (block (result i32)
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (struct.get $environment76 0
                        (struct.get $type39 0
                         (local.get $4)
                        )
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i32.wrap_i64
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $5)
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.tee $2
                     (struct.get $type16 1
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (local.tee $5
                      (array.get $type17
                       (struct.get $type16 0
                        (local.get $2)
                       )
                       (block (result i32)
                        (if
                         (i64.gt_u
                          (local.tee $1
                           (struct.get $environment76 0
                            (struct.get $type39 0
                             (local.get $4)
                            )
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (i32.wrap_i64
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $5)
                     )
                     (else
                      (if (result i32)
                       (ref.is_null
                        (local.tee $2
                         (struct.get $type16 1
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (local.tee $5
                          (array.get $type17
                           (struct.get $type16 0
                            (local.get $2)
                           )
                           (block (result i32)
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (struct.get $environment76 0
                                (struct.get $type39 0
                                 (local.get $4)
                                )
                               )
                              )
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $5)
                         )
                         (else
                          (if (result i32)
                           (ref.is_null
                            (local.tee $2
                             (struct.get $type16 1
                              (local.get $2)
                             )
                            )
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (local.tee $5
                              (array.get $type17
                               (struct.get $type16 0
                                (local.get $2)
                               )
                               (block (result i32)
                                (if
                                 (i64.gt_u
                                  (local.tee $1
                                   (struct.get $environment76 0
                                    (struct.get $type39 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (i32.wrap_i64
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $5)
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.tee $2
                                 (struct.get $type16 1
                                  (local.get $2)
                                 )
                                )
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (local.tee $5
                                  (array.get $type17
                                   (struct.get $type16 0
                                    (local.get $2)
                                   )
                                   (block (result i32)
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (struct.get $environment76 0
                                        (struct.get $type39 0
                                         (local.get $4)
                                        )
                                       )
                                      )
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (i32.wrap_i64
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $5)
                                 )
                                 (else
                                  (if (result i32)
                                   (ref.is_null
                                    (local.tee $2
                                     (struct.get $type16 1
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (local.tee $5
                                      (array.get $type17
                                       (struct.get $type16 0
                                        (local.get $2)
                                       )
                                       (block (result i32)
                                        (if
                                         (i64.gt_u
                                          (local.tee $1
                                           (struct.get $environment76 0
                                            (struct.get $type39 0
                                             (local.get $4)
                                            )
                                           )
                                          )
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (i32.wrap_i64
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $5)
                                     )
                                     (else
                                      (return_call $function78
                                       (local.get $4)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (struct.get $type16 1
                                        (local.get $2)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function78 (type $5) (param $0 (ref $type39)) (param $1 i32) (param $2 i32) (param $3 (ref null $type16)) (result i32)
  (local $4 (ref $type17))
  (local $5 i64)
  (local $6 i32)
  (if (result i32)
   (ref.is_null
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $6
      (array.get $type17
       (struct.get $type16 0
        (local.get $3)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment76 0
            (struct.get $type39 0
             (local.get $0)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
     )
     (then
      (local.get $6)
     )
     (else
      (local.set $3
       (struct.get $type16 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function78
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function80 (type $4) (param $0 i64) (param $1 (ref $type25)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (local.get $0)
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if (result i32)
     (call_ref $call25
      (struct.get $type25 1
       (local.get $1)
      )
      (local.get $4)
      (struct.get $type25 0
       (local.get $1)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function80
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function81 (type $call33) (param $0 (ref null $environment81)) (param $1 i64) (result (ref null $type13))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type14
   (struct.get $environment81 0
    (local.get $0)
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function82 (type $3) (param $0 i64) (param $1 i64) (param $2 (ref $type51)) (param $3 i64) (param $4 (ref $type18)) (param $5 (ref $type14)) (param $6 (ref $type48)) (param $7 (ref $type25)) (param $8 (ref $type8)) (param $9 i32) (param $10 i32) (param $11 i64) (param $12 (ref $type17)) (param $13 i32) (param $14 i32) (param $15 i64) (param $16 i64) (param $17 (ref null $type24)) (result (ref null $type24))
  (local $18 i32)
  (local $19 i64)
  (local $20 (ref null $type13))
  (local $21 (ref $type17))
  (if (result (ref null $type24))
   (i64.eq
    (local.get $11)
    (local.get $15)
   )
   (then
    (if
     (i64.gt_u
      (local.get $11)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type48
     (local.get $6)
     (i32.wrap_i64
      (local.get $11)
     )
     (local.get $16)
    )
    (if
     (i32.eqz
      (local.get $10)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function73
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (local.get $10)
     (i64.add
      (local.get $11)
      (i64.const 1)
     )
     (local.get $17)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $14)
     )
     (then
      (unreachable)
     )
    )
    (local.set $17
     (call $function82
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $3)
      (local.get $4)
      (local.get $5)
      (local.get $6)
      (local.get $7)
      (local.get $8)
      (local.get $9)
      (local.get $10)
      (local.get $11)
      (local.get $12)
      (local.get $13)
      (local.get $14)
      (i64.add
       (local.get $15)
       (i64.const 1)
      )
      (local.get $16)
      (local.get $17)
     )
    )
    (if
     (i64.gt_u
      (local.get $15)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $21
     (array.get $type18
      (local.get $4)
      (i32.wrap_i64
       (local.get $15)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $15)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.tee $19
       (array.get $type48
        (local.get $6)
        (i32.wrap_i64
         (local.get $15)
        )
       )
      )
      (local.get $1)
     )
     (then
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $5)
       (local.tee $18
        (i32.wrap_i64
         (local.get $15)
        )
       )
       (struct.new $type13
        (local.get $11)
        (array.get $type14
         (local.get $5)
         (local.get $18)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $21)
       (i32.wrap_i64
        (local.get $11)
       )
       (i32.const 1)
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type48
       (local.get $6)
       (i32.wrap_i64
        (local.get $15)
       )
       (i64.add
        (local.get $19)
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (local.get $14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $17
       (call $function82
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (local.get $7)
        (local.get $8)
        (local.get $9)
        (local.get $10)
        (local.get $11)
        (local.get $12)
        (local.get $13)
        (local.get $14)
        (i64.add
         (local.get $15)
         (i64.const 1)
        )
        (local.get $16)
        (local.get $17)
       )
      )
      (if
       (i64.ne
        (local.get $1)
        (local.get $16)
       )
       (then
        (if
         (i64.gt_u
          (local.get $15)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (local.get $12)
         (i32.wrap_i64
          (local.get $15)
         )
         (i32.const 1)
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type14
         (local.get $5)
         (local.tee $18
          (i32.wrap_i64
           (local.get $11)
          )
         )
         (struct.new $type13
          (local.get $15)
          (array.get $type14
           (local.get $5)
           (local.get $18)
          )
         )
        )
        (if
         (i32.eqz
          (local.get $14)
         )
         (then
          (unreachable)
         )
        )
        (local.set $17
         (call $function82
          (local.get $0)
          (local.get $1)
          (local.get $2)
          (local.get $3)
          (local.get $4)
          (local.get $5)
          (local.get $6)
          (local.get $7)
          (local.get $8)
          (local.get $9)
          (local.get $10)
          (local.get $11)
          (local.get $12)
          (local.get $13)
          (local.get $14)
          (i64.add
           (local.get $15)
           (i64.const 1)
          )
          (i64.add
           (local.get $16)
           (i64.const 1)
          )
          (local.get $17)
         )
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $20
         (struct.get $type13 1
          (array.get $type14
           (local.get $5)
           (i32.wrap_i64
            (local.get $11)
           )
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $11)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type14
         (local.get $5)
         (i32.wrap_i64
          (local.get $11)
         )
         (local.get $20)
        )
        (if
         (i64.gt_u
          (local.get $15)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (local.get $12)
         (i32.wrap_i64
          (local.get $15)
         )
         (i32.const 0)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type48
       (local.get $6)
       (i32.wrap_i64
        (local.get $15)
       )
       (local.get $19)
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $21)
       (i32.wrap_i64
        (local.get $11)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $20
       (struct.get $type13 1
        (array.get $type14
         (local.get $5)
         (i32.wrap_i64
          (local.get $15)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $5)
       (i32.wrap_i64
        (local.get $15)
       )
       (local.get $20)
      )
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (local.get $16)
     )
     (then
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $5)
       (local.tee $18
        (i32.wrap_i64
         (local.get $11)
        )
       )
       (struct.new $type13
        (local.get $15)
        (array.get $type14
         (local.get $5)
         (local.get $18)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $12)
       (i32.wrap_i64
        (local.get $15)
       )
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $17
       (call $function82
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (local.get $7)
        (local.get $8)
        (local.get $9)
        (local.get $10)
        (local.get $11)
        (local.get $12)
        (local.get $13)
        (local.get $14)
        (i64.add
         (local.get $15)
         (i64.const 1)
        )
        (i64.add
         (local.get $16)
         (i64.const 1)
        )
        (local.get $17)
       )
      )
      (if
       (i64.gt_u
        (local.get $15)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $12)
       (i32.wrap_i64
        (local.get $15)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $20
       (struct.get $type13 1
        (array.get $type14
         (local.get $5)
         (i32.wrap_i64
          (local.get $11)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $11)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $5)
       (i32.wrap_i64
        (local.get $11)
       )
       (local.get $20)
      )
     )
    )
    (local.get $17)
   )
  )
 )
 (func $function84 (type $2) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 (ref null $type24))
  (local $6 (ref $type18))
  (local $7 (ref $type46))
  (local $8 (ref $type33))
  (local $9 (ref $type51))
  (local $10 i64)
  (local $11 i32)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready255)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready261)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global261)
     )
    )
    (local.set $4
     (call $foreign0
      (global.get $global255)
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (if
     (i32.eqz
      (global.get $ready190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (if
     (i32.eqz
      (global.get $ready159)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global159)
     )
    )
    (local.set $6
     (call $function54
      (local.get $4)
      (struct.new $type35
       (ref.func $function68)
       (struct.new $environment68
        (local.get $4)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready64)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global64)
     )
    )
    (if
     (i32.eqz
      (global.get $ready67)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (ref.as_non_null
      (global.get $global67)
     )
    )
    (if
     (i32.eqz
      (global.get $ready75)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global75)
     )
    )
    (local.set $9
     (struct.new_default $type51)
    )
    (local.set $7
     (struct.new $type46
      (struct.new $environment37
       (call $function30
        (i64.add
         (local.tee $10
          (i64.sub
           (local.get $4)
           (i64.const 1)
          )
         )
         (i64.const 1)
        )
        (local.get $8)
       )
       (block (result (ref (exact $type48)))
        (if
         (i64.gt_u
          (local.get $10)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.new_default $type48
         (i32.wrap_i64
          (local.get $10)
         )
        )
       )
      )
     )
    )
    (local.set $5
     (call $function73
      (local.get $4)
      (i64.const 2)
      (local.get $9)
      (local.get $10)
      (local.get $6)
      (array.new_default $type14
       (local.tee $11
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (array.new_default $type48
       (local.get $11)
      )
      (struct.new $type25
       (ref.func $function69)
       (struct.new $environment69
        (local.get $6)
        (local.get $7)
        (struct.new $type47
         (ref.func $function70)
         (ref.null none)
        )
       )
      )
      (struct.new $type8
       (ref.func $function71)
       (struct.new $environment71
        (local.get $10)
        (local.get $6)
        (local.get $7)
        (struct.new $type47
         (ref.func $function72)
         (struct.new $environment72
          (local.get $10)
          (local.get $6)
         )
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (global.get $ready264)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global264)
     )
    )
    (local.set $4
     (if (result i64)
      (ref.is_null
       (local.get $5)
      )
      (then
       (i64.const 0)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $5
          (struct.get $type24 0
           (local.get $5)
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $5
            (struct.get $type24 0
             (local.get $5)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $5
              (struct.get $type24 0
               (local.get $5)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $5
                (struct.get $type24 0
                 (local.get $5)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $5
                  (struct.get $type24 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $5
                    (struct.get $type24 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $5
                      (struct.get $type24 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $5
                        (struct.get $type24 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (call $function87
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type24 0
                         (local.get $5)
                        )
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $function87 (type $0) (param $0 i32) (param $1 i32) (param $2 (ref null $type24)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type24 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready256)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global256)
   )
  )
  (return_call $function84
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type11)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global162
   (struct.new_default $type15)
  )
  (global.set $ready162
   (i32.const 1)
  )
  (global.set $global80
   (struct.new_default $type19)
  )
  (global.set $ready80
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type20)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global264
   (struct.new_default $type23)
  )
  (global.set $ready264
   (i32.const 1)
  )
  (global.set $global72
   (struct.new $type25
    (ref.func $function29)
    (ref.null none)
   )
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type26)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global156
   (struct.new_default $type27)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $global261
   (struct.new_default $type29)
  )
  (global.set $ready261
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type30)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global75
   (struct.new_default $type32)
  )
  (global.set $ready75
   (i32.const 1)
  )
  (global.set $global159
   (struct.new_default $type34)
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global67
   (struct.new $type33
    (ref.func $function27)
    (ref.null none)
   )
  )
  (global.set $ready67
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type36)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type37)
  )
  (global.set $ready235
   (i32.const 1)
  )
  (global.set $global229
   (struct.new_default $type38)
  )
  (global.set $ready229
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type40)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global64
   (struct.new_default $type45)
  )
  (global.set $ready64
   (i32.const 1)
  )
  (global.set $global105
   (struct.new_default $type49)
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global190
   (struct.new_default $type50)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global149
   (struct.new_default $type52)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global188
   (struct.new_default $type53)
  )
  (global.set $ready188
   (i32.const 1)
  )
  (global.set $global255
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready255
   (i32.const 1)
  )
  (global.set $global256
   (struct.new_default $type54)
  )
  (global.set $ready256
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

