# Manual Boolean-matrix callable ablation

This is a manual mechanism ablation, prepared before choosing a compiler change.
It changes two call sites in a separate graphs source and adds concrete worker
definitions. It is not a production optimization or a new benchmark result.
No clean timings have run, and independent review is pending.

[`helpers.scm`](helpers.scm) gives the original two row callbacks their captures
as explicit parameters, and specializes copies of `proc->vector` for those known
workers. The first callback allocates a false row from the captured graph size.
The second allocates a reachability row, marks its diagonal and outgoing edges,
and keeps its original `list-for-each` callback. The
[complete source patch](variant/strict.patch) changes only these matrix call
sites. [`inspect.py`](inspect.py) verifies that reversing those changes and
removing the helpers exactly recovers the canonical source, byte for byte.

For size zero, each builder returns an empty vector without computing a row.
For a nonempty matrix, it computes row zero before allocating the outer vector,
initially fills that vector with row zero's reference, then replaces rows one
onward in increasing order. This preserves the original allocation/initialization
sequence for rows and matrices, their final mutable row identities, and the
algorithm's reads and writes. The explicit captures are initialized parameters
whose reads are inert; passing the outgoing-edge vector copies its reference,
not its contents. Native Wasm parameters and locals remain GC roots across row
allocation and the retained list callback.

The original `proc->vector` and other callback flows remain. The source forms for
`fold-over-perm-tree`, `make-minimal?`, `cmp-next-vertex`, `giota`,
`gnatural-for-each`, `run`, and `bench` are unchanged. The original repetition
count, seven-vertex input, host opacity calls, and final length predicate remain
in the frozen [specification](spec.json) and source. Unknown and recursive
callable flows retain their existing representation.

Preparation has passed 25 target checks, recorded individually in `commands/`:
16 complete ordered-output checks for graphs of sizes one through four
(baseline/variant, raw/optimized); three full seven-vertex/count-three checks
(variant raw/optimized and baseline optimized), each returning 213829 with three
validation opacity calls; and six matrix contracts at dimensions zero, one,
and three (raw/optimized). Matrix contracts compare values with the generic
generator, check every pair of rows has distinct mutable identity, and check
that changing the first initial row leaves another row unchanged. An empty
reachability matrix avoids the otherwise trapping row-zero read.
The retained complete-output goldens independently pass exhaustive rooted-graph
orbit checks. See [oracle validation](oracle-validation.json) and
[contracts](contracts-body.scm).

The original Boolean-matrix `proc->vector` has 12 static optimized indirect
sites across its worker and loop, including Binaryen's unrolled copies. Those
row-generator sites are absent from the variant. Raw specialized builders and
loops invoke the concrete workers directly; optimized code carries graph size
and outgoing-edge references as parameters, without the original row-generator
wrapper/environment pairs. The per-row list callback and natural-number callbacks
remain ordinary closures. The permutation continuation wrappers and environments
also remain. [Structure evidence](structure.json) maps the changing code/type
numbers back to source types and locations.

| Static module observation | Baseline | Variant |
| --- | ---: | ---: |
| Raw indirect sites | 21 | 19 |
| Optimized indirect sites | 78 | 66 |
| Optimized constructor sites | 102 | 112 |

These are static instruction sites, not dynamic counts or native allocation
events. Constructor sites increase because direct knowledge permits additional
inlining and unrolling; required row/matrix allocations remain. The prior
instrumented canonical run attributes roughly 87% of construction completions
to the continuation creation/resumption path, which this ablation preserves.
See [the audit](audit.md) for exact source, WAT, and counter references.

This source change combines dispatch removal, explicit capture transport, and
code copying; it can also change downstream inlining. It does not isolate a
dispatch-only cost. An explicit heap capture record consumed by direct workers
could provide a separate capture-transport control, but would introduce a new
layout and omit the original callable wrapper. Retaining the exact original
closure ABI while changing only invocation needs a controlled IR/Wasm change;
subsequent optimization may still eliminate construction. Dummy allocations or
observer barriers would introduce a different mechanism. No second variant has
been manufactured to force them.

Recreate the source and complete preparation checks from this worktree:

```sh
python3 experiments/proc-vector-callable-ablation/prepare.py
python3 experiments/proc-vector-callable-ablation/validate.py
python3 experiments/proc-vector-callable-ablation/inspect.py
python3 experiments/proc-vector-callable-ablation/freeze.py
```

Build and validation commands, stdout, stderr, and process durations are retained.
The ordinary host prints elapsed seconds during correctness execution; those
uncoordinated runs are explicitly unsuitable for performance comparisons.
An initial source-map helper failure omitted the compiler's required trace scope;
its retained failure and corrected success are separate records. All compiler
and program builds passed.

[The next-window handoff](next-window.json) freezes the baseline/variant artifacts,
host, specification, and exact unexecuted workload commands. Arrange a coordinated
quiet window and complete the pending fresh review before using it for clean
measurements. Nothing has been merged or published.

| Variant identity | SHA-256 |
| --- | --- |
| Strict source | `3190e2d42e469395f1b48b44969dde3d34b2cd5a2be6da3692df038ea0811332` |
| Optimized Wasm | `073d33cc2daf4e986cdc7121be08cac01d2ef0058a8da3ced4673b24ee98e5ea` |
| Raw Wasm | `1b82d2a44b963103a2ab05e31fecb9e62e383f09f560993e59de2f11e00d7014` |
| Optimized WAT | `31f5e068ef6abd60ed7769be7f9668579aa3b4d388fda28504068a000202d9c2` |

The four new Scheme operations are cohesive, each below ten logic lines. The
test scenario and Python command orchestration remain together to expose their
ordered contracts. The pinned simplify skill was applied through a local
explanation/critique pass; its required fresh explainer was unavailable because
the agent thread limit was reached. [Review status](review.json) preserves that
limitation rather than claiming independent approval.
