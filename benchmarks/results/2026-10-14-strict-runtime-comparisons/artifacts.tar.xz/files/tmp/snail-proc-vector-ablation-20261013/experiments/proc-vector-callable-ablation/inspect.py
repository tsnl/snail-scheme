"""Record source scope and static raw/optimized Wasm structure for the ablation."""

from collections import Counter
import json
from pathlib import Path
import re

from prepare import HERE, INITIAL, REACH, form, replace_once

# ---- Read printed Scheme maps and generated WAT ----


def parse_form(token, tokens):
    if token != '(':
        return token
    value = []
    for token in tokens:
        if token == ')':
            return value
        value.append(parse_form(token, tokens))
    raise ValueError('unterminated form')


def read_forms(path):
    tokens = iter(re.findall(r'"(?:\\.|[^"\\])*"|[^\s()]+|[()]', path.read_text()))
    return [parse_form(token, tokens) for token in tokens]


def walk(value):
    if isinstance(value, list):
        yield value
        for item in value:
            yield from walk(item)


def function_summary(function):
    nodes = list(walk(function))
    indirect = Counter(node[1] for node in nodes if node and node[0] in ('call_ref', 'return_call_ref'))
    constructors = Counter(node[1] for node in nodes if node and node[0] in
                           ('struct.new', 'struct.new_default', 'array.new', 'array.new_default'))
    direct = sorted({node[1] for node in nodes if node and node[0] in ('call', 'return_call')})
    return dict(indirect_calls=dict(indirect), construction_sites=dict(constructors), direct_targets=direct)


def module_summary(path):
    module = read_forms(path)[0]
    functions = {item[1]: function_summary(item) for item in module if isinstance(item, list)
                 and item and item[0] == 'func'}
    layouts = {item[1]: item[2:] for item in walk(module) if item and item[0] == 'type'
               and len(item) > 2 and isinstance(item[2], list)}
    return dict(functions=functions, type_definitions=layouts)

# ---- The complete source differs only at two call sites and new helpers ----


def source_scope():
    baseline = (HERE / 'baseline/strict.scm').read_text()
    variant = (HERE / 'variant/strict.scm').read_text()
    recovered = replace_once(variant, (HERE / 'helpers.scm').read_text() + '\n', '')
    recovered = replace_once(recovered, '(initial-boolean-matrix size)', INITIAL)
    recovered = replace_once(recovered, '(reachability-matrix size vertex->out)', REACH)
    if recovered != baseline:
        raise ValueError('changes escaped the two call sites and helper definitions')
    names = ('fold-over-perm-tree', 'make-minimal?', 'cmp-next-vertex', 'giota', 'gnatural-for-each', 'run', 'bench')
    unchanged = {name: form(baseline, '(define ' + name) == form(variant, '(define ' + name)
                 for name in names if name not in ('run', 'bench')}
    unchanged.update({name: form(baseline, '(define (' + name) == form(variant, '(define (' + name)
                      for name in ('run', 'bench')})
    return dict(exact_inverse_recovers_baseline=True, unchanged_forms=unchanged)


def compiler_map(directory):
    entries = read_forms(HERE / directory / 'function-map.scm')
    globals_ = [dict(name=row[1], value=row[2], type=row[3], function=row[4])
                for row in entries if row[0] == 'global']
    functions = {f'$function{row[1]}': dict(direct=row[2] == '#t', type=row[3], line=int(row[4]),
                 column=int(row[5]), source=row[6].strip('"'), captures=row[7])
                 for row in entries if row[0] == 'function'}
    return dict(globals=globals_, functions=functions)


def main():
    result = dict(definition='Static sites and targets, never runtime/native allocation counts.', source_scope=source_scope())
    for directory in ('baseline', 'variant'):
        result[directory] = dict(raw=module_summary(HERE / directory / 'strict.wasm.wat'),
                                 optimized=module_summary(HERE / directory / 'strict.optimized.wat'),
                                 compiler_map=compiler_map(directory))
    (HERE / 'structure.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['source_scope'], indent=2))


if __name__ == '__main__':
    main()
