;; ---- Known Boolean row workers ----

;; These are the two original callbacks with their captures made explicit.
;; The outgoing-edge references and the per-row list callback keep their identity.
(: initial-boolean-row (-> I64 I64 (Vector Bool)))
(define (initial-boolean-row size from)
  (make-vector size #f))

(: reachability-row (-> I64 (Vector (List I64)) I64 (Vector Bool)))
(define (reachability-row size vertex->out v)
  (let ((from-v (make-vector size #f)))
    (vector-set! from-v v #t)
    (list-for-each (lambda (x) (vector-set! from-v x #t))
                   (vector-ref vertex->out v))
    from-v))

;; ---- Specialized copies of proc->vector ----

;; Preserve the empty case, row-zero evaluation before allocation, and the
;; original increasing fill order. Initial fill aliases row zero until replaced.
(: initial-boolean-matrix (-> I64 (Vector (Vector Bool))))
(define (initial-boolean-matrix size)
  (if (integer-zero? size) (vector)
      (let ((x (make-vector size (initial-boolean-row size 0))))
        (let loop ((i 1))
          (when (< i size)
            (vector-set! x i (initial-boolean-row size i))
            (loop (+ i 1))))
        x)))

(: reachability-matrix (-> I64 (Vector (List I64)) (Vector (Vector Bool))))
(define (reachability-matrix size vertex->out)
  (if (integer-zero? size) (vector)
      (let ((x (make-vector size (reachability-row size vertex->out 0))))
        (let loop ((i 1))
          (when (< i size)
            (vector-set! x i (reachability-row size vertex->out i))
            (loop (+ i 1))))
        x)))
