(import (scheme base) (scheme cxr) (scheme process-context) (scheme write)
        (snail-scheme strict-compiler) (snail-scheme strict-specialize)
        (snail-scheme strict-types) (snail-scheme source) (snail-scheme chromium-trace)
        (only (snail-scheme ir) node-loc node-kind node-data value-definition-name))
(define arguments (cdr (command-line)))
(define program
  (with-chromium-trace-to (caddr arguments)
    (lambda ()
      (monomorphize (strict-source-file->core (car arguments) (cadr arguments)) 'bench))))

;; ---- Concrete source locations and global worker names ----

(for-each
 (lambda (function)
   (let ((loc (node-loc (function-source function))))
     (write (list 'function (function-index function) (function-direct? function)
                  (type-datum (function-type* function)) (loc-line loc)
                  (loc-column loc) (loc-filename loc)
                  (map value-index (function-captures function))))
     (newline)))
 (mono-program-functions program))
(for-each
 (lambda (value)
   (let ((initializer (value-initializer value)))
     (write (list 'global (value-definition-name (value-source value))
                  (value-index value) (type-datum (value-type value))
                  (and initializer (eq? (node-kind initializer) 'closure)
                       (function-index (car (node-data initializer))))))
     (newline)))
 (site-values (mono-program-globals program)))
