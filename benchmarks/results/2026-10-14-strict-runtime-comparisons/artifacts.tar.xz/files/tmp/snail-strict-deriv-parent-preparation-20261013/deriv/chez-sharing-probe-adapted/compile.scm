(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-deriv-parent-preparation-20261013/deriv/chez-sharing-probe-adapted/program.scm" "/tmp/snail-strict-deriv-parent-preparation-20261013/deriv/chez-sharing-probe-adapted/program.so"))
