(import (chezscheme))
;;; DERIV -- Symbolic derivation.


;;; Returns the wrong answer for quotients.
;;; Fortunately these aren't used in the benchmark.

(define (deriv a)
  (cond ((not (pair? a))
         (if (eq? a 'x) 1 0))
        ((eq? (car a) '+)
         (cons '+
               (map deriv (cdr a))))
        ((eq? (car a) '-)
         (cons '-
               (map deriv (cdr a))))
        ((eq? (car a) '*)
         (list '*
               a
               (cons '+
                     (map (lambda (a) (list '/ (deriv a) a)) (cdr a)))))
        ((eq? (car a) '/)
         (list '-
               (list '/
                     (deriv (cadr a))
                     (caddr a))
               (list '/
                     (cadr a)
                     (list '*
                           (caddr a)
                           (caddr a)
                           (deriv (caddr a))))))
        (else
         (error #f "No derivation method available"))))

(define (sharing-checks product quotient)
  (let* ((p (deriv product)) (q (deriv quotient))
         (terms (cdr (caddr p))) (denominator (caddr quotient)))
    (list
     (eq? (cadr p) product)
     (eq? (caddr (car terms)) (cadr product))
     (eq? (caddr (cadr terms)) (caddr product))
     (not (eq? p (deriv product)))
     (not (eq? (cdr p) (cdr (deriv product))))
     (eq? (cadr (caddr q)) (cadr quotient))
     (eq? (caddr (cadr q)) denominator)
     (eq? (cadr (caddr (caddr q))) denominator)
     (eq? (caddr (caddr (caddr q))) denominator))))
(let* ((product (read)) (quotient (read)))
  (write (sharing-checks product quotient)) (newline))
