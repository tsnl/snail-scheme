;;; DERIV -- Symbolic derivation.


;;; Returns the wrong answer for quotients.
;;; Fortunately these aren't used in the benchmark.

(define (deriv a)
  (cond ((not (datum-pair? a))
         (if (datum-x? a) datum-one datum-zero))
        ((datum-plus? (datum-car a))
         (datum-cons datum-plus
               (datum-map deriv (datum-cdr a))))
        ((datum-minus? (datum-car a))
         (datum-cons datum-minus
               (datum-map deriv (datum-cdr a))))
        ((datum-times? (datum-car a))
         (datum-list3 datum-times
               a
               (datum-cons datum-plus
                     (datum-map (lambda (a) (datum-list3 datum-divide (deriv a) a)) (datum-cdr a)))))
        ((datum-divide? (datum-car a))
         (datum-list3 datum-minus
               (datum-list3 datum-divide
                     (deriv (datum-cadr a))
                     (datum-caddr a))
               (datum-list3 datum-divide
                     (datum-cadr a)
                     (datum-list4 datum-times
                           (datum-caddr a)
                           (datum-caddr a)
                           (deriv (datum-caddr a))))))
        (else
         (unreachable))))

