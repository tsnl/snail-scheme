(module
 (rec
  (type $type12 (sub (struct (field i32))))
  (type $type32 (struct (field (mut i64))))
  (type $call34 (func (param i32 (ref $type32)) (result (ref $type12))))
  (type $call30 (func (param (ref $type12) (ref $type12)) (result i32)))
  (type $call29 (func (param (ref $type26) (ref $type12)) (result (ref $type12))))
  (type $call26 (func (param (ref $type12)) (result (ref $type12))))
  (type $type24 (sub $type12 (struct (field i32) (field (ref $type12)) (field (ref $type12)))))
  (type $call11 (func (param (ref $type12)) (result i64)))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type26 (struct (field (ref $call26))))
  (type $type25 (struct))
  (type $type23 (sub $type12 (struct (field i32) (field i64))))
  (type $type22 (sub $type12 (struct (field i32))))
  (type $type21 (sub $type12 (struct (field i32))))
  (type $type20 (sub $type12 (struct (field i32))))
  (type $type19 (sub $type12 (struct (field i32))))
  (type $type18 (sub $type12 (struct (field i32))))
  (type $type17 (sub $type12 (struct (field i32))))
  (type $type16 (sub $type12 (struct (field i32))))
  (type $type15 (sub $type12 (struct (field i32))))
  (type $type14 (sub $type12 (struct (field i32))))
  (type $type13 (sub $type12 (struct (field i32))))
  (type $type11 (struct))
 )
 (type $30 (func (param i32 i64) (result i64)))
 (type $31 (func (param i32) (result i64)))
 (type $32 (func (param i64) (result i64)))
 (type $33 (func))
 (import "benchmark" "vector_i64" (func $foreign0 (param i32 i64) (result i64)))
 (import "benchmark" "vector_length" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type11)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global67 (mut (ref null $type13)) (ref.null none))
 (global $ready67 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type14)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global69 (mut (ref null $type15)) (ref.null none))
 (global $ready69 (mut i32) (i32.const 0))
 (global $global70 (mut (ref null $type16)) (ref.null none))
 (global $ready70 (mut i32) (i32.const 0))
 (global $global71 (mut (ref null $type17)) (ref.null none))
 (global $ready71 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type18)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global73 (mut (ref null $type19)) (ref.null none))
 (global $ready73 (mut i32) (i32.const 0))
 (global $global74 (mut (ref null $type20)) (ref.null none))
 (global $ready74 (mut i32) (i32.const 0))
 (global $global75 (mut (ref null $type21)) (ref.null none))
 (global $ready75 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type22)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type23)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type23)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type25)) (ref.null none))
 (global $ready79 (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type25)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type25)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type25)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global115 (mut (ref null $type25)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type25)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type25)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type26)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type26)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type27)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type28)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type29)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type30)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type31)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global157 (mut (ref null $type33)) (ref.null none))
 (global $ready157 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type34)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global167 (mut (ref null $type26)) (ref.null none))
 (global $ready167 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type12)) (ref.null none))
 (global $ready170 (mut i32) (i32.const 0))
 (global $global171 (mut (ref null $type12)) (ref.null none))
 (global $ready171 (mut i32) (i32.const 0))
 (global $global172 (mut (ref null $type35)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (export "deriv-probe" (func $export0))
 (export "main" (func $main))
 (func $function25 (type $call11) (param $0 (ref $type12)) (result i64)
  (local $1 i32)
  (if (result i64)
   (local.tee $1
    (struct.get $type12 0
     (local.get $0)
    )
   )
   (then
    (if (result i64)
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i32.eq
        (struct.get $type12 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i32.eq
          (struct.get $type12 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (i64.const 5)
         )
         (else
          (if (result i64)
           (i32.eq
            (struct.get $type12 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (i64.const 6)
           )
           (else
            (if (result i64)
             (i32.eq
              (struct.get $type12 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (i64.const 7)
             )
             (else
              (if (result i64)
               (i32.eq
                (struct.get $type12 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (i64.const 8)
               )
               (else
                (if (result i64)
                 (i32.eq
                  (struct.get $type12 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (i64.const 9)
                 )
                 (else
                  (if (result i64)
                   (i32.eq
                    (struct.get $type12 0
                     (local.get $0)
                    )
                    (i32.const 8)
                   )
                   (then
                    (i64.const 10)
                   )
                   (else
                    (if (result i64)
                     (i32.eq
                      (struct.get $type12 0
                       (local.get $0)
                      )
                      (i32.const 9)
                     )
                     (then
                      (i64.const 11)
                     )
                     (else
                      (if (result i64)
                       (i32.eq
                        (struct.get $type12 0
                         (local.get $0)
                        )
                        (i32.const 10)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type23)
                          (local.get $0)
                         )
                        )
                        (i64.const 3)
                       )
                       (else
                        (drop
                         (ref.cast (ref $type24)
                          (local.get $0)
                         )
                        )
                        (i64.const 4)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function35 (type $call26) (param $0 (ref $type12)) (result (ref $type12))
  (if
   (i32.ne
    (struct.get $type12 0
     (local.get $0)
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type12 0
     (local.tee $0
      (struct.get $type24 2
       (ref.cast (ref $type24)
        (local.get $0)
       )
      )
     )
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type24 1
   (ref.cast (ref $type24)
    (local.get $0)
   )
  )
 )
 (func $function36 (type $call26) (param $0 (ref $type12)) (result (ref $type12))
  (if
   (i32.ne
    (struct.get $type12 0
     (local.get $0)
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type12 0
     (local.tee $0
      (struct.get $type24 2
       (ref.cast (ref $type24)
        (local.get $0)
       )
      )
     )
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type12 0
     (local.tee $0
      (struct.get $type24 2
       (ref.cast (ref $type24)
        (local.get $0)
       )
      )
     )
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type24 1
   (ref.cast (ref $type24)
    (local.get $0)
   )
  )
 )
 (func $function39 (type $call29) (param $0 (ref $type26)) (param $1 (ref $type12)) (result (ref $type12))
  (local $2 i32)
  (local $3 (ref $type24))
  (if
   (i32.eqz
    (global.get $ready85)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global85)
   )
  )
  (if (result (ref $type12))
   (if (result i32)
    (local.tee $2
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (then
     (if (result i32)
      (i32.eq
       (local.get $2)
       (i32.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (if (result i32)
        (i32.eq
         (struct.get $type12 0
          (local.get $1)
         )
         (i32.const 2)
        )
        (then
         (i32.const 1)
        )
        (else
         (if
          (i32.ne
           (local.tee $2
            (struct.get $type12 0
             (local.get $1)
            )
           )
           (i32.const 3)
          )
          (then
           (if
            (i32.and
             (i32.ne
              (local.get $2)
              (i32.const 4)
             )
             (i32.ne
              (local.get $2)
              (i32.const 5)
             )
            )
            (then
             (if
              (i32.and
               (i32.ne
                (local.get $2)
                (i32.const 6)
               )
               (i32.ne
                (local.get $2)
                (i32.const 7)
               )
              )
              (then
               (if
                (i32.and
                 (i32.ne
                  (local.get $2)
                  (i32.const 8)
                 )
                 (i32.ne
                  (local.get $2)
                  (i32.const 9)
                 )
                )
                (then
                 (if
                  (i32.eq
                   (local.get $2)
                   (i32.const 10)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type23)
                     (local.get $1)
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.cast (ref $type24)
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (i32.const 0)
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready69)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (global.get $global69)
    )
   )
   (else
    (if
     (i32.ne
      (struct.get $type12 0
       (local.get $1)
      )
      (i32.const 11)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call_ref $call26
      (struct.get $type24 1
       (local.tee $3
        (ref.cast (ref $type24)
         (local.get $1)
        )
       )
      )
      (struct.get $type26 0
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready146)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global146)
     )
    )
    (struct.new $type24
     (i32.const 11)
     (local.get $1)
     (call $function39
      (local.get $0)
      (struct.get $type24 2
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function40 (type $call30) (param $0 (ref $type12)) (param $1 (ref $type12)) (result i32)
  (local $2 i64)
  (local $3 (ref $type12))
  (local $4 (ref $type12))
  (local $scratch (ref $type12))
  (local $scratch_6 (ref $type12))
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $2
   (call $function25
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if (result i32)
   (i64.eq
    (call $function25
     (local.get $1)
    )
    (local.get $2)
   )
   (then
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 3)
     )
     (then
      (if
       (i32.ne
        (struct.get $type12 0
         (local.get $0)
        )
        (i32.const 10)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type23 1
        (ref.cast (ref $type23)
         (local.get $0)
        )
       )
      )
      (if
       (i32.ne
        (struct.get $type12 0
         (local.get $1)
        )
        (i32.const 10)
       )
       (then
        (unreachable)
       )
      )
      (i64.eq
       (struct.get $type23 1
        (ref.cast (ref $type23)
         (local.get $1)
        )
       )
       (local.get $2)
      )
     )
     (else
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 4)
       )
       (then
        (if
         (i32.ne
          (struct.get $type12 0
           (local.get $0)
          )
          (i32.const 11)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (call $function40
          (struct.get $type24 1
           (ref.cast (ref $type24)
            (local.get $0)
           )
          )
          (block (result (ref $type12))
           (if
            (i32.ne
             (struct.get $type12 0
              (local.get $1)
             )
             (i32.const 11)
            )
            (then
             (unreachable)
            )
           )
           (local.set $scratch
            (struct.get $type24 1
             (ref.cast (ref $type24)
              (local.get $1)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready149)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global149)
            )
           )
           (local.get $scratch)
          )
         )
         (then
          (if
           (i32.ne
            (struct.get $type12 0
             (local.get $0)
            )
            (i32.const 11)
           )
           (then
            (unreachable)
           )
          )
          (return_call $function40
           (struct.get $type24 2
            (ref.cast (ref $type24)
             (local.get $0)
            )
           )
           (block (result (ref $type12))
            (if
             (i32.ne
              (struct.get $type12 0
               (local.get $1)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $scratch_6
             (struct.get $type24 2
              (ref.cast (ref $type24)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready149)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global149)
             )
            )
            (local.get $scratch_6)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 1)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function43 (type $call34) (param $0 i32) (param $1 (ref $type32)) (result (ref $type12))
  (local $2 i64)
  (local $3 (ref $type12))
  (if
   (i32.eqz
    (global.get $ready153)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global153)
   )
  )
  (if (result (ref $type12))
   (i64.eq
    (local.tee $2
     (if (result i64)
      (i64.lt_s
       (local.tee $2
        (struct.get $type32 0
         (local.get $1)
        )
       )
       (call $foreign1
        (local.get $0)
       )
      )
      (then
       (struct.set $type32 0
        (local.get $1)
        (i64.add
         (local.get $2)
         (i64.const 1)
        )
       )
       (call $foreign0
        (local.get $0)
        (local.get $2)
       )
      )
      (else
       (unreachable)
      )
     )
    )
    (i64.const 3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global153)
     )
    )
    (struct.new $type23
     (i32.const 10)
     (if (result i64)
      (i64.lt_s
       (local.tee $2
        (struct.get $type32 0
         (local.get $1)
        )
       )
       (call $foreign1
        (local.get $0)
       )
      )
      (then
       (struct.set $type32 0
        (local.get $1)
        (i64.add
         (local.get $2)
         (i64.const 1)
        )
       )
       (call $foreign0
        (local.get $0)
        (local.get $2)
       )
      )
      (else
       (unreachable)
      )
     )
    )
   )
   (else
    (if (result (ref $type12))
     (i64.eq
      (local.get $2)
      (i64.const 4)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (local.set $3
       (call $function43
        (local.get $0)
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (struct.new $type24
       (i32.const 11)
       (local.get $3)
       (call $function43
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (else
      (if (result (ref $type12))
       (i64.eqz
        (local.get $2)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready67)
         )
         (then
          (unreachable)
         )
        )
        (ref.as_non_null
         (global.get $global67)
        )
       )
       (else
        (if (result (ref $type12))
         (i64.eq
          (local.get $2)
          (i64.const 1)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready68)
           )
           (then
            (unreachable)
           )
          )
          (ref.as_non_null
           (global.get $global68)
          )
         )
         (else
          (if (result (ref $type12))
           (i64.eq
            (local.get $2)
            (i64.const 2)
           )
           (then
            (if
             (i32.eqz
              (global.get $ready69)
             )
             (then
              (unreachable)
             )
            )
            (ref.as_non_null
             (global.get $global69)
            )
           )
           (else
            (if (result (ref $type12))
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready70)
               )
               (then
                (unreachable)
               )
              )
              (ref.as_non_null
               (global.get $global70)
              )
             )
             (else
              (if (result (ref $type12))
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (if
                 (i32.eqz
                  (global.get $ready71)
                 )
                 (then
                  (unreachable)
                 )
                )
                (ref.as_non_null
                 (global.get $global71)
                )
               )
               (else
                (if (result (ref $type12))
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (if
                   (i32.eqz
                    (global.get $ready72)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (ref.as_non_null
                   (global.get $global72)
                  )
                 )
                 (else
                  (if (result (ref $type12))
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (if
                     (i32.eqz
                      (global.get $ready73)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (ref.as_non_null
                     (global.get $global73)
                    )
                   )
                   (else
                    (if (result (ref $type12))
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (if
                       (i32.eqz
                        (global.get $ready74)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (ref.as_non_null
                       (global.get $global74)
                      )
                     )
                     (else
                      (if (result (ref $type12))
                       (i64.eq
                        (local.get $2)
                        (i64.const 10)
                       )
                       (then
                        (if
                         (i32.eqz
                          (global.get $ready75)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (ref.as_non_null
                         (global.get $global75)
                        )
                       )
                       (else
                        (if (result (ref $type22))
                         (i64.eq
                          (local.get $2)
                          (i64.const 11)
                         )
                         (then
                          (if
                           (i32.eqz
                            (global.get $ready76)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (ref.as_non_null
                           (global.get $global76)
                          )
                         )
                         (else
                          (unreachable)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function44 (type $call26) (param $0 (ref $type12)) (result (ref $type12))
  (local $1 (ref $type12))
  (local $2 (ref $type12))
  (local $3 (ref $type12))
  (local $4 (ref $type12))
  (local $5 (ref $type12))
  (local $6 (ref $type19))
  (local $7 (ref $type26))
  (local $8 (ref $type20))
  (local $9 (ref $type21))
  (local $10 (ref $type24))
  (local $11 (ref $type15))
  (local $12 (ref $type22))
  (local $13 (ref $type22))
  (local $14 i32)
  (local $scratch (ref $type12))
  (local $scratch_16 (ref $type12))
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if (result (ref $type12))
   (if (result i32)
    (local.tee $14
     (struct.get $type12 0
      (local.get $0)
     )
    )
    (then
     (if (result i32)
      (i32.eq
       (local.get $14)
       (i32.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (if (result i32)
        (i32.eq
         (struct.get $type12 0
          (local.get $0)
         )
         (i32.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (i32.eq
           (struct.get $type12 0
            (local.get $0)
           )
           (i32.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type12 0
              (local.get $0)
             )
             (i32.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type12 0
                (local.get $0)
               )
               (i32.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type12 0
                  (local.get $0)
                 )
                 (i32.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type12 0
                    (local.get $0)
                   )
                   (i32.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type12 0
                      (local.get $0)
                     )
                     (i32.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type12 0
                        (local.get $0)
                       )
                       (i32.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i32.eq
                         (struct.get $type12 0
                          (local.get $0)
                         )
                         (i32.const 10)
                        )
                        (then
                         (drop
                          (ref.cast (ref $type23)
                           (local.get $0)
                          )
                         )
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (ref.cast (ref $type24)
                           (local.get $0)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.ne
      (struct.get $type12 0
       (local.get $0)
      )
      (i32.const 11)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type24 1
      (ref.cast (ref $type24)
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if (result (ref $type24))
     (if (result i32)
      (local.tee $14
       (struct.get $type12 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $14)
         (i32.const 1)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (i32.eq
           (struct.get $type12 0
            (local.get $1)
           )
           (i32.const 2)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type12 0
              (local.get $1)
             )
             (i32.const 3)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type12 0
                (local.get $1)
               )
               (i32.const 4)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type12 0
                  (local.get $1)
                 )
                 (i32.const 5)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type12 0
                    (local.get $1)
                   )
                   (i32.const 6)
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (if
                    (i32.ne
                     (local.tee $14
                      (struct.get $type12 0
                       (local.get $1)
                      )
                     )
                     (i32.const 7)
                    )
                    (then
                     (if
                      (i32.and
                       (i32.ne
                        (local.get $14)
                        (i32.const 8)
                       )
                       (i32.ne
                        (local.get $14)
                        (i32.const 9)
                       )
                      )
                      (then
                       (if
                        (i32.eq
                         (local.get $14)
                         (i32.const 10)
                        )
                        (then
                         (drop
                          (ref.cast (ref $type23)
                           (local.get $1)
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.cast (ref $type24)
                           (local.get $1)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (i32.const 0)
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready73)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (ref.as_non_null
        (global.get $global73)
       )
      )
      (if
       (i32.eqz
        (global.get $ready167)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (ref.as_non_null
        (global.get $global167)
       )
      )
      (if
       (i32.ne
        (struct.get $type12 0
         (local.get $0)
        )
        (i32.const 11)
       )
       (then
        (unreachable)
       )
      )
      (local.set $0
       (struct.get $type24 2
        (ref.cast (ref $type24)
         (local.get $0)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready146)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global146)
       )
      )
      (struct.new $type24
       (i32.const 11)
       (local.get $6)
       (call $function39
        (local.get $7)
        (local.get $0)
       )
      )
     )
     (else
      (if
       (i32.ne
        (struct.get $type12 0
         (local.get $0)
        )
        (i32.const 11)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type24 1
        (ref.cast (ref $type24)
         (local.get $0)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready115)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if (result (ref $type24))
       (if (result i32)
        (local.tee $14
         (struct.get $type12 0
          (local.get $1)
         )
        )
        (then
         (if (result i32)
          (i32.eq
           (local.get $14)
           (i32.const 1)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type12 0
              (local.get $1)
             )
             (i32.const 2)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type12 0
                (local.get $1)
               )
               (i32.const 3)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type12 0
                  (local.get $1)
                 )
                 (i32.const 4)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type12 0
                    (local.get $1)
                   )
                   (i32.const 5)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type12 0
                      (local.get $1)
                     )
                     (i32.const 6)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type12 0
                        (local.get $1)
                       )
                       (i32.const 7)
                      )
                      (then
                       (i32.const 1)
                      )
                      (else
                       (if
                        (i32.and
                         (i32.ne
                          (local.tee $14
                           (struct.get $type12 0
                            (local.get $1)
                           )
                          )
                          (i32.const 8)
                         )
                         (i32.ne
                          (local.get $14)
                          (i32.const 9)
                         )
                        )
                        (then
                         (if
                          (i32.eq
                           (local.get $14)
                           (i32.const 10)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type23)
                             (local.get $1)
                            )
                           )
                          )
                          (else
                           (drop
                            (ref.cast (ref $type24)
                             (local.get $1)
                            )
                           )
                          )
                         )
                        )
                       )
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (if
         (i32.eqz
          (global.get $ready74)
         )
         (then
          (unreachable)
         )
        )
        (local.set $8
         (ref.as_non_null
          (global.get $global74)
         )
        )
        (if
         (i32.eqz
          (global.get $ready167)
         )
         (then
          (unreachable)
         )
        )
        (local.set $7
         (ref.as_non_null
          (global.get $global167)
         )
        )
        (if
         (i32.ne
          (struct.get $type12 0
           (local.get $0)
          )
          (i32.const 11)
         )
         (then
          (unreachable)
         )
        )
        (local.set $0
         (struct.get $type24 2
          (ref.cast (ref $type24)
           (local.get $0)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready146)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global146)
         )
        )
        (struct.new $type24
         (i32.const 11)
         (local.get $8)
         (call $function39
          (local.get $7)
          (local.get $0)
         )
        )
       )
       (else
        (if
         (i32.ne
          (struct.get $type12 0
           (local.get $0)
          )
          (i32.const 11)
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type24 1
          (ref.cast (ref $type24)
           (local.get $0)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (if (result (ref $type24))
         (if (result i32)
          (local.tee $14
           (struct.get $type12 0
            (local.get $1)
           )
          )
          (then
           (if (result i32)
            (i32.eq
             (local.get $14)
             (i32.const 1)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type12 0
                (local.get $1)
               )
               (i32.const 2)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type12 0
                  (local.get $1)
                 )
                 (i32.const 3)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type12 0
                    (local.get $1)
                   )
                   (i32.const 4)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type12 0
                      (local.get $1)
                     )
                     (i32.const 5)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type12 0
                        (local.get $1)
                       )
                       (i32.const 6)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i32.eq
                         (struct.get $type12 0
                          (local.get $1)
                         )
                         (i32.const 7)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i32.eq
                           (struct.get $type12 0
                            (local.get $1)
                           )
                           (i32.const 8)
                          )
                          (then
                           (i32.const 1)
                          )
                          (else
                           (if
                            (i32.ne
                             (local.tee $14
                              (struct.get $type12 0
                               (local.get $1)
                              )
                             )
                             (i32.const 9)
                            )
                            (then
                             (if
                              (i32.eq
                               (local.get $14)
                               (i32.const 10)
                              )
                              (then
                               (drop
                                (ref.cast (ref $type23)
                                 (local.get $1)
                                )
                               )
                              )
                              (else
                               (drop
                                (ref.cast (ref $type24)
                                 (local.get $1)
                                )
                               )
                              )
                             )
                            )
                           )
                           (i32.const 0)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready75)
           )
           (then
            (unreachable)
           )
          )
          (local.set $9
           (ref.as_non_null
            (global.get $global75)
           )
          )
          (if
           (i32.eqz
            (global.get $ready73)
           )
           (then
            (unreachable)
           )
          )
          (local.set $6
           (ref.as_non_null
            (global.get $global73)
           )
          )
          (if
           (i32.ne
            (struct.get $type12 0
             (local.get $0)
            )
            (i32.const 11)
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type24 2
            (ref.cast (ref $type24)
             (local.get $0)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready146)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global146)
           )
          )
          (local.set $10
           (struct.new $type24
            (i32.const 11)
            (local.get $6)
            (call $function39
             (struct.new $type26
              (ref.func $function45)
             )
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready137)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global137)
           )
          )
          (if
           (i32.eqz
            (global.get $ready69)
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type24
           (i32.const 11)
           (local.get $9)
           (struct.new $type24
            (i32.const 11)
            (local.get $0)
            (struct.new $type24
             (i32.const 11)
             (local.get $10)
             (ref.as_non_null
              (global.get $global69)
             )
            )
           )
          )
         )
         (else
          (if
           (i32.ne
            (struct.get $type12 0
             (local.get $0)
            )
            (i32.const 11)
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type24 1
            (ref.cast (ref $type24)
             (local.get $0)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready127)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global127)
           )
          )
          (if (result (ref $type24))
           (if (result i32)
            (local.tee $14
             (struct.get $type12 0
              (local.get $1)
             )
            )
            (then
             (if (result i32)
              (i32.eq
               (local.get $14)
               (i32.const 1)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type12 0
                  (local.get $1)
                 )
                 (i32.const 2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type12 0
                    (local.get $1)
                   )
                   (i32.const 3)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type12 0
                      (local.get $1)
                     )
                     (i32.const 4)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type12 0
                        (local.get $1)
                       )
                       (i32.const 5)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i32.eq
                         (struct.get $type12 0
                          (local.get $1)
                         )
                         (i32.const 6)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i32.eq
                           (struct.get $type12 0
                            (local.get $1)
                           )
                           (i32.const 7)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (if (result i32)
                            (i32.eq
                             (struct.get $type12 0
                              (local.get $1)
                             )
                             (i32.const 8)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if (result i32)
                              (i32.eq
                               (struct.get $type12 0
                                (local.get $1)
                               )
                               (i32.const 9)
                              )
                              (then
                               (i32.const 1)
                              )
                              (else
                               (if
                                (i32.eq
                                 (struct.get $type12 0
                                  (local.get $1)
                                 )
                                 (i32.const 10)
                                )
                                (then
                                 (drop
                                  (ref.cast (ref $type23)
                                   (local.get $1)
                                  )
                                 )
                                )
                                (else
                                 (drop
                                  (ref.cast (ref $type24)
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (i32.const 0)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (if
             (i32.eqz
              (global.get $ready74)
             )
             (then
              (unreachable)
             )
            )
            (local.set $8
             (ref.as_non_null
              (global.get $global74)
             )
            )
            (if
             (i32.eqz
              (global.get $ready76)
             )
             (then
              (unreachable)
             )
            )
            (local.set $12
             (ref.as_non_null
              (global.get $global76)
             )
            )
            (if
             (i32.eqz
              (global.get $ready133)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global133)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $1
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (call $function44
              (block (result (ref $type12))
               (local.set $scratch
                (struct.get $type24 1
                 (ref.cast (ref $type24)
                  (local.get $1)
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready167)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global167)
                )
               )
               (local.get $scratch)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready135)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global135)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $2
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $2
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $2)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type24 1
              (ref.cast (ref $type24)
               (local.get $2)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready137)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global137)
             )
            )
            (if
             (i32.eqz
              (global.get $ready69)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (global.get $ready76)
             )
             (then
              (unreachable)
             )
            )
            (local.set $13
             (ref.as_non_null
              (global.get $global76)
             )
            )
            (if
             (i32.eqz
              (global.get $ready133)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global133)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $5
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $5
             (struct.get $type24 1
              (ref.cast (ref $type24)
               (local.get $5)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready75)
             )
             (then
              (unreachable)
             )
            )
            (local.set $9
             (ref.as_non_null
              (global.get $global75)
             )
            )
            (if
             (i32.eqz
              (global.get $ready135)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global135)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $3
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $3
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $3)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type24 1
              (ref.cast (ref $type24)
               (local.get $3)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready135)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global135)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $4
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $4
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $4)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $4
             (struct.get $type24 1
              (ref.cast (ref $type24)
               (local.get $4)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready135)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global135)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $0
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type12 0
               (local.tee $0
                (struct.get $type24 2
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $0
             (call $function44
              (block (result (ref $type12))
               (local.set $scratch_16
                (struct.get $type24 1
                 (ref.cast (ref $type24)
                  (local.get $0)
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready167)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global167)
                )
               )
               (local.set $10
                (struct.new $type24
                 (i32.const 11)
                 (local.get $12)
                 (struct.new $type24
                  (i32.const 11)
                  (local.get $1)
                  (struct.new $type24
                   (i32.const 11)
                   (local.get $2)
                   (ref.as_non_null
                    (global.get $global69)
                   )
                  )
                 )
                )
               )
               (local.get $scratch_16)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready141)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global141)
             )
            )
            (if
             (i32.eqz
              (global.get $ready69)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (global.get $ready137)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global137)
             )
            )
            (if
             (i32.eqz
              (global.get $ready69)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (global.get $ready137)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global137)
             )
            )
            (if
             (i32.eqz
              (global.get $ready69)
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type24
             (i32.const 11)
             (local.get $8)
             (struct.new $type24
              (i32.const 11)
              (local.get $10)
              (struct.new $type24
               (i32.const 11)
               (struct.new $type24
                (i32.const 11)
                (local.get $13)
                (struct.new $type24
                 (i32.const 11)
                 (local.get $5)
                 (struct.new $type24
                  (i32.const 11)
                  (struct.new $type24
                   (i32.const 11)
                   (local.get $9)
                   (struct.new $type24
                    (i32.const 11)
                    (local.get $3)
                    (struct.new $type24
                     (i32.const 11)
                     (local.get $4)
                     (struct.new $type24
                      (i32.const 11)
                      (local.get $0)
                      (local.tee $11
                       (ref.as_non_null
                        (global.get $global69)
                       )
                      )
                     )
                    )
                   )
                  )
                  (local.get $11)
                 )
                )
               )
               (local.get $11)
              )
             )
            )
           )
           (else
            (unreachable)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready91)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global91)
     )
    )
    (if (result (ref $type23))
     (if (result i32)
      (local.tee $14
       (struct.get $type12 0
        (local.get $0)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $14)
         (i32.const 1)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (i32.eq
           (struct.get $type12 0
            (local.get $0)
           )
           (i32.const 2)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type12 0
              (local.get $0)
             )
             (i32.const 3)
            )
            (then
             (i32.const 1)
            )
            (else
             (if
              (i32.and
               (i32.ne
                (local.tee $14
                 (struct.get $type12 0
                  (local.get $0)
                 )
                )
                (i32.const 4)
               )
               (i32.ne
                (local.get $14)
                (i32.const 5)
               )
              )
              (then
               (if
                (i32.and
                 (i32.ne
                  (local.get $14)
                  (i32.const 6)
                 )
                 (i32.ne
                  (local.get $14)
                  (i32.const 7)
                 )
                )
                (then
                 (if
                  (i32.and
                   (i32.ne
                    (local.get $14)
                    (i32.const 8)
                   )
                   (i32.ne
                    (local.get $14)
                    (i32.const 9)
                   )
                  )
                  (then
                   (if
                    (i32.eq
                     (local.get $14)
                     (i32.const 10)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type23)
                       (local.get $0)
                      )
                     )
                    )
                    (else
                     (drop
                      (ref.cast (ref $type24)
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 0)
            )
           )
          )
         )
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready78)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (global.get $global78)
      )
     )
     (else
      (if
       (i32.eqz
        (global.get $ready77)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (global.get $global77)
      )
     )
    )
   )
  )
 )
 (func $function45 (type $call26) (param $0 (ref $type12)) (result (ref $type12))
  (local $1 (ref $type22))
  (local $2 (ref $type12))
  (if
   (i32.eqz
    (global.get $ready76)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global76)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (local.set $2
   (call $function44
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready69)
   )
   (then
    (unreachable)
   )
  )
  (struct.new $type24
   (i32.const 11)
   (local.get $1)
   (struct.new $type24
    (i32.const 11)
    (local.get $2)
    (struct.new $type24
     (i32.const 11)
     (local.get $0)
     (ref.as_non_null
      (global.get $global69)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type12))
  (local $2 (ref $type12))
  (local $scratch (ref $type12))
  (local $scratch_4 (ref $type12))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready172)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global172)
   )
  )
  (if
   (i32.eqz
    (global.get $ready170)
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function40
     (call $function44
      (block (result (ref $type12))
       (local.set $scratch
        (ref.as_non_null
         (global.get $global170)
        )
       )
       (if
        (i32.eqz
         (global.get $ready167)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global167)
        )
       )
       (local.get $scratch)
      )
     )
     (block (result (ref $type12))
      (if
       (i32.eqz
        (global.get $ready171)
       )
       (then
        (unreachable)
       )
      )
      (local.set $scratch_4
       (ref.as_non_null
        (global.get $global171)
       )
      )
      (if
       (i32.eqz
        (global.get $ready149)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global149)
       )
      )
      (local.get $scratch_4)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (local $0 (ref $type32))
  (local $1 (ref $type12))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type11)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global67
   (struct.new_default $type13)
  )
  (global.set $ready67
   (i32.const 1)
  )
  (global.set $global68
   (struct.new $type14
    (i32.const 1)
   )
  )
  (global.set $ready68
   (i32.const 1)
  )
  (global.set $global69
   (struct.new $type15
    (i32.const 2)
   )
  )
  (global.set $ready69
   (i32.const 1)
  )
  (global.set $global70
   (struct.new $type16
    (i32.const 3)
   )
  )
  (global.set $ready70
   (i32.const 1)
  )
  (global.set $global71
   (struct.new $type17
    (i32.const 4)
   )
  )
  (global.set $ready71
   (i32.const 1)
  )
  (global.set $global72
   (struct.new $type18
    (i32.const 5)
   )
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global73
   (struct.new $type19
    (i32.const 6)
   )
  )
  (global.set $ready73
   (i32.const 1)
  )
  (global.set $global74
   (struct.new $type20
    (i32.const 7)
   )
  )
  (global.set $ready74
   (i32.const 1)
  )
  (global.set $global75
   (struct.new $type21
    (i32.const 8)
   )
  )
  (global.set $ready75
   (i32.const 1)
  )
  (global.set $global76
   (struct.new $type22
    (i32.const 9)
   )
  )
  (global.set $ready76
   (i32.const 1)
  )
  (global.set $global77
   (struct.new $type23
    (i32.const 10)
    (i64.const 0)
   )
  )
  (global.set $ready77
   (i32.const 1)
  )
  (global.set $global78
   (struct.new $type23
    (i32.const 10)
    (i64.const 1)
   )
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global79
   (struct.new_default $type25)
  )
  (global.set $ready79
   (i32.const 1)
  )
  (global.set $global85
   (struct.new_default $type25)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global91
   (struct.new_default $type25)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type25)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global115
   (struct.new_default $type25)
  )
  (global.set $ready115
   (i32.const 1)
  )
  (global.set $global121
   (struct.new_default $type25)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type25)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global133
   (struct.new $type26
    (ref.func $function35)
   )
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global135
   (struct.new $type26
    (ref.func $function36)
   )
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type27)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type28)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global146
   (struct.new_default $type29)
  )
  (global.set $ready146
   (i32.const 1)
  )
  (global.set $global149
   (struct.new_default $type30)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global153
   (struct.new_default $type31)
  )
  (global.set $ready153
   (i32.const 1)
  )
  (global.set $global157
   (struct.new_default $type33)
  )
  (global.set $ready157
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type34)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global167
   (struct.new $type26
    (ref.func $function44)
   )
  )
  (global.set $ready167
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global157)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $1
   (call $function43
    (i32.const 0)
    (local.tee $0
     (struct.new_default $type32)
    )
   )
  )
  (global.set $global170
   (if (result (ref $type12))
    (i64.eq
     (struct.get $type32 0
      (local.get $0)
     )
     (call $foreign1
      (i32.const 0)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $ready170
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready157)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global157)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $1
   (call $function43
    (i32.const 1)
    (local.tee $0
     (struct.new_default $type32)
    )
   )
  )
  (global.set $global171
   (if (result (ref $type12))
    (i64.eq
     (struct.get $type32 0
      (local.get $0)
     )
     (call $foreign1
      (i32.const 1)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $ready171
   (i32.const 1)
  )
  (global.set $global172
   (struct.new_default $type35)
  )
  (global.set $ready172
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

