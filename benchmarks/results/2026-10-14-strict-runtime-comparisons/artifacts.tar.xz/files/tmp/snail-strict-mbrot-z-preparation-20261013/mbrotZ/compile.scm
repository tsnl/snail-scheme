(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-mbrot-z-preparation-20261013/mbrotZ/program.scm" "/tmp/snail-strict-mbrot-z-preparation-20261013/mbrotZ/program.so"))
