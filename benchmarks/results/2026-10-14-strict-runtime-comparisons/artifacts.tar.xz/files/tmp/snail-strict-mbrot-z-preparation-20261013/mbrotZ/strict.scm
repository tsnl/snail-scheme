(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-data Complex64
  (complex64 (real F64 complex64-real) (imag F64 complex64-imag)))
(define (complex64-add left right)
  (complex64 (+ (complex64-real left) (complex64-real right))
             (+ (complex64-imag left) (complex64-imag right))))
(define (complex64-scale value scale)
  (complex64 (* (complex64-real value) scale)
             (* (complex64-imag value) scale)))
(define (complex64-multiply left right)
  (let ((a (complex64-real left)) (b (complex64-imag left))
        (c (complex64-real right)) (d (complex64-imag right)))
    (complex64 (- (* a c) (* b d)) (+ (* a d) (* b c)))))
(define mbrot-z-origin (complex64 -1.0 -0.5))
(define mbrot-empty-row (make-vector 0 0))
(define (hide count x) (hide-i64 x))
;;; MBROT -- Generation of Mandelbrot set fractal
;;; using Scheme's complex numbers.


(define (count z0 step z)

  (let* ((max-count 64)
         (radius    4.0)
         (radius^2  (* radius radius)))

    (let ((z0 (complex64-add z0 (complex64-scale z step))))

      (let loop ((z z0)
                 (c 0))
        (if (= c max-count)
            c
            (let* ((zr (complex64-real z))
                   (zi (complex64-imag z))
                   (zr^2 (* zr zr))
                   (zi^2 (* zi zi)))
              (if (> (+ zr^2 zi^2) radius^2)
                  c
                  (loop (complex64-add (complex64-multiply z z) z0) (+ c 1)))))))))

(define (mbrot matrix z0 step n)
  (let loop1 ((y (- n 1)))
    (when (>= y 0)
        (let loop2 ((x (- n 1)))
          (if (>= x 0)
            (begin
              (vector-set! (vector-ref matrix x)
                            y
                            (count z0
                                   step
                                   (complex64 (i64->f64 x)
                                                     (i64->f64 y))))
              (loop2 (- x 1)))
            (loop1 (- y 1)))))))

(define (test n)
  (let ((matrix (make-vector n mbrot-empty-row)))
    (let loop ((i (- n 1)))
      (when (>= i 0)
        (vector-set! matrix i (make-vector n 0))
        (loop (- i 1))))
    (mbrot matrix mbrot-z-origin 0.005 n)
    (vector-ref (vector-ref matrix 0) 0)))

(define input0 (native-input-i64 (ann 0 I32)))
(: bench (-> I64 I64))
(define (bench count) (if (<= count 0) (unreachable)
    (let loop ((i 0) (result 0))
      (if (< i count) (loop (+ i 1) (test (hide count input0))) result))))
(unit)
