(module
 (rec
  (type $0 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $1 (func (param i64 f64 (ref $type12) i32 i32 (ref $type12) i64) (result i64)))
  (type $2 (func (param (ref $type18) (ref $type12) f64 i64 i32 i32 i64 i32 i32 i64) (result i32)))
  (type $3 (func (param i64 (ref $type18) i32 i32 i64) (result i32)))
  (type $type18 (array (mut (ref $type14))))
  (type $call19 (func (param i64) (result i64)))
  (type $type19 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type15 (struct))
  (type $type14 (array (mut i64)))
  (type $type12 (struct (field f64) (field f64)))
  (type $type13 (struct))
  (type $type11 (struct))
 )
 (type $14 (func (param i64) (result i64)))
 (type $15 (func (param i32) (result i64)))
 (type $16 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type11)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global95 (mut (ref null $type13)) (ref.null none))
 (global $ready95 (mut i32) (i32.const 0))
 (global $global64 (mut (ref null $type11)) (ref.null none))
 (global $ready64 (mut i32) (i32.const 0))
 (global $global71 (mut (ref null $type12)) (ref.null none))
 (global $ready71 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type14)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type15)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type16)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type17)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global73 (mut (ref null $type19)) (ref.null none))
 (global $ready73 (mut i32) (i32.const 0))
 (global $global105 (mut i64) (i64.const 0))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type19)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function27 (type $call19) (param $0 i64) (result i64)
  (local $1 i64)
  (local $2 (ref $type18))
  (local $3 (ref $type12))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (array.new $type18
    (ref.as_non_null
     (global.get $global72)
    )
    (i32.wrap_i64
     (local.get $0)
    )
   )
  )
  (drop
   (if (result i32)
    (i64.ge_s
     (local.tee $1
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
     )
     (i64.const 0)
    )
    (then
     (if
      (i64.gt_u
       (local.get $0)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (array.set $type18
      (local.get $2)
      (i32.wrap_i64
       (local.get $1)
      )
      (array.new_default $type14
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
     (if (result i32)
      (i64.ge_s
       (local.tee $1
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.set $type18
        (local.get $2)
        (i32.wrap_i64
         (local.get $1)
        )
        (array.new_default $type14
         (i32.wrap_i64
          (local.get $0)
         )
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.tee $1
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $0)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type18
          (local.get $2)
          (i32.wrap_i64
           (local.get $1)
          )
          (array.new_default $type14
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
         (if (result i32)
          (i64.ge_s
           (local.tee $1
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i64.gt_u
             (local.get $1)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.set $type18
            (local.get $2)
            (i32.wrap_i64
             (local.get $1)
            )
            (array.new_default $type14
             (i32.wrap_i64
              (local.get $0)
             )
            )
           )
           (if (result i32)
            (i64.ge_s
             (local.tee $1
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (if
              (i64.gt_u
               (local.get $0)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i64.gt_u
               (local.get $1)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (array.set $type18
              (local.get $2)
              (i32.wrap_i64
               (local.get $1)
              )
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $0)
               )
              )
             )
             (if (result i32)
              (i64.ge_s
               (local.tee $1
                (i64.sub
                 (local.get $1)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (if
                (i64.gt_u
                 (local.get $0)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (array.set $type18
                (local.get $2)
                (i32.wrap_i64
                 (local.get $1)
                )
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $0)
                 )
                )
               )
               (if (result i32)
                (i64.ge_s
                 (local.tee $1
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (if
                  (i64.gt_u
                   (local.get $0)
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i64.gt_u
                   (local.get $1)
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (array.set $type18
                  (local.get $2)
                  (i32.wrap_i64
                   (local.get $1)
                  )
                  (array.new_default $type14
                   (i32.wrap_i64
                    (local.get $0)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.ge_s
                   (local.tee $1
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (if
                    (i64.gt_u
                     (local.get $0)
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.get $1)
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (array.set $type18
                    (local.get $2)
                    (i32.wrap_i64
                     (local.get $1)
                    )
                    (array.new_default $type14
                     (i32.wrap_i64
                      (local.get $0)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.ge_s
                     (local.tee $1
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (if
                      (i64.gt_u
                       (local.get $0)
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if
                      (i64.gt_u
                       (local.get $1)
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (array.set $type18
                      (local.get $2)
                      (i32.wrap_i64
                       (local.get $1)
                      )
                      (array.new_default $type14
                       (i32.wrap_i64
                        (local.get $0)
                       )
                      )
                     )
                     (if (result i32)
                      (i64.ge_s
                       (local.tee $1
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $0)
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i64.gt_u
                         (local.get $1)
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (array.set $type18
                        (local.get $2)
                        (i32.wrap_i64
                         (local.get $1)
                        )
                        (array.new_default $type14
                         (i32.wrap_i64
                          (local.get $0)
                         )
                        )
                       )
                       (call $function28
                        (local.get $0)
                        (local.get $2)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready71)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global71)
   )
  )
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global78)
   )
  )
  (drop
   (if (result i32)
    (i64.ge_s
     (local.tee $1
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
     )
     (i64.const 0)
    )
    (then
     (call $function31
      (local.get $2)
      (local.get $3)
      (f64.const 0.005)
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (local.get $1)
      (i32.const 0)
      (i32.const 1)
      (local.get $1)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (array.get $type14
   (array.get $type18
    (local.get $2)
    (i32.const 0)
   )
   (i32.const 0)
  )
 )
 (func $function28 (type $3) (param $0 i64) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.ge_s
    (local.get $4)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type18
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
     (array.new_default $type14
      (i32.wrap_i64
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function28
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function31 (type $2) (param $0 (ref $type18)) (param $1 (ref $type12)) (param $2 f64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i32) (param $8 i32) (param $9 i64) (result i32)
  (local $10 (ref $type14))
  (local $11 (ref $type12))
  (local $12 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $9)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (array.get $type18
      (local.get $0)
      (i32.wrap_i64
       (local.get $9)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready87)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global87)
       )
      )
      (if
       (i32.eqz
        (global.get $ready95)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global95)
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (local.set $12
       (call $function34
        (i64.const 64)
        (f64.const 16)
        (local.tee $11
         (struct.new $type12
          (f64.add
           (struct.get $type12 0
            (local.get $1)
           )
           (f64.mul
            (f64.convert_i64_s
             (local.get $9)
            )
            (local.get $2)
           )
          )
          (f64.add
           (struct.get $type12 1
            (local.get $1)
           )
           (f64.mul
            (f64.convert_i64_s
             (local.get $6)
            )
            (local.get $2)
           )
          )
         )
        )
        (i32.const 0)
        (i32.const 1)
        (local.get $11)
        (i64.const 0)
       )
      )
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
     (local.get $12)
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function31
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (i64.sub
      (local.get $9)
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.ge_s
      (local.tee $6
       (i64.sub
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (return_call $function31
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (i32.const 0)
       (i32.const 1)
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function34 (type $1) (param $0 i64) (param $1 f64) (param $2 (ref $type12)) (param $3 i32) (param $4 i32) (param $5 (ref $type12)) (param $6 i64) (result i64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (if (result i64)
   (i64.eq
    (local.get $0)
    (local.get $6)
   )
   (then
    (local.get $6)
   )
   (else
    (if (result i64)
     (f64.lt
      (local.get $1)
      (f64.add
       (f64.mul
        (local.tee $7
         (struct.get $type12 0
          (local.get $5)
         )
        )
        (local.get $7)
       )
       (f64.mul
        (local.tee $7
         (struct.get $type12 1
          (local.get $5)
         )
        )
        (local.get $7)
       )
      )
     )
     (then
      (local.get $6)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready64)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global64)
       )
      )
      (local.set $9
       (f64.sub
        (f64.mul
         (local.tee $7
          (struct.get $type12 0
           (local.get $5)
          )
         )
         (local.get $7)
        )
        (f64.mul
         (local.tee $8
          (struct.get $type12 1
           (local.get $5)
          )
         )
         (local.get $8)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function34
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (struct.new $type12
        (f64.add
         (local.get $9)
         (struct.get $type12 0
          (local.get $2)
         )
        )
        (f64.add
         (f64.add
          (f64.mul
           (local.get $7)
           (local.get $8)
          )
          (f64.mul
           (local.get $8)
           (local.get $7)
          )
         )
         (struct.get $type12 1
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $6)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function36 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready105)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.set $4
     (call $function27
      (block (result i64)
       (local.set $scratch
        (call $foreign0
         (global.get $global105)
        )
       )
       (if
        (i32.eqz
         (global.get $ready73)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global73)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function36
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (if
   (i64.le_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (unreachable)
   )
   (else
    (return_call $function36
     (local.get $0)
     (i32.const 0)
     (i32.const 1)
     (i64.const 0)
     (i64.const 0)
    )
   )
  )
  (unreachable)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type11)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global95
   (struct.new_default $type13)
  )
  (global.set $ready95
   (i32.const 1)
  )
  (global.set $global64
   (struct.new_default $type11)
  )
  (global.set $ready64
   (i32.const 1)
  )
  (global.set $global71
   (struct.new $type12
    (f64.const -1)
    (f64.const -0.5)
   )
  )
  (global.set $ready71
   (i32.const 1)
  )
  (global.set $global72
   (array.new_default $type14
    (i32.const 0)
   )
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type15)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type16)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type17)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global73
   (struct.new_default $type19)
  )
  (global.set $ready73
   (i32.const 1)
  )
  (global.set $global105
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type19)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

