(module
 (rec
  (type $0 (func (param i64 f64 f64 f64 f64) (result (ref $type12))))
  (type $1 (func (param (ref $type14) i32 i32 i64) (result i32)))
  (type $2 (func (param (ref $type17) i32 i32 i64) (result i32)))
  (type $call20 (func (param i64) (result i32)))
  (type $4 (func (param i64 f64 (ref $type12) i32 i32 (ref $type12) i64) (result i64)))
  (type $5 (func (param (ref $type17) (ref $type12) f64 i64 i32 i32 i64 i32 i32 i64) (result i32)))
  (type $6 (func (param i64 (ref $type17) i32 i32 i64) (result i32)))
  (type $type17 (array (mut (ref $type14))))
  (type $8 (func (param i64) (result (ref $type17))))
  (type $type23 (struct))
  (type $type22 (struct))
  (type $type21 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type18 (struct))
  (type $type16 (struct))
  (type $type15 (struct))
  (type $type14 (array (mut i64)))
  (type $type12 (struct (field f64) (field f64)))
  (type $type13 (struct))
  (type $type11 (struct))
 )
 (type $21 (func (param i64)))
 (type $22 (func (param i64 f64 f64 f64 f64) (result f64)))
 (type $23 (func (param i64 i64 i64)))
 (type $24 (func (param f64 f64 f64 f64 f64) (result i64)))
 (type $25 (func))
 (import "probe" "store" (func $foreign0 (param i64 i64 i64)))
 (import "probe" "i64" (func $foreign1 (param i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type11)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global95 (mut (ref null $type13)) (ref.null none))
 (global $ready95 (mut i32) (i32.const 0))
 (global $global64 (mut (ref null $type11)) (ref.null none))
 (global $ready64 (mut i32) (i32.const 0))
 (global $global71 (mut (ref null $type12)) (ref.null none))
 (global $ready71 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type14)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type15)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type16)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global73 (mut (ref null $type18)) (ref.null none))
 (global $ready73 (mut i32) (i32.const 0))
 (global $global105 (mut (ref null $type19)) (ref.null none))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type20)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type21)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type22)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type22)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type23)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (export "probe-grid" (func $export0))
 (export "probe-real" (func $export1))
 (export "probe-imag" (func $export2))
 (export "probe-count" (func $export3))
 (export "main" (func $main))
 (func $function27 (type $8) (param $0 i64) (result (ref $type17))
  (local $1 i64)
  (local $2 (ref $type17))
  (local $3 (ref $type12))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (array.new $type17
    (ref.as_non_null
     (global.get $global72)
    )
    (i32.wrap_i64
     (local.get $0)
    )
   )
  )
  (drop
   (if (result i32)
    (i64.ge_s
     (local.tee $1
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
     )
     (i64.const 0)
    )
    (then
     (if
      (i64.gt_u
       (local.get $0)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (array.set $type17
      (local.get $2)
      (i32.wrap_i64
       (local.get $1)
      )
      (array.new_default $type14
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
     (if (result i32)
      (i64.ge_s
       (local.tee $1
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.set $type17
        (local.get $2)
        (i32.wrap_i64
         (local.get $1)
        )
        (array.new_default $type14
         (i32.wrap_i64
          (local.get $0)
         )
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.tee $1
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $0)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type17
          (local.get $2)
          (i32.wrap_i64
           (local.get $1)
          )
          (array.new_default $type14
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
         (if (result i32)
          (i64.ge_s
           (local.tee $1
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i64.gt_u
             (local.get $1)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.set $type17
            (local.get $2)
            (i32.wrap_i64
             (local.get $1)
            )
            (array.new_default $type14
             (i32.wrap_i64
              (local.get $0)
             )
            )
           )
           (if (result i32)
            (i64.ge_s
             (local.tee $1
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (if
              (i64.gt_u
               (local.get $0)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i64.gt_u
               (local.get $1)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (array.set $type17
              (local.get $2)
              (i32.wrap_i64
               (local.get $1)
              )
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $0)
               )
              )
             )
             (if (result i32)
              (i64.ge_s
               (local.tee $1
                (i64.sub
                 (local.get $1)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (if
                (i64.gt_u
                 (local.get $0)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (array.set $type17
                (local.get $2)
                (i32.wrap_i64
                 (local.get $1)
                )
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $0)
                 )
                )
               )
               (if (result i32)
                (i64.ge_s
                 (local.tee $1
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (if
                  (i64.gt_u
                   (local.get $0)
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i64.gt_u
                   (local.get $1)
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (array.set $type17
                  (local.get $2)
                  (i32.wrap_i64
                   (local.get $1)
                  )
                  (array.new_default $type14
                   (i32.wrap_i64
                    (local.get $0)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.ge_s
                   (local.tee $1
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (if
                    (i64.gt_u
                     (local.get $0)
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.get $1)
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (array.set $type17
                    (local.get $2)
                    (i32.wrap_i64
                     (local.get $1)
                    )
                    (array.new_default $type14
                     (i32.wrap_i64
                      (local.get $0)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.ge_s
                     (local.tee $1
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (if
                      (i64.gt_u
                       (local.get $0)
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if
                      (i64.gt_u
                       (local.get $1)
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (array.set $type17
                      (local.get $2)
                      (i32.wrap_i64
                       (local.get $1)
                      )
                      (array.new_default $type14
                       (i32.wrap_i64
                        (local.get $0)
                       )
                      )
                     )
                     (if (result i32)
                      (i64.ge_s
                       (local.tee $1
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $0)
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i64.gt_u
                         (local.get $1)
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (array.set $type17
                        (local.get $2)
                        (i32.wrap_i64
                         (local.get $1)
                        )
                        (array.new_default $type14
                         (i32.wrap_i64
                          (local.get $0)
                         )
                        )
                       )
                       (call $function28
                        (local.get $0)
                        (local.get $2)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready71)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global71)
   )
  )
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global78)
   )
  )
  (drop
   (if (result i32)
    (i64.ge_s
     (local.tee $1
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
     )
     (i64.const 0)
    )
    (then
     (call $function31
      (local.get $2)
      (local.get $3)
      (f64.const 0.005)
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (local.get $1)
      (i32.const 0)
      (i32.const 1)
      (local.get $1)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (local.get $2)
 )
 (func $function28 (type $6) (param $0 i64) (param $1 (ref $type17)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.ge_s
    (local.get $4)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
     (array.new_default $type14
      (i32.wrap_i64
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function28
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function31 (type $5) (param $0 (ref $type17)) (param $1 (ref $type12)) (param $2 f64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i32) (param $8 i32) (param $9 i64) (result i32)
  (local $10 i64)
  (local $11 (ref $type12))
  (if (result i32)
   (i64.ge_s
    (local.get $9)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (if
     (i32.eqz
      (global.get $ready95)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global95)
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $10
     (call $function34
      (i64.const 64)
      (f64.const 16)
      (local.tee $11
       (struct.new $type12
        (f64.add
         (struct.get $type12 0
          (local.get $1)
         )
         (f64.mul
          (f64.convert_i64_s
           (local.get $9)
          )
          (local.get $2)
         )
        )
        (f64.add
         (struct.get $type12 1
          (local.get $1)
         )
         (f64.mul
          (f64.convert_i64_s
           (local.get $6)
          )
          (local.get $2)
         )
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
      (local.get $11)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready105)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global105)
     )
    )
    (call $foreign0
     (local.get $9)
     (local.get $6)
     (local.get $10)
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (array.get $type17
      (local.get $0)
      (i32.wrap_i64
       (local.get $9)
      )
     )
     (i32.wrap_i64
      (local.get $6)
     )
     (local.get $10)
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function31
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (i64.sub
      (local.get $9)
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.ge_s
      (local.tee $6
       (i64.sub
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (return_call $function31
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (i32.const 0)
       (i32.const 1)
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function34 (type $4) (param $0 i64) (param $1 f64) (param $2 (ref $type12)) (param $3 i32) (param $4 i32) (param $5 (ref $type12)) (param $6 i64) (result i64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (if (result i64)
   (i64.eq
    (local.get $0)
    (local.get $6)
   )
   (then
    (local.get $6)
   )
   (else
    (if (result i64)
     (f64.lt
      (local.get $1)
      (f64.add
       (f64.mul
        (local.tee $7
         (struct.get $type12 0
          (local.get $5)
         )
        )
        (local.get $7)
       )
       (f64.mul
        (local.tee $7
         (struct.get $type12 1
          (local.get $5)
         )
        )
        (local.get $7)
       )
      )
     )
     (then
      (local.get $6)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready64)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global64)
       )
      )
      (local.set $9
       (f64.sub
        (f64.mul
         (local.tee $7
          (struct.get $type12 0
           (local.get $5)
          )
         )
         (local.get $7)
        )
        (f64.mul
         (local.tee $8
          (struct.get $type12 1
           (local.get $5)
          )
         )
         (local.get $8)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function34
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (struct.new $type12
        (f64.add
         (local.get $9)
         (struct.get $type12 0
          (local.get $2)
         )
        )
        (f64.add
         (f64.add
          (f64.mul
           (local.get $7)
           (local.get $8)
          )
          (f64.mul
           (local.get $8)
           (local.get $7)
          )
         )
         (struct.get $type12 1
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $6)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function36 (type $call20) (param $0 i64) (result i32)
  (local $1 (ref $type14))
  (local $2 (ref $type17))
  (if
   (i32.eqz
    (global.get $ready73)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global73)
   )
  )
  (call $foreign1
   (i64.extend_i32_u
    (array.len
     (local.tee $2
      (call $function27
       (local.get $0)
      )
     )
    )
   )
  )
  (if (result i32)
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.get $2)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign1
     (i64.extend_i32_u
      (array.len
       (local.tee $1
        (array.get $type17
         (local.get $2)
         (i32.const 0)
        )
       )
      )
     )
    )
    (drop
     (if (result i32)
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (local.get $1)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign1
        (array.get $type14
         (local.get $1)
         (i32.const 0)
        )
       )
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.get $1)
          )
         )
         (i64.const 1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign1
          (array.get $type14
           (local.get $1)
           (i32.const 1)
          )
         )
         (if (result i32)
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $1)
            )
           )
           (i64.const 2)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign1
            (array.get $type14
             (local.get $1)
             (i32.const 2)
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (i64.const 3)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign1
              (array.get $type14
               (local.get $1)
               (i32.const 3)
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (local.get $1)
                )
               )
               (i64.const 4)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign1
                (array.get $type14
                 (local.get $1)
                 (i32.const 4)
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $1)
                  )
                 )
                 (i64.const 5)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (array.get $type14
                   (local.get $1)
                   (i32.const 5)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $1)
                    )
                   )
                   (i64.const 6)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (array.get $type14
                     (local.get $1)
                     (i32.const 6)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                     (i64.const 7)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 7)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 8)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 8)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (array.len
        (local.get $2)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (call $foreign1
       (i64.extend_i32_u
        (array.len
         (local.tee $1
          (array.get $type17
           (local.get $2)
           (i32.const 1)
          )
         )
        )
       )
      )
      (drop
       (if (result i32)
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (local.get $1)
          )
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign1
          (array.get $type14
           (local.get $1)
           (i32.const 0)
          )
         )
         (if (result i32)
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $1)
            )
           )
           (i64.const 1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign1
            (array.get $type14
             (local.get $1)
             (i32.const 1)
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (i64.const 2)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign1
              (array.get $type14
               (local.get $1)
               (i32.const 2)
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (local.get $1)
                )
               )
               (i64.const 3)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign1
                (array.get $type14
                 (local.get $1)
                 (i32.const 3)
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $1)
                  )
                 )
                 (i64.const 4)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (array.get $type14
                   (local.get $1)
                   (i32.const 4)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $1)
                    )
                   )
                   (i64.const 5)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (array.get $type14
                     (local.get $1)
                     (i32.const 5)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                     (i64.const 6)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 6)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 7)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 7)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 8)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (array.len
          (local.get $2)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $foreign1
         (i64.extend_i32_u
          (array.len
           (local.tee $1
            (array.get $type17
             (local.get $2)
             (i32.const 2)
            )
           )
          )
         )
        )
        (drop
         (if (result i32)
          (i64.eqz
           (i64.extend_i32_u
            (array.len
             (local.get $1)
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign1
            (array.get $type14
             (local.get $1)
             (i32.const 0)
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (i64.const 1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign1
              (array.get $type14
               (local.get $1)
               (i32.const 1)
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (local.get $1)
                )
               )
               (i64.const 2)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign1
                (array.get $type14
                 (local.get $1)
                 (i32.const 2)
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $1)
                  )
                 )
                 (i64.const 3)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (array.get $type14
                   (local.get $1)
                   (i32.const 3)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $1)
                    )
                   )
                   (i64.const 4)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (array.get $type14
                     (local.get $1)
                     (i32.const 4)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                     (i64.const 5)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 5)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 6)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 6)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 7)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (array.len
            (local.get $2)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (call $foreign1
           (i64.extend_i32_u
            (array.len
             (local.tee $1
              (array.get $type17
               (local.get $2)
               (i32.const 3)
              )
             )
            )
           )
          )
          (drop
           (if (result i32)
            (i64.eqz
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign1
              (array.get $type14
               (local.get $1)
               (i32.const 0)
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (local.get $1)
                )
               )
               (i64.const 1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign1
                (array.get $type14
                 (local.get $1)
                 (i32.const 1)
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $1)
                  )
                 )
                 (i64.const 2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (array.get $type14
                   (local.get $1)
                   (i32.const 2)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $1)
                    )
                   )
                   (i64.const 3)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (array.get $type14
                     (local.get $1)
                     (i32.const 3)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                     (i64.const 4)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 4)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 5)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 5)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 6)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (array.len
              (local.get $2)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (call $foreign1
             (i64.extend_i32_u
              (array.len
               (local.tee $1
                (array.get $type17
                 (local.get $2)
                 (i32.const 4)
                )
               )
              )
             )
            )
            (drop
             (if (result i32)
              (i64.eqz
               (i64.extend_i32_u
                (array.len
                 (local.get $1)
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign1
                (array.get $type14
                 (local.get $1)
                 (i32.const 0)
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $1)
                  )
                 )
                 (i64.const 1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (array.get $type14
                   (local.get $1)
                   (i32.const 1)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $1)
                    )
                   )
                   (i64.const 2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (array.get $type14
                     (local.get $1)
                     (i32.const 2)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                     (i64.const 3)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 3)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 4)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 4)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 5)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (call $foreign1
               (i64.extend_i32_u
                (array.len
                 (local.tee $1
                  (array.get $type17
                   (local.get $2)
                   (i32.const 5)
                  )
                 )
                )
               )
              )
              (drop
               (if (result i32)
                (i64.eqz
                 (i64.extend_i32_u
                  (array.len
                   (local.get $1)
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (array.get $type14
                   (local.get $1)
                   (i32.const 0)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $1)
                    )
                   )
                   (i64.const 1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (array.get $type14
                     (local.get $1)
                     (i32.const 1)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                     (i64.const 2)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 2)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 3)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 3)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 4)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (call $foreign1
                 (i64.extend_i32_u
                  (array.len
                   (local.tee $1
                    (array.get $type17
                     (local.get $2)
                     (i32.const 6)
                    )
                   )
                  )
                 )
                )
                (drop
                 (if (result i32)
                  (i64.eqz
                   (i64.extend_i32_u
                    (array.len
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (array.get $type14
                     (local.get $1)
                     (i32.const 0)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                     (i64.const 1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 1)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 2)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 3)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (array.len
                    (local.get $2)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (call $foreign1
                   (i64.extend_i32_u
                    (array.len
                     (local.tee $1
                      (array.get $type17
                       (local.get $2)
                       (i32.const 7)
                      )
                     )
                    )
                   )
                  )
                  (drop
                   (if (result i32)
                    (i64.eqz
                     (i64.extend_i32_u
                      (array.len
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (array.get $type14
                       (local.get $1)
                       (i32.const 0)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                       (i64.const 1)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 1)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 2)
                       )
                      )
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (array.len
                      (local.get $2)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign1
                     (i64.extend_i32_u
                      (array.len
                       (local.tee $1
                        (array.get $type17
                         (local.get $2)
                         (i32.const 8)
                        )
                       )
                      )
                     )
                    )
                    (drop
                     (if (result i32)
                      (i64.eqz
                       (i64.extend_i32_u
                        (array.len
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (array.get $type14
                         (local.get $1)
                         (i32.const 0)
                        )
                       )
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 1)
                       )
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $2)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign1
                       (i64.extend_i32_u
                        (array.len
                         (local.tee $1
                          (array.get $type17
                           (local.get $2)
                           (i32.const 9)
                          )
                         )
                        )
                       )
                      )
                      (drop
                       (call $function38
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 0)
                       )
                      )
                      (return_call $function37
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function37 (type $2) (param $0 (ref $type17)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 (ref $type14))
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (i64.extend_i32_u
      (array.len
       (local.tee $4
        (array.get $type17
         (local.get $0)
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (drop
     (call $function38
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function37
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function38 (type $1) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type14
      (local.get $0)
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function40 (type $0) (param $0 i64) (param $1 f64) (param $2 f64) (param $3 f64) (param $4 f64) (result (ref $type12))
  (local $5 (ref $type12))
  (local.set $5
   (struct.new $type12
    (local.get $1)
    (local.get $2)
   )
  )
  (if (result (ref $type12))
   (i64.eqz
    (local.get $0)
   )
   (then
    (local.get $5)
   )
   (else
    (if (result (ref $type12))
     (i64.eq
      (local.get $0)
      (i64.const 1)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (struct.new $type12
       (f64.add
        (struct.get $type12 0
         (local.get $5)
        )
        (local.get $3)
       )
       (f64.add
        (struct.get $type12 1
         (local.get $5)
        )
        (local.get $4)
       )
      )
     )
     (else
      (if (result (ref $type12))
       (i64.eq
        (local.get $0)
        (i64.const 2)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready64)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global64)
         )
        )
        (struct.new $type12
         (f64.sub
          (f64.mul
           (local.tee $1
            (struct.get $type12 0
             (local.get $5)
            )
           )
           (local.get $3)
          )
          (f64.mul
           (local.tee $2
            (struct.get $type12 1
             (local.get $5)
            )
           )
           (local.get $4)
          )
         )
         (f64.add
          (f64.mul
           (local.get $1)
           (local.get $4)
          )
          (f64.mul
           (local.get $2)
           (local.get $3)
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready95)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global95)
         )
        )
        (struct.new $type12
         (f64.mul
          (struct.get $type12 0
           (local.get $5)
          )
          (local.get $3)
         )
         (f64.mul
          (struct.get $type12 1
           (local.get $5)
          )
          (local.get $3)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (drop
   (call $function36
    (local.get $0)
   )
  )
 )
 (func $export1 (param $0 i64) (param $1 f64) (param $2 f64) (param $3 f64) (param $4 f64) (result f64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (struct.get $type12 0
   (call $function40
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
    (local.get $4)
   )
  )
 )
 (func $export2 (param $0 i64) (param $1 f64) (param $2 f64) (param $3 f64) (param $4 f64) (result f64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (struct.get $type12 1
   (call $function40
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
    (local.get $4)
   )
  )
 )
 (func $export3 (param $0 f64) (param $1 f64) (param $2 f64) (param $3 f64) (param $4 f64) (result i64)
  (local $5 (ref $type12))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (if
   (i32.eqz
    (global.get $ready95)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global95)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (return_call $function34
   (i64.const 64)
   (f64.const 16)
   (local.tee $5
    (struct.new $type12
     (f64.add
      (local.get $0)
      (f64.mul
       (local.get $3)
       (local.get $2)
      )
     )
     (f64.add
      (local.get $1)
      (f64.mul
       (local.get $4)
       (local.get $2)
      )
     )
    )
   )
   (i32.const 0)
   (i32.const 1)
   (local.get $5)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type11)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global95
   (struct.new_default $type13)
  )
  (global.set $ready95
   (i32.const 1)
  )
  (global.set $global64
   (struct.new_default $type11)
  )
  (global.set $ready64
   (i32.const 1)
  )
  (global.set $global71
   (struct.new $type12
    (f64.const -1)
    (f64.const -0.5)
   )
  )
  (global.set $ready71
   (i32.const 1)
  )
  (global.set $global72
   (array.new_default $type14
    (i32.const 0)
   )
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type15)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type16)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global73
   (struct.new_default $type18)
  )
  (global.set $ready73
   (i32.const 1)
  )
  (global.set $global105
   (struct.new_default $type19)
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type20)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type21)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type22)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type22)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type23)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

