import fs from 'node:fs';
const [artifact, specification] = process.argv.slice(2);
const config = JSON.parse(fs.readFileSync(specification, 'utf8'));
const matrix = [], stores = [];
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), {probe: {
  i64: value => matrix.push(Number(value)),
  store: (x, y, value) => stores.push([Number(x), Number(y), Number(value)]),
}});
instance.exports.main();
function bits(value) {
  const bytes = new DataView(new ArrayBuffer(8));
  bytes.setFloat64(0, value, true);
  return bytes.getBigUint64(0, true).toString();
}
let actual;
if (config.mode === 'grid') {
  instance.exports['probe-grid'](BigInt(config.size));
  actual = {matrix, stores};
} else if (config.mode === 'components') {
  const arguments_ = [BigInt(config.operation), ...config.inputs];
  actual = ['probe-real', 'probe-imag'].map(name => bits(instance.exports[name](...arguments_)));
} else {
  actual = Number(instance.exports['probe-count'](...config.inputs));
}
console.log(JSON.stringify(actual));
