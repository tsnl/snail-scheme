;;; MBROT -- Generation of Mandelbrot set fractal
;;; using Scheme's complex numbers.


(define (count z0 step z)

  (let* ((max-count 64)
         (radius    4.0)
         (radius^2  (* radius radius)))

    (let ((z0 (complex64-add z0 (complex64-scale z step))))

      (let loop ((z z0)
                 (c 0))
        (if (= c max-count)
            c
            (let* ((zr (complex64-real z))
                   (zi (complex64-imag z))
                   (zr^2 (* zr zr))
                   (zi^2 (* zi zi)))
              (if (> (+ zr^2 zi^2) radius^2)
                  c
                  (loop (complex64-add (complex64-multiply z z) z0) (+ c 1)))))))))

(define (mbrot matrix z0 step n)
  (let loop1 ((y (- n 1)))
    (when (>= y 0)
        (let loop2 ((x (- n 1)))
          (if (>= x 0)
            (begin
              (vector-set! (vector-ref matrix x)
                            y
                            (count z0
                                   step
                                   (complex64 (i64->f64 x)
                                                     (i64->f64 y))))
              (loop2 (- x 1)))
            (loop1 (- y 1)))))))

(define (test n)
  (let ((matrix (make-vector n mbrot-empty-row)))
    (let loop ((i (- n 1)))
      (when (>= i 0)
        (vector-set! matrix i (make-vector n 0))
        (loop (- i 1))))
    (mbrot matrix mbrot-z-origin 0.005 n)
    (vector-ref (vector-ref matrix 0) 0)))

