import fs from 'node:fs';
import assert from 'node:assert/strict';
const [artifact, countText] = process.argv.slice(2);
const count = BigInt(countText);
let hides = 0;
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), {benchmark: {
  input_i64: index => { assert.equal(index, 0); return 44n; },
  hide_i64: value => { hides++; return value; },
}});
const entries = Object.entries(instance.exports).filter(([key]) => key.startsWith('observed:'));
instance.exports.main();
const before = Object.fromEntries(entries.map(([name, counter]) => [name, counter.value]));
assert.equal(hides, 0);
assert.equal(instance.exports.bench(count), 120549n);
assert.equal(hides, Number(count));
const observed = Object.fromEntries(entries.map(([name, counter]) =>
  [name.slice('observed:'.length), (counter.value - before[name]).toString()]));
assert.equal(observed.$function46, count.toString());
assert.equal(observed.$export0, '1');
console.log(JSON.stringify({count: countText, hides, result: '120549', observed}, null, 2));
