"""Count entries in exact optimized lattice functions without reoptimizing."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

prepared, destination = map(Path, sys.argv[1:])
destination.mkdir(parents=True, exist_ok=True)
metadata = json.loads((prepared / 'prepared.json').read_text())
source = (prepared / 'lattice/strict.optimized.wat').read_text()
headers = re.compile(r'(?m)^ \(func (\$[^\s()]+)[^\n]*\n(?:  \(local [^\n]*\)\n)*')
functions = [match[1] for match in headers.finditer(source)]
assert functions and len(set(functions)) == len(functions)
counts = {name: '$observed' + str(index) for index, name in enumerate(functions)}
increments = {name: f'  (global.set {cell} (i64.add (global.get {cell}) (i64.const 1)))\n'
              for name, cell in counts.items()}
observed = headers.sub(lambda match: match[0] + increments[match[1]], source)
addition = ''.join(f' (global {cell} (mut i64) (i64.const 0))\n'
                   f' (export "observed:{name}" (global {cell}))\n' for name, cell in counts.items())
closing = observed.rfind(')')
observed = observed[:closing] + addition + observed[closing:]
restored = observed.replace(addition, '')
for statement in increments.values():
    assert restored.count(statement) == 1
    restored = restored.replace(statement, '')
assert restored == source
(destination / 'observed.wat').write_text(observed)
command = [metadata['tools']['WASM_AS']['path'], str(destination / 'observed.wat'),
           '--mvp-features', '--enable-gc', '--enable-reference-types', '--enable-tail-call',
           '--enable-mutable-globals', '--enable-sign-ext', '--enable-bulk-memory',
           '--enable-nontrapping-float-to-int', '-o', str(destination / 'observed.wasm')]
run = subprocess.run(command, text=True, capture_output=True)
(destination / 'build.json').write_text(json.dumps(dict(command=command, returncode=run.returncode,
    stdout=run.stdout, stderr=run.stderr), indent=2) + '\n')
run.check_returncode()
report = dict(original_wat_sha256=hashlib.sha256(source.encode()).hexdigest(),
    original_wasm_sha256=hashlib.sha256((prepared / 'lattice/strict.wasm').read_bytes()).hexdigest(),
    erased_text_exact_match=True, observed_functions=functions,
    original_function_count=len(functions), reoptimized=False)
(destination / 'source-proof.json').write_text(json.dumps(report, indent=2) + '\n')
