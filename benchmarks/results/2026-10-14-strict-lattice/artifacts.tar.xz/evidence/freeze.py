"""Archive the committed lattice preparation, checks and isolated diagnostics."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path('/tmp/snail-strict-lattice-20261014')
prepared = Path('/tmp/snail-strict-lattice-preparation-20261014-r3')
evidence = Path('/tmp/snail-strict-lattice-evidence-20261014')
report = root / 'benchmarks/results/2026-10-14-strict-lattice'
load = lambda path: json.loads(path.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
save = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n')
metadata = load(prepared / 'prepared.json')
case = metadata['cases'][0]
assert case['name'] == 'lattice' and case['status'] == 'ready'
for name, expected in case['hashes'].items():
    assert digest(prepared / 'lattice' / name) == expected, name
canonical = load(prepared / 'lattice/validation.json') + load(prepared / 'lattice/chez-validation.json')
assert len(canonical) == 12 and all(row['returncode'] == 0 and not row['stderr'] for row in canonical)
oracles = [load(prepared / f'lattice/probe-oracle-{i}.json') for i in range(4)]
assert all(all(values == oracle['expected'] for values in oracle['observations']) for oracle in oracles)
for label, accepted in [('other-branch', True), ('wrong-result', False)]:
    checks = load(prepared / f'lattice/validation-{label}.json')
    assert len(checks) == 2
    assert all((row['returncode'] == 0) == accepted for row in checks)
    for control in ('', 'same-source-chez'):
        row = load(prepared / 'lattice' / control / f'chez-validation-{label}.json')
        assert row['returncode'] == 0 and not row['stderr']
summary = dict(source_commit='b47381a7074ad1073acc7e8a65bbc67c80a43b0d',
    preparation_commit=metadata['driver_commit'], compiler_commit=metadata['compiler_commit'],
    compiler_files=len(metadata['compiler_files']), canonical_executions=12,
    supplemental_executions=16, scalar_harness_executions=8, total_behavior_executions=36,
    probe_observations_per_form=[len(oracle['expected']) for oracle in oracles],
    independent_exhaustive_poset_oracles=[0, 1], original_chez_comparison_trace_oracle=2,
    list_order_and_identity_oracle=3, original_input=case['spec'],
    make_test='passed', make_check='passed', prior_unchanged_ports=28, clean_measurements=0)
save(report / 'correctness-summary.json', summary)
proof = load(evidence / 'diagnostics/source-proof.json')
assert proof['original_wasm_sha256'] == digest(prepared / 'lattice/strict.wasm')
assert proof['original_wat_sha256'] == digest(prepared / 'lattice/strict.optimized.wat')
observations = [json.loads(load(evidence / f'observed-{count}.json')['stdout']) for count in (1, 2, 10)]
for record in observations[1:]:
    for name, count in record['observed'].items():
        if name != '$export0':
            assert int(count) == int(record['count']) * int(observations[0]['observed'][name]), name
roles = {'$function41': 'Finite tag-list membership', '$function45': 'Recursive I64 branch-list sum',
    '$function46': 'Complete run including lattice construction and preliminary counts',
    '$function69': 'Destructive rotation of I64 lists', '$function103': 'Destructive rotation of point-sequence lists',
    '$function121': 'Preliminary l2 to l2 enumerator', '$function126': 'Preliminary l3 to l3 enumerator',
    '$function131': 'Preliminary l2 to l3 enumerator', '$function146': 'Preliminary l3 to l2 enumerator',
    '$function161': 'Canonical l4 to l4 enumerator', '$function162': 'Prepend one shared partial binding and recurse',
    '$function164': 'Lower/upper constraint scans followed by target candidate selection',
    '$function170': 'Destructive rotation of nested point-sequence lists',
    '$function181': 'Materialized I64 results of recursively mapped candidates',
    '$function209': 'Deeper rotation used only by larger unexecuted branches',
    '$function253': 'Outer runtime repetition loop'}
save(report / 'retention-audit.json', dict(**proof,
    optimized_bytes=(prepared / 'lattice/strict.wasm').stat().st_size,
    canonical_exports=['bench', 'main'], function_roles=roles, observations=observations,
    source_roundtrip='All 119 original optimized function forms recovered exactly',
    initialization_excluded=True, r2_r3_canonical_artifacts_byte_identical=True,
    limitations='Instrumented Wasm function entries; not physical allocations, machine-code counts or performance samples.'))
items = {str(path.relative_to(prepared)): path for path in prepared.rglob('*') if path.is_file()}
items.update({'evidence/' + str(path.relative_to(evidence)): path for path in evidence.rglob('*') if path.is_file()})
manifest = {name: digest(path) for name, path in sorted(items.items())}
archive = report / 'artifacts.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as output:
    for name, path in sorted(items.items()):
        info = output.gettarinfo(str(path), arcname=name)
        info.mtime, info.uid, info.gid, info.uname, info.gname = 0, 0, 0, '', ''
        with path.open('rb') as stream:
            output.addfile(info, stream)
save(report / 'manifest.json', dict(archive_sha256=digest(archive), files=manifest,
    source_commit=metadata['driver_commit'], compiler_commit=metadata['compiler_commit'],
    upstream_commit=metadata['upstream_commit'], preparation_directory=str(prepared), clean_measurements=0))
print('Archived', len(items), 'files;', archive.stat().st_size, 'bytes')
