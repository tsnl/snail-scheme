0000000000059970 <f.35>:
   59970:	55                   	push   %rbp
   59971:	41 57                	push   %r15
   59973:	41 56                	push   %r14
   59975:	41 55                	push   %r13
   59977:	41 54                	push   %r12
   59979:	53                   	push   %rbx
   5997a:	48 83 ec 38          	sub    $0x38,%rsp
   5997e:	48 89 d1             	mov    %rdx,%rcx
   59981:	48 c7 44 24 08 04 00 	movq   $0x4,0x8(%rsp)
   59988:	00 00 
   5998a:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   59991:	00 00 
   59993:	48 8b 05 a6 60 01 00 	mov    0x160a6(%rip),%rax        # 6fa40 <native_roots>
   5999a:	48 89 04 24          	mov    %rax,(%rsp)
   5999e:	48 89 e0             	mov    %rsp,%rax
   599a1:	48 89 05 98 60 01 00 	mov    %rax,0x16098(%rip)        # 6fa40 <native_roots>
   599a8:	48 8b 05 c1 5f 01 00 	mov    0x15fc1(%rip),%rax        # 6f970 <root_depth>
   599af:	48 ff c0             	inc    %rax
   599b2:	48 89 05 b7 5f 01 00 	mov    %rax,0x15fb7(%rip)        # 6f970 <root_depth>
   599b9:	48 3b 05 b8 5f 01 00 	cmp    0x15fb8(%rip),%rax        # 6f978 <peak_root_depth>
   599c0:	76 07                	jbe    599c9 <f.35+0x59>
   599c2:	48 89 05 af 5f 01 00 	mov    %rax,0x15faf(%rip)        # 6f978 <peak_root_depth>
   599c9:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   599ce:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
   599d3:	48 83 3d dd 5d 01 00 	cmpq   $0x0,0x15ddd(%rip)        # 6f7b8 <g.34>
   599da:	00 
   599db:	0f 84 6d 03 00 00    	je     59d4e <f.35+0x3de>
   599e1:	48 83 3d ff 5c 01 00 	cmpq   $0x0,0x15cff(%rip)        # 6f6e8 <g.8>
   599e8:	00 
   599e9:	0f 84 5f 03 00 00    	je     59d4e <f.35+0x3de>
   599ef:	48 85 f6             	test   %rsi,%rsi
   599f2:	0f 84 56 03 00 00    	je     59d4e <f.35+0x3de>
   599f8:	89 f0                	mov    %esi,%eax
   599fa:	83 e0 01             	and    $0x1,%eax
   599fd:	0f 85 4b 03 00 00    	jne    59d4e <f.35+0x3de>
   59a03:	48 8b 46 08          	mov    0x8(%rsi),%rax
   59a07:	41 89 c1             	mov    %eax,%r9d
   59a0a:	49 8d 51 ff          	lea    -0x1(%r9),%rdx
   59a0e:	49 89 d0             	mov    %rdx,%r8
   59a11:	49 c1 e8 20          	shr    $0x20,%r8
   59a15:	0f 85 33 03 00 00    	jne    59d4e <f.35+0x3de>
   59a1b:	48 39 d0             	cmp    %rdx,%rax
   59a1e:	0f 86 2a 03 00 00    	jbe    59d4e <f.35+0x3de>
   59a24:	4a 8d 04 09          	lea    (%rcx,%r9,1),%rax
   59a28:	48 89 c2             	mov    %rax,%rdx
   59a2b:	48 c1 ea 20          	shr    $0x20,%rdx
   59a2f:	0f 85 19 03 00 00    	jne    59d4e <f.35+0x3de>
   59a35:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
   59a39:	49 89 d0             	mov    %rdx,%r8
   59a3c:	49 c1 e8 20          	shr    $0x20,%r8
   59a40:	0f 85 08 03 00 00    	jne    59d4e <f.35+0x3de>
   59a46:	48 85 ff             	test   %rdi,%rdi
   59a49:	0f 84 ff 02 00 00    	je     59d4e <f.35+0x3de>
   59a4f:	41 89 f8             	mov    %edi,%r8d
   59a52:	41 83 e0 01          	and    $0x1,%r8d
   59a56:	0f 85 f2 02 00 00    	jne    59d4e <f.35+0x3de>
   59a5c:	4c 8b 47 08          	mov    0x8(%rdi),%r8
   59a60:	49 39 d0             	cmp    %rdx,%r8
   59a63:	0f 86 e5 02 00 00    	jbe    59d4e <f.35+0x3de>
   59a69:	49 39 c0             	cmp    %rax,%r8
   59a6c:	0f 86 dc 02 00 00    	jbe    59d4e <f.35+0x3de>
   59a72:	4e 63 54 8e 0c       	movslq 0xc(%rsi,%r9,4),%r10
   59a77:	45 85 d2             	test   %r10d,%r10d
   59a7a:	0f 84 ce 02 00 00    	je     59d4e <f.35+0x3de>
   59a80:	48 63 54 87 0c       	movslq 0xc(%rdi,%rax,4),%rdx
   59a85:	4c 63 44 87 10       	movslq 0x10(%rdi,%rax,4),%r8
   59a8a:	49 c1 e0 1e          	shl    $0x1e,%r8
   59a8e:	49 01 d0             	add    %rdx,%r8
   59a91:	4c 89 c0             	mov    %r8,%rax
   59a94:	4c 09 d0             	or     %r10,%rax
   59a97:	48 c1 e8 20          	shr    $0x20,%rax
   59a9b:	74 0d                	je     59aaa <f.35+0x13a>
   59a9d:	4c 89 c0             	mov    %r8,%rax
   59aa0:	48 99                	cqto
   59aa2:	49 f7 fa             	idiv   %r10
   59aa5:	48 89 c2             	mov    %rax,%rdx
   59aa8:	eb 0a                	jmp    59ab4 <f.35+0x144>
   59aaa:	44 89 c0             	mov    %r8d,%eax
   59aad:	31 d2                	xor    %edx,%edx
   59aaf:	41 f7 f2             	div    %r10d
   59ab2:	89 c2                	mov    %eax,%edx
   59ab4:	48 81 fa ff ff ff 3f 	cmp    $0x3fffffff,%rdx
   59abb:	b8 ff ff ff 3f       	mov    $0x3fffffff,%eax
   59ac0:	48 0f 4c c2          	cmovl  %rdx,%rax
   59ac4:	48 89 c2             	mov    %rax,%rdx
   59ac7:	49 0f af d2          	imul   %r10,%rdx
   59acb:	49 29 d0             	sub    %rdx,%r8
   59ace:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   59ad3:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   59ad8:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   59adf:	00 00 
   59ae1:	49 8d 14 09          	lea    (%r9,%rcx,1),%rdx
   59ae5:	48 83 c2 fe          	add    $0xfffffffffffffffe,%rdx
   59ae9:	49 89 d3             	mov    %rdx,%r11
   59aec:	49 c1 eb 20          	shr    $0x20,%r11
   59af0:	75 11                	jne    59b03 <f.35+0x193>
   59af2:	4d 8d 59 fe          	lea    -0x2(%r9),%r11
   59af6:	4c 89 db             	mov    %r11,%rbx
   59af9:	48 c1 eb 20          	shr    $0x20,%rbx
   59afd:	0f 84 50 02 00 00    	je     59d53 <f.35+0x3e3>
   59b03:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
   59b0a:	0f 8c 3e 02 00 00    	jl     59d4e <f.35+0x3de>
   59b10:	48 83 3d a8 5c 01 00 	cmpq   $0x0,0x15ca8(%rip)        # 6f7c0 <g.35>
   59b17:	00 
   59b18:	0f 84 30 02 00 00    	je     59d4e <f.35+0x3de>
   59b1e:	8b 56 08             	mov    0x8(%rsi),%edx
   59b21:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   59b26:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   59b2b:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   59b32:	00 00 
   59b34:	4c 8d 04 8f          	lea    (%rdi,%rcx,4),%r8
   59b38:	49 83 c0 10          	add    $0x10,%r8
   59b3c:	bb 01 00 00 00       	mov    $0x1,%ebx
   59b41:	45 31 d2             	xor    %r10d,%r10d
   59b44:	45 31 c9             	xor    %r9d,%r9d
   59b47:	4c 39 ca             	cmp    %r9,%rdx
   59b4a:	0f 84 8d 00 00 00    	je     59bdd <f.35+0x26d>
   59b50:	48 85 db             	test   %rbx,%rbx
   59b53:	0f 84 f5 01 00 00    	je     59d4e <f.35+0x3de>
   59b59:	4c 39 4e 08          	cmp    %r9,0x8(%rsi)
   59b5d:	0f 86 eb 01 00 00    	jbe    59d4e <f.35+0x3de>
   59b63:	48 83 3d 85 5b 01 00 	cmpq   $0x0,0x15b85(%rip)        # 6f6f0 <g.9>
   59b6a:	00 
   59b6b:	0f 84 dd 01 00 00    	je     59d4e <f.35+0x3de>
   59b71:	4e 8d 1c 09          	lea    (%rcx,%r9,1),%r11
   59b75:	4c 89 db             	mov    %r11,%rbx
   59b78:	48 c1 eb 20          	shr    $0x20,%rbx
   59b7c:	0f 85 cc 01 00 00    	jne    59d4e <f.35+0x3de>
   59b82:	4c 39 5f 08          	cmp    %r11,0x8(%rdi)
   59b86:	0f 86 c2 01 00 00    	jbe    59d4e <f.35+0x3de>
   59b8c:	4e 63 5c 8e 10       	movslq 0x10(%rsi,%r9,4),%r11
   59b91:	4c 0f af d8          	imul   %rax,%r11
   59b95:	4d 01 d3             	add    %r10,%r11
   59b98:	4f 63 14 88          	movslq (%r8,%r9,4),%r10
   59b9c:	44 89 db             	mov    %r11d,%ebx
   59b9f:	81 e3 ff ff ff 3f    	and    $0x3fffffff,%ebx
   59ba5:	49 29 da             	sub    %rbx,%r10
   59ba8:	4c 89 d3             	mov    %r10,%rbx
   59bab:	48 c1 eb 21          	shr    $0x21,%rbx
   59baf:	81 e3 00 00 00 40    	and    $0x40000000,%ebx
   59bb5:	44 01 d3             	add    %r10d,%ebx
   59bb8:	43 89 1c 88          	mov    %ebx,(%r8,%r9,4)
   59bbc:	49 c1 ea 3f          	shr    $0x3f,%r10
   59bc0:	49 ff c1             	inc    %r9
   59bc3:	49 c1 eb 1e          	shr    $0x1e,%r11
   59bc7:	4d 01 d3             	add    %r10,%r11
   59bca:	48 8b 1d 17 5b 01 00 	mov    0x15b17(%rip),%rbx        # 6f6e8 <g.8>
   59bd1:	4d 89 da             	mov    %r11,%r10
   59bd4:	4c 39 ca             	cmp    %r9,%rdx
   59bd7:	0f 85 73 ff ff ff    	jne    59b50 <f.35+0x1e0>
   59bdd:	48 85 db             	test   %rbx,%rbx
   59be0:	0f 84 68 01 00 00    	je     59d4e <f.35+0x3de>
   59be6:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
   59bea:	49 89 f0             	mov    %rsi,%r8
   59bed:	49 c1 e8 20          	shr    $0x20,%r8
   59bf1:	0f 85 57 01 00 00    	jne    59d4e <f.35+0x3de>
   59bf7:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   59bfb:	0f 86 4d 01 00 00    	jbe    59d4e <f.35+0x3de>
   59c01:	4c 63 44 b7 10       	movslq 0x10(%rdi,%rsi,4),%r8
   59c06:	4d 29 d0             	sub    %r10,%r8
   59c09:	4d 8d 48 01          	lea    0x1(%r8),%r9
   59c0d:	49 83 f9 02          	cmp    $0x2,%r9
   59c11:	0f 83 37 01 00 00    	jae    59d4e <f.35+0x3de>
   59c17:	48 83 3d d1 5a 01 00 	cmpq   $0x0,0x15ad1(%rip)        # 6f6f0 <g.9>
   59c1e:	00 
   59c1f:	0f 84 29 01 00 00    	je     59d4e <f.35+0x3de>
   59c25:	4d 89 c1             	mov    %r8,%r9
   59c28:	49 c1 e9 21          	shr    $0x21,%r9
   59c2c:	41 81 e1 00 00 00 40 	and    $0x40000000,%r9d
   59c33:	45 01 c1             	add    %r8d,%r9d
   59c36:	44 89 4c b7 10       	mov    %r9d,0x10(%rdi,%rsi,4)
   59c3b:	4d 85 c0             	test   %r8,%r8
   59c3e:	0f 89 c1 01 00 00    	jns    59e05 <f.35+0x495>
   59c44:	48 83 3d 7c 5b 01 00 	cmpq   $0x0,0x15b7c(%rip)        # 6f7c8 <g.36>
   59c4b:	00 
   59c4c:	0f 84 fc 00 00 00    	je     59d4e <f.35+0x3de>
   59c52:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   59c57:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
   59c5c:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   59c61:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   59c66:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   59c6d:	00 00 
   59c6f:	48 85 d2             	test   %rdx,%rdx
   59c72:	0f 84 35 01 00 00    	je     59dad <f.35+0x43d>
   59c78:	48 83 3d 68 5a 01 00 	cmpq   $0x0,0x15a68(%rip)        # 6f6e8 <g.8>
   59c7f:	00 
   59c80:	0f 84 c8 00 00 00    	je     59d4e <f.35+0x3de>
   59c86:	48 83 3d 62 5a 01 00 	cmpq   $0x0,0x15a62(%rip)        # 6f6f0 <g.9>
   59c8d:	00 
   59c8e:	0f 84 ba 00 00 00    	je     59d4e <f.35+0x3de>
   59c94:	49 89 c8             	mov    %rcx,%r8
   59c97:	49 c1 e8 20          	shr    $0x20,%r8
   59c9b:	0f 85 ad 00 00 00    	jne    59d4e <f.35+0x3de>
   59ca1:	49 ba 00 00 00 00 01 	movabs $0x100000000,%r10
   59ca8:	00 00 00 
   59cab:	49 29 ca             	sub    %rcx,%r10
   59cae:	4d 85 c9             	test   %r9,%r9
   59cb1:	41 0f 95 c0          	setne  %r8b
   59cb5:	41 f6 c1 01          	test   $0x1,%r9b
   59cb9:	41 0f 94 c3          	sete   %r11b
   59cbd:	45 20 c3             	and    %r8b,%r11b
   59cc0:	48 85 ff             	test   %rdi,%rdi
   59cc3:	41 0f 95 c0          	setne  %r8b
   59cc7:	40 f6 c7 01          	test   $0x1,%dil
   59ccb:	0f 94 c3             	sete   %bl
   59cce:	44 20 c3             	and    %r8b,%bl
   59cd1:	48 ff ca             	dec    %rdx
   59cd4:	45 31 c0             	xor    %r8d,%r8d
   59cd7:	45 31 f6             	xor    %r14d,%r14d
   59cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   59ce0:	84 db                	test   %bl,%bl
   59ce2:	74 6a                	je     59d4e <f.35+0x3de>
   59ce4:	46 8d 3c 31          	lea    (%rcx,%r14,1),%r15d
   59ce8:	4c 39 7f 08          	cmp    %r15,0x8(%rdi)
   59cec:	76 60                	jbe    59d4e <f.35+0x3de>
   59cee:	45 84 db             	test   %r11b,%r11b
   59cf1:	74 5b                	je     59d4e <f.35+0x3de>
   59cf3:	4d 39 71 08          	cmp    %r14,0x8(%r9)
   59cf7:	76 55                	jbe    59d4e <f.35+0x3de>
   59cf9:	4e 63 64 bf 10       	movslq 0x10(%rdi,%r15,4),%r12
   59cfe:	4f 63 6c b1 10       	movslq 0x10(%r9,%r14,4),%r13
   59d03:	4d 01 e0             	add    %r12,%r8
   59d06:	4d 89 c4             	mov    %r8,%r12
   59d09:	4d 01 ec             	add    %r13,%r12
   59d0c:	4f 8d 84 05 ff ff ff 	lea    0x3fffffff(%r13,%r8,1),%r8
   59d13:	3f 
   59d14:	4d 0f 49 c4          	cmovns %r12,%r8
   59d18:	44 89 c5             	mov    %r8d,%ebp
   59d1b:	81 e5 00 00 00 c0    	and    $0xc0000000,%ebp
   59d21:	41 29 ec             	sub    %ebp,%r12d
   59d24:	46 89 64 bf 10       	mov    %r12d,0x10(%rdi,%r15,4)
   59d29:	49 c1 f8 1e          	sar    $0x1e,%r8
   59d2d:	4c 39 f2             	cmp    %r14,%rdx
   59d30:	74 7e                	je     59db0 <f.35+0x440>
   59d32:	48 83 3d ae 59 01 00 	cmpq   $0x0,0x159ae(%rip)        # 6f6e8 <g.8>
   59d39:	00 
   59d3a:	74 12                	je     59d4e <f.35+0x3de>
   59d3c:	48 83 3d ac 59 01 00 	cmpq   $0x0,0x159ac(%rip)        # 6f6f0 <g.9>
   59d43:	00 
   59d44:	74 08                	je     59d4e <f.35+0x3de>
   59d46:	49 ff c6             	inc    %r14
   59d49:	4d 39 f2             	cmp    %r14,%r10
   59d4c:	75 92                	jne    59ce0 <f.35+0x370>
   59d4e:	e8 1d d2 00 00       	call   66f70 <native_trap>
   59d53:	4c 89 c3             	mov    %r8,%rbx
   59d56:	48 c1 e3 1e          	shl    $0x1e,%rbx
   59d5a:	4d 89 d6             	mov    %r10,%r14
   59d5d:	49 c1 e6 1e          	shl    $0x1e,%r14
   59d61:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   59d68:	0f 8f a2 fd ff ff    	jg     59b10 <f.35+0x1a0>
   59d6e:	66 90                	xchg   %ax,%ax
   59d70:	48 39 57 08          	cmp    %rdx,0x8(%rdi)
   59d74:	76 d8                	jbe    59d4e <f.35+0x3de>
   59d76:	4c 39 5e 08          	cmp    %r11,0x8(%rsi)
   59d7a:	76 d2                	jbe    59d4e <f.35+0x3de>
   59d7c:	4c 63 7c 97 10       	movslq 0x10(%rdi,%rdx,4),%r15
   59d81:	49 01 df             	add    %rbx,%r15
   59d84:	4e 63 64 8e 08       	movslq 0x8(%rsi,%r9,4),%r12
   59d89:	4c 0f af e0          	imul   %rax,%r12
   59d8d:	4d 39 e7             	cmp    %r12,%r15
   59d90:	0f 8d 7a fd ff ff    	jge    59b10 <f.35+0x1a0>
   59d96:	48 ff c8             	dec    %rax
   59d99:	4d 01 d0             	add    %r10,%r8
   59d9c:	4c 01 f3             	add    %r14,%rbx
   59d9f:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   59da6:	7e c8                	jle    59d70 <f.35+0x400>
   59da8:	e9 63 fd ff ff       	jmp    59b10 <f.35+0x1a0>
   59dad:	45 31 c0             	xor    %r8d,%r8d
   59db0:	48 83 3d 30 59 01 00 	cmpq   $0x0,0x15930(%rip)        # 6f6e8 <g.8>
   59db7:	00 
   59db8:	74 94                	je     59d4e <f.35+0x3de>
   59dba:	48 83 3d 2e 59 01 00 	cmpq   $0x0,0x1592e(%rip)        # 6f6f0 <g.9>
   59dc1:	00 
   59dc2:	74 8a                	je     59d4e <f.35+0x3de>
   59dc4:	48 85 ff             	test   %rdi,%rdi
   59dc7:	74 85                	je     59d4e <f.35+0x3de>
   59dc9:	89 f9                	mov    %edi,%ecx
   59dcb:	83 e1 01             	and    $0x1,%ecx
   59dce:	0f 85 7a ff ff ff    	jne    59d4e <f.35+0x3de>
   59dd4:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   59dd8:	0f 86 70 ff ff ff    	jbe    59d4e <f.35+0x3de>
   59dde:	48 63 4c b7 10       	movslq 0x10(%rdi,%rsi,4),%rcx
   59de3:	49 01 c8             	add    %rcx,%r8
   59de6:	41 8d 88 ff ff ff 3f 	lea    0x3fffffff(%r8),%ecx
   59ded:	4d 85 c0             	test   %r8,%r8
   59df0:	41 0f 49 c8          	cmovns %r8d,%ecx
   59df4:	81 e1 00 00 00 c0    	and    $0xc0000000,%ecx
   59dfa:	41 29 c8             	sub    %ecx,%r8d
   59dfd:	44 89 44 b7 10       	mov    %r8d,0x10(%rdi,%rsi,4)
   59e02:	48 ff c8             	dec    %rax
   59e05:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   59e0b:	74 12                	je     59e1f <f.35+0x4af>
   59e0d:	48 8b 0c 24          	mov    (%rsp),%rcx
   59e11:	48 89 0d 28 5c 01 00 	mov    %rcx,0x15c28(%rip)        # 6fa40 <native_roots>
   59e18:	48 ff 0d 51 5b 01 00 	decq   0x15b51(%rip)        # 6f970 <root_depth>
   59e1f:	48 83 c4 38          	add    $0x38,%rsp
   59e23:	5b                   	pop    %rbx
   59e24:	41 5c                	pop    %r12
   59e26:	41 5d                	pop    %r13
   59e28:	41 5e                	pop    %r14
   59e2a:	41 5f                	pop    %r15
   59e2c:	5d                   	pop    %rbp
   59e2d:	c2 08 00             	ret    $0x8

