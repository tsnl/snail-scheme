0000000000055660 <f.36>:
   55660:	55                   	push   %rbp
   55661:	41 57                	push   %r15
   55663:	41 56                	push   %r14
   55665:	41 55                	push   %r13
   55667:	41 54                	push   %r12
   55669:	53                   	push   %rbx
   5566a:	48 83 ec 38          	sub    $0x38,%rsp
   5566e:	48 89 d1             	mov    %rdx,%rcx
   55671:	48 c7 44 24 08 04 00 	movq   $0x4,0x8(%rsp)
   55678:	00 00 
   5567a:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   55681:	00 00 
   55683:	48 8b 05 86 53 01 00 	mov    0x15386(%rip),%rax        # 6aa10 <native_roots>
   5568a:	48 89 04 24          	mov    %rax,(%rsp)
   5568e:	48 89 e0             	mov    %rsp,%rax
   55691:	48 89 05 78 53 01 00 	mov    %rax,0x15378(%rip)        # 6aa10 <native_roots>
   55698:	48 8b 05 a1 52 01 00 	mov    0x152a1(%rip),%rax        # 6a940 <root_depth>
   5569f:	48 ff c0             	inc    %rax
   556a2:	48 89 05 97 52 01 00 	mov    %rax,0x15297(%rip)        # 6a940 <root_depth>
   556a9:	48 3b 05 98 52 01 00 	cmp    0x15298(%rip),%rax        # 6a948 <peak_root_depth>
   556b0:	76 07                	jbe    556b9 <f.36+0x59>
   556b2:	48 89 05 8f 52 01 00 	mov    %rax,0x1528f(%rip)        # 6a948 <peak_root_depth>
   556b9:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   556be:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
   556c3:	48 83 3d ad 50 01 00 	cmpq   $0x0,0x150ad(%rip)        # 6a778 <g.35>
   556ca:	00 
   556cb:	0f 84 6d 03 00 00    	je     55a3e <f.36+0x3de>
   556d1:	48 83 3d cf 4f 01 00 	cmpq   $0x0,0x14fcf(%rip)        # 6a6a8 <g.8>
   556d8:	00 
   556d9:	0f 84 5f 03 00 00    	je     55a3e <f.36+0x3de>
   556df:	48 85 f6             	test   %rsi,%rsi
   556e2:	0f 84 56 03 00 00    	je     55a3e <f.36+0x3de>
   556e8:	89 f0                	mov    %esi,%eax
   556ea:	83 e0 01             	and    $0x1,%eax
   556ed:	0f 85 4b 03 00 00    	jne    55a3e <f.36+0x3de>
   556f3:	48 8b 46 08          	mov    0x8(%rsi),%rax
   556f7:	41 89 c1             	mov    %eax,%r9d
   556fa:	49 8d 51 ff          	lea    -0x1(%r9),%rdx
   556fe:	49 89 d0             	mov    %rdx,%r8
   55701:	49 c1 e8 20          	shr    $0x20,%r8
   55705:	0f 85 33 03 00 00    	jne    55a3e <f.36+0x3de>
   5570b:	48 39 d0             	cmp    %rdx,%rax
   5570e:	0f 86 2a 03 00 00    	jbe    55a3e <f.36+0x3de>
   55714:	4a 8d 04 09          	lea    (%rcx,%r9,1),%rax
   55718:	48 89 c2             	mov    %rax,%rdx
   5571b:	48 c1 ea 20          	shr    $0x20,%rdx
   5571f:	0f 85 19 03 00 00    	jne    55a3e <f.36+0x3de>
   55725:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
   55729:	49 89 d0             	mov    %rdx,%r8
   5572c:	49 c1 e8 20          	shr    $0x20,%r8
   55730:	0f 85 08 03 00 00    	jne    55a3e <f.36+0x3de>
   55736:	48 85 ff             	test   %rdi,%rdi
   55739:	0f 84 ff 02 00 00    	je     55a3e <f.36+0x3de>
   5573f:	41 89 f8             	mov    %edi,%r8d
   55742:	41 83 e0 01          	and    $0x1,%r8d
   55746:	0f 85 f2 02 00 00    	jne    55a3e <f.36+0x3de>
   5574c:	4c 8b 47 08          	mov    0x8(%rdi),%r8
   55750:	49 39 d0             	cmp    %rdx,%r8
   55753:	0f 86 e5 02 00 00    	jbe    55a3e <f.36+0x3de>
   55759:	49 39 c0             	cmp    %rax,%r8
   5575c:	0f 86 dc 02 00 00    	jbe    55a3e <f.36+0x3de>
   55762:	4e 63 54 8e 0c       	movslq 0xc(%rsi,%r9,4),%r10
   55767:	45 85 d2             	test   %r10d,%r10d
   5576a:	0f 84 ce 02 00 00    	je     55a3e <f.36+0x3de>
   55770:	48 63 54 87 0c       	movslq 0xc(%rdi,%rax,4),%rdx
   55775:	4c 63 44 87 10       	movslq 0x10(%rdi,%rax,4),%r8
   5577a:	49 c1 e0 1e          	shl    $0x1e,%r8
   5577e:	49 01 d0             	add    %rdx,%r8
   55781:	4c 89 c0             	mov    %r8,%rax
   55784:	4c 09 d0             	or     %r10,%rax
   55787:	48 c1 e8 20          	shr    $0x20,%rax
   5578b:	74 0d                	je     5579a <f.36+0x13a>
   5578d:	4c 89 c0             	mov    %r8,%rax
   55790:	48 99                	cqto
   55792:	49 f7 fa             	idiv   %r10
   55795:	48 89 c2             	mov    %rax,%rdx
   55798:	eb 0a                	jmp    557a4 <f.36+0x144>
   5579a:	44 89 c0             	mov    %r8d,%eax
   5579d:	31 d2                	xor    %edx,%edx
   5579f:	41 f7 f2             	div    %r10d
   557a2:	89 c2                	mov    %eax,%edx
   557a4:	48 81 fa ff ff ff 3f 	cmp    $0x3fffffff,%rdx
   557ab:	b8 ff ff ff 3f       	mov    $0x3fffffff,%eax
   557b0:	48 0f 4c c2          	cmovl  %rdx,%rax
   557b4:	48 89 c2             	mov    %rax,%rdx
   557b7:	49 0f af d2          	imul   %r10,%rdx
   557bb:	49 29 d0             	sub    %rdx,%r8
   557be:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   557c3:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   557c8:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   557cf:	00 00 
   557d1:	49 8d 14 09          	lea    (%r9,%rcx,1),%rdx
   557d5:	48 83 c2 fe          	add    $0xfffffffffffffffe,%rdx
   557d9:	49 89 d3             	mov    %rdx,%r11
   557dc:	49 c1 eb 20          	shr    $0x20,%r11
   557e0:	75 11                	jne    557f3 <f.36+0x193>
   557e2:	4d 8d 59 fe          	lea    -0x2(%r9),%r11
   557e6:	4c 89 db             	mov    %r11,%rbx
   557e9:	48 c1 eb 20          	shr    $0x20,%rbx
   557ed:	0f 84 50 02 00 00    	je     55a43 <f.36+0x3e3>
   557f3:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
   557fa:	0f 8c 3e 02 00 00    	jl     55a3e <f.36+0x3de>
   55800:	48 83 3d 78 4f 01 00 	cmpq   $0x0,0x14f78(%rip)        # 6a780 <g.36>
   55807:	00 
   55808:	0f 84 30 02 00 00    	je     55a3e <f.36+0x3de>
   5580e:	8b 56 08             	mov    0x8(%rsi),%edx
   55811:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   55816:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   5581b:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   55822:	00 00 
   55824:	4c 8d 04 8f          	lea    (%rdi,%rcx,4),%r8
   55828:	49 83 c0 10          	add    $0x10,%r8
   5582c:	bb 01 00 00 00       	mov    $0x1,%ebx
   55831:	45 31 d2             	xor    %r10d,%r10d
   55834:	45 31 c9             	xor    %r9d,%r9d
   55837:	4c 39 ca             	cmp    %r9,%rdx
   5583a:	0f 84 8d 00 00 00    	je     558cd <f.36+0x26d>
   55840:	48 85 db             	test   %rbx,%rbx
   55843:	0f 84 f5 01 00 00    	je     55a3e <f.36+0x3de>
   55849:	4c 39 4e 08          	cmp    %r9,0x8(%rsi)
   5584d:	0f 86 eb 01 00 00    	jbe    55a3e <f.36+0x3de>
   55853:	48 83 3d 55 4e 01 00 	cmpq   $0x0,0x14e55(%rip)        # 6a6b0 <g.9>
   5585a:	00 
   5585b:	0f 84 dd 01 00 00    	je     55a3e <f.36+0x3de>
   55861:	4e 8d 1c 09          	lea    (%rcx,%r9,1),%r11
   55865:	4c 89 db             	mov    %r11,%rbx
   55868:	48 c1 eb 20          	shr    $0x20,%rbx
   5586c:	0f 85 cc 01 00 00    	jne    55a3e <f.36+0x3de>
   55872:	4c 39 5f 08          	cmp    %r11,0x8(%rdi)
   55876:	0f 86 c2 01 00 00    	jbe    55a3e <f.36+0x3de>
   5587c:	4e 63 5c 8e 10       	movslq 0x10(%rsi,%r9,4),%r11
   55881:	4c 0f af d8          	imul   %rax,%r11
   55885:	4d 01 d3             	add    %r10,%r11
   55888:	4f 63 14 88          	movslq (%r8,%r9,4),%r10
   5588c:	44 89 db             	mov    %r11d,%ebx
   5588f:	81 e3 ff ff ff 3f    	and    $0x3fffffff,%ebx
   55895:	49 29 da             	sub    %rbx,%r10
   55898:	4c 89 d3             	mov    %r10,%rbx
   5589b:	48 c1 eb 21          	shr    $0x21,%rbx
   5589f:	81 e3 00 00 00 40    	and    $0x40000000,%ebx
   558a5:	44 01 d3             	add    %r10d,%ebx
   558a8:	43 89 1c 88          	mov    %ebx,(%r8,%r9,4)
   558ac:	49 c1 ea 3f          	shr    $0x3f,%r10
   558b0:	49 ff c1             	inc    %r9
   558b3:	49 c1 eb 1e          	shr    $0x1e,%r11
   558b7:	4d 01 d3             	add    %r10,%r11
   558ba:	48 8b 1d e7 4d 01 00 	mov    0x14de7(%rip),%rbx        # 6a6a8 <g.8>
   558c1:	4d 89 da             	mov    %r11,%r10
   558c4:	4c 39 ca             	cmp    %r9,%rdx
   558c7:	0f 85 73 ff ff ff    	jne    55840 <f.36+0x1e0>
   558cd:	48 85 db             	test   %rbx,%rbx
   558d0:	0f 84 68 01 00 00    	je     55a3e <f.36+0x3de>
   558d6:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
   558da:	49 89 f0             	mov    %rsi,%r8
   558dd:	49 c1 e8 20          	shr    $0x20,%r8
   558e1:	0f 85 57 01 00 00    	jne    55a3e <f.36+0x3de>
   558e7:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   558eb:	0f 86 4d 01 00 00    	jbe    55a3e <f.36+0x3de>
   558f1:	4c 63 44 b7 10       	movslq 0x10(%rdi,%rsi,4),%r8
   558f6:	4d 29 d0             	sub    %r10,%r8
   558f9:	4d 8d 48 01          	lea    0x1(%r8),%r9
   558fd:	49 83 f9 02          	cmp    $0x2,%r9
   55901:	0f 83 37 01 00 00    	jae    55a3e <f.36+0x3de>
   55907:	48 83 3d a1 4d 01 00 	cmpq   $0x0,0x14da1(%rip)        # 6a6b0 <g.9>
   5590e:	00 
   5590f:	0f 84 29 01 00 00    	je     55a3e <f.36+0x3de>
   55915:	4d 89 c1             	mov    %r8,%r9
   55918:	49 c1 e9 21          	shr    $0x21,%r9
   5591c:	41 81 e1 00 00 00 40 	and    $0x40000000,%r9d
   55923:	45 01 c1             	add    %r8d,%r9d
   55926:	44 89 4c b7 10       	mov    %r9d,0x10(%rdi,%rsi,4)
   5592b:	4d 85 c0             	test   %r8,%r8
   5592e:	0f 89 c1 01 00 00    	jns    55af5 <f.36+0x495>
   55934:	48 83 3d 4c 4e 01 00 	cmpq   $0x0,0x14e4c(%rip)        # 6a788 <g.37>
   5593b:	00 
   5593c:	0f 84 fc 00 00 00    	je     55a3e <f.36+0x3de>
   55942:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   55947:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
   5594c:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   55951:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   55956:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   5595d:	00 00 
   5595f:	48 85 d2             	test   %rdx,%rdx
   55962:	0f 84 35 01 00 00    	je     55a9d <f.36+0x43d>
   55968:	48 83 3d 38 4d 01 00 	cmpq   $0x0,0x14d38(%rip)        # 6a6a8 <g.8>
   5596f:	00 
   55970:	0f 84 c8 00 00 00    	je     55a3e <f.36+0x3de>
   55976:	48 83 3d 32 4d 01 00 	cmpq   $0x0,0x14d32(%rip)        # 6a6b0 <g.9>
   5597d:	00 
   5597e:	0f 84 ba 00 00 00    	je     55a3e <f.36+0x3de>
   55984:	49 89 c8             	mov    %rcx,%r8
   55987:	49 c1 e8 20          	shr    $0x20,%r8
   5598b:	0f 85 ad 00 00 00    	jne    55a3e <f.36+0x3de>
   55991:	49 ba 00 00 00 00 01 	movabs $0x100000000,%r10
   55998:	00 00 00 
   5599b:	49 29 ca             	sub    %rcx,%r10
   5599e:	4d 85 c9             	test   %r9,%r9
   559a1:	41 0f 95 c0          	setne  %r8b
   559a5:	41 f6 c1 01          	test   $0x1,%r9b
   559a9:	41 0f 94 c3          	sete   %r11b
   559ad:	45 20 c3             	and    %r8b,%r11b
   559b0:	48 85 ff             	test   %rdi,%rdi
   559b3:	41 0f 95 c0          	setne  %r8b
   559b7:	40 f6 c7 01          	test   $0x1,%dil
   559bb:	0f 94 c3             	sete   %bl
   559be:	44 20 c3             	and    %r8b,%bl
   559c1:	48 ff ca             	dec    %rdx
   559c4:	45 31 c0             	xor    %r8d,%r8d
   559c7:	45 31 f6             	xor    %r14d,%r14d
   559ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   559d0:	84 db                	test   %bl,%bl
   559d2:	74 6a                	je     55a3e <f.36+0x3de>
   559d4:	46 8d 3c 31          	lea    (%rcx,%r14,1),%r15d
   559d8:	4c 39 7f 08          	cmp    %r15,0x8(%rdi)
   559dc:	76 60                	jbe    55a3e <f.36+0x3de>
   559de:	45 84 db             	test   %r11b,%r11b
   559e1:	74 5b                	je     55a3e <f.36+0x3de>
   559e3:	4d 39 71 08          	cmp    %r14,0x8(%r9)
   559e7:	76 55                	jbe    55a3e <f.36+0x3de>
   559e9:	4e 63 64 bf 10       	movslq 0x10(%rdi,%r15,4),%r12
   559ee:	4f 63 6c b1 10       	movslq 0x10(%r9,%r14,4),%r13
   559f3:	4d 01 e0             	add    %r12,%r8
   559f6:	4d 89 c4             	mov    %r8,%r12
   559f9:	4d 01 ec             	add    %r13,%r12
   559fc:	4f 8d 84 05 ff ff ff 	lea    0x3fffffff(%r13,%r8,1),%r8
   55a03:	3f 
   55a04:	4d 0f 49 c4          	cmovns %r12,%r8
   55a08:	44 89 c5             	mov    %r8d,%ebp
   55a0b:	81 e5 00 00 00 c0    	and    $0xc0000000,%ebp
   55a11:	41 29 ec             	sub    %ebp,%r12d
   55a14:	46 89 64 bf 10       	mov    %r12d,0x10(%rdi,%r15,4)
   55a19:	49 c1 f8 1e          	sar    $0x1e,%r8
   55a1d:	4c 39 f2             	cmp    %r14,%rdx
   55a20:	74 7e                	je     55aa0 <f.36+0x440>
   55a22:	48 83 3d 7e 4c 01 00 	cmpq   $0x0,0x14c7e(%rip)        # 6a6a8 <g.8>
   55a29:	00 
   55a2a:	74 12                	je     55a3e <f.36+0x3de>
   55a2c:	48 83 3d 7c 4c 01 00 	cmpq   $0x0,0x14c7c(%rip)        # 6a6b0 <g.9>
   55a33:	00 
   55a34:	74 08                	je     55a3e <f.36+0x3de>
   55a36:	49 ff c6             	inc    %r14
   55a39:	4d 39 f2             	cmp    %r14,%r10
   55a3c:	75 92                	jne    559d0 <f.36+0x370>
   55a3e:	e8 5d c4 00 00       	call   61ea0 <native_trap>
   55a43:	4c 89 c3             	mov    %r8,%rbx
   55a46:	48 c1 e3 1e          	shl    $0x1e,%rbx
   55a4a:	4d 89 d6             	mov    %r10,%r14
   55a4d:	49 c1 e6 1e          	shl    $0x1e,%r14
   55a51:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   55a58:	0f 8f a2 fd ff ff    	jg     55800 <f.36+0x1a0>
   55a5e:	66 90                	xchg   %ax,%ax
   55a60:	48 39 57 08          	cmp    %rdx,0x8(%rdi)
   55a64:	76 d8                	jbe    55a3e <f.36+0x3de>
   55a66:	4c 39 5e 08          	cmp    %r11,0x8(%rsi)
   55a6a:	76 d2                	jbe    55a3e <f.36+0x3de>
   55a6c:	4c 63 7c 97 10       	movslq 0x10(%rdi,%rdx,4),%r15
   55a71:	49 01 df             	add    %rbx,%r15
   55a74:	4e 63 64 8e 08       	movslq 0x8(%rsi,%r9,4),%r12
   55a79:	4c 0f af e0          	imul   %rax,%r12
   55a7d:	4d 39 e7             	cmp    %r12,%r15
   55a80:	0f 8d 7a fd ff ff    	jge    55800 <f.36+0x1a0>
   55a86:	48 ff c8             	dec    %rax
   55a89:	4d 01 d0             	add    %r10,%r8
   55a8c:	4c 01 f3             	add    %r14,%rbx
   55a8f:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   55a96:	7e c8                	jle    55a60 <f.36+0x400>
   55a98:	e9 63 fd ff ff       	jmp    55800 <f.36+0x1a0>
   55a9d:	45 31 c0             	xor    %r8d,%r8d
   55aa0:	48 83 3d 00 4c 01 00 	cmpq   $0x0,0x14c00(%rip)        # 6a6a8 <g.8>
   55aa7:	00 
   55aa8:	74 94                	je     55a3e <f.36+0x3de>
   55aaa:	48 83 3d fe 4b 01 00 	cmpq   $0x0,0x14bfe(%rip)        # 6a6b0 <g.9>
   55ab1:	00 
   55ab2:	74 8a                	je     55a3e <f.36+0x3de>
   55ab4:	48 85 ff             	test   %rdi,%rdi
   55ab7:	74 85                	je     55a3e <f.36+0x3de>
   55ab9:	89 f9                	mov    %edi,%ecx
   55abb:	83 e1 01             	and    $0x1,%ecx
   55abe:	0f 85 7a ff ff ff    	jne    55a3e <f.36+0x3de>
   55ac4:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   55ac8:	0f 86 70 ff ff ff    	jbe    55a3e <f.36+0x3de>
   55ace:	48 63 4c b7 10       	movslq 0x10(%rdi,%rsi,4),%rcx
   55ad3:	49 01 c8             	add    %rcx,%r8
   55ad6:	41 8d 88 ff ff ff 3f 	lea    0x3fffffff(%r8),%ecx
   55add:	4d 85 c0             	test   %r8,%r8
   55ae0:	41 0f 49 c8          	cmovns %r8d,%ecx
   55ae4:	81 e1 00 00 00 c0    	and    $0xc0000000,%ecx
   55aea:	41 29 c8             	sub    %ecx,%r8d
   55aed:	44 89 44 b7 10       	mov    %r8d,0x10(%rdi,%rsi,4)
   55af2:	48 ff c8             	dec    %rax
   55af5:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   55afb:	74 12                	je     55b0f <f.36+0x4af>
   55afd:	48 8b 0c 24          	mov    (%rsp),%rcx
   55b01:	48 89 0d 08 4f 01 00 	mov    %rcx,0x14f08(%rip)        # 6aa10 <native_roots>
   55b08:	48 ff 0d 31 4e 01 00 	decq   0x14e31(%rip)        # 6a940 <root_depth>
   55b0f:	48 83 c4 38          	add    $0x38,%rsp
   55b13:	5b                   	pop    %rbx
   55b14:	41 5c                	pop    %r12
   55b16:	41 5d                	pop    %r13
   55b18:	41 5e                	pop    %r14
   55b1a:	41 5f                	pop    %r15
   55b1c:	5d                   	pop    %rbp
   55b1d:	c2 08 00             	ret    $0x8

