#!/usr/bin/env python3
"""Recheck retained bytes without importing the measurement runner or executing guests."""

from collections import Counter, defaultdict
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT.with_name('snail-limb-bits-production-clean-20261014')
PLAN_SHA = '1ebb5ae98083223fa69b8b865b019ecd85aabe9638b990b24966a38c2d7e2dad'
CAPTURED = {}
COUNTS = {'pi': 100, 'chudnovsky': 1000}
MODES = ('production-v8', 'native-final-v8', 'native64')


# ---- Read once: the evidence hashed below is the evidence interpreted ----

def capture(path):
    path = Path(path)
    if path not in CAPTURED:
        CAPTURED[path] = path.read_bytes()
    return CAPTURED[path]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(capture(path))


def verify_identities(plan):
    assert len(plan['artifact_sha256']) == 361
    for path, expected in plan['artifact_sha256'].items():
        assert digest(capture(path)) == expected, path
    assert digest(capture(ROOT / 'timing-plan.json')) == PLAN_SHA


# ---- Physical command order supplies the balance, not reported positions ----

def verify_schedule(plan):
    rows = plan['schedule']
    assert plan['counts'] == COUNTS and plan['rounds'] == 12
    assert len(rows) == 156 and [r['index'] for r in rows] == list(range(156))
    assert all(r['phase'] == 'untimed-warmup' for r in rows[:12])
    assert all(r['phase'] == 'measurement' for r in rows[12:])
    systems = {revision + '-' + mode for revision in ('baseline', 'candidate') for mode in MODES}
    assert set(plan['systems']) == systems
    for round_number in range(12):
        group = rows[12 + round_number * 12:24 + round_number * 12]
        assert [r['workload'] for r in group] == (['pi'] * 6 + ['chudnovsky'] * 6)[::1 if round_number % 2 == 0 else -1]
        assert all(r['round'] == round_number for r in group)
    return {workload: verify_workload_order(rows, workload, systems) for workload in COUNTS}


def verify_workload_order(rows, workload, systems):
    warmups = [r for r in rows[:12] if r['workload'] == workload]
    assert Counter(r['system'] for r in warmups) == Counter({s: 1 for s in systems})
    positions, adjacency, earlier = defaultdict(Counter), Counter(), Counter()
    for round_number in range(12):
        order = [r['system'] for r in rows[12:] if r['workload'] == workload and r['round'] == round_number]
        assert len(order) == 6 and set(order) == systems
        for position, system in enumerate(order):
            positions[system][position] += 1
        adjacency.update(zip(order, order[1:]))
        for mode in MODES:
            earlier[mode] += order.index('candidate-' + mode) < order.index('baseline-' + mode)
    assert all(p == Counter({i: 2 for i in range(6)}) for p in positions.values())
    assert len(adjacency) == 30 and set(adjacency.values()) == {2}
    assert all(count == 6 for count in earlier.values())
    return {'rounds': 12, 'each_position_per_system': 2, 'each_directed_adjacent_pair': 2, 'candidate_precedes_baseline': dict(earlier)}


# ---- Full numeric results, exactly one clock, and completed process ownership ----

def expected_output(workload):
    before = read_json(ROOT / 'baseline' / workload / 'full.spec.json')
    after = read_json(ROOT / 'candidate' / workload / 'full.spec.json')
    assert before == after and before['count'] == COUNTS[workload]
    return before['output']


def verify_process(row, sample):
    assert all(sample[k] == value for k, value in row.items())
    assert row['count'] == COUNTS[row['workload']]
    assert row['command'][:3] == ['/run/current-system/sw/bin/taskset', '-c', '5']
    assert row['command'][-1] == ('--validate' if row['phase'] == 'untimed-warmup' else '--time')
    assert 'environment' not in row and sample['environment'] == {'BINARYEN_CORES': '1'}
    assert sample['status'] == 'valid' and sample['returncode'] == 0
    assert sample['diagnostic_only'] is False and sample['timeout'] is False
    assert sample['stderr'] == '' and sample['executing_descendants'] == []
    assert sample['cleanup'] == dict(process_group=sample['pid'], live_members=[], leader_reaped=True, capture_handles_closed=True, zombies_count_as_stopped=True)
    assert sample['process_group'] == sample['pid']
    assert math.isfinite(sample['process_seconds']) and sample['process_seconds'] > 0


def verified_clock(row, sample):
    output = expected_output(row['workload'])
    assert digest(output.encode()) == row['expected_output_sha256']
    if row['phase'] == 'untimed-warmup':
        assert sample['stdout'] == output and sample['workload_seconds'] is None
        return None
    assert sample['stdout'].startswith(output)
    frame = sample['stdout'][len(output):]
    label = 'native' if row['system'].endswith('-native64') else row['workload']
    assert frame.startswith(f'+!CSVLINE!+snail-integer,{label}:{row["count"]},')
    fields = frame.split(',')
    assert len(fields) == 3 and re.fullmatch(r'[0-9.eE+\-]+\n', fields[2])
    seconds = float(fields[2])
    assert math.isfinite(seconds) and 0 < seconds <= sample['process_seconds']
    assert seconds == sample['workload_seconds']
    return seconds


def verify_samples(plan, campaign):
    assert len(campaign['samples']) == 156
    assert sorted(p.name for p in RESULTS.glob('sample-*.json')) == [f'sample-{i:03}.json' for i in range(156)]
    verified = []
    for row, embedded in zip(plan['schedule'], campaign['samples'], strict=True):
        sample = read_json(RESULTS / f'sample-{row["index"]:03}.json')
        assert sample == embedded
        verify_process(row, sample)
        seconds = verified_clock(row, sample)
        verified.append(dict(workload=row['workload'], system=row['system'], phase=row['phase'], round=row.get('round'), seconds=seconds))
    return verified


# ---- Independent statistics and before/after host observations ----

def summarize(samples):
    result = {}
    for workload in COUNTS:
        groups, by_round = {}, {}
        for mode in MODES:
            for revision in ('baseline', 'candidate'):
                system = revision + '-' + mode
                rows = [r for r in samples if r['workload'] == workload and r['system'] == system and r['phase'] == 'measurement']
                assert [r['round'] for r in rows] == list(range(12))
                times = [r['seconds'] for r in rows]
                groups[system] = dict(samples=len(times), median=statistics.median(times), range=[min(times), max(times)])
                by_round[system] = times
        result[workload] = dict(systems=groups, comparisons=compare_revisions(groups, by_round))
    return result


def compare_revisions(groups, by_round):
    result = {}
    for mode in MODES:
        before, after = 'baseline-' + mode, 'candidate-' + mode
        paired = [by_round[after][r] / by_round[before][r] for r in range(12)]
        ratio = groups[after]['median'] / groups[before]['median']
        result[mode] = dict(candidate_over_baseline=ratio, percent_less_time=100 * (1 - ratio), paired_round_ratios=paired, paired_median=statistics.median(paired))
    return result


def verify_host(plan, campaign):
    before, after = [read_json(RESULTS / f'host-{when}.json') for when in ('before', 'after')]
    for key in ('cpu', 'affinity', 'platform', 'inherited_environment'):
        assert before[key] == after[key]
    assert before['cpu'] == 5 and 5 in before['affinity']
    assert before['inherited_environment'] == plan['inherited_environment']
    policies = [{k: v for k, v in h['policy'].items() if not k.endswith('/scaling_cur_freq')} for h in (before, after)]
    assert policies[0] == policies[1]
    starts = [datetime.fromisoformat(s['started']) for s in campaign['samples']]
    assert starts == sorted(starts) and len(set(starts)) == 156
    assert datetime.fromisoformat(before['date']) <= starts[0] < starts[-1] <= datetime.fromisoformat(after['date'])
    return {'stable_recorded_policy': policies[0], 'elapsed_seconds': (datetime.fromisoformat(after['date']) - datetime.fromisoformat(before['date'])).total_seconds(), 'scope': 'Endpoint observations and recorded process ownership; no claim of absence of unrelated host activity.'}


def main():
    plan, campaign = read_json(ROOT / 'timing-plan.json'), read_json(RESULTS / 'campaign.json')
    verify_identities(plan)
    assert campaign['plan_sha256'] == PLAN_SHA and campaign['complete'] is True and campaign['diagnostic_only'] is False
    assert set(campaign) == {'plan_sha256', 'complete', 'diagnostic_only', 'samples', 'summary'}
    balance = verify_schedule(plan)
    summary = summarize(verify_samples(plan, campaign))
    assert summary == campaign['summary']
    host = verify_host(plan, campaign)
    capture(Path(__file__).resolve())
    for name in ('coordination-before.json', 'coordination-after.json', 'matched-ready.json', 'parent-preflight.json'):
        capture(ROOT / name)
    output = dict(passed=True, plan_sha256=PLAN_SHA, warmups=12, retained=144, artifacts=361, balance=balance, host=host, summary=summary,
                  capture_sha256={str(p): digest(data) for p, data in sorted(CAPTURED.items())})
    (ROOT / 'independent-review.json').write_text(json.dumps(output, indent=2) + '\n')
    print('PASS: 156 complete captures, 144 clocks, 361 identities, balanced order, cleanup and independently recomputed summaries')


if __name__ == '__main__':
    main()
