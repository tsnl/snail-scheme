#!/usr/bin/env python3
"""Freeze and validate one committed source revision without starting a clock."""

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys


def git(root, *arguments):
    return subprocess.run(['git', '-C', str(root), *arguments],
                          text=True, capture_output=True, check=True).stdout.strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_identities(root):
    names = git(root, 'ls-files', 'src', 'scripts', 'Cargo.toml', 'Cargo.lock',
                'tests/build-strict-program.scm', 'benchmarks/strict-suite').splitlines()
    subprocess.run(['git', '-C', str(root), 'diff', '--quiet', 'HEAD', '--', *names], check=True)
    return {name: digest(root/name) for name in names}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('commit')
    options = parser.parse_args()
    root, output = options.root.resolve(), options.output.resolve()
    assert git(root, 'rev-parse', 'HEAD') == options.commit
    output.mkdir(parents=True)
    sys.path.insert(0, str(root/'benchmarks/strict-suite'))
    import integer_controls as controls
    import integer_ports as ports
    environment = {**os.environ, 'BINARYEN_CORES': '1'}
    environment.pop('SNAIL_INTEGER_TIME', None)
    for variable, default in [('NODE', 'node'), ('CHEZ', 'scheme'), ('WASM_DIS', 'wasm-dis')]:
        environment[variable] = shutil.which(environment.get(variable, default))
    identities = source_identities(root)
    assert git(ports.CORPUS, 'rev-parse', 'HEAD') == ports.REVISION
    assert not git(ports.CORPUS, 'status', '--porcelain', '--untracked-files=no')
    shutil.copy2(__file__, output/'prepare-production.py')
    controls.freeze_preparation(output, environment)
    controls.record_tools(output, environment)
    ports.save(output/'source.json', dict(commit=options.commit, root=str(root), sha256=identities,
                                        corpus_revision=ports.REVISION, diagnostic_only=True))
    for name in ['pi', 'chudnovsky']:
        directory = output/name
        directory.mkdir()
        original, adapted, data, specification = controls.freeze_sources(name, directory)
        controls.prepare_scheme(directory, specification, environment)
        ports.save(directory/'validated.json', dict(passed=True, diagnostic_only=True,
            no_clock_started=True, count=specification['count'],
            input_sha256=hashlib.sha256(data.encode()).hexdigest(),
            output_sha256=hashlib.sha256(specification['output'].encode()).hexdigest()))
        print(f'PASS {name}: raw, production, native-final Wasm and native64; all controls', flush=True)
    assert source_identities(root) == identities
    ports.save(output/'validated.json', dict(passed=True, diagnostic_only=True,
               no_clock_started=True, commit=options.commit, source_sha256=identities))


if __name__ == '__main__':
    main()
