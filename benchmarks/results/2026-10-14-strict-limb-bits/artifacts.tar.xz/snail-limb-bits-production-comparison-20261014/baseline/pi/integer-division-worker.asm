0000000000059990 <f.35>:
   59990:	55                   	push   %rbp
   59991:	41 57                	push   %r15
   59993:	41 56                	push   %r14
   59995:	41 55                	push   %r13
   59997:	41 54                	push   %r12
   59999:	53                   	push   %rbx
   5999a:	48 83 ec 38          	sub    $0x38,%rsp
   5999e:	48 89 d1             	mov    %rdx,%rcx
   599a1:	48 c7 44 24 08 04 00 	movq   $0x4,0x8(%rsp)
   599a8:	00 00 
   599aa:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   599b1:	00 00 
   599b3:	48 8b 05 c6 60 01 00 	mov    0x160c6(%rip),%rax        # 6fa80 <native_roots>
   599ba:	48 89 04 24          	mov    %rax,(%rsp)
   599be:	48 89 e0             	mov    %rsp,%rax
   599c1:	48 89 05 b8 60 01 00 	mov    %rax,0x160b8(%rip)        # 6fa80 <native_roots>
   599c8:	48 8b 05 e1 5f 01 00 	mov    0x15fe1(%rip),%rax        # 6f9b0 <root_depth>
   599cf:	48 ff c0             	inc    %rax
   599d2:	48 89 05 d7 5f 01 00 	mov    %rax,0x15fd7(%rip)        # 6f9b0 <root_depth>
   599d9:	48 3b 05 d8 5f 01 00 	cmp    0x15fd8(%rip),%rax        # 6f9b8 <peak_root_depth>
   599e0:	76 07                	jbe    599e9 <f.35+0x59>
   599e2:	48 89 05 cf 5f 01 00 	mov    %rax,0x15fcf(%rip)        # 6f9b8 <peak_root_depth>
   599e9:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   599ee:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
   599f3:	48 83 3d fd 5d 01 00 	cmpq   $0x0,0x15dfd(%rip)        # 6f7f8 <g.34>
   599fa:	00 
   599fb:	0f 84 8d 03 00 00    	je     59d8e <f.35+0x3fe>
   59a01:	48 83 3d 1f 5d 01 00 	cmpq   $0x0,0x15d1f(%rip)        # 6f728 <g.8>
   59a08:	00 
   59a09:	0f 84 7f 03 00 00    	je     59d8e <f.35+0x3fe>
   59a0f:	48 85 f6             	test   %rsi,%rsi
   59a12:	0f 84 76 03 00 00    	je     59d8e <f.35+0x3fe>
   59a18:	89 f0                	mov    %esi,%eax
   59a1a:	83 e0 01             	and    $0x1,%eax
   59a1d:	0f 85 6b 03 00 00    	jne    59d8e <f.35+0x3fe>
   59a23:	48 8b 46 08          	mov    0x8(%rsi),%rax
   59a27:	41 89 c1             	mov    %eax,%r9d
   59a2a:	49 8d 51 ff          	lea    -0x1(%r9),%rdx
   59a2e:	49 89 d0             	mov    %rdx,%r8
   59a31:	49 c1 e8 20          	shr    $0x20,%r8
   59a35:	0f 85 53 03 00 00    	jne    59d8e <f.35+0x3fe>
   59a3b:	48 39 d0             	cmp    %rdx,%rax
   59a3e:	0f 86 4a 03 00 00    	jbe    59d8e <f.35+0x3fe>
   59a44:	4a 8d 04 09          	lea    (%rcx,%r9,1),%rax
   59a48:	48 89 c2             	mov    %rax,%rdx
   59a4b:	48 c1 ea 20          	shr    $0x20,%rdx
   59a4f:	0f 85 39 03 00 00    	jne    59d8e <f.35+0x3fe>
   59a55:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
   59a59:	49 89 d0             	mov    %rdx,%r8
   59a5c:	49 c1 e8 20          	shr    $0x20,%r8
   59a60:	0f 85 28 03 00 00    	jne    59d8e <f.35+0x3fe>
   59a66:	48 85 ff             	test   %rdi,%rdi
   59a69:	0f 84 1f 03 00 00    	je     59d8e <f.35+0x3fe>
   59a6f:	41 89 f8             	mov    %edi,%r8d
   59a72:	41 83 e0 01          	and    $0x1,%r8d
   59a76:	0f 85 12 03 00 00    	jne    59d8e <f.35+0x3fe>
   59a7c:	4c 8b 47 08          	mov    0x8(%rdi),%r8
   59a80:	49 39 d0             	cmp    %rdx,%r8
   59a83:	0f 86 05 03 00 00    	jbe    59d8e <f.35+0x3fe>
   59a89:	49 39 c0             	cmp    %rax,%r8
   59a8c:	0f 86 fc 02 00 00    	jbe    59d8e <f.35+0x3fe>
   59a92:	4e 63 54 8e 0c       	movslq 0xc(%rsi,%r9,4),%r10
   59a97:	45 85 d2             	test   %r10d,%r10d
   59a9a:	0f 84 ee 02 00 00    	je     59d8e <f.35+0x3fe>
   59aa0:	48 63 54 87 0c       	movslq 0xc(%rdi,%rax,4),%rdx
   59aa5:	4c 63 44 87 10       	movslq 0x10(%rdi,%rax,4),%r8
   59aaa:	49 c1 e0 1e          	shl    $0x1e,%r8
   59aae:	49 01 d0             	add    %rdx,%r8
   59ab1:	4c 89 c0             	mov    %r8,%rax
   59ab4:	4c 09 d0             	or     %r10,%rax
   59ab7:	48 c1 e8 20          	shr    $0x20,%rax
   59abb:	74 0d                	je     59aca <f.35+0x13a>
   59abd:	4c 89 c0             	mov    %r8,%rax
   59ac0:	48 99                	cqto
   59ac2:	49 f7 fa             	idiv   %r10
   59ac5:	48 89 c2             	mov    %rax,%rdx
   59ac8:	eb 0a                	jmp    59ad4 <f.35+0x144>
   59aca:	44 89 c0             	mov    %r8d,%eax
   59acd:	31 d2                	xor    %edx,%edx
   59acf:	41 f7 f2             	div    %r10d
   59ad2:	89 c2                	mov    %eax,%edx
   59ad4:	48 81 fa ff ff ff 3f 	cmp    $0x3fffffff,%rdx
   59adb:	b8 ff ff ff 3f       	mov    $0x3fffffff,%eax
   59ae0:	48 0f 4c c2          	cmovl  %rdx,%rax
   59ae4:	48 89 c2             	mov    %rax,%rdx
   59ae7:	49 0f af d2          	imul   %r10,%rdx
   59aeb:	49 29 d0             	sub    %rdx,%r8
   59aee:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   59af3:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   59af8:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   59aff:	00 00 
   59b01:	49 8d 14 09          	lea    (%r9,%rcx,1),%rdx
   59b05:	48 83 c2 fe          	add    $0xfffffffffffffffe,%rdx
   59b09:	49 89 d3             	mov    %rdx,%r11
   59b0c:	49 c1 eb 20          	shr    $0x20,%r11
   59b10:	75 11                	jne    59b23 <f.35+0x193>
   59b12:	4d 8d 59 fe          	lea    -0x2(%r9),%r11
   59b16:	4c 89 db             	mov    %r11,%rbx
   59b19:	48 c1 eb 20          	shr    $0x20,%rbx
   59b1d:	0f 84 70 02 00 00    	je     59d93 <f.35+0x403>
   59b23:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
   59b2a:	0f 8c 5e 02 00 00    	jl     59d8e <f.35+0x3fe>
   59b30:	48 83 3d c8 5c 01 00 	cmpq   $0x0,0x15cc8(%rip)        # 6f800 <g.35>
   59b37:	00 
   59b38:	0f 84 50 02 00 00    	je     59d8e <f.35+0x3fe>
   59b3e:	8b 56 08             	mov    0x8(%rsi),%edx
   59b41:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   59b46:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   59b4b:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   59b52:	00 00 
   59b54:	4c 8d 0c 8f          	lea    (%rdi,%rcx,4),%r9
   59b58:	49 83 c1 10          	add    $0x10,%r9
   59b5c:	41 bb 01 00 00 00    	mov    $0x1,%r11d
   59b62:	45 31 c0             	xor    %r8d,%r8d
   59b65:	45 31 d2             	xor    %r10d,%r10d
   59b68:	4c 39 d2             	cmp    %r10,%rdx
   59b6b:	0f 84 ac 00 00 00    	je     59c1d <f.35+0x28d>
   59b71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   59b78:	0f 1f 84 00 00 00 00 
   59b7f:	00 
   59b80:	4d 85 db             	test   %r11,%r11
   59b83:	0f 84 05 02 00 00    	je     59d8e <f.35+0x3fe>
   59b89:	4c 39 56 08          	cmp    %r10,0x8(%rsi)
   59b8d:	0f 86 fb 01 00 00    	jbe    59d8e <f.35+0x3fe>
   59b93:	48 83 3d 95 5b 01 00 	cmpq   $0x0,0x15b95(%rip)        # 6f730 <g.9>
   59b9a:	00 
   59b9b:	0f 84 ed 01 00 00    	je     59d8e <f.35+0x3fe>
   59ba1:	4e 8d 1c 11          	lea    (%rcx,%r10,1),%r11
   59ba5:	4c 89 db             	mov    %r11,%rbx
   59ba8:	48 c1 eb 20          	shr    $0x20,%rbx
   59bac:	0f 85 dc 01 00 00    	jne    59d8e <f.35+0x3fe>
   59bb2:	4c 39 5f 08          	cmp    %r11,0x8(%rdi)
   59bb6:	0f 86 d2 01 00 00    	jbe    59d8e <f.35+0x3fe>
   59bbc:	4e 63 5c 96 10       	movslq 0x10(%rsi,%r10,4),%r11
   59bc1:	4c 0f af d8          	imul   %rax,%r11
   59bc5:	4d 01 c3             	add    %r8,%r11
   59bc8:	4b 63 1c 91          	movslq (%r9,%r10,4),%rbx
   59bcc:	4d 8d 83 ff ff ff 3f 	lea    0x3fffffff(%r11),%r8
   59bd3:	4d 85 db             	test   %r11,%r11
   59bd6:	4d 0f 49 c3          	cmovns %r11,%r8
   59bda:	4d 89 c6             	mov    %r8,%r14
   59bdd:	49 81 e6 00 00 00 c0 	and    $0xffffffffc0000000,%r14
   59be4:	4d 29 de             	sub    %r11,%r14
   59be7:	49 01 de             	add    %rbx,%r14
   59bea:	4d 89 f3             	mov    %r14,%r11
   59bed:	49 c1 eb 21          	shr    $0x21,%r11
   59bf1:	41 81 e3 00 00 00 40 	and    $0x40000000,%r11d
   59bf8:	45 01 f3             	add    %r14d,%r11d
   59bfb:	47 89 1c 91          	mov    %r11d,(%r9,%r10,4)
   59bff:	49 c1 ee 3f          	shr    $0x3f,%r14
   59c03:	49 ff c2             	inc    %r10
   59c06:	49 c1 f8 1e          	sar    $0x1e,%r8
   59c0a:	4d 01 f0             	add    %r14,%r8
   59c0d:	4c 8b 1d 14 5b 01 00 	mov    0x15b14(%rip),%r11        # 6f728 <g.8>
   59c14:	4c 39 d2             	cmp    %r10,%rdx
   59c17:	0f 85 63 ff ff ff    	jne    59b80 <f.35+0x1f0>
   59c1d:	4d 85 db             	test   %r11,%r11
   59c20:	0f 84 68 01 00 00    	je     59d8e <f.35+0x3fe>
   59c26:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
   59c2a:	49 89 f1             	mov    %rsi,%r9
   59c2d:	49 c1 e9 20          	shr    $0x20,%r9
   59c31:	0f 85 57 01 00 00    	jne    59d8e <f.35+0x3fe>
   59c37:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   59c3b:	0f 86 4d 01 00 00    	jbe    59d8e <f.35+0x3fe>
   59c41:	4c 63 4c b7 10       	movslq 0x10(%rdi,%rsi,4),%r9
   59c46:	4d 29 c1             	sub    %r8,%r9
   59c49:	4d 8d 41 01          	lea    0x1(%r9),%r8
   59c4d:	49 83 f8 02          	cmp    $0x2,%r8
   59c51:	0f 83 37 01 00 00    	jae    59d8e <f.35+0x3fe>
   59c57:	48 83 3d d1 5a 01 00 	cmpq   $0x0,0x15ad1(%rip)        # 6f730 <g.9>
   59c5e:	00 
   59c5f:	0f 84 29 01 00 00    	je     59d8e <f.35+0x3fe>
   59c65:	4d 89 c8             	mov    %r9,%r8
   59c68:	49 c1 e8 21          	shr    $0x21,%r8
   59c6c:	41 81 e0 00 00 00 40 	and    $0x40000000,%r8d
   59c73:	45 01 c8             	add    %r9d,%r8d
   59c76:	44 89 44 b7 10       	mov    %r8d,0x10(%rdi,%rsi,4)
   59c7b:	4d 85 c9             	test   %r9,%r9
   59c7e:	0f 89 c1 01 00 00    	jns    59e45 <f.35+0x4b5>
   59c84:	48 83 3d 7c 5b 01 00 	cmpq   $0x0,0x15b7c(%rip)        # 6f808 <g.36>
   59c8b:	00 
   59c8c:	0f 84 fc 00 00 00    	je     59d8e <f.35+0x3fe>
   59c92:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   59c97:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
   59c9c:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   59ca1:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   59ca6:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   59cad:	00 00 
   59caf:	48 85 d2             	test   %rdx,%rdx
   59cb2:	0f 84 35 01 00 00    	je     59ded <f.35+0x45d>
   59cb8:	48 83 3d 68 5a 01 00 	cmpq   $0x0,0x15a68(%rip)        # 6f728 <g.8>
   59cbf:	00 
   59cc0:	0f 84 c8 00 00 00    	je     59d8e <f.35+0x3fe>
   59cc6:	48 83 3d 62 5a 01 00 	cmpq   $0x0,0x15a62(%rip)        # 6f730 <g.9>
   59ccd:	00 
   59cce:	0f 84 ba 00 00 00    	je     59d8e <f.35+0x3fe>
   59cd4:	49 89 c8             	mov    %rcx,%r8
   59cd7:	49 c1 e8 20          	shr    $0x20,%r8
   59cdb:	0f 85 ad 00 00 00    	jne    59d8e <f.35+0x3fe>
   59ce1:	49 ba 00 00 00 00 01 	movabs $0x100000000,%r10
   59ce8:	00 00 00 
   59ceb:	49 29 ca             	sub    %rcx,%r10
   59cee:	4d 85 c9             	test   %r9,%r9
   59cf1:	41 0f 95 c0          	setne  %r8b
   59cf5:	41 f6 c1 01          	test   $0x1,%r9b
   59cf9:	41 0f 94 c3          	sete   %r11b
   59cfd:	45 20 c3             	and    %r8b,%r11b
   59d00:	48 85 ff             	test   %rdi,%rdi
   59d03:	41 0f 95 c0          	setne  %r8b
   59d07:	40 f6 c7 01          	test   $0x1,%dil
   59d0b:	0f 94 c3             	sete   %bl
   59d0e:	44 20 c3             	and    %r8b,%bl
   59d11:	48 ff ca             	dec    %rdx
   59d14:	45 31 c0             	xor    %r8d,%r8d
   59d17:	45 31 f6             	xor    %r14d,%r14d
   59d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   59d20:	84 db                	test   %bl,%bl
   59d22:	74 6a                	je     59d8e <f.35+0x3fe>
   59d24:	46 8d 3c 31          	lea    (%rcx,%r14,1),%r15d
   59d28:	4c 39 7f 08          	cmp    %r15,0x8(%rdi)
   59d2c:	76 60                	jbe    59d8e <f.35+0x3fe>
   59d2e:	45 84 db             	test   %r11b,%r11b
   59d31:	74 5b                	je     59d8e <f.35+0x3fe>
   59d33:	4d 39 71 08          	cmp    %r14,0x8(%r9)
   59d37:	76 55                	jbe    59d8e <f.35+0x3fe>
   59d39:	4e 63 64 bf 10       	movslq 0x10(%rdi,%r15,4),%r12
   59d3e:	4f 63 6c b1 10       	movslq 0x10(%r9,%r14,4),%r13
   59d43:	4d 01 e0             	add    %r12,%r8
   59d46:	4d 89 c4             	mov    %r8,%r12
   59d49:	4d 01 ec             	add    %r13,%r12
   59d4c:	4f 8d 84 05 ff ff ff 	lea    0x3fffffff(%r13,%r8,1),%r8
   59d53:	3f 
   59d54:	4d 0f 49 c4          	cmovns %r12,%r8
   59d58:	44 89 c5             	mov    %r8d,%ebp
   59d5b:	81 e5 00 00 00 c0    	and    $0xc0000000,%ebp
   59d61:	41 29 ec             	sub    %ebp,%r12d
   59d64:	46 89 64 bf 10       	mov    %r12d,0x10(%rdi,%r15,4)
   59d69:	49 c1 f8 1e          	sar    $0x1e,%r8
   59d6d:	4c 39 f2             	cmp    %r14,%rdx
   59d70:	74 7e                	je     59df0 <f.35+0x460>
   59d72:	48 83 3d ae 59 01 00 	cmpq   $0x0,0x159ae(%rip)        # 6f728 <g.8>
   59d79:	00 
   59d7a:	74 12                	je     59d8e <f.35+0x3fe>
   59d7c:	48 83 3d ac 59 01 00 	cmpq   $0x0,0x159ac(%rip)        # 6f730 <g.9>
   59d83:	00 
   59d84:	74 08                	je     59d8e <f.35+0x3fe>
   59d86:	49 ff c6             	inc    %r14
   59d89:	4d 39 f2             	cmp    %r14,%r10
   59d8c:	75 92                	jne    59d20 <f.35+0x390>
   59d8e:	e8 1d d2 00 00       	call   66fb0 <native_trap>
   59d93:	4c 89 c3             	mov    %r8,%rbx
   59d96:	48 c1 e3 1e          	shl    $0x1e,%rbx
   59d9a:	4d 89 d6             	mov    %r10,%r14
   59d9d:	49 c1 e6 1e          	shl    $0x1e,%r14
   59da1:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   59da8:	0f 8f 82 fd ff ff    	jg     59b30 <f.35+0x1a0>
   59dae:	66 90                	xchg   %ax,%ax
   59db0:	48 39 57 08          	cmp    %rdx,0x8(%rdi)
   59db4:	76 d8                	jbe    59d8e <f.35+0x3fe>
   59db6:	4c 39 5e 08          	cmp    %r11,0x8(%rsi)
   59dba:	76 d2                	jbe    59d8e <f.35+0x3fe>
   59dbc:	4c 63 7c 97 10       	movslq 0x10(%rdi,%rdx,4),%r15
   59dc1:	49 01 df             	add    %rbx,%r15
   59dc4:	4e 63 64 8e 08       	movslq 0x8(%rsi,%r9,4),%r12
   59dc9:	4c 0f af e0          	imul   %rax,%r12
   59dcd:	4d 39 e7             	cmp    %r12,%r15
   59dd0:	0f 8d 5a fd ff ff    	jge    59b30 <f.35+0x1a0>
   59dd6:	48 ff c8             	dec    %rax
   59dd9:	4d 01 d0             	add    %r10,%r8
   59ddc:	4c 01 f3             	add    %r14,%rbx
   59ddf:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   59de6:	7e c8                	jle    59db0 <f.35+0x420>
   59de8:	e9 43 fd ff ff       	jmp    59b30 <f.35+0x1a0>
   59ded:	45 31 c0             	xor    %r8d,%r8d
   59df0:	48 83 3d 30 59 01 00 	cmpq   $0x0,0x15930(%rip)        # 6f728 <g.8>
   59df7:	00 
   59df8:	74 94                	je     59d8e <f.35+0x3fe>
   59dfa:	48 83 3d 2e 59 01 00 	cmpq   $0x0,0x1592e(%rip)        # 6f730 <g.9>
   59e01:	00 
   59e02:	74 8a                	je     59d8e <f.35+0x3fe>
   59e04:	48 85 ff             	test   %rdi,%rdi
   59e07:	74 85                	je     59d8e <f.35+0x3fe>
   59e09:	89 f9                	mov    %edi,%ecx
   59e0b:	83 e1 01             	and    $0x1,%ecx
   59e0e:	0f 85 7a ff ff ff    	jne    59d8e <f.35+0x3fe>
   59e14:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   59e18:	0f 86 70 ff ff ff    	jbe    59d8e <f.35+0x3fe>
   59e1e:	48 63 4c b7 10       	movslq 0x10(%rdi,%rsi,4),%rcx
   59e23:	49 01 c8             	add    %rcx,%r8
   59e26:	41 8d 88 ff ff ff 3f 	lea    0x3fffffff(%r8),%ecx
   59e2d:	4d 85 c0             	test   %r8,%r8
   59e30:	41 0f 49 c8          	cmovns %r8d,%ecx
   59e34:	81 e1 00 00 00 c0    	and    $0xc0000000,%ecx
   59e3a:	41 29 c8             	sub    %ecx,%r8d
   59e3d:	44 89 44 b7 10       	mov    %r8d,0x10(%rdi,%rsi,4)
   59e42:	48 ff c8             	dec    %rax
   59e45:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   59e4b:	74 12                	je     59e5f <f.35+0x4cf>
   59e4d:	48 8b 0c 24          	mov    (%rsp),%rcx
   59e51:	48 89 0d 28 5c 01 00 	mov    %rcx,0x15c28(%rip)        # 6fa80 <native_roots>
   59e58:	48 ff 0d 51 5b 01 00 	decq   0x15b51(%rip)        # 6f9b0 <root_depth>
   59e5f:	48 83 c4 38          	add    $0x38,%rsp
   59e63:	5b                   	pop    %rbx
   59e64:	41 5c                	pop    %r12
   59e66:	41 5d                	pop    %r13
   59e68:	41 5e                	pop    %r14
   59e6a:	41 5f                	pop    %r15
   59e6c:	5d                   	pop    %rbp
   59e6d:	c2 08 00             	ret    $0x8

