0000000000055680 <f.36>:
   55680:	55                   	push   %rbp
   55681:	41 57                	push   %r15
   55683:	41 56                	push   %r14
   55685:	41 55                	push   %r13
   55687:	41 54                	push   %r12
   55689:	53                   	push   %rbx
   5568a:	48 83 ec 38          	sub    $0x38,%rsp
   5568e:	48 89 d1             	mov    %rdx,%rcx
   55691:	48 c7 44 24 08 04 00 	movq   $0x4,0x8(%rsp)
   55698:	00 00 
   5569a:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   556a1:	00 00 
   556a3:	48 8b 05 a6 53 01 00 	mov    0x153a6(%rip),%rax        # 6aa50 <native_roots>
   556aa:	48 89 04 24          	mov    %rax,(%rsp)
   556ae:	48 89 e0             	mov    %rsp,%rax
   556b1:	48 89 05 98 53 01 00 	mov    %rax,0x15398(%rip)        # 6aa50 <native_roots>
   556b8:	48 8b 05 c1 52 01 00 	mov    0x152c1(%rip),%rax        # 6a980 <root_depth>
   556bf:	48 ff c0             	inc    %rax
   556c2:	48 89 05 b7 52 01 00 	mov    %rax,0x152b7(%rip)        # 6a980 <root_depth>
   556c9:	48 3b 05 b8 52 01 00 	cmp    0x152b8(%rip),%rax        # 6a988 <peak_root_depth>
   556d0:	76 07                	jbe    556d9 <f.36+0x59>
   556d2:	48 89 05 af 52 01 00 	mov    %rax,0x152af(%rip)        # 6a988 <peak_root_depth>
   556d9:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   556de:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
   556e3:	48 83 3d cd 50 01 00 	cmpq   $0x0,0x150cd(%rip)        # 6a7b8 <g.35>
   556ea:	00 
   556eb:	0f 84 8d 03 00 00    	je     55a7e <f.36+0x3fe>
   556f1:	48 83 3d ef 4f 01 00 	cmpq   $0x0,0x14fef(%rip)        # 6a6e8 <g.8>
   556f8:	00 
   556f9:	0f 84 7f 03 00 00    	je     55a7e <f.36+0x3fe>
   556ff:	48 85 f6             	test   %rsi,%rsi
   55702:	0f 84 76 03 00 00    	je     55a7e <f.36+0x3fe>
   55708:	89 f0                	mov    %esi,%eax
   5570a:	83 e0 01             	and    $0x1,%eax
   5570d:	0f 85 6b 03 00 00    	jne    55a7e <f.36+0x3fe>
   55713:	48 8b 46 08          	mov    0x8(%rsi),%rax
   55717:	41 89 c1             	mov    %eax,%r9d
   5571a:	49 8d 51 ff          	lea    -0x1(%r9),%rdx
   5571e:	49 89 d0             	mov    %rdx,%r8
   55721:	49 c1 e8 20          	shr    $0x20,%r8
   55725:	0f 85 53 03 00 00    	jne    55a7e <f.36+0x3fe>
   5572b:	48 39 d0             	cmp    %rdx,%rax
   5572e:	0f 86 4a 03 00 00    	jbe    55a7e <f.36+0x3fe>
   55734:	4a 8d 04 09          	lea    (%rcx,%r9,1),%rax
   55738:	48 89 c2             	mov    %rax,%rdx
   5573b:	48 c1 ea 20          	shr    $0x20,%rdx
   5573f:	0f 85 39 03 00 00    	jne    55a7e <f.36+0x3fe>
   55745:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
   55749:	49 89 d0             	mov    %rdx,%r8
   5574c:	49 c1 e8 20          	shr    $0x20,%r8
   55750:	0f 85 28 03 00 00    	jne    55a7e <f.36+0x3fe>
   55756:	48 85 ff             	test   %rdi,%rdi
   55759:	0f 84 1f 03 00 00    	je     55a7e <f.36+0x3fe>
   5575f:	41 89 f8             	mov    %edi,%r8d
   55762:	41 83 e0 01          	and    $0x1,%r8d
   55766:	0f 85 12 03 00 00    	jne    55a7e <f.36+0x3fe>
   5576c:	4c 8b 47 08          	mov    0x8(%rdi),%r8
   55770:	49 39 d0             	cmp    %rdx,%r8
   55773:	0f 86 05 03 00 00    	jbe    55a7e <f.36+0x3fe>
   55779:	49 39 c0             	cmp    %rax,%r8
   5577c:	0f 86 fc 02 00 00    	jbe    55a7e <f.36+0x3fe>
   55782:	4e 63 54 8e 0c       	movslq 0xc(%rsi,%r9,4),%r10
   55787:	45 85 d2             	test   %r10d,%r10d
   5578a:	0f 84 ee 02 00 00    	je     55a7e <f.36+0x3fe>
   55790:	48 63 54 87 0c       	movslq 0xc(%rdi,%rax,4),%rdx
   55795:	4c 63 44 87 10       	movslq 0x10(%rdi,%rax,4),%r8
   5579a:	49 c1 e0 1e          	shl    $0x1e,%r8
   5579e:	49 01 d0             	add    %rdx,%r8
   557a1:	4c 89 c0             	mov    %r8,%rax
   557a4:	4c 09 d0             	or     %r10,%rax
   557a7:	48 c1 e8 20          	shr    $0x20,%rax
   557ab:	74 0d                	je     557ba <f.36+0x13a>
   557ad:	4c 89 c0             	mov    %r8,%rax
   557b0:	48 99                	cqto
   557b2:	49 f7 fa             	idiv   %r10
   557b5:	48 89 c2             	mov    %rax,%rdx
   557b8:	eb 0a                	jmp    557c4 <f.36+0x144>
   557ba:	44 89 c0             	mov    %r8d,%eax
   557bd:	31 d2                	xor    %edx,%edx
   557bf:	41 f7 f2             	div    %r10d
   557c2:	89 c2                	mov    %eax,%edx
   557c4:	48 81 fa ff ff ff 3f 	cmp    $0x3fffffff,%rdx
   557cb:	b8 ff ff ff 3f       	mov    $0x3fffffff,%eax
   557d0:	48 0f 4c c2          	cmovl  %rdx,%rax
   557d4:	48 89 c2             	mov    %rax,%rdx
   557d7:	49 0f af d2          	imul   %r10,%rdx
   557db:	49 29 d0             	sub    %rdx,%r8
   557de:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   557e3:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   557e8:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   557ef:	00 00 
   557f1:	49 8d 14 09          	lea    (%r9,%rcx,1),%rdx
   557f5:	48 83 c2 fe          	add    $0xfffffffffffffffe,%rdx
   557f9:	49 89 d3             	mov    %rdx,%r11
   557fc:	49 c1 eb 20          	shr    $0x20,%r11
   55800:	75 11                	jne    55813 <f.36+0x193>
   55802:	4d 8d 59 fe          	lea    -0x2(%r9),%r11
   55806:	4c 89 db             	mov    %r11,%rbx
   55809:	48 c1 eb 20          	shr    $0x20,%rbx
   5580d:	0f 84 70 02 00 00    	je     55a83 <f.36+0x403>
   55813:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
   5581a:	0f 8c 5e 02 00 00    	jl     55a7e <f.36+0x3fe>
   55820:	48 83 3d 98 4f 01 00 	cmpq   $0x0,0x14f98(%rip)        # 6a7c0 <g.36>
   55827:	00 
   55828:	0f 84 50 02 00 00    	je     55a7e <f.36+0x3fe>
   5582e:	8b 56 08             	mov    0x8(%rsi),%edx
   55831:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   55836:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   5583b:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   55842:	00 00 
   55844:	4c 8d 0c 8f          	lea    (%rdi,%rcx,4),%r9
   55848:	49 83 c1 10          	add    $0x10,%r9
   5584c:	41 bb 01 00 00 00    	mov    $0x1,%r11d
   55852:	45 31 c0             	xor    %r8d,%r8d
   55855:	45 31 d2             	xor    %r10d,%r10d
   55858:	4c 39 d2             	cmp    %r10,%rdx
   5585b:	0f 84 ac 00 00 00    	je     5590d <f.36+0x28d>
   55861:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   55868:	0f 1f 84 00 00 00 00 
   5586f:	00 
   55870:	4d 85 db             	test   %r11,%r11
   55873:	0f 84 05 02 00 00    	je     55a7e <f.36+0x3fe>
   55879:	4c 39 56 08          	cmp    %r10,0x8(%rsi)
   5587d:	0f 86 fb 01 00 00    	jbe    55a7e <f.36+0x3fe>
   55883:	48 83 3d 65 4e 01 00 	cmpq   $0x0,0x14e65(%rip)        # 6a6f0 <g.9>
   5588a:	00 
   5588b:	0f 84 ed 01 00 00    	je     55a7e <f.36+0x3fe>
   55891:	4e 8d 1c 11          	lea    (%rcx,%r10,1),%r11
   55895:	4c 89 db             	mov    %r11,%rbx
   55898:	48 c1 eb 20          	shr    $0x20,%rbx
   5589c:	0f 85 dc 01 00 00    	jne    55a7e <f.36+0x3fe>
   558a2:	4c 39 5f 08          	cmp    %r11,0x8(%rdi)
   558a6:	0f 86 d2 01 00 00    	jbe    55a7e <f.36+0x3fe>
   558ac:	4e 63 5c 96 10       	movslq 0x10(%rsi,%r10,4),%r11
   558b1:	4c 0f af d8          	imul   %rax,%r11
   558b5:	4d 01 c3             	add    %r8,%r11
   558b8:	4b 63 1c 91          	movslq (%r9,%r10,4),%rbx
   558bc:	4d 8d 83 ff ff ff 3f 	lea    0x3fffffff(%r11),%r8
   558c3:	4d 85 db             	test   %r11,%r11
   558c6:	4d 0f 49 c3          	cmovns %r11,%r8
   558ca:	4d 89 c6             	mov    %r8,%r14
   558cd:	49 81 e6 00 00 00 c0 	and    $0xffffffffc0000000,%r14
   558d4:	4d 29 de             	sub    %r11,%r14
   558d7:	49 01 de             	add    %rbx,%r14
   558da:	4d 89 f3             	mov    %r14,%r11
   558dd:	49 c1 eb 21          	shr    $0x21,%r11
   558e1:	41 81 e3 00 00 00 40 	and    $0x40000000,%r11d
   558e8:	45 01 f3             	add    %r14d,%r11d
   558eb:	47 89 1c 91          	mov    %r11d,(%r9,%r10,4)
   558ef:	49 c1 ee 3f          	shr    $0x3f,%r14
   558f3:	49 ff c2             	inc    %r10
   558f6:	49 c1 f8 1e          	sar    $0x1e,%r8
   558fa:	4d 01 f0             	add    %r14,%r8
   558fd:	4c 8b 1d e4 4d 01 00 	mov    0x14de4(%rip),%r11        # 6a6e8 <g.8>
   55904:	4c 39 d2             	cmp    %r10,%rdx
   55907:	0f 85 63 ff ff ff    	jne    55870 <f.36+0x1f0>
   5590d:	4d 85 db             	test   %r11,%r11
   55910:	0f 84 68 01 00 00    	je     55a7e <f.36+0x3fe>
   55916:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
   5591a:	49 89 f1             	mov    %rsi,%r9
   5591d:	49 c1 e9 20          	shr    $0x20,%r9
   55921:	0f 85 57 01 00 00    	jne    55a7e <f.36+0x3fe>
   55927:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   5592b:	0f 86 4d 01 00 00    	jbe    55a7e <f.36+0x3fe>
   55931:	4c 63 4c b7 10       	movslq 0x10(%rdi,%rsi,4),%r9
   55936:	4d 29 c1             	sub    %r8,%r9
   55939:	4d 8d 41 01          	lea    0x1(%r9),%r8
   5593d:	49 83 f8 02          	cmp    $0x2,%r8
   55941:	0f 83 37 01 00 00    	jae    55a7e <f.36+0x3fe>
   55947:	48 83 3d a1 4d 01 00 	cmpq   $0x0,0x14da1(%rip)        # 6a6f0 <g.9>
   5594e:	00 
   5594f:	0f 84 29 01 00 00    	je     55a7e <f.36+0x3fe>
   55955:	4d 89 c8             	mov    %r9,%r8
   55958:	49 c1 e8 21          	shr    $0x21,%r8
   5595c:	41 81 e0 00 00 00 40 	and    $0x40000000,%r8d
   55963:	45 01 c8             	add    %r9d,%r8d
   55966:	44 89 44 b7 10       	mov    %r8d,0x10(%rdi,%rsi,4)
   5596b:	4d 85 c9             	test   %r9,%r9
   5596e:	0f 89 c1 01 00 00    	jns    55b35 <f.36+0x4b5>
   55974:	48 83 3d 4c 4e 01 00 	cmpq   $0x0,0x14e4c(%rip)        # 6a7c8 <g.37>
   5597b:	00 
   5597c:	0f 84 fc 00 00 00    	je     55a7e <f.36+0x3fe>
   55982:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   55987:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
   5598c:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   55991:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   55996:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   5599d:	00 00 
   5599f:	48 85 d2             	test   %rdx,%rdx
   559a2:	0f 84 35 01 00 00    	je     55add <f.36+0x45d>
   559a8:	48 83 3d 38 4d 01 00 	cmpq   $0x0,0x14d38(%rip)        # 6a6e8 <g.8>
   559af:	00 
   559b0:	0f 84 c8 00 00 00    	je     55a7e <f.36+0x3fe>
   559b6:	48 83 3d 32 4d 01 00 	cmpq   $0x0,0x14d32(%rip)        # 6a6f0 <g.9>
   559bd:	00 
   559be:	0f 84 ba 00 00 00    	je     55a7e <f.36+0x3fe>
   559c4:	49 89 c8             	mov    %rcx,%r8
   559c7:	49 c1 e8 20          	shr    $0x20,%r8
   559cb:	0f 85 ad 00 00 00    	jne    55a7e <f.36+0x3fe>
   559d1:	49 ba 00 00 00 00 01 	movabs $0x100000000,%r10
   559d8:	00 00 00 
   559db:	49 29 ca             	sub    %rcx,%r10
   559de:	4d 85 c9             	test   %r9,%r9
   559e1:	41 0f 95 c0          	setne  %r8b
   559e5:	41 f6 c1 01          	test   $0x1,%r9b
   559e9:	41 0f 94 c3          	sete   %r11b
   559ed:	45 20 c3             	and    %r8b,%r11b
   559f0:	48 85 ff             	test   %rdi,%rdi
   559f3:	41 0f 95 c0          	setne  %r8b
   559f7:	40 f6 c7 01          	test   $0x1,%dil
   559fb:	0f 94 c3             	sete   %bl
   559fe:	44 20 c3             	and    %r8b,%bl
   55a01:	48 ff ca             	dec    %rdx
   55a04:	45 31 c0             	xor    %r8d,%r8d
   55a07:	45 31 f6             	xor    %r14d,%r14d
   55a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   55a10:	84 db                	test   %bl,%bl
   55a12:	74 6a                	je     55a7e <f.36+0x3fe>
   55a14:	46 8d 3c 31          	lea    (%rcx,%r14,1),%r15d
   55a18:	4c 39 7f 08          	cmp    %r15,0x8(%rdi)
   55a1c:	76 60                	jbe    55a7e <f.36+0x3fe>
   55a1e:	45 84 db             	test   %r11b,%r11b
   55a21:	74 5b                	je     55a7e <f.36+0x3fe>
   55a23:	4d 39 71 08          	cmp    %r14,0x8(%r9)
   55a27:	76 55                	jbe    55a7e <f.36+0x3fe>
   55a29:	4e 63 64 bf 10       	movslq 0x10(%rdi,%r15,4),%r12
   55a2e:	4f 63 6c b1 10       	movslq 0x10(%r9,%r14,4),%r13
   55a33:	4d 01 e0             	add    %r12,%r8
   55a36:	4d 89 c4             	mov    %r8,%r12
   55a39:	4d 01 ec             	add    %r13,%r12
   55a3c:	4f 8d 84 05 ff ff ff 	lea    0x3fffffff(%r13,%r8,1),%r8
   55a43:	3f 
   55a44:	4d 0f 49 c4          	cmovns %r12,%r8
   55a48:	44 89 c5             	mov    %r8d,%ebp
   55a4b:	81 e5 00 00 00 c0    	and    $0xc0000000,%ebp
   55a51:	41 29 ec             	sub    %ebp,%r12d
   55a54:	46 89 64 bf 10       	mov    %r12d,0x10(%rdi,%r15,4)
   55a59:	49 c1 f8 1e          	sar    $0x1e,%r8
   55a5d:	4c 39 f2             	cmp    %r14,%rdx
   55a60:	74 7e                	je     55ae0 <f.36+0x460>
   55a62:	48 83 3d 7e 4c 01 00 	cmpq   $0x0,0x14c7e(%rip)        # 6a6e8 <g.8>
   55a69:	00 
   55a6a:	74 12                	je     55a7e <f.36+0x3fe>
   55a6c:	48 83 3d 7c 4c 01 00 	cmpq   $0x0,0x14c7c(%rip)        # 6a6f0 <g.9>
   55a73:	00 
   55a74:	74 08                	je     55a7e <f.36+0x3fe>
   55a76:	49 ff c6             	inc    %r14
   55a79:	4d 39 f2             	cmp    %r14,%r10
   55a7c:	75 92                	jne    55a10 <f.36+0x390>
   55a7e:	e8 5d c4 00 00       	call   61ee0 <native_trap>
   55a83:	4c 89 c3             	mov    %r8,%rbx
   55a86:	48 c1 e3 1e          	shl    $0x1e,%rbx
   55a8a:	4d 89 d6             	mov    %r10,%r14
   55a8d:	49 c1 e6 1e          	shl    $0x1e,%r14
   55a91:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   55a98:	0f 8f 82 fd ff ff    	jg     55820 <f.36+0x1a0>
   55a9e:	66 90                	xchg   %ax,%ax
   55aa0:	48 39 57 08          	cmp    %rdx,0x8(%rdi)
   55aa4:	76 d8                	jbe    55a7e <f.36+0x3fe>
   55aa6:	4c 39 5e 08          	cmp    %r11,0x8(%rsi)
   55aaa:	76 d2                	jbe    55a7e <f.36+0x3fe>
   55aac:	4c 63 7c 97 10       	movslq 0x10(%rdi,%rdx,4),%r15
   55ab1:	49 01 df             	add    %rbx,%r15
   55ab4:	4e 63 64 8e 08       	movslq 0x8(%rsi,%r9,4),%r12
   55ab9:	4c 0f af e0          	imul   %rax,%r12
   55abd:	4d 39 e7             	cmp    %r12,%r15
   55ac0:	0f 8d 5a fd ff ff    	jge    55820 <f.36+0x1a0>
   55ac6:	48 ff c8             	dec    %rax
   55ac9:	4d 01 d0             	add    %r10,%r8
   55acc:	4c 01 f3             	add    %r14,%rbx
   55acf:	49 81 f8 ff ff ff 3f 	cmp    $0x3fffffff,%r8
   55ad6:	7e c8                	jle    55aa0 <f.36+0x420>
   55ad8:	e9 43 fd ff ff       	jmp    55820 <f.36+0x1a0>
   55add:	45 31 c0             	xor    %r8d,%r8d
   55ae0:	48 83 3d 00 4c 01 00 	cmpq   $0x0,0x14c00(%rip)        # 6a6e8 <g.8>
   55ae7:	00 
   55ae8:	74 94                	je     55a7e <f.36+0x3fe>
   55aea:	48 83 3d fe 4b 01 00 	cmpq   $0x0,0x14bfe(%rip)        # 6a6f0 <g.9>
   55af1:	00 
   55af2:	74 8a                	je     55a7e <f.36+0x3fe>
   55af4:	48 85 ff             	test   %rdi,%rdi
   55af7:	74 85                	je     55a7e <f.36+0x3fe>
   55af9:	89 f9                	mov    %edi,%ecx
   55afb:	83 e1 01             	and    $0x1,%ecx
   55afe:	0f 85 7a ff ff ff    	jne    55a7e <f.36+0x3fe>
   55b04:	48 39 77 08          	cmp    %rsi,0x8(%rdi)
   55b08:	0f 86 70 ff ff ff    	jbe    55a7e <f.36+0x3fe>
   55b0e:	48 63 4c b7 10       	movslq 0x10(%rdi,%rsi,4),%rcx
   55b13:	49 01 c8             	add    %rcx,%r8
   55b16:	41 8d 88 ff ff ff 3f 	lea    0x3fffffff(%r8),%ecx
   55b1d:	4d 85 c0             	test   %r8,%r8
   55b20:	41 0f 49 c8          	cmovns %r8d,%ecx
   55b24:	81 e1 00 00 00 c0    	and    $0xc0000000,%ecx
   55b2a:	41 29 c8             	sub    %ecx,%r8d
   55b2d:	44 89 44 b7 10       	mov    %r8d,0x10(%rdi,%rsi,4)
   55b32:	48 ff c8             	dec    %rax
   55b35:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   55b3b:	74 12                	je     55b4f <f.36+0x4cf>
   55b3d:	48 8b 0c 24          	mov    (%rsp),%rcx
   55b41:	48 89 0d 08 4f 01 00 	mov    %rcx,0x14f08(%rip)        # 6aa50 <native_roots>
   55b48:	48 ff 0d 31 4e 01 00 	decq   0x14e31(%rip)        # 6a980 <root_depth>
   55b4f:	48 83 c4 38          	add    $0x38,%rsp
   55b53:	5b                   	pop    %rbx
   55b54:	41 5c                	pop    %r12
   55b56:	41 5d                	pop    %r13
   55b58:	41 5e                	pop    %r14
   55b5a:	41 5f                	pop    %r15
   55b5c:	5d                   	pop    %rbp
   55b5d:	c2 08 00             	ret    $0x8

