#!/usr/bin/env python3
"""Audit the completed matched builds and freeze a schedule without running it."""

from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parent
REVISIONS = {
    'baseline': 'd685a644207805a3f9e755e00fcbcac12118735f',
    'candidate': 'fdb9eb65bdfcd0e8752a2745350ced26ff9bd0f9',
}
WORKLOADS = {'pi': 100, 'chudnovsky': 1000}
CONTROLS = ['full', 'count-0', 'count-1', 'count-2', 'wrong-result', 'wrong-final']
MODES = ['production-v8', 'native-final-v8', 'native64']
SYSTEMS = [f'{revision}-{mode}' for mode in MODES for revision in REVISIONS]


# ---- Exact inputs, tools, source revisions and completed control processes ----

def read(path):
    return json.loads(path.read_text())


def save(name, value):
    (ROOT/name).write_text(json.dumps(value, indent=2) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_controls(directory):
    for control in CONTROLS:
        spec = read(directory/(control+'.spec.json'))
        for system in ['raw', 'production', 'native-final', 'native']:
            record = read(directory/(system+'-'+control+'.json'))
            assert record['returncode'] == 0 and not record['timeout']
            assert record['executing_descendants'] == []
            assert '--time' not in record['command']
            assert record['stdout'] == spec['output']
    return len(CONTROLS) * 4


def normalized_commands(revision, workload):
    directory = ROOT/revision/workload
    build, = directory.glob('native.native-*')
    source = read(ROOT/revision/'source.json')['root']
    replacements = [(str(build), '<native-build>'), (str(directory), '<workload>'),
                    (source, '<source>')]
    commands = read(build/'build.json')['commands']
    result = []
    for record in commands:
        assert record['status'] == 0
        command = []
        for argument in record['command']:
            for old, new in replacements:
                argument = argument.replace(old, new)
            command.append(argument)
        result.append(command)
    return result


tools = read(ROOT/'baseline/tools.json')
assert tools == read(ROOT/'candidate/tools.json')
sources = {revision: read(ROOT/revision/'source.json') for revision in REVISIONS}
control_count = 0
for revision, commit in REVISIONS.items():
    validation = read(ROOT/revision/'validated.json')
    assert validation['passed'] and validation['no_clock_started']
    assert validation['commit'] == sources[revision]['commit'] == commit
    assert validation['source_sha256'] == sources[revision]['sha256']
    for workload, count in WORKLOADS.items():
        directory = ROOT/revision/workload
        spec = read(directory/'full.spec.json')
        assert spec['count'] == count and spec['inputs'] == [50, 500, 50]
        build, = directory.glob('native.native-*')
        assert digest(build/'optimized.wasm') == digest(directory/'native-final.wasm')
        assert (build/'provider-0.o').is_file()
        control_count += validate_controls(directory)

for workload in WORKLOADS:
    baseline, candidate = [ROOT/revision/workload for revision in REVISIONS]
    names = ['original.scm', 'adapted.scm', 'strict.scm', 'input']
    names += [control+suffix for control in CONTROLS for suffix in ['.spec.json', '.native-input']]
    assert all(digest(baseline/name) == digest(candidate/name) for name in names)
    assert normalized_commands('baseline', workload) == normalized_commands('candidate', workload)
for name in ['integer-control-host.mjs', 'integer-control-entry.c', 'integer-provider.c', 'integer-provider.h']:
    assert digest(ROOT/'baseline/frozen/benchmarks/strict-suite'/name) == digest(ROOT/'candidate/frozen/benchmarks/strict-suite'/name)


# ---- Both Wasm stages retain exactly the intended local arithmetic change ----

def wasm_worker(path):
    text = path.read_text()
    start = text.index('(func $function85 ')
    depth = 0
    for end in range(start, len(text)):
        depth += (text[end] == '(') - (text[end] == ')')
        if depth == 0:
            return text[start:end+1]
    raise AssertionError('unterminated function85')


workers = []
for workload in WORKLOADS:
    for stage in ['production', 'native-final']:
        counts = {}
        for revision in REVISIONS:
            worker = wasm_worker(ROOT/revision/workload/(stage+'.wat'))
            counts[revision] = {op: len(re.findall(r'\('+re.escape(op)+r'(?=[\s)])', worker))
                for op in ['i64.and', 'i64.shr_u', 'i64.div_s', 'i64.rem_s',
                           'return_call', 'array.set', 'unreachable']}
        before, after = counts['baseline'], counts['candidate']
        assert [before[op] for op in ['i64.and', 'i64.shr_u', 'i64.div_s', 'i64.rem_s']] == [0, 0, 1, 1]
        assert [after[op] for op in ['i64.and', 'i64.shr_u', 'i64.div_s', 'i64.rem_s']] == [1, 1, 0, 0]
        assert all(before[op] == after[op] for op in ['return_call', 'array.set', 'unreachable'])
        workers.append(dict(workload=workload, stage=stage, worker='function85', counts=counts))
save('wasm-worker-audit.json', workers)


# ---- Fixed six-system schedule: two balanced Williams cycles ----

def command(workload, system, timed):
    revision, mode = system.split('-', 1)
    directory = ROOT/revision/workload
    if mode == 'native64':
        arguments = [str(directory/'native'), str(directory/'full.native-input')]
    else:
        module = 'production.wasm' if mode == 'production-v8' else 'native-final.wasm'
        host = ROOT/revision/'frozen/benchmarks/strict-suite/integer-control-host.mjs'
        arguments = [tools['NODE']['path'], str(host), str(directory/module), str(directory/'full.spec.json')]
    return [shutil.which('taskset'), '-c', '5', *arguments, '--time' if timed else '--validate']


base_order = [0, 1, 5, 2, 4, 3]
orders = [[(value + round_index % 6) % 6 for value in
           (base_order if round_index < 6 else list(reversed(base_order)))]
          for round_index in range(12)]
assert all(Counter(order[position] for order in orders) == Counter({i: 2 for i in range(6)})
           for position in range(6))
assert Counter((order[i], order[i+1]) for order in orders for i in range(5)) == Counter(
    {(a, b): 2 for a in range(6) for b in range(6) if a != b})
assert all(sum(order.index(i) < order.index(i+1) for order in orders) == 6 for i in [0, 2, 4])
schedule = []
for workload_index, workload in enumerate(WORKLOADS):
    for system in SYSTEMS[::1 if workload_index == 0 else -1]:
        schedule.append(dict(phase='untimed-warmup', workload=workload, system=system,
                             command=command(workload, system, False)))
for round_index, order in enumerate(orders):
    for workload in list(WORKLOADS)[::1 if round_index % 2 == 0 else -1]:
        for system_index in order:
            system = SYSTEMS[system_index]
            schedule.append(dict(phase='measurement', round=round_index, workload=workload,
                                 system=system, command=command(workload, system, True)))
for index, row in enumerate(schedule):
    row.update(index=index, cwd=str(ROOT), count=WORKLOADS[row['workload']])
    spec = read(ROOT/'baseline'/row['workload']/'full.spec.json')
    row['expected_output_sha256'] = hashlib.sha256(spec['output'].encode()).hexdigest()

identities = {str(path): digest(path) for revision in REVISIONS
              for path in sorted((ROOT/revision).rglob('*')) if path.is_file()}
identities[str(Path(__file__).resolve())] = digest(Path(__file__).resolve())
for path in [ROOT/'measure.py', ROOT/'process-driver.py', ROOT/'supervisor-provenance.json',
             *sorted((ROOT/'supervisor').glob('*.py'))]:
    identities[str(path)] = digest(path)
identities[str(Path(shutil.which('taskset')))] = digest(Path(shutil.which('taskset')))
for tool in tools.values():
    assert digest(Path(tool['path'])) == tool['sha256']
    identities[tool['path']] = tool['sha256']
guard_names = ['NODE_OPTIONS', 'NODE_V8_COVERAGE', 'NODE_DEBUG', 'NODE_DEBUG_NATIVE',
    'LD_PRELOAD', 'LD_LIBRARY_PATH', 'SNAIL_NATIVE_GC_INTERVAL', 'SNAIL_GC_STATS',
    'SNAIL_GC_HEAP_BYTES', 'SNAIL_GC_MIN_BYTES', 'SNAIL_INTEGER_TIME',
    'CHEZSCHEMELIBDIRS', 'SCHEMEHEAPDIRS', 'LANG', 'LC_ALL', 'TZ']
plan = dict(measurement_started=False, coordinated_release_required=True, cpu=5,
    supervisor=str(ROOT/'supervisor'), timeout_seconds=60,
    commits=REVISIONS, systems=SYSTEMS, counts=WORKLOADS, rounds=12,
    warmup_processes=12, measured_processes=144, fresh_processes=True, serial_execution=True,
    environment={'BINARYEN_CORES': '1'}, inherited_environment={name: os.environ.get(name) for name in guard_names},
    clock_boundary='Parse inputs and expected values and initialize before timing. Time computation plus the complete numerical predicate. Serialize afterward.',
    analysis='Keep all 12 samples per system; report median and range, candidate/baseline ratios within each mode, and all paired per-round ratios. Do not trim or stop adaptively.',
    failure_policy='Abort on timeout, nonzero exit, wrong complete stdout, extra/missing CSV time, hash or environment drift, surviving descendants, or competing measurement activity. Retain partial records and report the failure; do not silently retry.',
    balance='Two six-row Williams cycles. Each system occupies every position twice; each directed within-row adjacent pair occurs twice. Each candidate precedes its baseline six times and follows it six times. Alternate workload order by round.',
    source_scope='This plan compares freshly built committed production sources. Earlier WAT probe timings are separate evidence.',
    schedule=schedule, artifact_sha256=identities)
save('timing-plan.json', plan)
save('matched-ready.json', dict(passed=True, diagnostic_only=True, no_clock_started=True,
    commits=REVISIONS, tool_records_identical=True, inputs_identical=True, native_commands_identical_after_path_normalization=True,
    completed_control_executions=control_count, owned_build_handles={'70670': 0, '76184': 0},
    plan_sha256=digest(ROOT/'timing-plan.json'), hashed_files=len(identities),
    wasm_worker_audit_sha256=digest(ROOT/'wasm-worker-audit.json'),
    source_differences=[name for name, value in sources['baseline']['sha256'].items()
                        if sources['candidate']['sha256'][name] != value]))
print(f'PASS matched preparation: {control_count} controls; {len(identities)} identities; 12 warmups + 144 timed processes planned, none launched')
