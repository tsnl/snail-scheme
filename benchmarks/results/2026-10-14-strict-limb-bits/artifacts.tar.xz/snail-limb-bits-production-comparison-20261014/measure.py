#!/usr/bin/env python3
"""Verify or execute the frozen production comparison after coordinated release."""

import argparse
from datetime import datetime, timezone
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import statistics

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('owned_process_driver', ROOT/'process-driver.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)


# ---- The reviewed schedule and every retained dependency stay fixed ----

def verify_environment(plan):
    driver.verify_environment(plan)
    assert plan['cpu'] == 5 and 5 in os.sched_getaffinity(0)


def verify_identity(plan, path):
    assert driver.digest(path) == plan['artifact_sha256'][str(path)], f'changed artifact: {path}'


def verify(plan):
    verify_environment(plan)
    assert plan['rounds'] == 12 and plan['counts'] == {'pi': 100, 'chudnovsky': 1000}
    assert len(plan['schedule']) == 156 and not plan['measurement_started']
    for path in plan['artifact_sha256']:
        verify_identity(plan, Path(path))
    driver.verify_import_closure(plan)
    supervisor = driver.load_supervisor(plan)
    for workload in plan['counts']:
        for system in plan['systems']:
            rows = [row for row in plan['schedule'] if row['workload'] == workload and row['system'] == system]
            assert len(rows) == 13 and rows[0]['phase'] == 'untimed-warmup'
            assert [row['round'] for row in rows[1:]] == list(range(12))
    return supervisor


# ---- Complete output and one workload clock, with no parsing inside timing ----

def check_output(row, record):
    assert record['returncode'] == 0 and not record['stderr'] and not record['timeout']
    assert not record['executing_descendants'] and not record['cleanup']['live_members']
    config = json.loads((ROOT/'baseline'/row['workload']/'full.spec.json').read_text())
    if row['phase'] == 'untimed-warmup':
        assert record['stdout'] == config['output']
        return None
    label = 'native' if row['system'].endswith('-native64') else row['workload']
    prefix = config['output'] + f'+!CSVLINE!+snail-integer,{label}:{row["count"]},'
    match = re.fullmatch(re.escape(prefix) + r'([0-9.eE+\-]+)\n', record['stdout'])
    assert match, 'complete numerical output or clock framing differs'
    seconds = float(match[1])
    assert math.isfinite(seconds) and seconds > 0
    return seconds


def sample(plan, row, path, supervisor, diagnostic):
    verify_environment(plan)
    for argument in row['command']:
        if Path(argument).is_file():
            verify_identity(plan, Path(argument))
    record = dict(row, status='starting', started=datetime.now(timezone.utc).isoformat(),
                  diagnostic_only=diagnostic, environment=plan['environment'])
    driver.save(path, record)
    try:
        driver.run_owned(plan, row, record, path, supervisor)
        driver.check_stop()
        record.update(workload_seconds=check_output(row, record), status='valid')
    except BaseException as error:
        record.update(error=repr(error), status='failed')
        raise
    finally:
        driver.save(path, record)
    return record


# ---- Predetermined samples, paired revision comparisons and retained failures ----

def summarize(plan, samples):
    summaries = {}
    for workload in plan['counts']:
        summary, times = {}, {}
        for system in plan['systems']:
            rows = [row for row in samples if row['workload'] == workload
                    and row['system'] == system and row['phase'] == 'measurement']
            assert len(rows) == 12 and all(row['status'] == 'valid' for row in rows)
            times[system] = [row['workload_seconds'] for row in rows]
            summary[system] = dict(samples=12, median=statistics.median(times[system]),
                                   range=[min(times[system]), max(times[system])])
        comparisons = {}
        for mode in ['production-v8', 'native-final-v8', 'native64']:
            baseline, candidate = 'baseline-'+mode, 'candidate-'+mode
            ratios = [b/a for a, b in zip(times[baseline], times[candidate])]
            ratio = summary[candidate]['median'] / summary[baseline]['median']
            comparisons[mode] = dict(candidate_over_baseline=ratio, percent_less_time=100*(1-ratio),
                                     paired_round_ratios=ratios, paired_median=statistics.median(ratios))
        summaries[workload] = dict(systems=summary, comparisons=comparisons)
    return summaries


def execute(plan, output, diagnostic):
    supervisor = verify(plan)
    output.mkdir(parents=True, exist_ok=False)
    rows = [row for row in plan['schedule'] if row['phase'] == 'untimed-warmup'] if diagnostic else plan['schedule']
    report = dict(plan_sha256=driver.digest(ROOT/'timing-plan.json'), complete=False,
                  diagnostic_only=diagnostic, samples=[])
    driver.save(output/'host-before.json', driver.host_snapshot(plan['cpu']))
    try:
        for row in rows:
            driver.check_stop()
            report['pending_sample'] = row
            driver.save(output/'campaign.json', report)
            record = sample(plan, row, output/f'sample-{row["index"]:03}.json', supervisor, diagnostic)
            report['samples'].append(record)
            driver.save(output/'campaign.json', report)
            print(row['index'], row['workload'], row['system'], row['phase'], 'verified', flush=True)
        verify(plan)
        if not diagnostic:
            report['summary'] = summarize(plan, report['samples'])
        report.update(complete=True)
        report.pop('pending_sample')
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        driver.save(output/'host-after.json', driver.host_snapshot(plan['cpu']))
        driver.save(output/'campaign.json', report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument('--run', action='store_true', help='requires root-coordinated quiet-window release')
    actions.add_argument('--diagnose', action='store_true', help='run the twelve untimed full workload checks only')
    parser.add_argument('--expected-plan-sha256')
    parser.add_argument('--output', type=Path)
    options = parser.parse_args()
    plan_path = ROOT/'timing-plan.json'
    expected = options.expected_plan_sha256 or json.loads((ROOT/'matched-ready.json').read_text())['plan_sha256']
    assert driver.digest(plan_path) == expected, 'plan hash differs'
    plan = json.loads(plan_path.read_text())
    if not options.run and not options.diagnose:
        verify(plan)
        print('PASS frozen schedule, artifact identities and supervisor closure; no guest started')
        return
    if options.output is None or (options.run and options.expected_plan_sha256 is None):
        parser.error('execution needs fresh --output; --run also requires --expected-plan-sha256')
    signal.signal(signal.SIGTERM, driver.request_stop)
    signal.signal(signal.SIGINT, driver.request_stop)
    execute(plan, options.output, options.diagnose)


if __name__ == '__main__':
    main()
