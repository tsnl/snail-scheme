(module
 (rec
  (type $type23 (struct (field (ref $environment12))))
  (type $type24 (struct (field (mut i32)) (field (mut (ref null $type23)))))
  (type $environment12 (struct (field i64) (field (ref $type24))))
  (type $call23 (func (param (ref $environment12) i64 i64) (result i64)))
  (type $call21 (func (param (ref $environment10) i32 i64 i64) (result i32)))
  (type $call17 (func (param (ref $environment8) (ref null $type1) i64) (result i32)))
  (type $call19 (func (param (ref $environment7) (ref null $type1) i64) (result i64)))
  (type $type17 (struct (field (ref $environment8))))
  (type $type19 (struct (field (ref $environment7))))
  (type $environment8 (struct (field (ref $type11)) (field (ref $type18))))
  (type $type18 (struct (field (mut i32)) (field (mut (ref null $type17)))))
  (type $type20 (struct (field (mut i32)) (field (mut (ref null $type19)))))
  (type $environment7 (struct (field (ref $type20))))
  (type $call0 (func (param (ref null $type1)) (result (ref $type2))))
  (type $call15 (func (param (ref $environment4) i64 (ref $type1)) (result (ref null $type1))))
  (type $type21 (struct (field (ref $environment10))))
  (type $environment10 (struct (field (ref $type2)) (field f64) (field f64) (field (ref $type2)) (field (ref $type22))))
  (type $type15 (struct (field (ref $environment4))))
  (type $type16 (struct (field (mut i32)) (field (mut (ref null $type15)))))
  (type $type1 (struct (field f64) (field (ref null $type1))))
  (type $environment4 (struct (field (ref $type16)) (field (ref $type2))))
  (type $type22 (struct (field (mut i32)) (field (mut (ref null $type21)))))
  (type $call8 (func (param (ref $type2) (ref $type2)) (result i64)))
  (type $call12 (func (param (ref $environment1) i64) (result i32)))
  (type $type12 (struct (field (ref $environment1))))
  (type $environment1 (struct (field (ref $type10)) (field (ref $type11)) (field i32) (field (ref $type13))))
  (type $type11 (struct (field i32) (field (ref $type2))))
  (type $type10 (struct (field (mut i32)) (field (mut i64))))
  (type $type13 (struct (field (mut i32)) (field (mut (ref null $type12)))))
  (type $call5 (func (param i32) (result (ref $type2))))
  (type $type9 (struct))
  (type $type2 (array (mut f64)))
  (type $type8 (struct))
  (type $type7 (struct))
  (type $type6 (struct))
  (type $type5 (struct))
  (type $type4 (struct))
  (type $type3 (struct))
  (type $type0 (struct))
 )
 (type $39 (func (param i32) (result i64)))
 (type $40 (func (param i32 i64) (result f64)))
 (type $41 (func (result i32)))
 (type $42 (func (param (ref $environment1) i64)))
 (type $43 (func (param (ref $environment8) (ref null $type1) i64)))
 (type $44 (func (param i64) (result i64)))
 (type $45 (func))
 (import "benchmark" "vector_length" (func $foreign0 (param i32) (result i64)))
 (import "benchmark" "vector_f64" (func $foreign1 (param i32 i64) (result f64)))
 (import "benchmark" "barrier" (func $foreign2 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $global16 (mut (ref null $type0)) (ref.null none))
 (global $ready16 (mut i32) (i32.const 0))
 (global $global19 (mut (ref null $type3)) (ref.null none))
 (global $ready19 (mut i32) (i32.const 0))
 (global $global11 (mut (ref null $type4)) (ref.null none))
 (global $ready11 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type5)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global47 (mut (ref null $type6)) (ref.null none))
 (global $ready47 (mut i32) (i32.const 0))
 (global $global28 (mut (ref null $type7)) (ref.null none))
 (global $ready28 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type8)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global40 (mut (ref null $type2)) (ref.null none))
 (global $ready40 (mut i32) (i32.const 0))
 (global $global41 (mut (ref null $type2)) (ref.null none))
 (global $ready41 (mut i32) (i32.const 0))
 (global $global42 (mut (ref null $type9)) (ref.null none))
 (global $ready42 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call5) (param $0 i32) (result (ref $type2))
  (local $1 (ref $type10))
  (local $2 (ref $type13))
  (local $3 (ref $type11))
  (local $4 i64)
  (local.set $1
   (struct.new $type10
    (i32.const 1)
    (call $foreign0
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type10 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $4
     (struct.get $type10 1
      (local.get $1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type13 1
   (local.tee $2
    (struct.new_default $type13)
   )
   (struct.new $type12
    (struct.new $environment1
     (local.get $1)
     (local.tee $3
      (struct.new $type11
       (i32.const 1)
       (array.new_default $type2
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
     (local.get $0)
     (local.get $2)
    )
   )
  )
  (struct.set $type13 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type13 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (call $function1
   (struct.get $type12 0
    (struct.get $type13 1
     (local.get $2)
    )
   )
   (i64.const 0)
  )
  (struct.get $type11 1
   (local.get $3)
  )
 )
 (func $function1 (param $0 (ref $environment1)) (param $1 i64)
  (local $2 f64)
  (if
   (i32.eqz
    (struct.get $type10 0
     (struct.get $environment1 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_s
    (struct.get $type10 1
     (struct.get $environment1 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (local.set $2
     (call $foreign1
      (struct.get $environment1 2
       (local.get $0)
      )
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type2
     (struct.get $type11 1
      (struct.get $environment1 1
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $2)
    )
    (if
     (i32.eqz
      (struct.get $type13 0
       (struct.get $environment1 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $function1
     (struct.get $type12 0
      (struct.get $type13 1
       (struct.get $environment1 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function2 (type $call8) (param $0 (ref $type2)) (param $1 (ref $type2)) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 (ref $environment4))
  (local $6 (ref $type22))
  (local $7 (ref $type1))
  (local $8 (ref $type16))
  (local $9 (ref null $type1))
  (local $scratch (ref null $type1))
  (local $scratch_11 (ref null $type1))
  (if
   (i32.eqz
    (global.get $ready11)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global11)
   )
  )
  (struct.set $type16 1
   (local.tee $8
    (struct.new_default $type16)
   )
   (struct.new $type15
    (struct.new $environment4
     (local.get $8)
     (local.get $0)
    )
   )
  )
  (struct.set $type16 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type16 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type15 0
    (struct.get $type16 1
     (local.get $8)
    )
   )
  )
  (local.set $0
   (call $function5
    (block (result (ref null $type1))
     (local.set $scratch
      (if (result (ref null $type1))
       (i64.eqz
        (local.tee $2
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
        )
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i64.gt_u
          (local.tee $3
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $7
         (struct.new $type1
          (array.get $type2
           (struct.get $environment4 1
            (local.get $5)
           )
           (i32.wrap_i64
            (local.get $3)
           )
          )
          (block (result nullref)
           (if
            (i32.eqz
             (struct.get $type16 0
              (struct.get $environment4 0
               (local.get $5)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $type15 0
             (struct.get $type16 1
              (struct.get $environment4 0
               (local.get $5)
              )
             )
            )
           )
           (ref.null none)
          )
         )
        )
        (if (result (ref null $type1))
         (i64.eqz
          (local.tee $2
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $7)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.set $7
           (struct.new $type1
            (array.get $type2
             (struct.get $environment4 1
              (local.get $5)
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
            (block (result (ref $type1))
             (if
              (i32.eqz
               (struct.get $type16 0
                (struct.get $environment4 0
                 (local.get $5)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $5
              (struct.get $type15 0
               (struct.get $type16 1
                (struct.get $environment4 0
                 (local.get $5)
                )
               )
              )
             )
             (local.get $7)
            )
           )
          )
          (if (result (ref null $type1))
           (i64.eqz
            (local.tee $2
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $7)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (local.set $7
             (struct.new $type1
              (array.get $type2
               (struct.get $environment4 1
                (local.get $5)
               )
               (i32.wrap_i64
                (local.get $3)
               )
              )
              (block (result (ref $type1))
               (if
                (i32.eqz
                 (struct.get $type16 0
                  (struct.get $environment4 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $5
                (struct.get $type15 0
                 (struct.get $type16 1
                  (struct.get $environment4 0
                   (local.get $5)
                  )
                 )
                )
               )
               (local.get $7)
              )
             )
            )
            (if (result (ref null $type1))
             (i64.eqz
              (local.tee $2
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $7)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $3
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                )
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (local.set $7
               (struct.new $type1
                (array.get $type2
                 (struct.get $environment4 1
                  (local.get $5)
                 )
                 (i32.wrap_i64
                  (local.get $3)
                 )
                )
                (block (result (ref $type1))
                 (if
                  (i32.eqz
                   (struct.get $type16 0
                    (struct.get $environment4 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $5
                  (struct.get $type15 0
                   (struct.get $type16 1
                    (struct.get $environment4 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (local.get $7)
                )
               )
              )
              (if (result (ref null $type1))
               (i64.eqz
                (local.tee $2
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $7)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $3
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $7
                 (struct.new $type1
                  (array.get $type2
                   (struct.get $environment4 1
                    (local.get $5)
                   )
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                  (block (result (ref $type1))
                   (if
                    (i32.eqz
                     (struct.get $type16 0
                      (struct.get $environment4 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $5
                    (struct.get $type15 0
                     (struct.get $type16 1
                      (struct.get $environment4 0
                       (local.get $5)
                      )
                     )
                    )
                   )
                   (local.get $7)
                  )
                 )
                )
                (if (result (ref null $type1))
                 (i64.eqz
                  (local.tee $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $7)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.sub
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                    (i64.const 4294967295)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $7
                   (struct.new $type1
                    (array.get $type2
                     (struct.get $environment4 1
                      (local.get $5)
                     )
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                    (block (result (ref $type1))
                     (if
                      (i32.eqz
                       (struct.get $type16 0
                        (struct.get $environment4 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $5
                      (struct.get $type15 0
                       (struct.get $type16 1
                        (struct.get $environment4 0
                         (local.get $5)
                        )
                       )
                      )
                     )
                     (local.get $7)
                    )
                   )
                  )
                  (if (result (ref null $type1))
                   (i64.eqz
                    (local.tee $2
                     (i64.sub
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $7)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $7
                     (struct.new $type1
                      (array.get $type2
                       (struct.get $environment4 1
                        (local.get $5)
                       )
                       (i32.wrap_i64
                        (local.get $3)
                       )
                      )
                      (block (result (ref $type1))
                       (if
                        (i32.eqz
                         (struct.get $type16 0
                          (struct.get $environment4 0
                           (local.get $5)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $5
                        (struct.get $type15 0
                         (struct.get $type16 1
                          (struct.get $environment4 0
                           (local.get $5)
                          )
                         )
                        )
                       )
                       (local.get $7)
                      )
                     )
                    )
                    (if (result (ref null $type1))
                     (i64.eqz
                      (local.tee $2
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $7)
                     )
                     (else
                      (if
                       (i64.gt_u
                        (local.tee $3
                         (i64.sub
                          (local.get $2)
                          (i64.const 1)
                         )
                        )
                        (i64.const 4294967295)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $7
                       (struct.new $type1
                        (array.get $type2
                         (struct.get $environment4 1
                          (local.get $5)
                         )
                         (i32.wrap_i64
                          (local.get $3)
                         )
                        )
                        (block (result (ref $type1))
                         (if
                          (i32.eqz
                           (struct.get $type16 0
                            (struct.get $environment4 0
                             (local.get $5)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $5
                          (struct.get $type15 0
                           (struct.get $type16 1
                            (struct.get $environment4 0
                             (local.get $5)
                            )
                           )
                          )
                         )
                         (local.get $7)
                        )
                       )
                      )
                      (if (result (ref null $type1))
                       (i64.eqz
                        (local.tee $2
                         (i64.sub
                          (local.get $2)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $7)
                       )
                       (else
                        (if
                         (i64.gt_u
                          (local.tee $3
                           (i64.sub
                            (local.get $2)
                            (i64.const 1)
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $4
                         (array.get $type2
                          (struct.get $environment4 1
                           (local.get $5)
                          )
                          (i32.wrap_i64
                           (local.get $3)
                          )
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type16 0
                           (struct.get $environment4 0
                            (local.get $5)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $function4
                         (struct.get $type15 0
                          (struct.get $type16 1
                           (struct.get $environment4 0
                            (local.get $5)
                           )
                          )
                         )
                         (i64.sub
                          (local.get $2)
                          (i64.const 1)
                         )
                         (struct.new $type1
                          (local.get $4)
                          (local.get $7)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready16)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global16)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready11)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global11)
   )
  )
  (struct.set $type16 1
   (local.tee $8
    (struct.new_default $type16)
   )
   (struct.new $type15
    (struct.new $environment4
     (local.get $8)
     (local.get $1)
    )
   )
  )
  (struct.set $type16 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type16 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type15 0
    (struct.get $type16 1
     (local.get $8)
    )
   )
  )
  (local.set $1
   (call $function5
    (block (result (ref null $type1))
     (local.set $scratch_11
      (if (result (ref null $type1))
       (i64.eqz
        (local.tee $2
         (i64.extend_i32_u
          (array.len
           (local.get $1)
          )
         )
        )
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i64.gt_u
          (local.tee $3
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $7
         (struct.new $type1
          (array.get $type2
           (struct.get $environment4 1
            (local.get $5)
           )
           (i32.wrap_i64
            (local.get $3)
           )
          )
          (block (result nullref)
           (if
            (i32.eqz
             (struct.get $type16 0
              (struct.get $environment4 0
               (local.get $5)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $type15 0
             (struct.get $type16 1
              (struct.get $environment4 0
               (local.get $5)
              )
             )
            )
           )
           (ref.null none)
          )
         )
        )
        (if (result (ref null $type1))
         (i64.eqz
          (local.tee $2
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $7)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.set $7
           (struct.new $type1
            (array.get $type2
             (struct.get $environment4 1
              (local.get $5)
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
            (block (result (ref $type1))
             (if
              (i32.eqz
               (struct.get $type16 0
                (struct.get $environment4 0
                 (local.get $5)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $5
              (struct.get $type15 0
               (struct.get $type16 1
                (struct.get $environment4 0
                 (local.get $5)
                )
               )
              )
             )
             (local.get $7)
            )
           )
          )
          (if (result (ref null $type1))
           (i64.eqz
            (local.tee $2
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $7)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (local.set $7
             (struct.new $type1
              (array.get $type2
               (struct.get $environment4 1
                (local.get $5)
               )
               (i32.wrap_i64
                (local.get $3)
               )
              )
              (block (result (ref $type1))
               (if
                (i32.eqz
                 (struct.get $type16 0
                  (struct.get $environment4 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $5
                (struct.get $type15 0
                 (struct.get $type16 1
                  (struct.get $environment4 0
                   (local.get $5)
                  )
                 )
                )
               )
               (local.get $7)
              )
             )
            )
            (if (result (ref null $type1))
             (i64.eqz
              (local.tee $2
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $7)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $3
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                )
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (local.set $7
               (struct.new $type1
                (array.get $type2
                 (struct.get $environment4 1
                  (local.get $5)
                 )
                 (i32.wrap_i64
                  (local.get $3)
                 )
                )
                (block (result (ref $type1))
                 (if
                  (i32.eqz
                   (struct.get $type16 0
                    (struct.get $environment4 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $5
                  (struct.get $type15 0
                   (struct.get $type16 1
                    (struct.get $environment4 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (local.get $7)
                )
               )
              )
              (if (result (ref null $type1))
               (i64.eqz
                (local.tee $2
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $7)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $3
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $7
                 (struct.new $type1
                  (array.get $type2
                   (struct.get $environment4 1
                    (local.get $5)
                   )
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                  (block (result (ref $type1))
                   (if
                    (i32.eqz
                     (struct.get $type16 0
                      (struct.get $environment4 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $5
                    (struct.get $type15 0
                     (struct.get $type16 1
                      (struct.get $environment4 0
                       (local.get $5)
                      )
                     )
                    )
                   )
                   (local.get $7)
                  )
                 )
                )
                (if (result (ref null $type1))
                 (i64.eqz
                  (local.tee $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $7)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.sub
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                    (i64.const 4294967295)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $7
                   (struct.new $type1
                    (array.get $type2
                     (struct.get $environment4 1
                      (local.get $5)
                     )
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                    (block (result (ref $type1))
                     (if
                      (i32.eqz
                       (struct.get $type16 0
                        (struct.get $environment4 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $5
                      (struct.get $type15 0
                       (struct.get $type16 1
                        (struct.get $environment4 0
                         (local.get $5)
                        )
                       )
                      )
                     )
                     (local.get $7)
                    )
                   )
                  )
                  (if (result (ref null $type1))
                   (i64.eqz
                    (local.tee $2
                     (i64.sub
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $7)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $7
                     (struct.new $type1
                      (array.get $type2
                       (struct.get $environment4 1
                        (local.get $5)
                       )
                       (i32.wrap_i64
                        (local.get $3)
                       )
                      )
                      (block (result (ref $type1))
                       (if
                        (i32.eqz
                         (struct.get $type16 0
                          (struct.get $environment4 0
                           (local.get $5)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $5
                        (struct.get $type15 0
                         (struct.get $type16 1
                          (struct.get $environment4 0
                           (local.get $5)
                          )
                         )
                        )
                       )
                       (local.get $7)
                      )
                     )
                    )
                    (if (result (ref null $type1))
                     (i64.eqz
                      (local.tee $2
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $7)
                     )
                     (else
                      (if
                       (i64.gt_u
                        (local.tee $3
                         (i64.sub
                          (local.get $2)
                          (i64.const 1)
                         )
                        )
                        (i64.const 4294967295)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $7
                       (struct.new $type1
                        (array.get $type2
                         (struct.get $environment4 1
                          (local.get $5)
                         )
                         (i32.wrap_i64
                          (local.get $3)
                         )
                        )
                        (block (result (ref $type1))
                         (if
                          (i32.eqz
                           (struct.get $type16 0
                            (struct.get $environment4 0
                             (local.get $5)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $5
                          (struct.get $type15 0
                           (struct.get $type16 1
                            (struct.get $environment4 0
                             (local.get $5)
                            )
                           )
                          )
                         )
                         (local.get $7)
                        )
                       )
                      )
                      (if (result (ref null $type1))
                       (i64.eqz
                        (local.tee $2
                         (i64.sub
                          (local.get $2)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $7)
                       )
                       (else
                        (if
                         (i64.gt_u
                          (local.tee $3
                           (i64.sub
                            (local.get $2)
                            (i64.const 1)
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $4
                         (array.get $type2
                          (struct.get $environment4 1
                           (local.get $5)
                          )
                          (i32.wrap_i64
                           (local.get $3)
                          )
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type16 0
                           (struct.get $environment4 0
                            (local.get $5)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $function4
                         (struct.get $type15 0
                          (struct.get $type16 1
                           (struct.get $environment4 0
                            (local.get $5)
                           )
                          )
                         )
                         (i64.sub
                          (local.get $2)
                          (i64.const 1)
                         )
                         (struct.new $type1
                          (local.get $4)
                          (local.get $7)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready16)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global16)
      )
     )
     (local.get $scratch_11)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const 0.5)
     (f64.const 0.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (i64.extend_i32_u
    (i32.ne
     (call $function10
      (struct.get $type21 0
       (struct.get $type22 1
        (local.get $6)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $0)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const 1.5)
     (f64.const 0.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const 1.5)
     (f64.const -0.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const 2.25)
     (f64.const 0.75)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const 2.01)
     (f64.const 0)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const 2.5)
     (f64.const -0.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const -0.5)
     (f64.const -1)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const 0.5)
     (f64.const -1.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const -1)
     (f64.const -2.25)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const -0.25)
     (f64.const 0.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const -1.25)
     (f64.const 0.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (select
    (i64.add
     (local.get $2)
     (i64.const 1)
    )
    (local.get $2)
    (call $function10
     (struct.get $type21 0
      (struct.get $type22 1
       (local.get $6)
      )
     )
     (i32.const 0)
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready28)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global28)
   )
  )
  (struct.set $type22 1
   (local.tee $6
    (struct.new_default $type22)
   )
   (struct.new $type21
    (struct.new $environment10
     (local.get $1)
     (f64.const -2.5)
     (f64.const -0.5)
     (local.get $0)
     (local.get $6)
    )
   )
  )
  (struct.set $type22 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (select
   (i64.add
    (local.get $2)
    (i64.const 1)
   )
   (local.get $2)
   (call $function10
    (struct.get $type21 0
     (struct.get $type22 1
      (local.get $6)
     )
    )
    (i32.const 0)
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $0)
      )
     )
     (i64.const 1)
    )
    (i64.const 0)
   )
  )
 )
 (func $function4 (type $call15) (param $0 (ref $environment4)) (param $1 i64) (param $2 (ref $type1)) (result (ref null $type1))
  (local $3 i64)
  (local $4 f64)
  (if (result (ref $type1))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $3
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type2
      (struct.get $environment4 1
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type16 0
       (struct.get $environment4 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function4
     (struct.get $type15 0
      (struct.get $type16 1
       (struct.get $environment4 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type1
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function5 (type $call0) (param $0 (ref null $type1)) (result (ref $type2))
  (local $1 (ref $environment7))
  (local $2 (ref null $type1))
  (local $3 (ref $environment8))
  (local $4 (ref $type20))
  (local $5 (ref $type18))
  (local $6 (ref $type11))
  (local $7 i64)
  (if (result (ref $type2))
   (ref.is_null
    (local.get $0)
   )
   (then
    (array.new_fixed $type2 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready19)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global19)
     )
    )
    (struct.set $type20 1
     (local.tee $4
      (struct.new_default $type20)
     )
     (struct.new $type19
      (struct.new $environment7
       (local.get $4)
      )
     )
    )
    (struct.set $type20 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type20 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type19 0
      (struct.get $type20 1
       (local.get $4)
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (if (result i64)
        (ref.is_null
         (local.get $0)
        )
        (then
         (i64.const 0)
        )
        (else
         (local.set $2
          (struct.get $type1 1
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (struct.get $type20 0
            (struct.get $environment7 0
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type19 0
           (struct.get $type20 1
            (struct.get $environment7 0
             (local.get $1)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 1)
          )
          (else
           (local.set $2
            (struct.get $type1 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (struct.get $type20 0
              (struct.get $environment7 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type19 0
             (struct.get $type20 1
              (struct.get $environment7 0
               (local.get $1)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i64.const 2)
            )
            (else
             (local.set $2
              (struct.get $type1 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (struct.get $type20 0
                (struct.get $environment7 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type19 0
               (struct.get $type20 1
                (struct.get $environment7 0
                 (local.get $1)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i64.const 3)
              )
              (else
               (local.set $2
                (struct.get $type1 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type20 0
                  (struct.get $environment7 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type19 0
                 (struct.get $type20 1
                  (struct.get $environment7 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i64.const 4)
                )
                (else
                 (local.set $2
                  (struct.get $type1 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type20 0
                    (struct.get $environment7 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type19 0
                   (struct.get $type20 1
                    (struct.get $environment7 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i64.const 5)
                  )
                  (else
                   (local.set $2
                    (struct.get $type1 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type20 0
                      (struct.get $environment7 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type19 0
                     (struct.get $type20 1
                      (struct.get $environment7 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i64.const 6)
                    )
                    (else
                     (local.set $2
                      (struct.get $type1 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type20 0
                        (struct.get $environment7 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type19 0
                       (struct.get $type20 1
                        (struct.get $environment7 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i64.const 7)
                      )
                      (else
                       (local.set $2
                        (struct.get $type1 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type20 0
                          (struct.get $environment7 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (struct.get $type19 0
                         (struct.get $type20 1
                          (struct.get $environment7 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (i64.const 8)
                        )
                        (else
                         (local.set $2
                          (struct.get $type1 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type20 0
                            (struct.get $environment7 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (call $function7
                          (struct.get $type19 0
                           (struct.get $type20 1
                            (struct.get $environment7 0
                             (local.get $1)
                            )
                           )
                          )
                          (local.get $2)
                          (i64.const 9)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type18 1
     (local.tee $5
      (struct.new_default $type18)
     )
     (struct.new $type17
      (struct.new $environment8
       (local.tee $6
        (struct.new $type11
         (i32.const 1)
         (array.new $type2
          (struct.get $type1 0
           (local.get $0)
          )
          (i32.wrap_i64
           (local.get $7)
          )
         )
        )
       )
       (local.get $5)
      )
     )
    )
    (struct.set $type18 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type18 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type17 0
      (struct.get $type18 1
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (ref.is_null
       (local.get $0)
      )
     )
     (then
      (array.set $type2
       (struct.get $type11 1
        (struct.get $environment8 0
         (local.get $3)
        )
       )
       (i32.const 0)
       (struct.get $type1 0
        (local.get $0)
       )
      )
      (local.set $0
       (struct.get $type1 1
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (struct.get $type18 0
         (struct.get $environment8 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type17 0
        (struct.get $type18 1
         (struct.get $environment8 1
          (local.get $3)
         )
        )
       )
      )
      (if
       (i32.eqz
        (ref.is_null
         (local.get $0)
        )
       )
       (then
        (array.set $type2
         (struct.get $type11 1
          (struct.get $environment8 0
           (local.get $3)
          )
         )
         (i32.const 1)
         (struct.get $type1 0
          (local.get $0)
         )
        )
        (local.set $0
         (struct.get $type1 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (struct.get $type18 0
           (struct.get $environment8 1
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type17 0
          (struct.get $type18 1
           (struct.get $environment8 1
            (local.get $3)
           )
          )
         )
        )
        (if
         (i32.eqz
          (ref.is_null
           (local.get $0)
          )
         )
         (then
          (array.set $type2
           (struct.get $type11 1
            (struct.get $environment8 0
             (local.get $3)
            )
           )
           (i32.const 2)
           (struct.get $type1 0
            (local.get $0)
           )
          )
          (local.set $0
           (struct.get $type1 1
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (struct.get $type18 0
             (struct.get $environment8 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type17 0
            (struct.get $type18 1
             (struct.get $environment8 1
              (local.get $3)
             )
            )
           )
          )
          (if
           (i32.eqz
            (ref.is_null
             (local.get $0)
            )
           )
           (then
            (array.set $type2
             (struct.get $type11 1
              (struct.get $environment8 0
               (local.get $3)
              )
             )
             (i32.const 3)
             (struct.get $type1 0
              (local.get $0)
             )
            )
            (local.set $0
             (struct.get $type1 1
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (struct.get $type18 0
               (struct.get $environment8 1
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type17 0
              (struct.get $type18 1
               (struct.get $environment8 1
                (local.get $3)
               )
              )
             )
            )
            (if
             (i32.eqz
              (ref.is_null
               (local.get $0)
              )
             )
             (then
              (array.set $type2
               (struct.get $type11 1
                (struct.get $environment8 0
                 (local.get $3)
                )
               )
               (i32.const 4)
               (struct.get $type1 0
                (local.get $0)
               )
              )
              (local.set $0
               (struct.get $type1 1
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (struct.get $type18 0
                 (struct.get $environment8 1
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (call $function8
               (struct.get $type17 0
                (struct.get $type18 1
                 (struct.get $environment8 1
                  (local.get $3)
                 )
                )
               )
               (local.get $0)
               (i64.const 5)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (struct.get $type11 1
     (local.get $6)
    )
   )
  )
 )
 (func $function7 (type $call19) (param $0 (ref $environment7)) (param $1 (ref null $type1)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type1 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type20 0
         (struct.get $environment7 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function7
       (struct.get $type19 0
        (struct.get $type20 1
         (struct.get $environment7 0
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function8 (param $0 (ref $environment8)) (param $1 (ref null $type1)) (param $2 i64)
  (local $3 f64)
  (if
   (i32.eqz
    (ref.is_null
     (local.get $1)
    )
   )
   (then
    (local.set $3
     (struct.get $type1 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type2
     (struct.get $type11 1
      (struct.get $environment8 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type1 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type18 0
       (struct.get $environment8 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $function8
     (struct.get $type17 0
      (struct.get $type18 1
       (struct.get $environment8 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function10 (type $call21) (param $0 (ref $environment10)) (param $1 i32) (param $2 i64) (param $3 i64) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 f64)
  (local $7 (ref $type2))
  (if (result i32)
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (local.tee $4
       (if (result i32)
        (if (result i32)
         (local.tee $4
          (f64.lt
           (struct.get $environment10 1
            (local.get $0)
           )
           (array.get $type2
            (struct.get $environment10 0
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $2)
            )
           )
          )
         )
         (then
          (local.get $4)
         )
         (else
          (if
           (i64.gt_u
            (local.get $3)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (f64.ge
           (struct.get $environment10 1
            (local.get $0)
           )
           (array.get $type2
            (struct.get $environment10 0
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $3)
            )
           )
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if (result i32)
          (local.tee $4
           (f64.lt
            (struct.get $environment10 1
             (local.get $0)
            )
            (array.get $type2
             (struct.get $environment10 0
              (local.get $0)
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (then
           (local.get $4)
          )
          (else
           (if
            (i64.gt_u
             (local.get $2)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (f64.ge
            (struct.get $environment10 1
             (local.get $0)
            )
            (array.get $type2
             (struct.get $environment10 0
              (local.get $0)
             )
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (then
       (local.get $4)
      )
      (else
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $3)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $3)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (f64.le
        (f64.add
         (local.tee $6
          (array.get $type2
           (local.tee $7
            (struct.get $environment10 3
             (local.get $0)
            )
           )
           (local.tee $4
            (i32.wrap_i64
             (local.get $2)
            )
           )
          )
         )
         (f64.div
          (f64.mul
           (f64.sub
            (array.get $type2
             (local.get $7)
             (local.tee $5
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (local.get $6)
           )
           (f64.sub
            (struct.get $environment10 1
             (local.get $0)
            )
            (local.tee $6
             (array.get $type2
              (local.tee $7
               (struct.get $environment10 0
                (local.get $0)
               )
              )
              (local.get $4)
             )
            )
           )
          )
          (f64.sub
           (array.get $type2
            (local.get $7)
            (local.get $5)
           )
           (local.get $6)
          )
         )
        )
        (struct.get $environment10 2
         (local.get $0)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type22 0
         (struct.get $environment10 4
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function10
       (struct.get $type21 0
        (struct.get $type22 1
         (struct.get $environment10 4
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
       (local.get $2)
      )
     )
     (else
      (if
       (i32.eqz
        (struct.get $type22 0
         (struct.get $environment10 4
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function10
       (struct.get $type21 0
        (struct.get $type22 1
         (struct.get $environment10 4
          (local.get $0)
         )
        )
       )
       (i32.eqz
        (local.get $1)
       )
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
       (local.get $2)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function12 (type $call23) (param $0 (ref $environment12)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type2))
  (local $4 (ref $type2))
  (local $scratch (ref $type2))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment12 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready40)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function2
      (ref.as_non_null
       (global.get $global40)
      )
      (block (result (ref $type2))
       (if
        (i32.eqz
         (global.get $ready47)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global47)
        )
       )
       (if
        (i32.eqz
         (call $foreign2)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready41)
        )
        (then
         (unreachable)
        )
       )
       (local.set $scratch
        (ref.as_non_null
         (global.get $global41)
        )
       )
       (if
        (i32.eqz
         (global.get $ready47)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global47)
        )
       )
       (if
        (i32.eqz
         (call $foreign2)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready6)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global6)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type24 0
       (struct.get $environment12 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function12
     (struct.get $type23 0
      (struct.get $type24 1
       (struct.get $environment12 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type24))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready42)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global42)
   )
  )
  (struct.set $type24 1
   (local.tee $1
    (struct.new_default $type24)
   )
   (struct.new $type23
    (struct.new $environment12
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type24 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type24 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function12
   (struct.get $type23 0
    (struct.get $type24 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global16
   (struct.new_default $type0)
  )
  (global.set $ready16
   (i32.const 1)
  )
  (global.set $global19
   (struct.new_default $type3)
  )
  (global.set $ready19
   (i32.const 1)
  )
  (global.set $global11
   (struct.new_default $type4)
  )
  (global.set $ready11
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type5)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global47
   (struct.new_default $type6)
  )
  (global.set $ready47
   (i32.const 1)
  )
  (global.set $global28
   (struct.new_default $type7)
  )
  (global.set $ready28
   (i32.const 1)
  )
  (global.set $global6
   (struct.new_default $type8)
  )
  (global.set $ready6
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (global.set $global40
   (call $function0
    (i32.const 0)
   )
  )
  (global.set $ready40
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (global.set $global41
   (call $function0
    (i32.const 1)
   )
  )
  (global.set $ready41
   (i32.const 1)
  )
  (global.set $global42
   (struct.new_default $type9)
  )
  (global.set $ready42
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

