(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-next-suite-ports-20261013/build/strict-next-five-interim-320987e/pnpoly/same-source-chez/program.scm" "/tmp/snail-strict-next-suite-ports-20261013/build/strict-next-five-interim-320987e/pnpoly/same-source-chez/program.so"))
