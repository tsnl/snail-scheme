;;; TRIANGL -- Board game benchmark.


(define *board*
  (list->vector (list 1 1 1 1 1 0 1 1 1 1 1 1 1 1 1 1)))

(define *sequence*
  (list->vector (list 0 0 0 0 0 0 0 0 0 0 0 0 0 0)))

(define *a*
  (list->vector (list 1 2 4 3 5 6 1 3 6 2 5 4 11 12
                    13 7 8 4 4 7 11 8 12 13 6 10
                    15 9 14 13 13 14 15 9 10
                    6 6)))

(define *b*
  (list->vector (list 2 4 7 5 8 9 3 6 10 5 9 8
                    12 13 14 8 9 5 2 4 7 5 8
                    9 3 6 10 5 9 8 12 13 14
                    8 9 5 5)))

(define *c*
  (list->vector (list 4 7 11 8 12 13 6 10 15 9 14 13
                    13 14 15 9 10 6 1 2 4 3 5 6 1
                    3 6 2 5 4 11 12 13 7 8 4 4)))

(define *answer* (ref (ann '() (List (List I64)))))

(define (attempt i depth)
  (cond ((= depth 14)
         (ref-set! *answer*
               (cons (cdr (vector->list *sequence*)) (ref-get *answer*)))
         #t)
        ((and (= 1 (vector-ref *board* (vector-ref *a* i)))
              (= 1 (vector-ref *board* (vector-ref *b* i)))
              (= 0 (vector-ref *board* (vector-ref *c* i))))
         (vector-set! *board* (vector-ref *a* i) 0)
         (vector-set! *board* (vector-ref *b* i) 0)
         (vector-set! *board* (vector-ref *c* i) 1)
         (vector-set! *sequence* depth i)
         (do ((j 0 (+ j 1))
              (depth (+ depth 1) depth))
             ((or (= j 36) (attempt j depth)) #f))
         (vector-set! *board* (vector-ref *a* i) 1)
         (vector-set! *board* (vector-ref *b* i) 1)
         (vector-set! *board* (vector-ref *c* i) 0) #f)
        (else #f)))

(define (test i depth)
  (ref-set! *answer* '())
  (attempt i depth)
  (car (ref-get *answer*)))

