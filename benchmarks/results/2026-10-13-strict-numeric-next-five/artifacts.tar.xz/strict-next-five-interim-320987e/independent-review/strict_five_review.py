#!/usr/bin/env python3
"""Read-only preparation review; executes only small count-one Node probes."""

from collections import Counter
from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from types import ModuleType, SimpleNamespace

sys.dont_write_bytecode = True
LIVE = Path('/tmp/snail-strict-next-suite-ports-20261013')
PROBE = LIVE / 'build/strict-next-five-probe-b'
HERE = Path(__file__).resolve().parent
ARTIFACTS = HERE / 'artifacts'
HISTORICAL_COMMIT = '87009af'
DRIVER = LIVE / 'benchmarks/strict-suite/measure.py'
HOST = LIVE / 'benchmarks/strict-suite/host.mjs'


# ---- Frozen inputs and historical compatibility ----


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def module(text, name):
    result = ModuleType(name)
    result.__file__ = str(DRIVER)
    exec(compile(text, str(DRIVER), 'exec'), result.__dict__)
    return result


def historical_source():
    return subprocess.check_output(['git', 'show', f'{HISTORICAL_COMMIT}:benchmarks/strict-suite/measure.py'], cwd=LIVE, text=True)


def check_historical(old, current, files):
    records = []
    for name in old.NAMES:
        data, source = files[f'inputs/{name}.input'], files[f'src/{name}.scm'].decode()
        before, after = old.case_specification(name, data), current.case_specification(name, data)
        assert before == after, name
        before_source, after_source = old.strict_program(name, before, source), current.strict_program(name, after, source)
        assert before_source == after_source, name
        records.append(dict(name=name, spec_equal=True, strict_source_equal=True, strict_source_sha256=sha(after_source.encode())))
    return records


def fake_measure(driver, cases, rounds, selection):
    prepared = dict(cases=cases, tools={}, host_sha256='stub', driver_sha256='stub')
    calls = []
    driver.load = lambda _: prepared
    driver.checked_preparation = lambda _: prepared
    driver.digest = lambda _: 'stub'
    driver.save = lambda *_: None
    driver.run_case = lambda case, system, *_: (calls.append((case['name'], system)) or dict(valid=True, workload_seconds=1))
    options = SimpleNamespace(output=ARTIFACTS, cpu=5, rounds=rounds, benchmarks=selection)
    with redirect_stdout(io.StringIO()):
        driver.measure(options)
    return calls


def check_scheduling(old_text, current_text, current):
    legacy = [dict(name=name, status='ready') for name in module(old_text, 'old_names').NAMES]
    before = fake_measure(module(old_text, 'old_schedule'), legacy, 3, ['array1'])
    after = fake_measure(module(current_text, 'new_schedule'), legacy, 3, list(current.NEXT_PORTS))
    assert before == after
    next_cases = [dict(name=n, status='ready', systems=['strict', 'chez', 'chez-adapted']) for n in current.NEXT_PORTS]
    for index, case in enumerate(next_cases):
        orders = [current.round_systems(case, round_number, index) for round_number in range(3)]
        assert all({order[position] for order in orders} == set(case['systems']) for position in range(3))
    try:
        fake_measure(module(current_text, 'reject_wrong_rounds'), next_cases, 1, ['ack'])
    except ValueError as error:
        assert 'exactly three' in str(error)
    else:
        raise AssertionError('prepared three-system cases must reject one round even with unrelated CLI selection')
    assert fake_measure(module(current_text, 'allow_legacy_rounds'), legacy, 1, list(current.NEXT_PORTS))
    return dict(historical_orders_equal=True, all_three_retained_positions_balanced=True,
                prepared_three_system_guard_verified=True, historical_two_system_flexibility_verified=True)


# ---- Canonical source, adaptation, and provenance ----


def check_cases(current, files, prepared):
    records = []
    for case in prepared['cases']:
        name, directory = case['name'], PROBE / case['name']
        assert (directory / 'input.txt').read_bytes() == files[f'inputs/{name}.input']
        assert (directory / 'upstream.scm').read_bytes() == files[f'src/{name}.scm']
        assert read_json(directory / 'spec.json') == current.case_specification(name, files[f'inputs/{name}.input']) == case['spec']
        adapted, original_kernel, adapted_kernel = current.matched_chez_source(name, directory)
        assert adapted == (directory / 'same-source-chez/program.scm').read_text()
        assert original_kernel == (directory / 'original-kernel.scm').read_text()
        assert adapted_kernel == (directory / 'adapted-kernel.scm').read_text()
        assert current.strict_program(name, case['spec'], files[f'src/{name}.scm'].decode()) == (directory / 'strict.scm').read_text()
        assert current.upstream_runner().source_text(files, name, 'chez') == (directory / 'program.scm').read_text()
        mismatches = [n for n, h in case['hashes'].items() if sha((directory / n).read_bytes()) != h]
        records.append(dict(name=name, canonical_inputs=True, canonical_source=True,
                            strict_generated_source_equal=True, complete_chez_reconstructed=True,
                            exact_shared_kernel=True, probe_stale_files=mismatches))
    return records


def check_capabilities(files):
    data = read_json(LIVE / 'benchmarks/strict-suite/capabilities.json')
    for case in data['cases']:
        assert all(sha(files[name]) == h for name, h in case['files'].items())
        assert case['source_lines'] == len(files[f"src/{case['name']}.scm"].decode().splitlines())
    return dict(inspected=len(data['cases']), categories=dict(Counter(c['status'] for c in data['cases'])),
                all_source_input_hashes_equal=True, compiler_status=data['compiler_status'])


def check_provenance(prepared):
    for name, h in prepared['compiler_files'].items():
        assert sha((PROBE / 'compiler-source' / name).read_bytes()) == h
        committed = subprocess.check_output(['git', 'show', f"{prepared['compiler_commit']}:{name}"], cwd=LIVE)
        assert sha(committed) == h
    for record in prepared['tools'].values():
        assert sha(Path(record['path']).read_bytes()) == record['sha256']
    assert sha((PROBE / 'host.mjs').read_bytes()) == prepared['host_sha256'] == sha(HOST.read_bytes())
    assert sha((PROBE / 'measure.py').read_bytes()) == prepared['driver_sha256']
    return dict(compiler_source_files=len(prepared['compiler_files']), compiler_commit=prepared['compiler_commit'],
                compiler_snapshot_matches_commit=True, all_recorded_tool_hashes_equal=True,
                host_equal=True, probe_driver_current=prepared['driver_sha256'] == sha(DRIVER.read_bytes()))


def check_evidence(prepared, runner):
    records = []
    for case in prepared['cases']:
        directory = PROBE / case['name']
        strict, chez = read_json(directory / 'validation.json'), read_json(directory / 'chez-validation.json')
        assert all(r['returncode'] == 0 and not r['stderr'] for r in strict + chez)
        for record in strict:
            result, spec = json.loads(record['stdout']), record['specification']
            assert result['barriers'] == spec['barriers_per_iteration'] * spec['count']
            assert result['result'] == ('1' if spec.get('result_kind') == 'i64-list-values' else str(spec['expected']))
        assert all(runner.parse_result(r['stdout'], 'chez', case['name'])['status'] == 'ok' for r in chez)
        negatives = read_json(directory / 'validation-negative.json') if (directory / 'validation-negative.json').exists() else []
        assert all(r['returncode'] != 0 and 'AssertionError' in r['stderr'] and "actual: '0'" in r['stderr'] for r in negatives)
        records.append(dict(name=case['name'], strict_successes=len(strict), chez_successes=len(chez), list_rejections=len(negatives)))
    return records


# ---- Additional small correctness probes ----


def run_probe(prepared, name, label, spec, suffix='', rejection=False):
    path = ARTIFACTS / f'{name}-{label}{"-raw" if suffix else ""}.json'
    path.write_text(json.dumps(spec, indent=2) + '\n')
    command = [prepared['tools']['NODE']['path'], PROBE / 'host.mjs', PROBE / name / ('strict.wasm' + suffix), path, '--validate']
    result = subprocess.run(list(map(str, command)), capture_output=True, text=True, timeout=10)
    record = dict(name=name, label=label, suffix=suffix, command=list(map(str, command)), returncode=result.returncode,
                  stdout=result.stdout, stderr=result.stderr, purpose='Correctness only; elapsed fields are not performance evidence.')
    assert result.returncode != 0 and "actual: '0'" in result.stderr if rejection else result.returncode == 0 and not result.stderr
    if not rejection:
        observed = json.loads(result.stdout)
        assert observed['barriers'] == spec['barriers_per_iteration'] * spec['count']
    return record


def bounded_probes(prepared):
    specs = {case['name']: case['spec'] for case in prepared['cases']}
    primes = dict(specs['primes'], count=1)
    swapped = list(primes['expected'])
    swapped[0], swapped[1] = swapped[1], swapped[0]
    records = [run_probe(prepared, 'primes', 'ordered-original', primes)]
    records.append(run_probe(prepared, 'primes', 'swapped-order', dict(primes, expected=swapped), rejection=True))
    for suffix in ('.raw.wasm', ''):
        records.append(run_probe(prepared, 'primes', 'empty', dict(primes, inputs=[1], expected=[]), suffix))
        records.append(run_probe(prepared, 'pnpoly', 'zero-vectors', dict(specs['pnpoly'], count=1, inputs=[[0.0] * 20, [0.0] * 20], expected=0), suffix))
    return records


def main():
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    current_text, old_text = DRIVER.read_text(), historical_source()
    for source in (DRIVER, HOST, LIVE / 'benchmarks/strict-suite/capabilities.md', LIVE / 'benchmarks/strict-suite/capabilities.json'):
        shutil.copy2(source, ARTIFACTS / source.name)
    current, old = module(current_text, 'current'), module(old_text, 'historical')
    runner, prepared = current.upstream_runner(), read_json(PROBE / 'prepared.json')
    files = runner.suite_sources()
    report = dict(driver_sha256=sha(current_text.encode()), host_sha256=sha(HOST.read_bytes()), historical_base=HISTORICAL_COMMIT)
    report['historical'] = check_historical(old, current, files)
    report['scheduling'] = check_scheduling(old_text, current_text, current)
    report['cases'] = check_cases(current, files, prepared)
    report['capabilities'] = check_capabilities(files)
    report['provenance'] = check_provenance(prepared)
    report['evidence'] = check_evidence(prepared, runner)
    report['bounded_correctness_probes'] = bounded_probes(prepared)
    report['readiness'] = 'Source review passed. Exploratory probe-b has stale hashes; create a fresh final preparation before measurement.'
    (ARTIFACTS / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('bounded_correctness_probes','historical')}, indent=2))


if __name__ == '__main__':
    main()
