(module
 (rec
  (type $type11 (struct (field (mut i32)) (field (mut (ref null $type2)))))
  (type $environment7 (struct (field i64) (field (ref $type11))))
  (type $call2 (func (param (ref null $environment7) i64 i64) (result i64)))
  (type $call0 (func (param (ref null $type1) (ref null $type1)) (result (ref null $type1))))
  (type $call8 (func (param (ref $environment4) i64 i64 (ref null $type1)) (result i32)))
  (type $5 (func (param (ref $environment3) (ref null $type1) (ref null $type1) (ref null $type1)) (result i64)))
  (type $call9 (func (param (ref $environment2) i64 (ref $type1)) (result (ref null $type1))))
  (type $type9 (struct (field (ref $environment2))))
  (type $type8 (struct (field (ref $environment4))))
  (type $environment4 (struct (field (ref $type7))))
  (type $type6 (struct (field (ref $environment3))))
  (type $environment3 (struct (field (ref $type7)) (field (ref $type5))))
  (type $type7 (struct (field (mut i32)) (field (mut (ref null $type8)))))
  (type $type10 (struct (field (mut i32)) (field (mut (ref null $type9)))))
  (type $type5 (struct (field (mut i32)) (field (mut (ref null $type6)))))
  (type $type1 (struct (field i64) (field (ref null $type1))))
  (type $environment2 (struct (field (ref $type10))))
  (type $call3 (func (param i64) (result i64)))
  (type $type3 (struct))
  (type $type2 (struct (field (ref $call2)) (field (ref null $environment7))))
  (type $type0 (struct))
 )
 (type $21 (func (param i64) (result i64)))
 (type $22 (func (param i32) (result i64)))
 (type $23 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global16 (mut (ref null $type0)) (ref.null none))
 (global $ready16 (mut i32) (i32.const 0))
 (global $global25 (mut (ref null $type2)) (ref.null none))
 (global $ready25 (mut i32) (i32.const 0))
 (global $global1 (mut (ref null $type3)) (ref.null none))
 (global $ready1 (mut i32) (i32.const 0))
 (global $global19 (mut i64) (i64.const 0))
 (global $ready19 (mut i32) (i32.const 0))
 (global $global20 (mut (ref null $type3)) (ref.null none))
 (global $ready20 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call3) (param $0 i64) (result i64)
  (local $1 (ref $environment2))
  (local $2 (ref $type1))
  (local $3 (ref $type5))
  (local $4 (ref $type10))
  (local $5 (ref $type7))
  (local $6 (ref null $type1))
  (struct.set $type5 1
   (local.tee $3
    (struct.new_default $type5)
   )
   (struct.new $type6
    (struct.new $environment3
     (local.tee $5
      (struct.new_default $type7)
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type5 0
   (local.get $3)
   (i32.const 1)
  )
  (struct.set $type7 1
   (local.get $5)
   (struct.new $type8
    (struct.new $environment4
     (local.get $5)
    )
   )
  )
  (struct.set $type7 0
   (local.get $5)
   (i32.const 1)
  )
  (struct.set $type10 1
   (local.tee $4
    (struct.new_default $type10)
   )
   (struct.new $type9
    (struct.new $environment2
     (local.get $4)
    )
   )
  )
  (struct.set $type10 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type10 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type9 0
    (struct.get $type10 1
     (local.get $4)
    )
   )
  )
  (local.set $6
   (if (result (ref null $type1))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i32.eqz
       (struct.get $type10 0
        (struct.get $environment2 0
         (local.get $1)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $1
      (struct.get $type9 0
       (struct.get $type10 1
        (struct.get $environment2 0
         (local.get $1)
        )
       )
      )
     )
     (local.set $2
      (struct.new $type1
       (local.get $0)
       (ref.null none)
      )
     )
     (if (result (ref null $type1))
      (i64.eqz
       (local.tee $0
        (i64.sub
         (local.get $0)
         (i64.const 1)
        )
       )
      )
      (then
       (local.get $2)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type10 0
          (struct.get $environment2 0
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (struct.get $type9 0
         (struct.get $type10 1
          (struct.get $environment2 0
           (local.get $1)
          )
         )
        )
       )
       (local.set $2
        (struct.new $type1
         (local.get $0)
         (local.get $2)
        )
       )
       (if (result (ref null $type1))
        (i64.eqz
         (local.tee $0
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $2)
        )
        (else
         (if
          (i32.eqz
           (struct.get $type10 0
            (struct.get $environment2 0
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type9 0
           (struct.get $type10 1
            (struct.get $environment2 0
             (local.get $1)
            )
           )
          )
         )
         (local.set $2
          (struct.new $type1
           (local.get $0)
           (local.get $2)
          )
         )
         (if (result (ref null $type1))
          (i64.eqz
           (local.tee $0
            (i64.sub
             (local.get $0)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $2)
          )
          (else
           (if
            (i32.eqz
             (struct.get $type10 0
              (struct.get $environment2 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type9 0
             (struct.get $type10 1
              (struct.get $environment2 0
               (local.get $1)
              )
             )
            )
           )
           (local.set $2
            (struct.new $type1
             (local.get $0)
             (local.get $2)
            )
           )
           (if (result (ref null $type1))
            (i64.eqz
             (local.tee $0
              (i64.sub
               (local.get $0)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (if
              (i32.eqz
               (struct.get $type10 0
                (struct.get $environment2 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type9 0
               (struct.get $type10 1
                (struct.get $environment2 0
                 (local.get $1)
                )
               )
              )
             )
             (local.set $2
              (struct.new $type1
               (local.get $0)
               (local.get $2)
              )
             )
             (if (result (ref null $type1))
              (i64.eqz
               (local.tee $0
                (i64.sub
                 (local.get $0)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (if
                (i32.eqz
                 (struct.get $type10 0
                  (struct.get $environment2 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type9 0
                 (struct.get $type10 1
                  (struct.get $environment2 0
                   (local.get $1)
                  )
                 )
                )
               )
               (local.set $2
                (struct.new $type1
                 (local.get $0)
                 (local.get $2)
                )
               )
               (if (result (ref null $type1))
                (i64.eqz
                 (local.tee $0
                  (i64.sub
                   (local.get $0)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (if
                  (i32.eqz
                   (struct.get $type10 0
                    (struct.get $environment2 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type9 0
                   (struct.get $type10 1
                    (struct.get $environment2 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (local.set $2
                  (struct.new $type1
                   (local.get $0)
                   (local.get $2)
                  )
                 )
                 (if (result (ref null $type1))
                  (i64.eqz
                   (local.tee $0
                    (i64.sub
                     (local.get $0)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (if
                    (i32.eqz
                     (struct.get $type10 0
                      (struct.get $environment2 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type9 0
                     (struct.get $type10 1
                      (struct.get $environment2 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (local.set $2
                    (struct.new $type1
                     (local.get $0)
                     (local.get $2)
                    )
                   )
                   (if (result (ref null $type1))
                    (i64.eqz
                     (local.tee $0
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (if
                      (i32.eqz
                       (struct.get $type10 0
                        (struct.get $environment2 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function2
                      (struct.get $type9 0
                       (struct.get $type10 1
                        (struct.get $environment2 0
                         (local.get $1)
                        )
                       )
                      )
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                      (struct.new $type1
                       (local.get $0)
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type5 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function3
   (struct.get $type6 0
    (struct.get $type5 1
     (local.get $3)
    )
   )
   (local.get $6)
   (ref.null none)
   (ref.null none)
  )
 )
 (func $function2 (type $call9) (param $0 (ref $environment2)) (param $1 i64) (param $2 (ref $type1)) (result (ref null $type1))
  (if (result (ref $type1))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type10 0
       (struct.get $environment2 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function2
     (struct.get $type9 0
      (struct.get $type10 1
       (struct.get $environment2 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type1
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function3 (type $5) (param $0 (ref $environment3)) (param $1 (ref null $type1)) (param $2 (ref null $type1)) (param $3 (ref null $type1)) (result i64)
  (local $4 (ref null $type1))
  (local $5 (ref null $type1))
  (local $6 (ref $environment4))
  (local $7 i64)
  (local $8 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i64.extend_i32_u
     (ref.is_null
      (local.get $2)
     )
    )
   )
   (else
    (local.set $7
     (struct.get $type1 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type7 0
       (struct.get $environment3 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type8 0
      (struct.get $type7 1
       (struct.get $environment3 0
        (local.get $0)
       )
      )
     )
    )
    (local.set $7
     (if (result i64)
      (if (result i32)
       (ref.is_null
        (local.get $3)
       )
       (then
        (i32.const 1)
       )
       (else
        (if (result i32)
         (i64.eq
          (i64.add
           (local.get $7)
           (i64.const 1)
          )
          (struct.get $type1 0
           (local.get $3)
          )
         )
         (then
          (i32.const 0)
         )
         (else
          (if (result i32)
           (i64.eq
            (i64.sub
             (local.get $7)
             (i64.const 1)
            )
            (struct.get $type1 0
             (local.get $3)
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (local.set $4
             (struct.get $type1 1
              (local.get $3)
             )
            )
            (if
             (i32.eqz
              (struct.get $type7 0
               (struct.get $environment4 0
                (local.get $6)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $6
             (struct.get $type8 0
              (struct.get $type7 1
               (struct.get $environment4 0
                (local.get $6)
               )
              )
             )
            )
            (if (result i32)
             (ref.is_null
              (local.get $4)
             )
             (then
              (i32.const 1)
             )
             (else
              (if (result i32)
               (i64.eq
                (i64.add
                 (local.get $7)
                 (i64.const 2)
                )
                (struct.get $type1 0
                 (local.get $4)
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (i64.eq
                  (i64.sub
                   (local.get $7)
                   (i64.const 2)
                  )
                  (struct.get $type1 0
                   (local.get $4)
                  )
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (local.set $4
                   (struct.get $type1 1
                    (local.get $4)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type7 0
                     (struct.get $environment4 0
                      (local.get $6)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $6
                   (struct.get $type8 0
                    (struct.get $type7 1
                     (struct.get $environment4 0
                      (local.get $6)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $4)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (if (result i32)
                     (i64.eq
                      (i64.add
                       (local.get $7)
                       (i64.const 3)
                      )
                      (struct.get $type1 0
                       (local.get $4)
                      )
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if (result i32)
                       (i64.eq
                        (i64.sub
                         (local.get $7)
                         (i64.const 3)
                        )
                        (struct.get $type1 0
                         (local.get $4)
                        )
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (local.set $4
                         (struct.get $type1 1
                          (local.get $4)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type7 0
                           (struct.get $environment4 0
                            (local.get $6)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $6
                         (struct.get $type8 0
                          (struct.get $type7 1
                           (struct.get $environment4 0
                            (local.get $6)
                           )
                          )
                         )
                        )
                        (if (result i32)
                         (ref.is_null
                          (local.get $4)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (if (result i32)
                           (i64.eq
                            (i64.add
                             (local.get $7)
                             (i64.const 4)
                            )
                            (struct.get $type1 0
                             (local.get $4)
                            )
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (i64.eq
                              (i64.sub
                               (local.get $7)
                               (i64.const 4)
                              )
                              (struct.get $type1 0
                               (local.get $4)
                              )
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (local.set $4
                               (struct.get $type1 1
                                (local.get $4)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type7 0
                                 (struct.get $environment4 0
                                  (local.get $6)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $6
                               (struct.get $type8 0
                                (struct.get $type7 1
                                 (struct.get $environment4 0
                                  (local.get $6)
                                 )
                                )
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $4)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (if (result i32)
                                 (i64.eq
                                  (i64.add
                                   (local.get $7)
                                   (i64.const 5)
                                  )
                                  (struct.get $type1 0
                                   (local.get $4)
                                  )
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (if (result i32)
                                   (i64.eq
                                    (i64.sub
                                     (local.get $7)
                                     (i64.const 5)
                                    )
                                    (struct.get $type1 0
                                     (local.get $4)
                                    )
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (local.set $4
                                     (struct.get $type1 1
                                      (local.get $4)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (struct.get $type7 0
                                       (struct.get $environment4 0
                                        (local.get $6)
                                       )
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (local.set $6
                                     (struct.get $type8 0
                                      (struct.get $type7 1
                                       (struct.get $environment4 0
                                        (local.get $6)
                                       )
                                      )
                                     )
                                    )
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $4)
                                     )
                                     (then
                                      (i32.const 1)
                                     )
                                     (else
                                      (if (result i32)
                                       (i64.eq
                                        (i64.add
                                         (local.get $7)
                                         (i64.const 6)
                                        )
                                        (struct.get $type1 0
                                         (local.get $4)
                                        )
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if (result i32)
                                         (i64.eq
                                          (i64.sub
                                           (local.get $7)
                                           (i64.const 6)
                                          )
                                          (struct.get $type1 0
                                           (local.get $4)
                                          )
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (local.set $4
                                           (struct.get $type1 1
                                            (local.get $4)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (struct.get $type7 0
                                             (struct.get $environment4 0
                                              (local.get $6)
                                             )
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (local.set $6
                                           (struct.get $type8 0
                                            (struct.get $type7 1
                                             (struct.get $environment4 0
                                              (local.get $6)
                                             )
                                            )
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $4)
                                           )
                                           (then
                                            (i32.const 1)
                                           )
                                           (else
                                            (if (result i32)
                                             (i64.eq
                                              (i64.add
                                               (local.get $7)
                                               (i64.const 7)
                                              )
                                              (struct.get $type1 0
                                               (local.get $4)
                                              )
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (if (result i32)
                                               (i64.eq
                                                (i64.sub
                                                 (local.get $7)
                                                 (i64.const 7)
                                                )
                                                (struct.get $type1 0
                                                 (local.get $4)
                                                )
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (local.set $4
                                                 (struct.get $type1 1
                                                  (local.get $4)
                                                 )
                                                )
                                                (if
                                                 (i32.eqz
                                                  (struct.get $type7 0
                                                   (struct.get $environment4 0
                                                    (local.get $6)
                                                   )
                                                  )
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (local.set $6
                                                 (struct.get $type8 0
                                                  (struct.get $type7 1
                                                   (struct.get $environment4 0
                                                    (local.get $6)
                                                   )
                                                  )
                                                 )
                                                )
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $4)
                                                 )
                                                 (then
                                                  (i32.const 1)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i64.eq
                                                    (i64.add
                                                     (local.get $7)
                                                     (i64.const 8)
                                                    )
                                                    (struct.get $type1 0
                                                     (local.get $4)
                                                    )
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (i64.eq
                                                      (i64.sub
                                                       (local.get $7)
                                                       (i64.const 8)
                                                      )
                                                      (struct.get $type1 0
                                                       (local.get $4)
                                                      )
                                                     )
                                                     (then
                                                      (i32.const 0)
                                                     )
                                                     (else
                                                      (local.set $4
                                                       (struct.get $type1 1
                                                        (local.get $4)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (struct.get $type7 0
                                                         (struct.get $environment4 0
                                                          (local.get $6)
                                                         )
                                                        )
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (local.set $6
                                                       (struct.get $type8 0
                                                        (struct.get $type7 1
                                                         (struct.get $environment4 0
                                                          (local.get $6)
                                                         )
                                                        )
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $4)
                                                       )
                                                       (then
                                                        (i32.const 1)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i64.eq
                                                          (i64.add
                                                           (local.get $7)
                                                           (i64.const 9)
                                                          )
                                                          (struct.get $type1 0
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (then
                                                          (i32.const 0)
                                                         )
                                                         (else
                                                          (if (result i32)
                                                           (i64.eq
                                                            (i64.sub
                                                             (local.get $7)
                                                             (i64.const 9)
                                                            )
                                                            (struct.get $type1 0
                                                             (local.get $4)
                                                            )
                                                           )
                                                           (then
                                                            (i32.const 0)
                                                           )
                                                           (else
                                                            (local.set $4
                                                             (struct.get $type1 1
                                                              (local.get $4)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (struct.get $type7 0
                                                               (struct.get $environment4 0
                                                                (local.get $6)
                                                               )
                                                              )
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (local.set $6
                                                             (struct.get $type8 0
                                                              (struct.get $type7 1
                                                               (struct.get $environment4 0
                                                                (local.get $6)
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $4)
                                                             )
                                                             (then
                                                              (i32.const 1)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i64.eq
                                                                (i64.add
                                                                 (local.get $7)
                                                                 (i64.const 10)
                                                                )
                                                                (struct.get $type1 0
                                                                 (local.get $4)
                                                                )
                                                               )
                                                               (then
                                                                (i32.const 0)
                                                               )
                                                               (else
                                                                (if (result i32)
                                                                 (i64.eq
                                                                  (i64.sub
                                                                   (local.get $7)
                                                                   (i64.const 10)
                                                                  )
                                                                  (struct.get $type1 0
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                 (then
                                                                  (i32.const 0)
                                                                 )
                                                                 (else
                                                                  (local.set $4
                                                                   (struct.get $type1 1
                                                                    (local.get $4)
                                                                   )
                                                                  )
                                                                  (if
                                                                   (i32.eqz
                                                                    (struct.get $type7 0
                                                                     (struct.get $environment4 0
                                                                      (local.get $6)
                                                                     )
                                                                    )
                                                                   )
                                                                   (then
                                                                    (unreachable)
                                                                   )
                                                                  )
                                                                  (call $function4
                                                                   (struct.get $type8 0
                                                                    (struct.get $type7 1
                                                                     (struct.get $environment4 0
                                                                      (local.get $6)
                                                                     )
                                                                    )
                                                                   )
                                                                   (local.get $7)
                                                                   (i64.const 11)
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (then
       (local.set $4
        (struct.get $type1 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready16)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global16)
        )
       )
       (local.set $5
        (if (result (ref null $type1))
         (ref.is_null
          (local.get $4)
         )
         (then
          (local.get $2)
         )
         (else
          (struct.new $type1
           (struct.get $type1 0
            (local.get $4)
           )
           (block (result (ref null $type1))
            (local.set $4
             (struct.get $type1 1
              (local.get $4)
             )
            )
            (if
             (i32.eqz
              (global.get $ready16)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global16)
             )
            )
            (if (result (ref null $type1))
             (ref.is_null
              (local.get $4)
             )
             (then
              (local.get $2)
             )
             (else
              (struct.new $type1
               (struct.get $type1 0
                (local.get $4)
               )
               (block (result (ref null $type1))
                (local.set $4
                 (struct.get $type1 1
                  (local.get $4)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready16)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global16)
                 )
                )
                (if (result (ref null $type1))
                 (ref.is_null
                  (local.get $4)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (struct.new $type1
                   (struct.get $type1 0
                    (local.get $4)
                   )
                   (block (result (ref null $type1))
                    (local.set $4
                     (struct.get $type1 1
                      (local.get $4)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready16)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global16)
                     )
                    )
                    (if (result (ref null $type1))
                     (ref.is_null
                      (local.get $4)
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (struct.new $type1
                       (struct.get $type1 0
                        (local.get $4)
                       )
                       (block (result (ref null $type1))
                        (local.set $4
                         (struct.get $type1 1
                          (local.get $4)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready16)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global16)
                         )
                        )
                        (if (result (ref null $type1))
                         (ref.is_null
                          (local.get $4)
                         )
                         (then
                          (local.get $2)
                         )
                         (else
                          (struct.new $type1
                           (struct.get $type1 0
                            (local.get $4)
                           )
                           (block (result (ref null $type1))
                            (local.set $4
                             (struct.get $type1 1
                              (local.get $4)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready16)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global16)
                             )
                            )
                            (if (result (ref null $type1))
                             (ref.is_null
                              (local.get $4)
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (struct.new $type1
                               (struct.get $type1 0
                                (local.get $4)
                               )
                               (block (result (ref null $type1))
                                (local.set $4
                                 (struct.get $type1 1
                                  (local.get $4)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready16)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global16)
                                 )
                                )
                                (if (result (ref null $type1))
                                 (ref.is_null
                                  (local.get $4)
                                 )
                                 (then
                                  (local.get $2)
                                 )
                                 (else
                                  (struct.new $type1
                                   (struct.get $type1 0
                                    (local.get $4)
                                   )
                                   (block (result (ref null $type1))
                                    (local.set $4
                                     (struct.get $type1 1
                                      (local.get $4)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global16)
                                     )
                                    )
                                    (if (result (ref null $type1))
                                     (ref.is_null
                                      (local.get $4)
                                     )
                                     (then
                                      (local.get $2)
                                     )
                                     (else
                                      (struct.new $type1
                                       (struct.get $type1 0
                                        (local.get $4)
                                       )
                                       (block (result (ref null $type1))
                                        (local.set $4
                                         (struct.get $type1 1
                                          (local.get $4)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready16)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global16)
                                         )
                                        )
                                        (if (result (ref null $type1))
                                         (ref.is_null
                                          (local.get $4)
                                         )
                                         (then
                                          (local.get $2)
                                         )
                                         (else
                                          (struct.new $type1
                                           (struct.get $type1 0
                                            (local.get $4)
                                           )
                                           (block (result (ref null $type1))
                                            (local.set $4
                                             (struct.get $type1 1
                                              (local.get $4)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready16)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global16)
                                             )
                                            )
                                            (if (result (ref null $type1))
                                             (ref.is_null
                                              (local.get $4)
                                             )
                                             (then
                                              (local.get $2)
                                             )
                                             (else
                                              (struct.new $type1
                                               (struct.get $type1 0
                                                (local.get $4)
                                               )
                                               (call $function5
                                                (struct.get $type1 1
                                                 (local.get $4)
                                                )
                                                (block (result (ref null $type1))
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready16)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global16)
                                                  )
                                                 )
                                                 (local.get $2)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (local.set $7
        (struct.get $type1 0
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type5 0
          (struct.get $environment3 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function3
        (struct.get $type6 0
         (struct.get $type5 1
          (struct.get $environment3 1
           (local.get $0)
          )
         )
        )
        (local.get $5)
        (ref.null none)
        (struct.new $type1
         (local.get $7)
         (local.get $3)
        )
       )
      )
      (else
       (i64.const 0)
      )
     )
    )
    (local.set $4
     (struct.get $type1 1
      (local.get $1)
     )
    )
    (local.set $8
     (struct.get $type1 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type5 0
       (struct.get $environment3 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (call $function3
      (struct.get $type6 0
       (struct.get $type5 1
        (struct.get $environment3 1
         (local.get $0)
        )
       )
      )
      (local.get $4)
      (struct.new $type1
       (local.get $8)
       (local.get $2)
      )
      (local.get $3)
     )
     (local.get $7)
    )
   )
  )
 )
 (func $function4 (type $call8) (param $0 (ref $environment4)) (param $1 i64) (param $2 i64) (param $3 (ref null $type1)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $3)
   )
   (then
    (i32.const 1)
   )
   (else
    (if (result i32)
     (i64.eq
      (i64.add
       (local.get $1)
       (local.get $2)
      )
      (struct.get $type1 0
       (local.get $3)
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (i64.sub
         (local.get $1)
         (local.get $2)
        )
        (struct.get $type1 0
         (local.get $3)
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (local.set $3
         (struct.get $type1 1
          (local.get $3)
         )
        )
        (if
         (i32.eqz
          (struct.get $type7 0
           (struct.get $environment4 0
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function4
         (struct.get $type8 0
          (struct.get $type7 1
           (struct.get $environment4 0
            (local.get $0)
           )
          )
         )
         (local.get $1)
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
         (local.get $3)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function5 (type $call0) (param $0 (ref null $type1)) (param $1 (ref null $type1)) (result (ref null $type1))
  (local $2 i64)
  (if (result (ref null $type1))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (struct.new $type1
     (struct.get $type1 0
      (local.get $0)
     )
     (call $function5
      (struct.get $type1 1
       (local.get $0)
      )
      (block (result (ref null $type1))
       (if
        (i32.eqz
         (global.get $ready16)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global16)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function7 (type $call2) (param $0 (ref null $environment7)) (param $1 i64) (param $2 i64) (result i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment7 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready19)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready25)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type2 1
      (global.get $global25)
     )
    )
    (local.set $2
     (call $function0
      (block (result i64)
       (local.set $scratch
        (call $foreign0
         (global.get $global19)
        )
       )
       (if
        (i32.eqz
         (global.get $ready1)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type11 0
       (struct.get $environment7 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function7
     (struct.get $type2 1
      (struct.get $type11 1
       (struct.get $environment7 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function8 (type $call2) (param $0 (ref null $environment7)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type11))
  (local $2 (ref $type2))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready20)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global20)
   )
  )
  (struct.set $type11 1
   (local.tee $1
    (struct.new_default $type11)
   )
   (struct.new $type2
    (ref.func $function7)
    (struct.new $environment7
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type11 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type11 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call2
   (struct.get $type2 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type11 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type2 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global16
   (struct.new_default $type0)
  )
  (global.set $ready16
   (i32.const 1)
  )
  (global.set $global25
   (struct.new $type2
    (ref.func $function8)
    (ref.null none)
   )
  )
  (global.set $ready25
   (i32.const 1)
  )
  (global.set $global1
   (struct.new_default $type3)
  )
  (global.set $ready1
   (i32.const 1)
  )
  (global.set $global19
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready19
   (i32.const 1)
  )
  (global.set $global20
   (struct.new_default $type3)
  )
  (global.set $ready20
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

