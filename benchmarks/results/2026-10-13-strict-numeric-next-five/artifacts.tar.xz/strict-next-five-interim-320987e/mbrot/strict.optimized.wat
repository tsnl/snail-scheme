(module
 (rec
  (type $type13 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment8 (struct (field i64) (field (ref $type13))))
  (type $call0 (func (param (ref null $environment8) i64 i64) (result i64)))
  (type $type12 (struct (field (ref $type3))))
  (type $environment6 (struct (field (ref $type12)) (field i64) (field (ref $type11))))
  (type $type3 (array (mut (ref $type4))))
  (type $type4 (array (mut i64)))
  (type $environment4 (struct (field (ref $type3)) (field i64) (field (ref $type11)) (field (ref $type11))))
  (type $type10 (struct (field (ref $call10)) (field (ref struct))))
  (type $environment3 (struct (field (ref $type3)) (field (ref $type11)) (field i64)))
  (type $type11 (struct (field (mut i32)) (field (mut (ref null $type10)))))
  (type $call10 (func (param (ref struct) i64) (result i32)))
  (type $type8 (struct (field (ref $environment1))))
  (type $type9 (struct (field (mut i32)) (field (mut (ref null $type8)))))
  (type $type7 (struct (field f64)))
  (type $environment1 (struct (field (ref $type7)) (field (ref $type7)) (field (ref $type7)) (field (ref $type9))))
  (type $call8 (func (param (ref $environment1) f64 f64 i64) (result i64)))
  (type $type5 (struct))
  (type $type2 (struct))
  (type $type1 (struct))
  (type $type0 (struct (field (ref $call0)) (field (ref null $environment8))))
 )
 (type $21 (func (param i64) (result i64)))
 (type $22 (func (param i32) (result i64)))
 (type $23 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global39 (mut (ref null $type0)) (ref.null none))
 (global $ready39 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type1)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global18 (mut (ref null $type2)) (ref.null none))
 (global $ready18 (mut i32) (i32.const 0))
 (global $global28 (mut (ref null $type5)) (ref.null none))
 (global $ready28 (mut i32) (i32.const 0))
 (global $global33 (mut i64) (i64.const 0))
 (global $ready33 (mut i32) (i32.const 0))
 (global $global34 (mut (ref null $type5)) (ref.null none))
 (global $ready34 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function1 (type $call8) (param $0 (ref $environment1)) (param $1 f64) (param $2 f64) (param $3 i64) (result i64)
  (local $4 f64)
  (local $5 f64)
  (if (result i64)
   (i64.eq
    (local.get $3)
    (i64.const 64)
   )
   (then
    (local.get $3)
   )
   (else
    (if (result i64)
     (f64.gt
      (f64.add
       (local.tee $4
        (f64.mul
         (local.get $1)
         (local.get $1)
        )
       )
       (local.tee $5
        (f64.mul
         (local.get $2)
         (local.get $2)
        )
       )
      )
      (struct.get $type7 0
       (struct.get $environment1 0
        (local.get $0)
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (if
       (i32.eqz
        (struct.get $type9 0
         (struct.get $environment1 3
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function1
       (struct.get $type8 0
        (struct.get $type9 1
         (struct.get $environment1 3
          (local.get $0)
         )
        )
       )
       (f64.add
        (f64.sub
         (local.get $4)
         (local.get $5)
        )
        (struct.get $type7 0
         (struct.get $environment1 1
          (local.get $0)
         )
        )
       )
       (f64.add
        (f64.mul
         (f64.mul
          (local.get $1)
          (local.get $2)
         )
         (f64.const 2)
        )
        (struct.get $type7 0
         (struct.get $environment1 2
          (local.get $0)
         )
        )
       )
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function3 (type $call10) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type11))
  (local $3 (ref $environment3))
  (local $4 (ref $type10))
  (local $5 i64)
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.set $5
     (struct.get $environment3 2
      (local.tee $3
       (ref.cast (ref $environment3)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type11 1
     (local.tee $2
      (struct.new_default $type11)
     )
     (struct.new $type10
      (ref.func $function4)
      (struct.new $environment4
       (struct.get $environment3 0
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
       (struct.get $environment3 1
        (local.get $3)
       )
      )
     )
    )
    (struct.set $type11 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type11 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call10
      (struct.get $type10 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type11 1
          (local.get $2)
         )
        )
       )
      )
      (i64.sub
       (local.get $5)
       (i64.const 1)
      )
      (struct.get $type10 0
       (local.get $4)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function4 (type $call10) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment4))
  (local $3 (ref $type9))
  (local $4 (ref $type4))
  (local $5 (ref $type7))
  (local $6 (ref $type7))
  (local $7 i64)
  (local $8 i64)
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type4
     (array.get $type3
      (struct.get $environment4 0
       (local.tee $2
        (ref.cast (ref $environment4)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global0)
       )
      )
      (struct.set $type9 1
       (local.tee $3
        (struct.new_default $type9)
       )
       (struct.new $type8
        (struct.new $environment1
         (struct.new $type7
          (f64.const 16)
         )
         (local.tee $5
          (struct.new $type7
           (f64.add
            (f64.mul
             (f64.convert_i64_s
              (local.get $1)
             )
             (f64.const 0.005)
            )
            (f64.const -1)
           )
          )
         )
         (local.tee $6
          (struct.new $type7
           (f64.add
            (f64.mul
             (f64.convert_i64_s
              (struct.get $environment4 1
               (local.get $2)
              )
             )
             (f64.const 0.005)
            )
            (f64.const -0.5)
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type9 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type9 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (call $function1
        (struct.get $type8 0
         (struct.get $type9 1
          (local.get $3)
         )
        )
        (struct.get $type7 0
         (local.get $5)
        )
        (struct.get $type7 0
         (local.get $6)
        )
        (i64.const 0)
       )
      )
      (if
       (i64.gt_u
        (local.tee $8
         (struct.get $environment4 1
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $8)
      )
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (struct.get $type11 0
       (struct.get $environment4 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function4
     (struct.get $type10 1
      (struct.get $type11 1
       (struct.get $environment4 2
        (local.get $2)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (local.set $1
     (struct.get $environment4 1
      (local.tee $2
       (ref.cast (ref $environment4)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type11 0
       (struct.get $environment4 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function3
     (struct.get $type10 1
      (struct.get $type11 1
       (struct.get $environment4 3
        (local.get $2)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function6 (type $call10) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment6))
  (local $3 (ref $type3))
  (local $4 i64)
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (array.set $type3
     (struct.get $type12 0
      (struct.get $environment6 0
       (local.tee $2
        (ref.cast (ref $environment6)
         (local.get $0)
        )
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment6 1
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (array.new_default $type4
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type11 0
       (struct.get $environment6 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function6
      (struct.get $type10 1
       (struct.get $type11 1
        (struct.get $environment6 2
         (local.get $2)
        )
       )
      )
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function8 (type $call0) (param $0 (ref null $environment8)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type11))
  (local $4 (ref $type10))
  (local $5 (ref $type12))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment8 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready33)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready39)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global39)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global33)
     )
    )
    (if
     (i32.eqz
      (global.get $ready28)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global28)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type11 1
     (local.tee $3
      (struct.new_default $type11)
     )
     (struct.new $type10
      (ref.func $function6)
      (struct.new $environment6
       (local.tee $5
        (struct.new $type12
         (array.new $type3
          (array.new_fixed $type4 0)
          (i32.wrap_i64
           (local.get $2)
          )
         )
        )
       )
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (struct.set $type11 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type11 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call10
      (struct.get $type10 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type11 1
          (local.get $3)
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
      (struct.get $type10 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready18)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global18)
     )
    )
    (struct.set $type11 1
     (local.tee $3
      (struct.new_default $type11)
     )
     (struct.new $type10
      (ref.func $function3)
      (struct.new $environment3
       (struct.get $type12 0
        (local.get $5)
       )
       (local.get $3)
       (local.get $2)
      )
     )
    )
    (struct.set $type11 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type11 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call10
      (struct.get $type10 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type11 1
          (local.get $3)
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
      (struct.get $type10 0
       (local.get $4)
      )
     )
    )
    (local.set $2
     (array.get $type4
      (array.get $type3
       (struct.get $type12 0
        (local.get $5)
       )
       (i32.const 0)
      )
      (i32.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type13 0
       (struct.get $environment8 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function8
     (struct.get $type0 1
      (struct.get $type13 1
       (struct.get $environment8 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function9 (type $call0) (param $0 (ref null $environment8)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type13))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready34)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global34)
   )
  )
  (struct.set $type13 1
   (local.tee $1
    (struct.new_default $type13)
   )
   (struct.new $type0
    (ref.func $function8)
    (struct.new $environment8
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type13 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type13 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type13 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global39
   (struct.new $type0
    (ref.func $function9)
    (ref.null none)
   )
  )
  (global.set $ready39
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type1)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global18
   (struct.new_default $type2)
  )
  (global.set $ready18
   (i32.const 1)
  )
  (global.set $global28
   (struct.new_default $type5)
  )
  (global.set $ready28
   (i32.const 1)
  )
  (global.set $global33
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready33
   (i32.const 1)
  )
  (global.set $global34
   (struct.new_default $type5)
  )
  (global.set $ready34
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

