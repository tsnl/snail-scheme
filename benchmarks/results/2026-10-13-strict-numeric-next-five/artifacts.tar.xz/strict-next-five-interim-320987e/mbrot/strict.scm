(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define (list . elements) elements)
(define (append xs ys)
  (if (null? xs) ys (cons (car xs) (append (cdr xs) ys))))
(define (hide count x) (hide-i64 x))
;;; MBROT -- Generation of Mandelbrot set fractal.


(define (count r i step x y)

  (let ((max-count 64)
        (radius^2  16.0))

    (let ((cr (+ r (* (i64->f64 x) step)))
          (ci (+ i (* (i64->f64 y) step))))

      (let loop ((zr cr)
                 (zi ci)
                 (c 0))
        (if (= c max-count)
            c
            (let ((zr^2 (* zr zr))
                  (zi^2 (* zi zi)))
              (if (> (+ zr^2 zi^2) radius^2)
                  c
                  (let ((new-zr (+ (- zr^2 zi^2) cr))
                        (new-zi (+ (* 2.0 (* zr zi)) ci)))
                    (loop new-zr new-zi (+ c 1))))))))))

(define (mbrot matrix r i step n)
  (let loop1 ((y (- n 1)))
    (when (>= y 0)
      (let loop2 ((x (- n 1)))
        (if (>= x 0)
            (begin
              (vector-set! (vector-ref matrix x) y (count r i step x y))
              (loop2 (- x 1)))
            (loop1 (- y 1)))))))

(define (test n)
  (let ((matrix (make-vector n (empty-vector))))
    (let loop ((i (- n 1)))
      (when (>= i 0)
        (vector-set! matrix i (make-vector n 0))
        (loop (- i 1))))
    (mbrot matrix -1.0 -0.5 0.005 n)
    (vector-ref (vector-ref matrix 0) 0)))

(define input0 (native-input-i64 (ann 0 I32)))
(: bench (-> I64 I64))
(define (bench count) (let loop ((i 0) (result 0))
    (if (< i count) (loop (+ i 1) (test (hide count input0))) result)))
(unit)
