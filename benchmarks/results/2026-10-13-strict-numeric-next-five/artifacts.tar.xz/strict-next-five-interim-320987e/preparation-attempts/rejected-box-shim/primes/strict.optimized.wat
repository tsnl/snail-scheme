(module
 (rec
  (type $environment8 (struct (field i64) (field (ref $type9))))
  (type $call7 (func (param i64) (result i64)))
  (type $2 (func (param i64) (result (ref null $type1))))
  (type $environment5 (struct (field (ref $type9))))
  (type $call5 (func (param (ref null $type1)) (result (ref null $type1))))
  (type $call4 (func (param i64 i64) (result (ref null $type1))))
  (type $call2 (func (param (ref null $type1) (ref null $type1)) (result i32)))
  (type $type8 (struct (field (ref $call8)) (field (ref struct))))
  (type $type9 (struct (field (mut i32)) (field (mut (ref null $type8)))))
  (type $environment1 (struct (field (ref $type9))))
  (type $call8 (func (param (ref struct) i64 (ref null $type1)) (result (ref null $type1))))
  (type $type7 (struct))
  (type $type1 (struct (field i64) (field (ref null $type1))))
  (type $type6 (struct))
  (type $type5 (struct))
  (type $type4 (struct))
  (type $type3 (struct))
  (type $type2 (struct))
  (type $type0 (struct))
 )
 (type $19 (func (param i64) (result i64)))
 (type $20 (func (result i64)))
 (type $21 (func (param i32) (result i64)))
 (type $22 (func))
 (import "benchmark" "expected_length" (func $foreign0 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign2 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign3 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global4 (mut (ref null $type2)) (ref.null none))
 (global $ready4 (mut i32) (i32.const 0))
 (global $global24 (mut (ref null $type3)) (ref.null none))
 (global $ready24 (mut i32) (i32.const 0))
 (global $global7 (mut (ref null $type4)) (ref.null none))
 (global $ready7 (mut i32) (i32.const 0))
 (global $global10 (mut (ref null $type5)) (ref.null none))
 (global $ready10 (mut i32) (i32.const 0))
 (global $global15 (mut (ref null $type6)) (ref.null none))
 (global $ready15 (mut i32) (i32.const 0))
 (global $global17 (mut i64) (i64.const 0))
 (global $ready17 (mut i32) (i32.const 0))
 (global $global18 (mut (ref null $type1)) (ref.null none))
 (global $ready18 (mut i32) (i32.const 0))
 (global $global19 (mut (ref null $type7)) (ref.null none))
 (global $ready19 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function1 (type $call8) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 i64)
  (if (result (ref null $type1))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type9 0
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function1
     (struct.get $type8 1
      (struct.get $type9 1
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type1
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function2 (type $call2) (param $0 (ref null $type1)) (param $1 (ref null $type1)) (result i32)
  (local $scratch (ref null $type1))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type1 0
         (local.get $0)
        )
        (struct.get $type1 0
         (local.get $1)
        )
       )
       (then
        (return_call $function2
         (struct.get $type1 1
          (local.get $0)
         )
         (block (result (ref null $type1))
          (local.set $scratch
           (struct.get $type1 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready4)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global4)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function3 (type $call4) (param $0 i64) (param $1 i64) (result (ref null $type1))
  (if (result (ref null $type1))
   (i64.gt_s
    (local.get $0)
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready7)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global7)
     )
    )
    (struct.new $type1
     (local.get $0)
     (call $function3
      (i64.add
       (local.get $0)
       (i64.const 1)
      )
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function4 (type $call5) (param $0 (ref null $type1)) (result (ref null $type1))
  (local $1 (ref $type9))
  (local $2 i64)
  (struct.set $type9 1
   (local.tee $1
    (struct.new_default $type9)
   )
   (struct.new $type8
    (ref.func $function5)
    (struct.new $environment5
     (local.get $1)
    )
   )
  )
  (struct.set $type9 0
   (local.get $1)
   (i32.const 1)
  )
  (if (result (ref null $type1))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $2
     (struct.get $type1 0
      (local.get $0)
     )
    )
    (local.set $0
     (struct.get $type1 1
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type9 0
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $0
     (call $function5
      (struct.get $type8 1
       (struct.get $type9 1
        (local.get $1)
       )
      )
      (local.get $2)
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready10)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global10)
     )
    )
    (struct.new $type1
     (local.get $2)
     (call $function4
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function5 (type $call8) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 i64)
  (if (result (ref null $type1))
   (ref.is_null
    (local.get $2)
   )
   (then
    (ref.null none)
   )
   (else
    (if (result (ref $type1))
     (i64.eqz
      (i64.rem_s
       (struct.get $type1 0
        (local.get $2)
       )
       (local.get $1)
      )
     )
     (then
      (local.set $2
       (struct.get $type1 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type9 0
         (struct.get $environment5 0
          (ref.cast (ref $environment5)
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function5
       (struct.get $type8 1
        (struct.get $type9 1
         (struct.get $environment5 0
          (ref.cast (ref $environment5)
           (local.get $0)
          )
         )
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
     (else
      (struct.new $type1
       (struct.get $type1 0
        (local.get $2)
       )
       (block (result (ref null $type1))
        (local.set $2
         (struct.get $type1 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (struct.get $type9 0
           (struct.get $environment5 0
            (ref.cast (ref $environment5)
             (local.get $0)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (call $function5
         (struct.get $type8 1
          (struct.get $type9 1
           (struct.get $environment5 0
            (ref.cast (ref $environment5)
             (local.get $0)
            )
           )
          )
         )
         (local.get $1)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function6 (type $2) (param $0 i64) (result (ref null $type1))
  (local $1 (ref null $type1))
  (local $scratch (ref null $type1))
  (if
   (i32.eqz
    (global.get $ready7)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global7)
   )
  )
  (return_call $function4
   (block (result (ref null $type1))
    (local.set $scratch
     (if (result (ref null $type1))
      (i64.lt_s
       (local.get $0)
       (i64.const 2)
      )
      (then
       (ref.null none)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready7)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global7)
        )
       )
       (struct.new $type1
        (i64.const 2)
        (if (result (ref null $type1))
         (i64.lt_s
          (local.get $0)
          (i64.const 3)
         )
         (then
          (ref.null none)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready7)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global7)
           )
          )
          (struct.new $type1
           (i64.const 3)
           (if (result (ref null $type1))
            (i64.lt_s
             (local.get $0)
             (i64.const 4)
            )
            (then
             (ref.null none)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready7)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global7)
              )
             )
             (struct.new $type1
              (i64.const 4)
              (if (result (ref null $type1))
               (i64.lt_s
                (local.get $0)
                (i64.const 5)
               )
               (then
                (ref.null none)
               )
               (else
                (if
                 (i32.eqz
                  (global.get $ready7)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global7)
                 )
                )
                (struct.new $type1
                 (i64.const 5)
                 (if (result (ref null $type1))
                  (i64.lt_s
                   (local.get $0)
                   (i64.const 6)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready7)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global7)
                    )
                   )
                   (struct.new $type1
                    (i64.const 6)
                    (if (result (ref null $type1))
                     (i64.lt_s
                      (local.get $0)
                      (i64.const 7)
                     )
                     (then
                      (ref.null none)
                     )
                     (else
                      (if
                       (i32.eqz
                        (global.get $ready7)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global7)
                       )
                      )
                      (struct.new $type1
                       (i64.const 7)
                       (if (result (ref null $type1))
                        (i64.lt_s
                         (local.get $0)
                         (i64.const 8)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready7)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global7)
                          )
                         )
                         (struct.new $type1
                          (i64.const 8)
                          (if (result (ref null $type1))
                           (i64.lt_s
                            (local.get $0)
                            (i64.const 9)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (if
                             (i32.eqz
                              (global.get $ready7)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global7)
                             )
                            )
                            (struct.new $type1
                             (i64.const 9)
                             (if (result (ref null $type1))
                              (i64.lt_s
                               (local.get $0)
                               (i64.const 10)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (if
                                (i32.eqz
                                 (global.get $ready7)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global7)
                                )
                               )
                               (struct.new $type1
                                (i64.const 10)
                                (if (result (ref null $type1))
                                 (i64.lt_s
                                  (local.get $0)
                                  (i64.const 11)
                                 )
                                 (then
                                  (ref.null none)
                                 )
                                 (else
                                  (if
                                   (i32.eqz
                                    (global.get $ready7)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global7)
                                   )
                                  )
                                  (struct.new $type1
                                   (i64.const 11)
                                   (call $function3
                                    (i64.const 12)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready10)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global10)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function7 (type $call7) (param $0 i64) (result i64)
  (local $1 (ref null $type1))
  (local $2 (ref null $type1))
  (local $3 (ref $type9))
  (local $4 (ref $type8))
  (local $scratch (ref null $type1))
  (struct.set $type9 1
   (local.tee $3
    (struct.new_default $type9)
   )
   (struct.new $type8
    (ref.func $function8)
    (struct.new $environment8
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type9 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type9 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call8
    (struct.get $type8 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type9 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type8 0
     (local.get $4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready18)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global4)
   )
  )
  (local.set $1
   (global.get $global18)
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (ref.is_null
       (local.get $1)
      )
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i64.eq
          (struct.get $type1 0
           (local.get $2)
          )
          (struct.get $type1 0
           (local.get $1)
          )
         )
         (then
          (local.set $2
           (struct.get $type1 1
            (local.get $2)
           )
          )
          (local.set $1
           (struct.get $type1 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready4)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global4)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (ref.is_null
             (local.get $1)
            )
           )
           (else
            (if (result i32)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i64.eq
                (struct.get $type1 0
                 (local.get $2)
                )
                (struct.get $type1 0
                 (local.get $1)
                )
               )
               (then
                (local.set $2
                 (struct.get $type1 1
                  (local.get $2)
                 )
                )
                (local.set $1
                 (struct.get $type1 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready4)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global4)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (ref.is_null
                   (local.get $1)
                  )
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (i64.eq
                      (struct.get $type1 0
                       (local.get $2)
                      )
                      (struct.get $type1 0
                       (local.get $1)
                      )
                     )
                     (then
                      (local.set $2
                       (struct.get $type1 1
                        (local.get $2)
                       )
                      )
                      (local.set $1
                       (struct.get $type1 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready4)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global4)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (ref.is_null
                         (local.get $1)
                        )
                       )
                       (else
                        (if (result i32)
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i64.eq
                            (struct.get $type1 0
                             (local.get $2)
                            )
                            (struct.get $type1 0
                             (local.get $1)
                            )
                           )
                           (then
                            (local.set $2
                             (struct.get $type1 1
                              (local.get $2)
                             )
                            )
                            (local.set $1
                             (struct.get $type1 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready4)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global4)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (ref.is_null
                               (local.get $1)
                              )
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (i64.eq
                                  (struct.get $type1 0
                                   (local.get $2)
                                  )
                                  (struct.get $type1 0
                                   (local.get $1)
                                  )
                                 )
                                 (then
                                  (local.set $2
                                   (struct.get $type1 1
                                    (local.get $2)
                                   )
                                  )
                                  (local.set $1
                                   (struct.get $type1 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready4)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global4)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                   )
                                   (else
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $1)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if (result i32)
                                       (i64.eq
                                        (struct.get $type1 0
                                         (local.get $2)
                                        )
                                        (struct.get $type1 0
                                         (local.get $1)
                                        )
                                       )
                                       (then
                                        (local.set $2
                                         (struct.get $type1 1
                                          (local.get $2)
                                         )
                                        )
                                        (local.set $1
                                         (struct.get $type1 1
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready4)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global4)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                         )
                                         (else
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (i64.eq
                                              (struct.get $type1 0
                                               (local.get $2)
                                              )
                                              (struct.get $type1 0
                                               (local.get $1)
                                              )
                                             )
                                             (then
                                              (local.set $2
                                               (struct.get $type1 1
                                                (local.get $2)
                                               )
                                              )
                                              (local.set $1
                                               (struct.get $type1 1
                                                (local.get $1)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready4)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global4)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (ref.is_null
                                                 (local.get $1)
                                                )
                                               )
                                               (else
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $1)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i64.eq
                                                    (struct.get $type1 0
                                                     (local.get $2)
                                                    )
                                                    (struct.get $type1 0
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (then
                                                    (local.set $2
                                                     (struct.get $type1 1
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (local.set $1
                                                     (struct.get $type1 1
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready4)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global4)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                     (then
                                                      (ref.is_null
                                                       (local.get $1)
                                                      )
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $1)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i64.eq
                                                          (struct.get $type1 0
                                                           (local.get $2)
                                                          )
                                                          (struct.get $type1 0
                                                           (local.get $1)
                                                          )
                                                         )
                                                         (then
                                                          (local.set $2
                                                           (struct.get $type1 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (local.set $1
                                                           (struct.get $type1 1
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready4)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global4)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (ref.is_null
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $1)
                                                             )
                                                             (then
                                                              (i32.const 0)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i64.eq
                                                                (struct.get $type1 0
                                                                 (local.get $2)
                                                                )
                                                                (struct.get $type1 0
                                                                 (local.get $1)
                                                                )
                                                               )
                                                               (then
                                                                (call $function2
                                                                 (struct.get $type1 1
                                                                  (local.get $2)
                                                                 )
                                                                 (block (result (ref null $type1))
                                                                  (local.set $scratch
                                                                   (struct.get $type1 1
                                                                    (local.get $1)
                                                                   )
                                                                  )
                                                                  (if
                                                                   (i32.eqz
                                                                    (global.get $ready4)
                                                                   )
                                                                   (then
                                                                    (unreachable)
                                                                   )
                                                                  )
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global4)
                                                                   )
                                                                  )
                                                                  (local.get $scratch)
                                                                 )
                                                                )
                                                               )
                                                               (else
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (else
                                                          (i32.const 0)
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (i32.const 0)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (i32.const 0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function8 (type $call8) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 (ref $environment8))
  (local $4 (ref null $type1))
  (local $5 i64)
  (local $scratch i64)
  (if (result (ref null $type1))
   (i64.gt_s
    (struct.get $environment8 0
     (local.tee $3
      (ref.cast (ref $environment8)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready17)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready24)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global24)
     )
    )
    (local.set $4
     (call $function6
      (block (result i64)
       (local.set $scratch
        (call $foreign2
         (global.get $global17)
        )
       )
       (if
        (i32.eqz
         (global.get $ready15)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global15)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type9 0
       (struct.get $environment8 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function8
     (struct.get $type8 1
      (struct.get $type9 1
       (struct.get $environment8 1
        (local.get $3)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready19)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global19)
   )
  )
  (return_call $function7
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type9))
  (local $1 (ref $type8))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type0)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global4
   (struct.new_default $type2)
  )
  (global.set $ready4
   (i32.const 1)
  )
  (global.set $global24
   (struct.new_default $type3)
  )
  (global.set $ready24
   (i32.const 1)
  )
  (global.set $global7
   (struct.new_default $type4)
  )
  (global.set $ready7
   (i32.const 1)
  )
  (global.set $global10
   (struct.new_default $type5)
  )
  (global.set $ready10
   (i32.const 1)
  )
  (global.set $global15
   (struct.new_default $type6)
  )
  (global.set $ready15
   (i32.const 1)
  )
  (global.set $global17
   (call $foreign3
    (i32.const 0)
   )
  )
  (global.set $ready17
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (local.set $2
   (call $foreign0)
  )
  (struct.set $type9 1
   (local.tee $0
    (struct.new_default $type9)
   )
   (struct.new $type8
    (ref.func $function1)
    (struct.new $environment1
     (local.get $0)
    )
   )
  )
  (struct.set $type9 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type9 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global18
   (call_ref $call8
    (struct.get $type8 1
     (local.tee $1
      (ref.as_non_null
       (struct.get $type9 1
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
    (ref.null none)
    (struct.get $type8 0
     (local.get $1)
    )
   )
  )
  (global.set $ready18
   (i32.const 1)
  )
  (global.set $global19
   (struct.new_default $type7)
  )
  (global.set $ready19
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

