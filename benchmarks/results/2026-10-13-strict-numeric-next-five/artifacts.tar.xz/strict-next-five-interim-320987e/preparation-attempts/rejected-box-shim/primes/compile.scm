(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-next-suite-ports-20261013/build/strict-next-five-probe-a/primes/program.scm" "/tmp/snail-strict-next-suite-ports-20261013/build/strict-next-five-probe-a/primes/program.so"))
