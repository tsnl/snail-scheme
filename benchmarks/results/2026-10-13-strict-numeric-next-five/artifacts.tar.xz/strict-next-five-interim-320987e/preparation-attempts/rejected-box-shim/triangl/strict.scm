(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define (list . elements) elements)
(define (append xs ys)
  (if (null? xs) ys (cons (car xs) (append (cdr xs) ys))))
(define-extern native-expected-length "benchmark" "expected_length" (-> I64))
(define-extern native-expected-i64 "benchmark" "expected_i64" (-> I64 I64))
(define (expected-list)
  (let loop ((n (native-expected-length)) (xs '()))
    (if (= n 0) xs
        (loop (- n 1) (cons (native-expected-i64 (- n 1)) xs)))))
(: same-i64-list? (-> (List I64) (List I64) Bool))
(define (same-i64-list? xs ys)
  (if (null? xs) (null? ys)
      (and (not (null? ys)) (= (car xs) (car ys))
           (same-i64-list? (cdr xs) (cdr ys)))))
(define (hide count x) (hide-i64 x))
;;; TRIANGL -- Board game benchmark.


(define *board*
  (list->vector (list 1 1 1 1 1 0 1 1 1 1 1 1 1 1 1 1)))

(define *sequence*
  (list->vector (list 0 0 0 0 0 0 0 0 0 0 0 0 0 0)))

(define *a*
  (list->vector (list 1 2 4 3 5 6 1 3 6 2 5 4 11 12
                    13 7 8 4 4 7 11 8 12 13 6 10
                    15 9 14 13 13 14 15 9 10
                    6 6)))

(define *b*
  (list->vector (list 2 4 7 5 8 9 3 6 10 5 9 8
                    12 13 14 8 9 5 2 4 7 5 8
                    9 3 6 10 5 9 8 12 13 14
                    8 9 5 5)))

(define *c*
  (list->vector (list 4 7 11 8 12 13 6 10 15 9 14 13
                    13 14 15 9 10 6 1 2 4 3 5 6 1
                    3 6 2 5 4 11 12 13 7 8 4 4)))

(define *answer* (ref (ann '() (List (List I64)))))

(define (attempt i depth)
  (cond ((= depth 14)
         (ref-set! *answer*
               (cons (cdr (vector->list *sequence*)) (ref-get *answer*)))
         #t)
        ((and (= 1 (vector-ref *board* (vector-ref *a* i)))
              (= 1 (vector-ref *board* (vector-ref *b* i)))
              (= 0 (vector-ref *board* (vector-ref *c* i))))
         (vector-set! *board* (vector-ref *a* i) 0)
         (vector-set! *board* (vector-ref *b* i) 0)
         (vector-set! *board* (vector-ref *c* i) 1)
         (vector-set! *sequence* depth i)
         (do ((j 0 (+ j 1))
              (depth (+ depth 1) depth))
             ((or (= j 36) (attempt j depth)) #f))
         (vector-set! *board* (vector-ref *a* i) 1)
         (vector-set! *board* (vector-ref *b* i) 1)
         (vector-set! *board* (vector-ref *c* i) 0) #f)
        (else #f)))

(define (test i depth)
  (ref-set! *answer* '())
  (attempt i depth)
  (car (ref-get *answer*)))

(define input0 (native-input-i64 (ann 0 I32)))
(define input1 (native-input-i64 (ann 1 I32)))
(define expected (expected-list))
(: bench (-> I64 I64))
(define (bench count) (if (same-i64-list? (let loop ((i 0) (result '()))
    (if (< i count) (loop (+ i 1) (test (hide count input0) (hide count input1))) result)) expected) 1 0))
(unit)
