(module
 (rec
  (type $environment14 (struct (field i64) (field (ref $type15))))
  (type $call13 (func (param i64) (result i64)))
  (type $environment11 (struct (field (ref $type21))))
  (type $type10 (struct (field (ref null $type1))))
  (type $environment10 (struct (field (ref $type15)) (field (ref $type2))))
  (type $type21 (struct (field (mut i32)) (field (mut (ref null $type11)))))
  (type $call11 (func (param (ref null $environment11) i64 i64) (result i32)))
  (type $call17 (func (param (ref $environment7) (ref null $type1) i64) (result i32)))
  (type $call19 (func (param (ref $environment6) (ref null $type1) i64) (result i64)))
  (type $type17 (struct (field (ref $environment7))))
  (type $type19 (struct (field (ref $environment6))))
  (type $environment7 (struct (field (ref $type16)) (field (ref $type18))))
  (type $type16 (struct (field i32) (field (ref $type2))))
  (type $type18 (struct (field (mut i32)) (field (mut (ref null $type17)))))
  (type $type20 (struct (field (mut i32)) (field (mut (ref null $type19)))))
  (type $environment6 (struct (field (ref $type20))))
  (type $call0 (func (param (ref $type1)) (result (ref $type2))))
  (type $call7 (func (param (ref null $type1) (ref null $type1)) (result i32)))
  (type $type14 (struct (field (ref $call14)) (field (ref struct))))
  (type $type15 (struct (field (mut i32)) (field (mut (ref null $type14)))))
  (type $environment1 (struct (field (ref $type15))))
  (type $call14 (func (param (ref struct) i64 (ref null $type1)) (result (ref null $type1))))
  (type $type13 (struct))
  (type $type1 (struct (field i64) (field (ref null $type1))))
  (type $type12 (struct))
  (type $type11 (struct (field (ref $call11)) (field (ref null $environment11))))
  (type $type9 (struct (field (mut (ref null $type10)))))
  (type $type2 (array (mut i64)))
  (type $type8 (struct))
  (type $type7 (struct))
  (type $type6 (struct))
  (type $type5 (struct))
  (type $type4 (struct))
  (type $type3 (struct))
  (type $type0 (struct))
 )
 (type $35 (func (param i64) (result i64)))
 (type $36 (func (result i64)))
 (type $37 (func (param i32) (result i64)))
 (type $38 (func (param (ref $environment7) (ref null $type1) i64)))
 (type $39 (func))
 (import "benchmark" "expected_length" (func $foreign0 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign2 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign3 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global10 (mut (ref null $type0)) (ref.null none))
 (global $ready10 (mut i32) (i32.const 0))
 (global $global13 (mut (ref null $type3)) (ref.null none))
 (global $ready13 (mut i32) (i32.const 0))
 (global $global29 (mut (ref null $type4)) (ref.null none))
 (global $ready29 (mut i32) (i32.const 0))
 (global $global8 (mut (ref null $type5)) (ref.null none))
 (global $ready8 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type6)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global4 (mut (ref null $type7)) (ref.null none))
 (global $ready4 (mut i32) (i32.const 0))
 (global $global49 (mut (ref null $type8)) (ref.null none))
 (global $ready49 (mut i32) (i32.const 0))
 (global $global7 (mut (ref null $type2)) (ref.null none))
 (global $ready7 (mut i32) (i32.const 0))
 (global $global21 (mut (ref null $type2)) (ref.null none))
 (global $ready21 (mut i32) (i32.const 0))
 (global $global22 (mut (ref null $type2)) (ref.null none))
 (global $ready22 (mut i32) (i32.const 0))
 (global $global23 (mut (ref null $type2)) (ref.null none))
 (global $ready23 (mut i32) (i32.const 0))
 (global $global24 (mut (ref null $type2)) (ref.null none))
 (global $ready24 (mut i32) (i32.const 0))
 (global $global25 (mut (ref null $type9)) (ref.null none))
 (global $ready25 (mut i32) (i32.const 0))
 (global $global26 (mut (ref null $type11)) (ref.null none))
 (global $ready26 (mut i32) (i32.const 0))
 (global $global38 (mut (ref null $type12)) (ref.null none))
 (global $ready38 (mut i32) (i32.const 0))
 (global $global41 (mut i64) (i64.const 0))
 (global $ready41 (mut i32) (i32.const 0))
 (global $global42 (mut i64) (i64.const 0))
 (global $ready42 (mut i32) (i32.const 0))
 (global $global43 (mut (ref null $type1)) (ref.null none))
 (global $ready43 (mut i32) (i32.const 0))
 (global $global44 (mut (ref null $type13)) (ref.null none))
 (global $ready44 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function1 (type $call14) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 i64)
  (if (result (ref null $type1))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type15 0
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function1
     (struct.get $type14 1
      (struct.get $type15 1
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type1
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function2 (type $call7) (param $0 (ref null $type1)) (param $1 (ref null $type1)) (result i32)
  (local $scratch (ref null $type1))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type1 0
         (local.get $0)
        )
        (struct.get $type1 0
         (local.get $1)
        )
       )
       (then
        (return_call $function2
         (struct.get $type1 1
          (local.get $0)
         )
         (block (result (ref null $type1))
          (local.set $scratch
           (struct.get $type1 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready4)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global4)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function4 (type $call0) (param $0 (ref $type1)) (result (ref $type2))
  (local $1 (ref null $type1))
  (local $2 (ref $environment6))
  (local $3 (ref $environment7))
  (local $4 (ref $type20))
  (local $5 (ref $type18))
  (local $6 (ref $type16))
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready13)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global13)
   )
  )
  (struct.set $type20 1
   (local.tee $4
    (struct.new_default $type20)
   )
   (struct.new $type19
    (struct.new $environment6
     (local.get $4)
    )
   )
  )
  (struct.set $type20 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type20 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type20 0
     (struct.get $environment6 0
      (local.tee $2
       (struct.get $type19 0
        (struct.get $type20 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type19 0
    (struct.get $type20 1
     (struct.get $environment6 0
      (local.get $2)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $7
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type1 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type1 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type20 0
          (struct.get $environment6 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type19 0
         (struct.get $type20 1
          (struct.get $environment6 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type1 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type20 0
            (struct.get $environment6 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type19 0
           (struct.get $type20 1
            (struct.get $environment6 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type1 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type20 0
              (struct.get $environment6 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type19 0
             (struct.get $type20 1
              (struct.get $environment6 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type1 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type20 0
                (struct.get $environment6 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type19 0
               (struct.get $type20 1
                (struct.get $environment6 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type1 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type20 0
                  (struct.get $environment6 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type19 0
                 (struct.get $type20 1
                  (struct.get $environment6 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type1 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type20 0
                    (struct.get $environment6 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type19 0
                   (struct.get $type20 1
                    (struct.get $environment6 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type1 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type20 0
                      (struct.get $environment6 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type19 0
                     (struct.get $type20 1
                      (struct.get $environment6 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type1 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type20 0
                        (struct.get $environment6 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function6
                      (struct.get $type19 0
                       (struct.get $type20 1
                        (struct.get $environment6 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type18 1
   (local.tee $5
    (struct.new_default $type18)
   )
   (struct.new $type17
    (struct.new $environment7
     (local.tee $6
      (struct.new $type16
       (i32.const 1)
       (array.new $type2
        (struct.get $type1 0
         (local.get $0)
        )
        (i32.wrap_i64
         (local.get $7)
        )
       )
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type18 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type18 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type2
   (struct.get $type16 1
    (struct.get $environment7 0
     (local.tee $3
      (struct.get $type17 0
       (struct.get $type18 1
        (local.get $5)
       )
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type1 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type18 0
     (struct.get $environment7 1
      (local.get $3)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type17 0
    (struct.get $type18 1
     (struct.get $environment7 1
      (local.get $3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.tee $1
      (struct.get $type1 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (array.set $type2
     (struct.get $type16 1
      (struct.get $environment7 0
       (local.get $3)
      )
     )
     (i32.const 1)
     (struct.get $type1 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type1 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type18 0
       (struct.get $environment7 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type17 0
      (struct.get $type18 1
       (struct.get $environment7 1
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (ref.is_null
       (local.get $1)
      )
     )
     (then
      (array.set $type2
       (struct.get $type16 1
        (struct.get $environment7 0
         (local.get $3)
        )
       )
       (i32.const 2)
       (struct.get $type1 0
        (local.get $1)
       )
      )
      (local.set $1
       (struct.get $type1 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type18 0
         (struct.get $environment7 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type17 0
        (struct.get $type18 1
         (struct.get $environment7 1
          (local.get $3)
         )
        )
       )
      )
      (if
       (i32.eqz
        (ref.is_null
         (local.get $1)
        )
       )
       (then
        (array.set $type2
         (struct.get $type16 1
          (struct.get $environment7 0
           (local.get $3)
          )
         )
         (i32.const 3)
         (struct.get $type1 0
          (local.get $1)
         )
        )
        (local.set $1
         (struct.get $type1 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type18 0
           (struct.get $environment7 1
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type17 0
          (struct.get $type18 1
           (struct.get $environment7 1
            (local.get $3)
           )
          )
         )
        )
        (if
         (i32.eqz
          (ref.is_null
           (local.get $1)
          )
         )
         (then
          (array.set $type2
           (struct.get $type16 1
            (struct.get $environment7 0
             (local.get $3)
            )
           )
           (i32.const 4)
           (struct.get $type1 0
            (local.get $1)
           )
          )
          (local.set $1
           (struct.get $type1 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type18 0
             (struct.get $environment7 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (call $function7
           (struct.get $type17 0
            (struct.get $type18 1
             (struct.get $environment7 1
              (local.get $3)
             )
            )
           )
           (local.get $1)
           (i64.const 5)
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (struct.get $type16 1
   (local.get $6)
  )
 )
 (func $function6 (type $call19) (param $0 (ref $environment6)) (param $1 (ref null $type1)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type1 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type20 0
         (struct.get $environment6 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function6
       (struct.get $type19 0
        (struct.get $type20 1
         (struct.get $environment6 0
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function7 (param $0 (ref $environment7)) (param $1 (ref null $type1)) (param $2 i64)
  (local $3 i64)
  (if
   (i32.eqz
    (ref.is_null
     (local.get $1)
    )
   )
   (then
    (local.set $3
     (struct.get $type1 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type2
     (struct.get $type16 1
      (struct.get $environment7 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type1 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type18 0
       (struct.get $environment7 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $function7
     (struct.get $type17 0
      (struct.get $type18 1
       (struct.get $environment7 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function8 (type $call11) (param $0 (ref null $environment11)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 (ref $type2))
  (local $4 (ref $type15))
  (local $5 (ref $type21))
  (local $6 (ref $type9))
  (local $7 (ref $type14))
  (local $8 (ref null $type1))
  (local $9 (ref $type11))
  (local $10 i64)
  (local $scratch (ref null $type1))
  (if (result i32)
   (i64.eq
    (local.get $2)
    (i64.const 14)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready25)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type9 0
     (ref.as_non_null
      (global.get $global25)
     )
     (block (result (ref (exact $type10)))
      (if
       (i32.eqz
        (global.get $ready21)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (ref.as_non_null
        (global.get $global21)
       )
      )
      (if
       (i32.eqz
        (global.get $ready29)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global29)
       )
      )
      (struct.set $type15 1
       (local.tee $4
        (struct.new_default $type15)
       )
       (struct.new $type14
        (ref.func $function10)
        (struct.new $environment10
         (local.get $4)
         (local.get $3)
        )
       )
      )
      (struct.set $type15 0
       (local.get $4)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type15 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type10
       (block (result (ref null $type1))
        (local.set $scratch
         (struct.get $type1 1
          (call_ref $call14
           (struct.get $type14 1
            (local.tee $7
             (ref.as_non_null
              (struct.get $type15 1
               (local.get $4)
              )
             )
            )
           )
           (i64.extend_i32_u
            (array.len
             (local.get $3)
            )
           )
           (ref.null none)
           (struct.get $type14 0
            (local.get $7)
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready25)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global25)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
    (i32.const 1)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready7)
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.eq
       (array.get $type2
        (ref.as_non_null
         (global.get $global7)
        )
        (block (result i32)
         (if
          (i32.eqz
           (global.get $ready22)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $10
            (array.get $type2
             (global.get $global22)
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $10)
         )
        )
       )
       (i64.const 1)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready7)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (i64.eq
         (array.get $type2
          (ref.as_non_null
           (global.get $global7)
          )
          (block (result i32)
           (if
            (i32.eqz
             (global.get $ready23)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i64.gt_u
             (local.get $1)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i64.gt_u
             (local.tee $10
              (array.get $type2
               (global.get $global23)
               (i32.wrap_i64
                (local.get $1)
               )
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $10)
           )
          )
         )
         (i64.const 1)
        )
        (then
         (if
          (i32.eqz
           (global.get $ready7)
          )
          (then
           (unreachable)
          )
         )
         (i64.eqz
          (array.get $type2
           (ref.as_non_null
            (global.get $global7)
           )
           (block (result i32)
            (if
             (i32.eqz
              (global.get $ready24)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i64.gt_u
              (local.get $1)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i64.gt_u
              (local.tee $10
               (array.get $type2
                (global.get $global24)
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $10)
            )
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready7)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type2
       (ref.as_non_null
        (global.get $global7)
       )
       (block (result i32)
        (if
         (i32.eqz
          (global.get $ready22)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.tee $10
           (array.get $type2
            (global.get $global22)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $10)
        )
       )
       (i64.const 0)
      )
      (if
       (i32.eqz
        (global.get $ready7)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type2
       (ref.as_non_null
        (global.get $global7)
       )
       (block (result i32)
        (if
         (i32.eqz
          (global.get $ready23)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.tee $10
           (array.get $type2
            (global.get $global23)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $10)
        )
       )
       (i64.const 0)
      )
      (if
       (i32.eqz
        (global.get $ready7)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type2
       (ref.as_non_null
        (global.get $global7)
       )
       (block (result i32)
        (if
         (i32.eqz
          (global.get $ready24)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.tee $10
           (array.get $type2
            (global.get $global24)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $10)
        )
       )
       (i64.const 1)
      )
      (if
       (i32.eqz
        (global.get $ready21)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type2
       (global.get $global21)
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $1)
      )
      (struct.set $type21 1
       (local.tee $5
        (struct.new_default $type21)
       )
       (struct.new $type11
        (ref.func $function11)
        (struct.new $environment11
         (local.get $5)
        )
       )
      )
      (struct.set $type21 0
       (local.get $5)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type21 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call11
        (struct.get $type11 1
         (local.tee $9
          (ref.as_non_null
           (struct.get $type21 1
            (local.get $5)
           )
          )
         )
        )
        (i64.const 0)
        (i64.add
         (local.get $2)
         (i64.const 1)
        )
        (struct.get $type11 0
         (local.get $9)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready7)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type2
       (ref.as_non_null
        (global.get $global7)
       )
       (block (result i32)
        (if
         (i32.eqz
          (global.get $ready22)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.tee $2
           (array.get $type2
            (global.get $global22)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (i64.const 1)
      )
      (if
       (i32.eqz
        (global.get $ready7)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type2
       (ref.as_non_null
        (global.get $global7)
       )
       (block (result i32)
        (if
         (i32.eqz
          (global.get $ready23)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.tee $2
           (array.get $type2
            (global.get $global23)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (i64.const 1)
      )
      (if
       (i32.eqz
        (global.get $ready7)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type2
       (ref.as_non_null
        (global.get $global7)
       )
       (block (result i32)
        (if
         (i32.eqz
          (global.get $ready24)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.tee $1
           (array.get $type2
            (global.get $global24)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i64.const 0)
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function10 (type $call14) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 i64)
  (local $4 (ref $environment10))
  (if (result (ref null $type1))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $3
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.get $type2
      (struct.get $environment10 1
       (local.tee $4
        (ref.cast (ref $environment10)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type15 0
       (struct.get $environment10 0
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function10
     (struct.get $type14 1
      (struct.get $type15 1
       (struct.get $environment10 0
        (ref.cast (ref $environment10)
         (local.get $4)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type1
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function11 (type $call11) (param $0 (ref null $environment11)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 i32)
  (if (result i32)
   (if (result i32)
    (local.tee $3
     (i64.eq
      (local.get $1)
      (i64.const 36)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready26)
      )
      (then
       (unreachable)
      )
     )
     (call $function8
      (struct.get $type11 1
       (global.get $global26)
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type21 0
       (struct.get $environment11 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function11
     (struct.get $type11 1
      (struct.get $type21 1
       (struct.get $environment11 0
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function13 (type $call13) (param $0 i64) (result i64)
  (local $1 (ref null $type1))
  (local $2 (ref null $type1))
  (local $3 (ref $type15))
  (local $4 (ref $type14))
  (local $scratch (ref null $type1))
  (struct.set $type15 1
   (local.tee $3
    (struct.new_default $type15)
   )
   (struct.new $type14
    (ref.func $function14)
    (struct.new $environment14
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type15 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type15 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call14
    (struct.get $type14 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type15 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type14 0
     (local.get $4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready43)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global4)
   )
  )
  (local.set $1
   (global.get $global43)
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (ref.is_null
       (local.get $1)
      )
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i64.eq
          (struct.get $type1 0
           (local.get $2)
          )
          (struct.get $type1 0
           (local.get $1)
          )
         )
         (then
          (local.set $2
           (struct.get $type1 1
            (local.get $2)
           )
          )
          (local.set $1
           (struct.get $type1 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready4)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global4)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (ref.is_null
             (local.get $1)
            )
           )
           (else
            (if (result i32)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i64.eq
                (struct.get $type1 0
                 (local.get $2)
                )
                (struct.get $type1 0
                 (local.get $1)
                )
               )
               (then
                (local.set $2
                 (struct.get $type1 1
                  (local.get $2)
                 )
                )
                (local.set $1
                 (struct.get $type1 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready4)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global4)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (ref.is_null
                   (local.get $1)
                  )
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (i64.eq
                      (struct.get $type1 0
                       (local.get $2)
                      )
                      (struct.get $type1 0
                       (local.get $1)
                      )
                     )
                     (then
                      (local.set $2
                       (struct.get $type1 1
                        (local.get $2)
                       )
                      )
                      (local.set $1
                       (struct.get $type1 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready4)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global4)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (ref.is_null
                         (local.get $1)
                        )
                       )
                       (else
                        (if (result i32)
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i64.eq
                            (struct.get $type1 0
                             (local.get $2)
                            )
                            (struct.get $type1 0
                             (local.get $1)
                            )
                           )
                           (then
                            (local.set $2
                             (struct.get $type1 1
                              (local.get $2)
                             )
                            )
                            (local.set $1
                             (struct.get $type1 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready4)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global4)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (ref.is_null
                               (local.get $1)
                              )
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (i64.eq
                                  (struct.get $type1 0
                                   (local.get $2)
                                  )
                                  (struct.get $type1 0
                                   (local.get $1)
                                  )
                                 )
                                 (then
                                  (local.set $2
                                   (struct.get $type1 1
                                    (local.get $2)
                                   )
                                  )
                                  (local.set $1
                                   (struct.get $type1 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready4)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global4)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                   )
                                   (else
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $1)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if (result i32)
                                       (i64.eq
                                        (struct.get $type1 0
                                         (local.get $2)
                                        )
                                        (struct.get $type1 0
                                         (local.get $1)
                                        )
                                       )
                                       (then
                                        (local.set $2
                                         (struct.get $type1 1
                                          (local.get $2)
                                         )
                                        )
                                        (local.set $1
                                         (struct.get $type1 1
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready4)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global4)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                         )
                                         (else
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (i64.eq
                                              (struct.get $type1 0
                                               (local.get $2)
                                              )
                                              (struct.get $type1 0
                                               (local.get $1)
                                              )
                                             )
                                             (then
                                              (local.set $2
                                               (struct.get $type1 1
                                                (local.get $2)
                                               )
                                              )
                                              (local.set $1
                                               (struct.get $type1 1
                                                (local.get $1)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready4)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global4)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (ref.is_null
                                                 (local.get $1)
                                                )
                                               )
                                               (else
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $1)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i64.eq
                                                    (struct.get $type1 0
                                                     (local.get $2)
                                                    )
                                                    (struct.get $type1 0
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (then
                                                    (local.set $2
                                                     (struct.get $type1 1
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (local.set $1
                                                     (struct.get $type1 1
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready4)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global4)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                     (then
                                                      (ref.is_null
                                                       (local.get $1)
                                                      )
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $1)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i64.eq
                                                          (struct.get $type1 0
                                                           (local.get $2)
                                                          )
                                                          (struct.get $type1 0
                                                           (local.get $1)
                                                          )
                                                         )
                                                         (then
                                                          (local.set $2
                                                           (struct.get $type1 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (local.set $1
                                                           (struct.get $type1 1
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready4)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global4)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (ref.is_null
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $1)
                                                             )
                                                             (then
                                                              (i32.const 0)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i64.eq
                                                                (struct.get $type1 0
                                                                 (local.get $2)
                                                                )
                                                                (struct.get $type1 0
                                                                 (local.get $1)
                                                                )
                                                               )
                                                               (then
                                                                (call $function2
                                                                 (struct.get $type1 1
                                                                  (local.get $2)
                                                                 )
                                                                 (block (result (ref null $type1))
                                                                  (local.set $scratch
                                                                   (struct.get $type1 1
                                                                    (local.get $1)
                                                                   )
                                                                  )
                                                                  (if
                                                                   (i32.eqz
                                                                    (global.get $ready4)
                                                                   )
                                                                   (then
                                                                    (unreachable)
                                                                   )
                                                                  )
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global4)
                                                                   )
                                                                  )
                                                                  (local.get $scratch)
                                                                 )
                                                                )
                                                               )
                                                               (else
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (else
                                                          (i32.const 0)
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (i32.const 0)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (i32.const 0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function14 (type $call14) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 (ref $environment14))
  (local $4 i64)
  (local $5 i64)
  (if (result (ref null $type1))
   (i64.gt_s
    (struct.get $environment14 0
     (local.tee $3
      (ref.cast (ref $environment14)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready41)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready49)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global49)
     )
    )
    (local.set $4
     (call $foreign2
      (global.get $global41)
     )
    )
    (if
     (i32.eqz
      (global.get $ready42)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready49)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global49)
     )
    )
    (local.set $5
     (call $foreign2
      (global.get $global42)
     )
    )
    (if
     (i32.eqz
      (global.get $ready38)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global38)
     )
    )
    (if
     (i32.eqz
      (global.get $ready25)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type9 0
     (global.get $global25)
     (ref.null none)
    )
    (if
     (i32.eqz
      (global.get $ready26)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function8
      (struct.get $type11 1
       (global.get $global26)
      )
      (local.get $4)
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (global.get $ready25)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type10 0
      (struct.get $type9 0
       (global.get $global25)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type15 0
       (struct.get $environment14 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function14
     (struct.get $type14 1
      (struct.get $type15 1
       (struct.get $environment14 1
        (local.get $3)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready44)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global44)
   )
  )
  (return_call $function13
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type15))
  (local $1 (ref $type14))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global10
   (struct.new_default $type0)
  )
  (global.set $ready10
   (i32.const 1)
  )
  (global.set $global13
   (struct.new_default $type3)
  )
  (global.set $ready13
   (i32.const 1)
  )
  (global.set $global29
   (struct.new_default $type4)
  )
  (global.set $ready29
   (i32.const 1)
  )
  (global.set $global8
   (struct.new_default $type5)
  )
  (global.set $ready8
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type6)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global4
   (struct.new_default $type7)
  )
  (global.set $ready4
   (i32.const 1)
  )
  (global.set $global49
   (struct.new_default $type8)
  )
  (global.set $ready49
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global8)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global10)
   )
  )
  (global.set $global7
   (call $function4
    (struct.new $type1
     (i64.const 1)
     (struct.new $type1
      (i64.const 1)
      (struct.new $type1
       (i64.const 1)
       (struct.new $type1
        (i64.const 1)
        (struct.new $type1
         (i64.const 1)
         (struct.new $type1
          (i64.const 0)
          (struct.new $type1
           (i64.const 1)
           (struct.new $type1
            (i64.const 1)
            (struct.new $type1
             (i64.const 1)
             (struct.new $type1
              (i64.const 1)
              (struct.new $type1
               (i64.const 1)
               (struct.new $type1
                (i64.const 1)
                (struct.new $type1
                 (i64.const 1)
                 (struct.new $type1
                  (i64.const 1)
                  (struct.new $type1
                   (i64.const 1)
                   (struct.new $type1
                    (i64.const 1)
                    (ref.null none)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready7
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global8)
   )
  )
  (if
   (i32.eqz
    (global.get $ready10)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global10)
   )
  )
  (global.set $global21
   (call $function4
    (struct.new $type1
     (i64.const 0)
     (struct.new $type1
      (i64.const 0)
      (struct.new $type1
       (i64.const 0)
       (struct.new $type1
        (i64.const 0)
        (struct.new $type1
         (i64.const 0)
         (struct.new $type1
          (i64.const 0)
          (struct.new $type1
           (i64.const 0)
           (struct.new $type1
            (i64.const 0)
            (struct.new $type1
             (i64.const 0)
             (struct.new $type1
              (i64.const 0)
              (struct.new $type1
               (i64.const 0)
               (struct.new $type1
                (i64.const 0)
                (struct.new $type1
                 (i64.const 0)
                 (struct.new_default $type1)
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready21
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global8)
   )
  )
  (if
   (i32.eqz
    (global.get $ready10)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global10)
   )
  )
  (global.set $global22
   (call $function4
    (struct.new $type1
     (i64.const 1)
     (struct.new $type1
      (i64.const 2)
      (struct.new $type1
       (i64.const 4)
       (struct.new $type1
        (i64.const 3)
        (struct.new $type1
         (i64.const 5)
         (struct.new $type1
          (i64.const 6)
          (struct.new $type1
           (i64.const 1)
           (struct.new $type1
            (i64.const 3)
            (struct.new $type1
             (i64.const 6)
             (struct.new $type1
              (i64.const 2)
              (struct.new $type1
               (i64.const 5)
               (struct.new $type1
                (i64.const 4)
                (struct.new $type1
                 (i64.const 11)
                 (struct.new $type1
                  (i64.const 12)
                  (struct.new $type1
                   (i64.const 13)
                   (struct.new $type1
                    (i64.const 7)
                    (struct.new $type1
                     (i64.const 8)
                     (struct.new $type1
                      (i64.const 4)
                      (struct.new $type1
                       (i64.const 4)
                       (struct.new $type1
                        (i64.const 7)
                        (struct.new $type1
                         (i64.const 11)
                         (struct.new $type1
                          (i64.const 8)
                          (struct.new $type1
                           (i64.const 12)
                           (struct.new $type1
                            (i64.const 13)
                            (struct.new $type1
                             (i64.const 6)
                             (struct.new $type1
                              (i64.const 10)
                              (struct.new $type1
                               (i64.const 15)
                               (struct.new $type1
                                (i64.const 9)
                                (struct.new $type1
                                 (i64.const 14)
                                 (struct.new $type1
                                  (i64.const 13)
                                  (struct.new $type1
                                   (i64.const 13)
                                   (struct.new $type1
                                    (i64.const 14)
                                    (struct.new $type1
                                     (i64.const 15)
                                     (struct.new $type1
                                      (i64.const 9)
                                      (struct.new $type1
                                       (i64.const 10)
                                       (struct.new $type1
                                        (i64.const 6)
                                        (struct.new $type1
                                         (i64.const 6)
                                         (ref.null none)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready22
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global8)
   )
  )
  (if
   (i32.eqz
    (global.get $ready10)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global10)
   )
  )
  (global.set $global23
   (call $function4
    (struct.new $type1
     (i64.const 2)
     (struct.new $type1
      (i64.const 4)
      (struct.new $type1
       (i64.const 7)
       (struct.new $type1
        (i64.const 5)
        (struct.new $type1
         (i64.const 8)
         (struct.new $type1
          (i64.const 9)
          (struct.new $type1
           (i64.const 3)
           (struct.new $type1
            (i64.const 6)
            (struct.new $type1
             (i64.const 10)
             (struct.new $type1
              (i64.const 5)
              (struct.new $type1
               (i64.const 9)
               (struct.new $type1
                (i64.const 8)
                (struct.new $type1
                 (i64.const 12)
                 (struct.new $type1
                  (i64.const 13)
                  (struct.new $type1
                   (i64.const 14)
                   (struct.new $type1
                    (i64.const 8)
                    (struct.new $type1
                     (i64.const 9)
                     (struct.new $type1
                      (i64.const 5)
                      (struct.new $type1
                       (i64.const 2)
                       (struct.new $type1
                        (i64.const 4)
                        (struct.new $type1
                         (i64.const 7)
                         (struct.new $type1
                          (i64.const 5)
                          (struct.new $type1
                           (i64.const 8)
                           (struct.new $type1
                            (i64.const 9)
                            (struct.new $type1
                             (i64.const 3)
                             (struct.new $type1
                              (i64.const 6)
                              (struct.new $type1
                               (i64.const 10)
                               (struct.new $type1
                                (i64.const 5)
                                (struct.new $type1
                                 (i64.const 9)
                                 (struct.new $type1
                                  (i64.const 8)
                                  (struct.new $type1
                                   (i64.const 12)
                                   (struct.new $type1
                                    (i64.const 13)
                                    (struct.new $type1
                                     (i64.const 14)
                                     (struct.new $type1
                                      (i64.const 8)
                                      (struct.new $type1
                                       (i64.const 9)
                                       (struct.new $type1
                                        (i64.const 5)
                                        (struct.new $type1
                                         (i64.const 5)
                                         (ref.null none)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready23
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global8)
   )
  )
  (if
   (i32.eqz
    (global.get $ready10)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global10)
   )
  )
  (global.set $global24
   (call $function4
    (struct.new $type1
     (i64.const 4)
     (struct.new $type1
      (i64.const 7)
      (struct.new $type1
       (i64.const 11)
       (struct.new $type1
        (i64.const 8)
        (struct.new $type1
         (i64.const 12)
         (struct.new $type1
          (i64.const 13)
          (struct.new $type1
           (i64.const 6)
           (struct.new $type1
            (i64.const 10)
            (struct.new $type1
             (i64.const 15)
             (struct.new $type1
              (i64.const 9)
              (struct.new $type1
               (i64.const 14)
               (struct.new $type1
                (i64.const 13)
                (struct.new $type1
                 (i64.const 13)
                 (struct.new $type1
                  (i64.const 14)
                  (struct.new $type1
                   (i64.const 15)
                   (struct.new $type1
                    (i64.const 9)
                    (struct.new $type1
                     (i64.const 10)
                     (struct.new $type1
                      (i64.const 6)
                      (struct.new $type1
                       (i64.const 1)
                       (struct.new $type1
                        (i64.const 2)
                        (struct.new $type1
                         (i64.const 4)
                         (struct.new $type1
                          (i64.const 3)
                          (struct.new $type1
                           (i64.const 5)
                           (struct.new $type1
                            (i64.const 6)
                            (struct.new $type1
                             (i64.const 1)
                             (struct.new $type1
                              (i64.const 3)
                              (struct.new $type1
                               (i64.const 6)
                               (struct.new $type1
                                (i64.const 2)
                                (struct.new $type1
                                 (i64.const 5)
                                 (struct.new $type1
                                  (i64.const 4)
                                  (struct.new $type1
                                   (i64.const 11)
                                   (struct.new $type1
                                    (i64.const 12)
                                    (struct.new $type1
                                     (i64.const 13)
                                     (struct.new $type1
                                      (i64.const 7)
                                      (struct.new $type1
                                       (i64.const 8)
                                       (struct.new $type1
                                        (i64.const 4)
                                        (struct.new $type1
                                         (i64.const 4)
                                         (ref.null none)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready24
   (i32.const 1)
  )
  (global.set $global25
   (struct.new_default $type9)
  )
  (global.set $ready25
   (i32.const 1)
  )
  (global.set $global26
   (struct.new $type11
    (ref.func $function8)
    (ref.null none)
   )
  )
  (global.set $ready26
   (i32.const 1)
  )
  (global.set $global38
   (struct.new_default $type12)
  )
  (global.set $ready38
   (i32.const 1)
  )
  (global.set $global41
   (call $foreign3
    (i32.const 0)
   )
  )
  (global.set $ready41
   (i32.const 1)
  )
  (global.set $global42
   (call $foreign3
    (i32.const 1)
   )
  )
  (global.set $ready42
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (local.set $2
   (call $foreign0)
  )
  (struct.set $type15 1
   (local.tee $0
    (struct.new_default $type15)
   )
   (struct.new $type14
    (ref.func $function1)
    (struct.new $environment1
     (local.get $0)
    )
   )
  )
  (struct.set $type15 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type15 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global43
   (call_ref $call14
    (struct.get $type14 1
     (local.tee $1
      (ref.as_non_null
       (struct.get $type15 1
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
    (ref.null none)
    (struct.get $type14 0
     (local.get $1)
    )
   )
  )
  (global.set $ready43
   (i32.const 1)
  )
  (global.set $global44
   (struct.new_default $type13)
  )
  (global.set $ready44
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

