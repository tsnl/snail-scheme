;; Concrete primitive contracts are shared by inference and Wasm emission.
;; Numeric widths are siblings: selecting an opcode never inserts a coercion.
(define-library (snail-scheme strict-primitives)
  (export primitive-names primitive-scheme primitive-opcode)
  (import (scheme base) (scheme cxr) (snail-scheme strict-types))
  (begin

    ;; ---- Concrete numeric operations ----

    ;; Each row gives its complete domains, result and native instruction.
    ;; Unary conversions and binary arithmetic use the same signature rule.
    (define numeric-primitives
      '((i32-add (I32 I32) I32 i32.add)
        (i32-sub (I32 I32) I32 i32.sub)
        (i32-mul (I32 I32) I32 i32.mul)
        (i32-eq (I32 I32) Bool i32.eq)
        (i32-lt (I32 I32) Bool i32.lt_s)
        (i32-le (I32 I32) Bool i32.le_s)
        (i32-gt (I32 I32) Bool i32.gt_s)
        (i32-ge (I32 I32) Bool i32.ge_s)
        (i32-quotient (I32 I32) I32 i32.div_s)
        (i32-remainder (I32 I32) I32 i32.rem_s)
        (i64-add (I64 I64) I64 i64.add)
        (i64-sub (I64 I64) I64 i64.sub)
        (i64-mul (I64 I64) I64 i64.mul)
        (i64-eq (I64 I64) Bool i64.eq)
        (i64-lt (I64 I64) Bool i64.lt_s)
        (i64-le (I64 I64) Bool i64.le_s)
        (i64-gt (I64 I64) Bool i64.gt_s)
        (i64-ge (I64 I64) Bool i64.ge_s)
        (i64-quotient (I64 I64) I64 i64.div_s)
        (i64-remainder (I64 I64) I64 i64.rem_s)
        (f32-add (F32 F32) F32 f32.add)
        (f32-sub (F32 F32) F32 f32.sub)
        (f32-mul (F32 F32) F32 f32.mul)
        (f32-eq (F32 F32) Bool f32.eq)
        (f32-lt (F32 F32) Bool f32.lt)
        (f32-le (F32 F32) Bool f32.le)
        (f32-gt (F32 F32) Bool f32.gt)
        (f32-ge (F32 F32) Bool f32.ge)
        (f32-div (F32 F32) F32 f32.div)
        (f32-sqrt (F32) F32 f32.sqrt)
        (f64-add (F64 F64) F64 f64.add)
        (f64-sub (F64 F64) F64 f64.sub)
        (f64-mul (F64 F64) F64 f64.mul)
        (f64-eq (F64 F64) Bool f64.eq)
        (f64-lt (F64 F64) Bool f64.lt)
        (f64-le (F64 F64) Bool f64.le)
        (f64-gt (F64 F64) Bool f64.gt)
        (f64-ge (F64 F64) Bool f64.ge)
        (f64-div (F64 F64) F64 f64.div)
        (f64-sqrt (F64) F64 f64.sqrt)
        (i64->f64 (I64) F64 f64.convert_i64_s)
        (i32->i64 (I32) I64 i64.extend_i32_s)
        (i64->i32 (I64) I32 i32.wrap_i64)
        (f32->f64 (F32) F64 f64.promote_f32)
        (f64->f32 (F64) F32 f32.demote_f64)
        (f64->i64 (F64) I64 i64.trunc_f64_s)))
    (define primitive-names
      (append (map car numeric-primitives)
              '(not unit ref ref-get ref-set! ref-eq? cons car cdr null? unreachable
                    empty-vector make-vector vector-length vector-ref vector-set! vector-eq? vector-copy!)))
    (define (primitive-opcode name)
      (let ((entry (assq name numeric-primitives))) (if entry (cadddr entry) name)))
    (define (primitive-scheme name)
      (let ((entry (assq name numeric-primitives)))
        (cond (entry (make-scheme '() (function-type (cadr entry) #f (caddr entry)) '()))
              ((eq? name 'not) (make-scheme '() (function-type '(Bool) #f 'Bool) '()))
              ((eq? name 'unit) (make-scheme '() (function-type '() #f 'Unit) '()))
              ((eq? name 'unreachable) (make-scheme '() (function-type '() #f 'Never) '()))
              (else (container-scheme name)))))

    ;; ---- Concrete containers ----

    ;; Allocation is an ordinary application, so the inference value restriction
    ;; prevents a mutable container from acquiring independent element types.

    (define (container-scheme name)
      (let* ((a (fresh-variable)) (ref (list 'Ref a)) (list-type (list 'List a))
             (vector-type (list 'Vector a))
             (signature
              (case name
                ((ref) (function-type (list a) #f ref))
                ((ref-get) (function-type (list ref) #f a))
                ((ref-set!) (function-type (list ref a) #f 'Unit))
                ((ref-eq?) (function-type (list ref ref) #f 'Bool))
                ((cons) (function-type (list a list-type) #f list-type))
                ((car) (function-type (list list-type) #f a))
                ((cdr) (function-type (list list-type) #f list-type))
                ((null?) (function-type (list list-type) #f 'Bool))
                ((empty-vector) (function-type '() #f vector-type))
                ((make-vector) (function-type (list 'I64 a) #f vector-type))
                ((vector-length) (function-type (list vector-type) #f 'I64))
                ((vector-ref) (function-type (list vector-type 'I64) #f a))
                ((vector-set!) (function-type (list vector-type 'I64 a) #f 'Unit))
                ((vector-eq?) (function-type (list vector-type vector-type) #f 'Bool))
                ((vector-copy!) (function-type (list vector-type 'I64 vector-type 'I64 'I64) #f 'Unit))
                (else (error "unknown strict primitive" name)))))
        (make-scheme (list a) signature '())))))
