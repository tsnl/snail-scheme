"""Build local pages running the exact frozen mperm Wasm with scalar imports."""
import base64
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
MODULE=Path('/tmp/snail-strict-call-capture-combined-20261013/build/initialized-capture-benchmarks/mperm/mperm/strict.wasm')
ORIGINAL=Path('/tmp/snail-strict-enumeration-preparation-20261013/mperm/spec.json')
encoded=base64.b64encode(MODULE.read_bytes()).decode()
source='''<!doctype html><meta charset="utf-8"><body><pre id="result">pending</pre><script>
'use strict';
const config = CONFIG;
const bytes = Uint8Array.from(atob('MODULE'), character => character.charCodeAt(0));
let barriers = 0;
const opacity = value => { barriers++; return value; };
try {
  const module = new WebAssembly.Module(bytes);
  const imports = {benchmark:{
    count: () => BigInt(config.count),
    input_i64: index => BigInt(config.inputs[index]),
    hide_i64: opacity,
    barrier: () => opacity(1)
  }};
  const instance = new WebAssembly.Instance(module, imports);
  instance.exports.main();
  const setupBarriers = barriers;
  barriers = 0;
  const start = performance.now();
  const result = instance.exports.bench(BigInt(config.count));
  const seconds = (performance.now() - start) / 1000;
  if (result.toString() !== config.expected.toString() || setupBarriers !== 4 || barriers !== 0)
    throw new Error('Incorrect result or opacity count');
  const record = {status:'pass', result:result.toString(), setupBarriers, barriers, seconds,
                  imports:WebAssembly.Module.imports(module), userAgent:navigator.userAgent};
  document.getElementById('result').textContent = JSON.stringify(record);
  console.log('SNAIL_RESULT ' + JSON.stringify(record));
} catch (error) {
  document.getElementById('result').textContent = JSON.stringify({status:'error', message:error.stack});
  console.error(error);
}
</script></body>
'''
spec=json.loads(ORIGINAL.read_text())
for name, config in [('small',dict(spec,count=2,inputs=[5,2,1])),('full',spec)]:
    target=ROOT/'browser-probe'/(name+'.html')
    target.write_text(source.replace('CONFIG',json.dumps(config)).replace('MODULE',encoded))
identity=dict(module=str(MODULE),sha256=hashlib.sha256(MODULE.read_bytes()).hexdigest(),original_spec=json.loads(ORIGINAL.read_text()),scope='Diagnostic browser host; timings are not clean observations; validation import counts are active.')
(ROOT/'browser-probe/identity.json').write_text(json.dumps(identity,indent=2)+'\n')
