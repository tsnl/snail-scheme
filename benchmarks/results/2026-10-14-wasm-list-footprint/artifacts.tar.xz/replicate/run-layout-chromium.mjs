import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const profile = path.join(root, 'browser-probe/profile-heap');
const page = new URL('./browser-probe/heap.html', import.meta.url).href;
const args = ['--headless', '--disable-gpu', '--disable-background-networking', '--disable-sync',
  '--disable-extensions', '--disable-component-update', '--no-first-run', '--no-default-browser-check',
  '--enable-precise-memory-info', '--js-flags=--expose-gc', '--remote-debugging-port=0',
  '--remote-debugging-address=127.0.0.1', '--user-data-dir=' + profile, page];
const child = spawn('/run/current-system/sw/bin/chromium', args, {detached:true, stdio:['ignore','pipe','pipe']});
let stdout = '', stderr = '';
child.stdout.on('data', bytes => { stdout += bytes; });
child.stderr.on('data', bytes => { stderr += bytes; });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
let socket;
try {
  const activePort = path.join(profile, 'DevToolsActivePort');
  for (let i = 0; !fs.existsSync(activePort) && i < 100; i++) await sleep(100);
  const port = fs.readFileSync(activePort, 'utf8').split('\n')[0];
  let target;
  for (let i = 0; !target && i < 100; i++) {
    const targets = await (await fetch('http://127.0.0.1:' + port + '/json/list')).json();
    target = targets.find(item => item.type === 'page' && item.url === page);
    if (!target) await sleep(100);
  }
  if (!target) throw new Error('Local probe target did not appear');
  socket = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, {once:true}); socket.addEventListener('error', reject, {once:true}); });
  const response = new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Heap probe timed out')), 90000);
    socket.addEventListener('message', event => {
      const item = JSON.parse(event.data);
      if (item.id === 1) { clearTimeout(timeout); resolve(item); }
    });
  });
  socket.send(JSON.stringify({id:1, method:'Runtime.evaluate', params:{
    expression:'new Promise(resolve => { const check = () => typeof globalThis.probeDone === "undefined" ? setTimeout(check, 50) : resolve(globalThis.probeDone); check(); })',
    awaitPromise:true, returnByValue:true}}));
  const result = await response;
  if (result.error || result.result.exceptionDetails || !result.result.result.value)
    throw new Error(JSON.stringify(result));
  fs.writeFileSync(path.join(root, 'chromium-heap-layout.json'), JSON.stringify(result.result.result.value, null, 2) + '\n');
  console.log('Chromium heap probe complete');
} finally {
  socket?.close();
  try { process.kill(-child.pid, 'SIGTERM'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
  fs.writeFileSync(path.join(root, 'chromium-heap-process.json'), JSON.stringify({command:['/run/current-system/sw/bin/chromium', ...args], stdout, stderr}, null, 2) + '\n');
}
