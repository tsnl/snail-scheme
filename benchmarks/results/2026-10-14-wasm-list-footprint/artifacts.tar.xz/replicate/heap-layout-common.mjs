export async function runProbe(bytes, collect, heapUsed, engine) {
  const instance = new WebAssembly.Instance(new WebAssembly.Module(bytes));
  const wasm = instance.exports;
  const sleep = () => new Promise(resolve => setTimeout(resolve, 110));
  async function settled() {
    const samples = [];
    for (let repeat = 0; repeat < 3; repeat++) {
      collect();
      await sleep();
      samples.push(heapUsed());
    }
    return samples;
  }
  for (let round = 0; round < 6; round++) {
    for (const kind of [0, 1]) {
      wasm.reset(10000);
      wasm.fill(kind);
      if (wasm.verify(kind) !== 10000) throw new Error('Warmup graph mismatch');
    }
    wasm.reset(0);
    collect();
    heapUsed();
    await sleep();
  }
  const initial = await settled();
  const observations = [];
  for (const kind of [1, 0]) {
    for (const count of [200000, 100000, 25000, 25000, 100000, 200000]) {
      wasm.reset(count);
      if (wasm.length() !== count) throw new Error('Root array length mismatch');
      const empty = await settled();
      wasm.fill(kind);
      if (wasm.verify(kind) !== count || !wasm.same(0, 0) || wasm.same(0, count - 1))
        throw new Error('Node identity, payload or chain mismatch');
      const populated = await settled();
      wasm.reset(0);
      const released = await settled();
      observations.push({kind:kind === 0 ? 'inner' : 'outer', count, empty, populated, released});
    }
  }
  return {engine, initial, observations,
    scope:'Retained heap counter deltas after explicit GC; no physical-residency or exact-header claim. Same-length empty-root arrays control root storage; all immutable links and payloads checked in Wasm.'};
}
