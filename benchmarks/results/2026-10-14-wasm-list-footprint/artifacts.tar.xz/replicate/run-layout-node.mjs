import fs from 'node:fs';
import v8 from 'node:v8';
import {runProbe} from './heap-layout-common.mjs';
const bytes = fs.readFileSync(new URL('./list-layout-probe.wasm', import.meta.url));
const result = await runProbe(bytes, globalThis.gc, () => v8.getHeapStatistics().used_heap_size,
  {node:process.version, v8:process.versions.v8, pointerCompression:process.config.variables.v8_enable_pointer_compression});
fs.writeFileSync(new URL('./node-heap-layout.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log('Node heap probe complete');
