"""Archive the explicit diagnostic files; never archive browser profiles."""

import base64
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path(__file__).resolve().parent
REPORT = ROOT.parent / 'benchmarks/results/2026-10-14-wasm-list-footprint'
FILES = {}


# ---- Source identities and embedded modules ----

def digest(data):
    return hashlib.sha256(data).hexdigest()


def include(name, path=None):
    FILES[name] = (path or ROOT / name).read_bytes()


for name, entry in json.loads((ROOT / 'heap-layout-freeze.json').read_text())['files'].items():
    assert digest((ROOT / name).read_bytes()) == entry['sha256'], name
for name, expected in json.loads((ROOT / 'replicate/source-freeze.json').read_text()).items():
    assert digest((ROOT / 'replicate' / name).read_bytes()) == expected, name

for prefix in ('', 'replicate/'):
    for name in ('list-layout-probe.wat', 'list-layout-probe.wasm',
                 'heap-layout-common.mjs', 'run-layout-node.mjs',
                 'run-layout-chromium.mjs', 'browser-probe/heap.html',
                 'node-heap-layout.json', 'chromium-heap-layout.json',
                 'chromium-heap-process.json'):
        include(prefix + name)
    page = FILES[prefix + 'browser-probe/heap.html'].decode()
    embedded = re.search(r'atob\("([A-Za-z0-9+/=]+)"\)', page).group(1)
    assert base64.b64decode(embedded) == FILES[prefix + 'list-layout-probe.wasm']
    source = FILES[prefix + 'heap-layout-common.mjs'].decode().replace('export async', 'async')
    assert source in page

for name in ('heap-layout-freeze.json', 'replicate/source-freeze.json',
             'heap-layout-tools.json', 'heap-layout-rebuild.json',
             'heap-layout-summary.json', 'prepare-browser.py', 'archive-layout.py'):
    include(name)
for name in ('identity.json', 'small.html', 'full.html', 'small-run.json',
             'small-native-run.json', 'full-diagnostic-run.json', 'code-run.json',
             'code-file-run.json', 'code-local-run.json', 'code.stdout', 'code.stderr'):
    include('browser-probe/' + name)
workload = json.loads(FILES['browser-probe/identity.json'])
include('mperm.wasm', Path(workload['module']))
assert digest(FILES['mperm.wasm']) == workload['sha256']


# ---- Stable regular-file archive ----

archive = REPORT / 'artifacts.tar.xz'
with tarfile.open(archive, 'w:xz') as output:
    for name, payload in sorted(FILES.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(payload)
        entry.mode = 0o644
        output.addfile(entry, io.BytesIO(payload))
manifest = dict(archive_sha256=digest(archive.read_bytes()),
                files={name: digest(data) for name, data in sorted(FILES.items())})
(REPORT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(REPORT / 'summary.json').write_bytes(FILES['heap-layout-summary.json'])
print(f'Archived {len(FILES)} regular files, {archive.stat().st_size} compressed bytes')
