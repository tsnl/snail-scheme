(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-v8-gc-20261012/build/v8-worst-five/cases/wc/chez/program.scm" "/tmp/snail-v8-gc-20261012/build/v8-worst-five/cases/wc/chez/program.so"))
