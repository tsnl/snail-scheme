(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-wasm-five-20261013/build/wasm-reference/final/graph-audit/program.scm" "/tmp/snail-rust-wasm-five-20261013/build/wasm-reference/final/graph-audit/program.so"))
