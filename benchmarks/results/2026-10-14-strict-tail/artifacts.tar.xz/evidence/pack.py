"""Freeze every retained Tail/source/contract byte into a regular-file archive."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path(__file__).resolve().parents[2]
report = root / 'benchmarks/results/2026-10-14-strict-tail'
preparation = root / 'build/strict-tail-final'
members = {}


def add(path, name):
    assert name not in members
    members[name] = (path.read_bytes(), 0o755 if path.stat().st_mode & 0o111 else 0o644)


def tree(directory, prefix, predicate=lambda path: True):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and predicate(path):
            add(path, prefix + '/' + str(path.relative_to(directory)))


tree(preparation, 'preparation')
tree(root / 'build/strict-tail-attempt1', 'preliminary-records',
     lambda path: path.suffix in ('.json', '.scm', '.py', '.mjs', '.patch'))
tree(root / 'build/strict-io', 'library-contract/wasm')
tree(root / 'build/native-tests', 'library-contract/native')
tree(root / 'build/tail-checks', 'checks')
tree(root / 'build/tail-evidence', 'evidence')
tree(report, 'report', lambda path: path.name not in ('artifacts.tar.xz', 'manifest.json', 'archive-verification.json'))
contract = [root / 'scripts/test-strict-io', root / 'scripts/test-native', root / 'tests/native-input-runner.c',
            root / 'tests/native-lifecycle.c', root / 'tests/native-cleanup-observer.h', root / 'src/snail/io.sld',
            root / 'src/strict_io.rs', *sorted((root / 'tests/strict-io').glob('*'))]
for path in contract:
    add(path, 'library-contract/source/' + str(path.relative_to(root)))
native = json.loads(next((preparation / 'tail').glob('native.native-*/build.json')).read_text())
for filename, expected in native['sha256'].items():
    path = Path(filename)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    if not path.is_relative_to(preparation):
        add(path, 'native-inputs/' + str(path.relative_to(root)))
reference = root / 'benchmarks/results/2026-10-13-rust-full-suite/artifacts.tar.xz'
with tarfile.open(reference) as archive:
    source = archive.extractfile('blobs/3a9fc5b621bce175145a635ab869d0b757579af8d1da7ca8a583b231d58d9b30').read()
assert hashlib.sha256(source).hexdigest() == '3a9fc5b621bce175145a635ab869d0b757579af8d1da7ca8a583b231d58d9b30'
members['rust-reference/tail.rs'] = (source, 0o644)
files = {name: hashlib.sha256(data).hexdigest() for name, (data, _) in sorted(members.items())}
output = report / 'artifacts.tar.xz'
with tarfile.open(output, 'w:xz', preset=6) as archive:
    for name, (data, mode) in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), mode, 0
        archive.addfile(info, io.BytesIO(data))
manifest = dict(archive_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
                archive_bytes=output.stat().st_size, files=files, clean_timings=0,
                scope='Complete Tail preparation, native inputs, line-I/O contracts and separate canonical file-work audit')
(report / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Archived', len(files), 'regular files;', output.stat().st_size, 'compressed bytes')
