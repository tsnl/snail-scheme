"""Audit actual canonical file work using the unchanged optimized Tail binary."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
case = root / 'build/strict-tail-final/tail'
original = (case.parent / 'tail-host.mjs').read_text()
changes = [
    ('let eofSeen = false;', 'let eofSeen = false;\nlet readBytes = 0, writtenBytes = 0;'),
    ('    const status = wasi.wasiImport.fd_read(...args);',
     '    const status = wasi.wasiImport.fd_read(...args);\n'
     '    if (status === 0) readBytes += new DataView(instance.exports.memory.buffer).getUint32(args.at(-1), true);'),
    ('    return wasi.wasiImport.fd_write(...args);',
     '    const status = wasi.wasiImport.fd_write(...args);\n'
     '    if (status === 0 && live.get(args[0]) === config.pathnames[1])\n'
     '      writtenBytes += new DataView(instance.exports.memory.buffer).getUint32(args.at(-1), true);\n'
     '    return status;'),
    ('  observation.events = events;',
     '  observation.events = events;\n  observation.read_bytes = readBytes;\n  observation.written_bytes = writtenBytes;'),
]
observer = original
for before, after in changes:
    assert observer.count(before) == 1
    observer = observer.replace(before, after)
restored = observer
for before, after in reversed(changes):
    assert restored.count(after) == 1
    restored = restored.replace(after, before)
assert restored == original
(here / 'retention-host.mjs').write_text(observer)
spec = dict(json.loads((case / 'spec.json').read_text()), trace=True)
(here / 'spec.json').write_text(json.dumps(spec, indent=2) + '\n')
files = here / 'files'
(files / 'inputs').mkdir(parents=True, exist_ok=True)
(files / 'outputs').mkdir(parents=True, exist_ok=True)
shutil.copyfile(case / 'upstream-input.bin', files / spec['pathnames'][0])
(files / spec['pathnames'][1]).unlink(missing_ok=True)
command = ['node', '--disable-warning=ExperimentalWarning', str(here / 'retention-host.mjs'),
           str(case / 'strict.wasm'), str(here / 'spec.json'), '--validate']
run = subprocess.run(command, cwd=files, text=True, capture_output=True)
record = dict(command=command, cwd=str(files), status=run.returncode, stdout=run.stdout, stderr=run.stderr)
(here / 'retention-run.json').write_text(json.dumps(record, indent=2) + '\n')
assert run.returncode == 0 and not run.stderr
result = json.loads(run.stdout)
source, target = spec['pathnames']
ordinary = [['open', source, 0], ['delete', 0], ['open', target, 0], ['close', target, 0], ['close', source, 0]]
first = [ordinary[index] for index in (0, 2, 3, 4)]
assert [event for event in result['events'] if event[0] != 'eof'] == first + ordinary * 49
assert result['read_bytes'] == result['written_bytes'] == 50 * 4460056
assert result['barriers'] == 100 and result['result'] == '1'
actual = (files / target).read_bytes()
assert actual == (case / 'canonical-output.bin').read_bytes()
proof = dict(unchanged_binary_sha256=hashlib.sha256((case / 'strict.wasm').read_bytes()).hexdigest(),
             observer_erasure_recovers_original_host=True, iterations=50, opens=100, closes=100,
             deletes=49, read_bytes=result['read_bytes'], written_bytes=result['written_bytes'],
             output_sha256=hashlib.sha256(actual).hexdigest(), changes=changes,
             limit='WASI events establish physical read/write order; source proves full line retention before Scheme writes.')
(here / 'retained-work.json').write_text(json.dumps(proof, indent=2) + '\n')
print('PASS unchanged optimized Tail: 50 file reversals, 223002800 bytes read and written')
