(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-tail-20261014/build/strict-tail-attempt1/tail/program.scm" "/tmp/snail-strict-tail-20261014/build/strict-tail-attempt1/tail/program.so"))
