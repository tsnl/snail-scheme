(module
 (rec
  (type $type40 (sub (struct)))
  (type $1 (func (param i64 i32 i32 i64) (result i64)))
  (type $2 (func (param i32 i64 (ref $type14) i32 i32 i64) (result (ref $type14))))
  (type $call54 (func (param i32) (result (ref $type14))))
  (type $call50 (func (param (ref $type27) (ref null $type23)) (result i32)))
  (type $environment63 (struct (field (ref $type30))))
  (type $6 (func (param (ref $type33) (ref $type30)) (result i32)))
  (type $type42 (sub $type40 (struct (field (ref $type14)))))
  (type $type41 (sub $type40 (struct)))
  (type $type33 (struct (field (ref $type31))))
  (type $type23 (struct (field (ref $type14)) (field (ref null $type23))))
  (type $11 (func (param (ref $type33) (ref null $type23)) (result (ref null $type23))))
  (type $type31 (struct (field (mut i32))))
  (type $type30 (struct (field (ref $type31))))
  (type $14 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
  (type $call45 (func (param i32 i32 (ref $type14) i64) (result (ref $type14))))
  (type $16 (func (param (ref $type14) i64 i32 i32 i64) (result i32)))
  (type $call27 (func (param (ref null $environment63) (ref $type14)) (result i32)))
  (type $18 (func (param (ref $type14) (ref $type14) i32)))
  (type $19 (func (param (ref $type14) i32) (result (ref $type15))))
  (type $type15 (array (mut i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $22 (func (param i32) (result (ref $type14))))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type14 (struct (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment63))))
  (type $type20 (struct))
  (type $type13 (struct))
 )
 (type $49 (func (result i32)))
 (type $50 (func))
 (type $51 (func (param i32)))
 (type $52 (func (param i32) (result i32)))
 (type $53 (func (param i32 i32)))
 (type $54 (func (param i32) (result i64)))
 (type $55 (func (param i32 i64) (result i32)))
 (type $56 (func (param i64) (result i64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign9 (param i32 i32)))
 (import "benchmark" "path_length" (func $foreign10 (param i32) (result i64)))
 (import "benchmark" "path_character" (func $foreign11 (param i32 i64) (result i32)))
 (import "benchmark" "barrier" (func $foreign12 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type28)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type34)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type35)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type36)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global186 (mut (ref null $type37)) (ref.null none))
 (global $ready186 (mut i32) (i32.const 0))
 (global $global191 (mut (ref null $type38)) (ref.null none))
 (global $ready191 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type39)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type43)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type44)) (ref.null none))
 (global $ready144 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type45)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type46)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global152 (mut (ref null $type47)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type48)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type34)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global178 (mut (ref null $type50)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type51)) (ref.null none))
 (global $ready170 (mut i32) (i32.const 0))
 (global $global174 (mut (ref null $type52)) (ref.null none))
 (global $ready174 (mut i32) (i32.const 0))
 (global $global181 (mut (ref null $type53)) (ref.null none))
 (global $ready181 (mut i32) (i32.const 0))
 (global $global196 (mut (ref null $type54)) (ref.null none))
 (global $ready196 (mut i32) (i32.const 0))
 (global $global202 (mut (ref null $type14)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type14)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global204 (mut (ref null $type55)) (ref.null none))
 (global $ready204 (mut i32) (i32.const 0))
 (global $global207 (mut (ref null $type56)) (ref.null none))
 (global $ready207 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-new (type $22) (param $0 i32) (result (ref $type14))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type16))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type14
   (local.get $0)
   (array.new_default $type15
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $19) (param $0 (ref $type14)) (param $1 i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 1
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 2
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy-forward (type $18) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (loop $label
   (if
    (local.get $2)
    (then
     (local.set $3
      (select
       (local.get $2)
       (local.tee $3
        (select
         (local.tee $3
          (i32.sub
           (i32.const 8192)
           (local.tee $6
            (i32.and
             (local.get $4)
             (i32.const 8191)
            )
           )
          )
         )
         (local.tee $8
          (i32.sub
           (i32.const 8192)
           (local.tee $7
            (i32.and
             (local.get $5)
             (i32.const 8191)
            )
           )
          )
         )
         (i32.lt_u
          (local.get $3)
          (local.get $8)
         )
        )
       )
       (i32.lt_u
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (array.copy $type15 $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $4)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $4)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $6)
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $5)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $1)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 2
           (local.get $1)
          )
          (i32.sub
           (i32.shr_u
            (local.get $5)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $7)
      (local.get $3)
     )
     (local.set $4
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (local.set $5
      (i32.add
       (local.get $3)
       (local.get $5)
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (local.get $3)
      )
     )
     (br $label)
    )
   )
  )
 )
 (func $function41 (type $call27) (param $0 (ref null $environment63)) (param $1 (ref $type14)) (result i32)
  (local $2 i64)
  (call $foreign0)
  (if (result i32)
   (i64.eqz
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type14 0
       (local.get $1)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (struct.get $type14 1
       (local.get $1)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 0
          (local.get $1)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (array.get $type15
        (struct.get $type14 1
         (local.get $1)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $1)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (array.get $type15
          (struct.get $type14 1
           (local.get $1)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $2)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 0
              (local.get $1)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (array.get $type15
            (struct.get $type14 1
             (local.get $1)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $2)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 0
                (local.get $1)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (array.get $type15
              (struct.get $type14 1
               (local.get $1)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 0
                  (local.get $1)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (array.get $type15
                (struct.get $type14 1
                 (local.get $1)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 0
                    (local.get $1)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (array.get $type15
                  (struct.get $type14 1
                   (local.get $1)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 0
                      (local.get $1)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (array.get $type15
                    (struct.get $type14 1
                     (local.get $1)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 0
                        (local.get $1)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (array.get $type15
                      (struct.get $type14 1
                       (local.get $1)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 0
                          (local.get $1)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (array.get $type15
                        (struct.get $type14 1
                         (local.get $1)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $2)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type14 0
                            (local.get $1)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign1
                         (array.get $type15
                          (struct.get $type14 1
                           (local.get $1)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $2)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type14 0
                              (local.get $1)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign1
                           (array.get $type15
                            (struct.get $type14 1
                             (local.get $1)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $2)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type14 0
                                (local.get $1)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign1
                             (array.get $type15
                              (struct.get $type14 1
                               (local.get $1)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $2)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type14 0
                                  (local.get $1)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign1
                               (array.get $type15
                                (struct.get $type14 1
                                 (local.get $1)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $2)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type14 0
                                    (local.get $1)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign1
                                 (array.get $type15
                                  (struct.get $type14 1
                                   (local.get $1)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $2)
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type14 0
                                      (local.get $1)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign1
                                   (array.get $type15
                                    (struct.get $type14 1
                                     (local.get $1)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $2)
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type14 0
                                        (local.get $1)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign1
                                     (array.get $type15
                                      (struct.get $type14 1
                                       (local.get $1)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $2)
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type14 0
                                          (local.get $1)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign1
                                       (array.get $type15
                                        (struct.get $type14 1
                                         (local.get $1)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $2)
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type14 0
                                            (local.get $1)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign1
                                         (array.get $type15
                                          (struct.get $type14 1
                                           (local.get $1)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $2)
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type14 0
                                              (local.get $1)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign1
                                           (array.get $type15
                                            (struct.get $type14 1
                                             (local.get $1)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (if (result i32)
                                           (i64.eq
                                            (local.get $2)
                                            (i64.const 20)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if
                                             (i64.le_u
                                              (i64.extend_i32_u
                                               (struct.get $type14 0
                                                (local.get $1)
                                               )
                                              )
                                              (i64.const 20)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (call $foreign1
                                             (array.get $type15
                                              (struct.get $type14 1
                                               (local.get $1)
                                              )
                                              (i32.const 20)
                                             )
                                            )
                                            (if (result i32)
                                             (i64.eq
                                              (local.get $2)
                                              (i64.const 21)
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (if
                                               (i64.le_u
                                                (i64.extend_i32_u
                                                 (struct.get $type14 0
                                                  (local.get $1)
                                                 )
                                                )
                                                (i64.const 21)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (call $foreign1
                                               (array.get $type15
                                                (struct.get $type14 1
                                                 (local.get $1)
                                                )
                                                (i32.const 21)
                                               )
                                              )
                                              (if (result i32)
                                               (i64.eq
                                                (local.get $2)
                                                (i64.const 22)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (if
                                                 (i64.le_u
                                                  (i64.extend_i32_u
                                                   (struct.get $type14 0
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (i64.const 22)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (call $foreign1
                                                 (array.get $type15
                                                  (struct.get $type14 1
                                                   (local.get $1)
                                                  )
                                                  (i32.const 22)
                                                 )
                                                )
                                                (if (result i32)
                                                 (i64.eq
                                                  (local.get $2)
                                                  (i64.const 23)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if
                                                   (i64.le_u
                                                    (i64.extend_i32_u
                                                     (struct.get $type14 0
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (i64.const 23)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (call $foreign1
                                                   (array.get $type15
                                                    (struct.get $type14 1
                                                     (local.get $1)
                                                    )
                                                    (i32.const 23)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (i64.eq
                                                    (local.get $2)
                                                    (i64.const 24)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (if
                                                     (i64.le_u
                                                      (i64.extend_i32_u
                                                       (struct.get $type14 0
                                                        (local.get $1)
                                                       )
                                                      )
                                                      (i64.const 24)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (call $foreign1
                                                     (array.get $type15
                                                      (call $string-block
                                                       (local.get $1)
                                                       (i32.const 24)
                                                      )
                                                      (i32.const 24)
                                                     )
                                                    )
                                                    (return_call $function42
                                                     (local.get $1)
                                                     (local.get $2)
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (i64.const 25)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $16) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function44 (type $call27) (param $0 (ref null $environment63)) (param $1 (ref $type14)) (result i32)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (global.get $global109)
    )
    (local.get $1)
   )
  )
  (call $foreign3)
  (i32.const 0)
 )
 (func $function52 (type $call45) (param $0 i32) (param $1 i32) (param $2 (ref $type14)) (param $3 i64) (result (ref $type14))
  (local $4 (ref $type14))
  (local $5 i64)
  (local $6 i32)
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $6
     (i32.eq
      (local.get $1)
      (i32.const -1)
     )
    )
    (then
     (local.get $6)
    )
    (else
     (if (result i32)
      (local.tee $6
       (i32.eq
        (local.get $1)
        (i32.const 10)
       )
      )
      (then
       (local.get $6)
      )
      (else
       (i32.eq
        (local.get $1)
        (i32.const 13)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eq
      (local.get $1)
      (i32.const 13)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready144)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global144)
       )
      )
      (if
       (i32.eq
        (call $foreign8
         (local.get $0)
        )
        (i32.const 10)
       )
       (then
        (drop
         (call $foreign7
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $2)
       )
      )
      (local.get $3)
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready81)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (if (result (ref $type14))
       (if (result i32)
        (local.tee $0
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
        )
        (then
         (local.get $0)
        )
        (else
         (i64.lt_s
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $2)
           )
          )
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967294)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (call $string-new
          (i32.wrap_i64
           (local.get $3)
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.lt_u
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $4)
           )
          )
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (call $string-copy-forward
         (local.get $4)
         (local.get $2)
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready147)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (if
     (i64.ge_s
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $2)
       )
      )
     )
     (then
      (local.set $2
       (if (result (ref $type14))
        (i64.eq
         (local.get $3)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.tee $5
            (if (result i64)
             (i64.eqz
              (local.get $3)
             )
             (then
              (i64.const 64)
             )
             (else
              (select
               (i64.const 4294967294)
               (i64.shl
                (local.get $3)
                (i64.const 1)
               )
               (i64.gt_s
                (local.get $3)
                (i64.const 2147483647)
               )
              )
             )
            )
           )
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (call $string-new
           (i32.wrap_i64
            (local.get $5)
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.extend_i32_u
            (struct.get $type14 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_u
           (i64.extend_i32_u
            (struct.get $type14 0
             (local.get $4)
            )
           )
           (local.get $3)
          )
          (then
           (unreachable)
          )
         )
         (call $string-copy-forward
          (local.get $4)
          (local.get $2)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.extend_i32_s
        (local.get $1)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $1
        (i32.wrap_i64
         (local.get $3)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 1
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 2
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $1)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $1)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (local.set $1
     (call $foreign7
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function57 (type $14) (param $0 (ref $type14)) (param $1 (ref $type30)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (call $foreign9
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function61 (type $11) (param $0 (ref $type33)) (param $1 (ref null $type23)) (result (ref null $type23))
  (local $2 (ref $type40))
  (local $3 (ref $type14))
  (local $4 (ref $type23))
  (local $5 i32)
  (local $6 i32)
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (local.set $2
   (if (result (ref $type40))
    (i32.eq
     (local.tee $6
      (call $foreign7
       (local.tee $5
        (struct.get $type31 0
         (struct.get $type33 0
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type41)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $3
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (struct.new $type42
      (call $function52
       (local.get $5)
       (local.get $6)
       (local.get $3)
       (i64.const 0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if (result (ref null $type23))
   (if (result i32)
    (ref.test (ref $type42)
     (local.get $2)
    )
    (then
     (drop
      (ref.cast (ref $type42)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type42)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.new $type23
      (struct.get $type42 0
       (ref.cast (ref $type42)
        (local.get $2)
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready170)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global170)
     )
    )
    (return_call $function61
     (local.get $0)
     (local.get $4)
    )
   )
  )
 )
 (func $function62 (type $6) (param $0 (ref $type33)) (param $1 (ref $type30)) (result i32)
  (local $2 (ref null $type23))
  (local $3 (ref $type27))
  (if
   (i32.eqz
    (global.get $ready170)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global170)
   )
  )
  (local.set $2
   (call $function61
    (local.get $0)
    (ref.null none)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call27
      (struct.get $type27 1
       (local.tee $3
        (struct.new $type27
         (ref.func $function63)
         (struct.new $environment63
          (local.get $1)
         )
        )
       )
      )
      (struct.get $type23 0
       (local.get $2)
      )
      (struct.get $type27 0
       (local.get $3)
      )
     )
    )
    (local.set $2
     (struct.get $type23 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready178)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (call_ref $call27
        (struct.get $type27 1
         (local.get $3)
        )
        (struct.get $type23 0
         (local.get $2)
        )
        (struct.get $type27 0
         (local.get $3)
        )
       )
      )
      (local.set $2
       (struct.get $type23 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready178)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (if (result i32)
       (ref.is_null
        (local.get $2)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (call_ref $call27
          (struct.get $type27 1
           (local.get $3)
          )
          (struct.get $type23 0
           (local.get $2)
          )
          (struct.get $type27 0
           (local.get $3)
          )
         )
        )
        (local.set $2
         (struct.get $type23 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready178)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global178)
         )
        )
        (if (result i32)
         (ref.is_null
          (local.get $2)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (call_ref $call27
            (struct.get $type27 1
             (local.get $3)
            )
            (struct.get $type23 0
             (local.get $2)
            )
            (struct.get $type27 0
             (local.get $3)
            )
           )
          )
          (local.set $2
           (struct.get $type23 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (global.get $ready178)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global178)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (call_ref $call27
              (struct.get $type27 1
               (local.get $3)
              )
              (struct.get $type23 0
               (local.get $2)
              )
              (struct.get $type27 0
               (local.get $3)
              )
             )
            )
            (local.set $2
             (struct.get $type23 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready178)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global178)
             )
            )
            (if (result i32)
             (ref.is_null
              (local.get $2)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (call_ref $call27
                (struct.get $type27 1
                 (local.get $3)
                )
                (struct.get $type23 0
                 (local.get $2)
                )
                (struct.get $type27 0
                 (local.get $3)
                )
               )
              )
              (local.set $2
               (struct.get $type23 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready178)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global178)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (call_ref $call27
                  (struct.get $type27 1
                   (local.get $3)
                  )
                  (struct.get $type23 0
                   (local.get $2)
                  )
                  (struct.get $type27 0
                   (local.get $3)
                  )
                 )
                )
                (local.set $2
                 (struct.get $type23 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready178)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global178)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (call_ref $call27
                    (struct.get $type27 1
                     (local.get $3)
                    )
                    (struct.get $type23 0
                     (local.get $2)
                    )
                    (struct.get $type27 0
                     (local.get $3)
                    )
                   )
                  )
                  (local.set $2
                   (struct.get $type23 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready178)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global178)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (call_ref $call27
                      (struct.get $type27 1
                       (local.get $3)
                      )
                      (struct.get $type23 0
                       (local.get $2)
                      )
                      (struct.get $type27 0
                       (local.get $3)
                      )
                     )
                    )
                    (local.set $2
                     (struct.get $type23 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready178)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global178)
                     )
                    )
                    (if (result i32)
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (call_ref $call27
                        (struct.get $type27 1
                         (local.get $3)
                        )
                        (struct.get $type23 0
                         (local.get $2)
                        )
                        (struct.get $type27 0
                         (local.get $3)
                        )
                       )
                      )
                      (local.set $2
                       (struct.get $type23 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready178)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global178)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (call_ref $call27
                          (struct.get $type27 1
                           (local.get $3)
                          )
                          (struct.get $type23 0
                           (local.get $2)
                          )
                          (struct.get $type27 0
                           (local.get $3)
                          )
                         )
                        )
                        (local.set $2
                         (struct.get $type23 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready178)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global178)
                         )
                        )
                        (if (result i32)
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (drop
                           (call_ref $call27
                            (struct.get $type27 1
                             (local.get $3)
                            )
                            (struct.get $type23 0
                             (local.get $2)
                            )
                            (struct.get $type27 0
                             (local.get $3)
                            )
                           )
                          )
                          (local.set $2
                           (struct.get $type23 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready178)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global178)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (call_ref $call27
                              (struct.get $type27 1
                               (local.get $3)
                              )
                              (struct.get $type23 0
                               (local.get $2)
                              )
                              (struct.get $type27 0
                               (local.get $3)
                              )
                             )
                            )
                            (local.set $2
                             (struct.get $type23 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready178)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global178)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (call_ref $call27
                                (struct.get $type27 1
                                 (local.get $3)
                                )
                                (struct.get $type23 0
                                 (local.get $2)
                                )
                                (struct.get $type27 0
                                 (local.get $3)
                                )
                               )
                              )
                              (local.set $2
                               (struct.get $type23 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready178)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global178)
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (call_ref $call27
                                  (struct.get $type27 1
                                   (local.get $3)
                                  )
                                  (struct.get $type23 0
                                   (local.get $2)
                                  )
                                  (struct.get $type27 0
                                   (local.get $3)
                                  )
                                 )
                                )
                                (local.set $2
                                 (struct.get $type23 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready178)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global178)
                                 )
                                )
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (call_ref $call27
                                    (struct.get $type27 1
                                     (local.get $3)
                                    )
                                    (struct.get $type23 0
                                     (local.get $2)
                                    )
                                    (struct.get $type27 0
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (local.set $2
                                   (struct.get $type23 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready178)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global178)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (call_ref $call27
                                      (struct.get $type27 1
                                       (local.get $3)
                                      )
                                      (struct.get $type23 0
                                       (local.get $2)
                                      )
                                      (struct.get $type27 0
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (local.set $2
                                     (struct.get $type23 1
                                      (local.get $2)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready178)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global178)
                                     )
                                    )
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $2)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (drop
                                       (call_ref $call27
                                        (struct.get $type27 1
                                         (local.get $3)
                                        )
                                        (struct.get $type23 0
                                         (local.get $2)
                                        )
                                        (struct.get $type27 0
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (local.set $2
                                       (struct.get $type23 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready178)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global178)
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (call_ref $call27
                                          (struct.get $type27 1
                                           (local.get $3)
                                          )
                                          (struct.get $type23 0
                                           (local.get $2)
                                          )
                                          (struct.get $type27 0
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (local.set $2
                                         (struct.get $type23 1
                                          (local.get $2)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready178)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global178)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (drop
                                           (call_ref $call27
                                            (struct.get $type27 1
                                             (local.get $3)
                                            )
                                            (struct.get $type23 0
                                             (local.get $2)
                                            )
                                            (struct.get $type27 0
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (local.set $2
                                           (struct.get $type23 1
                                            (local.get $2)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready178)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global178)
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (drop
                                             (call_ref $call27
                                              (struct.get $type27 1
                                               (local.get $3)
                                              )
                                              (struct.get $type23 0
                                               (local.get $2)
                                              )
                                              (struct.get $type27 0
                                               (local.get $3)
                                              )
                                             )
                                            )
                                            (local.set $2
                                             (struct.get $type23 1
                                              (local.get $2)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready178)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global178)
                                             )
                                            )
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $2)
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (drop
                                               (call_ref $call27
                                                (struct.get $type27 1
                                                 (local.get $3)
                                                )
                                                (struct.get $type23 0
                                                 (local.get $2)
                                                )
                                                (struct.get $type27 0
                                                 (local.get $3)
                                                )
                                               )
                                              )
                                              (local.set $2
                                               (struct.get $type23 1
                                                (local.get $2)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready178)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global178)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (drop
                                                 (call_ref $call27
                                                  (struct.get $type27 1
                                                   (local.get $3)
                                                  )
                                                  (struct.get $type23 0
                                                   (local.get $2)
                                                  )
                                                  (struct.get $type27 0
                                                   (local.get $3)
                                                  )
                                                 )
                                                )
                                                (local.set $2
                                                 (struct.get $type23 1
                                                  (local.get $2)
                                                 )
                                                )
                                                (if
                                                 (i32.eqz
                                                  (global.get $ready178)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global178)
                                                 )
                                                )
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $2)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (drop
                                                   (call_ref $call27
                                                    (struct.get $type27 1
                                                     (local.get $3)
                                                    )
                                                    (struct.get $type23 0
                                                     (local.get $2)
                                                    )
                                                    (struct.get $type27 0
                                                     (local.get $3)
                                                    )
                                                   )
                                                  )
                                                  (local.set $2
                                                   (struct.get $type23 1
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready178)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global178)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $2)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (drop
                                                     (call_ref $call27
                                                      (struct.get $type27 1
                                                       (local.get $3)
                                                      )
                                                      (struct.get $type23 0
                                                       (local.get $2)
                                                      )
                                                      (struct.get $type27 0
                                                       (local.get $3)
                                                      )
                                                     )
                                                    )
                                                    (local.set $2
                                                     (struct.get $type23 1
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready178)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global178)
                                                     )
                                                    )
                                                    (return_call $function64
                                                     (local.get $3)
                                                     (local.get $2)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function63 (type $call27) (param $0 (ref null $environment63)) (param $1 (ref $type14)) (result i32)
  (local $2 (ref $type30))
  (local $scratch (ref $type30))
  (local.set $2
   (struct.get $environment63 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (drop
   (call $function57
    (local.get $1)
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type14 0
      (local.get $1)
     )
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (call $foreign9
   (struct.get $type31 0
    (struct.get $type30 0
     (block (result (ref $type30))
      (local.set $scratch
       (struct.get $environment63 0
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (if
       (i32.eqz
        (global.get $ready152)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global152)
       )
      )
      (local.get $scratch)
     )
    )
   )
   (i32.const 10)
  )
  (i32.const 0)
 )
 (func $function64 (type $call50) (param $0 (ref $type27)) (param $1 (ref null $type23)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call27
      (struct.get $type27 1
       (local.get $0)
      )
      (struct.get $type23 0
       (local.get $1)
      )
      (struct.get $type27 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type23 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready178)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (return_call $function64
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function70 (type $call54) (param $0 i32) (result (ref $type14))
  (local $1 (ref $type14))
  (local $2 i32)
  (local $3 i64)
  (local.set $3
   (call $foreign10
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call $string-new
    (i32.wrap_i64
     (local.get $3)
    )
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $2
     (call $foreign11
      (local.get $0)
      (i64.const 0)
     )
    )
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (struct.get $type14 1
      (local.get $1)
     )
     (i32.const 0)
     (local.get $2)
    )
    (if (result (ref $type14))
     (i64.eq
      (local.get $3)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $2
       (call $foreign11
        (local.get $0)
        (i64.const 1)
       )
      )
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 0
          (local.get $1)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type15
       (struct.get $type14 1
        (local.get $1)
       )
       (i32.const 1)
       (local.get $2)
      )
      (if (result (ref $type14))
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (local.set $2
         (call $foreign11
          (local.get $0)
          (i64.const 2)
         )
        )
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $1)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type15
         (struct.get $type14 1
          (local.get $1)
         )
         (i32.const 2)
         (local.get $2)
        )
        (if (result (ref $type14))
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (local.set $2
           (call $foreign11
            (local.get $0)
            (i64.const 3)
           )
          )
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 0
              (local.get $1)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (array.set $type15
           (struct.get $type14 1
            (local.get $1)
           )
           (i32.const 3)
           (local.get $2)
          )
          (if (result (ref $type14))
           (i64.eq
            (local.get $3)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (local.set $2
             (call $foreign11
              (local.get $0)
              (i64.const 4)
             )
            )
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 0
                (local.get $1)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (array.set $type15
             (struct.get $type14 1
              (local.get $1)
             )
             (i32.const 4)
             (local.get $2)
            )
            (if (result (ref $type14))
             (i64.eq
              (local.get $3)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (local.set $2
               (call $foreign11
                (local.get $0)
                (i64.const 5)
               )
              )
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 0
                  (local.get $1)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (array.set $type15
               (struct.get $type14 1
                (local.get $1)
               )
               (i32.const 5)
               (local.get $2)
              )
              (if (result (ref $type14))
               (i64.eq
                (local.get $3)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (local.set $2
                 (call $foreign11
                  (local.get $0)
                  (i64.const 6)
                 )
                )
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 0
                    (local.get $1)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.set $type15
                 (struct.get $type14 1
                  (local.get $1)
                 )
                 (i32.const 6)
                 (local.get $2)
                )
                (if (result (ref $type14))
                 (i64.eq
                  (local.get $3)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (local.set $2
                   (call $foreign11
                    (local.get $0)
                    (i64.const 7)
                   )
                  )
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 0
                      (local.get $1)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (array.set $type15
                   (struct.get $type14 1
                    (local.get $1)
                   )
                   (i32.const 7)
                   (local.get $2)
                  )
                  (if (result (ref $type14))
                   (i64.eq
                    (local.get $3)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (local.set $2
                     (call $foreign11
                      (local.get $0)
                      (i64.const 8)
                     )
                    )
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 0
                        (local.get $1)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (array.set $type15
                     (struct.get $type14 1
                      (local.get $1)
                     )
                     (i32.const 8)
                     (local.get $2)
                    )
                    (if (result (ref $type14))
                     (i64.eq
                      (local.get $3)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (local.set $2
                       (call $foreign11
                        (local.get $0)
                        (i64.const 9)
                       )
                      )
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 0
                          (local.get $1)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (array.set $type15
                       (struct.get $type14 1
                        (local.get $1)
                       )
                       (i32.const 9)
                       (local.get $2)
                      )
                      (if (result (ref $type14))
                       (i64.eq
                        (local.get $3)
                        (i64.const 10)
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (local.set $2
                         (call $foreign11
                          (local.get $0)
                          (i64.const 10)
                         )
                        )
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type14 0
                            (local.get $1)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (array.set $type15
                         (struct.get $type14 1
                          (local.get $1)
                         )
                         (i32.const 10)
                         (local.get $2)
                        )
                        (if (result (ref $type14))
                         (i64.eq
                          (local.get $3)
                          (i64.const 11)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (local.set $2
                           (call $foreign11
                            (local.get $0)
                            (i64.const 11)
                           )
                          )
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type14 0
                              (local.get $1)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (array.set $type15
                           (struct.get $type14 1
                            (local.get $1)
                           )
                           (i32.const 11)
                           (local.get $2)
                          )
                          (if (result (ref $type14))
                           (i64.eq
                            (local.get $3)
                            (i64.const 12)
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (local.set $2
                             (call $foreign11
                              (local.get $0)
                              (i64.const 12)
                             )
                            )
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type14 0
                                (local.get $1)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (array.set $type15
                             (struct.get $type14 1
                              (local.get $1)
                             )
                             (i32.const 12)
                             (local.get $2)
                            )
                            (if (result (ref $type14))
                             (i64.eq
                              (local.get $3)
                              (i64.const 13)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (local.set $2
                               (call $foreign11
                                (local.get $0)
                                (i64.const 13)
                               )
                              )
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type14 0
                                  (local.get $1)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (array.set $type15
                               (struct.get $type14 1
                                (local.get $1)
                               )
                               (i32.const 13)
                               (local.get $2)
                              )
                              (if (result (ref $type14))
                               (i64.eq
                                (local.get $3)
                                (i64.const 14)
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (local.set $2
                                 (call $foreign11
                                  (local.get $0)
                                  (i64.const 14)
                                 )
                                )
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type14 0
                                    (local.get $1)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (array.set $type15
                                 (struct.get $type14 1
                                  (local.get $1)
                                 )
                                 (i32.const 14)
                                 (local.get $2)
                                )
                                (if (result (ref $type14))
                                 (i64.eq
                                  (local.get $3)
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (local.set $2
                                   (call $foreign11
                                    (local.get $0)
                                    (i64.const 15)
                                   )
                                  )
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type14 0
                                      (local.get $1)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (array.set $type15
                                   (struct.get $type14 1
                                    (local.get $1)
                                   )
                                   (i32.const 15)
                                   (local.get $2)
                                  )
                                  (if (result (ref $type14))
                                   (i64.eq
                                    (local.get $3)
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (local.set $2
                                     (call $foreign11
                                      (local.get $0)
                                      (i64.const 16)
                                     )
                                    )
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type14 0
                                        (local.get $1)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (array.set $type15
                                     (struct.get $type14 1
                                      (local.get $1)
                                     )
                                     (i32.const 16)
                                     (local.get $2)
                                    )
                                    (if (result (ref $type14))
                                     (i64.eq
                                      (local.get $3)
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (local.set $2
                                       (call $foreign11
                                        (local.get $0)
                                        (i64.const 17)
                                       )
                                      )
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type14 0
                                          (local.get $1)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (array.set $type15
                                       (struct.get $type14 1
                                        (local.get $1)
                                       )
                                       (i32.const 17)
                                       (local.get $2)
                                      )
                                      (if (result (ref $type14))
                                       (i64.eq
                                        (local.get $3)
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (local.set $2
                                         (call $foreign11
                                          (local.get $0)
                                          (i64.const 18)
                                         )
                                        )
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type14 0
                                            (local.get $1)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (array.set $type15
                                         (struct.get $type14 1
                                          (local.get $1)
                                         )
                                         (i32.const 18)
                                         (local.get $2)
                                        )
                                        (if (result (ref $type14))
                                         (i64.eq
                                          (local.get $3)
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (local.set $2
                                           (call $foreign11
                                            (local.get $0)
                                            (i64.const 19)
                                           )
                                          )
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type14 0
                                              (local.get $1)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (array.set $type15
                                           (struct.get $type14 1
                                            (local.get $1)
                                           )
                                           (i32.const 19)
                                           (local.get $2)
                                          )
                                          (if (result (ref $type14))
                                           (i64.eq
                                            (local.get $3)
                                            (i64.const 20)
                                           )
                                           (then
                                            (local.get $1)
                                           )
                                           (else
                                            (local.set $2
                                             (call $foreign11
                                              (local.get $0)
                                              (i64.const 20)
                                             )
                                            )
                                            (if
                                             (i64.le_u
                                              (i64.extend_i32_u
                                               (struct.get $type14 0
                                                (local.get $1)
                                               )
                                              )
                                              (i64.const 20)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (array.set $type15
                                             (struct.get $type14 1
                                              (local.get $1)
                                             )
                                             (i32.const 20)
                                             (local.get $2)
                                            )
                                            (if (result (ref $type14))
                                             (i64.eq
                                              (local.get $3)
                                              (i64.const 21)
                                             )
                                             (then
                                              (local.get $1)
                                             )
                                             (else
                                              (local.set $2
                                               (call $foreign11
                                                (local.get $0)
                                                (i64.const 21)
                                               )
                                              )
                                              (if
                                               (i64.le_u
                                                (i64.extend_i32_u
                                                 (struct.get $type14 0
                                                  (local.get $1)
                                                 )
                                                )
                                                (i64.const 21)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (array.set $type15
                                               (struct.get $type14 1
                                                (local.get $1)
                                               )
                                               (i32.const 21)
                                               (local.get $2)
                                              )
                                              (if (result (ref $type14))
                                               (i64.eq
                                                (local.get $3)
                                                (i64.const 22)
                                               )
                                               (then
                                                (local.get $1)
                                               )
                                               (else
                                                (local.set $2
                                                 (call $foreign11
                                                  (local.get $0)
                                                  (i64.const 22)
                                                 )
                                                )
                                                (if
                                                 (i64.le_u
                                                  (i64.extend_i32_u
                                                   (struct.get $type14 0
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (i64.const 22)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (array.set $type15
                                                 (struct.get $type14 1
                                                  (local.get $1)
                                                 )
                                                 (i32.const 22)
                                                 (local.get $2)
                                                )
                                                (if (result (ref $type14))
                                                 (i64.eq
                                                  (local.get $3)
                                                  (i64.const 23)
                                                 )
                                                 (then
                                                  (local.get $1)
                                                 )
                                                 (else
                                                  (local.set $2
                                                   (call $foreign11
                                                    (local.get $0)
                                                    (i64.const 23)
                                                   )
                                                  )
                                                  (if
                                                   (i64.le_u
                                                    (i64.extend_i32_u
                                                     (struct.get $type14 0
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (i64.const 23)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (array.set $type15
                                                   (struct.get $type14 1
                                                    (local.get $1)
                                                   )
                                                   (i32.const 23)
                                                   (local.get $2)
                                                  )
                                                  (if (result (ref $type14))
                                                   (i64.eq
                                                    (local.get $3)
                                                    (i64.const 24)
                                                   )
                                                   (then
                                                    (local.get $1)
                                                   )
                                                   (else
                                                    (local.set $2
                                                     (call $foreign11
                                                      (local.get $0)
                                                      (i64.const 24)
                                                     )
                                                    )
                                                    (if
                                                     (i64.le_u
                                                      (i64.extend_i32_u
                                                       (struct.get $type14 0
                                                        (local.get $1)
                                                       )
                                                      )
                                                      (i64.const 24)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (array.set $type15
                                                     (call $string-block
                                                      (local.get $1)
                                                      (i32.const 24)
                                                     )
                                                     (i32.const 24)
                                                     (local.get $2)
                                                    )
                                                    (return_call $function71
                                                     (local.get $0)
                                                     (local.get $3)
                                                     (local.get $1)
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (i64.const 25)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function71 (type $2) (param $0 i32) (param $1 i64) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type14))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type14))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $6
     (call $foreign11
      (local.get $0)
      (local.get $5)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (call $string-block
      (local.get $2)
      (local.tee $7
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
     (i32.and
      (local.get $7)
      (i32.const 8191)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function74 (type $1) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $6 (ref $type31))
  (local $7 (ref $type33))
  (local $8 (ref $type30))
  (local $9 i32)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready202)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (if
     (i32.eqz
      (global.get $ready204)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global204)
     )
    )
    (if
     (i32.eqz
      (call $foreign12)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready203)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (if
     (i32.eqz
      (global.get $ready204)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global204)
     )
    )
    (if
     (i32.eqz
      (call $foreign12)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready181)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global181)
     )
    )
    (if
     (i32.eqz
      (global.get $ready191)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global191)
     )
    )
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function41
      (struct.get $type27 1
       (global.get $global109)
      )
      (local.get $5)
     )
    )
    (local.set $7
     (struct.new $type33
      (struct.new $type31
       (call $foreign5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready114)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global114)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function41
      (struct.get $type27 1
       (global.get $global109)
      )
      (local.get $4)
     )
    )
    (if
     (i32.eq
      (call $foreign2)
      (i32.const 1)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready116)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type27 1
        (global.get $global116)
       )
      )
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call $function41
        (struct.get $type27 1
         (global.get $global109)
        )
        (local.get $4)
       )
      )
      (call $foreign3)
     )
    )
    (if
     (i32.eqz
      (global.get $ready186)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global186)
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function41
      (struct.get $type27 1
       (global.get $global109)
      )
      (local.get $4)
     )
    )
    (local.set $8
     (struct.new $type30
      (struct.new $type31
       (call $foreign4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready174)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global174)
     )
    )
    (drop
     (call $function62
      (local.get $7)
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (global.get $ready122)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.ne
      (local.tee $9
       (struct.get $type31 0
        (local.tee $6
         (struct.get $type30 0
          (local.get $8)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (struct.set $type31 0
       (local.get $6)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $9)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.ne
      (local.tee $9
       (struct.get $type31 0
        (local.tee $6
         (struct.get $type33 0
          (local.get $7)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (struct.set $type31 0
       (local.get $6)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $9)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
   (else
    (i64.const 1)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready207)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global207)
   )
  )
  (return_call $function74
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type20)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global109
   (struct.new $type27
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type28)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global116
   (struct.new $type27
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type29)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type32)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type34)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type35)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type36)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global186
   (struct.new_default $type37)
  )
  (global.set $ready186
   (i32.const 1)
  )
  (global.set $global191
   (struct.new_default $type38)
  )
  (global.set $ready191
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type39)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type43)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global144
   (struct.new_default $type44)
  )
  (global.set $ready144
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type45)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global147
   (struct.new_default $type46)
  )
  (global.set $ready147
   (i32.const 1)
  )
  (global.set $global152
   (struct.new_default $type47)
  )
  (global.set $ready152
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type48)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type34)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global178
   (struct.new_default $type50)
  )
  (global.set $ready178
   (i32.const 1)
  )
  (global.set $global170
   (struct.new_default $type51)
  )
  (global.set $ready170
   (i32.const 1)
  )
  (global.set $global174
   (struct.new_default $type52)
  )
  (global.set $ready174
   (i32.const 1)
  )
  (global.set $global181
   (struct.new_default $type53)
  )
  (global.set $ready181
   (i32.const 1)
  )
  (global.set $global196
   (struct.new_default $type54)
  )
  (global.set $ready196
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global196)
   )
  )
  (global.set $global202
   (call $function70
    (i32.const 0)
   )
  )
  (global.set $ready202
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready196)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global196)
   )
  )
  (global.set $global203
   (call $function70
    (i32.const 1)
   )
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global204
   (struct.new_default $type55)
  )
  (global.set $ready204
   (i32.const 1)
  )
  (global.set $global207
   (struct.new_default $type56)
  )
  (global.set $ready207
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

