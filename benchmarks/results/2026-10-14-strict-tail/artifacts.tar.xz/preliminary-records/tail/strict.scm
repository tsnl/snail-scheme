(import (snail strict) (rename (snail io) (eof-object? line-eof?)))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(: tail-for-each (All (T) (-> (-> T Unit) (List T) Unit)))
(define (tail-for-each procedure values)
  (unless (null? values)
    (procedure (car values))
    (tail-for-each procedure (cdr values))))
(define (hide count x) (hide-i64 x))
(: tail-r-aux (-> InputPort (List String) (List String)))
(: echo-lines-in-reverse-order (-> InputPort OutputPort Unit))
(: go (-> String String Unit))
;;; TAIL -- One of the Kernighan and Van Wyk benchmarks.
;;;
;;; Modified for R7RS by Will Clinger.
;;;
;;; The key idea of this benchmark is that, for each iteration,
;;; the entire input is read line by line before any output
;;; is produced, and the lines are then written to the output
;;; in the reverse of the order in which they were read.


(define (tail-r-aux port file-so-far)
  (let ((x (read-line port)))
    (if (line-eof? x)
        file-so-far
        (tail-r-aux port (cons (line-text x) file-so-far)))))

(define (echo-lines-in-reverse-order in out)
  (tail-for-each (lambda (line) (write-string line out) (newline out))
            (tail-r-aux in '())))

(define (go input output)
  (call-with-input-file
      input
    (lambda (in)
      (when (file-exists? output)
        (delete-file output))
      (call-with-output-file
          output
        (lambda (out)
          (echo-lines-in-reverse-order in out))))))

(define-extern path-length "benchmark" "path_length" (-> I32 I64))
(define-extern path-character "benchmark" "path_character" (-> I32 I64 Char))
(: input-path (-> I32 String))
(define (input-path which)
  (let* ((size (path-length which)) (text (make-string size)))
    (let loop ((index 0))
      (if (= index size) text
          (begin (string-set! text index (path-character which index)) (loop (+ index 1)))))))
(define input0 (input-path (ann 0 I32)))
(define input1 (input-path (ann 1 I32)))
(: hide-path (-> I64 String String))
(define (hide-path count value) (if (barrier) value (unreachable)))

(: bench (-> I64 I64))
(define (bench count) (let loop ((i 0))
  (if (< i count)
      (begin (go (hide-path count input0) (hide-path count input1)) (loop (+ i 1)))
      1)))
(unit)
