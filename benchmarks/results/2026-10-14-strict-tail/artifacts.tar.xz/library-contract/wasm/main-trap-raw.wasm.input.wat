(module
 (rec
  (type $top-scalar (struct (field i32) (field i64)))
  (type $top-reference (struct (field i32) (field eqref)))
  (type $call0 (func (param eqref i64 f64) (result f64)))
  (type $type0 (struct (field (ref $call0)) (field eqref)))
  (type $call1 (func (param eqref f64 i64) (result f64)))
  (type $type1 (struct (field (ref $call1)) (field eqref)))
  (type $call2 (func (param eqref i64 f64) (result i32)))
  (type $type2 (struct (field (ref $call2)) (field eqref)))
  (type $call3 (func (param eqref f64 i64) (result i32)))
  (type $type3 (struct (field (ref $call3)) (field eqref)))
  (type $call4 (func (param eqref) (result i32)))
  (type $type4 (struct (field (ref $call4)) (field eqref)))
  (type $call5 (func (param eqref) (result i64)))
  (type $type5 (struct (field (ref $call5)) (field eqref)))
  (type $call6 (func (param eqref) (result f32)))
  (type $type6 (struct (field (ref $call6)) (field eqref)))
  (type $call7 (func (param eqref) (result f64)))
  (type $type7 (struct (field (ref $call7)) (field eqref)))
  (type $call8 (func (param eqref) (result i32)))
  (type $type8 (struct (field (ref $call8)) (field eqref)))
  (type $call9 (func (param eqref) (result i32)))
  (type $type9 (struct (field (ref $call9)) (field eqref)))
  (type $call10 (func (param eqref) (result i32)))
  (type $type10 (struct (field (ref $call10)) (field eqref)))
  (type $call11 (func (param eqref (ref null $type12)) (result i64)))
  (type $type11 (struct (field (ref $call11)) (field eqref)))
  (type $type12 (struct (field i32) (field (ref null $type12))))
  (type $call13 (func (param eqref i64) (result (ref $type14))))
  (type $type13 (struct (field (ref $call13)) (field eqref)))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $call17 (func (param eqref (ref null $type12)) (result (ref $type14))))
  (type $type17 (struct (field (ref $call17)) (field eqref)))
  (type $call18 (func (param eqref (ref null $type12)) (result (ref $type14))))
  (type $type18 (struct (field (ref $call18)) (field eqref)))
  (type $call19 (func (param eqref (ref $type14)) (result (ref null $type12))))
  (type $type19 (struct (field (ref $call19)) (field eqref)))
  (type $call20 (func (param eqref (ref $type14) i64 i64) (result (ref $type14))))
  (type $type20 (struct (field (ref $call20)) (field eqref)))
  (type $call21 (func (param eqref (ref $type14)) (result (ref $type14))))
  (type $type21 (struct (field (ref $call21)) (field eqref)))
  (type $call22 (func (param eqref (ref null $type23)) (result (ref $type14))))
  (type $type22 (struct (field (ref $call22)) (field eqref)))
  (type $type23 (struct (field (ref $type14)) (field (ref null $type23))))
  (type $call24 (func (param eqref (ref null $type23)) (result i64)))
  (type $type24 (struct (field (ref $call24)) (field eqref)))
  (type $call25 (func (param eqref (ref $type14) (ref null $type23) i64) (result i32)))
  (type $type25 (struct (field (ref $call25)) (field eqref)))
  (type $call26 (func (param eqref (ref $type14) (ref $type14)) (result i32)))
  (type $type26 (struct (field (ref $call26)) (field eqref)))
  (type $call27 (func (param eqref (ref $type14)) (result i32)))
  (type $type27 (struct (field (ref $call27)) (field eqref)))
  (type $call28 (func (param eqref (ref $type14)) (result i32)))
  (type $type28 (struct (field (ref $call28)) (field eqref)))
  (type $call29 (func (param eqref (ref $type14)) (result (ref $type30))))
  (type $type29 (struct (field (ref $call29)) (field eqref)))
  (type $type30 (struct (field (ref $type31))))
  (type $type31 (struct (field (mut i32))))
  (type $call32 (func (param eqref (ref $type14)) (result (ref $type33))))
  (type $type32 (struct (field (ref $call32)) (field eqref)))
  (type $type33 (struct (field (ref $type31))))
  (type $call34 (func (param eqref (ref $type30)) (result i32)))
  (type $type34 (struct (field (ref $call34)) (field eqref)))
  (type $call35 (func (param eqref (ref $type33)) (result i32)))
  (type $type35 (struct (field (ref $call35)) (field eqref)))
  (type $call36 (func (param eqref (ref $type31)) (result i32)))
  (type $type36 (struct (field (ref $call36)) (field eqref)))
  (type $call37 (func (param eqref (ref $type38)) (result i32)))
  (type $type37 (struct (field (ref $call37)) (field eqref)))
  (type $type38 (sub (struct (field i32))))
  (type $type39 (sub $type38 (struct (field i32))))
  (type $type40 (sub $type38 (struct (field i32) (field (ref $type14)))))
  (type $call41 (func (param eqref (ref $type33)) (result (ref $type38))))
  (type $type41 (struct (field (ref $call41)) (field eqref)))
  (type $call42 (func (param eqref i32) (result i32)))
  (type $type42 (struct (field (ref $call42)) (field eqref)))
  (type $call43 (func (param eqref i32 i32 (ref $type14) i64) (result (ref $type14))))
  (type $type43 (struct (field (ref $call43)) (field eqref)))
  (type $call44 (func (param eqref (ref $type14) i64) (result (ref $type14))))
  (type $type44 (struct (field (ref $call44)) (field eqref)))
  (type $call45 (func (param eqref i32 (ref $type30)) (result i32)))
  (type $type45 (struct (field (ref $call45)) (field eqref)))
  (type $call46 (func (param eqref (ref $type14) (ref $type30)) (result i32)))
  (type $type46 (struct (field (ref $call46)) (field eqref)))
  (type $call47 (func (param eqref i64 (ref $type30)) (result i32)))
  (type $type47 (struct (field (ref $call47)) (field eqref)))
  (type $environment0 (struct))
  (type $environment1 (struct))
  (type $environment2 (struct))
  (type $environment3 (struct))
  (type $environment4 (struct))
  (type $environment5 (struct))
  (type $environment6 (struct))
  (type $environment7 (struct))
  (type $environment8 (struct))
  (type $environment9 (struct))
  (type $environment10 (struct))
  (type $environment11 (struct))
  (type $environment12 (struct))
  (type $environment13 (struct))
  (type $environment14 (struct))
  (type $environment15 (struct))
  (type $environment16 (struct))
  (type $environment17 (struct))
  (type $environment18 (struct))
  (type $environment19 (struct))
  (type $environment20 (struct))
  (type $environment21 (struct))
  (type $environment22 (struct))
  (type $environment23 (struct))
  (type $environment24 (struct))
  (type $environment25 (struct))
  (type $environment26 (struct))
  (type $environment27 (struct))
  (type $environment28 (struct))
  (type $environment31 (struct))
  (type $environment33 (struct))
  (type $environment34 (struct))
  (type $environment35 (struct))
  (type $environment36 (struct))
  (type $environment38 (struct))
  (type $environment39 (struct))
  (type $environment41 (struct))
  (type $environment43 (struct))
  (type $environment44 (struct))
  (type $environment45 (struct))
  (type $environment46 (struct))
  (type $environment47 (struct))
  (type $environment48 (struct))
  (type $environment49 (struct))
  (type $environment50 (struct))
  (type $environment51 (struct))
  (type $environment52 (struct))
  (type $environment53 (struct))
  (type $environment54 (struct))
  (type $environment55 (struct))
  (type $environment56 (struct))
  (type $environment58 (struct))
  (type $environment59 (struct))
  (type $environment60 (struct))
 )
 (type $141 (func))
 (type $142 (func (result i32)))
 (type $143 (func (param i32)))
 (type $144 (func (param i32) (result i32)))
 (type $145 (func (param (ref $type14) i32 (ref $type14) i32 i32)))
 (type $146 (func (param i32 i32)))
 (type $147 (func (param i32 i32) (result i32)))
 (type $148 (func (param i32 i32) (result (ref $type14))))
 (type $149 (func (param (ref $type14) i32) (result (ref $type15))))
 (type $150 (func (param (ref $type14) i64 (ref $type14) i64 i64) (result i32)))
 (type $151 (func (param i32 i32 (ref null $type12) i64) (result i64)))
 (type $152 (func (param (ref $type14) i32 i32 (ref null $type12) i64) (result (ref $type14))))
 (type $153 (func (param (ref $type14) i32 i32 i64 (ref null $type12)) (result (ref null $type12))))
 (type $154 (func (param i32 i32 (ref null $type23) i64) (result i64)))
 (type $155 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
 (type $156 (func (param (ref $type14) i64 i32 i32 i64) (result i32)))
 (type $157 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign9 (param i32 i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type15 28
   (i32.const 98)
   (i32.const 117)
   (i32.const 102)
   (i32.const 102)
   (i32.const 101)
   (i32.const 114)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 101)
   (i32.const 102)
   (i32.const 111)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 109)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 112)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 13)
  (array.new_fixed $type15 13
   (i32.const 109)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 45)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 112)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global3 (mut (ref null $type1)) (ref.null none))
 (global $ready3 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type0)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global9 (mut (ref null $type1)) (ref.null none))
 (global $ready9 (mut i32) (i32.const 0))
 (global $global12 (mut (ref null $type0)) (ref.null none))
 (global $ready12 (mut i32) (i32.const 0))
 (global $global15 (mut (ref null $type1)) (ref.null none))
 (global $ready15 (mut i32) (i32.const 0))
 (global $global18 (mut (ref null $type0)) (ref.null none))
 (global $ready18 (mut i32) (i32.const 0))
 (global $global21 (mut (ref null $type1)) (ref.null none))
 (global $ready21 (mut i32) (i32.const 0))
 (global $global24 (mut (ref null $type2)) (ref.null none))
 (global $ready24 (mut i32) (i32.const 0))
 (global $global27 (mut (ref null $type3)) (ref.null none))
 (global $ready27 (mut i32) (i32.const 0))
 (global $global30 (mut (ref null $type2)) (ref.null none))
 (global $ready30 (mut i32) (i32.const 0))
 (global $global33 (mut (ref null $type3)) (ref.null none))
 (global $ready33 (mut i32) (i32.const 0))
 (global $global36 (mut (ref null $type2)) (ref.null none))
 (global $ready36 (mut i32) (i32.const 0))
 (global $global39 (mut (ref null $type3)) (ref.null none))
 (global $ready39 (mut i32) (i32.const 0))
 (global $global42 (mut (ref null $type2)) (ref.null none))
 (global $ready42 (mut i32) (i32.const 0))
 (global $global45 (mut (ref null $type3)) (ref.null none))
 (global $ready45 (mut i32) (i32.const 0))
 (global $global48 (mut (ref null $type2)) (ref.null none))
 (global $ready48 (mut i32) (i32.const 0))
 (global $global51 (mut (ref null $type3)) (ref.null none))
 (global $ready51 (mut i32) (i32.const 0))
 (global $global54 (mut (ref null $type4)) (ref.null none))
 (global $ready54 (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global56 (mut (ref null $type6)) (ref.null none))
 (global $ready56 (mut i32) (i32.const 0))
 (global $global57 (mut (ref null $type7)) (ref.null none))
 (global $ready57 (mut i32) (i32.const 0))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $ready58 (mut i32) (i32.const 0))
 (global $global59 (mut (ref null $type9)) (ref.null none))
 (global $ready59 (mut i32) (i32.const 0))
 (global $global60 (mut (ref null $type10)) (ref.null none))
 (global $ready60 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type11)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type17)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type18)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type19)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type21)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type22)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type24)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type25)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type26)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type28)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type34)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type35)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type36)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type37)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type41)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type42)) (ref.null none))
 (global $ready144 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type43)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type44)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global152 (mut (ref null $type45)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type46)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type34)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type47)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type47)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type30)) (ref.null none))
 (global $ready170 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $string-min (param $a i32) (param $b i32) (result i32)
  (if (result i32)
   (i32.lt_u
    (local.get $a)
    (local.get $b)
   )
   (then
    (local.get $a)
   )
   (else
    (local.get $b)
   )
  )
 )
 (func $string-new (param $length i32) (param $fill i32) (result (ref $type14))
  (local $first (ref null $type15))
  (local $directory (ref null $type16))
  (local $remaining i32)
  (local $index i32)
  (local $size i32)
  (local.set $size
   (call $string-min
    (local.get $length)
    (i32.const 8192)
   )
  )
  (local.set $first
   (array.new $type15
    (local.get $fill)
    (local.get $size)
   )
  )
  (local.set $remaining
   (i32.sub
    (local.get $length)
    (local.get $size)
   )
  )
  (if
   (local.get $remaining)
   (then
    (local.set $directory
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $length)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (local.set $size
      (call $string-min
       (local.get $remaining)
       (i32.const 8192)
      )
     )
     (array.set $type16
      (local.get $directory)
      (local.get $index)
      (array.new $type15
       (local.get $fill)
       (local.get $size)
      )
     )
     (local.set $index
      (i32.add
       (local.get $index)
       (i32.const 1)
      )
     )
     (local.set $remaining
      (i32.sub
       (local.get $remaining)
       (local.get $size)
      )
     )
     (br_if $label
      (local.get $remaining)
     )
    )
   )
  )
  (struct.new $type14
   (i32.const 1)
   (local.get $length)
   (ref.as_non_null
    (local.get $first)
   )
   (local.get $directory)
  )
 )
 (func $string-block (param $string (ref $type14)) (param $index i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $index)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 2
     (local.get $string)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 3
       (local.get $string)
      )
      (i32.sub
       (i32.shr_u
        (local.get $index)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy-forward (param $target (ref $type14)) (param $at i32) (param $source (ref $type14)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $at)
         (i32.const 8191)
        )
       )
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $start)
         (i32.const 8191)
        )
       )
      )
     )
    )
    (array.copy $type15 $type15
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $at
     (i32.add
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.add
      (local.get $start)
      (local.get $step)
     )
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy-backward (param $target (ref $type14)) (param $at i32) (param $source (ref $type14)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (local.set $at
   (i32.add
    (local.get $at)
    (local.get $remaining)
   )
  )
  (local.set $start
   (i32.add
    (local.get $start)
    (local.get $remaining)
   )
  )
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.add
        (i32.and
         (i32.sub
          (local.get $at)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
       (i32.add
        (i32.and
         (i32.sub
          (local.get $start)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
      )
     )
    )
    (local.set $at
     (i32.sub
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.sub
      (local.get $start)
      (local.get $step)
     )
    )
    (array.copy $type15 $type15
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy (param $target (ref $type14)) (param $at i64) (param $source (ref $type14)) (param $start i64) (param $end i64) (result i32)
  (if
   (i32.ne
    (struct.get $type14 0
     (local.get $target)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $at)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $target)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $end)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $source)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $start)
    (local.get $end)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $end)
     (local.get $start)
    )
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $target)
      )
     )
     (local.get $at)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (ref.eq
     (local.get $target)
     (local.get $source)
    )
    (i64.gt_u
     (local.get $at)
     (local.get $start)
    )
   )
   (then
    (call $string-copy-backward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
   (else
    (call $string-copy-forward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function0 (type $call0) (param $environment eqref) (param $argument1 i64) (param $argument2 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument1)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument2)
  )
  (f64.add
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function1 (type $call1) (param $environment eqref) (param $argument4 f64) (param $argument5 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument4)
  )
  (local.set $local2
   (local.get $argument5)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.add
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function2 (type $call0) (param $environment eqref) (param $argument7 i64) (param $argument8 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument7)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument8)
  )
  (f64.sub
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function3 (type $call1) (param $environment eqref) (param $argument10 f64) (param $argument11 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument10)
  )
  (local.set $local2
   (local.get $argument11)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.sub
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function4 (type $call0) (param $environment eqref) (param $argument13 i64) (param $argument14 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument13)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument14)
  )
  (f64.mul
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function5 (type $call1) (param $environment eqref) (param $argument16 f64) (param $argument17 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument16)
  )
  (local.set $local2
   (local.get $argument17)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.mul
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function6 (type $call0) (param $environment eqref) (param $argument19 i64) (param $argument20 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument19)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument20)
  )
  (f64.div
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function7 (type $call1) (param $environment eqref) (param $argument22 f64) (param $argument23 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument22)
  )
  (local.set $local2
   (local.get $argument23)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.div
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function8 (type $call2) (param $environment eqref) (param $argument25 i64) (param $argument26 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument25)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument26)
  )
  (f64.eq
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function9 (type $call3) (param $environment eqref) (param $argument28 f64) (param $argument29 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument28)
  )
  (local.set $local2
   (local.get $argument29)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function10 (type $call2) (param $environment eqref) (param $argument31 i64) (param $argument32 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument31)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument32)
  )
  (f64.lt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function11 (type $call3) (param $environment eqref) (param $argument34 f64) (param $argument35 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument34)
  )
  (local.set $local2
   (local.get $argument35)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.lt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function12 (type $call2) (param $environment eqref) (param $argument37 i64) (param $argument38 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument37)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument38)
  )
  (f64.le
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function13 (type $call3) (param $environment eqref) (param $argument40 f64) (param $argument41 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument40)
  )
  (local.set $local2
   (local.get $argument41)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.le
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function14 (type $call2) (param $environment eqref) (param $argument43 i64) (param $argument44 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument43)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument44)
  )
  (f64.gt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function15 (type $call3) (param $environment eqref) (param $argument46 f64) (param $argument47 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument46)
  )
  (local.set $local2
   (local.get $argument47)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.gt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function16 (type $call2) (param $environment eqref) (param $argument49 i64) (param $argument50 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument49)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument50)
  )
  (f64.ge
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function17 (type $call3) (param $environment eqref) (param $argument52 f64) (param $argument53 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument52)
  )
  (local.set $local2
   (local.get $argument53)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.ge
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function18 (type $call4) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function19 (type $call5) (param $environment eqref) (result i64)
  (i64.const 0)
 )
 (func $function20 (type $call6) (param $environment eqref) (result f32)
  (f32.const 0)
 )
 (func $function21 (type $call7) (param $environment eqref) (result f64)
  (f64.const 0)
 )
 (func $function22 (type $call8) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function23 (type $call9) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function24 (type $call10) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function25 (type $call13) (param $environment eqref) (param $argument62 i64) (result (ref $type14))
  (local $local0 i64)
  (local $local1 i32)
  (local.set $local0
   (local.get $argument62)
  )
  (local.set $local1
   (i32.const 0)
  )
  (if
   (i64.gt_u
    (local.get $local0)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (call $string-new
   (i32.wrap_i64
    (local.get $local0)
   )
   (local.get $local1)
  )
 )
 (func $function26 (type $call17) (param $environment eqref) (param $argument64 (ref null $type12)) (result (ref $type14))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type18))
  (local.set $local0
   (local.get $argument64)
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (return_call $function27
   (struct.get $type18 1
    (ref.as_non_null
     (local.get $local1)
    )
   )
   (local.get $local0)
  )
 )
 (func $function27 (type $call18) (param $environment eqref) (param $argument66 (ref null $type12)) (result (ref $type14))
  (local $local0 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local2 i64)
  (local $local7 i64)
  (local $local1 (ref null $type14))
  (local $local3 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local4 (ref null $type11))
  (local $local5 (ref null $type13))
  (local.set $local3
   (local.get $argument66)
  )
  (if
   (i32.eqz
    (global.get $ready68)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global68)
   )
  )
  (local.set $local2
   (call $function28
    (struct.get $type11 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type13 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local6
   (local.get $argument66)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function30
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local9)
   (local.get $local8)
   (local.get $local6)
   (local.get $local7)
  )
 )
 (func $function28 (type $call11) (param $environment eqref) (param $argument69 (ref null $type12)) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument69)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function29
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function29 (param $capture70 i32) (param $initialized70 i32) (param $argument71 (ref null $type12)) (param $argument72 i64) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local7 (ref null $type12))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local.set $local7
   (local.get $argument71)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local7)
   )
   (then
    (local.get $argument72)
   )
   (else
    (local.set $local5
     (local.get $argument72)
    )
    (local.set $local6
     (i64.const 4294967295)
    )
    (if (result i64)
     (i64.eq
      (local.get $local5)
      (local.get $local6)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local1
       (local.get $argument71)
      )
      (local.set $local0
       (struct.get $type12 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument72)
      )
      (local.set $local4
       (i64.const 1)
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized70)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture70)
      )
      (return_call $function29
       (local.get $capture70)
       (local.get $initialized70)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function30 (param $capture67 (ref $type14)) (param $capture73 i32) (param $initialized73 i32) (param $argument74 (ref null $type12)) (param $argument75 i64) (result (ref $type14))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local8 (ref null $type12))
  (local $local10 (ref null $type12))
  (local $local5 (ref null $type14))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i32)
  (local $local9 i32)
  (local.set $local10
   (local.get $argument74)
  )
  (if (result (ref $type14))
   (ref.is_null
    (local.get $local10)
   )
   (then
    (local.get $capture67)
   )
   (else
    (local.set $local5
     (local.get $capture67)
    )
    (local.set $local6
     (local.get $argument75)
    )
    (local.set $local8
     (local.get $argument74)
    )
    (local.set $local7
     (struct.get $type12 0
      (local.get $local8)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (array.set $type15
     (call $string-block
      (ref.as_non_null
       (local.get $local5)
      )
      (local.get $local9)
     )
     (i32.and
      (local.get $local9)
      (i32.const 8191)
     )
     (local.get $local7)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument74)
    )
    (local.set $local0
     (struct.get $type12 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument75)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized73)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture73)
    )
    (return_call $function30
     (local.get $capture67)
     (local.get $capture73)
     (local.get $initialized73)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function31 (type $call19) (param $environment eqref) (param $argument77 (ref $type14)) (result (ref null $type12))
  (local $local0 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type12))
  (local.set $local1
   (local.get $argument77)
  )
  (local.set $local0
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local2
   (ref.null none)
  )
  (local.set $local4
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local4)
  )
  (return_call $function32
   (local.get $argument77)
   (local.get $local4)
   (local.get $local3)
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function32 (param $capture77 (ref $type14)) (param $capture78 i32) (param $initialized78 i32) (param $argument79 i64) (param $argument80 (ref null $type12)) (result (ref null $type12))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local4 i32)
  (local $local9 i32)
  (local $local3 (ref null $type12))
  (local $local10 (ref null $type12))
  (local $local5 (ref null $type14))
  (local.set $local11
   (local.get $argument79)
  )
  (local.set $local12
   (i64.const 0)
  )
  (if (result (ref null $type12))
   (i64.eq
    (local.get $local11)
    (local.get $local12)
   )
   (then
    (local.get $argument80)
   )
   (else
    (local.set $local1
     (local.get $argument79)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local5
     (local.get $capture77)
    )
    (local.set $local7
     (local.get $argument79)
    )
    (local.set $local8
     (i64.const 1)
    )
    (local.set $local6
     (i64.sub
      (local.get $local7)
      (local.get $local8)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (local.set $local4
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local5)
       )
       (local.get $local9)
      )
      (i32.and
       (local.get $local9)
       (i32.const 8191)
      )
     )
    )
    (local.set $local10
     (local.get $argument80)
    )
    (local.set $local3
     (struct.new $type12
      (local.get $local4)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture78)
    )
    (return_call $function32
     (local.get $capture77)
     (local.get $capture78)
     (local.get $initialized78)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function33 (type $call20) (param $environment eqref) (param $argument82 (ref $type14)) (param $argument83 i64) (param $argument84 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local16 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local1 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local21 (ref null $type14))
  (local $local5 (ref null $type13))
  (local.set $local13
   (local.get $argument83)
  )
  (local.set $local14
   (i64.const 0)
  )
  (local.set $local12
   (i64.lt_s
    (local.get $local13)
    (local.get $local14)
   )
  )
  (local.set $local11
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type14))
   (if (result i32)
    (local.get $local12)
    (then
     (if
      (i32.eqz
       (local.get $local11)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local12)
    )
    (else
     (local.set $local17
      (local.get $argument84)
     )
     (local.set $local18
      (local.get $argument83)
     )
     (local.set $local16
      (i64.lt_s
       (local.get $local17)
       (local.get $local18)
      )
     )
     (local.set $local15
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local15)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local16)
      (then
       (if
        (i32.eqz
         (local.get $local15)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local16)
      )
      (else
       (local.set $local19
        (local.get $argument84)
       )
       (local.set $local21
        (local.get $argument82)
       )
       (local.set $local20
        (i64.extend_i32_u
         (struct.get $type14 1
          (ref.as_non_null
           (local.get $local21)
          )
         )
        )
       )
       (i64.gt_s
        (local.get $local19)
        (local.get $local20)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local3
     (local.get $argument84)
    )
    (local.set $local4
     (local.get $argument83)
    )
    (local.set $local2
     (i64.sub
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local1
     (call $function25
      (struct.get $type13 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local7
     (i64.const 0)
    )
    (local.set $local8
     (local.get $argument82)
    )
    (local.set $local9
     (local.get $argument83)
    )
    (local.set $local10
     (local.get $argument84)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local6)
      )
      (local.get $local7)
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
 )
 (func $function34 (type $call21) (param $environment eqref) (param $argument89 (ref $type14)) (result (ref $type14))
  (local $local0 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local4 (ref null $type20))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument89)
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (local.get $argument89)
  )
  (local.set $local2
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (return_call $function33
   (struct.get $type20 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function35 (type $call22) (param $environment eqref) (param $argument91 (ref null $type23)) (result (ref $type14))
  (local $local0 i32)
  (local $local2 i64)
  (local $local8 i64)
  (local $local1 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local3 (ref null $type23))
  (local $local7 (ref null $type23))
  (local $local4 (ref null $type24))
  (local $local5 (ref null $type13))
  (local $local9 (ref null $type25))
  (local.set $local3
   (local.get $argument91)
  )
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $local2
   (call $function36
    (struct.get $type24 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type13 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (local.get $argument91)
  )
  (local.set $local8
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (call $function38
    (struct.get $type25 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (local.get $local7)
    (local.get $local8)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function36 (type $call24) (param $environment eqref) (param $argument94 (ref null $type23)) (result i64)
  (local $local0 (ref null $type23))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument94)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function37
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function37 (param $capture95 i32) (param $initialized95 i32) (param $argument96 (ref null $type23)) (param $argument97 i64) (result i64)
  (local $local0 (ref null $type23))
  (local $local1 (ref null $type23))
  (local $local6 (ref null $type23))
  (local $local7 (ref null $type23))
  (local $local5 (ref null $type14))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local.set $local8
   (local.get $argument97)
  )
  (local.set $local9
   (i64.const 4294967294)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local7
     (local.get $argument96)
    )
    (if (result i64)
     (ref.is_null
      (local.get $local7)
     )
     (then
      (local.get $argument97)
     )
     (else
      (local.set $local1
       (local.get $argument96)
      )
      (local.set $local0
       (struct.get $type23 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument97)
      )
      (local.set $local6
       (local.get $argument96)
      )
      (local.set $local5
       (struct.get $type23 0
        (local.get $local6)
       )
      )
      (local.set $local4
       (i64.extend_i32_u
        (struct.get $type14 1
         (ref.as_non_null
          (local.get $local5)
         )
        )
       )
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized95)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture95)
      )
      (return_call $function37
       (local.get $capture95)
       (local.get $initialized95)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call25) (param $environment eqref) (param $argument99 (ref $type14)) (param $argument100 (ref null $type23)) (param $argument101 i64) (result i32)
  (local $local0 i32)
  (local $local1 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local2 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local11 (ref null $type14))
  (local $local13 (ref null $type14))
  (local $local3 (ref null $type23))
  (local $local5 (ref null $type23))
  (local $local6 (ref null $type23))
  (local $local14 (ref null $type23))
  (local $local17 (ref null $type23))
  (local $local10 (ref null $type25))
  (local.set $local17
   (local.get $argument100)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local17)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (local.get $argument100)
    )
    (local.set $local2
     (struct.get $type23 0
      (local.get $local3)
     )
    )
    (local.set $local1
     (i64.extend_i32_u
      (struct.get $type14 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local11
     (local.get $argument99)
    )
    (local.set $local12
     (local.get $argument101)
    )
    (local.set $local14
     (local.get $argument100)
    )
    (local.set $local13
     (struct.get $type23 0
      (local.get $local14)
     )
    )
    (local.set $local15
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local11)
      )
      (local.get $local12)
      (ref.as_non_null
       (local.get $local13)
      )
      (local.get $local15)
      (local.get $local16)
     )
    )
    (local.set $local4
     (local.get $argument99)
    )
    (local.set $local6
     (local.get $argument100)
    )
    (local.set $local5
     (struct.get $type23 1
      (local.get $local6)
     )
    )
    (local.set $local8
     (local.get $argument101)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (local.get $local1)
    )
    (local.set $local7
     (i64.add
      (local.get $local8)
      (local.get $local9)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (struct.get $type25 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (ref.as_non_null
      (local.get $local4)
     )
     (local.get $local5)
     (local.get $local7)
    )
   )
  )
 )
 (func $function39 (type $call26) (param $environment eqref) (param $argument104 (ref $type14)) (param $argument105 (ref $type14)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 (ref null $type14))
  (local $local6 (ref null $type14))
  (local.set $local4
   (local.get $argument104)
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local6
   (local.get $argument105)
  )
  (local.set $local5
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local3)
    (local.get $local5)
   )
   (then
    (local.set $local0
     (i64.const 0)
    )
    (local.set $local2
     (i32.const 0)
    )
    (local.set $local1
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local2)
    )
    (return_call $function40
     (local.get $argument104)
     (local.get $argument105)
     (local.get $local2)
     (local.get $local1)
     (local.get $local0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function40 (param $capture104 (ref $type14)) (param $capture105 (ref $type14)) (param $capture106 i32) (param $initialized106 i32) (param $argument107 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local8 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local14 i64)
  (local $local4 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local13 (ref null $type14))
  (local.set $local2
   (local.get $argument107)
  )
  (local.set $local4
   (local.get $capture104)
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local1
   (i64.eq
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local9
     (local.get $capture104)
    )
    (local.set $local10
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local10)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (i32.wrap_i64
      (local.get $local10)
     )
    )
    (local.set $local8
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local9)
       )
       (local.get $local11)
      )
      (i32.and
       (local.get $local11)
       (i32.const 8191)
      )
     )
    )
    (local.set $local13
     (local.get $capture105)
    )
    (local.set $local14
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local14)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (i32.wrap_i64
      (local.get $local14)
     )
    )
    (local.set $local12
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local13)
       )
       (local.get $local15)
      )
      (i32.and
       (local.get $local15)
       (i32.const 8191)
      )
     )
    )
    (if (result i32)
     (i32.eq
      (local.get $local8)
      (local.get $local12)
     )
     (then
      (local.set $local6
       (local.get $argument107)
      )
      (local.set $local7
       (i64.const 1)
      )
      (local.set $local5
       (i64.add
        (local.get $local6)
        (local.get $local7)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized106)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture106)
      )
      (return_call $function40
       (local.get $capture104)
       (local.get $capture105)
       (local.get $capture106)
       (local.get $initialized106)
       (local.get $local5)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call27) (param $environment eqref) (param $argument110 (ref $type14)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local2 (ref null $type14))
  (call $foreign0)
  (drop
   (i32.const 0)
  )
  (local.set $local2
   (local.get $argument110)
  )
  (local.set $local1
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function42
   (local.get $argument110)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local5)
   (local.get $local4)
   (local.get $local3)
  )
 )
 (func $function42 (param $capture110 (ref $type14)) (param $capture111 i64) (param $capture112 i32) (param $initialized112 i32) (param $argument113 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type14))
  (local.set $local7
   (local.get $argument113)
  )
  (local.set $local8
   (local.get $capture111)
  )
  (if (result i32)
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (local.get $capture110)
    )
    (local.set $local5
     (local.get $argument113)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (call $foreign1
     (local.get $local3)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument113)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture112)
    )
    (return_call $function42
     (local.get $capture110)
     (local.get $capture111)
     (local.get $capture112)
     (local.get $initialized112)
     (local.get $local0)
    )
   )
  )
 )
 (func $function43 (type $call28) (param $environment eqref) (param $argument115 (ref $type14)) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type27))
  (local.set $local2
   (local.get $argument115)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (call $foreign2)
  )
  (local.set $local1
   (i32.const 1)
  )
  (i32.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function44 (type $call27) (param $environment eqref) (param $argument117 (ref $type14)) (result i32)
  (local $local0 (ref null $type14))
  (local $local1 (ref null $type27))
  (local.set $local0
   (local.get $argument117)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (ref.as_non_null
     (local.get $local0)
    )
   )
  )
  (call $foreign3)
  (i32.const 0)
 )
 (func $function45 (type $call29) (param $environment eqref) (param $argument119 (ref $type14)) (result (ref $type30))
  (local $local0 (ref null $type31))
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type27))
  (local $local1 i32)
  (local.set $local2
   (local.get $argument119)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local1
   (call $foreign4)
  )
  (local.set $local0
   (struct.new $type31
    (local.get $local1)
   )
  )
  (struct.new $type30
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function46 (type $call32) (param $environment eqref) (param $argument121 (ref $type14)) (result (ref $type33))
  (local $local0 (ref null $type31))
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type27))
  (local $local1 i32)
  (local.set $local2
   (local.get $argument121)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local1
   (call $foreign5)
  )
  (local.set $local0
   (struct.new $type31
    (local.get $local1)
   )
  )
  (struct.new $type33
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function47 (type $call34) (param $environment eqref) (param $argument123 (ref $type30)) (result i32)
  (local $local0 (ref null $type31))
  (local $local1 (ref null $type30))
  (local $local2 (ref null $type36))
  (local.set $local1
   (local.get $argument123)
  )
  (local.set $local0
   (struct.get $type30 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (return_call $function48
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function48 (type $call36) (param $environment eqref) (param $argument125 (ref $type31)) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local3 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local2 (ref null $type31))
  (local $local4 (ref null $type31))
  (local.set $local2
   (local.get $argument125)
  )
  (local.set $local1
   (struct.get $type31 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local7
   (i32.const -1)
  )
  (if (result i32)
   (i32.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (local.get $argument125)
    )
    (local.set $local5
     (i32.const -1)
    )
    (struct.set $type31 0
     (ref.as_non_null
      (local.get $local4)
     )
     (local.get $local5)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (local.get $local1)
    )
    (call $foreign6
     (local.get $local3)
    )
    (i32.const 0)
   )
  )
 )
 (func $function49 (type $call35) (param $environment eqref) (param $argument128 (ref $type33)) (result i32)
  (local $local0 (ref null $type31))
  (local $local1 (ref null $type33))
  (local $local2 (ref null $type36))
  (local.set $local1
   (local.get $argument128)
  )
  (local.set $local0
   (struct.get $type33 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (return_call $function48
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function50 (type $call37) (param $environment eqref) (param $argument130 (ref $type38)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local1 (ref null $type38))
  (local $local3 (ref null $type14))
  (local.set $local1
   (local.get $argument130)
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type38 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type40 1
      (ref.cast (ref $type40)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (i32.const 0)
   )
  )
 )
 (func $function51 (type $call41) (param $environment eqref) (param $argument134 (ref $type33)) (result (ref $type38))
  (local $local0 i32)
  (local $local1 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local15 i32)
  (local $local16 i32)
  (local $local11 i64)
  (local $local13 i64)
  (local $local2 (ref null $type31))
  (local $local3 (ref null $type33))
  (local $local7 (ref null $type14))
  (local $local10 (ref null $type14))
  (local $local12 (ref null $type13))
  (local $local14 (ref null $type43))
  (local.set $local3
   (local.get $argument134)
  )
  (local.set $local2
   (struct.get $type33 0
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local1
   (struct.get $type31 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (local.get $local1)
  )
  (local.set $local5
   (call $foreign7
    (local.get $local6)
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (local.get $local5)
  )
  (local.set $local16
   (i32.const -1)
  )
  (if (result (ref $type38))
   (i32.eq
    (local.get $local15)
    (local.get $local16)
   )
   (then
    (struct.new $type39
     (i32.const 0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (local.get $local1)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (local.get $local5)
    )
    (local.set $local11
     (i64.const 0)
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local10
     (call $function25
      (struct.get $type13 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (local.get $local11)
     )
    )
    (local.set $local13
     (i64.const 0)
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (local.set $local7
     (call $function52
      (struct.get $type43 1
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (local.get $local8)
      (local.get $local9)
      (ref.as_non_null
       (local.get $local10)
      )
      (local.get $local13)
     )
    )
    (struct.new $type40
     (i32.const 1)
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
 )
 (func $function52 (type $call43) (param $environment eqref) (param $argument138 i32) (param $argument139 i32) (param $argument140 (ref $type14)) (param $argument141 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local7 i32)
  (local $local15 i32)
  (local $local17 i32)
  (local $local18 i32)
  (local $local26 i32)
  (local $local28 i32)
  (local $local29 i32)
  (local $local30 i32)
  (local $local31 i32)
  (local $local32 i32)
  (local $local33 i32)
  (local $local34 i32)
  (local $local35 i32)
  (local $local36 i32)
  (local $local37 i32)
  (local $local38 i32)
  (local $local39 i32)
  (local $local3 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local14 i64)
  (local $local16 i64)
  (local $local20 i64)
  (local $local21 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local13 (ref null $type14))
  (local $local19 (ref null $type14))
  (local $local25 (ref null $type14))
  (local $local4 (ref null $type44))
  (local $local12 (ref null $type43))
  (local $local22 (ref null $type20))
  (local $local27 (ref null $type42))
  (local.set $local32
   (local.get $argument139)
  )
  (local.set $local33
   (i32.const -1)
  )
  (local.set $local31
   (i32.eq
    (local.get $local32)
    (local.get $local33)
   )
  )
  (local.set $local30
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local30)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type14))
   (if (result i32)
    (local.get $local31)
    (then
     (if
      (i32.eqz
       (local.get $local30)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local31)
    )
    (else
     (local.set $local36
      (local.get $argument139)
     )
     (local.set $local37
      (i32.const 10)
     )
     (local.set $local35
      (i32.eq
       (local.get $local36)
       (local.get $local37)
      )
     )
     (local.set $local34
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local34)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local35)
      (then
       (if
        (i32.eqz
         (local.get $local34)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local35)
      )
      (else
       (local.set $local38
        (local.get $argument139)
       )
       (local.set $local39
        (i32.const 13)
       )
       (i32.eq
        (local.get $local38)
        (local.get $local39)
       )
      )
     )
    )
   )
   (then
    (local.set $local28
     (local.get $argument139)
    )
    (local.set $local29
     (i32.const 13)
    )
    (drop
     (if (result i32)
      (i32.eq
       (local.get $local28)
       (local.get $local29)
      )
      (then
       (local.set $local26
        (local.get $argument138)
       )
       (if
        (i32.eqz
         (global.get $ready144)
        )
        (then
         (unreachable)
        )
       )
       (local.set $local27
        (ref.as_non_null
         (global.get $global144)
        )
       )
       (drop
        (call $function53
         (struct.get $type42 1
          (ref.as_non_null
           (local.get $local27)
          )
         )
         (local.get $local26)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $local23
     (local.get $argument141)
    )
    (local.set $local25
     (local.get $argument140)
    )
    (local.set $local24
     (i64.extend_i32_u
      (struct.get $type14 1
       (ref.as_non_null
        (local.get $local25)
       )
      )
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (local.get $local23)
      (local.get $local24)
     )
     (then
      (local.get $argument140)
     )
     (else
      (local.set $local19
       (local.get $argument140)
      )
      (local.set $local20
       (i64.const 0)
      )
      (local.set $local21
       (local.get $argument141)
      )
      (if
       (i32.eqz
        (global.get $ready81)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local22
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (return_call $function33
       (struct.get $type20 1
        (ref.as_non_null
         (local.get $local22)
        )
       )
       (ref.as_non_null
        (local.get $local19)
       )
       (local.get $local20)
       (local.get $local21)
      )
     )
    )
   )
   (else
    (local.set $local2
     (local.get $argument140)
    )
    (local.set $local3
     (local.get $argument141)
    )
    (if
     (i32.eqz
      (global.get $ready147)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (local.set $local1
     (call $function54
      (struct.get $type44 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
      (local.get $local3)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local14
     (local.get $argument141)
    )
    (local.set $local17
     (local.get $argument139)
    )
    (local.set $local16
     (i64.extend_i32_s
      (local.get $local17)
     )
    )
    (if
     (i64.gt_u
      (local.get $local16)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.ge_u
       (local.get $local16)
       (i64.const 55296)
      )
      (i64.le_u
       (local.get $local16)
       (i64.const 57343)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (i32.wrap_i64
      (local.get $local16)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local14)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local18
     (i32.wrap_i64
      (local.get $local14)
     )
    )
    (array.set $type15
     (call $string-block
      (ref.as_non_null
       (local.get $local13)
      )
      (local.get $local18)
     )
     (i32.and
      (local.get $local18)
      (i32.const 8191)
     )
     (local.get $local15)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local5
     (local.get $argument138)
    )
    (local.set $local7
     (local.get $argument138)
    )
    (local.set $local6
     (call $foreign7
      (local.get $local7)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local10
     (local.get $argument141)
    )
    (local.set $local11
     (i64.const 1)
    )
    (local.set $local9
     (i64.add
      (local.get $local10)
      (local.get $local11)
     )
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (return_call $function52
     (struct.get $type43 1
      (ref.as_non_null
       (local.get $local12)
      )
     )
     (local.get $local5)
     (local.get $local6)
     (ref.as_non_null
      (local.get $local8)
     )
     (local.get $local9)
    )
   )
  )
 )
 (func $function53 (type $call42) (param $environment eqref) (param $argument145 i32) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local2
   (local.get $argument145)
  )
  (local.set $local1
   (call $foreign8
    (local.get $local2)
   )
  )
  (local.set $local3
   (i32.const 10)
  )
  (if (result i32)
   (i32.eq
    (local.get $local1)
    (local.get $local3)
   )
   (then
    (local.set $local0
     (local.get $argument145)
    )
    (drop
     (call $foreign7
      (local.get $local0)
     )
    )
    (i32.const 0)
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function54 (type $call44) (param $environment eqref) (param $argument148 (ref $type14)) (param $argument149 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local8 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local9 (ref null $type14))
  (local $local12 (ref null $type14))
  (local $local14 (ref null $type14))
  (local $local21 (ref null $type14))
  (local $local11 (ref null $type13))
  (local.set $local19
   (local.get $argument149)
  )
  (local.set $local21
   (local.get $argument148)
  )
  (local.set $local20
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local21)
     )
    )
   )
  )
  (if (result (ref $type14))
   (i64.lt_s
    (local.get $local19)
    (local.get $local20)
   )
   (then
    (local.get $argument148)
   )
   (else
    (local.set $local17
     (local.get $argument149)
    )
    (local.set $local18
     (i64.const 4294967294)
    )
    (if (result (ref $type14))
     (i64.eq
      (local.get $local17)
      (local.get $local18)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local6
       (local.get $argument149)
      )
      (local.set $local7
       (i64.const 0)
      )
      (local.set $local1
       (if (result i64)
        (i64.eq
         (local.get $local6)
         (local.get $local7)
        )
        (then
         (i64.const 64)
        )
        (else
         (local.set $local4
          (local.get $argument149)
         )
         (local.set $local5
          (i64.const 2147483647)
         )
         (if (result i64)
          (i64.gt_s
           (local.get $local4)
           (local.get $local5)
          )
          (then
           (i64.const 4294967294)
          )
          (else
           (local.set $local2
            (local.get $argument149)
           )
           (local.set $local3
            (i64.const 2)
           )
           (i64.mul
            (local.get $local2)
            (local.get $local3)
           )
          )
         )
        )
       )
      )
      (local.set $local0
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local10
       (local.get $local1)
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local11
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (local.set $local9
       (call $function25
        (struct.get $type13 1
         (ref.as_non_null
          (local.get $local11)
         )
        )
        (local.get $local10)
       )
      )
      (local.set $local8
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local12
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.set $local13
       (i64.const 0)
      )
      (local.set $local14
       (local.get $argument148)
      )
      (local.set $local15
       (i64.const 0)
      )
      (local.set $local16
       (local.get $argument149)
      )
      (drop
       (call $string-copy
        (ref.as_non_null
         (local.get $local12)
        )
        (local.get $local13)
        (ref.as_non_null
         (local.get $local14)
        )
        (local.get $local15)
        (local.get $local16)
       )
      )
      (if
       (i32.eqz
        (local.get $local8)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (local.get $local9)
      )
     )
    )
   )
  )
 )
 (func $function55 (type $call45) (param $environment eqref) (param $argument153 i32) (param $argument154 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local3 i32)
  (local $local1 (ref null $type31))
  (local $local2 (ref null $type30))
  (local.set $local2
   (local.get $argument154)
  )
  (local.set $local1
   (struct.get $type30 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (struct.get $type31 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (local.get $argument153)
  )
  (call $foreign9
   (local.get $local0)
   (local.get $local3)
  )
  (i32.const 0)
 )
 (func $function56 (type $call46) (param $environment eqref) (param $argument156 (ref $type14)) (param $argument157 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local2 (ref null $type14))
  (local.set $local2
   (local.get $argument156)
  )
  (local.set $local1
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function57
   (local.get $argument156)
   (local.get $argument157)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local5)
   (local.get $local4)
   (local.get $local3)
  )
 )
 (func $function57 (param $capture156 (ref $type14)) (param $capture157 (ref $type30)) (param $capture158 i64) (param $capture159 i32) (param $initialized159 i32) (param $argument160 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type14))
  (local $local7 (ref null $type30))
  (local $local8 (ref null $type45))
  (local.set $local9
   (local.get $argument160)
  )
  (local.set $local10
   (local.get $capture158)
  )
  (if (result i32)
   (i64.eq
    (local.get $local9)
    (local.get $local10)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (local.get $capture156)
    )
    (local.set $local5
     (local.get $argument160)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (local.set $local7
     (local.get $capture157)
    )
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (drop
     (call $function55
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (local.get $local3)
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local1
     (local.get $argument160)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized159)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture159)
    )
    (return_call $function57
     (local.get $capture156)
     (local.get $capture157)
     (local.get $capture158)
     (local.get $capture159)
     (local.get $initialized159)
     (local.get $local0)
    )
   )
  )
 )
 (func $function58 (type $call34) (param $environment eqref) (param $argument162 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local1 (ref null $type30))
  (local $local2 (ref null $type45))
  (local.set $local0
   (i32.const 10)
  )
  (local.set $local1
   (local.get $argument162)
  )
  (if
   (i32.eqz
    (global.get $ready152)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (return_call $function55
   (struct.get $type45 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (local.get $local0)
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function59 (type $call47) (param $environment eqref) (param $argument164 i64) (param $argument165 (ref $type30)) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local7 i32)
  (local $local5 (ref null $type30))
  (local $local8 (ref null $type30))
  (local $local6 (ref null $type47))
  (local $local9 (ref null $type45))
  (local.set $local10
   (local.get $argument164)
  )
  (local.set $local11
   (i64.const 0)
  )
  (drop
   (if (result i32)
    (i64.lt_s
     (local.get $local10)
     (local.get $local11)
    )
    (then
     (local.set $local7
      (i32.const 45)
     )
     (local.set $local8
      (local.get $argument165)
     )
     (if
      (i32.eqz
       (global.get $ready152)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local9
      (ref.as_non_null
       (global.get $global152)
      )
     )
     (drop
      (call $function55
       (struct.get $type45 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
       (local.get $local7)
       (ref.as_non_null
        (local.get $local8)
       )
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 0)
    )
   )
  )
  (local.set $local3
   (local.get $argument164)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local0
   (if (result i64)
    (i64.gt_s
     (local.get $local3)
     (local.get $local4)
    )
    (then
     (local.set $local1
      (i64.const 0)
     )
     (local.set $local2
      (local.get $argument164)
     )
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (else
     (local.get $argument164)
    )
   )
  )
  (local.set $local5
   (local.get $argument165)
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (return_call $function60
   (struct.get $type47 1
    (ref.as_non_null
     (local.get $local6)
    )
   )
   (local.get $local0)
   (ref.as_non_null
    (local.get $local5)
   )
  )
 )
 (func $function60 (type $call47) (param $environment eqref) (param $argument167 i64) (param $argument168 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local10 (ref null $type30))
  (local $local13 (ref null $type30))
  (local $local11 (ref null $type45))
  (local $local14 (ref null $type47))
  (local.set $local2
   (local.get $argument167)
  )
  (local.set $local3
   (i64.const 10)
  )
  (local.set $local1
   (i64.div_s
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (local.get $local1)
  )
  (local.set $local16
   (i64.const 0)
  )
  (drop
   (if (result i32)
    (i64.eq
     (local.get $local15)
     (local.get $local16)
    )
    (then
     (i32.const 0)
    )
    (else
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local12
      (local.get $local1)
     )
     (local.set $local13
      (local.get $argument168)
     )
     (if
      (i32.eqz
       (global.get $ready166)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local14
      (ref.as_non_null
       (global.get $global166)
      )
     )
     (drop
      (call $function60
       (struct.get $type47 1
        (ref.as_non_null
         (local.get $local14)
        )
       )
       (local.get $local12)
       (ref.as_non_null
        (local.get $local13)
       )
      )
     )
     (i32.const 0)
    )
   )
  )
  (local.set $local6
   (i64.const 48)
  )
  (local.set $local8
   (local.get $argument167)
  )
  (local.set $local9
   (i64.const 10)
  )
  (local.set $local7
   (i64.rem_s
    (local.get $local8)
    (local.get $local9)
   )
  )
  (local.set $local5
   (i64.sub
    (local.get $local6)
    (local.get $local7)
   )
  )
  (if
   (i64.gt_u
    (local.get $local5)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ge_u
     (local.get $local5)
     (i64.const 55296)
    )
    (i64.le_u
     (local.get $local5)
     (i64.const 57343)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (i32.wrap_i64
    (local.get $local5)
   )
  )
  (local.set $local10
   (local.get $argument168)
  )
  (if
   (i32.eqz
    (global.get $ready152)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (return_call $function55
   (struct.get $type45 1
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (local.get $local4)
   (ref.as_non_null
    (local.get $local10)
   )
  )
 )
 (func $main
  (local $local0 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local1 (ref null $type30))
  (local $local2 (ref null $type46))
  (local $local4 (ref null $type29))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new $type0
    (ref.func $function0)
    (ref.null none)
   )
  )
  (global.set $ready0
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global3
   (struct.new $type1
    (ref.func $function1)
    (ref.null none)
   )
  )
  (global.set $ready3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global6
   (struct.new $type0
    (ref.func $function2)
    (ref.null none)
   )
  )
  (global.set $ready6
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global9
   (struct.new $type1
    (ref.func $function3)
    (ref.null none)
   )
  )
  (global.set $ready9
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global12
   (struct.new $type0
    (ref.func $function4)
    (ref.null none)
   )
  )
  (global.set $ready12
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global15
   (struct.new $type1
    (ref.func $function5)
    (ref.null none)
   )
  )
  (global.set $ready15
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global18
   (struct.new $type0
    (ref.func $function6)
    (ref.null none)
   )
  )
  (global.set $ready18
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global21
   (struct.new $type1
    (ref.func $function7)
    (ref.null none)
   )
  )
  (global.set $ready21
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global24
   (struct.new $type2
    (ref.func $function8)
    (ref.null none)
   )
  )
  (global.set $ready24
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global27
   (struct.new $type3
    (ref.func $function9)
    (ref.null none)
   )
  )
  (global.set $ready27
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global30
   (struct.new $type2
    (ref.func $function10)
    (ref.null none)
   )
  )
  (global.set $ready30
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global33
   (struct.new $type3
    (ref.func $function11)
    (ref.null none)
   )
  )
  (global.set $ready33
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global36
   (struct.new $type2
    (ref.func $function12)
    (ref.null none)
   )
  )
  (global.set $ready36
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global39
   (struct.new $type3
    (ref.func $function13)
    (ref.null none)
   )
  )
  (global.set $ready39
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global42
   (struct.new $type2
    (ref.func $function14)
    (ref.null none)
   )
  )
  (global.set $ready42
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global45
   (struct.new $type3
    (ref.func $function15)
    (ref.null none)
   )
  )
  (global.set $ready45
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global48
   (struct.new $type2
    (ref.func $function16)
    (ref.null none)
   )
  )
  (global.set $ready48
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global51
   (struct.new $type3
    (ref.func $function17)
    (ref.null none)
   )
  )
  (global.set $ready51
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global54
   (struct.new $type4
    (ref.func $function18)
    (ref.null none)
   )
  )
  (global.set $ready54
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global55
   (struct.new $type5
    (ref.func $function19)
    (ref.null none)
   )
  )
  (global.set $ready55
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global56
   (struct.new $type6
    (ref.func $function20)
    (ref.null none)
   )
  )
  (global.set $ready56
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global57
   (struct.new $type7
    (ref.func $function21)
    (ref.null none)
   )
  )
  (global.set $ready57
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global58
   (struct.new $type8
    (ref.func $function22)
    (ref.null none)
   )
  )
  (global.set $ready58
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global59
   (struct.new $type9
    (ref.func $function23)
    (ref.null none)
   )
  )
  (global.set $ready59
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global60
   (struct.new $type10
    (ref.func $function24)
    (ref.null none)
   )
  )
  (global.set $ready60
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global68
   (struct.new $type11
    (ref.func $function28)
    (ref.null none)
   )
  )
  (global.set $ready68
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global61
   (struct.new $type13
    (ref.func $function25)
    (ref.null none)
   )
  )
  (global.set $ready61
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global63
   (struct.new $type17
    (ref.func $function26)
    (ref.null none)
   )
  )
  (global.set $ready63
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global65
   (struct.new $type18
    (ref.func $function27)
    (ref.null none)
   )
  )
  (global.set $ready65
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global76
   (struct.new $type19
    (ref.func $function31)
    (ref.null none)
   )
  )
  (global.set $ready76
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global81
   (struct.new $type20
    (ref.func $function33)
    (ref.null none)
   )
  )
  (global.set $ready81
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global88
   (struct.new $type21
    (ref.func $function34)
    (ref.null none)
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global90
   (struct.new $type22
    (ref.func $function35)
    (ref.null none)
   )
  )
  (global.set $ready90
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global93
   (struct.new $type24
    (ref.func $function36)
    (ref.null none)
   )
  )
  (global.set $ready93
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global98
   (struct.new $type25
    (ref.func $function38)
    (ref.null none)
   )
  )
  (global.set $ready98
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global103
   (struct.new $type26
    (ref.func $function39)
    (ref.null none)
   )
  )
  (global.set $ready103
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global109
   (struct.new $type27
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global114
   (struct.new $type28
    (ref.func $function43)
    (ref.null none)
   )
  )
  (global.set $ready114
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global116
   (struct.new $type27
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $ready116
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global118
   (struct.new $type29
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $ready118
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global120
   (struct.new $type32
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready120
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global122
   (struct.new $type34
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $ready122
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global127
   (struct.new $type35
    (ref.func $function49)
    (ref.null none)
   )
  )
  (global.set $ready127
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global124
   (struct.new $type36
    (ref.func $function48)
    (ref.null none)
   )
  )
  (global.set $ready124
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global129
   (struct.new $type37
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready129
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global133
   (struct.new $type41
    (ref.func $function51)
    (ref.null none)
   )
  )
  (global.set $ready133
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global144
   (struct.new $type42
    (ref.func $function53)
    (ref.null none)
   )
  )
  (global.set $ready144
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global137
   (struct.new $type43
    (ref.func $function52)
    (ref.null none)
   )
  )
  (global.set $ready137
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global147
   (struct.new $type44
    (ref.func $function54)
    (ref.null none)
   )
  )
  (global.set $ready147
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global152
   (struct.new $type45
    (ref.func $function55)
    (ref.null none)
   )
  )
  (global.set $ready152
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global155
   (struct.new $type46
    (ref.func $function56)
    (ref.null none)
   )
  )
  (global.set $ready155
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global161
   (struct.new $type34
    (ref.func $function58)
    (ref.null none)
   )
  )
  (global.set $ready161
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global163
   (struct.new $type47
    (ref.func $function59)
    (ref.null none)
   )
  )
  (global.set $ready163
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global166
   (struct.new $type47
    (ref.func $function60)
    (ref.null none)
   )
  )
  (global.set $ready166
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (global.get $string1)
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (global.set $global170
   (call $function45
    (struct.get $type29 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (global.set $ready170
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local0
   (global.get $string0)
  )
  (if
   (i32.eqz
    (global.get $ready170)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global170)
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (drop
   (call $function56
    (struct.get $type46 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (ref.as_non_null
     (local.get $local0)
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (unreachable)
 )
)

