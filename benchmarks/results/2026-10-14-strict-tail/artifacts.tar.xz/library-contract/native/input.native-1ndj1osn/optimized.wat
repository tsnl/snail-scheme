(module
 (type $0 (func))
 (rec
  (type $type47 (sub (struct)))
  (type $type49 (sub $type47 (struct (field (ref $type14)))))
  (type $type48 (sub $type47 (struct)))
  (type $type33 (struct (field (ref $type31))))
  (type $5 (func (param (ref $type33) (ref $type30) i32 i32 i64) (result i64)))
  (type $type31 (struct (field (mut i32))))
  (type $type30 (struct (field (ref $type31))))
  (type $8 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
  (type $call52 (func (param i32 i32 (ref $type14) i64) (result (ref $type14))))
  (type $10 (func (param (ref $type14) i64 i32 i32 i64) (result i32)))
  (type $11 (func (param (ref $type14)) (result i32)))
  (type $12 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
  (type $13 (func (param (ref $type14) (ref $type14) i32)))
  (type $14 (func (param (ref $type14) i32) (result (ref $type15))))
  (type $type16 (array (mut (ref null $type15))))
  (type $16 (func (param i32) (result (ref $type14))))
  (type $type10 (struct))
  (type $type8 (struct))
  (type $type5 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type43 (struct))
  (type $type41 (struct))
  (type $type39 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type29 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type20 (struct))
  (type $type13 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $43 (func (result i32)))
 (type $44 (func (param i32)))
 (type $45 (func (param i32) (result i32)))
 (type $46 (func (result i64)))
 (type $47 (func (param i32 i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign9 (param i32 i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 955)
   (i32.const 128512)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type15 9
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 115)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 115)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 120)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type15 10
   (i32.const 97)
   (i32.const 98)
   (i32.const 115)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 12)
  (array.new_fixed $type15 12
   (i32.const 98)
   (i32.const 117)
   (i32.const 102)
   (i32.const 102)
   (i32.const 101)
   (i32.const 114)
   (i32.const 101)
   (i32.const 100)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type15 27
   (i32.const 114)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 32)
   (i32.const 102)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
   (i32.const 117)
   (i32.const 114)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type26)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type34)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type35)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type36)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global176 (mut (ref null $type37)) (ref.null none))
 (global $ready176 (mut i32) (i32.const 0))
 (global $global181 (mut (ref null $type39)) (ref.null none))
 (global $ready181 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type41)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type43)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global210 (mut (ref null $type45)) (ref.null none))
 (global $ready210 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type46)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type50)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type51)) (ref.null none))
 (global $ready144 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type52)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type53)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global152 (mut (ref null $type54)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type55)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type34)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type5)) (ref.null none))
 (global $ready170 (mut i32) (i32.const 0))
 (global $global186 (mut (ref null $type8)) (ref.null none))
 (global $ready186 (mut i32) (i32.const 0))
 (global $global195 (mut (ref null $type10)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global198 (mut (ref null $type5)) (ref.null none))
 (global $ready198 (mut i32) (i32.const 0))
 (global $global200 (mut (ref null $type10)) (ref.null none))
 (global $ready200 (mut i32) (i32.const 0))
 (global $global208 (mut (ref null $type10)) (ref.null none))
 (global $ready208 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type10)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global217 (mut (ref null $type10)) (ref.null none))
 (global $ready217 (mut i32) (i32.const 0))
 (global $global220 (mut (ref null $type10)) (ref.null none))
 (global $ready220 (mut i32) (i32.const 0))
 (global $global221 (mut (ref null $type10)) (ref.null none))
 (global $ready221 (mut i32) (i32.const 0))
 (global $global223 (mut (ref null $type10)) (ref.null none))
 (global $ready223 (mut i32) (i32.const 0))
 (global $global224 (mut (ref null $type10)) (ref.null none))
 (global $ready224 (mut i32) (i32.const 0))
 (export "copy-lines" (func $export0))
 (export "line-storage" (func $export1))
 (export "close-input-alias" (func $export2))
 (export "input-callback-close" (func $export3))
 (export "input-escaped-alias" (func $export4))
 (export "input-missing" (func $export5))
 (export "input-callback-trap" (func $export6))
 (export "read-invalid" (func $export7))
 (export "input-raw-output" (func $export8))
 (export "input-stale-handle" (func $export9))
 (export "input-invalid-handle" (func $export10))
 (export "input-invalid-peek" (func $export11))
 (export "main" (func $main))
 (func $string-new (type $16) (param $0 i32) (result (ref $type14))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type16))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type14
   (i32.const 1)
   (local.get $0)
   (array.new_default $type15
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $14) (param $0 (ref $type14)) (param $1 i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy-forward (type $13) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (loop $label
   (if
    (local.get $2)
    (then
     (local.set $3
      (select
       (local.get $2)
       (local.tee $3
        (select
         (local.tee $3
          (i32.sub
           (i32.const 8192)
           (local.tee $6
            (i32.and
             (local.get $4)
             (i32.const 8191)
            )
           )
          )
         )
         (local.tee $8
          (i32.sub
           (i32.const 8192)
           (local.tee $7
            (i32.and
             (local.get $5)
             (i32.const 8191)
            )
           )
          )
         )
         (i32.lt_u
          (local.get $3)
          (local.get $8)
         )
        )
       )
       (i32.lt_u
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (array.copy $type15 $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $4)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $4)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $6)
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $5)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $1)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $1)
          )
          (i32.sub
           (i32.shr_u
            (local.get $5)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $7)
      (local.get $3)
     )
     (local.set $4
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (local.set $5
      (i32.add
       (local.get $3)
       (local.get $5)
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (local.get $3)
      )
     )
     (br $label)
    )
   )
  )
 )
 (func $function40 (type $12) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type15
       (if (result (ref $type15))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type14 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type16
           (struct.get $type14 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $11) (param $0 (ref $type14)) (result i32)
  (local $1 i64)
  (call $foreign0)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (struct.get $type14 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (array.get $type15
        (struct.get $type14 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (array.get $type15
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (array.get $type15
            (struct.get $type14 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (array.get $type15
              (struct.get $type14 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (array.get $type15
                (struct.get $type14 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (array.get $type15
                  (struct.get $type14 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (array.get $type15
                    (struct.get $type14 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (array.get $type15
                      (struct.get $type14 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (array.get $type15
                        (struct.get $type14 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type14 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign1
                         (array.get $type15
                          (struct.get $type14 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type14 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign1
                           (array.get $type15
                            (struct.get $type14 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type14 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign1
                             (array.get $type15
                              (struct.get $type14 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type14 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign1
                               (array.get $type15
                                (struct.get $type14 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type14 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign1
                                 (array.get $type15
                                  (call $string-block
                                   (local.get $0)
                                   (i32.const 14)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (return_call $function42
                                 (local.get $0)
                                 (local.get $1)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $10) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $call52) (param $0 i32) (param $1 i32) (param $2 (ref $type14)) (param $3 i64) (result (ref $type14))
  (local $4 (ref $type14))
  (local $5 i64)
  (local $6 i32)
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $6
     (i32.eq
      (local.get $1)
      (i32.const -1)
     )
    )
    (then
     (local.get $6)
    )
    (else
     (if (result i32)
      (local.tee $6
       (i32.eq
        (local.get $1)
        (i32.const 10)
       )
      )
      (then
       (local.get $6)
      )
      (else
       (i32.eq
        (local.get $1)
        (i32.const 13)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eq
      (local.get $1)
      (i32.const 13)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready144)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global144)
       )
      )
      (if
       (i32.eq
        (call $foreign8
         (local.get $0)
        )
        (i32.const 10)
       )
       (then
        (drop
         (call $foreign7
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $2)
       )
      )
      (local.get $3)
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready81)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (if (result (ref $type14))
       (if (result i32)
        (local.tee $0
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
        )
        (then
         (local.get $0)
        )
        (else
         (i64.lt_s
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $2)
           )
          )
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967294)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.ne
          (struct.get $type14 0
           (local.tee $4
            (call $string-new
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.lt_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $4)
           )
          )
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (call $string-copy-forward
         (local.get $4)
         (local.get $2)
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready147)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (if
     (i64.ge_s
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $2)
       )
      )
     )
     (then
      (local.set $2
       (if (result (ref $type14))
        (i64.eq
         (local.get $3)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.tee $5
            (if (result i64)
             (i64.eqz
              (local.get $3)
             )
             (then
              (i64.const 64)
             )
             (else
              (select
               (i64.const 4294967294)
               (i64.shl
                (local.get $3)
                (i64.const 1)
               )
               (i64.gt_s
                (local.get $3)
                (i64.const 2147483647)
               )
              )
             )
            )
           )
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (struct.get $type14 0
            (local.tee $4
             (call $string-new
              (i32.wrap_i64
               (local.get $5)
              )
             )
            )
           )
           (i32.const 1)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_u
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $4)
            )
           )
           (local.get $3)
          )
          (then
           (unreachable)
          )
         )
         (call $string-copy-forward
          (local.get $4)
          (local.get $2)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.extend_i32_s
        (local.get $1)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $1
        (i32.wrap_i64
         (local.get $3)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $1)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $1)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (local.set $1
     (call $foreign7
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function57 (type $8) (param $0 (ref $type14)) (param $1 (ref $type30)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (call $foreign9
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function64 (type $5) (param $0 (ref $type33)) (param $1 (ref $type30)) (param $2 i32) (param $3 i32) (param $4 i64) (result i64)
  (local $5 (ref $type47))
  (local $6 (ref $type14))
  (local $7 (ref $type14))
  (local $8 i32)
  (local $9 i32)
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (local.set $5
   (if (result (ref $type47))
    (i32.eq
     (local.tee $9
      (call $foreign7
       (local.tee $8
        (struct.get $type31 0
         (struct.get $type33 0
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type48)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $7
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (struct.new $type49
      (call $function52
       (local.get $8)
       (local.get $9)
       (local.get $7)
       (i64.const 0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type49)
     (local.get $5)
    )
    (then
     (drop
      (ref.cast (ref $type49)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type49)
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type49 0
      (ref.cast (ref $type49)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (drop
     (call $function57
      (local.get $6)
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $6)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global161)
     )
    )
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (call $foreign9
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (i32.const 10)
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (result i64)
  (local $0 (ref $type31))
  (local $1 (ref $type33))
  (local $2 (ref $type30))
  (local $3 i32)
  (local $4 i64)
  (local $scratch i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready170)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global170)
   )
  )
  (if
   (i32.eqz
    (global.get $ready181)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global181)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $1
   (struct.new $type33
    (struct.new $type31
     (call $foreign5)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string1)
   )
  )
  (local.set $scratch
   (call $function64
    (local.get $1)
    (local.tee $2
     (struct.new $type30
      (struct.new $type31
       (call $foreign4)
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready122)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type31 0
      (local.tee $0
       (struct.get $type30 0
        (local.get $2)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $0)
     (i32.const -1)
    )
    (call $foreign6
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type31 0
      (local.tee $0
       (struct.get $type33 0
        (local.get $1)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $0)
     (i32.const -1)
    )
    (call $foreign6
     (local.get $3)
    )
   )
  )
  (local.get $scratch)
 )
 (func $export1 (result i32)
  (local $0 i32)
  (local $1 i32)
  (local $2 (ref $type47))
  (local $3 (ref $type14))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $scratch i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready186)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global186)
   )
  )
  (if
   (i32.eqz
    (global.get $ready190)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global190)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $0
   (call $foreign5)
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type49)
     (local.tee $2
      (if (result (ref $type47))
       (i32.eq
        (local.tee $1
         (call $foreign7
          (local.get $0)
         )
        )
        (i32.const -1)
       )
       (then
        (struct.new_default $type48)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (local.set $3
         (call $string-new
          (i32.const 0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready137)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global137)
         )
        )
        (struct.new $type49
         (call $function52
          (local.get $0)
          (local.get $1)
          (local.get $3)
          (i64.const 0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type49 0
    (ref.cast (ref $type49)
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type49)
     (local.tee $2
      (if (result (ref $type47))
       (i32.eq
        (local.tee $1
         (call $foreign7
          (local.get $0)
         )
        )
        (i32.const -1)
       )
       (then
        (struct.new_default $type48)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (local.set $3
         (call $string-new
          (i32.const 0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready137)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global137)
         )
        )
        (struct.new $type49
         (call $function52
          (local.get $0)
          (local.get $1)
          (local.get $3)
          (i64.const 0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type49 0
    (ref.cast (ref $type49)
     (local.get $2)
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type14 0
     (local.get $4)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.eqz
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $4)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type15
   (struct.get $type14 2
    (local.get $4)
   )
   (i32.const 0)
   (i32.const 120)
  )
  (local.set $scratch
   (if (result i32)
    (ref.eq
     (local.get $4)
     (local.get $5)
    )
    (then
     (i32.const 0)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready103)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global103)
      )
     )
     (if (result i32)
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $4)
         )
        )
        (i64.const 4)
       )
       (then
        (call $function40
         (local.get $4)
         (global.get $string3)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (if
        (i32.eqz
         (global.get $ready103)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (if (result i32)
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $5)
           )
          )
          (i64.const 4)
         )
         (then
          (call $function40
           (local.get $5)
           (global.get $string2)
           (i32.const 0)
           (i32.const 1)
           (i64.const 0)
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (if
          (i32.eqz
           (global.get $ready133)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global133)
          )
         )
         (local.set $2
          (if (result (ref $type47))
           (i32.eq
            (local.tee $1
             (call $foreign7
              (local.get $0)
             )
            )
            (i32.const -1)
           )
           (then
            (struct.new_default $type48)
           )
           (else
            (if
             (i32.eqz
              (global.get $ready61)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global61)
             )
            )
            (local.set $3
             (call $string-new
              (i32.const 0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready137)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global137)
             )
            )
            (struct.new $type49
             (call $function52
              (local.get $0)
              (local.get $1)
              (local.get $3)
              (i64.const 0)
             )
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready129)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global129)
          )
         )
         (if (result i32)
          (if (result i32)
           (ref.test (ref $type49)
            (local.get $2)
           )
           (then
            (drop
             (ref.cast (ref $type49)
              (local.get $2)
             )
            )
            (i32.const 0)
           )
           (else
            (i32.const 1)
           )
          )
          (then
           (if
            (i32.eqz
             (global.get $ready133)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global133)
            )
           )
           (local.set $2
            (if (result (ref $type47))
             (i32.eq
              (local.tee $1
               (call $foreign7
                (local.get $0)
               )
              )
              (i32.const -1)
             )
             (then
              (struct.new_default $type48)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready61)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global61)
               )
              )
              (local.set $3
               (call $string-new
                (i32.const 0)
               )
              )
              (if
               (i32.eqz
                (global.get $ready137)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global137)
               )
              )
              (struct.new $type49
               (call $function52
                (local.get $0)
                (local.get $1)
                (local.get $3)
                (i64.const 0)
               )
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready129)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global129)
            )
           )
           (if (result i32)
            (ref.test (ref $type49)
             (local.get $2)
            )
            (then
             (drop
              (ref.cast (ref $type49)
               (local.get $2)
              )
             )
             (i32.const 0)
            )
            (else
             (i32.const 1)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
   )
  )
  (local.get $scratch)
 )
 (func $export2
  (local $0 i32)
  (local $1 i32)
  (local $2 (ref $type14))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready195)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $0
   (call $foreign5)
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (if (result (ref $type47))
    (i32.eq
     (local.tee $1
      (call $foreign7
       (local.get $0)
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type48)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $2
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (struct.new $type49
      (call $function52
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.const 0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
   )
  )
 )
 (func $export3 (result i64)
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready198)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global198)
   )
  )
  (if
   (i32.eqz
    (global.get $ready181)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global181)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $0
   (call $foreign5)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
   )
  )
  (i64.const 19)
 )
 (func $export4
  (local $0 i32)
  (local $1 i32)
  (local $2 (ref $type14))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready200)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global200)
   )
  )
  (if
   (i32.eqz
    (global.get $ready203)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global203)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $0
   (call $foreign5)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (if (result (ref $type47))
    (i32.eq
     (local.tee $1
      (call $foreign7
       (local.get $0)
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type48)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $2
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (struct.new $type49
      (call $function52
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $export5
  (local $0 i32)
  (local $1 i32)
  (local $2 (ref $type14))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready208)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global208)
   )
  )
  (if
   (i32.eqz
    (global.get $ready210)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global210)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string4)
   )
  )
  (local.set $0
   (call $foreign5)
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (if (result (ref $type47))
    (i32.eq
     (local.tee $1
      (call $foreign7
       (local.get $0)
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type48)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $2
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (struct.new $type49
      (call $function52
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.const 0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.ne
    (local.get $0)
    (i32.const -1)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
   )
  )
 )
 (func $export6
  (local $0 i32)
  (local $1 i32)
  (local $2 (ref $type14))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready215)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (if
   (i32.eqz
    (global.get $ready210)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global210)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $0
   (call $foreign5)
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (if (result (ref $type47))
    (i32.eq
     (local.tee $1
      (call $foreign7
       (local.get $0)
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type48)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $2
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (struct.new $type49
      (call $function52
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.const 0)
      )
     )
    )
   )
  )
  (unreachable)
 )
 (func $export7
  (local $0 i32)
  (local $1 i32)
  (local $2 (ref $type30))
  (local $3 (ref $type14))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready217)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string5)
   )
  )
  (local.set $2
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string0)
   )
  )
  (local.set $0
   (call $foreign5)
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (drop
   (call $function57
    (global.get $string6)
    (local.get $2)
    (i64.const 27)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (if (result (ref $type47))
    (i32.eq
     (local.tee $1
      (call $foreign7
       (local.get $0)
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type48)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $3
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (struct.new $type49
      (call $function52
       (local.get $0)
       (local.get $1)
       (local.get $3)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $export8
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready220)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global220)
   )
  )
  (call $foreign0)
  (call $foreign1
   (i32.const 120)
  )
  (drop
   (call $foreign7
    (call $foreign4)
   )
  )
 )
 (func $export9
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready221)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global221)
   )
  )
  (call $foreign0)
  (call $foreign1
   (i32.const 120)
  )
  (call $foreign6
   (local.tee $0
    (call $foreign4)
   )
  )
  (drop
   (call $foreign7
    (local.get $0)
   )
  )
 )
 (func $export10
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready223)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global223)
   )
  )
  (drop
   (call $foreign7
    (i32.const -1)
   )
  )
 )
 (func $export11
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready224)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global224)
   )
  )
  (drop
   (call $foreign8
    (i32.const -1)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type20)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type26)
  )
  (global.set $ready103
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type29)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type32)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type34)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type35)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type36)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global176
   (struct.new_default $type37)
  )
  (global.set $ready176
   (i32.const 1)
  )
  (global.set $global181
   (struct.new_default $type39)
  )
  (global.set $ready181
   (i32.const 1)
  )
  (global.set $global190
   (struct.new_default $type41)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global203
   (struct.new_default $type43)
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global210
   (struct.new_default $type45)
  )
  (global.set $ready210
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type46)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type50)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global144
   (struct.new_default $type51)
  )
  (global.set $ready144
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type52)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global147
   (struct.new_default $type53)
  )
  (global.set $ready147
   (i32.const 1)
  )
  (global.set $global152
   (struct.new_default $type54)
  )
  (global.set $ready152
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type55)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type34)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global170
   (struct.new_default $type5)
  )
  (global.set $ready170
   (i32.const 1)
  )
  (global.set $global186
   (struct.new_default $type8)
  )
  (global.set $ready186
   (i32.const 1)
  )
  (global.set $global195
   (struct.new_default $type10)
  )
  (global.set $ready195
   (i32.const 1)
  )
  (global.set $global198
   (struct.new_default $type5)
  )
  (global.set $ready198
   (i32.const 1)
  )
  (global.set $global200
   (struct.new_default $type10)
  )
  (global.set $ready200
   (i32.const 1)
  )
  (global.set $global208
   (struct.new_default $type10)
  )
  (global.set $ready208
   (i32.const 1)
  )
  (global.set $global215
   (struct.new_default $type10)
  )
  (global.set $ready215
   (i32.const 1)
  )
  (global.set $global217
   (struct.new_default $type10)
  )
  (global.set $ready217
   (i32.const 1)
  )
  (global.set $global220
   (struct.new_default $type10)
  )
  (global.set $ready220
   (i32.const 1)
  )
  (global.set $global221
   (struct.new_default $type10)
  )
  (global.set $ready221
   (i32.const 1)
  )
  (global.set $global223
   (struct.new_default $type10)
  )
  (global.set $ready223
   (i32.const 1)
  )
  (global.set $global224
   (struct.new_default $type10)
  )
  (global.set $ready224
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

