(module
 (rec
  (type $type38 (sub (struct)))
  (type $type40 (sub $type38 (struct)))
  (type $type39 (sub $type38 (struct)))
  (type $type31 (struct (field i32)))
  (type $call43 (func (param i32 i32 (ref $type14) i64) (result (ref $type14))))
  (type $5 (func (param (ref $type14) (ref $type14) i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $7 (func (param i32) (result (ref $type14))))
  (type $type33 (struct (field (ref $type31))))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type32 (struct))
  (type $type27 (struct))
  (type $type20 (struct))
  (type $type13 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $19 (func))
 (type $20 (func (param i32) (result i32)))
 (type $21 (func (param i32)))
 (type $22 (func (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 955)
   (i32.const 128512)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $global133 (mut (ref null $type41)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type42)) (ref.null none))
 (global $ready144 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type43)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type44)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type33)) (ref.null none))
 (export "main" (func $main))
 (func $string-new (type $7) (param $0 i32) (result (ref $type14))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type16))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type14
   (i32.const 1)
   (local.get $0)
   (array.new_default $type15
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-copy-forward (type $5) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (loop $label
   (if
    (local.get $2)
    (then
     (local.set $3
      (select
       (local.get $2)
       (local.tee $3
        (select
         (local.tee $3
          (i32.sub
           (i32.const 8192)
           (local.tee $6
            (i32.and
             (local.get $4)
             (i32.const 8191)
            )
           )
          )
         )
         (local.tee $8
          (i32.sub
           (i32.const 8192)
           (local.tee $7
            (i32.and
             (local.get $5)
             (i32.const 8191)
            )
           )
          )
         )
         (i32.lt_u
          (local.get $3)
          (local.get $8)
         )
        )
       )
       (i32.lt_u
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (array.copy $type15 $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $4)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $4)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $6)
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $5)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $1)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $1)
          )
          (i32.sub
           (i32.shr_u
            (local.get $5)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $7)
      (local.get $3)
     )
     (local.set $4
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (local.set $5
      (i32.add
       (local.get $3)
       (local.get $5)
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (local.get $3)
      )
     )
     (br $label)
    )
   )
  )
 )
 (func $function52 (type $call43) (param $0 i32) (param $1 i32) (param $2 (ref $type14)) (param $3 i64) (result (ref $type14))
  (local $4 (ref $type14))
  (local $5 i64)
  (local $6 i32)
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $6
     (i32.eq
      (local.get $1)
      (i32.const -1)
     )
    )
    (then
     (local.get $6)
    )
    (else
     (if (result i32)
      (local.tee $6
       (i32.eq
        (local.get $1)
        (i32.const 10)
       )
      )
      (then
       (local.get $6)
      )
      (else
       (i32.eq
        (local.get $1)
        (i32.const 13)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eq
      (local.get $1)
      (i32.const 13)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready144)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global144)
       )
      )
      (if
       (i32.eq
        (call $foreign8
         (local.get $0)
        )
        (i32.const 10)
       )
       (then
        (drop
         (call $foreign7
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $2)
       )
      )
      (local.get $3)
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready81)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (if (result (ref $type14))
       (if (result i32)
        (local.tee $0
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
        )
        (then
         (local.get $0)
        )
        (else
         (i64.lt_s
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $2)
           )
          )
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967294)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.ne
          (struct.get $type14 0
           (local.tee $4
            (call $string-new
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.lt_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $4)
           )
          )
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (call $string-copy-forward
         (local.get $4)
         (local.get $2)
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready147)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (if
     (i64.ge_s
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $2)
       )
      )
     )
     (then
      (local.set $2
       (if (result (ref $type14))
        (i64.eq
         (local.get $3)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.tee $5
            (if (result i64)
             (i64.eqz
              (local.get $3)
             )
             (then
              (i64.const 64)
             )
             (else
              (select
               (i64.const 4294967294)
               (i64.shl
                (local.get $3)
                (i64.const 1)
               )
               (i64.gt_s
                (local.get $3)
                (i64.const 2147483647)
               )
              )
             )
            )
           )
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (struct.get $type14 0
            (local.tee $4
             (call $string-new
              (i32.wrap_i64
               (local.get $5)
              )
             )
            )
           )
           (i32.const 1)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_u
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $4)
            )
           )
           (local.get $3)
          )
          (then
           (unreachable)
          )
         )
         (call $string-copy-forward
          (local.get $4)
          (local.get $2)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.extend_i32_s
        (local.get $1)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $1
        (i32.wrap_i64
         (local.get $3)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $1)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $1)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (local.set $1
     (call $foreign7
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready137)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $main
  (local $0 (ref $type15))
  (local $1 (ref $type14))
  (local $2 (ref $type33))
  (local $3 i32)
  (local $4 i32)
  (local $scratch (ref $type33))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type20)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $global120
   (struct.new_default $type32)
  )
  (global.set $global133
   (struct.new_default $type41)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global144
   (struct.new_default $type42)
  )
  (global.set $ready144
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type43)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global147
   (struct.new_default $type44)
  )
  (global.set $ready147
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (call $foreign0)
  (call $foreign1
   (array.get $type15
    (local.tee $0
     (struct.get $type14 2
      (local.tee $1
       (global.get $string0)
      )
     )
    )
    (i32.const 0)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.get $0)
    (i32.const 1)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.get $0)
    (i32.const 2)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.get $0)
    (i32.const 3)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.tee $0
     (struct.get $type14 2
      (local.get $1)
     )
    )
    (i32.const 4)
   )
  )
  (call $foreign1
   (array.get $type15
    (local.get $0)
    (i32.const 5)
   )
  )
  (global.set $global170
   (struct.new $type33
    (struct.new $type31
     (call $foreign5)
    )
   )
  )
  (drop
   (if (result (ref $type38))
    (i32.eq
     (local.tee $4
      (call $foreign7
       (local.tee $3
        (struct.get $type31 0
         (struct.get $type33 0
          (block (result (ref $type33))
           (local.set $scratch
            (ref.as_non_null
             (global.get $global170)
            )
           )
           (if
            (i32.eqz
             (global.get $ready133)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global133)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (i32.const -1)
    )
    (then
     (struct.new_default $type39)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (local.set $1
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready137)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (drop
      (call $function52
       (local.get $3)
       (local.get $4)
       (local.get $1)
       (i64.const 0)
      )
     )
     (struct.new_default $type40)
    )
   )
  )
  (unreachable)
 )
)

