
    #[test]
    fn cached_fields_survive_worklist_growth_and_ignore_undeclared_words() {
        let mut heap = Heap::new(8, 8);
        let offsets = vec![15, 1, 13, 3, 11, 5, 9, 7];
        heap.collector.metadata.layouts[0] = Layout::Fields(offsets.clone());
        let parent = heap.object(17 * 8, 6, 0);
        heap.frame.values[0] = parent as u64;
        for (index, offset) in offsets.iter().enumerate() {
            let child = heap.object(8, 10, 0);
            unsafe { parent.add(*offset as usize).write(child as u64) };
            heap.watch(child, index);
        }
        let decoy = heap.object(8, 10, 0);
        unsafe { parent.add(2).write(decoy as u64) };
        heap.watch(decoy, 8);
        heap.collect();
        assert!(heap.collector.work.capacity() >= offsets.len());
        assert_eq!(heap.collector.stats.field_visits, offsets.len());
        assert_eq!(heap.collector.stats.live_objects, offsets.len() + 1);
        assert_eq!(&heap.finalized[..9], &[0, 0, 0, 0, 0, 0, 0, 0, 1]);
        heap.frame.values[0] = 0;
        heap.collect();
        assert_eq!(&heap.finalized[..9], &[1; 9]);
    }

    #[test]
    #[should_panic(expected = "assertion failed: offset < count")]
    fn invalid_field_offset_panics_before_outside_payload_read() {
        let mut heap = Heap::new(1, 1);
        heap.collector.metadata.layouts[0] = Layout::Fields(vec![u32::MAX]);
        let object = heap.object(16, 6, 0);
        heap.frame.values[0] = object as u64;
        heap.collect();
    }

