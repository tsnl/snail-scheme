The control runtime is an unchanged copy of commit
08f98ad1db244753c48a1739702ca894e50416da from the runtime polish worktree.
It includes the full-u64 zero-fill guard and zero-live-line sweep shortcut.
The candidate only caches the Fields offset allocation and its length locally
inside trace_object. collector.patch is the complete release source diff.

The retained dead-block profile attributes 30.85% of core cycle samples to
mark, 19.97% to collect (which contains trace_object), 22.25% to allocate and
14.16% to sweep. The Fields loop still reloads layout length, layout pointer,
variant, field count and field pointer after each call to mark. This is a
code-generation fact; cycle samples cannot identify the precise cost of each
instruction because of sampling skid and memory dependencies.

The raw offset pointer stays valid throughout the loop:

- linked_metadata copies every linker offset array into an owned Vec, then
  moves the Metadata into Collector::new. Collector.metadata is private.
- Product code never mutates/replaces metadata.layouts or its Fields Vecs.
  Unit tests append globals/tables before collection; those allocations are
  separate from layouts and offset storage.
- collect is the only caller of trace_object. Its work-pop loop runs after
  mark_roots and before queue_finalizers and sweep.
- mark invokes containing_region/candidate/mark_lines and reserves/pushes the
  work Vec. It neither changes metadata nor calls guest code, finalizers,
  allocation or collection. Work Vec growth and region line writes touch
  different allocations from the owned offset Vec.
- A zero-length Fields Vec is never dereferenced. Every raw offset read uses
  index < the captured Vec length. The offset < object word-count assertion
  still runs before each guest payload read.

The candidate leaves exact-start membership, ALLOCATED/MARKED checks, nullable
handling, region checks, ReferenceArray checks, tracing order, worklist order,
field/root counts and all budget/growth policy unchanged. No instrumentation
is compiled into either binary. Existing opt-in statistics and external perf
are used for diagnostic runs; clean timing remains the parent coordinator's
responsibility.
