import {readFileSync, writeFileSync, cpSync, mkdirSync, copyFileSync, readdirSync, chmodSync} from 'node:fs';
import {spawnSync} from 'node:child_process';

const root = '/tmp/snail-native-allocator-20261016/probe/gcbench-field-layout-20261016';
const control = JSON.parse(readFileSync(root + '/control/command.json'));
const cargo = control.command[0];
const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
const attempts = [];
function run(label, command, args, env) {
  const prefix = root + '/' + label;
  save(prefix + '.command.json', {command: [command, ...args], environment: env, cwd: root});
  const started = new Date().toISOString();
  const result = spawnSync(command, args, {env, cwd: root, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024});
  writeFileSync(prefix + '.stdout', result.stdout ?? '');
  writeFileSync(prefix + '.stderr', result.stderr ?? '');
  attempts.push({label, started, finished: new Date().toISOString(), status: result.status, signal: result.signal, error: result.error?.message});
  save(root + '/validation-attempts.json', attempts);
  console.log(label, result.status, result.error?.message ?? '');
  if (result.status !== 0) throw Error('Validation failed: ' + label);
  return result;
}
const env = {...process.env, CARGO_HOME: root + '/cargo-home', RUSTC: '/tmp/sfir-native-parity-baseline-20261016/toolchain/rust/bin/rustc'};
delete env.RUSTC_WRAPPER;
delete env.RUSTFLAGS;
delete env.CARGO_ENCODED_RUSTFLAGS;
for (const key of Object.keys(env)) if (key.startsWith('SNAIL_GC_') || key === 'SNAIL_NATIVE_GC_INTERVAL') delete env[key];
run('format', cargo, ['fmt', '--manifest-path', root + '/runtime/Cargo.toml', '--all', '--', '--check'], env);
const tests = `
    #[test]
    fn cached_fields_survive_worklist_growth_and_ignore_undeclared_words() {
        let mut heap = Heap::new(8, 8);
        let offsets = vec![15, 1, 13, 3, 11, 5, 9, 7];
        heap.collector.metadata.layouts[0] = Layout::Fields(offsets.clone());
        let parent = heap.object(17 * 8, 6, 0);
        heap.frame.values[0] = parent as u64;
        for (index, offset) in offsets.iter().enumerate() {
            let child = heap.object(8, 10, 0);
            unsafe { parent.add(*offset as usize).write(child as u64) };
            heap.watch(child, index);
        }
        let decoy = heap.object(8, 10, 0);
        unsafe { parent.add(2).write(decoy as u64) };
        heap.watch(decoy, 8);
        heap.collect();
        assert!(heap.collector.work.capacity() >= offsets.len());
        assert_eq!(heap.collector.stats.field_visits, offsets.len());
        assert_eq!(heap.collector.stats.live_objects, offsets.len() + 1);
        assert_eq!(&heap.finalized[..9], &[0, 0, 0, 0, 0, 0, 0, 0, 1]);
        heap.frame.values[0] = 0;
        heap.collect();
        assert_eq!(&heap.finalized[..9], &[1; 9]);
    }

    #[test]
    #[should_panic(expected = "assertion failed: offset < count")]
    fn invalid_field_offset_panics_before_outside_payload_read() {
        let mut heap = Heap::new(1, 1);
        heap.collector.metadata.layouts[0] = Layout::Fields(vec![u32::MAX]);
        let object = heap.object(16, 6, 0);
        heap.frame.values[0] = object as u64;
        heap.collect();
    }

`;
writeFileSync(root + '/focused-tests.rs', tests);
for (const arm of ['control', 'cached-fields']) {
  const testRuntime = root + '/test-runtime-' + arm;
  mkdirSync(testRuntime, {recursive: true});
  for (const name of ['src', 'scheme', 'scripts']) cpSync(root + '/runtime/' + name, testRuntime + '/' + name, {recursive: true});
  for (const name of ['Cargo.toml', 'Cargo.lock']) copyFileSync(root + '/runtime/' + name, testRuntime + '/' + name);
  const gc = readFileSync(root + '/' + arm + '/native_gc.rs', 'utf8');
  const marker = '    #[test]\n    fn exact_roots_trace_declared_edges_globals_tables_and_reference_arrays()';
  if (!gc.includes(marker)) throw Error('Missing final Tests section');
  writeFileSync(testRuntime + '/src/native_gc.rs', gc.replace(marker, tests + marker));
  run('unit-' + arm, cargo, ['test', '--manifest-path', testRuntime + '/Cargo.toml', '--offline', '--target-dir', root + '/unit-target-' + arm], env);
}
const semantics = root + '/semantics';
mkdirSync(semantics, {recursive: true});
const previous = '/tmp/snail-native-allocator-checks-20261016';
const originalObject = previous + '/' + readdirSync(previous).find(name => name.startsWith('optimized-semantics.native-')) + '/module.o';
copyFileSync(originalObject, semantics + '/module.o');
const flags = control.environment.CARGO_ENCODED_RUSTFLAGS.split('\x1f');
const kept = [];
for (let index = 0; index < flags.length; index++) {
  if (flags[index] === '-C' && ['linker-plugin-lto', 'lto=fat', 'embed-bitcode=yes'].includes(flags[index + 1])) { index++; continue; }
  kept.push(flags[index]);
}
const nativeEnv = {...env, ...control.environment, CARGO_ENCODED_RUSTFLAGS: kept.join('\x1f')};
writeFileSync(semantics + '/Cargo.toml', '[package]\nname="field_layout_semantics"\nversion="0.0.0"\nedition="2024"\n[[bin]]\nname="field_layout_semantics"\npath="/tmp/snail-native-allocator-20261016/tests/native-runner.rs"\n[dependencies]\nsnail-runtime={path=' + JSON.stringify(root + '/runtime') + ',features=["native-runtime"]}\n[profile.release]\npanic="abort"\nlto=true\ncodegen-units=1\n');
writeFileSync(semantics + '/build.rs', 'fn main(){println!("cargo:rustc-link-arg={}",' + JSON.stringify(semantics + '/module.o') + ');}\n');
save(semantics + '/guest-provenance.json', {originalObject, mandatoryBinaryen: true, note: 'Copy of retained optimized Wasm native object; no guest changes'});
run('semantics-build', cargo, ['build', '--offline', '--release', '--manifest-path', semantics + '/Cargo.toml', '--target-dir', root + '/semantic-target'], nativeEnv);
copyFileSync(root + '/semantic-target/release/field_layout_semantics', semantics + '/program');
chmodSync(semantics + '/program', 0o755);
run('semantics-forced-collection', semantics + '/program', [], {...env, SNAIL_NATIVE_GC_INTERVAL: '1'});
save(root + '/validation-summary.json', {format: 'passed', runtimeTests: {control: 60, candidate: 60}, focusedInvalidOffset: 'asserted before payload pointer arithmetic', focusedWorklistGrowth: '8 nonsequential declared offsets, work Vec reallocation, undeclared decoy rejected, all expected finalizers', existingExactRoots: 'passed including stale exact-address republish and pointer-shaped scalars', optimizedNativeSemantics: 'passed with SNAIL_NATIVE_GC_INTERVAL=1', productionEdits: false});
