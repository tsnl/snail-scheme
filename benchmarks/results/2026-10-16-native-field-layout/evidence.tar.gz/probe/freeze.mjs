import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root = '/tmp/snail-native-allocator-20261016/probe/gcbench-field-layout-20261016';
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const summary = JSON.parse(readFileSync(root + '/summary.json'));
summary.samplingExecutions = [];
for (const arm of summary.ltoArms) {
  const prefix = root + '/' + arm.arm + '/profile';
  const result = readFileSync(prefix + '.stdout', 'utf8').split('\n').filter(line => line.startsWith('{')).map(line => JSON.parse(line));
  if (result.length !== 1 || result[0].result !== '1') throw Error('Sampling predicate failed');
  const line = readFileSync(prefix + '.stderr', 'utf8').split('\n').find(line => line.startsWith('immix-gc '));
  if (!line) throw Error('Missing sampling counters');
  const counters = Object.fromEntries([...line.matchAll(/([a-z_]+)=([^ ]+)/g)].map(match => [match[1], /^\d+(?:\.\d+)?$/.test(match[2]) ? Number(match[2]) : match[2]]));
  for (const [key, value] of Object.entries(summary.workloadCounts)) if (counters[key] !== value) throw Error('Sampling counter mismatch: ' + key);
  summary.samplingExecutions.push({arm: arm.arm, predicate: result[0], allNonTimeCountersEqual: true});
}
const frozen = '/tmp/sfir-native-parity-baseline-20261016/timing/artifacts/gcbench';
summary.frozenWasm = {path: frozen + '/program.wasm', sha256: sha(frozen + '/program.wasm')};
summary.frozenSpec = {path: frozen + '/spec.json', sha256: sha(frozen + '/spec.json')};
summary.allEightFullGcbenchPredicatesPassed = true;
const arms = [...summary.ltoArms, ...summary.machineArms];
for (const arm of arms) if (sha(arm.program) !== arm.sha256) throw Error('Binary integrity failed');
writeFileSync(root + '/timing-binaries.sha256', arms.map(arm => arm.sha256 + '  ' + arm.program).join('\n') + '\n');
summary.frozenAt = new Date().toISOString();
writeFileSync(root + '/summary.json', JSON.stringify(summary, null, 2) + '\n');
console.log('All 4 binaries verified; 8 complete gcbench predicates and all non-time counters agree. Frozen.');
