import {readFileSync, writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';

const base = '/tmp/snail-native-allocator-20261016/probe/gcbench-field-layout-20261016';
const perf = '/nix/store/apffmxq24i2xf89m4llsz4yc2sc1bv94-perf-linux-7.2.3/bin/perf';
const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const arms = JSON.parse(readFileSync(base + '/machine/arms.json'));
if (arms.length !== 2) throw Error('Both machine arms must exist');
const env = {...process.env};
for (const key of Object.keys(env)) if (key.startsWith('SNAIL_GC_') || key === 'SNAIL_NATIVE_GC_INTERVAL') delete env[key];
env.SNAIL_GC_STATS = '1';
const rows = [];
for (const arm of arms) {
  const prefix = base + '/machine/' + arm.arm + '/diagnostic';
  const args = ['stat', '-x', ';', '-e', 'cpu_core/cycles/u,cpu_core/instructions/u,cpu_core/branches/u,cpu_core/branch-misses/u,cpu_core/cache-misses/u', '-o', prefix + '.csv', '--', 'taskset', '-c', '2', arm.program];
  save(prefix + '.command.json', {command: [perf, ...args], cwd: base, unset: ['SNAIL_NATIVE_GC_INTERVAL', 'all other SNAIL_GC_*'], overrides: {SNAIL_GC_STATS: '1'}, cleanTiming: false});
  const started = new Date().toISOString();
  const result = spawnSync(perf, args, {cwd: base, env, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024});
  writeFileSync(prefix + '.stdout', result.stdout ?? '');
  writeFileSync(prefix + '.stderr', result.stderr ?? '');
  const attempt = {arm: arm.arm, started, finished: new Date().toISOString(), status: result.status, signal: result.signal, error: result.error?.message};
  save(prefix + '.attempt.json', attempt);
  console.log(arm.arm, 'machine diagnostic', result.status, result.error?.message ?? '');
  if (result.status !== 0 || sha(arm.program) !== arm.sha256) throw Error('Machine execution failed');
  const line = result.stderr.split('\n').find(line => line.startsWith('immix-gc '));
  if (!line) throw Error('Missing GC counters');
  const counters = Object.fromEntries([...line.matchAll(/([a-z_]+)=([^ ]+)/g)].map(match => [match[1], /^\d+(?:\.\d+)?$/.test(match[2]) ? Number(match[2]) : match[2]]));
  const predicates = result.stdout.trim().split('\n').filter(line => line.startsWith('{')).map(line => JSON.parse(line));
  if (predicates.length !== 1 || predicates[0].result !== '1') throw Error('Full predicate failed');
  const hardware = Object.fromEntries(readFileSync(prefix + '.csv', 'utf8').split('\n').filter(line => line.includes('cpu_core/')).map(line => {const fields = line.split(';'); return [fields[2], Number(fields[0])];}));
  rows.push({arm: arm.arm, counters, hardware, predicate: predicates[0], attempt});
}
const lto = JSON.parse(readFileSync(base + '/diagnostic-summary.json'));
const expected = lto.rows[0].counters;
const differences = [];
for (const row of rows) for (const key of Object.keys(expected)) if (!['mark_s', 'sweep_s'].includes(key) && row.counters[key] !== expected[key]) differences.push({arm: row.arm, key, expected: expected[key], actual: row.counters[key]});
save(base + '/machine/diagnostic-summary.json', {rows, sameNonTimeGcCountersWithLtoAndEachOther: differences.length === 0, differences, instrumented: true, cleanTiming: 'not-measured'});
if (differences.length) throw Error('Counter mismatch');
function deltas(before, after) {
  return Object.fromEntries(Object.keys(before).map(key => [key, {before: before[key], after: after[key], percent: (after[key] / before[key] - 1) * 100}]));
}
const mean = arm => {
  const selected = lto.rows.filter(row => row.arm === arm);
  return Object.fromEntries(Object.keys(selected[0].hardware).map(key => [key, selected.reduce((sum, row) => sum + row.hardware[key], 0) / selected.length]));
};
const delta = deltas(mean('control'), mean('cached-fields'));
const pair = JSON.parse(readFileSync(base + '/arms.json'));
const files = {
  entry: {source: '/tmp/snail-native-lto-20261016/probe/six/gcbench/timing/matched-native/main.rs', copies: [base + '/package/main.rs', base + '/machine/package/main.rs']},
  entryConfig: {source: '/tmp/snail-native-lto-20261016/probe/six/gcbench/timing/matched-native/case-config.rs', copies: [base + '/package/case-config.rs', base + '/machine/package/case-config.rs']},
  provider: {source: '/tmp/snail-native-lto-20261016/probe/six/gcbench/timing/scalar-provider.rs', copies: [base + '/scalar-provider.rs', base + '/machine/scalar-provider.rs']},
  providerConfig: {source: '/tmp/snail-native-lto-20261016/probe/six/gcbench/timing/case-config.rs', copies: [base + '/case-config.rs', base + '/machine/case-config.rs']},
  guestMachineObject: {source: '/tmp/snail-native-lto-20261016/probe/six/gcbench/native/module.o', copies: [base + '/machine/module.o']},
  guestBitcode: {source: '/tmp/snail-native-lto-20261016/probe/six/gcbench/native/module.bc', copies: [base + '/module.bc']},
  boundary: {source: '/tmp/snail-native-lto-20261016/probe/six/boundary.o', copies: [base + '/boundary.o', base + '/machine/boundary.o']}
};
for (const file of Object.values(files)) {
  file.sha256 = sha(file.source);
  for (const copy of file.copies) if (sha(copy) !== file.sha256) throw Error('Copied input changed: ' + copy);
}
for (const arm of [...pair, ...arms]) if (sha(arm.program) !== arm.sha256) throw Error('Frozen binary changed');
const summary = {
  kind: 'Private additive immutable Fields cache ablation',
  baseline: '08f98ad1db244753c48a1739702ca894e50416da',
  source_route: 'sfir-native',
  case: 'gcbench',
  input: {depth: 20, configuredCount: 1, expectedResult: '1', stdin: 'none', predicate: 'entire unchanged frozen gcbench predicate'},
  unchangedInputs: files,
  runtimeNativeSha256: sha(base + '/runtime/src/native.rs'),
  patch: base + '/collector.patch',
  lifetimeProof: base + '/invariants.md',
  focusedTests: base + '/focused-tests.rs',
  validation: JSON.parse(readFileSync(base + '/validation-summary.json')),
  ltoArms: pair,
  machineArms: arms,
  ltoDiagnosticHardwareMean: delta,
  machineDiagnosticHardware: deltas(rows[0].hardware, rows[1].hardware),
  allNonTimeGcCountersIdentical: true,
  workloadCounts: Object.fromEntries(Object.entries(expected).filter(([key]) => !['mark_s', 'sweep_s'].includes(key))),
  completeGcbenchExecutions: {ltoStat: 4, ltoSampling: 2, machineStat: 2},
  staticEvidence: 'Fields edge loop shrinks from 21 to 9 instructions, retaining offset < extent and the unchanged mark exact-start checks',
  measurementRecommendation: 'Worth separate controlled timing of each linkage pair; diagnostic cycle/time reductions are not clean timing and machine effect is independent of LTO effect',
  timingEnvironment: 'Unset SNAIL_GC_STATS, SNAIL_NATIVE_GC_INTERVAL and SNAIL_GC_* policy overrides; use ordinary runtime defaults',
  uninstrumentedTimingBinaries: true,
  cleanTiming: 'not-measured',
  productionEdits: false,
  allHeavyJobsExited: true
};
save(base + '/summary.json', summary);
console.log(JSON.stringify({allNonTimeGcCountersIdentical: true, ltoInstructionPercent: delta['cpu_core/instructions/u'].percent, ltoCyclePercent: delta['cpu_core/cycles/u'].percent, machineArms: arms.map(({arm, program, sha256}) => ({arm, program, sha256}))}, null, 2));
