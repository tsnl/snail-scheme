import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';

const root = '/tmp/snail-native-allocator-20261016/probe/gcbench-field-layout-20261016';
const perf = '/nix/store/apffmxq24i2xf89m4llsz4yc2sc1bv94-perf-linux-7.2.3/bin/perf';
const arms = JSON.parse(readFileSync(root + '/arms.json'));
if (arms.length !== 2) throw Error('Both arms must be built first');
const env = {...process.env};
for (const key of Object.keys(env)) if (key.startsWith('SNAIL_GC_') || key === 'SNAIL_NATIVE_GC_INTERVAL') delete env[key];
env.SNAIL_GC_STATS = '1';
const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const attempts = [];
function run(arm, label, command, args) {
  const dir = root + '/' + arm.arm;
  const prefix = dir + '/' + label;
  const commandSpec = {command: [command, ...args], cwd: root, overrides: {SNAIL_GC_STATS: '1'}, unset: ['all other SNAIL_GC_*', 'SNAIL_NATIVE_GC_INTERVAL'], cleanTiming: false, purpose: 'instrumented, possibly contended diagnostic'};
  save(prefix + '.command.json', commandSpec);
  const started = new Date().toISOString();
  const result = spawnSync(command, args, {cwd: root, env, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024});
  writeFileSync(prefix + '.stdout', result.stdout ?? '');
  writeFileSync(prefix + '.stderr', result.stderr ?? '');
  const attempt = {arm: arm.arm, label, started, finished: new Date().toISOString(), status: result.status, signal: result.signal, error: result.error?.message, programSha256: sha(arm.program)};
  attempts.push(attempt);
  save(root + '/diagnostic-attempts.json', attempts);
  console.log(arm.arm, label, result.status, result.error?.message ?? '');
  if (result.status !== 0 || attempt.programSha256 !== arm.sha256) throw Error('Diagnostic failed');
  return result;
}
const statEvents = 'cpu_core/cycles/u,cpu_core/instructions/u,cpu_core/branches/u,cpu_core/branch-misses/u,cpu_core/cache-misses/u';
for (const [round, order] of [[0, arms], [1, arms.toReversed()]]) {
  for (const arm of order) run(arm, 'stat-' + round, perf, ['stat', '-x', ';', '-e', statEvents, '-o', root + '/' + arm.arm + '/stat-' + round + '.csv', '--', 'taskset', '-c', '2', arm.program]);
}
for (const arm of arms) {
  run(arm, 'profile', perf, ['record', '-e', 'cycles:u', '-F', '1999', '--call-graph', 'dwarf,8192', '-o', root + '/' + arm.arm + '/profile.data', '--', 'taskset', '-c', '2', arm.program]);
  run(arm, 'report', perf, ['report', '--stdio', '--no-children', '--no-call-graph', '--percent-limit', '.25', '-i', root + '/' + arm.arm + '/profile.data']);
  run(arm, 'collect-annotate', perf, ['annotate', '--stdio', '--no-source', '--symbol', 'snail_runtime::native_gc::Collector::collect', '-i', root + '/' + arm.arm + '/profile.data']);
  run(arm, 'disassembly', 'objdump', ['-d', '-C', arm.program]);
}
function gc(prefix) {
  const stderr = readFileSync(prefix + '.stderr', 'utf8');
  const line = stderr.split('\n').find(line => line.startsWith('immix-gc '));
  if (!line) throw Error('Missing GC statistics: ' + prefix);
  const counters = Object.fromEntries([...line.matchAll(/([a-z_]+)=([^ ]+)/g)].map(match => [match[1], /^\d+(?:\.\d+)?$/.test(match[2]) ? Number(match[2]) : match[2]]));
  const stdout = readFileSync(prefix + '.stdout', 'utf8').trim().split('\n').filter(line => line.startsWith('{')).map(line => JSON.parse(line));
  if (stdout.length !== 1 || stdout[0].result !== '1') throw Error('Predicate mismatch: ' + prefix);
  return {counters, predicate: stdout[0]};
}
function stat(path) {
  return Object.fromEntries(readFileSync(path, 'utf8').split('\n').filter(line => line.includes('cpu_core/')).map(line => {
    const fields = line.split(';'); return [fields[2], Number(fields[0])];
  }));
}
const rows = [];
for (const arm of arms) for (const round of [0, 1]) rows.push({arm: arm.arm, round, ...gc(root + '/' + arm.arm + '/stat-' + round), hardware: stat(root + '/' + arm.arm + '/stat-' + round + '.csv')});
const control = rows[0].counters;
const differences = [];
for (const row of rows) for (const key of Object.keys(control)) if (!['mark_s', 'sweep_s'].includes(key) && row.counters[key] !== control[key]) differences.push({arm: row.arm, round: row.round, key, expected: control[key], actual: row.counters[key]});
save(root + '/diagnostic-summary.json', {rows, differences, sameNonTimeGcCounters: differences.length === 0, cleanTiming: 'not-measured', instrumented: true});
if (differences.length) throw Error('Collector counter mismatch');
