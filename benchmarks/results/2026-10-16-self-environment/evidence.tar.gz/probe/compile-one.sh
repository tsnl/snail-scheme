#!/bin/sh
set -eu
self_root=/tmp/snail-self-environment-20261016
. "$self_root/probe/build-env.sh"
self_arm=$1
self_source=$2
self_output=$3
shift 3
mkdir -p "$self_output"
if test "$self_arm" = control; then
    export CHIBI_MODULE_PATH="$self_root/probe/control-src:$self_root/src:$self_root/wasm-native/scheme:$CHIBI_MODULE_PATH"
else
    export CHIBI_MODULE_PATH="$self_root/src:$self_root/wasm-native/scheme:$CHIBI_MODULE_PATH"
fi
export SNAIL_PROCESS_RECORD="$self_output/compile-process.json"
"$SNAIL_NATIVE_SUPERVISOR" --command 120000 -- "$CHIBI" "$self_root/probe/compile-source.scm" "$self_root" "$self_source" "$self_output" "$@" > "$self_output/compile.stdout" 2> "$self_output/compile.stderr"
