#!/bin/sh
set -eu
self_root=/tmp/snail-self-environment-20261016
. "$self_root/probe/build-env.sh"
for self_arm in control candidate; do
    self_output=$self_root/probe/contract/$self_arm
    if test "$self_arm" = control; then
        sh "$self_root/probe/compile-one.sh" "$self_arm" "$self_root/probe/self-contract.sfir" "$self_output" -
    fi
    export SNAIL_PROCESS_RECORD="$self_output/wasm-process.json"
    "$SNAIL_NATIVE_SUPERVISOR" --command 30000 -- "$NODE" --no-wasm-async-compilation "$self_root/tests/sfir-integration/run.mjs" "$self_output/optimized.wasm" 42 > "$self_output/wasm.stdout" 2> "$self_output/wasm.stderr"
    printf 'contract %s passed\n' "$self_arm"
done
self_tab=$(printf '\t')
while IFS="$self_tab" read -r self_case self_expected self_checks self_exports; do
    for self_arm in control candidate; do
        self_output=$self_root/probe/fixtures/$self_case/$self_arm
        # Export names are fixed identifiers from the repository case manifest.
        sh "$self_root/probe/compile-one.sh" "$self_arm" "$self_root/tests/sfir-integration/$self_case.sfir" "$self_output" - $self_exports
        export SNAIL_PROCESS_RECORD="$self_output/wasm-process.json"
        "$SNAIL_NATIVE_SUPERVISOR" --command 30000 -- "$NODE" --no-wasm-async-compilation "$self_root/tests/sfir-integration/run.mjs" "$self_output/optimized.wasm" "$self_expected" "$self_checks" > "$self_output/wasm.stdout" 2> "$self_output/wasm.stderr"
        printf '%s %s passed\n' "$self_case" "$self_arm"
    done
done < "$self_root/probe/fixtures.tsv"
