import fs from 'node:fs';
const root = '/tmp/snail-self-environment-20261016';
const probe = `${root}/probe`;
fs.mkdirSync(`${probe}/cargo-home`, {recursive:true});
fs.mkdirSync(`${probe}/system-libraries`, {recursive:true});
fs.copyFileSync('/tmp/snail-native-host-cpu-20261016/probe/cargo-home/config.toml', `${probe}/cargo-home/config.toml`);
try {fs.symlinkSync('/nix/store/0vqb1mcas5j8dv6bhbrshinlgsg6bvgi-gcc-15.3.0-lib/lib/libgcc_s.so.1', `${probe}/system-libraries/libgcc_s.so`);} catch(error) {if(error.code !== 'EEXIST') throw error;}
const selected = ['mutual-recursion', 'specialized-shared-state', 'capture-initializer-scope', 'capture-recursive-alias', 'direct-early-call-order', 'direct-early-read-order', 'direct-escaping-chain', 'direct-activation-cells'];
const cases = JSON.parse(fs.readFileSync(`${root}/tests/sfir-integration/cases.json`));
fs.writeFileSync(`${probe}/fixtures.tsv`, selected.map(name => {
  const fixture = cases.find(item => item.name === name);
  if(!fixture) throw new Error(name);
  return [name, fixture.result, JSON.stringify(fixture.exports || {}), Object.keys(fixture.exports || {}).join(' ')].join('\t');
}).join('\n')+'\n');
