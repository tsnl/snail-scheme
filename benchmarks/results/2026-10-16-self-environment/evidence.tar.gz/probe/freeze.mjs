import fs from 'node:fs';
import crypto from 'node:crypto';
const root='/tmp/snail-self-environment-20261016';
const probe=`${root}/probe`;
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const frozen='/tmp/sfir-native-parity-baseline-20261016';
const boundary='/tmp/snail-native-lto-20261016/probe/six/boundary.o';
const files={};
const add=file=>files[file]=hash(file);
for(const file of ['src/snail-scheme/strict-wasm.sld','tests/sfir-integration/direct-self-environment.sfir','tests/sfir-integration/cases.json','benchmarks/sfir/array1/main.sfir','wasm-native/scheme/wasm-native/llvm.sld','wasm-native/scheme/wasm-native/native-build.sld']) add(`${root}/${file}`);
for(const file of ['strict-wasm.control.sld','compile-source.scm','compile-one.sh','build-native.sh','build-env.sh','contract-main.rs','self-contract.sfir','shared-source.scm','wat-proof.scm','array-main.rs','build/Cargo.toml','build/Cargo.lock','build/case-config.rs']) add(`${probe}/${file}`);
for(const file of ['scalar-provider.rs','scalar-timing-entry.rs','case-config.rs','spec.json']) add(`${frozen}/timing/artifacts/array1/${file}`);
add(`${frozen}/source/benchmarks/sfir/array1/main.sfir`);
add(boundary);
const frozenSource=files[`${frozen}/source/benchmarks/sfir/array1/main.sfir`];
if(files[`${root}/benchmarks/sfir/array1/main.sfir`]!==frozenSource) throw new Error('canonical array1 source changed');
const arms=[];
const check=file=>{
  const record=JSON.parse(fs.readFileSync(file));
  if(record.exit_code!==0 || !record.descendants_gone || record.timed_out || record.signal || record.executing_descendants.length || record.unexpected_descendants.length) throw new Error(`process failure: ${file}`);
  add(file);return record;
};
for(const kind of ['contract','array1']) for(const arm of ['control','candidate']) {
  const dir=`${probe}/${kind}/${arm}`;
  for(const file of ['raw.wat','raw.wasm','optimized.wasm','optimized.wat','module.ll','module.o','module.o.bc']) add(`${dir}/${file}`);
  check(`${dir}/${arm==='candidate'&&kind==='contract'?'compile-fixed2-process.json':'compile-process.json'}`);
  const wasmRecord=kind==='contract'?'wasm-process.json':'wasm-correctness-process.json';
  check(`${dir}/${wasmRecord}`);
  for(const mode of ['machine','lto']) {
    const build=`${dir}/${mode}`;
    for(const file of ['program','0.0.preopt.bc','0.4.opt.bc','0.0.preopt.ll','0.4.opt.ll','main.rs','build.rs','rustflags.encoded','assembly.txt','correctness.stdout']) add(`${build}/${file}`);
    check(`${build}/build-process.json`);check(`${build}/correctness-process.json`);
    if(kind==='contract') check(`${build}/forced-gc-process.json`);
    arms.push({kind,arm,mode,program:`${build}/program`,sha256:files[`${build}/program`],predicate:kind==='contract'?'result == 42':'configured count 1, input [500,1000000], full result == 1000000',opacity:kind==='contract'?'not applicable':boundary});
  }
}
const fixtureNames=fs.readFileSync(`${probe}/fixtures.tsv`,'utf8').trim().split('\n').map(line=>line.split('\t')[0]);
for(const name of fixtureNames) for(const arm of ['control','candidate']) {
  const dir=`${probe}/fixtures/${name}/${arm}`;
  check(`${dir}/compile-process.json`);check(`${dir}/wasm-process.json`);
  add(`${dir}/optimized.wasm`);
}
for(const file of ['shared.wasm','shared-proof.scm','shared-run.stdout','contract/wat-proof-fixed.scm','array1/wat-proof.scm']) add(`${probe}/${file}`);
const proof=[];
for(const arm of ['control','candidate']) for(const mode of ['machine','lto']) {
  const dir=`${probe}/array1/${arm}/${mode}`;
  const ir=fs.readFileSync(`${dir}/0.4.opt.ll`,'utf8');
  const assembly=fs.readFileSync(`${dir}/assembly.txt`,'utf8');
  const functions=[];
  for(const name of ['f.6','f.8']) {
    const body=ir.match(new RegExp(`^define[^\\n]*@${name.replace('.','\\.')}\\([^\\n]*\\{\\n[\\s\\S]*?^\\}`, 'm'))?.[0];
    const machine=assembly.match(new RegExp(`^[0-9a-f]+ <${name.replace('.','\\.')} >:[\\s\\S]*?(?=\\n\\n)`.replace(' >','>'),'m'))?.[0];
    if(!machine) throw new Error(`missing final loop ${arm}/${mode}/${name}`);
    fs.writeFileSync(`${dir}/${name}.assembly.txt`,machine+'\n');
    if(body) fs.writeFileSync(`${dir}/${name}.ll`,body+'\n');
    functions.push({name,irPresent:!!body,machineInstructions:machine.split('\n').length-1,envPhi:body?.split('\n').filter(line=>/%arg0[^=]*= phi/.test(line)),envRegisterWrites:machine.split('\n').filter(line=>/\b(?:mov|lea|add|sub|xor|pop)\w*\s+.*,\s*%rdi\b/.test(line)),arrayWork:machine.split('\n').filter(line=>/0x10\([^)]*,[^)]*,8\)/.test(line))});
  }
  const hideCalls=(ir.match(/\bcall\b[^\n]*@benchmark_opaque_hide_i64\(/g)||[]).length;
  const machineHideCalls=(assembly.match(/\bcallq\s+[^\n]*<benchmark_opaque_hide_i64>/g)||[]).length;
  if(machineHideCalls<2 || (mode==='lto' && hideCalls<2)) throw new Error('opaque hide calls vanished');
  proof.push({arm,mode,functions,hideCalls,machineHideCalls,opacityBoundaryHash:hash(boundary)});
}
fs.writeFileSync(`${probe}/machine-proof.json`,JSON.stringify(proof,null,2)+'\n');add(`${probe}/machine-proof.json`);
const output={base:'0a765e72',branch:'prototype-self-environment-20261016',worktree:root,scope:'emitter self-instance environment evidence only; mechanical native lowering unchanged',status:'diagnostic correctness complete; no clean measurements',wasmChecks:18,nativeContractChecks:8,arrayNativeChecks:4,arrayWasmChecks:2,sourceSharing:{publicCompilePassed:true,identicalLambdaPreserved:true,bindings:[['first',4,13],['second',5,9]]},arms,wasmArms:['control','candidate'].map(arm=>({arm,artifact:`${probe}/array1/${arm}/optimized.wasm`,sha256:hash(`${probe}/array1/${arm}/optimized.wasm`),runner:`${root}/benchmarks/sfir/support/scalar-host.mjs`,specification:`${frozen}/timing/artifacts/array1/spec.json`,validateBarriers:2})),files};
fs.writeFileSync(`${probe}/freeze.json`,JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({arms,wasmArms:output.wasmArms},null,2));
