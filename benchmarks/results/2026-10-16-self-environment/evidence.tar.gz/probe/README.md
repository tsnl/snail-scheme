# Lexical self-closure environment prototype

This is an isolated, unlanded emitter experiment from main `0a765e72`, in
`prototype-self-environment-20261016`. No native lowering, runtime, benchmark
workload, compiler portability policy, or shared-LTO product code changed.
`freeze.json` fixes the runnable artifacts, hashes, exact helper sources, encoded
Rust flags, and supervisor success/reaping records. The emitted code has passed
focused correctness checks; no clean measurements have been taken here.

## Soundness argument

Let binding B have exact lambda initializer L. Its concrete value request has an
instance ID. `request-function` keys L's implementation by lexical owner, concrete
instance, source node, and function type. The prototype recognizes a self
reference only if (1) B's known function ID is the currently executing function
owner and (2) B's entire initializer is that function's source lambda. Aliases
fail (2); another function, nested closure, mutual recursion, or another concrete
implementation fails (1). A lambda hidden inside a larger initializer does not
qualify.

The existing frontend invariant in `prepare-activation` reserves each lexical
scope once per activation, and recursive activations receive fresh private
binding cells. B is initialized once to closure C=(F,E). Any execution of F for
that activation was entered with E, and its exact lexical B still refers to C.
Thus the self call can pass the current E. Different factory activations may
share F's code, but their private B/E pairs remain separate. This proof depends
on the existing lexical binding/activation contract, not on unique source-node
allocation or code identity alone.

Generated-library inputs can share the exact same lambda node between two
binding initializers. `shared-source.scm` constructs that case through the public
library/compile API. `library-map->core` preserves the sharing, but the concrete
values have IDs 4/5 and their implementations have IDs 13/9. The assertion checks
all three facts and public compilation/execution returns 42. In the second
implementation, a call to the first binding therefore fails the owner test.

The whole existing operator read remains after arguments, including readiness
and reference checks. Only its eventual call environment changes. Captured
values, cells, closure allocation, direct versus indirect call selection, and
tail versus ordinary calls retain their original structure. `wat-proof.scm`
compares original and candidate raw Wasm datums and accepts only this substitution
in a known-function call, recursively checking every other argument/expression.
There are exactly nine substitutions in array1 and nine in the custom contract,
including an ordinary non-tail recursive call. Every changed call targets its
enclosing function. Native LLVM receives ordinary Wasm and no new assumptions.

## Correctness and retained work

- Baseline and candidate execute the custom contract plus eight existing
  capture/alias/activation/readiness/order fixtures in V8: 18 checks pass. The
  exported trap/effect probes observe 1, 12, and 7 as specified by the existing
  manifest; exact Wasm comparison also preserves their original check order.
- Four native custom-contract arms (machine guest or shared-LTO guest, baseline
  or candidate) pass normally and with `SNAIL_NATIVE_GC_INTERVAL=1`: eight checks.
  Allocating paths remain in the final LTO IR. This covers two captured factory
  activations, ordinary aliases, nested closures calling an outer function,
  non-tail recursion, and Bool/I64 instances of a generic recursive function.
- All four array1 native arms return the complete expected result 1000000 with
  original count 1 and inputs [500,1000000]. Both optimized Wasm arms pass their
  complete predicate and observe exactly two barriers. Supervisor records show
  exit 0, no timeout, and all descendants gone.
- The control optimized Wasm hash exactly equals the prior frozen six-case
  artifact. Candidate V8 and both candidate native modes use the same new
  optimized Wasm. Mandatory Binaryen policy stays unchanged.
- `machine-proof.json` and each arm's `f.6`/`f.8` extracts show retained indexed
  array copy/store instructions and induction loops. All three static opaque
  hide calls remain in every final native program. The extra static site is a
  separate reachable helper, not an extra observed benchmark barrier.
- In final LTO control, f.6/f.8 carry `%arg0` through a phi and reload next E
  through the binding's closure. In the candidate, neither function has an env
  phi or any instruction writing environment register `%rdi`. The binding
  readiness and payload non-null checks still execute. Candidate f.6 has slightly
  more static instructions but a shorter loop-carried dependency.

The native benchmark provider, entry, config, and canonical workload are exact
copies/references from the frozen six-case evidence. The identical opaque
machine-code boundary object is used in all four native arms. Ordinary product
providers receive no harness-specific opacity rule. Both Rust flags and guest
prelink optimization are identical between baseline and candidate; the machine
arm supplies genuine `module.o`, while LTO supplies its explicit `module.o.bc`.
The Cargo flags are target-only via `--target x86_64-unknown-linux-gnu`, preserving
host build-script compilation. No host CPU or fast-math flags were added.

## Replay and measurement boundary

Source compilation:

```sh
sh probe/compile-one.sh control "$PWD/benchmarks/sfir/array1/main.sfir" "$PWD/probe/array1/control" /tmp/sfir-native-parity-baseline-20261016/timing/artifacts/array1/scalar-provider.rs bench
sh probe/compile-one.sh candidate "$PWD/benchmarks/sfir/array1/main.sfir" "$PWD/probe/array1/candidate" /tmp/sfir-native-parity-baseline-20261016/timing/artifacts/array1/scalar-provider.rs bench
sh probe/build-native.sh array1
```

Those commands document construction; do not rerun them into these frozen paths.
For a new run, copy the helpers and use a fresh destination. Each build retains
verbose Cargo/Rust argv, pre-LTO and post-LTO IR, assembly, stdout/stderr, exit
code, and the direct supervisor record. The direct supervisor avoids the earlier
Node spawnSync status/error ambiguity.

Native clean-run entry points are fixed at
`array1/{control,candidate}/{machine,lto}/program`. V8 entry points are fixed at
`array1/{control,candidate}/optimized.wasm`, using the unchanged scalar host and
frozen spec paths listed in `freeze.json`; omit `--validate` for a clean run.
The single correctness-run time fields are instrumented/concurrent diagnostics,
not clean performance evidence. No repeated measurement campaign was run.

## Failures and review limits

Initial prototype import had an extra closing parenthesis; the original import
error is retained. The generated-library helper initially omitted `filter`'s
import. The custom contract initially had an unmatched parenthesis and then used
unsupported `and`; its original error files remain beside the successful
`compile-fixed2-process.json`. The first freeze verifier mistakenly required guest
calls in machine-arm Rust-only IR; `freeze.stderr` retains that failure and the
corrected verifier checks final machine calls for both modes. All native Cargo
attempts themselves succeeded.

The pinned simplify workflow was read and a fresh explainer was requested, but
the team thread limit rejected spawning. The local explanation/critique and
mechanical checks above are not an independent review. This prototype still
needs that review and clean paired timing before any landing decision. A comment
clarification made after compilation is recorded separately in
`compiler-provenance.json`; it has no executable source changes.
