unsafe extern "C" {
    fn native_host_init(argc: i32, argv: *const *const u8);
    fn native_module_init();
    fn native_finish(status: i32) -> i32;
    #[link_name = "wasm.main"]
    fn guest_main() -> i64;
}
fn main() {
    let status = unsafe {
        native_host_init(0, std::ptr::null());
        native_module_init();
        let result = guest_main();
        assert_eq!(result, 42);
        println!("result {result}");
        native_finish(0)
    };
    std::process::exit(status);
}
extern crate snail_runtime as _;
