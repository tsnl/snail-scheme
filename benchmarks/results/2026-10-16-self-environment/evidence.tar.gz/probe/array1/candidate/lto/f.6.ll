define internal tailcc i64 @f.6(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %v919 = icmp slt i64 %arg1, 0
  br i1 %v919, label %then14, label %else13.preheader.split

else13.preheader.split:                           ; preds = %entry
  %v41.first_iter = icmp samesign ugt i64 %arg1, 4294967295
  %0 = icmp eq i64 %arg0, 0
  br i1 %0, label %native_ref_test.exit, label %1

1:                                                ; preds = %else13.preheader.split
  %2 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %2, 0
  br i1 %.not.i, label %3, label %native_ref_test.exit

3:                                                ; preds = %1
  %4 = inttoptr i64 %arg0 to ptr
  %5 = load i64, ptr %4, align 8, !noundef !39
  %6 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hebaa5fcef3ba85fcE.0, align 8, !noundef !39
  %7 = icmp eq ptr %6, null
  br i1 %7, label %20, label %8

8:                                                ; preds = %3
  switch i64 %5, label %9 [
    i64 6, label %.loopexit23
    i64 0, label %.loopexit23
  ]

9:                                                ; preds = %8
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 360
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = lshr i64 %5, 2
  %13 = add nsw i64 %12, -1
  %14 = icmp ult i64 %13, %11
  br i1 %14, label %15, label %.loopexit22

15:                                               ; preds = %9
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 352
  %17 = load ptr, ptr %16, align 8, !nonnull !39, !noundef !39
  %18 = getelementptr inbounds nuw i64, ptr %17, i64 %13
  %19 = load i64, ptr %18, align 8, !noundef !39
  switch i64 %19, label %.preheader21 [
    i64 6, label %.loopexit23
    i64 0, label %.loopexit23
  ]

20:                                               ; preds = %3
  tail call fastcc void @native_trap() #113
  unreachable

.loopexit23:                                      ; preds = %26, %26, %15, %15, %8, %8
  %.in = phi i64 [ %5, %8 ], [ %19, %15 ], [ %19, %15 ], [ %5, %8 ], [ %28, %26 ], [ %28, %26 ]
  %21 = icmp ne i64 %.in, 6
  br label %native_ref_test.exit

.preheader21:                                     ; preds = %26, %15
  %22 = phi i64 [ %28, %26 ], [ %19, %15 ]
  %23 = lshr i64 %22, 2
  %24 = add nsw i64 %23, -1
  %25 = icmp ult i64 %24, %11
  br i1 %25, label %26, label %.loopexit22

.loopexit22:                                      ; preds = %.preheader21, %9
  tail call fastcc void @native_trap() #113
  unreachable

26:                                               ; preds = %.preheader21
  %27 = getelementptr inbounds nuw i64, ptr %17, i64 %24
  %28 = load i64, ptr %27, align 8, !noundef !39
  switch i64 %28, label %.preheader21 [
    i64 6, label %.loopexit23
    i64 0, label %.loopexit23
  ]

native_ref_test.exit:                             ; preds = %.loopexit23, %1, %else13.preheader.split
  %.not.i6 = phi i1 [ true, %.loopexit23 ], [ false, %1 ], [ true, %else13.preheader.split ]
  %.pre-phi27 = phi i64 [ 0, %.loopexit23 ], [ 1, %1 ], [ 0, %else13.preheader.split ]
  %29 = phi i1 [ %21, %.loopexit23 ], [ true, %1 ], [ true, %else13.preheader.split ]
  %v35 = inttoptr i64 %arg0 to ptr
  %v36 = getelementptr i8, ptr %v35, i64 16
  %v52 = getelementptr i8, ptr %v35, i64 8
  %v107 = getelementptr i8, ptr %v35, i64 24
  br label %else13

then14:                                           ; preds = %entry
  %30 = icmp eq i64 %arg0, 0
  br i1 %30, label %trap19, label %then14.then14.thread_crit_edge

then14.then14.thread_crit_edge:                   ; preds = %then14
  %.pre = and i64 %arg0, 1
  br label %then14.thread

then14.thread:                                    ; preds = %native_roots_leave.exit5, %then14.then14.thread_crit_edge
  %.pre-phi = phi i64 [ %.pre, %then14.then14.thread_crit_edge ], [ %.pre-phi27, %native_roots_leave.exit5 ]
  %.not.i3 = icmp eq i64 %.pre-phi, 0
  br i1 %.not.i3, label %31, label %trap19

31:                                               ; preds = %then14.thread
  %32 = inttoptr i64 %arg0 to ptr
  %33 = load i64, ptr %32, align 8, !noundef !39
  %34 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hebaa5fcef3ba85fcE.0, align 8, !noundef !39
  %35 = icmp eq ptr %34, null
  br i1 %35, label %48, label %36

36:                                               ; preds = %31
  switch i64 %33, label %37 [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

37:                                               ; preds = %36
  %38 = getelementptr inbounds nuw i8, ptr %34, i64 360
  %39 = load i64, ptr %38, align 8, !noundef !39
  %40 = lshr i64 %33, 2
  %41 = add nsw i64 %40, -1
  %42 = icmp ult i64 %41, %39
  br i1 %42, label %43, label %.loopexit

43:                                               ; preds = %37
  %44 = getelementptr inbounds nuw i8, ptr %34, i64 352
  %45 = load ptr, ptr %44, align 8, !nonnull !39, !noundef !39
  %46 = getelementptr inbounds nuw i64, ptr %45, i64 %41
  %47 = load i64, ptr %46, align 8, !noundef !39
  switch i64 %47, label %.preheader [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

48:                                               ; preds = %31
  tail call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %53, %43
  %49 = phi i64 [ %55, %53 ], [ %47, %43 ]
  %50 = lshr i64 %49, 2
  %51 = add nsw i64 %50, -1
  %52 = icmp ult i64 %51, %39
  br i1 %52, label %53, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %37
  tail call fastcc void @native_trap() #113
  unreachable

53:                                               ; preds = %.preheader
  %54 = getelementptr inbounds nuw i64, ptr %45, i64 %51
  %55 = load i64, ptr %54, align 8, !noundef !39
  switch i64 %55, label %.preheader [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

native_ref_test.exit4:                            ; preds = %53, %53, %43, %43, %36, %36
  %.in43 = phi i64 [ %33, %36 ], [ %47, %43 ], [ %47, %43 ], [ %33, %36 ], [ %55, %53 ], [ %55, %53 ]
  %56 = icmp eq i64 %.in43, 6
  br i1 %56, label %ok20, label %trap19

trap19:                                           ; preds = %native_ref_test.exit4, %then14.thread, %then14
  tail call fastcc void @native_trap()
  unreachable

ok20:                                             ; preds = %native_ref_test.exit4
  %v21.not = icmp eq i64 %arg0, 0
  br i1 %v21.not, label %trap22, label %ok23

trap22:                                           ; preds = %ok20
  tail call fastcc void @native_trap()
  unreachable

ok23:                                             ; preds = %ok20
  %v25 = getelementptr i8, ptr %32, i64 16
  %v26 = load i64, ptr %v25, align 1
  ret i64 %v26

else13:                                           ; preds = %else13.backedge, %native_ref_test.exit
  %phi.call = phi i1 [ %29, %native_ref_test.exit ], [ %phi.call.be, %else13.backedge ]
  %arg1.tr21 = phi i64 [ %arg1, %native_ref_test.exit ], [ %v139, %else13.backedge ]
  br i1 %phi.call, label %trap30, label %ok31

trap30:                                           ; preds = %else13
  tail call fastcc void @native_trap()
  unreachable

ok31:                                             ; preds = %else13
  br i1 %0, label %trap33, label %ok34

trap33:                                           ; preds = %ok31
  tail call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %ok31
  %v37 = load i64, ptr %v36, align 1
  br i1 %v41.first_iter, label %then45, label %ok50

then45:                                           ; preds = %ok34
  tail call fastcc void @native_trap()
  unreachable

ok50:                                             ; preds = %ok34
  %v53 = load i64, ptr %v52, align 1
  %v56.not = icmp eq i64 %v53, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %ok50
  tail call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok50
  %v59 = and i64 %v53, 1
  %v60 = icmp eq i64 %v59, 0
  br i1 %v60, label %ok62, label %trap61

trap61:                                           ; preds = %ok58
  tail call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok58
  %v63 = inttoptr i64 %v53 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load i64, ptr %v64, align 1
  %v67 = icmp ult i64 %arg1.tr21, %v65
  br i1 %v67, label %ok69, label %trap68

trap68:                                           ; preds = %ok62
  tail call fastcc void @native_trap()
  unreachable

ok69:                                             ; preds = %ok62
  %v71 = getelementptr i8, ptr %v63, i64 16
  %v72 = getelementptr i64, ptr %v71, i64 %arg1.tr21
  %v73 = load i64, ptr %v72, align 1
  %v85.not = icmp eq i64 %v37, 0
  br i1 %v85.not, label %trap86, label %ok87

trap86:                                           ; preds = %ok69
  tail call fastcc void @native_trap()
  unreachable

ok87:                                             ; preds = %ok69
  %v88 = and i64 %v37, 1
  %v89 = icmp eq i64 %v88, 0
  br i1 %v89, label %ok91, label %trap90

trap90:                                           ; preds = %ok87
  tail call fastcc void @native_trap()
  unreachable

ok91:                                             ; preds = %ok87
  %v92 = inttoptr i64 %v37 to ptr
  %v93 = getelementptr i8, ptr %v92, i64 8
  %v94 = load i64, ptr %v93, align 1
  %v96 = icmp ult i64 %arg1.tr21, %v94
  br i1 %v96, label %ok98, label %trap97

trap97:                                           ; preds = %ok91
  tail call fastcc void @native_trap()
  unreachable

ok98:                                             ; preds = %ok91
  %v100 = getelementptr i8, ptr %v92, i64 16
  %v101 = getelementptr i64, ptr %v100, i64 %arg1.tr21
  store i64 %v73, ptr %v101, align 1
  %v108 = load i64, ptr %v107, align 1
  %v109.not = icmp eq i64 %v108, 0
  br i1 %v109.not, label %trap110, label %ok111

trap110:                                          ; preds = %ok98
  tail call fastcc void @native_trap()
  unreachable

ok111:                                            ; preds = %ok98
  %v112 = inttoptr i64 %v108 to ptr
  %v113 = getelementptr i8, ptr %v112, i64 8
  %v114 = load i32, ptr %v113, align 1
  %v115 = icmp eq i32 %v114, 0
  br i1 %v115, label %then119, label %ok130

then119:                                          ; preds = %ok111
  tail call fastcc void @native_trap()
  unreachable

ok130:                                            ; preds = %ok111
  %v132 = getelementptr i8, ptr %v112, i64 16
  %v133 = load i64, ptr %v132, align 1
  %v134.not = icmp eq i64 %v133, 0
  br i1 %v134.not, label %trap135, label %native_roots_leave.exit5

trap135:                                          ; preds = %ok130
  tail call fastcc void @native_trap()
  unreachable

native_roots_leave.exit5:                         ; preds = %ok130
  %v9 = icmp eq i64 %arg1.tr21, 0
  br i1 %v9, label %then14.thread, label %57

57:                                               ; preds = %native_roots_leave.exit5
  %v139 = add nsw i64 %arg1.tr21, -1
  br i1 %.not.i6, label %58, label %else13.backedge

else13.backedge:                                  ; preds = %.loopexit19, %57
  %phi.call.be = phi i1 [ %75, %.loopexit19 ], [ true, %57 ]
  br label %else13

58:                                               ; preds = %57
  %59 = load i64, ptr %v35, align 8, !noundef !39
  %60 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hebaa5fcef3ba85fcE.0, align 8, !noundef !39
  %61 = icmp eq ptr %60, null
  br i1 %61, label %74, label %62

62:                                               ; preds = %58
  switch i64 %59, label %63 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

63:                                               ; preds = %62
  %64 = getelementptr inbounds nuw i8, ptr %60, i64 360
  %65 = load i64, ptr %64, align 8, !noundef !39
  %66 = lshr i64 %59, 2
  %67 = add nsw i64 %66, -1
  %68 = icmp ult i64 %67, %65
  br i1 %68, label %69, label %.loopexit18

69:                                               ; preds = %63
  %70 = getelementptr inbounds nuw i8, ptr %60, i64 352
  %71 = load ptr, ptr %70, align 8, !nonnull !39, !noundef !39
  %72 = getelementptr inbounds nuw i64, ptr %71, i64 %67
  %73 = load i64, ptr %72, align 8, !noundef !39
  switch i64 %73, label %.preheader17 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

74:                                               ; preds = %58
  tail call fastcc void @native_trap() #113
  unreachable

.loopexit19:                                      ; preds = %80, %80, %69, %69, %62, %62
  %.in42 = phi i64 [ %59, %62 ], [ %73, %69 ], [ %73, %69 ], [ %59, %62 ], [ %82, %80 ], [ %82, %80 ]
  %75 = icmp ne i64 %.in42, 6
  br label %else13.backedge

.preheader17:                                     ; preds = %80, %69
  %76 = phi i64 [ %82, %80 ], [ %73, %69 ]
  %77 = lshr i64 %76, 2
  %78 = add nsw i64 %77, -1
  %79 = icmp ult i64 %78, %65
  br i1 %79, label %80, label %.loopexit18

.loopexit18:                                      ; preds = %.preheader17, %63
  tail call fastcc void @native_trap() #113
  unreachable

80:                                               ; preds = %.preheader17
  %81 = getelementptr inbounds nuw i64, ptr %71, i64 %78
  %82 = load i64, ptr %81, align 8, !noundef !39
  switch i64 %82, label %.preheader17 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]
}
