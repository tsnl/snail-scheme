#!/bin/sh
set -eu
self_root=/tmp/snail-self-environment-20261016
self_probe=$self_root/probe
self_package=self_environment_probe
. "$self_probe/build-env.sh"
self_case=$1
for self_arm in control candidate; do
    self_guest=$self_probe/$self_case/$self_arm
    for self_mode in machine lto; do
        self_output=$self_guest/$self_mode
        mkdir -p "$self_output"
        if test "$self_mode" = machine; then self_link=$self_guest/module.o; else self_link=$self_guest/module.o.bc; fi
        if test "$self_case" = contract; then
            cp "$self_probe/contract-main.rs" "$self_probe/build/main.rs"
            printf 'fn main() { println!("cargo:rustc-link-arg={}", "%s"); }\n' "$self_link" > "$self_probe/build/build.rs"
        else
            cp "$self_probe/array-main.rs" "$self_probe/build/main.rs"
            printf 'fn main() { println!("cargo:rustc-link-arg={}", "%s"); println!("cargo:rustc-link-arg={}", "%s"); }\n' "$self_link" /tmp/snail-native-lto-20261016/probe/six/boundary.o > "$self_probe/build/build.rs"
        fi
        cp "$self_probe/build/main.rs" "$self_output/main.rs"
        cp "$self_probe/build/build.rs" "$self_output/build.rs"
        printf '%s' "$CARGO_ENCODED_RUSTFLAGS" > "$self_output/rustflags.encoded"
        export SNAIL_PROCESS_RECORD="$self_output/build-process.json"
        set +e
        "$SNAIL_NATIVE_SUPERVISOR" --command 120000 -- "$CARGO" build --offline --release --target x86_64-unknown-linux-gnu --manifest-path "$self_probe/build/Cargo.toml" --target-dir "$self_probe/target" -v > "$self_output/build.stdout" 2> "$self_output/build.stderr"
        self_exit=$?
        set -e
        printf '%s\n' "$self_exit" > "$self_output/build.exit"
        if test "$self_exit" -ne 0; then tail -n 12 "$self_output/build.stderr"; exit "$self_exit"; fi
        self_suffix=$(sed -n "/--crate-name $self_package /s/.*-C extra-filename=\([^ ]*\).*/\1/p" "$self_output/build.stderr")
        test -n "$self_suffix"
        cp "$self_probe/target/x86_64-unknown-linux-gnu/release/$self_package" "$self_output/program"
        for self_stage in 0.0.preopt 0.4.opt; do
            cp "$self_probe/target/x86_64-unknown-linux-gnu/release/deps/$self_package$self_suffix.$self_stage.bc" "$self_output/$self_stage.bc"
            llvm-dis "$self_output/$self_stage.bc" -o "$self_output/$self_stage.ll"
        done
        llvm-objdump -d --no-show-raw-insn "$self_output/program" > "$self_output/assembly.txt"
        export SNAIL_PROCESS_RECORD="$self_output/correctness-process.json"
        "$SNAIL_NATIVE_SUPERVISOR" --command 30000 -- "$self_output/program" > "$self_output/correctness.stdout" 2> "$self_output/correctness.stderr"
        if test "$self_case" = contract; then
            export SNAIL_PROCESS_RECORD="$self_output/forced-gc-process.json"
            SNAIL_NATIVE_GC_INTERVAL=1 "$SNAIL_NATIVE_SUPERVISOR" --command 30000 -- "$self_output/program" > "$self_output/forced-gc.stdout" 2> "$self_output/forced-gc.stderr"
        fi
        printf '%s %s %s passed\n' "$self_case" "$self_arm" "$self_mode"
    done
done
