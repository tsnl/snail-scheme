fn main() { println!("cargo:rustc-link-arg={}", "/tmp/snail-self-environment-20261016/probe/contract/candidate/module.o"); }
