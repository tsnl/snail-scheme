(module
 (rec
  (type $type5 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (mut i64))))
 )
 (type $3 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type25)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type26)) (ref.null none))
 (global $ready82 (mut i32) (i32.const 0))
 (global $global83 (mut (ref null $type5)) (ref.null none))
 (global $ready83 (mut i32) (i32.const 0))
 (global $global84 (mut (ref null $type5)) (ref.null none))
 (global $ready84 (mut i32) (i32.const 0))
 (export "checked" (func $export0))
 (export "observed" (func $export1))
 (export "main" (func $main))
 (func $export0 (result i64)
  (local $0 (ref $type25))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready83)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global83)
   )
  )
  (if
   (i32.eqz
    (global.get $ready82)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global82)
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global81)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready81)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (i64.mul
      (struct.get $type25 0
       (global.get $global81)
      )
      (i64.const 10)
     )
     (i64.const 1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready82)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global82)
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global81)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready81)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (i64.mul
      (struct.get $type25 0
       (global.get $global81)
      )
      (i64.const 10)
     )
     (i64.const 2)
    )
   )
  )
  (unreachable)
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type25 0
   (global.get $global81)
  )
 )
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type25)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type26)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $global83
   (struct.new_default $type5)
  )
  (global.set $ready83
   (i32.const 1)
  )
  (global.set $global84
   (struct.new_default $type5)
  )
  (global.set $ready84
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

