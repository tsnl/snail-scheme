(module
 (rec
  (type $type5 (struct))
  (type $type25 (struct (field (mut i64))))
 )
 (type $2 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global80 (mut (ref null $type25)) (ref.null none))
 (global $ready80 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type5)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type5)) (ref.null none))
 (global $ready82 (mut i32) (i32.const 0))
 (export "checked" (func $export0))
 (export "observed" (func $export1))
 (export "main" (func $main))
 (func $export0 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (global.get $global80)
   (i64.const 7)
  )
  (unreachable)
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready82)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global82)
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type25 0
   (global.get $global80)
  )
 )
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global80
   (struct.new_default $type25)
  )
  (global.set $ready80
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type5)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type5)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

