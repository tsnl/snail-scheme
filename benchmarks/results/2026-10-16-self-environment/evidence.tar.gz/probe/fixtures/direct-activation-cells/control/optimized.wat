(module
 (rec
  (type $type26 (struct (field (mut i32)) (field (mut (ref null $type25)))))
  (type $environment86 (struct (field (ref $type26))))
  (type $type25 (struct (field (ref null $environment86))))
 )
 (type $3 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type25)) (ref.null none))
 (export "main" (func $main))
 (func $main (result i64)
  (local $0 (ref null $environment86))
  (local $1 (ref $type26))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type25)
  )
  (drop
   (struct.get $type25 0
    (global.get $global78)
   )
  )
  (struct.set $type26 1
   (local.tee $1
    (struct.new_default $type26)
   )
   (struct.new $type25
    (struct.new $environment86
     (local.get $1)
    )
   )
  )
  (struct.set $type26 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (struct.get $environment86 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (struct.get $environment86 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (struct.get $environment86 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (struct.get $environment86 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (struct.get $environment86 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (struct.get $environment86 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type26 0
     (struct.get $environment86 0
      (local.tee $0
       (struct.get $type25 0
        (struct.get $type26 1
         (struct.get $environment86 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 0
    (struct.get $type26 1
     (struct.get $environment86 0
      (local.get $0)
     )
    )
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

