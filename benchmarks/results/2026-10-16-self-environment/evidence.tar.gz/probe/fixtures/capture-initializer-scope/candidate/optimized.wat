(module
 (rec
  (type $type27 (struct))
  (type $type28 (struct (field (ref $type5))))
  (type $environment96 (struct (field (ref $type27)) (field (ref $type28))))
  (type $call5 (func (param (ref null $environment96)) (result i64)))
  (type $type5 (struct (field (ref $call5)) (field (ref null $environment96))))
  (type $type26 (struct))
  (type $type25 (struct (field (mut i64))))
 )
 (type $7 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type25)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global82 (mut i64) (i64.const 0))
 (global $ready82 (mut i32) (i32.const 0))
 (global $global83 (mut (ref null $type26)) (ref.null none))
 (global $global84 (mut (ref null $type5)) (ref.null none))
 (export "main" (func $main))
 (func $function96 (type $call5) (param $0 (ref null $environment96)) (result i64)
  (local $1 (ref $type5))
  (drop
   (struct.get $environment96 0
    (local.get $0)
   )
  )
  (i64.add
   (call_ref $call5
    (struct.get $type5 1
     (local.tee $1
      (struct.get $type28 0
       (struct.get $environment96 1
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type5 0
     (local.get $1)
    )
   )
   (i64.const 1)
  )
 )
 (func $function99 (type $call5) (param $0 (ref null $environment96)) (result i64)
  (if
   (i32.eqz
    (global.get $ready82)
   )
   (then
    (unreachable)
   )
  )
  (global.get $global82)
 )
 (func $main (result i64)
  (local $0 i64)
  (local $1 (ref $type5))
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type25)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global82
   (i64.const 40)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $global83
   (struct.new_default $type26)
  )
  (drop
   (ref.as_non_null
    (global.get $global83)
   )
  )
  (struct.set $type25 0
   (global.get $global81)
   (i64.add
    (struct.get $type25 0
     (global.get $global81)
    )
    (i64.const 1)
   )
  )
  (struct.set $type25 0
   (global.get $global81)
   (i64.add
    (struct.get $type25 0
     (global.get $global81)
    )
    (i64.const 10)
   )
  )
  (global.set $global84
   (struct.new $type5
    (ref.func $function96)
    (struct.new $environment96
     (struct.new_default $type27)
     (struct.new $type28
      (struct.new $type5
       (ref.func $function99)
       (ref.null none)
      )
     )
    )
   )
  )
  (local.set $0
   (call_ref $call5
    (struct.get $type5 1
     (local.tee $1
      (ref.as_non_null
       (global.get $global84)
      )
     )
    )
    (struct.get $type5 0
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch
   (i64.add
    (struct.get $type25 0
     (global.get $global81)
    )
    (local.get $0)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (local.get $scratch)
 )
)

