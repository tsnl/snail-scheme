(module
 (rec
  (type $call25 (func (param i64) (result i32)))
  (type $type25 (struct))
 )
 (type $2 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type25)) (ref.null none))
 (global $ready79 (mut i32) (i32.const 0))
 (global $global84 (mut (ref null $type25)) (ref.null none))
 (global $ready84 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $function80 (type $call25) (param $0 i64) (result i32)
  (if (result i32)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready84)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global84)
     )
    )
    (if (result i32)
     (i64.eqz
      (local.tee $0
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready79)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global79)
       )
      )
      (return_call $function80
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $main (result i64)
  (local $0 i64)
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global79
   (struct.new_default $type25)
  )
  (global.set $ready79
   (i32.const 1)
  )
  (global.set $global84
   (struct.new_default $type25)
  )
  (global.set $ready84
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (local.set $scratch
   (i64.extend_i32_u
    (i32.ne
     (call $function80
      (i64.const 99983)
     )
     (i32.const 0)
    )
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (local.get $scratch)
 )
)

