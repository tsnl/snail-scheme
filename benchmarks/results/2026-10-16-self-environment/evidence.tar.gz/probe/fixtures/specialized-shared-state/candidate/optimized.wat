(module
 (rec
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (mut i64))))
 )
 (type $3 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type25)) (ref.null none))
 (global $global80 (mut (ref null $type26)) (ref.null none))
 (global $global81 (mut (ref null $type27)) (ref.null none))
 (export "main" (func $main))
 (func $main (result i64)
  (local $0 i64)
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global79
   (struct.new_default $type25)
  )
  (global.set $global80
   (struct.new_default $type26)
  )
  (global.set $global81
   (struct.new_default $type27)
  )
  (drop
   (ref.as_non_null
    (global.get $global80)
   )
  )
  (struct.set $type25 0
   (global.get $global79)
   (i64.add
    (struct.get $type25 0
     (global.get $global79)
    )
    (i64.const 1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (struct.set $type25 0
   (global.get $global79)
   (i64.add
    (struct.get $type25 0
     (global.get $global79)
    )
    (i64.const 1)
   )
  )
  (local.set $scratch
   (struct.get $type25 0
    (global.get $global79)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (local.get $scratch)
 )
)

