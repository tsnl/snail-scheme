(module
 (type $type25 (struct))
 (type $1 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type25)) (ref.null none))
 (export "main" (func $main))
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type25)
  )
  (drop
   (ref.as_non_null
    (global.get $global78)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

