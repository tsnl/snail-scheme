;; Throwaway ablation driver. Reuse the frozen campaign's predicates and capture.
(import (scheme base) (scheme file) (scheme process-context) (scheme write)
        (srfi 1) (except (chibi filesystem) file-exists?)
        (wasm-native process) (wasm-native json)
        (sfir runner) (sfir support) (sfir timing))

;; ---- Fixed arms and immutable inputs ----

(define (absolute-dependencies command)
  (map (lambda (path) (cons (string->symbol path) (file-sha256 path)))
       (filter (lambda (part) (and (positive? (string-length part))
                                  (char=? #\/ (string-ref part 0))
                                  (file-regular? part))) command)))

(define (make-arm definition source-rows)
  (let ((base (find (lambda (row) (and (equal? (field row 'case) (field definition 'case))
                                     (equal? (field row 'route) (field definition 'source_route)))) source-rows)))
    (unless base (error "missing ablation source route" definition))
    (let ((row (fields-with base (cons 'route (field definition 'name))
                            (cons 'report_route (field definition 'source_route)))))
      (if (not (equal? (field row 'eligibility) "ready")) row
          (let ((command (field definition 'command (field base 'command))))
            (fields-with row (cons 'command command)
                         (cons 'arm_dependencies (absolute-dependencies (json-array command)))))))))

(define (verify-absolute files)
  (for-each (lambda (file)
              (unless (equal? (file-sha256 (symbol->string (car file))) (cdr file))
                (error "ablation dependency changed" (car file)))) files))

(define (verify-arm freeze row)
  (when (equal? (field row 'eligibility) "ready")
    (verify-source-files freeze (field row 'files))
    (verify-absolute (field row 'immutable_dependencies))
    (verify-absolute (field row 'arm_dependencies))))

;; ---- One warmup, five rotated fresh-process rounds, no replacement samples ----

(define (rotate rows offset)
  (let ((offset (modulo offset (length rows)))) (append (drop rows offset) (take rows offset))))

(define (schedule-entry row round)
  (let ((phase (if (zero? round) "warmup" "sample")))
    `((case . ,(field row 'case)) (route . ,(field row 'route))
      (phase . ,phase) (round . ,round)
      (id . ,(string-append phase "-" (number->string round) "-"
                           (field row 'case) "-" (field row 'route))))))

(define (schedule rows)
  (let ((cases (delete-duplicates (map (lambda (row) (field row 'case)) rows)))
        (ready (filter (lambda (row) (equal? (field row 'eligibility) "ready")) rows)))
    (append-map
     (lambda (round)
       (append-map (lambda (name position)
                     (map (lambda (row) (schedule-entry row round))
                          (rotate (filter (lambda (row) (equal? (field row 'case) name)) ready)
                                  (+ round position))))
                   (rotate cases round) (iota (length cases)))) (iota 6))))

(define (find-arm rows entry)
  (find (lambda (row) (and (equal? (field row 'case) (field entry 'case))
                           (equal? (field row 'route) (field entry 'route)))) rows))

(define (checked-result result source working target row)
  (if (not (succeeded? result)) '((status . "failed-process"))
      (guard (failure (else `((status . "failed-result") (reason . ,(exception-text failure)))))
        (let ((seconds (elapsed-seconds (field row 'report_route) (field result 'stdout)
                                       (read-json (path-join source "spec.json")))))
          (unless (output-files-match? source working target (field row 'report_route))
            (error "complete output files differ"))
          `((status . "passed") (seconds . ,seconds))))))

(define (execute freeze output manifest protocol row entry)
  (let* ((target (path-join output "attempts" (field entry 'id)))
         (source (path-join freeze "source/benchmarks/sfir" (field row 'case)))
         (environment (environment-with (frozen-environment manifest)
                                        (map (lambda (item) (cons (symbol->string (car item)) (cdr item)))
                                             (field row 'execution_environment)))))
    (create-directory* target)
    (copy-file (path-join source "input.txt") (path-join target "input.txt"))
    (let* ((working (workload-directory freeze source target "workload"))
           (command (append (list (tool manifest 'TASKSET) "-c" (number->string (field protocol 'cpu)))
                            (json-array (field row 'command))))
           (result (record-command target "execute" command environment working (run-timeout manifest)
                                   (read-text (path-join target "input.txt")))))
      (append entry (checked-result result source working target row)
              `((record . ,(path-join target "commands/execute/record.json")))))))

;; ---- Retain every attempt, including failures ----

(define (published-statistics row attempts protocol status)
  (let ((result (route-statistics row attempts protocol)))
    (if (equal? status "complete") result
        (fields-with
         (filter (lambda (entry) (not (memq (car entry) '(median minimum maximum)))) result)
         (cons 'complete #f)))))

(define (publish output plan status attempts)
  (write-json (path-join output "measurement.json")
              `((status . ,status) (plan_sha256 . ,(file-sha256 (path-join output "plan.json")))
                (attempts . ,(list->vector attempts))
                (rows . ,(list->vector
                          (map (lambda (row) (published-statistics row attempts (field plan 'protocol) status))
                               (json-array (field plan 'rows))))))))

(define (measure config-path output)
  (when (file-exists? output) (error "choose a new ablation output directory" output))
  (let* ((config (read-json config-path)) (freeze (field config 'freeze))
         (manifest (verify-preparation freeze)) (source-plan (read-json (path-join freeze "timing/plan.json")))
         (protocol (fields-with (protocol-configuration (field config 'cpu) 1 5)
                                '(rotation . "rotate cases by round; rotate each case's listed arms by round plus case position")))
         (rows (map (lambda (arm) (make-arm arm (json-array (field source-plan 'rows))))
                    (json-array (field config 'arms))))
         (entries (schedule rows))
         (plan `((protocol . ,protocol) (freeze . ,freeze) (quiet_window . ,(field config 'quiet_window))
                 (driver_sha256 . ,(file-sha256 (car (command-line))))
                 (rows . ,(list->vector rows)) (schedule . ,(list->vector entries))))
         (attempts '()) (status "running"))
    (unless (equal? (file-sha256 (path-join freeze "timing/plan.json")) (field manifest 'timing_plan_sha256))
      (error "source campaign plan changed"))
    (require-clean-environment manifest)
    (for-each (lambda (row) (verify-arm freeze row)) rows)
    (create-directory* output)
    (copy-file config-path (path-join output "configuration.json"))
    (copy-file (car (command-line)) (path-join output "driver.scm"))
    (write-json (path-join output "plan.json") plan)
    (dynamic-wind
      (lambda () #f)
      (lambda ()
        (for-each (lambda (entry)
                    (let ((result (execute freeze output manifest protocol (find-arm rows entry) entry)))
                      (set! attempts (append attempts (list result)))
                      (publish output plan status attempts)
                      (write result) (newline) (flush-output-port))) entries)
        (verify-preparation freeze)
        (for-each (lambda (row) (verify-arm freeze row)) rows)
        (set! status "complete"))
      (lambda () (publish output plan (if (equal? status "complete") status "interrupted") attempts)))))

(let ((arguments (cdr (command-line))))
  (unless (= 2 (length arguments)) (error "usage: native-parity-probe.scm CONFIG OUTPUT"))
  (measure (car arguments) (cadr arguments)))
