(module
 (rec
  (type $type45 (sub (struct (field i32))))
  (type $environment102 (struct (field (ref $type12)) (field (ref $type12)) (field (ref $type92))))
  (type $type92 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $call55 (func (param (ref null $type20) (ref null $type20)) (result i32)))
  (type $call88 (func (param (ref $environment98) (ref null $type16) i64) (result (ref $type12))))
  (type $call90 (func (param (ref $environment97) (ref null $type16) i64) (result i64)))
  (type $type88 (struct (field (ref $environment98))))
  (type $type90 (struct (field (ref $environment97))))
  (type $type89 (struct (field (mut i32)) (field (mut (ref null $type88)))))
  (type $type91 (struct (field (mut i32)) (field (mut (ref null $type90)))))
  (type $environment98 (struct (field (ref $type64)) (field (ref $type89))))
  (type $environment97 (struct (field (ref $type91))))
  (type $type16 (struct (field i64) (field (ref null $type16))))
  (type $13 (func (param (ref $type16)) (result (ref $type12))))
  (type $call39 (func (param (ref null $type22) (ref null $type22)) (result i32)))
  (type $environment88 (struct (field (ref $type59))))
  (type $type85 (struct (field (ref $environment85))))
  (type $type86 (struct (field (mut i32)) (field (mut (ref null $type85)))))
  (type $environment86 (struct (field (ref $type63)) (field i64) (field (ref $type87)) (field (ref $type77))))
  (type $type84 (struct (field (ref $type37))))
  (type $environment85 (struct (field (ref $type63)) (field (ref $type63)) (field (ref $type84)) (field (ref $type86))))
  (type $type87 (struct (field i32) (field (ref $type33))))
  (type $call85 (func (param (ref $environment85) i64) (result (ref $type37))))
  (type $23 (func (param (ref null $type22) (ref $type22)) (result (ref null $type22))))
  (type $call82 (func (param (ref $environment82) (ref null $type22) i64) (result i64)))
  (type $type82 (struct (field (ref $environment82))))
  (type $type46 (sub $type45 (struct (field i32))))
  (type $type72 (struct))
  (type $type83 (struct (field (mut i32)) (field (mut (ref null $type82)))))
  (type $environment82 (struct (field (ref $type83))))
  (type $30 (func (param (ref $type37) i64 i64 i64) (result (ref $type22))))
  (type $type48 (sub $type45 (struct (field i32) (field (ref null $type20)))))
  (type $type73 (struct (field (ref $environment77))))
  (type $type74 (struct (field (mut i32)) (field (mut (ref null $type73)))))
  (type $type47 (sub $type45 (struct (field i32))))
  (type $environment77 (struct (field (ref $type37)) (field (ref $type62)) (field (ref $type63)) (field (ref $type63)) (field (ref $type64)) (field (ref $type64)) (field (ref $type66)) (field (ref $type64)) (field (ref $type64)) (field (ref $type66)) (field (ref $type66)) (field (ref $type68)) (field (ref $type74))))
  (type $call73 (func (param (ref $environment77)) (result (ref $type45))))
  (type $environment75 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type66)) (field (ref $type77))))
  (type $environment74 (struct (field (ref $type64)) (field (ref $type66)) (field (ref $type77))))
  (type $environment71 (struct (field (ref $type37)) (field (ref $type63)) (field i64) (field (ref $type77))))
  (type $environment70 (struct (field (ref $type37)) (field i64) (field (ref $type63)) (field (ref $type63)) (field (ref $type65)) (field (ref $type77))))
  (type $type10 (struct (field (ref $environment68))))
  (type $type75 (struct (field (mut i32)) (field (mut (ref null $type10)))))
  (type $environment76 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type66)) (field (ref $type77))))
  (type $environment73 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type64)) (field (ref $type66)) (field (ref $type66)) (field (ref $type77))))
  (type $environment69 (struct (field (ref $type37)) (field i64) (field (ref $type63)) (field (ref $type63)) (field (ref $type63)) (field (ref $type64)) (field (ref $type65)) (field (ref $type66)) (field (ref $type64)) (field (ref $type66)) (field (ref $type66)) (field (ref $type68)) (field (ref $type70)) (field (ref $type72)) (field (ref $type77))))
  (type $environment68 (struct (field (ref $type37)) (field i64) (field (ref $type62)) (field (ref $type63)) (field (ref $type63)) (field (ref $type63)) (field (ref $type64)) (field (ref $type64)) (field (ref $type65)) (field (ref $type66)) (field (ref $type64)) (field (ref $type64)) (field (ref $type66)) (field (ref $type66)) (field (ref $type68)) (field (ref $type70)) (field (ref $type70)) (field (ref $type72)) (field (ref $type75))))
  (type $call10 (func (param (ref $environment68)) (result i32)))
  (type $call80 (func (param (ref $environment67) i64 f64) (result i32)))
  (type $type80 (struct (field (ref $environment67))))
  (type $environment67 (struct (field (ref $type37)) (field (ref $type63)) (field i64) (field (ref $type81))))
  (type $type81 (struct (field (mut i32)) (field (mut (ref null $type80)))))
  (type $environment66 (struct (field (ref $type37)) (field i64) (field (ref $type63)) (field (ref $type63)) (field (ref $type77))))
  (type $environment65 (struct (field i64) (field (ref $type65)) (field (ref $type77))))
  (type $environment63 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type63)) (field (ref $type64)) (field (ref $type64)) (field (ref $type77))))
  (type $environment62 (struct (field (ref $type63)) (field (ref $type64)) (field (ref $type64)) (field (ref $type77))))
  (type $environment60 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type66)) (field (ref $type66)) (field i64) (field (ref $type77))))
  (type $environment61 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type66)) (field (ref $type66)) (field (ref $type62)) (field (ref $type77))))
  (type $environment59 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type63)) (field (ref $type66)) (field (ref $type66)) (field i32) (field (ref $type62)) (field (ref $type77))))
  (type $59 (func (param (ref $type37) (ref $type63) (ref $type63) (ref $type66) (ref $type66) i32) (result i32)))
  (type $environment57 (struct (field (ref $type37)) (field (ref $type63)) (field (ref $type64)) (field (ref $type66)) (field (ref $type66)) (field i64) (field (ref $type68)) (field (ref $type68)) (field (ref $type77))))
  (type $type62 (struct (field f64)))
  (type $type63 (struct (field i64)))
  (type $environment56 (struct (field (ref $type37)) (field (ref $type62)) (field (ref $type63)) (field (ref $type63)) (field (ref $type64)) (field (ref $type66)) (field (ref $type66)) (field (ref $type68)) (field (ref $type70)) (field (ref $type77))))
  (type $type71 (struct (field (mut i32))))
  (type $type70 (struct (field i32) (field (ref $type71))))
  (type $66 (func (param (ref $type37) (ref $type62) (ref $type63) (ref $type63) (ref $type64) (ref $type66) (ref $type66)) (result i32)))
  (type $call76 (func (param (ref struct) i64) (result i32)))
  (type $environment54 (struct (field (ref $type37)) (field (ref $type64)) (field (ref $type66)) (field (ref $type66)) (field (ref $type68)) (field i64) (field i32) (field (ref $type77))))
  (type $type69 (struct (field (mut f64))))
  (type $type68 (struct (field i32) (field (ref $type69))))
  (type $type67 (struct (field (mut i64))))
  (type $type66 (struct (field (ref $type67))))
  (type $type76 (struct (field (ref $call76)) (field (ref struct))))
  (type $type77 (struct (field (mut i32)) (field (mut (ref null $type76)))))
  (type $75 (func (param (ref $type37) (ref $type64) (ref $type66) (ref $type66) (ref $type68) i64 i32) (result i32)))
  (type $environment51 (struct (field i64) (field (ref $type65)) (field (ref $type79))))
  (type $type65 (struct (field (ref $type14))))
  (type $type14 (array (mut i32)))
  (type $type79 (struct (field (mut i32)) (field (mut (ref null $type13)))))
  (type $call13 (func (param (ref null $environment51) i64) (result (ref $type14))))
  (type $environment49 (struct (field i64) (field (ref $type64)) (field (ref $type78))))
  (type $type64 (struct (field (ref $type12))))
  (type $type78 (struct (field (mut i32)) (field (mut (ref null $type11)))))
  (type $call11 (func (param (ref null $environment49) i64) (result (ref $type12))))
  (type $call42 (func (param (ref $type37) i64 i64 f64) (result i32)))
  (type $type37 (array (mut (ref $type33))))
  (type $environment42 (struct (field (ref $type37)) (field (ref $type59))))
  (type $call60 (func (param (ref $environment40) (ref null $type20) i64) (result i64)))
  (type $89 (func (param (ref null $type22) i32 i32 (ref null $type20)) (result (ref null $type22))))
  (type $type60 (struct (field (ref $environment40))))
  (type $type61 (struct (field (mut i32)) (field (mut (ref null $type60)))))
  (type $type20 (struct (field (ref $type12)) (field (ref null $type20))))
  (type $environment40 (struct (field (ref $type61))))
  (type $call35 (func (param (ref null $type20) (ref null $type22)) (result (ref $type22))))
  (type $type12 (array (mut i64)))
  (type $environment36 (struct (field (ref $type12)) (field (ref $type59))))
  (type $call34 (func (param (ref $type12) (ref null $type22)) (result (ref null $type22))))
  (type $type58 (struct (field (ref $call58)) (field (ref struct))))
  (type $type59 (struct (field (mut i32)) (field (mut (ref null $type58)))))
  (type $type33 (array (mut f64)))
  (type $type22 (struct (field f64) (field (ref null $type22))))
  (type $environment34 (struct (field (ref $type33)) (field (ref $type59))))
  (type $call58 (func (param (ref struct) i64 (ref null $type22)) (result (ref null $type22))))
  (type $call27 (func (param (ref null $environment102) i64) (result i32)))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct (field (mut (ref null $type22)))))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment102))))
  (type $type26 (struct))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type23 (struct))
  (type $type21 (struct))
  (type $type19 (struct))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type15 (struct))
  (type $type13 (struct (field (ref $call13)) (field (ref null $environment51))))
  (type $type11 (struct (field (ref $call11)) (field (ref null $environment49))))
  (type $type8 (struct))
  (type $type5 (struct))
 )
 (type $143 (func (param i64) (result i64)))
 (type $144 (func (param i32) (result i64)))
 (type $145 (func (param i32 i64) (result f64)))
 (type $146 (func (result i64)))
 (type $147 (func (param i64) (result f64)))
 (type $148 (func))
 (import "benchmark" "input_i64" (func $foreign0 (param i32) (result i64)))
 (import "benchmark" "vector_f64" (func $foreign1 (param i32 i64) (result f64)))
 (import "benchmark" "expected_length" (func $foreign2 (result i64)))
 (import "benchmark" "expected_f64" (func $foreign3 (param i64) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $ready58 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type11)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type13)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global265 (mut (ref null $type15)) (ref.null none))
 (global $ready265 (mut i32) (i32.const 0))
 (global $global267 (mut (ref null $type17)) (ref.null none))
 (global $ready267 (mut i32) (i32.const 0))
 (global $global270 (mut (ref null $type18)) (ref.null none))
 (global $ready270 (mut i32) (i32.const 0))
 (global $global102 (mut (ref null $type19)) (ref.null none))
 (global $ready102 (mut i32) (i32.const 0))
 (global $global230 (mut (ref null $type21)) (ref.null none))
 (global $ready230 (mut i32) (i32.const 0))
 (global $global216 (mut (ref null $type23)) (ref.null none))
 (global $ready216 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type24)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type24)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type25)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global69 (mut (ref null $type26)) (ref.null none))
 (global $ready69 (mut i32) (i32.const 0))
 (global $global74 (mut (ref null $type27)) (ref.null none))
 (global $ready74 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type28)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global187 (mut (ref null $type28)) (ref.null none))
 (global $ready187 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type27)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type24)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global80 (mut (ref null $type29)) (ref.null none))
 (global $ready80 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type30)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type31)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type32)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type34)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global97 (mut (ref null $type35)) (ref.null none))
 (global $ready97 (mut i32) (i32.const 0))
 (global $global107 (mut (ref null $type36)) (ref.null none))
 (global $ready107 (mut i32) (i32.const 0))
 (global $global256 (mut (ref null $type38)) (ref.null none))
 (global $ready256 (mut i32) (i32.const 0))
 (global $global253 (mut (ref null $type39)) (ref.null none))
 (global $ready253 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type40)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type40)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type41)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type42)) (ref.null none))
 (global $ready113 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type43)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type44)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global219 (mut (ref null $type49)) (ref.null none))
 (global $ready219 (mut i32) (i32.const 0))
 (global $global224 (mut (ref null $type50)) (ref.null none))
 (global $ready224 (mut i32) (i32.const 0))
 (global $global238 (mut (ref null $type51)) (ref.null none))
 (global $ready238 (mut i32) (i32.const 0))
 (global $global247 (mut (ref null $type52)) (ref.null none))
 (global $ready247 (mut i32) (i32.const 0))
 (global $global251 (mut (ref null $type53)) (ref.null none))
 (global $ready251 (mut i32) (i32.const 0))
 (global $global287 (mut (ref null $type54)) (ref.null none))
 (global $ready287 (mut i32) (i32.const 0))
 (global $global284 (mut (ref null $type55)) (ref.null none))
 (global $ready284 (mut i32) (i32.const 0))
 (global $global279 (mut (ref null $type56)) (ref.null none))
 (global $ready279 (mut i32) (i32.const 0))
 (global $global262 (mut (ref null $type57)) (ref.null none))
 (global $ready262 (mut i32) (i32.const 0))
 (global $global260 (mut (ref null $type53)) (ref.null none))
 (global $ready260 (mut i32) (i32.const 0))
 (export "simplex-probe" (func $export0))
 (export "simplex-predicate-probe" (func $export1))
 (export "main" (func $main))
 (func $function29 (type $call27) (param $0 (ref null $environment102)) (param $1 i64) (result i32)
  (i64.gt_s
   (local.get $1)
   (i64.const 0)
  )
 )
 (func $function34 (type $call58) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type22)) (result (ref null $type22))
  (local $3 (ref $environment34))
  (local $4 f64)
  (if (result (ref $type22))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type22
     (f64.convert_i64_s
      (i64.extend_i32_u
       (array.len
        (struct.get $environment34 0
         (ref.cast (ref $environment34)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type33
      (struct.get $environment34 0
       (local.tee $3
        (ref.cast (ref $environment34)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type59 0
       (struct.get $environment34 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function34
     (struct.get $type58 1
      (struct.get $type59 1
       (struct.get $environment34 1
        (local.get $3)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type22
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function35 (type $call34) (param $0 (ref $type12)) (param $1 (ref null $type22)) (result (ref null $type22))
  (local $2 (ref $type59))
  (local $3 (ref $type58))
  (struct.set $type59 1
   (local.tee $2
    (struct.new_default $type59)
   )
   (struct.new $type58
    (ref.func $function36)
    (struct.new $environment36
     (local.get $0)
     (local.get $2)
    )
   )
  )
  (struct.set $type59 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type59 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call58
   (struct.get $type58 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type59 1
       (local.get $2)
      )
     )
    )
   )
   (i64.sub
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (i64.const 1)
   )
   (local.get $1)
   (struct.get $type58 0
    (local.get $3)
   )
  )
 )
 (func $function36 (type $call58) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type22)) (result (ref null $type22))
  (local $3 (ref $environment36))
  (local $4 i64)
  (if (result (ref $type22))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type22
     (f64.convert_i64_s
      (i64.extend_i32_u
       (array.len
        (struct.get $environment36 0
         (ref.cast (ref $environment36)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $environment36 0
       (local.tee $3
        (ref.cast (ref $environment36)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type59 0
       (struct.get $environment36 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function36
     (struct.get $type58 1
      (struct.get $type59 1
       (struct.get $environment36 1
        (local.get $3)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type22
      (f64.convert_i64_s
       (local.get $4)
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function37 (type $call35) (param $0 (ref null $type20)) (param $1 (ref null $type22)) (result (ref $type22))
  (local $2 (ref $type59))
  (local $3 (ref $environment40))
  (local $4 (ref null $type20))
  (local $5 (ref $type58))
  (local $6 (ref $type61))
  (local $7 (ref $type12))
  (local $8 (ref $type12))
  (local $9 (ref $type12))
  (local $10 (ref $type12))
  (local $11 (ref $type12))
  (local $12 (ref $type12))
  (local $13 (ref $type12))
  (local $14 (ref $type12))
  (local $15 (ref $type12))
  (local $16 (ref $type12))
  (local $17 (ref $type12))
  (local $18 (ref $type12))
  (local $19 (ref $type12))
  (local $20 (ref $type12))
  (local $21 (ref $type12))
  (local $scratch (ref null $type22))
  (if
   (i32.eqz
    (global.get $ready102)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global102)
   )
  )
  (struct.set $type61 1
   (local.tee $6
    (struct.new_default $type61)
   )
   (struct.new $type60
    (struct.new $environment40
     (local.get $6)
    )
   )
  )
  (struct.set $type61 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type61 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type60 0
    (struct.get $type61 1
     (local.get $6)
    )
   )
  )
  (struct.new $type22
   (f64.convert_i64_s
    (if (result i64)
     (ref.is_null
      (local.get $0)
     )
     (then
      (i64.const 0)
     )
     (else
      (local.set $4
       (struct.get $type20 1
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (struct.get $type61 0
         (struct.get $environment40 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type60 0
        (struct.get $type61 1
         (struct.get $environment40 0
          (local.get $3)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $4)
       )
       (then
        (i64.const 1)
       )
       (else
        (local.set $4
         (struct.get $type20 1
          (local.get $4)
         )
        )
        (if
         (i32.eqz
          (struct.get $type61 0
           (struct.get $environment40 0
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type60 0
          (struct.get $type61 1
           (struct.get $environment40 0
            (local.get $3)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $4)
         )
         (then
          (i64.const 2)
         )
         (else
          (local.set $4
           (struct.get $type20 1
            (local.get $4)
           )
          )
          (if
           (i32.eqz
            (struct.get $type61 0
             (struct.get $environment40 0
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type60 0
            (struct.get $type61 1
             (struct.get $environment40 0
              (local.get $3)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $4)
           )
           (then
            (i64.const 3)
           )
           (else
            (local.set $4
             (struct.get $type20 1
              (local.get $4)
             )
            )
            (if
             (i32.eqz
              (struct.get $type61 0
               (struct.get $environment40 0
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type60 0
              (struct.get $type61 1
               (struct.get $environment40 0
                (local.get $3)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $4)
             )
             (then
              (i64.const 4)
             )
             (else
              (local.set $4
               (struct.get $type20 1
                (local.get $4)
               )
              )
              (if
               (i32.eqz
                (struct.get $type61 0
                 (struct.get $environment40 0
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type60 0
                (struct.get $type61 1
                 (struct.get $environment40 0
                  (local.get $3)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $4)
               )
               (then
                (i64.const 5)
               )
               (else
                (local.set $4
                 (struct.get $type20 1
                  (local.get $4)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type61 0
                   (struct.get $environment40 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $3
                 (struct.get $type60 0
                  (struct.get $type61 1
                   (struct.get $environment40 0
                    (local.get $3)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $4)
                 )
                 (then
                  (i64.const 6)
                 )
                 (else
                  (local.set $4
                   (struct.get $type20 1
                    (local.get $4)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type61 0
                     (struct.get $environment40 0
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type60 0
                    (struct.get $type61 1
                     (struct.get $environment40 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $4)
                   )
                   (then
                    (i64.const 7)
                   )
                   (else
                    (local.set $4
                     (struct.get $type20 1
                      (local.get $4)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type61 0
                       (struct.get $environment40 0
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $3
                     (struct.get $type60 0
                      (struct.get $type61 1
                       (struct.get $environment40 0
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $4)
                     )
                     (then
                      (i64.const 8)
                     )
                     (else
                      (local.set $4
                       (struct.get $type20 1
                        (local.get $4)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type61 0
                         (struct.get $environment40 0
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type60 0
                        (struct.get $type61 1
                         (struct.get $environment40 0
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (if (result i64)
                       (ref.is_null
                        (local.get $4)
                       )
                       (then
                        (i64.const 9)
                       )
                       (else
                        (local.set $4
                         (struct.get $type20 1
                          (local.get $4)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type61 0
                           (struct.get $environment40 0
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $3
                         (struct.get $type60 0
                          (struct.get $type61 1
                           (struct.get $environment40 0
                            (local.get $3)
                           )
                          )
                         )
                        )
                        (if (result i64)
                         (ref.is_null
                          (local.get $4)
                         )
                         (then
                          (i64.const 10)
                         )
                         (else
                          (local.set $4
                           (struct.get $type20 1
                            (local.get $4)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type61 0
                             (struct.get $environment40 0
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $3
                           (struct.get $type60 0
                            (struct.get $type61 1
                             (struct.get $environment40 0
                              (local.get $3)
                             )
                            )
                           )
                          )
                          (if (result i64)
                           (ref.is_null
                            (local.get $4)
                           )
                           (then
                            (i64.const 11)
                           )
                           (else
                            (local.set $4
                             (struct.get $type20 1
                              (local.get $4)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type61 0
                               (struct.get $environment40 0
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (local.set $3
                             (struct.get $type60 0
                              (struct.get $type61 1
                               (struct.get $environment40 0
                                (local.get $3)
                               )
                              )
                             )
                            )
                            (if (result i64)
                             (ref.is_null
                              (local.get $4)
                             )
                             (then
                              (i64.const 12)
                             )
                             (else
                              (local.set $4
                               (struct.get $type20 1
                                (local.get $4)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type61 0
                                 (struct.get $environment40 0
                                  (local.get $3)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $3
                               (struct.get $type60 0
                                (struct.get $type61 1
                                 (struct.get $environment40 0
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                              (if (result i64)
                               (ref.is_null
                                (local.get $4)
                               )
                               (then
                                (i64.const 13)
                               )
                               (else
                                (local.set $4
                                 (struct.get $type20 1
                                  (local.get $4)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type61 0
                                   (struct.get $environment40 0
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $function40
                                 (struct.get $type60 0
                                  (struct.get $type61 1
                                   (struct.get $environment40 0
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (local.get $4)
                                 (i64.const 14)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (if (result (ref null $type22))
    (ref.is_null
     (local.get $0)
    )
    (then
     (local.get $1)
    )
    (else
     (local.set $7
      (struct.get $type20 0
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (ref.is_null
        (local.tee $0
         (struct.get $type20 1
          (local.get $0)
         )
        )
       )
      )
      (then
       (local.set $8
        (struct.get $type20 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (ref.is_null
          (local.tee $0
           (struct.get $type20 1
            (local.get $0)
           )
          )
         )
        )
        (then
         (local.set $9
          (struct.get $type20 0
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (ref.is_null
            (local.tee $0
             (struct.get $type20 1
              (local.get $0)
             )
            )
           )
          )
          (then
           (local.set $10
            (struct.get $type20 0
             (local.get $0)
            )
           )
           (if
            (i32.eqz
             (ref.is_null
              (local.tee $0
               (struct.get $type20 1
                (local.get $0)
               )
              )
             )
            )
            (then
             (local.set $11
              (struct.get $type20 0
               (local.get $0)
              )
             )
             (if
              (i32.eqz
               (ref.is_null
                (local.tee $0
                 (struct.get $type20 1
                  (local.get $0)
                 )
                )
               )
              )
              (then
               (local.set $12
                (struct.get $type20 0
                 (local.get $0)
                )
               )
               (if
                (i32.eqz
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type20 1
                    (local.get $0)
                   )
                  )
                 )
                )
                (then
                 (local.set $13
                  (struct.get $type20 0
                   (local.get $0)
                  )
                 )
                 (if
                  (i32.eqz
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type20 1
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (then
                   (local.set $14
                    (struct.get $type20 0
                     (local.get $0)
                    )
                   )
                   (if
                    (i32.eqz
                     (ref.is_null
                      (local.tee $0
                       (struct.get $type20 1
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (then
                     (local.set $15
                      (struct.get $type20 0
                       (local.get $0)
                      )
                     )
                     (if
                      (i32.eqz
                       (ref.is_null
                        (local.tee $0
                         (struct.get $type20 1
                          (local.get $0)
                         )
                        )
                       )
                      )
                      (then
                       (local.set $16
                        (struct.get $type20 0
                         (local.get $0)
                        )
                       )
                       (if
                        (i32.eqz
                         (ref.is_null
                          (local.tee $0
                           (struct.get $type20 1
                            (local.get $0)
                           )
                          )
                         )
                        )
                        (then
                         (local.set $17
                          (struct.get $type20 0
                           (local.get $0)
                          )
                         )
                         (if
                          (i32.eqz
                           (ref.is_null
                            (local.tee $0
                             (struct.get $type20 1
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (then
                           (local.set $18
                            (struct.get $type20 0
                             (local.get $0)
                            )
                           )
                           (if
                            (i32.eqz
                             (ref.is_null
                              (local.tee $0
                               (struct.get $type20 1
                                (local.get $0)
                               )
                              )
                             )
                            )
                            (then
                             (local.set $19
                              (struct.get $type20 0
                               (local.get $0)
                              )
                             )
                             (if
                              (i32.eqz
                               (ref.is_null
                                (local.tee $0
                                 (struct.get $type20 1
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                              (then
                               (local.set $20
                                (struct.get $type20 0
                                 (local.get $0)
                                )
                               )
                               (if
                                (i32.eqz
                                 (ref.is_null
                                  (local.tee $0
                                   (struct.get $type20 1
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (then
                                 (local.set $1
                                  (call $function35
                                   (struct.get $type20 0
                                    (local.get $0)
                                   )
                                   (block (result (ref null $type22))
                                    (local.set $scratch
                                     (call $function38
                                      (local.get $1)
                                      (i32.const 0)
                                      (i32.const 1)
                                      (struct.get $type20 1
                                       (local.get $0)
                                      )
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready91)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global91)
                                     )
                                    )
                                    (local.get $scratch)
                                   )
                                  )
                                 )
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready91)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global91)
                                )
                               )
                               (struct.set $type59 1
                                (local.tee $2
                                 (struct.new_default $type59)
                                )
                                (struct.new $type58
                                 (ref.func $function36)
                                 (struct.new $environment36
                                  (local.get $20)
                                  (local.get $2)
                                 )
                                )
                               )
                               (struct.set $type59 0
                                (local.get $2)
                                (i32.const 1)
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type59 0
                                  (local.get $2)
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $1
                                (call_ref $call58
                                 (struct.get $type58 1
                                  (local.tee $5
                                   (ref.as_non_null
                                    (struct.get $type59 1
                                     (local.get $2)
                                    )
                                   )
                                  )
                                 )
                                 (i64.sub
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $20)
                                   )
                                  )
                                  (i64.const 1)
                                 )
                                 (local.get $1)
                                 (struct.get $type58 0
                                  (local.get $5)
                                 )
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready91)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global91)
                              )
                             )
                             (struct.set $type59 1
                              (local.tee $2
                               (struct.new_default $type59)
                              )
                              (struct.new $type58
                               (ref.func $function36)
                               (struct.new $environment36
                                (local.get $19)
                                (local.get $2)
                               )
                              )
                             )
                             (struct.set $type59 0
                              (local.get $2)
                              (i32.const 1)
                             )
                             (if
                              (i32.eqz
                               (struct.get $type59 0
                                (local.get $2)
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $1
                              (call_ref $call58
                               (struct.get $type58 1
                                (local.tee $5
                                 (ref.as_non_null
                                  (struct.get $type59 1
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                               (i64.sub
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $19)
                                 )
                                )
                                (i64.const 1)
                               )
                               (local.get $1)
                               (struct.get $type58 0
                                (local.get $5)
                               )
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready91)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global91)
                            )
                           )
                           (struct.set $type59 1
                            (local.tee $2
                             (struct.new_default $type59)
                            )
                            (struct.new $type58
                             (ref.func $function36)
                             (struct.new $environment36
                              (local.get $18)
                              (local.get $2)
                             )
                            )
                           )
                           (struct.set $type59 0
                            (local.get $2)
                            (i32.const 1)
                           )
                           (if
                            (i32.eqz
                             (struct.get $type59 0
                              (local.get $2)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $1
                            (call_ref $call58
                             (struct.get $type58 1
                              (local.tee $5
                               (ref.as_non_null
                                (struct.get $type59 1
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (i64.sub
                              (i64.extend_i32_u
                               (array.len
                                (local.get $18)
                               )
                              )
                              (i64.const 1)
                             )
                             (local.get $1)
                             (struct.get $type58 0
                              (local.get $5)
                             )
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready91)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global91)
                          )
                         )
                         (struct.set $type59 1
                          (local.tee $2
                           (struct.new_default $type59)
                          )
                          (struct.new $type58
                           (ref.func $function36)
                           (struct.new $environment36
                            (local.get $17)
                            (local.get $2)
                           )
                          )
                         )
                         (struct.set $type59 0
                          (local.get $2)
                          (i32.const 1)
                         )
                         (if
                          (i32.eqz
                           (struct.get $type59 0
                            (local.get $2)
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $1
                          (call_ref $call58
                           (struct.get $type58 1
                            (local.tee $5
                             (ref.as_non_null
                              (struct.get $type59 1
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (i64.sub
                            (i64.extend_i32_u
                             (array.len
                              (local.get $17)
                             )
                            )
                            (i64.const 1)
                           )
                           (local.get $1)
                           (struct.get $type58 0
                            (local.get $5)
                           )
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready91)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global91)
                        )
                       )
                       (struct.set $type59 1
                        (local.tee $2
                         (struct.new_default $type59)
                        )
                        (struct.new $type58
                         (ref.func $function36)
                         (struct.new $environment36
                          (local.get $16)
                          (local.get $2)
                         )
                        )
                       )
                       (struct.set $type59 0
                        (local.get $2)
                        (i32.const 1)
                       )
                       (if
                        (i32.eqz
                         (struct.get $type59 0
                          (local.get $2)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (call_ref $call58
                         (struct.get $type58 1
                          (local.tee $5
                           (ref.as_non_null
                            (struct.get $type59 1
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (i64.sub
                          (i64.extend_i32_u
                           (array.len
                            (local.get $16)
                           )
                          )
                          (i64.const 1)
                         )
                         (local.get $1)
                         (struct.get $type58 0
                          (local.get $5)
                         )
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready91)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global91)
                      )
                     )
                     (struct.set $type59 1
                      (local.tee $2
                       (struct.new_default $type59)
                      )
                      (struct.new $type58
                       (ref.func $function36)
                       (struct.new $environment36
                        (local.get $15)
                        (local.get $2)
                       )
                      )
                     )
                     (struct.set $type59 0
                      (local.get $2)
                      (i32.const 1)
                     )
                     (if
                      (i32.eqz
                       (struct.get $type59 0
                        (local.get $2)
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (call_ref $call58
                       (struct.get $type58 1
                        (local.tee $5
                         (ref.as_non_null
                          (struct.get $type59 1
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (i64.sub
                        (i64.extend_i32_u
                         (array.len
                          (local.get $15)
                         )
                        )
                        (i64.const 1)
                       )
                       (local.get $1)
                       (struct.get $type58 0
                        (local.get $5)
                       )
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready91)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global91)
                    )
                   )
                   (struct.set $type59 1
                    (local.tee $2
                     (struct.new_default $type59)
                    )
                    (struct.new $type58
                     (ref.func $function36)
                     (struct.new $environment36
                      (local.get $14)
                      (local.get $2)
                     )
                    )
                   )
                   (struct.set $type59 0
                    (local.get $2)
                    (i32.const 1)
                   )
                   (if
                    (i32.eqz
                     (struct.get $type59 0
                      (local.get $2)
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (call_ref $call58
                     (struct.get $type58 1
                      (local.tee $5
                       (ref.as_non_null
                        (struct.get $type59 1
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (i64.sub
                      (i64.extend_i32_u
                       (array.len
                        (local.get $14)
                       )
                      )
                      (i64.const 1)
                     )
                     (local.get $1)
                     (struct.get $type58 0
                      (local.get $5)
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready91)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global91)
                  )
                 )
                 (struct.set $type59 1
                  (local.tee $2
                   (struct.new_default $type59)
                  )
                  (struct.new $type58
                   (ref.func $function36)
                   (struct.new $environment36
                    (local.get $13)
                    (local.get $2)
                   )
                  )
                 )
                 (struct.set $type59 0
                  (local.get $2)
                  (i32.const 1)
                 )
                 (if
                  (i32.eqz
                   (struct.get $type59 0
                    (local.get $2)
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (call_ref $call58
                   (struct.get $type58 1
                    (local.tee $5
                     (ref.as_non_null
                      (struct.get $type59 1
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (i64.sub
                    (i64.extend_i32_u
                     (array.len
                      (local.get $13)
                     )
                    )
                    (i64.const 1)
                   )
                   (local.get $1)
                   (struct.get $type58 0
                    (local.get $5)
                   )
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready91)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global91)
                )
               )
               (struct.set $type59 1
                (local.tee $2
                 (struct.new_default $type59)
                )
                (struct.new $type58
                 (ref.func $function36)
                 (struct.new $environment36
                  (local.get $12)
                  (local.get $2)
                 )
                )
               )
               (struct.set $type59 0
                (local.get $2)
                (i32.const 1)
               )
               (if
                (i32.eqz
                 (struct.get $type59 0
                  (local.get $2)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (call_ref $call58
                 (struct.get $type58 1
                  (local.tee $5
                   (ref.as_non_null
                    (struct.get $type59 1
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (i64.sub
                  (i64.extend_i32_u
                   (array.len
                    (local.get $12)
                   )
                  )
                  (i64.const 1)
                 )
                 (local.get $1)
                 (struct.get $type58 0
                  (local.get $5)
                 )
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready91)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global91)
              )
             )
             (struct.set $type59 1
              (local.tee $2
               (struct.new_default $type59)
              )
              (struct.new $type58
               (ref.func $function36)
               (struct.new $environment36
                (local.get $11)
                (local.get $2)
               )
              )
             )
             (struct.set $type59 0
              (local.get $2)
              (i32.const 1)
             )
             (if
              (i32.eqz
               (struct.get $type59 0
                (local.get $2)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (call_ref $call58
               (struct.get $type58 1
                (local.tee $5
                 (ref.as_non_null
                  (struct.get $type59 1
                   (local.get $2)
                  )
                 )
                )
               )
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (local.get $11)
                 )
                )
                (i64.const 1)
               )
               (local.get $1)
               (struct.get $type58 0
                (local.get $5)
               )
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready91)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global91)
            )
           )
           (struct.set $type59 1
            (local.tee $2
             (struct.new_default $type59)
            )
            (struct.new $type58
             (ref.func $function36)
             (struct.new $environment36
              (local.get $10)
              (local.get $2)
             )
            )
           )
           (struct.set $type59 0
            (local.get $2)
            (i32.const 1)
           )
           (if
            (i32.eqz
             (struct.get $type59 0
              (local.get $2)
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (call_ref $call58
             (struct.get $type58 1
              (local.tee $5
               (ref.as_non_null
                (struct.get $type59 1
                 (local.get $2)
                )
               )
              )
             )
             (i64.sub
              (i64.extend_i32_u
               (array.len
                (local.get $10)
               )
              )
              (i64.const 1)
             )
             (local.get $1)
             (struct.get $type58 0
              (local.get $5)
             )
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready91)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global91)
          )
         )
         (struct.set $type59 1
          (local.tee $2
           (struct.new_default $type59)
          )
          (struct.new $type58
           (ref.func $function36)
           (struct.new $environment36
            (local.get $9)
            (local.get $2)
           )
          )
         )
         (struct.set $type59 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type59 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (call_ref $call58
           (struct.get $type58 1
            (local.tee $5
             (ref.as_non_null
              (struct.get $type59 1
               (local.get $2)
              )
             )
            )
           )
           (i64.sub
            (i64.extend_i32_u
             (array.len
              (local.get $9)
             )
            )
            (i64.const 1)
           )
           (local.get $1)
           (struct.get $type58 0
            (local.get $5)
           )
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready91)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global91)
        )
       )
       (struct.set $type59 1
        (local.tee $2
         (struct.new_default $type59)
        )
        (struct.new $type58
         (ref.func $function36)
         (struct.new $environment36
          (local.get $8)
          (local.get $2)
         )
        )
       )
       (struct.set $type59 0
        (local.get $2)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type59 0
          (local.get $2)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (call_ref $call58
         (struct.get $type58 1
          (local.tee $5
           (ref.as_non_null
            (struct.get $type59 1
             (local.get $2)
            )
           )
          )
         )
         (i64.sub
          (i64.extend_i32_u
           (array.len
            (local.get $8)
           )
          )
          (i64.const 1)
         )
         (local.get $1)
         (struct.get $type58 0
          (local.get $5)
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready91)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global91)
      )
     )
     (struct.set $type59 1
      (local.tee $2
       (struct.new_default $type59)
      )
      (struct.new $type58
       (ref.func $function36)
       (struct.new $environment36
        (local.get $7)
        (local.get $2)
       )
      )
     )
     (struct.set $type59 0
      (local.get $2)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type59 0
        (local.get $2)
       )
      )
      (then
       (unreachable)
      )
     )
     (call_ref $call58
      (struct.get $type58 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type59 1
          (local.get $2)
         )
        )
       )
      )
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $7)
        )
       )
       (i64.const 1)
      )
      (local.get $1)
      (struct.get $type58 0
       (local.get $5)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $89) (param $0 (ref null $type22)) (param $1 i32) (param $2 i32) (param $3 (ref null $type20)) (result (ref null $type22))
  (local $4 (ref $type12))
  (local $scratch (ref null $type22))
  (if (result (ref null $type22))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (return_call $function35
     (struct.get $type20 0
      (local.get $3)
     )
     (block (result (ref null $type22))
      (local.set $3
       (struct.get $type20 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $scratch
       (call $function38
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (global.get $ready91)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global91)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function40 (type $call60) (param $0 (ref $environment40)) (param $1 (ref null $type20)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type20 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment40 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function40
     (struct.get $type60 0
      (struct.get $type61 1
       (struct.get $environment40 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function42 (type $call58) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type22)) (result (ref null $type22))
  (local $3 (ref $type59))
  (local $4 (ref $type33))
  (local $5 (ref $type58))
  (if (result (ref $type22))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type22
     (f64.convert_i64_s
      (i64.extend_i32_u
       (array.len
        (struct.get $environment42 0
         (ref.cast (ref $environment42)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type37
      (struct.get $environment42 0
       (ref.cast (ref $environment42)
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready85)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global85)
     )
    )
    (struct.set $type59 1
     (local.tee $3
      (struct.new_default $type59)
     )
     (struct.new $type58
      (ref.func $function34)
      (struct.new $environment34
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type59 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type59 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call58
      (struct.get $type58 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type59 1
          (local.get $3)
         )
        )
       )
      )
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $4)
        )
       )
       (i64.const 1)
      )
      (local.get $2)
      (struct.get $type58 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type59 0
       (struct.get $environment42 1
        (ref.cast (ref $environment42)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (struct.get $type58 1
      (struct.get $type59 1
       (struct.get $environment42 1
        (ref.cast (ref $environment42)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function43 (type $call42) (param $0 (ref $type37)) (param $1 i64) (param $2 i64) (param $3 f64) (result i32)
  (local $4 (ref $type29))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type33
   (array.get $type37
    (local.get $0)
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (i32.wrap_i64
    (local.get $2)
   )
   (local.get $3)
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type29 0
   (ref.as_non_null
    (global.get $global80)
   )
   (block (result (ref (exact $type22)))
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type22
     (local.get $3)
     (struct.new $type22
      (f64.convert_i64_s
       (local.get $2)
      )
      (struct.new $type22
       (f64.convert_i64_s
        (local.get $1)
       )
       (struct.get $type29 0
        (global.get $global80)
       )
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function48 (type $call11) (param $0 (ref null $environment49)) (param $1 i64) (result (ref $type12))
  (local $2 (ref $type78))
  (local $3 (ref $type11))
  (local $4 i32)
  (if (result (ref $type12))
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (i64.const 4294967295)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type12))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type12 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready55)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type78 1
       (local.tee $2
        (struct.new_default $type78)
       )
       (struct.new $type11
        (ref.func $function49)
        (struct.new $environment49
         (local.get $1)
         (struct.new $type64
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type78 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type78 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call11
       (struct.get $type11 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type78 1
           (local.get $2)
          )
         )
        )
       )
       (i64.const 1)
       (struct.get $type11 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function49 (type $call11) (param $0 (ref null $environment49)) (param $1 i64) (result (ref $type12))
  (local $2 (ref $type12))
  (if (result (ref $type12))
   (i64.eq
    (struct.get $environment49 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (struct.get $type64 0
     (struct.get $environment49 1
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment49 1
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready55)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i64.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type78 0
       (struct.get $environment49 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type11 1
      (struct.get $type78 1
       (struct.get $environment49 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function50 (type $call13) (param $0 (ref null $environment51)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $type79))
  (local $3 (ref $type13))
  (local $4 i32)
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (i64.const 4294967295)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type14))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type14 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready58)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global58)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type79 1
       (local.tee $2
        (struct.new_default $type79)
       )
       (struct.new $type13
        (ref.func $function51)
        (struct.new $environment51
         (local.get $1)
         (struct.new $type65
          (array.new_default $type14
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type79 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type79 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call13
       (struct.get $type13 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type79 1
           (local.get $2)
          )
         )
        )
       )
       (i64.const 1)
       (struct.get $type13 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $call13) (param $0 (ref null $environment51)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $type14))
  (if (result (ref $type14))
   (i64.eq
    (struct.get $environment51 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (struct.get $type65 0
     (struct.get $environment51 1
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type14
     (struct.get $type65 0
      (struct.get $environment51 1
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready58)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global58)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type79 0
       (struct.get $environment51 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (struct.get $type13 1
      (struct.get $type79 1
       (struct.get $environment51 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $75) (param $0 (ref $type37)) (param $1 (ref $type64)) (param $2 (ref $type66)) (param $3 (ref $type66)) (param $4 (ref $type68)) (param $5 i64) (param $6 i32) (result i32)
  (local $7 (ref $type77))
  (local $8 (ref $type76))
  (local $9 i64)
  (struct.set $type67 0
   (struct.get $type66 0
    (local.get $3)
   )
   (array.get $type12
    (struct.get $type64 0
     (local.get $1)
    )
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (if
   (i64.gt_u
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (struct.get $type67 0
      (struct.get $type66 0
       (local.get $3)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type69 0
   (struct.get $type68 1
    (local.get $4)
   )
   (array.get $type33
    (array.get $type37
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (i32.wrap_i64
     (local.get $9)
    )
   )
  )
  (struct.set $type77 1
   (local.tee $7
    (struct.new_default $type77)
   )
   (struct.new $type76
    (ref.func $function54)
    (struct.new $environment54
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
    )
   )
  )
  (struct.set $type77 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call76
   (struct.get $type76 1
    (local.tee $8
     (ref.as_non_null
      (struct.get $type77 1
       (local.get $7)
      )
     )
    )
   )
   (i64.const 1)
   (struct.get $type76 0
    (local.get $8)
   )
  )
 )
 (func $function54 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment54))
  (local $3 f64)
  (local $4 i64)
  (local $5 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type67 0
     (struct.get $type66 0
      (struct.get $environment54 2
       (ref.cast (ref $environment54)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (f64.gt
      (if (result f64)
       (struct.get $environment54 6
        (local.tee $2
         (ref.cast (ref $environment54)
          (local.get $0)
         )
        )
       )
       (then
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (array.get $type12
          (struct.get $type64 0
           (struct.get $environment54 1
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready158)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global158)
         )
        )
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment54 5
            (local.get $2)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (array.get $type33
          (array.get $type37
           (struct.get $environment54 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready78)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global78)
         )
        )
        (f64.sub
         (if (result f64)
          (f64.eq
           (local.get $3)
           (f64.const 0)
          )
          (then
           (f64.const 0)
          )
          (else
           (if (result f64)
            (f64.lt
             (local.get $3)
             (f64.const 0)
            )
            (then
             (if
              (i32.eqz
               (global.get $ready61)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (f64.sub
              (f64.const -0)
              (local.get $3)
             )
            )
            (else
             (local.get $3)
            )
           )
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready78)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global78)
           )
          )
          (if (result f64)
           (f64.eq
            (local.tee $3
             (struct.get $type69 0
              (struct.get $type68 1
               (struct.get $environment54 4
                (local.get $2)
               )
              )
             )
            )
            (f64.const 0)
           )
           (then
            (f64.const 0)
           )
           (else
            (if (result f64)
             (f64.lt
              (local.get $3)
              (f64.const 0)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready61)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global61)
               )
              )
              (f64.sub
               (f64.const -0)
               (local.get $3)
              )
             )
             (else
              (local.get $3)
             )
            )
           )
          )
         )
        )
       )
       (else
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (array.get $type12
          (struct.get $type64 0
           (struct.get $environment54 1
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready158)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global158)
         )
        )
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment54 5
            (local.get $2)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (f64.sub
         (array.get $type33
          (array.get $type37
           (struct.get $environment54 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (struct.get $type69 0
          (struct.get $type68 1
           (struct.get $environment54 4
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (block (result f64)
       (if
        (i32.eqz
         (global.get $ready76)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global76)
        )
       )
       (f64.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type67 0
       (struct.get $type66 0
        (struct.get $environment54 3
         (local.get $2)
        )
       )
       (array.get $type12
        (struct.get $type64 0
         (struct.get $environment54 1
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type12
        (struct.get $type64 0
         (struct.get $environment54 1
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (struct.get $environment54 5
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type69 0
       (struct.get $type68 1
        (struct.get $environment54 4
         (local.get $2)
        )
       )
       (array.get $type33
        (array.get $type37
         (struct.get $environment54 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment54 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment54 7
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function55 (type $66) (param $0 (ref $type37)) (param $1 (ref $type62)) (param $2 (ref $type63)) (param $3 (ref $type63)) (param $4 (ref $type64)) (param $5 (ref $type66)) (param $6 (ref $type66)) (result i32)
  (local $7 (ref $type77))
  (local $8 (ref $type76))
  (struct.set $type67 0
   (struct.get $type66 0
    (local.get $5)
   )
   (i64.const 0)
  )
  (struct.set $type77 1
   (local.tee $7
    (struct.new_default $type77)
   )
   (struct.new $type76
    (ref.func $function56)
    (struct.new $environment56
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (struct.new $type68
      (i32.const 1)
      (struct.new_default $type69)
     )
     (struct.new $type70
      (i32.const 1)
      (struct.new_default $type71)
     )
     (local.get $7)
    )
   )
  )
  (struct.set $type77 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call76
   (struct.get $type76 1
    (local.tee $8
     (ref.as_non_null
      (struct.get $type77 1
       (local.get $7)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type76 0
    (local.get $8)
   )
  )
 )
 (func $function56 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment56))
  (local $3 (ref $type77))
  (local $4 (ref $type68))
  (local $5 (ref $type68))
  (local $6 (ref $type76))
  (local $7 i64)
  (local $8 i64)
  (local $9 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type63 0
     (struct.get $environment56 2
      (ref.cast (ref $environment56)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment56)
      (local.get $0)
     )
    )
    (drop
     (if (result i32)
      (struct.get $type71 0
       (struct.get $type70 1
        (struct.get $environment56 8
         (local.tee $2
          (ref.cast (ref $environment56)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (array.get $type12
         (struct.get $type64 0
          (struct.get $environment56 4
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $7)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment56 6
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (f64.lt
         (array.get $type33
          (array.get $type37
           (struct.get $environment56 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
          (i32.wrap_i64
           (local.get $8)
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready61)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (f64.sub
           (f64.const -0)
           (struct.get $type62 0
            (struct.get $environment56 1
             (local.get $2)
            )
           )
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type64 0
            (struct.get $environment56 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $9
          (array.get $type33
           (array.get $type37
            (struct.get $environment56 0
             (local.get $2)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
           (i32.const 0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type64 0
            (struct.get $environment56 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (struct.get $type67 0
             (struct.get $type66 0
              (struct.get $environment56 6
               (local.get $2)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (f64.lt
           (local.tee $9
            (f64.div
             (f64.sub
              (f64.const -0)
              (local.get $9)
             )
             (array.get $type33
              (array.get $type37
               (struct.get $environment56 0
                (local.get $2)
               )
               (i32.wrap_i64
                (local.get $7)
               )
              )
              (i32.wrap_i64
               (local.get $8)
              )
             )
            )
           )
           (struct.get $type69 0
            (struct.get $type68 1
             (struct.get $environment56 7
              (local.get $2)
             )
            )
           )
          )
          (then
           (if
            (i64.gt_u
             (local.get $1)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (struct.set $type67 0
            (struct.get $type66 0
             (struct.get $environment56 5
              (local.get $2)
             )
            )
            (array.get $type12
             (struct.get $type64 0
              (struct.get $environment56 4
               (local.get $2)
              )
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (struct.set $type69 0
            (struct.get $type68 1
             (struct.get $environment56 7
              (local.get $2)
             )
            )
            (local.get $9)
           )
          )
          (else
           (if
            (f64.eq
             (struct.get $type69 0
              (struct.get $type68 1
               (struct.get $environment56 7
                (local.get $2)
               )
              )
             )
             (local.get $9)
            )
            (then
             (struct.set $type77 1
              (local.tee $3
               (struct.new_default $type77)
              )
              (struct.new $type76
               (ref.func $function57)
               (struct.new $environment57
                (struct.get $environment56 0
                 (local.get $2)
                )
                (struct.get $environment56 3
                 (local.get $2)
                )
                (struct.get $environment56 4
                 (local.get $2)
                )
                (struct.get $environment56 5
                 (local.get $2)
                )
                (struct.get $environment56 6
                 (local.get $2)
                )
                (local.get $1)
                (local.tee $4
                 (struct.new $type68
                  (i32.const 1)
                  (struct.new_default $type69)
                 )
                )
                (local.tee $5
                 (struct.new $type68
                  (i32.const 1)
                  (struct.new_default $type69)
                 )
                )
                (local.get $3)
               )
              )
             )
             (struct.set $type77 0
              (local.get $3)
              (i32.const 1)
             )
             (if
              (i32.eqz
               (struct.get $type77 0
                (local.get $3)
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (call_ref $call76
               (struct.get $type76 1
                (local.tee $6
                 (ref.as_non_null
                  (struct.get $type77 1
                   (local.get $3)
                  )
                 )
                )
               )
               (i64.const 1)
               (struct.get $type76 0
                (local.get $6)
               )
              )
             )
             (if
              (f64.lt
               (struct.get $type69 0
                (struct.get $type68 1
                 (local.get $5)
                )
               )
               (struct.get $type69 0
                (struct.get $type68 1
                 (local.get $4)
                )
               )
              )
              (then
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (struct.set $type67 0
                (struct.get $type66 0
                 (struct.get $environment56 5
                  (local.get $2)
                 )
                )
                (array.get $type12
                 (struct.get $type64 0
                  (struct.get $environment56 4
                   (local.get $2)
                  )
                 )
                 (i32.wrap_i64
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i32.const 0)
      )
      (else
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (array.get $type12
         (struct.get $type64 0
          (struct.get $environment56 4
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $7)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment56 6
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (f64.lt
         (array.get $type33
          (array.get $type37
           (struct.get $environment56 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
          (i32.wrap_i64
           (local.get $8)
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready61)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (f64.sub
           (f64.const -0)
           (struct.get $type62 0
            (struct.get $environment56 1
             (local.get $2)
            )
           )
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type64 0
            (struct.get $environment56 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $9
          (array.get $type33
           (array.get $type37
            (struct.get $environment56 0
             (local.get $2)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
           (i32.const 0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type64 0
            (struct.get $environment56 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (struct.get $type67 0
             (struct.get $type66 0
              (struct.get $environment56 6
               (local.get $2)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type69 0
          (struct.get $type68 1
           (struct.get $environment56 7
            (local.get $2)
           )
          )
          (f64.div
           (f64.sub
            (f64.const -0)
            (local.get $9)
           )
           (array.get $type33
            (array.get $type37
             (struct.get $environment56 0
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $7)
             )
            )
            (i32.wrap_i64
             (local.get $8)
            )
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type67 0
          (struct.get $type66 0
           (struct.get $environment56 5
            (local.get $2)
           )
          )
          (array.get $type12
           (struct.get $type64 0
            (struct.get $environment56 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (struct.set $type71 0
          (struct.get $type70 1
           (struct.get $environment56 8
            (local.get $2)
           )
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment56 9
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment56 9
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function57 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment57))
  (local $3 (ref $type69))
  (local $4 i64)
  (local $5 i64)
  (local $6 f64)
  (if (result i32)
   (i64.ge_s
    (struct.get $type63 0
     (struct.get $environment57 1
      (local.tee $2
       (ref.cast (ref $environment57)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $type67 0
        (struct.get $type66 0
         (struct.get $environment57 3
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type33
      (array.get $type37
       (struct.get $environment57 0
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $type67 0
        (struct.get $type66 0
         (struct.get $environment57 3
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type67 0
        (struct.get $type66 0
         (struct.get $environment57 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type69 0
     (struct.get $type68 1
      (struct.get $environment57 6
       (local.get $2)
      )
     )
     (f64.div
      (f64.sub
       (f64.const -0)
       (local.get $6)
      )
      (array.get $type33
       (array.get $type37
        (struct.get $environment57 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment57 5
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $type64 0
       (struct.get $environment57 2
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type33
      (array.get $type37
       (struct.get $environment57 0
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment57 5
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $type64 0
       (struct.get $environment57 2
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type67 0
        (struct.get $type66 0
         (struct.get $environment57 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type69 0
     (local.tee $3
      (struct.get $type68 1
       (struct.get $environment57 7
        (local.get $2)
       )
      )
     )
     (f64.div
      (f64.sub
       (f64.const -0)
       (local.get $6)
      )
      (array.get $type33
       (array.get $type37
        (struct.get $environment57 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if (result i32)
     (f64.eq
      (struct.get $type69 0
       (local.get $3)
      )
      (struct.get $type69 0
       (struct.get $type68 1
        (struct.get $environment57 6
         (local.get $2)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type77 0
         (struct.get $environment57 8
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function57
       (struct.get $type76 1
        (struct.get $type77 1
         (struct.get $environment57 8
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function58 (type $59) (param $0 (ref $type37)) (param $1 (ref $type63)) (param $2 (ref $type63)) (param $3 (ref $type66)) (param $4 (ref $type66)) (param $5 i32) (result i32)
  (local $6 (ref $type77))
  (local $7 (ref $type76))
  (local $8 (ref $type62))
  (local $9 i64)
  (local $10 i64)
  (local $11 f64)
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (struct.get $type67 0
      (struct.get $type66 0
       (local.get $3)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $10
     (struct.get $type67 0
      (struct.get $type66 0
       (local.get $4)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $11
   (array.get $type33
    (array.get $type37
     (local.get $0)
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (i32.wrap_i64
     (local.get $10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready63)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global63)
   )
  )
  (struct.set $type77 1
   (local.tee $6
    (struct.new_default $type77)
   )
   (struct.new $type76
    (ref.func $function59)
    (struct.new $environment59
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.tee $8
      (struct.new $type62
       (f64.div
        (f64.const 1)
        (local.get $11)
       )
      )
     )
     (local.get $6)
    )
   )
  )
  (struct.set $type77 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call76
    (struct.get $type76 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type77 1
        (local.get $6)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type76 0
     (local.get $7)
    )
   )
  )
  (struct.set $type77 1
   (local.tee $6
    (struct.new_default $type77)
   )
   (struct.new $type76
    (ref.func $function61)
    (struct.new $environment61
     (local.get $0)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $8)
     (local.get $6)
    )
   )
  )
  (struct.set $type77 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call76
    (struct.get $type76 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type77 1
        (local.get $6)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type76 0
     (local.get $7)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready113)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global113)
   )
  )
  (return_call $function43
   (local.get $0)
   (struct.get $type67 0
    (struct.get $type66 0
     (local.get $3)
    )
   )
   (struct.get $type67 0
    (struct.get $type66 0
     (local.get $4)
    )
   )
   (struct.get $type62 0
    (local.get $8)
   )
  )
 )
 (func $function59 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment59))
  (local $3 (ref $type77))
  (local $4 (ref $type37))
  (local $5 (ref $type66))
  (local $6 (ref $type76))
  (local $7 i64)
  (local $8 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type63 0
      (struct.get $environment59 1
       (local.tee $2
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (select
      (i64.const 2)
      (i64.const 1)
      (struct.get $environment59 5
       (local.get $2)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type67 0
       (struct.get $type66 0
        (struct.get $environment59 3
         (local.get $2)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $7
         (struct.get $type67 0
          (struct.get $type66 0
           (struct.get $environment59 4
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (array.get $type33
        (array.get $type37
         (struct.get $environment59 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $7)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready113)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (drop
       (call $function43
        (local.tee $4
         (struct.get $environment59 0
          (local.get $2)
         )
        )
        (local.get $1)
        (struct.get $type67 0
         (struct.get $type66 0
          (local.tee $5
           (struct.get $environment59 4
            (local.get $2)
           )
          )
         )
        )
        (f64.mul
         (struct.get $type62 0
          (struct.get $environment59 6
           (local.get $2)
          )
         )
         (local.get $8)
        )
       )
      )
      (struct.set $type77 1
       (local.tee $3
        (struct.new_default $type77)
       )
       (struct.new $type76
        (ref.func $function60)
        (struct.new $environment60
         (local.get $4)
         (struct.get $environment59 2
          (local.get $2)
         )
         (struct.get $environment59 3
          (local.get $2)
         )
         (local.get $5)
         (local.get $1)
         (local.get $3)
        )
       )
      )
      (struct.set $type77 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type77 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call76
        (struct.get $type76 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type77 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type76 0
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment59 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment59 7
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function60 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment60))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type63 0
      (struct.get $environment60 1
       (ref.cast (ref $environment60)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type67 0
       (struct.get $type66 0
        (struct.get $environment60 3
         (local.tee $2
          (ref.cast (ref $environment60)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment60 4
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (array.get $type33
        (array.get $type37
         (struct.get $environment60 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type67 0
          (struct.get $type66 0
           (struct.get $environment60 2
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (array.get $type33
        (array.get $type37
         (struct.get $environment60 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $environment60 4
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (struct.get $type67 0
          (struct.get $type66 0
           (struct.get $environment60 3
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (array.get $type33
        (array.get $type37
         (struct.get $environment60 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready113)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (drop
       (call $function43
        (struct.get $environment60 0
         (local.get $2)
        )
        (local.get $4)
        (local.get $1)
        (f64.sub
         (local.get $6)
         (f64.mul
          (local.get $7)
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment60 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function60
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment60 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function61 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment61))
  (local $3 i64)
  (local $4 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type63 0
      (struct.get $environment61 1
       (ref.cast (ref $environment61)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type67 0
       (struct.get $type66 0
        (struct.get $environment61 3
         (local.tee $2
          (ref.cast (ref $environment61)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type67 0
          (struct.get $type66 0
           (struct.get $environment61 2
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type33
        (array.get $type37
         (struct.get $environment61 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready113)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (drop
       (call $function43
        (struct.get $environment61 0
         (local.get $2)
        )
        (struct.get $type67 0
         (struct.get $type66 0
          (struct.get $environment61 2
           (local.get $2)
          )
         )
        )
        (local.get $1)
        (f64.mul
         (f64.sub
          (f64.const -0)
          (struct.get $type62 0
           (struct.get $environment61 4
            (local.get $2)
           )
          )
         )
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment61 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function61
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment61 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function62 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment62))
  (if (result i32)
   (i64.eq
    (struct.get $type63 0
     (struct.get $environment62 0
      (ref.cast (ref $environment62)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment62)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment62 1
       (local.tee $2
        (ref.cast (ref $environment62)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment62 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment62 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment62 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function63 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment63))
  (local $3 (ref $type37))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type63 0
     (struct.get $environment63 1
      (ref.cast (ref $environment63)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (f64.lt
      (array.get $type33
       (array.get $type37
        (struct.get $environment63 0
         (ref.cast (ref $environment63)
          (local.get $0)
         )
        )
        (block (result i32)
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.tee $4
            (i64.add
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i32.const 0)
      )
      (block (result f64)
       (if
        (i32.eqz
         (global.get $ready187)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global187)
        )
       )
       (f64.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (unreachable)
     )
    )
    (drop
     (ref.cast (ref $environment63)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment63 3
       (local.tee $2
        (ref.cast (ref $environment63)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment63 4
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (struct.get $type63 0
       (struct.get $environment63 2
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment63 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function63
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment63 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function65 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment65))
  (if (result i32)
   (i64.eq
    (struct.get $environment65 0
     (ref.cast (ref $environment65)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment65)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (struct.get $type65 0
      (struct.get $environment65 1
       (local.tee $2
        (ref.cast (ref $environment65)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment65 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function65
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment65 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function66 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment66))
  (local $3 (ref $type81))
  (local $4 i64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type63 0
      (struct.get $environment66 3
       (ref.cast (ref $environment66)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $4
     (struct.get $environment66 1
      (local.tee $2
       (ref.cast (ref $environment66)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type81 1
     (local.tee $3
      (struct.new_default $type81)
     )
     (struct.new $type80
      (struct.new $environment67
       (struct.get $environment66 0
        (local.get $2)
       )
       (struct.get $environment66 2
        (local.get $2)
       )
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type81 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type81 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function67
      (struct.get $type80 0
       (struct.get $type81 1
        (local.get $3)
       )
      )
      (i64.add
       (local.get $4)
       (i64.const 1)
      )
      (f64.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment66 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function66
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment66 4
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function67 (type $call80) (param $0 (ref $environment67)) (param $1 i64) (param $2 f64) (result i32)
  (local $3 i64)
  (local $4 f64)
  (if
   (i64.lt_s
    (struct.get $type63 0
     (struct.get $environment67 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i32.eqz
      (global.get $ready113)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (return_call $function43
     (struct.get $environment67 0
      (local.get $0)
     )
     (i64.add
      (struct.get $type63 0
       (struct.get $environment67 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (struct.get $environment67 2
      (local.get $0)
     )
     (f64.sub
      (f64.const -0)
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (struct.get $environment67 2
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type33
      (array.get $type37
       (struct.get $environment67 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type81 0
       (struct.get $environment67 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (struct.get $type80 0
      (struct.get $type81 1
       (struct.get $environment67 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (f64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function68 (type $call10) (param $0 (ref $environment68)) (result i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 (ref $type77))
  (local $6 (ref $type76))
  (local $7 (ref $type37))
  (local $8 (ref $type63))
  (local $9 (ref $type66))
  (local $10 (ref $type68))
  (local $11 (ref $type71))
  (drop
   (call $function52
    (struct.get $environment68 0
     (local.get $0)
    )
    (struct.get $environment68 6
     (local.get $0)
    )
    (struct.get $environment68 9
     (local.get $0)
    )
    (struct.get $environment68 13
     (local.get $0)
    )
    (local.tee $10
     (struct.get $environment68 14
      (local.get $0)
     )
    )
    (i64.add
     (struct.get $type63 0
      (struct.get $environment68 4
       (local.get $0)
      )
     )
     (i64.const 1)
    )
    (i32.const 0)
   )
  )
  (drop
   (if (result i32)
    (f64.le
     (struct.get $type69 0
      (struct.get $type68 1
       (local.get $10)
      )
     )
     (struct.get $type62 0
      (struct.get $environment68 2
       (local.get $0)
      )
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready158)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global158)
      )
     )
     (if
      (i64.gt_u
       (local.tee $1
        (i64.add
         (struct.get $type63 0
          (struct.get $environment68 4
           (local.get $0)
          )
         )
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (f64.lt
       (array.get $type33
        (array.get $type37
         (struct.get $environment68 0
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 0)
       )
       (block (result f64)
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (f64.sub
         (f64.const -0)
         (struct.get $type62 0
          (struct.get $environment68 2
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (struct.set $type71 0
        (struct.get $type70 1
         (struct.get $environment68 16
          (local.get $0)
         )
        )
        (i32.const 0)
       )
       (i32.const 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.tee $1
          (i64.add
           (struct.get $type63 0
            (struct.get $environment68 4
             (local.get $0)
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (f64.ge
         (struct.get $type62 0
          (struct.get $environment68 2
           (local.get $0)
          )
         )
         (array.get $type33
          (array.get $type37
           (local.tee $7
            (struct.get $environment68 0
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 0)
         )
        )
        (then
         (local.set $1
          (struct.get $type63 0
           (local.tee $8
            (struct.get $environment68 3
             (local.get $0)
            )
           )
          )
         )
         (struct.set $type77 1
          (local.tee $5
           (struct.new_default $type77)
          )
          (struct.new $type76
           (ref.func $function69)
           (struct.new $environment69
            (local.get $7)
            (struct.get $environment68 1
             (local.get $0)
            )
            (local.get $8)
            (struct.get $environment68 4
             (local.get $0)
            )
            (struct.get $environment68 5
             (local.get $0)
            )
            (struct.get $environment68 6
             (local.get $0)
            )
            (struct.get $environment68 8
             (local.get $0)
            )
            (struct.get $environment68 9
             (local.get $0)
            )
            (struct.get $environment68 10
             (local.get $0)
            )
            (struct.get $environment68 12
             (local.get $0)
            )
            (struct.get $environment68 13
             (local.get $0)
            )
            (struct.get $environment68 14
             (local.get $0)
            )
            (struct.get $environment68 15
             (local.get $0)
            )
            (struct.get $environment68 17
             (local.get $0)
            )
            (local.get $5)
           )
          )
         )
         (struct.set $type77 0
          (local.get $5)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type77 0
            (local.get $5)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call76
          (struct.get $type76 1
           (local.tee $6
            (ref.as_non_null
             (struct.get $type77 1
              (local.get $5)
             )
            )
           )
          )
          (local.get $1)
          (struct.get $type76 0
           (local.get $6)
          )
         )
        )
        (else
         (drop
          (call $function55
           (struct.get $environment68 0
            (local.get $0)
           )
           (struct.get $environment68 2
            (local.get $0)
           )
           (struct.get $environment68 4
            (local.get $0)
           )
           (struct.get $environment68 5
            (local.get $0)
           )
           (struct.get $environment68 7
            (local.get $0)
           )
           (struct.get $environment68 12
            (local.get $0)
           )
           (struct.get $environment68 13
            (local.get $0)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready203)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (struct.get $type27 1
           (global.get $global203)
          )
         )
         (if
          (i64.eqz
           (struct.get $type67 0
            (struct.get $type66 0
             (struct.get $environment68 12
              (local.get $0)
             )
            )
           )
          )
          (then
           (struct.set $type71 0
            (struct.get $type70 1
             (struct.get $environment68 16
              (local.get $0)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (struct.set $type71 0
            (struct.get $type70 1
             (struct.get $environment68 15
              (local.get $0)
             )
            )
            (i32.const 1)
           )
          )
         )
         (i32.const 0)
        )
       )
      )
     )
    )
    (else
     (drop
      (call $function55
       (struct.get $environment68 0
        (local.get $0)
       )
       (struct.get $environment68 2
        (local.get $0)
       )
       (struct.get $environment68 4
        (local.get $0)
       )
       (struct.get $environment68 5
        (local.get $0)
       )
       (struct.get $environment68 7
        (local.get $0)
       )
       (struct.get $environment68 12
        (local.get $0)
       )
       (struct.get $environment68 13
        (local.get $0)
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready203)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (struct.get $type27 1
       (global.get $global203)
      )
     )
     (if
      (i64.eqz
       (struct.get $type67 0
        (struct.get $type66 0
         (struct.get $environment68 12
          (local.get $0)
         )
        )
       )
      )
      (then
       (struct.set $type71 0
        (struct.get $type70 1
         (struct.get $environment68 16
          (local.get $0)
         )
        )
        (i32.const 0)
       )
      )
      (else
       (struct.set $type71 0
        (struct.get $type70 1
         (struct.get $environment68 15
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
    )
   )
  )
  (if (result i32)
   (struct.get $type71 0
    (local.tee $11
     (struct.get $type70 1
      (struct.get $environment68 15
       (local.get $0)
      )
     )
    )
   )
   (then
    (struct.set $type71 0
     (local.get $11)
     (i32.const 0)
    )
    (drop
     (call $function58
      (struct.get $environment68 0
       (local.get $0)
      )
      (struct.get $environment68 4
       (local.get $0)
      )
      (struct.get $environment68 5
       (local.get $0)
      )
      (local.tee $9
       (struct.get $environment68 12
        (local.get $0)
       )
      )
      (struct.get $environment68 13
       (local.get $0)
      )
      (i32.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.sub
        (struct.get $type67 0
         (struct.get $type66 0
          (local.get $9)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (i64.ge_s
       (array.get $type12
        (struct.get $type64 0
         (struct.get $environment68 10
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (block (result i64)
        (if
         (i32.eqz
          (global.get $ready65)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global65)
         )
        )
        (i64.sub
         (i64.add
          (struct.get $type63 0
           (struct.get $environment68 5
            (local.get $0)
           )
          )
          (struct.get $type63 0
           (struct.get $environment68 3
            (local.get $0)
           )
          )
         )
         (i64.const 1)
        )
       )
      )
      (then
       (struct.set $type77 1
        (local.tee $5
         (struct.new_default $type77)
        )
        (struct.new $type76
         (ref.func $function73)
         (struct.new $environment73
          (struct.get $environment68 0
           (local.get $0)
          )
          (struct.get $environment68 4
           (local.get $0)
          )
          (struct.get $environment68 6
           (local.get $0)
          )
          (struct.get $environment68 9
           (local.get $0)
          )
          (struct.get $environment68 13
           (local.get $0)
          )
          (local.get $5)
         )
        )
       )
       (struct.set $type77 0
        (local.get $5)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type77 0
          (local.get $5)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call76
        (struct.get $type76 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type77 1
            (local.get $5)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type76 0
         (local.get $6)
        )
       )
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.sub
           (struct.get $type67 0
            (struct.get $type66 0
             (struct.get $environment68 12
              (local.get $0)
             )
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (if (result i32)
         (i64.le_s
          (i64.add
           (struct.get $type63 0
            (struct.get $environment68 5
             (local.get $0)
            )
           )
           (struct.get $environment68 1
            (local.get $0)
           )
          )
          (array.get $type12
           (struct.get $type64 0
            (struct.get $environment68 10
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (then
          (if
           (i64.gt_u
            (local.tee $1
             (i64.sub
              (struct.get $type67 0
               (struct.get $type66 0
                (struct.get $environment68 12
                 (local.get $0)
                )
               )
              )
              (i64.const 1)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.tee $1
             (i64.sub
              (array.get $type12
               (struct.get $type64 0
                (struct.get $environment68 10
                 (local.get $0)
                )
               )
               (i32.wrap_i64
                (local.get $1)
               )
              )
              (i64.add
               (struct.get $environment68 1
                (local.get $0)
               )
               (struct.get $type63 0
                (struct.get $environment68 5
                 (local.get $0)
                )
               )
              )
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (array.get $type14
           (struct.get $type65 0
            (struct.get $environment68 8
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (if
          (i64.gt_u
           (local.tee $1
            (i64.sub
             (struct.get $type67 0
              (struct.get $type66 0
               (struct.get $environment68 12
                (local.get $0)
               )
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $1
            (i64.sub
             (array.get $type12
              (struct.get $type64 0
               (struct.get $environment68 10
                (local.get $0)
               )
              )
              (i32.wrap_i64
               (local.get $1)
              )
             )
             (i64.add
              (struct.get $environment68 1
               (local.get $0)
              )
              (struct.get $type63 0
               (struct.get $environment68 5
                (local.get $0)
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type14
          (struct.get $type65 0
           (struct.get $environment68 8
            (local.get $0)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
          (i32.const 0)
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.tee $1
            (i64.add
             (struct.get $type63 0
              (struct.get $environment68 4
               (local.get $0)
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $2
            (struct.get $type67 0
             (struct.get $type66 0
              (struct.get $environment68 13
               (local.get $0)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (array.get $type33
           (array.get $type37
            (struct.get $environment68 0
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready113)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global113)
          )
         )
         (drop
          (call $function43
           (local.tee $7
            (struct.get $environment68 0
             (local.get $0)
            )
           )
           (i64.add
            (struct.get $type63 0
             (local.tee $8
              (struct.get $environment68 4
               (local.get $0)
              )
             )
            )
            (i64.const 1)
           )
           (struct.get $type67 0
            (struct.get $type66 0
             (local.tee $9
              (struct.get $environment68 13
               (local.get $0)
              )
             )
            )
           )
           (f64.add
            (local.get $4)
            (f64.const 1)
           )
          )
         )
         (struct.set $type77 1
          (local.tee $5
           (struct.new_default $type77)
          )
          (struct.new $type76
           (ref.func $function76)
           (struct.new $environment76
            (local.get $7)
            (local.get $8)
            (local.get $9)
            (local.get $5)
           )
          )
         )
         (struct.set $type77 0
          (local.get $5)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type77 0
            (local.get $5)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call76
          (struct.get $type76 1
           (local.tee $6
            (ref.as_non_null
             (struct.get $type77 1
              (local.get $5)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type76 0
           (local.get $6)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.sub
        (struct.get $type67 0
         (struct.get $type66 0
          (struct.get $environment68 13
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (array.get $type12
      (struct.get $type64 0
       (struct.get $environment68 11
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.sub
        (struct.get $type67 0
         (struct.get $type66 0
          (struct.get $environment68 12
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (array.get $type12
      (struct.get $type64 0
       (struct.get $environment68 10
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (i64.sub
        (struct.get $type67 0
         (struct.get $type66 0
          (struct.get $environment68 13
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment68 11
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (local.get $2)
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.sub
        (struct.get $type67 0
         (struct.get $type66 0
          (struct.get $environment68 12
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment68 10
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (struct.get $environment68 18
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function68
     (struct.get $type10 0
      (struct.get $type75 1
       (struct.get $environment68 18
        (local.get $0)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function69 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $environment69))
  (local $3 (ref $type77))
  (local $4 (ref $type68))
  (local $5 (ref $type76))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 f64)
  (local $scratch i64)
  (block $block
   (return
    (if (result i32)
     (i64.ge_s
      (struct.get $type63 0
       (struct.get $environment69 3
        (local.tee $2
         (ref.cast (ref $environment69)
          (local.get $0)
         )
        )
       )
      )
      (local.get $1)
     )
     (then
      (drop
       (struct.get $environment69 8
        (local.get $2)
       )
      )
      (if
       (i64.gt_u
        (local.tee $6
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (br_if $block
       (i64.ne
        (array.get $type12
         (struct.get $type64 0
          (struct.get $environment69 8
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $6)
         )
        )
        (i64.sub
         (i64.add
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment69 9
             (local.get $2)
            )
           )
          )
          (block (result i64)
           (local.set $scratch
            (struct.get $type63 0
             (struct.get $environment69 4
              (local.get $2)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready65)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global65)
            )
           )
           (local.get $scratch)
          )
         )
         (i64.const 1)
        )
       )
      )
      (drop
       (struct.get $environment69 13
        (local.get $2)
       )
      )
      (drop
       (call $function52
        (struct.get $environment69 0
         (local.get $2)
        )
        (struct.get $environment69 5
         (local.get $2)
        )
        (struct.get $environment69 7
         (local.get $2)
        )
        (struct.get $environment69 10
         (local.get $2)
        )
        (local.tee $4
         (struct.get $environment69 11
          (local.get $2)
         )
        )
        (local.get $1)
        (i32.const 1)
       )
      )
      (br_if $block
       (i32.eqz
        (f64.gt
         (struct.get $type69 0
          (struct.get $type68 1
           (local.get $4)
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready76)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global76)
           )
          )
          (f64.const 0)
         )
        )
       )
      )
      (struct.set $type67 0
       (struct.get $type66 0
        (struct.get $environment69 9
         (local.get $2)
        )
       )
       (local.get $1)
      )
      (drop
       (struct.get $environment69 12
        (local.get $2)
       )
      )
      (struct.set $type71 0
       (struct.get $type70 1
        (struct.get $environment69 12
         (local.get $2)
        )
       )
       (i32.const 1)
      )
      (i32.const 0)
     )
     (else
      (struct.set $type77 1
       (local.tee $3
        (struct.new_default $type77)
       )
       (struct.new $type76
        (ref.func $function70)
        (struct.new $environment70
         (struct.get $environment69 0
          (local.get $2)
         )
         (local.tee $1
          (struct.get $environment69 1
           (local.get $2)
          )
         )
         (struct.get $environment69 2
          (local.get $2)
         )
         (struct.get $environment69 4
          (local.get $2)
         )
         (struct.get $environment69 6
          (local.get $2)
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type77 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type77 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call76
       (struct.get $type76 1
        (local.tee $5
         (ref.as_non_null
          (struct.get $type77 1
           (local.get $3)
          )
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
       (struct.get $type76 0
        (local.get $5)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (struct.get $environment69 14
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function69
   (struct.get $type76 1
    (struct.get $type77 1
     (struct.get $environment69 14
      (local.get $2)
     )
    )
   )
   (i64.add
    (local.get $1)
    (i64.const 1)
   )
  )
 )
 (func $function70 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment70))
  (local $3 (ref $type77))
  (local $4 (ref $type76))
  (local $5 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type63 0
     (struct.get $environment70 2
      (ref.cast (ref $environment70)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (array.get $type14
      (struct.get $type65 0
       (struct.get $environment70 4
        (local.tee $2
         (ref.cast (ref $environment70)
          (local.get $0)
         )
        )
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.tee $5
          (i64.sub
           (local.get $1)
           (i64.add
            (struct.get $environment70 1
             (local.get $2)
            )
            (i64.const 1)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
     (then
      (struct.set $type77 1
       (local.tee $3
        (struct.new_default $type77)
       )
       (struct.new $type76
        (ref.func $function71)
        (struct.new $environment71
         (struct.get $environment70 0
          (local.get $2)
         )
         (struct.get $environment70 3
          (local.get $2)
         )
         (local.get $1)
         (local.get $3)
        )
       )
      )
      (struct.set $type77 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type77 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call76
        (struct.get $type76 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type77 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type76 0
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment70 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment70 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment71))
  (local $3 (ref $type37))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type63 0
      (struct.get $environment71 1
       (ref.cast (ref $environment71)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function43
      (struct.get $environment71 0
       (local.tee $2
        (ref.cast (ref $environment71)
         (local.get $0)
        )
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $environment71 2
           (local.get $2)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type33
         (array.get $type37
          (struct.get $environment71 0
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready113)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global113)
        )
       )
       (local.get $4)
      )
      (local.get $1)
      (f64.sub
       (f64.const -0)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment71 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment71 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function72 (type $call27) (param $0 (ref null $environment102)) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function73 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment73))
  (local $3 (ref $type77))
  (local $4 (ref $type66))
  (local $5 (ref $type76))
  (local $6 (ref $type37))
  (local $7 (ref $type63))
  (local $8 i64)
  (local $9 f64)
  (if
   (if (result i32)
    (i64.gt_s
     (struct.get $type67 0
      (struct.get $type66 0
       (struct.get $environment73 3
        (local.tee $2
         (ref.cast (ref $environment73)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $1)
    )
    (then
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (struct.get $type67 0
       (struct.get $type66 0
        (struct.get $environment73 4
         (local.get $2)
        )
       )
      )
      (array.get $type12
       (struct.get $type64 0
        (struct.get $environment73 2
         (local.get $2)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment73 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function73
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment73 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (struct.set $type67 0
     (struct.get $type66 0
      (local.tee $4
       (struct.get $environment73 3
        (local.get $2)
       )
      )
     )
     (i64.sub
      (struct.get $type67 0
       (struct.get $type66 0
        (local.get $4)
       )
      )
      (i64.const 1)
     )
    )
    (struct.set $type77 1
     (local.tee $3
      (struct.new_default $type77)
     )
     (struct.new $type76
      (ref.func $function74)
      (struct.new $environment74
       (struct.get $environment73 2
        (local.get $2)
       )
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type77 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call76
      (struct.get $type76 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type77 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type76 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (struct.get $type63 0
         (struct.get $environment73 1
          (local.get $2)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (struct.get $type67 0
        (struct.get $type66 0
         (struct.get $environment73 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type33
      (array.get $type37
       (struct.get $environment73 0
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $8)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready113)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (drop
     (call $function43
      (local.tee $6
       (struct.get $environment73 0
        (local.get $2)
       )
      )
      (i64.add
       (struct.get $type63 0
        (local.tee $7
         (struct.get $environment73 1
          (local.get $2)
         )
        )
       )
       (i64.const 1)
      )
      (struct.get $type67 0
       (struct.get $type66 0
        (local.tee $4
         (struct.get $environment73 4
          (local.get $2)
         )
        )
       )
      )
      (f64.add
       (local.get $9)
       (f64.const 1)
      )
     )
    )
    (struct.set $type77 1
     (local.tee $3
      (struct.new_default $type77)
     )
     (struct.new $type76
      (ref.func $function75)
      (struct.new $environment75
       (local.get $6)
       (local.get $7)
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type77 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call76
     (struct.get $type76 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type77 1
         (local.get $3)
        )
       )
      )
     )
     (i64.const 0)
     (struct.get $type76 0
      (local.get $5)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function74 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment74))
  (local $3 (ref $type12))
  (local $4 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type67 0
     (struct.get $type66 0
      (struct.get $environment74 1
       (ref.cast (ref $environment74)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment74 0
       (local.tee $2
        (ref.cast (ref $environment74)
         (local.get $0)
        )
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type12
        (struct.get $type64 0
         (struct.get $environment74 0
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment74 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment74 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function75 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment75))
  (local $3 (ref $type37))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type63 0
      (struct.get $environment75 1
       (ref.cast (ref $environment75)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function43
      (struct.get $environment75 0
       (local.tee $2
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment75 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type33
         (array.get $type37
          (struct.get $environment75 0
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready113)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global113)
        )
       )
       (local.get $1)
      )
      (struct.get $type67 0
       (struct.get $type66 0
        (struct.get $environment75 2
         (local.get $2)
        )
       )
      )
      (f64.sub
       (f64.const -0)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment75 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment75 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function76 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment76))
  (local $3 (ref $type37))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type63 0
      (struct.get $environment76 1
       (ref.cast (ref $environment76)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function43
      (struct.get $environment76 0
       (local.tee $2
        (ref.cast (ref $environment76)
         (local.get $0)
        )
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment76 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type33
         (array.get $type37
          (struct.get $environment76 0
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready113)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global113)
        )
       )
       (local.get $1)
      )
      (struct.get $type67 0
       (struct.get $type66 0
        (struct.get $environment76 2
         (local.get $2)
        )
       )
      )
      (f64.sub
       (f64.const -0)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment76 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function76
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment76 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function77 (type $call73) (param $0 (ref $environment77)) (result (ref $type45))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type66))
  (drop
   (call $function52
    (struct.get $environment77 0
     (local.get $0)
    )
    (struct.get $environment77 4
     (local.get $0)
    )
    (struct.get $environment77 6
     (local.get $0)
    )
    (struct.get $environment77 10
     (local.get $0)
    )
    (struct.get $environment77 11
     (local.get $0)
    )
    (i64.const 0)
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready76)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global76)
   )
  )
  (if (result (ref $type45))
   (f64.gt
    (struct.get $type69 0
     (struct.get $type68 1
      (struct.get $environment77 11
       (local.get $0)
      )
     )
    )
    (f64.const 0)
   )
   (then
    (drop
     (call $function55
      (struct.get $environment77 0
       (local.get $0)
      )
      (struct.get $environment77 1
       (local.get $0)
      )
      (struct.get $environment77 2
       (local.get $0)
      )
      (struct.get $environment77 3
       (local.get $0)
      )
      (struct.get $environment77 5
       (local.get $0)
      )
      (struct.get $environment77 9
       (local.get $0)
      )
      (struct.get $environment77 10
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready203)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global203)
     )
    )
    (if (result (ref $type47))
     (i64.eqz
      (struct.get $type67 0
       (struct.get $type66 0
        (struct.get $environment77 9
         (local.get $0)
        )
       )
      )
     )
     (then
      (struct.new $type47
       (i32.const 1)
      )
     )
     (else
      (drop
       (call $function58
        (struct.get $environment77 0
         (local.get $0)
        )
        (struct.get $environment77 2
         (local.get $0)
        )
        (struct.get $environment77 3
         (local.get $0)
        )
        (struct.get $environment77 9
         (local.get $0)
        )
        (local.tee $4
         (struct.get $environment77 10
          (local.get $0)
         )
        )
        (i32.const 0)
       )
      )
      (if
       (i64.gt_u
        (local.tee $2
         (i64.sub
          (struct.get $type67 0
           (struct.get $type66 0
            (local.get $4)
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (array.get $type12
        (struct.get $type64 0
         (struct.get $environment77 8
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (i64.sub
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment77 9
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (array.get $type12
        (struct.get $type64 0
         (struct.get $environment77 7
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (i64.sub
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment77 10
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $type64 0
        (struct.get $environment77 8
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $3)
       )
       (local.get $1)
      )
      (if
       (i64.gt_u
        (local.tee $1
         (i64.sub
          (struct.get $type67 0
           (struct.get $type66 0
            (struct.get $environment77 9
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $type64 0
        (struct.get $environment77 7
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $2)
      )
      (if
       (i32.eqz
        (struct.get $type74 0
         (struct.get $environment77 12
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function77
       (struct.get $type73 0
        (struct.get $type74 1
         (struct.get $environment77 12
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready216)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global216)
     )
    )
    (struct.new $type48
     (i32.const 2)
     (struct.new $type20
      (struct.get $type64 0
       (struct.get $environment77 7
        (local.get $0)
       )
      )
      (struct.new $type20
       (struct.get $type64 0
        (struct.get $environment77 8
         (local.get $0)
        )
       )
       (ref.null none)
      )
     )
    )
   )
  )
 )
 (func $function80 (type $30) (param $0 (ref $type37)) (param $1 i64) (param $2 i64) (param $3 i64) (result (ref $type22))
  (local $4 (ref null $type22))
  (local $5 (ref null $type22))
  (local $6 (ref $environment82))
  (local $7 (ref $type22))
  (local $8 (ref $type77))
  (local $9 (ref $type63))
  (local $10 (ref $type63))
  (local $11 (ref $type76))
  (local $12 (ref $type75))
  (local $13 (ref $type74))
  (local $14 (ref $type83))
  (local $15 (ref $type59))
  (local $16 (ref $type64))
  (local $17 (ref $type64))
  (local $18 (ref $type64))
  (local $19 (ref $type64))
  (local $20 (ref $type65))
  (local $21 (ref $type66))
  (local $22 (ref $type66))
  (local $23 (ref $type66))
  (local $24 (ref $type68))
  (local $25 (ref $type70))
  (local $26 (ref $type62))
  (local $27 (ref $type45))
  (local $28 (ref $type58))
  (local $29 (ref null $type20))
  (local $30 f64)
  (local $31 i32)
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type29 0
   (global.get $global80)
   (ref.null none)
  )
  (if
   (i32.eqz
    (global.get $ready119)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i64.ge_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if (result i32)
       (i64.ge_s
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if (result i32)
         (i64.ge_s
          (local.get $3)
          (i64.const 0)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready125)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global125)
           )
          )
          (if
           (i32.eqz
            (global.get $ready69)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global69)
           )
          )
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (i64.add
            (i64.add
             (local.get $3)
             (i64.add
              (local.get $1)
              (local.get $2)
             )
            )
            (i64.const 2)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (local.set $16
   (struct.new $type64
    (call $function48
     (struct.get $type11 1
      (global.get $global133)
     )
     (struct.get $type63 0
      (local.tee $9
       (struct.new $type63
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (array.get $type37
            (local.get $0)
            (i32.const 0)
           )
          )
         )
         (i64.const 1)
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (local.set $17
   (struct.new $type64
    (call $function48
     (struct.get $type11 1
      (global.get $global133)
     )
     (struct.get $type63 0
      (local.tee $10
       (struct.new $type63
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 2)
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (local.set $20
   (struct.new $type65
    (call $function50
     (struct.get $type13 1
      (global.get $global141)
     )
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (local.set $18
   (struct.new $type64
    (call $function48
     (struct.get $type11 1
      (global.get $global133)
     )
     (struct.get $type63 0
      (local.get $10)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type77 1
   (local.tee $8
    (struct.new_default $type77)
   )
   (struct.new $type76
    (ref.func $function62)
    (struct.new $environment62
     (local.get $9)
     (local.get $16)
     (local.tee $19
      (struct.new $type64
       (call $function48
        (struct.get $type11 1
         (global.get $global133)
        )
        (struct.get $type63 0
         (local.get $9)
        )
       )
      )
     )
     (local.get $8)
    )
   )
  )
  (struct.set $type77 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call76
    (struct.get $type76 1
     (local.tee $11
      (ref.as_non_null
       (struct.get $type77 1
        (local.get $8)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type76 0
     (local.get $11)
    )
   )
  )
  (struct.set $type77 1
   (local.tee $8
    (struct.new_default $type77)
   )
   (struct.new $type76
    (ref.func $function63)
    (struct.new $environment63
     (local.get $0)
     (local.get $10)
     (local.get $9)
     (local.get $17)
     (local.get $18)
     (local.get $8)
    )
   )
  )
  (struct.set $type77 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call76
    (struct.get $type76 1
     (local.tee $11
      (ref.as_non_null
       (struct.get $type77 1
        (local.get $8)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type76 0
     (local.get $11)
    )
   )
  )
  (struct.set $type77 1
   (local.tee $8
    (struct.new_default $type77)
   )
   (struct.new $type76
    (ref.func $function65)
    (struct.new $environment65
     (local.get $2)
     (local.get $20)
     (local.get $8)
    )
   )
  )
  (struct.set $type77 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call76
    (struct.get $type76 1
     (local.tee $11
      (ref.as_non_null
       (struct.get $type77 1
        (local.get $8)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type76 0
     (local.get $11)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready74)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type27 1
    (global.get $global74)
   )
  )
  (local.set $21
   (struct.new $type66
    (struct.new $type67
     (struct.get $type63 0
      (local.get $9)
     )
    )
   )
  )
  (local.set $22
   (struct.new $type66
    (struct.new_default $type67)
   )
  )
  (local.set $23
   (struct.new $type66
    (struct.new_default $type67)
   )
  )
  (local.set $24
   (struct.new $type68
    (i32.const 1)
    (struct.new_default $type69)
   )
  )
  (local.set $25
   (struct.new $type70
    (i32.const 1)
    (struct.new $type71
     (i32.const 1)
    )
   )
  )
  (local.set $26
   (struct.new $type62
    (f64.const 1e-06)
   )
  )
  (if
   (i64.gt_s
    (i64.add
     (local.get $2)
     (local.get $3)
    )
    (i64.const 0)
   )
   (then
    (struct.set $type77 1
     (local.tee $8
      (struct.new_default $type77)
     )
     (struct.new $type76
      (ref.func $function66)
      (struct.new $environment66
       (local.get $0)
       (local.get $1)
       (local.get $10)
       (local.get $9)
       (local.get $8)
      )
     )
    )
    (struct.set $type77 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call76
      (struct.get $type76 1
       (local.tee $11
        (ref.as_non_null
         (struct.get $type77 1
          (local.get $8)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type76 0
       (local.get $11)
      )
     )
    )
    (struct.set $type75 1
     (local.tee $12
      (struct.new_default $type75)
     )
     (struct.new $type10
      (struct.new $environment68
       (local.get $0)
       (local.get $1)
       (local.get $26)
       (struct.new $type63
        (i64.add
         (i64.add
          (local.get $1)
          (local.get $2)
         )
         (i64.const 1)
        )
       )
       (local.get $10)
       (local.get $9)
       (local.get $16)
       (local.get $17)
       (local.get $20)
       (local.get $21)
       (local.get $18)
       (local.get $19)
       (local.get $22)
       (local.get $23)
       (local.get $24)
       (struct.new $type70
        (i32.const 1)
        (struct.new_default $type71)
       )
       (local.get $25)
       (struct.new_default $type72)
       (local.get $12)
      )
     )
    )
    (struct.set $type75 0
     (local.get $12)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (local.get $12)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function68
      (struct.get $type10 0
       (struct.get $type75 1
        (local.get $12)
       )
      )
     )
    )
   )
  )
  (local.set $27
   (if (result (ref $type45))
    (struct.get $type71 0
     (struct.get $type70 1
      (local.get $25)
     )
    )
    (then
     (struct.set $type74 1
      (local.tee $13
       (struct.new_default $type74)
      )
      (struct.new $type73
       (struct.new $environment77
        (local.get $0)
        (local.get $26)
        (local.get $10)
        (local.get $9)
        (local.get $16)
        (local.get $17)
        (local.get $21)
        (local.get $18)
        (local.get $19)
        (local.get $22)
        (local.get $23)
        (local.get $24)
        (local.get $13)
       )
      )
     )
     (struct.set $type74 0
      (local.get $13)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type74 0
        (local.get $13)
       )
      )
      (then
       (unreachable)
      )
     )
     (call $function77
      (struct.get $type73 0
       (struct.get $type74 1
        (local.get $13)
       )
      )
     )
    )
    (else
     (struct.new_default $type46)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type29 0
    (global.get $global80)
   )
  )
  (if
   (i32.eqz
    (global.get $ready230)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global230)
   )
  )
  (struct.set $type83 1
   (local.tee $14
    (struct.new_default $type83)
   )
   (struct.new $type82
    (struct.new $environment82
     (local.get $14)
    )
   )
  )
  (struct.set $type83 0
   (local.get $14)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type83 0
     (local.get $14)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type82 0
    (struct.get $type83 1
     (local.get $14)
    )
   )
  )
  (local.set $1
   (if (result i64)
    (ref.is_null
     (local.get $4)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $4
      (struct.get $type22 1
       (local.get $4)
      )
     )
     (if
      (i32.eqz
       (struct.get $type83 0
        (struct.get $environment82 0
         (local.get $6)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $6
      (struct.get $type82 0
       (struct.get $type83 1
        (struct.get $environment82 0
         (local.get $6)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $4
        (struct.get $type22 1
         (local.get $4)
        )
       )
       (if
        (i32.eqz
         (struct.get $type83 0
          (struct.get $environment82 0
           (local.get $6)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $6
        (struct.get $type82 0
         (struct.get $type83 1
          (struct.get $environment82 0
           (local.get $6)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $4)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $4
          (struct.get $type22 1
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (struct.get $type83 0
            (struct.get $environment82 0
             (local.get $6)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $6
          (struct.get $type82 0
           (struct.get $type83 1
            (struct.get $environment82 0
             (local.get $6)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $4)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $4
            (struct.get $type22 1
             (local.get $4)
            )
           )
           (if
            (i32.eqz
             (struct.get $type83 0
              (struct.get $environment82 0
               (local.get $6)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $6
            (struct.get $type82 0
             (struct.get $type83 1
              (struct.get $environment82 0
               (local.get $6)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $4)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $4
              (struct.get $type22 1
               (local.get $4)
              )
             )
             (if
              (i32.eqz
               (struct.get $type83 0
                (struct.get $environment82 0
                 (local.get $6)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $6
              (struct.get $type82 0
               (struct.get $type83 1
                (struct.get $environment82 0
                 (local.get $6)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $4
                (struct.get $type22 1
                 (local.get $4)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type83 0
                  (struct.get $environment82 0
                   (local.get $6)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $6
                (struct.get $type82 0
                 (struct.get $type83 1
                  (struct.get $environment82 0
                   (local.get $6)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $4
                  (struct.get $type22 1
                   (local.get $4)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type83 0
                    (struct.get $environment82 0
                     (local.get $6)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $6
                  (struct.get $type82 0
                   (struct.get $type83 1
                    (struct.get $environment82 0
                     (local.get $6)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $4
                    (struct.get $type22 1
                     (local.get $4)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type83 0
                      (struct.get $environment82 0
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $6
                    (struct.get $type82 0
                     (struct.get $type83 1
                      (struct.get $environment82 0
                       (local.get $6)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $4
                      (struct.get $type22 1
                       (local.get $4)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type83 0
                        (struct.get $environment82 0
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $6
                      (struct.get $type82 0
                       (struct.get $type83 1
                        (struct.get $environment82 0
                         (local.get $6)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (local.set $4
                        (struct.get $type22 1
                         (local.get $4)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type83 0
                          (struct.get $environment82 0
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $6
                        (struct.get $type82 0
                         (struct.get $type83 1
                          (struct.get $environment82 0
                           (local.get $6)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (local.set $4
                          (struct.get $type22 1
                           (local.get $4)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type83 0
                            (struct.get $environment82 0
                             (local.get $6)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $6
                          (struct.get $type82 0
                           (struct.get $type83 1
                            (struct.get $environment82 0
                             (local.get $6)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $4)
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (local.set $4
                            (struct.get $type22 1
                             (local.get $4)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type83 0
                              (struct.get $environment82 0
                               (local.get $6)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $6
                            (struct.get $type82 0
                             (struct.get $type83 1
                              (struct.get $environment82 0
                               (local.get $6)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (local.set $4
                              (struct.get $type22 1
                               (local.get $4)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type83 0
                                (struct.get $environment82 0
                                 (local.get $6)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $6
                              (struct.get $type82 0
                               (struct.get $type83 1
                                (struct.get $environment82 0
                                 (local.get $6)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (local.set $4
                                (struct.get $type22 1
                                 (local.get $4)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type83 0
                                  (struct.get $environment82 0
                                   (local.get $6)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (call $function82
                                (struct.get $type82 0
                                 (struct.get $type83 1
                                  (struct.get $environment82 0
                                   (local.get $6)
                                  )
                                 )
                                )
                                (local.get $4)
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type29 0
    (global.get $global80)
   )
  )
  (if
   (i32.eqz
    (global.get $ready235)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (local.set $4
   (if (result (ref null $type22))
    (ref.is_null
     (local.get $4)
    )
    (then
     (ref.null none)
    )
    (else
     (local.set $5
      (struct.get $type22 1
       (local.get $4)
      )
     )
     (local.set $7
      (struct.new $type22
       (struct.get $type22 0
        (local.get $4)
       )
       (block (result nullref)
        (if
         (i32.eqz
          (global.get $ready235)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global235)
         )
        )
        (ref.null none)
       )
      )
     )
     (if (result (ref null $type22))
      (ref.is_null
       (local.get $5)
      )
      (then
       (local.get $7)
      )
      (else
       (local.set $4
        (struct.get $type22 1
         (local.get $5)
        )
       )
       (local.set $7
        (struct.new $type22
         (struct.get $type22 0
          (local.get $5)
         )
         (block (result (ref $type22))
          (if
           (i32.eqz
            (global.get $ready235)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global235)
           )
          )
          (local.get $7)
         )
        )
       )
       (if (result (ref null $type22))
        (ref.is_null
         (local.get $4)
        )
        (then
         (local.get $7)
        )
        (else
         (local.set $5
          (struct.get $type22 1
           (local.get $4)
          )
         )
         (local.set $7
          (struct.new $type22
           (struct.get $type22 0
            (local.get $4)
           )
           (block (result (ref $type22))
            (if
             (i32.eqz
              (global.get $ready235)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global235)
             )
            )
            (local.get $7)
           )
          )
         )
         (if (result (ref null $type22))
          (ref.is_null
           (local.get $5)
          )
          (then
           (local.get $7)
          )
          (else
           (local.set $4
            (struct.get $type22 1
             (local.get $5)
            )
           )
           (local.set $7
            (struct.new $type22
             (struct.get $type22 0
              (local.get $5)
             )
             (block (result (ref $type22))
              (if
               (i32.eqz
                (global.get $ready235)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global235)
               )
              )
              (local.get $7)
             )
            )
           )
           (if (result (ref null $type22))
            (ref.is_null
             (local.get $4)
            )
            (then
             (local.get $7)
            )
            (else
             (local.set $5
              (struct.get $type22 1
               (local.get $4)
              )
             )
             (local.set $7
              (struct.new $type22
               (struct.get $type22 0
                (local.get $4)
               )
               (block (result (ref $type22))
                (if
                 (i32.eqz
                  (global.get $ready235)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global235)
                 )
                )
                (local.get $7)
               )
              )
             )
             (if (result (ref null $type22))
              (ref.is_null
               (local.get $5)
              )
              (then
               (local.get $7)
              )
              (else
               (local.set $4
                (struct.get $type22 1
                 (local.get $5)
                )
               )
               (local.set $7
                (struct.new $type22
                 (struct.get $type22 0
                  (local.get $5)
                 )
                 (block (result (ref $type22))
                  (if
                   (i32.eqz
                    (global.get $ready235)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global235)
                   )
                  )
                  (local.get $7)
                 )
                )
               )
               (if (result (ref null $type22))
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (local.get $7)
                )
                (else
                 (local.set $5
                  (struct.get $type22 1
                   (local.get $4)
                  )
                 )
                 (local.set $7
                  (struct.new $type22
                   (struct.get $type22 0
                    (local.get $4)
                   )
                   (block (result (ref $type22))
                    (if
                     (i32.eqz
                      (global.get $ready235)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global235)
                     )
                    )
                    (local.get $7)
                   )
                  )
                 )
                 (if (result (ref null $type22))
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (local.get $7)
                  )
                  (else
                   (local.set $4
                    (struct.get $type22 1
                     (local.get $5)
                    )
                   )
                   (local.set $7
                    (struct.new $type22
                     (struct.get $type22 0
                      (local.get $5)
                     )
                     (block (result (ref $type22))
                      (if
                       (i32.eqz
                        (global.get $ready235)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global235)
                       )
                      )
                      (local.get $7)
                     )
                    )
                   )
                   (if (result (ref null $type22))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $7)
                    )
                    (else
                     (local.set $5
                      (struct.get $type22 1
                       (local.get $4)
                      )
                     )
                     (local.set $7
                      (struct.new $type22
                       (struct.get $type22 0
                        (local.get $4)
                       )
                       (block (result (ref $type22))
                        (if
                         (i32.eqz
                          (global.get $ready235)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global235)
                         )
                        )
                        (local.get $7)
                       )
                      )
                     )
                     (if (result (ref null $type22))
                      (ref.is_null
                       (local.get $5)
                      )
                      (then
                       (local.get $7)
                      )
                      (else
                       (local.set $4
                        (struct.get $type22 1
                         (local.get $5)
                        )
                       )
                       (local.set $7
                        (struct.new $type22
                         (struct.get $type22 0
                          (local.get $5)
                         )
                         (block (result (ref $type22))
                          (if
                           (i32.eqz
                            (global.get $ready235)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global235)
                           )
                          )
                          (local.get $7)
                         )
                        )
                       )
                       (if (result (ref null $type22))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $7)
                        )
                        (else
                         (local.set $5
                          (struct.get $type22 1
                           (local.get $4)
                          )
                         )
                         (local.set $7
                          (struct.new $type22
                           (struct.get $type22 0
                            (local.get $4)
                           )
                           (block (result (ref $type22))
                            (if
                             (i32.eqz
                              (global.get $ready235)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global235)
                             )
                            )
                            (local.get $7)
                           )
                          )
                         )
                         (if (result (ref null $type22))
                          (ref.is_null
                           (local.get $5)
                          )
                          (then
                           (local.get $7)
                          )
                          (else
                           (local.set $4
                            (struct.get $type22 1
                             (local.get $5)
                            )
                           )
                           (local.set $7
                            (struct.new $type22
                             (struct.get $type22 0
                              (local.get $5)
                             )
                             (block (result (ref $type22))
                              (if
                               (i32.eqz
                                (global.get $ready235)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global235)
                               )
                              )
                              (local.get $7)
                             )
                            )
                           )
                           (if (result (ref null $type22))
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (local.get $7)
                            )
                            (else
                             (local.set $5
                              (struct.get $type22 1
                               (local.get $4)
                              )
                             )
                             (local.set $7
                              (struct.new $type22
                               (struct.get $type22 0
                                (local.get $4)
                               )
                               (block (result (ref $type22))
                                (if
                                 (i32.eqz
                                  (global.get $ready235)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global235)
                                 )
                                )
                                (local.get $7)
                               )
                              )
                             )
                             (if (result (ref null $type22))
                              (ref.is_null
                               (local.get $5)
                              )
                              (then
                               (local.get $7)
                              )
                              (else
                               (local.set $4
                                (struct.get $type22 1
                                 (local.get $5)
                                )
                               )
                               (local.set $7
                                (struct.new $type22
                                 (struct.get $type22 0
                                  (local.get $5)
                                 )
                                 (block (result (ref $type22))
                                  (if
                                   (i32.eqz
                                    (global.get $ready235)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global235)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                )
                               )
                               (if (result (ref null $type22))
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (local.get $7)
                                )
                                (else
                                 (call $function83
                                  (struct.get $type22 1
                                   (local.get $4)
                                  )
                                  (struct.new $type22
                                   (struct.get $type22 0
                                    (local.get $4)
                                   )
                                   (block (result (ref $type22))
                                    (if
                                     (i32.eqz
                                      (global.get $ready235)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global235)
                                     )
                                    )
                                    (local.get $7)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (struct.set $type59 1
   (local.tee $15
    (struct.new_default $type59)
   )
   (struct.new $type58
    (ref.func $function42)
    (struct.new $environment42
     (local.get $0)
     (local.get $15)
    )
   )
  )
  (struct.set $type59 0
   (local.get $15)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type59 0
     (local.get $15)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (call_ref $call58
    (struct.get $type58 1
     (local.tee $28
      (ref.as_non_null
       (struct.get $type59 1
        (local.get $15)
       )
      )
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $0)
      )
     )
     (i64.const 1)
    )
    (struct.new $type22
     (f64.convert_i64_s
      (local.get $1)
     )
     (local.get $4)
    )
    (struct.get $type58 0
     (local.get $28)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready219)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global219)
   )
  )
  (if (result (ref $type22))
   (local.tee $31
    (struct.get $type45 0
     (local.get $27)
    )
   )
   (then
    (if (result (ref $type22))
     (i32.eq
      (local.get $31)
      (i32.const 1)
     )
     (then
      (struct.new $type22
       (f64.const 1)
       (local.get $4)
      )
     )
     (else
      (local.set $29
       (struct.get $type48 1
        (ref.cast (ref $type48)
         (local.get $27)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready97)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global97)
       )
      )
      (struct.new $type22
       (f64.const 2)
       (call $function37
        (local.get $29)
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (struct.new $type22
     (f64.const 0)
     (local.get $4)
    )
   )
  )
 )
 (func $function82 (type $call82) (param $0 (ref $environment82)) (param $1 (ref null $type22)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type22 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type83 0
       (struct.get $environment82 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function82
     (struct.get $type82 0
      (struct.get $type83 1
       (struct.get $environment82 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function83 (type $23) (param $0 (ref null $type22)) (param $1 (ref $type22)) (result (ref null $type22))
  (local $2 (ref null $type22))
  (local $3 f64)
  (if (result (ref $type22))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function83
     (struct.get $type22 1
      (local.get $0)
     )
     (struct.new $type22
      (struct.get $type22 0
       (local.get $0)
      )
      (block (result (ref $type22))
       (if
        (i32.eqz
         (global.get $ready235)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global235)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function85 (type $call85) (param $0 (ref $environment85)) (param $1 i64) (result (ref $type37))
  (local $2 (ref $type77))
  (local $3 (ref $type87))
  (local $4 (ref $type76))
  (local $5 i64)
  (if (result (ref $type37))
   (i64.eq
    (struct.get $type63 0
     (struct.get $environment85 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type84 0
     (struct.get $environment85 2
      (local.get $0)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type63 0
        (struct.get $environment85 1
         (local.get $0)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type77 1
     (local.tee $2
      (struct.new_default $type77)
     )
     (struct.new $type76
      (ref.func $function86)
      (struct.new $environment86
       (struct.get $environment85 1
        (local.get $0)
       )
       (local.get $1)
       (local.tee $3
        (struct.new $type87
         (i32.const 1)
         (array.new_default $type33
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type77 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call76
      (struct.get $type76 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type77 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type76 0
       (local.get $4)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type37
     (struct.get $type84 0
      (struct.get $environment85 2
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (struct.get $type87 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (struct.get $type86 0
       (struct.get $environment85 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function85
     (struct.get $type85 0
      (struct.get $type86 1
       (struct.get $environment85 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function86 (type $call76) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment86))
  (local $3 (ref $type33))
  (local $4 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type63 0
     (struct.get $environment86 0
      (ref.cast (ref $environment86)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment86)
      (local.get $0)
     )
    )
    (array.set $type33
     (struct.get $type87 1
      (struct.get $environment86 2
       (local.tee $2
        (ref.cast (ref $environment86)
         (local.get $0)
        )
       )
      )
     )
     (block (result i32)
      (local.set $4
       (call $foreign1
        (i32.const 5)
        (i64.add
         (local.get $1)
         (i64.mul
          (struct.get $environment86 1
           (local.get $2)
          )
          (struct.get $type63 0
           (struct.get $environment86 0
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type77 0
       (struct.get $environment86 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function86
     (struct.get $type76 1
      (struct.get $type77 1
       (struct.get $environment86 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function88 (type $call58) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type22)) (result (ref null $type22))
  (local $3 f64)
  (if (result (ref null $type22))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign3
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type59 0
       (struct.get $environment88 0
        (ref.cast (ref $environment88)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function88
     (struct.get $type58 1
      (struct.get $type59 1
       (struct.get $environment88 0
        (ref.cast (ref $environment88)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type22
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function90 (type $call39) (param $0 (ref null $type22)) (param $1 (ref null $type22)) (result i32)
  (local $2 f64)
  (local $3 f64)
  (local $4 i32)
  (local $scratch (ref null $type22))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $2
       (struct.get $type22 0
        (local.get $0)
       )
      )
      (local.set $3
       (struct.get $type22 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready256)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global256)
       )
      )
      (if (result i32)
       (if (result i32)
        (f64.eq
         (local.get $2)
         (local.get $3)
        )
        (then
         (if (result i32)
          (local.tee $4
           (f64.ne
            (local.get $2)
            (f64.const 0)
           )
          )
          (then
           (local.get $4)
          )
          (else
           (f64.eq
            (f64.div
             (f64.const 1)
             (local.get $2)
            )
            (f64.div
             (f64.const 1)
             (local.get $3)
            )
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return_call $function90
         (struct.get $type22 1
          (local.get $0)
         )
         (block (result (ref null $type22))
          (local.set $scratch
           (struct.get $type22 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready253)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global253)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function95 (type $13) (param $0 (ref $type16)) (result (ref $type12))
  (local $1 (ref null $type16))
  (local $2 (ref $environment98))
  (local $3 (ref $environment97))
  (local $4 (ref $type91))
  (local $5 (ref $type89))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready270)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global270)
   )
  )
  (struct.set $type91 1
   (local.tee $4
    (struct.new_default $type91)
   )
   (struct.new $type90
    (struct.new $environment97
     (local.get $4)
    )
   )
  )
  (struct.set $type91 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type91 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type91 0
     (struct.get $environment97 0
      (local.tee $3
       (struct.get $type90 0
        (struct.get $type91 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type90 0
    (struct.get $type91 1
     (struct.get $environment97 0
      (local.get $3)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $6
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type16 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type16 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type91 0
          (struct.get $environment97 0
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type90 0
         (struct.get $type91 1
          (struct.get $environment97 0
           (local.get $3)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type16 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type91 0
            (struct.get $environment97 0
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $3
          (struct.get $type90 0
           (struct.get $type91 1
            (struct.get $environment97 0
             (local.get $3)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type16 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type91 0
              (struct.get $environment97 0
               (local.get $3)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (struct.get $type90 0
             (struct.get $type91 1
              (struct.get $environment97 0
               (local.get $3)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type16 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type91 0
                (struct.get $environment97 0
                 (local.get $3)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $3
              (struct.get $type90 0
               (struct.get $type91 1
                (struct.get $environment97 0
                 (local.get $3)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type16 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type91 0
                  (struct.get $environment97 0
                   (local.get $3)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $3
                (struct.get $type90 0
                 (struct.get $type91 1
                  (struct.get $environment97 0
                   (local.get $3)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type16 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type91 0
                    (struct.get $environment97 0
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $3
                  (struct.get $type90 0
                   (struct.get $type91 1
                    (struct.get $environment97 0
                     (local.get $3)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type16 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type91 0
                      (struct.get $environment97 0
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $3
                    (struct.get $type90 0
                     (struct.get $type91 1
                      (struct.get $environment97 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type16 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type91 0
                        (struct.get $environment97 0
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $3
                      (struct.get $type90 0
                       (struct.get $type91 1
                        (struct.get $environment97 0
                         (local.get $3)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (local.set $1
                        (struct.get $type16 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type91 0
                          (struct.get $environment97 0
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $3
                        (struct.get $type90 0
                         (struct.get $type91 1
                          (struct.get $environment97 0
                           (local.get $3)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (local.set $1
                          (struct.get $type16 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type91 0
                            (struct.get $environment97 0
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $3
                          (struct.get $type90 0
                           (struct.get $type91 1
                            (struct.get $environment97 0
                             (local.get $3)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (local.set $1
                            (struct.get $type16 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type91 0
                              (struct.get $environment97 0
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $3
                            (struct.get $type90 0
                             (struct.get $type91 1
                              (struct.get $environment97 0
                               (local.get $3)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (local.set $1
                              (struct.get $type16 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type91 0
                                (struct.get $environment97 0
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $3
                              (struct.get $type90 0
                               (struct.get $type91 1
                                (struct.get $environment97 0
                                 (local.get $3)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (local.set $1
                                (struct.get $type16 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type91 0
                                  (struct.get $environment97 0
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (call $function97
                                (struct.get $type90 0
                                 (struct.get $type91 1
                                  (struct.get $environment97 0
                                   (local.get $3)
                                  )
                                 )
                                )
                                (local.get $1)
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type89 1
   (local.tee $5
    (struct.new_default $type89)
   )
   (struct.new $type88
    (struct.new $environment98
     (struct.new $type64
      (array.new $type12
       (struct.get $type16 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type89 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type89 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type12
   (struct.get $type64 0
    (struct.get $environment98 0
     (local.tee $2
      (struct.get $type88 0
       (struct.get $type89 1
        (local.get $5)
       )
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type16 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type89 0
     (struct.get $environment98 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type88 0
    (struct.get $type89 1
     (struct.get $environment98 1
      (local.get $2)
     )
    )
   )
  )
  (if (result (ref $type12))
   (ref.is_null
    (local.tee $1
     (struct.get $type16 1
      (local.get $0)
     )
    )
   )
   (then
    (struct.get $type64 0
     (struct.get $environment98 0
      (local.get $2)
     )
    )
   )
   (else
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment98 0
       (local.get $2)
      )
     )
     (i32.const 1)
     (struct.get $type16 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type16 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type89 0
       (struct.get $environment98 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type88 0
      (struct.get $type89 1
       (struct.get $environment98 1
        (local.get $2)
       )
      )
     )
    )
    (if (result (ref $type12))
     (ref.is_null
      (local.get $1)
     )
     (then
      (struct.get $type64 0
       (struct.get $environment98 0
        (local.get $2)
       )
      )
     )
     (else
      (array.set $type12
       (struct.get $type64 0
        (struct.get $environment98 0
         (local.get $2)
        )
       )
       (i32.const 2)
       (struct.get $type16 0
        (local.get $1)
       )
      )
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type89 0
         (struct.get $environment98 1
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type88 0
        (struct.get $type89 1
         (struct.get $environment98 1
          (local.get $2)
         )
        )
       )
      )
      (if (result (ref $type12))
       (ref.is_null
        (local.get $1)
       )
       (then
        (struct.get $type64 0
         (struct.get $environment98 0
          (local.get $2)
         )
        )
       )
       (else
        (array.set $type12
         (struct.get $type64 0
          (struct.get $environment98 0
           (local.get $2)
          )
         )
         (i32.const 3)
         (struct.get $type16 0
          (local.get $1)
         )
        )
        (local.set $1
         (struct.get $type16 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type89 0
           (struct.get $environment98 1
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type88 0
          (struct.get $type89 1
           (struct.get $environment98 1
            (local.get $2)
           )
          )
         )
        )
        (if (result (ref $type12))
         (ref.is_null
          (local.get $1)
         )
         (then
          (struct.get $type64 0
           (struct.get $environment98 0
            (local.get $2)
           )
          )
         )
         (else
          (array.set $type12
           (struct.get $type64 0
            (struct.get $environment98 0
             (local.get $2)
            )
           )
           (i32.const 4)
           (struct.get $type16 0
            (local.get $1)
           )
          )
          (local.set $1
           (struct.get $type16 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type89 0
             (struct.get $environment98 1
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type88 0
            (struct.get $type89 1
             (struct.get $environment98 1
              (local.get $2)
             )
            )
           )
          )
          (if (result (ref $type12))
           (ref.is_null
            (local.get $1)
           )
           (then
            (struct.get $type64 0
             (struct.get $environment98 0
              (local.get $2)
             )
            )
           )
           (else
            (array.set $type12
             (struct.get $type64 0
              (struct.get $environment98 0
               (local.get $2)
              )
             )
             (i32.const 5)
             (struct.get $type16 0
              (local.get $1)
             )
            )
            (local.set $1
             (struct.get $type16 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type89 0
               (struct.get $environment98 1
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type88 0
              (struct.get $type89 1
               (struct.get $environment98 1
                (local.get $2)
               )
              )
             )
            )
            (if (result (ref $type12))
             (ref.is_null
              (local.get $1)
             )
             (then
              (struct.get $type64 0
               (struct.get $environment98 0
                (local.get $2)
               )
              )
             )
             (else
              (array.set $type12
               (struct.get $type64 0
                (struct.get $environment98 0
                 (local.get $2)
                )
               )
               (i32.const 6)
               (struct.get $type16 0
                (local.get $1)
               )
              )
              (local.set $1
               (struct.get $type16 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type89 0
                 (struct.get $environment98 1
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type88 0
                (struct.get $type89 1
                 (struct.get $environment98 1
                  (local.get $2)
                 )
                )
               )
              )
              (if (result (ref $type12))
               (ref.is_null
                (local.get $1)
               )
               (then
                (struct.get $type64 0
                 (struct.get $environment98 0
                  (local.get $2)
                 )
                )
               )
               (else
                (array.set $type12
                 (struct.get $type64 0
                  (struct.get $environment98 0
                   (local.get $2)
                  )
                 )
                 (i32.const 7)
                 (struct.get $type16 0
                  (local.get $1)
                 )
                )
                (local.set $1
                 (struct.get $type16 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type89 0
                   (struct.get $environment98 1
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type88 0
                  (struct.get $type89 1
                   (struct.get $environment98 1
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result (ref $type12))
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (struct.get $type64 0
                   (struct.get $environment98 0
                    (local.get $2)
                   )
                  )
                 )
                 (else
                  (array.set $type12
                   (struct.get $type64 0
                    (struct.get $environment98 0
                     (local.get $2)
                    )
                   )
                   (i32.const 8)
                   (struct.get $type16 0
                    (local.get $1)
                   )
                  )
                  (local.set $1
                   (struct.get $type16 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type89 0
                     (struct.get $environment98 1
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type88 0
                    (struct.get $type89 1
                     (struct.get $environment98 1
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result (ref $type12))
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (struct.get $type64 0
                     (struct.get $environment98 0
                      (local.get $2)
                     )
                    )
                   )
                   (else
                    (array.set $type12
                     (struct.get $type64 0
                      (struct.get $environment98 0
                       (local.get $2)
                      )
                     )
                     (i32.const 9)
                     (struct.get $type16 0
                      (local.get $1)
                     )
                    )
                    (local.set $1
                     (struct.get $type16 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type89 0
                       (struct.get $environment98 1
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function98
                     (struct.get $type88 0
                      (struct.get $type89 1
                       (struct.get $environment98 1
                        (local.get $2)
                       )
                      )
                     )
                     (local.get $1)
                     (i64.const 10)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function97 (type $call90) (param $0 (ref $environment97)) (param $1 (ref null $type16)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type91 0
         (struct.get $environment97 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function97
       (struct.get $type90 0
        (struct.get $type91 1
         (struct.get $environment97 0
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function98 (type $call88) (param $0 (ref $environment98)) (param $1 (ref null $type16)) (param $2 i64) (result (ref $type12))
  (local $3 i64)
  (if (result (ref $type12))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type64 0
     (struct.get $environment98 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type16 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type64 0
      (struct.get $environment98 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type16 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type89 0
       (struct.get $environment98 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function98
     (struct.get $type88 0
      (struct.get $type89 1
       (struct.get $environment98 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function100 (type $call55) (param $0 (ref null $type20)) (param $1 (ref null $type20)) (result i32)
  (local $2 (ref $type92))
  (local $3 (ref $type12))
  (local $4 (ref $type12))
  (local $5 (ref $type27))
  (local $scratch (ref null $type20))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $3
       (struct.get $type20 0
        (local.get $0)
       )
      )
      (local.set $4
       (struct.get $type20 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready287)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global287)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
        )
        (then
         (struct.set $type92 1
          (local.tee $2
           (struct.new_default $type92)
          )
          (struct.new $type27
           (ref.func $function102)
           (struct.new $environment102
            (local.get $3)
            (local.get $4)
            (local.get $2)
           )
          )
         )
         (struct.set $type92 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type92 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call27
          (struct.get $type27 1
           (local.tee $5
            (ref.as_non_null
             (struct.get $type92 1
              (local.get $2)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type27 0
           (local.get $5)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return_call $function100
         (struct.get $type20 1
          (local.get $0)
         )
         (block (result (ref null $type20))
          (local.set $scratch
           (struct.get $type20 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready284)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global284)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function102 (type $call27) (param $0 (ref null $environment102)) (param $1 i64) (result i32)
  (local $2 i32)
  (if (result i32)
   (local.tee $2
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $environment102 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (array.get $type12
       (struct.get $environment102 0
        (local.get $0)
       )
       (local.tee $2
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (array.get $type12
       (struct.get $environment102 1
        (local.get $0)
       )
       (local.get $2)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type92 0
         (struct.get $environment102 2
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function102
       (struct.get $type27 1
        (struct.get $type92 1
         (struct.get $environment102 2
          (local.get $0)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type86))
  (local $2 (ref $type59))
  (local $3 (ref $type63))
  (local $4 (ref $type63))
  (local $5 (ref $type37))
  (local $6 (ref $type22))
  (local $7 (ref $type58))
  (local $8 (ref null $type22))
  (local $9 i64)
  (local $10 i64)
  (local $scratch i64)
  (local $scratch_12 (ref null $type22))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready251)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global251)
   )
  )
  (if
   (i32.eqz
    (global.get $ready238)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global238)
   )
  )
  (local.set $3
   (struct.new $type63
    (call $foreign0
     (i32.const 3)
    )
   )
  )
  (local.set $4
   (struct.new $type63
    (call $foreign0
     (i32.const 4)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (struct.get $type63 0
      (local.get $3)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type86 1
   (local.tee $1
    (struct.new_default $type86)
   )
   (struct.new $type85
    (struct.new $environment85
     (local.get $3)
     (local.get $4)
     (struct.new $type84
      (array.new $type37
       (array.new_fixed $type33 0)
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type86 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type86 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function90
     (call $function80
      (call $function85
       (struct.get $type85 0
        (struct.get $type86 1
         (local.get $1)
        )
       )
       (i64.const 0)
      )
      (call $foreign0
       (i32.const 0)
      )
      (call $foreign0
       (i32.const 1)
      )
      (block (result i64)
       (local.set $scratch
        (call $foreign0
         (i32.const 2)
        )
       )
       (if
        (i32.eqz
         (global.get $ready224)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global224)
        )
       )
       (local.get $scratch)
      )
     )
     (block (result (ref null $type22))
      (if
       (i32.eqz
        (global.get $ready247)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global247)
       )
      )
      (local.set $0
       (call $foreign2)
      )
      (struct.set $type59 1
       (local.tee $2
        (struct.new_default $type59)
       )
       (struct.new $type58
        (ref.func $function88)
        (struct.new $environment88
         (local.get $2)
        )
       )
      )
      (struct.set $type59 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type59 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $scratch_12
       (call_ref $call58
        (struct.get $type58 1
         (local.tee $7
          (ref.as_non_null
           (struct.get $type59 1
            (local.get $2)
           )
          )
         )
        )
        (local.get $0)
        (ref.null none)
        (struct.get $type58 0
         (local.get $7)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready253)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global253)
       )
      )
      (local.get $scratch_12)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $export1 (param $0 i64) (result i64)
  (local $1 (ref $type12))
  (local $2 (ref $type12))
  (local $3 (ref $type45))
  (local $4 (ref $type20))
  (local $5 (ref null $type20))
  (local $6 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready260)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global260)
   )
  )
  (if
   (i32.eqz
    (global.get $ready262)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global262)
   )
  )
  (if
   (i32.eqz
    (global.get $ready265)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (if
   (i32.eqz
    (global.get $ready267)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global267)
   )
  )
  (local.set $1
   (call $function95
    (struct.new $type16
     (i64.const 4)
     (struct.new $type16
      (i64.const 1)
      (struct.new $type16
       (i64.const 3)
       (struct.new $type16
        (i64.const 2)
        (ref.null none)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready265)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (if
   (i32.eqz
    (global.get $ready267)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global267)
   )
  )
  (local.set $2
   (call $function95
    (struct.new $type16
     (i64.const 0)
     (struct.new $type16
      (i64.const 5)
      (struct.new $type16
       (i64.const 7)
       (struct.new $type16
        (i64.const 6)
        (ref.null none)
       )
      )
     )
    )
   )
  )
  (local.set $3
   (if (result (ref $type45))
    (i64.eqz
     (local.get $0)
    )
    (then
     (if
      (i32.eqz
       (global.get $ready216)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global216)
      )
     )
     (struct.new $type48
      (i32.const 2)
      (struct.new $type20
       (local.get $1)
       (struct.new $type20
        (local.get $2)
        (ref.null none)
       )
      )
     )
    )
    (else
     (if (result (ref $type45))
      (i64.eq
       (local.get $0)
       (i64.const 1)
      )
      (then
       (struct.new_default $type46)
      )
      (else
       (if (result (ref $type45))
        (i64.eq
         (local.get $0)
         (i64.const 2)
        )
        (then
         (struct.new $type47
          (i32.const 1)
         )
        )
        (else
         (if (result (ref $type48))
          (i64.eq
           (local.get $0)
           (i64.const 3)
          )
          (then
           (struct.new $type48
            (i32.const 2)
            (ref.null none)
           )
          )
          (else
           (if (result (ref $type48))
            (i64.eq
             (local.get $0)
             (i64.const 4)
            )
            (then
             (if
              (i32.eqz
               (global.get $ready216)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global216)
              )
             )
             (struct.new $type48
              (i32.const 2)
              (struct.new $type20
               (local.get $1)
               (struct.new $type20
                (local.get $2)
                (struct.new $type20
                 (local.get $1)
                 (ref.null none)
                )
               )
              )
             )
            )
            (else
             (if (result (ref $type48))
              (i64.eq
               (local.get $0)
               (i64.const 5)
              )
              (then
               (if
                (i32.eqz
                 (global.get $ready265)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global265)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready267)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global267)
                )
               )
               (local.set $1
                (call $function95
                 (struct.new $type16
                  (i64.const 4)
                  (struct.new $type16
                   (i64.const 1)
                   (struct.new $type16
                    (i64.const 3)
                    (ref.null none)
                   )
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready216)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global216)
                )
               )
               (struct.new $type48
                (i32.const 2)
                (struct.new $type20
                 (local.get $1)
                 (struct.new $type20
                  (local.get $2)
                  (ref.null none)
                 )
                )
               )
              )
              (else
               (if (result (ref $type48))
                (i64.eq
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (if
                  (i32.eqz
                   (global.get $ready265)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global265)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready267)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global267)
                  )
                 )
                 (local.set $2
                  (call $function95
                   (struct.new $type16
                    (i64.const 0)
                    (struct.new $type16
                     (i64.const 5)
                     (struct.new $type16
                      (i64.const 7)
                      (struct.new $type16
                       (i64.const 6)
                       (struct.new_default $type16)
                      )
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready216)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global216)
                  )
                 )
                 (struct.new $type48
                  (i32.const 2)
                  (struct.new $type20
                   (local.get $1)
                   (struct.new $type20
                    (local.get $2)
                    (ref.null none)
                   )
                  )
                 )
                )
                (else
                 (if (result (ref $type48))
                  (i64.eq
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (if
                    (i32.eqz
                     (global.get $ready265)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global265)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready267)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global267)
                    )
                   )
                   (local.set $1
                    (call $function95
                     (struct.new $type16
                      (i64.const 5)
                      (struct.new $type16
                       (i64.const 1)
                       (struct.new $type16
                        (i64.const 3)
                        (struct.new $type16
                         (i64.const 2)
                         (ref.null none)
                        )
                       )
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready216)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global216)
                    )
                   )
                   (struct.new $type48
                    (i32.const 2)
                    (struct.new $type20
                     (local.get $1)
                     (struct.new $type20
                      (local.get $2)
                      (ref.null none)
                     )
                    )
                   )
                  )
                  (else
                   (if (result (ref $type48))
                    (i64.eq
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready265)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global265)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready267)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global267)
                      )
                     )
                     (local.set $1
                      (call $function95
                       (struct.new $type16
                        (i64.const 4)
                        (struct.new $type16
                         (i64.const 1)
                         (struct.new $type16
                          (i64.const 4)
                          (struct.new $type16
                           (i64.const 2)
                           (ref.null none)
                          )
                         )
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready216)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global216)
                      )
                     )
                     (struct.new $type48
                      (i32.const 2)
                      (struct.new $type20
                       (local.get $1)
                       (struct.new $type20
                        (local.get $2)
                        (ref.null none)
                       )
                      )
                     )
                    )
                    (else
                     (if (result (ref $type48))
                      (i64.eq
                       (local.get $0)
                       (i64.const 9)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready265)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global265)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready267)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global267)
                        )
                       )
                       (local.set $2
                        (call $function95
                         (struct.new $type16
                          (i64.const 0)
                          (struct.new $type16
                           (i64.const 5)
                           (struct.new $type16
                            (i64.const 7)
                            (struct.new $type16
                             (i64.const 5)
                             (ref.null none)
                            )
                           )
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready216)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global216)
                        )
                       )
                       (struct.new $type48
                        (i32.const 2)
                        (struct.new $type20
                         (local.get $1)
                         (struct.new $type20
                          (local.get $2)
                          (ref.null none)
                         )
                        )
                       )
                      )
                      (else
                       (if (result (ref $type48))
                        (i64.eq
                         (local.get $0)
                         (i64.const 10)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready216)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global216)
                          )
                         )
                         (struct.new $type48
                          (i32.const 2)
                          (struct.new $type20
                           (local.get $2)
                           (struct.new $type20
                            (local.get $1)
                            (ref.null none)
                           )
                          )
                         )
                        )
                        (else
                         (unreachable)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready265)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (if
   (i32.eqz
    (global.get $ready267)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global267)
   )
  )
  (local.set $4
   (struct.new $type20
    (call $function95
     (struct.new $type16
      (i64.const 4)
      (struct.new $type16
       (i64.const 1)
       (struct.new $type16
        (i64.const 3)
        (struct.new $type16
         (i64.const 2)
         (ref.null none)
        )
       )
      )
     )
    )
    (block (result (ref (exact $type20)))
     (if
      (i32.eqz
       (global.get $ready265)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global265)
      )
     )
     (if
      (i32.eqz
       (global.get $ready267)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global267)
      )
     )
     (struct.new $type20
      (call $function95
       (struct.new $type16
        (i64.const 0)
        (struct.new $type16
         (i64.const 5)
         (struct.new $type16
          (i64.const 7)
          (struct.new $type16
           (i64.const 6)
           (ref.null none)
          )
         )
        )
       )
      )
      (block (result nullref)
       (if
        (i32.eqz
         (global.get $ready216)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global216)
        )
       )
       (if
        (i32.eqz
         (global.get $ready279)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global279)
        )
       )
       (ref.null none)
      )
     )
    )
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (local.tee $6
      (struct.get $type45 0
       (local.get $3)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $6)
        (i32.const 1)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $function100
         (struct.get $type48 1
          (ref.cast (ref $type48)
           (local.get $3)
          )
         )
         (block (result (ref $type20))
          (if
           (i32.eqz
            (global.get $ready284)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global284)
           )
          )
          (local.get $4)
         )
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $ready55
   (i32.const 1)
  )
  (global.set $global58
   (struct.new_default $type8)
  )
  (global.set $ready58
   (i32.const 1)
  )
  (global.set $global133
   (struct.new $type11
    (ref.func $function48)
    (ref.null none)
   )
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global141
   (struct.new $type13
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global265
   (struct.new_default $type15)
  )
  (global.set $ready265
   (i32.const 1)
  )
  (global.set $global267
   (struct.new_default $type17)
  )
  (global.set $ready267
   (i32.const 1)
  )
  (global.set $global270
   (struct.new_default $type18)
  )
  (global.set $ready270
   (i32.const 1)
  )
  (global.set $global102
   (struct.new_default $type19)
  )
  (global.set $ready102
   (i32.const 1)
  )
  (global.set $global230
   (struct.new_default $type21)
  )
  (global.set $ready230
   (i32.const 1)
  )
  (global.set $global216
   (struct.new_default $type23)
  )
  (global.set $ready216
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type24)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global63
   (struct.new_default $type24)
  )
  (global.set $ready63
   (i32.const 1)
  )
  (global.set $global65
   (struct.new_default $type25)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global69
   (struct.new_default $type26)
  )
  (global.set $ready69
   (i32.const 1)
  )
  (global.set $global74
   (struct.new $type27
    (ref.func $function29)
    (ref.null none)
   )
  )
  (global.set $ready74
   (i32.const 1)
  )
  (global.set $global76
   (struct.new_default $type28)
  )
  (global.set $ready76
   (i32.const 1)
  )
  (global.set $global187
   (struct.new_default $type28)
  )
  (global.set $ready187
   (i32.const 1)
  )
  (global.set $global203
   (struct.new $type27
    (ref.func $function72)
    (ref.null none)
   )
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type24)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global80
   (struct.new_default $type29)
  )
  (global.set $ready80
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type30)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type31)
  )
  (global.set $ready235
   (i32.const 1)
  )
  (global.set $global85
   (struct.new_default $type32)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global91
   (struct.new_default $type34)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global97
   (struct.new_default $type35)
  )
  (global.set $ready97
   (i32.const 1)
  )
  (global.set $global107
   (struct.new_default $type36)
  )
  (global.set $ready107
   (i32.const 1)
  )
  (global.set $global256
   (struct.new_default $type38)
  )
  (global.set $ready256
   (i32.const 1)
  )
  (global.set $global253
   (struct.new_default $type39)
  )
  (global.set $ready253
   (i32.const 1)
  )
  (global.set $global125
   (struct.new_default $type40)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type40)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global158
   (struct.new_default $type41)
  )
  (global.set $ready158
   (i32.const 1)
  )
  (global.set $global113
   (struct.new_default $type42)
  )
  (global.set $ready113
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type43)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type44)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global219
   (struct.new_default $type49)
  )
  (global.set $ready219
   (i32.const 1)
  )
  (global.set $global224
   (struct.new_default $type50)
  )
  (global.set $ready224
   (i32.const 1)
  )
  (global.set $global238
   (struct.new_default $type51)
  )
  (global.set $ready238
   (i32.const 1)
  )
  (global.set $global247
   (struct.new_default $type52)
  )
  (global.set $ready247
   (i32.const 1)
  )
  (global.set $global251
   (struct.new_default $type53)
  )
  (global.set $ready251
   (i32.const 1)
  )
  (global.set $global287
   (struct.new_default $type54)
  )
  (global.set $ready287
   (i32.const 1)
  )
  (global.set $global284
   (struct.new_default $type55)
  )
  (global.set $ready284
   (i32.const 1)
  )
  (global.set $global279
   (struct.new_default $type56)
  )
  (global.set $ready279
   (i32.const 1)
  )
  (global.set $global262
   (struct.new_default $type57)
  )
  (global.set $ready262
   (i32.const 1)
  )
  (global.set $global260
   (struct.new_default $type53)
  )
  (global.set $ready260
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

