(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-simplex-review-preparation-20261013/simplex/chez-output-probe-original/program.scm" "/tmp/snail-strict-simplex-review-preparation-20261013/simplex/chez-output-probe-original/program.so"))
