(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-simplex-review-preparation-20261013/simplex/program.scm" "/tmp/snail-strict-simplex-review-preparation-20261013/simplex/program.so"))
