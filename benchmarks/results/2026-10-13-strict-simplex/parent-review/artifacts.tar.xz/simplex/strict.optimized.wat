(module
 (rec
  (type $type39 (sub (struct (field i32))))
  (type $environment90 (struct (field (ref $type12)) (field (ref $type12)) (field (ref $type83))))
  (type $type83 (struct (field (mut i32)) (field (mut (ref null $type30)))))
  (type $call37 (func (param (ref null $type26) (ref null $type26)) (result i32)))
  (type $call74 (func (param (ref $environment81) (ref null $type16) i64) (result (ref $type17))))
  (type $call76 (func (param (ref $environment80) (ref null $type16) i64) (result i64)))
  (type $type74 (struct (field (ref $environment81))))
  (type $type73 (struct (field (ref $type17))))
  (type $type76 (struct (field (ref $environment80))))
  (type $type75 (struct (field (mut i32)) (field (mut (ref null $type74)))))
  (type $type77 (struct (field (mut i32)) (field (mut (ref null $type76)))))
  (type $environment80 (struct (field (ref $type77))))
  (type $environment81 (struct (field (ref $type73)) (field (ref $type75))))
  (type $call15 (func (param (ref $type16)) (result (ref $type17))))
  (type $type71 (struct (field (ref $environment74))))
  (type $type72 (struct (field (mut i32)) (field (mut (ref null $type71)))))
  (type $type40 (sub $type39 (struct (field i32))))
  (type $type62 (struct))
  (type $type79 (struct (field (ref $environment86))))
  (type $type78 (struct (field (ref $type20))))
  (type $type81 (struct (field (ref $environment85))))
  (type $type16 (struct (field f64) (field (ref null $type16))))
  (type $environment74 (struct (field i64) (field (ref $type72))))
  (type $type80 (struct (field (mut i32)) (field (mut (ref null $type79)))))
  (type $type82 (struct (field (mut i32)) (field (mut (ref null $type81)))))
  (type $environment85 (struct (field (ref $type82))))
  (type $environment86 (struct (field (ref $type78)) (field (ref $type80))))
  (type $call71 (func (param (ref $environment74) i64 (ref $type39)) (result (ref $type39))))
  (type $type42 (sub $type39 (struct (field i32) (field (ref $type26)))))
  (type $type63 (struct (field (ref $environment71))))
  (type $type64 (struct (field (mut i32)) (field (mut (ref null $type63)))))
  (type $type41 (sub $type39 (struct (field i32))))
  (type $environment71 (struct (field (ref $type20)) (field (ref $type56)) (field (ref $type50)) (field (ref $type50)) (field (ref $type51)) (field (ref $type51)) (field (ref $type53)) (field (ref $type51)) (field (ref $type51)) (field (ref $type53)) (field (ref $type53)) (field (ref $type58)) (field (ref $type64))))
  (type $call63 (func (param (ref $environment71)) (result (ref $type39))))
  (type $environment69 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type53)) (field (ref $type67))))
  (type $environment68 (struct (field (ref $type51)) (field (ref $type53)) (field (ref $type67))))
  (type $environment65 (struct (field (ref $type20)) (field (ref $type50)) (field i64) (field (ref $type67))))
  (type $environment64 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type50)) (field (ref $type57)) (field (ref $type67))))
  (type $type10 (struct (field (ref $environment62))))
  (type $type65 (struct (field (mut i32)) (field (mut (ref null $type10)))))
  (type $environment70 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type53)) (field (ref $type67))))
  (type $environment67 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type51)) (field (ref $type53)) (field (ref $type53)) (field (ref $type67))))
  (type $environment63 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type50)) (field (ref $type50)) (field (ref $type51)) (field (ref $type57)) (field (ref $type53)) (field (ref $type51)) (field (ref $type53)) (field (ref $type53)) (field (ref $type58)) (field (ref $type60)) (field (ref $type62)) (field (ref $type67))))
  (type $environment62 (struct (field (ref $type20)) (field (ref $type56)) (field (ref $type50)) (field (ref $type50)) (field (ref $type50)) (field (ref $type51)) (field (ref $type51)) (field (ref $type57)) (field (ref $type53)) (field (ref $type51)) (field (ref $type51)) (field (ref $type53)) (field (ref $type53)) (field (ref $type58)) (field (ref $type60)) (field (ref $type60)) (field (ref $type62)) (field (ref $type65))))
  (type $call10 (func (param (ref $environment62)) (result i32)))
  (type $call69 (func (param (ref $environment61) i64 f64) (result i32)))
  (type $type69 (struct (field (ref $environment61))))
  (type $environment61 (struct (field (ref $type20)) (field (ref $type50)) (field i64) (field (ref $type70))))
  (type $environment60 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type50)) (field (ref $type67))))
  (type $type70 (struct (field (mut i32)) (field (mut (ref null $type69)))))
  (type $environment59 (struct (field (ref $type57)) (field (ref $type67))))
  (type $environment57 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type50)) (field (ref $type51)) (field (ref $type51)) (field (ref $type67))))
  (type $environment56 (struct (field (ref $type50)) (field (ref $type51)) (field (ref $type51)) (field (ref $type67))))
  (type $environment54 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type53)) (field (ref $type53)) (field i64) (field (ref $type67))))
  (type $environment55 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type53)) (field (ref $type53)) (field (ref $type56)) (field (ref $type67))))
  (type $environment52 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type50)) (field (ref $type53)) (field (ref $type53)) (field i32) (field (ref $type56)) (field (ref $type67))))
  (type $56 (func (param (ref $type20) (ref $type50) (ref $type50) (ref $type53) (ref $type53) i32)))
  (type $environment50 (struct (field (ref $type20)) (field (ref $type50)) (field (ref $type51)) (field (ref $type53)) (field (ref $type53)) (field i64) (field (ref $type58)) (field (ref $type58)) (field (ref $type67))))
  (type $type56 (struct (field f64)))
  (type $environment49 (struct (field (ref $type20)) (field (ref $type56)) (field (ref $type50)) (field (ref $type50)) (field (ref $type51)) (field (ref $type53)) (field (ref $type53)) (field (ref $type58)) (field (ref $type60)) (field (ref $type67))))
  (type $type60 (struct (field (ref $type61))))
  (type $type61 (struct (field (mut i32))))
  (type $62 (func (param (ref $type20) (ref $type56) (ref $type50) (ref $type50) (ref $type51) (ref $type53) (ref $type53)) (result i32)))
  (type $call66 (func (param (ref struct) i64) (result i32)))
  (type $environment47 (struct (field (ref $type20)) (field (ref $type51)) (field (ref $type53)) (field (ref $type53)) (field (ref $type58)) (field i64) (field i32) (field (ref $type67))))
  (type $type59 (struct (field (mut f64))))
  (type $type17 (array (mut f64)))
  (type $type20 (array (mut (ref $type17))))
  (type $type58 (struct (field (ref $type59))))
  (type $type66 (struct (field (ref $call66)) (field (ref struct))))
  (type $type67 (struct (field (mut i32)) (field (mut (ref null $type66)))))
  (type $71 (func (param (ref $type20) (ref $type51) (ref $type53) (ref $type53) (ref $type58) i64 i32) (result i32)))
  (type $environment44 (struct (field i64) (field (ref $type57)) (field (ref $type68))))
  (type $type57 (struct (field (ref $type14))))
  (type $type14 (array (mut i32)))
  (type $type68 (struct (field (mut i32)) (field (mut (ref null $type13)))))
  (type $call13 (func (param (ref null $environment44) i64) (result (ref $type14))))
  (type $environment42 (struct (field i64) (field (ref $type51)) (field (ref $type52))))
  (type $type54 (struct (field (ref $environment36))))
  (type $type55 (struct (field (mut i32)) (field (mut (ref null $type54)))))
  (type $type53 (struct (field (ref $type33))))
  (type $environment36 (struct (field (ref $type53)) (field (ref $type55))))
  (type $call54 (func (param (ref $environment36) i64) (result (ref null $type26))))
  (type $type52 (struct (field (mut i32)) (field (mut (ref null $type11)))))
  (type $type12 (array (mut i64)))
  (type $type51 (struct (field (ref $type12))))
  (type $type50 (struct (field i64)))
  (type $type33 (struct (field (mut i64))))
  (type $environment34 (struct (field (ref $type33)) (field (ref $type50)) (field (ref $type51)) (field (ref $type52))))
  (type $call11 (func (param structref i64) (result (ref $type12))))
  (type $call30 (func (param (ref null $environment90) i64) (result i32)))
  (type $type49 (struct))
  (type $type26 (struct (field (ref $type12)) (field (ref null $type26))))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type0 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct (field (ref $call30)) (field (ref null $environment90))))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type23 (struct))
  (type $type22 (struct))
  (type $type21 (struct))
  (type $type18 (struct))
  (type $type15 (struct))
  (type $type13 (struct (field (ref $call13)) (field (ref null $environment44))))
  (type $type11 (struct (field (ref $call11)) (field structref)))
  (type $type8 (struct))
  (type $type5 (struct))
 )
 (type $122 (func (param i64) (result i64)))
 (type $123 (func (result i64)))
 (type $124 (func (param f64) (result f64)))
 (type $125 (func (param i32) (result f64)))
 (type $126 (func))
 (import "benchmark" "expected_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "expected_length" (func $foreign1 (result i64)))
 (import "benchmark" "hide_f64" (func $foreign2 (param f64) (result f64)))
 (import "benchmark" "input_f64" (func $foreign3 (param i32) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $ready58 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type11)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type13)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global213 (mut (ref null $type15)) (ref.null none))
 (global $ready213 (mut i32) (i32.const 0))
 (global $global226 (mut (ref null $type18)) (ref.null none))
 (global $ready226 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type21)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global228 (mut (ref null $type22)) (ref.null none))
 (global $ready228 (mut i32) (i32.const 0))
 (global $global218 (mut (ref null $type23)) (ref.null none))
 (global $ready218 (mut i32) (i32.const 0))
 (global $global231 (mut (ref null $type24)) (ref.null none))
 (global $ready231 (mut i32) (i32.const 0))
 (global $global198 (mut (ref null $type25)) (ref.null none))
 (global $ready198 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type27)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type27)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type28)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global69 (mut (ref null $type29)) (ref.null none))
 (global $ready69 (mut i32) (i32.const 0))
 (global $global74 (mut (ref null $type30)) (ref.null none))
 (global $ready74 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type31)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type31)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type30)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type27)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global80 (mut (ref null $type32)) (ref.null none))
 (global $ready80 (mut i32) (i32.const 0))
 (global $global83 (mut (ref null $type34)) (ref.null none))
 (global $ready83 (mut i32) (i32.const 0))
 (global $global89 (mut (ref null $type35)) (ref.null none))
 (global $ready89 (mut i32) (i32.const 0))
 (global $global247 (mut (ref null $type36)) (ref.null none))
 (global $ready247 (mut i32) (i32.const 0))
 (global $global244 (mut (ref null $type37)) (ref.null none))
 (global $ready244 (mut i32) (i32.const 0))
 (global $global239 (mut (ref null $type38)) (ref.null none))
 (global $ready239 (mut i32) (i32.const 0))
 (global $global208 (mut (ref null $type0)) (ref.null none))
 (global $ready208 (mut i32) (i32.const 0))
 (global $global102 (mut (ref null $type43)) (ref.null none))
 (global $ready102 (mut i32) (i32.const 0))
 (global $global107 (mut (ref null $type43)) (ref.null none))
 (global $ready107 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type44)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global156 (mut (ref null $type45)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (global $global95 (mut (ref null $type46)) (ref.null none))
 (global $ready95 (mut i32) (i32.const 0))
 (global $global96 (mut (ref null $type47)) (ref.null none))
 (global $ready96 (mut i32) (i32.const 0))
 (global $global211 (mut (ref null $type48)) (ref.null none))
 (global $ready211 (mut i32) (i32.const 0))
 (global $global201 (mut f64) (f64.const 0))
 (global $ready201 (mut i32) (i32.const 0))
 (global $global202 (mut (ref null $type26)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type49)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function29 (type $call30) (param $0 (ref null $environment90)) (param $1 i64) (result i32)
  (i64.gt_s
   (local.get $1)
   (i64.const 0)
  )
 )
 (func $function34 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $environment34))
  (local $3 (ref $type33))
  (local $4 i64)
  (if (result (ref $type12))
   (i64.eq
    (struct.get $type50 0
     (struct.get $environment34 1
      (local.tee $2
       (ref.cast (ref $environment34)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type51 0
     (struct.get $environment34 2
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global80)
     )
    )
    (local.set $4
     (call $foreign0
      (struct.get $type33 0
       (local.tee $3
        (struct.get $environment34 0
         (local.get $2)
        )
       )
      )
     )
    )
    (struct.set $type33 0
     (local.get $3)
     (i64.add
      (struct.get $type33 0
       (local.get $3)
      )
      (i64.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment34 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment34 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function34
     (struct.get $type11 1
      (struct.get $type52 1
       (struct.get $environment34 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function36 (type $call54) (param $0 (ref $environment36)) (param $1 i64) (result (ref null $type26))
  (local $2 (ref $type52))
  (local $3 (ref $type33))
  (local $4 (ref $type50))
  (local $5 (ref $type11))
  (local $6 (ref $type12))
  (local $7 i64)
  (local $scratch i64)
  (if (result (ref null $type26))
   (i64.eqz
    (local.get $1)
   )
   (then
    (if (result nullref)
     (i64.eq
      (struct.get $type33 0
       (struct.get $type53 0
        (struct.get $environment36 0
         (local.get $0)
        )
       )
      )
      (call $foreign1)
     )
     (then
      (ref.null none)
     )
     (else
      (unreachable)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready83)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global83)
     )
    )
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global80)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (struct.get $type50 0
        (local.tee $4
         (struct.new $type50
          (block (result i64)
           (local.set $scratch
            (call $foreign0
             (struct.get $type33 0
              (local.tee $3
               (struct.get $type53 0
                (struct.get $environment36 0
                 (local.get $0)
                )
               )
              )
             )
            )
           )
           (struct.set $type33 0
            (local.get $3)
            (i64.add
             (struct.get $type33 0
              (local.get $3)
             )
             (i64.const 1)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type52 1
     (local.tee $2
      (struct.new_default $type52)
     )
     (struct.new $type11
      (ref.func $function34)
      (struct.new $environment34
       (local.get $3)
       (local.get $4)
       (struct.new $type51
        (array.new_default $type12
         (i32.wrap_i64
          (local.get $7)
         )
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type52 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type26
     (call_ref $call11
      (struct.get $type11 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type52 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type11 0
       (local.get $5)
      )
     )
     (block (result (ref null $type26))
      (if
       (i32.eqz
        (struct.get $type55 0
         (struct.get $environment36 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (call $function36
       (struct.get $type54 0
        (struct.get $type55 1
         (struct.get $environment36 1
          (local.get $0)
         )
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function41 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $type52))
  (local $3 (ref $type11))
  (local $4 i32)
  (if (result (ref $type12))
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (i64.const 4294967295)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type12))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type12 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready55)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type52 1
       (local.tee $2
        (struct.new_default $type52)
       )
       (struct.new $type11
        (ref.func $function42)
        (struct.new $environment42
         (local.get $1)
         (struct.new $type51
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type52 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type52 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call11
       (struct.get $type11 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type52 1
           (local.get $2)
          )
         )
        )
       )
       (i64.const 1)
       (struct.get $type11 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $environment42))
  (if (result (ref $type12))
   (i64.eq
    (struct.get $environment42 0
     (local.tee $2
      (ref.cast (ref $environment42)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type51 0
     (struct.get $environment42 1
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready55)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global55)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment42 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment42 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (struct.get $type11 1
      (struct.get $type52 1
       (struct.get $environment42 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function43 (type $call13) (param $0 (ref null $environment44)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $type68))
  (local $3 (ref $type13))
  (local $4 i32)
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (i64.const 4294967295)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type14))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type14 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready58)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global58)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type68 1
       (local.tee $2
        (struct.new_default $type68)
       )
       (struct.new $type13
        (ref.func $function44)
        (struct.new $environment44
         (local.get $1)
         (struct.new $type57
          (array.new_default $type14
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type68 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type68 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call13
       (struct.get $type13 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type68 1
           (local.get $2)
          )
         )
        )
       )
       (i64.const 1)
       (struct.get $type13 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function44 (type $call13) (param $0 (ref null $environment44)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $type14))
  (if (result (ref $type14))
   (i64.eq
    (struct.get $environment44 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (struct.get $type57 0
     (struct.get $environment44 1
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type14
     (struct.get $type57 0
      (struct.get $environment44 1
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready58)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global58)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment44 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type13 1
      (struct.get $type68 1
       (struct.get $environment44 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function45 (type $71) (param $0 (ref $type20)) (param $1 (ref $type51)) (param $2 (ref $type53)) (param $3 (ref $type53)) (param $4 (ref $type58)) (param $5 i64) (param $6 i32) (result i32)
  (local $7 (ref $type67))
  (local $8 (ref $type66))
  (local $9 i64)
  (struct.set $type33 0
   (struct.get $type53 0
    (local.get $3)
   )
   (array.get $type12
    (struct.get $type51 0
     (local.get $1)
    )
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i64.gt_u
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (struct.get $type33 0
      (struct.get $type53 0
       (local.get $3)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type59 0
   (struct.get $type58 0
    (local.get $4)
   )
   (array.get $type17
    (array.get $type20
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (i32.wrap_i64
     (local.get $9)
    )
   )
  )
  (struct.set $type67 1
   (local.tee $7
    (struct.new_default $type67)
   )
   (struct.new $type66
    (ref.func $function47)
    (struct.new $environment47
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
    )
   )
  )
  (struct.set $type67 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call66
   (struct.get $type66 1
    (local.tee $8
     (ref.as_non_null
      (struct.get $type67 1
       (local.get $7)
      )
     )
    )
   )
   (i64.const 1)
   (struct.get $type66 0
    (local.get $8)
   )
  )
 )
 (func $function47 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment47))
  (local $3 f64)
  (local $4 i64)
  (local $5 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type33 0
     (struct.get $type53 0
      (struct.get $environment47 2
       (ref.cast (ref $environment47)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (f64.gt
      (if (result f64)
       (struct.get $environment47 6
        (local.tee $2
         (ref.cast (ref $environment47)
          (local.get $0)
         )
        )
       )
       (then
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (array.get $type12
          (struct.get $type51 0
           (struct.get $environment47 1
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready135)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global135)
         )
        )
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment47 5
            (local.get $2)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (array.get $type17
          (array.get $type20
           (struct.get $environment47 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready78)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global78)
         )
        )
        (f64.sub
         (if (result f64)
          (f64.eq
           (local.get $3)
           (f64.const 0)
          )
          (then
           (f64.const 0)
          )
          (else
           (if (result f64)
            (f64.lt
             (local.get $3)
             (f64.const 0)
            )
            (then
             (if
              (i32.eqz
               (global.get $ready61)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (f64.sub
              (f64.const -0)
              (local.get $3)
             )
            )
            (else
             (local.get $3)
            )
           )
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready78)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global78)
           )
          )
          (if (result f64)
           (f64.eq
            (local.tee $3
             (struct.get $type59 0
              (struct.get $type58 0
               (struct.get $environment47 4
                (local.get $2)
               )
              )
             )
            )
            (f64.const 0)
           )
           (then
            (f64.const 0)
           )
           (else
            (if (result f64)
             (f64.lt
              (local.get $3)
              (f64.const 0)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready61)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global61)
               )
              )
              (f64.sub
               (f64.const -0)
               (local.get $3)
              )
             )
             (else
              (local.get $3)
             )
            )
           )
          )
         )
        )
       )
       (else
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (array.get $type12
          (struct.get $type51 0
           (struct.get $environment47 1
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready135)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global135)
         )
        )
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment47 5
            (local.get $2)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (f64.sub
         (array.get $type17
          (array.get $type20
           (struct.get $environment47 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (struct.get $type59 0
          (struct.get $type58 0
           (struct.get $environment47 4
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (block (result f64)
       (if
        (i32.eqz
         (global.get $ready76)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global76)
        )
       )
       (f64.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type33 0
       (struct.get $type53 0
        (struct.get $environment47 3
         (local.get $2)
        )
       )
       (array.get $type12
        (struct.get $type51 0
         (struct.get $environment47 1
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type12
        (struct.get $type51 0
         (struct.get $environment47 1
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (struct.get $environment47 5
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type59 0
       (struct.get $type58 0
        (struct.get $environment47 4
         (local.get $2)
        )
       )
       (array.get $type17
        (array.get $type20
         (struct.get $environment47 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment47 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function47
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment47 7
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function49 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment49))
  (local $3 (ref $type67))
  (local $4 (ref $type58))
  (local $5 (ref $type58))
  (local $6 (ref $type66))
  (local $7 i64)
  (local $8 i64)
  (local $9 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type50 0
     (struct.get $environment49 2
      (ref.cast (ref $environment49)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (if (result i32)
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment49 8
         (local.tee $2
          (ref.cast (ref $environment49)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (array.get $type12
         (struct.get $type51 0
          (struct.get $environment49 4
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready135)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global135)
        )
       )
       (if
        (i64.gt_u
         (local.get $7)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment49 6
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (f64.lt
         (array.get $type17
          (array.get $type20
           (struct.get $environment49 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
          (i32.wrap_i64
           (local.get $8)
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready61)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (f64.sub
           (f64.const -0)
           (struct.get $type56 0
            (struct.get $environment49 1
             (local.get $2)
            )
           )
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type51 0
            (struct.get $environment49 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready135)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $9
          (array.get $type17
           (array.get $type20
            (struct.get $environment49 0
             (local.get $2)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
           (i32.const 0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type51 0
            (struct.get $environment49 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready135)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (struct.get $type33 0
             (struct.get $type53 0
              (struct.get $environment49 6
               (local.get $2)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (f64.lt
           (local.tee $9
            (f64.div
             (f64.sub
              (f64.const -0)
              (local.get $9)
             )
             (array.get $type17
              (array.get $type20
               (struct.get $environment49 0
                (local.get $2)
               )
               (i32.wrap_i64
                (local.get $7)
               )
              )
              (i32.wrap_i64
               (local.get $8)
              )
             )
            )
           )
           (struct.get $type59 0
            (struct.get $type58 0
             (struct.get $environment49 7
              (local.get $2)
             )
            )
           )
          )
          (then
           (if
            (i64.gt_u
             (local.get $1)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (struct.set $type33 0
            (struct.get $type53 0
             (struct.get $environment49 5
              (local.get $2)
             )
            )
            (array.get $type12
             (struct.get $type51 0
              (struct.get $environment49 4
               (local.get $2)
              )
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (struct.set $type59 0
            (struct.get $type58 0
             (struct.get $environment49 7
              (local.get $2)
             )
            )
            (local.get $9)
           )
          )
          (else
           (if
            (f64.eq
             (struct.get $type59 0
              (struct.get $type58 0
               (struct.get $environment49 7
                (local.get $2)
               )
              )
             )
             (local.get $9)
            )
            (then
             (struct.set $type67 1
              (local.tee $3
               (struct.new_default $type67)
              )
              (struct.new $type66
               (ref.func $function50)
               (struct.new $environment50
                (struct.get $environment49 0
                 (local.get $2)
                )
                (struct.get $environment49 3
                 (local.get $2)
                )
                (struct.get $environment49 4
                 (local.get $2)
                )
                (struct.get $environment49 5
                 (local.get $2)
                )
                (struct.get $environment49 6
                 (local.get $2)
                )
                (local.get $1)
                (local.tee $4
                 (struct.new $type58
                  (struct.new_default $type59)
                 )
                )
                (local.tee $5
                 (struct.new $type58
                  (struct.new_default $type59)
                 )
                )
                (local.get $3)
               )
              )
             )
             (struct.set $type67 0
              (local.get $3)
              (i32.const 1)
             )
             (if
              (i32.eqz
               (struct.get $type67 0
                (local.get $3)
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (call_ref $call66
               (struct.get $type66 1
                (local.tee $6
                 (ref.as_non_null
                  (struct.get $type67 1
                   (local.get $3)
                  )
                 )
                )
               )
               (i64.const 1)
               (struct.get $type66 0
                (local.get $6)
               )
              )
             )
             (if
              (f64.lt
               (struct.get $type59 0
                (struct.get $type58 0
                 (local.get $5)
                )
               )
               (struct.get $type59 0
                (struct.get $type58 0
                 (local.get $4)
                )
               )
              )
              (then
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (struct.set $type33 0
                (struct.get $type53 0
                 (struct.get $environment49 5
                  (local.get $2)
                 )
                )
                (array.get $type12
                 (struct.get $type51 0
                  (struct.get $environment49 4
                   (local.get $2)
                  )
                 )
                 (i32.wrap_i64
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i32.const 0)
      )
      (else
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (array.get $type12
         (struct.get $type51 0
          (struct.get $environment49 4
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready135)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global135)
        )
       )
       (if
        (i64.gt_u
         (local.get $7)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment49 6
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (f64.lt
         (array.get $type17
          (array.get $type20
           (struct.get $environment49 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
          (i32.wrap_i64
           (local.get $8)
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready61)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (f64.sub
           (f64.const -0)
           (struct.get $type56 0
            (struct.get $environment49 1
             (local.get $2)
            )
           )
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type51 0
            (struct.get $environment49 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready135)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $9
          (array.get $type17
           (array.get $type20
            (struct.get $environment49 0
             (local.get $2)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
           (i32.const 0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type51 0
            (struct.get $environment49 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready135)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (struct.get $type33 0
             (struct.get $type53 0
              (struct.get $environment49 6
               (local.get $2)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type59 0
          (struct.get $type58 0
           (struct.get $environment49 7
            (local.get $2)
           )
          )
          (f64.div
           (f64.sub
            (f64.const -0)
            (local.get $9)
           )
           (array.get $type17
            (array.get $type20
             (struct.get $environment49 0
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $7)
             )
            )
            (i32.wrap_i64
             (local.get $8)
            )
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type33 0
          (struct.get $type53 0
           (struct.get $environment49 5
            (local.get $2)
           )
          )
          (array.get $type12
           (struct.get $type51 0
            (struct.get $environment49 4
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (struct.set $type61 0
          (struct.get $type60 0
           (struct.get $environment49 8
            (local.get $2)
           )
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment49 9
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment49 9
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function50 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment50))
  (local $3 (ref $type59))
  (local $4 i64)
  (local $5 i64)
  (local $6 f64)
  (if (result i32)
   (i64.ge_s
    (struct.get $type50 0
     (struct.get $environment50 1
      (local.tee $2
       (ref.cast (ref $environment50)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $type33 0
        (struct.get $type53 0
         (struct.get $environment50 3
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type17
      (array.get $type20
       (struct.get $environment50 0
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $type33 0
        (struct.get $type53 0
         (struct.get $environment50 3
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type33 0
        (struct.get $type53 0
         (struct.get $environment50 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type59 0
     (struct.get $type58 0
      (struct.get $environment50 6
       (local.get $2)
      )
     )
     (f64.div
      (f64.sub
       (f64.const -0)
       (local.get $6)
      )
      (array.get $type17
       (array.get $type20
        (struct.get $environment50 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment50 5
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $type51 0
       (struct.get $environment50 2
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type17
      (array.get $type20
       (struct.get $environment50 0
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment50 5
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $type51 0
       (struct.get $environment50 2
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type33 0
        (struct.get $type53 0
         (struct.get $environment50 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type59 0
     (local.tee $3
      (struct.get $type58 0
       (struct.get $environment50 7
        (local.get $2)
       )
      )
     )
     (f64.div
      (f64.sub
       (f64.const -0)
       (local.get $6)
      )
      (array.get $type17
       (array.get $type20
        (struct.get $environment50 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if (result i32)
     (f64.eq
      (struct.get $type59 0
       (local.get $3)
      )
      (struct.get $type59 0
       (struct.get $type58 0
        (struct.get $environment50 6
         (local.get $2)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type67 0
         (struct.get $environment50 8
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function50
       (struct.get $type66 1
        (struct.get $type67 1
         (struct.get $environment50 8
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function51 (type $56) (param $0 (ref $type20)) (param $1 (ref $type50)) (param $2 (ref $type50)) (param $3 (ref $type53)) (param $4 (ref $type53)) (param $5 i32)
  (local $6 (ref $type67))
  (local $7 (ref $type66))
  (local $8 (ref $type56))
  (local $9 i64)
  (local $10 i64)
  (local $11 f64)
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (struct.get $type33 0
      (struct.get $type53 0
       (local.get $3)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $10
     (struct.get $type33 0
      (struct.get $type53 0
       (local.get $4)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $11
   (array.get $type17
    (array.get $type20
     (local.get $0)
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (i32.wrap_i64
     (local.get $10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready63)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global63)
   )
  )
  (struct.set $type67 1
   (local.tee $6
    (struct.new_default $type67)
   )
   (struct.new $type66
    (ref.func $function52)
    (struct.new $environment52
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.tee $8
      (struct.new $type56
       (f64.div
        (f64.const 1)
        (local.get $11)
       )
      )
     )
     (local.get $6)
    )
   )
  )
  (struct.set $type67 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call66
    (struct.get $type66 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type67 1
        (local.get $6)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type66 0
     (local.get $7)
    )
   )
  )
  (struct.set $type67 1
   (local.tee $6
    (struct.new_default $type67)
   )
   (struct.new $type66
    (ref.func $function55)
    (struct.new $environment55
     (local.get $0)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $8)
     (local.get $6)
    )
   )
  )
  (struct.set $type67 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call66
    (struct.get $type66 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type67 1
        (local.get $6)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type66 0
     (local.get $7)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (struct.get $type33 0
      (struct.get $type53 0
       (local.get $3)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $10
     (struct.get $type33 0
      (struct.get $type53 0
       (local.get $4)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (array.get $type20
    (local.get $0)
    (i32.wrap_i64
     (local.get $9)
    )
   )
   (i32.wrap_i64
    (local.get $10)
   )
   (struct.get $type56 0
    (local.get $8)
   )
  )
 )
 (func $function52 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment52))
  (local $3 (ref $type67))
  (local $4 (ref $type20))
  (local $5 (ref $type66))
  (local $6 i64)
  (local $7 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type50 0
      (struct.get $environment52 1
       (local.tee $2
        (ref.cast (ref $environment52)
         (local.get $0)
        )
       )
      )
     )
     (select
      (i64.const 2)
      (i64.const 1)
      (struct.get $environment52 5
       (local.get $2)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type33 0
       (struct.get $type53 0
        (struct.get $environment52 3
         (local.get $2)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $6
         (struct.get $type33 0
          (struct.get $type53 0
           (struct.get $environment52 4
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (array.get $type17
        (array.get $type20
         (struct.get $environment52 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready156)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global156)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $6
         (struct.get $type33 0
          (struct.get $type53 0
           (struct.get $environment52 4
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (array.get $type20
        (local.tee $4
         (struct.get $environment52 0
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (f64.mul
        (struct.get $type56 0
         (struct.get $environment52 6
          (local.get $2)
         )
        )
        (local.get $7)
       )
      )
      (struct.set $type67 1
       (local.tee $3
        (struct.new_default $type67)
       )
       (struct.new $type66
        (ref.func $function54)
        (struct.new $environment54
         (local.get $4)
         (struct.get $environment52 2
          (local.get $2)
         )
         (struct.get $environment52 3
          (local.get $2)
         )
         (struct.get $environment52 4
          (local.get $2)
         )
         (local.get $1)
         (local.get $3)
        )
       )
      )
      (struct.set $type67 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type67 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call66
        (struct.get $type66 1
         (local.tee $5
          (ref.as_non_null
           (struct.get $type67 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type66 0
         (local.get $5)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment52 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment52 7
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function54 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment54))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type50 0
      (struct.get $environment54 1
       (ref.cast (ref $environment54)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type33 0
       (struct.get $type53 0
        (struct.get $environment54 3
         (local.tee $2
          (ref.cast (ref $environment54)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $environment54 4
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (array.get $type17
        (array.get $type20
         (struct.get $environment54 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $type33 0
          (struct.get $type53 0
           (struct.get $environment54 2
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (array.get $type17
        (array.get $type20
         (struct.get $environment54 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment54 4
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (struct.get $type33 0
          (struct.get $type53 0
           (struct.get $environment54 3
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (array.get $type17
        (array.get $type20
         (struct.get $environment54 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready156)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global156)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (array.get $type20
        (struct.get $environment54 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (f64.sub
        (local.get $6)
        (f64.mul
         (local.get $7)
         (local.get $8)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment54 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment54 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function55 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment55))
  (local $3 i64)
  (local $4 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type50 0
      (struct.get $environment55 1
       (ref.cast (ref $environment55)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type33 0
       (struct.get $type53 0
        (struct.get $environment55 3
         (local.tee $2
          (ref.cast (ref $environment55)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type33 0
          (struct.get $type53 0
           (struct.get $environment55 2
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type17
        (array.get $type20
         (struct.get $environment55 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready156)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global156)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type33 0
          (struct.get $type53 0
           (struct.get $environment55 2
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (array.get $type20
        (struct.get $environment55 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (f64.mul
        (f64.sub
         (f64.const -0)
         (struct.get $type56 0
          (struct.get $environment55 4
           (local.get $2)
          )
         )
        )
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment55 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment55 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function56 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment56))
  (if (result i32)
   (i64.eq
    (struct.get $type50 0
     (struct.get $environment56 0
      (ref.cast (ref $environment56)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment56)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment56 1
       (local.tee $2
        (ref.cast (ref $environment56)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment56 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment56 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment56 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function57 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment57))
  (local $3 (ref $type20))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type50 0
     (struct.get $environment57 1
      (ref.cast (ref $environment57)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (f64.lt
      (array.get $type17
       (array.get $type20
        (struct.get $environment57 0
         (ref.cast (ref $environment57)
          (local.get $0)
         )
        )
        (block (result i32)
         (if
          (i32.eqz
           (global.get $ready135)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (if
          (i64.gt_u
           (local.tee $4
            (i64.add
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i32.const 0)
      )
      (block (result f64)
       (if
        (i32.eqz
         (global.get $ready169)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global169)
        )
       )
       (f64.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready95)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global95)
       )
      )
      (unreachable)
     )
    )
    (drop
     (ref.cast (ref $environment57)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment57 3
       (local.tee $2
        (ref.cast (ref $environment57)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment57 4
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (struct.get $type50 0
       (struct.get $environment57 2
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment57 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment57 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function59 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment59))
  (drop
   (ref.cast (ref $environment59)
    (local.get $0)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment59)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (struct.get $type57 0
      (struct.get $environment59 0
       (local.tee $2
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment59 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment59 1
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function60 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type70))
  (local $3 (ref $environment60))
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type50 0
      (struct.get $environment60 2
       (ref.cast (ref $environment60)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type70 1
     (local.tee $2
      (struct.new_default $type70)
     )
     (struct.new $type69
      (struct.new $environment61
       (struct.get $environment60 0
        (local.tee $3
         (ref.cast (ref $environment60)
          (local.get $0)
         )
        )
       )
       (struct.get $environment60 1
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type70 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function61
      (struct.get $type69 0
       (struct.get $type70 1
        (local.get $2)
       )
      )
      (i64.const 3)
      (f64.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment60 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function60
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment60 3
        (local.get $3)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function61 (type $call69) (param $0 (ref $environment61)) (param $1 i64) (param $2 f64) (result i32)
  (local $3 i64)
  (local $4 f64)
  (if (result i32)
   (i64.lt_s
    (struct.get $type50 0
     (struct.get $environment61 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i32.eqz
      (global.get $ready156)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global156)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (struct.get $type50 0
         (struct.get $environment61 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (struct.get $environment61 2
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (array.get $type20
      (struct.get $environment61 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (f64.sub
      (f64.const -0)
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (struct.get $environment61 2
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type17
      (array.get $type20
       (struct.get $environment61 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (struct.get $environment61 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function61
     (struct.get $type69 0
      (struct.get $type70 1
       (struct.get $environment61 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (f64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function62 (type $call10) (param $0 (ref $environment62)) (result i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 (ref $type67))
  (local $6 (ref $type66))
  (local $7 (ref $type53))
  (local $8 (ref $type20))
  (local $9 (ref $type58))
  (local $10 (ref $type50))
  (local $11 (ref $type61))
  (drop
   (call $function45
    (struct.get $environment62 0
     (local.get $0)
    )
    (struct.get $environment62 5
     (local.get $0)
    )
    (struct.get $environment62 8
     (local.get $0)
    )
    (struct.get $environment62 12
     (local.get $0)
    )
    (local.tee $9
     (struct.get $environment62 13
      (local.get $0)
     )
    )
    (i64.add
     (struct.get $type50 0
      (struct.get $environment62 3
       (local.get $0)
      )
     )
     (i64.const 1)
    )
    (i32.const 0)
   )
  )
  (drop
   (if (result i32)
    (f64.le
     (struct.get $type59 0
      (struct.get $type58 0
       (local.get $9)
      )
     )
     (struct.get $type56 0
      (struct.get $environment62 1
       (local.get $0)
      )
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready135)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global135)
      )
     )
     (if
      (i64.gt_u
       (local.tee $1
        (i64.add
         (struct.get $type50 0
          (struct.get $environment62 3
           (local.get $0)
          )
         )
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (f64.lt
       (array.get $type17
        (array.get $type20
         (struct.get $environment62 0
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 0)
       )
       (block (result f64)
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (f64.sub
         (f64.const -0)
         (struct.get $type56 0
          (struct.get $environment62 1
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (struct.set $type61 0
        (struct.get $type60 0
         (struct.get $environment62 15
          (local.get $0)
         )
        )
        (i32.const 0)
       )
       (i32.const 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready135)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global135)
        )
       )
       (if
        (i64.gt_u
         (local.tee $1
          (i64.add
           (struct.get $type50 0
            (struct.get $environment62 3
             (local.get $0)
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (f64.ge
         (struct.get $type56 0
          (struct.get $environment62 1
           (local.get $0)
          )
         )
         (array.get $type17
          (array.get $type20
           (local.tee $8
            (struct.get $environment62 0
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 0)
         )
        )
        (then
         (local.set $1
          (struct.get $type50 0
           (local.tee $10
            (struct.get $environment62 2
             (local.get $0)
            )
           )
          )
         )
         (struct.set $type67 1
          (local.tee $5
           (struct.new_default $type67)
          )
          (struct.new $type66
           (ref.func $function63)
           (struct.new $environment63
            (local.get $8)
            (local.get $10)
            (struct.get $environment62 3
             (local.get $0)
            )
            (struct.get $environment62 4
             (local.get $0)
            )
            (struct.get $environment62 5
             (local.get $0)
            )
            (struct.get $environment62 7
             (local.get $0)
            )
            (struct.get $environment62 8
             (local.get $0)
            )
            (struct.get $environment62 9
             (local.get $0)
            )
            (struct.get $environment62 11
             (local.get $0)
            )
            (struct.get $environment62 12
             (local.get $0)
            )
            (struct.get $environment62 13
             (local.get $0)
            )
            (struct.get $environment62 14
             (local.get $0)
            )
            (struct.get $environment62 16
             (local.get $0)
            )
            (local.get $5)
           )
          )
         )
         (struct.set $type67 0
          (local.get $5)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type67 0
            (local.get $5)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call66
          (struct.get $type66 1
           (local.tee $6
            (ref.as_non_null
             (struct.get $type67 1
              (local.get $5)
             )
            )
           )
          )
          (local.get $1)
          (struct.get $type66 0
           (local.get $6)
          )
         )
        )
        (else
         (struct.set $type33 0
          (struct.get $type53 0
           (local.tee $7
            (struct.get $environment62 11
             (local.get $0)
            )
           )
          )
          (i64.const 0)
         )
         (struct.set $type67 1
          (local.tee $5
           (struct.new_default $type67)
          )
          (struct.new $type66
           (ref.func $function49)
           (struct.new $environment49
            (struct.get $environment62 0
             (local.get $0)
            )
            (struct.get $environment62 1
             (local.get $0)
            )
            (struct.get $environment62 3
             (local.get $0)
            )
            (struct.get $environment62 4
             (local.get $0)
            )
            (struct.get $environment62 6
             (local.get $0)
            )
            (local.get $7)
            (struct.get $environment62 12
             (local.get $0)
            )
            (struct.new $type58
             (struct.new_default $type59)
            )
            (struct.new $type60
             (struct.new_default $type61)
            )
            (local.get $5)
           )
          )
         )
         (struct.set $type67 0
          (local.get $5)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type67 0
            (local.get $5)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (call_ref $call66
           (struct.get $type66 1
            (local.tee $6
             (ref.as_non_null
              (struct.get $type67 1
               (local.get $5)
              )
             )
            )
           )
           (i64.const 0)
           (struct.get $type66 0
            (local.get $6)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready185)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (struct.get $type30 1
           (global.get $global185)
          )
         )
         (if
          (i64.eqz
           (struct.get $type33 0
            (struct.get $type53 0
             (struct.get $environment62 11
              (local.get $0)
             )
            )
           )
          )
          (then
           (struct.set $type61 0
            (struct.get $type60 0
             (struct.get $environment62 15
              (local.get $0)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (struct.set $type61 0
            (struct.get $type60 0
             (struct.get $environment62 14
              (local.get $0)
             )
            )
            (i32.const 1)
           )
          )
         )
         (i32.const 0)
        )
       )
      )
     )
    )
    (else
     (struct.set $type33 0
      (struct.get $type53 0
       (local.tee $7
        (struct.get $environment62 11
         (local.get $0)
        )
       )
      )
      (i64.const 0)
     )
     (struct.set $type67 1
      (local.tee $5
       (struct.new_default $type67)
      )
      (struct.new $type66
       (ref.func $function49)
       (struct.new $environment49
        (struct.get $environment62 0
         (local.get $0)
        )
        (struct.get $environment62 1
         (local.get $0)
        )
        (struct.get $environment62 3
         (local.get $0)
        )
        (struct.get $environment62 4
         (local.get $0)
        )
        (struct.get $environment62 6
         (local.get $0)
        )
        (local.get $7)
        (struct.get $environment62 12
         (local.get $0)
        )
        (struct.new $type58
         (struct.new_default $type59)
        )
        (struct.new $type60
         (struct.new_default $type61)
        )
        (local.get $5)
       )
      )
     )
     (struct.set $type67 0
      (local.get $5)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type67 0
        (local.get $5)
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (call_ref $call66
       (struct.get $type66 1
        (local.tee $6
         (ref.as_non_null
          (struct.get $type67 1
           (local.get $5)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type66 0
        (local.get $6)
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready185)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (struct.get $type30 1
       (global.get $global185)
      )
     )
     (if
      (i64.eqz
       (struct.get $type33 0
        (struct.get $type53 0
         (struct.get $environment62 11
          (local.get $0)
         )
        )
       )
      )
      (then
       (struct.set $type61 0
        (struct.get $type60 0
         (struct.get $environment62 15
          (local.get $0)
         )
        )
        (i32.const 0)
       )
      )
      (else
       (struct.set $type61 0
        (struct.get $type60 0
         (struct.get $environment62 14
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
    )
   )
  )
  (if (result i32)
   (struct.get $type61 0
    (local.tee $11
     (struct.get $type60 0
      (struct.get $environment62 14
       (local.get $0)
      )
     )
    )
   )
   (then
    (struct.set $type61 0
     (local.get $11)
     (i32.const 0)
    )
    (call $function51
     (struct.get $environment62 0
      (local.get $0)
     )
     (struct.get $environment62 3
      (local.get $0)
     )
     (struct.get $environment62 4
      (local.get $0)
     )
     (local.tee $7
      (struct.get $environment62 11
       (local.get $0)
      )
     )
     (struct.get $environment62 12
      (local.get $0)
     )
     (i32.const 1)
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.sub
        (struct.get $type33 0
         (struct.get $type53 0
          (local.get $7)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (i64.ge_s
       (array.get $type12
        (struct.get $type51 0
         (struct.get $environment62 9
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (block (result i64)
        (if
         (i32.eqz
          (global.get $ready65)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global65)
         )
        )
        (i64.sub
         (i64.add
          (struct.get $type50 0
           (struct.get $environment62 4
            (local.get $0)
           )
          )
          (struct.get $type50 0
           (struct.get $environment62 2
            (local.get $0)
           )
          )
         )
         (i64.const 1)
        )
       )
      )
      (then
       (struct.set $type67 1
        (local.tee $5
         (struct.new_default $type67)
        )
        (struct.new $type66
         (ref.func $function67)
         (struct.new $environment67
          (struct.get $environment62 0
           (local.get $0)
          )
          (struct.get $environment62 3
           (local.get $0)
          )
          (struct.get $environment62 5
           (local.get $0)
          )
          (struct.get $environment62 8
           (local.get $0)
          )
          (struct.get $environment62 12
           (local.get $0)
          )
          (local.get $5)
         )
        )
       )
       (struct.set $type67 0
        (local.get $5)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type67 0
          (local.get $5)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call66
        (struct.get $type66 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type67 1
            (local.get $5)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type66 0
         (local.get $6)
        )
       )
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.sub
           (struct.get $type33 0
            (struct.get $type53 0
             (struct.get $environment62 11
              (local.get $0)
             )
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (if (result i32)
         (i64.le_s
          (i64.add
           (struct.get $type50 0
            (struct.get $environment62 4
             (local.get $0)
            )
           )
           (i64.const 2)
          )
          (array.get $type12
           (struct.get $type51 0
            (struct.get $environment62 9
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (then
          (if
           (i64.gt_u
            (local.tee $1
             (i64.sub
              (struct.get $type33 0
               (struct.get $type53 0
                (struct.get $environment62 11
                 (local.get $0)
                )
               )
              )
              (i64.const 1)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.tee $1
             (i64.sub
              (array.get $type12
               (struct.get $type51 0
                (struct.get $environment62 9
                 (local.get $0)
                )
               )
               (i32.wrap_i64
                (local.get $1)
               )
              )
              (i64.add
               (struct.get $type50 0
                (struct.get $environment62 4
                 (local.get $0)
                )
               )
               (i64.const 2)
              )
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (array.get $type14
           (struct.get $type57 0
            (struct.get $environment62 7
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (if
          (i64.gt_u
           (local.tee $1
            (i64.sub
             (struct.get $type33 0
              (struct.get $type53 0
               (struct.get $environment62 11
                (local.get $0)
               )
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $1
            (i64.sub
             (array.get $type12
              (struct.get $type51 0
               (struct.get $environment62 9
                (local.get $0)
               )
              )
              (i32.wrap_i64
               (local.get $1)
              )
             )
             (i64.add
              (struct.get $type50 0
               (struct.get $environment62 4
                (local.get $0)
               )
              )
              (i64.const 2)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type14
          (struct.get $type57 0
           (struct.get $environment62 7
            (local.get $0)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
          (i32.const 0)
         )
         (if
          (i32.eqz
           (global.get $ready135)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (if
          (i64.gt_u
           (local.tee $1
            (i64.add
             (struct.get $type50 0
              (struct.get $environment62 3
               (local.get $0)
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $2
            (struct.get $type33 0
             (struct.get $type53 0
              (struct.get $environment62 12
               (local.get $0)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (array.get $type17
           (array.get $type20
            (struct.get $environment62 0
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready156)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global156)
          )
         )
         (if
          (i64.gt_u
           (local.tee $1
            (i64.add
             (struct.get $type50 0
              (struct.get $environment62 3
               (local.get $0)
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $2
            (struct.get $type33 0
             (struct.get $type53 0
              (struct.get $environment62 12
               (local.get $0)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type17
          (array.get $type20
           (local.tee $8
            (struct.get $environment62 0
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.wrap_i64
           (local.get $2)
          )
          (f64.add
           (local.get $4)
           (f64.const 1)
          )
         )
         (struct.set $type67 1
          (local.tee $5
           (struct.new_default $type67)
          )
          (struct.new $type66
           (ref.func $function70)
           (struct.new $environment70
            (local.get $8)
            (struct.get $environment62 3
             (local.get $0)
            )
            (struct.get $environment62 12
             (local.get $0)
            )
            (local.get $5)
           )
          )
         )
         (struct.set $type67 0
          (local.get $5)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type67 0
            (local.get $5)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call66
          (struct.get $type66 1
           (local.tee $6
            (ref.as_non_null
             (struct.get $type67 1
              (local.get $5)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type66 0
           (local.get $6)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.sub
        (struct.get $type33 0
         (struct.get $type53 0
          (struct.get $environment62 12
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (array.get $type12
      (struct.get $type51 0
       (struct.get $environment62 10
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.sub
        (struct.get $type33 0
         (struct.get $type53 0
          (struct.get $environment62 11
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (array.get $type12
      (struct.get $type51 0
       (struct.get $environment62 9
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (i64.sub
        (struct.get $type33 0
         (struct.get $type53 0
          (struct.get $environment62 12
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment62 10
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (local.get $2)
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.sub
        (struct.get $type33 0
         (struct.get $type53 0
          (struct.get $environment62 11
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment62 9
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (struct.get $type65 0
       (struct.get $environment62 17
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (struct.get $type10 0
      (struct.get $type65 1
       (struct.get $environment62 17
        (local.get $0)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function63 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $environment63))
  (local $3 (ref $type67))
  (local $4 (ref $environment63))
  (local $5 (ref $type58))
  (local $6 (ref $type66))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $scratch i64)
  (block $block
   (return
    (if (result i32)
     (i64.ge_s
      (struct.get $type50 0
       (struct.get $environment63 2
        (local.tee $2
         (ref.cast (ref $environment63)
          (local.get $0)
         )
        )
       )
      )
      (local.get $1)
     )
     (then
      (if
       (i64.gt_u
        (local.tee $7
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (br_if $block
       (i64.ne
        (array.get $type12
         (struct.get $type51 0
          (struct.get $environment63 7
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $7)
         )
        )
        (i64.sub
         (i64.add
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment63 8
             (local.get $2)
            )
           )
          )
          (block (result i64)
           (local.set $scratch
            (struct.get $type50 0
             (struct.get $environment63 3
              (local.get $2)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready65)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global65)
            )
           )
           (local.get $scratch)
          )
         )
         (i64.const 1)
        )
       )
      )
      (drop
       (struct.get $environment63 12
        (local.get $2)
       )
      )
      (drop
       (call $function45
        (struct.get $environment63 0
         (local.get $2)
        )
        (struct.get $environment63 4
         (local.get $2)
        )
        (struct.get $environment63 6
         (local.get $2)
        )
        (struct.get $environment63 9
         (local.get $2)
        )
        (local.tee $5
         (struct.get $environment63 10
          (local.get $2)
         )
        )
        (local.get $1)
        (i32.const 1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready76)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global76)
       )
      )
      (br_if $block
       (i32.eqz
        (f64.gt
         (struct.get $type59 0
          (struct.get $type58 0
           (local.get $5)
          )
         )
         (f64.const 0)
        )
       )
      )
      (struct.set $type33 0
       (struct.get $type53 0
        (struct.get $environment63 8
         (local.get $2)
        )
       )
       (local.get $1)
      )
      (struct.set $type61 0
       (struct.get $type60 0
        (struct.get $environment63 11
         (local.get $2)
        )
       )
       (i32.const 1)
      )
      (i32.const 0)
     )
     (else
      (struct.set $type67 1
       (local.tee $3
        (struct.new_default $type67)
       )
       (struct.new $type66
        (ref.func $function64)
        (struct.new $environment64
         (struct.get $environment63 0
          (local.tee $4
           (ref.as_non_null
            (local.get $2)
           )
          )
         )
         (struct.get $environment63 1
          (local.get $4)
         )
         (struct.get $environment63 3
          (local.get $4)
         )
         (struct.get $environment63 5
          (local.get $4)
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type67 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type67 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call66
       (struct.get $type66 1
        (local.tee $6
         (ref.as_non_null
          (struct.get $type67 1
           (local.get $3)
          )
         )
        )
       )
       (i64.const 3)
       (struct.get $type66 0
        (local.get $6)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (struct.get $environment63 13
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function63
   (struct.get $type66 1
    (struct.get $type67 1
     (struct.get $environment63 13
      (local.get $2)
     )
    )
   )
   (i64.add
    (local.get $1)
    (i64.const 1)
   )
  )
 )
 (func $function64 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment64))
  (local $3 (ref $type67))
  (local $4 (ref $type66))
  (local $5 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type50 0
     (struct.get $environment64 1
      (ref.cast (ref $environment64)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $5
       (i64.sub
        (local.get $1)
        (i64.const 3)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (array.get $type14
      (struct.get $type57 0
       (struct.get $environment64 3
        (local.tee $2
         (ref.cast (ref $environment64)
          (local.get $0)
         )
        )
       )
      )
      (i32.wrap_i64
       (local.get $5)
      )
     )
     (then
      (struct.set $type67 1
       (local.tee $3
        (struct.new_default $type67)
       )
       (struct.new $type66
        (ref.func $function65)
        (struct.new $environment65
         (struct.get $environment64 0
          (local.get $2)
         )
         (struct.get $environment64 2
          (local.get $2)
         )
         (local.get $1)
         (local.get $3)
        )
       )
      )
      (struct.set $type67 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type67 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call66
        (struct.get $type66 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type67 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type66 0
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment64 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment64 4
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function65 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment65))
  (local $3 (ref $type20))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type50 0
      (struct.get $environment65 1
       (ref.cast (ref $environment65)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type17
     (array.get $type20
      (struct.get $environment65 0
       (local.tee $2
        (ref.cast (ref $environment65)
         (local.get $0)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready135)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global135)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $environment65 2
           (local.get $2)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type17
         (array.get $type20
          (struct.get $environment65 0
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready156)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global156)
        )
       )
       (if
        (i64.gt_u
         (local.get $4)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (f64.sub
      (f64.const -0)
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment65 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function65
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment65 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function66 (type $call30) (param $0 (ref null $environment90)) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function67 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment67))
  (local $3 (ref $type67))
  (local $4 (ref $type66))
  (local $5 (ref $type53))
  (local $6 (ref $type20))
  (local $7 i64)
  (local $8 f64)
  (if
   (if (result i32)
    (i64.gt_s
     (struct.get $type33 0
      (struct.get $type53 0
       (struct.get $environment67 3
        (local.tee $2
         (ref.cast (ref $environment67)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $1)
    )
    (then
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (struct.get $type33 0
       (struct.get $type53 0
        (struct.get $environment67 4
         (local.get $2)
        )
       )
      )
      (array.get $type12
       (struct.get $type51 0
        (struct.get $environment67 2
         (local.get $2)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment67 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment67 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (struct.set $type33 0
     (struct.get $type53 0
      (local.tee $5
       (struct.get $environment67 3
        (local.get $2)
       )
      )
     )
     (i64.sub
      (struct.get $type33 0
       (struct.get $type53 0
        (local.get $5)
       )
      )
      (i64.const 1)
     )
    )
    (struct.set $type67 1
     (local.tee $3
      (struct.new_default $type67)
     )
     (struct.new $type66
      (ref.func $function68)
      (struct.new $environment68
       (struct.get $environment67 2
        (local.get $2)
       )
       (local.get $5)
       (local.get $3)
      )
     )
    )
    (struct.set $type67 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call66
      (struct.get $type66 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type67 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type66 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (struct.get $type50 0
         (struct.get $environment67 1
          (local.get $2)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (struct.get $type33 0
        (struct.get $type53 0
         (struct.get $environment67 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (array.get $type17
      (array.get $type20
       (struct.get $environment67 0
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready156)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global156)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (struct.get $type50 0
         (struct.get $environment67 1
          (local.get $2)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (struct.get $type33 0
        (struct.get $type53 0
         (struct.get $environment67 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (array.get $type20
      (local.tee $6
       (struct.get $environment67 0
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.wrap_i64
      (local.get $7)
     )
     (f64.add
      (local.get $8)
      (f64.const 1)
     )
    )
    (struct.set $type67 1
     (local.tee $3
      (struct.new_default $type67)
     )
     (struct.new $type66
      (ref.func $function69)
      (struct.new $environment69
       (local.get $6)
       (struct.get $environment67 1
        (local.get $2)
       )
       (struct.get $environment67 4
        (local.get $2)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type67 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call66
     (struct.get $type66 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type67 1
         (local.get $3)
        )
       )
      )
     )
     (i64.const 0)
     (struct.get $type66 0
      (local.get $4)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function68 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment68))
  (local $3 (ref $type12))
  (local $4 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type33 0
     (struct.get $type53 0
      (struct.get $environment68 1
       (ref.cast (ref $environment68)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type12
     (struct.get $type51 0
      (struct.get $environment68 0
       (local.tee $2
        (ref.cast (ref $environment68)
         (local.get $0)
        )
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type12
        (struct.get $type51 0
         (struct.get $environment68 0
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment68 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function68
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment68 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function69 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment69))
  (local $3 (ref $type20))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type50 0
      (struct.get $environment69 1
       (ref.cast (ref $environment69)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type17
     (array.get $type20
      (struct.get $environment69 0
       (local.tee $2
        (ref.cast (ref $environment69)
         (local.get $0)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready135)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global135)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment69 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type17
         (array.get $type20
          (struct.get $environment69 0
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready156)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global156)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment69 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (i32.wrap_i64
      (local.get $4)
     )
     (f64.sub
      (f64.const -0)
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment69 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment69 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function70 (type $call66) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment70))
  (local $3 (ref $type20))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type50 0
      (struct.get $environment70 1
       (ref.cast (ref $environment70)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type17
     (array.get $type20
      (struct.get $environment70 0
       (local.tee $2
        (ref.cast (ref $environment70)
         (local.get $0)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready135)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global135)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment70 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type17
         (array.get $type20
          (struct.get $environment70 0
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready156)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global156)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment70 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (i32.wrap_i64
      (local.get $4)
     )
     (f64.sub
      (f64.const -0)
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment70 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (struct.get $type66 1
      (struct.get $type67 1
       (struct.get $environment70 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $call63) (param $0 (ref $environment71)) (result (ref $type39))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type67))
  (local $5 (ref $type53))
  (local $6 (ref $type66))
  (drop
   (call $function45
    (struct.get $environment71 0
     (local.get $0)
    )
    (struct.get $environment71 4
     (local.get $0)
    )
    (struct.get $environment71 6
     (local.get $0)
    )
    (struct.get $environment71 10
     (local.get $0)
    )
    (struct.get $environment71 11
     (local.get $0)
    )
    (i64.const 0)
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready76)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global76)
   )
  )
  (if (result (ref $type39))
   (f64.gt
    (struct.get $type59 0
     (struct.get $type58 0
      (struct.get $environment71 11
       (local.get $0)
      )
     )
    )
    (f64.const 0)
   )
   (then
    (struct.set $type33 0
     (struct.get $type53 0
      (local.tee $5
       (struct.get $environment71 9
        (local.get $0)
       )
      )
     )
     (i64.const 0)
    )
    (struct.set $type67 1
     (local.tee $4
      (struct.new_default $type67)
     )
     (struct.new $type66
      (ref.func $function49)
      (struct.new $environment49
       (struct.get $environment71 0
        (local.get $0)
       )
       (struct.get $environment71 1
        (local.get $0)
       )
       (struct.get $environment71 2
        (local.get $0)
       )
       (struct.get $environment71 3
        (local.get $0)
       )
       (struct.get $environment71 5
        (local.get $0)
       )
       (local.get $5)
       (struct.get $environment71 10
        (local.get $0)
       )
       (struct.new $type58
        (struct.new_default $type59)
       )
       (struct.new $type60
        (struct.new_default $type61)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type67 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call66
      (struct.get $type66 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type67 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type66 0
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready185)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type30 1
      (global.get $global185)
     )
    )
    (if (result (ref $type41))
     (i64.eqz
      (struct.get $type33 0
       (struct.get $type53 0
        (struct.get $environment71 9
         (local.get $0)
        )
       )
      )
     )
     (then
      (struct.new $type41
       (i32.const 1)
      )
     )
     (else
      (call $function51
       (struct.get $environment71 0
        (local.get $0)
       )
       (struct.get $environment71 2
        (local.get $0)
       )
       (struct.get $environment71 3
        (local.get $0)
       )
       (struct.get $environment71 9
        (local.get $0)
       )
       (local.tee $5
        (struct.get $environment71 10
         (local.get $0)
        )
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.tee $2
         (i64.sub
          (struct.get $type33 0
           (struct.get $type53 0
            (local.get $5)
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (array.get $type12
        (struct.get $type51 0
         (struct.get $environment71 8
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (i64.sub
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment71 9
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (array.get $type12
        (struct.get $type51 0
         (struct.get $environment71 7
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (i64.sub
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment71 10
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $type51 0
        (struct.get $environment71 8
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $3)
       )
       (local.get $1)
      )
      (if
       (i64.gt_u
        (local.tee $1
         (i64.sub
          (struct.get $type33 0
           (struct.get $type53 0
            (struct.get $environment71 9
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $type51 0
        (struct.get $environment71 7
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $2)
      )
      (if
       (i32.eqz
        (struct.get $type64 0
         (struct.get $environment71 12
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function71
       (struct.get $type63 0
        (struct.get $type64 1
         (struct.get $environment71 12
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready198)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global198)
     )
    )
    (struct.new $type42
     (i32.const 2)
     (struct.new $type26
      (struct.get $type51 0
       (struct.get $environment71 7
        (local.get $0)
       )
      )
      (struct.new $type26
       (struct.get $type51 0
        (struct.get $environment71 8
         (local.get $0)
        )
       )
       (ref.null none)
      )
     )
    )
   )
  )
 )
 (func $function74 (type $call71) (param $0 (ref $environment74)) (param $1 i64) (param $2 (ref $type39)) (result (ref $type39))
  (local $3 (ref $type67))
  (local $4 (ref $environment86))
  (local $5 (ref $environment85))
  (local $6 (ref $type50))
  (local $7 (ref $type50))
  (local $8 (ref $type20))
  (local $9 (ref $type66))
  (local $10 (ref $type82))
  (local $11 (ref $type80))
  (local $12 (ref $type65))
  (local $13 (ref $type64))
  (local $14 (ref $type51))
  (local $15 (ref $type51))
  (local $16 (ref $type51))
  (local $17 (ref $type51))
  (local $18 (ref $type17))
  (local $19 (ref $type17))
  (local $20 (ref $type17))
  (local $21 (ref $type17))
  (local $22 (ref $type17))
  (local $23 (ref $type17))
  (local $24 (ref $type57))
  (local $25 (ref $type56))
  (local $26 (ref $type53))
  (local $27 (ref $type53))
  (local $28 (ref $type53))
  (local $29 (ref $type58))
  (local $30 (ref $type60))
  (if (result (ref $type39))
   (i64.gt_s
    (struct.get $environment74 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready201)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready208)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global208)
     )
    )
    (drop
     (call $foreign2
      (global.get $global201)
     )
    )
    (if
     (i32.eqz
      (global.get $ready211)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (if
     (i32.eqz
      (global.get $ready213)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global213)
     )
    )
    (local.set $18
     (call $function77
      (struct.new $type16
       (f64.const 0)
       (struct.new $type16
        (f64.const 1)
        (struct.new $type16
         (f64.const 1)
         (struct.new $type16
          (f64.const 3)
          (struct.new $type16
           (f64.const -0.5)
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready213)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global213)
     )
    )
    (local.set $19
     (call $function77
      (struct.new $type16
       (f64.const 740)
       (struct.new $type16
        (f64.const -1)
        (struct.new $type16
         (f64.const 0)
         (struct.new $type16
          (f64.const -2)
          (struct.new_default $type16)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready213)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global213)
     )
    )
    (local.set $20
     (call $function77
      (struct.new $type16
       (f64.const 0)
       (struct.new $type16
        (f64.const 0)
        (struct.new $type16
         (f64.const -2)
         (struct.new $type16
          (f64.const 0)
          (struct.new $type16
           (f64.const 7)
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready213)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global213)
     )
    )
    (local.set $21
     (call $function77
      (struct.new $type16
       (f64.const 0.5)
       (struct.new $type16
        (f64.const 0)
        (struct.new $type16
         (f64.const -1)
         (struct.new $type16
          (f64.const 1)
          (struct.new $type16
           (f64.const -2)
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready213)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global213)
     )
    )
    (local.set $22
     (call $function77
      (struct.new $type16
       (f64.const 9)
       (struct.new $type16
        (f64.const -1)
        (struct.new $type16
         (f64.const -1)
         (struct.new $type16
          (f64.const -1)
          (struct.new $type16
           (f64.const -1)
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready213)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global213)
     )
    )
    (local.set $23
     (call $function77
      (struct.new $type16
       (f64.const 0)
       (struct.new $type16
        (f64.const 0)
        (struct.new $type16
         (f64.const 0)
         (struct.new $type16
          (f64.const 0)
          (struct.new_default $type16)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready226)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global226)
     )
    )
    (if
     (i32.eqz
      (global.get $ready228)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global228)
     )
    )
    (if
     (i32.eqz
      (global.get $ready231)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global231)
     )
    )
    (struct.set $type82 1
     (local.tee $10
      (struct.new_default $type82)
     )
     (struct.new $type81
      (struct.new $environment85
       (local.get $10)
      )
     )
    )
    (struct.set $type82 0
     (local.get $10)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (local.get $10)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment85 0
        (local.tee $5
         (struct.get $type81 0
          (struct.get $type82 1
           (local.get $10)
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment85 0
        (local.tee $5
         (struct.get $type81 0
          (struct.get $type82 1
           (struct.get $environment85 0
            (local.get $5)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment85 0
        (local.tee $5
         (struct.get $type81 0
          (struct.get $type82 1
           (struct.get $environment85 0
            (local.get $5)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment85 0
        (local.tee $5
         (struct.get $type81 0
          (struct.get $type82 1
           (struct.get $environment85 0
            (local.get $5)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment85 0
        (local.tee $5
         (struct.get $type81 0
          (struct.get $type82 1
           (struct.get $environment85 0
            (local.get $5)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment85 0
        (local.tee $5
         (struct.get $type81 0
          (struct.get $type82 1
           (struct.get $environment85 0
            (local.get $5)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type81 0
      (struct.get $type82 1
       (struct.get $environment85 0
        (local.get $5)
       )
      )
     )
    )
    (struct.set $type80 1
     (local.tee $11
      (struct.new_default $type80)
     )
     (struct.new $type79
      (struct.new $environment86
       (struct.new $type78
        (array.new $type20
         (local.get $18)
         (i32.const 6)
        )
       )
       (local.get $11)
      )
     )
    )
    (struct.set $type80 0
     (local.get $11)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (local.get $11)
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (struct.get $type78 0
      (struct.get $environment86 0
       (local.tee $4
        (struct.get $type79 0
         (struct.get $type80 1
          (local.get $11)
         )
        )
       )
      )
     )
     (i32.const 0)
     (local.get $18)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (struct.get $environment86 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (struct.get $type78 0
      (struct.get $environment86 0
       (local.tee $4
        (struct.get $type79 0
         (struct.get $type80 1
          (struct.get $environment86 1
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (i32.const 1)
     (local.get $19)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (struct.get $environment86 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (struct.get $type78 0
      (struct.get $environment86 0
       (local.tee $4
        (struct.get $type79 0
         (struct.get $type80 1
          (struct.get $environment86 1
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (i32.const 2)
     (local.get $20)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (struct.get $environment86 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (struct.get $type78 0
      (struct.get $environment86 0
       (local.tee $4
        (struct.get $type79 0
         (struct.get $type80 1
          (struct.get $environment86 1
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (i32.const 3)
     (local.get $21)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (struct.get $environment86 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (struct.get $type78 0
      (struct.get $environment86 0
       (local.tee $4
        (struct.get $type79 0
         (struct.get $type80 1
          (struct.get $environment86 1
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (i32.const 4)
     (local.get $22)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (struct.get $environment86 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (struct.get $type78 0
      (struct.get $environment86 0
       (local.tee $4
        (struct.get $type79 0
         (struct.get $type80 1
          (struct.get $environment86 1
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (i32.const 5)
     (local.get $23)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (struct.get $environment86 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type78 0
      (struct.get $environment86 0
       (struct.get $type79 0
        (struct.get $type80 1
         (struct.get $environment86 1
          (local.get $4)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready96)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global96)
     )
    )
    (if
     (i32.eqz
      (global.get $ready102)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global102)
     )
    )
    (if
     (i32.eqz
      (global.get $ready69)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global69)
     )
    )
    (if
     (i64.ne
      (i64.extend_i32_u
       (array.len
        (local.get $8)
       )
      )
      (i64.const 6)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready95)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global95)
       )
      )
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready65)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global65)
     )
    )
    (if
     (i32.eqz
      (global.get $ready102)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global102)
     )
    )
    (if
     (i32.eqz
      (global.get $ready107)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global107)
     )
    )
    (local.set $6
     (struct.new $type50
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (array.get $type20
          (local.get $8)
          (i32.const 0)
         )
        )
       )
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (local.set $14
     (struct.new $type51
      (call $function41
       (struct.get $type11 1
        (global.get $global110)
       )
       (struct.get $type50 0
        (local.get $6)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (local.set $15
     (struct.new $type51
      (call $function41
       (struct.get $type11 1
        (global.get $global110)
       )
       (struct.get $type50 0
        (local.tee $7
         (struct.new $type50
          (i64.sub
           (i64.extend_i32_u
            (array.len
             (local.get $8)
            )
           )
           (i64.const 2)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (local.set $24
     (struct.new $type57
      (call $function43
       (struct.get $type13 1
        (global.get $global118)
       )
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (local.set $16
     (struct.new $type51
      (call $function41
       (struct.get $type11 1
        (global.get $global110)
       )
       (struct.get $type50 0
        (local.get $7)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type67 1
     (local.tee $3
      (struct.new_default $type67)
     )
     (struct.new $type66
      (ref.func $function56)
      (struct.new $environment56
       (local.get $6)
       (local.get $14)
       (local.tee $17
        (struct.new $type51
         (call $function41
          (struct.get $type11 1
           (global.get $global110)
          )
          (struct.get $type50 0
           (local.get $6)
          )
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type67 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call66
      (struct.get $type66 1
       (local.tee $9
        (ref.as_non_null
         (struct.get $type67 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type66 0
       (local.get $9)
      )
     )
    )
    (struct.set $type67 1
     (local.tee $3
      (struct.new_default $type67)
     )
     (struct.new $type66
      (ref.func $function57)
      (struct.new $environment57
       (local.get $8)
       (local.get $7)
       (local.get $6)
       (local.get $15)
       (local.get $16)
       (local.get $3)
      )
     )
    )
    (struct.set $type67 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call66
      (struct.get $type66 1
       (local.tee $9
        (ref.as_non_null
         (struct.get $type67 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type66 0
       (local.get $9)
      )
     )
    )
    (struct.set $type67 1
     (local.tee $3
      (struct.new_default $type67)
     )
     (struct.new $type66
      (ref.func $function59)
      (struct.new $environment59
       (local.get $24)
       (local.get $3)
      )
     )
    )
    (struct.set $type67 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call66
      (struct.get $type66 1
       (local.tee $9
        (ref.as_non_null
         (struct.get $type67 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type66 0
       (local.get $9)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready74)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type30 1
      (global.get $global74)
     )
    )
    (struct.set $type67 1
     (local.tee $3
      (struct.new_default $type67)
     )
     (struct.new $type66
      (ref.func $function60)
      (struct.new $environment60
       (local.get $8)
       (local.get $7)
       (local.get $6)
       (local.get $3)
      )
     )
    )
    (struct.set $type67 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call66
      (struct.get $type66 1
       (local.tee $9
        (ref.as_non_null
         (struct.get $type67 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type66 0
       (local.get $9)
      )
     )
    )
    (struct.set $type65 1
     (local.tee $12
      (struct.new_default $type65)
     )
     (struct.new $type10
      (struct.new $environment62
       (local.get $8)
       (local.tee $25
        (struct.new $type56
         (f64.const 1e-06)
        )
       )
       (struct.new $type50
        (i64.const 4)
       )
       (local.get $7)
       (local.get $6)
       (local.get $14)
       (local.get $15)
       (local.get $24)
       (local.tee $26
        (struct.new $type53
         (struct.new $type33
          (struct.get $type50 0
           (local.get $6)
          )
         )
        )
       )
       (local.get $16)
       (local.get $17)
       (local.tee $27
        (struct.new $type53
         (struct.new_default $type33)
        )
       )
       (local.tee $28
        (struct.new $type53
         (struct.new_default $type33)
        )
       )
       (local.tee $29
        (struct.new $type58
         (struct.new_default $type59)
        )
       )
       (struct.new $type60
        (struct.new_default $type61)
       )
       (local.tee $30
        (struct.new $type60
         (struct.new $type61
          (i32.const 1)
         )
        )
       )
       (struct.new_default $type62)
       (local.get $12)
      )
     )
    )
    (struct.set $type65 0
     (local.get $12)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type65 0
       (local.get $12)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function62
      (struct.get $type10 0
       (struct.get $type65 1
        (local.get $12)
       )
      )
     )
    )
    (local.set $2
     (if (result (ref $type39))
      (struct.get $type61 0
       (struct.get $type60 0
        (local.get $30)
       )
      )
      (then
       (struct.set $type64 1
        (local.tee $13
         (struct.new_default $type64)
        )
        (struct.new $type63
         (struct.new $environment71
          (local.get $8)
          (local.get $25)
          (local.get $7)
          (local.get $6)
          (local.get $14)
          (local.get $15)
          (local.get $26)
          (local.get $16)
          (local.get $17)
          (local.get $27)
          (local.get $28)
          (local.get $29)
          (local.get $13)
         )
        )
       )
       (struct.set $type64 0
        (local.get $13)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type64 0
          (local.get $13)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function71
        (struct.get $type63 0
         (struct.get $type64 1
          (local.get $13)
         )
        )
       )
      )
      (else
       (struct.new_default $type40)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type72 0
       (struct.get $environment74 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (struct.get $type71 0
      (struct.get $type72 1
       (struct.get $environment74 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function77 (type $call15) (param $0 (ref $type16)) (result (ref $type17))
  (local $1 (ref null $type16))
  (local $2 (ref $environment81))
  (local $3 (ref $environment80))
  (local $4 (ref $type77))
  (local $5 (ref $type75))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready215)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (if
   (i32.eqz
    (global.get $ready218)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global218)
   )
  )
  (struct.set $type77 1
   (local.tee $4
    (struct.new_default $type77)
   )
   (struct.new $type76
    (struct.new $environment80
     (local.get $4)
    )
   )
  )
  (struct.set $type77 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (struct.get $environment80 0
      (local.tee $3
       (struct.get $type76 0
        (struct.get $type77 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type76 0
    (struct.get $type77 1
     (struct.get $environment80 0
      (local.get $3)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $6
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type16 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type16 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type77 0
          (struct.get $environment80 0
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type76 0
         (struct.get $type77 1
          (struct.get $environment80 0
           (local.get $3)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type16 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type77 0
            (struct.get $environment80 0
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $3
          (struct.get $type76 0
           (struct.get $type77 1
            (struct.get $environment80 0
             (local.get $3)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type16 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type77 0
              (struct.get $environment80 0
               (local.get $3)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (struct.get $type76 0
             (struct.get $type77 1
              (struct.get $environment80 0
               (local.get $3)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type16 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type77 0
                (struct.get $environment80 0
                 (local.get $3)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $3
              (struct.get $type76 0
               (struct.get $type77 1
                (struct.get $environment80 0
                 (local.get $3)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type16 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type77 0
                  (struct.get $environment80 0
                   (local.get $3)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $3
                (struct.get $type76 0
                 (struct.get $type77 1
                  (struct.get $environment80 0
                   (local.get $3)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type16 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type77 0
                    (struct.get $environment80 0
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $3
                  (struct.get $type76 0
                   (struct.get $type77 1
                    (struct.get $environment80 0
                     (local.get $3)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type16 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type77 0
                      (struct.get $environment80 0
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $3
                    (struct.get $type76 0
                     (struct.get $type77 1
                      (struct.get $environment80 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type16 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type77 0
                        (struct.get $environment80 0
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $3
                      (struct.get $type76 0
                       (struct.get $type77 1
                        (struct.get $environment80 0
                         (local.get $3)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (local.set $1
                        (struct.get $type16 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type77 0
                          (struct.get $environment80 0
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $3
                        (struct.get $type76 0
                         (struct.get $type77 1
                          (struct.get $environment80 0
                           (local.get $3)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (local.set $1
                          (struct.get $type16 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type77 0
                            (struct.get $environment80 0
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $3
                          (struct.get $type76 0
                           (struct.get $type77 1
                            (struct.get $environment80 0
                             (local.get $3)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (local.set $1
                            (struct.get $type16 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type77 0
                              (struct.get $environment80 0
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $3
                            (struct.get $type76 0
                             (struct.get $type77 1
                              (struct.get $environment80 0
                               (local.get $3)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (local.set $1
                              (struct.get $type16 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type77 0
                                (struct.get $environment80 0
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $3
                              (struct.get $type76 0
                               (struct.get $type77 1
                                (struct.get $environment80 0
                                 (local.get $3)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (local.set $1
                                (struct.get $type16 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type77 0
                                  (struct.get $environment80 0
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $3
                                (struct.get $type76 0
                                 (struct.get $type77 1
                                  (struct.get $environment80 0
                                   (local.get $3)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (i64.const 14)
                                )
                                (else
                                 (local.set $1
                                  (struct.get $type16 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type77 0
                                    (struct.get $environment80 0
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (local.set $3
                                  (struct.get $type76 0
                                   (struct.get $type77 1
                                    (struct.get $environment80 0
                                     (local.get $3)
                                    )
                                   )
                                  )
                                 )
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (i64.const 15)
                                  )
                                  (else
                                   (local.set $1
                                    (struct.get $type16 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (struct.get $type77 0
                                      (struct.get $environment80 0
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (local.set $3
                                    (struct.get $type76 0
                                     (struct.get $type77 1
                                      (struct.get $environment80 0
                                       (local.get $3)
                                      )
                                     )
                                    )
                                   )
                                   (if (result i64)
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                    (then
                                     (i64.const 16)
                                    )
                                    (else
                                     (local.set $1
                                      (struct.get $type16 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (struct.get $type77 0
                                        (struct.get $environment80 0
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (local.set $3
                                      (struct.get $type76 0
                                       (struct.get $type77 1
                                        (struct.get $environment80 0
                                         (local.get $3)
                                        )
                                       )
                                      )
                                     )
                                     (if (result i64)
                                      (ref.is_null
                                       (local.get $1)
                                      )
                                      (then
                                       (i64.const 17)
                                      )
                                      (else
                                       (local.set $1
                                        (struct.get $type16 1
                                         (local.get $1)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (struct.get $type77 0
                                          (struct.get $environment80 0
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (local.set $3
                                        (struct.get $type76 0
                                         (struct.get $type77 1
                                          (struct.get $environment80 0
                                           (local.get $3)
                                          )
                                         )
                                        )
                                       )
                                       (if (result i64)
                                        (ref.is_null
                                         (local.get $1)
                                        )
                                        (then
                                         (i64.const 18)
                                        )
                                        (else
                                         (local.set $1
                                          (struct.get $type16 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (struct.get $type77 0
                                            (struct.get $environment80 0
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (call $function80
                                          (struct.get $type76 0
                                           (struct.get $type77 1
                                            (struct.get $environment80 0
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (local.get $1)
                                          (i64.const 19)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type75 1
   (local.tee $5
    (struct.new_default $type75)
   )
   (struct.new $type74
    (struct.new $environment81
     (struct.new $type73
      (array.new $type17
       (struct.get $type16 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type75 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type75 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (struct.get $type73 0
    (struct.get $environment81 0
     (local.tee $2
      (struct.get $type74 0
       (struct.get $type75 1
        (local.get $5)
       )
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type16 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type75 0
     (struct.get $environment81 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type74 0
    (struct.get $type75 1
     (struct.get $environment81 1
      (local.get $2)
     )
    )
   )
  )
  (if (result (ref $type17))
   (ref.is_null
    (local.tee $1
     (struct.get $type16 1
      (local.get $0)
     )
    )
   )
   (then
    (struct.get $type73 0
     (struct.get $environment81 0
      (local.get $2)
     )
    )
   )
   (else
    (array.set $type17
     (struct.get $type73 0
      (struct.get $environment81 0
       (local.get $2)
      )
     )
     (i32.const 1)
     (struct.get $type16 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type16 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (struct.get $environment81 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type74 0
      (struct.get $type75 1
       (struct.get $environment81 1
        (local.get $2)
       )
      )
     )
    )
    (if (result (ref $type17))
     (ref.is_null
      (local.get $1)
     )
     (then
      (struct.get $type73 0
       (struct.get $environment81 0
        (local.get $2)
       )
      )
     )
     (else
      (array.set $type17
       (struct.get $type73 0
        (struct.get $environment81 0
         (local.get $2)
        )
       )
       (i32.const 2)
       (struct.get $type16 0
        (local.get $1)
       )
      )
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type75 0
         (struct.get $environment81 1
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type74 0
        (struct.get $type75 1
         (struct.get $environment81 1
          (local.get $2)
         )
        )
       )
      )
      (if (result (ref $type17))
       (ref.is_null
        (local.get $1)
       )
       (then
        (struct.get $type73 0
         (struct.get $environment81 0
          (local.get $2)
         )
        )
       )
       (else
        (array.set $type17
         (struct.get $type73 0
          (struct.get $environment81 0
           (local.get $2)
          )
         )
         (i32.const 3)
         (struct.get $type16 0
          (local.get $1)
         )
        )
        (local.set $1
         (struct.get $type16 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type75 0
           (struct.get $environment81 1
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type74 0
          (struct.get $type75 1
           (struct.get $environment81 1
            (local.get $2)
           )
          )
         )
        )
        (if (result (ref $type17))
         (ref.is_null
          (local.get $1)
         )
         (then
          (struct.get $type73 0
           (struct.get $environment81 0
            (local.get $2)
           )
          )
         )
         (else
          (array.set $type17
           (struct.get $type73 0
            (struct.get $environment81 0
             (local.get $2)
            )
           )
           (i32.const 4)
           (struct.get $type16 0
            (local.get $1)
           )
          )
          (local.set $1
           (struct.get $type16 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type75 0
             (struct.get $environment81 1
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type74 0
            (struct.get $type75 1
             (struct.get $environment81 1
              (local.get $2)
             )
            )
           )
          )
          (if (result (ref $type17))
           (ref.is_null
            (local.get $1)
           )
           (then
            (struct.get $type73 0
             (struct.get $environment81 0
              (local.get $2)
             )
            )
           )
           (else
            (array.set $type17
             (struct.get $type73 0
              (struct.get $environment81 0
               (local.get $2)
              )
             )
             (i32.const 5)
             (struct.get $type16 0
              (local.get $1)
             )
            )
            (local.set $1
             (struct.get $type16 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type75 0
               (struct.get $environment81 1
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type74 0
              (struct.get $type75 1
               (struct.get $environment81 1
                (local.get $2)
               )
              )
             )
            )
            (if (result (ref $type17))
             (ref.is_null
              (local.get $1)
             )
             (then
              (struct.get $type73 0
               (struct.get $environment81 0
                (local.get $2)
               )
              )
             )
             (else
              (array.set $type17
               (struct.get $type73 0
                (struct.get $environment81 0
                 (local.get $2)
                )
               )
               (i32.const 6)
               (struct.get $type16 0
                (local.get $1)
               )
              )
              (local.set $1
               (struct.get $type16 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type75 0
                 (struct.get $environment81 1
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type74 0
                (struct.get $type75 1
                 (struct.get $environment81 1
                  (local.get $2)
                 )
                )
               )
              )
              (if (result (ref $type17))
               (ref.is_null
                (local.get $1)
               )
               (then
                (struct.get $type73 0
                 (struct.get $environment81 0
                  (local.get $2)
                 )
                )
               )
               (else
                (array.set $type17
                 (struct.get $type73 0
                  (struct.get $environment81 0
                   (local.get $2)
                  )
                 )
                 (i32.const 7)
                 (struct.get $type16 0
                  (local.get $1)
                 )
                )
                (local.set $1
                 (struct.get $type16 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type75 0
                   (struct.get $environment81 1
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type74 0
                  (struct.get $type75 1
                   (struct.get $environment81 1
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result (ref $type17))
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (struct.get $type73 0
                   (struct.get $environment81 0
                    (local.get $2)
                   )
                  )
                 )
                 (else
                  (array.set $type17
                   (struct.get $type73 0
                    (struct.get $environment81 0
                     (local.get $2)
                    )
                   )
                   (i32.const 8)
                   (struct.get $type16 0
                    (local.get $1)
                   )
                  )
                  (local.set $1
                   (struct.get $type16 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type75 0
                     (struct.get $environment81 1
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type74 0
                    (struct.get $type75 1
                     (struct.get $environment81 1
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result (ref $type17))
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (struct.get $type73 0
                     (struct.get $environment81 0
                      (local.get $2)
                     )
                    )
                   )
                   (else
                    (array.set $type17
                     (struct.get $type73 0
                      (struct.get $environment81 0
                       (local.get $2)
                      )
                     )
                     (i32.const 9)
                     (struct.get $type16 0
                      (local.get $1)
                     )
                    )
                    (local.set $1
                     (struct.get $type16 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type75 0
                       (struct.get $environment81 1
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $2
                     (struct.get $type74 0
                      (struct.get $type75 1
                       (struct.get $environment81 1
                        (local.get $2)
                       )
                      )
                     )
                    )
                    (if (result (ref $type17))
                     (ref.is_null
                      (local.get $1)
                     )
                     (then
                      (struct.get $type73 0
                       (struct.get $environment81 0
                        (local.get $2)
                       )
                      )
                     )
                     (else
                      (array.set $type17
                       (struct.get $type73 0
                        (struct.get $environment81 0
                         (local.get $2)
                        )
                       )
                       (i32.const 10)
                       (struct.get $type16 0
                        (local.get $1)
                       )
                      )
                      (local.set $1
                       (struct.get $type16 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type75 0
                         (struct.get $environment81 1
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $2
                       (struct.get $type74 0
                        (struct.get $type75 1
                         (struct.get $environment81 1
                          (local.get $2)
                         )
                        )
                       )
                      )
                      (if (result (ref $type17))
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (struct.get $type73 0
                         (struct.get $environment81 0
                          (local.get $2)
                         )
                        )
                       )
                       (else
                        (array.set $type17
                         (struct.get $type73 0
                          (struct.get $environment81 0
                           (local.get $2)
                          )
                         )
                         (i32.const 11)
                         (struct.get $type16 0
                          (local.get $1)
                         )
                        )
                        (local.set $1
                         (struct.get $type16 1
                          (local.get $1)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type75 0
                           (struct.get $environment81 1
                            (local.get $2)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $2
                         (struct.get $type74 0
                          (struct.get $type75 1
                           (struct.get $environment81 1
                            (local.get $2)
                           )
                          )
                         )
                        )
                        (if (result (ref $type17))
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (struct.get $type73 0
                           (struct.get $environment81 0
                            (local.get $2)
                           )
                          )
                         )
                         (else
                          (array.set $type17
                           (struct.get $type73 0
                            (struct.get $environment81 0
                             (local.get $2)
                            )
                           )
                           (i32.const 12)
                           (struct.get $type16 0
                            (local.get $1)
                           )
                          )
                          (local.set $1
                           (struct.get $type16 1
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type75 0
                             (struct.get $environment81 1
                              (local.get $2)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $2
                           (struct.get $type74 0
                            (struct.get $type75 1
                             (struct.get $environment81 1
                              (local.get $2)
                             )
                            )
                           )
                          )
                          (if (result (ref $type17))
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (struct.get $type73 0
                             (struct.get $environment81 0
                              (local.get $2)
                             )
                            )
                           )
                           (else
                            (array.set $type17
                             (struct.get $type73 0
                              (struct.get $environment81 0
                               (local.get $2)
                              )
                             )
                             (i32.const 13)
                             (struct.get $type16 0
                              (local.get $1)
                             )
                            )
                            (local.set $1
                             (struct.get $type16 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type75 0
                               (struct.get $environment81 1
                                (local.get $2)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (local.set $2
                             (struct.get $type74 0
                              (struct.get $type75 1
                               (struct.get $environment81 1
                                (local.get $2)
                               )
                              )
                             )
                            )
                            (if (result (ref $type17))
                             (ref.is_null
                              (local.get $1)
                             )
                             (then
                              (struct.get $type73 0
                               (struct.get $environment81 0
                                (local.get $2)
                               )
                              )
                             )
                             (else
                              (array.set $type17
                               (struct.get $type73 0
                                (struct.get $environment81 0
                                 (local.get $2)
                                )
                               )
                               (i32.const 14)
                               (struct.get $type16 0
                                (local.get $1)
                               )
                              )
                              (local.set $1
                               (struct.get $type16 1
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type75 0
                                 (struct.get $environment81 1
                                  (local.get $2)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (return_call $function81
                               (struct.get $type74 0
                                (struct.get $type75 1
                                 (struct.get $environment81 1
                                  (local.get $2)
                                 )
                                )
                               )
                               (local.get $1)
                               (i64.const 15)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function80 (type $call76) (param $0 (ref $environment80)) (param $1 (ref null $type16)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type77 0
         (struct.get $environment80 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function80
       (struct.get $type76 0
        (struct.get $type77 1
         (struct.get $environment80 0
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function81 (type $call74) (param $0 (ref $environment81)) (param $1 (ref null $type16)) (param $2 i64) (result (ref $type17))
  (local $3 f64)
  (if (result (ref $type17))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type73 0
     (struct.get $environment81 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type16 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type73 0
      (struct.get $environment81 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type16 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (struct.get $environment81 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (struct.get $type74 0
      (struct.get $type75 1
       (struct.get $environment81 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function88 (type $call37) (param $0 (ref null $type26)) (param $1 (ref null $type26)) (result i32)
  (local $2 (ref $type83))
  (local $3 (ref $type12))
  (local $4 (ref $type12))
  (local $5 (ref $type30))
  (local $scratch (ref null $type26))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $3
       (struct.get $type26 0
        (local.get $0)
       )
      )
      (local.set $4
       (struct.get $type26 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready247)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global247)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
        )
        (then
         (struct.set $type83 1
          (local.tee $2
           (struct.new_default $type83)
          )
          (struct.new $type30
           (ref.func $function90)
           (struct.new $environment90
            (local.get $3)
            (local.get $4)
            (local.get $2)
           )
          )
         )
         (struct.set $type83 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type83 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call30
          (struct.get $type30 1
           (local.tee $5
            (ref.as_non_null
             (struct.get $type83 1
              (local.get $2)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type30 0
           (local.get $5)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return_call $function88
         (struct.get $type26 1
          (local.get $0)
         )
         (block (result (ref null $type26))
          (local.set $scratch
           (struct.get $type26 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready244)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global244)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function90 (type $call30) (param $0 (ref null $environment90)) (param $1 i64) (result i32)
  (local $2 i32)
  (if (result i32)
   (local.tee $2
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $environment90 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (array.get $type12
       (struct.get $environment90 0
        (local.get $0)
       )
       (local.tee $2
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (array.get $type12
       (struct.get $environment90 1
        (local.get $0)
       )
       (local.get $2)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type83 0
         (struct.get $environment90 2
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function90
       (struct.get $type30 1
        (struct.get $type83 1
         (struct.get $environment90 2
          (local.get $0)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type72))
  (local $2 (ref $type39))
  (local $3 (ref $type26))
  (local $4 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready203)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global203)
   )
  )
  (struct.set $type72 1
   (local.tee $1
    (struct.new_default $type72)
   )
   (struct.new $type71
    (struct.new $environment74
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type72 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type72 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function74
    (struct.get $type71 0
     (struct.get $type72 1
      (local.get $1)
     )
    )
    (i64.const 0)
    (struct.new_default $type40)
   )
  )
  (if
   (i32.eqz
    (global.get $ready202)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready239)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global239)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (local.tee $4
      (struct.get $type39 0
       (local.get $2)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $4)
        (i32.const 1)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $function88
         (struct.get $type42 1
          (ref.cast (ref $type42)
           (local.get $2)
          )
         )
         (block (result (ref null $type26))
          (if
           (i32.eqz
            (global.get $ready244)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global244)
           )
          )
          (global.get $global202)
         )
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (local $0 (ref $type55))
  (local $1 (ref $type33))
  (local $2 (ref $type53))
  (local $3 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $ready55
   (i32.const 1)
  )
  (global.set $global58
   (struct.new_default $type8)
  )
  (global.set $ready58
   (i32.const 1)
  )
  (global.set $global110
   (struct.new $type11
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global118
   (struct.new $type13
    (ref.func $function43)
    (ref.null none)
   )
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global213
   (struct.new_default $type15)
  )
  (global.set $ready213
   (i32.const 1)
  )
  (global.set $global226
   (struct.new_default $type18)
  )
  (global.set $ready226
   (i32.const 1)
  )
  (global.set $global215
   (struct.new_default $type21)
  )
  (global.set $ready215
   (i32.const 1)
  )
  (global.set $global228
   (struct.new_default $type22)
  )
  (global.set $ready228
   (i32.const 1)
  )
  (global.set $global218
   (struct.new_default $type23)
  )
  (global.set $ready218
   (i32.const 1)
  )
  (global.set $global231
   (struct.new_default $type24)
  )
  (global.set $ready231
   (i32.const 1)
  )
  (global.set $global198
   (struct.new_default $type25)
  )
  (global.set $ready198
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type27)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global63
   (struct.new_default $type27)
  )
  (global.set $ready63
   (i32.const 1)
  )
  (global.set $global65
   (struct.new_default $type28)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global69
   (struct.new_default $type29)
  )
  (global.set $ready69
   (i32.const 1)
  )
  (global.set $global74
   (struct.new $type30
    (ref.func $function29)
    (ref.null none)
   )
  )
  (global.set $ready74
   (i32.const 1)
  )
  (global.set $global76
   (struct.new_default $type31)
  )
  (global.set $ready76
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type31)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global185
   (struct.new $type30
    (ref.func $function66)
    (ref.null none)
   )
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type27)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global80
   (struct.new_default $type32)
  )
  (global.set $ready80
   (i32.const 1)
  )
  (global.set $global83
   (struct.new_default $type34)
  )
  (global.set $ready83
   (i32.const 1)
  )
  (global.set $global89
   (struct.new_default $type35)
  )
  (global.set $ready89
   (i32.const 1)
  )
  (global.set $global247
   (struct.new_default $type36)
  )
  (global.set $ready247
   (i32.const 1)
  )
  (global.set $global244
   (struct.new_default $type37)
  )
  (global.set $ready244
   (i32.const 1)
  )
  (global.set $global239
   (struct.new_default $type38)
  )
  (global.set $ready239
   (i32.const 1)
  )
  (global.set $global208
   (struct.new_default $type0)
  )
  (global.set $ready208
   (i32.const 1)
  )
  (global.set $global102
   (struct.new_default $type43)
  )
  (global.set $ready102
   (i32.const 1)
  )
  (global.set $global107
   (struct.new_default $type43)
  )
  (global.set $ready107
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type44)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global156
   (struct.new_default $type45)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $global95
   (struct.new_default $type46)
  )
  (global.set $ready95
   (i32.const 1)
  )
  (global.set $global96
   (struct.new_default $type47)
  )
  (global.set $ready96
   (i32.const 1)
  )
  (global.set $global211
   (struct.new_default $type48)
  )
  (global.set $ready211
   (i32.const 1)
  )
  (global.set $global201
   (call $foreign3
    (i32.const 0)
   )
  )
  (global.set $ready201
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready89)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global89)
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global80)
   )
  )
  (local.set $3
   (call $foreign0
    (struct.get $type33 0
     (local.tee $1
      (struct.get $type53 0
       (local.tee $2
        (struct.new $type53
         (struct.new_default $type33)
        )
       )
      )
     )
    )
   )
  )
  (struct.set $type33 0
   (local.get $1)
   (i64.add
    (struct.get $type33 0
     (local.get $1)
    )
    (i64.const 1)
   )
  )
  (struct.set $type55 1
   (local.tee $0
    (struct.new_default $type55)
   )
   (struct.new $type54
    (struct.new $environment36
     (local.get $2)
     (local.get $0)
    )
   )
  )
  (struct.set $type55 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type55 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global202
   (call $function36
    (struct.get $type54 0
     (struct.get $type55 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
  )
  (global.set $ready202
   (i32.const 1)
  )
  (global.set $global203
   (struct.new_default $type49)
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

