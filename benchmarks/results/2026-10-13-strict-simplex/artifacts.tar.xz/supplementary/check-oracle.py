"""Small analytical expectations and rejected corruptions of the complete oracle."""

import copy
import json
import sys
from pathlib import Path

prepared, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(prepared))
import simplex_port as port

cases = json.loads((prepared / 'simplex/complete-output-oracles.json').read_text())
bounded = {'bounded-one': '2', 'bounded-two': '8', 'ratio-tie': '2',
           'duplicate-constraint': '2', 'greater-equal': '3', 'equality': '2',
           'zero-equality': '0', 'no-improvement': '0'}
for item in cases:
    label, oracle = item['case']['label'], port.independent_lp(item['case'])
    if label in bounded:
        assert oracle['status'] == 2 and oracle['objective'] == bounded[label]
    if label == 'infeasible':
        assert oracle['status'] == 0
    if label in ('unbounded', 'unbounded-after-pivot'):
        assert oracle['status'] == 1 and oracle['improving_ray']

canonical = cases[-1]
vectors, matrix, trace = port.encoded_payload_positions(canonical['expected'])
mutations = [('wrong-status', 0), ('duplicate-basis-variable', vectors[0][0]),
             ('wrong-tableau', matrix[0]), ('wrong-last-store', len(canonical['expected']) - 1)]
rejections = []
for label, index in mutations:
    values = canonical['expected'].copy()
    values[index] += 1.0
    try:
        port.check_oracle(canonical['case'], values)
    except (ValueError, StopIteration) as error:
        rejections.append(dict(label=label, diagnostic=str(error), rejected=True))
    else:
        raise AssertionError(label + ' was accepted')

decoded = port.decode_probe(canonical['expected'])
decoded['matrix'][0][0] += 1.0
try:
    port.check_solution(canonical['case'], decoded, port.independent_lp(canonical['case']))
except ValueError as error:
    rejections.append(dict(label='independent-objective-comparison', diagnostic=str(error), rejected=True))
else:
    raise AssertionError('wrong objective was accepted')
output.write_text(json.dumps(dict(analytical_cases=11, canonical_optimum='681/40',
    rejected_mutations=rejections, source_discrepancy_preserved=cases[5]['checked']), indent=2) + '\n')
