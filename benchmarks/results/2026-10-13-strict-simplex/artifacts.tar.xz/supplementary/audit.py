"""Describe retained instructions and layouts in the frozen canonical module."""

import collections
import hashlib
import json
import re
import sys
from pathlib import Path

directory, output = map(Path, sys.argv[1:])
optimized = (directory / 'strict.optimized.wat').read_text()
raw = (directory / 'strict.wasm.wat').read_text()
starts = list(re.finditer(r'^ \(func (\$\S+)', optimized, re.M))
functions = {}
for index, match in enumerate(starts):
    end = starts[index + 1].start() if index + 1 < len(starts) else len(optimized)
    body = optimized[match.start():end]
    operations = collections.Counter(re.findall(r'\((array\.[\w_]+|struct\.[\w_]+|f64\.[\w_]+|call|return_call|call_ref|return_call_ref)(?=\s)', body))
    functions[match[1]] = dict(start_line=optimized[:match.start()].count('\n') + 1,
        end_line=optimized[:end].count('\n'), static_instruction_sites=dict(sorted(operations.items())),
        direct_calls=re.findall(r'\((?:call|return_call) (\$\w+)', body),
        referenced_functions=re.findall(r'\(ref.func (\$\w+)', body))

roles = {'$function45': 'simp1 coefficient selection and initialization',
         '$function47': 'remaining coefficient scan',
         '$function48': 'simp2 ratio selection setup',
         '$function49': 'ratio candidate traversal',
         '$function50': 'lexicographic ratio tie traversal',
         '$function51': 'simp3 pivot reciprocal and row-loop setup',
         '$function52': 'pivot elimination outer row traversal',
         '$function54': 'pivot elimination inner column updates',
         '$function55': 'pivot row updates',
         '$function60': 'auxiliary objective construction',
         '$function61': 'auxiliary coefficient sum',
         '$function62': 'phase-one control and basis exchange',
         '$function71': 'phase-two control, basis exchange and complete solved result',
         '$function74': 'repetition, hide call, fresh tableau and simplex setup',
         '$function77': 'typed variadic F64 vector construction',
         '$function81': 'F64 list-to-vector copying loop',
         '$function88': 'complete result-list comparison',
         '$function90': 'complete I64 vector comparison',
         '$export0': 'bench: repeat then check the final result once',
         '$main': 'untimed inputs and expected-value setup'}
for name, role in roles.items():
    functions[name]['inspected_role'] = role

type_roles = {'$type12': 'I64 index array', '$type14': 'Bool flag array',
              '$type17': 'F64 row array', '$type20': 'matrix of F64 rows',
              '$type16': 'temporary F64 constructor list', '$type26': 'solved index-vector list',
              '$type33': 'I64 Ref payload', '$type59': 'F64 Ref payload',
              '$type61': 'Bool Ref payload', '$type39': 'result parent',
              '$type40': 'infeasible case', '$type41': 'unbounded case', '$type42': 'solved case'}
layouts = {}


def declaration(text, name):
    start, depth = text.index('(type ' + name + ' '), 0
    for end in range(start, len(text)):
        depth += (text[end] == '(') - (text[end] == ')')
        if depth == 0:
            return text[start:end + 1]
    raise ValueError('unclosed type declaration')


for name, role in type_roles.items():
    layouts[role] = dict(raw=declaration(raw, name), optimized=declaration(optimized, name))

evidence = dict(evidence_kind='Static inspection of the exact canonical optimized Wasm; no dynamic allocation or machine-code claim.',
    compiler_commit='a4030ce190058db3e9d64f6942401b5fa38dbd58',
    hashes={name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
            for name in ('strict.scm', 'strict.wasm.raw.wasm', 'strict.wasm', 'strict.optimized.wat')},
    exports=re.findall(r'\(export "([^"]+)"', optimized), layouts=layouts, functions=functions,
    repetition='function74 tests the runtime count, calls hide_f64, constructs six fresh rows and the matrix, executes both phases, and tail-calls itself with the incremented index and current result.',
    predicate='export0 calls the repeat loop once, then matches its final result and traverses every list/vector element through function88/function90.',
    mutation='Mutable F64 rows, I64 work/result arrays, Bool flags and explicit scalar Ref payloads remain. Pivot arithmetic and array stores remain in both phases.',
    result='function71 retains the nominal solved wrapper, both list nodes, and both mutable I64 vector references; all are observed by the final predicate.',
    representation_cost='The strict variadic vector constructor retains temporary F64 list nodes and copying in function77/function81. Chez native vector construction need not perform this work. Ref binding and closure wrapper shapes are optimized independently.',
    probe_isolation='Canonical exports are bench and main only. Matrix-store observers, full tableau encoding and predicate probes use separate modules.',
    limits='Static sites are not execution counts. This does not establish V8 machine-code allocation, live-heap overlap, equal allocation across systems or Chez optimizer retention.',
    performance_samples=0)
assert evidence['exports'] == ['bench', 'main']
assert all(functions[name]['static_instruction_sites'].get('array.set') for name in ('$function54', '$function55', '$function71'))
assert functions['$function74']['direct_calls'].count('$foreign2') == 1
output.write_text(json.dumps(evidence, indent=2) + '\n')
