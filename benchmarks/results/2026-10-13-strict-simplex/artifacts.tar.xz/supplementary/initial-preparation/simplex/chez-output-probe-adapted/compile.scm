(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-simplex-preparation-20261013/simplex/chez-output-probe-adapted/program.scm" "/tmp/snail-strict-simplex-preparation-20261013/simplex/chez-output-probe-adapted/program.so"))
