(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-simplex-preparation-20261013/simplex/same-source-chez/program.scm" "/tmp/snail-strict-simplex-preparation-20261013/simplex/same-source-chez/program.so"))
