(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-simplex-focused-20261013/final-probes/chez-output-probe-adapted/program.scm" "/tmp/snail-simplex-focused-20261013/final-probes/chez-output-probe-adapted/program.so"))
