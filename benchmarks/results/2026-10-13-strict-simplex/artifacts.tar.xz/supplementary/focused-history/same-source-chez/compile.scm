(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-simplex-focused-20261013/same-source-chez/program.scm" "/tmp/snail-simplex-focused-20261013/same-source-chez/program.so"))
