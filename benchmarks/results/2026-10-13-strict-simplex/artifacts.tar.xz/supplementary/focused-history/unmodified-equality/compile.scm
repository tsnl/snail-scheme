(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-simplex-focused-20261013/unmodified-equality/program.scm" "/tmp/snail-simplex-focused-20261013/unmodified-equality/program.so"))
