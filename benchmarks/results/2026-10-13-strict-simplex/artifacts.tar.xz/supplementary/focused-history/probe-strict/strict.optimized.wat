(module
 (rec
  (type $type41 (sub (struct (field i32))))
  (type $call35 (func (param (ref null $type18) (ref null $type18)) (result i32)))
  (type $environment88 (struct (field (ref $type51))))
  (type $type82 (struct (field (ref $environment85))))
  (type $type83 (struct (field (mut i32)) (field (mut (ref null $type82)))))
  (type $environment86 (struct (field (ref $type57)) (field (ref $type84)) (field i64) (field (ref $type74))))
  (type $type81 (struct (field (ref $type33))))
  (type $environment85 (struct (field (ref $type57)) (field (ref $type81)) (field (ref $type57)) (field (ref $type83))))
  (type $type84 (struct (field i32) (field (ref $type29))))
  (type $call82 (func (param (ref $environment85) i64) (result (ref $type33))))
  (type $10 (func (param (ref null $type18) (ref $type18)) (result (ref null $type18))))
  (type $call79 (func (param (ref $environment82) (ref null $type18) i64) (result i64)))
  (type $type79 (struct (field (ref $environment82))))
  (type $type42 (sub $type41 (struct (field i32))))
  (type $type80 (struct (field (mut i32)) (field (mut (ref null $type79)))))
  (type $environment82 (struct (field (ref $type80))))
  (type $16 (func (param (ref $type33) i64 i64 i64) (result (ref $type18))))
  (type $type44 (sub $type41 (struct (field i32) (field (ref $type16)))))
  (type $type71 (struct (field (ref $environment77))))
  (type $type72 (struct (field (mut i32)) (field (mut (ref null $type71)))))
  (type $type43 (sub $type41 (struct (field i32))))
  (type $environment77 (struct (field (ref $type66)) (field (ref $type62)) (field (ref $type68)) (field (ref $type60)) (field (ref $type69)) (field (ref $type58)) (field (ref $type60)) (field (ref $type58)) (field (ref $type72))))
  (type $call71 (func (param (ref $environment77)) (result (ref $type41))))
  (type $environment75 (struct (field (ref $type57)) (field (ref $type33)) (field (ref $type60)) (field (ref $type74))))
  (type $environment74 (struct (field (ref $type60)) (field (ref $type58)) (field (ref $type74))))
  (type $environment71 (struct (field (ref $type57)) (field (ref $type33)) (field i64) (field (ref $type74))))
  (type $environment70 (struct (field (ref $type57)) (field (ref $type59)) (field i64) (field (ref $type57)) (field (ref $type33)) (field (ref $type74))))
  (type $environment76 (struct (field (ref $type57)) (field (ref $type33)) (field (ref $type60)) (field (ref $type74))))
  (type $environment73 (struct (field (ref $type60)) (field (ref $type60)) (field (ref $type58)) (field (ref $type74)) (field (ref $type33)) (field (ref $type57))))
  (type $type70 (struct (field (ref $environment58))))
  (type $type69 (struct (field (ref $type70))))
  (type $type10 (struct (field (ref $call10)) (field (ref struct))))
  (type $type68 (struct (field (mut i32)) (field (mut (ref null $type10)))))
  (type $environment69 (struct (field (ref $type57)) (field (ref $type58)) (field (ref $type60)) (field (ref $type57)) (field (ref $type66)) (field (ref $type62)) (field (ref $type64)) (field (ref $type74)) (field (ref $type57)) (field (ref $type59)) (field i64) (field (ref $type33))))
  (type $type67 (struct (field (ref $environment52))))
  (type $type66 (struct (field (ref $type67))))
  (type $environment68 (struct (field (ref $type66)) (field (ref $type57)) (field (ref $type62)) (field (ref $type56)) (field (ref $type33)) (field (ref $type64)) (field (ref $type58)) (field (ref $type60)) (field (ref $type57)) (field (ref $type64)) (field (ref $type57)) (field (ref $type59)) (field i64) (field (ref $type68)) (field (ref $type69)) (field (ref $type60)) (field (ref $type60)) (field (ref $type58)) (field (ref $type58)) (field (ref $type68))))
  (type $call77 (func (param (ref $environment67) i64 f64) (result i32)))
  (type $type77 (struct (field (ref $environment67))))
  (type $environment67 (struct (field (ref $type57)) (field (ref $type33)) (field i64) (field (ref $type78))))
  (type $type78 (struct (field (mut i32)) (field (mut (ref null $type77)))))
  (type $environment66 (struct (field (ref $type57)) (field (ref $type57)) (field (ref $type33)) (field i64) (field (ref $type74))))
  (type $environment65 (struct (field i64) (field (ref $type59)) (field (ref $type74))))
  (type $environment63 (struct (field (ref $type57)) (field (ref $type33)) (field (ref $type58)) (field (ref $type58)) (field (ref $type57)) (field (ref $type74))))
  (type $environment62 (struct (field (ref $type57)) (field (ref $type58)) (field (ref $type58)) (field (ref $type74))))
  (type $environment60 (struct (field (ref $type57)) (field (ref $type60)) (field (ref $type33)) (field i64) (field (ref $type60)) (field (ref $type74))))
  (type $environment61 (struct (field (ref $type57)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type56)) (field (ref $type74))))
  (type $environment59 (struct (field (ref $type57)) (field i32) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type56)) (field (ref $type57)) (field (ref $type74))))
  (type $environment58 (struct (field (ref $type33)) (field (ref $type60)) (field (ref $type60)) (field (ref $type57)) (field (ref $type57))))
  (type $call70 (func (param (ref $environment58) i32) (result i32)))
  (type $environment57 (struct (field (ref $type57)) (field (ref $type62)) (field (ref $type33)) (field (ref $type60)) (field (ref $type60)) (field (ref $type62)) (field (ref $type58)) (field i64) (field (ref $type74))))
  (type $type56 (struct (field f64)))
  (type $type57 (struct (field i64)))
  (type $environment56 (struct (field (ref $type57)) (field (ref $type64)) (field (ref $type33)) (field (ref $type58)) (field (ref $type60)) (field (ref $type56)) (field (ref $type62)) (field (ref $type60)) (field (ref $type57)) (field (ref $type74))))
  (type $type65 (struct (field (mut i32))))
  (type $type64 (struct (field i32) (field (ref $type65))))
  (type $environment55 (struct (field (ref $type60)) (field (ref $type57)) (field (ref $type33)) (field (ref $type58)) (field (ref $type60)) (field (ref $type56)) (field (ref $type57))))
  (type $call10 (func (param (ref struct)) (result i32)))
  (type $call73 (func (param (ref struct) i64) (result i32)))
  (type $environment54 (struct (field (ref $type60)) (field i32) (field (ref $type33)) (field i64) (field (ref $type58)) (field (ref $type62)) (field (ref $type60)) (field (ref $type74))))
  (type $type63 (struct (field (mut f64))))
  (type $type61 (struct (field (mut i64))))
  (type $type60 (struct (field (ref $type61))))
  (type $environment52 (struct (field (ref $type60)) (field (ref $type58)) (field (ref $type62)) (field (ref $type33)) (field (ref $type60))))
  (type $type73 (struct (field (ref $call73)) (field (ref struct))))
  (type $type62 (struct (field i32) (field (ref $type63))))
  (type $type74 (struct (field (mut i32)) (field (mut (ref null $type73)))))
  (type $call67 (func (param (ref $environment52) i64 i32) (result i32)))
  (type $environment51 (struct (field i64) (field (ref $type59)) (field (ref $type76))))
  (type $type59 (struct (field (ref $type14))))
  (type $type14 (array (mut i32)))
  (type $type76 (struct (field (mut i32)) (field (mut (ref null $type13)))))
  (type $call13 (func (param (ref null $environment51) i64) (result (ref $type14))))
  (type $environment49 (struct (field i64) (field (ref $type58)) (field (ref $type75))))
  (type $type58 (struct (field (ref $type12))))
  (type $type75 (struct (field (mut i32)) (field (mut (ref null $type11)))))
  (type $call11 (func (param (ref null $environment49) i64) (result (ref $type12))))
  (type $call38 (func (param (ref $type33) i64 i64 f64) (result i32)))
  (type $type33 (array (mut (ref $type29))))
  (type $environment42 (struct (field (ref $type33)) (field (ref $type51))))
  (type $call54 (func (param (ref $environment40) (ref null $type16) i64) (result i64)))
  (type $call53 (func (param (ref $environment38) (ref null $type16)) (result (ref null $type18))))
  (type $type54 (struct (field (ref $environment40))))
  (type $type53 (struct (field (ref $environment38))))
  (type $type55 (struct (field (mut i32)) (field (mut (ref null $type54)))))
  (type $type52 (struct (field (mut i32)) (field (mut (ref null $type53)))))
  (type $environment40 (struct (field (ref $type55))))
  (type $environment38 (struct (field (ref null $type18)) (field (ref $type52))))
  (type $type16 (struct (field (ref $type12)) (field (ref null $type16))))
  (type $89 (func (param (ref $type16) (ref null $type18)) (result (ref $type18))))
  (type $type12 (array (mut i64)))
  (type $environment36 (struct (field (ref $type12)) (field (ref $type51))))
  (type $call30 (func (param (ref $type12) (ref null $type18)) (result (ref null $type18))))
  (type $type50 (struct (field (ref $call50)) (field (ref struct))))
  (type $type51 (struct (field (mut i32)) (field (mut (ref null $type50)))))
  (type $type29 (array (mut f64)))
  (type $type18 (struct (field f64) (field (ref null $type18))))
  (type $environment34 (struct (field (ref $type29)) (field (ref $type51))))
  (type $call50 (func (param (ref struct) i64 (ref null $type18)) (result (ref null $type18))))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (mut (ref null $type18)))))
  (type $type24 (struct))
  (type $type23 (struct))
  (type $type22 (struct))
  (type $type21 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type17 (struct))
  (type $type15 (struct))
  (type $type13 (struct (field (ref $call13)) (field (ref null $environment51))))
  (type $type11 (struct (field (ref $call11)) (field (ref null $environment49))))
  (type $type8 (struct))
  (type $type5 (struct))
 )
 (type $130 (func (param i32) (result i64)))
 (type $131 (func (param i32 i64) (result f64)))
 (type $132 (func (result i64)))
 (type $133 (func (param i64) (result f64)))
 (type $134 (func (param i64) (result i64)))
 (type $135 (func))
 (import "benchmark" "input_i64" (func $foreign0 (param i32) (result i64)))
 (import "benchmark" "vector_f64" (func $foreign1 (param i32 i64) (result f64)))
 (import "benchmark" "expected_length" (func $foreign2 (result i64)))
 (import "benchmark" "expected_f64" (func $foreign3 (param i64) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $ready58 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type11)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type13)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global102 (mut (ref null $type15)) (ref.null none))
 (global $ready102 (mut i32) (i32.const 0))
 (global $global230 (mut (ref null $type17)) (ref.null none))
 (global $ready230 (mut i32) (i32.const 0))
 (global $global216 (mut (ref null $type19)) (ref.null none))
 (global $ready216 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type20)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type20)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type21)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global69 (mut (ref null $type22)) (ref.null none))
 (global $ready69 (mut i32) (i32.const 0))
 (global $global74 (mut (ref null $type23)) (ref.null none))
 (global $ready74 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type24)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global187 (mut (ref null $type24)) (ref.null none))
 (global $ready187 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type23)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type20)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global80 (mut (ref null $type25)) (ref.null none))
 (global $ready80 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type26)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type27)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type28)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type30)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global97 (mut (ref null $type31)) (ref.null none))
 (global $ready97 (mut i32) (i32.const 0))
 (global $global107 (mut (ref null $type32)) (ref.null none))
 (global $ready107 (mut i32) (i32.const 0))
 (global $global256 (mut (ref null $type34)) (ref.null none))
 (global $ready256 (mut i32) (i32.const 0))
 (global $global253 (mut (ref null $type35)) (ref.null none))
 (global $ready253 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type36)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type36)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type37)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type38)) (ref.null none))
 (global $ready113 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type39)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type40)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global219 (mut (ref null $type45)) (ref.null none))
 (global $ready219 (mut i32) (i32.const 0))
 (global $global224 (mut (ref null $type46)) (ref.null none))
 (global $ready224 (mut i32) (i32.const 0))
 (global $global238 (mut (ref null $type47)) (ref.null none))
 (global $ready238 (mut i32) (i32.const 0))
 (global $global247 (mut (ref null $type48)) (ref.null none))
 (global $ready247 (mut i32) (i32.const 0))
 (global $global251 (mut (ref null $type49)) (ref.null none))
 (global $ready251 (mut i32) (i32.const 0))
 (export "simplex-probe" (func $export0))
 (export "main" (func $main))
 (func $function34 (type $call50) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type18)) (result (ref null $type18))
  (local $3 (ref $environment34))
  (local $4 f64)
  (if (result (ref $type18))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type18
     (f64.convert_i64_s
      (i64.extend_i32_u
       (array.len
        (struct.get $environment34 0
         (ref.cast (ref $environment34)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type29
      (struct.get $environment34 0
       (local.tee $3
        (ref.cast (ref $environment34)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment34 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function34
     (struct.get $type50 1
      (struct.get $type51 1
       (struct.get $environment34 1
        (local.get $3)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type18
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function35 (type $call30) (param $0 (ref $type12)) (param $1 (ref null $type18)) (result (ref null $type18))
  (local $2 (ref $type51))
  (local $3 (ref $type50))
  (struct.set $type51 1
   (local.tee $2
    (struct.new_default $type51)
   )
   (struct.new $type50
    (ref.func $function36)
    (struct.new $environment36
     (local.get $0)
     (local.get $2)
    )
   )
  )
  (struct.set $type51 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call50
   (struct.get $type50 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type51 1
       (local.get $2)
      )
     )
    )
   )
   (i64.sub
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (i64.const 1)
   )
   (local.get $1)
   (struct.get $type50 0
    (local.get $3)
   )
  )
 )
 (func $function36 (type $call50) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type18)) (result (ref null $type18))
  (local $3 (ref $environment36))
  (local $4 i64)
  (if (result (ref $type18))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type18
     (f64.convert_i64_s
      (i64.extend_i32_u
       (array.len
        (struct.get $environment36 0
         (ref.cast (ref $environment36)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $environment36 0
       (local.tee $3
        (ref.cast (ref $environment36)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment36 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function36
     (struct.get $type50 1
      (struct.get $type51 1
       (struct.get $environment36 1
        (local.get $3)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type18
      (f64.convert_i64_s
       (local.get $4)
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function37 (type $89) (param $0 (ref $type16)) (param $1 (ref null $type18)) (result (ref $type18))
  (local $2 (ref null $type16))
  (local $3 (ref $type51))
  (local $4 (ref $environment38))
  (local $5 (ref $environment40))
  (local $6 (ref $type50))
  (local $7 (ref $type52))
  (local $8 (ref $type55))
  (local $9 (ref $type12))
  (local $10 (ref $type12))
  (local $11 (ref $type12))
  (local $12 (ref $type12))
  (local $13 (ref $type12))
  (local $14 (ref $type12))
  (local $15 (ref $type12))
  (local $16 (ref $type12))
  (local $17 (ref $type12))
  (local $18 (ref $type12))
  (local $19 (ref $type12))
  (local $20 (ref $type12))
  (local $21 (ref $type12))
  (local $22 (ref $type12))
  (local $23 i64)
  (local $scratch (ref null $type18))
  (local $scratch_25 i64)
  (struct.set $type52 1
   (local.tee $7
    (struct.new_default $type52)
   )
   (struct.new $type53
    (struct.new $environment38
     (local.get $1)
     (local.get $7)
    )
   )
  )
  (struct.set $type52 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready102)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global102)
   )
  )
  (struct.set $type55 1
   (local.tee $8
    (struct.new_default $type55)
   )
   (struct.new $type54
    (struct.new $environment40
     (local.get $8)
    )
   )
  )
  (struct.set $type55 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type55 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type55 0
     (struct.get $environment40 0
      (local.tee $5
       (struct.get $type54 0
        (struct.get $type55 1
         (local.get $8)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type54 0
    (struct.get $type55 1
     (struct.get $environment40 0
      (local.get $5)
     )
    )
   )
  )
  (struct.new $type18
   (f64.convert_i64_s
    (block (result i64)
     (local.set $scratch_25
      (if (result i64)
       (ref.is_null
        (local.tee $2
         (struct.get $type16 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 1)
       )
       (else
        (local.set $2
         (struct.get $type16 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (struct.get $type55 0
           (struct.get $environment40 0
            (local.get $5)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $5
         (struct.get $type54 0
          (struct.get $type55 1
           (struct.get $environment40 0
            (local.get $5)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $2)
         )
         (then
          (i64.const 2)
         )
         (else
          (local.set $2
           (struct.get $type16 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (struct.get $type55 0
             (struct.get $environment40 0
              (local.get $5)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $5
           (struct.get $type54 0
            (struct.get $type55 1
             (struct.get $environment40 0
              (local.get $5)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i64.const 3)
           )
           (else
            (local.set $2
             (struct.get $type16 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (struct.get $type55 0
               (struct.get $environment40 0
                (local.get $5)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $5
             (struct.get $type54 0
              (struct.get $type55 1
               (struct.get $environment40 0
                (local.get $5)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $2)
             )
             (then
              (i64.const 4)
             )
             (else
              (local.set $2
               (struct.get $type16 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type55 0
                 (struct.get $environment40 0
                  (local.get $5)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $5
               (struct.get $type54 0
                (struct.get $type55 1
                 (struct.get $environment40 0
                  (local.get $5)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i64.const 5)
               )
               (else
                (local.set $2
                 (struct.get $type16 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type55 0
                   (struct.get $environment40 0
                    (local.get $5)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $5
                 (struct.get $type54 0
                  (struct.get $type55 1
                   (struct.get $environment40 0
                    (local.get $5)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (i64.const 6)
                 )
                 (else
                  (local.set $2
                   (struct.get $type16 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type55 0
                     (struct.get $environment40 0
                      (local.get $5)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $5
                   (struct.get $type54 0
                    (struct.get $type55 1
                     (struct.get $environment40 0
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i64.const 7)
                   )
                   (else
                    (local.set $2
                     (struct.get $type16 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type55 0
                       (struct.get $environment40 0
                        (local.get $5)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $5
                     (struct.get $type54 0
                      (struct.get $type55 1
                       (struct.get $environment40 0
                        (local.get $5)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (i64.const 8)
                     )
                     (else
                      (local.set $2
                       (struct.get $type16 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type55 0
                         (struct.get $environment40 0
                          (local.get $5)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $5
                       (struct.get $type54 0
                        (struct.get $type55 1
                         (struct.get $environment40 0
                          (local.get $5)
                         )
                        )
                       )
                      )
                      (if (result i64)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i64.const 9)
                       )
                       (else
                        (local.set $2
                         (struct.get $type16 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type55 0
                           (struct.get $environment40 0
                            (local.get $5)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $5
                         (struct.get $type54 0
                          (struct.get $type55 1
                           (struct.get $environment40 0
                            (local.get $5)
                           )
                          )
                         )
                        )
                        (if (result i64)
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (i64.const 10)
                         )
                         (else
                          (local.set $2
                           (struct.get $type16 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type55 0
                             (struct.get $environment40 0
                              (local.get $5)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $5
                           (struct.get $type54 0
                            (struct.get $type55 1
                             (struct.get $environment40 0
                              (local.get $5)
                             )
                            )
                           )
                          )
                          (if (result i64)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i64.const 11)
                           )
                           (else
                            (local.set $2
                             (struct.get $type16 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type55 0
                               (struct.get $environment40 0
                                (local.get $5)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (local.set $5
                             (struct.get $type54 0
                              (struct.get $type55 1
                               (struct.get $environment40 0
                                (local.get $5)
                               )
                              )
                             )
                            )
                            (if (result i64)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (i64.const 12)
                             )
                             (else
                              (local.set $2
                               (struct.get $type16 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type55 0
                                 (struct.get $environment40 0
                                  (local.get $5)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $5
                               (struct.get $type54 0
                                (struct.get $type55 1
                                 (struct.get $environment40 0
                                  (local.get $5)
                                 )
                                )
                               )
                              )
                              (if (result i64)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i64.const 13)
                               )
                               (else
                                (local.set $2
                                 (struct.get $type16 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type55 0
                                   (struct.get $environment40 0
                                    (local.get $5)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $function40
                                 (struct.get $type54 0
                                  (struct.get $type55 1
                                   (struct.get $environment40 0
                                    (local.get $5)
                                   )
                                  )
                                 )
                                 (local.get $2)
                                 (i64.const 14)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (struct.get $type52 0
        (local.get $7)
       )
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (struct.get $type52 0
        (struct.get $environment38 1
         (local.tee $4
          (struct.get $type53 0
           (struct.get $type52 1
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $4
      (struct.get $type53 0
       (struct.get $type52 1
        (struct.get $environment38 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (if (result (ref null $type18))
       (ref.is_null
        (local.tee $2
         (struct.get $type16 1
          (local.get $0)
         )
        )
       )
       (then
        (struct.get $environment38 0
         (local.get $4)
        )
       )
       (else
        (local.set $10
         (struct.get $type16 0
          (local.get $2)
         )
        )
        (local.set $2
         (struct.get $type16 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (struct.get $type52 0
           (struct.get $environment38 1
            (local.get $4)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (struct.get $type53 0
          (struct.get $type52 1
           (struct.get $environment38 1
            (local.get $4)
           )
          )
         )
        )
        (local.set $1
         (if (result (ref null $type18))
          (ref.is_null
           (local.get $2)
          )
          (then
           (struct.get $environment38 0
            (local.get $4)
           )
          )
          (else
           (local.set $11
            (struct.get $type16 0
             (local.get $2)
            )
           )
           (local.set $2
            (struct.get $type16 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (struct.get $type52 0
              (struct.get $environment38 1
               (local.get $4)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.get $type53 0
             (struct.get $type52 1
              (struct.get $environment38 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (if (result (ref null $type18))
             (ref.is_null
              (local.get $2)
             )
             (then
              (struct.get $environment38 0
               (local.get $4)
              )
             )
             (else
              (local.set $12
               (struct.get $type16 0
                (local.get $2)
               )
              )
              (local.set $2
               (struct.get $type16 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type52 0
                 (struct.get $environment38 1
                  (local.get $4)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $4
               (struct.get $type53 0
                (struct.get $type52 1
                 (struct.get $environment38 1
                  (local.get $4)
                 )
                )
               )
              )
              (local.set $1
               (if (result (ref null $type18))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (struct.get $environment38 0
                  (local.get $4)
                 )
                )
                (else
                 (local.set $13
                  (struct.get $type16 0
                   (local.get $2)
                  )
                 )
                 (local.set $2
                  (struct.get $type16 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type52 0
                    (struct.get $environment38 1
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (struct.get $type53 0
                   (struct.get $type52 1
                    (struct.get $environment38 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (if (result (ref null $type18))
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (struct.get $environment38 0
                     (local.get $4)
                    )
                   )
                   (else
                    (local.set $14
                     (struct.get $type16 0
                      (local.get $2)
                     )
                    )
                    (local.set $2
                     (struct.get $type16 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type52 0
                       (struct.get $environment38 1
                        (local.get $4)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $4
                     (struct.get $type53 0
                      (struct.get $type52 1
                       (struct.get $environment38 1
                        (local.get $4)
                       )
                      )
                     )
                    )
                    (local.set $1
                     (if (result (ref null $type18))
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (struct.get $environment38 0
                        (local.get $4)
                       )
                      )
                      (else
                       (local.set $15
                        (struct.get $type16 0
                         (local.get $2)
                        )
                       )
                       (local.set $2
                        (struct.get $type16 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type52 0
                          (struct.get $environment38 1
                           (local.get $4)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $4
                        (struct.get $type53 0
                         (struct.get $type52 1
                          (struct.get $environment38 1
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (local.set $1
                        (if (result (ref null $type18))
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (struct.get $environment38 0
                           (local.get $4)
                          )
                         )
                         (else
                          (local.set $16
                           (struct.get $type16 0
                            (local.get $2)
                           )
                          )
                          (local.set $2
                           (struct.get $type16 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type52 0
                             (struct.get $environment38 1
                              (local.get $4)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $4
                           (struct.get $type53 0
                            (struct.get $type52 1
                             (struct.get $environment38 1
                              (local.get $4)
                             )
                            )
                           )
                          )
                          (local.set $1
                           (if (result (ref null $type18))
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (struct.get $environment38 0
                              (local.get $4)
                             )
                            )
                            (else
                             (local.set $17
                              (struct.get $type16 0
                               (local.get $2)
                              )
                             )
                             (local.set $2
                              (struct.get $type16 1
                               (local.get $2)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type52 0
                                (struct.get $environment38 1
                                 (local.get $4)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $4
                              (struct.get $type53 0
                               (struct.get $type52 1
                                (struct.get $environment38 1
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (local.set $1
                              (if (result (ref null $type18))
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (struct.get $environment38 0
                                 (local.get $4)
                                )
                               )
                               (else
                                (local.set $18
                                 (struct.get $type16 0
                                  (local.get $2)
                                 )
                                )
                                (local.set $2
                                 (struct.get $type16 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type52 0
                                   (struct.get $environment38 1
                                    (local.get $4)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (local.set $4
                                 (struct.get $type53 0
                                  (struct.get $type52 1
                                   (struct.get $environment38 1
                                    (local.get $4)
                                   )
                                  )
                                 )
                                )
                                (local.set $1
                                 (if (result (ref null $type18))
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (struct.get $environment38 0
                                    (local.get $4)
                                   )
                                  )
                                  (else
                                   (local.set $19
                                    (struct.get $type16 0
                                     (local.get $2)
                                    )
                                   )
                                   (local.set $2
                                    (struct.get $type16 1
                                     (local.get $2)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (struct.get $type52 0
                                      (struct.get $environment38 1
                                       (local.get $4)
                                      )
                                     )
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (local.set $4
                                    (struct.get $type53 0
                                     (struct.get $type52 1
                                      (struct.get $environment38 1
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                   (local.set $1
                                    (if (result (ref null $type18))
                                     (ref.is_null
                                      (local.get $2)
                                     )
                                     (then
                                      (struct.get $environment38 0
                                       (local.get $4)
                                      )
                                     )
                                     (else
                                      (local.set $20
                                       (struct.get $type16 0
                                        (local.get $2)
                                       )
                                      )
                                      (local.set $2
                                       (struct.get $type16 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (struct.get $type52 0
                                         (struct.get $environment38 1
                                          (local.get $4)
                                         )
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (local.set $4
                                       (struct.get $type53 0
                                        (struct.get $type52 1
                                         (struct.get $environment38 1
                                          (local.get $4)
                                         )
                                        )
                                       )
                                      )
                                      (local.set $1
                                       (if (result (ref null $type18))
                                        (ref.is_null
                                         (local.get $2)
                                        )
                                        (then
                                         (struct.get $environment38 0
                                          (local.get $4)
                                         )
                                        )
                                        (else
                                         (local.set $21
                                          (struct.get $type16 0
                                           (local.get $2)
                                          )
                                         )
                                         (local.set $2
                                          (struct.get $type16 1
                                           (local.get $2)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (struct.get $type52 0
                                            (struct.get $environment38 1
                                             (local.get $4)
                                            )
                                           )
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (local.set $4
                                          (struct.get $type53 0
                                           (struct.get $type52 1
                                            (struct.get $environment38 1
                                             (local.get $4)
                                            )
                                           )
                                          )
                                         )
                                         (local.set $1
                                          (if (result (ref null $type18))
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (struct.get $environment38 0
                                             (local.get $4)
                                            )
                                           )
                                           (else
                                            (local.set $9
                                             (struct.get $type16 0
                                              (local.get $2)
                                             )
                                            )
                                            (local.set $2
                                             (struct.get $type16 1
                                              (local.get $2)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (struct.get $type52 0
                                               (struct.get $environment38 1
                                                (local.get $4)
                                               )
                                              )
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (local.set $4
                                             (struct.get $type53 0
                                              (struct.get $type52 1
                                               (struct.get $environment38 1
                                                (local.get $4)
                                               )
                                              )
                                             )
                                            )
                                            (local.set $1
                                             (if (result (ref null $type18))
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (struct.get $environment38 0
                                                (local.get $4)
                                               )
                                              )
                                              (else
                                               (call $function35
                                                (struct.get $type16 0
                                                 (local.get $2)
                                                )
                                                (block (result (ref null $type18))
                                                 (local.set $2
                                                  (struct.get $type16 1
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (struct.get $type52 0
                                                    (struct.get $environment38 1
                                                     (local.get $4)
                                                    )
                                                   )
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (local.set $scratch
                                                  (call $function38
                                                   (struct.get $type53 0
                                                    (struct.get $type52 1
                                                     (struct.get $environment38 1
                                                      (local.get $4)
                                                     )
                                                    )
                                                   )
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready91)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global91)
                                                  )
                                                 )
                                                 (local.get $scratch)
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready91)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global91)
                                             )
                                            )
                                            (struct.set $type51 1
                                             (local.tee $3
                                              (struct.new_default $type51)
                                             )
                                             (struct.new $type50
                                              (ref.func $function36)
                                              (struct.new $environment36
                                               (local.get $9)
                                               (local.get $3)
                                              )
                                             )
                                            )
                                            (struct.set $type51 0
                                             (local.get $3)
                                             (i32.const 1)
                                            )
                                            (if
                                             (i32.eqz
                                              (struct.get $type51 0
                                               (local.get $3)
                                              )
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (call_ref $call50
                                             (struct.get $type50 1
                                              (local.tee $6
                                               (ref.as_non_null
                                                (struct.get $type51 1
                                                 (local.get $3)
                                                )
                                               )
                                              )
                                             )
                                             (i64.sub
                                              (i64.extend_i32_u
                                               (array.len
                                                (local.get $9)
                                               )
                                              )
                                              (i64.const 1)
                                             )
                                             (local.get $1)
                                             (struct.get $type50 0
                                              (local.get $6)
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready91)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global91)
                                          )
                                         )
                                         (struct.set $type51 1
                                          (local.tee $3
                                           (struct.new_default $type51)
                                          )
                                          (struct.new $type50
                                           (ref.func $function36)
                                           (struct.new $environment36
                                            (local.get $21)
                                            (local.get $3)
                                           )
                                          )
                                         )
                                         (struct.set $type51 0
                                          (local.get $3)
                                          (i32.const 1)
                                         )
                                         (if
                                          (i32.eqz
                                           (struct.get $type51 0
                                            (local.get $3)
                                           )
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (call_ref $call50
                                          (struct.get $type50 1
                                           (local.tee $6
                                            (ref.as_non_null
                                             (struct.get $type51 1
                                              (local.get $3)
                                             )
                                            )
                                           )
                                          )
                                          (i64.sub
                                           (i64.extend_i32_u
                                            (array.len
                                             (local.get $21)
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (local.get $1)
                                          (struct.get $type50 0
                                           (local.get $6)
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready91)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global91)
                                       )
                                      )
                                      (struct.set $type51 1
                                       (local.tee $3
                                        (struct.new_default $type51)
                                       )
                                       (struct.new $type50
                                        (ref.func $function36)
                                        (struct.new $environment36
                                         (local.get $20)
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (struct.set $type51 0
                                       (local.get $3)
                                       (i32.const 1)
                                      )
                                      (if
                                       (i32.eqz
                                        (struct.get $type51 0
                                         (local.get $3)
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call_ref $call50
                                       (struct.get $type50 1
                                        (local.tee $6
                                         (ref.as_non_null
                                          (struct.get $type51 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                       )
                                       (i64.sub
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $20)
                                         )
                                        )
                                        (i64.const 1)
                                       )
                                       (local.get $1)
                                       (struct.get $type50 0
                                        (local.get $6)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready91)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global91)
                                    )
                                   )
                                   (struct.set $type51 1
                                    (local.tee $3
                                     (struct.new_default $type51)
                                    )
                                    (struct.new $type50
                                     (ref.func $function36)
                                     (struct.new $environment36
                                      (local.get $19)
                                      (local.get $3)
                                     )
                                    )
                                   )
                                   (struct.set $type51 0
                                    (local.get $3)
                                    (i32.const 1)
                                   )
                                   (if
                                    (i32.eqz
                                     (struct.get $type51 0
                                      (local.get $3)
                                     )
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (call_ref $call50
                                    (struct.get $type50 1
                                     (local.tee $6
                                      (ref.as_non_null
                                       (struct.get $type51 1
                                        (local.get $3)
                                       )
                                      )
                                     )
                                    )
                                    (i64.sub
                                     (i64.extend_i32_u
                                      (array.len
                                       (local.get $19)
                                      )
                                     )
                                     (i64.const 1)
                                    )
                                    (local.get $1)
                                    (struct.get $type50 0
                                     (local.get $6)
                                    )
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready91)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global91)
                                 )
                                )
                                (struct.set $type51 1
                                 (local.tee $3
                                  (struct.new_default $type51)
                                 )
                                 (struct.new $type50
                                  (ref.func $function36)
                                  (struct.new $environment36
                                   (local.get $18)
                                   (local.get $3)
                                  )
                                 )
                                )
                                (struct.set $type51 0
                                 (local.get $3)
                                 (i32.const 1)
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type51 0
                                   (local.get $3)
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call_ref $call50
                                 (struct.get $type50 1
                                  (local.tee $6
                                   (ref.as_non_null
                                    (struct.get $type51 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                 )
                                 (i64.sub
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $18)
                                   )
                                  )
                                  (i64.const 1)
                                 )
                                 (local.get $1)
                                 (struct.get $type50 0
                                  (local.get $6)
                                 )
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready91)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global91)
                              )
                             )
                             (struct.set $type51 1
                              (local.tee $3
                               (struct.new_default $type51)
                              )
                              (struct.new $type50
                               (ref.func $function36)
                               (struct.new $environment36
                                (local.get $17)
                                (local.get $3)
                               )
                              )
                             )
                             (struct.set $type51 0
                              (local.get $3)
                              (i32.const 1)
                             )
                             (if
                              (i32.eqz
                               (struct.get $type51 0
                                (local.get $3)
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (call_ref $call50
                              (struct.get $type50 1
                               (local.tee $6
                                (ref.as_non_null
                                 (struct.get $type51 1
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                              (i64.sub
                               (i64.extend_i32_u
                                (array.len
                                 (local.get $17)
                                )
                               )
                               (i64.const 1)
                              )
                              (local.get $1)
                              (struct.get $type50 0
                               (local.get $6)
                              )
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready91)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global91)
                           )
                          )
                          (struct.set $type51 1
                           (local.tee $3
                            (struct.new_default $type51)
                           )
                           (struct.new $type50
                            (ref.func $function36)
                            (struct.new $environment36
                             (local.get $16)
                             (local.get $3)
                            )
                           )
                          )
                          (struct.set $type51 0
                           (local.get $3)
                           (i32.const 1)
                          )
                          (if
                           (i32.eqz
                            (struct.get $type51 0
                             (local.get $3)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call_ref $call50
                           (struct.get $type50 1
                            (local.tee $6
                             (ref.as_non_null
                              (struct.get $type51 1
                               (local.get $3)
                              )
                             )
                            )
                           )
                           (i64.sub
                            (i64.extend_i32_u
                             (array.len
                              (local.get $16)
                             )
                            )
                            (i64.const 1)
                           )
                           (local.get $1)
                           (struct.get $type50 0
                            (local.get $6)
                           )
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready91)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global91)
                        )
                       )
                       (struct.set $type51 1
                        (local.tee $3
                         (struct.new_default $type51)
                        )
                        (struct.new $type50
                         (ref.func $function36)
                         (struct.new $environment36
                          (local.get $15)
                          (local.get $3)
                         )
                        )
                       )
                       (struct.set $type51 0
                        (local.get $3)
                        (i32.const 1)
                       )
                       (if
                        (i32.eqz
                         (struct.get $type51 0
                          (local.get $3)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call_ref $call50
                        (struct.get $type50 1
                         (local.tee $6
                          (ref.as_non_null
                           (struct.get $type51 1
                            (local.get $3)
                           )
                          )
                         )
                        )
                        (i64.sub
                         (i64.extend_i32_u
                          (array.len
                           (local.get $15)
                          )
                         )
                         (i64.const 1)
                        )
                        (local.get $1)
                        (struct.get $type50 0
                         (local.get $6)
                        )
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready91)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global91)
                     )
                    )
                    (struct.set $type51 1
                     (local.tee $3
                      (struct.new_default $type51)
                     )
                     (struct.new $type50
                      (ref.func $function36)
                      (struct.new $environment36
                       (local.get $14)
                       (local.get $3)
                      )
                     )
                    )
                    (struct.set $type51 0
                     (local.get $3)
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (struct.get $type51 0
                       (local.get $3)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call_ref $call50
                     (struct.get $type50 1
                      (local.tee $6
                       (ref.as_non_null
                        (struct.get $type51 1
                         (local.get $3)
                        )
                       )
                      )
                     )
                     (i64.sub
                      (i64.extend_i32_u
                       (array.len
                        (local.get $14)
                       )
                      )
                      (i64.const 1)
                     )
                     (local.get $1)
                     (struct.get $type50 0
                      (local.get $6)
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready91)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global91)
                  )
                 )
                 (struct.set $type51 1
                  (local.tee $3
                   (struct.new_default $type51)
                  )
                  (struct.new $type50
                   (ref.func $function36)
                   (struct.new $environment36
                    (local.get $13)
                    (local.get $3)
                   )
                  )
                 )
                 (struct.set $type51 0
                  (local.get $3)
                  (i32.const 1)
                 )
                 (if
                  (i32.eqz
                   (struct.get $type51 0
                    (local.get $3)
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (call_ref $call50
                  (struct.get $type50 1
                   (local.tee $6
                    (ref.as_non_null
                     (struct.get $type51 1
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (i64.sub
                   (i64.extend_i32_u
                    (array.len
                     (local.get $13)
                    )
                   )
                   (i64.const 1)
                  )
                  (local.get $1)
                  (struct.get $type50 0
                   (local.get $6)
                  )
                 )
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready91)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global91)
               )
              )
              (struct.set $type51 1
               (local.tee $3
                (struct.new_default $type51)
               )
               (struct.new $type50
                (ref.func $function36)
                (struct.new $environment36
                 (local.get $12)
                 (local.get $3)
                )
               )
              )
              (struct.set $type51 0
               (local.get $3)
               (i32.const 1)
              )
              (if
               (i32.eqz
                (struct.get $type51 0
                 (local.get $3)
                )
               )
               (then
                (unreachable)
               )
              )
              (call_ref $call50
               (struct.get $type50 1
                (local.tee $6
                 (ref.as_non_null
                  (struct.get $type51 1
                   (local.get $3)
                  )
                 )
                )
               )
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (local.get $12)
                 )
                )
                (i64.const 1)
               )
               (local.get $1)
               (struct.get $type50 0
                (local.get $6)
               )
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready91)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global91)
            )
           )
           (struct.set $type51 1
            (local.tee $3
             (struct.new_default $type51)
            )
            (struct.new $type50
             (ref.func $function36)
             (struct.new $environment36
              (local.get $11)
              (local.get $3)
             )
            )
           )
           (struct.set $type51 0
            (local.get $3)
            (i32.const 1)
           )
           (if
            (i32.eqz
             (struct.get $type51 0
              (local.get $3)
             )
            )
            (then
             (unreachable)
            )
           )
           (call_ref $call50
            (struct.get $type50 1
             (local.tee $6
              (ref.as_non_null
               (struct.get $type51 1
                (local.get $3)
               )
              )
             )
            )
            (i64.sub
             (i64.extend_i32_u
              (array.len
               (local.get $11)
              )
             )
             (i64.const 1)
            )
            (local.get $1)
            (struct.get $type50 0
             (local.get $6)
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready91)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global91)
         )
        )
        (struct.set $type51 1
         (local.tee $3
          (struct.new_default $type51)
         )
         (struct.new $type50
          (ref.func $function36)
          (struct.new $environment36
           (local.get $10)
           (local.get $3)
          )
         )
        )
        (struct.set $type51 0
         (local.get $3)
         (i32.const 1)
        )
        (if
         (i32.eqz
          (struct.get $type51 0
           (local.get $3)
          )
         )
         (then
          (unreachable)
         )
        )
        (call_ref $call50
         (struct.get $type50 1
          (local.tee $6
           (ref.as_non_null
            (struct.get $type51 1
             (local.get $3)
            )
           )
          )
         )
         (i64.sub
          (i64.extend_i32_u
           (array.len
            (local.get $10)
           )
          )
          (i64.const 1)
         )
         (local.get $1)
         (struct.get $type50 0
          (local.get $6)
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready91)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global91)
      )
     )
     (struct.set $type51 1
      (local.tee $3
       (struct.new_default $type51)
      )
      (struct.new $type50
       (ref.func $function36)
       (struct.new $environment36
        (local.tee $9
         (struct.get $type16 0
          (local.get $0)
         )
        )
        (local.get $3)
       )
      )
     )
     (struct.set $type51 0
      (local.get $3)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type51 0
        (local.get $3)
       )
      )
      (then
       (unreachable)
      )
     )
     (local.get $scratch_25)
    )
   )
   (call_ref $call50
    (struct.get $type50 1
     (local.tee $6
      (ref.as_non_null
       (struct.get $type51 1
        (local.get $3)
       )
      )
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $9)
      )
     )
     (i64.const 1)
    )
    (local.get $1)
    (struct.get $type50 0
     (local.get $6)
    )
   )
  )
 )
 (func $function38 (type $call53) (param $0 (ref $environment38)) (param $1 (ref null $type16)) (result (ref null $type18))
  (local $2 (ref $type12))
  (local $3 (ref null $type18))
  (local $scratch (ref null $type18))
  (if (result (ref null $type18))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $environment38 0
     (local.get $0)
    )
   )
   (else
    (return_call $function35
     (struct.get $type16 0
      (local.get $1)
     )
     (block (result (ref null $type18))
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type52 0
         (struct.get $environment38 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $scratch
       (call $function38
        (struct.get $type53 0
         (struct.get $type52 1
          (struct.get $environment38 1
           (local.get $0)
          )
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready91)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global91)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function40 (type $call54) (param $0 (ref $environment40)) (param $1 (ref null $type16)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type16 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment40 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function40
     (struct.get $type54 0
      (struct.get $type55 1
       (struct.get $environment40 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function42 (type $call50) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type18)) (result (ref null $type18))
  (local $3 (ref $type51))
  (local $4 (ref $type29))
  (local $5 (ref $type50))
  (if (result (ref $type18))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type18
     (f64.convert_i64_s
      (i64.extend_i32_u
       (array.len
        (struct.get $environment42 0
         (ref.cast (ref $environment42)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type33
      (struct.get $environment42 0
       (ref.cast (ref $environment42)
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready85)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global85)
     )
    )
    (struct.set $type51 1
     (local.tee $3
      (struct.new_default $type51)
     )
     (struct.new $type50
      (ref.func $function34)
      (struct.new $environment34
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type51 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call50
      (struct.get $type50 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type51 1
          (local.get $3)
         )
        )
       )
      )
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $4)
        )
       )
       (i64.const 1)
      )
      (local.get $2)
      (struct.get $type50 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment42 1
        (ref.cast (ref $environment42)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (struct.get $type50 1
      (struct.get $type51 1
       (struct.get $environment42 1
        (ref.cast (ref $environment42)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function43 (type $call38) (param $0 (ref $type33)) (param $1 i64) (param $2 i64) (param $3 f64) (result i32)
  (local $4 (ref $type25))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type29
   (array.get $type33
    (local.get $0)
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (i32.wrap_i64
    (local.get $2)
   )
   (local.get $3)
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global80)
   )
   (block (result (ref (exact $type18)))
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type18
     (local.get $3)
     (struct.new $type18
      (f64.convert_i64_s
       (local.get $2)
      )
      (struct.new $type18
       (f64.convert_i64_s
        (local.get $1)
       )
       (struct.get $type25 0
        (global.get $global80)
       )
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function48 (type $call11) (param $0 (ref null $environment49)) (param $1 i64) (result (ref $type12))
  (local $2 (ref $type75))
  (local $3 (ref $type11))
  (local $4 i32)
  (if (result (ref $type12))
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (i64.const 4294967295)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type12))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type12 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready55)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type75 1
       (local.tee $2
        (struct.new_default $type75)
       )
       (struct.new $type11
        (ref.func $function49)
        (struct.new $environment49
         (local.get $1)
         (struct.new $type58
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type75 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type75 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call11
       (struct.get $type11 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type75 1
           (local.get $2)
          )
         )
        )
       )
       (i64.const 1)
       (struct.get $type11 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function49 (type $call11) (param $0 (ref null $environment49)) (param $1 i64) (result (ref $type12))
  (local $2 (ref $type12))
  (if (result (ref $type12))
   (i64.eq
    (struct.get $environment49 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (struct.get $type58 0
     (struct.get $environment49 1
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment49 1
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready55)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i64.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (struct.get $environment49 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type11 1
      (struct.get $type75 1
       (struct.get $environment49 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function50 (type $call13) (param $0 (ref null $environment51)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $type76))
  (local $3 (ref $type13))
  (local $4 i32)
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (i64.const 4294967295)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type14))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type14 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready58)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global58)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type76 1
       (local.tee $2
        (struct.new_default $type76)
       )
       (struct.new $type13
        (ref.func $function51)
        (struct.new $environment51
         (local.get $1)
         (struct.new $type59
          (array.new_default $type14
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type76 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type76 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call13
       (struct.get $type13 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type76 1
           (local.get $2)
          )
         )
        )
       )
       (i64.const 1)
       (struct.get $type13 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $call13) (param $0 (ref null $environment51)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $type14))
  (if (result (ref $type14))
   (i64.eq
    (struct.get $environment51 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (struct.get $type59 0
     (struct.get $environment51 1
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type14
     (struct.get $type59 0
      (struct.get $environment51 1
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready58)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global58)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type76 0
       (struct.get $environment51 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (struct.get $type13 1
      (struct.get $type76 1
       (struct.get $environment51 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $call67) (param $0 (ref $environment52)) (param $1 i64) (param $2 i32) (result i32)
  (local $3 (ref $type74))
  (local $4 (ref $type62))
  (local $5 (ref $type33))
  (local $6 (ref $type73))
  (local $7 i64)
  (struct.set $type61 0
   (struct.get $type60 0
    (struct.get $environment52 0
     (local.get $0)
    )
   )
   (array.get $type12
    (struct.get $type58 0
     (struct.get $environment52 1
      (local.get $0)
     )
    )
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $7
     (struct.get $type61 0
      (struct.get $type60 0
       (struct.get $environment52 0
        (local.get $0)
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type63 0
   (struct.get $type62 1
    (local.tee $4
     (struct.get $environment52 2
      (local.get $0)
     )
    )
   )
   (array.get $type29
    (array.get $type33
     (local.tee $5
      (struct.get $environment52 3
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (i32.wrap_i64
     (local.get $7)
    )
   )
  )
  (struct.set $type74 1
   (local.tee $3
    (struct.new_default $type74)
   )
   (struct.new $type73
    (ref.func $function54)
    (struct.new $environment54
     (struct.get $environment52 4
      (local.get $0)
     )
     (local.get $2)
     (local.get $5)
     (local.get $1)
     (struct.get $environment52 1
      (local.get $0)
     )
     (local.get $4)
     (struct.get $environment52 0
      (local.get $0)
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type74 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call73
   (struct.get $type73 1
    (local.tee $6
     (ref.as_non_null
      (struct.get $type74 1
       (local.get $3)
      )
     )
    )
   )
   (i64.const 1)
   (struct.get $type73 0
    (local.get $6)
   )
  )
 )
 (func $function54 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment54))
  (local $3 f64)
  (local $4 i64)
  (local $5 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type61 0
     (struct.get $type60 0
      (struct.get $environment54 0
       (ref.cast (ref $environment54)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (f64.gt
      (if (result f64)
       (struct.get $environment54 1
        (local.tee $2
         (ref.cast (ref $environment54)
          (local.get $0)
         )
        )
       )
       (then
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (array.get $type12
          (struct.get $type58 0
           (struct.get $environment54 4
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready158)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global158)
         )
        )
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment54 3
            (local.get $2)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (array.get $type29
          (array.get $type33
           (struct.get $environment54 2
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready78)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global78)
         )
        )
        (f64.sub
         (if (result f64)
          (f64.eq
           (local.get $3)
           (f64.const 0)
          )
          (then
           (f64.const 0)
          )
          (else
           (if (result f64)
            (f64.lt
             (local.get $3)
             (f64.const 0)
            )
            (then
             (if
              (i32.eqz
               (global.get $ready61)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (f64.sub
              (f64.const -0)
              (local.get $3)
             )
            )
            (else
             (local.get $3)
            )
           )
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready78)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global78)
           )
          )
          (if (result f64)
           (f64.eq
            (local.tee $3
             (struct.get $type63 0
              (struct.get $type62 1
               (struct.get $environment54 5
                (local.get $2)
               )
              )
             )
            )
            (f64.const 0)
           )
           (then
            (f64.const 0)
           )
           (else
            (if (result f64)
             (f64.lt
              (local.get $3)
              (f64.const 0)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready61)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global61)
               )
              )
              (f64.sub
               (f64.const -0)
               (local.get $3)
              )
             )
             (else
              (local.get $3)
             )
            )
           )
          )
         )
        )
       )
       (else
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (array.get $type12
          (struct.get $type58 0
           (struct.get $environment54 4
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready158)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global158)
         )
        )
        (if
         (i64.gt_u
          (local.tee $5
           (struct.get $environment54 3
            (local.get $2)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (f64.sub
         (array.get $type29
          (array.get $type33
           (struct.get $environment54 2
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (struct.get $type63 0
          (struct.get $type62 1
           (struct.get $environment54 5
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (block (result f64)
       (if
        (i32.eqz
         (global.get $ready76)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global76)
        )
       )
       (f64.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type61 0
       (struct.get $type60 0
        (struct.get $environment54 6
         (local.get $2)
        )
       )
       (array.get $type12
        (struct.get $type58 0
         (struct.get $environment54 4
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type12
        (struct.get $type58 0
         (struct.get $environment54 4
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (struct.get $environment54 3
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type63 0
       (struct.get $type62 1
        (struct.get $environment54 5
         (local.get $2)
        )
       )
       (array.get $type29
        (array.get $type33
         (struct.get $environment54 2
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment54 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment54 7
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function55 (type $call10) (param $0 (ref struct)) (result i32)
  (local $1 (ref $environment55))
  (local $2 (ref $type74))
  (local $3 (ref $type73))
  (struct.set $type61 0
   (struct.get $type60 0
    (struct.get $environment55 0
     (local.tee $1
      (ref.cast (ref $environment55)
       (local.get $0)
      )
     )
    )
   )
   (i64.const 0)
  )
  (struct.set $type74 1
   (local.tee $2
    (struct.new_default $type74)
   )
   (struct.new $type73
    (ref.func $function56)
    (struct.new $environment56
     (struct.get $environment55 1
      (local.get $1)
     )
     (struct.new $type64
      (i32.const 1)
      (struct.new_default $type65)
     )
     (struct.get $environment55 2
      (local.get $1)
     )
     (struct.get $environment55 3
      (local.get $1)
     )
     (struct.get $environment55 4
      (local.get $1)
     )
     (struct.get $environment55 5
      (local.get $1)
     )
     (struct.new $type62
      (i32.const 1)
      (struct.new_default $type63)
     )
     (struct.get $environment55 0
      (local.get $1)
     )
     (struct.get $environment55 6
      (local.get $1)
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type74 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call73
   (struct.get $type73 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type74 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type73 0
    (local.get $3)
   )
  )
 )
 (func $function56 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment56))
  (local $3 (ref $type74))
  (local $4 (ref $type62))
  (local $5 (ref $type62))
  (local $6 (ref $type73))
  (local $7 i64)
  (local $8 i64)
  (local $9 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type57 0
     (struct.get $environment56 0
      (ref.cast (ref $environment56)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment56)
      (local.get $0)
     )
    )
    (drop
     (if (result i32)
      (struct.get $type65 0
       (struct.get $type64 1
        (struct.get $environment56 1
         (local.tee $2
          (ref.cast (ref $environment56)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (array.get $type12
         (struct.get $type58 0
          (struct.get $environment56 3
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $7)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment56 4
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (f64.lt
         (array.get $type29
          (array.get $type33
           (struct.get $environment56 2
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
          (i32.wrap_i64
           (local.get $8)
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready61)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (f64.sub
           (f64.const -0)
           (struct.get $type56 0
            (struct.get $environment56 5
             (local.get $2)
            )
           )
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type58 0
            (struct.get $environment56 3
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $9
          (array.get $type29
           (array.get $type33
            (struct.get $environment56 2
             (local.get $2)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
           (i32.const 0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type58 0
            (struct.get $environment56 3
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (struct.get $type61 0
             (struct.get $type60 0
              (struct.get $environment56 4
               (local.get $2)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (f64.lt
           (local.tee $9
            (f64.div
             (f64.sub
              (f64.const -0)
              (local.get $9)
             )
             (array.get $type29
              (array.get $type33
               (struct.get $environment56 2
                (local.get $2)
               )
               (i32.wrap_i64
                (local.get $7)
               )
              )
              (i32.wrap_i64
               (local.get $8)
              )
             )
            )
           )
           (struct.get $type63 0
            (struct.get $type62 1
             (struct.get $environment56 6
              (local.get $2)
             )
            )
           )
          )
          (then
           (if
            (i64.gt_u
             (local.get $1)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (struct.set $type61 0
            (struct.get $type60 0
             (struct.get $environment56 7
              (local.get $2)
             )
            )
            (array.get $type12
             (struct.get $type58 0
              (struct.get $environment56 3
               (local.get $2)
              )
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (struct.set $type63 0
            (struct.get $type62 1
             (struct.get $environment56 6
              (local.get $2)
             )
            )
            (local.get $9)
           )
          )
          (else
           (if
            (f64.eq
             (struct.get $type63 0
              (struct.get $type62 1
               (struct.get $environment56 6
                (local.get $2)
               )
              )
             )
             (local.get $9)
            )
            (then
             (struct.set $type74 1
              (local.tee $3
               (struct.new_default $type74)
              )
              (struct.new $type73
               (ref.func $function57)
               (struct.new $environment57
                (struct.get $environment56 8
                 (local.get $2)
                )
                (local.tee $4
                 (struct.new $type62
                  (i32.const 1)
                  (struct.new_default $type63)
                 )
                )
                (struct.get $environment56 2
                 (local.get $2)
                )
                (struct.get $environment56 7
                 (local.get $2)
                )
                (struct.get $environment56 4
                 (local.get $2)
                )
                (local.tee $5
                 (struct.new $type62
                  (i32.const 1)
                  (struct.new_default $type63)
                 )
                )
                (struct.get $environment56 3
                 (local.get $2)
                )
                (local.get $1)
                (local.get $3)
               )
              )
             )
             (struct.set $type74 0
              (local.get $3)
              (i32.const 1)
             )
             (if
              (i32.eqz
               (struct.get $type74 0
                (local.get $3)
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (call_ref $call73
               (struct.get $type73 1
                (local.tee $6
                 (ref.as_non_null
                  (struct.get $type74 1
                   (local.get $3)
                  )
                 )
                )
               )
               (i64.const 1)
               (struct.get $type73 0
                (local.get $6)
               )
              )
             )
             (if
              (f64.lt
               (struct.get $type63 0
                (struct.get $type62 1
                 (local.get $5)
                )
               )
               (struct.get $type63 0
                (struct.get $type62 1
                 (local.get $4)
                )
               )
              )
              (then
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (struct.set $type61 0
                (struct.get $type60 0
                 (struct.get $environment56 7
                  (local.get $2)
                 )
                )
                (array.get $type12
                 (struct.get $type58 0
                  (struct.get $environment56 3
                   (local.get $2)
                  )
                 )
                 (i32.wrap_i64
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i32.const 0)
      )
      (else
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (array.get $type12
         (struct.get $type58 0
          (struct.get $environment56 3
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $7)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment56 4
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (f64.lt
         (array.get $type29
          (array.get $type33
           (struct.get $environment56 2
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
          (i32.wrap_i64
           (local.get $8)
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready61)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (f64.sub
           (f64.const -0)
           (struct.get $type56 0
            (struct.get $environment56 5
             (local.get $2)
            )
           )
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type58 0
            (struct.get $environment56 3
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $9
          (array.get $type29
           (array.get $type33
            (struct.get $environment56 2
             (local.get $2)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
           (i32.const 0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready61)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (array.get $type12
           (struct.get $type58 0
            (struct.get $environment56 3
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.get $7)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (struct.get $type61 0
             (struct.get $type60 0
              (struct.get $environment56 4
               (local.get $2)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type63 0
          (struct.get $type62 1
           (struct.get $environment56 6
            (local.get $2)
           )
          )
          (f64.div
           (f64.sub
            (f64.const -0)
            (local.get $9)
           )
           (array.get $type29
            (array.get $type33
             (struct.get $environment56 2
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $7)
             )
            )
            (i32.wrap_i64
             (local.get $8)
            )
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type61 0
          (struct.get $type60 0
           (struct.get $environment56 7
            (local.get $2)
           )
          )
          (array.get $type12
           (struct.get $type58 0
            (struct.get $environment56 3
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (struct.set $type65 0
          (struct.get $type64 1
           (struct.get $environment56 1
            (local.get $2)
           )
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment56 9
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment56 9
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function57 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment57))
  (local $3 (ref $type63))
  (local $4 i64)
  (local $5 i64)
  (local $6 f64)
  (if (result i32)
   (i64.ge_s
    (struct.get $type57 0
     (struct.get $environment57 0
      (local.tee $2
       (ref.cast (ref $environment57)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $type61 0
        (struct.get $type60 0
         (struct.get $environment57 3
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type29
      (array.get $type33
       (struct.get $environment57 2
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $type61 0
        (struct.get $type60 0
         (struct.get $environment57 3
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type61 0
        (struct.get $type60 0
         (struct.get $environment57 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type63 0
     (struct.get $type62 1
      (struct.get $environment57 1
       (local.get $2)
      )
     )
     (f64.div
      (f64.sub
       (f64.const -0)
       (local.get $6)
      )
      (array.get $type29
       (array.get $type33
        (struct.get $environment57 2
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment57 7
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $type58 0
       (struct.get $environment57 6
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type29
      (array.get $type33
       (struct.get $environment57 2
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment57 7
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $type58 0
       (struct.get $environment57 6
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type61 0
        (struct.get $type60 0
         (struct.get $environment57 4
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type63 0
     (local.tee $3
      (struct.get $type62 1
       (struct.get $environment57 5
        (local.get $2)
       )
      )
     )
     (f64.div
      (f64.sub
       (f64.const -0)
       (local.get $6)
      )
      (array.get $type29
       (array.get $type33
        (struct.get $environment57 2
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if (result i32)
     (f64.eq
      (struct.get $type63 0
       (local.get $3)
      )
      (struct.get $type63 0
       (struct.get $type62 1
        (struct.get $environment57 1
         (local.get $2)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type74 0
         (struct.get $environment57 8
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function57
       (struct.get $type73 1
        (struct.get $type74 1
         (struct.get $environment57 8
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function58 (type $call70) (param $0 (ref $environment58)) (param $1 i32) (result i32)
  (local $2 (ref $type74))
  (local $3 (ref $type73))
  (local $4 (ref $type56))
  (local $5 i64)
  (local $6 i64)
  (local $7 f64)
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (if
   (i64.gt_u
    (local.tee $5
     (struct.get $type61 0
      (struct.get $type60 0
       (struct.get $environment58 1
        (local.get $0)
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $6
     (struct.get $type61 0
      (struct.get $type60 0
       (struct.get $environment58 2
        (local.get $0)
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $7
   (array.get $type29
    (array.get $type33
     (struct.get $environment58 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready63)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global63)
   )
  )
  (struct.set $type74 1
   (local.tee $2
    (struct.new_default $type74)
   )
   (struct.new $type73
    (ref.func $function59)
    (struct.new $environment59
     (struct.get $environment58 3
      (local.get $0)
     )
     (local.get $1)
     (struct.get $environment58 1
      (local.get $0)
     )
     (struct.get $environment58 0
      (local.get $0)
     )
     (struct.get $environment58 2
      (local.get $0)
     )
     (local.tee $4
      (struct.new $type56
       (f64.div
        (f64.const 1)
        (local.get $7)
       )
      )
     )
     (struct.get $environment58 4
      (local.get $0)
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type74 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call73
    (struct.get $type73 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type74 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type73 0
     (local.get $3)
    )
   )
  )
  (struct.set $type74 1
   (local.tee $2
    (struct.new_default $type74)
   )
   (struct.new $type73
    (ref.func $function61)
    (struct.new $environment61
     (struct.get $environment58 4
      (local.get $0)
     )
     (struct.get $environment58 2
      (local.get $0)
     )
     (struct.get $environment58 0
      (local.get $0)
     )
     (struct.get $environment58 1
      (local.get $0)
     )
     (local.get $4)
     (local.get $2)
    )
   )
  )
  (struct.set $type74 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call73
    (struct.get $type73 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type74 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type73 0
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready113)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global113)
   )
  )
  (return_call $function43
   (struct.get $environment58 0
    (local.get $0)
   )
   (struct.get $type61 0
    (struct.get $type60 0
     (struct.get $environment58 1
      (local.get $0)
     )
    )
   )
   (struct.get $type61 0
    (struct.get $type60 0
     (struct.get $environment58 2
      (local.get $0)
     )
    )
   )
   (struct.get $type56 0
    (local.get $4)
   )
  )
 )
 (func $function59 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment59))
  (local $3 (ref $type74))
  (local $4 (ref $type33))
  (local $5 (ref $type60))
  (local $6 (ref $type73))
  (local $7 i64)
  (local $8 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type57 0
      (struct.get $environment59 0
       (local.tee $2
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (select
      (i64.const 2)
      (i64.const 1)
      (struct.get $environment59 1
       (local.get $2)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment59 2
         (local.get $2)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $7
         (struct.get $type61 0
          (struct.get $type60 0
           (struct.get $environment59 4
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (array.get $type29
        (array.get $type33
         (struct.get $environment59 3
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $7)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready113)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (drop
       (call $function43
        (local.tee $4
         (struct.get $environment59 3
          (local.get $2)
         )
        )
        (local.get $1)
        (struct.get $type61 0
         (struct.get $type60 0
          (local.tee $5
           (struct.get $environment59 4
            (local.get $2)
           )
          )
         )
        )
        (f64.mul
         (struct.get $type56 0
          (struct.get $environment59 5
           (local.get $2)
          )
         )
         (local.get $8)
        )
       )
      )
      (struct.set $type74 1
       (local.tee $3
        (struct.new_default $type74)
       )
       (struct.new $type73
        (ref.func $function60)
        (struct.new $environment60
         (struct.get $environment59 6
          (local.get $2)
         )
         (local.get $5)
         (local.get $4)
         (local.get $1)
         (struct.get $environment59 2
          (local.get $2)
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type74 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type74 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call73
        (struct.get $type73 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type74 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type73 0
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment59 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment59 7
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function60 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment60))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type57 0
      (struct.get $environment60 0
       (ref.cast (ref $environment60)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment60 1
         (local.tee $2
          (ref.cast (ref $environment60)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment60 3
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (array.get $type29
        (array.get $type33
         (struct.get $environment60 2
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type61 0
          (struct.get $type60 0
           (struct.get $environment60 4
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (array.get $type29
        (array.get $type33
         (struct.get $environment60 2
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $environment60 3
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (struct.get $type61 0
          (struct.get $type60 0
           (struct.get $environment60 1
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (array.get $type29
        (array.get $type33
         (struct.get $environment60 2
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready113)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (drop
       (call $function43
        (struct.get $environment60 2
         (local.get $2)
        )
        (local.get $4)
        (local.get $1)
        (f64.sub
         (local.get $6)
         (f64.mul
          (local.get $7)
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment60 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function60
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment60 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function61 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment61))
  (local $3 i64)
  (local $4 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type57 0
      (struct.get $environment61 0
       (ref.cast (ref $environment61)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment61 1
         (local.tee $2
          (ref.cast (ref $environment61)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i32.eqz
        (global.get $ready158)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global158)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type61 0
          (struct.get $type60 0
           (struct.get $environment61 3
            (local.get $2)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type29
        (array.get $type33
         (struct.get $environment61 2
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready113)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (drop
       (call $function43
        (struct.get $environment61 2
         (local.get $2)
        )
        (struct.get $type61 0
         (struct.get $type60 0
          (struct.get $environment61 3
           (local.get $2)
          )
         )
        )
        (local.get $1)
        (f64.mul
         (f64.sub
          (f64.const -0)
          (struct.get $type56 0
           (struct.get $environment61 4
            (local.get $2)
           )
          )
         )
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment61 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function61
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment61 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function62 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment62))
  (if (result i32)
   (i64.eq
    (struct.get $type57 0
     (struct.get $environment62 0
      (ref.cast (ref $environment62)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment62)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment62 1
       (local.tee $2
        (ref.cast (ref $environment62)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment62 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment62 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment62 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function63 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment63))
  (local $3 (ref $type33))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type57 0
     (struct.get $environment63 0
      (ref.cast (ref $environment63)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (f64.lt
      (array.get $type29
       (array.get $type33
        (struct.get $environment63 1
         (ref.cast (ref $environment63)
          (local.get $0)
         )
        )
        (block (result i32)
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.tee $4
            (i64.add
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i32.const 0)
      )
      (block (result f64)
       (if
        (i32.eqz
         (global.get $ready187)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global187)
        )
       )
       (f64.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (unreachable)
     )
    )
    (drop
     (ref.cast (ref $environment63)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment63 2
       (local.tee $2
        (ref.cast (ref $environment63)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment63 3
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.add
      (local.get $1)
      (struct.get $type57 0
       (struct.get $environment63 4
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment63 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function63
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment63 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function65 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment65))
  (if (result i32)
   (i64.eq
    (struct.get $environment65 0
     (ref.cast (ref $environment65)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment65)
      (local.get $0)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (struct.get $type59 0
      (struct.get $environment65 1
       (local.tee $2
        (ref.cast (ref $environment65)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment65 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function65
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment65 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function66 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment66))
  (local $3 (ref $type78))
  (local $4 i64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type57 0
      (struct.get $environment66 0
       (ref.cast (ref $environment66)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $4
     (struct.get $environment66 3
      (local.tee $2
       (ref.cast (ref $environment66)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type78 1
     (local.tee $3
      (struct.new_default $type78)
     )
     (struct.new $type77
      (struct.new $environment67
       (struct.get $environment66 1
        (local.get $2)
       )
       (struct.get $environment66 2
        (local.get $2)
       )
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type78 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type78 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function67
      (struct.get $type77 0
       (struct.get $type78 1
        (local.get $3)
       )
      )
      (i64.add
       (local.get $4)
       (i64.const 1)
      )
      (f64.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment66 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function66
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment66 4
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function67 (type $call77) (param $0 (ref $environment67)) (param $1 i64) (param $2 f64) (result i32)
  (local $3 i64)
  (local $4 f64)
  (if
   (i64.lt_s
    (struct.get $type57 0
     (struct.get $environment67 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i32.eqz
      (global.get $ready113)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (return_call $function43
     (struct.get $environment67 1
      (local.get $0)
     )
     (i64.add
      (struct.get $type57 0
       (struct.get $environment67 0
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (struct.get $environment67 2
      (local.get $0)
     )
     (f64.sub
      (f64.const -0)
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (struct.get $environment67 2
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type29
      (array.get $type33
       (struct.get $environment67 1
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type78 0
       (struct.get $environment67 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (struct.get $type77 0
      (struct.get $type78 1
       (struct.get $environment67 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (f64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function68 (type $call10) (param $0 (ref struct)) (result i32)
  (local $1 (ref $environment68))
  (local $2 (ref $type74))
  (local $3 (ref $type73))
  (local $4 (ref $type33))
  (local $5 (ref $type57))
  (local $6 (ref $type65))
  (local $7 (ref $type60))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 f64)
  (local.set $8
   (struct.get $type57 0
    (struct.get $environment68 1
     (local.tee $1
      (ref.cast (ref $environment68)
       (local.get $0)
      )
     )
    )
   )
  )
  (drop
   (call $function52
    (struct.get $type67 0
     (struct.get $type66 0
      (struct.get $environment68 0
       (local.get $1)
      )
     )
    )
    (i64.add
     (local.get $8)
     (i64.const 1)
    )
    (i32.const 0)
   )
  )
  (drop
   (if (result i32)
    (f64.le
     (struct.get $type63 0
      (struct.get $type62 1
       (struct.get $environment68 2
        (local.get $1)
       )
      )
     )
     (struct.get $type56 0
      (struct.get $environment68 3
       (local.get $1)
      )
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready158)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global158)
      )
     )
     (if
      (i64.gt_u
       (local.tee $8
        (i64.add
         (struct.get $type57 0
          (struct.get $environment68 1
           (local.get $1)
          )
         )
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (f64.lt
       (array.get $type29
        (array.get $type33
         (struct.get $environment68 4
          (local.get $1)
         )
         (i32.wrap_i64
          (local.get $8)
         )
        )
        (i32.const 0)
       )
       (block (result f64)
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (f64.sub
         (f64.const -0)
         (struct.get $type56 0
          (struct.get $environment68 3
           (local.get $1)
          )
         )
        )
       )
      )
      (then
       (struct.set $type65 0
        (struct.get $type64 1
         (struct.get $environment68 5
          (local.get $1)
         )
        )
        (i32.const 0)
       )
       (i32.const 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (i64.add
           (struct.get $type57 0
            (struct.get $environment68 1
             (local.get $1)
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (f64.ge
         (struct.get $type56 0
          (struct.get $environment68 3
           (local.get $1)
          )
         )
         (array.get $type29
          (array.get $type33
           (local.tee $4
            (struct.get $environment68 4
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $8)
           )
          )
          (i32.const 0)
         )
        )
        (then
         (local.set $8
          (struct.get $type57 0
           (local.tee $5
            (struct.get $environment68 10
             (local.get $1)
            )
           )
          )
         )
         (struct.set $type74 1
          (local.tee $2
           (struct.new_default $type74)
          )
          (struct.new $type73
           (ref.func $function69)
           (struct.new $environment69
            (struct.get $environment68 1
             (local.get $1)
            )
            (struct.get $environment68 6
             (local.get $1)
            )
            (struct.get $environment68 7
             (local.get $1)
            )
            (struct.get $environment68 8
             (local.get $1)
            )
            (struct.get $environment68 0
             (local.get $1)
            )
            (struct.get $environment68 2
             (local.get $1)
            )
            (struct.get $environment68 9
             (local.get $1)
            )
            (local.get $2)
            (local.get $5)
            (struct.get $environment68 11
             (local.get $1)
            )
            (struct.get $environment68 12
             (local.get $1)
            )
            (local.get $4)
           )
          )
         )
         (struct.set $type74 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type74 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call73
          (struct.get $type73 1
           (local.tee $3
            (ref.as_non_null
             (struct.get $type74 1
              (local.get $2)
             )
            )
           )
          )
          (local.get $8)
          (struct.get $type73 0
           (local.get $3)
          )
         )
        )
        (else
         (if
          (i32.eqz
           (struct.get $type68 0
            (struct.get $environment68 13
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (call $function55
           (struct.get $type10 1
            (struct.get $type68 1
             (struct.get $environment68 13
              (local.get $1)
             )
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready203)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global203)
          )
         )
         (if
          (i64.eqz
           (struct.get $type61 0
            (struct.get $type60 0
             (struct.get $environment68 7
              (local.get $1)
             )
            )
           )
          )
          (then
           (struct.set $type65 0
            (struct.get $type64 1
             (struct.get $environment68 5
              (local.get $1)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (struct.set $type65 0
            (struct.get $type64 1
             (struct.get $environment68 9
              (local.get $1)
             )
            )
            (i32.const 1)
           )
          )
         )
         (i32.const 0)
        )
       )
      )
     )
    )
    (else
     (if
      (i32.eqz
       (struct.get $type68 0
        (struct.get $environment68 13
         (local.get $1)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (call $function55
       (struct.get $type10 1
        (struct.get $type68 1
         (struct.get $environment68 13
          (local.get $1)
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready203)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global203)
      )
     )
     (if
      (i64.eqz
       (struct.get $type61 0
        (struct.get $type60 0
         (struct.get $environment68 7
          (local.get $1)
         )
        )
       )
      )
      (then
       (struct.set $type65 0
        (struct.get $type64 1
         (struct.get $environment68 5
          (local.get $1)
         )
        )
        (i32.const 0)
       )
      )
      (else
       (struct.set $type65 0
        (struct.get $type64 1
         (struct.get $environment68 9
          (local.get $1)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
    )
   )
  )
  (if (result i32)
   (struct.get $type65 0
    (local.tee $6
     (struct.get $type64 1
      (struct.get $environment68 9
       (local.get $1)
      )
     )
    )
   )
   (then
    (struct.set $type65 0
     (local.get $6)
     (i32.const 0)
    )
    (drop
     (call $function58
      (struct.get $type70 0
       (struct.get $type69 0
        (struct.get $environment68 14
         (local.get $1)
        )
       )
      )
      (i32.const 1)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.sub
        (struct.get $type61 0
         (struct.get $type60 0
          (struct.get $environment68 7
           (local.get $1)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (i64.ge_s
       (array.get $type12
        (struct.get $type58 0
         (struct.get $environment68 6
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
       (block (result i64)
        (if
         (i32.eqz
          (global.get $ready65)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global65)
         )
        )
        (i64.sub
         (i64.add
          (struct.get $type57 0
           (struct.get $environment68 8
            (local.get $1)
           )
          )
          (struct.get $type57 0
           (struct.get $environment68 10
            (local.get $1)
           )
          )
         )
         (i64.const 1)
        )
       )
      )
      (then
       (struct.set $type74 1
        (local.tee $2
         (struct.new_default $type74)
        )
        (struct.new $type73
         (ref.func $function73)
         (struct.new $environment73
          (struct.get $environment68 15
           (local.get $1)
          )
          (struct.get $environment68 16
           (local.get $1)
          )
          (struct.get $environment68 17
           (local.get $1)
          )
          (local.get $2)
          (struct.get $environment68 4
           (local.get $1)
          )
          (struct.get $environment68 1
           (local.get $1)
          )
         )
        )
       )
       (struct.set $type74 0
        (local.get $2)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type74 0
          (local.get $2)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call73
        (struct.get $type73 1
         (local.tee $3
          (ref.as_non_null
           (struct.get $type74 1
            (local.get $2)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type73 0
         (local.get $3)
        )
       )
      )
      (else
       (if
        (i64.gt_u
         (local.tee $8
          (i64.sub
           (struct.get $type61 0
            (struct.get $type60 0
             (struct.get $environment68 7
              (local.get $1)
             )
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (if (result i32)
         (i64.le_s
          (i64.add
           (struct.get $type57 0
            (struct.get $environment68 8
             (local.get $1)
            )
           )
           (struct.get $environment68 12
            (local.get $1)
           )
          )
          (array.get $type12
           (struct.get $type58 0
            (struct.get $environment68 6
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (then
          (if
           (i64.gt_u
            (local.tee $8
             (i64.sub
              (struct.get $type61 0
               (struct.get $type60 0
                (struct.get $environment68 7
                 (local.get $1)
                )
               )
              )
              (i64.const 1)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.tee $8
             (i64.sub
              (array.get $type12
               (struct.get $type58 0
                (struct.get $environment68 6
                 (local.get $1)
                )
               )
               (i32.wrap_i64
                (local.get $8)
               )
              )
              (i64.add
               (struct.get $environment68 12
                (local.get $1)
               )
               (struct.get $type57 0
                (struct.get $environment68 8
                 (local.get $1)
                )
               )
              )
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (array.get $type14
           (struct.get $type59 0
            (struct.get $environment68 11
             (local.get $1)
            )
           )
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (if
          (i64.gt_u
           (local.tee $8
            (i64.sub
             (struct.get $type61 0
              (struct.get $type60 0
               (struct.get $environment68 7
                (local.get $1)
               )
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (i64.sub
             (array.get $type12
              (struct.get $type58 0
               (struct.get $environment68 6
                (local.get $1)
               )
              )
              (i32.wrap_i64
               (local.get $8)
              )
             )
             (i64.add
              (struct.get $environment68 12
               (local.get $1)
              )
              (struct.get $type57 0
               (struct.get $environment68 8
                (local.get $1)
               )
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type14
          (struct.get $type59 0
           (struct.get $environment68 11
            (local.get $1)
           )
          )
          (i32.wrap_i64
           (local.get $8)
          )
          (i32.const 0)
         )
         (if
          (i32.eqz
           (global.get $ready158)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global158)
          )
         )
         (if
          (i64.gt_u
           (local.tee $8
            (i64.add
             (struct.get $type57 0
              (struct.get $environment68 1
               (local.get $1)
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $9
            (struct.get $type61 0
             (struct.get $type60 0
              (struct.get $environment68 16
               (local.get $1)
              )
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $11
          (array.get $type29
           (array.get $type33
            (struct.get $environment68 4
             (local.get $1)
            )
            (i32.wrap_i64
             (local.get $8)
            )
           )
           (i32.wrap_i64
            (local.get $9)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready113)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global113)
          )
         )
         (drop
          (call $function43
           (local.tee $4
            (struct.get $environment68 4
             (local.get $1)
            )
           )
           (i64.add
            (struct.get $type57 0
             (local.tee $5
              (struct.get $environment68 1
               (local.get $1)
              )
             )
            )
            (i64.const 1)
           )
           (struct.get $type61 0
            (struct.get $type60 0
             (local.tee $7
              (struct.get $environment68 16
               (local.get $1)
              )
             )
            )
           )
           (f64.add
            (local.get $11)
            (f64.const 1)
           )
          )
         )
         (struct.set $type74 1
          (local.tee $2
           (struct.new_default $type74)
          )
          (struct.new $type73
           (ref.func $function76)
           (struct.new $environment76
            (local.get $5)
            (local.get $4)
            (local.get $7)
            (local.get $2)
           )
          )
         )
         (struct.set $type74 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type74 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call73
          (struct.get $type73 1
           (local.tee $3
            (ref.as_non_null
             (struct.get $type74 1
              (local.get $2)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type73 0
           (local.get $3)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.sub
        (struct.get $type61 0
         (struct.get $type60 0
          (struct.get $environment68 16
           (local.get $1)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (array.get $type12
      (struct.get $type58 0
       (struct.get $environment68 18
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $8)
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.sub
        (struct.get $type61 0
         (struct.get $type60 0
          (struct.get $environment68 7
           (local.get $1)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type12
      (struct.get $type58 0
       (struct.get $environment68 6
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $9)
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $10
       (i64.sub
        (struct.get $type61 0
         (struct.get $type60 0
          (struct.get $environment68 16
           (local.get $1)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment68 18
       (local.get $1)
      )
     )
     (i32.wrap_i64
      (local.get $10)
     )
     (local.get $9)
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.sub
        (struct.get $type61 0
         (struct.get $type60 0
          (struct.get $environment68 7
           (local.get $1)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment68 6
       (local.get $1)
      )
     )
     (i32.wrap_i64
      (local.get $9)
     )
     (local.get $8)
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment68 19
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function68
     (struct.get $type10 1
      (struct.get $type68 1
       (struct.get $environment68 19
        (local.get $1)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function69 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $environment69))
  (local $3 (ref $type74))
  (local $4 (ref $type73))
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 f64)
  (local $scratch i64)
  (block $block
   (return
    (if (result i32)
     (i64.ge_s
      (struct.get $type57 0
       (struct.get $environment69 0
        (local.tee $2
         (ref.cast (ref $environment69)
          (local.get $0)
         )
        )
       )
      )
      (local.get $1)
     )
     (then
      (drop
       (struct.get $environment69 1
        (local.get $2)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (br_if $block
       (i64.ne
        (array.get $type12
         (struct.get $type58 0
          (struct.get $environment69 1
           (local.get $2)
          )
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i64.sub
         (i64.add
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment69 2
             (local.get $2)
            )
           )
          )
          (block (result i64)
           (local.set $scratch
            (struct.get $type57 0
             (struct.get $environment69 3
              (local.get $2)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready65)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global65)
            )
           )
           (local.get $scratch)
          )
         )
         (i64.const 1)
        )
       )
      )
      (drop
       (call $function52
        (struct.get $type67 0
         (struct.get $type66 0
          (struct.get $environment69 4
           (local.get $2)
          )
         )
        )
        (local.get $1)
        (i32.const 1)
       )
      )
      (drop
       (struct.get $environment69 5
        (local.get $2)
       )
      )
      (br_if $block
       (i32.eqz
        (f64.gt
         (struct.get $type63 0
          (struct.get $type62 1
           (struct.get $environment69 5
            (local.get $2)
           )
          )
         )
         (block (result f64)
          (if
           (i32.eqz
            (global.get $ready76)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global76)
           )
          )
          (f64.const 0)
         )
        )
       )
      )
      (struct.set $type61 0
       (struct.get $type60 0
        (struct.get $environment69 2
         (local.get $2)
        )
       )
       (local.get $1)
      )
      (drop
       (struct.get $environment69 6
        (local.get $2)
       )
      )
      (struct.set $type65 0
       (struct.get $type64 1
        (struct.get $environment69 6
         (local.get $2)
        )
       )
       (i32.const 1)
      )
      (i32.const 0)
     )
     (else
      (struct.set $type74 1
       (local.tee $3
        (struct.new_default $type74)
       )
       (struct.new $type73
        (ref.func $function70)
        (struct.new $environment70
         (struct.get $environment69 8
          (local.get $2)
         )
         (struct.get $environment69 9
          (local.get $2)
         )
         (local.tee $1
          (struct.get $environment69 10
           (local.get $2)
          )
         )
         (struct.get $environment69 3
          (local.get $2)
         )
         (struct.get $environment69 11
          (local.get $2)
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type74 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type74 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call73
       (struct.get $type73 1
        (local.tee $4
         (ref.as_non_null
          (struct.get $type74 1
           (local.get $3)
          )
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
       (struct.get $type73 0
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (struct.get $environment69 7
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function69
   (struct.get $type73 1
    (struct.get $type74 1
     (struct.get $environment69 7
      (local.get $2)
     )
    )
   )
   (i64.add
    (local.get $1)
    (i64.const 1)
   )
  )
 )
 (func $function70 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment70))
  (local $3 (ref $type74))
  (local $4 (ref $type73))
  (local $5 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type57 0
     (struct.get $environment70 0
      (ref.cast (ref $environment70)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (array.get $type14
      (struct.get $type59 0
       (struct.get $environment70 1
        (local.tee $2
         (ref.cast (ref $environment70)
          (local.get $0)
         )
        )
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.tee $5
          (i64.sub
           (local.get $1)
           (i64.add
            (struct.get $environment70 2
             (local.get $2)
            )
            (i64.const 1)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
     (then
      (struct.set $type74 1
       (local.tee $3
        (struct.new_default $type74)
       )
       (struct.new $type73
        (ref.func $function71)
        (struct.new $environment71
         (struct.get $environment70 3
          (local.get $2)
         )
         (struct.get $environment70 4
          (local.get $2)
         )
         (local.get $1)
         (local.get $3)
        )
       )
      )
      (struct.set $type74 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type74 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call73
        (struct.get $type73 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type74 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type73 0
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment70 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment70 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment71))
  (local $3 (ref $type33))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type57 0
      (struct.get $environment71 0
       (ref.cast (ref $environment71)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function43
      (struct.get $environment71 1
       (local.tee $2
        (ref.cast (ref $environment71)
         (local.get $0)
        )
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $environment71 2
           (local.get $2)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type29
         (array.get $type33
          (struct.get $environment71 1
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready113)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global113)
        )
       )
       (local.get $4)
      )
      (local.get $1)
      (f64.sub
       (f64.const -0)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment71 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment71 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function73 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment73))
  (local $3 (ref $type74))
  (local $4 (ref $type60))
  (local $5 (ref $type73))
  (local $6 (ref $type33))
  (local $7 (ref $type57))
  (local $8 i64)
  (local $9 f64)
  (if
   (if (result i32)
    (i64.gt_s
     (struct.get $type61 0
      (struct.get $type60 0
       (struct.get $environment73 0
        (local.tee $2
         (ref.cast (ref $environment73)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.get $1)
    )
    (then
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment73 1
         (local.get $2)
        )
       )
      )
      (array.get $type12
       (struct.get $type58 0
        (struct.get $environment73 2
         (local.get $2)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment73 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function73
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment73 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (struct.set $type61 0
     (struct.get $type60 0
      (local.tee $4
       (struct.get $environment73 0
        (local.get $2)
       )
      )
     )
     (i64.sub
      (struct.get $type61 0
       (struct.get $type60 0
        (local.get $4)
       )
      )
      (i64.const 1)
     )
    )
    (struct.set $type74 1
     (local.tee $3
      (struct.new_default $type74)
     )
     (struct.new $type73
      (ref.func $function74)
      (struct.new $environment74
       (local.get $4)
       (struct.get $environment73 2
        (local.get $2)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type74 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call73
      (struct.get $type73 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type74 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type73 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (struct.get $type57 0
         (struct.get $environment73 5
          (local.get $2)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (struct.get $type61 0
        (struct.get $type60 0
         (struct.get $environment73 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type29
      (array.get $type33
       (struct.get $environment73 4
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.wrap_i64
       (local.get $8)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready113)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (drop
     (call $function43
      (local.tee $6
       (struct.get $environment73 4
        (local.get $2)
       )
      )
      (i64.add
       (struct.get $type57 0
        (local.tee $7
         (struct.get $environment73 5
          (local.get $2)
         )
        )
       )
       (i64.const 1)
      )
      (struct.get $type61 0
       (struct.get $type60 0
        (local.tee $4
         (struct.get $environment73 1
          (local.get $2)
         )
        )
       )
      )
      (f64.add
       (local.get $9)
       (f64.const 1)
      )
     )
    )
    (struct.set $type74 1
     (local.tee $3
      (struct.new_default $type74)
     )
     (struct.new $type73
      (ref.func $function75)
      (struct.new $environment75
       (local.get $7)
       (local.get $6)
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type74 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call73
     (struct.get $type73 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type74 1
         (local.get $3)
        )
       )
      )
     )
     (i64.const 0)
     (struct.get $type73 0
      (local.get $5)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function74 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment74))
  (local $3 (ref $type12))
  (local $4 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type61 0
     (struct.get $type60 0
      (struct.get $environment74 0
       (ref.cast (ref $environment74)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type12
     (struct.get $type58 0
      (struct.get $environment74 1
       (local.tee $2
        (ref.cast (ref $environment74)
         (local.get $0)
        )
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type12
        (struct.get $type58 0
         (struct.get $environment74 1
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment74 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment74 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function75 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment75))
  (local $3 (ref $type33))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type57 0
      (struct.get $environment75 0
       (ref.cast (ref $environment75)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function43
      (struct.get $environment75 1
       (local.tee $2
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment75 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type29
         (array.get $type33
          (struct.get $environment75 1
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready113)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global113)
        )
       )
       (local.get $1)
      )
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment75 2
         (local.get $2)
        )
       )
      )
      (f64.sub
       (f64.const -0)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment75 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment75 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function76 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment76))
  (local $3 (ref $type33))
  (local $4 i64)
  (local $5 f64)
  (if (result i32)
   (i64.eq
    (i64.add
     (struct.get $type57 0
      (struct.get $environment76 0
       (ref.cast (ref $environment76)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function43
      (struct.get $environment76 1
       (local.tee $2
        (ref.cast (ref $environment76)
         (local.get $0)
        )
       )
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready158)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global158)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $4
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment76 2
             (local.get $2)
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (array.get $type29
         (array.get $type33
          (struct.get $environment76 1
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready61)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i32.eqz
         (global.get $ready113)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global113)
        )
       )
       (local.get $1)
      )
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment76 2
         (local.get $2)
        )
       )
      )
      (f64.sub
       (f64.const -0)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment76 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function76
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment76 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function77 (type $call71) (param $0 (ref $environment77)) (result (ref $type41))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (drop
   (call $function52
    (struct.get $type67 0
     (struct.get $type66 0
      (struct.get $environment77 0
       (local.get $0)
      )
     )
    )
    (i64.const 0)
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready76)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global76)
   )
  )
  (if (result (ref $type41))
   (f64.gt
    (struct.get $type63 0
     (struct.get $type62 1
      (struct.get $environment77 1
       (local.get $0)
      )
     )
    )
    (f64.const 0)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment77 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function55
      (struct.get $type10 1
       (struct.get $type68 1
        (struct.get $environment77 2
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready203)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (if (result (ref $type43))
     (i64.eqz
      (struct.get $type61 0
       (struct.get $type60 0
        (struct.get $environment77 3
         (local.get $0)
        )
       )
      )
     )
     (then
      (struct.new $type43
       (i32.const 1)
      )
     )
     (else
      (drop
       (call $function58
        (struct.get $type70 0
         (struct.get $type69 0
          (struct.get $environment77 4
           (local.get $0)
          )
         )
        )
        (i32.const 0)
       )
      )
      (if
       (i64.gt_u
        (local.tee $2
         (i64.sub
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment77 6
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (array.get $type12
        (struct.get $type58 0
         (struct.get $environment77 5
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (i64.sub
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment77 3
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (array.get $type12
        (struct.get $type58 0
         (struct.get $environment77 7
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (i64.sub
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment77 6
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $type58 0
        (struct.get $environment77 5
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $3)
       )
       (local.get $1)
      )
      (if
       (i64.gt_u
        (local.tee $1
         (i64.sub
          (struct.get $type61 0
           (struct.get $type60 0
            (struct.get $environment77 3
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $type58 0
        (struct.get $environment77 7
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $2)
      )
      (if
       (i32.eqz
        (struct.get $type72 0
         (struct.get $environment77 8
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function77
       (struct.get $type71 0
        (struct.get $type72 1
         (struct.get $environment77 8
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready216)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global216)
     )
    )
    (struct.new $type44
     (i32.const 2)
     (struct.new $type16
      (struct.get $type58 0
       (struct.get $environment77 7
        (local.get $0)
       )
      )
      (struct.new $type16
       (struct.get $type58 0
        (struct.get $environment77 5
         (local.get $0)
        )
       )
       (ref.null none)
      )
     )
    )
   )
  )
 )
 (func $function80 (type $16) (param $0 (ref $type33)) (param $1 i64) (param $2 i64) (param $3 i64) (result (ref $type18))
  (local $4 (ref null $type18))
  (local $5 (ref null $type18))
  (local $6 (ref $environment82))
  (local $7 (ref $type18))
  (local $8 (ref $type74))
  (local $9 (ref $type57))
  (local $10 (ref $type57))
  (local $11 (ref $type73))
  (local $12 (ref $type60))
  (local $13 (ref $type60))
  (local $14 (ref $type60))
  (local $15 (ref $type68))
  (local $16 (ref $type68))
  (local $17 (ref $type72))
  (local $18 (ref $type80))
  (local $19 (ref $type51))
  (local $20 (ref $type58))
  (local $21 (ref $type58))
  (local $22 (ref $type58))
  (local $23 (ref $type58))
  (local $24 (ref $type59))
  (local $25 (ref $type62))
  (local $26 (ref $type66))
  (local $27 (ref $type64))
  (local $28 (ref $type69))
  (local $29 (ref $type41))
  (local $30 (ref $type56))
  (local $31 (ref $type10))
  (local $32 (ref $type50))
  (local $33 (ref $type16))
  (local $34 f64)
  (local $35 i32)
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (global.get $global80)
   (ref.null none)
  )
  (if
   (i32.eqz
    (global.get $ready119)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i64.ge_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if (result i32)
       (i64.ge_s
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if (result i32)
         (i64.ge_s
          (local.get $3)
          (i64.const 0)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready125)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global125)
           )
          )
          (if
           (i32.eqz
            (global.get $ready69)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global69)
           )
          )
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (i64.add
            (i64.add
             (local.get $3)
             (i64.add
              (local.get $1)
              (local.get $2)
             )
            )
            (i64.const 2)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (local.set $20
   (struct.new $type58
    (call $function48
     (struct.get $type11 1
      (global.get $global133)
     )
     (struct.get $type57 0
      (local.tee $9
       (struct.new $type57
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (array.get $type33
            (local.get $0)
            (i32.const 0)
           )
          )
         )
         (i64.const 1)
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (local.set $22
   (struct.new $type58
    (call $function48
     (struct.get $type11 1
      (global.get $global133)
     )
     (struct.get $type57 0
      (local.tee $10
       (struct.new $type57
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 2)
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (local.set $24
   (struct.new $type59
    (call $function50
     (struct.get $type13 1
      (global.get $global141)
     )
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (local.set $21
   (struct.new $type58
    (call $function48
     (struct.get $type11 1
      (global.get $global133)
     )
     (struct.get $type57 0
      (local.get $10)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type74 1
   (local.tee $8
    (struct.new_default $type74)
   )
   (struct.new $type73
    (ref.func $function62)
    (struct.new $environment62
     (local.get $9)
     (local.get $20)
     (local.tee $23
      (struct.new $type58
       (call $function48
        (struct.get $type11 1
         (global.get $global133)
        )
        (struct.get $type57 0
         (local.get $9)
        )
       )
      )
     )
     (local.get $8)
    )
   )
  )
  (struct.set $type74 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call73
    (struct.get $type73 1
     (local.tee $11
      (ref.as_non_null
       (struct.get $type74 1
        (local.get $8)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type73 0
     (local.get $11)
    )
   )
  )
  (struct.set $type74 1
   (local.tee $8
    (struct.new_default $type74)
   )
   (struct.new $type73
    (ref.func $function63)
    (struct.new $environment63
     (local.get $10)
     (local.get $0)
     (local.get $22)
     (local.get $21)
     (local.get $9)
     (local.get $8)
    )
   )
  )
  (struct.set $type74 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call73
    (struct.get $type73 1
     (local.tee $11
      (ref.as_non_null
       (struct.get $type74 1
        (local.get $8)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type73 0
     (local.get $11)
    )
   )
  )
  (struct.set $type74 1
   (local.tee $8
    (struct.new_default $type74)
   )
   (struct.new $type73
    (ref.func $function65)
    (struct.new $environment65
     (local.get $2)
     (local.get $24)
     (local.get $8)
    )
   )
  )
  (struct.set $type74 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call73
    (struct.get $type73 1
     (local.tee $11
      (ref.as_non_null
       (struct.get $type74 1
        (local.get $8)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type73 0
     (local.get $11)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready74)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global74)
   )
  )
  (local.set $26
   (struct.new $type66
    (struct.new $type67
     (struct.new $environment52
      (local.tee $12
       (struct.new $type60
        (struct.new_default $type61)
       )
      )
      (local.get $20)
      (local.tee $25
       (struct.new $type62
        (i32.const 1)
        (struct.new_default $type63)
       )
      )
      (local.get $0)
      (local.tee $14
       (struct.new $type60
        (struct.new $type61
         (struct.get $type57 0
          (local.get $9)
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $27
   (struct.new $type64
    (i32.const 1)
    (struct.new $type65
     (i32.const 1)
    )
   )
  )
  (local.set $16
   (struct.new $type68
    (i32.const 1)
    (struct.new $type10
     (ref.func $function55)
     (struct.new $environment55
      (local.tee $13
       (struct.new $type60
        (struct.new_default $type61)
       )
      )
      (local.get $10)
      (local.get $0)
      (local.get $22)
      (local.get $12)
      (local.tee $30
       (struct.new $type56
        (f64.const 1e-06)
       )
      )
      (local.get $9)
     )
    )
   )
  )
  (local.set $28
   (struct.new $type69
    (struct.new $type70
     (struct.new $environment58
      (local.get $0)
      (local.get $13)
      (local.get $12)
      (local.get $10)
      (local.get $9)
     )
    )
   )
  )
  (if
   (i64.gt_s
    (i64.add
     (local.get $2)
     (local.get $3)
    )
    (i64.const 0)
   )
   (then
    (struct.set $type74 1
     (local.tee $8
      (struct.new_default $type74)
     )
     (struct.new $type73
      (ref.func $function66)
      (struct.new $environment66
       (local.get $9)
       (local.get $10)
       (local.get $0)
       (local.get $1)
       (local.get $8)
      )
     )
    )
    (struct.set $type74 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call73
      (struct.get $type73 1
       (local.tee $11
        (ref.as_non_null
         (struct.get $type74 1
          (local.get $8)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type73 0
       (local.get $11)
      )
     )
    )
    (struct.set $type68 1
     (local.tee $15
      (struct.new_default $type68)
     )
     (struct.new $type10
      (ref.func $function68)
      (struct.new $environment68
       (local.get $26)
       (local.get $10)
       (local.get $25)
       (local.get $30)
       (local.get $0)
       (local.get $27)
       (local.get $21)
       (local.get $13)
       (local.get $9)
       (struct.new $type64
        (i32.const 1)
        (struct.new_default $type65)
       )
       (struct.new $type57
        (i64.add
         (i64.add
          (local.get $1)
          (local.get $2)
         )
         (i64.const 1)
        )
       )
       (local.get $24)
       (local.get $1)
       (local.get $16)
       (local.get $28)
       (local.get $14)
       (local.get $12)
       (local.get $20)
       (local.get $23)
       (local.get $15)
      )
     )
    )
    (struct.set $type68 0
     (local.get $15)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (local.get $15)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call10
      (struct.get $type10 1
       (local.tee $31
        (ref.as_non_null
         (struct.get $type68 1
          (local.get $15)
         )
        )
       )
      )
      (struct.get $type10 0
       (local.get $31)
      )
     )
    )
   )
  )
  (local.set $29
   (if (result (ref $type41))
    (struct.get $type65 0
     (struct.get $type64 1
      (local.get $27)
     )
    )
    (then
     (struct.set $type72 1
      (local.tee $17
       (struct.new_default $type72)
      )
      (struct.new $type71
       (struct.new $environment77
        (local.get $26)
        (local.get $25)
        (local.get $16)
        (local.get $13)
        (local.get $28)
        (local.get $23)
        (local.get $12)
        (local.get $21)
        (local.get $17)
       )
      )
     )
     (struct.set $type72 0
      (local.get $17)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type72 0
        (local.get $17)
       )
      )
      (then
       (unreachable)
      )
     )
     (call $function77
      (struct.get $type71 0
       (struct.get $type72 1
        (local.get $17)
       )
      )
     )
    )
    (else
     (struct.new_default $type42)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type25 0
    (global.get $global80)
   )
  )
  (if
   (i32.eqz
    (global.get $ready230)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global230)
   )
  )
  (struct.set $type80 1
   (local.tee $18
    (struct.new_default $type80)
   )
   (struct.new $type79
    (struct.new $environment82
     (local.get $18)
    )
   )
  )
  (struct.set $type80 0
   (local.get $18)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type80 0
     (local.get $18)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type79 0
    (struct.get $type80 1
     (local.get $18)
    )
   )
  )
  (local.set $1
   (if (result i64)
    (ref.is_null
     (local.get $4)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $4
      (struct.get $type18 1
       (local.get $4)
      )
     )
     (if
      (i32.eqz
       (struct.get $type80 0
        (struct.get $environment82 0
         (local.get $6)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $6
      (struct.get $type79 0
       (struct.get $type80 1
        (struct.get $environment82 0
         (local.get $6)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $4
        (struct.get $type18 1
         (local.get $4)
        )
       )
       (if
        (i32.eqz
         (struct.get $type80 0
          (struct.get $environment82 0
           (local.get $6)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $6
        (struct.get $type79 0
         (struct.get $type80 1
          (struct.get $environment82 0
           (local.get $6)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $4)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $4
          (struct.get $type18 1
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (struct.get $type80 0
            (struct.get $environment82 0
             (local.get $6)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $6
          (struct.get $type79 0
           (struct.get $type80 1
            (struct.get $environment82 0
             (local.get $6)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $4)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $4
            (struct.get $type18 1
             (local.get $4)
            )
           )
           (if
            (i32.eqz
             (struct.get $type80 0
              (struct.get $environment82 0
               (local.get $6)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $6
            (struct.get $type79 0
             (struct.get $type80 1
              (struct.get $environment82 0
               (local.get $6)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $4)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $4
              (struct.get $type18 1
               (local.get $4)
              )
             )
             (if
              (i32.eqz
               (struct.get $type80 0
                (struct.get $environment82 0
                 (local.get $6)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $6
              (struct.get $type79 0
               (struct.get $type80 1
                (struct.get $environment82 0
                 (local.get $6)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $4
                (struct.get $type18 1
                 (local.get $4)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type80 0
                  (struct.get $environment82 0
                   (local.get $6)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $6
                (struct.get $type79 0
                 (struct.get $type80 1
                  (struct.get $environment82 0
                   (local.get $6)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $4
                  (struct.get $type18 1
                   (local.get $4)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type80 0
                    (struct.get $environment82 0
                     (local.get $6)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $6
                  (struct.get $type79 0
                   (struct.get $type80 1
                    (struct.get $environment82 0
                     (local.get $6)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $4
                    (struct.get $type18 1
                     (local.get $4)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type80 0
                      (struct.get $environment82 0
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $6
                    (struct.get $type79 0
                     (struct.get $type80 1
                      (struct.get $environment82 0
                       (local.get $6)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $4
                      (struct.get $type18 1
                       (local.get $4)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type80 0
                        (struct.get $environment82 0
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $6
                      (struct.get $type79 0
                       (struct.get $type80 1
                        (struct.get $environment82 0
                         (local.get $6)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (local.set $4
                        (struct.get $type18 1
                         (local.get $4)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type80 0
                          (struct.get $environment82 0
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $6
                        (struct.get $type79 0
                         (struct.get $type80 1
                          (struct.get $environment82 0
                           (local.get $6)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (local.set $4
                          (struct.get $type18 1
                           (local.get $4)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type80 0
                            (struct.get $environment82 0
                             (local.get $6)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $6
                          (struct.get $type79 0
                           (struct.get $type80 1
                            (struct.get $environment82 0
                             (local.get $6)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $4)
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (local.set $4
                            (struct.get $type18 1
                             (local.get $4)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type80 0
                              (struct.get $environment82 0
                               (local.get $6)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $6
                            (struct.get $type79 0
                             (struct.get $type80 1
                              (struct.get $environment82 0
                               (local.get $6)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (local.set $4
                              (struct.get $type18 1
                               (local.get $4)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type80 0
                                (struct.get $environment82 0
                                 (local.get $6)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $6
                              (struct.get $type79 0
                               (struct.get $type80 1
                                (struct.get $environment82 0
                                 (local.get $6)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (local.set $4
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type80 0
                                  (struct.get $environment82 0
                                   (local.get $6)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (call $function82
                                (struct.get $type79 0
                                 (struct.get $type80 1
                                  (struct.get $environment82 0
                                   (local.get $6)
                                  )
                                 )
                                )
                                (local.get $4)
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready80)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type25 0
    (global.get $global80)
   )
  )
  (if
   (i32.eqz
    (global.get $ready235)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (local.set $4
   (if (result (ref null $type18))
    (ref.is_null
     (local.get $4)
    )
    (then
     (ref.null none)
    )
    (else
     (local.set $5
      (struct.get $type18 1
       (local.get $4)
      )
     )
     (local.set $7
      (struct.new $type18
       (struct.get $type18 0
        (local.get $4)
       )
       (block (result nullref)
        (if
         (i32.eqz
          (global.get $ready235)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global235)
         )
        )
        (ref.null none)
       )
      )
     )
     (if (result (ref null $type18))
      (ref.is_null
       (local.get $5)
      )
      (then
       (local.get $7)
      )
      (else
       (local.set $4
        (struct.get $type18 1
         (local.get $5)
        )
       )
       (local.set $7
        (struct.new $type18
         (struct.get $type18 0
          (local.get $5)
         )
         (block (result (ref $type18))
          (if
           (i32.eqz
            (global.get $ready235)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global235)
           )
          )
          (local.get $7)
         )
        )
       )
       (if (result (ref null $type18))
        (ref.is_null
         (local.get $4)
        )
        (then
         (local.get $7)
        )
        (else
         (local.set $5
          (struct.get $type18 1
           (local.get $4)
          )
         )
         (local.set $7
          (struct.new $type18
           (struct.get $type18 0
            (local.get $4)
           )
           (block (result (ref $type18))
            (if
             (i32.eqz
              (global.get $ready235)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global235)
             )
            )
            (local.get $7)
           )
          )
         )
         (if (result (ref null $type18))
          (ref.is_null
           (local.get $5)
          )
          (then
           (local.get $7)
          )
          (else
           (local.set $4
            (struct.get $type18 1
             (local.get $5)
            )
           )
           (local.set $7
            (struct.new $type18
             (struct.get $type18 0
              (local.get $5)
             )
             (block (result (ref $type18))
              (if
               (i32.eqz
                (global.get $ready235)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global235)
               )
              )
              (local.get $7)
             )
            )
           )
           (if (result (ref null $type18))
            (ref.is_null
             (local.get $4)
            )
            (then
             (local.get $7)
            )
            (else
             (local.set $5
              (struct.get $type18 1
               (local.get $4)
              )
             )
             (local.set $7
              (struct.new $type18
               (struct.get $type18 0
                (local.get $4)
               )
               (block (result (ref $type18))
                (if
                 (i32.eqz
                  (global.get $ready235)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global235)
                 )
                )
                (local.get $7)
               )
              )
             )
             (if (result (ref null $type18))
              (ref.is_null
               (local.get $5)
              )
              (then
               (local.get $7)
              )
              (else
               (local.set $4
                (struct.get $type18 1
                 (local.get $5)
                )
               )
               (local.set $7
                (struct.new $type18
                 (struct.get $type18 0
                  (local.get $5)
                 )
                 (block (result (ref $type18))
                  (if
                   (i32.eqz
                    (global.get $ready235)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global235)
                   )
                  )
                  (local.get $7)
                 )
                )
               )
               (if (result (ref null $type18))
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (local.get $7)
                )
                (else
                 (local.set $5
                  (struct.get $type18 1
                   (local.get $4)
                  )
                 )
                 (local.set $7
                  (struct.new $type18
                   (struct.get $type18 0
                    (local.get $4)
                   )
                   (block (result (ref $type18))
                    (if
                     (i32.eqz
                      (global.get $ready235)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global235)
                     )
                    )
                    (local.get $7)
                   )
                  )
                 )
                 (if (result (ref null $type18))
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (local.get $7)
                  )
                  (else
                   (local.set $4
                    (struct.get $type18 1
                     (local.get $5)
                    )
                   )
                   (local.set $7
                    (struct.new $type18
                     (struct.get $type18 0
                      (local.get $5)
                     )
                     (block (result (ref $type18))
                      (if
                       (i32.eqz
                        (global.get $ready235)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global235)
                       )
                      )
                      (local.get $7)
                     )
                    )
                   )
                   (if (result (ref null $type18))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $7)
                    )
                    (else
                     (local.set $5
                      (struct.get $type18 1
                       (local.get $4)
                      )
                     )
                     (local.set $7
                      (struct.new $type18
                       (struct.get $type18 0
                        (local.get $4)
                       )
                       (block (result (ref $type18))
                        (if
                         (i32.eqz
                          (global.get $ready235)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global235)
                         )
                        )
                        (local.get $7)
                       )
                      )
                     )
                     (if (result (ref null $type18))
                      (ref.is_null
                       (local.get $5)
                      )
                      (then
                       (local.get $7)
                      )
                      (else
                       (local.set $4
                        (struct.get $type18 1
                         (local.get $5)
                        )
                       )
                       (local.set $7
                        (struct.new $type18
                         (struct.get $type18 0
                          (local.get $5)
                         )
                         (block (result (ref $type18))
                          (if
                           (i32.eqz
                            (global.get $ready235)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global235)
                           )
                          )
                          (local.get $7)
                         )
                        )
                       )
                       (if (result (ref null $type18))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $7)
                        )
                        (else
                         (local.set $5
                          (struct.get $type18 1
                           (local.get $4)
                          )
                         )
                         (local.set $7
                          (struct.new $type18
                           (struct.get $type18 0
                            (local.get $4)
                           )
                           (block (result (ref $type18))
                            (if
                             (i32.eqz
                              (global.get $ready235)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global235)
                             )
                            )
                            (local.get $7)
                           )
                          )
                         )
                         (if (result (ref null $type18))
                          (ref.is_null
                           (local.get $5)
                          )
                          (then
                           (local.get $7)
                          )
                          (else
                           (local.set $4
                            (struct.get $type18 1
                             (local.get $5)
                            )
                           )
                           (local.set $7
                            (struct.new $type18
                             (struct.get $type18 0
                              (local.get $5)
                             )
                             (block (result (ref $type18))
                              (if
                               (i32.eqz
                                (global.get $ready235)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global235)
                               )
                              )
                              (local.get $7)
                             )
                            )
                           )
                           (if (result (ref null $type18))
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (local.get $7)
                            )
                            (else
                             (local.set $5
                              (struct.get $type18 1
                               (local.get $4)
                              )
                             )
                             (local.set $7
                              (struct.new $type18
                               (struct.get $type18 0
                                (local.get $4)
                               )
                               (block (result (ref $type18))
                                (if
                                 (i32.eqz
                                  (global.get $ready235)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global235)
                                 )
                                )
                                (local.get $7)
                               )
                              )
                             )
                             (if (result (ref null $type18))
                              (ref.is_null
                               (local.get $5)
                              )
                              (then
                               (local.get $7)
                              )
                              (else
                               (local.set $4
                                (struct.get $type18 1
                                 (local.get $5)
                                )
                               )
                               (local.set $7
                                (struct.new $type18
                                 (struct.get $type18 0
                                  (local.get $5)
                                 )
                                 (block (result (ref $type18))
                                  (if
                                   (i32.eqz
                                    (global.get $ready235)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global235)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                )
                               )
                               (if (result (ref null $type18))
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (local.get $7)
                                )
                                (else
                                 (call $function83
                                  (struct.get $type18 1
                                   (local.get $4)
                                  )
                                  (struct.new $type18
                                   (struct.get $type18 0
                                    (local.get $4)
                                   )
                                   (block (result (ref $type18))
                                    (if
                                     (i32.eqz
                                      (global.get $ready235)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global235)
                                     )
                                    )
                                    (local.get $7)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (struct.set $type51 1
   (local.tee $19
    (struct.new_default $type51)
   )
   (struct.new $type50
    (ref.func $function42)
    (struct.new $environment42
     (local.get $0)
     (local.get $19)
    )
   )
  )
  (struct.set $type51 0
   (local.get $19)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $19)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (call_ref $call50
    (struct.get $type50 1
     (local.tee $32
      (ref.as_non_null
       (struct.get $type51 1
        (local.get $19)
       )
      )
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $0)
      )
     )
     (i64.const 1)
    )
    (struct.new $type18
     (f64.convert_i64_s
      (local.get $1)
     )
     (local.get $4)
    )
    (struct.get $type50 0
     (local.get $32)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready219)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global219)
   )
  )
  (if (result (ref $type18))
   (local.tee $35
    (struct.get $type41 0
     (local.get $29)
    )
   )
   (then
    (if (result (ref $type18))
     (i32.eq
      (local.get $35)
      (i32.const 1)
     )
     (then
      (struct.new $type18
       (f64.const 1)
       (local.get $4)
      )
     )
     (else
      (local.set $33
       (struct.get $type44 1
        (ref.cast (ref $type44)
         (local.get $29)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready97)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global97)
       )
      )
      (struct.new $type18
       (f64.const 2)
       (call $function37
        (local.get $33)
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (struct.new $type18
     (f64.const 0)
     (local.get $4)
    )
   )
  )
 )
 (func $function82 (type $call79) (param $0 (ref $environment82)) (param $1 (ref null $type18)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type18 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (struct.get $environment82 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function82
     (struct.get $type79 0
      (struct.get $type80 1
       (struct.get $environment82 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function83 (type $10) (param $0 (ref null $type18)) (param $1 (ref $type18)) (result (ref null $type18))
  (local $2 (ref null $type18))
  (local $3 f64)
  (if (result (ref $type18))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function83
     (struct.get $type18 1
      (local.get $0)
     )
     (struct.new $type18
      (struct.get $type18 0
       (local.get $0)
      )
      (block (result (ref $type18))
       (if
        (i32.eqz
         (global.get $ready235)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global235)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function85 (type $call82) (param $0 (ref $environment85)) (param $1 i64) (result (ref $type33))
  (local $2 (ref $type74))
  (local $3 (ref $type84))
  (local $4 (ref $type73))
  (local $5 i64)
  (if (result (ref $type33))
   (i64.eq
    (struct.get $type57 0
     (struct.get $environment85 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type81 0
     (struct.get $environment85 1
      (local.get $0)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type57 0
        (struct.get $environment85 2
         (local.get $0)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type74 1
     (local.tee $2
      (struct.new_default $type74)
     )
     (struct.new $type73
      (ref.func $function86)
      (struct.new $environment86
       (struct.get $environment85 2
        (local.get $0)
       )
       (local.tee $3
        (struct.new $type84
         (i32.const 1)
         (array.new_default $type29
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type74 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call73
      (struct.get $type73 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type74 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type73 0
       (local.get $4)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type33
     (struct.get $type81 0
      (struct.get $environment85 1
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (struct.get $type84 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (struct.get $type83 0
       (struct.get $environment85 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function85
     (struct.get $type82 0
      (struct.get $type83 1
       (struct.get $environment85 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function86 (type $call73) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment86))
  (local $3 (ref $type29))
  (local $4 f64)
  (if (result i32)
   (i64.eq
    (struct.get $type57 0
     (struct.get $environment86 0
      (ref.cast (ref $environment86)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment86)
      (local.get $0)
     )
    )
    (array.set $type29
     (struct.get $type84 1
      (struct.get $environment86 1
       (local.tee $2
        (ref.cast (ref $environment86)
         (local.get $0)
        )
       )
      )
     )
     (block (result i32)
      (local.set $4
       (call $foreign1
        (i32.const 5)
        (i64.add
         (local.get $1)
         (i64.mul
          (struct.get $environment86 2
           (local.get $2)
          )
          (struct.get $type57 0
           (struct.get $environment86 0
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment86 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function86
     (struct.get $type73 1
      (struct.get $type74 1
       (struct.get $environment86 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function88 (type $call50) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type18)) (result (ref null $type18))
  (local $3 f64)
  (if (result (ref null $type18))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign3
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment88 0
        (ref.cast (ref $environment88)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function88
     (struct.get $type50 1
      (struct.get $type51 1
       (struct.get $environment88 0
        (ref.cast (ref $environment88)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type18
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function90 (type $call35) (param $0 (ref null $type18)) (param $1 (ref null $type18)) (result i32)
  (local $2 f64)
  (local $3 f64)
  (local $4 i32)
  (local $scratch (ref null $type18))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $2
       (struct.get $type18 0
        (local.get $0)
       )
      )
      (local.set $3
       (struct.get $type18 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready256)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global256)
       )
      )
      (if (result i32)
       (if (result i32)
        (f64.eq
         (local.get $2)
         (local.get $3)
        )
        (then
         (if (result i32)
          (local.tee $4
           (f64.ne
            (local.get $2)
            (f64.const 0)
           )
          )
          (then
           (local.get $4)
          )
          (else
           (f64.eq
            (f64.div
             (f64.const 1)
             (local.get $2)
            )
            (f64.div
             (f64.const 1)
             (local.get $3)
            )
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return_call $function90
         (struct.get $type18 1
          (local.get $0)
         )
         (block (result (ref null $type18))
          (local.set $scratch
           (struct.get $type18 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready253)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global253)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type83))
  (local $2 (ref $type51))
  (local $3 (ref $type57))
  (local $4 (ref $type57))
  (local $5 (ref $type33))
  (local $6 (ref $type18))
  (local $7 (ref $type50))
  (local $8 (ref null $type18))
  (local $9 i64)
  (local $10 i64)
  (local $scratch i64)
  (local $scratch_12 (ref null $type18))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready251)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global251)
   )
  )
  (if
   (i32.eqz
    (global.get $ready238)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global238)
   )
  )
  (local.set $3
   (struct.new $type57
    (call $foreign0
     (i32.const 3)
    )
   )
  )
  (local.set $4
   (struct.new $type57
    (call $foreign0
     (i32.const 4)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (struct.get $type57 0
      (local.get $3)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type83 1
   (local.tee $1
    (struct.new_default $type83)
   )
   (struct.new $type82
    (struct.new $environment85
     (local.get $3)
     (struct.new $type81
      (array.new $type33
       (array.new_fixed $type29 0)
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
     (local.get $4)
     (local.get $1)
    )
   )
  )
  (struct.set $type83 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type83 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function90
     (call $function80
      (call $function85
       (struct.get $type82 0
        (struct.get $type83 1
         (local.get $1)
        )
       )
       (i64.const 0)
      )
      (call $foreign0
       (i32.const 0)
      )
      (call $foreign0
       (i32.const 1)
      )
      (block (result i64)
       (local.set $scratch
        (call $foreign0
         (i32.const 2)
        )
       )
       (if
        (i32.eqz
         (global.get $ready224)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global224)
        )
       )
       (local.get $scratch)
      )
     )
     (block (result (ref null $type18))
      (if
       (i32.eqz
        (global.get $ready247)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global247)
       )
      )
      (local.set $0
       (call $foreign2)
      )
      (struct.set $type51 1
       (local.tee $2
        (struct.new_default $type51)
       )
       (struct.new $type50
        (ref.func $function88)
        (struct.new $environment88
         (local.get $2)
        )
       )
      )
      (struct.set $type51 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type51 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $scratch_12
       (call_ref $call50
        (struct.get $type50 1
         (local.tee $7
          (ref.as_non_null
           (struct.get $type51 1
            (local.get $2)
           )
          )
         )
        )
        (local.get $0)
        (ref.null none)
        (struct.get $type50 0
         (local.get $7)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready253)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global253)
       )
      )
      (local.get $scratch_12)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $ready55
   (i32.const 1)
  )
  (global.set $global58
   (struct.new_default $type8)
  )
  (global.set $ready58
   (i32.const 1)
  )
  (global.set $global133
   (struct.new $type11
    (ref.func $function48)
    (ref.null none)
   )
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global141
   (struct.new $type13
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global102
   (struct.new_default $type15)
  )
  (global.set $ready102
   (i32.const 1)
  )
  (global.set $global230
   (struct.new_default $type17)
  )
  (global.set $ready230
   (i32.const 1)
  )
  (global.set $global216
   (struct.new_default $type19)
  )
  (global.set $ready216
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type20)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global63
   (struct.new_default $type20)
  )
  (global.set $ready63
   (i32.const 1)
  )
  (global.set $global65
   (struct.new_default $type21)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global69
   (struct.new_default $type22)
  )
  (global.set $ready69
   (i32.const 1)
  )
  (global.set $global74
   (struct.new_default $type23)
  )
  (global.set $ready74
   (i32.const 1)
  )
  (global.set $global76
   (struct.new_default $type24)
  )
  (global.set $ready76
   (i32.const 1)
  )
  (global.set $global187
   (struct.new_default $type24)
  )
  (global.set $ready187
   (i32.const 1)
  )
  (global.set $global203
   (struct.new_default $type23)
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type20)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global80
   (struct.new_default $type25)
  )
  (global.set $ready80
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type26)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type27)
  )
  (global.set $ready235
   (i32.const 1)
  )
  (global.set $global85
   (struct.new_default $type28)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global91
   (struct.new_default $type30)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global97
   (struct.new_default $type31)
  )
  (global.set $ready97
   (i32.const 1)
  )
  (global.set $global107
   (struct.new_default $type32)
  )
  (global.set $ready107
   (i32.const 1)
  )
  (global.set $global256
   (struct.new_default $type34)
  )
  (global.set $ready256
   (i32.const 1)
  )
  (global.set $global253
   (struct.new_default $type35)
  )
  (global.set $ready253
   (i32.const 1)
  )
  (global.set $global125
   (struct.new_default $type36)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type36)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global158
   (struct.new_default $type37)
  )
  (global.set $ready158
   (i32.const 1)
  )
  (global.set $global113
   (struct.new_default $type38)
  )
  (global.set $ready113
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type39)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type40)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global219
   (struct.new_default $type45)
  )
  (global.set $ready219
   (i32.const 1)
  )
  (global.set $global224
   (struct.new_default $type46)
  )
  (global.set $ready224
   (i32.const 1)
  )
  (global.set $global238
   (struct.new_default $type47)
  )
  (global.set $ready238
   (i32.const 1)
  )
  (global.set $global247
   (struct.new_default $type48)
  )
  (global.set $ready247
   (i32.const 1)
  )
  (global.set $global251
   (struct.new_default $type49)
  )
  (global.set $ready251
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

