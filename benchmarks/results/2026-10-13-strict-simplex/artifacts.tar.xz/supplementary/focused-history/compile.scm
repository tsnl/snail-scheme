(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-simplex-focused-20261013/program.scm" "/tmp/snail-simplex-focused-20261013/program.so"))
