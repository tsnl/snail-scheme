(import (scheme base) (scheme file) (scheme write) (srfi 1) (srfi 95)
        (except (chibi filesystem) file-exists?)
        (only (chibi string) string-prefix? string-suffix?)
        (wasm-native process) (sfir support))

;; ---- Fixed evidence, with local originals left intact ----

(define root "/tmp/snail-native-proof-evidence-20261016")
(define preparation "/tmp/sfir-native-production-six-20261016/candidate")
(define coordinator "/tmp/snail-native-shared-lto-evidence-20261016/build")
(define campaign "/tmp/sfir-native-proof-probes-paired-20261016")
(define output "/tmp/sfir-native-proof-evidence-20261016-v3")
(define files '())
(define filtered '())
(when (file-exists? output) (error "choose a new evidence directory" output))
(create-directory* output)

;; ---- Retain only the documented build and execution environment ----

(define environment-names
  '("PATH" "LANG" "LC_ALL" "TZ" "TMPDIR" "CHIBI_MODULE_PATH" "CHIBI_IGNORE_SYSTEM_PATH"
    "CC" "CXX" "AR" "AS" "LD" "NM" "RANLIB" "OBJCOPY" "OBJDUMP" "READELF" "STRIP"
    "RUSTC" "CARGO" "CARGO_HOME" "RUSTC_WRAPPER" "RUSTC_WORKSPACE_WRAPPER"
    "RUSTFLAGS" "CARGO_ENCODED_RUSTFLAGS" "CARGO_TARGET_DIR" "CARGO_BUILD_TARGET"
    "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS" "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER"
    "CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS" "CARGO_TARGET_WASM32_WASIP1_LINKER"
    "RUSTUP_HOME" "RUSTUP_TOOLCHAIN" "LD_LIBRARY_PATH" "LD_PRELOAD" "LIBRARY_PATH"
    "NIX_CC" "NIX_BINTOOLS" "NIX_LDFLAGS" "NIX_CFLAGS_COMPILE" "NIX_LD" "NIX_LD_LIBRARY_PATH"
    "NIX_ENFORCE_NO_NATIVE" "BINARYEN_CORES" "NODE_OPTIONS" "NODE_V8_COVERAGE" "SCHEMEHEAPDIRS"
    "SNAIL_NATIVE_SUPERVISOR" "SNAIL_NATIVE_LIBC" "SNAIL_NATIVE_GCC" "SNAIL_NATIVE_GC_INTERVAL"
    "SNAIL_GC_STATS" "SNAIL_GC_HEAP_BYTES" "SNAIL_GC_INITIAL_BYTES" "SNAIL_GC_MIN_BYTES"
    "SNAIL_NATIVE_CLEANUP_LOG" "SNAIL_NATIVE_TAIL_STRESS"
    "CHIBI" "NODE" "CHEZ" "WASM_OPT" "WASM_AS" "WASM_DIS" "WASM_MERGE" "LLC" "LLVM_OPT"
    "TASKSET" "LDD" "GIT" "ENV" "REALPATH" "DATE" "TIMEOUT" "CP" "SHA256SUM"))

(define (environment-entry? entry)
  (member (symbol->string (car entry)) environment-names))

(define (filter-environment value)
  (cond ((vector? value) (list->vector (map filter-environment (vector->list value))))
        ((and (pair? value) (pair? (car value)) (symbol? (caar value)))
         (map (lambda (entry)
                (cons (car entry)
                      (if (eq? (car entry) 'environment)
                          (filter environment-entry? (cdr entry))
                          (filter-environment (cdr entry))))) value))
        (else value)))

(define (retain-json source destination relative)
  (let* ((original (read-json source)) (kept (filter-environment original)))
    (if (equal? original kept) (copy-file source destination)
        (begin (write-json destination kept)
               (set! filtered (cons `((file . ,relative) (original_sha256 . ,(file-sha256 source))) filtered))))))

(define (retain source relative)
  (unless (and (file-regular? source) (not (file-link? source)))
    (error "expected an ordinary evidence file" source))
  (let ((destination (path-join output relative)))
    (create-directory* (path-directory destination))
    ;; Interrupted build traces are intentionally incomplete JSON. Preserve the
    ;; phase-event bytes, including their missing terminators, without parsing.
    (if (and (string-suffix? ".json" source) (not (string-suffix? ".trace.json" source)))
        (retain-json source destination relative)
        (copy-file source destination))
    (set! files (cons relative files))))

;; ---- Exclude caches and repeated working-directory input copies ----

(define (excluded? name)
  (member name '("." ".." ".git" "build" "target" "rust-target" "toolchain" "cargo-home"
                "runs" "inputs" "results" "evidence" "node_modules" "workload")))

(define (retain-tree source relative)
  (for-each
   (lambda (name)
     (let ((path (path-join source name)) (destination (path-join relative name)))
       (unless (or (excluded? name) (file-link? path))
         (if (file-directory? path) (retain-tree path destination)
             (when (file-regular? path) (retain path destination))))))
   (sort (directory-files source) string<?)))

(retain-tree "/tmp/sfir-native-gc-leaf-20261016" "no-gc-frames")
(retain-tree "/tmp/snail-native-finality-20261016/probe" "finality")
(retain "/tmp/snail-native-gc-leaf-20261016/wasm-native/scheme/wasm-native/llvm.sld" "source/no-gc-frames/llvm.sld")
(retain "/tmp/snail-native-finality-20261016/wasm-native/scheme/wasm-native/llvm.sld" "source/finality/llvm.sld")
(retain-tree (path-join preparation "source/wasm-native") "source/baseline/wasm-native")
(for-each (lambda (name)
            (retain-tree (path-join preparation "source/benchmarks/sfir" name) (path-join "source/benchmarks/sfir" name))
            (retain-tree (path-join preparation "timing/artifacts" name) (path-join "control-artifacts" name)))
          '("fib" "fibfp" "array1" "bv2string" "gcbench"))
(retain-tree campaign "measurement")
(retain-tree (path-join coordinator "proof-probes-run") "coordinator")
(for-each (lambda (name) (retain (path-join coordinator name) name))
          '("configure-proof-probes.scm" "observe-host.scm" "proof-probes-configuration.json" "audit-proof-probes.scm"))
(retain (path-join root "build/archive-proof.scm") "archive-proof.scm")
(retain (path-join root "build/summarize-proof.scm") "summarize-proof.scm")
(retain "/tmp/snail-native-collection-effects-review-20261016/validation.json" "product-validation/validation.json")
(retain "/tmp/snail-native-collection-effects-review-20261016/product-llvm.json" "product-validation/product-llvm.json")
(retain (path-join preparation "manifest.json") "baseline-manifest.json")
(write-json (path-join output "environment-filtering.json")
            `((policy . "Only the explicit build/runtime environment allowlist in archive-proof.scm is published. Original local records are unchanged. Host snapshots were collected with process names, never arguments. Caches, toolchain executables, repeated working directories and earlier evidence archives are omitted; their original identities remain in manifests.")
              (changed_records . ,(list->vector (reverse filtered)))))
(set! files (cons "environment-filtering.json" files))
(write-text (path-join output "evidence-files.sha256")
            (run-command! (append '("sha256sum" "--") (sort files string<?)) `((directory . ,output))))
(display (length files)) (display " retained evidence files\n")
