fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-finality-20261016/probe/semantics/attempt-1792165984376/stress.native-1105-0/module.bc");
}
