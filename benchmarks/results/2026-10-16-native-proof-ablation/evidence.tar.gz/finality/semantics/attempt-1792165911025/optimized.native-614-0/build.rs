fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-finality-20261016/probe/semantics/attempt-1792165911025/optimized.native-614-0/module.bc");
}
