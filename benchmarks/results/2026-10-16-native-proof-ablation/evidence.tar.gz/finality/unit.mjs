import {repo, env, run} from './commands.mjs';
await run(repo + '/probe/unit', 'llvm-resolver', env.CHIBI,
  ['-D', 'snail-tests', '-I', repo + '/wasm-native/scheme', '-I', repo + '/wasm-native/tests', repo + '/probe/unit.scm']);
