import {readFileSync, readdirSync, mkdirSync} from 'node:fs';
import {repo, env, sha, save, run} from './commands.mjs';
const root = repo + '/probe/semantics/attempt-' + Date.now();
mkdirSync(root, {recursive: true});
save(root + '/source.json', {base: 'f320ef2f1b160ed85b3823696d4a916ab352f0d4',
  files: Object.fromEntries(['wasm-native/scheme/wasm-native/llvm.sld', 'tests/native-subtypes.scm',
    'tests/native-runner.rs', 'tests/check-native-semantics.mjs'].map(file => [file, sha(repo + '/' + file)]))});
await run(root, 'emit', env.CHIBI, ['-I', repo + '/wasm-native/scheme', 'tests/build-native-datums.scm', root]);
if (sha(root + '/semantics.ll') !== sha(root + '/semantics-again.ll')) throw Error('Nondeterministic LLVM');
await run(root, 'assemble', env.WASM_AS, ['--mvp-features', '--enable-gc', '--enable-reference-types', '--enable-tail-call',
  '--enable-mutable-globals', '--enable-sign-ext', '--enable-bulk-memory', '--enable-nontrapping-float-to-int',
  root + '/semantics.wat', '-o', root + '/semantics.wasm']);
await run(root, 'v8', env.NODE, [repo + '/tests/check-native-semantics.mjs', root + '/semantics.wasm', root + '/saturation.json']);
const checks = [];
for (const [name, mode, file] of [['direct', '--llvm', 'semantics.ll'], ['optimized', '--wasm', 'semantics.wasm'], ['stress', '--llvm', 'semantics-stress.ll']]) {
  const program = root + '/' + name;
  await run(root, name + '-build', repo + '/scripts/build-native', [mode, '--entry-rust', repo + '/tests/native-runner.rs', root + '/' + file, program]);
  const environment = name === 'stress' ? {SNAIL_NATIVE_TAIL_STRESS: '1', SNAIL_GC_STATS: '1'} : {SNAIL_NATIVE_GC_INTERVAL: '1', SNAIL_GC_STATS: '1'};
  checks.push(await run(root, name + '-forced-gc', program, [], {environment}));
  for (let kind = 0; kind < 7; kind++) {
    const row = await run(root, name + '-finality-trap-' + kind, program, ['finality-trap', String(kind)], {status: 1, environment});
    if (!row.stderr.includes('WebAssembly trap')) throw Error('Missing native finality trap');
    checks.push(row);
  }
  const subtype = await run(root, name + '-sibling-trap', program, ['subtype-trap'], {status: 1, environment});
  if (!subtype.stderr.includes('WebAssembly trap')) throw Error('Missing native sibling trap');
  checks.push(subtype);
  if (name === 'optimized') {
    const metadata = readdirSync(root).find(name => name.startsWith('optimized.native-'));
    await run(root, 'optimized-v8', env.NODE, [repo + '/tests/check-native-semantics.mjs', root + '/' + metadata + '/optimized.wasm']);
  }
}
save(root + '/summary.json', {status: 'passed', deterministicLlvm: true, v8OriginalAndOptimized: true,
  nativeModes: ['direct', 'optimized', 'stress'], nativeTrapChecks: 24,
  fullNativeRunner: true, forcedGcInterval: 1, checks,
  hashes: Object.fromEntries(['semantics.ll', 'semantics.wasm', 'direct', 'optimized', 'stress'].map(file => [file, sha(root + '/' + file)])),
  measurement: 'correctness only; other compiler jobs may run'});
console.log('Finality semantics passed:', root);
