# Wasm final target prototype

Base: `f320ef2f1b160ed85b3823696d4a916ab352f0d4`.
Candidate worktree: `/tmp/snail-native-finality-20261016`.
Unmodified control: `/tmp/snail-native-finality-control-20261016`.

The product change is confined to `wasm-native/scheme/wasm-native/llvm.sld`.
An immutable native-type record retains the canonical header ID, composite
definition and resolved finality. Resolved `(type index definition)` is final;
the optional fourth field records explicit open/final subtype declarations.
The runtime reference-test exact flag is explicit-exact OR concrete-final.

For validated Wasm, no declaration can subtype a final concrete target. A
nonnull value belongs to that target precisely when its canonical dynamic
type equals the target's canonical identity. Finality is a declaration fact,
never inferred from an absent child, SFIR type, or current use sites.

The nullability operand, type/category tag, reference operand, call placement
and trap guard are unchanged. Null remains accepted exactly for nullable
targets. i31 keeps its inline odd-bit test and never causes header reads.
Abstract heaps never consult the concrete type table and gain no exact flag.
Explicit exact targets retain their existing behavior, including open targets.
Open parents and open leaves keep ancestry testing; final children still
retain their declared parent metadata. Parent index zero remains meaningful.

The resolver already interns ordered recursive groups including finality,
parents and within-group references. This patch does not change interning,
canonical indices, headers, parent arrays or group identity. Equal final
aliases share a canonical ID; equal-shaped open and final declarations remain
distinct. Function targets use the same rule; open function parents continue
to accept declared function subtypes through call_indirect.

No Rust runtime, SFIR typing, allocation, GC root publication, collector policy,
workload/source/input/count/predicate, provider opacity or Binaryen feature
change is part of the prototype. Mandatory Binaryen validates production Wasm
before lowering. The explicit-exact IR unit case preserves an existing lowering
contract; it does not enable the custom-descriptors proposal in production V8.

## Evidence

`unit/commands/llvm-resolver`: focused lowered-IR flags and existing canonical
resolver tests passed. Cases include default-final struct/array/function,
final child of open parent at index zero, open leaf, duplicate final aliases,
explicit exact open targets, nullable/nonnullable targets, all supported
abstract heaps and unchanged i31 inline lowering.

`semantics/attempt-1792165984376/summary.json`: original and optimized V8,
direct native LLVM, optimized native shared LTO and native stress lowering all
passed. Native direct/optimized used GC interval one; stress lowering collected
at call boundaries. Existing runner checks managed root survival and recursive
type aliases. New checks cover equal-shaped open/final identities, nullable
struct/array/function casts, wrong-kind/i31 rejection, bottom/abstract heaps,
open function parent acceptance and final function call_indirect rejection.
There were 24 successful expected-trap checks across the three native modes.
The respective successful runs collected 40547, 30 and 88071 times.

`extra-checks/summary.json`: the actual native harness module imports and 56
existing general, array storage and invalid-array-access trap checks passed
against direct and optimized binaries with GC interval one.

`pairs/arms.json`, `pairs/validation.json` and per-case `work-retention.json`:
fresh uninstrumented production shared-LTO control/treatment pairs for
bv2string and gcbench. Raw and optimized Wasm, full benchmark predicate,
provider, entry, config and input match the immutable f320 production freeze.
Control LLVM is byte-identical to the production artifact. Every differing
LLVM line changes only exact 0 to 1 for a proven final target: 12 calls for
bv2string, 17 for gcbench. All non-time collector counters match between arms.
The first predicate runs enabled GC statistics and are diagnostic only; other
compiler jobs could run. No clean paired measurement has been performed here.

## Retained preparation failures

- Semantics attempt `1792165858059`: fixture parenthesis error; corrected before
  any successful assembly/execution.
- Semantics attempt `1792165889283`: private driver used `--all-features`, which
  enabled custom-descriptor exact refs unsupported by default V8. The driver
  now uses the repository's exact production Binaryen feature list.
- Pair coordinator first attempt: it compared mark_s/sweep_s timers alongside
  counters. Both workload predicates had passed. The checker now compares all
  non-time fields and retains raw timing fields separately.
- Pair coordinator second attempt: gcbench's intended diagnostic stdout prefix
  preceded the JSON record. The checker now parses the final complete JSON line.
  The guest had exited zero. Existing ELF files were retained without rebuild.

Every command, stdout, stderr and terminal status remains under its command
attempt directory. No failed attempt is removed or relabeled.

## Review boundary

A local behavioral review finds that the three immutable fields directly
represent the facts emission needs. The existing exhaustive reference-test
dispatch remains one operation; its extra lines keep nullability, explicit
exactness and abstract categories visible together. Test fixtures deliberately
exceed ten lines to keep the type/case matrices readable.

The pinned simplify skill was read. Its independent fresh-explainer pass is
reserved for the parent's Astra cleanup/review after measurement; all four
team slots were occupied during prototype completion. This local review is
not presented as an independent review. No broader cleanup was attempted.
