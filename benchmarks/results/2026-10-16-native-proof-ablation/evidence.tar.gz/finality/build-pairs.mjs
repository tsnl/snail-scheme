import {readFileSync, writeFileSync, readdirSync, mkdirSync, copyFileSync, existsSync} from 'node:fs';
import {repo, freeze, env, sha, save, run} from './commands.mjs';
const root = repo + '/probe/pairs';
const control = '/tmp/snail-native-finality-control-20261016';
const base = 'f320ef2f1b160ed85b3823696d4a916ab352f0d4';
const files = ['program.wasm.raw.wasm', 'program.wasm', 'spec.json', 'input.txt',
  'scalar-provider.rs', 'scalar-timing-entry.rs', 'case-config.rs'];
mkdirSync(root, {recursive: true});
if (existsSync(root + '/arms.json')) throw Error('Frozen pair already complete; do not rebuild');
copyFileSync('/tmp/snail-native-allocator-20261016/probe/lto-final-target/dump-final-types.scm', root + '/dump-final-types.scm');
const arms = existsSync(root + '/arms-in-progress.json') ? JSON.parse(readFileSync(root + '/arms-in-progress.json')) : [];
const evidence = [];
function gcCounters(text) {
  return Object.fromEntries([...text.matchAll(/([a-z_]+)=([^\s]+)/g)]
    .filter(([, key]) => !['mark_s', 'sweep_s'].includes(key)).map(([, key, value]) => [key, value]));
}
function proveFlags(before, after, types) {
  const lines = before.split('\n'), candidate = after.split('\n'), changes = [];
  if (lines.length !== candidate.length) throw Error('LLVM line count changed');
  for (let index = 0; index < lines.length; index++) {
    if (lines[index] === candidate[index]) continue;
    const old = lines[index].match(/^(.*@native_ref_test\(i64 .*?, i64 (-?\d+), i32 ([01]), i32 )([01])(\).*)$/);
    const now = candidate[index].match(/^(.*@native_ref_test\(i64 .*?, i64 (-?\d+), i32 ([01]), i32 )([01])(\).*)$/);
    if (!old || !now || old[1] !== now[1] || old[5] !== now[5] || old[4] !== '0' || now[4] !== '1')
      throw Error('LLVM changed beyond exact flag at line ' + (index + 1));
    const type = types.find(row => row.tag === Number(old[2]));
    if (!type?.final) throw Error('Exact test introduced for non-final/abstract target');
    changes.push({line: index + 1, tag: type.tag, nullable: Number(old[3]), canonicalType: type.index});
  }
  return {changes, onlyFinalExactFlagsChanged: true, allOtherLinesIdentical: true};
}
for (const name of ['bv2string', 'gcbench']) {
  const output = root + '/' + name, source = freeze + '/timing/artifacts/' + name;
  mkdirSync(output, {recursive: true});
  const inputs = Object.fromEntries(files.map(file => [file, sha(source + '/' + file)]));
  const sourceHashes = Object.fromEntries(['src/native.rs', 'src/native_gc.rs', 'scripts/rustc-native', 'scheme/wasm-native/wasm-resolve.sld']
    .map(file => [file, sha(control + '/wasm-native/' + file)]));
  for (const [file, hash] of Object.entries(sourceHashes)) {
    if (hash !== sha(repo + '/wasm-native/' + file) || hash !== sha(freeze + '/source/wasm-native/' + file))
      throw Error('Runtime/resolver/tooling source differs: ' + file);
  }
  for (const [arm, tree] of [['control', control], ['finality', repo]]) {
    const directory = output + '/' + arm;
    const retained = arms.find(row => row.case === name && row.arm === arm);
    if (retained) {
      if (sha(retained.program) !== retained.sha256 || sha(retained.metadata + '/module.ll') !== retained.guestLlvmSha256 ||
          sha(tree + '/wasm-native/scheme/wasm-native/llvm.sld') !== retained.llvmSourceSha256)
        throw Error('Retained frozen arm/source changed');
      for (const file of files) if (sha(directory + '/' + file) !== inputs[file]) throw Error('Retained input changed');
      console.log('Retaining existing immutable arm:', name, arm, retained.sha256);
      continue;
    }
    mkdirSync(directory);
    for (const file of files) copyFileSync(source + '/' + file, directory + '/' + file);
    for (const file of files) if (sha(directory + '/' + file) !== inputs[file]) throw Error('Copied input mismatch');
    const program = directory + '/program';
    await run(output, arm + '-build', tree + '/scripts/build-native', ['--wasm', '--entry-rust', directory + '/scalar-timing-entry.rs',
      '--rust-provider', 'benchmark', directory + '/scalar-provider.rs', directory + '/program.wasm.raw.wasm', program],
      {cwd: directory, environment: {RUSTC_WRAPPER: tree + '/wasm-native/scripts/rustc-native'}});
    const metadata = directory + '/' + readdirSync(directory).find(file => file.startsWith('program.native-'));
    if (sha(metadata + '/optimized.wasm') !== inputs['program.wasm']) throw Error('Native/V8 optimized Wasm mismatch');
    if (!readFileSync(metadata + '/Cargo.toml', 'utf8').includes('lto = true') ||
        !readFileSync(metadata + '/build.rs', 'utf8').includes('/module.bc')) throw Error('Missing shared guest/runtime LTO');
    const row = {case: name, arm, program, sha256: sha(program), metadata, base, inputs,
      uninstrumentedRuntime: true, sharedGuestRuntimeLto: true, runtimeResolverHashes: sourceHashes,
      llvmSourceSha256: sha(tree + '/wasm-native/scheme/wasm-native/llvm.sld'),
      guestLlvmSha256: sha(metadata + '/module.ll'), guestBitcodeSha256: sha(metadata + '/module.bc')};
    arms.push(row); save(root + '/arms-in-progress.json', arms);
  }
  const matched = arms.filter(row => row.case === name);
  await run(output, 'resolved-final-types', env.CHIBI, ['-I', repo + '/wasm-native/scheme', root + '/dump-final-types.scm',
    matched[1].metadata + '/optimized.wat', output + '/reader.scm', output + '/types.json']);
  const proof = proveFlags(readFileSync(matched[0].metadata + '/module.ll', 'utf8'),
    readFileSync(matched[1].metadata + '/module.ll', 'utf8'), JSON.parse(readFileSync(output + '/types.json')));
  const frozenMetadata = readdirSync(source).find(file => file.startsWith('program.native.native-'));
  if (sha(matched[0].metadata + '/module.ll') !== sha(source + '/' + frozenMetadata + '/module.ll'))
    throw Error('Control LLVM differs from production freeze');
  save(output + '/work-retention.json', {...proof, productionControlLlvmIdentical: true, sourceRoute: 'sfir-native',
    spec: JSON.parse(readFileSync(source + '/spec.json')), inputs, unchangedRuntimeAndResolver: sourceHashes});
  for (const row of matched) {
    const check = await run(output, row.arm + '-predicate-and-counters', env.TASKSET, ['-c', '2', row.program],
      {input: source + '/input.txt', environment: {SNAIL_GC_STATS: '1'}});
    const result = JSON.parse(check.stdout.trimEnd().split('\n').at(-1));
    if (result.result !== '1') throw Error('Full native predicate failed');
    evidence.push({case: name, arm: row.arm, result, gc: check.stderr, counters: gcCounters(check.stderr), directory: check.directory});
  }
  const checks = evidence.filter(row => row.case === name);
  if (JSON.stringify(checks[0].counters) !== JSON.stringify(checks[1].counters)) throw Error('GC counters changed');
  await run(output, 'v8-full-predicate', env.TASKSET, ['-c', '2', env.NODE, '--no-warnings',
    freeze + '/source/benchmarks/sfir/support/scalar-host.mjs', output + '/control/program.wasm',
    output + '/control/spec.json', '--timing'], {input: source + '/input.txt'});
}
save(root + '/arms.json', arms);
save(root + '/validation.json', {status: 'passed', evidence, allGcCountersIdentical: true,
  completePredicates: true, nativeV8OptimizedWasmIdentical: true,
  timingStatus: 'diagnostic predicate runs only; other compiler jobs may run; clean comparison not started'});
console.log('Frozen finality pairs ready:', root);
