import {readFileSync, writeFileSync, mkdirSync, copyFileSync, openSync, closeSync, existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
export const repo = '/tmp/snail-native-finality-20261016';
export const freeze = '/tmp/sfir-native-production-six-20261016/candidate';
const original = JSON.parse(readFileSync(freeze + '/timing/artifacts/bv2string/commands/native-build/record.json'));
export const env = {...process.env};
for (const [key, value] of Object.entries(original.environment)) {
  if (value === null) delete env[key]; else env[key] = value;
}
env.CARGO_HOME = repo + '/probe/cargo-home';
env.RUSTC_WRAPPER = repo + '/wasm-native/scripts/rustc-native';
mkdirSync(env.CARGO_HOME, {recursive: true});
if (!existsSync(env.CARGO_HOME + '/config.toml'))
  copyFileSync(freeze + '/toolchain/cargo-home/config.toml', env.CARGO_HOME + '/config.toml');
export const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
export const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
export async function run(root, label, command, args, options = {}) {
  const prefix = root + '/commands/' + label;
  let directory = prefix;
  for (let index = 1; existsSync(directory); index++) directory = prefix + '-attempt-' + index;
  mkdirSync(directory, {recursive: true});
  const active = {...env, ...options.environment};
  const cwd = options.cwd ?? repo;
  const environment = Object.fromEntries(Object.keys(original.environment).map(key => [key, active[key] ?? null]));
  save(directory + '/command.json', {command: [command, ...args], cwd, environment,
    environmentScope: 'Explicit production toolchain/runtime controls; unrelated inherited variables omitted.'});
  const descriptors = [openSync(directory + '/stdout', 'w'), openSync(directory + '/stderr', 'w')];
  const input = options.input ? openSync(options.input, 'r') : 'ignore';
  const started = new Date().toISOString();
  console.log(started, label, 'started');
  const child = spawn(command, args, {cwd, env: active, stdio: [input, ...descriptors]});
  save(directory + '/process.json', {started, pid: child.pid});
  const terminal = await new Promise(resolve => {
    child.once('error', error => resolve({status: null, error: error.message}));
    child.once('close', (status, signal) => resolve({status, signal}));
  });
  for (const descriptor of descriptors) closeSync(descriptor);
  if (typeof input === 'number') closeSync(input);
  const row = {label, directory, started, finished: new Date().toISOString(), ...terminal};
  save(directory + '/terminal.json', row);
  console.log(row.finished, label, terminal.status);
  if (terminal.status !== (options.status ?? 0)) throw Error('Unexpected command status: ' + JSON.stringify(row));
  return {...row, stdout: readFileSync(directory + '/stdout', 'utf8'), stderr: readFileSync(directory + '/stderr', 'utf8')};
}
