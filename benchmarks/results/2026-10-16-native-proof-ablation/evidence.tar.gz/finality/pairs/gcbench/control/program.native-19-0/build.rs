fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-finality-20261016/probe/pairs/gcbench/control/program.native-19-0/module.bc");
}
