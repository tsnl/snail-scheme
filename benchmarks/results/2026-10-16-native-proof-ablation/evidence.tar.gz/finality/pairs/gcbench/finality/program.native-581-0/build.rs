fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-finality-20261016/probe/pairs/gcbench/finality/program.native-581-0/module.bc");
}
