fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-finality-20261016/probe/pairs/bv2string/finality/program.native-647-0/module.bc");
}
