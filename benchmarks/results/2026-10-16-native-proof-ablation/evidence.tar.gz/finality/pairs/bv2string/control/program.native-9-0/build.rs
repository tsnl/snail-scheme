fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-finality-20261016/probe/pairs/bv2string/control/program.native-9-0/module.bc");
}
