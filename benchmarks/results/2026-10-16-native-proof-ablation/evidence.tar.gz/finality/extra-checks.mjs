import {repo, env, save, run} from './commands.mjs';
const root = repo + '/probe/extra-checks';
const semantics = repo + '/probe/semantics/attempt-1792165984376';
await run(root, 'harness-import', env.CHIBI, ['-I', repo + '/src', '-I', repo + '/wasm-native/scheme',
  '-I', repo + '/tests', '-I', repo + '/wasm-native/tests', '-e', '(import (snail-tests native))']);
const checks = [];
for (const name of ['direct', 'optimized']) {
  const program = semantics + '/' + name;
  const cases = [
    ...Array.from({length: 13}, (_, kind) => [String(kind)]),
    ...Array.from({length: 5}, (_, kind) => ['storage-trap', String(kind)]),
    ...[['null', [0, 1, 2]], ['i31', [0, 1, 2]], ['empty', [1, 2]], ['upper', [1, 2]]]
      .flatMap(([kind, operations]) => operations.map(operation => ['storage-access-trap', kind, String(operation)]))];
  for (const [index, args] of cases.entries()) {
    const row = await run(root, name + '-existing-trap-' + index, program, args,
      {status: 1, environment: {SNAIL_NATIVE_GC_INTERVAL: '1'}});
    if (!row.stderr.includes('WebAssembly trap')) throw Error('Missing expected native trap');
    checks.push({name, args, directory: row.directory});
  }
}
save(root + '/summary.json', {status: 'passed', harnessImports: true, existingTrapChecks: checks.length, checks});
console.log('Existing native trap checks passed:', checks.length);
