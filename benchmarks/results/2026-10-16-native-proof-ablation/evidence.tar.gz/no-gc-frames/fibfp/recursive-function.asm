000000000007c700 <f.4>:
   7c700: 48 83 ec 18                  	subq	$0x18, %rsp
   7c704: 66 0f 28 c8                  	movapd	%xmm0, %xmm1
   7c708: f2 0f 10 05 e8 8f f8 ff      	movsd	-0x77018(%rip), %xmm0   # 0x56f8 <writev+0x56f8>
   7c710: 66 0f 2e c1                  	ucomisd	%xmm1, %xmm0
   7c714: 77 68                        	ja	0x7c77e <f.4+0x7e>
   7c716: 80 3d 53 4e 00 00 00         	cmpb	$0x0, 0x4e53(%rip)      # 0x81570 <g.4>
   7c71d: 74 6a                        	je	0x7c789 <f.4+0x89>
   7c71f: 48 83 3d 41 4e 00 00 00      	cmpq	$0x0, 0x4e41(%rip)      # 0x81568 <g.3>
   7c727: 74 60                        	je	0x7c789 <f.4+0x89>
   7c729: f2 0f 10 05 bf 8f f8 ff      	movsd	-0x77041(%rip), %xmm0   # 0x56f0 <writev+0x56f0>
   7c731: f2 0f 11 4c 24 10            	movsd	%xmm1, 0x10(%rsp)
   7c737: f2 0f 58 c1                  	addsd	%xmm1, %xmm0
   7c73b: e8 c0 ff ff ff               	callq	0x7c700 <f.4>
   7c740: 48 83 ec 08                  	subq	$0x8, %rsp
   7c744: 80 3d 25 4e 00 00 00         	cmpb	$0x0, 0x4e25(%rip)      # 0x81570 <g.4>
   7c74b: 74 3c                        	je	0x7c789 <f.4+0x89>
   7c74d: f2 0f 11 44 24 08            	movsd	%xmm0, 0x8(%rsp)
   7c753: 48 83 3d 0d 4e 00 00 00      	cmpq	$0x0, 0x4e0d(%rip)      # 0x81568 <g.3>
   7c75b: 74 2c                        	je	0x7c789 <f.4+0x89>
   7c75d: f2 0f 10 44 24 10            	movsd	0x10(%rsp), %xmm0
   7c763: f2 0f 58 05 9d 8f f8 ff      	addsd	-0x77063(%rip), %xmm0   # 0x5708 <writev+0x5708>
   7c76b: e8 90 ff ff ff               	callq	0x7c700 <f.4>
   7c770: 48 83 ec 08                  	subq	$0x8, %rsp
   7c774: f2 0f 10 4c 24 08            	movsd	0x8(%rsp), %xmm1
   7c77a: f2 0f 58 c8                  	addsd	%xmm0, %xmm1
   7c77e: 66 0f 28 c1                  	movapd	%xmm1, %xmm0
   7c782: 48 83 c4 18                  	addq	$0x18, %rsp
   7c786: c2 08 00                     	retq	$0x8
   7c789: e8 52 77 fd ff               	callq	0x53ee0 <native_trap>
   7c78e: cc                           	int3
   7c78f: cc                           	int3
