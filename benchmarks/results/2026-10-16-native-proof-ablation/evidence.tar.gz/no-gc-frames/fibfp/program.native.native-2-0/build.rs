fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/fibfp/program.native.native-2-0/module.bc");
}
