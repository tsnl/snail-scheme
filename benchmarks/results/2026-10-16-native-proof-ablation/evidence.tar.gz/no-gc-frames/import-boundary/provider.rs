unsafe extern "C" {
    fn native_gc_collect();
}

#[unsafe(export_name = "collect")]
pub extern "C" fn collect() {
    unsafe { native_gc_collect() };
}
