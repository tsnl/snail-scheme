fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/import-boundary/probe.native.native-2-0/module.bc");
}
