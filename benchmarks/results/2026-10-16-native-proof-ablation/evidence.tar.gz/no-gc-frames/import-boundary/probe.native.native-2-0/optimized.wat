(module
 (type $0 (struct))
 (type $1 (func))
 (type $2 (func (result i64)))
 (import "probe" "collect" (func $fimport$0))
 (global $global$0 (mut (ref null $0)) (ref.null none))
 (export "main" (func $0))
 (func $0 (result i64)
  (global.set $global$0
   (struct.new_default $0)
  )
  (drop
   (ref.as_non_null
    (global.get $global$0)
   )
  )
  (global.set $global$0
   (ref.null none)
  )
  (call $fimport$0)
  (i64.const 42)
 )
)

