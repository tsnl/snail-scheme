unsafe extern "C" {
    fn native_module_init();
    #[link_name = "wasm.main"]
    fn guest_main() -> u64;
}

fn main() {
    snail_runtime::native::initialize_host();
    unsafe {
        native_module_init();
        assert_eq!(guest_main(), 42);
        assert!(snail_runtime::native::native_gc_collections() > 0);
        assert!(snail_runtime::native::native_roots.is_null());
    }
}

extern crate snail_runtime as _;
extern crate wasm_native_3c756847486941432d09c8155cdcbb8bd66d6f9dc6f69ae0990218334997104d_provider_0 as _;
