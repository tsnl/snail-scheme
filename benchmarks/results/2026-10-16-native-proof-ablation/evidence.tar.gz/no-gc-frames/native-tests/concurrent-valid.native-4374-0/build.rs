fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/native-tests/concurrent-valid.native-4374-0/module.bc");
}
