;; Native executables keep guest LLVM bitcode visible to Rust's final LTO link.
(define-library (wasm-native native-build)
  (export rust-bindings runtime-bindings check-provider-bindings
          llvm-bitcode llvm-object link-native-object native-cargo-environment native-system-environment
          ensure-native-supervisor native-rustc-main
          rust-source-inputs source-hashes check-stable-inputs native-evidence)
  (import (scheme base) (scheme char) (scheme cxr) (scheme file) (scheme read)
          (scheme write) (scheme process-context) (chibi filesystem) (chibi pathname)
          (only (chibi process) current-process-id execute)
          (only (chibi crypto sha2) sha-256)
          (chibi string) (chibi regexp) (wasm-native json) (srfi 1) (srfi 95) (srfi 151)
          (wasm-native process))
  (begin

    ;; ---- Scalar declarations read from the compiled Rust sources ----

    (define rust-export
      (rx "#" (* space) "[" (* space) "unsafe" (* space) "(" (* space) "export_name"
          (* space) "=" (* space) "\"" ($ (+ (~ #\"))) "\"" (* space) ")" (* space) "]"
          (* space) "pub" (+ space) (? "unsafe" (+ space)) "extern" (+ space) "\"C\"" (+ space)
          "fn" (+ space) ($ (+ (or alpha numeric "_"))) (* space)
          "(" ($ (* (~ #\)))) ")" (* space) (? "->" (* space) ($ (+ (or alpha numeric "_"))))
          (* space) "{"))
    (define (text-at? text offset fragment)
      (let ((end (+ offset (string-length fragment))))
        (and (<= end (vector-length text))
             (let loop ((index offset))
               (or (= index end) (and (char=? (vector-ref text index) (string-ref fragment (- index offset))) (loop (+ index 1))))))))
    (define (rust-export-marker? characters offset)
      (let loop ((offset offset) (tokens '("#" "[" "unsafe" "(" "export_name")))
        (cond ((null? tokens) #t)
              ((and (< offset (vector-length characters)) (char-whitespace? (vector-ref characters offset)))
               (loop (+ offset 1) tokens))
              ((text-at? characters offset (car tokens)) (loop (+ offset (string-length (car tokens))) (cdr tokens)))
              (else #f))))
    (define (quoted-end text offset delimiter)
      (let loop ((index (+ offset 1)))
        (cond ((>= index (vector-length text)) (error "unterminated Rust literal"))
              ((char=? (vector-ref text index) #\\) (loop (+ index 2)))
              ((char=? (vector-ref text index) delimiter) (+ index 1))
              (else (loop (+ index 1))))))
    (define (block-comment-end text offset)
      (let loop ((index (+ offset 2)) (depth 1))
        (cond ((>= index (vector-length text)) (error "unterminated Rust block comment"))
              ((text-at? text index "/*") (loop (+ index 2) (+ depth 1)))
              ((text-at? text index "*/") (if (= depth 1) (+ index 2) (loop (+ index 2) (- depth 1))))
              (else (loop (+ index 1) depth)))))
    (define (line-comment-end text offset)
      (let loop ((index offset))
        (if (or (= index (vector-length text)) (char=? (vector-ref text index) #\newline)) index
            (loop (+ index 1)))))
    (define (raw-string-end text offset)
      (and (char=? (vector-ref text offset) #\r)
           (let hashes ((index (+ offset 1)))
             (cond ((= index (vector-length text)) #f)
                   ((char=? (vector-ref text index) #\#) (hashes (+ index 1)))
                   ((char=? (vector-ref text index) #\")
                    (let ((end (string-append "\"" (make-string (- index offset 1) #\#))))
                      (let loop ((position (+ index 1)))
                        (cond ((>= position (vector-length text)) (error "unterminated Rust raw string"))
                              ((text-at? text position end) (+ position (string-length end)))
                              (else (loop (+ position 1)))))))
                   (else #f)))))
    (define (character-literal? text offset)
      (and (text-at? text offset "'") (< (+ offset 2) (vector-length text))
           (or (char=? (vector-ref text (+ offset 1)) #\\) (char=? (vector-ref text (+ offset 2)) #\'))))
    (define (blank-region! text start end)
      (do ((index start (+ index 1))) ((= index end))
        (unless (char=? (vector-ref text index) #\newline) (vector-set! text index #\space))))
    (define (rust-source-masks text)
      ;; Keep offsets identical in both masks. One excludes comments, while the
      ;; other also excludes literals so documentation cannot declare an ABI.
      (let* ((text (list->vector (string->list text))) (comments (vector-copy text)) (code (vector-copy text)))
        (let loop ((offset 0))
          (if (= offset (vector-length text)) (cons (list->string (vector->list comments)) (list->string (vector->list code)))
              (let* ((comment? (or (text-at? text offset "//") (text-at? text offset "/*")))
                     (end (cond ((text-at? text offset "//") (line-comment-end text offset))
                                ((text-at? text offset "/*") (block-comment-end text offset))
                                ((char=? (vector-ref text offset) #\") (quoted-end text offset #\"))
                                ((character-literal? text offset) (quoted-end text offset #\'))
                                (else (raw-string-end text offset)))))
                (when end (blank-region! code offset end) (when comment? (blank-region! comments offset end)))
                (loop (or end (+ offset 1))))))))
    (define (physical-type spelling)
      (cond ((member spelling '("i32" "u32")) 'i32)
            ((member spelling '("i64" "u64")) 'i64)
            ((string=? spelling "f32") 'f32) ((string=? spelling "f64") 'f64)
            ((string=? spelling "") 'void)
            (else (error "unsupported native Rust scalar type" spelling))))
    (define (parameter-type text)
      (let ((parts (string-split (string-trim text char-whitespace?) #\:)))
        (unless (= 2 (length parts)) (error "unsupported Rust parameter declaration" text))
        (physical-type (string-trim (cadr parts) char-whitespace?))))
    (define (export-binding module match)
      (let* ((name (regexp-match-submatch match 1))
             (parameters (filter (lambda (part) (not (string=? "" (string-trim part char-whitespace?))))
                                 (string-split (regexp-match-submatch match 3) #\,)))
             (result (physical-type (or (regexp-match-submatch match 4) ""))))
        (list (list module name) name (map parameter-type parameters)
              (if (eq? result 'void) '() (list result)))))
    (define (rust-source-bindings module text)
      (let* ((masks (rust-source-masks text)) (comments (car masks)) (code (cdr masks))
             (characters (list->vector (string->list code))))
        (let loop ((offset 0) (depth 0) (bindings '()))
          (if (= offset (vector-length characters)) (reverse bindings)
              (let* ((character (vector-ref characters offset))
                     (marker (and (char=? character #\#) (rust-export-marker? characters offset))))
                (if marker
                    (let ((match (regexp-search rust-export comments offset)))
                      (unless (and (zero? depth) match (= offset (regexp-match-submatch-start match 0)))
                        (error "unsupported Rust export declaration syntax"))
                      (let ((binding (export-binding module match)))
                        (loop (regexp-match-submatch-end match 0) 1 (if binding (cons binding bindings) bindings))))
                    (loop (+ offset 1) (+ depth (cond ((char=? character #\{) 1) ((char=? character #\}) -1) (else 0))) bindings)))))))
    (define (rust-bindings module source) (rust-source-bindings module (read-text source)))
    (define (runtime-bindings root)
      ;; These files declare this runtime's scalar ABI. Its memory32 diagnostic
      ;; export in lib.rs has pointers, so it is not a native scalar provider.
      (append-map (lambda (path) (rust-bindings "snail.library" path))
                  (map (lambda (name) (path-join root "src" name))
                       '("strict_datum.rs" "strict_io.rs" "strict_math.rs" "strict_text.rs"))))
    (define (check-provider-bindings required declarations)
      (let loop ((items declarations) (keys '()))
        (unless (null? items)
          (when (member (caar items) keys) (error "duplicate native provider declaration" (caar items)))
          (loop (cdr items) (cons (caar items) keys))))
      (for-each
       (lambda (wanted)
         (let ((actual (assoc (car wanted) declarations)))
           (unless actual (error "missing native provider" (car wanted)))
           (unless (equal? actual wanted) (error "native provider signature or symbol mismatch" (car wanted)))))
       required))

    ;; ---- Optimized bitcode and saved machine objects ----

    (define native-target "x86_64-unknown-linux-gnu")

    (define (llvm-bitcode input output)
      (run-command! (list (tool-name "LLVM_OPT" "opt") "-passes=default<O3>" input "-o" output))
      output)

    (define (llvm-object input output)
      (let ((optimized (llvm-bitcode input (string-append output ".bc"))))
        (run-command! (list (tool-name "LLC" "llc") "-O=3" (string-append "-mtriple=" native-target)
                            "-relocation-model=pic" "-function-sections" "-data-sections"
                            "-filetype=obj" optimized "-o" output))
        output))

    ;; ---- Rust's linker and the host's Linux runtime libraries ----

    (define (first-existing paths name)
      (or (find (lambda (directory) (file-exists? (path-join directory name))) paths)
          (error "missing native system library; set SNAIL_NATIVE_LIBC or SNAIL_NATIVE_GCC" name)))
    (define (nix-support name)
      (let ((compiler (get-environment-variable "NIX_CC")))
        (and compiler
             (let ((path (path-join compiler "nix-support" name)))
               (and (file-exists? path) (string-trim (read-text path) char-whitespace?))))))
    (define (libc-directory)
      (first-existing
       (filter string? (list (get-environment-variable "SNAIL_NATIVE_LIBC")
                             (and (nix-support "orig-libc") (path-join (nix-support "orig-libc") "lib"))
                             "/usr/lib/x86_64-linux-gnu" "/usr/lib64" "/usr/lib")) "Scrt1.o"))
    (define (gcc-directory)
      (first-existing
       (append (filter string? (list (get-environment-variable "SNAIL_NATIVE_GCC")))
               (map (lambda (word) (substring word 2 (string-length word)))
                    (filter (lambda (word) (string-prefix? "-L" word))
                            (string-split (or (nix-support "cc-ldflags") "") char-whitespace?)))
               '("/lib/x86_64-linux-gnu" "/usr/lib/x86_64-linux-gnu" "/lib64" "/usr/lib64"))
       "libgcc_s.so.1"))
    (define (native-linker-flags directory)
      (let* ((libc (libc-directory)) (gcc (gcc-directory)) (links (path-join directory "system-libraries")))
        (create-directory* links)
        (unless (file-exists? (path-join links "libgcc_s.so"))
          (symbolic-link-file (path-join gcc "libgcc_s.so.1") (path-join links "libgcc_s.so")))
        (append '("-C" "linker=rust-lld" "-C" "linker-flavor=ld.lld")
                (list "-L" (string-append "native=" links) "-L" (string-append "native=" libc))
                (append-map (lambda (argument) (list "-C" (string-append "link-arg=" argument)))
                            (list (path-join libc "Scrt1.o") (path-join libc "crti.o") (path-join libc "crtn.o")
                                  (string-append "--dynamic-linker=" (path-join libc "ld-linux-x86-64.so.2"))
                                  (string-append "-rpath=" libc) (string-append "-rpath=" gcc))))))
    (define (native-cargo-environment directory)
      (let ((flags (native-linker-flags directory)))
        (list (cons "CARGO_ENCODED_RUSTFLAGS" (string-join flags (string (integer->char 31)))))))
    (define (native-lto-environment root)
      (let ((flags (append (native-linker-flags (path-join root "build/native-runtime"))
                           '("-C" "linker-plugin-lto" "-C" "lto=fat"))))
        (list (cons "CARGO_ENCODED_RUSTFLAGS" (string-join flags (string (integer->char 31))))
              (cons "RUSTC_WRAPPER" (tool-name "RUSTC_WRAPPER" (path-join root "scripts/rustc-native"))))))
    (define (native-system-environment)
      (list (cons "SNAIL_NATIVE_LIBC" (libc-directory)) (cons "SNAIL_NATIVE_GCC" (gcc-directory))))
    (define (rustc-target arguments)
      (cond ((null? arguments) #f)
            ((string=? (car arguments) "--target") (if (pair? (cdr arguments)) (cadr arguments) 'missing))
            ((string-prefix? "--target=" (car arguments)) (substring (car arguments) 9))
            (else (rustc-target (cdr arguments)))))
    (define (needs-native-linker? arguments)
      (let ((target (rustc-target arguments)))
        (and (or (not target) (equal? target native-target))
             (not (any (lambda (argument) (or (string-prefix? "linker=" argument) (string-prefix? "-Clinker=" argument))) arguments)))))
    (define (native-rustc-main root arguments)
      ;; Cargo passes its chosen compiler as argv[0]. Host build scripts also
      ;; need a native linker during cross compilation, when Cargo intentionally
      ;; excludes target rustflags. Explicit target/linker choices stay intact.
      (unless (pair? arguments) (error "Rust compiler wrapper requires Cargo's compiler argument"))
      (execute (car arguments)
               (append arguments (if (needs-native-linker? (cdr arguments))
                                     (native-linker-flags (path-join root "build/native-runtime")) '())))
      (emergency-exit 127))
    (define (cargo-build root manifest target)
      ;; An explicit target keeps LTO flags off host build scripts. The existing
      ;; compiler wrapper supplies their native linker without enabling LTO.
      (run-command! (list (tool-name "CARGO" "cargo") "build" "--quiet" "--offline" "--release"
                          "--target" native-target "--manifest-path" manifest "--target-dir" target)
                    `((environment . ,(native-lto-environment root)))))

    ;; ---- Rust providers and a single shared runtime ----

    (define (link-package-name directory)
      ;; Cargo shares dependency compilation, but each build must own its root
      ;; package and output filename until publication has consumed that file.
      (string-append "wasm_native_" (sha-256 directory)))
    (define (provider-crate provider index directory)
      (let* ((name (string-append (link-package-name directory) "_provider_" (number->string index)))
             (crate (path-join directory name)))
        (create-directory* crate)
        (write-text (path-join crate "Cargo.toml")
                    (string-append "[package]\nname = " (json->string name) "\nversion = \"0.0.0\"\nedition = \"2024\"\n"
                                   "[lib]\npath = " (json->string (cadr provider)) "\n"))
        (cons name crate)))
    (define (stage-entry-source entry providers directory)
      ;; A true crate root preserves inner attributes and module documentation.
      ;; Its temporary sibling also preserves every Rust relative-path rule.
      (let ((source (string-append (read-text entry) "\nextern crate snail_runtime as _;\n"
                                   (apply string-append
                                          (map (lambda (provider) (string-append "extern crate " (car provider) " as _;\n")) providers)))))
        (write-text (path-join directory "main.rs") source)
        (let loop ((index 0))
          (let* ((path (path-join (path-directory entry)
                                  (string-append ".snail-native-entry-" (number->string (current-process-id)) "-" (number->string index) ".rs")))
                 (descriptor (open path (bitwise-ior open/write open/create open/exclusive) #o600)))
            (cond (descriptor (call-with-port (open-output-file-descriptor descriptor) (lambda (port) (display source port))) path)
                  ((file-exists? path) (loop (+ index 1)))
                  (else (error "cannot stage Rust crate root beside entry" entry)))))))
    (define (write-link-package root object entry providers directory)
      (write-text (path-join directory "Cargo.toml")
                  (string-append "[package]\nname = " (json->string (link-package-name directory)) "\nversion = \"0.0.0\"\nedition = \"2024\"\n"
                                 "[[bin]]\nname = " (json->string (link-package-name directory)) "\npath = " (json->string entry)
                                 "\n[dependencies]\nsnail-runtime = { path = " (json->string root)
                                 ", features = [\"native-runtime\"] }\n"
                                 (apply string-append (map (lambda (provider)
                                                             (string-append (car provider) " = { path = "
                                                                            (json->string (cdr provider)) " }\n")) providers))
                                 "[profile.release]\npanic = \"abort\"\nlto = true\ncodegen-units = 1\n"))
      ;; Bitcode joins Rust's final optimization. A saved ELF object still links,
      ;; but its guest bodies are already machine code and cannot participate.
      (write-text (path-join directory "build.rs")
                  (string-append "fn main() {\n    println!(\"cargo:rustc-link-arg={}\", "
                                 (json->string object) ");\n}\n")))
    (define (link-native-object root object entry providers directory)
      ;; Cargo resolves manifest paths from each generated package, so capture
      ;; every caller-relative input before writing any package files.
      (let* ((root (absolute-path root)) (object (absolute-path object))
             (entry (absolute-path entry)) (directory (absolute-path directory))
             (providers (map (lambda (provider) (list (car provider) (absolute-path (cadr provider)))) providers)))
        (create-directory* directory)
        (let* ((crates (map (lambda (provider index) (provider-crate provider index directory))
                            providers (iota (length providers))))
               (target (path-join root "build" "native-programs")) (staged #f))
          (create-directory* target)
          (dynamic-wind
              (lambda () #f)
              (lambda ()
                (set! staged (stage-entry-source entry crates directory))
                (write-link-package root object staged crates directory)
                (cargo-build root (path-join directory "Cargo.toml") target)
                (let ((program (path-join directory "program")))
                  (write-bytes program (read-bytes (path-join target native-target "release" (link-package-name directory))))
                  (chmod program #o755) program))
              (lambda () (when staged (delete-file staged)))))))
    (define (ensure-native-supervisor root)
      (let ((target (path-join root "build" "native-runtime")))
        (create-directory* target)
        (run-command! (list (tool-name "CARGO" "cargo") "build" "--quiet" "--offline" "--release"
                            "--features" "native-runtime" "--bin" "snail-native-supervisor"
                            "--manifest-path" (path-join root "Cargo.toml") "--target-dir" target)
                      `((supervisor . #f) (environment . ,(native-cargo-environment target))))
        (path-join target "release" "snail-native-supervisor")))

    ;; ---- Retained Rust inputs and build evidence ----

    (define rust-source-path
      (rx (or (seq "include" (? (or "_str" "_bytes")) (* space) "!" (* space) "(" (* space))
              (seq "#" (* space) "[" (* space) "path" (* space) "=" (* space)))
          "\"" ($ (+ (~ #\"))) "\""))
    (define (rust-input-path source literal)
      (if (string-prefix? "/" literal) (path-normalize literal)
          (path-join (path-directory source) literal)))
    (define (rust-literal-inputs path)
      (let* ((masks (rust-source-masks (read-text path))) (comments (car masks)) (code (cdr masks)))
        (let loop ((offset 0) (paths '()))
          (let ((match (regexp-search rust-source-path comments offset)))
            (if (not match) paths
                (loop (regexp-match-submatch-end match 0)
                      (if (char-whitespace? (string-ref code (regexp-match-submatch-start match 0))) paths
                          (cons (rust-input-path path (regexp-match-submatch match 1)) paths))))))))
    (define (rust-source-inputs path)
      (let loop ((pending (list path)) (seen '()))
        (cond ((null? pending) (reverse seen))
              ((member (car pending) seen) (loop (cdr pending) seen))
              (else (loop (append (if (string-suffix? ".rs" (car pending)) (rust-literal-inputs (car pending)) '()) (cdr pending))
                          (cons (car pending) seen))))))
    (define (source-hashes inputs)
      (map (lambda (path) (cons (string->symbol path) (file-sha256 path))) (filter file-regular? (delete-duplicates inputs))))
    (define (check-stable-inputs hashes)
      (for-each (lambda (entry)
                  (let* ((path (symbol->string (car entry))) (actual (and (file-regular? path) (file-sha256 path))))
                    (unless (and actual (string=? (cdr entry) actual))
                      (error "native build input changed while compiling" path (cdr entry) actual)))) hashes))
    (define (native-evidence root directory inputs before output)
      (let ((paths (delete-duplicates
                    (append inputs
                            (filter (lambda (path) (or (not (regexp-search (rx "/target/") path)) (string-suffix? ".a" path)))
                                    (directory-files-recursive directory)) (list output)))))
        (write-json (path-join directory "build.json")
                    `((commands . ,(list->vector (current-command-records)))
                      (input_sha256 . ,before)
                      (sha256 . ,(map (lambda (path) (cons (string->symbol path) (file-sha256 path)))
                                      (filter file-regular? paths)))))))
    )

  ;; ---- Tests ----

  (cond-expand
   (snail-tests
    (export test-native-build)
    (import (wasm-native test-utils))
    (begin
      (define (test-build-error thunk)
        (guard (failure (else (and (error-object? failure) (error-object-message failure)))) (thunk) #f))
      (define (test-rust-declaration-reader)
        (let* ((declaration "#[unsafe(export_name = \"value\")] pub extern \"C\" fn value(x: i64) -> f64 { 0.0 }")
               (source (string-append "// " declaration "\n/* nested /* " declaration " */ comment */\n"
                                      "const S: &str = r##\"" declaration "\"##;\n"
                                      "const C: char = '\\''; fn lifetime<'a>(x: &'a str) {}\n"
                                      "#[ /* comment */ unsafe(export_name = \"value\")] pub extern \"C\" fn value(x: i64) -> f64 { 0.0 }")))
          (expect (rust-source-bindings "test" source) '((("test" "value") "value" (i64) (f64))))
          (expect (test-build-error (lambda () (rust-source-bindings "test" (string-append "fn nested() { " declaration " }"))))
                  "unsupported Rust export declaration syntax"))
        (expect (test-build-error (lambda () (rust-source-bindings "test" "#[unsafe(export_name = \"p\")] pub extern \"C\" fn p(x: *const u8) {}")))
                "unsupported native Rust scalar type")
        (expect (test-build-error (lambda () (rust-source-bindings "test" "#[unsafe(export_name = \"p\")] pub extern \"system\" fn p(x: i32) {}")))
                "unsupported Rust export declaration syntax"))
      (define (test-input-identity)
        (let* ((directory (make-build-directory "/tmp" "native-build-test-"))
               (source (path-join directory "source")) (output (path-join directory "output")))
          (dynamic-wind
              (lambda () (write-text source "original") (link-file source output))
              (lambda ()
                (expect (paths-alias? output source) #t)
                (let ((hashes (source-hashes (list source))))
                  (write-text source "changed")
                  (expect (test-build-error (lambda () (check-stable-inputs hashes))) "native build input changed while compiling")))
              (lambda () (delete-file-hierarchy directory)))))
      (define (test-rust-input-paths)
        (let* ((directory (make-build-directory "/tmp" "native-inputs-test-"))
               (source (path-join directory "entry.rs")) (absolute (path-join directory "absolute.rs"))
               (relative (path-join directory "relative.rs")) (data (path-join directory "data.txt")))
          (dynamic-wind
              (lambda ()
                (for-each (lambda (path) (write-text path "")) (list absolute relative data))
                (write-text source (string-append "#[path=" (json->string absolute) "] mod support;\n"
                                                  "include!(\"relative.rs\");\ninclude_str!(" (json->string data) ");\n")))
              (lambda () (expect (sort (rust-source-inputs source) string<?) (sort (list source absolute relative data) string<?)))
              (lambda () (delete-file-hierarchy directory)))))
      (define (test-native-build)
        (run-test test-rust-declaration-reader)
        (run-test test-input-identity)
        (run-test test-rust-input-paths)
        (expect (needs-native-linker? '("--crate-name" "build_script_build")) #t)
        (expect (needs-native-linker? '("--target=x86_64-unknown-linux-gnu")) #t)
        (expect (needs-native-linker? '("--target" "wasm32-wasip1")) #f)
        (expect (needs-native-linker? '("--target=aarch64-unknown-linux-gnu")) #f)
        (expect (needs-native-linker? '("-C" "linker=rust-lld" "-C" "link-arg=Scrt1.o")) #f)
        (expect (needs-native-linker? '("-Clinker=/chosen/linker")) #f))))
   (else)))
