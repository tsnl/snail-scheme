unsafe extern "C" { fn native_module_init(); #[link_name = "wasm.main"] fn guest_main() -> i32; }
fn main() {
    snail_runtime::native::initialize_host();
    unsafe { native_module_init(); }
    let value = unsafe { guest_main() } as i64;
    let status = if (0..=255).contains(&value) { value as i32 } else { 1 };
    std::process::exit(snail_runtime::native::native_finish(status));
}

extern crate snail_runtime as _;
extern crate wasm_native_28d04e57e0cbb6b3f566925703f118c1c597f01ab91dd8dca2c94f28fbf721d5_provider_0 as _;
