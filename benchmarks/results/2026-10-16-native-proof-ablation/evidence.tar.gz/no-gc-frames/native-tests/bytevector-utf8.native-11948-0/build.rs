fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/native-tests/bytevector-utf8.native-11948-0/module.bc");
}
