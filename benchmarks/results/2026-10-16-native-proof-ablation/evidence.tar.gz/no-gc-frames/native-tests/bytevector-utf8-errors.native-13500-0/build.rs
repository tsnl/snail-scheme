fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/native-tests/bytevector-utf8-errors.native-13500-0/module.bc");
}
