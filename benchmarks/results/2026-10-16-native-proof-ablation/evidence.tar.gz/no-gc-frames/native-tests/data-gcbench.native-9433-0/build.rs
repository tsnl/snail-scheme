fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/native-tests/data-gcbench.native-9433-0/module.bc");
}
