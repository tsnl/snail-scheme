fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/native-tests/string-block-literal.native-10942-0/module.bc");
}
