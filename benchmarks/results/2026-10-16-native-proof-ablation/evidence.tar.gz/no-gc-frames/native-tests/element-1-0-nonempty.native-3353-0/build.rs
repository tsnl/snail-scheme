fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-leaf-20261016/native-tests/element-1-0-nonempty.native-3353-0/module.bc");
}
