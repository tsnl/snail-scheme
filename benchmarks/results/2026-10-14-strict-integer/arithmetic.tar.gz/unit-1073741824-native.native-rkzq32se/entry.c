#include <stdint.h>
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern void native_poll_finalizers(void);
extern int64_t guest_main(void) __asm__("wasm.main");
int main(int argc, char **argv) {
  native_host_init(argc, argv);
  native_module_init();
  int64_t value = guest_main(); int status = (value >= 0 && value <= 255) ? (int)value : 1;
  return native_finish(status);
}
