(import (snail strict) (snail integer))
(+ (integer-from-i64 1) 1)
