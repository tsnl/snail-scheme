(import (snail strict) (snail integer))
(integer-limbs (integer-from-i64 1))
