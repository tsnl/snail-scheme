(import (snail strict) (snail integer))
(integer #f (vector (ann 1 I32)))
