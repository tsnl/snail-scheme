(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test) body ...)
     (do ((var init step) ...) (test (unit)) body ...))
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-data Radical (H) (C (first Radical) (second Radical) (third Radical)))
(define-data Paraffin
  (BCP (first Radical) (second Radical))
  (CCP (first Radical) (second Radical) (third Radical) (fourth Radical)))
(define (max a b) (if (> a b) a b))
(define (odd? n) (not (= (remainder n 2) 0)))
(define-extern native-expected-length "benchmark" "expected_length" (-> I64))
(define-extern native-expected-i64 "benchmark" "expected_i64" (-> I64 I64))
(define (expected-list)
  (let loop ((n (native-expected-length)) (xs '()))
    (if (= n 0) xs
        (loop (- n 1) (cons (native-expected-i64 (- n 1)) xs)))))
(: same-i64-list? (-> (List I64) (List I64) Bool))
(define (same-i64-list? xs ys)
  (if (null? xs) (null? ys)
      (and (not (null? ys)) (= (car xs) (car ys))
           (same-i64-list? (cdr xs) (cdr ys)))))
(define (hide count x) (hide-i64 x))
;;; PARAFFINS -- Compute how many paraffins exist with N carbon atoms.


(define (gen n)
  (let* ((n/2 (quotient n 2))
         (radicals (make-vector (+ n/2 1) (cons (H) '()))))

    (define (rads-of-size n)
      (let loop1 ((ps
                   (three-partitions (- n 1)))
                  (lst
                   '()))
        (if (null? ps)
            lst
            (let* ((p (car ps))
                   (nc1 (vector-ref p 0))
                   (nc2 (vector-ref p 1))
                   (nc3 (vector-ref p 2)))
              (let loop2 ((rads1
                           (vector-ref radicals nc1))
                          (lst
                           (loop1 (cdr ps)
                                  lst)))
                (if (null? rads1)
                    lst
                    (let loop3 ((rads2
                                 (if (= nc1 nc2)
                                     rads1
                                     (vector-ref radicals nc2)))
                                (lst
                                 (loop2 (cdr rads1)
                                        lst)))
                      (if (null? rads2)
                          lst
                          (let loop4 ((rads3
                                       (if (= nc2 nc3)
                                           rads2
                                           (vector-ref radicals nc3)))
                                      (lst
                                       (loop3 (cdr rads2)
                                              lst)))
                            (if (null? rads3)
                                lst
                                (cons (C
                                              (car rads1)
                                              (car rads2)
                                              (car rads3))
                                      (loop4 (cdr rads3)
                                             lst))))))))))))

    (define (bcp-generator j)
      (if (odd? j)
          '()
          (let loop1 ((rads1
                       (vector-ref radicals (quotient j 2)))
                      (lst
                       '()))
            (if (null? rads1)
                lst
                (let loop2 ((rads2
                             rads1)
                            (lst
                             (loop1 (cdr rads1)
                                    lst)))
                  (if (null? rads2)
                      lst
                      (cons (BCP
                                    (car rads1)
                                    (car rads2))
                            (loop2 (cdr rads2)
                                   lst))))))))

    (define (ccp-generator j)
      (let loop1 ((ps
                   (four-partitions (- j 1)))
                  (lst
                   '()))
        (if (null? ps)
            lst
            (let* ((p (car ps))
                   (nc1 (vector-ref p 0))
                   (nc2 (vector-ref p 1))
                   (nc3 (vector-ref p 2))
                   (nc4 (vector-ref p 3)))
              (let loop2 ((rads1
                           (vector-ref radicals nc1))
                          (lst
                           (loop1 (cdr ps)
                                  lst)))
                (if (null? rads1)
                    lst
                    (let loop3 ((rads2
                                 (if (= nc1 nc2)
                                     rads1
                                     (vector-ref radicals nc2)))
                                (lst
                                 (loop2 (cdr rads1)
                                        lst)))
                      (if (null? rads2)
                          lst
                          (let loop4 ((rads3
                                       (if (= nc2 nc3)
                                           rads2
                                           (vector-ref radicals nc3)))
                                      (lst
                                       (loop3 (cdr rads2)
                                              lst)))
                            (if (null? rads3)
                                lst
                                (let loop5 ((rads4
                                             (if (= nc3 nc4)
                                                 rads3
                                                 (vector-ref radicals nc4)))
                                            (lst
                                             (loop4 (cdr rads3)
                                                    lst)))
                                  (if (null? rads4)
                                      lst
                                      (cons (CCP
                                                    (car rads1)
                                                    (car rads2)
                                                    (car rads3)
                                                    (car rads4))
                                            (loop5 (cdr rads4)
                                                   lst))))))))))))))

    (let loop ((i 1))
      (if (> i n/2)
          (vector (bcp-generator n)
                  (ccp-generator n))
          (begin
            (vector-set! radicals i (rads-of-size i))
            (loop (+ i 1)))))))

(define (three-partitions m)
  (let loop1 ((lst '())
              (nc1 (quotient m 3)))
    (if (< nc1 0)
        lst
        (let loop2 ((lst lst)
                    (nc2 (quotient (- m nc1) 2)))
          (if (< nc2 nc1)
              (loop1 lst
                     (- nc1 1))
              (loop2 (cons (vector nc1 nc2 (- m (+ nc1 nc2))) lst)
                     (- nc2 1)))))))

(define (four-partitions m)
  (let loop1 ((lst '())
              (nc1 (quotient m 4)))
    (if (< nc1 0)
        lst
        (let loop2 ((lst lst)
                    (nc2 (quotient (- m nc1) 3)))
          (if (< nc2 nc1)
              (loop1 lst
                     (- nc1 1))
              (let ((start (max nc2 (- (quotient (+ m 1) 2) (+ nc1 nc2)))))
                (let loop3 ((lst lst)
                            (nc3 (quotient (- m (+ nc1 nc2)) 2)))
                  (if (< nc3 start)
                      (loop2 lst (- nc2 1))
                      (loop3 (cons (vector nc1 nc2 nc3 (- m (+ nc1 (+ nc2 nc3)))) lst)
                             (- nc3 1))))))))))

(define (nb n)
  (let ((x (gen n)))
    (+ (length (vector-ref x 0))
       (length (vector-ref x 1)))))

(define input0 (native-input-i64 (ann 0 I32)))
(define (encode-radical value tail)
  (match value
    ((H) (cons 0 tail))
    ((C a b c) (cons 1 (encode-radical a (encode-radical b (encode-radical c tail)))))))
(define (encode-paraffin value tail)
  (match value
    ((BCP a b) (cons 2 (encode-radical a (encode-radical b tail))))
    ((CCP a b c d)
     (cons 3 (encode-radical a (encode-radical b (encode-radical c (encode-radical d tail))))))))
(define (encode-products values tail)
  (if (null? values) tail
      (encode-paraffin (car values) (encode-products (cdr values) tail))))
(define (encode-result result)
  (let ((first (vector-ref result 0)) (second (vector-ref result 1)))
    (cons (length first) (encode-products first (cons (length second) (encode-products second '()))))))
(: paraffins-probe (-> I64 I64))
(define (paraffins-probe count)
  (if (same-i64-list? (encode-result (gen input0)) (expected-list)) 1 0))
(: bench (-> I64 I64))
(define (bench count) (let loop ((i 0) (result 0))
    (if (< i count) (loop (+ i 1) (nb (hide count input0))) result)))
(unit)
