(module
 (rec
  (type $type17 (sub (struct)))
  (type $type19 (sub (struct)))
  (type $type74 (struct (field (mut i32)) (field (mut (ref null $type29)))))
  (type $environment72 (struct (field i64) (field (ref $type74))))
  (type $call40 (func (param (ref $type23)) (result (ref $type12))))
  (type $call39 (func (param (ref null $type16) (ref null $type12)) (result (ref null $type12))))
  (type $call37 (func (param (ref $type19) (ref null $type12)) (result (ref $type12))))
  (type $call72 (func (param (ref $environment65) (ref null $type16) i64) (result i64)))
  (type $type72 (struct (field (ref $environment65))))
  (type $type73 (struct (field (mut i32)) (field (mut (ref null $type72)))))
  (type $environment65 (struct (field (ref $type73))))
  (type $call36 (func (param i64) (result i64)))
  (type $call68 (func (param (ref $environment62) (ref null $type15) i64) (result (ref $type23))))
  (type $call70 (func (param (ref $environment61) (ref null $type15) i64) (result i64)))
  (type $type68 (struct (field (ref $environment62))))
  (type $environment62 (struct (field (ref $type67)) (field (ref $type69))))
  (type $type67 (struct (field i32) (field (ref $type23))))
  (type $type23 (array (mut (ref null $type16))))
  (type $type70 (struct (field (ref $environment61))))
  (type $type69 (struct (field (mut i32)) (field (mut (ref null $type68)))))
  (type $type71 (struct (field (mut i32)) (field (mut (ref null $type70)))))
  (type $type15 (struct (field (ref null $type16)) (field (ref null $type15))))
  (type $environment61 (struct (field (ref $type71))))
  (type $type22 (sub $type17 (struct (field (ref $type19)) (field (ref $type19)) (field (ref $type19)) (field (ref $type19)))))
  (type $environment56 (struct (field (ref null $type46)) (field (ref null $type46)) (field (ref null $type46)) (field (ref $type64))))
  (type $environment55 (struct (field (ref null $type46)) (field (ref null $type46)) (field (ref $type43)) (field (ref $type43)) (field (ref $type44)) (field (ref $type64))))
  (type $environment54 (struct (field (ref null $type46)) (field (ref $type43)) (field (ref $type43)) (field (ref $type44)) (field (ref $type43)) (field (ref $type64))))
  (type $environment53 (struct (field (ref $type43)) (field (ref $type43)) (field (ref $type44)) (field (ref $type43)) (field (ref $type43)) (field (ref $type64))))
  (type $type65 (struct (field (ref $environment52))))
  (type $type66 (struct (field (mut i32)) (field (mut (ref null $type65)))))
  (type $environment52 (struct (field (ref $type44)) (field (ref $type66))))
  (type $call65 (func (param (ref $environment52) (ref null $type35) (ref null $type16)) (result (ref null $type16))))
  (type $call29 (func (param (ref null $environment72) i64 i64) (result i64)))
  (type $environment51 (struct (field (ref $type43)) (field (ref $type55)) (field i64) (field (ref $type55)) (field i64) (field i64)))
  (type $environment49 (struct (field i64) (field (ref $type55)) (field i64) (field (ref $type55))))
  (type $environment48 (struct (field (ref $type55)) (field i64)))
  (type $type18 (sub $type17 (struct (field (ref $type19)) (field (ref $type19)))))
  (type $type16 (struct (field (ref $type17)) (field (ref null $type16))))
  (type $environment45 (struct (field (ref null $type46)) (field (ref $type64))))
  (type $environment44 (struct (field (ref $type64))))
  (type $type63 (struct (field (ref $call63)) (field (ref struct))))
  (type $type64 (struct (field (mut i32)) (field (mut (ref null $type63)))))
  (type $call63 (func (param (ref struct) (ref null $type46) (ref null $type16)) (result (ref null $type16))))
  (type $type21 (sub $type19 (struct (field (ref $type19)) (field (ref $type19)) (field (ref $type19)))))
  (type $environment42 (struct (field (ref null $type46)) (field (ref null $type46)) (field (ref $type62))))
  (type $environment41 (struct (field (ref null $type46)) (field (ref $type43)) (field (ref $type43)) (field (ref $type44)) (field (ref $type62))))
  (type $call61 (func (param (ref struct) (ref null $type46) (ref null $type46)) (result (ref null $type46))))
  (type $environment40 (struct (field (ref $type43)) (field (ref $type43)) (field (ref $type44)) (field (ref $type43)) (field (ref $type62))))
  (type $type52 (struct (field (ref $environment39))))
  (type $type53 (struct (field (mut i32)) (field (mut (ref null $type52)))))
  (type $environment39 (struct (field (ref $type44)) (field (ref $type53))))
  (type $type61 (struct (field (ref $call61)) (field (ref struct))))
  (type $type62 (struct (field (mut i32)) (field (mut (ref null $type61)))))
  (type $call52 (func (param (ref $environment39) (ref null $type35) (ref null $type46)) (result (ref null $type46))))
  (type $call57 (func (param (ref $environment38) (ref null $type12) i64) (result (ref $type13))))
  (type $call59 (func (param (ref $environment37) (ref null $type12) i64) (result i64)))
  (type $type57 (struct (field (ref $environment38))))
  (type $environment38 (struct (field (ref $type56)) (field (ref $type58))))
  (type $type56 (struct (field i32) (field (ref $type13))))
  (type $type13 (array (mut i64)))
  (type $type59 (struct (field (ref $environment37))))
  (type $type58 (struct (field (mut i32)) (field (mut (ref null $type57)))))
  (type $type60 (struct (field (mut i32)) (field (mut (ref null $type59)))))
  (type $environment37 (struct (field (ref $type60))))
  (type $64 (func (param (ref $type12)) (result (ref $type13))))
  (type $type35 (struct (field (ref $type13)) (field (ref null $type35))))
  (type $environment33 (struct (field i64) (field (ref $type55)) (field (ref $type55)) (field i64)))
  (type $type54 (struct (field (ref $call54)) (field (ref struct))))
  (type $environment32 (struct (field (ref $type55)) (field i64)))
  (type $type55 (struct (field (mut i32)) (field (mut (ref null $type54)))))
  (type $call54 (func (param (ref struct) (ref null $type35) i64) (result (ref null $type35))))
  (type $environment57 (struct (field (ref $type43)) (field (ref $type49)) (field i64) (field (ref $type49)) (field (ref $type44)) (field (ref $type47)) (field (ref $type51))))
  (type $environment46 (struct (field (ref $type44))))
  (type $type50 (struct (field (ref struct))))
  (type $environment43 (struct (field (ref $type44))))
  (type $type48 (struct (field (ref $environment30))))
  (type $environment30 (struct (field (ref $type44))))
  (type $type45 (array (mut (ref null $type46))))
  (type $type46 (struct (field (ref $type19)) (field (ref null $type46))))
  (type $type20 (sub $type19 (struct)))
  (type $type49 (struct (field (mut i32)) (field (ref $type50))))
  (type $type47 (struct (field (mut i32)) (field (ref $type48))))
  (type $type51 (struct (field (mut i32)) (field (mut (ref null $type33)))))
  (type $type43 (struct (field (mut i32)) (field i64)))
  (type $type44 (struct (field (mut i32)) (field (ref $type45))))
  (type $call33 (func (param (ref null $environment57) i64) (result (ref $type23))))
  (type $call32 (func (param (ref null $type12) (ref null $type12)) (result i32)))
  (type $call41 (func (param (ref $environment27) i64 (ref $type12)) (result (ref null $type12))))
  (type $type41 (struct (field (ref $environment27))))
  (type $type42 (struct (field (mut i32)) (field (mut (ref null $type41)))))
  (type $type12 (struct (field i64) (field (ref null $type12))))
  (type $environment27 (struct (field (ref $type42))))
  (type $call31 (func (result (ref null $type12))))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type34 (struct))
  (type $type33 (struct (field (ref $call33)) (field (ref null $environment57))))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct (field (ref $call29)) (field (ref null $environment72))))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type14 (struct))
  (type $type11 (struct))
 )
 (type $111 (func (param i64) (result i64)))
 (type $112 (func (result i64)))
 (type $113 (func (param i32) (result i64)))
 (type $114 (func))
 (import "benchmark" "expected_length" (func $foreign0 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign2 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign3 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global84 (mut (ref null $type11)) (ref.null none))
 (global $ready84 (mut i32) (i32.const 0))
 (global $global160 (mut (ref null $type14)) (ref.null none))
 (global $ready160 (mut i32) (i32.const 0))
 (global $global86 (mut (ref null $type24)) (ref.null none))
 (global $ready86 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type25)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global89 (mut (ref null $type26)) (ref.null none))
 (global $ready89 (mut i32) (i32.const 0))
 (global $global165 (mut (ref null $type27)) (ref.null none))
 (global $ready165 (mut i32) (i32.const 0))
 (global $global176 (mut (ref null $type28)) (ref.null none))
 (global $ready176 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type29)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type30)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type31)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global67 (mut (ref null $type32)) (ref.null none))
 (global $ready67 (mut i32) (i32.const 0))
 (global $global213 (mut (ref null $type29)) (ref.null none))
 (global $ready213 (mut i32) (i32.const 0))
 (global $global70 (mut (ref null $type33)) (ref.null none))
 (global $ready70 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type34)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type34)) (ref.null none))
 (global $ready123 (mut i32) (i32.const 0))
 (global $global173 (mut (ref null $type36)) (ref.null none))
 (global $ready173 (mut i32) (i32.const 0))
 (global $global181 (mut i64) (i64.const 0))
 (global $ready181 (mut i32) (i32.const 0))
 (global $global182 (mut (ref null $type37)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global189 (mut (ref null $type38)) (ref.null none))
 (global $ready189 (mut i32) (i32.const 0))
 (global $global199 (mut (ref null $type39)) (ref.null none))
 (global $ready199 (mut i32) (i32.const 0))
 (global $global202 (mut (ref null $type40)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global206 (mut (ref null $type36)) (ref.null none))
 (global $ready206 (mut i32) (i32.const 0))
 (global $global208 (mut (ref null $type36)) (ref.null none))
 (global $ready208 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "paraffins-probe" (func $export1))
 (export "main" (func $main))
 (func $function26 (type $call31) (result (ref null $type12))
  (local $0 i64)
  (local $1 i64)
  (local $2 (ref $environment27))
  (local $3 (ref $type12))
  (local $4 (ref $type42))
  (local.set $0
   (call $foreign0)
  )
  (struct.set $type42 1
   (local.tee $4
    (struct.new_default $type42)
   )
   (struct.new $type41
    (struct.new $environment27
     (local.get $4)
    )
   )
  )
  (struct.set $type42 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type42 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type41 0
    (struct.get $type42 1
     (local.get $4)
    )
   )
  )
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $3
     (struct.new $type12
      (call $foreign1
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
      (block (result nullref)
       (if
        (i32.eqz
         (struct.get $type42 0
          (struct.get $environment27 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type41 0
         (struct.get $type42 1
          (struct.get $environment27 0
           (local.get $2)
          )
         )
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type12))
     (i64.eqz
      (local.tee $0
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $3
       (struct.new $type12
        (call $foreign1
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (block (result (ref $type12))
         (if
          (i32.eqz
           (struct.get $type42 0
            (struct.get $environment27 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type41 0
           (struct.get $type42 1
            (struct.get $environment27 0
             (local.get $2)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (if (result (ref $type12))
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (local.get $3)
       )
       (else
        (local.set $3
         (struct.new $type12
          (call $foreign1
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
          (block (result (ref $type12))
           (if
            (i32.eqz
             (struct.get $type42 0
              (struct.get $environment27 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type41 0
             (struct.get $type42 1
              (struct.get $environment27 0
               (local.get $2)
              )
             )
            )
           )
           (local.get $3)
          )
         )
        )
        (if (result (ref $type12))
         (i64.eqz
          (local.tee $0
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $3)
         )
         (else
          (local.set $3
           (struct.new $type12
            (call $foreign1
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
            (block (result (ref $type12))
             (if
              (i32.eqz
               (struct.get $type42 0
                (struct.get $environment27 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type41 0
               (struct.get $type42 1
                (struct.get $environment27 0
                 (local.get $2)
                )
               )
              )
             )
             (local.get $3)
            )
           )
          )
          (if (result (ref $type12))
           (i64.eqz
            (local.tee $0
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $3)
           )
           (else
            (local.set $3
             (struct.new $type12
              (call $foreign1
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
              (block (result (ref $type12))
               (if
                (i32.eqz
                 (struct.get $type42 0
                  (struct.get $environment27 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type41 0
                 (struct.get $type42 1
                  (struct.get $environment27 0
                   (local.get $2)
                  )
                 )
                )
               )
               (local.get $3)
              )
             )
            )
            (if (result (ref $type12))
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $3)
             )
             (else
              (local.set $3
               (struct.new $type12
                (call $foreign1
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
                (block (result (ref $type12))
                 (if
                  (i32.eqz
                   (struct.get $type42 0
                    (struct.get $environment27 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type41 0
                   (struct.get $type42 1
                    (struct.get $environment27 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (local.get $3)
                )
               )
              )
              (if (result (ref $type12))
               (i64.eqz
                (local.tee $0
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $3)
               )
               (else
                (local.set $3
                 (struct.new $type12
                  (call $foreign1
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                  (block (result (ref $type12))
                   (if
                    (i32.eqz
                     (struct.get $type42 0
                      (struct.get $environment27 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type41 0
                     (struct.get $type42 1
                      (struct.get $environment27 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (local.get $3)
                  )
                 )
                )
                (if (result (ref $type12))
                 (i64.eqz
                  (local.tee $0
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (local.set $3
                   (struct.new $type12
                    (call $foreign1
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                    (block (result (ref $type12))
                     (if
                      (i32.eqz
                       (struct.get $type42 0
                        (struct.get $environment27 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $2
                      (struct.get $type41 0
                       (struct.get $type42 1
                        (struct.get $environment27 0
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (local.get $3)
                    )
                   )
                  )
                  (if (result (ref $type12))
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (local.set $3
                     (struct.new $type12
                      (call $foreign1
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                      (block (result (ref $type12))
                       (if
                        (i32.eqz
                         (struct.get $type42 0
                          (struct.get $environment27 0
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $2
                        (struct.get $type41 0
                         (struct.get $type42 1
                          (struct.get $environment27 0
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (local.get $3)
                      )
                     )
                    )
                    (if (result (ref $type12))
                     (i64.eqz
                      (local.tee $0
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $3)
                     )
                     (else
                      (local.set $1
                       (call $foreign1
                        (i64.sub
                         (local.get $0)
                         (i64.const 1)
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type42 0
                         (struct.get $environment27 0
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (return_call $function27
                       (struct.get $type41 0
                        (struct.get $type42 1
                         (struct.get $environment27 0
                          (local.get $2)
                         )
                        )
                       )
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                       (struct.new $type12
                        (local.get $1)
                        (local.get $3)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function27 (type $call41) (param $0 (ref $environment27)) (param $1 i64) (param $2 (ref $type12)) (result (ref null $type12))
  (local $3 i64)
  (if (result (ref $type12))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type42 0
       (struct.get $environment27 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function27
     (struct.get $type41 0
      (struct.get $type42 1
       (struct.get $environment27 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type12
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function28 (type $call32) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result i32)
  (local $scratch (ref null $type12))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $0)
        )
        (struct.get $type12 0
         (local.get $1)
        )
       )
       (then
        (return_call $function28
         (struct.get $type12 1
          (local.get $0)
         )
         (block (result (ref null $type12))
          (local.set $scratch
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready67)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global67)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function29 (type $call33) (param $0 (ref null $environment57)) (param $1 i64) (result (ref $type23))
  (local $2 (ref $type44))
  (local $3 (ref $type51))
  (local $4 (ref $type43))
  (local $5 (ref $type47))
  (local $6 (ref $type49))
  (local $7 (ref $type49))
  (local $8 (ref $type33))
  (local $9 i64)
  (local.set $4
   (struct.new $type43
    (i32.const 1)
    (i64.div_s
     (local.get $1)
     (i64.const 2)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type43 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (i64.add
      (struct.get $type43 1
       (local.get $4)
      )
      (i64.const 1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.new $type44
    (i32.const 1)
    (array.new $type45
     (struct.new $type46
      (struct.new_default $type20)
      (ref.null none)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
   )
  )
  (local.set $5
   (struct.new $type47
    (i32.const 1)
    (struct.new $type48
     (struct.new $environment30
      (local.get $2)
     )
    )
   )
  )
  (local.set $6
   (struct.new $type49
    (i32.const 1)
    (struct.new $type50
     (struct.new $environment43
      (local.get $2)
     )
    )
   )
  )
  (local.set $7
   (struct.new $type49
    (i32.const 1)
    (struct.new $type50
     (struct.new $environment46
      (local.get $2)
     )
    )
   )
  )
  (struct.set $type51 1
   (local.tee $3
    (struct.new_default $type51)
   )
   (struct.new $type33
    (ref.func $function57)
    (struct.new $environment57
     (local.get $4)
     (local.get $6)
     (local.get $1)
     (local.get $7)
     (local.get $2)
     (local.get $5)
     (local.get $3)
    )
   )
  )
  (struct.set $type51 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call33
   (struct.get $type33 1
    (local.tee $8
     (ref.as_non_null
      (struct.get $type51 1
       (local.get $3)
      )
     )
    )
   )
   (i64.const 1)
   (struct.get $type33 0
    (local.get $8)
   )
  )
 )
 (func $function32 (type $call54) (param $0 (ref struct)) (param $1 (ref null $type35)) (param $2 i64) (result (ref null $type35))
  (local $3 (ref $type55))
  (local $4 (ref $environment32))
  (local $5 (ref $type54))
  (local $6 i64)
  (if (result (ref null $type35))
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $6
     (struct.get $environment32 1
      (local.tee $4
       (ref.cast (ref $environment32)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type55 1
     (local.tee $3
      (struct.new_default $type55)
     )
     (struct.new $type54
      (ref.func $function33)
      (struct.new $environment33
       (local.get $2)
       (struct.get $environment32 0
        (local.get $4)
       )
       (local.get $3)
       (struct.get $environment32 1
        (local.get $4)
       )
      )
     )
    )
    (struct.set $type55 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call54
     (struct.get $type54 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type55 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (i64.sub
       (local.get $6)
       (local.get $2)
      )
      (i64.const 2)
     )
     (struct.get $type54 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function33 (type $call54) (param $0 (ref struct)) (param $1 (ref null $type35)) (param $2 i64) (result (ref null $type35))
  (local $3 (ref $environment33))
  (local $4 (ref $type12))
  (local $5 (ref $type35))
  (local $6 i64)
  (local $scratch (ref (exact $type12)))
  (if
   (i64.gt_s
    (struct.get $environment33 0
     (local.tee $3
      (ref.cast (ref $environment33)
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment33 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function32
     (struct.get $type54 1
      (struct.get $type55 1
       (struct.get $environment33 1
        (local.get $3)
       )
      )
     )
     (local.get $1)
     (i64.sub
      (struct.get $environment33 0
       (local.get $3)
      )
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready84)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global84)
     )
    )
    (local.set $5
     (struct.new $type35
      (call $function35
       (block (result (ref (exact $type12)))
        (local.set $scratch
         (struct.new $type12
          (local.tee $6
           (struct.get $environment33 0
            (local.get $3)
           )
          )
          (struct.new $type12
           (local.get $2)
           (struct.new $type12
            (i64.sub
             (struct.get $environment33 3
              (local.get $3)
             )
             (i64.add
              (local.get $2)
              (local.get $6)
             )
            )
            (ref.null none)
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready86)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global86)
         )
        )
        (local.get $scratch)
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment33 2
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function33
     (struct.get $type54 1
      (struct.get $type55 1
       (struct.get $environment33 2
        (local.get $3)
       )
      )
     )
     (local.get $5)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function35 (type $64) (param $0 (ref $type12)) (result (ref $type13))
  (local $1 (ref null $type12))
  (local $2 (ref $environment37))
  (local $3 (ref $environment38))
  (local $4 (ref $type60))
  (local $5 (ref $type58))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready89)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global89)
   )
  )
  (struct.set $type60 1
   (local.tee $4
    (struct.new_default $type60)
   )
   (struct.new $type59
    (struct.new $environment37
     (local.get $4)
    )
   )
  )
  (struct.set $type60 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (struct.get $environment37 0
      (local.tee $2
       (struct.get $type59 0
        (struct.get $type60 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type59 0
    (struct.get $type60 1
     (struct.get $environment37 0
      (local.get $2)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $6
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type12 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type12 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type60 0
          (struct.get $environment37 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type59 0
         (struct.get $type60 1
          (struct.get $environment37 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type12 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type60 0
            (struct.get $environment37 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type59 0
           (struct.get $type60 1
            (struct.get $environment37 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type12 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type60 0
              (struct.get $environment37 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type59 0
             (struct.get $type60 1
              (struct.get $environment37 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type12 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type60 0
                (struct.get $environment37 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type59 0
               (struct.get $type60 1
                (struct.get $environment37 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type12 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type60 0
                  (struct.get $environment37 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type59 0
                 (struct.get $type60 1
                  (struct.get $environment37 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type12 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type60 0
                    (struct.get $environment37 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type59 0
                   (struct.get $type60 1
                    (struct.get $environment37 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type12 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type60 0
                      (struct.get $environment37 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type59 0
                     (struct.get $type60 1
                      (struct.get $environment37 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type12 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type60 0
                        (struct.get $environment37 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function37
                      (struct.get $type59 0
                       (struct.get $type60 1
                        (struct.get $environment37 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type58 1
   (local.tee $5
    (struct.new_default $type58)
   )
   (struct.new $type57
    (struct.new $environment38
     (struct.new $type56
      (i32.const 1)
      (array.new $type13
       (struct.get $type12 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type58 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type58 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type13
   (struct.get $type56 1
    (struct.get $environment38 0
     (local.tee $3
      (struct.get $type57 0
       (struct.get $type58 1
        (local.get $5)
       )
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type12 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type58 0
     (struct.get $environment38 1
      (local.get $3)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type57 0
    (struct.get $type58 1
     (struct.get $environment38 1
      (local.get $3)
     )
    )
   )
  )
  (if (result (ref $type13))
   (ref.is_null
    (local.tee $1
     (struct.get $type12 1
      (local.get $0)
     )
    )
   )
   (then
    (struct.get $type56 1
     (struct.get $environment38 0
      (local.get $3)
     )
    )
   )
   (else
    (array.set $type13
     (struct.get $type56 1
      (struct.get $environment38 0
       (local.get $3)
      )
     )
     (i32.const 1)
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment38 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type57 0
      (struct.get $type58 1
       (struct.get $environment38 1
        (local.get $3)
       )
      )
     )
    )
    (if (result (ref $type13))
     (ref.is_null
      (local.get $1)
     )
     (then
      (struct.get $type56 1
       (struct.get $environment38 0
        (local.get $3)
       )
      )
     )
     (else
      (array.set $type13
       (struct.get $type56 1
        (struct.get $environment38 0
         (local.get $3)
        )
       )
       (i32.const 2)
       (struct.get $type12 0
        (local.get $1)
       )
      )
      (local.set $1
       (struct.get $type12 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type58 0
         (struct.get $environment38 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type57 0
        (struct.get $type58 1
         (struct.get $environment38 1
          (local.get $3)
         )
        )
       )
      )
      (if (result (ref $type13))
       (ref.is_null
        (local.get $1)
       )
       (then
        (struct.get $type56 1
         (struct.get $environment38 0
          (local.get $3)
         )
        )
       )
       (else
        (array.set $type13
         (struct.get $type56 1
          (struct.get $environment38 0
           (local.get $3)
          )
         )
         (i32.const 3)
         (struct.get $type12 0
          (local.get $1)
         )
        )
        (local.set $1
         (struct.get $type12 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type58 0
           (struct.get $environment38 1
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type57 0
          (struct.get $type58 1
           (struct.get $environment38 1
            (local.get $3)
           )
          )
         )
        )
        (if (result (ref $type13))
         (ref.is_null
          (local.get $1)
         )
         (then
          (struct.get $type56 1
           (struct.get $environment38 0
            (local.get $3)
           )
          )
         )
         (else
          (array.set $type13
           (struct.get $type56 1
            (struct.get $environment38 0
             (local.get $3)
            )
           )
           (i32.const 4)
           (struct.get $type12 0
            (local.get $1)
           )
          )
          (local.set $1
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type58 0
             (struct.get $environment38 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (return_call $function38
           (struct.get $type57 0
            (struct.get $type58 1
             (struct.get $environment38 1
              (local.get $3)
             )
            )
           )
           (local.get $1)
           (i64.const 5)
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function37 (type $call59) (param $0 (ref $environment37)) (param $1 (ref null $type12)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type12 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type60 0
         (struct.get $environment37 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (struct.get $type59 0
        (struct.get $type60 1
         (struct.get $environment37 0
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function38 (type $call57) (param $0 (ref $environment38)) (param $1 (ref null $type12)) (param $2 i64) (result (ref $type13))
  (local $3 i64)
  (if (result (ref $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type56 1
     (struct.get $environment38 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (struct.get $type56 1
      (struct.get $environment38 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment38 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function38
     (struct.get $type57 0
      (struct.get $type58 1
       (struct.get $environment38 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function39 (type $call52) (param $0 (ref $environment39)) (param $1 (ref null $type35)) (param $2 (ref null $type46)) (result (ref null $type46))
  (local $3 (ref $type62))
  (local $4 (ref $type43))
  (local $5 (ref $type43))
  (local $6 (ref $type43))
  (local $7 (ref $type13))
  (local $8 (ref null $type46))
  (local $9 (ref $type61))
  (local $10 i64)
  (if (result (ref null $type46))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.new $type43
      (i32.const 1)
      (array.get $type13
       (local.tee $7
        (struct.get $type35 0
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
    )
    (local.set $5
     (struct.new $type43
      (i32.const 1)
      (array.get $type13
       (local.get $7)
       (i32.const 1)
      )
     )
    )
    (local.set $6
     (struct.new $type43
      (i32.const 1)
      (array.get $type13
       (local.get $7)
       (i32.const 2)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type44 0
       (struct.get $environment39 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $10
       (struct.get $type43 1
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (array.get $type45
      (struct.get $type44 1
       (struct.get $environment39 0
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $10)
      )
     )
    )
    (local.set $1
     (struct.get $type35 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type53 0
       (struct.get $environment39 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function39
      (struct.get $type52 0
       (struct.get $type53 1
        (struct.get $environment39 1
         (local.get $0)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
    (struct.set $type62 1
     (local.tee $3
      (struct.new_default $type62)
     )
     (struct.new $type61
      (ref.func $function40)
      (struct.new $environment40
       (local.get $5)
       (local.get $6)
       (struct.get $environment39 0
        (local.get $0)
       )
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type62 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call61
     (struct.get $type61 1
      (local.tee $9
       (ref.as_non_null
        (struct.get $type62 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $8)
     (local.get $2)
     (struct.get $type61 0
      (local.get $9)
     )
    )
   )
  )
 )
 (func $function40 (type $call61) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type46)) (result (ref null $type46))
  (local $3 (ref $environment40))
  (local $4 (ref $type62))
  (local $5 (ref null $type46))
  (local $6 (ref null $type46))
  (local $7 (ref $type61))
  (local $8 i64)
  (if (result (ref null $type46))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment40 3
        (ref.cast (ref $environment40)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type43 1
      (struct.get $environment40 3
       (local.tee $3
        (ref.cast (ref $environment40)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment40 0
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type46))
      (i64.eq
       (struct.get $type43 1
        (struct.get $environment40 0
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type44 0
          (struct.get $environment40 2
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type43 0
          (struct.get $environment40 0
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type43 1
           (struct.get $environment40 0
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type45
        (struct.get $type44 1
         (struct.get $environment40 2
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type46 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (struct.get $environment40 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function40
      (struct.get $type61 1
       (struct.get $type62 1
        (struct.get $environment40 4
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type62 1
     (local.tee $4
      (struct.new_default $type62)
     )
     (struct.new $type61
      (ref.func $function41)
      (struct.new $environment41
       (local.get $1)
       (struct.get $environment40 0
        (local.get $3)
       )
       (struct.get $environment40 1
        (local.get $3)
       )
       (struct.get $environment40 2
        (local.get $3)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type62 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call61
     (struct.get $type61 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type62 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type61 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function41 (type $call61) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type46)) (result (ref null $type46))
  (local $3 (ref $environment41))
  (local $4 (ref $type62))
  (local $5 (ref null $type46))
  (local $6 (ref null $type46))
  (local $7 (ref $type61))
  (local $8 i64)
  (if (result (ref null $type46))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment41 1
        (ref.cast (ref $environment41)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type43 1
      (struct.get $environment41 1
       (local.tee $3
        (ref.cast (ref $environment41)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment41 2
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type46))
      (i64.eq
       (struct.get $type43 1
        (struct.get $environment41 2
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type44 0
          (struct.get $environment41 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type43 0
          (struct.get $environment41 2
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type43 1
           (struct.get $environment41 2
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type45
        (struct.get $type44 1
         (struct.get $environment41 3
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type46 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (struct.get $environment41 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function41
      (struct.get $type61 1
       (struct.get $type62 1
        (struct.get $environment41 4
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type62 1
     (local.tee $4
      (struct.new_default $type62)
     )
     (struct.new $type61
      (ref.func $function42)
      (struct.new $environment42
       (struct.get $environment41 0
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type62 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call61
     (struct.get $type61 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type62 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type61 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function42 (type $call61) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type46)) (result (ref null $type46))
  (local $3 (ref $environment42))
  (local $4 (ref $type19))
  (local $5 (ref $type19))
  (local $6 (ref $type19))
  (local $scratch (ref $type19))
  (if (result (ref null $type46))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (struct.new $type46
     (struct.new $type21
      (struct.get $type46 0
       (struct.get $environment42 0
        (local.tee $3
         (ref.cast (ref $environment42)
          (local.get $0)
         )
        )
       )
      )
      (struct.get $type46 0
       (struct.get $environment42 1
        (local.get $3)
       )
      )
      (block (result (ref $type19))
       (local.set $scratch
        (struct.get $type46 0
         (local.get $1)
        )
       )
       (local.set $1
        (struct.get $type46 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type62 0
          (struct.get $environment42 2
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
     (call $function42
      (struct.get $type61 1
       (struct.get $type62 1
        (struct.get $environment42 2
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function44 (type $call63) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $type64))
  (local $4 (ref null $type46))
  (local $5 (ref $type63))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.get $type46 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (struct.get $environment44 0
        (ref.cast (ref $environment44)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function44
      (struct.get $type63 1
       (struct.get $type64 1
        (struct.get $environment44 0
         (ref.cast (ref $environment44)
          (local.get $0)
         )
        )
       )
      )
      (local.get $4)
      (local.get $2)
     )
    )
    (struct.set $type64 1
     (local.tee $3
      (struct.new_default $type64)
     )
     (struct.new $type63
      (ref.func $function45)
      (struct.new $environment45
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type64 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call63
     (struct.get $type63 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type64 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (local.get $2)
     (struct.get $type63 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function45 (type $call63) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment45))
  (local $4 (ref $type19))
  (local $5 (ref $type19))
  (local $scratch (ref $type19))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (struct.new $type16
     (struct.new $type18
      (struct.get $type46 0
       (struct.get $environment45 0
        (local.tee $3
         (ref.cast (ref $environment45)
          (local.get $0)
         )
        )
       )
      )
      (block (result (ref $type19))
       (local.set $scratch
        (struct.get $type46 0
         (local.get $1)
        )
       )
       (local.set $1
        (struct.get $type46 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type64 0
          (struct.get $environment45 1
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
     (call $function45
      (struct.get $type63 1
       (struct.get $type64 1
        (struct.get $environment45 1
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function48 (type $call54) (param $0 (ref struct)) (param $1 (ref null $type35)) (param $2 i64) (result (ref null $type35))
  (local $3 (ref $type55))
  (local $4 (ref $environment48))
  (local $5 (ref $type54))
  (local $6 i64)
  (if (result (ref null $type35))
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $6
     (struct.get $environment48 1
      (local.tee $4
       (ref.cast (ref $environment48)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type55 1
     (local.tee $3
      (struct.new_default $type55)
     )
     (struct.new $type54
      (ref.func $function49)
      (struct.new $environment49
       (local.get $2)
       (struct.get $environment48 0
        (local.get $4)
       )
       (struct.get $environment48 1
        (local.get $4)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type55 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call54
     (struct.get $type54 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type55 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (i64.sub
       (local.get $6)
       (local.get $2)
      )
      (i64.const 3)
     )
     (struct.get $type54 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function49 (type $call54) (param $0 (ref struct)) (param $1 (ref null $type35)) (param $2 i64) (result (ref null $type35))
  (local $3 (ref $environment49))
  (local $4 (ref $type55))
  (local $5 (ref $type54))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (if
   (i64.gt_s
    (struct.get $environment49 0
     (local.tee $3
      (ref.cast (ref $environment49)
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment49 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type54 1
      (struct.get $type55 1
       (struct.get $environment49 1
        (local.get $3)
       )
      )
     )
     (local.get $1)
     (i64.sub
      (struct.get $environment49 0
       (local.get $3)
      )
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready132)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global132)
     )
    )
    (struct.set $type55 1
     (local.tee $4
      (struct.new_default $type55)
     )
     (struct.new $type54
      (ref.func $function51)
      (struct.new $environment51
       (struct.new $type43
        (i32.const 1)
        (select
         (local.get $2)
         (local.tee $8
          (i64.sub
           (i64.div_s
            (i64.add
             (local.tee $7
              (struct.get $environment49 2
               (local.get $3)
              )
             )
             (i64.const 1)
            )
            (i64.const 2)
           )
           (i64.add
            (local.tee $6
             (struct.get $environment49 0
              (local.get $3)
             )
            )
            (local.get $2)
           )
          )
         )
         (i64.gt_s
          (local.get $2)
          (local.get $8)
         )
        )
       )
       (struct.get $environment49 3
        (local.get $3)
       )
       (local.get $2)
       (local.get $4)
       (local.get $6)
       (local.get $7)
      )
     )
    )
    (struct.set $type55 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call54
     (struct.get $type54 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type55 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (i64.sub
       (struct.get $environment49 2
        (local.get $3)
       )
       (i64.add
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 2)
     )
     (struct.get $type54 0
      (local.get $5)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function50 (type $call29) (param $0 (ref null $environment72)) (param $1 i64) (param $2 i64) (result i64)
  (select
   (local.get $1)
   (local.get $2)
   (i64.gt_s
    (local.get $1)
    (local.get $2)
   )
  )
 )
 (func $function51 (type $call54) (param $0 (ref struct)) (param $1 (ref null $type35)) (param $2 i64) (result (ref null $type35))
  (local $3 (ref $environment51))
  (local $4 (ref $type12))
  (local $5 (ref $type35))
  (local $6 i64)
  (local $7 i64)
  (local $scratch (ref (exact $type12)))
  (if
   (i32.eqz
    (struct.get $type43 0
     (struct.get $environment51 0
      (ref.cast (ref $environment51)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_s
    (struct.get $type43 1
     (struct.get $environment51 0
      (local.tee $3
       (ref.cast (ref $environment51)
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment51 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type54 1
      (struct.get $type55 1
       (struct.get $environment51 1
        (local.get $3)
       )
      )
     )
     (local.get $1)
     (i64.sub
      (struct.get $environment51 2
       (local.get $3)
      )
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready84)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global84)
     )
    )
    (local.set $5
     (struct.new $type35
      (call $function35
       (block (result (ref (exact $type12)))
        (local.set $scratch
         (struct.new $type12
          (local.tee $6
           (struct.get $environment51 4
            (local.get $3)
           )
          )
          (struct.new $type12
           (local.tee $7
            (struct.get $environment51 2
             (local.get $3)
            )
           )
           (struct.new $type12
            (local.get $2)
            (struct.new $type12
             (i64.sub
              (struct.get $environment51 5
               (local.get $3)
              )
              (i64.add
               (i64.add
                (local.get $2)
                (local.get $7)
               )
               (local.get $6)
              )
             )
             (ref.null none)
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready86)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global86)
         )
        )
        (local.get $scratch)
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment51 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (struct.get $type54 1
      (struct.get $type55 1
       (struct.get $environment51 3
        (local.get $3)
       )
      )
     )
     (local.get $5)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function52 (type $call65) (param $0 (ref $environment52)) (param $1 (ref null $type35)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $type64))
  (local $4 (ref $type13))
  (local $5 (ref $type43))
  (local $6 (ref $type43))
  (local $7 (ref $type43))
  (local $8 (ref $type43))
  (local $9 (ref null $type46))
  (local $10 (ref $type63))
  (local $11 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (struct.new $type43
      (i32.const 1)
      (array.get $type13
       (local.tee $4
        (struct.get $type35 0
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
    )
    (local.set $6
     (struct.new $type43
      (i32.const 1)
      (array.get $type13
       (local.get $4)
       (i32.const 1)
      )
     )
    )
    (local.set $7
     (struct.new $type43
      (i32.const 1)
      (array.get $type13
       (local.get $4)
       (i32.const 2)
      )
     )
    )
    (local.set $8
     (struct.new $type43
      (i32.const 1)
      (array.get $type13
       (local.get $4)
       (i32.const 3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type44 0
       (struct.get $environment52 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (struct.get $type43 1
        (local.get $5)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type45
      (struct.get $type44 1
       (struct.get $environment52 0
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $11)
      )
     )
    )
    (local.set $1
     (struct.get $type35 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (struct.get $environment52 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function52
      (struct.get $type65 0
       (struct.get $type66 1
        (struct.get $environment52 1
         (local.get $0)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
    (struct.set $type64 1
     (local.tee $3
      (struct.new_default $type64)
     )
     (struct.new $type63
      (ref.func $function53)
      (struct.new $environment53
       (local.get $7)
       (local.get $8)
       (struct.get $environment52 0
        (local.get $0)
       )
       (local.get $6)
       (local.get $5)
       (local.get $3)
      )
     )
    )
    (struct.set $type64 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call63
     (struct.get $type63 1
      (local.tee $10
       (ref.as_non_null
        (struct.get $type64 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $9)
     (local.get $2)
     (struct.get $type63 0
      (local.get $10)
     )
    )
   )
  )
 )
 (func $function53 (type $call63) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment53))
  (local $4 (ref $type64))
  (local $5 (ref null $type46))
  (local $6 (ref null $type46))
  (local $7 (ref $type63))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment53 4
        (ref.cast (ref $environment53)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type43 1
      (struct.get $environment53 4
       (local.tee $3
        (ref.cast (ref $environment53)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment53 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type46))
      (i64.eq
       (struct.get $type43 1
        (struct.get $environment53 3
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type44 0
          (struct.get $environment53 2
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type43 0
          (struct.get $environment53 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type43 1
           (struct.get $environment53 3
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type45
        (struct.get $type44 1
         (struct.get $environment53 2
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type46 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (struct.get $environment53 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function53
      (struct.get $type63 1
       (struct.get $type64 1
        (struct.get $environment53 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type64 1
     (local.tee $4
      (struct.new_default $type64)
     )
     (struct.new $type63
      (ref.func $function54)
      (struct.new $environment54
       (local.get $1)
       (struct.get $environment53 0
        (local.get $3)
       )
       (struct.get $environment53 1
        (local.get $3)
       )
       (struct.get $environment53 2
        (local.get $3)
       )
       (struct.get $environment53 3
        (local.get $3)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type64 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call63
     (struct.get $type63 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type64 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type63 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function54 (type $call63) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment54))
  (local $4 (ref $type64))
  (local $5 (ref null $type46))
  (local $6 (ref null $type46))
  (local $7 (ref $type63))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment54 4
        (ref.cast (ref $environment54)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type43 1
      (struct.get $environment54 4
       (local.tee $3
        (ref.cast (ref $environment54)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment54 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type46))
      (i64.eq
       (struct.get $type43 1
        (struct.get $environment54 1
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type44 0
          (struct.get $environment54 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type43 0
          (struct.get $environment54 1
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type43 1
           (struct.get $environment54 1
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type45
        (struct.get $type44 1
         (struct.get $environment54 3
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type46 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (struct.get $environment54 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function54
      (struct.get $type63 1
       (struct.get $type64 1
        (struct.get $environment54 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type64 1
     (local.tee $4
      (struct.new_default $type64)
     )
     (struct.new $type63
      (ref.func $function55)
      (struct.new $environment55
       (struct.get $environment54 0
        (local.get $3)
       )
       (local.get $1)
       (struct.get $environment54 1
        (local.get $3)
       )
       (struct.get $environment54 2
        (local.get $3)
       )
       (struct.get $environment54 3
        (local.get $3)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type64 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call63
     (struct.get $type63 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type64 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type63 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function55 (type $call63) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment55))
  (local $4 (ref $type64))
  (local $5 (ref null $type46))
  (local $6 (ref null $type46))
  (local $7 (ref $type63))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment55 2
        (ref.cast (ref $environment55)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type43 1
      (struct.get $environment55 2
       (local.tee $3
        (ref.cast (ref $environment55)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment55 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type46))
      (i64.eq
       (struct.get $type43 1
        (struct.get $environment55 3
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type44 0
          (struct.get $environment55 4
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type43 0
          (struct.get $environment55 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type43 1
           (struct.get $environment55 3
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type45
        (struct.get $type44 1
         (struct.get $environment55 4
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type46 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (struct.get $environment55 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function55
      (struct.get $type63 1
       (struct.get $type64 1
        (struct.get $environment55 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type64 1
     (local.tee $4
      (struct.new_default $type64)
     )
     (struct.new $type63
      (ref.func $function56)
      (struct.new $environment56
       (struct.get $environment55 0
        (local.get $3)
       )
       (struct.get $environment55 1
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type64 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call63
     (struct.get $type63 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type64 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type63 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function56 (type $call63) (param $0 (ref struct)) (param $1 (ref null $type46)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment56))
  (local $4 (ref $type19))
  (local $5 (ref $type19))
  (local $6 (ref $type19))
  (local $7 (ref $type19))
  (local $scratch (ref $type19))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (struct.new $type16
     (struct.new $type22
      (struct.get $type46 0
       (struct.get $environment56 0
        (local.tee $3
         (ref.cast (ref $environment56)
          (local.get $0)
         )
        )
       )
      )
      (struct.get $type46 0
       (struct.get $environment56 1
        (local.get $3)
       )
      )
      (struct.get $type46 0
       (struct.get $environment56 2
        (local.get $3)
       )
      )
      (block (result (ref $type19))
       (local.set $scratch
        (struct.get $type46 0
         (local.get $1)
        )
       )
       (local.set $1
        (struct.get $type46 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type64 0
          (struct.get $environment56 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
     (call $function56
      (struct.get $type63 1
       (struct.get $type64 1
        (struct.get $environment56 3
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function57 (type $call33) (param $0 (ref null $environment57)) (param $1 i64) (result (ref $type23))
  (local $2 (ref $type55))
  (local $3 (ref $environment62))
  (local $4 (ref struct))
  (local $5 (ref $type64))
  (local $6 (ref $type66))
  (local $7 (ref $type71))
  (local $8 (ref $type69))
  (local $9 (ref $type53))
  (local $10 (ref null $type46))
  (local $11 (ref $type54))
  (local $12 (ref null $type35))
  (local $13 (ref $environment61))
  (local $14 (ref null $type16))
  (local $15 (ref null $type16))
  (local $16 (ref $type63))
  (local $17 (ref $type45))
  (local $18 (ref $environment30))
  (local $19 i64)
  (if
   (i32.eqz
    (struct.get $type43 0
     (struct.get $environment57 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type23))
   (i64.lt_s
    (struct.get $type43 1
     (struct.get $environment57 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (local.set $1
     (struct.get $environment57 2
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (struct.get $environment57 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type50 0
      (struct.get $type49 1
       (struct.get $environment57 1
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $14
     (if (result (ref null $type16))
      (i32.wrap_i64
       (i64.and
        (local.get $1)
        (i64.const 1)
       )
      )
      (then
       (ref.null none)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type44 0
          (struct.get $environment43 0
           (ref.cast (ref $environment43)
            (local.get $4)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $1
          (i64.div_s
           (local.get $1)
           (i64.const 2)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $10
        (array.get $type45
         (struct.get $type44 1
          (struct.get $environment43 0
           (ref.cast (ref $environment43)
            (local.get $4)
           )
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (struct.set $type64 1
        (local.tee $5
         (struct.new_default $type64)
        )
        (struct.new $type63
         (ref.func $function44)
         (struct.new $environment44
          (local.get $5)
         )
        )
       )
       (struct.set $type64 0
        (local.get $5)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type64 0
          (local.get $5)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call63
        (struct.get $type63 1
         (local.tee $16
          (ref.as_non_null
           (struct.get $type64 1
            (local.get $5)
           )
          )
         )
        )
        (local.get $10)
        (ref.null none)
        (struct.get $type63 0
         (local.get $16)
        )
       )
      )
     )
    )
    (local.set $1
     (struct.get $environment57 2
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (struct.get $environment57 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type50 0
      (struct.get $type49 1
       (struct.get $environment57 3
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready123)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global123)
     )
    )
    (struct.set $type55 1
     (local.tee $2
      (struct.new_default $type55)
     )
     (struct.new $type54
      (ref.func $function48)
      (struct.new $environment48
       (local.get $2)
       (local.tee $1
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
      )
     )
    )
    (struct.set $type55 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (call_ref $call54
      (struct.get $type54 1
       (local.tee $11
        (ref.as_non_null
         (struct.get $type55 1
          (local.get $2)
         )
        )
       )
      )
      (ref.null none)
      (i64.div_s
       (local.get $1)
       (i64.const 4)
      )
      (struct.get $type54 0
       (local.get $11)
      )
     )
    )
    (struct.set $type66 1
     (local.tee $6
      (struct.new_default $type66)
     )
     (struct.new $type65
      (struct.new $environment52
       (struct.get $environment46 0
        (ref.cast (ref $environment46)
         (local.get $4)
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type66 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $15
     (call $function52
      (struct.get $type65 0
       (struct.get $type66 1
        (local.get $6)
       )
      )
      (local.get $12)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (global.get $ready160)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global160)
     )
    )
    (if
     (i32.eqz
      (global.get $ready162)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (i32.eqz
      (global.get $ready165)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global165)
     )
    )
    (struct.set $type71 1
     (local.tee $7
      (struct.new_default $type71)
     )
     (struct.new $type70
      (struct.new $environment61
       (local.get $7)
      )
     )
    )
    (struct.set $type71 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment61 0
        (local.tee $13
         (struct.get $type70 0
          (struct.get $type71 1
           (local.get $7)
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment61 0
        (local.tee $13
         (struct.get $type70 0
          (struct.get $type71 1
           (struct.get $environment61 0
            (local.get $13)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type70 0
      (struct.get $type71 1
       (struct.get $environment61 0
        (local.get $13)
       )
      )
     )
    )
    (struct.set $type69 1
     (local.tee $8
      (struct.new_default $type69)
     )
     (struct.new $type68
      (struct.new $environment62
       (struct.new $type67
        (i32.const 1)
        (array.new $type23
         (local.get $14)
         (i32.const 2)
        )
       )
       (local.get $8)
      )
     )
    )
    (struct.set $type69 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type23
     (struct.get $type67 1
      (struct.get $environment62 0
       (local.tee $3
        (struct.get $type68 0
         (struct.get $type69 1
          (local.get $8)
         )
        )
       )
      )
     )
     (i32.const 0)
     (local.get $14)
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment62 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type23
     (struct.get $type67 1
      (struct.get $environment62 0
       (local.tee $3
        (struct.get $type68 0
         (struct.get $type69 1
          (struct.get $environment62 1
           (local.get $3)
          )
         )
        )
       )
      )
     )
     (i32.const 1)
     (local.get $15)
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment62 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.get $type67 1
     (struct.get $environment62 0
      (struct.get $type68 0
       (struct.get $type69 1
        (struct.get $environment62 1
         (local.get $3)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type44 0
       (struct.get $environment57 4
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type45
     (struct.get $type44 1
      (struct.get $environment57 4
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (struct.get $type47 0
         (struct.get $environment57 5
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $18
       (struct.get $type48 0
        (struct.get $type47 1
         (struct.get $environment57 5
          (local.get $0)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready76)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global76)
       )
      )
      (struct.set $type55 1
       (local.tee $2
        (struct.new_default $type55)
       )
       (struct.new $type54
        (ref.func $function32)
        (struct.new $environment32
         (local.get $2)
         (local.tee $19
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
        )
       )
      )
      (struct.set $type55 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type55 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $12
       (call_ref $call54
        (struct.get $type54 1
         (local.tee $11
          (ref.as_non_null
           (struct.get $type55 1
            (local.get $2)
           )
          )
         )
        )
        (ref.null none)
        (i64.div_s
         (local.get $19)
         (i64.const 3)
        )
        (struct.get $type54 0
         (local.get $11)
        )
       )
      )
      (struct.set $type53 1
       (local.tee $9
        (struct.new_default $type53)
       )
       (struct.new $type52
        (struct.new $environment39
         (struct.get $environment30 0
          (local.get $18)
         )
         (local.get $9)
        )
       )
      )
      (struct.set $type53 0
       (local.get $9)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type53 0
         (local.get $9)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $10
       (call $function39
        (struct.get $type52 0
         (struct.get $type53 1
          (local.get $9)
         )
        )
        (local.get $12)
        (ref.null none)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $10)
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment57 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (struct.get $type33 1
      (struct.get $type51 1
       (struct.get $environment57 6
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function63 (type $call36) (param $0 i64) (result i64)
  (local $1 (ref null $type16))
  (local $2 (ref $environment65))
  (local $3 (ref $type73))
  (local $4 (ref $type23))
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (array.get $type23
    (local.tee $4
     (call $function29
      (struct.get $type33 1
       (global.get $global70)
      )
      (local.get $0)
     )
    )
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (struct.set $type73 1
   (local.tee $3
    (struct.new_default $type73)
   )
   (struct.new $type72
    (struct.new $environment65
     (local.get $3)
    )
   )
  )
  (struct.set $type73 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type73 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type72 0
    (struct.get $type73 1
     (local.get $3)
    )
   )
  )
  (local.set $0
   (if (result i64)
    (ref.is_null
     (local.get $1)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $1
      (struct.get $type16 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (struct.get $type73 0
        (struct.get $environment65 0
         (local.get $2)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $2
      (struct.get $type72 0
       (struct.get $type73 1
        (struct.get $environment65 0
         (local.get $2)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type16 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type73 0
          (struct.get $environment65 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type72 0
         (struct.get $type73 1
          (struct.get $environment65 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type16 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type73 0
            (struct.get $environment65 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type72 0
           (struct.get $type73 1
            (struct.get $environment65 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type16 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type73 0
              (struct.get $environment65 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type72 0
             (struct.get $type73 1
              (struct.get $environment65 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type16 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type73 0
                (struct.get $environment65 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type72 0
               (struct.get $type73 1
                (struct.get $environment65 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type16 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type73 0
                  (struct.get $environment65 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type72 0
                 (struct.get $type73 1
                  (struct.get $environment65 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type16 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type73 0
                    (struct.get $environment65 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type72 0
                   (struct.get $type73 1
                    (struct.get $environment65 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type16 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type73 0
                      (struct.get $environment65 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type72 0
                     (struct.get $type73 1
                      (struct.get $environment65 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type16 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type73 0
                        (struct.get $environment65 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function65
                      (struct.get $type72 0
                       (struct.get $type73 1
                        (struct.get $environment65 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $1
   (array.get $type23
    (local.get $4)
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (struct.set $type73 1
   (local.tee $3
    (struct.new_default $type73)
   )
   (struct.new $type72
    (struct.new $environment65
     (local.get $3)
    )
   )
  )
  (struct.set $type73 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type73 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type72 0
    (struct.get $type73 1
     (local.get $3)
    )
   )
  )
  (i64.add
   (if (result i64)
    (ref.is_null
     (local.get $1)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $1
      (struct.get $type16 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (struct.get $type73 0
        (struct.get $environment65 0
         (local.get $2)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $2
      (struct.get $type72 0
       (struct.get $type73 1
        (struct.get $environment65 0
         (local.get $2)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type16 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type73 0
          (struct.get $environment65 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type72 0
         (struct.get $type73 1
          (struct.get $environment65 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type16 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type73 0
            (struct.get $environment65 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type72 0
           (struct.get $type73 1
            (struct.get $environment65 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type16 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type73 0
              (struct.get $environment65 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type72 0
             (struct.get $type73 1
              (struct.get $environment65 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type16 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type73 0
                (struct.get $environment65 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type72 0
               (struct.get $type73 1
                (struct.get $environment65 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type16 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type73 0
                  (struct.get $environment65 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type72 0
                 (struct.get $type73 1
                  (struct.get $environment65 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type16 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type73 0
                    (struct.get $environment65 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type72 0
                   (struct.get $type73 1
                    (struct.get $environment65 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type16 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type73 0
                      (struct.get $environment65 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type72 0
                     (struct.get $type73 1
                      (struct.get $environment65 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type16 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type73 0
                        (struct.get $environment65 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function65
                      (struct.get $type72 0
                       (struct.get $type73 1
                        (struct.get $environment65 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.get $0)
  )
 )
 (func $function65 (type $call72) (param $0 (ref $environment65)) (param $1 (ref null $type16)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type16 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type73 0
       (struct.get $environment65 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function65
     (struct.get $type72 0
      (struct.get $type73 1
       (struct.get $environment65 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function66 (type $call37) (param $0 (ref $type19)) (param $1 (ref null $type12)) (result (ref $type12))
  (local $2 (ref $type12))
  (local $3 (ref $type21))
  (if (result (ref $type12))
   (ref.test (ref $type20)
    (local.get $0)
   )
   (then
    (struct.new $type12
     (i64.const 0)
     (local.get $1)
    )
   )
   (else
    (local.set $0
     (struct.get $type21 0
      (local.tee $3
       (ref.cast (ref $type21)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global182)
     )
    )
    (local.set $2
     (call $function66
      (struct.get $type21 2
       (local.get $3)
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global182)
     )
    )
    (local.set $2
     (call $function66
      (struct.get $type21 1
       (local.get $3)
      )
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global182)
     )
    )
    (struct.new $type12
     (i64.const 1)
     (call $function66
      (local.get $0)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function68 (type $call39) (param $0 (ref null $type16)) (param $1 (ref null $type12)) (result (ref null $type12))
  (local $2 (ref $type12))
  (local $3 (ref $type17))
  (local $4 (ref $type19))
  (local $5 (ref $type22))
  (local $6 (ref $type18))
  (if (result (ref null $type12))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $3
     (struct.get $type16 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $function68
      (struct.get $type16 1
       (local.get $0)
      )
      (block (result (ref null $type12))
       (if
        (i32.eqz
         (global.get $ready199)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global199)
        )
       )
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready189)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global189)
     )
    )
    (if (result (ref $type12))
     (ref.test (ref $type18)
      (local.get $3)
     )
     (then
      (local.set $4
       (struct.get $type18 0
        (local.tee $6
         (ref.cast (ref $type18)
          (local.get $3)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready182)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global182)
       )
      )
      (local.set $2
       (call $function66
        (struct.get $type18 1
         (local.get $6)
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready182)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global182)
       )
      )
      (struct.new $type12
       (i64.const 2)
       (call $function66
        (local.get $4)
        (local.get $2)
       )
      )
     )
     (else
      (local.set $4
       (struct.get $type22 0
        (local.tee $5
         (ref.cast (ref $type22)
          (local.get $3)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready182)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global182)
       )
      )
      (local.set $2
       (call $function66
        (struct.get $type22 3
         (local.get $5)
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready182)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global182)
       )
      )
      (local.set $2
       (call $function66
        (struct.get $type22 2
         (local.get $5)
        )
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready182)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global182)
       )
      )
      (local.set $2
       (call $function66
        (struct.get $type22 1
         (local.get $5)
        )
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready182)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global182)
       )
      )
      (struct.new $type12
       (i64.const 3)
       (call $function66
        (local.get $4)
        (local.get $2)
       )
      )
     )
    )
   )
  )
 )
 (func $function69 (type $call40) (param $0 (ref $type23)) (result (ref $type12))
  (local $1 (ref $environment65))
  (local $2 (ref null $type16))
  (local $3 (ref null $type16))
  (local $4 (ref null $type16))
  (local $5 (ref $type73))
  (local $6 (ref null $type12))
  (local $7 i64)
  (local $8 i64)
  (local.set $3
   (array.get $type23
    (local.get $0)
    (i32.const 0)
   )
  )
  (local.set $4
   (array.get $type23
    (local.get $0)
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (struct.set $type73 1
   (local.tee $5
    (struct.new_default $type73)
   )
   (struct.new $type72
    (struct.new $environment65
     (local.get $5)
    )
   )
  )
  (struct.set $type73 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type73 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type72 0
    (struct.get $type73 1
     (local.get $5)
    )
   )
  )
  (struct.new $type12
   (if (result i64)
    (ref.is_null
     (local.get $3)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $2
      (struct.get $type16 1
       (local.get $3)
      )
     )
     (if
      (i32.eqz
       (struct.get $type73 0
        (struct.get $environment65 0
         (local.get $1)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $1
      (struct.get $type72 0
       (struct.get $type73 1
        (struct.get $environment65 0
         (local.get $1)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $2)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $2
        (struct.get $type16 1
         (local.get $2)
        )
       )
       (if
        (i32.eqz
         (struct.get $type73 0
          (struct.get $environment65 0
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (struct.get $type72 0
         (struct.get $type73 1
          (struct.get $environment65 0
           (local.get $1)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $2)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $2
          (struct.get $type16 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (struct.get $type73 0
            (struct.get $environment65 0
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type72 0
           (struct.get $type73 1
            (struct.get $environment65 0
             (local.get $1)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $2
            (struct.get $type16 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (struct.get $type73 0
              (struct.get $environment65 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type72 0
             (struct.get $type73 1
              (struct.get $environment65 0
               (local.get $1)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $2
              (struct.get $type16 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (struct.get $type73 0
                (struct.get $environment65 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type72 0
               (struct.get $type73 1
                (struct.get $environment65 0
                 (local.get $1)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $2
                (struct.get $type16 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type73 0
                  (struct.get $environment65 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type72 0
                 (struct.get $type73 1
                  (struct.get $environment65 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $2
                  (struct.get $type16 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type73 0
                    (struct.get $environment65 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type72 0
                   (struct.get $type73 1
                    (struct.get $environment65 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $2
                    (struct.get $type16 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type73 0
                      (struct.get $environment65 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type72 0
                     (struct.get $type73 1
                      (struct.get $environment65 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $2
                      (struct.get $type16 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type73 0
                        (struct.get $environment65 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function65
                      (struct.get $type72 0
                       (struct.get $type73 1
                        (struct.get $environment65 0
                         (local.get $1)
                        )
                       )
                      )
                      (local.get $2)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (block (result (ref null $type12))
    (if
     (i32.eqz
      (global.get $ready176)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (struct.set $type73 1
     (local.tee $5
      (struct.new_default $type73)
     )
     (struct.new $type72
      (struct.new $environment65
       (local.get $5)
      )
     )
    )
    (struct.set $type73 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type73 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type72 0
      (struct.get $type73 1
       (local.get $5)
      )
     )
    )
    (local.set $8
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $2
        (struct.get $type16 1
         (local.get $4)
        )
       )
       (if
        (i32.eqz
         (struct.get $type73 0
          (struct.get $environment65 0
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (struct.get $type72 0
         (struct.get $type73 1
          (struct.get $environment65 0
           (local.get $1)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $2)
        )
        (then
         (i64.const 1)
        )
        (else
         (local.set $2
          (struct.get $type16 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (struct.get $type73 0
            (struct.get $environment65 0
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type72 0
           (struct.get $type73 1
            (struct.get $environment65 0
             (local.get $1)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 2)
          )
          (else
           (local.set $2
            (struct.get $type16 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (struct.get $type73 0
              (struct.get $environment65 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type72 0
             (struct.get $type73 1
              (struct.get $environment65 0
               (local.get $1)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i64.const 3)
            )
            (else
             (local.set $2
              (struct.get $type16 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (struct.get $type73 0
                (struct.get $environment65 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type72 0
               (struct.get $type73 1
                (struct.get $environment65 0
                 (local.get $1)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i64.const 4)
              )
              (else
               (local.set $2
                (struct.get $type16 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type73 0
                  (struct.get $environment65 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type72 0
                 (struct.get $type73 1
                  (struct.get $environment65 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (local.set $2
                  (struct.get $type16 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type73 0
                    (struct.get $environment65 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type72 0
                   (struct.get $type73 1
                    (struct.get $environment65 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type16 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type73 0
                      (struct.get $environment65 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type72 0
                     (struct.get $type73 1
                      (struct.get $environment65 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (local.set $2
                      (struct.get $type16 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type73 0
                        (struct.get $environment65 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type72 0
                       (struct.get $type73 1
                        (struct.get $environment65 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (local.set $2
                        (struct.get $type16 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type73 0
                          (struct.get $environment65 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function65
                        (struct.get $type72 0
                         (struct.get $type73 1
                          (struct.get $environment65 0
                           (local.get $1)
                          )
                         )
                        )
                        (local.get $2)
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready199)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global199)
     )
    )
    (local.set $6
     (call $function68
      (local.get $4)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (global.get $ready199)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global199)
     )
    )
    (call $function68
     (local.get $3)
     (struct.new $type12
      (local.get $8)
      (local.get $6)
     )
    )
   )
  )
 )
 (func $function70 (result i64)
  (local $0 (ref null $type12))
  (local $1 (ref null $type12))
  (local $2 (ref $type12))
  (local $3 (ref $type23))
  (local $scratch (ref $type23))
  (local $scratch_5 (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready181)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function69
    (block (result (ref $type23))
     (local.set $scratch
      (call $function29
       (struct.get $type33 1
        (global.get $global70)
       )
       (global.get $global181)
      )
     )
     (if
      (i32.eqz
       (global.get $ready202)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global202)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready63)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global63)
   )
  )
  (local.set $0
   (call $function26)
  )
  (if
   (i32.eqz
    (global.get $ready67)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global67)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $0)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $2)
        )
        (struct.get $type12 0
         (local.get $0)
        )
       )
       (then
        (local.set $0
         (struct.get $type12 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready67)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global67)
         )
        )
        (if (result i32)
         (ref.is_null
          (local.tee $1
           (struct.get $type12 1
            (local.get $2)
           )
          )
         )
         (then
          (ref.is_null
           (local.get $0)
          )
         )
         (else
          (if (result i32)
           (ref.is_null
            (local.get $0)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (i64.eq
              (struct.get $type12 0
               (local.get $1)
              )
              (struct.get $type12 0
               (local.get $0)
              )
             )
             (then
              (local.set $1
               (struct.get $type12 1
                (local.get $1)
               )
              )
              (local.set $0
               (struct.get $type12 1
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (global.get $ready67)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global67)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $1)
               )
               (then
                (ref.is_null
                 (local.get $0)
                )
               )
               (else
                (if (result i32)
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if (result i32)
                   (i64.eq
                    (struct.get $type12 0
                     (local.get $1)
                    )
                    (struct.get $type12 0
                     (local.get $0)
                    )
                   )
                   (then
                    (local.set $1
                     (struct.get $type12 1
                      (local.get $1)
                     )
                    )
                    (local.set $0
                     (struct.get $type12 1
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready67)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global67)
                     )
                    )
                    (if (result i32)
                     (ref.is_null
                      (local.get $1)
                     )
                     (then
                      (ref.is_null
                       (local.get $0)
                      )
                     )
                     (else
                      (if (result i32)
                       (ref.is_null
                        (local.get $0)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (i64.eq
                          (struct.get $type12 0
                           (local.get $1)
                          )
                          (struct.get $type12 0
                           (local.get $0)
                          )
                         )
                         (then
                          (local.set $1
                           (struct.get $type12 1
                            (local.get $1)
                           )
                          )
                          (local.set $0
                           (struct.get $type12 1
                            (local.get $0)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready67)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global67)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (ref.is_null
                             (local.get $0)
                            )
                           )
                           (else
                            (if (result i32)
                             (ref.is_null
                              (local.get $0)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if (result i32)
                               (i64.eq
                                (struct.get $type12 0
                                 (local.get $1)
                                )
                                (struct.get $type12 0
                                 (local.get $0)
                                )
                               )
                               (then
                                (local.set $1
                                 (struct.get $type12 1
                                  (local.get $1)
                                 )
                                )
                                (local.set $0
                                 (struct.get $type12 1
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready67)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global67)
                                 )
                                )
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $1)
                                 )
                                 (then
                                  (ref.is_null
                                   (local.get $0)
                                  )
                                 )
                                 (else
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $0)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (i64.eq
                                      (struct.get $type12 0
                                       (local.get $1)
                                      )
                                      (struct.get $type12 0
                                       (local.get $0)
                                      )
                                     )
                                     (then
                                      (local.set $1
                                       (struct.get $type12 1
                                        (local.get $1)
                                       )
                                      )
                                      (local.set $0
                                       (struct.get $type12 1
                                        (local.get $0)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready67)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global67)
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                       (then
                                        (ref.is_null
                                         (local.get $0)
                                        )
                                       )
                                       (else
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $0)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if (result i32)
                                           (i64.eq
                                            (struct.get $type12 0
                                             (local.get $1)
                                            )
                                            (struct.get $type12 0
                                             (local.get $0)
                                            )
                                           )
                                           (then
                                            (local.set $1
                                             (struct.get $type12 1
                                              (local.get $1)
                                             )
                                            )
                                            (local.set $0
                                             (struct.get $type12 1
                                              (local.get $0)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready67)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global67)
                                             )
                                            )
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $1)
                                             )
                                             (then
                                              (ref.is_null
                                               (local.get $0)
                                              )
                                             )
                                             (else
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $0)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (if (result i32)
                                                 (i64.eq
                                                  (struct.get $type12 0
                                                   (local.get $1)
                                                  )
                                                  (struct.get $type12 0
                                                   (local.get $0)
                                                  )
                                                 )
                                                 (then
                                                  (local.set $1
                                                   (struct.get $type12 1
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (local.set $0
                                                   (struct.get $type12 1
                                                    (local.get $0)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready67)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global67)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $1)
                                                   )
                                                   (then
                                                    (ref.is_null
                                                     (local.get $0)
                                                    )
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $0)
                                                     )
                                                     (then
                                                      (i32.const 0)
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (i64.eq
                                                        (struct.get $type12 0
                                                         (local.get $1)
                                                        )
                                                        (struct.get $type12 0
                                                         (local.get $0)
                                                        )
                                                       )
                                                       (then
                                                        (local.set $1
                                                         (struct.get $type12 1
                                                          (local.get $1)
                                                         )
                                                        )
                                                        (local.set $0
                                                         (struct.get $type12 1
                                                          (local.get $0)
                                                         )
                                                        )
                                                        (if
                                                         (i32.eqz
                                                          (global.get $ready67)
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                        )
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global67)
                                                         )
                                                        )
                                                        (if (result i32)
                                                         (ref.is_null
                                                          (local.get $1)
                                                         )
                                                         (then
                                                          (ref.is_null
                                                           (local.get $0)
                                                          )
                                                         )
                                                         (else
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $0)
                                                           )
                                                           (then
                                                            (i32.const 0)
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (i64.eq
                                                              (struct.get $type12 0
                                                               (local.get $1)
                                                              )
                                                              (struct.get $type12 0
                                                               (local.get $0)
                                                              )
                                                             )
                                                             (then
                                                              (call $function28
                                                               (struct.get $type12 1
                                                                (local.get $1)
                                                               )
                                                               (block (result (ref null $type12))
                                                                (local.set $scratch_5
                                                                 (struct.get $type12 1
                                                                  (local.get $0)
                                                                 )
                                                                )
                                                                (if
                                                                 (i32.eqz
                                                                  (global.get $ready67)
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global67)
                                                                 )
                                                                )
                                                                (local.get $scratch_5)
                                                               )
                                                              )
                                                             )
                                                             (else
                                                              (i32.const 0)
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (else
                                                        (i32.const 0)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (i32.const 0)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (else
                                            (i32.const 0)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (i32.const 0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (i32.const 0)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function72 (type $call29) (param $0 (ref null $environment72)) (param $1 i64) (param $2 i64) (result i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment72 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready181)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready213)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global213)
     )
    )
    (local.set $2
     (call $function63
      (block (result i64)
       (local.set $scratch
        (call $foreign2
         (global.get $global181)
        )
       )
       (if
        (i32.eqz
         (global.get $ready173)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global173)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (struct.get $environment72 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function72
     (struct.get $type29 1
      (struct.get $type74 1
       (struct.get $environment72 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function73 (type $call29) (param $0 (ref null $environment72)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign2
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type74))
  (local $2 (ref $type29))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready208)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global208)
   )
  )
  (struct.set $type74 1
   (local.tee $1
    (struct.new_default $type74)
   )
   (struct.new $type29
    (ref.func $function72)
    (struct.new $environment72
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type74 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type74 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type29 0
    (local.get $2)
   )
  )
 )
 (func $export1 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready206)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (return_call $function70)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global84
   (struct.new_default $type11)
  )
  (global.set $ready84
   (i32.const 1)
  )
  (global.set $global160
   (struct.new_default $type14)
  )
  (global.set $ready160
   (i32.const 1)
  )
  (global.set $global86
   (struct.new_default $type24)
  )
  (global.set $ready86
   (i32.const 1)
  )
  (global.set $global162
   (struct.new_default $type25)
  )
  (global.set $ready162
   (i32.const 1)
  )
  (global.set $global89
   (struct.new_default $type26)
  )
  (global.set $ready89
   (i32.const 1)
  )
  (global.set $global165
   (struct.new_default $type27)
  )
  (global.set $ready165
   (i32.const 1)
  )
  (global.set $global176
   (struct.new_default $type28)
  )
  (global.set $ready176
   (i32.const 1)
  )
  (global.set $global132
   (struct.new $type29
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type30)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global63
   (struct.new_default $type31)
  )
  (global.set $ready63
   (i32.const 1)
  )
  (global.set $global67
   (struct.new_default $type32)
  )
  (global.set $ready67
   (i32.const 1)
  )
  (global.set $global213
   (struct.new $type29
    (ref.func $function73)
    (ref.null none)
   )
  )
  (global.set $ready213
   (i32.const 1)
  )
  (global.set $global70
   (struct.new $type33
    (ref.func $function29)
    (ref.null none)
   )
  )
  (global.set $ready70
   (i32.const 1)
  )
  (global.set $global76
   (struct.new_default $type34)
  )
  (global.set $ready76
   (i32.const 1)
  )
  (global.set $global123
   (struct.new_default $type34)
  )
  (global.set $ready123
   (i32.const 1)
  )
  (global.set $global173
   (struct.new_default $type36)
  )
  (global.set $ready173
   (i32.const 1)
  )
  (global.set $global181
   (call $foreign3
    (i32.const 0)
   )
  )
  (global.set $ready181
   (i32.const 1)
  )
  (global.set $global182
   (struct.new_default $type37)
  )
  (global.set $ready182
   (i32.const 1)
  )
  (global.set $global189
   (struct.new_default $type38)
  )
  (global.set $ready189
   (i32.const 1)
  )
  (global.set $global199
   (struct.new_default $type39)
  )
  (global.set $ready199
   (i32.const 1)
  )
  (global.set $global202
   (struct.new_default $type40)
  )
  (global.set $ready202
   (i32.const 1)
  )
  (global.set $global206
   (struct.new_default $type36)
  )
  (global.set $ready206
   (i32.const 1)
  )
  (global.set $global208
   (struct.new_default $type36)
  )
  (global.set $ready208
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

