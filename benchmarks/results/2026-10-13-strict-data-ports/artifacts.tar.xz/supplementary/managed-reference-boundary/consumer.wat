(module
  (type $node (struct (field (ref null $node)) (field i64)))
  (type $values (array (mut f64)))
  (import "host" "collect" (func $collect))
  (import "provider" "observe" (func $observe (param (ref $node)) (param (ref $values))))
  (func (export "main")
    (local $root (ref null $node))
    (local $array (ref null $values))
    (local.set $root
      (struct.new $node
        (struct.new $node (ref.null $node) (i64.const 7))
        (i64.const 42)))
    (local.set $array (array.new $values (f64.const 3.5) (i32.const 8)))
    (call $collect)
    (call $observe (ref.as_non_null (local.get $root)) (ref.as_non_null (local.get $array))))
)
