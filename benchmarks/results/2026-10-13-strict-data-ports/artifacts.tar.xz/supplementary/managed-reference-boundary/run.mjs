import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const module = await WebAssembly.compile(readFileSync(process.argv[2]));
const outcomes = [];
for (const mode of ['valid', 'plain-object', 'null', 'wrong-array-type']) {
  let instance;
  let root;
  let array;
  let collected = 0;
  const host = {
    collect() { globalThis.gc(); collected++; },
    observe(node, values) {
      root = node;
      array = values;
      globalThis.gc();
      assert.equal(instance.exports.value(node), 42n);
      assert.equal(instance.exports['child-value'](node), 7n);
      assert.equal(instance.exports['array-value'](values), 3.5);
    },
    identity(node) {
      assert.equal(node, root);
      return {valid: node, 'plain-object': {}, null: null, 'wrong-array-type': array}[mode];
    },
  };
  instance = await WebAssembly.instantiate(module, {host});
  if (mode === 'valid') {
    assert.equal(instance.exports.main(), 42n);
    globalThis.gc();
    assert.equal(instance.exports['child-value'](root), 7n);
    assert.equal(instance.exports['array-value'](array), 3.5);
  } else {
    assert.throws(() => instance.exports.main(), TypeError);
  }
  assert.equal(collected, 1);
  outcomes.push({mode, passed: true});
}
console.log(JSON.stringify({artifact: process.argv[2], outcomes}));
