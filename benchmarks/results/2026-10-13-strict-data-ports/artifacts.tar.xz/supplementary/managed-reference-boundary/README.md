# Managed-reference boundary probe

This is a hand-written Wasm probe on compiler baseline `9c4d1b2`, not implemented
Scheme extern support and not a performance measurement. It uses Node 24.19.0,
Binaryen 132, and the compiler's explicit Wasm feature flags.

`probe.wat` and `run.mjs` show that a JavaScript import can receive an opaque
recursive GC struct and GC array, preserve their identity, and return the struct
with its declared non-null Wasm type. Actual raw and optimized execution accepts
the valid reference and rejects an ordinary JavaScript object, null, and the
wrong array reference. Field-reading Wasm exports still see the expected child
and array values after explicit GC. Those exports make payloads observable;
this probe does not establish allocation retention for a module without them.
The exact commands and outputs are in `results.json`.

`consumer.wat` and `provider.wat` use a separately instantiated Wasm provider
which reads the recursive child and array. Both open-world and closed-world
optimization preserve the typed import layout and link successfully in this
example (`link-results.json`). This does not establish a general cross-module
ABI: nominal semantic types, recursive-group identity, and optimizer contracts
still need a design. In particular Binaryen's closed-world option promises that
outside code may retain or return GC references but does not inspect them.

The unpinned optimized consumer moves the pure struct/array constructions past
the host collection call. Thus a final consumption alone cannot establish that
an object was alive during earlier activity. `consumer.pinned.wat` calls the
provider before and after collection. Its optimized disassembly visibly keeps
the same two references in locals across the collection import; the provider
observes all payloads on both sides. Raw and optimized runs pass, including a
host assertion that the first observation occurred before collection. Commands
and outputs are in `pinned-results.json`. This bounded probe does not prove the
corresponding lifetime in gcbench's independently compiled program.

The first assembly attempt used `--all-features`; both outputs failed Node
validation with `unknown import kind 0x7f @+57`. Those binaries are retained as
`raw.all-features.wasm` and `optimized.all-features.wasm`. All successful checks
use the project's explicit feature set instead. No compiler source was changed.
