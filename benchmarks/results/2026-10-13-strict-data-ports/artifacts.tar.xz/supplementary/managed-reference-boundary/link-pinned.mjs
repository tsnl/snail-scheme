import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const provider = (await WebAssembly.instantiate(readFileSync(process.argv[2]))).instance;
const consumer = (await WebAssembly.instantiate(readFileSync(process.argv[3]), {
  provider: provider.exports,
  host: {collect() { assert.equal(provider.exports.observed(), 49n); globalThis.gc(); }},
})).instance;
consumer.exports.main();
assert.equal(provider.exports.observed(), 49n);
console.log(JSON.stringify({provider: process.argv[2], consumer: process.argv[3], passed: true}));
