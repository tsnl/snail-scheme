(module
  (type $node (struct (field (ref null $node)) (field i64)))
  (type $values (array (mut f64)))
  (global $seen (mut i64) (i64.const 0))
  (func (export "observe") (param $root (ref $node)) (param $array (ref $values))
    (global.set $seen
      (i64.add
        (struct.get $node 1 (local.get $root))
        (struct.get $node 1 (ref.as_non_null (struct.get $node 0 (local.get $root))))))
    (if (f64.ne (array.get $values (local.get $array) (i32.const 2)) (f64.const 3.5))
      (then (unreachable))))
  (func (export "observed") (result i64) (global.get $seen))
)
