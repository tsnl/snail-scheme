(module
 (type $0 (struct (field (ref null $0)) (field i64)))
 (type $1 (array (mut f64)))
 (type $2 (func))
 (type $3 (func (param (ref $0) (ref $1))))
 (import "host" "collect" (func $fimport$0))
 (import "provider" "observe" (func $fimport$1 (param (ref $0) (ref $1))))
 (export "main" (func $0))
 (func $0
  (local $0 (ref $0))
  (local $1 (ref $1))
  (call $fimport$1
   (local.tee $0
    (struct.new $0
     (struct.new $0
      (ref.null none)
      (i64.const 7)
     )
     (i64.const 42)
    )
   )
   (local.tee $1
    (array.new $1
     (f64.const 3.5)
     (i32.const 8)
    )
   )
  )
  (call $fimport$0)
  (call $fimport$1
   (local.get $0)
   (local.get $1)
  )
 )
)

