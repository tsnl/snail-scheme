(module
 (rec
  (type $type12 (sub (struct)))
  (type $call55 (func (param (ref $environment64) i64) (result i32)))
  (type $environment62 (struct (field (ref $type31)) (field (ref $type42)) (field i64) (field (ref $type52)) (field (ref $type33))))
  (type $environment59 (struct (field (ref $type31)) (field (ref $type46)) (field (ref $type50)) (field i64) (field (ref $type42)) (field (ref $type33))))
  (type $call51 (func (param (ref $environment53) i64 (ref $type12)) (result i32)))
  (type $5 (func (param (ref $environment52) i64) (result (ref $type14))))
  (type $call41 (func (param (ref $environment47) i64 (ref $type12)) (result i32)))
  (type $7 (func (param (ref $environment46) i64 i64 (ref $type14))))
  (type $type55 (struct (field (ref $environment64))))
  (type $environment64 (struct (field (ref $type23)) (field (ref $type56))))
  (type $environment55 (struct (field (ref $type31)) (field (ref $type33)) (field (ref $type33))))
  (type $environment54 (struct (field (ref $type31)) (field (ref $type32)) (field (ref $type33))))
  (type $environment56 (struct (field (ref $type38)) (field (ref $type46)) (field (ref $type50)) (field (ref $type42)) (field (ref $type52))))
  (type $type43 (struct (field (ref $environment46))))
  (type $environment46 (struct (field (ref $type40))))
  (type $environment57 (struct (field (ref $type38)) (field i64)))
  (type $type53 (struct (field (ref $environment52))))
  (type $environment52 (struct (field (ref $type46)) (field (ref $type52))))
  (type $type51 (struct (field (ref $environment53))))
  (type $environment53 (struct (field (ref $type46)) (field (ref $type50))))
  (type $type41 (struct (field (ref $environment47))))
  (type $environment47 (struct (field (ref $type40))))
  (type $call20 (func (param (ref null $environment45) i64 i64) (result i64)))
  (type $environment45 (struct (field (ref $type54))))
  (type $type15 (struct (field (mut (ref $type12)))))
  (type $type47 (struct (field (ref $environment48))))
  (type $type39 (struct (field (ref $type13))))
  (type $type38 (struct (field (ref $type19))))
  (type $type42 (struct (field (ref $type43))))
  (type $type56 (struct (field (mut i32)) (field (mut (ref null $type55)))))
  (type $type54 (struct (field (mut i32)) (field (mut (ref null $type20)))))
  (type $type52 (struct (field (mut i32)) (field (mut (ref null $type53)))))
  (type $type50 (struct (field (mut i32)) (field (mut (ref null $type51)))))
  (type $type46 (struct (field (ref $type47))))
  (type $type14 (sub $type12 (struct (field (ref $type15)) (field (ref $type15)) (field i64))))
  (type $type13 (sub $type12 (struct)))
  (type $environment48 (struct (field (ref $type39))))
  (type $type40 (struct (field (mut i32)) (field (mut (ref null $type41)))))
  (type $call36 (func (param (ref $environment40) (ref null $type25) (ref $type25)) (result (ref null $type25))))
  (type $type36 (struct (field (ref $environment40))))
  (type $type37 (struct (field (mut i32)) (field (mut (ref null $type36)))))
  (type $environment40 (struct (field (ref $type37))))
  (type $call26 (func (param (ref null $type25) (ref null $type25)) (result i32)))
  (type $call34 (func (param (ref $environment36) i64 (ref $type25)) (result (ref null $type25))))
  (type $type34 (struct (field (ref $environment36))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type34)))))
  (type $type25 (struct (field i64) (field (ref null $type25))))
  (type $environment36 (struct (field (ref $type35))))
  (type $call24 (func (result (ref null $type25))))
  (type $type33 (struct (field (mut i32)) (field (mut (ref null $type30)))))
  (type $type32 (struct (field (ref $type23))))
  (type $type31 (struct (field i64)))
  (type $environment34 (struct (field (ref $type31)) (field (ref $type32)) (field (ref $type33))))
  (type $call30 (func (param structref i64) (result i32)))
  (type $type30 (struct (field (ref $call30)) (field structref)))
  (type $type10 (struct))
  (type $type29 (struct))
  (type $type23 (array (mut f64)))
  (type $type28 (struct))
  (type $type27 (struct (field (mut (ref null $type25)))))
  (type $type26 (struct))
  (type $type24 (struct))
  (type $type22 (struct))
  (type $type21 (struct))
  (type $type20 (struct (field (ref $call20)) (field (ref null $environment45))))
  (type $type19 (struct (field (ref null $environment57))))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type11 (struct))
 )
 (type $70 (func (param i32) (result i64)))
 (type $71 (func (result i64)))
 (type $72 (func (param i64) (result i64)))
 (type $73 (func (param i64 i64)))
 (type $74 (func (param i32 i64) (result f64)))
 (type $75 (func (param i64)))
 (type $76 (func))
 (import "benchmark" "vector_length" (func $foreign0 (param i32) (result i64)))
 (import "benchmark" "vector_f64" (func $foreign1 (param i32 i64) (result f64)))
 (import "benchmark" "expected_length" (func $foreign2 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign3 (param i64) (result i64)))
 (import "benchmark" "print_text" (func $foreign4 (param i64)))
 (import "benchmark" "print_size" (func $foreign5 (param i64 i64)))
 (import "benchmark" "print_construction" (func $foreign6 (param i64 i64)))
 (import "benchmark" "input_i64" (func $foreign7 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type11)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type11)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global70 (mut (ref null $type16)) (ref.null none))
 (global $ready70 (mut i32) (i32.const 0))
 (global $global75 (mut (ref null $type17)) (ref.null none))
 (global $ready75 (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type17)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type18)) (ref.null none))
 (global $ready79 (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type18)) (ref.null none))
 (global $ready82 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type19)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type20)) (ref.null none))
 (global $ready170 (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type21)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type22)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type24)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global97 (mut (ref null $type26)) (ref.null none))
 (global $ready97 (mut i32) (i32.const 0))
 (global $global100 (mut (ref null $type27)) (ref.null none))
 (global $ready100 (mut i32) (i32.const 0))
 (global $global101 (mut (ref null $type28)) (ref.null none))
 (global $ready101 (mut i32) (i32.const 0))
 (global $global105 (mut (ref null $type24)) (ref.null none))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global109 (mut i64) (i64.const 0))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type23)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type29)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type10)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type30)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global174 (mut (ref null $type19)) (ref.null none))
 (global $ready174 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function34 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment34))
  (local $3 f64)
  (if (result i32)
   (i64.gt_s
    (struct.get $type31 0
     (struct.get $environment34 0
      (local.tee $2
       (ref.cast (ref $environment34)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $3
     (call $foreign1
      (i32.const 1)
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type23
     (struct.get $type32 0
      (struct.get $environment34 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment34 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function34
     (struct.get $type30 1
      (struct.get $type33 1
       (struct.get $environment34 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function35 (type $call24) (result (ref null $type25))
  (local $0 i64)
  (local $1 i64)
  (local $2 (ref $environment36))
  (local $3 (ref $type25))
  (local $4 (ref $type35))
  (local.set $0
   (call $foreign2)
  )
  (struct.set $type35 1
   (local.tee $4
    (struct.new_default $type35)
   )
   (struct.new $type34
    (struct.new $environment36
     (local.get $4)
    )
   )
  )
  (struct.set $type35 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type34 0
    (struct.get $type35 1
     (local.get $4)
    )
   )
  )
  (if (result (ref null $type25))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $3
     (struct.new $type25
      (call $foreign3
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
      (block (result nullref)
       (if
        (i32.eqz
         (struct.get $type35 0
          (struct.get $environment36 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type34 0
         (struct.get $type35 1
          (struct.get $environment36 0
           (local.get $2)
          )
         )
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type25))
     (i64.eqz
      (local.tee $0
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $3
       (struct.new $type25
        (call $foreign3
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (block (result (ref $type25))
         (if
          (i32.eqz
           (struct.get $type35 0
            (struct.get $environment36 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type34 0
           (struct.get $type35 1
            (struct.get $environment36 0
             (local.get $2)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (if (result (ref $type25))
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (local.get $3)
       )
       (else
        (local.set $3
         (struct.new $type25
          (call $foreign3
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
          (block (result (ref $type25))
           (if
            (i32.eqz
             (struct.get $type35 0
              (struct.get $environment36 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type34 0
             (struct.get $type35 1
              (struct.get $environment36 0
               (local.get $2)
              )
             )
            )
           )
           (local.get $3)
          )
         )
        )
        (if (result (ref $type25))
         (i64.eqz
          (local.tee $0
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $3)
         )
         (else
          (local.set $3
           (struct.new $type25
            (call $foreign3
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
            (block (result (ref $type25))
             (if
              (i32.eqz
               (struct.get $type35 0
                (struct.get $environment36 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type34 0
               (struct.get $type35 1
                (struct.get $environment36 0
                 (local.get $2)
                )
               )
              )
             )
             (local.get $3)
            )
           )
          )
          (if (result (ref $type25))
           (i64.eqz
            (local.tee $0
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $3)
           )
           (else
            (local.set $3
             (struct.new $type25
              (call $foreign3
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
              (block (result (ref $type25))
               (if
                (i32.eqz
                 (struct.get $type35 0
                  (struct.get $environment36 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type34 0
                 (struct.get $type35 1
                  (struct.get $environment36 0
                   (local.get $2)
                  )
                 )
                )
               )
               (local.get $3)
              )
             )
            )
            (if (result (ref $type25))
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $3)
             )
             (else
              (local.set $3
               (struct.new $type25
                (call $foreign3
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
                (block (result (ref $type25))
                 (if
                  (i32.eqz
                   (struct.get $type35 0
                    (struct.get $environment36 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type34 0
                   (struct.get $type35 1
                    (struct.get $environment36 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (local.get $3)
                )
               )
              )
              (if (result (ref $type25))
               (i64.eqz
                (local.tee $0
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $3)
               )
               (else
                (local.set $3
                 (struct.new $type25
                  (call $foreign3
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                  (block (result (ref $type25))
                   (if
                    (i32.eqz
                     (struct.get $type35 0
                      (struct.get $environment36 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type34 0
                     (struct.get $type35 1
                      (struct.get $environment36 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (local.get $3)
                  )
                 )
                )
                (if (result (ref $type25))
                 (i64.eqz
                  (local.tee $0
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (local.set $3
                   (struct.new $type25
                    (call $foreign3
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                    (block (result (ref $type25))
                     (if
                      (i32.eqz
                       (struct.get $type35 0
                        (struct.get $environment36 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $2
                      (struct.get $type34 0
                       (struct.get $type35 1
                        (struct.get $environment36 0
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (local.get $3)
                    )
                   )
                  )
                  (if (result (ref $type25))
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (local.set $3
                     (struct.new $type25
                      (call $foreign3
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                      (block (result (ref $type25))
                       (if
                        (i32.eqz
                         (struct.get $type35 0
                          (struct.get $environment36 0
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $2
                        (struct.get $type34 0
                         (struct.get $type35 1
                          (struct.get $environment36 0
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (local.get $3)
                      )
                     )
                    )
                    (if (result (ref $type25))
                     (i64.eqz
                      (local.tee $0
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $3)
                     )
                     (else
                      (local.set $3
                       (struct.new $type25
                        (call $foreign3
                         (i64.sub
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                        (block (result (ref $type25))
                         (if
                          (i32.eqz
                           (struct.get $type35 0
                            (struct.get $environment36 0
                             (local.get $2)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $2
                          (struct.get $type34 0
                           (struct.get $type35 1
                            (struct.get $environment36 0
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (local.get $3)
                        )
                       )
                      )
                      (if (result (ref $type25))
                       (i64.eqz
                        (local.tee $0
                         (i64.sub
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $3)
                       )
                       (else
                        (local.set $3
                         (struct.new $type25
                          (call $foreign3
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                          (block (result (ref $type25))
                           (if
                            (i32.eqz
                             (struct.get $type35 0
                              (struct.get $environment36 0
                               (local.get $2)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $2
                            (struct.get $type34 0
                             (struct.get $type35 1
                              (struct.get $environment36 0
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (local.get $3)
                          )
                         )
                        )
                        (if (result (ref $type25))
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (local.get $3)
                         )
                         (else
                          (local.set $3
                           (struct.new $type25
                            (call $foreign3
                             (i64.sub
                              (local.get $0)
                              (i64.const 1)
                             )
                            )
                            (block (result (ref $type25))
                             (if
                              (i32.eqz
                               (struct.get $type35 0
                                (struct.get $environment36 0
                                 (local.get $2)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $2
                              (struct.get $type34 0
                               (struct.get $type35 1
                                (struct.get $environment36 0
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (local.get $3)
                            )
                           )
                          )
                          (if (result (ref $type25))
                           (i64.eqz
                            (local.tee $0
                             (i64.sub
                              (local.get $0)
                              (i64.const 1)
                             )
                            )
                           )
                           (then
                            (local.get $3)
                           )
                           (else
                            (local.set $3
                             (struct.new $type25
                              (call $foreign3
                               (i64.sub
                                (local.get $0)
                                (i64.const 1)
                               )
                              )
                              (block (result (ref $type25))
                               (if
                                (i32.eqz
                                 (struct.get $type35 0
                                  (struct.get $environment36 0
                                   (local.get $2)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $2
                                (struct.get $type34 0
                                 (struct.get $type35 1
                                  (struct.get $environment36 0
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                               (local.get $3)
                              )
                             )
                            )
                            (if (result (ref $type25))
                             (i64.eqz
                              (local.tee $0
                               (i64.sub
                                (local.get $0)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (local.get $3)
                             )
                             (else
                              (local.set $3
                               (struct.new $type25
                                (call $foreign3
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                                (block (result (ref $type25))
                                 (if
                                  (i32.eqz
                                   (struct.get $type35 0
                                    (struct.get $environment36 0
                                     (local.get $2)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (local.set $2
                                  (struct.get $type34 0
                                   (struct.get $type35 1
                                    (struct.get $environment36 0
                                     (local.get $2)
                                    )
                                   )
                                  )
                                 )
                                 (local.get $3)
                                )
                               )
                              )
                              (if (result (ref $type25))
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (local.get $3)
                               )
                               (else
                                (local.set $1
                                 (call $foreign3
                                  (i64.sub
                                   (local.get $0)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type35 0
                                   (struct.get $environment36 0
                                    (local.get $2)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (return_call $function36
                                 (struct.get $type34 0
                                  (struct.get $type35 1
                                   (struct.get $environment36 0
                                    (local.get $2)
                                   )
                                  )
                                 )
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                 (struct.new $type25
                                  (local.get $1)
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function36 (type $call34) (param $0 (ref $environment36)) (param $1 i64) (param $2 (ref $type25)) (result (ref null $type25))
  (local $3 i64)
  (if (result (ref $type25))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign3
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment36 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function36
     (struct.get $type34 0
      (struct.get $type35 1
       (struct.get $environment36 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type25
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function37 (type $call26) (param $0 (ref null $type25)) (param $1 (ref null $type25)) (result i32)
  (local $scratch (ref null $type25))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type25 0
         (local.get $0)
        )
        (struct.get $type25 0
         (local.get $1)
        )
       )
       (then
        (return_call $function37
         (struct.get $type25 1
          (local.get $0)
         )
         (block (result (ref null $type25))
          (local.set $scratch
           (struct.get $type25 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready97)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global97)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function39 (type $call24) (result (ref null $type25))
  (local $0 (ref $environment40))
  (local $1 (ref $type25))
  (local $2 (ref null $type25))
  (local $3 (ref null $type25))
  (local $4 (ref $type37))
  (local $5 i64)
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type27 0
    (global.get $global100)
   )
  )
  (struct.set $type37 1
   (local.tee $4
    (struct.new_default $type37)
   )
   (struct.new $type36
    (struct.new $environment40
     (local.get $4)
    )
   )
  )
  (struct.set $type37 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type37 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (struct.get $type36 0
    (struct.get $type37 1
     (local.get $4)
    )
   )
  )
  (if (result (ref null $type25))
   (ref.is_null
    (local.get $2)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $3
     (struct.get $type25 1
      (local.get $2)
     )
    )
    (local.set $1
     (struct.new $type25
      (struct.get $type25 0
       (local.get $2)
      )
      (block (result nullref)
       (if
        (i32.eqz
         (struct.get $type37 0
          (struct.get $environment40 0
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $0
        (struct.get $type36 0
         (struct.get $type37 1
          (struct.get $environment40 0
           (local.get $0)
          )
         )
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type25))
     (ref.is_null
      (local.get $3)
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $2
       (struct.get $type25 1
        (local.get $3)
       )
      )
      (local.set $1
       (struct.new $type25
        (struct.get $type25 0
         (local.get $3)
        )
        (block (result (ref $type25))
         (if
          (i32.eqz
           (struct.get $type37 0
            (struct.get $environment40 0
             (local.get $0)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $0
          (struct.get $type36 0
           (struct.get $type37 1
            (struct.get $environment40 0
             (local.get $0)
            )
           )
          )
         )
         (local.get $1)
        )
       )
      )
      (if (result (ref $type25))
       (ref.is_null
        (local.get $2)
       )
       (then
        (local.get $1)
       )
       (else
        (local.set $3
         (struct.get $type25 1
          (local.get $2)
         )
        )
        (local.set $1
         (struct.new $type25
          (struct.get $type25 0
           (local.get $2)
          )
          (block (result (ref $type25))
           (if
            (i32.eqz
             (struct.get $type37 0
              (struct.get $environment40 0
               (local.get $0)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $0
            (struct.get $type36 0
             (struct.get $type37 1
              (struct.get $environment40 0
               (local.get $0)
              )
             )
            )
           )
           (local.get $1)
          )
         )
        )
        (if (result (ref $type25))
         (ref.is_null
          (local.get $3)
         )
         (then
          (local.get $1)
         )
         (else
          (local.set $2
           (struct.get $type25 1
            (local.get $3)
           )
          )
          (local.set $1
           (struct.new $type25
            (struct.get $type25 0
             (local.get $3)
            )
            (block (result (ref $type25))
             (if
              (i32.eqz
               (struct.get $type37 0
                (struct.get $environment40 0
                 (local.get $0)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $0
              (struct.get $type36 0
               (struct.get $type37 1
                (struct.get $environment40 0
                 (local.get $0)
                )
               )
              )
             )
             (local.get $1)
            )
           )
          )
          (if (result (ref $type25))
           (ref.is_null
            (local.get $2)
           )
           (then
            (local.get $1)
           )
           (else
            (local.set $3
             (struct.get $type25 1
              (local.get $2)
             )
            )
            (local.set $1
             (struct.new $type25
              (struct.get $type25 0
               (local.get $2)
              )
              (block (result (ref $type25))
               (if
                (i32.eqz
                 (struct.get $type37 0
                  (struct.get $environment40 0
                   (local.get $0)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $0
                (struct.get $type36 0
                 (struct.get $type37 1
                  (struct.get $environment40 0
                   (local.get $0)
                  )
                 )
                )
               )
               (local.get $1)
              )
             )
            )
            (if (result (ref $type25))
             (ref.is_null
              (local.get $3)
             )
             (then
              (local.get $1)
             )
             (else
              (local.set $2
               (struct.get $type25 1
                (local.get $3)
               )
              )
              (local.set $1
               (struct.new $type25
                (struct.get $type25 0
                 (local.get $3)
                )
                (block (result (ref $type25))
                 (if
                  (i32.eqz
                   (struct.get $type37 0
                    (struct.get $environment40 0
                     (local.get $0)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $0
                  (struct.get $type36 0
                   (struct.get $type37 1
                    (struct.get $environment40 0
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (local.get $1)
                )
               )
              )
              (if (result (ref $type25))
               (ref.is_null
                (local.get $2)
               )
               (then
                (local.get $1)
               )
               (else
                (local.set $3
                 (struct.get $type25 1
                  (local.get $2)
                 )
                )
                (local.set $1
                 (struct.new $type25
                  (struct.get $type25 0
                   (local.get $2)
                  )
                  (block (result (ref $type25))
                   (if
                    (i32.eqz
                     (struct.get $type37 0
                      (struct.get $environment40 0
                       (local.get $0)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $0
                    (struct.get $type36 0
                     (struct.get $type37 1
                      (struct.get $environment40 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (local.get $1)
                  )
                 )
                )
                (if (result (ref $type25))
                 (ref.is_null
                  (local.get $3)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (local.set $2
                   (struct.get $type25 1
                    (local.get $3)
                   )
                  )
                  (local.set $1
                   (struct.new $type25
                    (struct.get $type25 0
                     (local.get $3)
                    )
                    (block (result (ref $type25))
                     (if
                      (i32.eqz
                       (struct.get $type37 0
                        (struct.get $environment40 0
                         (local.get $0)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $0
                      (struct.get $type36 0
                       (struct.get $type37 1
                        (struct.get $environment40 0
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (if (result (ref $type25))
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (local.set $3
                     (struct.get $type25 1
                      (local.get $2)
                     )
                    )
                    (local.set $1
                     (struct.new $type25
                      (struct.get $type25 0
                       (local.get $2)
                      )
                      (block (result (ref $type25))
                       (if
                        (i32.eqz
                         (struct.get $type37 0
                          (struct.get $environment40 0
                           (local.get $0)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $0
                        (struct.get $type36 0
                         (struct.get $type37 1
                          (struct.get $environment40 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (local.get $1)
                      )
                     )
                    )
                    (if (result (ref $type25))
                     (ref.is_null
                      (local.get $3)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (local.set $2
                       (struct.get $type25 1
                        (local.get $3)
                       )
                      )
                      (local.set $1
                       (struct.new $type25
                        (struct.get $type25 0
                         (local.get $3)
                        )
                        (block (result (ref $type25))
                         (if
                          (i32.eqz
                           (struct.get $type37 0
                            (struct.get $environment40 0
                             (local.get $0)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $0
                          (struct.get $type36 0
                           (struct.get $type37 1
                            (struct.get $environment40 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (local.get $1)
                        )
                       )
                      )
                      (if (result (ref $type25))
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (local.set $3
                         (struct.get $type25 1
                          (local.get $2)
                         )
                        )
                        (local.set $1
                         (struct.new $type25
                          (struct.get $type25 0
                           (local.get $2)
                          )
                          (block (result (ref $type25))
                           (if
                            (i32.eqz
                             (struct.get $type37 0
                              (struct.get $environment40 0
                               (local.get $0)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $0
                            (struct.get $type36 0
                             (struct.get $type37 1
                              (struct.get $environment40 0
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (local.get $1)
                          )
                         )
                        )
                        (if (result (ref $type25))
                         (ref.is_null
                          (local.get $3)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (local.set $2
                           (struct.get $type25 1
                            (local.get $3)
                           )
                          )
                          (local.set $1
                           (struct.new $type25
                            (struct.get $type25 0
                             (local.get $3)
                            )
                            (block (result (ref $type25))
                             (if
                              (i32.eqz
                               (struct.get $type37 0
                                (struct.get $environment40 0
                                 (local.get $0)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $0
                              (struct.get $type36 0
                               (struct.get $type37 1
                                (struct.get $environment40 0
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (local.get $1)
                            )
                           )
                          )
                          (if (result (ref $type25))
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (local.set $3
                             (struct.get $type25 1
                              (local.get $2)
                             )
                            )
                            (local.set $1
                             (struct.new $type25
                              (struct.get $type25 0
                               (local.get $2)
                              )
                              (block (result (ref $type25))
                               (if
                                (i32.eqz
                                 (struct.get $type37 0
                                  (struct.get $environment40 0
                                   (local.get $0)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $0
                                (struct.get $type36 0
                                 (struct.get $type37 1
                                  (struct.get $environment40 0
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (local.get $1)
                              )
                             )
                            )
                            (if (result (ref $type25))
                             (ref.is_null
                              (local.get $3)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (local.set $2
                               (struct.get $type25 1
                                (local.get $3)
                               )
                              )
                              (local.set $1
                               (struct.new $type25
                                (struct.get $type25 0
                                 (local.get $3)
                                )
                                (block (result (ref $type25))
                                 (if
                                  (i32.eqz
                                   (struct.get $type37 0
                                    (struct.get $environment40 0
                                     (local.get $0)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (local.set $0
                                  (struct.get $type36 0
                                   (struct.get $type37 1
                                    (struct.get $environment40 0
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (local.get $1)
                                )
                               )
                              )
                              (if (result (ref $type25))
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (local.set $3
                                 (struct.get $type25 1
                                  (local.get $2)
                                 )
                                )
                                (local.set $5
                                 (struct.get $type25 0
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type37 0
                                   (struct.get $environment40 0
                                    (local.get $0)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (return_call $function40
                                 (struct.get $type36 0
                                  (struct.get $type37 1
                                   (struct.get $environment40 0
                                    (local.get $0)
                                   )
                                  )
                                 )
                                 (local.get $3)
                                 (struct.new $type25
                                  (local.get $5)
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function40 (type $call36) (param $0 (ref $environment40)) (param $1 (ref null $type25)) (param $2 (ref $type25)) (result (ref null $type25))
  (local $3 (ref null $type25))
  (local $4 i64)
  (if (result (ref $type25))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type25 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.get $type25 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type37 0
       (struct.get $environment40 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function40
     (struct.get $type36 0
      (struct.get $type37 1
       (struct.get $environment40 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (struct.new $type25
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function42 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type40))
  (local $3 (ref $type27))
  (local $4 (ref $type33))
  (local $5 (ref $type33))
  (local $6 (ref $type14))
  (local $7 (ref $environment48))
  (local $8 (ref $type46))
  (local $9 (ref $type50))
  (local $10 (ref $type52))
  (local $11 (ref $type54))
  (local $12 (ref $type56))
  (local $13 (ref $type32))
  (local $14 (ref $type30))
  (local $15 (ref $type31))
  (local $16 (ref $type42))
  (local $17 (ref $type20))
  (local $18 (ref $type39))
  (local $19 (ref $type12))
  (local $20 (ref $type13))
  (local $21 (ref $type23))
  (local $22 i32)
  (local $23 i64)
  (local $24 f64)
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type19 0
    (global.get $global118)
   )
  )
  (struct.set $type54 1
   (local.tee $11
    (struct.new_default $type54)
   )
   (struct.new $type20
    (ref.func $function45)
    (struct.new $environment45
     (local.get $11)
    )
   )
  )
  (struct.set $type54 0
   (local.get $11)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type54 0
     (local.get $11)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $15
   (struct.new $type31
    (i64.shl
     (i64.sub
      (call_ref $call20
       (struct.get $type20 1
        (local.tee $17
         (ref.as_non_null
          (struct.get $type54 1
           (local.get $11)
          )
         )
        )
       )
       (i64.add
        (local.tee $23
         (i64.sub
          (local.get $1)
          (i64.const 2)
         )
        )
        (i64.const 1)
       )
       (i64.const 1)
       (struct.get $type20 0
        (local.get $17)
       )
      )
      (i64.const 1)
     )
     (i64.const 2)
    )
   )
  )
  (struct.set $type40 1
   (local.tee $2
    (struct.new_default $type40)
   )
   (struct.new $type41
    (struct.new $environment47
     (local.get $2)
    )
   )
  )
  (struct.set $type40 0
   (local.get $2)
   (i32.const 1)
  )
  (struct.set $type50 1
   (local.tee $9
    (struct.new_default $type50)
   )
   (struct.new $type51
    (struct.new $environment53
     (local.tee $8
      (struct.new $type46
       (struct.new $type47
        (struct.new $environment48
         (local.tee $18
          (struct.new $type39
           (struct.new_default $type13)
          )
         )
        )
       )
      )
     )
     (local.get $9)
    )
   )
  )
  (struct.set $type50 0
   (local.get $9)
   (i32.const 1)
  )
  (struct.set $type52 1
   (local.tee $10
    (struct.new_default $type52)
   )
   (struct.new $type53
    (struct.new $environment52
     (local.get $8)
     (local.get $10)
    )
   )
  )
  (struct.set $type52 0
   (local.get $10)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global70)
   )
  )
  (if
   (i32.eqz
    (struct.get $type40 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $22
   (if (result i32)
    (call $function47
     (struct.get $type41 0
      (struct.get $type40 1
       (local.get $2)
      )
     )
     (i64.const 0)
     (local.tee $6
      (struct.new $type14
       (struct.new $type15
        (struct.get $type39 0
         (struct.get $environment48 0
          (local.tee $7
           (struct.get $type47 0
            (struct.get $type46 0
             (local.get $8)
            )
           )
          )
         )
        )
       )
       (struct.new $type15
        (struct.get $type39 0
         (struct.get $environment48 0
          (local.get $7)
         )
        )
       )
       (i64.const 0)
      )
     )
    )
    (then
     (if
      (i32.eqz
       (struct.get $type40 0
        (local.get $2)
       )
      )
      (then
       (unreachable)
      )
     )
     (i32.eqz
      (call $function47
       (struct.get $type41 0
        (struct.get $type40 1
         (local.get $2)
        )
       )
       (i64.const 1)
       (local.get $6)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready101)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global100)
   )
   (block (result (ref (exact $type25)))
    (if
     (i32.eqz
      (global.get $ready100)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type25
     (i64.extend_i32_u
      (i32.ne
       (local.get $22)
       (i32.const 0)
      )
     )
     (struct.new $type25
      (i64.const 0)
      (struct.new $type25
       (i64.const 5)
       (struct.get $type27 0
        (global.get $global100)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global70)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (struct.set $type15 0
   (struct.get $type14 0
    (local.get $6)
   )
   (struct.new $type14
    (struct.new $type15
     (struct.get $type39 0
      (struct.get $environment48 0
       (local.tee $7
        (struct.get $type47 0
         (struct.get $type46 0
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (struct.new $type15
     (struct.get $type39 0
      (struct.get $environment48 0
       (local.get $7)
      )
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type40 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $22
   (if (result i32)
    (call $function47
     (struct.get $type41 0
      (struct.get $type40 1
       (local.get $2)
      )
     )
     (i64.const 0)
     (local.get $6)
    )
    (then
     (i32.const 0)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready77)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global77)
      )
     )
     (if
      (i32.eqz
       (global.get $ready61)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (if (result i32)
      (ref.test (ref $type14)
       (local.tee $19
        (struct.get $type15 0
         (struct.get $type14 1
          (local.get $6)
         )
        )
       )
      )
      (then
       (drop
        (ref.cast (ref $type14)
         (local.get $19)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready101)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global100)
   )
   (block (result (ref (exact $type25)))
    (if
     (i32.eqz
      (global.get $ready100)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type25
     (i64.extend_i32_u
      (i32.ne
       (local.get $22)
       (i32.const 0)
      )
     )
     (struct.new $type25
      (i64.const 0)
      (struct.new $type25
       (i64.const 6)
       (struct.get $type27 0
        (global.get $global100)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global70)
   )
  )
  (if
   (i32.eqz
    (global.get $ready82)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global82)
   )
  )
  (struct.set $type15 0
   (struct.get $type14 1
    (local.get $6)
   )
   (struct.new $type14
    (struct.new $type15
     (struct.get $type39 0
      (struct.get $environment48 0
       (local.tee $7
        (struct.get $type47 0
         (struct.get $type46 0
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (struct.new $type15
     (struct.get $type39 0
      (struct.get $environment48 0
       (local.get $7)
      )
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type40 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $22
   (call $function47
    (struct.get $type41 0
     (struct.get $type40 1
      (local.get $2)
     )
    )
    (i64.const 1)
    (local.get $6)
   )
  )
  (if
   (i32.eqz
    (global.get $ready101)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global100)
   )
   (block (result (ref (exact $type25)))
    (if
     (i32.eqz
      (global.get $ready100)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type25
     (i64.extend_i32_u
      (i32.ne
       (local.get $22)
       (i32.const 0)
      )
     )
     (struct.new $type25
      (i64.const 1)
      (struct.new $type25
       (i64.const 7)
       (struct.get $type27 0
        (global.get $global100)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global70)
   )
  )
  (if
   (i32.eqz
    (struct.get $type40 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $22
   (call $function47
    (struct.get $type41 0
     (struct.get $type40 1
      (local.get $2)
     )
    )
    (i64.const 0)
    (struct.new $type14
     (struct.new $type15
      (local.tee $20
       (struct.get $type39 0
        (local.get $18)
       )
      )
     )
     (struct.new $type15
      (local.get $20)
     )
     (i64.const 1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready101)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global100)
   )
   (block (result (ref (exact $type25)))
    (if
     (i32.eqz
      (global.get $ready100)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type25
     (i64.extend_i32_u
      (i32.eqz
       (local.get $22)
      )
     )
     (struct.new $type25
      (i64.const 0)
      (struct.new $type25
       (i64.const 8)
       (struct.get $type27 0
        (global.get $global100)
       )
      )
     )
    )
   )
  )
  (call $foreign4
   (i64.const 3)
  )
  (call $foreign4
   (i64.const 0)
  )
  (call $foreign5
   (i64.const 0)
   (local.get $1)
  )
  (call $foreign4
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (call $foreign4
   (i64.const 1)
  )
  (call $foreign4
   (i64.const 2)
  )
  (call $foreign4
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (call $foreign4
   (i64.const 6)
  )
  (call $foreign4
   (i64.const 0)
  )
  (if
   (i32.eqz
    (struct.get $type52 0
     (local.get $10)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.new $type33
    (i32.const 1)
    (struct.new $type30
     (ref.func $function56)
     (struct.new $environment56
      (struct.new $type38
       (struct.new $type19
        (struct.new $environment57
         (struct.new $type38
          (struct.new_default $type19)
         )
         (local.get $1)
        )
       )
      )
      (local.get $8)
      (local.get $9)
      (local.tee $16
       (struct.new $type42
        (struct.new $type43
         (struct.new $environment46
          (local.get $2)
         )
        )
       )
      )
      (local.get $10)
     )
    )
   )
  )
  (call $function46
   (struct.get $type43 0
    (struct.get $type42 0
     (local.get $16)
    )
   )
   (i64.const 0)
   (local.get $1)
   (call $function52
    (struct.get $type53 0
     (struct.get $type52 1
      (local.get $10)
     )
    )
    (local.get $1)
   )
  )
  (call $foreign5
   (i64.const 1)
   (local.get $23)
  )
  (call $foreign4
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global70)
   )
  )
  (if
   (i32.eqz
    (struct.get $type50 0
     (local.get $9)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function53
    (struct.get $type51 0
     (struct.get $type50 1
      (local.get $9)
     )
    )
    (local.get $23)
    (local.tee $6
     (struct.new $type14
      (struct.new $type15
       (struct.get $type39 0
        (struct.get $environment48 0
         (local.tee $7
          (struct.get $type47 0
           (struct.get $type46 0
            (local.get $8)
           )
          )
         )
        )
       )
      )
      (struct.new $type15
       (struct.get $type39 0
        (struct.get $environment48 0
         (local.get $7)
        )
       )
      )
      (i64.const 0)
     )
    )
   )
  )
  (call $foreign5
   (i64.const 2)
   (local.tee $1
    (struct.get $type31 0
     (local.get $15)
    )
   )
  )
  (call $foreign4
   (i64.const 0)
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type33 1
   (local.tee $4
    (struct.new_default $type33)
   )
   (struct.new $type30
    (ref.func $function54)
    (struct.new $environment54
     (local.get $15)
     (local.tee $13
      (struct.new $type32
       (array.new_default $type23
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type33 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type33 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call30
    (struct.get $type30 1
     (local.tee $14
      (ref.as_non_null
       (struct.get $type33 1
        (local.get $4)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type30 0
     (local.get $14)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (call $foreign4
   (i64.const 1)
  )
  (call $foreign4
   (i64.const 2)
  )
  (call $foreign4
   (i64.const 0)
  )
  (struct.set $type33 1
   (local.tee $4
    (struct.new_default $type33)
   )
   (struct.new $type30
    (ref.func $function55)
    (struct.new $environment55
     (struct.new $type31
      (local.get $23)
     )
     (local.get $5)
     (local.get $4)
    )
   )
  )
  (struct.set $type33 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type33 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call30
    (struct.get $type30 1
     (local.tee $14
      (ref.as_non_null
       (struct.get $type33 1
        (local.get $4)
       )
      )
     )
    )
    (i64.const 4)
    (struct.get $type30 0
     (local.get $14)
    )
   )
  )
  (call $function46
   (struct.get $type43 0
    (struct.get $type42 0
     (local.get $16)
    )
   )
   (i64.const 3)
   (local.get $23)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (local.set $22
   (if (result i32)
    (i64.eq
     (local.tee $1
      (i64.extend_i32_u
       (array.len
        (local.tee $21
         (struct.get $type32 0
          (local.get $13)
         )
        )
       )
      )
     )
     (i64.extend_i32_u
      (array.len
       (global.get $global110)
      )
     )
    )
    (then
     (struct.set $type56 1
      (local.tee $12
       (struct.new_default $type56)
      )
      (struct.new $type55
       (struct.new $environment64
        (local.get $21)
        (local.get $12)
       )
      )
     )
     (struct.set $type56 0
      (local.get $12)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type56 0
        (local.get $12)
       )
      )
      (then
       (unreachable)
      )
     )
     (call $function64
      (struct.get $type55 0
       (struct.get $type56 1
        (local.get $12)
       )
      )
      (i64.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready101)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global100)
   )
   (block (result (ref (exact $type25)))
    (if
     (i32.eqz
      (global.get $ready100)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type25
     (i64.extend_i32_u
      (i32.ne
       (local.get $22)
       (i32.const 0)
      )
     )
     (struct.new $type25
      (local.get $1)
      (struct.new $type25
       (i64.const 4)
       (struct.get $type27 0
        (global.get $global100)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i32.eqz
    (global.get $ready170)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type20 1
    (global.get $global170)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (select
      (i64.const 1000)
      (local.tee $1
       (i64.sub
        (i64.shr_u
         (i64.extend_i32_u
          (array.len
           (struct.get $type32 0
            (local.get $13)
           )
          )
         )
         (i64.const 1)
        )
        (i64.const 1)
       )
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 1000)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (f64.ne
    (array.get $type23
     (struct.get $type32 0
      (local.get $13)
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (block (result f64)
     (if
      (i32.eqz
       (global.get $ready85)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global85)
      )
     )
     (f64.div
      (f64.const 1)
      (f64.convert_i64_s
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
   )
   (then
    (call $foreign4
     (i64.const 7)
    )
    (call $foreign4
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (call $foreign4
   (i64.const 1)
  )
  (call $foreign4
   (i64.const 2)
  )
  (call $foreign4
   (i64.const 0)
  )
  (i32.const 0)
 )
 (func $function45 (type $call20) (param $0 (ref null $environment45)) (param $1 i64) (param $2 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type54 0
       (struct.get $environment45 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type20 1
      (struct.get $type54 1
       (struct.get $environment45 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (i64.shl
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function46 (type $7) (param $0 (ref $environment46)) (param $1 i64) (param $2 i64) (param $3 (ref $type14))
  (local $4 i32)
  (local $5 (ref $type27))
  (if
   (i32.eqz
    (struct.get $type40 0
     (struct.get $environment46 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (call $function47
    (struct.get $type41 0
     (struct.get $type40 1
      (struct.get $environment46 0
       (local.get $0)
      )
     )
    )
    (local.get $2)
    (local.get $3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready101)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type27 0
   (ref.as_non_null
    (global.get $global100)
   )
   (block (result (ref (exact $type25)))
    (if
     (i32.eqz
      (global.get $ready100)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type25
     (i64.extend_i32_u
      (i32.ne
       (local.get $4)
       (i32.const 0)
      )
     )
     (struct.new $type25
      (local.get $2)
      (struct.new $type25
       (local.get $1)
       (struct.get $type27 0
        (global.get $global100)
       )
      )
     )
    )
   )
  )
 )
 (func $function47 (type $call41) (param $0 (ref $environment47)) (param $1 i64) (param $2 (ref $type12)) (result i32)
  (local $3 (ref $type14))
  (if
   (i32.eqz
    (global.get $ready68)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global68)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type14)
     (local.get $2)
    )
    (then
     (drop
      (ref.cast (ref $type14)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eqz
      (struct.get $type14 2
       (local.tee $3
        (ref.cast (ref $type14)
         (local.get $2)
        )
       )
      )
     )
     (then
      (if (result i32)
       (i64.eqz
        (local.get $1)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready75)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global75)
         )
        )
        (if
         (i32.eqz
          (global.get $ready61)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (if (result i32)
         (if (result i32)
          (ref.test (ref $type14)
           (local.tee $2
            (struct.get $type15 0
             (struct.get $type14 0
              (local.get $3)
             )
            )
           )
          )
          (then
           (drop
            (ref.cast (ref $type14)
             (local.get $2)
            )
           )
           (i32.const 0)
          )
          (else
           (i32.const 1)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready77)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global77)
           )
          )
          (if
           (i32.eqz
            (global.get $ready61)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (if (result i32)
           (ref.test (ref $type14)
            (local.tee $2
             (struct.get $type15 0
              (struct.get $type14 1
               (local.get $3)
              )
             )
            )
           )
           (then
            (drop
             (ref.cast (ref $type14)
              (local.get $2)
             )
            )
            (i32.const 0)
           )
           (else
            (i32.const 1)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready75)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global75)
         )
        )
        (if
         (i32.eqz
          (struct.get $type40 0
           (struct.get $environment47 0
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (call $function47
          (struct.get $type41 0
           (struct.get $type40 1
            (struct.get $environment47 0
             (local.get $0)
            )
           )
          )
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
          (struct.get $type15 0
           (struct.get $type14 0
            (local.get $3)
           )
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready77)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global77)
           )
          )
          (if
           (i32.eqz
            (struct.get $type40 0
             (struct.get $environment47 0
              (local.get $0)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (return_call $function47
           (struct.get $type41 0
            (struct.get $type40 1
             (struct.get $environment47 0
              (local.get $0)
             )
            )
           )
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
           (struct.get $type15 0
            (struct.get $type14 1
             (local.get $3)
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function52 (type $5) (param $0 (ref $environment52)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $environment48))
  (local $3 (ref $type52))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $scratch (ref $type14))
  (if (result (ref $type14))
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (struct.new $type14
     (struct.new $type15
      (struct.get $type39 0
       (struct.get $environment48 0
        (local.tee $2
         (struct.get $type47 0
          (struct.get $type46 0
           (struct.get $environment52 0
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (struct.new $type15
      (struct.get $type39 0
       (struct.get $environment48 0
        (local.get $2)
       )
      )
     )
     (i64.const 0)
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment52 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type14
     (struct.new $type15
      (block (result (ref $type14))
       (local.set $scratch
        (call $function52
         (struct.get $type53 0
          (struct.get $type52 1
           (local.tee $3
            (struct.get $environment52 1
             (local.get $0)
            )
           )
          )
         )
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (struct.get $type52 0
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (call $function52
         (struct.get $type53 0
          (struct.get $type52 1
           (struct.get $environment52 1
            (local.get $0)
           )
          )
         )
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready70)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global70)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.new $type15
      (local.get $5)
     )
     (i64.const 0)
    )
   )
  )
 )
 (func $function53 (type $call51) (param $0 (ref $environment53)) (param $1 i64) (param $2 (ref $type12)) (result i32)
  (local $3 (ref $environment48))
  (local $4 (ref $type12))
  (if (result i32)
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (if
     (i32.eqz
      (global.get $ready79)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global79)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type15 0
     (struct.get $type14 0
      (ref.cast (ref $type14)
       (local.get $2)
      )
     )
     (struct.new $type14
      (struct.new $type15
       (struct.get $type39 0
        (struct.get $environment48 0
         (local.tee $3
          (struct.get $type47 0
           (struct.get $type46 0
            (struct.get $environment53 0
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (struct.new $type15
       (struct.get $type39 0
        (struct.get $environment48 0
         (local.get $3)
        )
       )
      )
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (if
     (i32.eqz
      (global.get $ready82)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global82)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type15 0
     (struct.get $type14 1
      (ref.cast (ref $type14)
       (local.get $2)
      )
     )
     (struct.new $type14
      (struct.new $type15
       (struct.get $type39 0
        (struct.get $environment48 0
         (local.tee $3
          (struct.get $type47 0
           (struct.get $type46 0
            (struct.get $environment53 0
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (struct.new $type15
       (struct.get $type39 0
        (struct.get $environment48 0
         (local.get $3)
        )
       )
      )
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready75)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global75)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type15 0
      (struct.get $type14 0
       (ref.cast (ref $type14)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment53 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function53
      (struct.get $type51 0
       (struct.get $type50 1
        (struct.get $environment53 1
         (local.get $0)
        )
       )
      )
      (local.tee $1
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready77)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global77)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type15 0
      (struct.get $type14 1
       (ref.cast (ref $type14)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment53 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function53
     (struct.get $type51 0
      (struct.get $type50 1
       (struct.get $environment53 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function54 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type23))
  (if (result i32)
   (i64.le_s
    (i64.div_s
     (struct.get $type31 0
      (struct.get $environment54 0
       (ref.cast (ref $environment54)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type23
     (struct.get $type32 0
      (struct.get $environment54 1
       (ref.cast (ref $environment54)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready85)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global85)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (f64.div
      (f64.const 1)
      (f64.convert_i64_s
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment54 2
        (ref.cast (ref $environment54)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (struct.get $type30 1
      (struct.get $type33 1
       (struct.get $environment54 2
        (ref.cast (ref $environment54)
         (local.get $0)
        )
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function55 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment55))
  (if (result i32)
   (i64.lt_s
    (struct.get $type31 0
     (struct.get $environment55 0
      (ref.cast (ref $environment55)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment55 1
        (ref.cast (ref $environment55)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function56
      (struct.get $type30 1
       (struct.get $type33 1
        (struct.get $environment55 1
         (local.tee $2
          (ref.cast (ref $environment55)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment55 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (struct.get $type30 1
      (struct.get $type33 1
       (struct.get $environment55 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function56 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type54))
  (local $3 (ref $type33))
  (local $4 (ref $environment56))
  (local $5 (ref $type20))
  (local $6 (ref $type30))
  (local $7 (ref null $environment57))
  (local $8 (ref $type31))
  (local $9 (ref $type46))
  (local $10 i64)
  (local.set $10
   (struct.get $environment57 1
    (local.tee $7
     (struct.get $type19 0
      (struct.get $type38 0
       (struct.get $environment56 0
        (ref.cast (ref $environment56)
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
  (drop
   (struct.get $environment57 0
    (local.get $7)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type19 0
    (global.get $global118)
   )
  )
  (struct.set $type54 1
   (local.tee $2
    (struct.new_default $type54)
   )
   (struct.new $type20
    (ref.func $function45)
    (struct.new $environment45
     (local.get $2)
    )
   )
  )
  (struct.set $type54 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type54 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (local.tee $8
     (struct.new $type31
      (i64.div_s
       (i64.shl
        (i64.sub
         (call_ref $call20
          (struct.get $type20 1
           (local.tee $5
            (ref.as_non_null
             (struct.get $type54 1
              (local.get $2)
             )
            )
           )
          )
          (i64.add
           (local.get $10)
           (i64.const 1)
          )
          (i64.const 1)
          (struct.get $type20 0
           (local.get $5)
          )
         )
         (i64.const 1)
        )
        (block (result i64)
         (drop
          (struct.get $environment57 0
           (local.get $7)
          )
         )
         (if
          (i32.eqz
           (global.get $ready118)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (struct.get $type19 0
           (global.get $global118)
          )
         )
         (struct.set $type54 1
          (local.tee $2
           (struct.new_default $type54)
          )
          (struct.new $type20
           (ref.func $function45)
           (struct.new $environment45
            (local.get $2)
           )
          )
         )
         (struct.set $type54 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type54 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (i64.const 1)
        )
       )
       (i64.sub
        (call_ref $call20
         (struct.get $type20 1
          (local.tee $5
           (ref.as_non_null
            (struct.get $type54 1
             (local.get $2)
            )
           )
          )
         )
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
         (i64.const 1)
         (struct.get $type20 0
          (local.get $5)
         )
        )
        (i64.const 1)
       )
      )
     )
    )
   )
   (local.get $1)
  )
  (call $foreign4
   (i64.const 0)
  )
  (local.set $9
   (struct.get $environment56 1
    (local.tee $4
     (ref.cast (ref $environment56)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (call $foreign4
   (i64.const 4)
  )
  (call $foreign4
   (i64.const 0)
  )
  (struct.set $type33 1
   (local.tee $3
    (struct.new_default $type33)
   )
   (struct.new $type30
    (ref.func $function59)
    (struct.new $environment59
     (local.get $8)
     (local.get $9)
     (struct.get $environment56 2
      (local.get $4)
     )
     (local.get $1)
     (struct.get $environment56 3
      (local.get $4)
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type33 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type33 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call30
    (struct.get $type30 1
     (local.tee $6
      (ref.as_non_null
       (struct.get $type33 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type30 0
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (call $foreign4
   (i64.const 5)
  )
  (call $foreign4
   (i64.const 0)
  )
  (struct.set $type33 1
   (local.tee $3
    (struct.new_default $type33)
   )
   (struct.new $type30
    (ref.func $function62)
    (struct.new $environment62
     (local.get $8)
     (struct.get $environment56 3
      (local.get $4)
     )
     (local.get $1)
     (struct.get $environment56 4
      (local.get $4)
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type33 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type33 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call30
   (struct.get $type30 1
    (local.tee $6
     (ref.as_non_null
      (struct.get $type33 1
       (local.get $3)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type30 0
    (local.get $6)
   )
  )
 )
 (func $function59 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment59))
  (local $3 (ref $environment48))
  (local $4 (ref $type13))
  (local $5 (ref $type14))
  (local $6 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type31 0
     (struct.get $environment59 0
      (ref.cast (ref $environment59)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $type47 0
      (struct.get $type46 0
       (struct.get $environment59 1
        (local.tee $2
         (ref.cast (ref $environment59)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment59 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function53
      (struct.get $type51 0
       (struct.get $type50 1
        (struct.get $environment59 2
         (local.get $2)
        )
       )
      )
      (local.tee $6
       (struct.get $environment59 3
        (local.get $2)
       )
      )
      (local.tee $5
       (struct.new $type14
        (struct.new $type15
         (local.tee $4
          (struct.get $type39 0
           (struct.get $environment48 0
            (local.get $3)
           )
          )
         )
        )
        (struct.new $type15
         (local.get $4)
        )
        (i64.const 0)
       )
      )
     )
    )
    (call $function46
     (struct.get $type43 0
      (struct.get $type42 0
       (struct.get $environment59 4
        (local.get $2)
       )
      )
     )
     (i64.const 1)
     (local.get $6)
     (local.get $5)
    )
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment59 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type30 1
      (struct.get $type33 1
       (struct.get $environment59 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function62 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment62))
  (local $3 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type31 0
     (struct.get $environment62 0
      (ref.cast (ref $environment62)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $environment62 2
      (local.tee $2
       (ref.cast (ref $environment62)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment62 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $function46
     (struct.get $type43 0
      (struct.get $type42 0
       (struct.get $environment62 1
        (local.get $2)
       )
      )
     )
     (i64.const 2)
     (local.get $3)
     (call $function52
      (struct.get $type53 0
       (struct.get $type52 1
        (struct.get $environment62 3
         (local.get $2)
        )
       )
      )
      (struct.get $environment62 2
       (local.get $2)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment62 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (struct.get $type30 1
      (struct.get $type33 1
       (struct.get $environment62 4
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function64 (type $call55) (param $0 (ref $environment64)) (param $1 i64) (result i32)
  (local $2 i32)
  (local $3 f64)
  (if (result i32)
   (local.tee $2
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $environment64 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.get $type23
      (struct.get $environment64 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (f64.eq
      (array.get $type23
       (global.get $global110)
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $3)
     )
     (then
      (if
       (i32.eqz
        (struct.get $type56 0
         (struct.get $environment64 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function64
       (struct.get $type55 0
        (struct.get $type56 1
         (struct.get $environment64 1
          (local.get $0)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function65 (type $call20) (param $0 (ref null $environment45)) (param $1 i64) (param $2 i64) (result i64)
  (select
   (local.get $1)
   (local.get $2)
   (i64.lt_s
    (local.get $1)
    (local.get $2)
   )
  )
 )
 (func $function66 (result i64)
  (local $0 (ref null $type25))
  (local $1 (ref null $type25))
  (local $scratch (ref null $type25))
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function42
    (struct.get $type30 1
     (global.get $global112)
    )
    (global.get $global109)
   )
  )
  (if
   (i32.eqz
    (global.get $ready105)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global105)
   )
  )
  (local.set $1
   (call $function39)
  )
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $0
   (call $function35)
  )
  (if
   (i32.eqz
    (global.get $ready97)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global97)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (ref.is_null
       (local.get $0)
      )
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.get $0)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i64.eq
          (struct.get $type25 0
           (local.get $1)
          )
          (struct.get $type25 0
           (local.get $0)
          )
         )
         (then
          (local.set $1
           (struct.get $type25 1
            (local.get $1)
           )
          )
          (local.set $0
           (struct.get $type25 1
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready97)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global97)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $1)
           )
           (then
            (ref.is_null
             (local.get $0)
            )
           )
           (else
            (if (result i32)
             (ref.is_null
              (local.get $0)
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i64.eq
                (struct.get $type25 0
                 (local.get $1)
                )
                (struct.get $type25 0
                 (local.get $0)
                )
               )
               (then
                (local.set $1
                 (struct.get $type25 1
                  (local.get $1)
                 )
                )
                (local.set $0
                 (struct.get $type25 1
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready97)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global97)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (ref.is_null
                   (local.get $0)
                  )
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (i64.eq
                      (struct.get $type25 0
                       (local.get $1)
                      )
                      (struct.get $type25 0
                       (local.get $0)
                      )
                     )
                     (then
                      (local.set $1
                       (struct.get $type25 1
                        (local.get $1)
                       )
                      )
                      (local.set $0
                       (struct.get $type25 1
                        (local.get $0)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready97)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global97)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (ref.is_null
                         (local.get $0)
                        )
                       )
                       (else
                        (if (result i32)
                         (ref.is_null
                          (local.get $0)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i64.eq
                            (struct.get $type25 0
                             (local.get $1)
                            )
                            (struct.get $type25 0
                             (local.get $0)
                            )
                           )
                           (then
                            (local.set $1
                             (struct.get $type25 1
                              (local.get $1)
                             )
                            )
                            (local.set $0
                             (struct.get $type25 1
                              (local.get $0)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready97)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global97)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $1)
                             )
                             (then
                              (ref.is_null
                               (local.get $0)
                              )
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.get $0)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (i64.eq
                                  (struct.get $type25 0
                                   (local.get $1)
                                  )
                                  (struct.get $type25 0
                                   (local.get $0)
                                  )
                                 )
                                 (then
                                  (local.set $1
                                   (struct.get $type25 1
                                    (local.get $1)
                                   )
                                  )
                                  (local.set $0
                                   (struct.get $type25 1
                                    (local.get $0)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready97)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global97)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                   (then
                                    (ref.is_null
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $0)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if (result i32)
                                       (i64.eq
                                        (struct.get $type25 0
                                         (local.get $1)
                                        )
                                        (struct.get $type25 0
                                         (local.get $0)
                                        )
                                       )
                                       (then
                                        (local.set $1
                                         (struct.get $type25 1
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $0
                                         (struct.get $type25 1
                                          (local.get $0)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready97)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global97)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $1)
                                         )
                                         (then
                                          (ref.is_null
                                           (local.get $0)
                                          )
                                         )
                                         (else
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $0)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (i64.eq
                                              (struct.get $type25 0
                                               (local.get $1)
                                              )
                                              (struct.get $type25 0
                                               (local.get $0)
                                              )
                                             )
                                             (then
                                              (local.set $1
                                               (struct.get $type25 1
                                                (local.get $1)
                                               )
                                              )
                                              (local.set $0
                                               (struct.get $type25 1
                                                (local.get $0)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready97)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global97)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $1)
                                               )
                                               (then
                                                (ref.is_null
                                                 (local.get $0)
                                                )
                                               )
                                               (else
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $0)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i64.eq
                                                    (struct.get $type25 0
                                                     (local.get $1)
                                                    )
                                                    (struct.get $type25 0
                                                     (local.get $0)
                                                    )
                                                   )
                                                   (then
                                                    (local.set $1
                                                     (struct.get $type25 1
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (local.set $0
                                                     (struct.get $type25 1
                                                      (local.get $0)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready97)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global97)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $1)
                                                     )
                                                     (then
                                                      (ref.is_null
                                                       (local.get $0)
                                                      )
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $0)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i64.eq
                                                          (struct.get $type25 0
                                                           (local.get $1)
                                                          )
                                                          (struct.get $type25 0
                                                           (local.get $0)
                                                          )
                                                         )
                                                         (then
                                                          (local.set $1
                                                           (struct.get $type25 1
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (local.set $0
                                                           (struct.get $type25 1
                                                            (local.get $0)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready97)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global97)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $1)
                                                           )
                                                           (then
                                                            (ref.is_null
                                                             (local.get $0)
                                                            )
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $0)
                                                             )
                                                             (then
                                                              (i32.const 0)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i64.eq
                                                                (struct.get $type25 0
                                                                 (local.get $1)
                                                                )
                                                                (struct.get $type25 0
                                                                 (local.get $0)
                                                                )
                                                               )
                                                               (then
                                                                (local.set $1
                                                                 (struct.get $type25 1
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                                (local.set $0
                                                                 (struct.get $type25 1
                                                                  (local.get $0)
                                                                 )
                                                                )
                                                                (if
                                                                 (i32.eqz
                                                                  (global.get $ready97)
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global97)
                                                                 )
                                                                )
                                                                (if (result i32)
                                                                 (ref.is_null
                                                                  (local.get $1)
                                                                 )
                                                                 (then
                                                                  (ref.is_null
                                                                   (local.get $0)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (if (result i32)
                                                                   (ref.is_null
                                                                    (local.get $0)
                                                                   )
                                                                   (then
                                                                    (i32.const 0)
                                                                   )
                                                                   (else
                                                                    (if (result i32)
                                                                     (i64.eq
                                                                      (struct.get $type25 0
                                                                       (local.get $1)
                                                                      )
                                                                      (struct.get $type25 0
                                                                       (local.get $0)
                                                                      )
                                                                     )
                                                                     (then
                                                                      (local.set $1
                                                                       (struct.get $type25 1
                                                                        (local.get $1)
                                                                       )
                                                                      )
                                                                      (local.set $0
                                                                       (struct.get $type25 1
                                                                        (local.get $0)
                                                                       )
                                                                      )
                                                                      (if
                                                                       (i32.eqz
                                                                        (global.get $ready97)
                                                                       )
                                                                       (then
                                                                        (unreachable)
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global97)
                                                                       )
                                                                      )
                                                                      (if (result i32)
                                                                       (ref.is_null
                                                                        (local.get $1)
                                                                       )
                                                                       (then
                                                                        (ref.is_null
                                                                         (local.get $0)
                                                                        )
                                                                       )
                                                                       (else
                                                                        (if (result i32)
                                                                         (ref.is_null
                                                                          (local.get $0)
                                                                         )
                                                                         (then
                                                                          (i32.const 0)
                                                                         )
                                                                         (else
                                                                          (if (result i32)
                                                                           (i64.eq
                                                                            (struct.get $type25 0
                                                                             (local.get $1)
                                                                            )
                                                                            (struct.get $type25 0
                                                                             (local.get $0)
                                                                            )
                                                                           )
                                                                           (then
                                                                            (local.set $1
                                                                             (struct.get $type25 1
                                                                              (local.get $1)
                                                                             )
                                                                            )
                                                                            (local.set $0
                                                                             (struct.get $type25 1
                                                                              (local.get $0)
                                                                             )
                                                                            )
                                                                            (if
                                                                             (i32.eqz
                                                                              (global.get $ready97)
                                                                             )
                                                                             (then
                                                                              (unreachable)
                                                                             )
                                                                            )
                                                                            (drop
                                                                             (ref.as_non_null
                                                                              (global.get $global97)
                                                                             )
                                                                            )
                                                                            (if (result i32)
                                                                             (ref.is_null
                                                                              (local.get $1)
                                                                             )
                                                                             (then
                                                                              (ref.is_null
                                                                               (local.get $0)
                                                                              )
                                                                             )
                                                                             (else
                                                                              (if (result i32)
                                                                               (ref.is_null
                                                                                (local.get $0)
                                                                               )
                                                                               (then
                                                                                (i32.const 0)
                                                                               )
                                                                               (else
                                                                                (if (result i32)
                                                                                 (i64.eq
                                                                                  (struct.get $type25 0
                                                                                   (local.get $1)
                                                                                  )
                                                                                  (struct.get $type25 0
                                                                                   (local.get $0)
                                                                                  )
                                                                                 )
                                                                                 (then
                                                                                  (local.set $1
                                                                                   (struct.get $type25 1
                                                                                    (local.get $1)
                                                                                   )
                                                                                  )
                                                                                  (local.set $0
                                                                                   (struct.get $type25 1
                                                                                    (local.get $0)
                                                                                   )
                                                                                  )
                                                                                  (if
                                                                                   (i32.eqz
                                                                                    (global.get $ready97)
                                                                                   )
                                                                                   (then
                                                                                    (unreachable)
                                                                                   )
                                                                                  )
                                                                                  (drop
                                                                                   (ref.as_non_null
                                                                                    (global.get $global97)
                                                                                   )
                                                                                  )
                                                                                  (if (result i32)
                                                                                   (ref.is_null
                                                                                    (local.get $1)
                                                                                   )
                                                                                   (then
                                                                                    (ref.is_null
                                                                                     (local.get $0)
                                                                                    )
                                                                                   )
                                                                                   (else
                                                                                    (if (result i32)
                                                                                     (ref.is_null
                                                                                      (local.get $0)
                                                                                     )
                                                                                     (then
                                                                                      (i32.const 0)
                                                                                     )
                                                                                     (else
                                                                                      (if (result i32)
                                                                                       (i64.eq
                                                                                        (struct.get $type25 0
                                                                                         (local.get $1)
                                                                                        )
                                                                                        (struct.get $type25 0
                                                                                         (local.get $0)
                                                                                        )
                                                                                       )
                                                                                       (then
                                                                                        (local.set $1
                                                                                         (struct.get $type25 1
                                                                                          (local.get $1)
                                                                                         )
                                                                                        )
                                                                                        (local.set $0
                                                                                         (struct.get $type25 1
                                                                                          (local.get $0)
                                                                                         )
                                                                                        )
                                                                                        (if
                                                                                         (i32.eqz
                                                                                          (global.get $ready97)
                                                                                         )
                                                                                         (then
                                                                                          (unreachable)
                                                                                         )
                                                                                        )
                                                                                        (drop
                                                                                         (ref.as_non_null
                                                                                          (global.get $global97)
                                                                                         )
                                                                                        )
                                                                                        (if (result i32)
                                                                                         (ref.is_null
                                                                                          (local.get $1)
                                                                                         )
                                                                                         (then
                                                                                          (ref.is_null
                                                                                           (local.get $0)
                                                                                          )
                                                                                         )
                                                                                         (else
                                                                                          (if (result i32)
                                                                                           (ref.is_null
                                                                                            (local.get $0)
                                                                                           )
                                                                                           (then
                                                                                            (i32.const 0)
                                                                                           )
                                                                                           (else
                                                                                            (if (result i32)
                                                                                             (i64.eq
                                                                                              (struct.get $type25 0
                                                                                               (local.get $1)
                                                                                              )
                                                                                              (struct.get $type25 0
                                                                                               (local.get $0)
                                                                                              )
                                                                                             )
                                                                                             (then
                                                                                              (call $function37
                                                                                               (struct.get $type25 1
                                                                                                (local.get $1)
                                                                                               )
                                                                                               (block (result (ref null $type25))
                                                                                                (local.set $scratch
                                                                                                 (struct.get $type25 1
                                                                                                  (local.get $0)
                                                                                                 )
                                                                                                )
                                                                                                (if
                                                                                                 (i32.eqz
                                                                                                  (global.get $ready97)
                                                                                                 )
                                                                                                 (then
                                                                                                  (unreachable)
                                                                                                 )
                                                                                                )
                                                                                                (drop
                                                                                                 (ref.as_non_null
                                                                                                  (global.get $global97)
                                                                                                 )
                                                                                                )
                                                                                                (local.get $scratch)
                                                                                               )
                                                                                              )
                                                                                             )
                                                                                             (else
                                                                                              (i32.const 0)
                                                                                             )
                                                                                            )
                                                                                           )
                                                                                          )
                                                                                         )
                                                                                        )
                                                                                       )
                                                                                       (else
                                                                                        (i32.const 0)
                                                                                       )
                                                                                      )
                                                                                     )
                                                                                    )
                                                                                   )
                                                                                  )
                                                                                 )
                                                                                 (else
                                                                                  (i32.const 0)
                                                                                 )
                                                                                )
                                                                               )
                                                                              )
                                                                             )
                                                                            )
                                                                           )
                                                                           (else
                                                                            (i32.const 0)
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                     (else
                                                                      (i32.const 0)
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                               (else
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (else
                                                          (i32.const 0)
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (i32.const 0)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (i32.const 0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready174)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type19 0
    (global.get $global174)
   )
  )
  (return_call $function66)
 )
 (func $main
  (local $0 (ref $type33))
  (local $1 (ref $type31))
  (local $2 (ref $type32))
  (local $3 (ref $type30))
  (local $4 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type11)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global68
   (struct.new_default $type11)
  )
  (global.set $ready68
   (i32.const 1)
  )
  (global.set $global70
   (struct.new_default $type16)
  )
  (global.set $ready70
   (i32.const 1)
  )
  (global.set $global75
   (struct.new_default $type17)
  )
  (global.set $ready75
   (i32.const 1)
  )
  (global.set $global77
   (struct.new_default $type17)
  )
  (global.set $ready77
   (i32.const 1)
  )
  (global.set $global79
   (struct.new_default $type18)
  )
  (global.set $ready79
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type18)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type19)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global170
   (struct.new $type20
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $ready170
   (i32.const 1)
  )
  (global.set $global85
   (struct.new_default $type21)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type22)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global93
   (struct.new_default $type24)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global97
   (struct.new_default $type26)
  )
  (global.set $ready97
   (i32.const 1)
  )
  (global.set $global100
   (struct.new_default $type27)
  )
  (global.set $ready100
   (i32.const 1)
  )
  (global.set $global101
   (struct.new_default $type28)
  )
  (global.set $ready101
   (i32.const 1)
  )
  (global.set $global105
   (struct.new_default $type24)
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global109
   (call $foreign7
    (i32.const 0)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (if
   (i64.gt_u
    (local.tee $4
     (struct.get $type31 0
      (local.tee $1
       (struct.new $type31
        (call $foreign0
         (i32.const 1)
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type33 1
   (local.tee $0
    (struct.new_default $type33)
   )
   (struct.new $type30
    (ref.func $function34)
    (struct.new $environment34
     (local.get $1)
     (local.tee $2
      (struct.new $type32
       (array.new_default $type23
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type33 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type33 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call30
    (struct.get $type30 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type33 1
        (local.get $0)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type30 0
     (local.get $3)
    )
   )
  )
  (global.set $global110
   (struct.get $type32 0
    (local.get $2)
   )
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global158
   (struct.new_default $type29)
  )
  (global.set $ready158
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type10)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global112
   (struct.new $type30
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global174
   (struct.new_default $type19)
  )
  (global.set $ready174
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

