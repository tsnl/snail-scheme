(module
 (rec
  (type $type12 (sub (struct)))
  (type $environment55 (struct (field i64) (field (ref $type35))))
  (type $environment52 (struct (field (ref $type25)) (field (ref $type33)) (field i64) (field (ref $type35))))
  (type $environment49 (struct (field (ref $type25)) (field (ref $type31)) (field i64) (field (ref $type27)) (field (ref $type35))))
  (type $call32 (func (param (ref $environment43) i64 (ref $type12)) (result i32)))
  (type $5 (func (param (ref $environment42) i64) (result (ref $type14))))
  (type $environment45 (struct (field (ref $type25)) (field (ref $type35)) (field (ref $type35))))
  (type $environment46 (struct (field (ref $type24)) (field (ref $type31)) (field (ref $type27)) (field (ref $type33))))
  (type $environment47 (struct (field (ref $type24)) (field i64)))
  (type $type24 (struct (field (ref $type19))))
  (type $environment44 (struct (field (ref $type25)) (field (ref $type37)) (field (ref $type35))))
  (type $type38 (array (mut f64)))
  (type $type14 (sub $type12 (struct (field (ref $type15)) (field (ref $type15)))))
  (type $type15 (struct (field (mut (ref $type12)))))
  (type $type34 (struct (field (ref $environment42))))
  (type $environment42 (struct (field (ref $type27)) (field (ref $type33))))
  (type $type32 (struct (field (ref $environment43))))
  (type $environment43 (struct (field (ref $type27)) (field (ref $type31))))
  (type $type28 (struct (field (ref $environment38))))
  (type $type26 (struct (field (ref $type13))))
  (type $type13 (sub $type12 (struct)))
  (type $call20 (func (param (ref null $environment37) i64 i64) (result i64)))
  (type $environment37 (struct (field (ref $type36))))
  (type $environment38 (struct (field (ref $type26))))
  (type $type37 (struct (field (ref $type38))))
  (type $type25 (struct (field i64)))
  (type $type27 (struct (field (ref $type28))))
  (type $type36 (struct (field (mut i32)) (field (mut (ref null $type20)))))
  (type $type33 (struct (field (mut i32)) (field (mut (ref null $type34)))))
  (type $type31 (struct (field (mut i32)) (field (mut (ref null $type32)))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type23)))))
  (type $call23 (func (param structref i64) (result i32)))
  (type $type23 (struct (field (ref $call23)) (field structref)))
  (type $type10 (struct))
  (type $type22 (struct))
  (type $type21 (struct))
  (type $type20 (struct (field (ref $call20)) (field (ref null $environment37))))
  (type $type19 (struct (field (ref null $environment47))))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type11 (struct))
 )
 (type $42 (func (param i64 i64)))
 (type $43 (func (param i64) (result i64)))
 (type $44 (func (param i64)))
 (type $45 (func (param i32) (result i64)))
 (type $46 (func))
 (import "benchmark" "print_text" (func $foreign0 (param i64)))
 (import "benchmark" "print_size" (func $foreign1 (param i64 i64)))
 (import "benchmark" "print_construction" (func $foreign2 (param i64 i64)))
 (import "benchmark" "hide_i64" (func $foreign3 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign4 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type11)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global70 (mut (ref null $type16)) (ref.null none))
 (global $ready70 (mut i32) (i32.const 0))
 (global $global75 (mut (ref null $type17)) (ref.null none))
 (global $ready75 (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type17)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type18)) (ref.null none))
 (global $ready79 (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type18)) (ref.null none))
 (global $ready82 (mut i32) (i32.const 0))
 (global $global94 (mut (ref null $type19)) (ref.null none))
 (global $ready94 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type20)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type21)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type20)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type22)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type10)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type23)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global136 (mut i64) (i64.const 0))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type19)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function34 (type $call23) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type35))
  (local $3 (ref $type31))
  (local $4 (ref $type33))
  (local $5 (ref $type36))
  (local $6 (ref $type27))
  (local $7 (ref $type23))
  (local $8 (ref $type25))
  (local $9 (ref $type37))
  (local $10 (ref $type20))
  (local $11 (ref $environment38))
  (local $12 i64)
  (local $13 i64)
  (local $14 f64)
  (if
   (i32.eqz
    (global.get $ready94)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type19 0
    (global.get $global94)
   )
  )
  (struct.set $type36 1
   (local.tee $5
    (struct.new_default $type36)
   )
   (struct.new $type20
    (ref.func $function37)
    (struct.new $environment37
     (local.get $5)
    )
   )
  )
  (struct.set $type36 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (struct.new $type25
    (i64.shl
     (i64.sub
      (call_ref $call20
       (struct.get $type20 1
        (local.tee $10
         (ref.as_non_null
          (struct.get $type36 1
           (local.get $5)
          )
         )
        )
       )
       (i64.add
        (local.tee $12
         (i64.sub
          (local.get $1)
          (i64.const 2)
         )
        )
        (i64.const 1)
       )
       (i64.const 1)
       (struct.get $type20 0
        (local.get $10)
       )
      )
      (i64.const 1)
     )
     (i64.const 2)
    )
   )
  )
  (struct.set $type31 1
   (local.tee $3
    (struct.new_default $type31)
   )
   (struct.new $type32
    (struct.new $environment43
     (local.tee $6
      (struct.new $type27
       (struct.new $type28
        (struct.new $environment38
         (struct.new $type26
          (struct.new_default $type13)
         )
        )
       )
      )
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type31 0
   (local.get $3)
   (i32.const 1)
  )
  (struct.set $type33 1
   (local.tee $4
    (struct.new_default $type33)
   )
   (struct.new $type34
    (struct.new $environment42
     (local.get $6)
     (local.get $4)
    )
   )
  )
  (struct.set $type33 0
   (local.get $4)
   (i32.const 1)
  )
  (call $foreign0
   (i64.const 3)
  )
  (call $foreign0
   (i64.const 0)
  )
  (call $foreign1
   (i64.const 0)
   (local.get $1)
  )
  (call $foreign0
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (call $foreign0
   (i64.const 1)
  )
  (call $foreign0
   (i64.const 2)
  )
  (call $foreign0
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (call $foreign0
   (i64.const 6)
  )
  (call $foreign0
   (i64.const 0)
  )
  (if
   (i32.eqz
    (struct.get $type33 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function42
    (struct.get $type34 0
     (struct.get $type33 1
      (local.get $4)
     )
    )
    (local.get $1)
   )
  )
  (call $foreign1
   (i64.const 1)
   (local.get $12)
  )
  (call $foreign0
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready70)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global70)
   )
  )
  (if
   (i32.eqz
    (struct.get $type31 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function43
    (struct.get $type32 0
     (struct.get $type31 1
      (local.get $3)
     )
    )
    (local.get $12)
    (struct.new $type14
     (struct.new $type15
      (struct.get $type26 0
       (struct.get $environment38 0
        (local.tee $11
         (struct.get $type28 0
          (struct.get $type27 0
           (local.get $6)
          )
         )
        )
       )
      )
     )
     (struct.new $type15
      (struct.get $type26 0
       (struct.get $environment38 0
        (local.get $11)
       )
      )
     )
    )
   )
  )
  (call $foreign1
   (i64.const 2)
   (local.tee $13
    (struct.get $type25 0
     (local.get $8)
    )
   )
  )
  (call $foreign0
   (i64.const 0)
  )
  (if
   (i64.gt_u
    (local.get $13)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type35 1
   (local.tee $2
    (struct.new_default $type35)
   )
   (struct.new $type23
    (ref.func $function44)
    (struct.new $environment44
     (local.get $8)
     (local.tee $9
      (struct.new $type37
       (array.new_default $type38
        (i32.wrap_i64
         (local.get $13)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type35 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call23
    (struct.get $type23 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type23 0
     (local.get $7)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (call $foreign0
   (i64.const 1)
  )
  (call $foreign0
   (i64.const 2)
  )
  (call $foreign0
   (i64.const 0)
  )
  (struct.set $type35 1
   (local.tee $2
    (struct.new_default $type35)
   )
   (struct.new $type23
    (ref.func $function45)
    (struct.new $environment45
     (struct.new $type25
      (local.get $12)
     )
     (struct.new $type35
      (i32.const 1)
      (struct.new $type23
       (ref.func $function46)
       (struct.new $environment46
        (struct.new $type24
         (struct.new $type19
          (struct.new $environment47
           (struct.new $type24
            (struct.new_default $type19)
           )
           (local.get $1)
          )
         )
        )
        (local.get $3)
        (local.get $6)
        (local.get $4)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type35 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call23
    (struct.get $type23 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 4)
    (struct.get $type23 0
     (local.get $7)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type20 1
    (global.get $global133)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (select
      (i64.const 1000)
      (local.tee $1
       (i64.sub
        (i64.shr_u
         (i64.extend_i32_u
          (array.len
           (struct.get $type37 0
            (local.get $9)
           )
          )
         )
         (i64.const 1)
        )
        (i64.const 1)
       )
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 1000)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (f64.ne
    (array.get $type38
     (struct.get $type37 0
      (local.get $9)
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (block (result f64)
     (if
      (i32.eqz
       (global.get $ready85)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global85)
      )
     )
     (f64.div
      (f64.const 1)
      (f64.convert_i64_s
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
   )
   (then
    (call $foreign0
     (i64.const 7)
    )
    (call $foreign0
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (call $foreign0
   (i64.const 1)
  )
  (call $foreign0
   (i64.const 2)
  )
  (call $foreign0
   (i64.const 0)
  )
  (i32.const 0)
 )
 (func $function37 (type $call20) (param $0 (ref null $environment37)) (param $1 i64) (param $2 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment37 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function37
     (struct.get $type20 1
      (struct.get $type36 1
       (struct.get $environment37 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (i64.shl
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function42 (type $5) (param $0 (ref $environment42)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $environment38))
  (local $3 (ref $type33))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $scratch (ref $type14))
  (if (result (ref $type14))
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (struct.new $type14
     (struct.new $type15
      (struct.get $type26 0
       (struct.get $environment38 0
        (local.tee $2
         (struct.get $type28 0
          (struct.get $type27 0
           (struct.get $environment42 0
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (struct.new $type15
      (struct.get $type26 0
       (struct.get $environment38 0
        (local.get $2)
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment42 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type14
     (struct.new $type15
      (block (result (ref $type14))
       (local.set $scratch
        (call $function42
         (struct.get $type34 0
          (struct.get $type33 1
           (local.tee $3
            (struct.get $environment42 1
             (local.get $0)
            )
           )
          )
         )
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (struct.get $type33 0
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (call $function42
         (struct.get $type34 0
          (struct.get $type33 1
           (struct.get $environment42 1
            (local.get $0)
           )
          )
         )
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready70)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global70)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.new $type15
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function43 (type $call32) (param $0 (ref $environment43)) (param $1 i64) (param $2 (ref $type12)) (result i32)
  (local $3 (ref $environment38))
  (local $4 (ref $type12))
  (if (result i32)
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (if
     (i32.eqz
      (global.get $ready79)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global79)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type15 0
     (struct.get $type14 0
      (ref.cast (ref $type14)
       (local.get $2)
      )
     )
     (struct.new $type14
      (struct.new $type15
       (struct.get $type26 0
        (struct.get $environment38 0
         (local.tee $3
          (struct.get $type28 0
           (struct.get $type27 0
            (struct.get $environment43 0
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (struct.new $type15
       (struct.get $type26 0
        (struct.get $environment38 0
         (local.get $3)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (if
     (i32.eqz
      (global.get $ready82)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global82)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type15 0
     (struct.get $type14 1
      (ref.cast (ref $type14)
       (local.get $2)
      )
     )
     (struct.new $type14
      (struct.new $type15
       (struct.get $type26 0
        (struct.get $environment38 0
         (local.tee $3
          (struct.get $type28 0
           (struct.get $type27 0
            (struct.get $environment43 0
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (struct.new $type15
       (struct.get $type26 0
        (struct.get $environment38 0
         (local.get $3)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready75)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global75)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type15 0
      (struct.get $type14 0
       (ref.cast (ref $type14)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function43
      (struct.get $type32 0
       (struct.get $type31 1
        (struct.get $environment43 1
         (local.get $0)
        )
       )
      )
      (local.tee $1
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready77)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global77)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type14)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type15 0
      (struct.get $type14 1
       (ref.cast (ref $type14)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type32 0
      (struct.get $type31 1
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function44 (type $call23) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type38))
  (if (result i32)
   (i64.le_s
    (i64.div_s
     (struct.get $type25 0
      (struct.get $environment44 0
       (ref.cast (ref $environment44)
        (local.get $0)
       )
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type38
     (struct.get $type37 0
      (struct.get $environment44 1
       (ref.cast (ref $environment44)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready85)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global85)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (f64.div
      (f64.const 1)
      (f64.convert_i64_s
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment44 2
        (ref.cast (ref $environment44)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type23 1
      (struct.get $type35 1
       (struct.get $environment44 2
        (ref.cast (ref $environment44)
         (local.get $0)
        )
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function45 (type $call23) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment45))
  (if (result i32)
   (i64.lt_s
    (struct.get $type25 0
     (struct.get $environment45 0
      (ref.cast (ref $environment45)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment45 1
        (ref.cast (ref $environment45)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function46
      (struct.get $type23 1
       (struct.get $type35 1
        (struct.get $environment45 1
         (local.tee $2
          (ref.cast (ref $environment45)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment45 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type23 1
      (struct.get $type35 1
       (struct.get $environment45 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function46 (type $call23) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type36))
  (local $3 (ref $type35))
  (local $4 (ref $type20))
  (local $5 (ref $type23))
  (local $6 (ref null $environment47))
  (local $7 (ref $type25))
  (local $8 (ref $environment46))
  (local $9 (ref $type31))
  (local $10 i64)
  (local.set $10
   (struct.get $environment47 1
    (local.tee $6
     (struct.get $type19 0
      (struct.get $type24 0
       (struct.get $environment46 0
        (ref.cast (ref $environment46)
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
  (drop
   (struct.get $environment47 0
    (local.get $6)
   )
  )
  (if
   (i32.eqz
    (global.get $ready94)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type19 0
    (global.get $global94)
   )
  )
  (struct.set $type36 1
   (local.tee $2
    (struct.new_default $type36)
   )
   (struct.new $type20
    (ref.func $function37)
    (struct.new $environment37
     (local.get $2)
    )
   )
  )
  (struct.set $type36 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (call $foreign2
   (struct.get $type25 0
    (local.tee $7
     (struct.new $type25
      (i64.div_s
       (i64.shl
        (i64.sub
         (call_ref $call20
          (struct.get $type20 1
           (local.tee $4
            (ref.as_non_null
             (struct.get $type36 1
              (local.get $2)
             )
            )
           )
          )
          (i64.add
           (local.get $10)
           (i64.const 1)
          )
          (i64.const 1)
          (struct.get $type20 0
           (local.get $4)
          )
         )
         (i64.const 1)
        )
        (block (result i64)
         (drop
          (struct.get $environment47 0
           (local.get $6)
          )
         )
         (if
          (i32.eqz
           (global.get $ready94)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (struct.get $type19 0
           (global.get $global94)
          )
         )
         (struct.set $type36 1
          (local.tee $2
           (struct.new_default $type36)
          )
          (struct.new $type20
           (ref.func $function37)
           (struct.new $environment37
            (local.get $2)
           )
          )
         )
         (struct.set $type36 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type36 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (i64.const 1)
        )
       )
       (i64.sub
        (call_ref $call20
         (struct.get $type20 1
          (local.tee $4
           (ref.as_non_null
            (struct.get $type36 1
             (local.get $2)
            )
           )
          )
         )
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
         (i64.const 1)
         (struct.get $type20 0
          (local.get $4)
         )
        )
        (i64.const 1)
       )
      )
     )
    )
   )
   (local.get $1)
  )
  (call $foreign0
   (i64.const 0)
  )
  (local.set $9
   (struct.get $environment46 1
    (local.tee $8
     (ref.cast (ref $environment46)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (call $foreign0
   (i64.const 4)
  )
  (call $foreign0
   (i64.const 0)
  )
  (struct.set $type35 1
   (local.tee $3
    (struct.new_default $type35)
   )
   (struct.new $type23
    (ref.func $function49)
    (struct.new $environment49
     (local.get $7)
     (local.get $9)
     (local.get $1)
     (struct.get $environment46 2
      (local.get $8)
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type35 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call23
    (struct.get $type23 1
     (local.tee $5
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type23 0
     (local.get $5)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (call $foreign0
   (i64.const 5)
  )
  (call $foreign0
   (i64.const 0)
  )
  (struct.set $type35 1
   (local.tee $3
    (struct.new_default $type35)
   )
   (struct.new $type23
    (ref.func $function52)
    (struct.new $environment52
     (local.get $7)
     (struct.get $environment46 3
      (local.get $8)
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
  (struct.set $type35 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call23
   (struct.get $type23 1
    (local.tee $5
     (ref.as_non_null
      (struct.get $type35 1
       (local.get $3)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type23 0
    (local.get $5)
   )
  )
 )
 (func $function49 (type $call23) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment49))
  (local $3 (ref $environment38))
  (local $4 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type25 0
     (struct.get $environment49 0
      (ref.cast (ref $environment49)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $4
     (struct.get $environment49 2
      (local.tee $2
       (ref.cast (ref $environment49)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready70)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global70)
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment49 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function43
      (struct.get $type32 0
       (struct.get $type31 1
        (struct.get $environment49 1
         (local.get $2)
        )
       )
      )
      (local.get $4)
      (struct.new $type14
       (struct.new $type15
        (struct.get $type26 0
         (struct.get $environment38 0
          (local.tee $3
           (struct.get $type28 0
            (struct.get $type27 0
             (struct.get $environment49 3
              (local.get $2)
             )
            )
           )
          )
         )
        )
       )
       (struct.new $type15
        (struct.get $type26 0
         (struct.get $environment38 0
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment49 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type23 1
      (struct.get $type35 1
       (struct.get $environment49 4
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $call23) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment52))
  (local $3 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type25 0
     (struct.get $environment52 0
      (ref.cast (ref $environment52)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $environment52 2
      (local.tee $2
       (ref.cast (ref $environment52)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment52 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function42
      (struct.get $type34 0
       (struct.get $type33 1
        (struct.get $environment52 1
         (local.get $2)
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment52 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (struct.get $type23 1
      (struct.get $type35 1
       (struct.get $environment52 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function53 (type $call20) (param $0 (ref null $environment37)) (param $1 i64) (param $2 i64) (result i64)
  (select
   (local.get $1)
   (local.get $2)
   (i64.lt_s
    (local.get $1)
    (local.get $2)
   )
  )
 )
 (func $function55 (type $call23) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (if (result i32)
   (i64.eq
    (struct.get $environment55 0
     (ref.cast (ref $environment55)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment55)
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready136)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready141)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type20 1
      (global.get $global141)
     )
    )
    (local.set $2
     (call $foreign3
      (global.get $global136)
     )
    )
    (if
     (i32.eqz
      (global.get $ready88)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function34
      (struct.get $type23 1
       (global.get $global88)
      )
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment55 1
        (ref.cast (ref $environment55)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (struct.get $type23 1
      (struct.get $type35 1
       (struct.get $environment55 1
        (ref.cast (ref $environment55)
         (local.get $0)
        )
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function56 (type $call20) (param $0 (ref null $environment37)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign3
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type35))
  (local $2 (ref $type23))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type19 0
    (global.get $global137)
   )
  )
  (struct.set $type35 1
   (local.tee $1
    (struct.new_default $type35)
   )
   (struct.new $type23
    (ref.func $function55)
    (struct.new $environment55
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type35 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call23
    (struct.get $type23 1
     (local.tee $2
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type23 0
     (local.get $2)
    )
   )
  )
  (i64.const 1)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type11)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global70
   (struct.new_default $type16)
  )
  (global.set $ready70
   (i32.const 1)
  )
  (global.set $global75
   (struct.new_default $type17)
  )
  (global.set $ready75
   (i32.const 1)
  )
  (global.set $global77
   (struct.new_default $type17)
  )
  (global.set $ready77
   (i32.const 1)
  )
  (global.set $global79
   (struct.new_default $type18)
  )
  (global.set $ready79
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type18)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $global94
   (struct.new_default $type19)
  )
  (global.set $ready94
   (i32.const 1)
  )
  (global.set $global133
   (struct.new $type20
    (ref.func $function53)
    (ref.null none)
   )
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global85
   (struct.new_default $type21)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global141
   (struct.new $type20
    (ref.func $function56)
    (ref.null none)
   )
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type22)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type10)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global88
   (struct.new $type23
    (ref.func $function34)
    (ref.null none)
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (global.set $global136
   (call $foreign4
    (i32.const 0)
   )
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type19)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

