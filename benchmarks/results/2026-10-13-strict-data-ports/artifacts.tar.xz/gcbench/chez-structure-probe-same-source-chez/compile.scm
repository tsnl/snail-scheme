(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-data-ports-final-20261013/gcbench/chez-structure-probe-same-source-chez/program.scm" "/tmp/snail-strict-data-ports-final-20261013/gcbench/chez-structure-probe-same-source-chez/program.so"))
