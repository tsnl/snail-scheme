(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-data-ports-final-20261013/gcbench/chez-structure-probe-original/program.scm" "/tmp/snail-strict-data-ports-final-20261013/gcbench/chez-structure-probe-original/program.so"))
