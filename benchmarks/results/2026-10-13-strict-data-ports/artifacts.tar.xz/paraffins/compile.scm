(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-data-ports-final-20261013/paraffins/program.scm" "/tmp/snail-strict-data-ports-final-20261013/paraffins/program.so"))
