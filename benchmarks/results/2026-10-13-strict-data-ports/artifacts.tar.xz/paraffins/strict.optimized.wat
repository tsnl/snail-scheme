(module
 (rec
  (type $type19 (sub (struct)))
  (type $type66 (struct (field (mut i32)) (field (mut (ref null $type29)))))
  (type $environment64 (struct (field i64) (field (ref $type66))))
  (type $call64 (func (param (ref $environment62) (ref null $type16) i64) (result i64)))
  (type $type64 (struct (field (ref $environment62))))
  (type $type65 (struct (field (mut i32)) (field (mut (ref null $type64)))))
  (type $environment62 (struct (field (ref $type65))))
  (type $call34 (func (param i64) (result i64)))
  (type $call60 (func (param (ref $environment59) (ref null $type15) i64) (result (ref $type23))))
  (type $call62 (func (param (ref $environment58) (ref null $type15) i64) (result i64)))
  (type $type60 (struct (field (ref $environment59))))
  (type $environment59 (struct (field (ref $type59)) (field (ref $type61))))
  (type $type59 (struct (field i32) (field (ref $type23))))
  (type $type23 (array (mut (ref null $type16))))
  (type $type62 (struct (field (ref $environment58))))
  (type $type61 (struct (field (mut i32)) (field (mut (ref null $type60)))))
  (type $type63 (struct (field (mut i32)) (field (mut (ref null $type62)))))
  (type $type15 (struct (field (ref null $type16)) (field (ref null $type15))))
  (type $environment58 (struct (field (ref $type63))))
  (type $environment53 (struct (field (ref null $type38)) (field (ref null $type38)) (field (ref null $type38)) (field (ref $type56))))
  (type $environment52 (struct (field (ref null $type38)) (field (ref null $type38)) (field (ref $type35)) (field (ref $type35)) (field (ref $type36)) (field (ref $type56))))
  (type $environment51 (struct (field (ref null $type38)) (field (ref $type35)) (field (ref $type35)) (field (ref $type36)) (field (ref $type35)) (field (ref $type56))))
  (type $environment50 (struct (field (ref $type35)) (field (ref $type35)) (field (ref $type36)) (field (ref $type35)) (field (ref $type35)) (field (ref $type56))))
  (type $type57 (struct (field (ref $environment49))))
  (type $type58 (struct (field (mut i32)) (field (mut (ref null $type57)))))
  (type $environment49 (struct (field (ref $type36)) (field (ref $type58))))
  (type $call57 (func (param (ref $environment49) (ref null $type33) (ref null $type16)) (result (ref null $type16))))
  (type $call29 (func (param (ref null $environment64) i64 i64) (result i64)))
  (type $environment48 (struct (field (ref $type35)) (field (ref $type47)) (field i64) (field (ref $type47)) (field i64) (field i64)))
  (type $environment46 (struct (field i64) (field (ref $type47)) (field i64) (field (ref $type47))))
  (type $environment45 (struct (field (ref $type47)) (field i64)))
  (type $type16 (struct (field (ref null $type16))))
  (type $environment42 (struct (field (ref null $type38)) (field (ref $type56))))
  (type $environment41 (struct (field (ref $type56))))
  (type $type55 (struct (field (ref $call55)) (field (ref struct))))
  (type $type56 (struct (field (mut i32)) (field (mut (ref null $type55)))))
  (type $call55 (func (param (ref struct) (ref null $type38) (ref null $type16)) (result (ref null $type16))))
  (type $type21 (sub $type19 (struct)))
  (type $environment39 (struct (field (ref null $type38)) (field (ref null $type38)) (field (ref $type54))))
  (type $environment38 (struct (field (ref null $type38)) (field (ref $type35)) (field (ref $type35)) (field (ref $type36)) (field (ref $type54))))
  (type $call53 (func (param (ref struct) (ref null $type38) (ref null $type38)) (result (ref null $type38))))
  (type $environment37 (struct (field (ref $type35)) (field (ref $type35)) (field (ref $type36)) (field (ref $type35)) (field (ref $type54))))
  (type $type44 (struct (field (ref $environment36))))
  (type $type45 (struct (field (mut i32)) (field (mut (ref null $type44)))))
  (type $environment36 (struct (field (ref $type36)) (field (ref $type45))))
  (type $type53 (struct (field (ref $call53)) (field (ref struct))))
  (type $type54 (struct (field (mut i32)) (field (mut (ref null $type53)))))
  (type $call44 (func (param (ref $environment36) (ref null $type33) (ref null $type38)) (result (ref null $type38))))
  (type $call49 (func (param (ref $environment35) (ref null $type12) i64) (result (ref $type13))))
  (type $call51 (func (param (ref $environment34) (ref null $type12) i64) (result i64)))
  (type $type49 (struct (field (ref $environment35))))
  (type $environment35 (struct (field (ref $type48)) (field (ref $type50))))
  (type $type48 (struct (field i32) (field (ref $type13))))
  (type $type13 (array (mut i64)))
  (type $type51 (struct (field (ref $environment34))))
  (type $type50 (struct (field (mut i32)) (field (mut (ref null $type49)))))
  (type $type52 (struct (field (mut i32)) (field (mut (ref null $type51)))))
  (type $environment34 (struct (field (ref $type52))))
  (type $58 (func (param (ref $type12)) (result (ref $type13))))
  (type $type12 (struct (field i64) (field (ref null $type12))))
  (type $type33 (struct (field (ref $type13)) (field (ref null $type33))))
  (type $environment30 (struct (field i64) (field (ref $type47)) (field (ref $type47)) (field i64)))
  (type $type46 (struct (field (ref $call46)) (field (ref struct))))
  (type $environment29 (struct (field (ref $type47)) (field i64)))
  (type $type47 (struct (field (mut i32)) (field (mut (ref null $type46)))))
  (type $call46 (func (param (ref struct) (ref null $type33) i64) (result (ref null $type33))))
  (type $environment54 (struct (field (ref $type35)) (field (ref $type41)) (field i64) (field (ref $type41)) (field (ref $type36)) (field (ref $type39)) (field (ref $type43))))
  (type $environment43 (struct (field (ref $type36))))
  (type $type42 (struct (field (ref struct))))
  (type $environment40 (struct (field (ref $type36))))
  (type $type40 (struct (field (ref $environment27))))
  (type $environment27 (struct (field (ref $type36))))
  (type $type37 (array (mut (ref null $type38))))
  (type $type38 (struct (field (ref $type19)) (field (ref null $type38))))
  (type $type20 (sub $type19 (struct)))
  (type $type41 (struct (field (mut i32)) (field (ref $type42))))
  (type $type39 (struct (field (mut i32)) (field (ref $type40))))
  (type $type43 (struct (field (mut i32)) (field (mut (ref null $type31)))))
  (type $type35 (struct (field (mut i32)) (field i64)))
  (type $type36 (struct (field (mut i32)) (field (ref $type37))))
  (type $call31 (func (param (ref null $environment54) i64) (result (ref $type23))))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type31 (struct (field (ref $call31)) (field (ref null $environment54))))
  (type $type30 (struct))
  (type $type29 (struct (field (ref $call29)) (field (ref null $environment64))))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type14 (struct))
  (type $type11 (struct))
 )
 (type $93 (func (param i64) (result i64)))
 (type $94 (func (param i32) (result i64)))
 (type $95 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type11)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type14)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type24)) (ref.null none))
 (global $ready79 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type25)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type26)) (ref.null none))
 (global $ready82 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type27)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type28)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type29)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type30)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global180 (mut (ref null $type29)) (ref.null none))
 (global $ready180 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type31)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global69 (mut (ref null $type32)) (ref.null none))
 (global $ready69 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type32)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type34)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global174 (mut i64) (i64.const 0))
 (global $ready174 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type34)) (ref.null none))
 (global $ready175 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function26 (type $call31) (param $0 (ref null $environment54)) (param $1 i64) (result (ref $type23))
  (local $2 (ref $type36))
  (local $3 (ref $type43))
  (local $4 (ref $type35))
  (local $5 (ref $type39))
  (local $6 (ref $type41))
  (local $7 (ref $type41))
  (local $8 (ref $type31))
  (local $9 i64)
  (local.set $4
   (struct.new $type35
    (i32.const 1)
    (i64.div_s
     (local.get $1)
     (i64.const 2)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (i64.add
      (struct.get $type35 1
       (local.get $4)
      )
      (i64.const 1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.new $type36
    (i32.const 1)
    (array.new $type37
     (struct.new $type38
      (struct.new_default $type20)
      (ref.null none)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
   )
  )
  (local.set $5
   (struct.new $type39
    (i32.const 1)
    (struct.new $type40
     (struct.new $environment27
      (local.get $2)
     )
    )
   )
  )
  (local.set $6
   (struct.new $type41
    (i32.const 1)
    (struct.new $type42
     (struct.new $environment40
      (local.get $2)
     )
    )
   )
  )
  (local.set $7
   (struct.new $type41
    (i32.const 1)
    (struct.new $type42
     (struct.new $environment43
      (local.get $2)
     )
    )
   )
  )
  (struct.set $type43 1
   (local.tee $3
    (struct.new_default $type43)
   )
   (struct.new $type31
    (ref.func $function54)
    (struct.new $environment54
     (local.get $4)
     (local.get $6)
     (local.get $1)
     (local.get $7)
     (local.get $2)
     (local.get $5)
     (local.get $3)
    )
   )
  )
  (struct.set $type43 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type43 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call31
   (struct.get $type31 1
    (local.tee $8
     (ref.as_non_null
      (struct.get $type43 1
       (local.get $3)
      )
     )
    )
   )
   (i64.const 1)
   (struct.get $type31 0
    (local.get $8)
   )
  )
 )
 (func $function29 (type $call46) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 i64) (result (ref null $type33))
  (local $3 (ref $type47))
  (local $4 (ref $environment29))
  (local $5 (ref $type46))
  (local $6 i64)
  (if (result (ref null $type33))
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $6
     (struct.get $environment29 1
      (local.tee $4
       (ref.cast (ref $environment29)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type47 1
     (local.tee $3
      (struct.new_default $type47)
     )
     (struct.new $type46
      (ref.func $function30)
      (struct.new $environment30
       (local.get $2)
       (struct.get $environment29 0
        (local.get $4)
       )
       (local.get $3)
       (struct.get $environment29 1
        (local.get $4)
       )
      )
     )
    )
    (struct.set $type47 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call46
     (struct.get $type46 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type47 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (i64.sub
       (local.get $6)
       (local.get $2)
      )
      (i64.const 2)
     )
     (struct.get $type46 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function30 (type $call46) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 i64) (result (ref null $type33))
  (local $3 (ref $environment30))
  (local $4 (ref $type12))
  (local $5 (ref $type33))
  (local $6 i64)
  (local $scratch (ref (exact $type12)))
  (if
   (i64.gt_s
    (struct.get $environment30 0
     (local.tee $3
      (ref.cast (ref $environment30)
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment30 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function29
     (struct.get $type46 1
      (struct.get $type47 1
       (struct.get $environment30 1
        (local.get $3)
       )
      )
     )
     (local.get $1)
     (i64.sub
      (struct.get $environment30 0
       (local.get $3)
      )
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready77)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global77)
     )
    )
    (local.set $5
     (struct.new $type33
      (call $function32
       (block (result (ref (exact $type12)))
        (local.set $scratch
         (struct.new $type12
          (local.tee $6
           (struct.get $environment30 0
            (local.get $3)
           )
          )
          (struct.new $type12
           (local.get $2)
           (struct.new $type12
            (i64.sub
             (struct.get $environment30 3
              (local.get $3)
             )
             (i64.add
              (local.get $2)
              (local.get $6)
             )
            )
            (ref.null none)
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready79)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global79)
         )
        )
        (local.get $scratch)
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment30 2
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function30
     (struct.get $type46 1
      (struct.get $type47 1
       (struct.get $environment30 2
        (local.get $3)
       )
      )
     )
     (local.get $5)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function32 (type $58) (param $0 (ref $type12)) (result (ref $type13))
  (local $1 (ref null $type12))
  (local $2 (ref $environment34))
  (local $3 (ref $environment35))
  (local $4 (ref $type52))
  (local $5 (ref $type50))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready82)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global82)
   )
  )
  (struct.set $type52 1
   (local.tee $4
    (struct.new_default $type52)
   )
   (struct.new $type51
    (struct.new $environment34
     (local.get $4)
    )
   )
  )
  (struct.set $type52 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type52 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type52 0
     (struct.get $environment34 0
      (local.tee $2
       (struct.get $type51 0
        (struct.get $type52 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type51 0
    (struct.get $type52 1
     (struct.get $environment34 0
      (local.get $2)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $6
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type12 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type12 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type52 0
          (struct.get $environment34 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type51 0
         (struct.get $type52 1
          (struct.get $environment34 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type12 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type52 0
            (struct.get $environment34 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type51 0
           (struct.get $type52 1
            (struct.get $environment34 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type12 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type52 0
              (struct.get $environment34 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type51 0
             (struct.get $type52 1
              (struct.get $environment34 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type12 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type52 0
                (struct.get $environment34 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type51 0
               (struct.get $type52 1
                (struct.get $environment34 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type12 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type52 0
                  (struct.get $environment34 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type51 0
                 (struct.get $type52 1
                  (struct.get $environment34 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type12 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type52 0
                    (struct.get $environment34 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type51 0
                   (struct.get $type52 1
                    (struct.get $environment34 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type12 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type52 0
                      (struct.get $environment34 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type51 0
                     (struct.get $type52 1
                      (struct.get $environment34 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type12 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type52 0
                        (struct.get $environment34 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function34
                      (struct.get $type51 0
                       (struct.get $type52 1
                        (struct.get $environment34 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type50 1
   (local.tee $5
    (struct.new_default $type50)
   )
   (struct.new $type49
    (struct.new $environment35
     (struct.new $type48
      (i32.const 1)
      (array.new $type13
       (struct.get $type12 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type50 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type50 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type13
   (struct.get $type48 1
    (struct.get $environment35 0
     (local.tee $3
      (struct.get $type49 0
       (struct.get $type50 1
        (local.get $5)
       )
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type12 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type50 0
     (struct.get $environment35 1
      (local.get $3)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type49 0
    (struct.get $type50 1
     (struct.get $environment35 1
      (local.get $3)
     )
    )
   )
  )
  (if (result (ref $type13))
   (ref.is_null
    (local.tee $1
     (struct.get $type12 1
      (local.get $0)
     )
    )
   )
   (then
    (struct.get $type48 1
     (struct.get $environment35 0
      (local.get $3)
     )
    )
   )
   (else
    (array.set $type13
     (struct.get $type48 1
      (struct.get $environment35 0
       (local.get $3)
      )
     )
     (i32.const 1)
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment35 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type49 0
      (struct.get $type50 1
       (struct.get $environment35 1
        (local.get $3)
       )
      )
     )
    )
    (if (result (ref $type13))
     (ref.is_null
      (local.get $1)
     )
     (then
      (struct.get $type48 1
       (struct.get $environment35 0
        (local.get $3)
       )
      )
     )
     (else
      (array.set $type13
       (struct.get $type48 1
        (struct.get $environment35 0
         (local.get $3)
        )
       )
       (i32.const 2)
       (struct.get $type12 0
        (local.get $1)
       )
      )
      (local.set $1
       (struct.get $type12 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type50 0
         (struct.get $environment35 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type49 0
        (struct.get $type50 1
         (struct.get $environment35 1
          (local.get $3)
         )
        )
       )
      )
      (if (result (ref $type13))
       (ref.is_null
        (local.get $1)
       )
       (then
        (struct.get $type48 1
         (struct.get $environment35 0
          (local.get $3)
         )
        )
       )
       (else
        (array.set $type13
         (struct.get $type48 1
          (struct.get $environment35 0
           (local.get $3)
          )
         )
         (i32.const 3)
         (struct.get $type12 0
          (local.get $1)
         )
        )
        (local.set $1
         (struct.get $type12 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type50 0
           (struct.get $environment35 1
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type49 0
          (struct.get $type50 1
           (struct.get $environment35 1
            (local.get $3)
           )
          )
         )
        )
        (if (result (ref $type13))
         (ref.is_null
          (local.get $1)
         )
         (then
          (struct.get $type48 1
           (struct.get $environment35 0
            (local.get $3)
           )
          )
         )
         (else
          (array.set $type13
           (struct.get $type48 1
            (struct.get $environment35 0
             (local.get $3)
            )
           )
           (i32.const 4)
           (struct.get $type12 0
            (local.get $1)
           )
          )
          (local.set $1
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type50 0
             (struct.get $environment35 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (return_call $function35
           (struct.get $type49 0
            (struct.get $type50 1
             (struct.get $environment35 1
              (local.get $3)
             )
            )
           )
           (local.get $1)
           (i64.const 5)
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function34 (type $call51) (param $0 (ref $environment34)) (param $1 (ref null $type12)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type12 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type52 0
         (struct.get $environment34 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function34
       (struct.get $type51 0
        (struct.get $type52 1
         (struct.get $environment34 0
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function35 (type $call49) (param $0 (ref $environment35)) (param $1 (ref null $type12)) (param $2 i64) (result (ref $type13))
  (local $3 i64)
  (if (result (ref $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type48 1
     (struct.get $environment35 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (struct.get $type48 1
      (struct.get $environment35 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment35 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function35
     (struct.get $type49 0
      (struct.get $type50 1
       (struct.get $environment35 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function36 (type $call44) (param $0 (ref $environment36)) (param $1 (ref null $type33)) (param $2 (ref null $type38)) (result (ref null $type38))
  (local $3 (ref $type54))
  (local $4 (ref $type35))
  (local $5 (ref $type35))
  (local $6 (ref $type35))
  (local $7 (ref $type13))
  (local $8 (ref null $type38))
  (local $9 (ref $type53))
  (local $10 i64)
  (if (result (ref null $type38))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.new $type35
      (i32.const 1)
      (array.get $type13
       (local.tee $7
        (struct.get $type33 0
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
    )
    (local.set $5
     (struct.new $type35
      (i32.const 1)
      (array.get $type13
       (local.get $7)
       (i32.const 1)
      )
     )
    )
    (local.set $6
     (struct.new $type35
      (i32.const 1)
      (array.get $type13
       (local.get $7)
       (i32.const 2)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment36 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $10
       (struct.get $type35 1
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (array.get $type37
      (struct.get $type36 1
       (struct.get $environment36 0
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $10)
      )
     )
    )
    (local.set $1
     (struct.get $type33 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type45 0
       (struct.get $environment36 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function36
      (struct.get $type44 0
       (struct.get $type45 1
        (struct.get $environment36 1
         (local.get $0)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
    (struct.set $type54 1
     (local.tee $3
      (struct.new_default $type54)
     )
     (struct.new $type53
      (ref.func $function37)
      (struct.new $environment37
       (local.get $5)
       (local.get $6)
       (struct.get $environment36 0
        (local.get $0)
       )
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type54 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call53
     (struct.get $type53 1
      (local.tee $9
       (ref.as_non_null
        (struct.get $type54 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $8)
     (local.get $2)
     (struct.get $type53 0
      (local.get $9)
     )
    )
   )
  )
 )
 (func $function37 (type $call53) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type38)) (result (ref null $type38))
  (local $3 (ref $environment37))
  (local $4 (ref $type54))
  (local $5 (ref null $type38))
  (local $6 (ref null $type38))
  (local $7 (ref $type53))
  (local $8 i64)
  (if (result (ref null $type38))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment37 3
        (ref.cast (ref $environment37)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type35 1
      (struct.get $environment37 3
       (local.tee $3
        (ref.cast (ref $environment37)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment37 0
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type38))
      (i64.eq
       (struct.get $type35 1
        (struct.get $environment37 0
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type36 0
          (struct.get $environment37 2
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type35 0
          (struct.get $environment37 0
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type35 1
           (struct.get $environment37 0
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type37
        (struct.get $type36 1
         (struct.get $environment37 2
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (struct.get $environment37 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function37
      (struct.get $type53 1
       (struct.get $type54 1
        (struct.get $environment37 4
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type54 1
     (local.tee $4
      (struct.new_default $type54)
     )
     (struct.new $type53
      (ref.func $function38)
      (struct.new $environment38
       (local.get $1)
       (struct.get $environment37 0
        (local.get $3)
       )
       (struct.get $environment37 1
        (local.get $3)
       )
       (struct.get $environment37 2
        (local.get $3)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type54 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call53
     (struct.get $type53 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type54 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type53 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function38 (type $call53) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type38)) (result (ref null $type38))
  (local $3 (ref $environment38))
  (local $4 (ref $type54))
  (local $5 (ref null $type38))
  (local $6 (ref null $type38))
  (local $7 (ref $type53))
  (local $8 i64)
  (if (result (ref null $type38))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment38 1
        (ref.cast (ref $environment38)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type35 1
      (struct.get $environment38 1
       (local.tee $3
        (ref.cast (ref $environment38)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment38 2
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type38))
      (i64.eq
       (struct.get $type35 1
        (struct.get $environment38 2
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type36 0
          (struct.get $environment38 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type35 0
          (struct.get $environment38 2
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type35 1
           (struct.get $environment38 2
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type37
        (struct.get $type36 1
         (struct.get $environment38 3
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (struct.get $environment38 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function38
      (struct.get $type53 1
       (struct.get $type54 1
        (struct.get $environment38 4
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type54 1
     (local.tee $4
      (struct.new_default $type54)
     )
     (struct.new $type53
      (ref.func $function39)
      (struct.new $environment39
       (struct.get $environment38 0
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type54 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call53
     (struct.get $type53 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type54 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type53 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function39 (type $call53) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type38)) (result (ref null $type38))
  (local $3 (ref $environment39))
  (if (result (ref null $type38))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (struct.get $type38 0
      (struct.get $environment39 0
       (local.tee $3
        (ref.cast (ref $environment39)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (struct.get $type38 0
      (struct.get $environment39 1
       (local.get $3)
      )
     )
    )
    (drop
     (struct.get $type38 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (struct.get $environment39 2
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type38
     (struct.new_default $type21)
     (call $function39
      (struct.get $type53 1
       (struct.get $type54 1
        (struct.get $environment39 2
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function41 (type $call55) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $type56))
  (local $4 (ref null $type38))
  (local $5 (ref $type55))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment41 0
        (ref.cast (ref $environment41)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function41
      (struct.get $type55 1
       (struct.get $type56 1
        (struct.get $environment41 0
         (ref.cast (ref $environment41)
          (local.get $0)
         )
        )
       )
      )
      (local.get $4)
      (local.get $2)
     )
    )
    (struct.set $type56 1
     (local.tee $3
      (struct.new_default $type56)
     )
     (struct.new $type55
      (ref.func $function42)
      (struct.new $environment42
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type56 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call55
     (struct.get $type55 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type56 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (local.get $2)
     (struct.get $type55 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function42 (type $call55) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment42))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (struct.get $type38 0
      (struct.get $environment42 0
       (local.tee $3
        (ref.cast (ref $environment42)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (struct.get $type38 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment42 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type16
     (call $function42
      (struct.get $type55 1
       (struct.get $type56 1
        (struct.get $environment42 1
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function45 (type $call46) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 i64) (result (ref null $type33))
  (local $3 (ref $type47))
  (local $4 (ref $environment45))
  (local $5 (ref $type46))
  (local $6 i64)
  (if (result (ref null $type33))
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $6
     (struct.get $environment45 1
      (local.tee $4
       (ref.cast (ref $environment45)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type47 1
     (local.tee $3
      (struct.new_default $type47)
     )
     (struct.new $type46
      (ref.func $function46)
      (struct.new $environment46
       (local.get $2)
       (struct.get $environment45 0
        (local.get $4)
       )
       (struct.get $environment45 1
        (local.get $4)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type47 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call46
     (struct.get $type46 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type47 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (i64.sub
       (local.get $6)
       (local.get $2)
      )
      (i64.const 3)
     )
     (struct.get $type46 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function46 (type $call46) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 i64) (result (ref null $type33))
  (local $3 (ref $environment46))
  (local $4 (ref $type47))
  (local $5 (ref $type46))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (if
   (i64.gt_s
    (struct.get $environment46 0
     (local.tee $3
      (ref.cast (ref $environment46)
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment46 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type46 1
      (struct.get $type47 1
       (struct.get $environment46 1
        (local.get $3)
       )
      )
     )
     (local.get $1)
     (i64.sub
      (struct.get $environment46 0
       (local.get $3)
      )
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global125)
     )
    )
    (struct.set $type47 1
     (local.tee $4
      (struct.new_default $type47)
     )
     (struct.new $type46
      (ref.func $function48)
      (struct.new $environment48
       (struct.new $type35
        (i32.const 1)
        (select
         (local.get $2)
         (local.tee $8
          (i64.sub
           (i64.div_s
            (i64.add
             (local.tee $7
              (struct.get $environment46 2
               (local.get $3)
              )
             )
             (i64.const 1)
            )
            (i64.const 2)
           )
           (i64.add
            (local.tee $6
             (struct.get $environment46 0
              (local.get $3)
             )
            )
            (local.get $2)
           )
          )
         )
         (i64.gt_s
          (local.get $2)
          (local.get $8)
         )
        )
       )
       (struct.get $environment46 3
        (local.get $3)
       )
       (local.get $2)
       (local.get $4)
       (local.get $6)
       (local.get $7)
      )
     )
    )
    (struct.set $type47 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call46
     (struct.get $type46 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type47 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (i64.sub
       (struct.get $environment46 2
        (local.get $3)
       )
       (i64.add
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 2)
     )
     (struct.get $type46 0
      (local.get $5)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function47 (type $call29) (param $0 (ref null $environment64)) (param $1 i64) (param $2 i64) (result i64)
  (select
   (local.get $1)
   (local.get $2)
   (i64.gt_s
    (local.get $1)
    (local.get $2)
   )
  )
 )
 (func $function48 (type $call46) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 i64) (result (ref null $type33))
  (local $3 (ref $environment48))
  (local $4 (ref $type12))
  (local $5 (ref $type33))
  (local $6 i64)
  (local $7 i64)
  (local $scratch (ref (exact $type12)))
  (if
   (i32.eqz
    (struct.get $type35 0
     (struct.get $environment48 0
      (ref.cast (ref $environment48)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_s
    (struct.get $type35 1
     (struct.get $environment48 0
      (local.tee $3
       (ref.cast (ref $environment48)
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment48 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (struct.get $type46 1
      (struct.get $type47 1
       (struct.get $environment48 1
        (local.get $3)
       )
      )
     )
     (local.get $1)
     (i64.sub
      (struct.get $environment48 2
       (local.get $3)
      )
      (i64.const 1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready77)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global77)
     )
    )
    (local.set $5
     (struct.new $type33
      (call $function32
       (block (result (ref (exact $type12)))
        (local.set $scratch
         (struct.new $type12
          (local.tee $6
           (struct.get $environment48 4
            (local.get $3)
           )
          )
          (struct.new $type12
           (local.tee $7
            (struct.get $environment48 2
             (local.get $3)
            )
           )
           (struct.new $type12
            (local.get $2)
            (struct.new $type12
             (i64.sub
              (struct.get $environment48 5
               (local.get $3)
              )
              (i64.add
               (i64.add
                (local.get $2)
                (local.get $7)
               )
               (local.get $6)
              )
             )
             (ref.null none)
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready79)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global79)
         )
        )
        (local.get $scratch)
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment48 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type46 1
      (struct.get $type47 1
       (struct.get $environment48 3
        (local.get $3)
       )
      )
     )
     (local.get $5)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function49 (type $call57) (param $0 (ref $environment49)) (param $1 (ref null $type33)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $type56))
  (local $4 (ref $type13))
  (local $5 (ref $type35))
  (local $6 (ref $type35))
  (local $7 (ref $type35))
  (local $8 (ref $type35))
  (local $9 (ref null $type38))
  (local $10 (ref $type55))
  (local $11 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (struct.new $type35
      (i32.const 1)
      (array.get $type13
       (local.tee $4
        (struct.get $type33 0
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
    )
    (local.set $6
     (struct.new $type35
      (i32.const 1)
      (array.get $type13
       (local.get $4)
       (i32.const 1)
      )
     )
    )
    (local.set $7
     (struct.new $type35
      (i32.const 1)
      (array.get $type13
       (local.get $4)
       (i32.const 2)
      )
     )
    )
    (local.set $8
     (struct.new $type35
      (i32.const 1)
      (array.get $type13
       (local.get $4)
       (i32.const 3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment49 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (struct.get $type35 1
        (local.get $5)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type37
      (struct.get $type36 1
       (struct.get $environment49 0
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $11)
      )
     )
    )
    (local.set $1
     (struct.get $type33 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment49 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function49
      (struct.get $type57 0
       (struct.get $type58 1
        (struct.get $environment49 1
         (local.get $0)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
    (struct.set $type56 1
     (local.tee $3
      (struct.new_default $type56)
     )
     (struct.new $type55
      (ref.func $function50)
      (struct.new $environment50
       (local.get $7)
       (local.get $8)
       (struct.get $environment49 0
        (local.get $0)
       )
       (local.get $6)
       (local.get $5)
       (local.get $3)
      )
     )
    )
    (struct.set $type56 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call55
     (struct.get $type55 1
      (local.tee $10
       (ref.as_non_null
        (struct.get $type56 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $9)
     (local.get $2)
     (struct.get $type55 0
      (local.get $10)
     )
    )
   )
  )
 )
 (func $function50 (type $call55) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment50))
  (local $4 (ref $type56))
  (local $5 (ref null $type38))
  (local $6 (ref null $type38))
  (local $7 (ref $type55))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment50 4
        (ref.cast (ref $environment50)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type35 1
      (struct.get $environment50 4
       (local.tee $3
        (ref.cast (ref $environment50)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment50 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type38))
      (i64.eq
       (struct.get $type35 1
        (struct.get $environment50 3
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type36 0
          (struct.get $environment50 2
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type35 0
          (struct.get $environment50 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type35 1
           (struct.get $environment50 3
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type37
        (struct.get $type36 1
         (struct.get $environment50 2
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment50 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function50
      (struct.get $type55 1
       (struct.get $type56 1
        (struct.get $environment50 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type56 1
     (local.tee $4
      (struct.new_default $type56)
     )
     (struct.new $type55
      (ref.func $function51)
      (struct.new $environment51
       (local.get $1)
       (struct.get $environment50 0
        (local.get $3)
       )
       (struct.get $environment50 1
        (local.get $3)
       )
       (struct.get $environment50 2
        (local.get $3)
       )
       (struct.get $environment50 3
        (local.get $3)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type56 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call55
     (struct.get $type55 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type56 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type55 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function51 (type $call55) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment51))
  (local $4 (ref $type56))
  (local $5 (ref null $type38))
  (local $6 (ref null $type38))
  (local $7 (ref $type55))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment51 4
        (ref.cast (ref $environment51)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type35 1
      (struct.get $environment51 4
       (local.tee $3
        (ref.cast (ref $environment51)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment51 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type38))
      (i64.eq
       (struct.get $type35 1
        (struct.get $environment51 1
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type36 0
          (struct.get $environment51 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type35 0
          (struct.get $environment51 1
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type35 1
           (struct.get $environment51 1
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type37
        (struct.get $type36 1
         (struct.get $environment51 3
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment51 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function51
      (struct.get $type55 1
       (struct.get $type56 1
        (struct.get $environment51 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type56 1
     (local.tee $4
      (struct.new_default $type56)
     )
     (struct.new $type55
      (ref.func $function52)
      (struct.new $environment52
       (struct.get $environment51 0
        (local.get $3)
       )
       (local.get $1)
       (struct.get $environment51 1
        (local.get $3)
       )
       (struct.get $environment51 2
        (local.get $3)
       )
       (struct.get $environment51 3
        (local.get $3)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type56 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call55
     (struct.get $type55 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type56 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type55 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function52 (type $call55) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment52))
  (local $4 (ref $type56))
  (local $5 (ref null $type38))
  (local $6 (ref null $type38))
  (local $7 (ref $type55))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment52 2
        (ref.cast (ref $environment52)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type35 1
      (struct.get $environment52 2
       (local.tee $3
        (ref.cast (ref $environment52)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment52 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (if (result (ref null $type38))
      (i64.eq
       (struct.get $type35 1
        (struct.get $environment52 3
         (local.get $3)
        )
       )
       (local.get $8)
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type36 0
          (struct.get $environment52 4
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type35 0
          (struct.get $environment52 3
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $type35 1
           (struct.get $environment52 3
            (local.get $3)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type37
        (struct.get $type36 1
         (struct.get $environment52 4
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment52 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function52
      (struct.get $type55 1
       (struct.get $type56 1
        (struct.get $environment52 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type56 1
     (local.tee $4
      (struct.new_default $type56)
     )
     (struct.new $type55
      (ref.func $function53)
      (struct.new $environment53
       (struct.get $environment52 0
        (local.get $3)
       )
       (struct.get $environment52 1
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type56 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call55
     (struct.get $type55 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type56 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type55 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function53 (type $call55) (param $0 (ref struct)) (param $1 (ref null $type38)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment53))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (struct.get $type38 0
      (struct.get $environment53 0
       (local.tee $3
        (ref.cast (ref $environment53)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (struct.get $type38 0
      (struct.get $environment53 1
       (local.get $3)
      )
     )
    )
    (drop
     (struct.get $type38 0
      (struct.get $environment53 2
       (local.get $3)
      )
     )
    )
    (drop
     (struct.get $type38 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type38 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment53 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type16
     (call $function53
      (struct.get $type55 1
       (struct.get $type56 1
        (struct.get $environment53 3
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function54 (type $call31) (param $0 (ref null $environment54)) (param $1 i64) (result (ref $type23))
  (local $2 (ref $type47))
  (local $3 (ref $environment59))
  (local $4 (ref struct))
  (local $5 (ref $type56))
  (local $6 (ref $type58))
  (local $7 (ref $type63))
  (local $8 (ref $type61))
  (local $9 (ref $type45))
  (local $10 (ref null $type38))
  (local $11 (ref $type46))
  (local $12 (ref null $type33))
  (local $13 (ref $environment58))
  (local $14 (ref null $type16))
  (local $15 (ref null $type16))
  (local $16 (ref $type55))
  (local $17 (ref $type37))
  (local $18 (ref $environment27))
  (local $19 i64)
  (if
   (i32.eqz
    (struct.get $type35 0
     (struct.get $environment54 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type23))
   (i64.lt_s
    (struct.get $type35 1
     (struct.get $environment54 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (local.set $1
     (struct.get $environment54 2
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment54 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type42 0
      (struct.get $type41 1
       (struct.get $environment54 1
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $14
     (if (result (ref null $type16))
      (i32.wrap_i64
       (i64.and
        (local.get $1)
        (i64.const 1)
       )
      )
      (then
       (ref.null none)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type36 0
          (struct.get $environment40 0
           (ref.cast (ref $environment40)
            (local.get $4)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $1
          (i64.div_s
           (local.get $1)
           (i64.const 2)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $10
        (array.get $type37
         (struct.get $type36 1
          (struct.get $environment40 0
           (ref.cast (ref $environment40)
            (local.get $4)
           )
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (struct.set $type56 1
        (local.tee $5
         (struct.new_default $type56)
        )
        (struct.new $type55
         (ref.func $function41)
         (struct.new $environment41
          (local.get $5)
         )
        )
       )
       (struct.set $type56 0
        (local.get $5)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type56 0
          (local.get $5)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call55
        (struct.get $type55 1
         (local.tee $16
          (ref.as_non_null
           (struct.get $type56 1
            (local.get $5)
           )
          )
         )
        )
        (local.get $10)
        (ref.null none)
        (struct.get $type55 0
         (local.get $16)
        )
       )
      )
     )
    )
    (local.set $1
     (struct.get $environment54 2
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment54 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type42 0
      (struct.get $type41 1
       (struct.get $environment54 3
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (struct.set $type47 1
     (local.tee $2
      (struct.new_default $type47)
     )
     (struct.new $type46
      (ref.func $function45)
      (struct.new $environment45
       (local.get $2)
       (local.tee $1
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
      )
     )
    )
    (struct.set $type47 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (call_ref $call46
      (struct.get $type46 1
       (local.tee $11
        (ref.as_non_null
         (struct.get $type47 1
          (local.get $2)
         )
        )
       )
      )
      (ref.null none)
      (i64.div_s
       (local.get $1)
       (i64.const 4)
      )
      (struct.get $type46 0
       (local.get $11)
      )
     )
    )
    (struct.set $type58 1
     (local.tee $6
      (struct.new_default $type58)
     )
     (struct.new $type57
      (struct.new $environment49
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $4)
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type58 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $15
     (call $function49
      (struct.get $type57 0
       (struct.get $type58 1
        (local.get $6)
       )
      )
      (local.get $12)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global153)
     )
    )
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (if
     (i32.eqz
      (global.get $ready158)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (struct.set $type63 1
     (local.tee $7
      (struct.new_default $type63)
     )
     (struct.new $type62
      (struct.new $environment58
       (local.get $7)
      )
     )
    )
    (struct.set $type63 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type63 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment58 0
        (local.tee $13
         (struct.get $type62 0
          (struct.get $type63 1
           (local.get $7)
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment58 0
        (local.tee $13
         (struct.get $type62 0
          (struct.get $type63 1
           (struct.get $environment58 0
            (local.get $13)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type62 0
      (struct.get $type63 1
       (struct.get $environment58 0
        (local.get $13)
       )
      )
     )
    )
    (struct.set $type61 1
     (local.tee $8
      (struct.new_default $type61)
     )
     (struct.new $type60
      (struct.new $environment59
       (struct.new $type59
        (i32.const 1)
        (array.new $type23
         (local.get $14)
         (i32.const 2)
        )
       )
       (local.get $8)
      )
     )
    )
    (struct.set $type61 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type23
     (struct.get $type59 1
      (struct.get $environment59 0
       (local.tee $3
        (struct.get $type60 0
         (struct.get $type61 1
          (local.get $8)
         )
        )
       )
      )
     )
     (i32.const 0)
     (local.get $14)
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment59 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type23
     (struct.get $type59 1
      (struct.get $environment59 0
       (local.tee $3
        (struct.get $type60 0
         (struct.get $type61 1
          (struct.get $environment59 1
           (local.get $3)
          )
         )
        )
       )
      )
     )
     (i32.const 1)
     (local.get $15)
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment59 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.get $type59 1
     (struct.get $environment59 0
      (struct.get $type60 0
       (struct.get $type61 1
        (struct.get $environment59 1
         (local.get $3)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment54 4
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type37
     (struct.get $type36 1
      (struct.get $environment54 4
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (struct.get $type39 0
         (struct.get $environment54 5
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $18
       (struct.get $type40 0
        (struct.get $type39 1
         (struct.get $environment54 5
          (local.get $0)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready69)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global69)
       )
      )
      (struct.set $type47 1
       (local.tee $2
        (struct.new_default $type47)
       )
       (struct.new $type46
        (ref.func $function29)
        (struct.new $environment29
         (local.get $2)
         (local.tee $19
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
        )
       )
      )
      (struct.set $type47 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type47 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $12
       (call_ref $call46
        (struct.get $type46 1
         (local.tee $11
          (ref.as_non_null
           (struct.get $type47 1
            (local.get $2)
           )
          )
         )
        )
        (ref.null none)
        (i64.div_s
         (local.get $19)
         (i64.const 3)
        )
        (struct.get $type46 0
         (local.get $11)
        )
       )
      )
      (struct.set $type45 1
       (local.tee $9
        (struct.new_default $type45)
       )
       (struct.new $type44
        (struct.new $environment36
         (struct.get $environment27 0
          (local.get $18)
         )
         (local.get $9)
        )
       )
      )
      (struct.set $type45 0
       (local.get $9)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type45 0
         (local.get $9)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $10
       (call $function36
        (struct.get $type44 0
         (struct.get $type45 1
          (local.get $9)
         )
        )
        (local.get $12)
        (ref.null none)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $10)
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment54 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (struct.get $type31 1
      (struct.get $type43 1
       (struct.get $environment54 6
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function60 (type $call34) (param $0 i64) (result i64)
  (local $1 (ref null $type16))
  (local $2 (ref $environment62))
  (local $3 (ref $type65))
  (local $4 (ref $type23))
  (if
   (i32.eqz
    (global.get $ready63)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (array.get $type23
    (local.tee $4
     (call $function26
      (struct.get $type31 1
       (global.get $global63)
      )
      (local.get $0)
     )
    )
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready169)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (struct.set $type65 1
   (local.tee $3
    (struct.new_default $type65)
   )
   (struct.new $type64
    (struct.new $environment62
     (local.get $3)
    )
   )
  )
  (struct.set $type65 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type65 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type64 0
    (struct.get $type65 1
     (local.get $3)
    )
   )
  )
  (local.set $0
   (if (result i64)
    (ref.is_null
     (local.get $1)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $1
      (struct.get $type16 0
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (struct.get $type65 0
        (struct.get $environment62 0
         (local.get $2)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $2
      (struct.get $type64 0
       (struct.get $type65 1
        (struct.get $environment62 0
         (local.get $2)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type16 0
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type65 0
          (struct.get $environment62 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type64 0
         (struct.get $type65 1
          (struct.get $environment62 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type16 0
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type65 0
            (struct.get $environment62 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type64 0
           (struct.get $type65 1
            (struct.get $environment62 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type16 0
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type65 0
              (struct.get $environment62 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type64 0
             (struct.get $type65 1
              (struct.get $environment62 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type16 0
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type65 0
                (struct.get $environment62 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type64 0
               (struct.get $type65 1
                (struct.get $environment62 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type16 0
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type65 0
                  (struct.get $environment62 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type64 0
                 (struct.get $type65 1
                  (struct.get $environment62 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type16 0
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type65 0
                    (struct.get $environment62 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type64 0
                   (struct.get $type65 1
                    (struct.get $environment62 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type16 0
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type65 0
                      (struct.get $environment62 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type64 0
                     (struct.get $type65 1
                      (struct.get $environment62 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type16 0
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type65 0
                        (struct.get $environment62 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function62
                      (struct.get $type64 0
                       (struct.get $type65 1
                        (struct.get $environment62 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $1
   (array.get $type23
    (local.get $4)
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready169)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (struct.set $type65 1
   (local.tee $3
    (struct.new_default $type65)
   )
   (struct.new $type64
    (struct.new $environment62
     (local.get $3)
    )
   )
  )
  (struct.set $type65 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type65 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type64 0
    (struct.get $type65 1
     (local.get $3)
    )
   )
  )
  (i64.add
   (if (result i64)
    (ref.is_null
     (local.get $1)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $1
      (struct.get $type16 0
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (struct.get $type65 0
        (struct.get $environment62 0
         (local.get $2)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $2
      (struct.get $type64 0
       (struct.get $type65 1
        (struct.get $environment62 0
         (local.get $2)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type16 0
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type65 0
          (struct.get $environment62 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type64 0
         (struct.get $type65 1
          (struct.get $environment62 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type16 0
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type65 0
            (struct.get $environment62 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type64 0
           (struct.get $type65 1
            (struct.get $environment62 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type16 0
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type65 0
              (struct.get $environment62 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type64 0
             (struct.get $type65 1
              (struct.get $environment62 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type16 0
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type65 0
                (struct.get $environment62 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type64 0
               (struct.get $type65 1
                (struct.get $environment62 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type16 0
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type65 0
                  (struct.get $environment62 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type64 0
                 (struct.get $type65 1
                  (struct.get $environment62 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type16 0
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type65 0
                    (struct.get $environment62 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type64 0
                   (struct.get $type65 1
                    (struct.get $environment62 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type16 0
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type65 0
                      (struct.get $environment62 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type64 0
                     (struct.get $type65 1
                      (struct.get $environment62 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type16 0
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type65 0
                        (struct.get $environment62 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function62
                      (struct.get $type64 0
                       (struct.get $type65 1
                        (struct.get $environment62 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.get $0)
  )
 )
 (func $function62 (type $call64) (param $0 (ref $environment62)) (param $1 (ref null $type16)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type16 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type65 0
       (struct.get $environment62 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (struct.get $type64 0
      (struct.get $type65 1
       (struct.get $environment62 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function64 (type $call29) (param $0 (ref null $environment64)) (param $1 i64) (param $2 i64) (result i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment64 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready174)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready180)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global180)
     )
    )
    (local.set $2
     (call $function60
      (block (result i64)
       (local.set $scratch
        (call $foreign0
         (global.get $global174)
        )
       )
       (if
        (i32.eqz
         (global.get $ready166)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global166)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (struct.get $environment64 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (struct.get $type29 1
      (struct.get $type66 1
       (struct.get $environment64 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function65 (type $call29) (param $0 (ref null $environment64)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type66))
  (local $2 (ref $type29))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready175)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (struct.set $type66 1
   (local.tee $1
    (struct.new_default $type66)
   )
   (struct.new $type29
    (ref.func $function64)
    (struct.new $environment64
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type66 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type66 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type66 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type29 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global77
   (struct.new_default $type11)
  )
  (global.set $ready77
   (i32.const 1)
  )
  (global.set $global153
   (struct.new_default $type14)
  )
  (global.set $ready153
   (i32.const 1)
  )
  (global.set $global79
   (struct.new_default $type24)
  )
  (global.set $ready79
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type25)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type26)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $global158
   (struct.new_default $type27)
  )
  (global.set $ready158
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type28)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global125
   (struct.new $type29
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type30)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global180
   (struct.new $type29
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $ready180
   (i32.const 1)
  )
  (global.set $global63
   (struct.new $type31
    (ref.func $function26)
    (ref.null none)
   )
  )
  (global.set $ready63
   (i32.const 1)
  )
  (global.set $global69
   (struct.new_default $type32)
  )
  (global.set $ready69
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type32)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type34)
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global174
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready174
   (i32.const 1)
  )
  (global.set $global175
   (struct.new_default $type34)
  )
  (global.set $ready175
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

