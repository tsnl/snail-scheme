(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/strict-quicksort-frozen-final-5894df7/quicksort/chez-output-probe-original/program.scm" "/tmp/strict-quicksort-frozen-final-5894df7/quicksort/chez-output-probe-original/program.so"))
