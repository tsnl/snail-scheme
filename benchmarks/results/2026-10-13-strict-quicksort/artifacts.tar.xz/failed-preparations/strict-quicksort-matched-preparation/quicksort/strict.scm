(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-extern native-count "benchmark" "count" (-> I64))
(define-extern native-vector-length "benchmark" "vector_length" (-> I32 I64))
(define-extern native-vector-i64 "benchmark" "vector_i64" (-> I32 I64 I64))
(define-extern native-expected-length "benchmark" "expected_length" (-> I64))
(define-extern native-expected-i64 "benchmark" "expected_i64" (-> I64 I64))
(define (inexact value) (i64->f64 value))
(define (exact value) (f64->i64 value))
(define (values value) value)
(define (input-i64-vector index)
  (let ((n (native-vector-length index)))
    (let ((result (make-vector n 0)))
      (let loop ((i 0))
        (if (= i n) result
            (begin (vector-set! result i (native-vector-i64 index i))
                   (loop (+ i 1))))))))
(define (same-expected-i64-vector? source)
  (and (= (vector-length source) (native-expected-length))
       (let loop ((i 0))
         (or (= i (vector-length source))
             (and (= (vector-ref source i) (native-expected-i64 i))
                  (loop (+ i 1)))))))
(define (same-input-i64-vector? source index)
  (and (= (vector-length source) (native-vector-length index))
       (let loop ((i 0))
         (or (= i (vector-length source))
             (and (= (vector-ref source i) (native-vector-i64 index i))
                  (loop (+ i 1)))))))
(define (same-f64-list? xs ys)
  (if (null? xs) (null? ys)
      (and (not (null? ys)) (= (car xs) (car ys))
           (same-f64-list? (cdr xs) (cdr ys)))))
(: uninitialized-seed-set (-> (Rest F64) Unit))
(define (uninitialized-seed-set . state) (unreachable))
(: uninitialized-seed-ref (-> (List F64)))
(define (uninitialized-seed-ref) (unreachable))
(: uninitialized-random-flonum (-> F64))
(define (uninitialized-random-flonum) (unreachable))
;; ---- Per-element mapping and adjacent-pair validation ----

(define (map-vector-elements function source)
  (let ((n (vector-length source)))
    (if (= n 0) (empty-vector)
        (let ((result (make-vector n (function (vector-ref source 0)))))
          (let loop ((i 1))
            (if (= i n) result
                (begin (vector-set! result i (function (vector-ref source i)))
                       (loop (+ i 1)))))))))
(define (sorted-i64-vector? source)
  (let loop ((i 1))
    (or (>= i (vector-length source))
        (and (<= (vector-ref source (- i 1)) (vector-ref source i))
             (loop (+ i 1))))))
(define (hide count x) (if (barrier) x (unreachable)))
;; This is probably from Lars Hansen's MS thesis.
;; The quick-1 benchmark.  (Figure 35, page 132.)


(define (quick-1 v less?)

  (define (helper left right)
    (if (< left right)
        (let ((median (partition v left right less?)))
          (if (< (- median left) (- right median))
              (begin (helper left (- median 1))
                     (helper (+ median 1) right))
              (begin (helper (+ median 1) right)
                     (helper left (- median 1)))))
        v))

  (helper 0 (- (vector-length v) 1)))


(define (partition v left right less?)
  (let ((mid (vector-ref v right)))

    (define (uploop i)
      (let ((i (+ i 1)))
        (if (and (< i right) (less? (vector-ref v i) mid))
            (uploop i)
            i)))

    (define (downloop j)
      (let ((j (- j 1)))
        (if (and (> j left) (less? mid (vector-ref v j)))
            (downloop j)
            j)))

    (define (ploop i j)
      (let* ((i (uploop i))
             (j (downloop j)))
        (let ((tmp (vector-ref v i)))
          (vector-set! v i (vector-ref v j))
          (vector-set! v j tmp)
          (if (< i j)
              (ploop i j)
              (begin (vector-set! v j (vector-ref v i))
                     (vector-set! v i (vector-ref v right))
                     (vector-set! v right tmp)
                     i)))))

    (ploop (- left 1) right)))

;;; Hansen's original code for this benchmark used Larceny's
;;; predefined random procedure.  When Marc Feeley modified
;;; Hansen's benchmark for the Gambit benchmark suite, however,
;;; he added a specific random number generator taken from an
;;; article in CACM.  Feeley's generator used bignums, and was
;;; extremely slow, causing the Gambit version of this benchmark
;;; to spend nearly all of its time generating the random numbers.
;;; For a benchmark called quicksort to become a bignum benchmark
;;; was very misleading, so Clinger left Feeley's version of this
;;; benchmark out of the Larceny benchmark suite.
;;;
;;; The following random number generator is much better and
;;; faster than the one used in the Gambit benchmark.  See
;;;
;;; http://srfi.schemers.org/srfi-27/mail-archive/msg00000.html
;;; http://www.math.purdue.edu/~lucier/random/random.scm

;;; A uniform [0,1] random number generator; is
;;; Pierre L'Ecuyer's generator from his paper
;;; "Good parameters and implementations for combined multiple
;;; recursive random number generators"
;;; available at his web site http://www.iro.umontreal.ca/~lecuyer

(define seed-set! (ref uninitialized-seed-set))
(define seed-ref (ref uninitialized-seed-ref))
(define random-flonum (ref uninitialized-random-flonum))

(let ((norm 2.328306549295728e-10)
      (m1 4294967087.0)
      (m2 4294944443.0)
      (a12 1403580.0)
      (a13n 810728.0)
      (a21 527612.0)
      (a23n 1370589.0)
      (seed (ref (vector 1.0 0.0 0.0 1.0 0.0 0.0))));; will be mutated

  ;; uses no conversions between flonums and fixnums.

  (ref-set! random-flonum
        (lambda ()
          (let ((seed (ref-get seed)));; make it local
            (let ((p1 (- (* a12 (vector-ref seed 1))
                         (* a13n (vector-ref seed 0))))
                  (p2 (- (* a21 (vector-ref seed 5))
                         (* a23n (vector-ref seed 3)))))
              (let ((k1 (truncate (/ p1 m1)))
                    (k2 (truncate (/ p2 m2)))
                    (ignore1 (vector-set! seed 0 (vector-ref seed 1)))
                    (ignore3 (vector-set! seed 3 (vector-ref seed 4))))
                (let ((p1 (- p1 (* k1 m1)))
                      (p2 (- p2 (* k2 m2)))
                      (ignore2 (vector-set! seed 1 (vector-ref seed 2)))
                      (ignore4 (vector-set! seed 4 (vector-ref seed 5))))
                  (let ((p1 (if (< p1 0.0) (+ p1 m1) p1))
                        (p2 (if (< p2 0.0) (+ p2 m2) p2)))
                    (vector-set! seed 2 p1)
                    (vector-set! seed 5 p2)
                    (if (<= p1 p2)
                        (* norm (+ (- p1 p2) m1))
                        (* norm (- p1 p2))))))))))

  (ref-set! seed-ref (lambda () (vector->list (ref-get seed))))

  (ref-set! seed-set! (lambda l (ref-set! seed (list->vector l)))))

(define (random n)
  (exact (truncate (* (inexact n) ((ref-get random-flonum))))))

;;; Even with the improved random number generator,
;;; this benchmark still spends almost all of its time
;;; generating the random vector.  To make this a true
;;; quicksort benchmark, we generate a relatively small
;;; random vector and then sort many copies of it.

;; ---- Original vector generation before timing ----

(define setup-count (native-count))
(define input0 (hide setup-count (native-input-i64 (ann 0 I32))))
(define input1 (hide setup-count (native-input-i64 (ann 1 I32))))
(define less? (hide setup-count (ann (lambda (x y) (< x y)) (-> I64 I64 Bool))))
(define quicksort-input
  (let ((v (ann (make-vector input0) (Vector I64))))
    (let loop ((i 0))
      (if (= i input0) v
          (begin (vector-set! v i (random input1)) (loop (+ i 1)))))))

;; ---- Supplemental full-output and initialization probes ----

(: quicksort-probe (-> I64 I64))
(define (quicksort-probe count)
  (let* ((source (input-i64-vector (ann 2 I32)))
         (result (quick-1 (map-vector-elements values source) less?)))
    (if (and (same-expected-i64-vector? result)
             (sorted-i64-vector? result)
             (same-input-i64-vector? source (ann 2 I32))
             (not (vector-eq? result source))) 1 0)))
(: quicksort-rng-probe (-> I64 I64))
(define (quicksort-rng-probe count)
  (if (same-expected-i64-vector? quicksort-input) 1 0))
(: quicksort-seed-probe (-> I64 I64))
(define (quicksort-seed-probe count)
  ((ref-get seed-set!) 1.0 0.0 0.0 1.0 0.0 0.0)
  (if (and (same-f64-list? ((ref-get seed-ref))
                          (vector->list (vector 1.0 0.0 0.0 1.0 0.0 0.0)))
           (= (random input1) (native-expected-i64 0))) 1 0))
(: quicksort-sorted-probe (-> I64 I64))
(define (quicksort-sorted-probe count)
  (if (sorted-i64-vector? (input-i64-vector (ann 2 I32))) 1 0))
(: bench (-> I64 I64))
(define (bench count) (if (sorted-i64-vector? (let loop ((i 0) (result quicksort-input))
    (if (< i count) (loop (+ i 1) (quick-1 (map-vector-elements values quicksort-input) less?)) result))) 1 0))
(unit)
