(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/strict-quicksort-matched-preparation/quicksort/program.scm" "/tmp/strict-quicksort-matched-preparation/quicksort/program.so"))
