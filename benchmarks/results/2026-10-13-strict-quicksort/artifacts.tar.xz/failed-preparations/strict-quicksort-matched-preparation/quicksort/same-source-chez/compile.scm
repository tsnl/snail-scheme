(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/strict-quicksort-matched-preparation/quicksort/same-source-chez/program.scm" "/tmp/strict-quicksort-matched-preparation/quicksort/same-source-chez/program.so"))
