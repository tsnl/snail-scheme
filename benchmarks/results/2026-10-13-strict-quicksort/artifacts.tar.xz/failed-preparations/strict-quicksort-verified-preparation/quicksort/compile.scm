(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/strict-quicksort-verified-preparation/quicksort/program.scm" "/tmp/strict-quicksort-verified-preparation/quicksort/program.so"))
