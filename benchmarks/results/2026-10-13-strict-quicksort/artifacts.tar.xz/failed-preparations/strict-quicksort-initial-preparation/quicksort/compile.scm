(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/strict-quicksort-initial-preparation/quicksort/program.scm" "/tmp/strict-quicksort-initial-preparation/quicksort/program.so"))
