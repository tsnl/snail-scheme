#!/usr/bin/env python3
"""Inspect instruction sites in the frozen optimized quicksort Wasm text."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def function_bodies(wat):
    starts = list(re.finditer(r'^ \(func (\$[^\s()]+)', wat, re.M))
    result = {}
    for index, match in enumerate(starts):
        stop = starts[index + 1].start() if index + 1 < len(starts) else len(wat)
        result[match.group(1)] = (match.start(), stop, wat[match.start():stop])
    return result


def instruction_sites(body):
    operations = re.findall(r'\((array\.[\w.]+|i64\.[\w.]+|f64\.[\w.]+|call_ref|return_call_ref|return_call)(?:\s|\))', body)
    return dict(sorted(Counter(operations).items()))


def inspect_function(wat, name, role, bounds):
    start, stop, body = bounds
    return dict(function=name, role=role, start_line=wat[:start].count('\n') + 1,
                end_line=wat[:stop].count('\n') + 1, static_instruction_sites=instruction_sites(body),
                direct_call_targets=re.findall(r'\((?:call|return_call) (\$[^\s()]+)', body),
                referenced_functions=re.findall(r'\(ref.func (\$[^\s()]+)', body))


def main():
    directory, destination = map(Path, sys.argv[1:])
    wat = (directory / 'strict.optimized.wat').read_text()
    bodies = function_bodies(wat)
    roles = {
        '$function69': 'bench entry: repeat loop, then complete adjacent-pair validation',
        '$function70': 'repeat loop: map base vector, sort copy, advance iteration and tail-call itself',
        '$function51': 'element mapper entry: map first value, allocate filled I64 array, enter element loop',
        '$function52': 'element mapper loop: load source, call identity mapper, store result and advance index',
        '$function54': 'quicksort helper: last-pivot load, partition, smaller-partition comparison and recursive ordering',
        '$function56': 'upward scan: advance index and compare vector element with pivot',
        '$function57': 'downward scan: decrease index and compare pivot with vector element',
        '$function58': 'partition loop: call both scans, swap crossing values, restore final pivot',
        '$function62': 'final validation loop: compare both adjacent values and stop at the first inversion',
        '$function37': 'untimed RNG: two combined recurrences, truncation and all six seed updates',
        '$function48': 'untimed base-vector fill: invoke initialized RNG, scale/truncate/convert and store each I64',
        '$main': 'untimed initialization: install RNG procedures, load count/inputs, perform three opacity calls and construct base input',
    }
    records = [inspect_function(wat, name, role, bodies[name]) for name, role in roles.items()]
    sites = {record['function']: record['static_instruction_sites'] for record in records}
    assert sites['$function51']['array.new'] == 1
    assert sites['$function52']['array.get'] == sites['$function52']['array.set'] == sites['$function52']['call_ref'] == 1
    assert sites['$function58']['array.get'] == 4 and sites['$function58']['array.set'] == 5
    assert sites['$function62']['array.get'] == 2 and sites['$function62']['return_call'] == 1
    assert sites['$function37']['f64.trunc'] == 2 and sites['$function37']['array.set'] == 6
    assert re.findall(r'\((?:call|return_call) (\$[^\s()]+)', bodies['$function70'][2]) == ['$function51', '$function54', '$function70']
    assert '(array.copy ' not in wat
    assert '(export "bench" (func $export0))' in wat and '(return_call $function69' in bodies['$export0'][2]
    report = dict(strict_wasm_sha256=digest(directory / 'strict.wasm'),
                  optimized_wat_sha256=digest(directory / 'strict.optimized.wat'),
                  strict_source_sha256=digest(directory / 'strict.scm'),
                  evidence_kind='Static inspection of the exact optimized artifact; no V8 machine-code/tier audit or dynamic instruction counts.',
                  timed_path='bench export0 -> function69 -> function70; every iteration calls function51 mapper and function54 sort; function69 then invokes function62 validator.',
                  no_array_copy_instruction_sites=True,
                  original_predicate_limitation='Sortedness alone does not prove multiplicity or original input preservation; supplemental complete-output probes cover bounded cases.',
                  opacity_limitation='The three opacity calls precede timing and do not establish dynamic work retention.',
                  functions=records)
    destination.write_text(json.dumps(report, indent=2) + '\n')
    print('Verified retained allocation, per-element mapping, partition/scans, repetition and adjacent validation in optimized Wasm.')


if __name__ == '__main__':
    main()
