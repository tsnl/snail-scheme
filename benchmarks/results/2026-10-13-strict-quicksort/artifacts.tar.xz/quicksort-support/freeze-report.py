from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile

ROOT = Path('/tmp/snail-strict-quicksort-20261013')
PREPARATION = Path('/tmp/strict-quicksort-frozen-final-5894df7')
REPORT = ROOT / 'benchmarks/results/2026-10-13-strict-quicksort'
BASE = '5894df771cace27507e0f1ab15f6dd320d2a6ad4'
FAILURES = [Path('/tmp/strict-quicksort-initial-preparation'),
            Path('/tmp/strict-quicksort-matched-preparation'),
            Path('/tmp/strict-quicksort-verified-preparation')]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


prepared = json.loads((PREPARATION / 'prepared.json').read_text())
assert prepared['cases'][0]['status'] == 'ready'
assert prepared['driver_sha256'] == digest(ROOT / 'benchmarks/strict-suite/measure.py')
assert prepared['host_sha256'] == digest(ROOT / 'benchmarks/strict-suite/host.mjs')
assert prepared['runner_sha256'] == digest(ROOT / 'benchmarks/r7rs.py')
REPORT.mkdir(parents=True, exist_ok=False)
case = PREPARATION / 'quicksort'
records = {name: json.loads((case / name).read_text()) for name in [
    'validation.json', 'validation-negative.json', 'validation-negative-rng.json',
    'chez-validation.json', 'chez-output-probe-original/validation.json',
    'chez-output-probe-same-source-chez/validation.json']}
assert all(record['returncode'] == 0 for record in records['validation.json'])
assert all(record['rejected'] for name in ['validation-negative.json', 'validation-negative-rng.json'] for record in records[name])
assert all(record['returncode'] == 0 for record in records['chez-validation.json'])
for name in ['chez-output-probe-original/validation.json', 'chez-output-probe-same-source-chez/validation.json']:
    assert all(record['returncode'] == 0 and record['stdout'].strip() == ('#t' if record['expected_flag'] else '#f') for record in records[name])
for name, expected in prepared['cases'][0]['hashes'].items():
    assert digest(case / name) == expected, name
for tool in prepared['tools'].values():
    assert digest(Path(tool['path'])) == tool['sha256']
for name, expected in prepared['compiler_files'].items():
    canonical = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=ROOT)
    assert hashlib.sha256(canonical).hexdigest() == expected, name

counts = {name: len(checks) for name, checks in records.items()}
save(REPORT / 'correctness-summary.json', dict(status='all expected outcomes passed',
     checks=counts, total_checks=sum(counts.values()),
     canonical_inputs=prepared['cases'][0]['spec'],
     default_node_behavior=True, no_compiler_changes=True, measurement_observations=0,
     empty_scope='Empty sorting is supplemental; empty copy identity is not required and the canonical predicate only promises positive-length equivalence.'))
save(REPORT / 'compiler-identity.json', dict(base_commit=BASE, file_count=len(prepared['compiler_files']),
     every_compiler_file_matches_base=True, files=prepared['compiler_files']))
save(REPORT / 'prepared.json', prepared)
subprocess.run(['python3', '/tmp/quicksort-retention-audit.py', str(case), str(REPORT / 'retention-audit.json')], check=True)
shutil.copyfile('/tmp/strict-quicksort-behavioral-brief.md', REPORT / 'simplify-behavioral-brief.md')
shutil.copyfile('/tmp/quicksort-prior-port-regression.json', REPORT / 'prior-port-regression.json')

reasons = [
    'The first adapted Chez helper conflicted with imported vector-map; the corrected adapter uses a local per-element mapper name and records the wrapper edit.',
    'The original Chez empty-vector mapping probe failed its identity assertion; canonical positive lengths still require fresh copy identity, while empty sorting promises values/source preservation only.',
    'The original Chez RNG probe incorrectly generated according to expected-vector length, accepting a shortened correct prefix; generation now uses the independent benchmark input length and both controls reject wrong/short/long expectations.',
]
failed = []
for path, reason in zip(FAILURES, reasons):
    entry = json.loads((path / 'prepared.json').read_text())['cases'][0]
    assert entry['status'] == 'prepare-failed'
    failed.append(dict(directory=path.name, recorded_diagnostic=entry['diagnostic'], reason=reason, corrected=True))
save(REPORT / 'preparation-history.json', dict(failed_preparations=failed,
     frozen_final_preparation=PREPARATION.name, final_status='ready', timing_attempts=0))

version_records = {}
for label, tool in prepared['tools'].items():
    argument = '-V' if label == 'CHIBI' else '--version'
    record = subprocess.run([tool['path'], argument], capture_output=True, text=True)
    assert record.returncode == 0
    version_records[label] = dict(tool, command=[tool['path'], argument],
                                 stdout=record.stdout, stderr=record.stderr, returncode=record.returncode)
node = prepared['tools']['NODE']['path']
node_versions = json.loads(subprocess.check_output([node, '-p', 'JSON.stringify(process.versions)'], text=True))
configured = json.loads((ROOT / 'benchmarks/results/2026-10-13-strict-vector-array1/environment.json').read_text())['build_environment']
save(REPORT / 'environment.json', dict(date=datetime.now(timezone.utc).isoformat(), tools=version_records,
     node_versions=node_versions, platform=platform.platform(),
     cpu_info=Path('/proc/cpuinfo').read_text().split('\n\n')[0], allowed_cpus=sorted(os.sched_getaffinity(0)),
     planned_measurement_cpu=5, build_environment=configured, NODE_OPTIONS=None,
     timing_window='Pending parent independent review and explicit coordinated quiet-window authorization.',
     performance_runs=0))
save(REPORT / 'measurement-metadata.json', dict(status='prepared; review and timing pending',
     compiler_base=BASE, upstream_commit=prepared['upstream_commit'],
     artifact_root=PREPARATION.name, driver_sha256=prepared['driver_sha256'],
     host_sha256=prepared['host_sha256'], runner_sha256=prepared['runner_sha256'],
     systems=['strict', 'chez', 'chez-adapted'], planned_discarded_trios=1,
     planned_retained_trios=3, default_v8_tiering=True, planned_cpu=5,
     quiet_window_authorized=False, performance_observations=0,
     simplification_scope=['benchmarks/strict-suite/measure.py', 'benchmarks/strict-suite/host.mjs'],
     longer_functions='The exact source adapter, six-state RNG reference, finite probe enumeration, source-roundtrip proof and validation/build protocols remain cohesive ordered operations; independent review is pending.'))
coverage = json.loads((ROOT / 'benchmarks/results/2026-10-13-strict-fft/coverage.json').read_text())
coverage['not_yet_ported'].remove('quicksort')
coverage['unported_count'] = len(coverage['not_yet_ported'])
coverage['prepared_pending_measurement'] = ['quicksort']
coverage['measured_previous_fft'] = ['fft']
coverage['measured_here'] = []
coverage['scope'] = 'Prior 19 measured passing ports/slices remain unchanged; quicksort is prepared with canonical correctness evidence and awaits independent review and timing.'
coverage['prior_coverage_source_commit'] = BASE
save(REPORT / 'coverage.json', coverage)

support = Path('/tmp/quicksort-frozen-support')
support.mkdir(exist_ok=False)
shutil.copyfile('/tmp/quicksort-retention-audit.py', support / 'retention-audit.py')
shutil.copyfile('/tmp/quicksort-freeze-report.py', support / 'freeze-report.py')
for path in REPORT.iterdir():
    if path.is_file():
        shutil.copyfile(path, support / path.name)
files = {}
packages = [(PREPARATION, PREPARATION.name), *[(path, 'failed-preparations/' + path.name) for path in FAILURES],
            (support, 'quicksort-support')]
with tarfile.open(REPORT / 'artifacts.tar.xz', 'w:xz') as archive:
    for base, prefix in packages:
        for path in sorted(base.rglob('*')):
            if path.is_file():
                assert not path.is_symlink(), path
                name = prefix + '/' + str(path.relative_to(base))
                archive.add(path, arcname=name, recursive=False)
                files[name] = digest(path)
save(REPORT / 'manifest.json', dict(archive_sha256=digest(REPORT / 'artifacts.tar.xz'), files=files))
print('Frozen', len(files), 'files and', sum(counts.values()), 'expected correctness outcomes. No timings.')
