"""Lexically bound reference inventory for the pinned compiler source only."""

import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'benchmarks/strict-suite'))
import compiler_port

source = (ROOT / 'benchmarks/r7rs-benchmarks/src/compiler.scm').read_text()
items = compiler_port.tokens(source)
cursor = 0


def parse():
    global cursor
    token = items[cursor]
    cursor += 1
    if token[0] in ("'", '`', ',', ',@'):
        names = {"'": 'quote', '`': 'quasiquote', ',': 'unquote', ',@': 'unquote-splicing'}
        return [(names[token[0]], token.start()), parse()]
    if token[0] in ('(', '#('):
        result = []
        while items[cursor][0] != ')':
            result.append(parse())
        cursor += 1
        return [('quote', token.start()), result] if token[0] == '#(' else result
    return token[0], token.start()


def name(value):
    return value[0] if isinstance(value, tuple) else None


def bound_names(parameters):
    if isinstance(parameters, tuple):
        return {name(parameters)}
    return {name(value) for value in parameters if name(value) != '.'}


def definition(form):
    if isinstance(form, list) and form and name(form[0]) == 'define':
        return name(form[1][0]) if isinstance(form[1], list) else name(form[1])
    return None


forms = []
while cursor < len(items):
    forms.append(parse())
globals = {definition(form) for form in forms} - {None}
assert len(globals) == 1344
references = defaultdict(list)
syntax = {'if', 'begin', 'and', 'or', 'when', 'unless', 'else', '=>'}


def visit_body(body, environment):
    environment = environment | ({definition(form) for form in body} - {None})
    for form in body:
        visit(form, environment)


def visit(value, environment, role='value'):
    if isinstance(value, tuple):
        word, offset = value
        literal = word.startswith(('"', '#')) or re.match(r'^[+-]?(?:\d|\.\d)', word)
        if not literal and word not in environment and word not in syntax:
            references[word].append({'line': source.count('\n', 0, offset) + 1,
                                     'offset': offset, 'role': role, 'owner': owner})
        return
    if not value:
        return
    head = name(value[0])
    if head in ('import', 'quote'):
        return
    if head in ('quasiquote', 'unquote', 'unquote-splicing'):
        raise ValueError('executable quasiquotation requires a dedicated audit')
    if head == 'define':
        if isinstance(value[1], list):
            visit_body(value[2:], environment | bound_names(value[1][1:]))
        else:
            visit_body(value[2:], environment)
    elif head == 'lambda':
        visit_body(value[2:], environment | bound_names(value[1]))
    elif head in ('let', 'let*', 'letrec', 'letrec*'):
        named = isinstance(value[1], tuple)
        bindings = value[2] if named else value[1]
        names = {name(binding[0]) for binding in bindings}
        local = environment | ({name(value[1])} if named else set())
        initial = local | names if head.startswith('letrec') else environment
        for binding in bindings:
            visit(binding[1], initial)
            if head == 'let*':
                initial = initial | {name(binding[0])}
        visit_body(value[3:] if named else value[2:], local | names)
    elif head == 'do':
        names = {name(binding[0]) for binding in value[1]}
        for binding in value[1]:
            visit(binding[1], environment)
            for step in binding[2:]:
                visit(step, environment | names)
        visit_body(value[2], environment | names)
        visit_body(value[3:], environment | names)
    elif head == 'cond':
        for clause in value[1:]:
            visit_body(clause, environment)
    elif head == 'case':
        visit(value[1], environment)
        for clause in value[2:]:
            visit_body(clause[1:], environment)
    elif head == 'set!':
        visit(value[1], environment, 'mutation')
        visit(value[2], environment)
    else:
        visit(value[0], environment, 'operator')
        for argument in value[1:]:
            visit(argument, environment)


for form in forms:
    owner = definition(form)
    visit(form, globals)
inventory = {word: occurrences for word, occurrences in sorted(references.items())}
(Path(__file__).with_name('references.json')).write_text(json.dumps(inventory, indent=2) + '\n')
for word, occurrences in inventory.items():
    print(word, len(occurrences), ','.join(str(line) for line in sorted({x['line'] for x in occurrences})))
