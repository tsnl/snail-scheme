(current-directory "/tmp/snail-strict-compiler-complete-20261014/build/compiler-output-chez-v2/boundary")
;; Scalar I/O providers for the exact typed io/read/write bodies under Chez.
;; This private scope holds native ports only. Datum traversal and formatting
;; stay in the shared Scheme modules; older reader controls retain their own
;; native input boundary and never instantiate this provider.

;; ---- One owner per issued ID and one synchronous pathname transfer ----

(define io-next-id 0)
(define io-path #f)
(define io-files '())
(define io-stdout (standard-output-port (buffer-mode block) #f))
(define (io-begin-path) (set! io-path '()))
(define (io-scalar-code value)
  (let ((code (if (char? value) (char->integer value) value)))
    (unless (and (integer? code) (exact? code) (<= 0 code #x10ffff)
                 (not (<= #xd800 code #xdfff)))
      (error 'scalar-io "invalid Unicode scalar"))
    code))
(define (io-path-character character)
  (unless io-path (error 'scalar-io "no pathname transfer is active"))
  (set! io-path (cons (integer->char (io-scalar-code character)) io-path)))
(define (io-take-path)
  (let ((path io-path))
    (set! io-path #f)
    (unless path (error 'scalar-io "no pathname transfer is active"))
    (list->string (reverse path))))
(define (io-reserve-id)
  (when (> io-next-id 2147483647) (error 'scalar-io "file port IDs exhausted"))
  (let ((id io-next-id)) (set! io-next-id (+ id 1)) id))
(define (io-open direction)
  (let* ((path (io-take-path)) (id (io-reserve-id))
         (port (if (eq? direction 'input)
                   (open-file-input-port path (file-options) (buffer-mode block) #f)
                   (open-file-output-port path (file-options no-fail) (buffer-mode block) #f))))
    ;; Newest IDs are first; reversing once during cleanup gives Rust's ascending
    ;; ID order, including when two independently buffered ports name one file.
    (set! io-files (cons (cons id (vector port direction #f)) io-files))
    id))
(define (io-entry id)
  (let ((entry (assv id io-files)))
    (unless entry (error 'scalar-io "unknown or closed file port"))
    entry))
(define (io-input id)
  (let ((entry (cdr (io-entry id))))
    (unless (eq? (vector-ref entry 1) 'input) (error 'scalar-io "expected an input port"))
    entry))
(define (io-output id)
  (if (= id -2) io-stdout
      (let ((entry (cdr (io-entry id))))
        (unless (eq? (vector-ref entry 1) 'output)
          (error 'scalar-io "expected an open output port"))
        (vector-ref entry 0))))

;; ---- Strict incremental UTF-8 preserves BOM and separate CR/LF scalars ----

(define (io-utf8-width first)
  (cond ((<= #xc2 first #xdf) 2) ((<= #xe0 first #xef) 3) ((<= #xf0 first #xf4) 4)
        (else (error 'scalar-io "invalid UTF-8"))))
(define (io-utf8-bytes port first width)
  (let ((bytes (make-bytevector width first)))
    (do ((index 1 (+ index 1))) ((= index width) bytes)
      (let ((byte (get-u8 port)))
        (when (eof-object? byte) (error 'scalar-io "incomplete UTF-8 scalar"))
        (bytevector-u8-set! bytes index byte)))))
(define (io-decode-utf8 bytes)
  (let* ((width (bytevector-length bytes)) (first (bytevector-u8-ref bytes 0))
         (mask (case width ((2) #x1f) ((3) #x0f) (else #x07))))
    (let loop ((index 1) (code (bitwise-and first mask)))
      (if (= index width)
          (begin
            (when (or (< code (case width ((2) #x80) ((3) #x800) (else #x10000)))
                      (> code #x10ffff) (<= #xd800 code #xdfff))
              (error 'scalar-io "invalid UTF-8"))
            code)
          (let ((byte (bytevector-u8-ref bytes index)))
            (unless (<= #x80 byte #xbf) (error 'scalar-io "invalid UTF-8"))
            (loop (+ index 1) (+ (* code 64) (- byte #x80))))))))
(define (io-read-scalar port)
  (let ((first (get-u8 port)))
    (cond ((eof-object? first) -1) ((< first #x80) first)
          (else (io-decode-utf8 (io-utf8-bytes port first (io-utf8-width first)))))))
(define (io-read id peek?)
  (let* ((entry (io-input id)) (old (vector-ref entry 2))
         (value (if old old (io-read-scalar (vector-ref entry 0)))))
    ;; #f is absent; both NUL (0) and EOF (-1) are cached values. A failed decode
    ;; publishes no cache, and an ordinary read consumes even a cached EOF.
    (vector-set! entry 2 (if peek? value #f))
    value))
(define (io-write id character)
  ;; Resolve the ID first, validate the scalar next, then check direction.
  ;; Rust's scalar writer has this order even for malformed raw ABI calls.
  (let* ((port (if (= id -2) io-stdout (vector-ref (cdr (io-entry id)) 0)))
         (code (io-scalar-code character)))
    (unless (output-port? port) (error 'scalar-io "expected an output port"))
    (put-bytevector port (string->utf8 (string (integer->char code))))
    (when (= id -2) (flush-output-port port))))

;; ---- Detached close preserves the first failure and releases its owner ----

(define (io-release port)
  (guard (first
          (else
           ;; Rust drops its failed buffered port, attempting its pending bytes
           ;; once more. Chez leaves a failed-close port open: retry once, then
           ;; discard failed output and close its descriptor before propagating.
           (guard (retry
                   (else
                    (guard (release (else (void)))
                      (when (output-port? port) (clear-output-port port))
                      (close-port port))))
             (close-port port))
           (raise first)))
    (close-port port)))
(define (io-close id)
  (unless (= id -2)
    (let ((entry (io-entry id)))
      (set! io-files (remq entry io-files))
      (io-release (vector-ref (cdr entry) 0)))))
(define (io-finish prior-error)
  (let ((owned (reverse io-files)))
    (set! io-files '())
    (set! io-path #f)
    (let loop ((owned owned) (failure prior-error))
      (if (null? owned) failure
          (let ((next (guard (error (else (or failure error)))
                        (io-release (vector-ref (cdar owned) 0)) failure)))
            (loop (cdr owned) next))))))

;; ---- Fixed scalar services, with no Datum or arbitrary-number operations ----

(define (io-scalar-service name)
  (cond
   ((string=? name "snail:io/path-begin") io-begin-path)
   ((string=? name "snail:io/path-character") io-path-character)
   ((string=? name "snail:io/file-exists") (lambda () (if (file-exists? (io-take-path)) 1 0)))
   ((string=? name "snail:io/delete-file") (lambda () (delete-file (io-take-path))))
   ((string=? name "snail:io/open-input-file") (lambda () (io-open 'input)))
   ((string=? name "snail:io/open-output-file") (lambda () (io-open 'output)))
   ((string=? name "snail:io/read-character") (lambda (id) (io-read id #f)))
   ((string=? name "snail:io/peek-character") (lambda (id) (io-read id #t)))
   ((string=? name "snail:io/write-character") io-write)
   ((string=? name "snail:io/check-output") (lambda (id) (io-output id) (void)))
   ((string=? name "snail:io/close") io-close)
   ((string=? name "snail:io/standard-output") (lambda () -2))
   (else (error 'scalar-io "unknown scalar export" name))))

;; Host-only scalar-provider diagnostics. Catching these conditions lets this
;; probe inspect ownership transitions; a failed guest invocation never resumes.

;; ---- Independent observations of raw service state ----

(define (boundary-check condition)
  (unless condition (error 'io-boundary "unexpected scalar-provider behavior")))
(define (boundary-message action)
  (guard (failure
          ((message-condition? failure) (condition-message failure))
          (else (raise failure)))
    (action)
    "unexpected normal return"))
(define (boundary-path text)
  (io-begin-path)
  (for-each io-path-character (string->list text)))
(define (boundary-open direction path)
  (boundary-path path) (io-open direction))
(define (boundary-bytes path)
  (call-with-port (open-file-input-port path (file-options) (buffer-mode block) #f)
    get-bytevector-all))

;; ---- Lookahead includes NUL and EOF, without text-transcoder normalization ----

(let ((id (boundary-open 'input "scalar-input")))
  (for-each
   (lambda (expected)
     (boundary-check (= (io-read id #t) expected))
     (boundary-check (= (io-read id #t) expected))
     (boundary-check (= (io-read id #f) expected)))
   '(0 65279 13 10 127 128 2047 2048 55295 57344 65535 65536 955 128512 1114111 -1 -1))
  (boundary-check (string=? (boundary-message (lambda () (io-output id)))
                            "expected an open output port"))
  (boundary-check (string=? (boundary-message (lambda () (io-write id 55296)))
                            "invalid Unicode scalar"))
  (boundary-check (string=? (boundary-message (lambda () (io-write id 65)))
                            "expected an output port"))
  (io-close id)
  (boundary-check (string=? (boundary-message (lambda () (io-read id #f)))
                            "unknown or closed file port")))
(boundary-check (string=? (boundary-message (lambda () (io-write -3 55296)))
                          "unknown or closed file port"))

;; ---- Failed opens consume paths and IDs; borrowed close consumes neither ----

(let ((before io-next-id))
  (boundary-path "does-not-exist")
  (boundary-message (lambda () (io-open 'input)))
  (boundary-check (= io-next-id (+ before 1)))
  (boundary-check (not io-path))
  (io-close -2) (io-close -2)
  (boundary-check (= io-next-id (+ before 1))))
(boundary-path "discarded")
(boundary-path "replacement")
(boundary-check (string=? (io-take-path) "replacement"))
(boundary-check (string=? (boundary-message io-take-path) "no pathname transfer is active"))

;; ---- Cleanup follows issue order and preserves the original failure ----

(let* ((first (boundary-open 'output "shared-output"))
       (second (boundary-open 'output "shared-output")))
  (io-write first 65) (io-write second 66)
  (boundary-check (not (io-finish #f)))
  (boundary-check (equal? (boundary-bytes "shared-output") #vu8(66))))
(let* ((failed (boundary-open 'output "/dev/full"))
       (port (vector-ref (cdr (io-entry failed)) 0))
       (descriptor (port-file-descriptor port))
       (pending (boundary-open 'output "cleanup-output"))
       (original (condition (make-error) (make-message-condition "first failure"))))
  (io-write failed 65) (io-write pending 67)
  (boundary-path "unfinished")
  (boundary-check (eq? (io-finish original) original))
  (boundary-check (and (null? io-files) (not io-path) (port-closed? port)))
  (boundary-check (not (file-exists? (string-append "/proc/self/fd/" (number->string descriptor)))))
  (boundary-check (equal? (boundary-bytes "cleanup-output") #vu8(67))))

;; ---- The last legal ID is issued once; exhaustion precedes file truncation ----

(set! io-next-id 2147483647)
(let ((last (boundary-open 'output "last-output")))
  (boundary-check (= last 2147483647)) (io-close last))
(boundary-path "shared-output")
(boundary-check (string=? (boundary-message (lambda () (io-open 'output))) "file port IDs exhausted"))
(boundary-check (and (= io-next-id 2147483648) (not io-path)))
(boundary-check (equal? (boundary-bytes "shared-output") #vu8(66)))
(boundary-check (not (io-finish #f)))
(display "PASS Chez scalar I/O boundary\n")
