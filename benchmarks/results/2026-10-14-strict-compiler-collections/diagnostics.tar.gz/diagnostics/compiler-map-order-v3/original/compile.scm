(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-compiler-complete-20261014/build/compiler-map-order-v3/original/program.scm" "/tmp/snail-strict-compiler-complete-20261014/build/compiler-map-order-v3/original/program.so"))
