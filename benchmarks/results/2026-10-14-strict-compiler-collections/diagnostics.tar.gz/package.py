from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path(__file__).resolve().parent.parent
report = root / 'benchmarks/results/2026-10-14-strict-compiler-collections'
report.mkdir()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
folders = sorted(path for path in (root / 'build').iterdir()
                 if path.is_dir() and path.name.startswith('compiler-'))
entries, omitted, records, partial_json = [], {}, [], []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command_records(value, filename, pointer=''):
    if isinstance(value, dict):
        if 'returncode' in value and 'command' in value:
            records.append(dict(file=filename, pointer=pointer, record=value))
            assert not value.get('executing_descendants'), (filename, pointer)
        assert value.get('status') != 'started', (filename, pointer)
        for key, item in value.items():
            command_records(item, filename, pointer + '/' + str(key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            command_records(item, filename, pointer + '/' + str(index))


for directory in folders:
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        name = str(path.relative_to(root / 'build'))
        if path.suffix in ('.wasm', '.o', '.so', '.a', '.ll', '.fasl') or path.name == 'collections-native':
            omitted[name] = dict(bytes=path.stat().st_size, sha256=digest(path))
            continue
        entries.append((path, 'diagnostics/' + name))
        if path.suffix == '.json':
            try:
                command_records(json.loads(path.read_text()), name)
            except json.JSONDecodeError:
                partial_json.append(name)

sources = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', head],
                                  cwd=root, text=True).splitlines()
sources += ['src/snail/' + name + '.sld' for name in
            ['strict', 'integer', 'rational', 'number', 'datum', 'read', 'write', 'io', 'bytes']]
sources += ['src/strict_io.rs', 'src/host.rs', 'src/strict_number.rs', 'src/strict_datum.rs',
            'src/native.c', 'src/precise-gc.c', 'Cargo.toml', 'Cargo.lock',
            'benchmarks/strict-suite/chez-number.scm', 'benchmarks/strict-suite/compiler-data.scm',
            'benchmarks/strict-suite/compiler-result.scm', 'tests/strict-write/output.scm',
            'scripts/test-strict-write', 'scripts/test-strict-integer', 'scripts/build-strict',
            'scripts/link-strict-runtime', 'scripts/build-native']
source_ids = {}
for name in sources:
    path = root / name
    source_ids[name] = digest(path)
    entries.append((path, 'sources/' + name))
entries.append((Path(__file__), 'package.py'))

archive = report / 'diagnostics.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as packed:
    for path, name in entries:
        packed.add(path, arcname=name, recursive=False)
inventory = {name: dict(bytes=path.stat().st_size, sha256=digest(path)) for path, name in entries}
with tarfile.open(archive) as packed:
    assert set(packed.getnames()) == set(inventory)
    for name, expected in inventory.items():
        data = packed.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
(report / 'archive.json').write_text(json.dumps(dict(sha256=digest(archive), bytes=archive.stat().st_size,
    files=inventory, omitted_executables_and_ir=omitted), indent=2) + '\n')

terminals = [
    ('map-v1', None, 'b37762', 1), ('map-v2', 55006, '2a8c44', 0),
    ('map-v3', 85919, 'e0515c', 0), ('original-v1', 94780, 'dda949', 0),
    ('original-v2', 1643, '3dd3b2', 0), ('typed-build-v2', 26245, 'dcc3e0', 1),
    ('typed-build-v3', 4126, '80dc12', 0), ('typed-targets-v3', 1327, 'bf2dfe', 0),
    ('collections-chez-v1', None, 'dea36c', 1), ('collections-chez-v2', None, 'c90ede', 0),
    ('collections-chez-v3', None, '997526', 0), ('io-host-close-v1', None, 'f7cc0b', 0),
    ('io-boundary-v1', None, 'ecfb2b', 1), ('io-boundary-v2', None, '61c3b8', 0),
    ('io-boundary-v3', 91428, '4f1231', 1), ('io-boundary-v4', 28108, 'e5ef71', 0),
    ('output-v1', 6326, 'd2c607', 0), ('output-v2', 94505, '7961ec', 0),
    ('format', None, '5d196a', 0), ('python-compile', None, '6b2552', 0),
    ('whitespace', None, 'b9ab29', 0), ('make-check', None, 'be2a36', 0),
    ('unchanged-reader-text', None, '78125b', 0), ('runtime-identity', None, 'f5e64f', 0)]
checks = dict(source_commit=head, intended_base='5be3958d38cb6115703bdb9508517bbb92fd08c9',
    writer_prerequisite='43c8929', local_writer_commit='52e8d01', complete_compiler_typed=False,
    clean_timing=False, source_forms_adapted=41, source_diagnostic_forms_adapted=3,
    original_collection_contracts=14, adapted_collection_contracts=22,
    host_failure_probes_per_target=3, targets=['Chez', 'raw linked Wasm', 'optimized linked Wasm', 'native64'],
    canonical_ordering_controls=dict(count=2000, assembly_lines=497, controls=3, typed_compiler=False),
    output_bridge=dict(datum_cases=68, graph_rows=8, depth=8192, terminal_failures=6,
                       malformed_utf8_terminal_cases=18, targets=['Chez using exact Scheme library bodies']),
    operation_inventory=dict(external_names=108, references=4580),
    source_sha256=source_ids, records=records, retained_partial_json=partial_json,
    terminal_tools=[dict(label=name, session_id=session, chunk=chunk, exit_code=code)
                    for name, session, chunk, code in terminals],
    all_owned_build_and_guest_handles_drained=True)
(report / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps(dict(report=str(report), source_commit=head, files=len(inventory),
                     command_records=len(records), archive_bytes=archive.stat().st_size,
                     partial_json=partial_json), indent=2))
