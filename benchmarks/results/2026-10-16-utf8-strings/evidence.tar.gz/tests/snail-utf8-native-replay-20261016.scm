(import (scheme base) (scheme file) (scheme read) (scheme process-context)
        (wasm-native llvm))
(define arguments (cdr (command-line)))
(parameterize ((current-native-imports
                '((("benchmark" "hide_i64") "hide_i64" (i64) (i64))
                  (("benchmark" "write_character") "write_character" (i32) ())
                  (("benchmark" "input_i64") "input_i64" (i32) (i64)))))
  (wasm->llvm-file (call-with-input-file (car arguments) read) (cadr arguments)))
