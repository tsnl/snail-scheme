#!/usr/bin/env python3
import hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
BASE=Path('/tmp/sfir-native-production-six-20261016/candidate')
ROOT=Path('/tmp/sfir-native-gc-hotpath-20261016')
record=json.loads((BASE/'timing/artifacts/gcbench/commands/native-build/record.json').read_text())
env=os.environ.copy()
for key,value in record['environment'].items():
 if value is None: env.pop(key,None)
 else: env[key]=value
# Build commands must use this task's wrapper and output directories.
env['RUSTC_WRAPPER']='/tmp/snail-native-gc-hotpath-20261016/wasm-native/scripts/rustc-native'
name=sys.argv[1]
command=sys.argv[2:]
directory=ROOT/'attempts'/name
directory.mkdir(parents=True,exist_ok=False)
env['SNAIL_PROCESS_RECORD']=str(directory/'process.json')
wrapped=[str(BASE/'toolchain/snail-native-supervisor'),'--command','1800000','--']+command
dependencies={part:hashlib.sha256(Path(part).read_bytes()).hexdigest() for part in command if part.startswith('/') and Path(part).is_file()}
source=Path('/tmp/snail-native-gc-hotpath-20261016/wasm-native/src')
runtime_before={str(source/name):hashlib.sha256((source/name).read_bytes()).hexdigest() for name in ('native.rs','native_gc.rs')}
start=time.monotonic()
with open(BASE/'timing/artifacts/gcbench/input.txt','rb') as inp,open(directory/'stdout.bin','wb') as out,open(directory/'stderr.bin','wb') as err:
 process=subprocess.run(wrapped,env=env,cwd=directory,stdin=inp,stdout=out,stderr=err)
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'command_dependencies_sha256':dependencies,'runtime_source_before_sha256':runtime_before,'resource_usage':{'scope':'supervisor and reaped descendant subtree; one supervisor per fresh capture process','max_rss_kib':usage.ru_maxrss,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,'minor_page_faults':usage.ru_minflt,'major_page_faults':usage.ru_majflt,'voluntary_context_switches':usage.ru_nvcsw,'involuntary_context_switches':usage.ru_nivcsw},'command':command,'supervisor_command':wrapped,'supervisor_returncode':process.returncode,'wall_seconds':time.monotonic()-start,'environment':env,'diagnostic_only':True,'timing_eligibility':'contended; no clean timing claim'}
for field in ('stdout','stderr'):
 raw=(directory/(field+'.bin')).read_bytes()
 result[field+'_sha256']=hashlib.sha256(raw).hexdigest()
 result[field]=raw.decode('utf-8',errors='replace')
if (directory/'process.json').exists(): result['process']=json.loads((directory/'process.json').read_text())
(directory/'capture.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result.get(key) for key in ('command','supervisor_returncode','wall_seconds','resource_usage','stdout','stderr','process')},indent=2))
if process.returncode: sys.exit(process.returncode)
