import collections,json,struct
from pathlib import Path
r=Path('/tmp/sfir-native-gc-hotpath-20261016/diagnostics')
main='/tmp/sfir-native-production-six-20261016/candidate/timing/artifacts/gcbench/program.native'
segments=[line.split() for line in (r/'production-pc.bin.maps').read_text().splitlines()]
base=next(int(x[0].split('-')[0],16) for x in segments if len(x)>5 and x[-1]==main and int(x[2],16)==0)
raw=(r/'production-pc.bin').read_bytes(); pcs=[x-base for x in struct.unpack('<'+'Q'*(len(raw)//8),raw)]
chain=[(0x5aff9,0x5b049),(0x5b3a2,0x5b3bd),(0x5b42e,0x5b47e),(0x5bfdb,0x5c038),(0x5c144,0x5c15f)]
publication=[(0x5b09a,0x5b0a8),(0x5b0f7,0x5b105),(0x5b136,0x5b144),(0x5b1f1,0x5b1ff),(0x5b281,0x5b294),(0x5b315,0x5b328),(0x5b61e,0x5b631),(0x5b6a7,0x5b6bf),(0x5b740,0x5b758),(0x5b96e,0x5b981),(0x5b9f2,0x5ba0a),(0x5ba8b,0x5baa3),(0x5bcf3,0x5bd06),(0x5bd7c,0x5bd8a),(0x5bf53,0x5bf66)]
counts={'root_chain':sum(any(a<=pc<b for a,b in chain) for pc in pcs),'temporary_root_publication':sum(any(a<=pc<b for a,b in publication) for pc in pcs)}
counts['other_guest_f17_f18']=sum(0x5aff0<=pc<0x5c190 for pc in pcs)-sum(counts.values())
output={'scope':'1ms sampled original immutable executable; manually classified instruction ranges in f.17/f.18, 2,671 samples total','limitation':'Instruction attribution is an approximate share, not a counterfactual measurement of removing roots. Local root slots also carry guest values. Unclassified guest functions sampled 1 time; no instruction-exact timing claim.','ranges':{'root_chain':[[hex(a),hex(b)] for a,b in chain],'temporary_root_publication':[[hex(a),hex(b)] for a,b in publication]},'samples':len(pcs),'counts':counts,'percentage':{k:100*v/len(pcs) for k,v in counts.items()}}
(r/'root-attribution.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output['percentage'],indent=2))
