#[unsafe(no_mangle)]
#[inline(always)]
pub extern "C" fn exported_add_one(value: u64) -> u64 {
    value + 1
}
