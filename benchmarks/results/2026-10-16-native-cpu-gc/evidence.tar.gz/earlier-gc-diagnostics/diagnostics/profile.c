#define _GNU_SOURCE
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
#include <unistd.h>

/* Throwaway, task-owned SIGPROF diagnostics. Never linked into a timed arm. */
static uintptr_t samples[1 << 20];
static volatile sig_atomic_t count;
static const char *output;
static void sample(int signal, siginfo_t *info, void *context) {
    (void)signal;
    (void)info;
    sig_atomic_t index = count;
    if (index < (sig_atomic_t)(sizeof(samples) / sizeof(samples[0]))) {
        samples[index] = ((ucontext_t *)context)->uc_mcontext.gregs[REG_RIP];
        count = index + 1;
    }
}
__attribute__((constructor)) static void start(void) {
    output = getenv("SNAIL_PROFILE_OUTPUT");
    if (!output) return;
    struct sigaction action = {0};
    action.sa_sigaction = sample;
    action.sa_flags = SA_SIGINFO | SA_RESTART;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGPROF, &action, NULL)) _exit(91);
    struct itimerval timer = {{0, 1000}, {0, 1000}};
    if (setitimer(ITIMER_PROF, &timer, NULL)) _exit(92);
}
__attribute__((destructor)) static void finish(void) {
    if (!output) return;
    struct itimerval timer = {0};
    setitimer(ITIMER_PROF, &timer, NULL);
    FILE *file = fopen(output, "wb");
    if (!file) _exit(93);
    fwrite(samples, sizeof(samples[0]), count, file);
    fclose(file);
    char path[4096];
    if (snprintf(path, sizeof(path), "%s.maps", output) >= sizeof(path)) _exit(94);
    file = fopen(path, "w");
    FILE *maps = fopen("/proc/self/maps", "r");
    if (!file || !maps) _exit(95);
    char line[8192];
    while (fgets(line, sizeof(line), maps)) fputs(line, file);
    fclose(maps);
    fclose(file);
}
