import bisect,collections,json,struct,subprocess,sys
from pathlib import Path
pc=Path(sys.argv[1]); main=sys.argv[2]
values=struct.unpack('<'+'Q'*(pc.stat().st_size//8),pc.read_bytes())
segments=[]
for line in Path(str(pc)+'.maps').read_text().splitlines():
 fields=line.split(); low,high=[int(x,16) for x in fields[0].split('-')]; offset=int(fields[2],16)
 segments.append((low,high,offset,fields[-1] if len(fields)>5 else 'anonymous'))
bases={path:low for low,high,offset,path in segments if offset==0}
syms=[]
for line in subprocess.check_output(['nm','-n','--defined-only',main],text=True).splitlines():
 fields=line.split()
 if len(fields)>=3 and fields[1] in ('t','T'): syms.append((int(fields[0],16),fields[2]))
starts=[a for a,n in syms]
counts=collections.Counter(); symbol_pcs=collections.defaultdict(collections.Counter)
for value in values:
 seg=next((s for s in segments if s[0]<=value<s[1]),None)
 if not seg: counts['unknown']+=1; continue
 offset=value-bases.get(seg[3],seg[0])
 if seg[3]==main:
  i=bisect.bisect_right(starts,offset)-1
  name=syms[i][1] if i>=0 else 'pre-text'
  counts[name]+=1; symbol_pcs[name][hex(offset)]+=1
 else: counts[seg[3]]+=1; symbol_pcs[seg[3]][hex(offset)]+=1
out={'sample_count':len(values),'interval_us':1000,'diagnostic_only':True,'symbols':[{'name':k,'samples':v,'percentage':100*v/len(values),'hot_pcs':symbol_pcs[k].most_common(25)} for k,v in counts.most_common()]}
pc.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print('samples',len(values))
for name,count in counts.most_common(20): print(f'{count:5} {100*count/len(values):5.1f}% {name}')
for k,v in symbol_pcs.items():
 if 'Collector8allocate' in k or 'Collector4mark' in k or k.endswith('libc.so.6'):
  print(k,v.most_common(25))
