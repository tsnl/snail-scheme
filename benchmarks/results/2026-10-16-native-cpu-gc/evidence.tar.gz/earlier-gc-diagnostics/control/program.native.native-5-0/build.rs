fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-hotpath-20261016/control/program.native.native-5-0/module.bc");
}
