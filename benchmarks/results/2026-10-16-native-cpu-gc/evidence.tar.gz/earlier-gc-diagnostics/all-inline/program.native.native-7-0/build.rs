fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-hotpath-20261016/all-inline/program.native.native-7-0/module.bc");
}
