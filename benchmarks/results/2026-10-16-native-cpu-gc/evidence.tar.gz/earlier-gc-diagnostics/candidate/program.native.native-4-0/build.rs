fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-hotpath-20261016/candidate/program.native.native-4-0/module.bc");
}
