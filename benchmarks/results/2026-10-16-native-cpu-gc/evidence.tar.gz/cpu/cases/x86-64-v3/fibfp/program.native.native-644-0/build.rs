fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-cpu-rootproof-evidence-20261016/cases/x86-64-v3/fibfp/program.native.native-644-0/module.bc");
}
