0000000000058c00 <f.5>:
   58c00:      	pushq	%rbp
   58c01:      	pushq	%r15
   58c03:      	pushq	%r14
   58c05:      	pushq	%r13
   58c07:      	pushq	%r12
   58c09:      	pushq	%rbx
   58c0a:      	subq	$0x78, %rsp
   58c0e:      	movq	%rsi, %rbx
   58c11:      	movq	$0x7, 0x10(%rsp)
   58c1a:      	movq	$0x0, 0x18(%rsp)
   58c23:      	movq	0x588e(%rip), %rcx      # 0x5e4b8 <native_roots.0>
   58c2a:      	movq	%rcx, 0x8(%rsp)
   58c2f:      	leaq	0x8(%rsp), %r13
   58c34:      	movq	%r13, 0x587d(%rip)      # 0x5e4b8 <native_roots.0>
   58c3b:      	movq	0x5856(%rip), %rax      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58c42:      	leaq	0x1(%rax), %rdx
   58c46:      	movq	0x5853(%rip), %rsi      # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   58c4d:      	cmpq	%rsi, %rdx
   58c50:      	cmovaq	%rdx, %rsi
   58c54:      	movq	%rdx, 0x583d(%rip)      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58c5b:      	movq	%rsi, 0x583e(%rip)      # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   58c62:      	movq	%rdi, 0x20(%rsp)
   58c67:      	vxorpd	%xmm0, %xmm0, %xmm0
   58c6b:      	vmovupd	%xmm0, 0x28(%rsp)
   58c71:      	movq	$0x0, 0x38(%rsp)
   58c7a:      	testq	%rbx, %rbx
   58c7d:      	js	0x591c7 <f.5+0x5c7>
   58c83:      	movq	%rbx, %rax
   58c86:      	shrq	$0x20, %rax
   58c8a:      	movq	%rax, 0x70(%rsp)
   58c8f:      	nop
   58c90:      	cmpq	$0x0, 0x70(%rsp)
   58c96:      	jne	0x5929c <f.5+0x69c>
   58c9c:      	testq	%rdi, %rdi
   58c9f:      	je	0x5929c <f.5+0x69c>
   58ca5:      	movl	%edi, %eax
   58ca7:      	andl	$0x1, %eax
   58caa:      	jne	0x5929c <f.5+0x69c>
   58cb0:      	movq	0x57f9(%rip), %r15      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58cb7:      	testq	%r15, %r15
   58cba:      	je	0x5929c <f.5+0x69c>
   58cc0:      	movq	(%rdi), %rax
   58cc3:      	testq	%rax, %rax
   58cc6:      	je	0x58d30 <f.5+0x130>
   58cc8:      	cmpq	$0x16, %rax
   58ccc:      	je	0x58d30 <f.5+0x130>
   58cce:      	movq	0x168(%r15), %rcx
   58cd5:      	shrq	$0x2, %rax
   58cd9:      	leaq	-0x1(%rax), %rdx
   58cdd:      	cmpq	%rcx, %rdx
   58ce0:      	jae	0x5929c <f.5+0x69c>
   58ce6:      	movq	0x160(%r15), %rdx
   58ced:      	movq	-0x8(%rdx,%rax,8), %rax
   58cf2:      	testq	%rax, %rax
   58cf5:      	je	0x58d30 <f.5+0x130>
   58cf7:      	cmpq	$0x16, %rax
   58cfb:      	je	0x58d30 <f.5+0x130>
   58cfd:      	nopl	(%rax)
   58d00:      	shrq	$0x2, %rax
   58d04:      	leaq	-0x1(%rax), %rsi
   58d08:      	cmpq	%rcx, %rsi
   58d0b:      	jae	0x5929c <f.5+0x69c>
   58d11:      	movq	-0x8(%rdx,%rax,8), %rax
   58d16:      	cmpq	$0x16, %rax
   58d1a:      	je	0x58d30 <f.5+0x130>
   58d1c:      	testq	%rax, %rax
   58d1f:      	jne	0x58d00 <f.5+0x100>
   58d21:      	nopw	%cs:(%rax,%rax)
   58d30:      	cmpq	$0x16, %rax
   58d34:      	jne	0x5929c <f.5+0x69c>
   58d3a:      	movq	%rdi, 0x28(%rsp)
   58d3f:      	movq	0x8(%rdi), %rax
   58d43:      	testq	%rax, %rax
   58d46:      	je	0x5929c <f.5+0x69c>
   58d4c:      	testb	$0x1, %al
   58d4e:      	jne	0x5929c <f.5+0x69c>
   58d54:      	cmpq	0x8(%rax), %rbx
   58d58:      	jae	0x5929c <f.5+0x69c>
   58d5e:      	cmpb	$0x0, 0x583b(%rip)      # 0x5e5a0 <g.4>
   58d65:      	je	0x5929c <f.5+0x69c>
   58d6b:      	cmpq	$0x0, 0x5825(%rip)      # 0x5e598 <g.3>
   58d73:      	je	0x5929c <f.5+0x69c>
   58d79:      	movq	0x10(%rax,%rbx,8), %rbp
   58d7e:      	movq	%rbp, 0x40(%rsp)
   58d83:      	movq	$0x5, 0x18(%rsp)
   58d8c:      	movq	0x178(%r15), %rcx
   58d93:      	movq	%r13, %rdx
   58d96:      	testq	%rcx, %rcx
   58d99:      	je	0x58dde <f.5+0x1de>
   58d9b:      	movq	0x170(%r15), %rax
   58da2:      	incq	%rax
   58da5:      	movq	%rax, 0x170(%r15)
   58dac:      	movq	%rax, %rdx
   58daf:      	orq	%rcx, %rdx
   58db2:      	shrq	$0x20, %rdx
   58db6:      	je	0x59170 <f.5+0x570>
   58dbc:      	xorl	%edx, %edx
   58dbe:      	divq	%rcx
   58dc1:      	movq	%rdx, %rax
   58dc4:      	movq	%r13, %rdx
   58dc7:      	testq	%rax, %rax
   58dca:      	jne	0x58dde <f.5+0x1de>
   58dcc:      	movq	%r15, %rdi
   58dcf:      	movq	%r13, %rsi
   58dd2:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58dd7:      	movq	0x56da(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   58dde:      	movl	$0x18, %esi
   58de3:      	movq	%r15, %rdi
   58de6:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58deb:      	testq	%rax, %rax
   58dee:      	je	0x592a1 <f.5+0x6a1>
   58df4:      	movq	%rax, %r15
   58df7:      	movq	$0x12, (%rax)
   58dfe:      	movl	$0x0, 0x8(%rax)
   58e05:      	movq	$0x0, 0x10(%rax)
   58e0d:      	movq	%rax, 0x30(%rsp)
   58e12:      	vcvtsi2sd	%rbx, %xmm15, %xmm0
   58e17:      	vmovsd	-0x5331f(%rip), %xmm1   # 0x5b00 <writev+0x5b00>
   58e1f:      	vmulsd	%xmm1, %xmm0, %xmm0
   58e23:      	vaddsd	-0x53373(%rip), %xmm0, %xmm2 # 0x5ab8 <writev+0x5ab8>
   58e2b:      	movq	0x28(%rsp), %rax
   58e30:      	testq	%rax, %rax
   58e33:      	je	0x5929c <f.5+0x69c>
   58e39:      	movq	0x18(%rax), %r14
   58e3d:      	vcvtsi2sd	%r14, %xmm15, %xmm0
   58e42:      	vmulsd	%xmm1, %xmm0, %xmm0
   58e46:      	vaddsd	-0x5336e(%rip), %xmm0, %xmm0 # 0x5ae0 <writev+0x5ae0>
   58e4e:      	movq	%r15, 0x40(%rsp)
   58e53:      	movq	%r15, 0x48(%rsp)
   58e58:      	movq	%rbp, 0x50(%rsp)
   58e5d:      	movq	$0x7, 0x18(%rsp)
   58e66:      	movq	0x5643(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58e6d:      	testq	%rdi, %rdi
   58e70:      	je	0x5929c <f.5+0x69c>
   58e76:      	vmovsd	%xmm0, 0x58(%rsp)
   58e7c:      	vmovsd	%xmm2, 0x60(%rsp)
   58e82:      	movq	0x178(%rdi), %rcx
   58e89:      	testq	%rcx, %rcx
   58e8c:      	je	0x58ecb <f.5+0x2cb>
   58e8e:      	movq	0x170(%rdi), %rax
   58e95:      	incq	%rax
   58e98:      	movq	%rax, 0x170(%rdi)
   58e9f:      	movq	%rax, %rdx
   58ea2:      	orq	%rcx, %rdx
   58ea5:      	shrq	$0x20, %rdx
   58ea9:      	je	0x59190 <f.5+0x590>
   58eaf:      	xorl	%edx, %edx
   58eb1:      	divq	%rcx
   58eb4:      	testq	%rdx, %rdx
   58eb7:      	jne	0x58ecb <f.5+0x2cb>
   58eb9:      	movq	0x55f8(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   58ec0:      	movq	%rdi, %r12
   58ec3:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58ec8:      	movq	%r12, %rdi
   58ecb:      	movq	0x55e6(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   58ed2:      	movl	$0x20, %esi
   58ed7:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58edc:      	testq	%rax, %rax
   58edf:      	je	0x592a1 <f.5+0x6a1>
   58ee5:      	movq	%rax, %r12
   58ee8:      	movq	$0xe, (%rax)
   58eef:      	vmovsd	0x60(%rsp), %xmm0
   58ef5:      	vmovsd	%xmm0, 0x8(%rax)
   58efa:      	vmovsd	0x58(%rsp), %xmm0
   58f00:      	vmovsd	%xmm0, 0x10(%rax)
   58f05:      	movq	%r15, 0x18(%rax)
   58f09:      	movq	%rax, 0x40(%rsp)
   58f0e:      	movq	%r15, 0x48(%rsp)
   58f13:      	movq	%rbp, 0x50(%rsp)
   58f18:      	movq	$0x7, 0x18(%rsp)
   58f21:      	movq	0x5588(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58f28:      	testq	%rdi, %rdi
   58f2b:      	je	0x5929c <f.5+0x69c>
   58f31:      	movq	0x178(%rdi), %rcx
   58f38:      	testq	%rcx, %rcx
   58f3b:      	je	0x58f8a <f.5+0x38a>
   58f3d:      	movq	0x170(%rdi), %rax
   58f44:      	incq	%rax
   58f47:      	movq	%rax, 0x170(%rdi)
   58f4e:      	movq	%rax, %rdx
   58f51:      	orq	%rcx, %rdx
   58f54:      	shrq	$0x20, %rdx
   58f58:      	je	0x591b0 <f.5+0x5b0>
   58f5e:      	xorl	%edx, %edx
   58f60:      	divq	%rcx
   58f63:      	testq	%rdx, %rdx
   58f66:      	jne	0x58f8a <f.5+0x38a>
   58f68:      	movq	0x5549(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   58f6f:      	movq	%rbx, 0x68(%rsp)
   58f74:      	movq	%r13, %rbx
   58f77:      	movq	%rdi, %r13
   58f7a:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58f7f:      	movq	%r13, %rdi
   58f82:      	movq	%rbx, %r13
   58f85:      	movq	0x68(%rsp), %rbx
   58f8a:      	movq	0x5527(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   58f91:      	movl	$0x10, %esi
   58f96:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58f9b:      	testq	%rax, %rax
   58f9e:      	je	0x592a1 <f.5+0x6a1>
   58fa4:      	movq	$0xa, (%rax)
   58fab:      	movq	%r12, 0x8(%rax)
   58faf:      	movq	%rax, 0x10(%r15)
   58fb3:      	movq	0x30(%rsp), %rax
   58fb8:      	testq	%rax, %rax
   58fbb:      	vmovsd	-0x534f3(%rip), %xmm3   # 0x5ad0 <writev+0x5ad0>
   58fc3:      	je	0x5929c <f.5+0x69c>
   58fc9:      	movl	$0x1, 0x8(%rax)
   58fd0:      	movq	0x30(%rsp), %rax
   58fd5:      	testq	%rax, %rax
   58fd8:      	vmovsd	0x60(%rsp), %xmm4
   58fde:      	vmovsd	0x58(%rsp), %xmm5
   58fe4:      	je	0x5929c <f.5+0x69c>
   58fea:      	cmpl	$0x0, 0x8(%rax)
   58fee:      	je	0x5929c <f.5+0x69c>
   58ff4:      	movq	0x10(%rax), %rax
   58ff8:      	testq	%rax, %rax
   58ffb:      	je	0x5929c <f.5+0x69c>
   59001:      	movq	0x8(%rax), %rcx
   59005:      	movq	%rbp, 0x40(%rsp)
   5900a:      	movq	%rcx, 0x48(%rsp)
   5900f:      	movq	$0x6, 0x18(%rsp)
   59018:      	xorl	%eax, %eax
   5901a:      	nopw	(%rax,%rax)
   59020:      	vmulsd	%xmm4, %xmm4, %xmm0
   59024:      	vmulsd	%xmm5, %xmm5, %xmm1
   59028:      	vaddsd	%xmm0, %xmm1, %xmm2
   5902c:      	vucomisd	%xmm3, %xmm2
   59030:      	ja	0x59087 <f.5+0x487>
   59032:      	testq	%rcx, %rcx
   59035:      	je	0x5929c <f.5+0x69c>
   5903b:      	movq	0x18(%rcx), %rdx
   5903f:      	testq	%rdx, %rdx
   59042:      	je	0x5929c <f.5+0x69c>
   59048:      	cmpl	$0x0, 0x8(%rdx)
   5904c:      	je	0x5929c <f.5+0x69c>
   59052:      	movq	0x10(%rdx), %rdx
   59056:      	testq	%rdx, %rdx
   59059:      	je	0x5929c <f.5+0x69c>
   5905f:      	vmulsd	%xmm4, %xmm5, %xmm2
   59063:      	vaddsd	%xmm2, %xmm2, %xmm2
   59067:      	vsubsd	%xmm1, %xmm0, %xmm0
   5906b:      	vaddsd	0x8(%rcx), %xmm0, %xmm4
   59070:      	vaddsd	0x10(%rcx), %xmm2, %xmm5
   59075:      	movq	0x8(%rdx), %rcx
   59079:      	incq	%rax
   5907c:      	cmpq	$0x40, %rax
   59080:      	jne	0x59020 <f.5+0x420>
   59082:      	movl	$0x40, %eax
   59087:      	movq	%r14, %rcx
   5908a:      	shrq	$0x20, %rcx
   5908e:      	jne	0x5929c <f.5+0x69c>
   59094:      	testq	%rbp, %rbp
   59097:      	je	0x5929c <f.5+0x69c>
   5909d:      	testb	$0x1, %bpl
   590a1:      	jne	0x5929c <f.5+0x69c>
   590a7:      	cmpq	0x8(%rbp), %r14
   590ab:      	jae	0x5929c <f.5+0x69c>
   590b1:      	movq	%rax, 0x10(%rbp,%r14,8)
   590b6:      	movq	0x28(%rsp), %rdi
   590bb:      	testq	%rdi, %rdi
   590be:      	je	0x5929c <f.5+0x69c>
   590c4:      	movq	0x20(%rdi), %rax
   590c8:      	testq	%rax, %rax
   590cb:      	je	0x5929c <f.5+0x69c>
   590d1:      	cmpl	$0x0, 0x8(%rax)
   590d5:      	je	0x5929c <f.5+0x69c>
   590db:      	cmpq	$0x0, 0x10(%rax)
   590e0:      	je	0x5929c <f.5+0x69c>
   590e6:      	xorl	%eax, %eax
   590e8:      	cmpq	$0x0, 0x10(%rsp)
   590ee:      	movq	%r13, %rcx
   590f1:      	leaq	0x53c0(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   590f8:      	cmoveq	%rdx, %rcx
   590fc:      	sete	%al
   590ff:      	addq	0x5392(%rip), %rax      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   59106:      	movq	0x5393(%rip), %rdx      # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   5910d:      	cmpq	%rdx, %rax
   59110:      	cmovaq	%rax, %rdx
   59114:      	movq	(%rcx), %rcx
   59117:      	movq	$0x7, 0x10(%rsp)
   59120:      	movq	$0x0, 0x18(%rsp)
   59129:      	movq	%rcx, 0x8(%rsp)
   5912e:      	movq	%r13, 0x5383(%rip)      # 0x5e4b8 <native_roots.0>
   59135:      	movq	%rax, 0x535c(%rip)      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   5913c:      	movq	%rdx, 0x535d(%rip)      # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   59143:      	movq	%rdi, 0x20(%rsp)
   59148:      	vxorpd	%xmm0, %xmm0, %xmm0
   5914c:      	leaq	0x28(%rsp), %rdx
   59151:      	vmovupd	%xmm0, (%rdx)
   59155:      	movq	$0x0, 0x10(%rdx)
   5915d:      	subq	$0x1, %rbx
   59161:      	jae	0x58c90 <f.5+0x90>
   59167:      	jmp	0x591c2 <f.5+0x5c2>
   59169:      	nopl	(%rax)
   59170:      	xorl	%edx, %edx
   59172:      	divl	%ecx
   59174:      	movl	%edx, %eax
   59176:      	movq	%r13, %rdx
   59179:      	testq	%rax, %rax
   5917c:      	jne	0x58dde <f.5+0x1de>
   59182:      	jmp	0x58dcc <f.5+0x1cc>
   59187:      	nopw	(%rax,%rax)
   59190:      	xorl	%edx, %edx
   59192:      	divl	%ecx
   59194:      	testq	%rdx, %rdx
   59197:      	jne	0x58ecb <f.5+0x2cb>
   5919d:      	jmp	0x58eb9 <f.5+0x2b9>
   591a2:      	nopw	%cs:(%rax,%rax)
   591b0:      	xorl	%edx, %edx
   591b2:      	divl	%ecx
   591b4:      	testq	%rdx, %rdx
   591b7:      	jne	0x58f8a <f.5+0x38a>
   591bd:      	jmp	0x58f68 <f.5+0x368>
   591c2:      	decq	%rax
   591c5:      	jmp	0x591d0 <f.5+0x5d0>
   591c7:      	testq	%rdi, %rdi
   591ca:      	je	0x5929c <f.5+0x69c>
   591d0:      	testb	$0x1, %dil
   591d4:      	jne	0x5929c <f.5+0x69c>
   591da:      	movq	0x52cf(%rip), %r8       # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   591e1:      	testq	%r8, %r8
   591e4:      	je	0x5929c <f.5+0x69c>
   591ea:      	movq	(%rdi), %rdx
   591ed:      	testq	%rdx, %rdx
   591f0:      	je	0x5924d <f.5+0x64d>
   591f2:      	cmpq	$0x16, %rdx
   591f6:      	je	0x5924d <f.5+0x64d>
   591f8:      	movq	0x168(%r8), %rsi
   591ff:      	shrq	$0x2, %rdx
   59203:      	leaq	-0x1(%rdx), %r9
   59207:      	cmpq	%rsi, %r9
   5920a:      	jae	0x5929c <f.5+0x69c>
   59210:      	movq	0x160(%r8), %r8
   59217:      	movq	-0x8(%r8,%rdx,8), %rdx
   5921c:      	testq	%rdx, %rdx
   5921f:      	je	0x5924d <f.5+0x64d>
   59221:      	cmpq	$0x16, %rdx
   59225:      	je	0x5924d <f.5+0x64d>
   59227:      	nopw	(%rax,%rax)
   59230:      	shrq	$0x2, %rdx
   59234:      	leaq	-0x1(%rdx), %r9
   59238:      	cmpq	%rsi, %r9
   5923b:      	jae	0x5929c <f.5+0x69c>
   5923d:      	movq	-0x8(%r8,%rdx,8), %rdx
   59242:      	cmpq	$0x16, %rdx
   59246:      	je	0x5924d <f.5+0x64d>
   59248:      	testq	%rdx, %rdx
   5924b:      	jne	0x59230 <f.5+0x630>
   5924d:      	cmpq	$0x16, %rdx
   59251:      	jne	0x5929c <f.5+0x69c>
   59253:      	movq	%rdi, 0x28(%rsp)
   59258:      	movq	0x10(%rdi), %rdx
   5925c:      	testq	%rdx, %rdx
   5925f:      	je	0x5929c <f.5+0x69c>
   59261:      	cmpl	$0x0, 0x8(%rdx)
   59265:      	je	0x5929c <f.5+0x69c>
   59267:      	movq	0x10(%rdx), %rdx
   5926b:      	testq	%rdx, %rdx
   5926e:      	je	0x5929c <f.5+0x69c>
   59270:      	movq	0x18(%rdi), %rsi
   59274:      	movq	0x10(%rdx), %rdi
   59278:      	movq	%rcx, 0x5239(%rip)      # 0x5e4b8 <native_roots.0>
   5927f:      	movq	%rax, 0x5212(%rip)      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   59286:      	decq	%rsi
   59289:      	addq	$0x78, %rsp
   5928d:      	popq	%rbx
   5928e:      	popq	%r12
   59290:      	popq	%r13
   59292:      	popq	%r14
   59294:      	popq	%r15
   59296:      	popq	%rbp
   59297:      	jmp	0x587e0 <f.4>
   5929c:      	callq	0x544d0 <native_trap>
   592a1:      	leaq	-0x50434(%rip), %rdi    # 0x8e74 <_RNvNtNtNtNtCsgEmfK2I1SDS_4core3num7flt2dec8strategy6dragon9POW5TO256+0x788>
   592a8:      	movl	$0x2f, %esi
   592ad:      	callq	0x55590 <_ZN13snail_runtime6native10fail_bytes17hebf443f7be983434E>
   592b2:      	int3
   592b3:      	int3
   592b4:      	int3
   592b5:      	int3
   592b6:      	int3
   592b7:      	int3
   592b8:      	int3
   592b9:      	int3
   592ba:      	int3
   592bb:      	int3
   592bc:      	int3
   592bd:      	int3
   592be:      	int3
   592bf:      	int3

