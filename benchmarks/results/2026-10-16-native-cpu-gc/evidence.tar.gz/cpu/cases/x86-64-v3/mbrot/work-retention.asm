0000000000057ef0 <f.2>:
   57ef0:      	pushq	%rbp
   57ef1:      	pushq	%r15
   57ef3:      	pushq	%r14
   57ef5:      	pushq	%r13
   57ef7:      	pushq	%r12
   57ef9:      	pushq	%rbx
   57efa:      	subq	$0x78, %rsp
   57efe:      	movq	%rsi, %rbx
   57f01:      	movq	$0x9, 0x18(%rsp)
   57f0a:      	movq	$0x0, 0x20(%rsp)
   57f13:      	movq	0x659e(%rip), %rcx      # 0x5e4b8 <native_roots.0>
   57f1a:      	movq	%rcx, 0x10(%rsp)
   57f1f:      	leaq	0x10(%rsp), %r9
   57f24:      	movq	0x656d(%rip), %rax      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   57f2b:      	leaq	0x1(%rax), %rsi
   57f2f:      	movq	0x656a(%rip), %r8       # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   57f36:      	cmpq	%r8, %rsi
   57f39:      	cmovaq	%rsi, %r8
   57f3d:      	movq	%r9, 0x6574(%rip)       # 0x5e4b8 <native_roots.0>
   57f44:      	movq	%rsi, 0x654d(%rip)      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   57f4b:      	movq	%r8, 0x654e(%rip)       # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   57f52:      	movq	%rdi, 0x28(%rsp)
   57f57:      	vxorps	%xmm0, %xmm0, %xmm0
   57f5b:      	vmovups	%ymm0, 0x30(%rsp)
   57f61:      	testq	%rdi, %rdi
   57f64:      	je	0x587ba <f.2+0x8ca>
   57f6a:      	movq	%rdi, 0x38(%rsp)
   57f6f:      	cmpq	%rbx, 0x8(%rdi)
   57f73:      	jle	0x58795 <f.2+0x8a5>
   57f79:      	nopl	(%rax)
   57f80:      	cmpb	$0x0, 0x6649(%rip)      # 0x5e5d0 <g.10>
   57f87:      	je	0x587ba <f.2+0x8ca>
   57f8d:      	cmpb	$0x0, 0x65fc(%rip)      # 0x5e590 <g.2>
   57f94:      	je	0x587ba <f.2+0x8ca>
   57f9a:      	cmpq	$0x0, 0x65e6(%rip)      # 0x5e588 <g.1>
   57fa2:      	je	0x587ba <f.2+0x8ca>
   57fa8:      	movq	0x6619(%rip), %rax      # 0x5e5c8 <g.9>
   57faf:      	movq	$0x5, 0x20(%rsp)
   57fb8:      	movq	%rax, 0x70(%rsp)
   57fbd:      	leaq	0x70(%rsp), %rax
   57fc2:      	cmpb	$0x0, 0x65f7(%rip)      # 0x5e5c0 <g.8>
   57fc9:      	je	0x587ba <f.2+0x8ca>
   57fcf:      	cmpq	$0x0, 0x65e1(%rip)      # 0x5e5b8 <g.7>
   57fd7:      	je	0x587ba <f.2+0x8ca>
   57fdd:      	movq	0x70(%rsp), %r14
   57fe2:      	movq	%r14, %rax
   57fe5:      	shrq	$0x20, %rax
   57fe9:      	jne	0x587ba <f.2+0x8ca>
   57fef:      	movq	$0x5, 0x20(%rsp)
   57ff8:      	movq	0x64b1(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   57fff:      	testq	%rdi, %rdi
   58002:      	je	0x587ba <f.2+0x8ca>
   58008:      	movq	0x178(%rdi), %rcx
   5800f:      	testq	%rcx, %rcx
   58012:      	je	0x58054 <f.2+0x164>
   58014:      	movq	0x170(%rdi), %rax
   5801b:      	incq	%rax
   5801e:      	movq	%rax, 0x170(%rdi)
   58025:      	movq	%rax, %rdx
   58028:      	orq	%rcx, %rdx
   5802b:      	shrq	$0x20, %rdx
   5802f:      	je	0x586c0 <f.2+0x7d0>
   58035:      	xorl	%edx, %edx
   58037:      	divq	%rcx
   5803a:      	testq	%rdx, %rdx
   5803d:      	jne	0x58054 <f.2+0x164>
   5803f:      	movq	0x6472(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   58046:      	movq	%rdi, %r15
   58049:      	vzeroupper
   5804c:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58051:      	movq	%r15, %rdi
   58054:      	movq	0x645d(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   5805b:      	movl	$0x18, %esi
   58060:      	vzeroupper
   58063:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58068:      	testq	%rax, %rax
   5806b:      	je	0x587c2 <f.2+0x8d2>
   58071:      	movq	%rax, %r15
   58074:      	movq	$0x3a, (%rax)
   5807b:      	movl	$0x0, 0x8(%rax)
   58082:      	movq	$0x0, 0x10(%rax)
   5808a:      	movq	%rax, 0x30(%rsp)
   5808f:      	leaq	0x44c2(%rip), %rax      # 0x5c558 <ref.7>
   58096:      	movq	%rax, 0x50(%rsp)
   5809b:      	movq	%r15, 0x58(%rsp)
   580a0:      	movq	$0x7, 0x20(%rsp)
   580a9:      	movq	0x6400(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   580b0:      	testq	%rdi, %rdi
   580b3:      	je	0x587ba <f.2+0x8ca>
   580b9:      	movq	0x178(%rdi), %rcx
   580c0:      	testq	%rcx, %rcx
   580c3:      	je	0x58102 <f.2+0x212>
   580c5:      	movq	0x170(%rdi), %rax
   580cc:      	incq	%rax
   580cf:      	movq	%rax, 0x170(%rdi)
   580d6:      	movq	%rax, %rdx
   580d9:      	orq	%rcx, %rdx
   580dc:      	shrq	$0x20, %rdx
   580e0:      	je	0x586e0 <f.2+0x7f0>
   580e6:      	xorl	%edx, %edx
   580e8:      	divq	%rcx
   580eb:      	testq	%rdx, %rdx
   580ee:      	jne	0x58102 <f.2+0x212>
   580f0:      	movq	0x63c1(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   580f7:      	movq	%rdi, %r12
   580fa:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   580ff:      	movq	%r12, %rdi
   58102:      	movq	0x63af(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   58109:      	movl	$0x10, %esi
   5810e:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58113:      	testq	%rax, %rax
   58116:      	je	0x587c2 <f.2+0x8d2>
   5811c:      	testb	$0x1, %al
   5811e:      	jne	0x587ba <f.2+0x8ca>
   58124:      	movq	$0x2b, (%rax)
   5812b:      	movq	$0x0, 0x8(%rax)
   58133:      	movq	%rax, 0x50(%rsp)
   58138:      	leaq	0x4419(%rip), %r12      # 0x5c558 <ref.7>
   5813f:      	movq	%r12, 0x58(%rsp)
   58144:      	movq	%r15, 0x60(%rsp)
   58149:      	movq	$0x8, 0x20(%rsp)
   58152:      	movl	$0x2f, %edi
   58157:      	movl	%r14d, %esi
   5815a:      	movq	%rax, %rdx
   5815d:      	callq	0x57d50 <native_array_new>
   58162:      	movq	%rax, 0x48(%rsp)
   58167:      	movq	0x30(%rsp), %rbp
   5816c:      	movq	%rbp, 0x50(%rsp)
   58171:      	movq	%rax, 0x58(%rsp)
   58176:      	movq	%r12, 0x60(%rsp)
   5817b:      	movq	%r15, 0x68(%rsp)
   58180:      	movq	$0x9, 0x20(%rsp)
   58189:      	movq	0x6320(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58190:      	testq	%rdi, %rdi
   58193:      	je	0x587ba <f.2+0x8ca>
   58199:      	movq	%rax, %r13
   5819c:      	movq	0x178(%rdi), %rcx
   581a3:      	testq	%rcx, %rcx
   581a6:      	je	0x581e5 <f.2+0x2f5>
   581a8:      	movq	0x170(%rdi), %rax
   581af:      	incq	%rax
   581b2:      	movq	%rax, 0x170(%rdi)
   581b9:      	movq	%rax, %rdx
   581bc:      	orq	%rcx, %rdx
   581bf:      	shrq	$0x20, %rdx
   581c3:      	je	0x58700 <f.2+0x810>
   581c9:      	xorl	%edx, %edx
   581cb:      	divq	%rcx
   581ce:      	testq	%rdx, %rdx
   581d1:      	jne	0x581e5 <f.2+0x2f5>
   581d3:      	movq	0x62de(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   581da:      	movq	%rdi, %r12
   581dd:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   581e2:      	movq	%r12, %rdi
   581e5:      	movq	0x62cc(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   581ec:      	movl	$0x20, %esi
   581f1:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   581f6:      	testq	%rax, %rax
   581f9:      	je	0x587c2 <f.2+0x8d2>
   581ff:      	movq	%rax, %r12
   58202:      	movq	$0x26, (%rax)
   58209:      	movq	%r14, 0x8(%rax)
   5820d:      	movq	%r13, 0x10(%rax)
   58211:      	movq	%rbp, 0x18(%rax)
   58215:      	movq	%rax, 0x50(%rsp)
   5821a:      	leaq	0x4337(%rip), %rax      # 0x5c558 <ref.7>
   58221:      	movq	%rax, 0x58(%rsp)
   58226:      	movq	%r15, 0x60(%rsp)
   5822b:      	movq	$0x8, 0x20(%rsp)
   58234:      	movq	0x6275(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   5823b:      	testq	%rdi, %rdi
   5823e:      	je	0x587ba <f.2+0x8ca>
   58244:      	movq	0x178(%rdi), %rcx
   5824b:      	testq	%rcx, %rcx
   5824e:      	je	0x5828d <f.2+0x39d>
   58250:      	movq	0x170(%rdi), %rax
   58257:      	incq	%rax
   5825a:      	movq	%rax, 0x170(%rdi)
   58261:      	movq	%rax, %rdx
   58264:      	orq	%rcx, %rdx
   58267:      	shrq	$0x20, %rdx
   5826b:      	je	0x58720 <f.2+0x830>
   58271:      	xorl	%edx, %edx
   58273:      	divq	%rcx
   58276:      	testq	%rdx, %rdx
   58279:      	jne	0x5828d <f.2+0x39d>
   5827b:      	movq	0x6236(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   58282:      	movq	%rdi, %r13
   58285:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   5828a:      	movq	%r13, %rdi
   5828d:      	movq	0x6224(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   58294:      	movl	$0x18, %esi
   58299:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   5829e:      	testq	%rax, %rax
   582a1:      	je	0x587c2 <f.2+0x8d2>
   582a7:      	movq	$0x32, (%rax)
   582ae:      	leaq	0x42a3(%rip), %rcx      # 0x5c558 <ref.7>
   582b5:      	movq	%rcx, 0x8(%rax)
   582b9:      	movq	%r12, 0x10(%rax)
   582bd:      	movq	%rax, 0x10(%r15)
   582c1:      	movq	0x30(%rsp), %rax
   582c6:      	testq	%rax, %rax
   582c9:      	je	0x587ba <f.2+0x8ca>
   582cf:      	movl	$0x1, 0x8(%rax)
   582d6:      	movq	0x30(%rsp), %rax
   582db:      	testq	%rax, %rax
   582de:      	je	0x587ba <f.2+0x8ca>
   582e4:      	cmpl	$0x0, 0x8(%rax)
   582e8:      	je	0x587ba <f.2+0x8ca>
   582ee:      	movq	0x10(%rax), %rax
   582f2:      	testq	%rax, %rax
   582f5:      	je	0x587ba <f.2+0x8ca>
   582fb:      	movq	%rax, 0x40(%rsp)
   58300:      	movq	0x8(%rax), %rcx
   58304:      	testq	%rcx, %rcx
   58307:      	je	0x587ba <f.2+0x8ca>
   5830d:      	leaq	-0x1(%r14), %r15
   58311:      	movq	0x10(%rax), %rdi
   58315:      	movq	0x8(%rcx), %rax
   58319:      	movq	%rdi, 0x50(%rsp)
   5831e:      	movq	$0x6, 0x20(%rsp)
   58327:      	movq	%r15, %rsi
   5832a:      	callq	*%rax
   5832c:      	subq	$0x8, %rsp
   58330:      	cmpb	$0x0, 0x6279(%rip)      # 0x5e5b0 <g.6>
   58337:      	je	0x587ba <f.2+0x8ca>
   5833d:      	cmpq	$0x0, 0x6263(%rip)      # 0x5e5a8 <g.5>
   58345:      	je	0x587ba <f.2+0x8ca>
   5834b:      	movq	$0x5, 0x20(%rsp)
   58354:      	movq	0x6155(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   5835b:      	testq	%rdi, %rdi
   5835e:      	je	0x587ba <f.2+0x8ca>
   58364:      	movq	0x178(%rdi), %rcx
   5836b:      	testq	%rcx, %rcx
   5836e:      	je	0x583ad <f.2+0x4bd>
   58370:      	movq	0x170(%rdi), %rax
   58377:      	incq	%rax
   5837a:      	movq	%rax, 0x170(%rdi)
   58381:      	movq	%rax, %rdx
   58384:      	orq	%rcx, %rdx
   58387:      	shrq	$0x20, %rdx
   5838b:      	je	0x58740 <f.2+0x850>
   58391:      	xorl	%edx, %edx
   58393:      	divq	%rcx
   58396:      	testq	%rdx, %rdx
   58399:      	jne	0x583ad <f.2+0x4bd>
   5839b:      	movq	0x6116(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   583a2:      	movq	%rdi, %r12
   583a5:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   583aa:      	movq	%r12, %rdi
   583ad:      	movq	0x6104(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   583b4:      	movl	$0x18, %esi
   583b9:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   583be:      	testq	%rax, %rax
   583c1:      	je	0x587c2 <f.2+0x8d2>
   583c7:      	movq	%rax, %r12
   583ca:      	movq	$0x3a, (%rax)
   583d1:      	movl	$0x0, 0x8(%rax)
   583d8:      	movq	$0x0, 0x10(%rax)
   583e0:      	movq	%rax, 0x30(%rsp)
   583e5:      	movq	0x48(%rsp), %rbp
   583ea:      	movq	%rax, 0x50(%rsp)
   583ef:      	movq	%rbp, 0x58(%rsp)
   583f4:      	leaq	0x413d(%rip), %rax      # 0x5c538 <ref.4>
   583fb:      	movq	%rax, 0x60(%rsp)
   58400:      	movq	%r12, 0x68(%rsp)
   58405:      	movq	$0x9, 0x20(%rsp)
   5840e:      	movq	0x609b(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58415:      	testq	%rdi, %rdi
   58418:      	je	0x587ba <f.2+0x8ca>
   5841e:      	movq	0x178(%rdi), %rcx
   58425:      	testq	%rcx, %rcx
   58428:      	je	0x58467 <f.2+0x577>
   5842a:      	movq	0x170(%rdi), %rax
   58431:      	incq	%rax
   58434:      	movq	%rax, 0x170(%rdi)
   5843b:      	movq	%rax, %rdx
   5843e:      	orq	%rcx, %rdx
   58441:      	shrq	$0x20, %rdx
   58445:      	je	0x58760 <f.2+0x870>
   5844b:      	xorl	%edx, %edx
   5844d:      	divq	%rcx
   58450:      	testq	%rdx, %rdx
   58453:      	jne	0x58467 <f.2+0x577>
   58455:      	movq	0x605c(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   5845c:      	movq	%rdi, %r13
   5845f:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58464:      	movq	%r13, %rdi
   58467:      	movq	0x604a(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   5846e:      	movl	$0x20, %esi
   58473:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58478:      	testq	%rax, %rax
   5847b:      	je	0x587c2 <f.2+0x8d2>
   58481:      	movq	%rax, %r13
   58484:      	movq	$0x1e, (%rax)
   5848b:      	movq	%rbp, 0x8(%rax)
   5848f:      	movq	%r14, 0x10(%rax)
   58493:      	movq	%r12, 0x18(%rax)
   58497:      	movq	%rax, 0x50(%rsp)
   5849c:      	leaq	0x4095(%rip), %rax      # 0x5c538 <ref.4>
   584a3:      	movq	%rax, 0x58(%rsp)
   584a8:      	movq	%r12, 0x60(%rsp)
   584ad:      	movq	$0x8, 0x20(%rsp)
   584b6:      	movq	0x5ff3(%rip), %rdi      # 0x5e4b0 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   584bd:      	testq	%rdi, %rdi
   584c0:      	je	0x587ba <f.2+0x8ca>
   584c6:      	movq	0x178(%rdi), %rcx
   584cd:      	testq	%rcx, %rcx
   584d0:      	je	0x5850f <f.2+0x61f>
   584d2:      	movq	0x170(%rdi), %rax
   584d9:      	incq	%rax
   584dc:      	movq	%rax, 0x170(%rdi)
   584e3:      	movq	%rax, %rdx
   584e6:      	orq	%rcx, %rdx
   584e9:      	shrq	$0x20, %rdx
   584ed:      	je	0x58780 <f.2+0x890>
   584f3:      	xorl	%edx, %edx
   584f5:      	divq	%rcx
   584f8:      	testq	%rdx, %rdx
   584fb:      	jne	0x5850f <f.2+0x61f>
   584fd:      	movq	0x5fb4(%rip), %rsi      # 0x5e4b8 <native_roots.0>
   58504:      	movq	%rdi, %r14
   58507:      	callq	0x55ba0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   5850c:      	movq	%r14, %rdi
   5850f:      	movq	0x5fa2(%rip), %rdx      # 0x5e4b8 <native_roots.0>
   58516:      	movl	$0x18, %esi
   5851b:      	callq	0x55a00 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58520:      	testq	%rax, %rax
   58523:      	je	0x587c2 <f.2+0x8d2>
   58529:      	movq	$0x32, (%rax)
   58530:      	leaq	0x4001(%rip), %rcx      # 0x5c538 <ref.4>
   58537:      	movq	%rcx, 0x8(%rax)
   5853b:      	movq	%r13, 0x10(%rax)
   5853f:      	movq	%rax, 0x10(%r12)
   58544:      	movq	0x30(%rsp), %rax
   58549:      	testq	%rax, %rax
   5854c:      	je	0x587ba <f.2+0x8ca>
   58552:      	movl	$0x1, 0x8(%rax)
   58559:      	movq	0x30(%rsp), %rax
   5855e:      	testq	%rax, %rax
   58561:      	je	0x587ba <f.2+0x8ca>
   58567:      	cmpl	$0x0, 0x8(%rax)
   5856b:      	je	0x587ba <f.2+0x8ca>
   58571:      	movq	0x10(%rax), %rax
   58575:      	testq	%rax, %rax
   58578:      	je	0x587ba <f.2+0x8ca>
   5857e:      	movq	%rax, 0x40(%rsp)
   58583:      	movq	0x8(%rax), %rcx
   58587:      	testq	%rcx, %rcx
   5858a:      	je	0x587ba <f.2+0x8ca>
   58590:      	movq	0x10(%rax), %rdi
   58594:      	movq	0x8(%rcx), %rax
   58598:      	movq	%rdi, 0x50(%rsp)
   5859d:      	movq	$0x6, 0x20(%rsp)
   585a6:      	movq	%r15, %rsi
   585a9:      	callq	*%rax
   585ab:      	subq	$0x8, %rsp
   585af:      	movq	0x48(%rsp), %rax
   585b4:      	testq	%rax, %rax
   585b7:      	je	0x587ba <f.2+0x8ca>
   585bd:      	testb	$0x1, %al
   585bf:      	jne	0x587ba <f.2+0x8ca>
   585c5:      	cmpq	$0x0, 0x8(%rax)
   585ca:      	je	0x587ba <f.2+0x8ca>
   585d0:      	movq	0x10(%rax), %rcx
   585d4:      	testq	%rcx, %rcx
   585d7:      	je	0x587ba <f.2+0x8ca>
   585dd:      	testb	$0x1, %cl
   585e0:      	jne	0x587ba <f.2+0x8ca>
   585e6:      	cmpq	$0x0, 0x8(%rcx)
   585eb:      	je	0x587ba <f.2+0x8ca>
   585f1:      	movq	0x38(%rsp), %rsi
   585f6:      	testq	%rsi, %rsi
   585f9:      	je	0x587ba <f.2+0x8ca>
   585ff:      	movq	0x10(%rsi), %rax
   58603:      	testq	%rax, %rax
   58606:      	je	0x587ba <f.2+0x8ca>
   5860c:      	cmpl	$0x0, 0x8(%rax)
   58610:      	je	0x587ba <f.2+0x8ca>
   58616:      	cmpq	$0x0, 0x10(%rax)
   5861b:      	je	0x587ba <f.2+0x8ca>
   58621:      	incq	%rbx
   58624:      	xorl	%eax, %eax
   58626:      	cmpq	$0x0, 0x18(%rsp)
   5862c:      	movq	0x10(%rcx), %rdx
   58630:      	sete	%al
   58633:      	leaq	0x10(%rsp), %rdi
   58638:      	movq	%rdi, %rcx
   5863b:      	leaq	0x5e76(%rip), %r8       # 0x5e4b8 <native_roots.0>
   58642:      	cmoveq	%r8, %rcx
   58646:      	addq	0x5e4b(%rip), %rax      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   5864d:      	movq	(%rcx), %rcx
   58650:      	movq	$0x9, 0x18(%rsp)
   58659:      	movq	$0x0, 0x20(%rsp)
   58662:      	movq	%rcx, 0x10(%rsp)
   58667:      	movq	%rdi, 0x5e4a(%rip)      # 0x5e4b8 <native_roots.0>
   5866e:      	movq	0x5e2b(%rip), %rdi      # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   58675:      	cmpq	%rdi, %rax
   58678:      	cmovaq	%rax, %rdi
   5867c:      	movq	%rax, 0x5e15(%rip)      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58683:      	movq	%rsi, 0x28(%rsp)
   58688:      	leaq	0x30(%rsp), %r8
   5868d:      	vxorps	%xmm0, %xmm0, %xmm0
   58691:      	vmovups	%ymm0, (%r8)
   58696:      	movq	%rdi, 0x5e03(%rip)      # 0x5e4a0 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   5869d:      	movq	%rsi, 0x38(%rsp)
   586a2:      	cmpq	%rbx, 0x8(%rsi)
   586a6:      	jg	0x57f80 <f.2+0x90>
   586ac:      	jmp	0x58792 <f.2+0x8a2>
   586b1:      	nopw	%cs:(%rax,%rax)
   586c0:      	xorl	%edx, %edx
   586c2:      	divl	%ecx
   586c4:      	testq	%rdx, %rdx
   586c7:      	jne	0x58054 <f.2+0x164>
   586cd:      	jmp	0x5803f <f.2+0x14f>
   586d2:      	nopw	%cs:(%rax,%rax)
   586e0:      	xorl	%edx, %edx
   586e2:      	divl	%ecx
   586e4:      	testq	%rdx, %rdx
   586e7:      	jne	0x58102 <f.2+0x212>
   586ed:      	jmp	0x580f0 <f.2+0x200>
   586f2:      	nopw	%cs:(%rax,%rax)
   58700:      	xorl	%edx, %edx
   58702:      	divl	%ecx
   58704:      	testq	%rdx, %rdx
   58707:      	jne	0x581e5 <f.2+0x2f5>
   5870d:      	jmp	0x581d3 <f.2+0x2e3>
   58712:      	nopw	%cs:(%rax,%rax)
   58720:      	xorl	%edx, %edx
   58722:      	divl	%ecx
   58724:      	testq	%rdx, %rdx
   58727:      	jne	0x5828d <f.2+0x39d>
   5872d:      	jmp	0x5827b <f.2+0x38b>
   58732:      	nopw	%cs:(%rax,%rax)
   58740:      	xorl	%edx, %edx
   58742:      	divl	%ecx
   58744:      	testq	%rdx, %rdx
   58747:      	jne	0x583ad <f.2+0x4bd>
   5874d:      	jmp	0x5839b <f.2+0x4ab>
   58752:      	nopw	%cs:(%rax,%rax)
   58760:      	xorl	%edx, %edx
   58762:      	divl	%ecx
   58764:      	testq	%rdx, %rdx
   58767:      	jne	0x58467 <f.2+0x577>
   5876d:      	jmp	0x58455 <f.2+0x565>
   58772:      	nopw	%cs:(%rax,%rax)
   58780:      	xorl	%edx, %edx
   58782:      	divl	%ecx
   58784:      	testq	%rdx, %rdx
   58787:      	jne	0x5850f <f.2+0x61f>
   5878d:      	jmp	0x584fd <f.2+0x60d>
   58792:      	decq	%rax
   58795:      	movq	%rcx, 0x5d1c(%rip)      # 0x5e4b8 <native_roots.0>
   5879c:      	movq	%rax, 0x5cf5(%rip)      # 0x5e498 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   587a3:      	movq	%rdx, %rax
   587a6:      	addq	$0x78, %rsp
   587aa:      	popq	%rbx
   587ab:      	popq	%r12
   587ad:      	popq	%r13
   587af:      	popq	%r14
   587b1:      	popq	%r15
   587b3:      	popq	%rbp
   587b4:      	vzeroupper
   587b7:      	retq	$0x8
   587ba:      	vzeroupper
   587bd:      	callq	0x544d0 <native_trap>
   587c2:      	leaq	-0x4f955(%rip), %rdi    # 0x8e74 <_RNvNtNtNtNtCsgEmfK2I1SDS_4core3num7flt2dec8strategy6dragon9POW5TO256+0x788>
   587c9:      	movl	$0x2f, %esi
   587ce:      	callq	0x55590 <_ZN13snail_runtime6native10fail_bytes17hebf443f7be983434E>
   587d3:      	int3
   587d4:      	int3
   587d5:      	int3
   587d6:      	int3
   587d7:      	int3
   587d8:      	int3
   587d9:      	int3
   587da:      	int3
   587db:      	int3
   587dc:      	int3
   587dd:      	int3
   587de:      	int3
   587df:      	int3

