   4bfb0:      	testq	%rax, %rax
   4bfb3:      	je	0x4c6c5 <_ZN76wasm_native_2c0bbf95a5b35c3daee372a4d5f35f8a607269c2b435df91790a2b81130b15743run17he69219367487dba5E+0x1585>
   4bfb9:      	movq	%rax, %r14
   4bfbc:      	movq	$0x36, (%rax)
   4bfc3:      	movq	$0x3e8, 0x8(%rax)       # imm = 0x3E8
   4bfcb:      	movq	%rbx, 0x10(%rax)
   4bfcf:      	movq	%rax, 0xa8(%rsp)
   4bfd7:      	movq	%r12, 0xb0(%rsp)
   4bfdf:      	movq	%rbx, 0xb8(%rsp)
