   4bfe0:      	testq	%rax, %rax
   4bfe3:      	je	0x4c6f5 <_ZN76wasm_native_58a5fd6939d81449e77b9c7edc43c9a4b446ec338b7f08ae19c0340918bc57973run17h02fd561b5b918269E+0x1585>
   4bfe9:      	movq	%rax, %r14
   4bfec:      	movq	$0x36, (%rax)
   4bff3:      	movq	$0x3e8, 0x8(%rax)       # imm = 0x3E8
   4bffb:      	movq	%rbx, 0x10(%rax)
   4bfff:      	movq	%rax, 0xa8(%rsp)
   4c007:      	movq	%r12, 0xb0(%rsp)
   4c00f:      	movq	%rbx, 0xb8(%rsp)
