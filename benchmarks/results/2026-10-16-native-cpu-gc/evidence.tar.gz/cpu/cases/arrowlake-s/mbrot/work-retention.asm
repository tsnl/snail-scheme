0000000000057f30 <f.2>:
   57f30:      	pushq	%rbp
   57f31:      	pushq	%r15
   57f33:      	pushq	%r14
   57f35:      	pushq	%r13
   57f37:      	pushq	%r12
   57f39:      	pushq	%rbx
   57f3a:      	subq	$0x78, %rsp
   57f3e:      	movq	$0x9, 0x18(%rsp)
   57f47:      	movq	$0x0, 0x20(%rsp)
   57f50:      	movq	0x6601(%rip), %rcx      # 0x5e558 <native_roots.0>
   57f57:      	movq	%rcx, 0x10(%rsp)
   57f5c:      	leaq	0x10(%rsp), %rax
   57f61:      	movq	%rax, 0x65f0(%rip)      # 0x5e558 <native_roots.0>
   57f68:      	movq	0x65c9(%rip), %rax      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   57f6f:      	leaq	0x1(%rax), %r8
   57f73:      	movq	%r8, 0x65be(%rip)       # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   57f7a:      	movq	%rsi, %rbx
   57f7d:      	movq	0x65bc(%rip), %rsi      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   57f84:      	cmpq	%rsi, %r8
   57f87:      	cmovaq	%r8, %rsi
   57f8b:      	movq	%rsi, 0x65ae(%rip)      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   57f92:      	movq	%rdi, 0x28(%rsp)
   57f97:      	vxorps	%xmm0, %xmm0, %xmm0
   57f9b:      	vmovups	%ymm0, 0x30(%rsp)
   57fa1:      	testq	%rdi, %rdi
   57fa4:      	je	0x587ea <f.2+0x8ba>
   57faa:      	movq	%rdi, 0x38(%rsp)
   57faf:      	cmpq	%rbx, 0x8(%rdi)
   57fb3:      	jle	0x587c5 <f.2+0x895>
   57fb9:      	nopl	(%rax)
   57fc0:      	cmpb	$0x0, 0x66a9(%rip)      # 0x5e670 <g.10>
   57fc7:      	je	0x587ea <f.2+0x8ba>
   57fcd:      	cmpb	$0x0, 0x665c(%rip)      # 0x5e630 <g.2>
   57fd4:      	je	0x587ea <f.2+0x8ba>
   57fda:      	cmpq	$0x0, 0x6646(%rip)      # 0x5e628 <g.1>
   57fe2:      	je	0x587ea <f.2+0x8ba>
   57fe8:      	movq	$0x5, 0x20(%rsp)
   57ff1:      	movq	0x6670(%rip), %rax      # 0x5e668 <g.9>
   57ff8:      	movq	%rax, 0x70(%rsp)
   57ffd:      	leaq	0x70(%rsp), %rax
   58002:      	cmpb	$0x0, 0x6657(%rip)      # 0x5e660 <g.8>
   58009:      	je	0x587ea <f.2+0x8ba>
   5800f:      	cmpq	$0x0, 0x6641(%rip)      # 0x5e658 <g.7>
   58017:      	je	0x587ea <f.2+0x8ba>
   5801d:      	movq	0x70(%rsp), %r14
   58022:      	movq	%r14, %rax
   58025:      	shrq	$0x20, %rax
   58029:      	jne	0x587ea <f.2+0x8ba>
   5802f:      	movq	$0x5, 0x20(%rsp)
   58038:      	movq	0x6511(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   5803f:      	testq	%rdi, %rdi
   58042:      	je	0x587ea <f.2+0x8ba>
   58048:      	movq	0x178(%rdi), %rcx
   5804f:      	testq	%rcx, %rcx
   58052:      	je	0x58094 <f.2+0x164>
   58054:      	movq	0x170(%rdi), %rax
   5805b:      	incq	%rax
   5805e:      	movq	%rax, 0x170(%rdi)
   58065:      	movq	%rax, %rdx
   58068:      	orq	%rcx, %rdx
   5806b:      	shrq	$0x20, %rdx
   5806f:      	je	0x586f0 <f.2+0x7c0>
   58075:      	xorl	%edx, %edx
   58077:      	divq	%rcx
   5807a:      	testq	%rdx, %rdx
   5807d:      	jne	0x58094 <f.2+0x164>
   5807f:      	movq	0x64d2(%rip), %rsi      # 0x5e558 <native_roots.0>
   58086:      	movq	%rdi, %r15
   58089:      	vzeroupper
   5808c:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58091:      	movq	%r15, %rdi
   58094:      	movq	0x64bd(%rip), %rdx      # 0x5e558 <native_roots.0>
   5809b:      	movl	$0x18, %esi
   580a0:      	vzeroupper
   580a3:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   580a8:      	testq	%rax, %rax
   580ab:      	je	0x587f2 <f.2+0x8c2>
   580b1:      	movq	%rax, %r15
   580b4:      	movq	$0x3a, (%rax)
   580bb:      	movl	$0x0, 0x8(%rax)
   580c2:      	movq	$0x0, 0x10(%rax)
   580ca:      	movq	%rax, 0x30(%rsp)
   580cf:      	leaq	0x4522(%rip), %rax      # 0x5c5f8 <ref.7>
   580d6:      	movq	%rax, 0x50(%rsp)
   580db:      	movq	%r15, 0x58(%rsp)
   580e0:      	movq	$0x7, 0x20(%rsp)
   580e9:      	movq	0x6460(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   580f0:      	testq	%rdi, %rdi
   580f3:      	je	0x587ea <f.2+0x8ba>
   580f9:      	movq	0x178(%rdi), %rcx
   58100:      	testq	%rcx, %rcx
   58103:      	je	0x58142 <f.2+0x212>
   58105:      	movq	0x170(%rdi), %rax
   5810c:      	incq	%rax
   5810f:      	movq	%rax, 0x170(%rdi)
   58116:      	movq	%rax, %rdx
   58119:      	orq	%rcx, %rdx
   5811c:      	shrq	$0x20, %rdx
   58120:      	je	0x58710 <f.2+0x7e0>
   58126:      	xorl	%edx, %edx
   58128:      	divq	%rcx
   5812b:      	testq	%rdx, %rdx
   5812e:      	jne	0x58142 <f.2+0x212>
   58130:      	movq	0x6421(%rip), %rsi      # 0x5e558 <native_roots.0>
   58137:      	movq	%rdi, %r12
   5813a:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   5813f:      	movq	%r12, %rdi
   58142:      	movq	0x640f(%rip), %rdx      # 0x5e558 <native_roots.0>
   58149:      	movl	$0x10, %esi
   5814e:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58153:      	testq	%rax, %rax
   58156:      	je	0x587f2 <f.2+0x8c2>
   5815c:      	testb	$0x1, %al
   5815e:      	jne	0x587ea <f.2+0x8ba>
   58164:      	movq	$0x2b, (%rax)
   5816b:      	movq	$0x0, 0x8(%rax)
   58173:      	movq	%rax, 0x50(%rsp)
   58178:      	leaq	0x4479(%rip), %r12      # 0x5c5f8 <ref.7>
   5817f:      	movq	%r12, 0x58(%rsp)
   58184:      	movq	%r15, 0x60(%rsp)
   58189:      	movq	$0x8, 0x20(%rsp)
   58192:      	movl	$0x2f, %edi
   58197:      	movl	%r14d, %esi
   5819a:      	movq	%rax, %rdx
   5819d:      	callq	0x57d90 <native_array_new>
   581a2:      	movq	%rax, 0x48(%rsp)
   581a7:      	movq	0x30(%rsp), %rbp
   581ac:      	movq	%rbp, 0x50(%rsp)
   581b1:      	movq	%rax, 0x58(%rsp)
   581b6:      	movq	%r12, 0x60(%rsp)
   581bb:      	movq	%r15, 0x68(%rsp)
   581c0:      	movq	$0x9, 0x20(%rsp)
   581c9:      	movq	0x6380(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   581d0:      	testq	%rdi, %rdi
   581d3:      	je	0x587ea <f.2+0x8ba>
   581d9:      	movq	%rax, %r13
   581dc:      	movq	0x178(%rdi), %rcx
   581e3:      	testq	%rcx, %rcx
   581e6:      	je	0x58225 <f.2+0x2f5>
   581e8:      	movq	0x170(%rdi), %rax
   581ef:      	incq	%rax
   581f2:      	movq	%rax, 0x170(%rdi)
   581f9:      	movq	%rax, %rdx
   581fc:      	orq	%rcx, %rdx
   581ff:      	shrq	$0x20, %rdx
   58203:      	je	0x58730 <f.2+0x800>
   58209:      	xorl	%edx, %edx
   5820b:      	divq	%rcx
   5820e:      	testq	%rdx, %rdx
   58211:      	jne	0x58225 <f.2+0x2f5>
   58213:      	movq	0x633e(%rip), %rsi      # 0x5e558 <native_roots.0>
   5821a:      	movq	%rdi, %r12
   5821d:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58222:      	movq	%r12, %rdi
   58225:      	movq	0x632c(%rip), %rdx      # 0x5e558 <native_roots.0>
   5822c:      	movl	$0x20, %esi
   58231:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58236:      	testq	%rax, %rax
   58239:      	je	0x587f2 <f.2+0x8c2>
   5823f:      	movq	%rax, %r12
   58242:      	movq	$0x26, (%rax)
   58249:      	movq	%r14, 0x8(%rax)
   5824d:      	movq	%r13, 0x10(%rax)
   58251:      	movq	%rbp, 0x18(%rax)
   58255:      	movq	%rax, 0x50(%rsp)
   5825a:      	leaq	0x4397(%rip), %rax      # 0x5c5f8 <ref.7>
   58261:      	movq	%rax, 0x58(%rsp)
   58266:      	movq	%r15, 0x60(%rsp)
   5826b:      	movq	$0x8, 0x20(%rsp)
   58274:      	movq	0x62d5(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   5827b:      	testq	%rdi, %rdi
   5827e:      	je	0x587ea <f.2+0x8ba>
   58284:      	movq	0x178(%rdi), %rcx
   5828b:      	testq	%rcx, %rcx
   5828e:      	je	0x582cd <f.2+0x39d>
   58290:      	movq	0x170(%rdi), %rax
   58297:      	incq	%rax
   5829a:      	movq	%rax, 0x170(%rdi)
   582a1:      	movq	%rax, %rdx
   582a4:      	orq	%rcx, %rdx
   582a7:      	shrq	$0x20, %rdx
   582ab:      	je	0x58750 <f.2+0x820>
   582b1:      	xorl	%edx, %edx
   582b3:      	divq	%rcx
   582b6:      	testq	%rdx, %rdx
   582b9:      	jne	0x582cd <f.2+0x39d>
   582bb:      	movq	0x6296(%rip), %rsi      # 0x5e558 <native_roots.0>
   582c2:      	movq	%rdi, %r13
   582c5:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   582ca:      	movq	%r13, %rdi
   582cd:      	movq	0x6284(%rip), %rdx      # 0x5e558 <native_roots.0>
   582d4:      	movl	$0x18, %esi
   582d9:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   582de:      	testq	%rax, %rax
   582e1:      	je	0x587f2 <f.2+0x8c2>
   582e7:      	movq	$0x32, (%rax)
   582ee:      	leaq	0x4303(%rip), %rcx      # 0x5c5f8 <ref.7>
   582f5:      	movq	%rcx, 0x8(%rax)
   582f9:      	movq	%r12, 0x10(%rax)
   582fd:      	movq	%rax, 0x10(%r15)
   58301:      	movq	0x30(%rsp), %rax
   58306:      	testq	%rax, %rax
   58309:      	je	0x587ea <f.2+0x8ba>
   5830f:      	movl	$0x1, 0x8(%rax)
   58316:      	movq	0x30(%rsp), %rax
   5831b:      	testq	%rax, %rax
   5831e:      	je	0x587ea <f.2+0x8ba>
   58324:      	cmpl	$0x0, 0x8(%rax)
   58328:      	je	0x587ea <f.2+0x8ba>
   5832e:      	movq	0x10(%rax), %rax
   58332:      	testq	%rax, %rax
   58335:      	je	0x587ea <f.2+0x8ba>
   5833b:      	movq	%rax, 0x40(%rsp)
   58340:      	movq	0x8(%rax), %rcx
   58344:      	testq	%rcx, %rcx
   58347:      	je	0x587ea <f.2+0x8ba>
   5834d:      	leaq	-0x1(%r14), %r15
   58351:      	movq	0x10(%rax), %rdi
   58355:      	movq	0x8(%rcx), %rax
   58359:      	movq	%rdi, 0x50(%rsp)
   5835e:      	movq	$0x6, 0x20(%rsp)
   58367:      	movq	%r15, %rsi
   5836a:      	callq	*%rax
   5836c:      	subq	$0x8, %rsp
   58370:      	cmpb	$0x0, 0x62d9(%rip)      # 0x5e650 <g.6>
   58377:      	je	0x587ea <f.2+0x8ba>
   5837d:      	cmpq	$0x0, 0x62c3(%rip)      # 0x5e648 <g.5>
   58385:      	je	0x587ea <f.2+0x8ba>
   5838b:      	movq	$0x5, 0x20(%rsp)
   58394:      	movq	0x61b5(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   5839b:      	testq	%rdi, %rdi
   5839e:      	je	0x587ea <f.2+0x8ba>
   583a4:      	movq	0x178(%rdi), %rcx
   583ab:      	testq	%rcx, %rcx
   583ae:      	je	0x583ed <f.2+0x4bd>
   583b0:      	movq	0x170(%rdi), %rax
   583b7:      	incq	%rax
   583ba:      	movq	%rax, 0x170(%rdi)
   583c1:      	movq	%rax, %rdx
   583c4:      	orq	%rcx, %rdx
   583c7:      	shrq	$0x20, %rdx
   583cb:      	je	0x58770 <f.2+0x840>
   583d1:      	xorl	%edx, %edx
   583d3:      	divq	%rcx
   583d6:      	testq	%rdx, %rdx
   583d9:      	jne	0x583ed <f.2+0x4bd>
   583db:      	movq	0x6176(%rip), %rsi      # 0x5e558 <native_roots.0>
   583e2:      	movq	%rdi, %r12
   583e5:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   583ea:      	movq	%r12, %rdi
   583ed:      	movq	0x6164(%rip), %rdx      # 0x5e558 <native_roots.0>
   583f4:      	movl	$0x18, %esi
   583f9:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   583fe:      	testq	%rax, %rax
   58401:      	je	0x587f2 <f.2+0x8c2>
   58407:      	movq	%rax, %r12
   5840a:      	movq	$0x3a, (%rax)
   58411:      	movl	$0x0, 0x8(%rax)
   58418:      	movq	$0x0, 0x10(%rax)
   58420:      	movq	%rax, 0x30(%rsp)
   58425:      	movq	0x48(%rsp), %rbp
   5842a:      	movq	%rax, 0x50(%rsp)
   5842f:      	movq	%rbp, 0x58(%rsp)
   58434:      	leaq	0x419d(%rip), %rax      # 0x5c5d8 <ref.4>
   5843b:      	movq	%rax, 0x60(%rsp)
   58440:      	movq	%r12, 0x68(%rsp)
   58445:      	movq	$0x9, 0x20(%rsp)
   5844e:      	movq	0x60fb(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58455:      	testq	%rdi, %rdi
   58458:      	je	0x587ea <f.2+0x8ba>
   5845e:      	movq	0x178(%rdi), %rcx
   58465:      	testq	%rcx, %rcx
   58468:      	je	0x584a7 <f.2+0x577>
   5846a:      	movq	0x170(%rdi), %rax
   58471:      	incq	%rax
   58474:      	movq	%rax, 0x170(%rdi)
   5847b:      	movq	%rax, %rdx
   5847e:      	orq	%rcx, %rdx
   58481:      	shrq	$0x20, %rdx
   58485:      	je	0x58790 <f.2+0x860>
   5848b:      	xorl	%edx, %edx
   5848d:      	divq	%rcx
   58490:      	testq	%rdx, %rdx
   58493:      	jne	0x584a7 <f.2+0x577>
   58495:      	movq	0x60bc(%rip), %rsi      # 0x5e558 <native_roots.0>
   5849c:      	movq	%rdi, %r13
   5849f:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   584a4:      	movq	%r13, %rdi
   584a7:      	movq	0x60aa(%rip), %rdx      # 0x5e558 <native_roots.0>
   584ae:      	movl	$0x20, %esi
   584b3:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   584b8:      	testq	%rax, %rax
   584bb:      	je	0x587f2 <f.2+0x8c2>
   584c1:      	movq	%rax, %r13
   584c4:      	movq	$0x1e, (%rax)
   584cb:      	movq	%rbp, 0x8(%rax)
   584cf:      	movq	%r14, 0x10(%rax)
   584d3:      	movq	%r12, 0x18(%rax)
   584d7:      	movq	%rax, 0x50(%rsp)
   584dc:      	leaq	0x40f5(%rip), %rax      # 0x5c5d8 <ref.4>
   584e3:      	movq	%rax, 0x58(%rsp)
   584e8:      	movq	%r12, 0x60(%rsp)
   584ed:      	movq	$0x8, 0x20(%rsp)
   584f6:      	movq	0x6053(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   584fd:      	testq	%rdi, %rdi
   58500:      	je	0x587ea <f.2+0x8ba>
   58506:      	movq	0x178(%rdi), %rcx
   5850d:      	testq	%rcx, %rcx
   58510:      	je	0x5854f <f.2+0x61f>
   58512:      	movq	0x170(%rdi), %rax
   58519:      	incq	%rax
   5851c:      	movq	%rax, 0x170(%rdi)
   58523:      	movq	%rax, %rdx
   58526:      	orq	%rcx, %rdx
   58529:      	shrq	$0x20, %rdx
   5852d:      	je	0x587b0 <f.2+0x880>
   58533:      	xorl	%edx, %edx
   58535:      	divq	%rcx
   58538:      	testq	%rdx, %rdx
   5853b:      	jne	0x5854f <f.2+0x61f>
   5853d:      	movq	0x6014(%rip), %rsi      # 0x5e558 <native_roots.0>
   58544:      	movq	%rdi, %r14
   58547:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   5854c:      	movq	%r14, %rdi
   5854f:      	movq	0x6002(%rip), %rdx      # 0x5e558 <native_roots.0>
   58556:      	movl	$0x18, %esi
   5855b:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58560:      	testq	%rax, %rax
   58563:      	je	0x587f2 <f.2+0x8c2>
   58569:      	movq	$0x32, (%rax)
   58570:      	leaq	0x4061(%rip), %rcx      # 0x5c5d8 <ref.4>
   58577:      	movq	%rcx, 0x8(%rax)
   5857b:      	movq	%r13, 0x10(%rax)
   5857f:      	movq	%rax, 0x10(%r12)
   58584:      	movq	0x30(%rsp), %rax
   58589:      	testq	%rax, %rax
   5858c:      	je	0x587ea <f.2+0x8ba>
   58592:      	movl	$0x1, 0x8(%rax)
   58599:      	movq	0x30(%rsp), %rax
   5859e:      	testq	%rax, %rax
   585a1:      	je	0x587ea <f.2+0x8ba>
   585a7:      	cmpl	$0x0, 0x8(%rax)
   585ab:      	je	0x587ea <f.2+0x8ba>
   585b1:      	movq	0x10(%rax), %rax
   585b5:      	testq	%rax, %rax
   585b8:      	je	0x587ea <f.2+0x8ba>
   585be:      	movq	%rax, 0x40(%rsp)
   585c3:      	movq	0x8(%rax), %rcx
   585c7:      	testq	%rcx, %rcx
   585ca:      	je	0x587ea <f.2+0x8ba>
   585d0:      	movq	0x10(%rax), %rdi
   585d4:      	movq	0x8(%rcx), %rax
   585d8:      	movq	%rdi, 0x50(%rsp)
   585dd:      	movq	$0x6, 0x20(%rsp)
   585e6:      	movq	%r15, %rsi
   585e9:      	callq	*%rax
   585eb:      	subq	$0x8, %rsp
   585ef:      	movq	0x48(%rsp), %rax
   585f4:      	testq	%rax, %rax
   585f7:      	je	0x587ea <f.2+0x8ba>
   585fd:      	testb	$0x1, %al
   585ff:      	jne	0x587ea <f.2+0x8ba>
   58605:      	cmpq	$0x0, 0x8(%rax)
   5860a:      	je	0x587ea <f.2+0x8ba>
   58610:      	movq	0x10(%rax), %rax
   58614:      	testq	%rax, %rax
   58617:      	je	0x587ea <f.2+0x8ba>
   5861d:      	testb	$0x1, %al
   5861f:      	jne	0x587ea <f.2+0x8ba>
   58625:      	cmpq	$0x0, 0x8(%rax)
   5862a:      	je	0x587ea <f.2+0x8ba>
   58630:      	movq	0x38(%rsp), %rsi
   58635:      	testq	%rsi, %rsi
   58638:      	je	0x587ea <f.2+0x8ba>
   5863e:      	movq	0x10(%rsi), %rcx
   58642:      	testq	%rcx, %rcx
   58645:      	je	0x587ea <f.2+0x8ba>
   5864b:      	cmpl	$0x0, 0x8(%rcx)
   5864f:      	je	0x587ea <f.2+0x8ba>
   58655:      	cmpq	$0x0, 0x10(%rcx)
   5865a:      	je	0x587ea <f.2+0x8ba>
   58660:      	movq	0x10(%rax), %rdx
   58664:      	incq	%rbx
   58667:      	xorl	%eax, %eax
   58669:      	cmpq	$0x0, 0x18(%rsp)
   5866f:      	sete	%al
   58672:      	leaq	0x10(%rsp), %rdi
   58677:      	movq	%rdi, %rcx
   5867a:      	leaq	0x5ed7(%rip), %r8       # 0x5e558 <native_roots.0>
   58681:      	cmoveq	%r8, %rcx
   58685:      	addq	0x5eac(%rip), %rax      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   5868c:      	movq	(%rcx), %rcx
   5868f:      	movq	$0x9, 0x18(%rsp)
   58698:      	movq	$0x0, 0x20(%rsp)
   586a1:      	movq	%rcx, 0x10(%rsp)
   586a6:      	movq	%rdi, 0x5eab(%rip)      # 0x5e558 <native_roots.0>
   586ad:      	movq	%rax, 0x5e84(%rip)      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   586b4:      	movq	0x5e85(%rip), %rdi      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   586bb:      	cmpq	%rdi, %rax
   586be:      	cmovaq	%rax, %rdi
   586c2:      	movq	%rdi, 0x5e77(%rip)      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   586c9:      	movq	%rsi, 0x28(%rsp)
   586ce:      	leaq	0x30(%rsp), %rdi
   586d3:      	vxorps	%xmm0, %xmm0, %xmm0
   586d7:      	vmovups	%ymm0, (%rdi)
   586db:      	movq	%rsi, 0x38(%rsp)
   586e0:      	cmpq	%rbx, 0x8(%rsi)
   586e4:      	jg	0x57fc0 <f.2+0x90>
   586ea:      	jmp	0x587c2 <f.2+0x892>
   586ef:      	nop
   586f0:      	xorl	%edx, %edx
   586f2:      	divl	%ecx
   586f4:      	testq	%rdx, %rdx
   586f7:      	jne	0x58094 <f.2+0x164>
   586fd:      	jmp	0x5807f <f.2+0x14f>
   58702:      	nopw	%cs:(%rax,%rax)
   58710:      	xorl	%edx, %edx
   58712:      	divl	%ecx
   58714:      	testq	%rdx, %rdx
   58717:      	jne	0x58142 <f.2+0x212>
   5871d:      	jmp	0x58130 <f.2+0x200>
   58722:      	nopw	%cs:(%rax,%rax)
   58730:      	xorl	%edx, %edx
   58732:      	divl	%ecx
   58734:      	testq	%rdx, %rdx
   58737:      	jne	0x58225 <f.2+0x2f5>
   5873d:      	jmp	0x58213 <f.2+0x2e3>
   58742:      	nopw	%cs:(%rax,%rax)
   58750:      	xorl	%edx, %edx
   58752:      	divl	%ecx
   58754:      	testq	%rdx, %rdx
   58757:      	jne	0x582cd <f.2+0x39d>
   5875d:      	jmp	0x582bb <f.2+0x38b>
   58762:      	nopw	%cs:(%rax,%rax)
   58770:      	xorl	%edx, %edx
   58772:      	divl	%ecx
   58774:      	testq	%rdx, %rdx
   58777:      	jne	0x583ed <f.2+0x4bd>
   5877d:      	jmp	0x583db <f.2+0x4ab>
   58782:      	nopw	%cs:(%rax,%rax)
   58790:      	xorl	%edx, %edx
   58792:      	divl	%ecx
   58794:      	testq	%rdx, %rdx
   58797:      	jne	0x584a7 <f.2+0x577>
   5879d:      	jmp	0x58495 <f.2+0x565>
   587a2:      	nopw	%cs:(%rax,%rax)
   587b0:      	xorl	%edx, %edx
   587b2:      	divl	%ecx
   587b4:      	testq	%rdx, %rdx
   587b7:      	jne	0x5854f <f.2+0x61f>
   587bd:      	jmp	0x5853d <f.2+0x60d>
   587c2:      	decq	%rax
   587c5:      	movq	%rcx, 0x5d8c(%rip)      # 0x5e558 <native_roots.0>
   587cc:      	movq	%rax, 0x5d65(%rip)      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   587d3:      	movq	%rdx, %rax
   587d6:      	addq	$0x78, %rsp
   587da:      	popq	%rbx
   587db:      	popq	%r12
   587dd:      	popq	%r13
   587df:      	popq	%r14
   587e1:      	popq	%r15
   587e3:      	popq	%rbp
   587e4:      	vzeroupper
   587e7:      	retq	$0x8
   587ea:      	vzeroupper
   587ed:      	callq	0x54500 <native_trap>
   587f2:      	leaq	-0x4f955(%rip), %rdi    # 0x8ea4 <_RNvNtNtNtNtCsgEmfK2I1SDS_4core3num7flt2dec8strategy6dragon9POW5TO256+0x788>
   587f9:      	movl	$0x2f, %esi
   587fe:      	callq	0x55560 <_ZN13snail_runtime6native10fail_bytes17hebf443f7be983434E>
   58803:      	int3
   58804:      	int3
   58805:      	int3
   58806:      	int3
   58807:      	int3
   58808:      	int3
   58809:      	int3
   5880a:      	int3
   5880b:      	int3
   5880c:      	int3
   5880d:      	int3
   5880e:      	int3
   5880f:      	int3

