0000000000058c30 <f.5>:
   58c30:      	pushq	%rbp
   58c31:      	pushq	%r15
   58c33:      	pushq	%r14
   58c35:      	pushq	%r13
   58c37:      	pushq	%r12
   58c39:      	pushq	%rbx
   58c3a:      	subq	$0x78, %rsp
   58c3e:      	movq	$0x7, 0x10(%rsp)
   58c47:      	movq	$0x0, 0x18(%rsp)
   58c50:      	movq	0x5901(%rip), %rcx      # 0x5e558 <native_roots.0>
   58c57:      	movq	%rcx, 0x8(%rsp)
   58c5c:      	leaq	0x8(%rsp), %r13
   58c61:      	movq	%r13, 0x58f0(%rip)      # 0x5e558 <native_roots.0>
   58c68:      	movq	%rsi, %r14
   58c6b:      	movq	0x58c6(%rip), %rax      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58c72:      	leaq	0x1(%rax), %rdx
   58c76:      	movq	%rdx, 0x58bb(%rip)      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58c7d:      	movq	0x58bc(%rip), %rsi      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   58c84:      	cmpq	%rsi, %rdx
   58c87:      	cmovaq	%rdx, %rsi
   58c8b:      	movq	%rsi, 0x58ae(%rip)      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   58c92:      	movq	%rdi, 0x20(%rsp)
   58c97:      	vxorpd	%xmm0, %xmm0, %xmm0
   58c9b:      	vmovupd	%xmm0, 0x28(%rsp)
   58ca1:      	movq	$0x0, 0x38(%rsp)
   58caa:      	testq	%r14, %r14
   58cad:      	js	0x59267 <f.5+0x637>
   58cb3:      	movq	%r14, %rax
   58cb6:      	shrq	$0x20, %rax
   58cba:      	movq	%rax, 0x70(%rsp)
   58cbf:      	nop
   58cc0:      	cmpq	$0x0, 0x70(%rsp)
   58cc6:      	jne	0x5933c <f.5+0x70c>
   58ccc:      	testq	%rdi, %rdi
   58ccf:      	je	0x5933c <f.5+0x70c>
   58cd5:      	movl	%edi, %eax
   58cd7:      	andl	$0x1, %eax
   58cda:      	jne	0x5933c <f.5+0x70c>
   58ce0:      	movq	0x5869(%rip), %r15      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58ce7:      	testq	%r15, %r15
   58cea:      	je	0x5933c <f.5+0x70c>
   58cf0:      	movq	(%rdi), %rax
   58cf3:      	testq	%rax, %rax
   58cf6:      	je	0x58d60 <f.5+0x130>
   58cf8:      	cmpq	$0x16, %rax
   58cfc:      	je	0x58d60 <f.5+0x130>
   58cfe:      	movq	0x168(%r15), %rcx
   58d05:      	shrq	$0x2, %rax
   58d09:      	leaq	-0x1(%rax), %rdx
   58d0d:      	cmpq	%rcx, %rdx
   58d10:      	jae	0x5933c <f.5+0x70c>
   58d16:      	movq	0x160(%r15), %rdx
   58d1d:      	movq	-0x8(%rdx,%rax,8), %rax
   58d22:      	testq	%rax, %rax
   58d25:      	je	0x58d60 <f.5+0x130>
   58d27:      	cmpq	$0x16, %rax
   58d2b:      	je	0x58d60 <f.5+0x130>
   58d2d:      	nopl	(%rax)
   58d30:      	shrq	$0x2, %rax
   58d34:      	leaq	-0x1(%rax), %rsi
   58d38:      	cmpq	%rcx, %rsi
   58d3b:      	jae	0x5933c <f.5+0x70c>
   58d41:      	movq	-0x8(%rdx,%rax,8), %rax
   58d46:      	cmpq	$0x16, %rax
   58d4a:      	je	0x58d60 <f.5+0x130>
   58d4c:      	testq	%rax, %rax
   58d4f:      	jne	0x58d30 <f.5+0x100>
   58d51:      	nopw	%cs:(%rax,%rax)
   58d60:      	cmpq	$0x16, %rax
   58d64:      	jne	0x5933c <f.5+0x70c>
   58d6a:      	movq	%rdi, 0x28(%rsp)
   58d6f:      	movq	0x8(%rdi), %rax
   58d73:      	testq	%rax, %rax
   58d76:      	je	0x5933c <f.5+0x70c>
   58d7c:      	testb	$0x1, %al
   58d7e:      	jne	0x5933c <f.5+0x70c>
   58d84:      	cmpq	0x8(%rax), %r14
   58d88:      	jae	0x5933c <f.5+0x70c>
   58d8e:      	cmpb	$0x0, 0x58ab(%rip)      # 0x5e640 <g.4>
   58d95:      	je	0x5933c <f.5+0x70c>
   58d9b:      	cmpq	$0x0, 0x5895(%rip)      # 0x5e638 <g.3>
   58da3:      	je	0x5933c <f.5+0x70c>
   58da9:      	movq	0x10(%rax,%r14,8), %rbp
   58dae:      	movq	%rbp, 0x40(%rsp)
   58db3:      	movq	$0x5, 0x18(%rsp)
   58dbc:      	movq	0x178(%r15), %rcx
   58dc3:      	movq	%r13, %rdx
   58dc6:      	testq	%rcx, %rcx
   58dc9:      	je	0x58e0e <f.5+0x1de>
   58dcb:      	movq	0x170(%r15), %rax
   58dd2:      	incq	%rax
   58dd5:      	movq	%rax, 0x170(%r15)
   58ddc:      	movq	%rax, %rdx
   58ddf:      	orq	%rcx, %rdx
   58de2:      	shrq	$0x20, %rdx
   58de6:      	je	0x59210 <f.5+0x5e0>
   58dec:      	xorl	%edx, %edx
   58dee:      	divq	%rcx
   58df1:      	movq	%rdx, %rax
   58df4:      	movq	%r13, %rdx
   58df7:      	testq	%rax, %rax
   58dfa:      	jne	0x58e0e <f.5+0x1de>
   58dfc:      	movq	%r15, %rdi
   58dff:      	movq	%r13, %rsi
   58e02:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58e07:      	movq	0x574a(%rip), %rdx      # 0x5e558 <native_roots.0>
   58e0e:      	movl	$0x18, %esi
   58e13:      	movq	%r15, %rdi
   58e16:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58e1b:      	testq	%rax, %rax
   58e1e:      	je	0x59341 <f.5+0x711>
   58e24:      	movq	%rax, %r15
   58e27:      	movq	$0x12, (%rax)
   58e2e:      	movl	$0x0, 0x8(%rax)
   58e35:      	movq	$0x0, 0x10(%rax)
   58e3d:      	movq	%rax, 0x30(%rsp)
   58e42:      	vcvtsi2sd	%r14, %xmm15, %xmm0
   58e47:      	vmovsd	-0x5331f(%rip), %xmm1   # 0x5b30 <writev+0x5b30>
   58e4f:      	vmulsd	%xmm1, %xmm0, %xmm0
   58e53:      	vaddsd	-0x53383(%rip), %xmm0, %xmm2 # 0x5ad8 <writev+0x5ad8>
   58e5b:      	movq	0x28(%rsp), %rax
   58e60:      	testq	%rax, %rax
   58e63:      	je	0x5933c <f.5+0x70c>
   58e69:      	movq	0x18(%rax), %rbx
   58e6d:      	vcvtsi2sd	%rbx, %xmm15, %xmm0
   58e72:      	vmulsd	%xmm1, %xmm0, %xmm0
   58e76:      	vaddsd	-0x5337e(%rip), %xmm0, %xmm0 # 0x5b00 <writev+0x5b00>
   58e7e:      	movq	%r15, 0x40(%rsp)
   58e83:      	movq	%r15, 0x48(%rsp)
   58e88:      	movq	%rbp, 0x50(%rsp)
   58e8d:      	movq	$0x7, 0x18(%rsp)
   58e96:      	movq	0x56b3(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58e9d:      	testq	%rdi, %rdi
   58ea0:      	je	0x5933c <f.5+0x70c>
   58ea6:      	vmovsd	%xmm0, 0x58(%rsp)
   58eac:      	vmovsd	%xmm2, 0x60(%rsp)
   58eb2:      	movq	0x178(%rdi), %rcx
   58eb9:      	testq	%rcx, %rcx
   58ebc:      	je	0x58efb <f.5+0x2cb>
   58ebe:      	movq	0x170(%rdi), %rax
   58ec5:      	incq	%rax
   58ec8:      	movq	%rax, 0x170(%rdi)
   58ecf:      	movq	%rax, %rdx
   58ed2:      	orq	%rcx, %rdx
   58ed5:      	shrq	$0x20, %rdx
   58ed9:      	je	0x59230 <f.5+0x600>
   58edf:      	xorl	%edx, %edx
   58ee1:      	divq	%rcx
   58ee4:      	testq	%rdx, %rdx
   58ee7:      	jne	0x58efb <f.5+0x2cb>
   58ee9:      	movq	0x5668(%rip), %rsi      # 0x5e558 <native_roots.0>
   58ef0:      	movq	%rdi, %r12
   58ef3:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58ef8:      	movq	%r12, %rdi
   58efb:      	movq	0x5656(%rip), %rdx      # 0x5e558 <native_roots.0>
   58f02:      	movl	$0x20, %esi
   58f07:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58f0c:      	testq	%rax, %rax
   58f0f:      	je	0x59341 <f.5+0x711>
   58f15:      	movq	%rax, %r12
   58f18:      	movq	$0xe, (%rax)
   58f1f:      	vmovsd	0x60(%rsp), %xmm0
   58f25:      	vmovsd	%xmm0, 0x8(%rax)
   58f2a:      	vmovsd	0x58(%rsp), %xmm0
   58f30:      	vmovsd	%xmm0, 0x10(%rax)
   58f35:      	movq	%r15, 0x18(%rax)
   58f39:      	movq	%rax, 0x40(%rsp)
   58f3e:      	movq	%r15, 0x48(%rsp)
   58f43:      	movq	%rbp, 0x50(%rsp)
   58f48:      	movq	$0x7, 0x18(%rsp)
   58f51:      	movq	0x55f8(%rip), %rdi      # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58f58:      	testq	%rdi, %rdi
   58f5b:      	je	0x5933c <f.5+0x70c>
   58f61:      	movq	0x178(%rdi), %rcx
   58f68:      	testq	%rcx, %rcx
   58f6b:      	je	0x58fba <f.5+0x38a>
   58f6d:      	movq	0x170(%rdi), %rax
   58f74:      	incq	%rax
   58f77:      	movq	%rax, 0x170(%rdi)
   58f7e:      	movq	%rax, %rdx
   58f81:      	orq	%rcx, %rdx
   58f84:      	shrq	$0x20, %rdx
   58f88:      	je	0x59250 <f.5+0x620>
   58f8e:      	xorl	%edx, %edx
   58f90:      	divq	%rcx
   58f93:      	testq	%rdx, %rdx
   58f96:      	jne	0x58fba <f.5+0x38a>
   58f98:      	movq	0x55b9(%rip), %rsi      # 0x5e558 <native_roots.0>
   58f9f:      	movq	%r14, 0x68(%rsp)
   58fa4:      	movq	%r13, %r14
   58fa7:      	movq	%rdi, %r13
   58faa:      	callq	0x55b70 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58faf:      	movq	%r13, %rdi
   58fb2:      	movq	%r14, %r13
   58fb5:      	movq	0x68(%rsp), %r14
   58fba:      	movq	0x5597(%rip), %rdx      # 0x5e558 <native_roots.0>
   58fc1:      	movl	$0x10, %esi
   58fc6:      	callq	0x559d0 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58fcb:      	testq	%rax, %rax
   58fce:      	je	0x59341 <f.5+0x711>
   58fd4:      	movq	$0xa, (%rax)
   58fdb:      	movq	%r12, 0x8(%rax)
   58fdf:      	movq	%rax, 0x10(%r15)
   58fe3:      	movq	0x30(%rsp), %rax
   58fe8:      	testq	%rax, %rax
   58feb:      	vmovsd	-0x53503(%rip), %xmm5   # 0x5af0 <writev+0x5af0>
   58ff3:      	je	0x5933c <f.5+0x70c>
   58ff9:      	movl	$0x1, 0x8(%rax)
   59000:      	movq	0x30(%rsp), %rax
   59005:      	testq	%rax, %rax
   59008:      	vmovsd	0x60(%rsp), %xmm3
   5900e:      	vmovsd	0x58(%rsp), %xmm4
   59014:      	je	0x5933c <f.5+0x70c>
   5901a:      	cmpl	$0x0, 0x8(%rax)
   5901e:      	je	0x5933c <f.5+0x70c>
   59024:      	movq	0x10(%rax), %rax
   59028:      	testq	%rax, %rax
   5902b:      	je	0x5933c <f.5+0x70c>
   59031:      	movq	0x8(%rax), %rcx
   59035:      	movq	%rbp, 0x40(%rsp)
   5903a:      	movq	%rcx, 0x48(%rsp)
   5903f:      	movq	$0x6, 0x18(%rsp)
   59048:      	xorl	%eax, %eax
   5904a:      	nopw	(%rax,%rax)
   59050:      	vmulsd	%xmm3, %xmm3, %xmm0
   59054:      	vmulsd	%xmm4, %xmm4, %xmm1
   59058:      	vaddsd	%xmm0, %xmm1, %xmm2
   5905c:      	vucomisd	%xmm5, %xmm2
   59060:      	ja	0x59124 <f.5+0x4f4>
   59066:      	testq	%rcx, %rcx
   59069:      	je	0x5933c <f.5+0x70c>
   5906f:      	movq	0x18(%rcx), %rdx
   59073:      	testq	%rdx, %rdx
   59076:      	je	0x5933c <f.5+0x70c>
   5907c:      	cmpl	$0x0, 0x8(%rdx)
   59080:      	je	0x5933c <f.5+0x70c>
   59086:      	movq	0x10(%rdx), %rdx
   5908a:      	testq	%rdx, %rdx
   5908d:      	je	0x5933c <f.5+0x70c>
   59093:      	vmulsd	%xmm3, %xmm4, %xmm2
   59097:      	vaddsd	%xmm2, %xmm2, %xmm2
   5909b:      	vsubsd	%xmm1, %xmm0, %xmm0
   5909f:      	vaddsd	0x8(%rcx), %xmm0, %xmm0
   590a4:      	vaddsd	0x10(%rcx), %xmm2, %xmm2
   590a9:      	vmulsd	%xmm0, %xmm0, %xmm1
   590ad:      	vmulsd	%xmm2, %xmm2, %xmm3
   590b1:      	vaddsd	%xmm1, %xmm3, %xmm4
   590b5:      	vucomisd	%xmm5, %xmm4
   590b9:      	ja	0x59120 <f.5+0x4f0>
   590bb:      	movq	0x8(%rdx), %rdx
   590bf:      	testq	%rdx, %rdx
   590c2:      	je	0x5933c <f.5+0x70c>
   590c8:      	movq	0x18(%rdx), %rcx
   590cc:      	testq	%rcx, %rcx
   590cf:      	je	0x5933c <f.5+0x70c>
   590d5:      	cmpl	$0x0, 0x8(%rcx)
   590d9:      	je	0x5933c <f.5+0x70c>
   590df:      	movq	0x10(%rcx), %rcx
   590e3:      	testq	%rcx, %rcx
   590e6:      	je	0x5933c <f.5+0x70c>
   590ec:      	movq	0x8(%rcx), %rcx
   590f0:      	vmulsd	%xmm0, %xmm2, %xmm0
   590f4:      	vaddsd	%xmm0, %xmm0, %xmm0
   590f8:      	vsubsd	%xmm3, %xmm1, %xmm1
   590fc:      	vaddsd	0x8(%rdx), %xmm1, %xmm3
   59101:      	vaddsd	0x10(%rdx), %xmm0, %xmm4
   59106:      	addq	$0x2, %rax
   5910a:      	cmpq	$0x40, %rax
   5910e:      	jne	0x59050 <f.5+0x420>
   59114:      	movl	$0x40, %eax
   59119:      	jmp	0x59124 <f.5+0x4f4>
   5911b:      	nopl	(%rax,%rax)
   59120:      	orq	$0x1, %rax
   59124:      	movq	%rbx, %rcx
   59127:      	shrq	$0x20, %rcx
   5912b:      	jne	0x5933c <f.5+0x70c>
   59131:      	testq	%rbp, %rbp
   59134:      	je	0x5933c <f.5+0x70c>
   5913a:      	testb	$0x1, %bpl
   5913e:      	jne	0x5933c <f.5+0x70c>
   59144:      	cmpq	0x8(%rbp), %rbx
   59148:      	jae	0x5933c <f.5+0x70c>
   5914e:      	movq	%rax, 0x10(%rbp,%rbx,8)
   59153:      	movq	0x28(%rsp), %rdi
   59158:      	testq	%rdi, %rdi
   5915b:      	je	0x5933c <f.5+0x70c>
   59161:      	movq	0x20(%rdi), %rax
   59165:      	testq	%rax, %rax
   59168:      	je	0x5933c <f.5+0x70c>
   5916e:      	cmpl	$0x0, 0x8(%rax)
   59172:      	je	0x5933c <f.5+0x70c>
   59178:      	cmpq	$0x0, 0x10(%rax)
   5917d:      	je	0x5933c <f.5+0x70c>
   59183:      	xorl	%eax, %eax
   59185:      	cmpq	$0x0, 0x10(%rsp)
   5918b:      	sete	%al
   5918e:      	movq	%r13, %rcx
   59191:      	leaq	0x53c0(%rip), %rdx      # 0x5e558 <native_roots.0>
   59198:      	cmoveq	%rdx, %rcx
   5919c:      	addq	0x5395(%rip), %rax      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   591a3:      	movq	0x5396(%rip), %rdx      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   591aa:      	cmpq	%rdx, %rax
   591ad:      	cmovaq	%rax, %rdx
   591b1:      	movq	(%rcx), %rcx
   591b4:      	movq	$0x7, 0x10(%rsp)
   591bd:      	movq	$0x0, 0x18(%rsp)
   591c6:      	movq	%rcx, 0x8(%rsp)
   591cb:      	movq	%r13, 0x5386(%rip)      # 0x5e558 <native_roots.0>
   591d2:      	movq	%rax, 0x535f(%rip)      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   591d9:      	movq	%rdx, 0x5360(%rip)      # 0x5e540 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   591e0:      	movq	%rdi, 0x20(%rsp)
   591e5:      	vxorpd	%xmm0, %xmm0, %xmm0
   591e9:      	leaq	0x28(%rsp), %rdx
   591ee:      	vmovupd	%xmm0, (%rdx)
   591f2:      	movq	$0x0, 0x10(%rdx)
   591fa:      	subq	$0x1, %r14
   591fe:      	jae	0x58cc0 <f.5+0x90>
   59204:      	jmp	0x59262 <f.5+0x632>
   59206:      	nopw	%cs:(%rax,%rax)
   59210:      	xorl	%edx, %edx
   59212:      	divl	%ecx
   59214:      	movl	%edx, %eax
   59216:      	movq	%r13, %rdx
   59219:      	testq	%rax, %rax
   5921c:      	jne	0x58e0e <f.5+0x1de>
   59222:      	jmp	0x58dfc <f.5+0x1cc>
   59227:      	nopw	(%rax,%rax)
   59230:      	xorl	%edx, %edx
   59232:      	divl	%ecx
   59234:      	testq	%rdx, %rdx
   59237:      	jne	0x58efb <f.5+0x2cb>
   5923d:      	jmp	0x58ee9 <f.5+0x2b9>
   59242:      	nopw	%cs:(%rax,%rax)
   59250:      	xorl	%edx, %edx
   59252:      	divl	%ecx
   59254:      	testq	%rdx, %rdx
   59257:      	jne	0x58fba <f.5+0x38a>
   5925d:      	jmp	0x58f98 <f.5+0x368>
   59262:      	decq	%rax
   59265:      	jmp	0x59270 <f.5+0x640>
   59267:      	testq	%rdi, %rdi
   5926a:      	je	0x5933c <f.5+0x70c>
   59270:      	testb	$0x1, %dil
   59274:      	jne	0x5933c <f.5+0x70c>
   5927a:      	movq	0x52cf(%rip), %r8       # 0x5e550 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   59281:      	testq	%r8, %r8
   59284:      	je	0x5933c <f.5+0x70c>
   5928a:      	movq	(%rdi), %rdx
   5928d:      	testq	%rdx, %rdx
   59290:      	je	0x592ed <f.5+0x6bd>
   59292:      	cmpq	$0x16, %rdx
   59296:      	je	0x592ed <f.5+0x6bd>
   59298:      	movq	0x168(%r8), %rsi
   5929f:      	shrq	$0x2, %rdx
   592a3:      	leaq	-0x1(%rdx), %r9
   592a7:      	cmpq	%rsi, %r9
   592aa:      	jae	0x5933c <f.5+0x70c>
   592b0:      	movq	0x160(%r8), %r8
   592b7:      	movq	-0x8(%r8,%rdx,8), %rdx
   592bc:      	testq	%rdx, %rdx
   592bf:      	je	0x592ed <f.5+0x6bd>
   592c1:      	cmpq	$0x16, %rdx
   592c5:      	je	0x592ed <f.5+0x6bd>
   592c7:      	nopw	(%rax,%rax)
   592d0:      	shrq	$0x2, %rdx
   592d4:      	leaq	-0x1(%rdx), %r9
   592d8:      	cmpq	%rsi, %r9
   592db:      	jae	0x5933c <f.5+0x70c>
   592dd:      	movq	-0x8(%r8,%rdx,8), %rdx
   592e2:      	cmpq	$0x16, %rdx
   592e6:      	je	0x592ed <f.5+0x6bd>
   592e8:      	testq	%rdx, %rdx
   592eb:      	jne	0x592d0 <f.5+0x6a0>
   592ed:      	cmpq	$0x16, %rdx
   592f1:      	jne	0x5933c <f.5+0x70c>
   592f3:      	movq	%rdi, 0x28(%rsp)
   592f8:      	movq	0x10(%rdi), %rdx
   592fc:      	testq	%rdx, %rdx
   592ff:      	je	0x5933c <f.5+0x70c>
   59301:      	cmpl	$0x0, 0x8(%rdx)
   59305:      	je	0x5933c <f.5+0x70c>
   59307:      	movq	0x10(%rdx), %rdx
   5930b:      	testq	%rdx, %rdx
   5930e:      	je	0x5933c <f.5+0x70c>
   59310:      	movq	0x18(%rdi), %rsi
   59314:      	movq	0x10(%rdx), %rdi
   59318:      	movq	%rcx, 0x5239(%rip)      # 0x5e558 <native_roots.0>
   5931f:      	movq	%rax, 0x5212(%rip)      # 0x5e538 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   59326:      	decq	%rsi
   59329:      	addq	$0x78, %rsp
   5932d:      	popq	%rbx
   5932e:      	popq	%r12
   59330:      	popq	%r13
   59332:      	popq	%r14
   59334:      	popq	%r15
   59336:      	popq	%rbp
   59337:      	jmp	0x58810 <f.4>
   5933c:      	callq	0x54500 <native_trap>
   59341:      	leaq	-0x504a4(%rip), %rdi    # 0x8ea4 <_RNvNtNtNtNtCsgEmfK2I1SDS_4core3num7flt2dec8strategy6dragon9POW5TO256+0x788>
   59348:      	movl	$0x2f, %esi
   5934d:      	callq	0x55560 <_ZN13snail_runtime6native10fail_bytes17hebf443f7be983434E>
   59352:      	int3
   59353:      	int3
   59354:      	int3
   59355:      	int3
   59356:      	int3
   59357:      	int3
   59358:      	int3
   59359:      	int3
   5935a:      	int3
   5935b:      	int3
   5935c:      	int3
   5935d:      	int3
   5935e:      	int3
   5935f:      	int3

