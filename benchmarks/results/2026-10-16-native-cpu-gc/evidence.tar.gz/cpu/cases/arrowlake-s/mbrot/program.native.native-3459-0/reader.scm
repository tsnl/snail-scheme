(module
 (rec
  (type $call40 (func (param (ref $environment186) f64 f64 i64) (result i64)))
  (type $type40 (struct (field (ref $environment186))))
  (type $environment186 (struct (field f64) (field f64) (field (ref $type41))))
  (type $type41 (struct (field (mut i32)) (field (mut (ref null $type40)))))
  (type $environment151 (struct (field (ref $type28)) (field (ref $type36)) (field i64) (field (ref $type36))))
  (type $type32 (struct (field (mut i32)) (field (mut (ref null $type25)))))
  (type $environment141 (struct (field (ref $type28)) (field i64) (field (ref $type36))))
  (type $call35 (func (param (ref struct) i64) (result i32)))
  (type $environment209 (struct (field i64) (field (ref $type28)) (field (ref $type36))))
  (type $type29 (array (mut i64)))
  (type $type28 (array (mut (ref $type29))))
  (type $type35 (struct (field (ref $call35)) (field (ref struct))))
  (type $environment99 (struct (field i64) (field (ref $type32))))
  (type $type36 (struct (field (mut i32)) (field (mut (ref null $type35)))))
  (type $call25 (func (param (ref null $environment99) i64 i64) (result i64)))
  (type $type30 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (ref $call25)) (field (ref null $environment99))))
 )
 (type $19 (func (param i64) (result i64)))
 (type $20 (func (param i32) (result i64)))
 (type $21 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global105 (mut (ref null $type25)) (ref.null none))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global156 (mut (ref null $type26)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type27)) (ref.null none))
 (global $ready123 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type30)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global88 (mut i64) (i64.const 0))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global89 (mut (ref null $type30)) (ref.null none))
 (global $ready89 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function99 (type $call25) (param $0 (ref null $environment99)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type36))
  (local $4 (ref $environment99))
  (local $5 (ref $type35))
  (local $6 (ref $type28))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment99 0
     (local.tee $4
      (ref.as_non_null
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready88)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready105)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global105)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global88)
     )
    )
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type36 1
     (local.tee $3
      (struct.new_default $type36)
     )
     (struct.new $type35
      (ref.func $function209)
      (struct.new $environment209
       (local.get $2)
       (local.tee $6
        (array.new $type28
         (array.new_fixed $type29 0)
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type36 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call35
      (struct.get $type35 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type36 1
          (local.get $3)
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
      (struct.get $type35 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready123)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global123)
     )
    )
    (struct.set $type36 1
     (local.tee $3
      (struct.new_default $type36)
     )
     (struct.new $type35
      (ref.func $function141)
      (struct.new $environment141
       (local.get $6)
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (struct.set $type36 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call35
      (struct.get $type35 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type36 1
          (local.get $3)
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
      (struct.get $type35 0
       (local.get $5)
      )
     )
    )
    (local.set $2
     (array.get $type29
      (array.get $type28
       (local.get $6)
       (i32.const 0)
      )
      (i32.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type32 0
       (struct.get $environment99 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type32 1
       (struct.get $environment99 1
        (local.get $4)
       )
      )
     )
    )
    (return_call $function99
     (local.get $4)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function106 (type $call25) (param $0 (ref null $environment99)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function141 (type $call35) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type36))
  (local $3 (ref $environment141))
  (local $4 (ref $type35))
  (local $5 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.set $5
     (i64.sub
      (struct.get $environment141 1
       (local.tee $3
        (ref.cast (ref $environment141)
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (struct.set $type36 1
     (local.tee $2
      (struct.new_default $type36)
     )
     (struct.new $type35
      (ref.func $function151)
      (struct.new $environment151
       (struct.get $environment141 0
        (local.get $3)
       )
       (struct.get $environment141 2
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type36 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call35
     (struct.get $type35 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type36 1
         (local.get $2)
        )
       )
      )
     )
     (local.get $5)
     (struct.get $type35 0
      (local.get $4)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function151 (type $call35) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment151))
  (local $3 (ref $type41))
  (local $4 (ref $type29))
  (local $5 i64)
  (local $6 i64)
  (local $7 f64)
  (local $8 f64)
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (array.get $type28
      (struct.get $environment151 0
       (local.tee $2
        (ref.cast (ref $environment151)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready156)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global156)
       )
      )
      (struct.set $type41 1
       (local.tee $3
        (struct.new_default $type41)
       )
       (struct.new $type40
        (struct.new $environment186
         (local.tee $7
          (f64.add
           (f64.mul
            (f64.convert_i64_s
             (local.get $1)
            )
            (f64.const 0.005)
           )
           (f64.const -1.0)
          )
         )
         (local.tee $8
          (f64.add
           (f64.mul
            (f64.convert_i64_s
             (local.tee $5
              (struct.get $environment151 2
               (local.get $2)
              )
             )
            )
            (f64.const 0.005)
           )
           (f64.const -0.5)
          )
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type41 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (call $function186
        (struct.get $type40 0
         (struct.get $type41 1
          (local.get $3)
         )
        )
        (local.get $7)
        (local.get $8)
        (i64.const 0)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $5)
      )
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment151 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type36 1
       (struct.get $environment151 3
        (local.get $2)
       )
      )
     )
    )
    (return_call $function151
     (local.get $2)
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (local.set $1
     (struct.get $environment151 2
      (local.tee $2
       (ref.cast (ref $environment151)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment151 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function141
     (struct.get $type35 1
      (struct.get $type36 1
       (struct.get $environment151 1
        (local.get $2)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function186 (type $call40) (param $0 (ref $environment186)) (param $1 f64) (param $2 f64) (param $3 i64) (result i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 (ref $type41))
  (if (result i64)
   (i64.eq
    (local.get $3)
    (i64.const 64)
   )
   (then
    (local.get $3)
   )
   (else
    (if (result i64)
     (f64.gt
      (f64.add
       (local.tee $4
        (f64.mul
         (local.get $1)
         (local.get $1)
        )
       )
       (local.tee $5
        (f64.mul
         (local.get $2)
         (local.get $2)
        )
       )
      )
      (f64.const 16.0)
     )
     (then
      (local.get $3)
     )
     (else
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.tee $6
          (struct.get $environment186 2
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function186
       (struct.get $type40 0
        (struct.get $type41 1
         (local.get $6)
        )
       )
       (f64.add
        (f64.sub
         (local.get $4)
         (local.get $5)
        )
        (struct.get $environment186 0
         (local.get $0)
        )
       )
       (f64.add
        (f64.mul
         (f64.mul
          (local.get $1)
          (local.get $2)
         )
         (f64.const 2.0)
        )
        (struct.get $environment186 1
         (local.get $0)
        )
       )
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function209 (type $call35) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment209))
  (local $3 (ref $type28))
  (local $4 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (array.set $type28
     (struct.get $environment209 1
      (local.tee $2
       (ref.cast (ref $environment209)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment209 0
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (array.new_default $type29
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment209 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type36 1
       (struct.get $environment209 2
        (local.get $2)
       )
      )
     )
    )
    (return_call $function209
     (local.get $2)
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type32))
  (local $2 (ref $type25))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready89)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global89)
   )
  )
  (struct.set $type32 1
   (local.tee $1
    (struct.new_default $type32)
   )
   (struct.new $type25
    (ref.func $function99)
    (struct.new $environment99
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type32 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type32 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call25
   (struct.get $type25 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type32 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type25 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global105
   (struct.new $type25
    (ref.func $function106)
    (ref.null none)
   )
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global156
   (struct.new_default $type26)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $global123
   (struct.new_default $type27)
  )
  (global.set $ready123
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type30)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global88
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (global.set $global89
   (struct.new_default $type30)
  )
  (global.set $ready89
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

