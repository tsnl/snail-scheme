fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-cpu-rootproof-evidence-20261016/cases/arrowlake-s/mbrot/program.native.native-3459-0/module.bc");
}
