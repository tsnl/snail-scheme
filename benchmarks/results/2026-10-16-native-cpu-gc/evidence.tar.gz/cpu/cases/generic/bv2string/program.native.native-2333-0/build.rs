fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-cpu-rootproof-evidence-20261016/cases/generic/bv2string/program.native.native-2333-0/module.bc");
}
