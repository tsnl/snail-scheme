(module
 (rec
  (type $environment156 (struct (field (ref $type27)) (field (ref $type27)) (field (ref $type34))))
  (type $call26 (func (param structref i64) (result (ref $type27))))
  (type $environment173 (struct (field i64) (field (ref $type35)) (field (ref $type34))))
  (type $type35 (struct (field (ref $type27))))
  (type $type27 (array (mut i64)))
  (type $type34 (struct (field (mut i32)) (field (mut (ref null $type26)))))
  (type $environment121 (struct (field i64) (field (ref $type31))))
  (type $environment102 (struct (field i64) (field (ref $type31))))
  (type $type31 (struct (field (mut i32)) (field (mut (ref null $type25)))))
  (type $call25 (func (param structref i64 i64) (result i64)))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type26 (struct (field (ref $call26)) (field structref)))
  (type $type25 (struct (field (ref $call25)) (field structref)))
 )
 (type $14 (func (param i64) (result i64)))
 (type $15 (func (param i32) (result i64)))
 (type $16 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global108 (mut (ref null $type25)) (ref.null none))
 (global $ready108 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type26)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type28)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global89 (mut (ref null $type29)) (ref.null none))
 (global $ready89 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type25)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global90 (mut i64) (i64.const 0))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global91 (mut i64) (i64.const 0))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global92 (mut (ref null $type29)) (ref.null none))
 (global $ready92 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function102 (type $call25) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type31))
  (local $4 (ref $type25))
  (local $5 (ref $environment102))
  (local $6 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment102 0
     (ref.cast (ref $environment102)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready90)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready90)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready108)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global108)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global90)
     )
    )
    (if
     (i32.eqz
      (global.get $ready90)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready91)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready108)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global108)
     )
    )
    (local.set $6
     (call $foreign0
      (global.get $global91)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global109)
     )
    )
    (struct.set $type31 1
     (local.tee $3
      (struct.new_default $type31)
     )
     (struct.new $type25
      (ref.func $function121)
      (struct.new $environment121
       (local.get $6)
       (local.get $3)
      )
     )
    )
    (struct.set $type31 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call25
      (struct.get $type25 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type31 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $2)
      (i64.const 0)
      (struct.get $type25 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment102 1
        (ref.cast (ref $environment102)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type31 1
       (struct.get $environment102 1
        (local.tee $5
         (ref.cast (ref $environment102)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (return_call $function102
     (local.get $5)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function110 (type $call25) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type31))
  (local $4 (ref $type25))
  (struct.set $type31 1
   (local.tee $3
    (struct.new_default $type31)
   )
   (struct.new $type25
    (ref.func $function121)
    (struct.new $environment121
     (local.get $2)
     (local.get $3)
    )
   )
  )
  (struct.set $type31 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type31 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call25
   (struct.get $type25 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type31 1
       (local.get $3)
      )
     )
    )
   )
   (local.get $1)
   (i64.const 0)
   (struct.get $type25 0
    (local.get $4)
   )
  )
 )
 (func $function121 (type $call25) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type34))
  (local $4 (ref $type26))
  (local $5 (ref $type27))
  (local $6 (ref $environment121))
  (if (result i64)
   (i64.gt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.set $2
     (struct.get $environment121 0
      (ref.cast (ref $environment121)
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready89)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global89)
     )
    )
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type26 1
      (global.get $global87)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type34 1
     (local.tee $3
      (struct.new_default $type34)
     )
     (struct.new $type26
      (ref.func $function173)
      (struct.new $environment173
       (local.get $2)
       (struct.new $type35
        (array.new_default $type27
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type34 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call_ref $call26
      (struct.get $type26 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type34 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type26 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready88)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global88)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.extend_i32_u
        (array.len
         (local.get $5)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type34 1
     (local.tee $3
      (struct.new_default $type34)
     )
     (struct.new $type26
      (ref.func $function156)
      (struct.new $environment156
       (local.get $5)
       (array.new_default $type27
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type34 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (i64.extend_i32_u
      (array.len
       (call_ref $call26
        (struct.get $type26 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type34 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
        (struct.get $type26 0
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment121 1
        (ref.cast (ref $environment121)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type31 1
       (struct.get $environment121 1
        (local.tee $6
         (ref.cast (ref $environment121)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (return_call $function121
     (local.get $6)
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function127 (type $call25) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function156 (type $call26) (param $0 structref) (param $1 i64) (result (ref $type27))
  (local $2 (ref $environment156))
  (local $3 (ref $type27))
  (local $4 i64)
  (if (result (ref $type27))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.get $environment156 1
     (ref.cast (ref $environment156)
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type27
     (struct.get $environment156 1
      (local.tee $2
       (ref.cast (ref $environment156)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type27
        (struct.get $environment156 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (struct.get $environment156 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type34 1
       (struct.get $environment156 2
        (local.get $2)
       )
      )
     )
    )
    (return_call $function156
     (local.get $2)
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function161 (type $call26) (param $0 structref) (param $1 i64) (result (ref $type27))
  (local $2 (ref $type34))
  (local $3 (ref $type26))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type34 1
   (local.tee $2
    (struct.new_default $type34)
   )
   (struct.new $type26
    (ref.func $function173)
    (struct.new $environment173
     (local.get $1)
     (struct.new $type35
      (array.new_default $type27
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type34 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type34 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call26
   (struct.get $type26 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type34 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type26 0
    (local.get $3)
   )
  )
 )
 (func $function173 (type $call26) (param $0 structref) (param $1 i64) (result (ref $type27))
  (local $2 (ref $environment173))
  (if (result (ref $type27))
   (i64.le_s
    (struct.get $environment173 0
     (local.tee $2
      (ref.cast (ref $environment173)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type35 0
     (struct.get $environment173 1
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type27
     (struct.get $type35 0
      (struct.get $environment173 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (struct.get $environment173 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type34 1
       (struct.get $environment173 2
        (local.get $2)
       )
      )
     )
    )
    (return_call $function173
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type31))
  (local $2 (ref $type25))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (struct.set $type31 1
   (local.tee $1
    (struct.new_default $type31)
   )
   (struct.new $type25
    (ref.func $function102)
    (struct.new $environment102
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type31 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type31 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call25
   (struct.get $type25 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type31 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type25 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global108
   (struct.new $type25
    (ref.func $function127)
    (ref.null none)
   )
  )
  (global.set $ready108
   (i32.const 1)
  )
  (global.set $global87
   (struct.new $type26
    (ref.func $function161)
    (ref.null none)
   )
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global88
   (struct.new_default $type28)
  )
  (global.set $ready88
   (i32.const 1)
  )
  (global.set $global89
   (struct.new_default $type29)
  )
  (global.set $ready89
   (i32.const 1)
  )
  (global.set $global109
   (struct.new $type25
    (ref.func $function110)
    (ref.null none)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global90
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready90
   (i32.const 1)
  )
  (global.set $global91
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global92
   (struct.new_default $type29)
  )
  (global.set $ready92
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

