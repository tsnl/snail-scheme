fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-cpu-rootproof-evidence-20261016/cases/generic/array1/program.native.native-1770-0/module.bc");
}
