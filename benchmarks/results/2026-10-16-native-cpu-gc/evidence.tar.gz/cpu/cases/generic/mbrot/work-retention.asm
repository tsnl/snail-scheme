0000000000057e60 <f.2>:
   57e60:      	pushq	%rbp
   57e61:      	pushq	%r15
   57e63:      	pushq	%r14
   57e65:      	pushq	%r13
   57e67:      	pushq	%r12
   57e69:      	pushq	%rbx
   57e6a:      	subq	$0x78, %rsp
   57e6e:      	movq	%rsi, %rbx
   57e71:      	movq	$0x9, 0x18(%rsp)
   57e7a:      	movq	$0x0, 0x20(%rsp)
   57e83:      	movq	0x65ae(%rip), %rcx      # 0x5e438 <native_roots.0>
   57e8a:      	movq	%rcx, 0x10(%rsp)
   57e8f:      	leaq	0x10(%rsp), %r9
   57e94:      	movq	0x657d(%rip), %rax      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   57e9b:      	leaq	0x1(%rax), %rsi
   57e9f:      	movq	0x657a(%rip), %r8       # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   57ea6:      	cmpq	%r8, %rsi
   57ea9:      	cmovaq	%rsi, %r8
   57ead:      	movq	%r9, 0x6584(%rip)       # 0x5e438 <native_roots.0>
   57eb4:      	movq	%rsi, 0x655d(%rip)      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   57ebb:      	movq	%r8, 0x655e(%rip)       # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   57ec2:      	movq	%rdi, 0x28(%rsp)
   57ec7:      	xorps	%xmm0, %xmm0
   57eca:      	movups	%xmm0, 0x30(%rsp)
   57ecf:      	movups	%xmm0, 0x40(%rsp)
   57ed4:      	testq	%rdi, %rdi
   57ed7:      	je	0x58717 <f.2+0x8b7>
   57edd:      	movq	%rdi, 0x38(%rsp)
   57ee2:      	cmpq	%rbx, 0x8(%rdi)
   57ee6:      	jle	0x586f5 <f.2+0x895>
   57eec:      	nopl	(%rax)
   57ef0:      	cmpb	$0x0, 0x6659(%rip)      # 0x5e550 <g.10>
   57ef7:      	je	0x58717 <f.2+0x8b7>
   57efd:      	cmpb	$0x0, 0x660c(%rip)      # 0x5e510 <g.2>
   57f04:      	je	0x58717 <f.2+0x8b7>
   57f0a:      	cmpq	$0x0, 0x65f6(%rip)      # 0x5e508 <g.1>
   57f12:      	je	0x58717 <f.2+0x8b7>
   57f18:      	movq	0x6629(%rip), %rax      # 0x5e548 <g.9>
   57f1f:      	movq	$0x5, 0x20(%rsp)
   57f28:      	movq	%rax, 0x70(%rsp)
   57f2d:      	leaq	0x70(%rsp), %rax
   57f32:      	cmpb	$0x0, 0x6607(%rip)      # 0x5e540 <g.8>
   57f39:      	je	0x58717 <f.2+0x8b7>
   57f3f:      	cmpq	$0x0, 0x65f1(%rip)      # 0x5e538 <g.7>
   57f47:      	je	0x58717 <f.2+0x8b7>
   57f4d:      	movq	0x70(%rsp), %r14
   57f52:      	movq	%r14, %rax
   57f55:      	shrq	$0x20, %rax
   57f59:      	jne	0x58717 <f.2+0x8b7>
   57f5f:      	movq	$0x5, 0x20(%rsp)
   57f68:      	movq	0x64c1(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   57f6f:      	testq	%rdi, %rdi
   57f72:      	je	0x58717 <f.2+0x8b7>
   57f78:      	movq	0x178(%rdi), %rcx
   57f7f:      	testq	%rcx, %rcx
   57f82:      	je	0x57fc1 <f.2+0x161>
   57f84:      	movq	0x170(%rdi), %rax
   57f8b:      	incq	%rax
   57f8e:      	movq	%rax, 0x170(%rdi)
   57f95:      	movq	%rax, %rdx
   57f98:      	orq	%rcx, %rdx
   57f9b:      	shrq	$0x20, %rdx
   57f9f:      	je	0x58620 <f.2+0x7c0>
   57fa5:      	xorl	%edx, %edx
   57fa7:      	divq	%rcx
   57faa:      	testq	%rdx, %rdx
   57fad:      	jne	0x57fc1 <f.2+0x161>
   57faf:      	movq	0x6482(%rip), %rsi      # 0x5e438 <native_roots.0>
   57fb6:      	movq	%rdi, %r15
   57fb9:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   57fbe:      	movq	%r15, %rdi
   57fc1:      	movq	0x6470(%rip), %rdx      # 0x5e438 <native_roots.0>
   57fc8:      	movl	$0x18, %esi
   57fcd:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   57fd2:      	testq	%rax, %rax
   57fd5:      	je	0x5871c <f.2+0x8bc>
   57fdb:      	movq	%rax, %r15
   57fde:      	movq	$0x3a, (%rax)
   57fe5:      	movl	$0x0, 0x8(%rax)
   57fec:      	movq	$0x0, 0x10(%rax)
   57ff4:      	movq	%rax, 0x30(%rsp)
   57ff9:      	leaq	0x44d8(%rip), %rax      # 0x5c4d8 <ref.7>
   58000:      	movq	%rax, 0x50(%rsp)
   58005:      	movq	%r15, 0x58(%rsp)
   5800a:      	movq	$0x7, 0x20(%rsp)
   58013:      	movq	0x6416(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   5801a:      	testq	%rdi, %rdi
   5801d:      	je	0x58717 <f.2+0x8b7>
   58023:      	movq	0x178(%rdi), %rcx
   5802a:      	testq	%rcx, %rcx
   5802d:      	je	0x5806c <f.2+0x20c>
   5802f:      	movq	0x170(%rdi), %rax
   58036:      	incq	%rax
   58039:      	movq	%rax, 0x170(%rdi)
   58040:      	movq	%rax, %rdx
   58043:      	orq	%rcx, %rdx
   58046:      	shrq	$0x20, %rdx
   5804a:      	je	0x58640 <f.2+0x7e0>
   58050:      	xorl	%edx, %edx
   58052:      	divq	%rcx
   58055:      	testq	%rdx, %rdx
   58058:      	jne	0x5806c <f.2+0x20c>
   5805a:      	movq	0x63d7(%rip), %rsi      # 0x5e438 <native_roots.0>
   58061:      	movq	%rdi, %r12
   58064:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58069:      	movq	%r12, %rdi
   5806c:      	movq	0x63c5(%rip), %rdx      # 0x5e438 <native_roots.0>
   58073:      	movl	$0x10, %esi
   58078:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   5807d:      	testq	%rax, %rax
   58080:      	je	0x5871c <f.2+0x8bc>
   58086:      	testb	$0x1, %al
   58088:      	jne	0x58717 <f.2+0x8b7>
   5808e:      	movq	$0x2b, (%rax)
   58095:      	movq	$0x0, 0x8(%rax)
   5809d:      	movq	%rax, 0x50(%rsp)
   580a2:      	leaq	0x442f(%rip), %r12      # 0x5c4d8 <ref.7>
   580a9:      	movq	%r12, 0x58(%rsp)
   580ae:      	movq	%r15, 0x60(%rsp)
   580b3:      	movq	$0x8, 0x20(%rsp)
   580bc:      	movl	$0x2f, %edi
   580c1:      	movl	%r14d, %esi
   580c4:      	movq	%rax, %rdx
   580c7:      	callq	0x57d20 <native_array_new>
   580cc:      	movq	%rax, 0x48(%rsp)
   580d1:      	movq	0x30(%rsp), %rbp
   580d6:      	movq	%rbp, 0x50(%rsp)
   580db:      	movq	%rax, 0x58(%rsp)
   580e0:      	movq	%r12, 0x60(%rsp)
   580e5:      	movq	%r15, 0x68(%rsp)
   580ea:      	movq	$0x9, 0x20(%rsp)
   580f3:      	movq	0x6336(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   580fa:      	testq	%rdi, %rdi
   580fd:      	je	0x58717 <f.2+0x8b7>
   58103:      	movq	%rax, %r13
   58106:      	movq	0x178(%rdi), %rcx
   5810d:      	testq	%rcx, %rcx
   58110:      	je	0x5814f <f.2+0x2ef>
   58112:      	movq	0x170(%rdi), %rax
   58119:      	incq	%rax
   5811c:      	movq	%rax, 0x170(%rdi)
   58123:      	movq	%rax, %rdx
   58126:      	orq	%rcx, %rdx
   58129:      	shrq	$0x20, %rdx
   5812d:      	je	0x58660 <f.2+0x800>
   58133:      	xorl	%edx, %edx
   58135:      	divq	%rcx
   58138:      	testq	%rdx, %rdx
   5813b:      	jne	0x5814f <f.2+0x2ef>
   5813d:      	movq	0x62f4(%rip), %rsi      # 0x5e438 <native_roots.0>
   58144:      	movq	%rdi, %r12
   58147:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   5814c:      	movq	%r12, %rdi
   5814f:      	movq	0x62e2(%rip), %rdx      # 0x5e438 <native_roots.0>
   58156:      	movl	$0x20, %esi
   5815b:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58160:      	testq	%rax, %rax
   58163:      	je	0x5871c <f.2+0x8bc>
   58169:      	movq	%rax, %r12
   5816c:      	movq	$0x26, (%rax)
   58173:      	movq	%r14, 0x8(%rax)
   58177:      	movq	%r13, 0x10(%rax)
   5817b:      	movq	%rbp, 0x18(%rax)
   5817f:      	movq	%rax, 0x50(%rsp)
   58184:      	leaq	0x434d(%rip), %rax      # 0x5c4d8 <ref.7>
   5818b:      	movq	%rax, 0x58(%rsp)
   58190:      	movq	%r15, 0x60(%rsp)
   58195:      	movq	$0x8, 0x20(%rsp)
   5819e:      	movq	0x628b(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   581a5:      	testq	%rdi, %rdi
   581a8:      	je	0x58717 <f.2+0x8b7>
   581ae:      	movq	0x178(%rdi), %rcx
   581b5:      	testq	%rcx, %rcx
   581b8:      	je	0x581f7 <f.2+0x397>
   581ba:      	movq	0x170(%rdi), %rax
   581c1:      	incq	%rax
   581c4:      	movq	%rax, 0x170(%rdi)
   581cb:      	movq	%rax, %rdx
   581ce:      	orq	%rcx, %rdx
   581d1:      	shrq	$0x20, %rdx
   581d5:      	je	0x58680 <f.2+0x820>
   581db:      	xorl	%edx, %edx
   581dd:      	divq	%rcx
   581e0:      	testq	%rdx, %rdx
   581e3:      	jne	0x581f7 <f.2+0x397>
   581e5:      	movq	0x624c(%rip), %rsi      # 0x5e438 <native_roots.0>
   581ec:      	movq	%rdi, %r13
   581ef:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   581f4:      	movq	%r13, %rdi
   581f7:      	movq	0x623a(%rip), %rdx      # 0x5e438 <native_roots.0>
   581fe:      	movl	$0x18, %esi
   58203:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58208:      	testq	%rax, %rax
   5820b:      	je	0x5871c <f.2+0x8bc>
   58211:      	movq	$0x32, (%rax)
   58218:      	leaq	0x42b9(%rip), %rcx      # 0x5c4d8 <ref.7>
   5821f:      	movq	%rcx, 0x8(%rax)
   58223:      	movq	%r12, 0x10(%rax)
   58227:      	movq	%rax, 0x10(%r15)
   5822b:      	movq	0x30(%rsp), %rax
   58230:      	testq	%rax, %rax
   58233:      	je	0x58717 <f.2+0x8b7>
   58239:      	movl	$0x1, 0x8(%rax)
   58240:      	movq	0x30(%rsp), %rax
   58245:      	testq	%rax, %rax
   58248:      	je	0x58717 <f.2+0x8b7>
   5824e:      	cmpl	$0x0, 0x8(%rax)
   58252:      	je	0x58717 <f.2+0x8b7>
   58258:      	movq	0x10(%rax), %rax
   5825c:      	testq	%rax, %rax
   5825f:      	je	0x58717 <f.2+0x8b7>
   58265:      	movq	%rax, 0x40(%rsp)
   5826a:      	movq	0x8(%rax), %rcx
   5826e:      	testq	%rcx, %rcx
   58271:      	je	0x58717 <f.2+0x8b7>
   58277:      	leaq	-0x1(%r14), %r15
   5827b:      	movq	0x10(%rax), %rdi
   5827f:      	movq	0x8(%rcx), %rax
   58283:      	movq	%rdi, 0x50(%rsp)
   58288:      	movq	$0x6, 0x20(%rsp)
   58291:      	movq	%r15, %rsi
   58294:      	callq	*%rax
   58296:      	subq	$0x8, %rsp
   5829a:      	cmpb	$0x0, 0x628f(%rip)      # 0x5e530 <g.6>
   582a1:      	je	0x58717 <f.2+0x8b7>
   582a7:      	cmpq	$0x0, 0x6279(%rip)      # 0x5e528 <g.5>
   582af:      	je	0x58717 <f.2+0x8b7>
   582b5:      	movq	$0x5, 0x20(%rsp)
   582be:      	movq	0x616b(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   582c5:      	testq	%rdi, %rdi
   582c8:      	je	0x58717 <f.2+0x8b7>
   582ce:      	movq	0x178(%rdi), %rcx
   582d5:      	testq	%rcx, %rcx
   582d8:      	je	0x58317 <f.2+0x4b7>
   582da:      	movq	0x170(%rdi), %rax
   582e1:      	incq	%rax
   582e4:      	movq	%rax, 0x170(%rdi)
   582eb:      	movq	%rax, %rdx
   582ee:      	orq	%rcx, %rdx
   582f1:      	shrq	$0x20, %rdx
   582f5:      	je	0x586a0 <f.2+0x840>
   582fb:      	xorl	%edx, %edx
   582fd:      	divq	%rcx
   58300:      	testq	%rdx, %rdx
   58303:      	jne	0x58317 <f.2+0x4b7>
   58305:      	movq	0x612c(%rip), %rsi      # 0x5e438 <native_roots.0>
   5830c:      	movq	%rdi, %r12
   5830f:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58314:      	movq	%r12, %rdi
   58317:      	movq	0x611a(%rip), %rdx      # 0x5e438 <native_roots.0>
   5831e:      	movl	$0x18, %esi
   58323:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58328:      	testq	%rax, %rax
   5832b:      	je	0x5871c <f.2+0x8bc>
   58331:      	movq	%rax, %r12
   58334:      	movq	$0x3a, (%rax)
   5833b:      	movl	$0x0, 0x8(%rax)
   58342:      	movq	$0x0, 0x10(%rax)
   5834a:      	movq	%rax, 0x30(%rsp)
   5834f:      	movq	0x48(%rsp), %rbp
   58354:      	movq	%rax, 0x50(%rsp)
   58359:      	movq	%rbp, 0x58(%rsp)
   5835e:      	leaq	0x4153(%rip), %rax      # 0x5c4b8 <ref.4>
   58365:      	movq	%rax, 0x60(%rsp)
   5836a:      	movq	%r12, 0x68(%rsp)
   5836f:      	movq	$0x9, 0x20(%rsp)
   58378:      	movq	0x60b1(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   5837f:      	testq	%rdi, %rdi
   58382:      	je	0x58717 <f.2+0x8b7>
   58388:      	movq	0x178(%rdi), %rcx
   5838f:      	testq	%rcx, %rcx
   58392:      	je	0x583d1 <f.2+0x571>
   58394:      	movq	0x170(%rdi), %rax
   5839b:      	incq	%rax
   5839e:      	movq	%rax, 0x170(%rdi)
   583a5:      	movq	%rax, %rdx
   583a8:      	orq	%rcx, %rdx
   583ab:      	shrq	$0x20, %rdx
   583af:      	je	0x586c0 <f.2+0x860>
   583b5:      	xorl	%edx, %edx
   583b7:      	divq	%rcx
   583ba:      	testq	%rdx, %rdx
   583bd:      	jne	0x583d1 <f.2+0x571>
   583bf:      	movq	0x6072(%rip), %rsi      # 0x5e438 <native_roots.0>
   583c6:      	movq	%rdi, %r13
   583c9:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   583ce:      	movq	%r13, %rdi
   583d1:      	movq	0x6060(%rip), %rdx      # 0x5e438 <native_roots.0>
   583d8:      	movl	$0x20, %esi
   583dd:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   583e2:      	testq	%rax, %rax
   583e5:      	je	0x5871c <f.2+0x8bc>
   583eb:      	movq	%rax, %r13
   583ee:      	movq	$0x1e, (%rax)
   583f5:      	movq	%rbp, 0x8(%rax)
   583f9:      	movq	%r14, 0x10(%rax)
   583fd:      	movq	%r12, 0x18(%rax)
   58401:      	movq	%rax, 0x50(%rsp)
   58406:      	leaq	0x40ab(%rip), %rax      # 0x5c4b8 <ref.4>
   5840d:      	movq	%rax, 0x58(%rsp)
   58412:      	movq	%r12, 0x60(%rsp)
   58417:      	movq	$0x8, 0x20(%rsp)
   58420:      	movq	0x6009(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58427:      	testq	%rdi, %rdi
   5842a:      	je	0x58717 <f.2+0x8b7>
   58430:      	movq	0x178(%rdi), %rcx
   58437:      	testq	%rcx, %rcx
   5843a:      	je	0x58479 <f.2+0x619>
   5843c:      	movq	0x170(%rdi), %rax
   58443:      	incq	%rax
   58446:      	movq	%rax, 0x170(%rdi)
   5844d:      	movq	%rax, %rdx
   58450:      	orq	%rcx, %rdx
   58453:      	shrq	$0x20, %rdx
   58457:      	je	0x586e0 <f.2+0x880>
   5845d:      	xorl	%edx, %edx
   5845f:      	divq	%rcx
   58462:      	testq	%rdx, %rdx
   58465:      	jne	0x58479 <f.2+0x619>
   58467:      	movq	0x5fca(%rip), %rsi      # 0x5e438 <native_roots.0>
   5846e:      	movq	%rdi, %r14
   58471:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58476:      	movq	%r14, %rdi
   58479:      	movq	0x5fb8(%rip), %rdx      # 0x5e438 <native_roots.0>
   58480:      	movl	$0x18, %esi
   58485:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   5848a:      	testq	%rax, %rax
   5848d:      	je	0x5871c <f.2+0x8bc>
   58493:      	movq	$0x32, (%rax)
   5849a:      	leaq	0x4017(%rip), %rcx      # 0x5c4b8 <ref.4>
   584a1:      	movq	%rcx, 0x8(%rax)
   584a5:      	movq	%r13, 0x10(%rax)
   584a9:      	movq	%rax, 0x10(%r12)
   584ae:      	movq	0x30(%rsp), %rax
   584b3:      	testq	%rax, %rax
   584b6:      	je	0x58717 <f.2+0x8b7>
   584bc:      	movl	$0x1, 0x8(%rax)
   584c3:      	movq	0x30(%rsp), %rax
   584c8:      	testq	%rax, %rax
   584cb:      	je	0x58717 <f.2+0x8b7>
   584d1:      	cmpl	$0x0, 0x8(%rax)
   584d5:      	je	0x58717 <f.2+0x8b7>
   584db:      	movq	0x10(%rax), %rax
   584df:      	testq	%rax, %rax
   584e2:      	je	0x58717 <f.2+0x8b7>
   584e8:      	movq	%rax, 0x40(%rsp)
   584ed:      	movq	0x8(%rax), %rcx
   584f1:      	testq	%rcx, %rcx
   584f4:      	je	0x58717 <f.2+0x8b7>
   584fa:      	movq	0x10(%rax), %rdi
   584fe:      	movq	0x8(%rcx), %rax
   58502:      	movq	%rdi, 0x50(%rsp)
   58507:      	movq	$0x6, 0x20(%rsp)
   58510:      	movq	%r15, %rsi
   58513:      	callq	*%rax
   58515:      	subq	$0x8, %rsp
   58519:      	movq	0x48(%rsp), %rax
   5851e:      	testq	%rax, %rax
   58521:      	je	0x58717 <f.2+0x8b7>
   58527:      	testb	$0x1, %al
   58529:      	jne	0x58717 <f.2+0x8b7>
   5852f:      	cmpq	$0x0, 0x8(%rax)
   58534:      	je	0x58717 <f.2+0x8b7>
   5853a:      	movq	0x10(%rax), %rax
   5853e:      	testq	%rax, %rax
   58541:      	je	0x58717 <f.2+0x8b7>
   58547:      	testb	$0x1, %al
   58549:      	jne	0x58717 <f.2+0x8b7>
   5854f:      	cmpq	$0x0, 0x8(%rax)
   58554:      	je	0x58717 <f.2+0x8b7>
   5855a:      	movq	0x38(%rsp), %rsi
   5855f:      	testq	%rsi, %rsi
   58562:      	je	0x58717 <f.2+0x8b7>
   58568:      	movq	0x10(%rsi), %rcx
   5856c:      	testq	%rcx, %rcx
   5856f:      	je	0x58717 <f.2+0x8b7>
   58575:      	cmpl	$0x0, 0x8(%rcx)
   58579:      	je	0x58717 <f.2+0x8b7>
   5857f:      	cmpq	$0x0, 0x10(%rcx)
   58584:      	je	0x58717 <f.2+0x8b7>
   5858a:      	movq	0x10(%rax), %rdx
   5858e:      	incq	%rbx
   58591:      	xorl	%eax, %eax
   58593:      	cmpq	$0x0, 0x18(%rsp)
   58599:      	sete	%al
   5859c:      	leaq	0x10(%rsp), %rdi
   585a1:      	movq	%rdi, %rcx
   585a4:      	leaq	0x5e8d(%rip), %r8       # 0x5e438 <native_roots.0>
   585ab:      	cmoveq	%r8, %rcx
   585af:      	addq	0x5e62(%rip), %rax      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   585b6:      	movq	(%rcx), %rcx
   585b9:      	movq	$0x9, 0x18(%rsp)
   585c2:      	movq	$0x0, 0x20(%rsp)
   585cb:      	movq	%rcx, 0x10(%rsp)
   585d0:      	movq	%rdi, 0x5e61(%rip)      # 0x5e438 <native_roots.0>
   585d7:      	movq	0x5e42(%rip), %rdi      # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   585de:      	cmpq	%rdi, %rax
   585e1:      	cmovaq	%rax, %rdi
   585e5:      	movq	%rax, 0x5e2c(%rip)      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   585ec:      	movq	%rdi, 0x5e2d(%rip)      # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   585f3:      	movq	%rsi, 0x28(%rsp)
   585f8:      	leaq	0x30(%rsp), %rdi
   585fd:      	xorps	%xmm0, %xmm0
   58600:      	movups	%xmm0, 0x10(%rdi)
   58604:      	movups	%xmm0, (%rdi)
   58607:      	movq	%rsi, 0x38(%rsp)
   5860c:      	cmpq	%rbx, 0x8(%rsi)
   58610:      	jg	0x57ef0 <f.2+0x90>
   58616:      	jmp	0x586f2 <f.2+0x892>
   5861b:      	nopl	(%rax,%rax)
   58620:      	xorl	%edx, %edx
   58622:      	divl	%ecx
   58624:      	testq	%rdx, %rdx
   58627:      	jne	0x57fc1 <f.2+0x161>
   5862d:      	jmp	0x57faf <f.2+0x14f>
   58632:      	nopw	%cs:(%rax,%rax)
   58640:      	xorl	%edx, %edx
   58642:      	divl	%ecx
   58644:      	testq	%rdx, %rdx
   58647:      	jne	0x5806c <f.2+0x20c>
   5864d:      	jmp	0x5805a <f.2+0x1fa>
   58652:      	nopw	%cs:(%rax,%rax)
   58660:      	xorl	%edx, %edx
   58662:      	divl	%ecx
   58664:      	testq	%rdx, %rdx
   58667:      	jne	0x5814f <f.2+0x2ef>
   5866d:      	jmp	0x5813d <f.2+0x2dd>
   58672:      	nopw	%cs:(%rax,%rax)
   58680:      	xorl	%edx, %edx
   58682:      	divl	%ecx
   58684:      	testq	%rdx, %rdx
   58687:      	jne	0x581f7 <f.2+0x397>
   5868d:      	jmp	0x581e5 <f.2+0x385>
   58692:      	nopw	%cs:(%rax,%rax)
   586a0:      	xorl	%edx, %edx
   586a2:      	divl	%ecx
   586a4:      	testq	%rdx, %rdx
   586a7:      	jne	0x58317 <f.2+0x4b7>
   586ad:      	jmp	0x58305 <f.2+0x4a5>
   586b2:      	nopw	%cs:(%rax,%rax)
   586c0:      	xorl	%edx, %edx
   586c2:      	divl	%ecx
   586c4:      	testq	%rdx, %rdx
   586c7:      	jne	0x583d1 <f.2+0x571>
   586cd:      	jmp	0x583bf <f.2+0x55f>
   586d2:      	nopw	%cs:(%rax,%rax)
   586e0:      	xorl	%edx, %edx
   586e2:      	divl	%ecx
   586e4:      	testq	%rdx, %rdx
   586e7:      	jne	0x58479 <f.2+0x619>
   586ed:      	jmp	0x58467 <f.2+0x607>
   586f2:      	decq	%rax
   586f5:      	movq	%rcx, 0x5d3c(%rip)      # 0x5e438 <native_roots.0>
   586fc:      	movq	%rax, 0x5d15(%rip)      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58703:      	movq	%rdx, %rax
   58706:      	addq	$0x78, %rsp
   5870a:      	popq	%rbx
   5870b:      	popq	%r12
   5870d:      	popq	%r13
   5870f:      	popq	%r14
   58711:      	popq	%r15
   58713:      	popq	%rbp
   58714:      	retq	$0x8
   58717:      	callq	0x54900 <native_trap>
   5871c:      	leaq	-0x4f917(%rip), %rdi    # 0x8e0c <_RNvNtNtNtNtCsgEmfK2I1SDS_4core3num7flt2dec8strategy6dragon9POW5TO256+0x828>
   58723:      	movl	$0x2f, %esi
   58728:      	callq	0x55900 <_ZN13snail_runtime6native10fail_bytes17hebf443f7be983434E>
   5872d:      	int3
   5872e:      	int3
   5872f:      	int3

