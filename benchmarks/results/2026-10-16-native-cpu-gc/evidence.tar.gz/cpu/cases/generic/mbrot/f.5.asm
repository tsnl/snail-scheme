0000000000058b50 <f.5>:
   58b50:      	pushq	%rbp
   58b51:      	pushq	%r15
   58b53:      	pushq	%r14
   58b55:      	pushq	%r13
   58b57:      	pushq	%r12
   58b59:      	pushq	%rbx
   58b5a:      	subq	$0x98, %rsp
   58b61:      	movq	%rsi, %rbx
   58b64:      	movq	$0x7, 0x18(%rsp)
   58b6d:      	movq	$0x0, 0x20(%rsp)
   58b76:      	movq	0x58bb(%rip), %rcx      # 0x5e438 <native_roots.0>
   58b7d:      	movq	%rcx, 0x10(%rsp)
   58b82:      	leaq	0x10(%rsp), %r13
   58b87:      	movq	0x588a(%rip), %rax      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58b8e:      	leaq	0x1(%rax), %rdx
   58b92:      	movq	0x5887(%rip), %rsi      # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   58b99:      	cmpq	%rsi, %rdx
   58b9c:      	cmovaq	%rdx, %rsi
   58ba0:      	movq	%r13, 0x5891(%rip)      # 0x5e438 <native_roots.0>
   58ba7:      	movq	%rdx, 0x586a(%rip)      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   58bae:      	movq	%rsi, 0x586b(%rip)      # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   58bb5:      	movq	%rdi, 0x28(%rsp)
   58bba:      	xorpd	%xmm0, %xmm0
   58bbe:      	movupd	%xmm0, 0x30(%rsp)
   58bc4:      	movq	$0x0, 0x40(%rsp)
   58bcd:      	testq	%rbx, %rbx
   58bd0:      	js	0x59147 <f.5+0x5f7>
   58bd6:      	movq	%rbx, %rax
   58bd9:      	shrq	$0x20, %rax
   58bdd:      	movq	%rax, 0x68(%rsp)
   58be2:      	nopw	%cs:(%rax,%rax)
   58bf0:      	cmpq	$0x0, 0x68(%rsp)
   58bf6:      	jne	0x5921f <f.5+0x6cf>
   58bfc:      	testq	%rdi, %rdi
   58bff:      	je	0x5921f <f.5+0x6cf>
   58c05:      	movl	%edi, %eax
   58c07:      	andl	$0x1, %eax
   58c0a:      	jne	0x5921f <f.5+0x6cf>
   58c10:      	movq	0x5819(%rip), %r15      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58c17:      	testq	%r15, %r15
   58c1a:      	je	0x5921f <f.5+0x6cf>
   58c20:      	movq	(%rdi), %rax
   58c23:      	testq	%rax, %rax
   58c26:      	je	0x58c90 <f.5+0x140>
   58c28:      	cmpq	$0x16, %rax
   58c2c:      	je	0x58c90 <f.5+0x140>
   58c2e:      	movq	0x168(%r15), %rcx
   58c35:      	shrq	$0x2, %rax
   58c39:      	leaq	-0x1(%rax), %rdx
   58c3d:      	cmpq	%rcx, %rdx
   58c40:      	jae	0x5921f <f.5+0x6cf>
   58c46:      	movq	0x160(%r15), %rdx
   58c4d:      	movq	-0x8(%rdx,%rax,8), %rax
   58c52:      	testq	%rax, %rax
   58c55:      	je	0x58c90 <f.5+0x140>
   58c57:      	cmpq	$0x16, %rax
   58c5b:      	je	0x58c90 <f.5+0x140>
   58c5d:      	nopl	(%rax)
   58c60:      	shrq	$0x2, %rax
   58c64:      	leaq	-0x1(%rax), %rsi
   58c68:      	cmpq	%rcx, %rsi
   58c6b:      	jae	0x5921f <f.5+0x6cf>
   58c71:      	movq	-0x8(%rdx,%rax,8), %rax
   58c76:      	cmpq	$0x16, %rax
   58c7a:      	je	0x58c90 <f.5+0x140>
   58c7c:      	testq	%rax, %rax
   58c7f:      	jne	0x58c60 <f.5+0x110>
   58c81:      	nopw	%cs:(%rax,%rax)
   58c90:      	cmpq	$0x16, %rax
   58c94:      	jne	0x5921f <f.5+0x6cf>
   58c9a:      	movq	%rdi, 0x30(%rsp)
   58c9f:      	movq	0x8(%rdi), %rax
   58ca3:      	testq	%rax, %rax
   58ca6:      	je	0x5921f <f.5+0x6cf>
   58cac:      	testb	$0x1, %al
   58cae:      	jne	0x5921f <f.5+0x6cf>
   58cb4:      	cmpq	0x8(%rax), %rbx
   58cb8:      	jae	0x5921f <f.5+0x6cf>
   58cbe:      	cmpb	$0x0, 0x585b(%rip)      # 0x5e520 <g.4>
   58cc5:      	je	0x5921f <f.5+0x6cf>
   58ccb:      	cmpq	$0x0, 0x5845(%rip)      # 0x5e518 <g.3>
   58cd3:      	je	0x5921f <f.5+0x6cf>
   58cd9:      	movq	0x10(%rax,%rbx,8), %rbp
   58cde:      	movq	%rbp, 0x48(%rsp)
   58ce3:      	movq	$0x5, 0x20(%rsp)
   58cec:      	movq	0x178(%r15), %rcx
   58cf3:      	movq	%r13, %rdx
   58cf6:      	testq	%rcx, %rcx
   58cf9:      	je	0x58d3e <f.5+0x1ee>
   58cfb:      	movq	0x170(%r15), %rax
   58d02:      	incq	%rax
   58d05:      	movq	%rax, 0x170(%r15)
   58d0c:      	movq	%rax, %rdx
   58d0f:      	orq	%rcx, %rdx
   58d12:      	shrq	$0x20, %rdx
   58d16:      	je	0x590f0 <f.5+0x5a0>
   58d1c:      	xorl	%edx, %edx
   58d1e:      	divq	%rcx
   58d21:      	movq	%rdx, %rax
   58d24:      	movq	%r13, %rdx
   58d27:      	testq	%rax, %rax
   58d2a:      	jne	0x58d3e <f.5+0x1ee>
   58d2c:      	movq	%r15, %rdi
   58d2f:      	movq	%r13, %rsi
   58d32:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58d37:      	movq	0x56fa(%rip), %rdx      # 0x5e438 <native_roots.0>
   58d3e:      	movl	$0x18, %esi
   58d43:      	movq	%r15, %rdi
   58d46:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58d4b:      	testq	%rax, %rax
   58d4e:      	je	0x59224 <f.5+0x6d4>
   58d54:      	movq	%rax, %r15
   58d57:      	movq	$0x12, (%rax)
   58d5e:      	movl	$0x0, 0x8(%rax)
   58d65:      	movq	$0x0, 0x10(%rax)
   58d6d:      	movq	%rax, 0x38(%rsp)
   58d72:      	cvtsi2sd	%rbx, %xmm1
   58d77:      	movsd	-0x53337(%rip), %xmm0   # 0x5a48 <writev+0x5a48>
   58d7f:      	mulsd	%xmm0, %xmm1
   58d83:      	addsd	-0x5337b(%rip), %xmm1   # 0x5a10 <writev+0x5a10>
   58d8b:      	movq	0x30(%rsp), %rax
   58d90:      	testq	%rax, %rax
   58d93:      	je	0x5921f <f.5+0x6cf>
   58d99:      	movq	0x18(%rax), %r14
   58d9d:      	cvtsi2sd	%r14, %xmm2
   58da2:      	mulsd	%xmm0, %xmm2
   58da6:      	addsd	-0x53386(%rip), %xmm2   # 0x5a28 <writev+0x5a28>
   58dae:      	movapd	%xmm2, 0x70(%rsp)
   58db4:      	movq	%r15, 0x48(%rsp)
   58db9:      	movq	%r15, 0x50(%rsp)
   58dbe:      	movq	%rbp, 0x58(%rsp)
   58dc3:      	movq	$0x7, 0x20(%rsp)
   58dcc:      	movq	0x565d(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58dd3:      	testq	%rdi, %rdi
   58dd6:      	je	0x5921f <f.5+0x6cf>
   58ddc:      	movapd	%xmm1, 0x80(%rsp)
   58de5:      	movq	0x178(%rdi), %rcx
   58dec:      	testq	%rcx, %rcx
   58def:      	je	0x58e2e <f.5+0x2de>
   58df1:      	movq	0x170(%rdi), %rax
   58df8:      	incq	%rax
   58dfb:      	movq	%rax, 0x170(%rdi)
   58e02:      	movq	%rax, %rdx
   58e05:      	orq	%rcx, %rdx
   58e08:      	shrq	$0x20, %rdx
   58e0c:      	je	0x59110 <f.5+0x5c0>
   58e12:      	xorl	%edx, %edx
   58e14:      	divq	%rcx
   58e17:      	testq	%rdx, %rdx
   58e1a:      	jne	0x58e2e <f.5+0x2de>
   58e1c:      	movq	0x5615(%rip), %rsi      # 0x5e438 <native_roots.0>
   58e23:      	movq	%rdi, %r12
   58e26:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58e2b:      	movq	%r12, %rdi
   58e2e:      	movq	0x5603(%rip), %rdx      # 0x5e438 <native_roots.0>
   58e35:      	movl	$0x20, %esi
   58e3a:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58e3f:      	testq	%rax, %rax
   58e42:      	je	0x59224 <f.5+0x6d4>
   58e48:      	movq	%rax, %r12
   58e4b:      	movq	$0xe, (%rax)
   58e52:      	movaps	0x80(%rsp), %xmm0
   58e5a:      	movsd	%xmm0, 0x8(%rax)
   58e5f:      	movaps	0x70(%rsp), %xmm0
   58e64:      	movsd	%xmm0, 0x10(%rax)
   58e69:      	movq	%r15, 0x18(%rax)
   58e6d:      	movq	%rax, 0x48(%rsp)
   58e72:      	movq	%r15, 0x50(%rsp)
   58e77:      	movq	%rbp, 0x58(%rsp)
   58e7c:      	movq	$0x7, 0x20(%rsp)
   58e85:      	movq	0x55a4(%rip), %rdi      # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   58e8c:      	testq	%rdi, %rdi
   58e8f:      	je	0x5921f <f.5+0x6cf>
   58e95:      	movq	0x178(%rdi), %rcx
   58e9c:      	testq	%rcx, %rcx
   58e9f:      	je	0x58eee <f.5+0x39e>
   58ea1:      	movq	0x170(%rdi), %rax
   58ea8:      	incq	%rax
   58eab:      	movq	%rax, 0x170(%rdi)
   58eb2:      	movq	%rax, %rdx
   58eb5:      	orq	%rcx, %rdx
   58eb8:      	shrq	$0x20, %rdx
   58ebc:      	je	0x59130 <f.5+0x5e0>
   58ec2:      	xorl	%edx, %edx
   58ec4:      	divq	%rcx
   58ec7:      	testq	%rdx, %rdx
   58eca:      	jne	0x58eee <f.5+0x39e>
   58ecc:      	movq	0x5565(%rip), %rsi      # 0x5e438 <native_roots.0>
   58ed3:      	movq	%rbx, 0x60(%rsp)
   58ed8:      	movq	%r13, %rbx
   58edb:      	movq	%rdi, %r13
   58ede:      	callq	0x55fd0 <_ZN13snail_runtime9native_gc9Collector7collect17h11d64f417aabdfdbE>
   58ee3:      	movq	%r13, %rdi
   58ee6:      	movq	%rbx, %r13
   58ee9:      	movq	0x60(%rsp), %rbx
   58eee:      	movq	0x5543(%rip), %rdx      # 0x5e438 <native_roots.0>
   58ef5:      	movl	$0x10, %esi
   58efa:      	callq	0x55e20 <_ZN13snail_runtime9native_gc9Collector8allocate17h6a89179535fb9c29E>
   58eff:      	testq	%rax, %rax
   58f02:      	je	0x59224 <f.5+0x6d4>
   58f08:      	movq	$0xa, (%rax)
   58f0f:      	movq	%r12, 0x8(%rax)
   58f13:      	movq	%rax, 0x10(%r15)
   58f17:      	movq	0x38(%rsp), %rax
   58f1c:      	testq	%rax, %rax
   58f1f:      	movsd	-0x53507(%rip), %xmm3   # 0x5a20 <writev+0x5a20>
   58f27:      	je	0x5921f <f.5+0x6cf>
   58f2d:      	movl	$0x1, 0x8(%rax)
   58f34:      	movq	0x38(%rsp), %rax
   58f39:      	testq	%rax, %rax
   58f3c:      	movapd	0x80(%rsp), %xmm4
   58f45:      	je	0x5921f <f.5+0x6cf>
   58f4b:      	cmpl	$0x0, 0x8(%rax)
   58f4f:      	je	0x5921f <f.5+0x6cf>
   58f55:      	movq	0x10(%rax), %rax
   58f59:      	testq	%rax, %rax
   58f5c:      	je	0x5921f <f.5+0x6cf>
   58f62:      	movq	0x8(%rax), %rcx
   58f66:      	movq	%rbp, 0x48(%rsp)
   58f6b:      	movq	%rcx, 0x50(%rsp)
   58f70:      	movq	$0x6, 0x20(%rsp)
   58f79:      	unpcklpd	0x70(%rsp), %xmm4       # xmm4 = xmm4[0],mem[0]
   58f7f:      	xorl	%eax, %eax
   58f81:      	nopw	%cs:(%rax,%rax)
   58f90:      	movapd	%xmm4, %xmm0
   58f94:      	mulpd	%xmm4, %xmm0
   58f98:      	movapd	%xmm0, %xmm1
   58f9c:      	unpckhpd	%xmm0, %xmm1            # xmm1 = xmm1[1],xmm0[1]
   58fa0:      	movapd	%xmm1, %xmm2
   58fa4:      	addsd	%xmm0, %xmm2
   58fa8:      	ucomisd	%xmm3, %xmm2
   58fac:      	ja	0x5900e <f.5+0x4be>
   58fae:      	testq	%rcx, %rcx
   58fb1:      	je	0x5921f <f.5+0x6cf>
   58fb7:      	movq	0x18(%rcx), %rdx
   58fbb:      	testq	%rdx, %rdx
   58fbe:      	je	0x5921f <f.5+0x6cf>
   58fc4:      	cmpl	$0x0, 0x8(%rdx)
   58fc8:      	je	0x5921f <f.5+0x6cf>
   58fce:      	movq	0x10(%rdx), %rdx
   58fd2:      	testq	%rdx, %rdx
   58fd5:      	je	0x5921f <f.5+0x6cf>
   58fdb:      	movapd	%xmm4, %xmm2
   58fdf:      	unpckhpd	%xmm4, %xmm2            # xmm2 = xmm2[1],xmm4[1]
   58fe3:      	mulsd	%xmm4, %xmm2
   58fe7:      	movupd	0x8(%rcx), %xmm4
   58fec:      	movq	0x8(%rdx), %rcx
   58ff0:      	addsd	%xmm2, %xmm2
   58ff4:      	subsd	%xmm1, %xmm0
   58ff8:      	unpcklpd	%xmm2, %xmm0            # xmm0 = xmm0[0],xmm2[0]
   58ffc:      	addpd	%xmm0, %xmm4
   59000:      	incq	%rax
   59003:      	cmpq	$0x40, %rax
   59007:      	jne	0x58f90 <f.5+0x440>
   59009:      	movl	$0x40, %eax
   5900e:      	movq	%r14, %rcx
   59011:      	shrq	$0x20, %rcx
   59015:      	jne	0x5921f <f.5+0x6cf>
   5901b:      	testq	%rbp, %rbp
   5901e:      	je	0x5921f <f.5+0x6cf>
   59024:      	testb	$0x1, %bpl
   59028:      	jne	0x5921f <f.5+0x6cf>
   5902e:      	cmpq	0x8(%rbp), %r14
   59032:      	jae	0x5921f <f.5+0x6cf>
   59038:      	movq	%rax, 0x10(%rbp,%r14,8)
   5903d:      	movq	0x30(%rsp), %rdi
   59042:      	testq	%rdi, %rdi
   59045:      	je	0x5921f <f.5+0x6cf>
   5904b:      	movq	0x20(%rdi), %rax
   5904f:      	testq	%rax, %rax
   59052:      	je	0x5921f <f.5+0x6cf>
   59058:      	cmpl	$0x0, 0x8(%rax)
   5905c:      	je	0x5921f <f.5+0x6cf>
   59062:      	cmpq	$0x0, 0x10(%rax)
   59067:      	je	0x5921f <f.5+0x6cf>
   5906d:      	xorl	%eax, %eax
   5906f:      	cmpq	$0x0, 0x18(%rsp)
   59075:      	movq	%r13, %rcx
   59078:      	leaq	0x53b9(%rip), %rdx      # 0x5e438 <native_roots.0>
   5907f:      	cmoveq	%rdx, %rcx
   59083:      	sete	%al
   59086:      	addq	0x538b(%rip), %rax      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   5908d:      	movq	0x538c(%rip), %rdx      # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   59094:      	cmpq	%rdx, %rax
   59097:      	cmovaq	%rax, %rdx
   5909b:      	movq	(%rcx), %rcx
   5909e:      	movq	$0x7, 0x18(%rsp)
   590a7:      	movq	$0x0, 0x20(%rsp)
   590b0:      	movq	%rcx, 0x10(%rsp)
   590b5:      	movq	%r13, 0x537c(%rip)      # 0x5e438 <native_roots.0>
   590bc:      	movq	%rax, 0x5355(%rip)      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   590c3:      	movq	%rdx, 0x5356(%rip)      # 0x5e420 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hcd4f6cc2e4df24caE.0>
   590ca:      	movq	%rdi, 0x28(%rsp)
   590cf:      	xorpd	%xmm0, %xmm0
   590d3:      	leaq	0x30(%rsp), %rdx
   590d8:      	movupd	%xmm0, (%rdx)
   590dc:      	movq	$0x0, 0x10(%rdx)
   590e4:      	subq	$0x1, %rbx
   590e8:      	jae	0x58bf0 <f.5+0xa0>
   590ee:      	jmp	0x59142 <f.5+0x5f2>
   590f0:      	xorl	%edx, %edx
   590f2:      	divl	%ecx
   590f4:      	movl	%edx, %eax
   590f6:      	movq	%r13, %rdx
   590f9:      	testq	%rax, %rax
   590fc:      	jne	0x58d3e <f.5+0x1ee>
   59102:      	jmp	0x58d2c <f.5+0x1dc>
   59107:      	nopw	(%rax,%rax)
   59110:      	xorl	%edx, %edx
   59112:      	divl	%ecx
   59114:      	testq	%rdx, %rdx
   59117:      	jne	0x58e2e <f.5+0x2de>
   5911d:      	jmp	0x58e1c <f.5+0x2cc>
   59122:      	nopw	%cs:(%rax,%rax)
   59130:      	xorl	%edx, %edx
   59132:      	divl	%ecx
   59134:      	testq	%rdx, %rdx
   59137:      	jne	0x58eee <f.5+0x39e>
   5913d:      	jmp	0x58ecc <f.5+0x37c>
   59142:      	decq	%rax
   59145:      	jmp	0x59150 <f.5+0x600>
   59147:      	testq	%rdi, %rdi
   5914a:      	je	0x5921f <f.5+0x6cf>
   59150:      	testb	$0x1, %dil
   59154:      	jne	0x5921f <f.5+0x6cf>
   5915a:      	movq	0x52cf(%rip), %r8       # 0x5e430 <_ZN13snail_runtime6native7RUNTIME17hc0d1cec0e506091aE.0>
   59161:      	testq	%r8, %r8
   59164:      	je	0x5921f <f.5+0x6cf>
   5916a:      	movq	(%rdi), %rdx
   5916d:      	testq	%rdx, %rdx
   59170:      	je	0x591cd <f.5+0x67d>
   59172:      	cmpq	$0x16, %rdx
   59176:      	je	0x591cd <f.5+0x67d>
   59178:      	movq	0x168(%r8), %rsi
   5917f:      	shrq	$0x2, %rdx
   59183:      	leaq	-0x1(%rdx), %r9
   59187:      	cmpq	%rsi, %r9
   5918a:      	jae	0x5921f <f.5+0x6cf>
   59190:      	movq	0x160(%r8), %r8
   59197:      	movq	-0x8(%r8,%rdx,8), %rdx
   5919c:      	testq	%rdx, %rdx
   5919f:      	je	0x591cd <f.5+0x67d>
   591a1:      	cmpq	$0x16, %rdx
   591a5:      	je	0x591cd <f.5+0x67d>
   591a7:      	nopw	(%rax,%rax)
   591b0:      	shrq	$0x2, %rdx
   591b4:      	leaq	-0x1(%rdx), %r9
   591b8:      	cmpq	%rsi, %r9
   591bb:      	jae	0x5921f <f.5+0x6cf>
   591bd:      	movq	-0x8(%r8,%rdx,8), %rdx
   591c2:      	cmpq	$0x16, %rdx
   591c6:      	je	0x591cd <f.5+0x67d>
   591c8:      	testq	%rdx, %rdx
   591cb:      	jne	0x591b0 <f.5+0x660>
   591cd:      	cmpq	$0x16, %rdx
   591d1:      	jne	0x5921f <f.5+0x6cf>
   591d3:      	movq	%rdi, 0x30(%rsp)
   591d8:      	movq	0x10(%rdi), %rdx
   591dc:      	testq	%rdx, %rdx
   591df:      	je	0x5921f <f.5+0x6cf>
   591e1:      	cmpl	$0x0, 0x8(%rdx)
   591e5:      	je	0x5921f <f.5+0x6cf>
   591e7:      	movq	0x10(%rdx), %rdx
   591eb:      	testq	%rdx, %rdx
   591ee:      	je	0x5921f <f.5+0x6cf>
   591f0:      	movq	0x18(%rdi), %rsi
   591f4:      	movq	0x10(%rdx), %rdi
   591f8:      	movq	%rcx, 0x5239(%rip)      # 0x5e438 <native_roots.0>
   591ff:      	movq	%rax, 0x5212(%rip)      # 0x5e418 <_ZN13snail_runtime6native10ROOT_DEPTH17h7bc4c02393ecdfe0E.0>
   59206:      	decq	%rsi
   59209:      	addq	$0x98, %rsp
   59210:      	popq	%rbx
   59211:      	popq	%r12
   59213:      	popq	%r13
   59215:      	popq	%r14
   59217:      	popq	%r15
   59219:      	popq	%rbp
   5921a:      	jmp	0x58730 <f.4>
   5921f:      	callq	0x54900 <native_trap>
   59224:      	leaq	-0x5041f(%rip), %rdi    # 0x8e0c <_RNvNtNtNtNtCsgEmfK2I1SDS_4core3num7flt2dec8strategy6dragon9POW5TO256+0x828>
   5922b:      	movl	$0x2f, %esi
   59230:      	callq	0x55900 <_ZN13snail_runtime6native10fail_bytes17hebf443f7be983434E>
   59235:      	int3
   59236:      	int3
   59237:      	int3
   59238:      	int3
   59239:      	int3
   5923a:      	int3
   5923b:      	int3
   5923c:      	int3
   5923d:      	int3
   5923e:      	int3
   5923f:      	int3

