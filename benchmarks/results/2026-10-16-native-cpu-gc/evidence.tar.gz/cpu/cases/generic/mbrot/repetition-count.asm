   4bef1:      	testq	%rax, %rax
   4bef4:      	je	0x4c63c <_ZN76wasm_native_7a1fe22847ac727b905bc5f2757399f0cd7a262927b6881d74b7e06f879e04f13run17h4efc39d8e4a945ecE+0x144c>
   4befa:      	movq	%rax, %r15
   4befd:      	movq	$0x36, (%rax)
   4bf04:      	movq	$0x3e8, 0x8(%rax)       # imm = 0x3E8
   4bf0c:      	movq	%r14, 0x10(%rax)
   4bf10:      	movq	%rax, 0xa8(%rsp)
   4bf18:      	movq	%r13, 0xb0(%rsp)
   4bf20:      	movq	%r14, 0xb8(%rsp)
