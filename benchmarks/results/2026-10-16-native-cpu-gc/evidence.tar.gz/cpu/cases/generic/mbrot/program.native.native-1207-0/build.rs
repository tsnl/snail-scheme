fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-cpu-rootproof-evidence-20261016/cases/generic/mbrot/program.native.native-1207-0/module.bc");
}
