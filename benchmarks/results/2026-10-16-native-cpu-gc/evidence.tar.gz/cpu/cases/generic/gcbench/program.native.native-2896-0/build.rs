fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-cpu-rootproof-evidence-20261016/cases/generic/gcbench/program.native.native-2896-0/module.bc");
}
