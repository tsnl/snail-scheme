(module
 (rec
  (type $type26 (sub (struct)))
  (type $1 (func (param (ref $environment290) i64) (result (ref $type28))))
  (type $2 (func (param (ref $environment285) i64) (result i32)))
  (type $call33 (func (param (ref null $environment267) i64) (result i64)))
  (type $environment252 (struct (field (ref $type45)) (field i64) (field i64) (field (ref $type39))))
  (type $environment262 (struct (field (ref $type47)) (field i64) (field i64) (field (ref $type39))))
  (type $6 (func (param (ref $environment238) i64) (result i32)))
  (type $environment238 (struct (field (ref $type45)) (field (ref $type47)) (field i64)))
  (type $environment227 (struct (field i64) (field (ref $type39)) (field (ref $type39))))
  (type $environment233 (struct (field (ref $type45)) (field (ref $type47)) (field (ref $type40))))
  (type $environment274 (struct (field i64) (field (ref $type50)) (field (ref $type39))))
  (type $environment285 (struct (field (ref $type47)) (field (ref $type26))))
  (type $type29 (struct (field (mut (ref $type26)))))
  (type $type46 (struct (field (ref $environment290))))
  (type $environment290 (struct (field (ref $type45))))
  (type $type48 (struct (field (ref $environment279))))
  (type $type28 (sub $type26 (struct (field (ref $type29)) (field (ref $type29)))))
  (type $environment279 (struct (field (ref $type47))))
  (type $type50 (array (mut f64)))
  (type $type45 (struct (field (mut i32)) (field (mut (ref null $type46)))))
  (type $type47 (struct (field (mut i32)) (field (mut (ref null $type48)))))
  (type $21 (func (param (ref $environment145)) (result i32)))
  (type $type39 (struct (field (mut i32)) (field (mut (ref null $type37)))))
  (type $environment145 (struct (field i64) (field i64) (field i64) (field (ref $type40))))
  (type $environment267 (struct (field i64) (field (ref $type40))))
  (type $type40 (struct (field (ref $type33))))
  (type $call34 (func (param (ref null $environment308) i64 i64) (result i64)))
  (type $environment308 (struct (field (ref $type55))))
  (type $environment117 (struct (field i64) (field (ref $type39))))
  (type $type55 (struct (field (mut i32)) (field (mut (ref null $type34)))))
  (type $call37 (func (param structref i64) (result i32)))
  (type $type37 (struct (field (ref $call37)) (field structref)))
  (type $type10 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct (field (ref $call34)) (field (ref null $environment308))))
  (type $type33 (struct (field (ref null $environment267))))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type25 (struct))
  (type $type27 (sub $type26 (struct)))
 )
 (type $42 (func (param i64) (result i64)))
 (type $43 (func (param i64 i64)))
 (type $44 (func (param i64)))
 (type $45 (func (param i32) (result i64)))
 (type $46 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "print_text" (func $foreign1 (param i64)))
 (import "benchmark" "print_size" (func $foreign2 (param i64 i64)))
 (import "benchmark" "print_construction" (func $foreign3 (param i64 i64)))
 (import "benchmark" "input_i64" (func $foreign4 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty27 (ref $type27) (struct.new_default $type27))
 (global $global95 (mut (ref null $type25)) (ref.null none))
 (global $ready95 (mut i32) (i32.const 0))
 (global $global97 (mut (ref null $type30)) (ref.null none))
 (global $ready97 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type31)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global99 (mut (ref null $type31)) (ref.null none))
 (global $ready99 (mut i32) (i32.const 0))
 (global $global100 (mut (ref null $type32)) (ref.null none))
 (global $ready100 (mut i32) (i32.const 0))
 (global $global101 (mut (ref null $type32)) (ref.null none))
 (global $ready101 (mut i32) (i32.const 0))
 (global $global298 (mut (ref null $type33)) (ref.null none))
 (global $ready298 (mut i32) (i32.const 0))
 (global $global213 (mut (ref null $type34)) (ref.null none))
 (global $ready213 (mut i32) (i32.const 0))
 (global $global102 (mut (ref null $type35)) (ref.null none))
 (global $ready102 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type34)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type36)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type10)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global104 (mut (ref null $type37)) (ref.null none))
 (global $ready104 (mut i32) (i32.const 0))
 (global $global105 (mut i64) (i64.const 0))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type33)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function117 (type $call37) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type55))
  (local $3 (ref $type34))
  (local $4 (ref $environment117))
  (local $5 i64)
  (local $6 i64)
  (if (result i32)
   (i64.eq
    (struct.get $environment117 0
     (ref.cast (ref $environment117)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment117)
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready105)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready122)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type34 1
      (global.get $global122)
     )
    )
    (local.set $5
     (call $foreign0
      (global.get $global105)
     )
    )
    (if
     (i32.eqz
      (global.get $ready104)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type37 1
      (global.get $global104)
     )
    )
    (if
     (i32.eqz
      (global.get $ready298)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type33 0
      (global.get $global298)
     )
    )
    (struct.set $type55 1
     (local.tee $2
      (struct.new_default $type55)
     )
     (struct.new $type34
      (ref.func $function308)
      (struct.new $environment308
       (local.get $2)
      )
     )
    )
    (struct.set $type55 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function145
      (struct.new $environment145
       (local.get $5)
       (local.tee $6
        (i64.sub
         (local.get $5)
         (i64.const 2)
        )
       )
       (i64.shl
        (i64.sub
         (call_ref $call34
          (struct.get $type34 1
           (local.tee $3
            (ref.as_non_null
             (struct.get $type55 1
              (local.get $2)
             )
            )
           )
          )
          (i64.add
           (local.get $6)
           (i64.const 1)
          )
          (i64.const 1)
          (struct.get $type34 0
           (local.get $3)
          )
         )
         (i64.const 1)
        )
        (i64.const 2)
       )
       (struct.new $type40
        (struct.new $type33
         (struct.new $environment267
          (local.get $5)
          (struct.new $type40
           (struct.new_default $type33)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment117 1
        (ref.cast (ref $environment117)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type39 1
       (struct.get $environment117 1
        (local.tee $4
         (ref.cast (ref $environment117)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (return_call $function117
     (local.get $4)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function123 (type $call34) (param $0 (ref null $environment308)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function129 (type $call37) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type55))
  (local $3 (ref $type34))
  (local $4 i64)
  (if
   (i32.eqz
    (global.get $ready298)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type33 0
    (global.get $global298)
   )
  )
  (struct.set $type55 1
   (local.tee $2
    (struct.new_default $type55)
   )
   (struct.new $type34
    (ref.func $function308)
    (struct.new $environment308
     (local.get $2)
    )
   )
  )
  (struct.set $type55 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type55 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function145
   (struct.new $environment145
    (local.get $1)
    (local.tee $4
     (i64.sub
      (local.get $1)
      (i64.const 2)
     )
    )
    (i64.shl
     (i64.sub
      (call_ref $call34
       (struct.get $type34 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type55 1
           (local.get $2)
          )
         )
        )
       )
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
       (i64.const 1)
       (struct.get $type34 0
        (local.get $3)
       )
      )
      (i64.const 1)
     )
     (i64.const 2)
    )
    (struct.new $type40
     (struct.new $type33
      (struct.new $environment267
       (local.get $1)
       (struct.new $type40
        (struct.new_default $type33)
       )
      )
     )
    )
   )
  )
 )
 (func $function145 (type $21) (param $0 (ref $environment145)) (result i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 f64)
  (local $4 (ref $type39))
  (local $5 (ref $type47))
  (local $6 (ref $type45))
  (local $7 (ref $type37))
  (local $8 (ref $type50))
  (local $9 (ref $environment279))
  (local $10 (ref $type28))
  (struct.set $type47 1
   (local.tee $5
    (struct.new_default $type47)
   )
   (struct.new $type48
    (struct.new $environment279
     (local.get $5)
    )
   )
  )
  (struct.set $type47 0
   (local.get $5)
   (i32.const 1)
  )
  (struct.set $type45 1
   (local.tee $6
    (struct.new_default $type45)
   )
   (struct.new $type46
    (struct.new $environment290
     (local.get $6)
    )
   )
  )
  (struct.set $type45 0
   (local.get $6)
   (i32.const 1)
  )
  (call $foreign1
   (i64.const 3)
  )
  (call $foreign1
   (i64.const 0)
  )
  (call $foreign2
   (i64.const 0)
   (local.tee $1
    (struct.get $environment145 0
     (local.get $0)
    )
   )
  )
  (call $foreign1
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (call $foreign1
   (i64.const 1)
  )
  (call $foreign1
   (i64.const 2)
  )
  (call $foreign1
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (call $foreign1
   (i64.const 6)
  )
  (call $foreign1
   (i64.const 0)
  )
  (if
   (i32.eqz
    (struct.get $type45 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function290
    (struct.get $type46 0
     (struct.get $type45 1
      (local.get $6)
     )
    )
    (local.get $1)
   )
  )
  (call $foreign2
   (i64.const 1)
   (local.tee $1
    (local.tee $2
     (struct.get $environment145 1
      (local.get $0)
     )
    )
   )
  )
  (call $foreign1
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready97)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global97)
   )
  )
  (if
   (i32.eqz
    (struct.get $type47 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $9
   (struct.get $type48 0
    (struct.get $type47 1
     (local.get $5)
    )
   )
  )
  (local.set $10
   (struct.new $type28
    (struct.new $type29
     (global.get $empty27)
    )
    (struct.new $type29
     (global.get $empty27)
    )
   )
  )
  (drop
   (if (result i32)
    (i64.le_s
     (local.get $1)
     (i64.const 0)
    )
    (then
     (i32.const 0)
    )
    (else
     (call $function285
      (struct.new $environment285
       (struct.get $environment279 0
        (local.get $9)
       )
       (local.get $10)
      )
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
  (call $foreign2
   (i64.const 2)
   (local.tee $1
    (struct.get $environment145 2
     (local.get $0)
    )
   )
  )
  (call $foreign1
   (i64.const 0)
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type39 1
   (local.tee $4
    (struct.new_default $type39)
   )
   (struct.new $type37
    (ref.func $function274)
    (struct.new $environment274
     (local.get $1)
     (local.tee $8
      (array.new_default $type50
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type39 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call37
    (struct.get $type37 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type39 1
        (local.get $4)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type37 0
     (local.get $7)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (call $foreign1
   (i64.const 1)
  )
  (call $foreign1
   (i64.const 2)
  )
  (call $foreign1
   (i64.const 0)
  )
  (struct.set $type39 1
   (local.tee $4
    (struct.new_default $type39)
   )
   (struct.new $type37
    (ref.func $function227)
    (struct.new $environment227
     (local.get $2)
     (local.get $4)
     (struct.new $type39
      (i32.const 1)
      (struct.new $type37
       (ref.func $function233)
       (struct.new $environment233
        (local.get $6)
        (local.get $5)
        (struct.get $environment145 3
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
  (struct.set $type39 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call37
    (struct.get $type37 1
     (local.tee $7
      (ref.as_non_null
       (struct.get $type39 1
        (local.get $4)
       )
      )
     )
    )
    (i64.const 4)
    (struct.get $type37 0
     (local.get $7)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready95)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global95)
   )
  )
  (if
   (i32.eqz
    (global.get $ready213)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type34 1
    (global.get $global213)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (select
      (i64.const 1000)
      (local.tee $1
       (i64.sub
        (i64.shr_u
         (i64.extend_i32_u
          (array.len
           (local.get $8)
          )
         )
         (i64.const 1)
        )
        (i64.const 1)
       )
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 1000)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (f64.ne
    (array.get $type50
     (local.get $8)
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (block (result f64)
     (if
      (i32.eqz
       (global.get $ready102)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global102)
      )
     )
     (f64.div
      (f64.const 1)
      (f64.convert_i64_s
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
   )
   (then
    (call $foreign1
     (i64.const 7)
    )
    (call $foreign1
     (i64.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (call $foreign1
   (i64.const 1)
  )
  (call $foreign1
   (i64.const 2)
  )
  (call $foreign1
   (i64.const 0)
  )
  (i32.const 0)
 )
 (func $function218 (type $call34) (param $0 (ref null $environment308)) (param $1 i64) (param $2 i64) (result i64)
  (select
   (local.get $1)
   (local.get $2)
   (i64.lt_s
    (local.get $1)
    (local.get $2)
   )
  )
 )
 (func $function227 (type $call37) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment227))
  (local $3 (ref $environment233))
  (local $4 i64)
  (if (result i32)
   (i64.lt_s
    (struct.get $environment227 0
     (ref.cast (ref $environment227)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment227 2
        (ref.cast (ref $environment227)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (call $function267
      (struct.get $type33 0
       (struct.get $type40 0
        (struct.get $environment233 2
         (local.tee $3
          (ref.cast (ref $environment233)
           (struct.get $type37 1
            (struct.get $type39 1
             (struct.get $environment227 2
              (local.tee $2
               (ref.cast (ref $environment227)
                (local.get $0)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (local.get $1)
     )
    )
    (drop
     (call $function238
      (struct.new $environment238
       (struct.get $environment233 0
        (local.get $3)
       )
       (struct.get $environment233 1
        (local.get $3)
       )
       (local.get $1)
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment227 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type39 1
       (struct.get $environment227 1
        (local.get $2)
       )
      )
     )
    )
    (return_call $function227
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 2)
     )
    )
   )
  )
 )
 (func $function233 (type $call37) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment233))
  (local $3 i64)
  (local.set $3
   (call $function267
    (struct.get $type33 0
     (struct.get $type40 0
      (struct.get $environment233 2
       (local.tee $2
        (ref.cast (ref $environment233)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
   )
  )
  (return_call $function238
   (struct.new $environment238
    (struct.get $environment233 0
     (local.get $2)
    )
    (struct.get $environment233 1
     (local.get $2)
    )
    (local.get $1)
   )
   (local.get $3)
  )
 )
 (func $function238 (type $6) (param $0 (ref $environment238)) (param $1 i64) (result i32)
  (local $2 (ref $type39))
  (local $3 (ref $type37))
  (call $foreign3
   (local.get $1)
   (struct.get $environment238 2
    (local.get $0)
   )
  )
  (call $foreign1
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (call $foreign1
   (i64.const 4)
  )
  (call $foreign1
   (i64.const 0)
  )
  (struct.set $type39 1
   (local.tee $2
    (struct.new_default $type39)
   )
   (struct.new $type37
    (ref.func $function262)
    (struct.new $environment262
     (struct.get $environment238 1
      (local.get $0)
     )
     (struct.get $environment238 2
      (local.get $0)
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type39 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call37
    (struct.get $type37 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type39 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type37 0
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (call $foreign1
   (i64.const 5)
  )
  (call $foreign1
   (i64.const 0)
  )
  (struct.set $type39 1
   (local.tee $2
    (struct.new_default $type39)
   )
   (struct.new $type37
    (ref.func $function252)
    (struct.new $environment252
     (struct.get $environment238 0
      (local.get $0)
     )
     (struct.get $environment238 2
      (local.get $0)
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type39 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call37
   (struct.get $type37 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type39 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type37 0
    (local.get $3)
   )
  )
 )
 (func $function252 (type $call37) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment252))
  (local $3 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $environment252 2
     (ref.cast (ref $environment252)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $environment252 1
      (local.tee $2
       (ref.cast (ref $environment252)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type45 0
       (struct.get $environment252 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function290
      (struct.get $type46 0
       (struct.get $type45 1
        (struct.get $environment252 0
         (local.get $2)
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment252 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type39 1
       (struct.get $environment252 3
        (local.get $2)
       )
      )
     )
    )
    (return_call $function252
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function262 (type $call37) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment262))
  (local $3 (ref $type28))
  (local $4 (ref $environment279))
  (local $5 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $environment262 2
     (ref.cast (ref $environment262)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $5
     (struct.get $environment262 1
      (local.tee $2
       (ref.cast (ref $environment262)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready97)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global97)
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment262 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.new $type28
      (struct.new $type29
       (global.get $empty27)
      )
      (struct.new $type29
       (global.get $empty27)
      )
     )
    )
    (local.set $4
     (struct.get $type48 0
      (struct.get $type47 1
       (struct.get $environment262 0
        (local.get $2)
       )
      )
     )
    )
    (drop
     (if (result i32)
      (i64.le_s
       (local.get $5)
       (i64.const 0)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $function285
        (struct.new $environment285
         (struct.get $environment279 0
          (local.get $4)
         )
         (local.get $3)
        )
        (i64.sub
         (local.get $5)
         (i64.const 1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment262 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type39 1
       (struct.get $environment262 3
        (local.get $2)
       )
      )
     )
    )
    (return_call $function262
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function267 (type $call33) (param $0 (ref null $environment267)) (param $1 i64) (result i64)
  (local $2 (ref $type55))
  (local $3 (ref $type34))
  (local $4 i64)
  (local.set $4
   (struct.get $environment267 0
    (local.get $0)
   )
  )
  (drop
   (struct.get $environment267 1
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready298)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type33 0
    (global.get $global298)
   )
  )
  (struct.set $type55 1
   (local.tee $2
    (struct.new_default $type55)
   )
   (struct.new $type34
    (ref.func $function308)
    (struct.new $environment308
     (local.get $2)
    )
   )
  )
  (struct.set $type55 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type55 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.div_s
   (i64.shl
    (i64.sub
     (call_ref $call34
      (struct.get $type34 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type55 1
          (local.get $2)
         )
        )
       )
      )
      (i64.add
       (local.get $4)
       (i64.const 1)
      )
      (i64.const 1)
      (struct.get $type34 0
       (local.get $3)
      )
     )
     (i64.const 1)
    )
    (block (result i64)
     (drop
      (struct.get $environment267 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready298)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (struct.get $type33 0
       (global.get $global298)
      )
     )
     (struct.set $type55 1
      (local.tee $2
       (struct.new_default $type55)
      )
      (struct.new $type34
       (ref.func $function308)
       (struct.new $environment308
        (local.get $2)
       )
      )
     )
     (struct.set $type55 0
      (local.get $2)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type55 0
        (local.get $2)
       )
      )
      (then
       (unreachable)
      )
     )
     (i64.const 1)
    )
   )
   (i64.sub
    (call_ref $call34
     (struct.get $type34 1
      (local.tee $3
       (ref.as_non_null
        (struct.get $type55 1
         (local.get $2)
        )
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (i64.const 1)
     (struct.get $type34 0
      (local.get $3)
     )
    )
    (i64.const 1)
   )
  )
 )
 (func $function274 (type $call37) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type50))
  (local $3 (ref $environment274))
  (if (result i32)
   (i64.le_s
    (i64.div_s
     (struct.get $environment274 0
      (ref.cast (ref $environment274)
       (local.get $0)
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type50
     (struct.get $environment274 1
      (ref.cast (ref $environment274)
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready102)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global102)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (f64.div
      (f64.const 1)
      (f64.convert_i64_s
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment274 2
        (ref.cast (ref $environment274)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type39 1
       (struct.get $environment274 2
        (local.tee $3
         (ref.cast (ref $environment274)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (return_call $function274
     (local.get $3)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function285 (type $2) (param $0 (ref $environment285)) (param $1 i64) (result i32)
  (local $2 (ref $type26))
  (local $3 (ref $environment279))
  (if
   (i32.eqz
    (global.get $ready97)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global97)
   )
  )
  (if
   (i32.eqz
    (global.get $ready100)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global100)
   )
  )
  (if
   (ref.test (ref $type27)
    (local.tee $2
     (struct.get $environment285 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 0
    (ref.cast (ref $type28)
     (local.get $2)
    )
   )
   (struct.new $type28
    (struct.new $type29
     (global.get $empty27)
    )
    (struct.new $type29
     (global.get $empty27)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready97)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global97)
   )
  )
  (if
   (i32.eqz
    (global.get $ready101)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (ref.test (ref $type27)
    (local.tee $2
     (struct.get $environment285 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (ref.cast (ref $type28)
     (local.get $2)
    )
   )
   (struct.new $type28
    (struct.new $type29
     (global.get $empty27)
    )
    (struct.new $type29
     (global.get $empty27)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (if
   (ref.test (ref $type27)
    (local.tee $2
     (struct.get $environment285 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type29 0
    (struct.get $type28 0
     (ref.cast (ref $type28)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type47 0
     (struct.get $environment285 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type48 0
    (struct.get $type47 1
     (struct.get $environment285 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (if (result i32)
    (i64.le_s
     (local.get $1)
     (i64.const 0)
    )
    (then
     (i32.const 0)
    )
    (else
     (call $function285
      (struct.new $environment285
       (struct.get $environment279 0
        (local.get $3)
       )
       (local.get $2)
      )
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready99)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global99)
   )
  )
  (if
   (ref.test (ref $type27)
    (local.tee $2
     (struct.get $environment285 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type29 0
    (struct.get $type28 1
     (ref.cast (ref $type28)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type47 0
     (struct.get $environment285 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type48 0
    (struct.get $type47 1
     (struct.get $environment285 0
      (local.get $0)
     )
    )
   )
  )
  (if (result i32)
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (return_call $function285
     (struct.new $environment285
      (struct.get $environment279 0
       (local.get $3)
      )
      (local.get $2)
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function290 (type $1) (param $0 (ref $environment290)) (param $1 i64) (result (ref $type28))
  (local $2 (ref $type45))
  (local $3 (ref $type28))
  (local $4 (ref $type28))
  (local $scratch (ref $type28))
  (if (result (ref $type28))
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready97)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global97)
     )
    )
    (struct.new $type28
     (struct.new $type29
      (global.get $empty27)
     )
     (struct.new $type29
      (global.get $empty27)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type45 0
       (struct.get $environment290 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type45 1
       (local.tee $2
        (struct.get $environment290 0
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.new $type28
     (struct.new $type29
      (block (result (ref $type28))
       (local.set $scratch
        (call $function290
         (local.get $0)
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (struct.get $type45 0
          (local.get $2)
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (struct.get $type45 1
          (struct.get $environment290 0
           (local.get $0)
          )
         )
        )
       )
       (local.set $4
        (call $function290
         (local.get $0)
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready97)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global97)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.new $type29
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function308 (type $call34) (param $0 (ref null $environment308)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $environment308))
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment308 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type55 1
       (struct.get $environment308 0
        (local.tee $3
         (ref.as_non_null
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (return_call $function308
     (local.get $3)
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (i64.shl
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type39))
  (local $2 (ref $type37))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type33 0
    (global.get $global106)
   )
  )
  (struct.set $type39 1
   (local.tee $1
    (struct.new_default $type39)
   )
   (struct.new $type37
    (ref.func $function117)
    (struct.new $environment117
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type39 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call37
    (struct.get $type37 1
     (local.tee $2
      (ref.as_non_null
       (struct.get $type39 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type37 0
     (local.get $2)
    )
   )
  )
  (i64.const 1)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global95
   (struct.new_default $type25)
  )
  (global.set $ready95
   (i32.const 1)
  )
  (global.set $global97
   (struct.new_default $type30)
  )
  (global.set $ready97
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type31)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global99
   (struct.new_default $type31)
  )
  (global.set $ready99
   (i32.const 1)
  )
  (global.set $global100
   (struct.new_default $type32)
  )
  (global.set $ready100
   (i32.const 1)
  )
  (global.set $global101
   (struct.new_default $type32)
  )
  (global.set $ready101
   (i32.const 1)
  )
  (global.set $global298
   (struct.new_default $type33)
  )
  (global.set $ready298
   (i32.const 1)
  )
  (global.set $global213
   (struct.new $type34
    (ref.func $function218)
    (ref.null none)
   )
  )
  (global.set $ready213
   (i32.const 1)
  )
  (global.set $global102
   (struct.new_default $type35)
  )
  (global.set $ready102
   (i32.const 1)
  )
  (global.set $global122
   (struct.new $type34
    (ref.func $function123)
    (ref.null none)
   )
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type36)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type10)
  )
  (global.set $ready103
   (i32.const 1)
  )
  (global.set $global104
   (struct.new $type37
    (ref.func $function129)
    (ref.null none)
   )
  )
  (global.set $ready104
   (i32.const 1)
  )
  (global.set $global105
   (call $foreign4
    (i32.const 0)
   )
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type33)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

