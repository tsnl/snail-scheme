#!/usr/bin/env python3
import json, os, pathlib, sys, time
root = pathlib.Path('/tmp/sfir-native-cpu-rootproof-evidence-20261016')
work = pathlib.Path('/tmp/sfir-native-cpu-rootproof-20261016')
manifest = json.loads(pathlib.Path('/tmp/sfir-native-production-six-20261016/candidate/manifest.json').read_text())
kind = pathlib.Path(sys.argv[0]).name
args = sys.argv[1:]
cpu = os.environ.get('SNAIL_PROBE_CPU', '')
mode = os.environ.get('SNAIL_PROBE_MODE', 'generic')
if kind == 'rustc-wrapper':
    target = '--target' in args and args[args.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    if cpu and target:
        args += ['-C', 'target-cpu=' + cpu]
    if target and '--crate-type' in args and args[args.index('--crate-type') + 1] == 'bin':
        args += ['-C', 'link-arg=--save-temps']
    command = [str(work / 'wasm-native/scripts/rustc-native'), *args]
elif kind == 'cargo-wrapper':
    if '--target-dir' in args:
        args[args.index('--target-dir') + 1] = str(root / 'targets' / mode)
    command = [manifest['tools']['CARGO']['path'], *args]
elif kind in ('opt-wrapper', 'llc-wrapper'):
    tool = 'LLVM_OPT' if kind == 'opt-wrapper' else 'LLC'
    command = [manifest['tools'][tool]['path'], *(['-mcpu=' + cpu] if cpu else []), *args]
else:
    raise RuntimeError(kind)
log = root / 'commands' / ('wrapper-' + mode + '-' + kind + '-' + str(os.getpid()) + '-' + str(time.time_ns()) + '.json')
log.write_text(json.dumps({'command':command, 'cwd':os.getcwd(), 'cpu':cpu, 'mode':mode}, indent=2) + '\n')
os.execvpe(command[0], command, os.environ)
