#!/usr/bin/env python3
import json, re, shutil
import probe as m
for mode in ['generic','x86-64-v3','arrowlake-s']:
    case=m.ROOT/'cases'/mode/'mbrot'
    if not (case/'program.native').exists(): continue
    retained=next(case.glob('program.native.native-*'))
    name=(retained/'Cargo.toml').read_text().split('name = ',1)[1].split('\n',1)[0].strip('"')
    proof={'cpu':None if mode=='generic' else mode, 'stages':{}}
    for stage in ['0.0.preopt','0.5.precodegen']:
        output=case/(stage+'.ll')
        if not output.exists():
            source=next((m.ROOT/'targets'/mode/'x86_64-unknown-linux-gnu/release/deps').glob(name+'-*.'+stage+'.bc'))
            bitcode=case/(stage+'.bc');shutil.copy2(source,bitcode)
            m.run('dump-'+mode+'-mbrot-'+stage,[m.MANIFEST['tools']['LLVM_OPT']['path'],'-S',bitcode,'-o',output],m.ROOT,m.env_for(mode))
        ll=output.read_text()
        flags=[line.strip() for line in ll.splitlines() if any(w in line.split() for w in ['fast','contract','reassoc','afn','nsz','nnan','ninf','arcp']) and any(op in line for op in ['fmul','fadd','fsub','fdiv'])]
        assert not flags,(mode,stage,flags)
        attrs={a[1]:a[2] for a in re.finditer(r'^attributes #(\d+) = (.*)$',ll,re.M)}
        chosen={}
        for label,pattern in [('guest_f5',r'^define[^\n]*@f\.5\([^\n]*$'),('native_array_new',r'^define[^\n]*@native_array_new\([^\n]*$'),('input_i64',r'^define[^\n]*@input_i64\([^\n]*$'),('entry',r'^define[^\n]*3run17h[^\n]*$')]:
            match=re.search(pattern,ll,re.M)
            if match:
                line=match[0];attribute=re.search(r'#(\d+)',line);chosen[label]={'definition':line,'attributes':attrs.get(attribute[1]) if attribute else None}
        if mode!='generic':
            for label,value in chosen.items():
                assert '"target-cpu"="'+mode+'"' in (value['attributes'] or ''),(mode,stage,label,value)
        proof['stages'][stage]={'fast_fp_flags':flags,'attributes':chosen,'bitcode_sha256':m.digest(case/(stage+'.bc')),'llvm_sha256':m.digest(output)}
    (case/'codegen-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    print('LTO STRICT FP VERIFIED',mode,flush=True)
