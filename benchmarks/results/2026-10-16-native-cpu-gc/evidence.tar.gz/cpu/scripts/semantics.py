#!/usr/bin/env python3
import json, pathlib
import probe as m

mode = 'x86-64-v3'
env = m.env_for(mode)
case = m.ROOT / 'strict-semantics' / mode
case.mkdir(parents=True, exist_ok=False)
chibi = m.MANIFEST['tools']['CHIBI']['path']
m.run('semantics-emit', [chibi, '-I', m.WORK/'wasm-native/scheme', m.WORK/'tests/build-native-datums.scm', case], m.WORK, env)
features = ['--mvp-features', '--enable-gc', '--enable-reference-types', '--enable-tail-call', '--enable-mutable-globals', '--enable-sign-ext', '--enable-bulk-memory', '--enable-nontrapping-float-to-int']
m.run('semantics-assemble', [m.MANIFEST['tools']['WASM_AS']['path'], '-g', *features, case/'semantics.wat', '-o', case/'semantics.wasm'], m.WORK, env)
m.run('semantics-v8', [m.MANIFEST['tools']['NODE']['path'], m.WORK/'tests/check-native-semantics.mjs', case/'semantics.wasm', case/'saturation.json'], m.WORK, env)
shared = m.WORK / 'wasm-native/build/native-programs'
if shared.is_symlink(): shared.unlink()
shared.symlink_to(m.ROOT/'targets'/mode, target_is_directory=True)
m.run('semantics-build-'+mode, [m.WORK/'scripts/build-native', '--wasm', '--entry-rust', m.WORK/'tests/native-runner.rs', case/'semantics.wasm', case/'semantics.native'], m.WORK, env)
m.run('semantics-native-'+mode, [case/'semantics.native'], case, dict(env, SNAIL_NATIVE_GC_INTERVAL='1'))
for index, sample in enumerate(json.loads((case/'saturation.json').read_text())):
    logs = m.run('semantics-saturate-'+str(index), [case/'semantics.native', 'saturate', sample['input']], case, env)
    assert (logs/'stdout').read_text() == ' '.join(sample['results'])+'\n'
for kind in [*map(str, range(13)), 'subtype-trap']:
    logs = m.run('semantics-trap-'+kind, [case/'semantics.native', kind], case, env, expected=1)
    assert 'WebAssembly trap' in (logs/'stderr').read_text()
for kind in range(5):
    logs = m.run('semantics-storage-trap-'+str(kind), [case/'semantics.native', 'storage-trap', str(kind)], case, env, expected=1)
    assert 'WebAssembly trap' in (logs/'stderr').read_text()
for reference, operations in [('null',[0,1,2]), ('i31',[0,1,2]), ('empty',[1,2]), ('upper',[1,2])]:
    for operation in operations:
        logs = m.run('semantics-storage-access-'+reference+'-'+str(operation), [case/'semantics.native', 'storage-access-trap', reference, str(operation)], case, env, expected=1)
        assert 'WebAssembly trap' in (logs/'stderr').read_text()
(case/'passed.json').write_text(json.dumps({'cpu':mode, 'semantics':'passed with forced GC', 'saturation_cases':len(json.loads((case/'saturation.json').read_text())), 'trap_cases':29}, indent=2)+'\n')
print('STRICT SEMANTICS PASSED', flush=True)
