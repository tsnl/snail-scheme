#!/usr/bin/env python3
import hashlib, json, os, pathlib, shutil, subprocess, sys, time
ROOT = pathlib.Path('/tmp/sfir-native-cpu-rootproof-evidence-20261016')
WORK = pathlib.Path('/tmp/sfir-native-cpu-rootproof-20261016')
FROZEN = pathlib.Path('/tmp/sfir-native-production-six-20261016/candidate')
MANIFEST = json.loads((FROZEN / 'manifest.json').read_text())

def env_for(mode):
    env = os.environ.copy()
    for k, v in MANIFEST['execution_environment'].items():
        if v is None: env.pop(k, None)
        else: env[k] = str(v)
    for k, v in MANIFEST['tools'].items(): env[k] = v['path']
    env['RUSTC_WRAPPER'] = str(ROOT / 'scripts/rustc-wrapper')
    env['CARGO'] = str(ROOT / 'scripts/cargo-wrapper')
    env['LLVM_OPT'] = str(ROOT / 'scripts/opt-wrapper')
    env['LLC'] = str(ROOT / 'scripts/llc-wrapper')
    env['SNAIL_PROBE_MODE'] = mode
    env['SNAIL_PROBE_CPU'] = '' if mode == 'generic' else mode
    return env

def run(name, command, cwd, env, timeout=1800, expected=0):
    logs = ROOT / 'commands' / name
    logs.mkdir(parents=True, exist_ok=False)
    selected = {k: v for k, v in env.items() if k in MANIFEST['execution_environment'] or k in MANIFEST['tools'] or k.startswith('SNAIL_PROBE_')}
    (logs / 'command.json').write_text(json.dumps({'command':list(map(str, command)), 'cwd':str(cwd), 'environment':selected, 'timing_class':'contended diagnostic'}, indent=2) + '\n')
    env = dict(env, SNAIL_PROCESS_RECORD=str(logs / 'terminal.json'))
    supervisor = MANIFEST['execution_environment']['SNAIL_NATIVE_SUPERVISOR']
    start = time.monotonic()
    with (logs / 'stdout').open('wb') as out, (logs / 'stderr').open('wb') as err:
        completed = subprocess.run([supervisor, '--command', str(timeout * 1000), '--', *map(str, command)], cwd=cwd, env=env, stdout=out, stderr=err)
    (logs / 'result.json').write_text(json.dumps({'returncode':completed.returncode, 'wall_seconds':time.monotonic()-start}, indent=2) + '\n')
    print(name, 'rc', completed.returncode, 'stdout', (logs / 'stdout').read_text()[-2000:], 'stderr', (logs / 'stderr').read_text()[-2000:], flush=True)
    if completed.returncode != expected: raise RuntimeError(name)
    terminal = json.loads((logs / 'terminal.json').read_text())
    if not terminal.get('descendants_gone'): raise RuntimeError(terminal)
    return logs

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def build(mode, case):
    target = ROOT / 'cases' / mode / case
    target.mkdir(parents=True, exist_ok=False)
    shared = WORK / 'wasm-native/build/native-programs'
    destination = ROOT / 'targets' / mode
    destination.mkdir(parents=True, exist_ok=True)
    if shared.is_symlink(): shared.unlink()
    elif shared.exists(): shared.rmdir()
    else: shared.parent.mkdir(parents=True, exist_ok=True)
    shared.symlink_to(destination, target_is_directory=True)
    original = FROZEN / 'timing/artifacts' / case
    names = ['case-config.rs', 'scalar-timing-entry.rs', 'scalar-provider.rs', 'input.txt', 'spec.json', 'program.wasm.raw.wasm', 'program.wasm']
    for name in names: shutil.copy2(original / name, target / name)
    command = [WORK / 'scripts/build-native', '--wasm', '--entry-rust', target / 'scalar-timing-entry.rs', '--rust-provider', 'benchmark', target / 'scalar-provider.rs', target / 'program.wasm.raw.wasm', target / 'program.native']
    run('build-' + mode + '-' + case + '-' + str(time.time_ns()), command, target, env_for(mode))
    retained = list(target.glob('program.native.native-*'))
    assert len(retained) == 1
    assert (retained[0] / 'optimized.wasm').read_bytes() == (original / 'program.wasm').read_bytes()
    if mode != 'generic':
        control = next((ROOT / 'cases/generic' / case).glob('program.native.native-*/module.ll'))
        assert (retained[0] / 'module.ll').read_bytes() == control.read_bytes()
    parity = {name:digest(target / name) for name in names + ['program.native']}
    parity['optimized.wasm'] = digest(retained[0] / 'optimized.wasm')
    parity['module.ll'] = digest(retained[0] / 'module.ll')
    parity['prior_lowering_module.ll'] = digest(next(original.glob('program.native.native-*/module.ll')))
    parity['source_revision'] = '506b5f9649b9a28260af70e472ad63a48b01994b'
    (target / 'parity.json').write_text(json.dumps(parity, indent=2) + '\n')
    print('PARITY', mode, case, parity['program.native'], flush=True)

if __name__ == '__main__':
    action, mode, *cases = sys.argv[1:]
    if action == 'build':
        for case in cases: build(mode, case)
    elif action == 'run':
        for case in cases:
            target = ROOT / 'cases' / mode / case
            run('run-' + mode + '-' + case + '-' + str(time.time_ns()), [target / 'program.native'], target, env_for(mode))
    else: raise RuntimeError(action)
