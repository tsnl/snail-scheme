#!/usr/bin/env python3
import hashlib, json, pathlib, re
import probe as m

SOURCE='506b5f9649b9a28260af70e472ad63a48b01994b'
CASES=['fib','fibfp','mbrot','array1','bv2string','gcbench']
OLD=pathlib.Path('/tmp/sfir-native-cpu-codegen-evidence-20261016')
old_identities=json.loads((m.ROOT/'prior-evidence-identities.json').read_text())
assert all(m.digest(pathlib.Path(p))==h for p,h in old_identities.items())
old_manifest=json.loads((OLD/'evidence-manifest.json').read_text())
assert all(m.digest(OLD/p)==h for p,h in old_manifest['file_sha256'].items())
(m.ROOT/'prior-evidence-preserved.json').write_text(json.dumps({'manifest_sha256':m.digest(OLD/'evidence-manifest.json'),'recorded_files_verified_unchanged':len(old_manifest['file_sha256']),'selected_script_identities_unchanged':True},indent=2)+'\n')
m.run('worktree-final-status',[m.MANIFEST['tools']['GIT']['path'],'--no-optional-locks','status','--porcelain'],m.WORK,m.env_for('generic'))
assert not (m.ROOT/'commands/worktree-final-status/stdout').read_text()
m.run('worktree-source-revision',[m.MANIFEST['tools']['GIT']['path'],'rev-parse','HEAD'],m.WORK,m.env_for('generic'))
assert (m.ROOT/'commands/worktree-source-revision/stdout').read_text().strip()==SOURCE
rows=[]
for mode in ['generic','x86-64-v3','arrowlake-s']:
    for case in (CASES if mode!='arrowlake-s' else ['mbrot']):
        directory=m.ROOT/'cases'/mode/case
        original=m.FROZEN/'timing/artifacts'/case
        retained=next(directory.glob('program.native.native-*'))
        for name in ['case-config.rs','scalar-provider.rs','scalar-timing-entry.rs','input.txt','spec.json','program.wasm.raw.wasm','program.wasm']:
            assert (directory/name).read_bytes()==(original/name).read_bytes(),(mode,case,name)
        assert (retained/'optimized.wasm').read_bytes()==(original/'program.wasm').read_bytes()
        control=next((m.ROOT/'cases/generic'/case).glob('program.native.native-*/module.ll'))
        assert (retained/'module.ll').read_bytes()==control.read_bytes()
        cfg=(directory/'case-config.rs').read_text();assert 'pub const OBSERVE_BARRIERS: bool = false;' in cfg
        count=int(re.search(r'CONFIGURED_COUNT: i64 = (\d+)',cfg)[1])
        logs=list((m.ROOT/'commands').glob('run-'+mode+'-'+case+'-*'));assert len(logs)==1
        stdout=(logs[0]/'stdout').read_text();result=json.loads([l for l in stdout.splitlines() if l.startswith('{')][-1])
        (directory/'program.native').chmod(0o555)
        rows.append({'mode':mode,'build_cpu':None if mode=='generic' else mode,'case':case,'source_revision':SOURCE,'command':[str(directory/'program.native')],'cwd':str(directory),'sha256':m.digest(directory/'program.native'),'elf_mode':'0555','raw_wasm_sha256':m.digest(directory/'program.wasm.raw.wasm'),'optimized_wasm_sha256':m.digest(retained/'optimized.wasm'),'module_ll_sha256':m.digest(retained/'module.ll'),'config_sha256':m.digest(directory/'case-config.rs'),'provider_sha256':m.digest(directory/'scalar-provider.rs'),'entry_sha256':m.digest(directory/'scalar-timing-entry.rs'),'configured_count':count,'expected_result':result['result'],'diagnostic_result':result,'diagnostic_command_directory':str(logs[0])})
terminals=list((m.ROOT/'commands').glob('*/terminal.json'))
assert all(json.loads(q.read_text()).get('descendants_gone') and not json.loads(q.read_text()).get('timed_out') and not json.loads(q.read_text()).get('unexpected_descendants') for q in terminals)
summary=json.loads((m.ROOT/'assembly-summary.json').read_text())
for case in CASES:
    pair=[next(r for r in summary if r['case']==case and r['cpu']==mode) for mode in ['generic','x86-64-v3']]
    graphs=[[(f['function'],len(f['backward_branches']),f['calls']) for f in r['functions']] for r in pair]
    assert graphs[0]==graphs[1],case
    assert all(r['FMA_in_guest_functions']==0 for r in pair),case
assert all(r['FMA_in_guest_functions']==0 for r in summary)
strict=json.loads((m.ROOT/'strict-semantics/x86-64-v3/passed.json').read_text())
plan={'status':'ready for parent-coordinated paired timing; no clean timing performed','source_revision':SOURCE,'cases':CASES,'suggested_cpu':2,'supervisor':m.MANIFEST['execution_environment']['SNAIL_NATIVE_SUPERVISOR'],'execution_environment':m.MANIFEST['execution_environment'],'native_pairs':[r for r in rows if r['mode']!='arrowlake-s'],'mbrot_arrowlake_control':next(r for r in rows if r['mode']=='arrowlake-s'),'v8_reference_commands':[{'case':r['case'],'command':r['command']} for r in json.loads((m.FROZEN/'timing/plan.json').read_text())['rows'] if r['route']=='sfir-wasm']}
(m.ROOT/'paired-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(m.ROOT/'selected-tools.json').write_text(json.dumps({'tools':m.MANIFEST['tools'],'execution_environment':m.MANIFEST['execution_environment'],'source_revision':SOURCE,'frozen_input_source_revision':m.MANIFEST['source_revision'],'host_cpu':'arrowlake-s','timing_class':'contended diagnostic'},indent=2)+'\n')
report='''Root-proof CPU/code generation probe, 2026-10-16

Clean isolated worktree: /tmp/sfir-native-cpu-rootproof-20261016 at 506b5f9649b9a28260af70e472ad63a48b01994b (landed root-proof PR287). No product edits or commits. The previous probe worktree/artifacts remain untouched; every one of the original evidence manifest's 1179 recorded files was verified unchanged.

Fresh pair: generic portable versus explicit x86-64-v3, all six cases. Additional arrowlake-s control: mbrot only. All thirteen executable files have fixed SHA256 identities in paired-plan.json and evidence-manifest.json and are mode 0555.

All immutable f320 raw/optimized Wasm, opaque black_box provider, scalar timing entry, full canonical config/count/input/spec bytes match the originals. Every fresh native build repeats mandatory Binaryen and its optimized Wasm matches the original exactly. New generic/v3/arrow module.ll files match one another per case. Their differences from older lowering are deliberate and recorded in lowering-root-frame-counts.json (root enters decrease in every case).

CPU selection uses external wrappers only: guest opt -mcpu=VALUE; target Rust -C target-cpu=VALUE at shared final fat LTO; the saved-object llc wrapper is configured with the same -mcpu (saved-object linking was not exercised). Generic supplies no CPU choice and retains production flags. Separate per-mode Cargo caches prevent an environment-only CPU wrapper change from reusing incompatible artifacts. Original wrapper artifacts were copied, never edited.

All 13 actual canonical full predicates pass, with OBSERVE_BARRIERS=false and no forced-GC/statistical instrumentation in their builds or runs. The fresh x86-64-v3 existing strict-semantics module passes forced collection, all 56 V8-matched conversion boundary inputs, 29 expected WebAssembly traps, and the newly landed noncollecting-root checks included by native-runner.rs.

Strict FP and retained work: full final assembly is saved for all 13 binaries. The generic/v3 guest function lists, backward-branch counts and call counts match for each of the six workloads; repeat drivers and kernel loops remain. Every guest FMA count is zero. Mandelbrot's configured 1000 count is visible in each final entry and its recurrence retains the 64 limit. Generic mbrot still packs squares into SSE mulpd and shuffles lanes. Both v3 and arrow select scalar AVX with separate multiply/add/subtract; arrow additionally unrolls the recurrence twice, while v3 keeps one recurrence per iteration. Saved final-LTO preopt/precodegen bitcode and text for all three mbrot controls prove the selected guest/runtime/provider/entry CPU attributes and contain no fast/contract/reassoc/afn/nsz/nnan/ninf/arcp FP flags.

No clean timing was run. Each number below is one unpinned, potentially contended execution, collected only while checking the actual predicate. Parent coordination is required before a performance claim.
'''
for case in CASES:
    pair=[next(r for r in rows if r['mode']==mode and r['case']==case) for mode in ['generic','x86-64-v3']]
    report+=f"{case}: generic {pair[0]['diagnostic_result']['seconds']:.9f}s; x86-64-v3 {pair[1]['diagnostic_result']['seconds']:.9f}s\n"
report+='arrowlake-s mbrot diagnostic: '+str(next(r for r in rows if r['mode']=='arrowlake-s')['diagnostic_result']['seconds'])+'s\n'
report+='''
The optional native-library CPU build input remains a direction only; no source change or implicit host-only default is proposed here. See cpu-input-direction.json. All supervisor terminal records report descendants_gone=true, timed_out=false, and no unexpected descendants. All jobs were reaped before this handoff.
'''
(m.ROOT/'REPORT.txt').write_text(report)
files={}
for p in sorted(m.ROOT.rglob('*')):
    if not p.is_file() or p.name=='evidence-manifest.json' or '__pycache__' in p.parts or 'targets' in p.relative_to(m.ROOT).parts: continue
    files[str(p.relative_to(m.ROOT))]=m.digest(p)
manifest={'source_revision':SOURCE,'product_source_changes':False,'timing_class':'contended diagnostic; no clean timing performed','native_artifacts':rows,'strict_semantics':strict,'supervisor_terminal_records':len(terminals),'all_descendants_reaped':True,'prior_probe_files_unchanged':len(old_manifest['file_sha256']),'file_sha256':files}
(m.ROOT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('MANIFEST_SHA256',m.digest(m.ROOT/'evidence-manifest.json'))
print('READY_ELFS',len(rows),'TERMINALS',len(terminals),'HASHED_FILES',len(files),'OLD_FILES_UNCHANGED',len(old_manifest['file_sha256']))
for r in rows: print(r['mode'],r['case'],r['sha256'])
