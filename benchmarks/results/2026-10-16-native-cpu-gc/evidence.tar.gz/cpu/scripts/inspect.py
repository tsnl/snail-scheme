#!/usr/bin/env python3
import contextlib, io, json, pathlib, re
import probe as m
rows=[]
for mode in ['generic','x86-64-v3','arrowlake-s']:
    for case in ['fib','fibfp','mbrot','array1','bv2string','gcbench']:
        directory=m.ROOT/'cases'/mode/case
        if not (directory/'program.native').exists(): continue
        name='objdump-'+mode+'-'+case
        logs=m.ROOT/'commands'/name
        if not logs.exists():
            with contextlib.redirect_stdout(io.StringIO()):
                m.run(name,['llvm-objdump','-d','--no-show-raw-insn',directory/'program.native'],m.ROOT,m.env_for(mode))
        asm=(logs/'stdout').read_text()
        (directory/'program.asm').write_text(asm)
        functions=[]
        for part in re.split(r'(?=^[0-9a-f]+ <)',asm,flags=re.M):
            header=part.splitlines()[0] if part.splitlines() else ''
            match=re.search(r'<(f\.\d+)>:',header)
            if not match: continue
            branches=[]
            for line in part.splitlines():
                branch=re.search(r'^\s*([0-9a-f]+):\s+j\w*\s+0x([0-9a-f]+)',line)
                if branch and int(branch[2],16)<int(branch[1],16): branches.append(line)
            functions.append({'function':match[1], 'lines':len(part.splitlines()), 'backward_branches':branches, 'calls':sum('\tcallq' in l for l in part.splitlines())})
        row={'cpu':mode, 'case':case, 'functions':functions, 'FMA_in_guest_functions':sum('fmadd' in l or 'fmsub' in l for part in re.split(r'(?=^[0-9a-f]+ <)',asm,flags=re.M) if re.search(r'^\w+ <f\.\d+>:',part) for l in part.splitlines())}
        rows.append(row)
        (directory/'assembly-summary.json').write_text(json.dumps(row,indent=2)+'\n')
        print(mode,case,[(f['function'],len(f['backward_branches']),f['calls']) for f in functions], flush=True)
(m.ROOT/'assembly-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
