(module
 (type $bytes (array (mut i8)))
 (type $storage-u16 (array (mut i16)))
 (rec
  (type $parent (sub (struct (field i64) (field (mut (ref null $left))))))
  (type $left (sub final $parent (struct (field i64) (field (mut (ref null $left))))))
  (type $different (func (param i64) (result i64)))
  (type $short (func (param i32 eqref) (result eqref)))
  (type $refs (array (mut eqref)))
  (type $storage-f64 (array (mut f64)))
  (type $storage-f32 (array (mut f32)))
  (type $storage-i32 (array (mut i32)))
  (type $box (struct (field (mut i64)) (field (mut (ref null $box)))))
  (type $float-prefix (struct (field (mut (ref null $box)))))
 )
 (type $12 (func (result eqref)))
 (type $integer (func (param i32) (result i32)))
 (type $14 (func (param i32 i32) (result eqref)))
 (type $15 (func (param i32) (result i64)))
 (type $16 (func (result i64)))
 (type $17 (func (result i32)))
 (type $18 (func (param eqref) (result i32)))
 (type $19 (func (param f32) (result i32)))
 (type $20 (func (param f64) (result i32)))
 (type $21 (func (param f32) (result i64)))
 (type $22 (func (param f64) (result i64)))
 (type $23 (func (param i32)))
 (type $24 (func (param eqref) (result i64)))
 (type $25 (func))
 (type $26 (func (param i64) (result eqref)))
 (type $27 (func (param i32 i64) (result eqref)))
 (type $28 (func (param i32) (result eqref)))
 (type $29 (func (param (ref null $bytes) i32 i32) (result i32)))
 (global $float-static (ref $float-prefix) (struct.new_default $float-prefix))
 (global $mutable (ref $box) (struct.new $box
  (i64.const 10)
  (ref.null none)
 ))
 (global $ordering (mut i32) (i32.const 11))
 (global $negative (ref i31) (ref.i31
  (i32.const -1)
 ))
 (global $static-u8 (ref $bytes) (array.new_fixed $bytes 3
  (i32.const 255)
  (i32.const 4660)
  (i32.const 128)
 ))
 (global $static-u16 (ref $storage-u16) (array.new_fixed $storage-u16 3
  (i32.const 65535)
  (i32.const 74565)
  (i32.const 32768)
 ))
 (global $static-i32 (ref $storage-i32) (array.new_fixed $storage-i32 3
  (i32.const -1)
  (i32.const 42)
  (i32.const 2147483647)
 ))
 (global $static-f32 (ref $storage-f32) (array.new_default $storage-f32
  (i32.const 3)
 ))
 (global $global-f32-bits (ref $storage-f32) (array.new_fixed $storage-f32 2
  (f32.const -0)
  (f32.const nan:0x412345)
 ))
 (global $static-f64 (ref $storage-f64) (array.new_fixed $storage-f64 3
  (f64.const -0)
  (f64.const 1.5)
  (f64.const nan:0x8000000001234)
 ))
 (global $static-refs (ref $refs) (array.new_default $refs
  (i32.const 3)
 ))
 (global $default-u8 (ref $bytes) (array.new_default $bytes
  (i32.const 3)
 ))
 (global $default-u16 (ref $storage-u16) (array.new_default $storage-u16
  (i32.const 3)
 ))
 (global $default-i32 (ref $storage-i32) (array.new_default $storage-i32
  (i32.const 3)
 ))
 (global $storage-order (mut i32) (i32.const 0))
 (table $roots 1 4 eqref)
 (table $functions 2 2 funcref)
 (elem $0 (table $functions) (i32.const 0) func $cold.increment $identity64)
 (export "sat-i32-f32-s" (func $0))
 (export "sat-i32-f32-u" (func $1))
 (export "sat-i32-f64-s" (func $2))
 (export "sat-i32-f64-u" (func $3))
 (export "sat-i64-f32-s" (func $4))
 (export "sat-i64-f32-u" (func $5))
 (export "sat-i64-f64-s" (func $6))
 (export "sat-i64-f64-u" (func $7))
 (export "tail" (func $9))
 (export "root" (func $10))
 (export "tail-gc" (func $12))
 (export "gc-operands" (func $13))
 (export "gc-effects" (func $16))
 (export "i31-s" (func $19))
 (export "i31-u" (func $20))
 (export "i31-eq-negative" (func $21))
 (export "check" (func $22))
 (export "_start" (func $23))
 (export "trap" (func $24))
 (export "left" (func $25))
 (export "read-parent" (func $26))
 (export "read-right" (func $27))
 (export "same-left" (func $28))
 (export "is-right" (func $29))
 (export "cyclic" (func $30))
 (export "storage-u8" (func $31))
 (export "storage-u16" (func $32))
 (export "storage-i32" (func $33))
 (export "storage-f32" (func $34))
 (export "storage-f64" (func $35))
 (export "storage-refs" (func $36))
 (export "storage-static-u8" (func $37))
 (export "storage-static-u16" (func $38))
 (export "storage-static-i32" (func $39))
 (export "storage-static-f32" (func $40))
 (export "storage-static-f64" (func $41))
 (export "storage-global-f32-bits" (func $42))
 (export "storage-identity" (func $43))
 (export "storage-order" (func $44))
 (export "storage-access" (func $45))
 (export "storage-roots" (func $46))
 (export "storage-check" (func $47))
 (export "storage-trap" (func $48))
 (func $0 (param $0 f32) (result i32)
  (i32.trunc_sat_f32_s
   (local.get $0)
  )
 )
 (func $1 (param $0 f32) (result i32)
  (i32.trunc_sat_f32_u
   (local.get $0)
  )
 )
 (func $2 (param $0 f64) (result i32)
  (i32.trunc_sat_f64_s
   (local.get $0)
  )
 )
 (func $3 (param $0 f64) (result i32)
  (i32.trunc_sat_f64_u
   (local.get $0)
  )
 )
 (func $4 (param $0 f32) (result i64)
  (i64.trunc_sat_f32_s
   (local.get $0)
  )
 )
 (func $5 (param $0 f32) (result i64)
  (i64.trunc_sat_f32_u
   (local.get $0)
  )
 )
 (func $6 (param $0 f64) (result i64)
  (i64.trunc_sat_f64_s
   (local.get $0)
  )
 )
 (func $7 (param $0 f64) (result i64)
  (i64.trunc_sat_f64_u
   (local.get $0)
  )
 )
 (func $short (type $short) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (return_call $short
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $9 (param $0 i32) (result i64)
  (local $1 (ref $box))
  (local.set $1
   (struct.new $box
    (i64.const 42)
    (ref.null none)
   )
  )
  (struct.get $box 0
   (ref.cast (ref $box)
    (if (result eqref)
     (local.get $0)
     (then
      (if (result eqref)
       (local.tee $0
        (i32.sub
         (local.get $0)
         (i32.const 1)
        )
       )
       (then
        (if (result eqref)
         (local.tee $0
          (i32.sub
           (local.get $0)
           (i32.const 1)
          )
         )
         (then
          (if (result eqref)
           (local.tee $0
            (i32.sub
             (local.get $0)
             (i32.const 1)
            )
           )
           (then
            (if (result eqref)
             (local.tee $0
              (i32.sub
               (local.get $0)
               (i32.const 1)
              )
             )
             (then
              (if (result eqref)
               (local.tee $0
                (i32.sub
                 (local.get $0)
                 (i32.const 1)
                )
               )
               (then
                (if (result eqref)
                 (local.tee $0
                  (i32.sub
                   (local.get $0)
                   (i32.const 1)
                  )
                 )
                 (then
                  (if (result eqref)
                   (local.tee $0
                    (i32.sub
                     (local.get $0)
                     (i32.const 1)
                    )
                   )
                   (then
                    (if (result eqref)
                     (local.tee $0
                      (i32.sub
                       (local.get $0)
                       (i32.const 1)
                      )
                     )
                     (then
                      (if (result eqref)
                       (local.tee $0
                        (i32.sub
                         (local.get $0)
                         (i32.const 1)
                        )
                       )
                       (then
                        (if (result eqref)
                         (local.tee $0
                          (i32.sub
                           (local.get $0)
                           (i32.const 1)
                          )
                         )
                         (then
                          (if (result eqref)
                           (local.tee $0
                            (i32.sub
                             (local.get $0)
                             (i32.const 1)
                            )
                           )
                           (then
                            (if (result eqref)
                             (local.tee $0
                              (i32.sub
                               (local.get $0)
                               (i32.const 1)
                              )
                             )
                             (then
                              (if (result eqref)
                               (local.tee $0
                                (i32.sub
                                 (local.get $0)
                                 (i32.const 1)
                                )
                               )
                               (then
                                (call $short
                                 (i32.sub
                                  (local.get $0)
                                  (i32.const 1)
                                 )
                                 (local.get $1)
                                )
                               )
                               (else
                                (local.get $1)
                               )
                              )
                             )
                             (else
                              (local.get $1)
                             )
                            )
                           )
                           (else
                            (local.get $1)
                           )
                          )
                         )
                         (else
                          (local.get $1)
                         )
                        )
                       )
                       (else
                        (local.get $1)
                       )
                      )
                     )
                     (else
                      (local.get $1)
                     )
                    )
                   )
                   (else
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
               (else
                (local.get $1)
               )
              )
             )
             (else
              (local.get $1)
             )
            )
           )
           (else
            (local.get $1)
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
       (else
        (local.get $1)
       )
      )
     )
     (else
      (local.get $1)
     )
    )
   )
  )
 )
 (func $10 (param $0 i32) (result i64)
  (loop $label
   (br_if $label
    (local.tee $0
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
    )
   )
  )
  (i64.const 99)
 )
 (func $gc-hop (type $short) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (return_call $gc-hop
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $12 (param $0 i32) (result i64)
  (local $1 (ref $box))
  (local.set $1
   (struct.new $box
    (i64.const 42)
    (ref.null none)
   )
  )
  (struct.get $box 0
   (ref.cast (ref $box)
    (if (result eqref)
     (local.get $0)
     (then
      (if (result eqref)
       (local.tee $0
        (i32.sub
         (local.get $0)
         (i32.const 1)
        )
       )
       (then
        (if (result eqref)
         (local.tee $0
          (i32.sub
           (local.get $0)
           (i32.const 1)
          )
         )
         (then
          (if (result eqref)
           (local.tee $0
            (i32.sub
             (local.get $0)
             (i32.const 1)
            )
           )
           (then
            (if (result eqref)
             (local.tee $0
              (i32.sub
               (local.get $0)
               (i32.const 1)
              )
             )
             (then
              (if (result eqref)
               (local.tee $0
                (i32.sub
                 (local.get $0)
                 (i32.const 1)
                )
               )
               (then
                (if (result eqref)
                 (local.tee $0
                  (i32.sub
                   (local.get $0)
                   (i32.const 1)
                  )
                 )
                 (then
                  (if (result eqref)
                   (local.tee $0
                    (i32.sub
                     (local.get $0)
                     (i32.const 1)
                    )
                   )
                   (then
                    (if (result eqref)
                     (local.tee $0
                      (i32.sub
                       (local.get $0)
                       (i32.const 1)
                      )
                     )
                     (then
                      (if (result eqref)
                       (local.tee $0
                        (i32.sub
                         (local.get $0)
                         (i32.const 1)
                        )
                       )
                       (then
                        (if (result eqref)
                         (local.tee $0
                          (i32.sub
                           (local.get $0)
                           (i32.const 1)
                          )
                         )
                         (then
                          (if (result eqref)
                           (local.tee $0
                            (i32.sub
                             (local.get $0)
                             (i32.const 1)
                            )
                           )
                           (then
                            (if (result eqref)
                             (local.tee $0
                              (i32.sub
                               (local.get $0)
                               (i32.const 1)
                              )
                             )
                             (then
                              (if (result eqref)
                               (local.tee $0
                                (i32.sub
                                 (local.get $0)
                                 (i32.const 1)
                                )
                               )
                               (then
                                (call $gc-hop
                                 (i32.sub
                                  (local.get $0)
                                  (i32.const 1)
                                 )
                                 (local.get $1)
                                )
                               )
                               (else
                                (local.get $1)
                               )
                              )
                             )
                             (else
                              (local.get $1)
                             )
                            )
                           )
                           (else
                            (local.get $1)
                           )
                          )
                         )
                         (else
                          (local.get $1)
                         )
                        )
                       )
                       (else
                        (local.get $1)
                       )
                      )
                     )
                     (else
                      (local.get $1)
                     )
                    )
                   )
                   (else
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
               (else
                (local.get $1)
               )
              )
             )
             (else
              (local.get $1)
             )
            )
           )
           (else
            (local.get $1)
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
       (else
        (local.get $1)
       )
      )
     )
     (else
      (local.get $1)
     )
    )
   )
  )
 )
 (func $13 (result i64)
  (struct.set $float-prefix 0
   (global.get $float-static)
   (struct.new $box
    (i64.const 41)
    (ref.null none)
   )
  )
  (struct.set $box 1
   (global.get $mutable)
   (struct.new $box
    (i64.const 40)
    (ref.null none)
   )
  )
  (if
   (i64.ne
    (struct.get $box 0
     (struct.get $float-prefix 0
      (global.get $float-static)
     )
    )
    (i64.const 41)
   )
   (then
    (unreachable)
   )
  )
  (i64.add
   (struct.get $box 0
    (struct.get $box 1
     (global.get $mutable)
    )
   )
   (i64.const 2)
  )
 )
 (func $pure-even (type $short) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (call $pure-even
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $collect-even (type $short) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (call $collect-even
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $16 (result i64)
  (local $0 eqref)
  (drop
   (call $collect-even
    (i32.const 6)
    (local.tee $0
     (call $pure-even
      (i32.const 36)
      (struct.new $box
       (i64.const 42)
       (ref.null none)
      )
     )
    )
   )
  )
  (drop
   (call $collect-even
    (i32.const 6)
    (local.get $0)
   )
  )
  (drop
   (call $collect-even
    (i32.const 10)
    (local.get $0)
   )
  )
  (struct.get $box 0
   (ref.cast (ref $box)
    (local.get $0)
   )
  )
 )
 (func $cold.increment (param $0 i32) (result i32)
  (unreachable)
 )
 (func $identity64 (type $different) (param $0 i64) (result i64)
  (unreachable)
 )
 (func $19 (param $0 i32) (result i32)
  (i31.get_s
   (ref.i31
    (local.get $0)
   )
  )
 )
 (func $20 (param $0 i32) (result i32)
  (i31.get_u
   (ref.i31
    (local.get $0)
   )
  )
 )
 (func $21 (param $0 i32) (result i32)
  (ref.eq
   (global.get $negative)
   (ref.i31
    (local.get $0)
   )
  )
 )
 (func $22 (result i32)
  (local $0 (ref $refs))
  (if
   (i32.ne
    (i32.add
     (global.get $ordering)
     (block (result i32)
      (global.set $ordering
       (i32.const 22)
      )
      (i32.const 1)
     )
    )
    (i32.const 12)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $box 0
   (global.get $mutable)
   (i64.const 20)
  )
  (if
   (i64.ne
    (struct.get $box 0
     (global.get $mutable)
    )
    (i64.const 20)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $refs $refs
   (local.tee $0
    (array.new_fixed $refs 3
     (ref.i31
      (i32.const 10)
     )
     (global.get $negative)
     (ref.null none)
    )
   )
   (i32.const 1)
   (local.get $0)
   (i32.const 0)
   (i32.const 2)
  )
  (if
   (i32.ne
    (i31.get_s
     (ref.cast (ref i31)
      (array.get $refs
       (local.get $0)
       (i32.const 2)
      )
     )
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (table.grow $roots
     (global.get $mutable)
     (i32.const 2)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (table.grow $roots
     (ref.null none)
     (i32.const 2)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (ref.eq
     (table.get $roots
      (i32.const 2)
     )
     (global.get $mutable)
    )
   )
   (then
    (unreachable)
   )
  )
  (i32.const 0)
 )
 (func $23
  (drop
   (call $short
    (i32.const 86)
    (ref.i31
     (i32.const 42)
    )
   )
  )
 )
 (func $24 (param $0 i32)
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (drop
     (i64.div_s
      (i64.const -9223372036854775808)
      (i64.const -1)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 1)
   )
   (then
    (drop
     (i32.div_u
      (i32.const 1)
      (i32.const 0)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 2)
   )
   (then
    (drop
     (i64.trunc_f64_s
      (f64.const 9223372036854775808)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 3)
   )
   (then
    (drop
     (i32.trunc_f64_u
      (f64.const nan:0x8000000000000)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 4)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 5)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 7)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 8)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 9)
   )
   (then
    (drop
     (table.get $functions
      (i32.const 2)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 10)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 11)
   )
   (then
    (array.copy $refs $refs
     (array.new_default $refs
      (i32.const 1)
     )
     (i32.const 1)
     (array.new_default $refs
      (i32.const 1)
     )
     (i32.const 0)
     (i32.const 1)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 12)
   )
   (then
    (drop
     (i31.get_s
      (ref.null none)
     )
    )
   )
  )
 )
 (func $25 (param $0 i64) (result eqref)
  (local $1 (ref $left))
  (struct.set $left 1
   (local.tee $1
    (struct.new $left
     (local.get $0)
     (ref.null none)
    )
   )
   (local.get $1)
  )
  (local.get $1)
 )
 (func $26 (param $0 eqref) (result i64)
  (struct.get $parent 0
   (ref.cast (ref $parent)
    (local.get $0)
   )
  )
 )
 (func $27 (param $0 eqref) (result i64)
  (unreachable)
 )
 (func $28 (param $0 eqref) (result i32)
  (ref.test (ref $left)
   (local.get $0)
  )
 )
 (func $29 (param $0 eqref) (result i32)
  (i32.const 0)
 )
 (func $30 (param $0 eqref) (result i32)
  (local $1 (ref $parent))
  (ref.eq
   (local.tee $1
    (ref.cast (ref $parent)
     (local.get $0)
    )
   )
   (struct.get $parent 1
    (local.get $1)
   )
  )
 )
 (func $31 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $bytes
   (local.get $1)
   (local.get $0)
  )
 )
 (func $32 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $storage-u16
   (local.get $1)
   (local.get $0)
  )
 )
 (func $33 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $storage-i32
   (local.get $1)
   (local.get $0)
  )
 )
 (func $34 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $storage-f32
   (f32.reinterpret_i32
    (local.get $1)
   )
   (local.get $0)
  )
 )
 (func $35 (param $0 i32) (param $1 i64) (result eqref)
  (array.new $storage-f64
   (f64.reinterpret_i64
    (local.get $1)
   )
   (local.get $0)
  )
 )
 (func $36 (param $0 i32) (result eqref)
  (array.new_default $refs
   (local.get $0)
  )
 )
 (func $37 (result eqref)
  (global.get $static-u8)
 )
 (func $38 (result eqref)
  (global.get $static-u16)
 )
 (func $39 (result eqref)
  (global.get $static-i32)
 )
 (func $40 (result eqref)
  (global.get $static-f32)
 )
 (func $41 (result eqref)
  (global.get $static-f64)
 )
 (func $42 (result eqref)
  (global.get $global-f32-bits)
 )
 (func $43 (result i32)
  (i32.const 1)
 )
 (func $44 (result i32)
  (global.get $storage-order)
 )
 (func $45 (param $0 (ref null $bytes)) (param $1 i32) (param $2 i32) (result i32)
  (global.set $storage-order
   (i32.const 0)
  )
  (if (result i32)
   (local.get $2)
   (then
    (if (result i32)
     (i32.eq
      (local.get $2)
      (i32.const 1)
     )
     (then
      (global.set $storage-order
       (i32.const 1)
      )
      (array.get_u $bytes
       (local.get $0)
       (local.get $1)
      )
     )
     (else
      (global.set $storage-order
       (i32.const 1)
      )
      (global.set $storage-order
       (i32.const 2)
      )
      (array.set $bytes
       (local.get $0)
       (local.get $1)
       (i32.const 42)
      )
      (i32.const 42)
     )
    )
   )
   (else
    (array.len
     (local.get $0)
    )
   )
  )
 )
 (func $46 (result i64)
  (i64.const 77)
 )
 (func $47 (param $0 i32) (result i32)
  (local $1 (ref $bytes))
  (local $2 (ref $storage-u16))
  (local $3 (ref $storage-i32))
  (local $4 (ref $storage-f32))
  (local $5 (ref $storage-f64))
  (if
   (array.get_u $bytes
    (global.get $default-u8)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get_u $storage-u16
    (global.get $default-u16)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get $storage-i32
    (global.get $default-i32)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (array.set $bytes
   (local.tee $1
    (array.new $bytes
     (local.get $0)
     (i32.const 4)
    )
   )
   (i32.const 0)
   (i32.const 128)
  )
  (array.set $bytes
   (local.get $1)
   (i32.const 1)
   (i32.const 52)
  )
  (array.copy $bytes $bytes
   (local.get $1)
   (i32.const 1)
   (local.get $1)
   (i32.const 0)
   (i32.const 3)
  )
  (if
   (i32.ne
    (array.get_s $bytes
     (local.get $1)
     (i32.const 1)
    )
    (i32.const -128)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get_u $bytes
     (local.get $1)
     (i32.const 2)
    )
    (i32.const 52)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $bytes $bytes
   (local.get $1)
   (i32.const 0)
   (local.get $1)
   (i32.const 1)
   (i32.const 3)
  )
  (if
   (i32.ne
    (i32.and
     (local.get $0)
     (i32.const 255)
    )
    (array.get_u $bytes
     (local.get $1)
     (i32.const 2)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.copy $bytes $bytes
   (local.get $1)
   (i32.const 4)
   (local.get $1)
   (i32.const 4)
   (i32.const 0)
  )
  (array.copy $bytes $bytes
   (global.get $static-u8)
   (i32.const 0)
   (local.get $1)
   (i32.const 0)
   (i32.const 3)
  )
  (if
   (i32.ne
    (array.get_u $bytes
     (global.get $static-u8)
     (i32.const 1)
    )
    (i32.const 52)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $storage-u16 $storage-u16
   (local.tee $2
    (array.new_fixed $storage-u16 3
     (local.get $0)
     (i32.const 65535)
     (i32.const 74565)
    )
   )
   (i32.const 0)
   (local.get $2)
   (i32.const 1)
   (i32.const 2)
  )
  (if
   (i32.ne
    (array.get_s $storage-u16
     (local.get $2)
     (i32.const 0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get_u $storage-u16
     (local.get $2)
     (i32.const 1)
    )
    (i32.const 9029)
   )
   (then
    (unreachable)
   )
  )
  (array.set $storage-u16
   (global.get $static-u16)
   (i32.const 2)
   (i32.const 0)
  )
  (if
   (array.get_u $storage-u16
    (global.get $static-u16)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (array.set $storage-i32
   (local.tee $3
    (array.new $storage-i32
     (local.get $0)
     (i32.const 3)
    )
   )
   (i32.const 1)
   (i32.const -1)
  )
  (array.copy $storage-i32 $storage-i32
   (local.get $3)
   (i32.const 2)
   (local.get $3)
   (i32.const 1)
   (i32.const 1)
  )
  (if
   (i32.ne
    (array.get $storage-i32
     (local.get $3)
     (i32.const 2)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $storage-f32
   (local.tee $4
    (array.new $storage-f32
     (f32.const 1.5)
     (i32.const 3)
    )
   )
   (i32.const 1)
   (f32.const -0)
  )
  (array.copy $storage-f32 $storage-f32
   (global.get $static-f32)
   (i32.const 0)
   (local.get $4)
   (i32.const 0)
   (i32.const 3)
  )
  (if
   (i32.ne
    (i32.reinterpret_f32
     (array.get $storage-f32
      (global.get $static-f32)
      (i32.const 1)
     )
    )
    (i32.const -2147483648)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $storage-f64 $storage-f64
   (local.tee $5
    (array.new_default $storage-f64
     (i32.const 2)
    )
   )
   (i32.const 0)
   (global.get $static-f64)
   (i32.const 0)
   (i32.const 2)
  )
  (if
   (i64.ne
    (i64.reinterpret_f64
     (array.get $storage-f64
      (local.get $5)
      (i32.const 0)
     )
    )
    (i64.const -9223372036854775808)
   )
   (then
    (unreachable)
   )
  )
  (array.set $refs
   (global.get $static-refs)
   (i32.const 1)
   (struct.new $box
    (i64.const 42)
    (ref.null none)
   )
  )
  (if
   (i64.ne
    (struct.get $box 0
     (ref.cast (ref $box)
      (array.get $refs
       (global.get $static-refs)
       (i32.const 1)
      )
     )
    )
    (i64.const 42)
   )
   (then
    (unreachable)
   )
  )
  (i32.const 1)
 )
 (func $48 (param $0 i32)
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (drop
     (array.get_u $bytes
      (global.get $static-u8)
      (i32.const -1)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 1)
   )
   (then
    (array.set $storage-u16
     (global.get $static-u16)
     (i32.const 3)
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 2)
   )
   (then
    (array.copy $storage-i32 $storage-i32
     (global.get $static-i32)
     (i32.const 4)
     (global.get $static-i32)
     (i32.const 0)
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 3)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 4)
   )
   (then
    (array.copy $storage-u16 $storage-u16
     (global.get $static-u16)
     (i32.const 0)
     (global.get $static-u16)
     (i32.const -1)
     (i32.const 2)
    )
   )
  )
 )
)

