fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-cpu-rootproof-evidence-20261016/strict-semantics/x86-64-v3/semantics.native.native-60-0/module.bc");
}
