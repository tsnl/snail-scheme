unsafe extern "C" { fn native_module_init(); #[link_name = "wasm.main"] fn guest_main() -> i64; }
fn main() {
    snail_runtime::native::initialize_host();
    unsafe { native_module_init(); }
    let value = unsafe { guest_main() } as i64;
    let status = if (0..=255).contains(&value) { value as i32 } else { 1 };
    std::process::exit(snail_runtime::native::native_finish(status));
}

extern crate snail_runtime as _;
