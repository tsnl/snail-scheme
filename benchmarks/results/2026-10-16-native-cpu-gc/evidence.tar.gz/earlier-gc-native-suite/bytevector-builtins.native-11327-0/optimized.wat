(module
 (rec
  (type $type45 (struct (field (ref $environment136))))
  (type $1 (func (param (ref $environment269) (ref null $type27) i64) (result i64)))
  (type $2 (func (param (ref $environment254) (ref null $type27) i64) (result (ref $type15))))
  (type $type52 (struct (field (ref $environment254))))
  (type $environment254 (struct (field (ref $type48)) (field (ref $type51))))
  (type $type54 (struct (field (ref $environment269))))
  (type $type51 (struct (field (mut i32)) (field (mut (ref null $type52)))))
  (type $type53 (struct (field (mut i32)) (field (mut (ref null $type54)))))
  (type $environment269 (struct (field (ref $type53))))
  (type $type27 (struct (field i64) (field (ref null $type27))))
  (type $call26 (func (param (ref null $type27)) (result (ref $type15))))
  (type $11 (func (param (ref $type15) i64 i64) (result (ref $type15))))
  (type $12 (func (param (ref $environment183) (ref null $type36) i64) (result (ref $type15))))
  (type $type50 (struct (field (ref $environment183))))
  (type $environment183 (struct (field (ref $type48)) (field (ref $type49))))
  (type $type48 (struct (field (ref $type15))))
  (type $type49 (struct (field (mut i32)) (field (mut (ref null $type50)))))
  (type $call35 (func (param (ref null $type36)) (result (ref $type15))))
  (type $18 (func (param (ref $environment167) (ref null $type36) i64) (result i64)))
  (type $type47 (struct (field (ref $environment167))))
  (type $type46 (struct (field (mut i32)) (field (mut (ref null $type47)))))
  (type $type36 (struct (field (ref $type15)) (field (ref null $type36))))
  (type $environment167 (struct (field (ref $type46))))
  (type $23 (func (param (ref null $type36)) (result i64)))
  (type $type44 (struct (field (mut i32)) (field (mut (ref null $type45)))))
  (type $environment136 (struct (field (ref $type15)) (field (ref $type15)) (field (ref $type44))))
  (type $26 (func (param (ref $environment136) i64) (result i32)))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type37 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type26 (struct))
  (type $type25 (struct))
  (type $type15 (struct (field i32) (field (ref $type16))))
  (type $type16 (array (mut i8)))
 )
 (type $40 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $bytes0 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 0)
 ))
 (global $bytes1 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 1
   (i32.const 42)
  )
 ))
 (global $bytes2 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 5
   (i32.const 1)
   (i32.const 1)
   (i32.const 2)
   (i32.const 3)
   (i32.const 4)
  )
 ))
 (global $bytes3 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 5
   (i32.const 1)
   (i32.const 2)
   (i32.const 3)
   (i32.const 4)
   (i32.const 4)
  )
 ))
 (global $bytes4 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 4
   (i32.const 0)
   (i32.const 127)
   (i32.const 128)
   (i32.const 255)
  )
 ))
 (global $bytes5 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 5
   (i32.const 0)
   (i32.const 127)
   (i32.const 128)
   (i32.const 255)
   (i32.const 42)
  )
 ))
 (global $bytes6 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 2
   (i32.const 127)
   (i32.const 128)
  )
 ))
 (global $bytes7 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 2
   (i32.const 128)
   (i32.const 255)
  )
 ))
 (global $bytes8 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 3
   (i32.const 255)
   (i32.const 255)
   (i32.const 255)
  )
 ))
 (global $bytes9 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 2
   (i32.const 0)
   (i32.const 0)
  )
 ))
 (global $global103 (mut (ref null $type25)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global104 (mut (ref null $type26)) (ref.null none))
 (global $ready104 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type28)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global212 (mut (ref null $type29)) (ref.null none))
 (global $ready212 (mut i32) (i32.const 0))
 (global $global107 (mut (ref null $type32)) (ref.null none))
 (global $ready107 (mut i32) (i32.const 0))
 (global $global108 (mut (ref null $type33)) (ref.null none))
 (global $ready108 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type34)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type35)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type37)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type42)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type15)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type15)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type15)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type15)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type15)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type15)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type15)) (ref.null none))
 (global $ready123 (mut i32) (i32.const 0))
 (global $global124 (mut i32) (i32.const 0))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global125 (mut i32) (i32.const 0))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type43)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $function136 (type $26) (param $0 (ref $environment136)) (param $1 i64) (result i32)
  (local $2 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (struct.get $type15 1
       (struct.get $environment136 0
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (array.get_u $type16
        (struct.get $type15 1
         (struct.get $environment136 0
          (local.get $0)
         )
        )
        (local.tee $2
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (i64.extend_i32_u
       (array.get_u $type16
        (struct.get $type15 1
         (struct.get $environment136 1
          (local.get $0)
         )
        )
        (local.get $2)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type44 0
         (struct.get $environment136 2
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type44 1
         (struct.get $environment136 2
          (local.get $0)
         )
        )
       )
      )
      (return_call $function136
       (local.get $0)
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function160 (type $23) (param $0 (ref null $type36)) (result i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $environment167))
  (local $4 (ref null $type36))
  (local $5 (ref null $type36))
  (local $6 (ref $type46))
  (struct.set $type46 1
   (local.tee $6
    (struct.new_default $type46)
   )
   (struct.new $type47
    (struct.new $environment167
     (local.get $6)
    )
   )
  )
  (struct.set $type46 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type46 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type47 0
    (struct.get $type46 1
     (local.get $6)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $4
     (struct.get $type36 1
      (local.get $0)
     )
    )
    (local.set $1
     (i64.extend_i32_u
      (array.len
       (struct.get $type15 1
        (struct.get $type36 0
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type46 0
       (struct.get $environment167 0
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type46 1
       (struct.get $environment167 0
        (local.get $3)
       )
      )
     )
    )
    (if (result i64)
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.get $4)
       )
       (then
        (local.get $1)
       )
       (else
        (local.set $5
         (struct.get $type36 1
          (local.get $4)
         )
        )
        (local.set $2
         (i64.extend_i32_u
          (array.len
           (struct.get $type15 1
            (struct.get $type36 0
             (local.get $4)
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type46 0
           (struct.get $environment167 0
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (struct.get $type46 1
           (struct.get $environment167 0
            (local.get $3)
           )
          )
         )
        )
        (if (result i64)
         (i64.gt_u
          (local.tee $1
           (i64.add
            (local.get $1)
            (local.get $2)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.get $5)
           )
           (then
            (local.get $1)
           )
           (else
            (local.set $4
             (struct.get $type36 1
              (local.get $5)
             )
            )
            (local.set $2
             (i64.extend_i32_u
              (array.len
               (struct.get $type15 1
                (struct.get $type36 0
                 (local.get $5)
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (struct.get $type46 0
               (struct.get $environment167 0
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (struct.get $type46 1
               (struct.get $environment167 0
                (local.get $3)
               )
              )
             )
            )
            (if (result i64)
             (i64.gt_s
              (local.tee $1
               (i64.add
                (local.get $1)
                (local.get $2)
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.get $4)
               )
               (then
                (local.get $1)
               )
               (else
                (local.set $5
                 (struct.get $type36 1
                  (local.get $4)
                 )
                )
                (local.set $2
                 (i64.extend_i32_u
                  (array.len
                   (struct.get $type15 1
                    (struct.get $type36 0
                     (local.get $4)
                    )
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type46 0
                   (struct.get $environment167 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (struct.get $type46 1
                   (struct.get $environment167 0
                    (local.get $3)
                   )
                  )
                 )
                )
                (if (result i64)
                 (i64.gt_s
                  (local.tee $1
                   (i64.add
                    (local.get $1)
                    (local.get $2)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.get $5)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (local.set $4
                     (struct.get $type36 1
                      (local.get $5)
                     )
                    )
                    (local.set $2
                     (i64.extend_i32_u
                      (array.len
                       (struct.get $type15 1
                        (struct.get $type36 0
                         (local.get $5)
                        )
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type46 0
                       (struct.get $environment167 0
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (struct.get $type46 1
                       (struct.get $environment167 0
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (i64.gt_s
                      (local.tee $1
                       (i64.add
                        (local.get $1)
                        (local.get $2)
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.get $4)
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (local.set $5
                         (struct.get $type36 1
                          (local.get $4)
                         )
                        )
                        (local.set $2
                         (i64.extend_i32_u
                          (array.len
                           (struct.get $type15 1
                            (struct.get $type36 0
                             (local.get $4)
                            )
                           )
                          )
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type46 0
                           (struct.get $environment167 0
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (struct.get $type46 1
                           (struct.get $environment167 0
                            (local.get $3)
                           )
                          )
                         )
                        )
                        (if (result i64)
                         (i64.gt_s
                          (local.tee $1
                           (i64.add
                            (local.get $1)
                            (local.get $2)
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                         (else
                          (if (result i64)
                           (ref.is_null
                            (local.get $5)
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (local.set $4
                             (struct.get $type36 1
                              (local.get $5)
                             )
                            )
                            (local.set $2
                             (i64.extend_i32_u
                              (array.len
                               (struct.get $type15 1
                                (struct.get $type36 0
                                 (local.get $5)
                                )
                               )
                              )
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type46 0
                               (struct.get $environment167 0
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (struct.get $type46 1
                               (struct.get $environment167 0
                                (local.get $3)
                               )
                              )
                             )
                            )
                            (if (result i64)
                             (i64.gt_s
                              (local.tee $1
                               (i64.add
                                (local.get $1)
                                (local.get $2)
                               )
                              )
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                             (else
                              (if (result i64)
                               (ref.is_null
                                (local.get $4)
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (local.set $5
                                 (struct.get $type36 1
                                  (local.get $4)
                                 )
                                )
                                (local.set $2
                                 (i64.extend_i32_u
                                  (array.len
                                   (struct.get $type15 1
                                    (struct.get $type36 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type46 0
                                   (struct.get $environment167 0
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (struct.get $type46 1
                                   (struct.get $environment167 0
                                    (local.get $3)
                                   )
                                  )
                                 )
                                )
                                (if (result i64)
                                 (i64.gt_s
                                  (local.tee $1
                                   (i64.add
                                    (local.get $1)
                                    (local.get $2)
                                   )
                                  )
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                 (else
                                  (if (result i64)
                                   (ref.is_null
                                    (local.get $5)
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (local.set $4
                                     (struct.get $type36 1
                                      (local.get $5)
                                     )
                                    )
                                    (local.set $2
                                     (i64.extend_i32_u
                                      (array.len
                                       (struct.get $type15 1
                                        (struct.get $type36 0
                                         (local.get $5)
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (struct.get $type46 0
                                       (struct.get $environment167 0
                                        (local.get $3)
                                       )
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (struct.get $type46 1
                                       (struct.get $environment167 0
                                        (local.get $3)
                                       )
                                      )
                                     )
                                    )
                                    (if (result i64)
                                     (i64.gt_s
                                      (local.tee $1
                                       (i64.add
                                        (local.get $1)
                                        (local.get $2)
                                       )
                                      )
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                     (else
                                      (if (result i64)
                                       (ref.is_null
                                        (local.get $4)
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (local.set $5
                                         (struct.get $type36 1
                                          (local.get $4)
                                         )
                                        )
                                        (local.set $2
                                         (i64.extend_i32_u
                                          (array.len
                                           (struct.get $type15 1
                                            (struct.get $type36 0
                                             (local.get $4)
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (struct.get $type46 0
                                           (struct.get $environment167 0
                                            (local.get $3)
                                           )
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (struct.get $type46 1
                                           (struct.get $environment167 0
                                            (local.get $3)
                                           )
                                          )
                                         )
                                        )
                                        (if (result i64)
                                         (i64.gt_s
                                          (local.tee $1
                                           (i64.add
                                            (local.get $1)
                                            (local.get $2)
                                           )
                                          )
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                         (else
                                          (if (result i64)
                                           (ref.is_null
                                            (local.get $5)
                                           )
                                           (then
                                            (local.get $1)
                                           )
                                           (else
                                            (local.set $4
                                             (struct.get $type36 1
                                              (local.get $5)
                                             )
                                            )
                                            (local.set $2
                                             (i64.extend_i32_u
                                              (array.len
                                               (struct.get $type15 1
                                                (struct.get $type36 0
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (struct.get $type46 0
                                               (struct.get $environment167 0
                                                (local.get $3)
                                               )
                                              )
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (struct.get $type46 1
                                               (struct.get $environment167 0
                                                (local.get $3)
                                               )
                                              )
                                             )
                                            )
                                            (if (result i64)
                                             (i64.gt_s
                                              (local.tee $1
                                               (i64.add
                                                (local.get $1)
                                                (local.get $2)
                                               )
                                              )
                                              (i64.const 4294967295)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                             (else
                                              (if (result i64)
                                               (ref.is_null
                                                (local.get $4)
                                               )
                                               (then
                                                (local.get $1)
                                               )
                                               (else
                                                (local.set $5
                                                 (struct.get $type36 1
                                                  (local.get $4)
                                                 )
                                                )
                                                (local.set $2
                                                 (i64.extend_i32_u
                                                  (array.len
                                                   (struct.get $type15 1
                                                    (struct.get $type36 0
                                                     (local.get $4)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                                (if
                                                 (i32.eqz
                                                  (struct.get $type46 0
                                                   (struct.get $environment167 0
                                                    (local.get $3)
                                                   )
                                                  )
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (struct.get $type46 1
                                                   (struct.get $environment167 0
                                                    (local.get $3)
                                                   )
                                                  )
                                                 )
                                                )
                                                (if (result i64)
                                                 (i64.gt_s
                                                  (local.tee $1
                                                   (i64.add
                                                    (local.get $1)
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i64.const 4294967295)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                 (else
                                                  (if (result i64)
                                                   (ref.is_null
                                                    (local.get $5)
                                                   )
                                                   (then
                                                    (local.get $1)
                                                   )
                                                   (else
                                                    (local.set $4
                                                     (struct.get $type36 1
                                                      (local.get $5)
                                                     )
                                                    )
                                                    (local.set $2
                                                     (i64.extend_i32_u
                                                      (array.len
                                                       (struct.get $type15 1
                                                        (struct.get $type36 0
                                                         (local.get $5)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (struct.get $type46 0
                                                       (struct.get $environment167 0
                                                        (local.get $3)
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (struct.get $type46 1
                                                       (struct.get $environment167 0
                                                        (local.get $3)
                                                       )
                                                      )
                                                     )
                                                    )
                                                    (if (result i64)
                                                     (i64.gt_s
                                                      (local.tee $1
                                                       (i64.add
                                                        (local.get $1)
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (i64.const 4294967295)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                     (else
                                                      (if (result i64)
                                                       (ref.is_null
                                                        (local.get $4)
                                                       )
                                                       (then
                                                        (local.get $1)
                                                       )
                                                       (else
                                                        (local.set $5
                                                         (struct.get $type36 1
                                                          (local.get $4)
                                                         )
                                                        )
                                                        (local.set $2
                                                         (i64.extend_i32_u
                                                          (array.len
                                                           (struct.get $type15 1
                                                            (struct.get $type36 0
                                                             (local.get $4)
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                        (if
                                                         (i32.eqz
                                                          (struct.get $type46 0
                                                           (struct.get $environment167 0
                                                            (local.get $3)
                                                           )
                                                          )
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                        )
                                                        (drop
                                                         (ref.as_non_null
                                                          (struct.get $type46 1
                                                           (struct.get $environment167 0
                                                            (local.get $3)
                                                           )
                                                          )
                                                         )
                                                        )
                                                        (if (result i64)
                                                         (i64.gt_s
                                                          (local.tee $1
                                                           (i64.add
                                                            (local.get $1)
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (i64.const 4294967295)
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                         (else
                                                          (if (result i64)
                                                           (ref.is_null
                                                            (local.get $5)
                                                           )
                                                           (then
                                                            (local.get $1)
                                                           )
                                                           (else
                                                            (local.set $4
                                                             (struct.get $type36 1
                                                              (local.get $5)
                                                             )
                                                            )
                                                            (local.set $2
                                                             (i64.extend_i32_u
                                                              (array.len
                                                               (struct.get $type15 1
                                                                (struct.get $type36 0
                                                                 (local.get $5)
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (struct.get $type46 0
                                                               (struct.get $environment167 0
                                                                (local.get $3)
                                                               )
                                                              )
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (struct.get $type46 1
                                                               (struct.get $environment167 0
                                                                (local.get $3)
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (return_call $function167
                                                             (local.get $3)
                                                             (local.get $4)
                                                             (i64.add
                                                              (local.get $1)
                                                              (local.get $2)
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function167 (type $18) (param $0 (ref $environment167)) (param $1 (ref null $type36)) (param $2 i64) (result i64)
  (local $3 (ref null $type36))
  (local $4 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (local.get $2)
     )
     (else
      (local.set $3
       (struct.get $type36 1
        (local.get $1)
       )
      )
      (local.set $4
       (i64.extend_i32_u
        (array.len
         (struct.get $type15 1
          (struct.get $type36 0
           (local.get $1)
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type46 0
         (struct.get $environment167 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type46 1
         (struct.get $environment167 0
          (local.get $0)
         )
        )
       )
      )
      (return_call $function167
       (local.get $0)
       (local.get $3)
       (i64.add
        (local.get $2)
        (local.get $4)
       )
      )
     )
    )
   )
  )
 )
 (func $function173 (type $call35) (param $0 (ref null $type36)) (result (ref $type15))
  (local $1 (ref $type49))
  (local $2 i64)
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (local.set $2
   (call $function160
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type49 1
   (local.tee $1
    (struct.new_default $type49)
   )
   (struct.new $type50
    (struct.new $environment183
     (struct.new $type48
      (struct.new $type15
       (i32.const 1)
       (array.new_default $type16
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type49 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type49 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function183
   (struct.get $type50 0
    (struct.get $type49 1
     (local.get $1)
    )
   )
   (local.get $0)
   (i64.const 0)
  )
 )
 (func $function183 (type $12) (param $0 (ref $environment183)) (param $1 (ref null $type36)) (param $2 i64) (result (ref $type15))
  (local $3 i64)
  (local $4 (ref $type15))
  (local $5 (ref $type15))
  (if (result (ref $type15))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type48 0
     (struct.get $environment183 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (i64.extend_i32_u
      (array.len
       (struct.get $type15 1
        (local.tee $4
         (struct.get $type36 0
          (local.get $1)
         )
        )
       )
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type15 0
       (local.tee $5
        (struct.get $type48 0
         (struct.get $environment183 0
          (local.get $0)
         )
        )
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type16 $type16
     (struct.get $type15 1
      (local.get $5)
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (struct.get $type15 1
      (local.get $4)
     )
     (i32.const 0)
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $1
     (struct.get $type36 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (struct.get $environment183 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type49 1
       (struct.get $environment183 1
        (local.get $0)
       )
      )
     )
    )
    (return_call $function183
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function203 (type $11) (param $0 (ref $type15)) (param $1 i64) (param $2 i64) (result (ref $type15))
  (local $3 (ref $type15))
  (local $4 i64)
  (if
   (i32.eqz
    (global.get $ready212)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global212)
   )
  )
  (if
   (i32.or
    (i32.or
     (i64.gt_s
      (local.get $2)
      (i64.extend_i32_u
       (array.len
        (struct.get $type15 1
         (local.get $0)
        )
       )
      )
     )
     (i64.gt_s
      (local.get $1)
      (local.get $2)
     )
    )
    (i64.lt_s
     (local.get $1)
     (i64.const 0)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (if
   (i64.gt_u
    (local.tee $4
     (i64.sub
      (local.get $2)
      (local.get $1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type15 0
     (local.tee $3
      (struct.new $type15
       (i32.const 1)
       (array.new_default $type16
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_s
    (local.get $1)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $2)
     (local.get $1)
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type16 $type16
   (struct.get $type15 1
    (local.get $3)
   )
   (i32.const 0)
   (struct.get $type15 1
    (local.get $0)
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.wrap_i64
    (i64.sub
     (local.get $2)
     (local.get $1)
    )
   )
  )
  (local.get $3)
 )
 (func $function244 (type $call26) (param $0 (ref null $type27)) (result (ref $type15))
  (local $1 (ref null $type27))
  (local $2 (ref $environment269))
  (local $3 (ref $type53))
  (local $4 (ref $type51))
  (local $5 i64)
  (if
   (i32.eqz
    (global.get $ready261)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global261)
   )
  )
  (struct.set $type53 1
   (local.tee $3
    (struct.new_default $type53)
   )
   (struct.new $type54
    (struct.new $environment269
     (local.get $3)
    )
   )
  )
  (struct.set $type53 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type53 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type54 0
    (struct.get $type53 1
     (local.get $3)
    )
   )
  )
  (local.set $5
   (if (result i64)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $1
      (struct.get $type27 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (struct.get $type53 0
        (struct.get $environment269 0
         (local.get $2)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (struct.get $type53 1
        (struct.get $environment269 0
         (local.get $2)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type27 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type53 0
          (struct.get $environment269 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (struct.get $type53 1
          (struct.get $environment269 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type27 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type53 0
            (struct.get $environment269 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (struct.get $type53 1
            (struct.get $environment269 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type27 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type53 0
              (struct.get $environment269 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (struct.get $type53 1
              (struct.get $environment269 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type27 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type53 0
                (struct.get $environment269 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (struct.get $type53 1
                (struct.get $environment269 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type27 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type53 0
                  (struct.get $environment269 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (struct.get $type53 1
                  (struct.get $environment269 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type27 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type53 0
                    (struct.get $environment269 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (struct.get $type53 1
                    (struct.get $environment269 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type27 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type53 0
                      (struct.get $environment269 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (struct.get $type53 1
                      (struct.get $environment269 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type27 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type53 0
                        (struct.get $environment269 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (struct.get $type53 1
                        (struct.get $environment269 0
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (local.set $1
                        (struct.get $type27 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type53 0
                          (struct.get $environment269 0
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (struct.get $type53 1
                          (struct.get $environment269 0
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (local.set $1
                          (struct.get $type27 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type53 0
                            (struct.get $environment269 0
                             (local.get $2)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (struct.get $type53 1
                            (struct.get $environment269 0
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (local.set $1
                            (struct.get $type27 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type53 0
                              (struct.get $environment269 0
                               (local.get $2)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (struct.get $type53 1
                              (struct.get $environment269 0
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (local.set $1
                              (struct.get $type27 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type53 0
                                (struct.get $environment269 0
                                 (local.get $2)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (struct.get $type53 1
                                (struct.get $environment269 0
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (local.set $1
                                (struct.get $type27 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type53 0
                                  (struct.get $environment269 0
                                   (local.get $2)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (struct.get $type53 1
                                  (struct.get $environment269 0
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                               (call $function269
                                (local.get $2)
                                (local.get $1)
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (if
   (i64.gt_u
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type51 1
   (local.tee $4
    (struct.new_default $type51)
   )
   (struct.new $type52
    (struct.new $environment254
     (struct.new $type48
      (struct.new $type15
       (i32.const 1)
       (array.new_default $type16
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type51 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function254
   (struct.get $type52 0
    (struct.get $type51 1
     (local.get $4)
    )
   )
   (local.get $0)
   (i64.const 0)
  )
 )
 (func $function254 (type $2) (param $0 (ref $environment254)) (param $1 (ref null $type27)) (param $2 i64) (result (ref $type15))
  (local $3 i64)
  (local $4 (ref $type15))
  (if (result (ref $type15))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type48 0
     (struct.get $environment254 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type27 0
      (local.get $1)
     )
    )
    (if
     (i32.ne
      (struct.get $type15 0
       (local.tee $4
        (struct.get $type48 0
         (struct.get $environment254 0
          (local.get $0)
         )
        )
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type16
     (struct.get $type15 1
      (local.get $4)
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $1
     (struct.get $type27 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment254 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type51 1
       (struct.get $environment254 1
        (local.get $0)
       )
      )
     )
    )
    (return_call $function254
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function269 (type $1) (param $0 (ref $environment269)) (param $1 (ref null $type27)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type27 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type53 0
         (struct.get $environment269 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type53 1
         (struct.get $environment269 0
          (local.get $0)
         )
        )
       )
      )
      (return_call $function269
       (local.get $0)
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $main (result i64)
  (local $0 (ref $type44))
  (local $1 (ref $type15))
  (local $2 (ref $type15))
  (local $3 (ref $type15))
  (local $4 (ref $type15))
  (local $scratch (ref $type15))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type25)
  )
  (global.set $ready103
   (i32.const 1)
  )
  (global.set $global104
   (struct.new_default $type26)
  )
  (global.set $ready104
   (i32.const 1)
  )
  (global.set $global261
   (struct.new_default $type28)
  )
  (global.set $ready261
   (i32.const 1)
  )
  (global.set $global212
   (struct.new_default $type29)
  )
  (global.set $ready212
   (i32.const 1)
  )
  (global.set $global107
   (struct.new_default $type32)
  )
  (global.set $ready107
   (i32.const 1)
  )
  (global.set $global108
   (struct.new_default $type33)
  )
  (global.set $ready108
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type34)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type35)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type37)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type42)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global104)
   )
  )
  (global.set $global117
   (call $function244
    (struct.new $type27
     (i64.const 0)
     (struct.new $type27
      (i64.const 127)
      (struct.new $type27
       (i64.const 128)
       (struct.new $type27
        (i64.const 255)
        (ref.null none)
       )
      )
     )
    )
   )
  )
  (global.set $ready117
   (i32.const 1)
  )
  (global.set $global118
   (local.tee $1
    (ref.as_non_null
     (global.get $global117)
    )
   )
  )
  (global.set $ready118
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (global.set $global119
   (call $function203
    (local.get $1)
    (i64.const 0)
    (i64.extend_i32_u
     (array.len
      (struct.get $type15 1
       (local.get $1)
      )
     )
    )
   )
  )
  (global.set $ready119
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready117)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (global.set $global120
   (call $function173
    (struct.new $type36
     (global.get $bytes0)
     (struct.new $type36
      (local.get $1)
      (struct.new $type36
       (global.get $bytes1)
       (ref.null none)
      )
     )
    )
   )
  )
  (global.set $ready120
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready117)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global121
   (call $function173
    (struct.new $type36
     (ref.as_non_null
      (global.get $global117)
     )
     (block (result nullref)
      (if
       (i32.eqz
        (global.get $ready110)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (ref.null none)
     )
    )
   )
  )
  (global.set $ready121
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (global.set $global122
   (struct.new $type15
    (i32.const 1)
    (array.new_default $type16
     (i32.const 0)
    )
   )
  )
  (global.set $ready122
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready104)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global104)
   )
  )
  (global.set $global123
   (call $function244
    (struct.new $type27
     (i64.const 1)
     (struct.new $type27
      (i64.const 2)
      (struct.new $type27
       (i64.const 3)
       (struct.new $type27
        (i64.const 4)
        (struct.new $type27
         (i64.const 5)
         (ref.null none)
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready123
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type15 0
     (local.tee $1
      (ref.as_non_null
       (global.get $global118)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type16
   (struct.get $type15 1
    (local.get $1)
   )
   (i32.const 0)
   (i32.const 254)
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.ne
    (struct.get $type15 0
     (local.get $1)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type16 $type16
   (struct.get $type15 1
    (local.get $1)
   )
   (i32.const 1)
   (struct.get $type15 1
    (local.get $3)
   )
   (i32.const 0)
   (i32.const 4)
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global124
   (if (result i32)
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $type15 1
        (local.get $1)
       )
      )
     )
     (i64.const 5)
    )
    (then
     (struct.set $type44 1
      (local.tee $0
       (struct.new_default $type44)
      )
      (struct.new $type45
       (struct.new $environment136
        (local.get $1)
        (global.get $bytes2)
        (local.get $0)
       )
      )
     )
     (struct.set $type44 0
      (local.get $0)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type44 0
        (local.get $0)
       )
      )
      (then
       (unreachable)
      )
     )
     (call $function136
      (struct.get $type45 0
       (struct.get $type44 1
        (local.get $0)
       )
      )
      (i64.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (global.set $ready124
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.ne
    (struct.get $type15 0
     (local.get $1)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type16 $type16
   (struct.get $type15 1
    (local.get $1)
   )
   (i32.const 0)
   (struct.get $type15 1
    (local.get $3)
   )
   (i32.const 1)
   (i32.const 4)
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global125
   (if (result i32)
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $type15 1
        (local.get $1)
       )
      )
     )
     (i64.const 5)
    )
    (then
     (struct.set $type44 1
      (local.tee $0
       (struct.new_default $type44)
      )
      (struct.new $type45
       (struct.new $environment136
        (local.get $1)
        (global.get $bytes3)
        (local.get $0)
       )
      )
     )
     (struct.set $type44 0
      (local.get $0)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type44 0
        (local.get $0)
       )
      )
      (then
       (unreachable)
      )
     )
     (call $function136
      (struct.get $type45 0
       (struct.get $type44 1
        (local.get $0)
       )
      )
      (i64.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (global.set $ready125
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.ne
    (struct.get $type15 0
     (local.get $1)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type16 $type16
   (struct.get $type15 1
    (local.get $1)
   )
   (i32.const 5)
   (struct.get $type15 1
    (local.get $3)
   )
   (i32.const 5)
   (i32.const 0)
  )
  (global.set $global126
   (struct.new_default $type43)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready117)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (ref.eq
      (ref.as_non_null
       (global.get $global117)
      )
      (block (result (ref $type15))
       (if
        (i32.eqz
         (global.get $ready118)
        )
        (then
         (unreachable)
        )
       )
       (ref.as_non_null
        (global.get $global118)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready117)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (array.get_u $type16
          (struct.get $type15 1
           (block (result (ref $type15))
            (local.set $scratch
             (ref.as_non_null
              (global.get $global117)
             )
            )
            (if
             (i32.eqz
              (global.get $ready126)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global126)
             )
            )
            (local.get $scratch)
           )
          )
          (i32.const 0)
         )
        )
        (i64.const 254)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready119)
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (ref.as_non_null
          (global.get $global119)
         )
        )
        (if
         (i32.eqz
          (global.get $ready116)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global116)
         )
        )
        (if (result i32)
         (if (result i32)
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (struct.get $type15 1
              (local.get $2)
             )
            )
           )
           (i64.const 4)
          )
          (then
           (struct.set $type44 1
            (local.tee $0
             (struct.new_default $type44)
            )
            (struct.new $type45
             (struct.new $environment136
              (local.get $2)
              (global.get $bytes4)
              (local.get $0)
             )
            )
           )
           (struct.set $type44 0
            (local.get $0)
            (i32.const 1)
           )
           (if
            (i32.eqz
             (struct.get $type44 0
              (local.get $0)
             )
            )
            (then
             (unreachable)
            )
           )
           (call $function136
            (struct.get $type45 0
             (struct.get $type44 1
              (local.get $0)
             )
            )
            (i64.const 0)
           )
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready120)
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (ref.as_non_null
            (global.get $global120)
           )
          )
          (if
           (i32.eqz
            (global.get $ready116)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global116)
           )
          )
          (if (result i32)
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (array.len
               (struct.get $type15 1
                (local.get $1)
               )
              )
             )
             (i64.const 5)
            )
            (then
             (struct.set $type44 1
              (local.tee $0
               (struct.new_default $type44)
              )
              (struct.new $type45
               (struct.new $environment136
                (local.get $1)
                (global.get $bytes5)
                (local.get $0)
               )
              )
             )
             (struct.set $type44 0
              (local.get $0)
              (i32.const 1)
             )
             (if
              (i32.eqz
               (struct.get $type44 0
                (local.get $0)
               )
              )
              (then
               (unreachable)
              )
             )
             (call $function136
              (struct.get $type45 0
               (struct.get $type44 1
                (local.get $0)
               )
              )
              (i64.const 0)
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (if
             (i32.eqz
              (global.get $ready121)
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (ref.as_non_null
              (global.get $global121)
             )
            )
            (if
             (i32.eqz
              (global.get $ready119)
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (ref.as_non_null
              (global.get $global119)
             )
            )
            (if
             (i32.eqz
              (global.get $ready116)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global116)
             )
            )
            (if (result i32)
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (struct.get $type15 1
                  (local.get $1)
                 )
                )
               )
               (i64.extend_i32_u
                (array.len
                 (struct.get $type15 1
                  (local.get $2)
                 )
                )
               )
              )
              (then
               (struct.set $type44 1
                (local.tee $0
                 (struct.new_default $type44)
                )
                (struct.new $type45
                 (struct.new $environment136
                  (local.get $1)
                  (local.get $2)
                  (local.get $0)
                 )
                )
               )
               (struct.set $type44 0
                (local.get $0)
                (i32.const 1)
               )
               (if
                (i32.eqz
                 (struct.get $type44 0
                  (local.get $0)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (call $function136
                (struct.get $type45 0
                 (struct.get $type44 1
                  (local.get $0)
                 )
                )
                (i64.const 0)
               )
              )
              (else
               (i32.const 0)
              )
             )
             (then
              (if
               (i32.eqz
                (global.get $ready121)
               )
               (then
                (unreachable)
               )
              )
              (if (result i32)
               (ref.eq
                (ref.as_non_null
                 (global.get $global121)
                )
                (block (result (ref $type15))
                 (if
                  (i32.eqz
                   (global.get $ready119)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (ref.as_non_null
                  (global.get $global119)
                 )
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i32.eqz
                  (global.get $ready119)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (call $function203
                  (ref.as_non_null
                   (global.get $global119)
                  )
                  (block (result i64)
                   (if
                    (i32.eqz
                     (global.get $ready107)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global107)
                    )
                   )
                   (i64.const 1)
                  )
                  (i64.const 3)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready116)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global116)
                 )
                )
                (if (result i32)
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (struct.get $type15 1
                      (local.get $2)
                     )
                    )
                   )
                   (i64.const 2)
                  )
                  (then
                   (struct.set $type44 1
                    (local.tee $0
                     (struct.new_default $type44)
                    )
                    (struct.new $type45
                     (struct.new $environment136
                      (local.get $2)
                      (global.get $bytes6)
                      (local.get $0)
                     )
                    )
                   )
                   (struct.set $type44 0
                    (local.get $0)
                    (i32.const 1)
                   )
                   (if
                    (i32.eqz
                     (struct.get $type44 0
                      (local.get $0)
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (call $function136
                    (struct.get $type45 0
                     (struct.get $type44 1
                      (local.get $0)
                     )
                    )
                    (i64.const 0)
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                 (then
                  (if
                   (i32.eqz
                    (global.get $ready119)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (ref.as_non_null
                    (global.get $global119)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready108)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global108)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready107)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global107)
                   )
                  )
                  (local.set $2
                   (call $function203
                    (local.get $2)
                    (i64.const 2)
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type15 1
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready116)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global116)
                   )
                  )
                  (if (result i32)
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (struct.get $type15 1
                        (local.get $2)
                       )
                      )
                     )
                     (i64.const 2)
                    )
                    (then
                     (struct.set $type44 1
                      (local.tee $0
                       (struct.new_default $type44)
                      )
                      (struct.new $type45
                       (struct.new $environment136
                        (local.get $2)
                        (global.get $bytes7)
                        (local.get $0)
                       )
                      )
                     )
                     (struct.set $type44 0
                      (local.get $0)
                      (i32.const 1)
                     )
                     (if
                      (i32.eqz
                       (struct.get $type44 0
                        (local.get $0)
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function136
                      (struct.get $type45 0
                       (struct.get $type44 1
                        (local.get $0)
                       )
                      )
                      (i64.const 0)
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (global.get $ready116)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global116)
                     )
                    )
                    (struct.set $type44 1
                     (local.tee $0
                      (struct.new_default $type44)
                     )
                     (struct.new $type45
                      (struct.new $environment136
                       (struct.new $type15
                        (i32.const 1)
                        (array.new $type16
                         (i32.const 255)
                         (i32.const 3)
                        )
                       )
                       (global.get $bytes8)
                       (local.get $0)
                      )
                     )
                    )
                    (struct.set $type44 0
                     (local.get $0)
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (struct.get $type44 0
                       (local.get $0)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if (result i32)
                     (call $function136
                      (struct.get $type45 0
                       (struct.get $type44 1
                        (local.get $0)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (if
                       (i32.eqz
                        (global.get $ready103)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global103)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready116)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global116)
                       )
                      )
                      (struct.set $type44 1
                       (local.tee $0
                        (struct.new_default $type44)
                       )
                       (struct.new $type45
                        (struct.new $environment136
                         (struct.new $type15
                          (i32.const 1)
                          (array.new_default $type16
                           (i32.const 2)
                          )
                         )
                         (global.get $bytes9)
                         (local.get $0)
                        )
                       )
                      )
                      (struct.set $type44 0
                       (local.get $0)
                       (i32.const 1)
                      )
                      (if
                       (i32.eqz
                        (struct.get $type44 0
                         (local.get $0)
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if (result i32)
                       (call $function136
                        (struct.get $type45 0
                         (struct.get $type44 1
                          (local.get $0)
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (if
                         (i32.eqz
                          (global.get $ready122)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if (result i32)
                         (ref.eq
                          (ref.as_non_null
                           (global.get $global122)
                          )
                          (block (result (ref $type15))
                           (if
                            (i32.eqz
                             (global.get $ready122)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $2
                            (ref.as_non_null
                             (global.get $global122)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready109)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global109)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready107)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global107)
                            )
                           )
                           (call $function203
                            (local.get $2)
                            (i64.const 0)
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type15 1
                               (local.get $2)
                              )
                             )
                            )
                           )
                          )
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i32.eqz
                            (global.get $ready104)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global104)
                           )
                          )
                          (if (result i32)
                           (ref.eq
                            (call $function244
                             (ref.null none)
                            )
                            (block (result (ref $type15))
                             (if
                              (i32.eqz
                               (global.get $ready104)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global104)
                              )
                             )
                             (call $function244
                              (ref.null none)
                             )
                            )
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i32.eqz
                              (global.get $ready110)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global110)
                             )
                            )
                            (if (result i32)
                             (ref.eq
                              (call $function173
                               (ref.null none)
                              )
                              (block (result (ref $type15))
                               (if
                                (i32.eqz
                                 (global.get $ready122)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (ref.as_non_null
                                (global.get $global122)
                               )
                              )
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i32.eqz
                                (global.get $ready124)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (if (result i32)
                               (global.get $global124)
                               (then
                                (if
                                 (i32.eqz
                                  (global.get $ready125)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (global.get $global125)
                               )
                               (else
                                (i32.const 0)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (i32.const 0)
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

