(module
 (rec
  (type $type31 (sub (struct)))
  (type $type40 (struct (field (mut (ref $type31)))))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type35 (struct))
  (type $type30 (struct))
  (type $type25 (struct))
  (type $type37 (struct))
  (type $type33 (sub $type31 (struct)))
  (type $type32 (sub $type31 (struct)))
  (type $type27 (sub (struct)))
 )
 (type $11 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty27 (ref $type27) (struct.new_default $type27))
 (global $empty32 (ref $type32) (struct.new_default $type32))
 (global $empty33 (ref $type33) (struct.new_default $type33))
 (global $empty37 (ref $type37) (struct.new_default $type37))
 (global $global110 (mut (ref null $type25)) (ref.null none))
 (global $global116 (mut (ref null $type30)) (ref.null none))
 (global $global105 (mut (ref null $type35)) (ref.null none))
 (global $global111 (mut (ref null $type38)) (ref.null none))
 (global $global117 (mut (ref null $type39)) (ref.null none))
 (global $global84 (mut (ref null $type32)) (ref.null none))
 (global $global85 (mut (ref null $type27)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global86 (mut (ref null $type37)) (ref.null none))
 (global $ready86 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type40)) (ref.null none))
 (global $global88 (mut (ref null $type40)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $main (result i64)
  (local $0 (ref $type31))
  (local $1 (ref $type32))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type25)
  )
  (global.set $global116
   (struct.new_default $type30)
  )
  (global.set $global105
   (struct.new_default $type35)
  )
  (global.set $global111
   (struct.new_default $type38)
  )
  (global.set $global117
   (struct.new_default $type39)
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (global.set $global84
   (global.get $empty32)
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (global.set $global85
   (global.get $empty27)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global105)
   )
  )
  (global.set $global86
   (global.get $empty37)
  )
  (global.set $ready86
   (i32.const 1)
  )
  (global.set $global87
   (struct.new $type40
    (local.tee $1
     (ref.as_non_null
      (global.get $global84)
     )
    )
   )
  )
  (global.set $global88
   (struct.new $type40
    (local.get $1)
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (struct.set $type40 0
   (global.get $global87)
   (global.get $empty33)
  )
  (i64.add
   (i64.add
    (select
     (i64.const -100)
     (i64.const 10)
     (ref.eq
      (ref.as_non_null
       (global.get $global87)
      )
      (ref.as_non_null
       (global.get $global88)
      )
     )
    )
    (block (result i64)
     (local.set $scratch
      (if (result i64)
       (ref.test (ref $type32)
        (local.tee $0
         (struct.get $type40 0
          (global.get $global87)
         )
        )
       )
       (then
        (i64.const -100)
       )
       (else
        (if (result i64)
         (ref.test (ref $type32)
          (local.get $0)
         )
         (then
          (unreachable)
         )
         (else
          (i64.const 12)
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready88)
      )
      (then
       (unreachable)
      )
     )
     (local.set $4
      (if (result i64)
       (ref.test (ref $type32)
        (local.tee $0
         (struct.get $type40 0
          (global.get $global88)
         )
        )
       )
       (then
        (i64.const 7)
       )
       (else
        (if (result i64)
         (ref.test (ref $type32)
          (local.get $0)
         )
         (then
          (unreachable)
         )
         (else
          (i64.const -100)
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready85)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global85)
      )
     )
     (if
      (i32.eqz
       (global.get $ready86)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global86)
      )
     )
     (global.set $execution
      (i32.const 2)
     )
     (local.get $scratch)
    )
   )
   (i64.add
    (local.get $4)
    (i64.const 13)
   )
  )
 )
)

