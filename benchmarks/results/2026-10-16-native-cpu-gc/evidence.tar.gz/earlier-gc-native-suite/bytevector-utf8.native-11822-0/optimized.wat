(module
 (rec
  (type $type44 (struct (field (ref $environment134))))
  (type $type43 (struct (field (mut i32)) (field (mut (ref null $type44)))))
  (type $environment134 (struct (field (ref $type15)) (field (ref $type15)) (field (ref $type43))))
  (type $3 (func (param (ref $environment134) i64) (result i32)))
  (type $4 (func (param (ref $type14) (ref $type14)) (result i32)))
  (type $5 (func (param (ref $type15) i64 i64) (result (ref $type14))))
  (type $6 (func (param (ref $type14) i64 i32)))
  (type $7 (func (param (ref $type14) i32) (result i32)))
  (type $8 (func (param (ref $type16) i32) (result i32)))
  (type $9 (func (param (ref $type16) i32 i32 i32)))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type15 (struct (field i32) (field (ref $type16))))
  (type $type14 (struct (field i32) (field i32) (field (mut i32)) (field (mut (ref $type16))) (field (mut i32)) (field (mut i32))))
  (type $type16 (array (mut i8)))
 )
 (type $18 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 11)
  (i32.const 29)
  (array.new_fixed $type16 29
   (i32.const 0)
   (i32.const 127)
   (i32.const 194)
   (i32.const 128)
   (i32.const 223)
   (i32.const 191)
   (i32.const 224)
   (i32.const 160)
   (i32.const 128)
   (i32.const 237)
   (i32.const 159)
   (i32.const 191)
   (i32.const 238)
   (i32.const 128)
   (i32.const 128)
   (i32.const 239)
   (i32.const 187)
   (i32.const 191)
   (i32.const 239)
   (i32.const 191)
   (i32.const 191)
   (i32.const 240)
   (i32.const 144)
   (i32.const 128)
   (i32.const 128)
   (i32.const 244)
   (i32.const 143)
   (i32.const 191)
   (i32.const 191)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 0)
  (i32.const 0)
  (array.new_fixed $type16 0)
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 2)
  (i32.const 3)
  (array.new_fixed $type16 3
   (i32.const 65)
   (i32.const 194)
   (i32.const 128)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (i32.const 8)
  (array.new_fixed $type16 8
   (i32.const 65)
   (i32.const 195)
   (i32.const 169)
   (i32.const 240)
   (i32.const 159)
   (i32.const 152)
   (i32.const 128)
   (i32.const 90)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string4 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 2)
  (i32.const 3)
  (array.new_fixed $type16 3
   (i32.const 65)
   (i32.const 195)
   (i32.const 169)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string5 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 1)
  (i32.const 2)
  (array.new_fixed $type16 2
   (i32.const 195)
   (i32.const 169)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $bytes0 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 29
   (i32.const 0)
   (i32.const 127)
   (i32.const 194)
   (i32.const 128)
   (i32.const 223)
   (i32.const 191)
   (i32.const 224)
   (i32.const 160)
   (i32.const 128)
   (i32.const 237)
   (i32.const 159)
   (i32.const 191)
   (i32.const 238)
   (i32.const 128)
   (i32.const 128)
   (i32.const 239)
   (i32.const 187)
   (i32.const 191)
   (i32.const 239)
   (i32.const 191)
   (i32.const 191)
   (i32.const 240)
   (i32.const 144)
   (i32.const 128)
   (i32.const 128)
   (i32.const 244)
   (i32.const 143)
   (i32.const 191)
   (i32.const 191)
  )
 ))
 (global $bytes1 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 2
   (i32.const 194)
   (i32.const 128)
  )
 ))
 (global $bytes2 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 0)
 ))
 (global $bytes3 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 5
   (i32.const 255)
   (i32.const 65)
   (i32.const 194)
   (i32.const 128)
   (i32.const 255)
  )
 ))
 (global $bytes4 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 6
   (i32.const 195)
   (i32.const 169)
   (i32.const 240)
   (i32.const 159)
   (i32.const 152)
   (i32.const 128)
  )
 ))
 (global $bytes5 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 2
   (i32.const 195)
   (i32.const 169)
  )
 ))
 (global $bytes6 (ref $type15) (struct.new $type15
  (i32.const 0)
  (array.new_fixed $type16 3
   (i32.const 65)
   (i32.const 195)
   (i32.const 169)
  )
 ))
 (global $global111 (mut (ref null $type38)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type39)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type40)) (ref.null none))
 (global $ready113 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type41)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global115 (mut (ref null $type14)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type15)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type15)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type14)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type14)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type14)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type42)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type14)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type14)) (ref.null none))
 (global $ready123 (mut i32) (i32.const 0))
 (global $global124 (mut i32) (i32.const 0))
 (global $ready124 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $utf8-store (type $9) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 i32)
  (local $4 i32)
  (if
   (i32.eq
    (local.get $3)
    (i32.const 1)
   )
   (then
    (array.set $type16
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
   )
   (else
    (local.set $4
     (local.get $3)
    )
    (loop $label
     (array.set $type16
      (local.get $0)
      (i32.add
       (local.tee $4
        (i32.sub
         (local.get $4)
         (i32.const 1)
        )
       )
       (local.get $1)
      )
      (i32.or
       (i32.and
        (local.get $2)
        (i32.const 63)
       )
       (i32.const 128)
      )
     )
     (local.set $2
      (i32.shr_u
       (local.get $2)
       (i32.const 6)
      )
     )
     (br_if $label
      (i32.gt_u
       (local.get $4)
       (i32.const 1)
      )
     )
    )
    (array.set $type16
     (local.get $0)
     (local.get $1)
     (i32.or
      (if (result i32)
       (i32.eq
        (local.get $3)
        (i32.const 2)
       )
       (then
        (i32.const 192)
       )
       (else
        (select
         (i32.const 224)
         (i32.const 240)
         (i32.eq
          (local.get $3)
          (i32.const 3)
         )
        )
       )
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $utf8-read (type $8) (param $0 (ref $type16)) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (if
   (i32.lt_u
    (local.tee $2
     (array.get_u $type16
      (local.get $0)
      (local.get $1)
     )
    )
    (i32.const 128)
   )
   (then
    (return
     (local.get $2)
    )
   )
  )
  (local.set $2
   (i32.and
    (local.get $2)
    (i32.shr_u
     (i32.const 127)
     (local.tee $4
      (if (result i32)
       (i32.lt_u
        (local.get $2)
        (i32.const 128)
       )
       (then
        (i32.const 1)
       )
       (else
        (if (result i32)
         (i32.lt_u
          (local.get $2)
          (i32.const 224)
         )
         (then
          (i32.const 2)
         )
         (else
          (select
           (i32.const 3)
           (i32.const 4)
           (i32.lt_u
            (local.get $2)
            (i32.const 240)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $3
   (i32.const 1)
  )
  (loop $label
   (local.set $2
    (i32.or
     (i32.and
      (array.get_u $type16
       (local.get $0)
       (i32.add
        (local.get $1)
        (local.get $3)
       )
      )
      (i32.const 63)
     )
     (i32.shl
      (local.get $2)
      (i32.const 6)
     )
    )
   )
   (br_if $label
    (i32.lt_u
     (local.tee $3
      (i32.add
       (local.get $3)
       (i32.const 1)
      )
     )
     (local.get $4)
    )
   )
  )
  (local.get $2)
 )
 (func $string-boundary (type $7) (param $0 (ref $type14)) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref $type16))
  (if
   (i32.lt_u
    (local.tee $4
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $4)
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (then
    (return
     (local.get $1)
    )
   )
  )
  (local.set $3
   (struct.get $type14 5
    (local.get $0)
   )
  )
  (if
   (i32.lt_u
    (local.get $1)
    (select
     (i32.sub
      (local.tee $2
       (struct.get $type14 4
        (local.get $0)
       )
      )
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (i32.const 0)
    )
    (local.set $2
     (i32.const 0)
    )
   )
  )
  (if
   (i32.lt_u
    (i32.sub
     (local.get $4)
     (local.get $1)
    )
    (select
     (i32.sub
      (local.get $2)
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (struct.get $type14 2
      (local.get $0)
     )
    )
    (local.set $2
     (local.get $4)
    )
   )
  )
  (local.set $5
   (struct.get $type14 3
    (local.get $0)
   )
  )
  (loop $label
   (if
    (i32.gt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (local.set $3
      (i32.add
       (if (result i32)
        (i32.lt_u
         (local.tee $4
          (array.get_u $type16
           (local.get $5)
           (local.get $3)
          )
         )
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $4)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $4)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
       (local.get $3)
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (loop $label2
   (if
    (i32.lt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (loop $label1
      (br_if $label1
       (i32.eq
        (i32.and
         (array.get_u $type16
          (local.get $5)
          (local.tee $3
           (i32.sub
            (local.get $3)
            (i32.const 1)
           )
          )
         )
         (i32.const 192)
        )
        (i32.const 128)
       )
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label2)
    )
   )
  )
  (struct.set $type14 4
   (local.get $0)
   (local.get $1)
  )
  (struct.set $type14 5
   (local.get $0)
   (local.get $3)
  )
  (local.get $3)
 )
 (func $string-set! (type $6) (param $0 (ref $type14)) (param $1 i64) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (local $11 (ref $type16))
  (local $12 (ref $type16))
  (if
   (i32.ne
    (struct.get $type14 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (call $utf8-store
   (block $block (result (ref $type16))
    (local.set $3
     (call $string-boundary
      (local.get $0)
      (local.tee $7
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (local.set $4
     (i32.add
      (if (result i32)
       (i32.lt_u
        (local.tee $4
         (array.get_u $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (local.get $3)
         )
        )
        (i32.const 128)
       )
       (then
        (i32.const 1)
       )
       (else
        (if (result i32)
         (i32.lt_u
          (local.get $4)
          (i32.const 224)
         )
         (then
          (i32.const 2)
         )
         (else
          (select
           (i32.const 3)
           (i32.const 4)
           (i32.lt_u
            (local.get $4)
            (i32.const 240)
           )
          )
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (drop
     (br_if $block
      (local.tee $11
       (struct.get $type14 3
        (local.get $0)
       )
      )
      (i32.eq
       (local.tee $6
        (if (result i32)
         (i32.lt_u
          (local.get $2)
          (i32.const 128)
         )
         (then
          (i32.const 1)
         )
         (else
          (if (result i32)
           (i32.lt_u
            (local.get $2)
            (i32.const 2048)
           )
           (then
            (i32.const 2)
           )
           (else
            (select
             (i32.const 3)
             (i32.const 4)
             (i32.lt_u
              (local.get $2)
              (i32.const 65536)
             )
            )
           )
          )
         )
        )
       )
       (local.tee $5
        (i32.sub
         (local.get $4)
         (local.get $3)
        )
       )
      )
     )
    )
    (local.set $12
     (local.get $11)
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (i64.extend_i32_u
         (i32.sub
          (local.tee $8
           (struct.get $type14 2
            (local.get $0)
           )
          )
          (local.get $5)
         )
        )
        (i64.extend_i32_u
         (local.get $6)
        )
       )
      )
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.lt_u
      (local.tee $9
       (array.len
        (local.get $11)
       )
      )
      (local.tee $5
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $1
         (i64.shl
          (i64.extend_i32_u
           (local.get $9)
          )
          (i64.const 1)
         )
        )
        (i64.const 4294967294)
       )
       (then
        (local.set $1
         (i64.const 4294967294)
        )
       )
      )
      (array.copy $type16 $type16
       (local.tee $12
        (array.new_default $type16
         (i32.wrap_i64
          (if (result i64)
           (i64.lt_u
            (local.get $1)
            (local.tee $10
             (i64.extend_i32_u
              (local.get $5)
             )
            )
           )
           (then
            (local.get $10)
           )
           (else
            (local.get $1)
           )
          )
         )
        )
       )
       (i32.const 0)
       (local.get $11)
       (i32.const 0)
       (local.get $3)
      )
     )
    )
    (array.copy $type16 $type16
     (local.get $12)
     (i32.add
      (local.get $3)
      (local.get $6)
     )
     (local.get $11)
     (local.get $4)
     (i32.sub
      (local.get $8)
      (local.get $4)
     )
    )
    (struct.set $type14 3
     (local.get $0)
     (local.get $12)
    )
    (struct.set $type14 2
     (local.get $0)
     (local.get $5)
    )
    (local.get $12)
   )
   (local.get $3)
   (local.get $2)
   (local.get $6)
  )
  (struct.set $type14 4
   (local.get $0)
   (local.get $7)
  )
  (struct.set $type14 5
   (local.get $0)
   (local.get $3)
  )
 )
 (func $utf8->string (type $5) (param $0 (ref $type15)) (param $1 i64) (param $2 i64) (result (ref $type14))
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 (ref $type16))
  (local $10 (ref $type16))
  (if
   (i64.gt_u
    (local.get $2)
    (i64.extend_i32_u
     (array.len
      (local.tee $9
       (struct.get $type15 1
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (local.tee $8
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (local.set $6
   (i32.wrap_i64
    (local.get $2)
   )
  )
  (loop $label1
   (if
    (i32.ne
     (local.get $4)
     (local.get $6)
    )
    (then
     (local.set $5
      (i32.const 1)
     )
     (if
      (i32.ge_u
       (local.tee $3
        (array.get_u $type16
         (local.get $9)
         (local.get $4)
        )
       )
       (i32.const 128)
      )
      (then
       (if
        (i32.or
         (i32.lt_u
          (local.get $3)
          (i32.const 194)
         )
         (i32.gt_u
          (local.get $3)
          (i32.const 244)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.gt_u
         (local.tee $5
          (if (result i32)
           (i32.lt_u
            (local.get $3)
            (i32.const 128)
           )
           (then
            (i32.const 1)
           )
           (else
            (if (result i32)
             (i32.lt_u
              (local.get $3)
              (i32.const 224)
             )
             (then
              (i32.const 2)
             )
             (else
              (select
               (i32.const 3)
               (i32.const 4)
               (i32.lt_u
                (local.get $3)
                (i32.const 240)
               )
              )
             )
            )
           )
          )
         )
         (i32.sub
          (local.get $6)
          (local.get $4)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (i32.const 1)
       )
       (loop $label
        (if
         (i32.gt_u
          (i32.sub
           (array.get_u $type16
            (local.get $9)
            (i32.add
             (local.get $3)
             (local.get $4)
            )
           )
           (i32.const 128)
          )
          (i32.const 63)
         )
         (then
          (unreachable)
         )
        )
        (br_if $label
         (i32.lt_u
          (local.tee $3
           (i32.add
            (local.get $3)
            (i32.const 1)
           )
          )
          (local.get $5)
         )
        )
       )
       (if
        (i32.ne
         (if (result i32)
          (i32.lt_u
           (local.tee $3
            (call $utf8-read
             (local.get $9)
             (local.get $4)
            )
           )
           (i32.const 128)
          )
          (then
           (i32.const 1)
          )
          (else
           (if (result i32)
            (i32.lt_u
             (local.get $3)
             (i32.const 2048)
            )
            (then
             (i32.const 2)
            )
            (else
             (select
              (i32.const 3)
              (i32.const 4)
              (i32.lt_u
               (local.get $3)
               (i32.const 65536)
              )
             )
            )
           )
          )
         )
         (local.get $5)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.or
         (i32.le_u
          (i32.sub
           (local.get $3)
           (i32.const 55296)
          )
          (i32.const 2047)
         )
         (i32.gt_u
          (local.get $3)
          (i32.const 1114111)
         )
        )
        (then
         (unreachable)
        )
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (local.get $5)
      )
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.const 1)
      )
     )
     (br $label1)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (i64.sub
      (local.get $2)
      (local.get $1)
     )
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type16 $type16
   (local.tee $10
    (array.new_default $type16
     (local.tee $4
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
   )
   (i32.const 0)
   (local.get $9)
   (local.get $8)
   (local.get $4)
  )
  (struct.new $type14
   (i32.const 1)
   (local.get $7)
   (local.get $4)
   (local.get $10)
   (i32.const 0)
   (i32.const 0)
  )
 )
 (func $string=? (type $4) (param $0 (ref $type14)) (param $1 (ref $type14)) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type16))
  (local $5 (ref $type16))
  (if
   (ref.eq
    (local.get $0)
    (local.get $1)
   )
   (then
    (return
     (i32.const 1)
    )
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type14 2
      (local.get $0)
     )
    )
    (struct.get $type14 2
     (local.get $1)
    )
   )
   (then
    (return
     (i32.const 0)
    )
   )
  )
  (local.set $4
   (struct.get $type14 3
    (local.get $0)
   )
  )
  (local.set $5
   (struct.get $type14 3
    (local.get $1)
   )
  )
  (loop $label
   (if
    (i32.ne
     (local.get $2)
     (local.get $3)
    )
    (then
     (if
      (i32.ne
       (array.get_u $type16
        (local.get $4)
        (local.get $2)
       )
       (array.get_u $type16
        (local.get $5)
        (local.get $2)
       )
      )
      (then
       (return
        (i32.const 0)
       )
      )
      (else
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const 1)
        )
       )
       (br $label)
      )
     )
     (unreachable)
    )
   )
  )
  (i32.const 1)
 )
 (func $function134 (type $3) (param $0 (ref $environment134)) (param $1 i64) (result i32)
  (local $2 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (struct.get $type15 1
       (struct.get $environment134 0
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (array.get_u $type16
        (struct.get $type15 1
         (struct.get $environment134 0
          (local.get $0)
         )
        )
        (local.tee $2
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (i64.extend_i32_u
       (array.get_u $type16
        (struct.get $type15 1
         (struct.get $environment134 1
          (local.get $0)
         )
        )
        (local.get $2)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type43 0
         (struct.get $environment134 2
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type43 1
         (struct.get $environment134 2
          (local.get $0)
         )
        )
       )
      )
      (return_call $function134
       (local.get $0)
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $main (result i64)
  (local $0 (ref $type14))
  (local $1 (ref $type43))
  (local $2 (ref $type15))
  (local $3 (ref $type15))
  (local $4 (ref $type16))
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type38)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global112
   (struct.new_default $type39)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global113
   (struct.new_default $type40)
  )
  (global.set $ready113
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type41)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global115
   (global.get $string0)
  )
  (global.set $ready115
   (i32.const 1)
  )
  (global.set $global116
   (global.get $bytes0)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i64.lt_u
    (local.tee $8
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.tee $0
        (ref.as_non_null
         (global.get $global115)
        )
       )
      )
     )
    )
    (local.get $8)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (call $string-boundary
    (local.get $0)
    (i32.const 0)
   )
  )
  (array.copy $type16 $type16
   (local.tee $4
    (array.new_default $type16
     (local.tee $7
      (i32.sub
       (call $string-boundary
        (local.get $0)
        (i32.wrap_i64
         (local.get $8)
        )
       )
       (local.get $6)
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type14 3
    (local.get $0)
   )
   (local.get $6)
   (local.get $7)
  )
  (global.set $global117
   (struct.new $type15
    (i32.const 1)
    (local.get $4)
   )
  )
  (global.set $ready117
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (global.set $global118
   (call $utf8->string
    (local.get $2)
    (i64.const 0)
    (i64.extend_i32_u
     (array.len
      (struct.get $type15 1
       (local.get $2)
      )
     )
    )
   )
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global119
   (call $utf8->string
    (global.get $bytes1)
    (i64.const 1)
    (i64.const 1)
   )
  )
  (global.set $ready119
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (global.set $global120
   (call $utf8->string
    (global.get $bytes2)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global121
   (struct.new_default $type42)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (local.set $4
   (array.new $type16
    (i32.const 955)
    (i32.const 34000)
   )
  )
  (loop $label
   (if
    (i32.ne
     (local.get $5)
     (i32.const 34000)
    )
    (then
     (call $utf8-store
      (local.get $4)
      (local.get $5)
      (i32.const 955)
      (i32.const 2)
     )
     (local.set $5
      (i32.add
       (local.get $5)
       (i32.const 2)
      )
     )
     (br $label)
    )
   )
  )
  (global.set $global122
   (struct.new $type14
    (i32.const 1)
    (i32.const 17000)
    (i32.const 34000)
    (local.get $4)
    (i32.const 0)
    (i32.const 0)
   )
  )
  (global.set $ready122
   (i32.const 1)
  )
  (call $string-set!
   (ref.as_non_null
    (global.get $global122)
   )
   (i64.const 8192)
   (i32.const 128512)
  )
  (if
   (i32.eqz
    (global.get $ready122)
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i64.lt_u
    (local.tee $8
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
    )
    (local.get $8)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-boundary
    (local.get $0)
    (i32.const 0)
   )
  )
  (array.copy $type16 $type16
   (local.tee $4
    (array.new_default $type16
     (local.tee $6
      (i32.sub
       (call $string-boundary
        (local.get $0)
        (i32.wrap_i64
         (local.get $8)
        )
       )
       (local.get $5)
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type14 3
    (local.get $0)
   )
   (local.get $5)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (global.set $global123
   (call $utf8->string
    (local.tee $2
     (struct.new $type15
      (i32.const 1)
      (local.get $4)
     )
    )
    (i64.const 0)
    (i64.extend_i32_u
     (array.len
      (struct.get $type15 1
       (local.get $2)
      )
     )
    )
   )
  )
  (global.set $ready123
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready117)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (global.set $global124
   (if (result i32)
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (array.len
        (struct.get $type15 1
         (local.get $2)
        )
       )
      )
      (i64.extend_i32_u
       (array.len
        (struct.get $type15 1
         (local.get $3)
        )
       )
      )
     )
     (then
      (struct.set $type43 1
       (local.tee $1
        (struct.new_default $type43)
       )
       (struct.new $type44
        (struct.new $environment134
         (local.get $2)
         (local.get $3)
         (local.get $1)
        )
       )
      )
      (struct.set $type43 0
       (local.get $1)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type43 0
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (call $function134
       (struct.get $type44 0
        (struct.get $type43 1
         (local.get $1)
        )
       )
       (i64.const 0)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i32.eqz
       (global.get $ready118)
      )
      (then
       (unreachable)
      )
     )
     (call $string=?
      (ref.as_non_null
       (global.get $global118)
      )
      (block (result (ref $type14))
       (if
        (i32.eqz
         (global.get $ready115)
        )
        (then
         (unreachable)
        )
       )
       (ref.as_non_null
        (global.get $global115)
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (global.set $ready124
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready117)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type15 0
     (local.tee $2
      (ref.as_non_null
       (global.get $global117)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type16
   (struct.get $type15 1
    (local.get $2)
   )
   (i32.const 0)
   (i32.const 42)
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (call $string-set!
   (ref.as_non_null
    (global.get $global118)
   )
   (i64.const 0)
   (i32.const 65)
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (global.get $global124)
     (then
      (if
       (i32.eqz
        (global.get $ready123)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (call $string=?
        (ref.as_non_null
         (global.get $global123)
        )
        (block (result (ref $type14))
         (if
          (i32.eqz
           (global.get $ready122)
          )
          (then
           (unreachable)
          )
         )
         (ref.as_non_null
          (global.get $global122)
         )
        )
       )
       (then
        (if
         (i32.eqz
          (global.get $ready116)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (i64.eqz
          (i64.extend_i32_u
           (array.get_u $type16
            (struct.get $type15 1
             (global.get $global116)
            )
            (i32.const 0)
           )
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready115)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.eqz
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.tee $0
               (ref.as_non_null
                (global.get $global115)
               )
              )
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (if (result i32)
           (call $utf8-read
            (struct.get $type14 3
             (local.get $0)
            )
            (call $string-boundary
             (local.get $0)
             (i32.const 0)
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i32.eqz
              (global.get $ready119)
             )
             (then
              (unreachable)
             )
            )
            (if (result i32)
             (ref.eq
              (ref.as_non_null
               (global.get $global119)
              )
              (block (result (ref $type14))
               (if
                (i32.eqz
                 (global.get $ready120)
                )
                (then
                 (unreachable)
                )
               )
               (ref.as_non_null
                (global.get $global120)
               )
              )
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready114)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global114)
               )
              )
              (local.set $5
               (call $string-boundary
                (local.tee $0
                 (global.get $string1)
                )
                (i32.const 0)
               )
              )
              (array.copy $type16 $type16
               (array.new_default $type16
                (local.tee $6
                 (i32.sub
                  (call $string-boundary
                   (local.get $0)
                   (i32.const 0)
                  )
                  (local.get $5)
                 )
                )
               )
               (i32.const 0)
               (struct.get $type14 3
                (local.get $0)
               )
               (local.get $5)
               (local.get $6)
              )
              (if
               (i32.eqz
                (global.get $ready114)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global114)
               )
              )
              (local.set $5
               (call $string-boundary
                (local.tee $0
                 (global.get $string1)
                )
                (i32.const 0)
               )
              )
              (array.copy $type16 $type16
               (array.new_default $type16
                (local.tee $6
                 (i32.sub
                  (call $string-boundary
                   (local.get $0)
                   (i32.const 0)
                  )
                  (local.get $5)
                 )
                )
               )
               (i32.const 0)
               (struct.get $type14 3
                (local.get $0)
               )
               (local.get $5)
               (local.get $6)
              )
              (if (result i32)
               (call $string=?
                (call $utf8->string
                 (global.get $bytes3)
                 (i64.const 1)
                 (i64.const 4)
                )
                (global.get $string2)
               )
               (then
                (local.set $5
                 (call $string-boundary
                  (local.tee $0
                   (global.get $string3)
                  )
                  (i32.const 1)
                 )
                )
                (array.copy $type16 $type16
                 (local.tee $4
                  (array.new_default $type16
                   (local.tee $6
                    (i32.sub
                     (call $string-boundary
                      (local.get $0)
                      (i32.const 3)
                     )
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (i32.const 0)
                 (struct.get $type14 3
                  (local.get $0)
                 )
                 (local.get $5)
                 (local.get $6)
                )
                (if
                 (i32.eqz
                  (global.get $ready121)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global121)
                 )
                )
                (if (result i32)
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (struct.get $type15 1
                      (local.tee $2
                       (struct.new $type15
                        (i32.const 1)
                        (local.get $4)
                       )
                      )
                     )
                    )
                   )
                   (i64.const 6)
                  )
                  (then
                   (struct.set $type43 1
                    (local.tee $1
                     (struct.new_default $type43)
                    )
                    (struct.new $type44
                     (struct.new $environment134
                      (local.get $2)
                      (global.get $bytes4)
                      (local.get $1)
                     )
                    )
                   )
                   (struct.set $type43 0
                    (local.get $1)
                    (i32.const 1)
                   )
                   (if
                    (i32.eqz
                     (struct.get $type43 0
                      (local.get $1)
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (call $function134
                    (struct.get $type44 0
                     (struct.get $type43 1
                      (local.get $1)
                     )
                    )
                    (i64.const 0)
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                 (then
                  (if
                   (i32.eqz
                    (global.get $ready113)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global113)
                   )
                  )
                  (local.set $5
                   (call $string-boundary
                    (local.tee $0
                     (global.get $string4)
                    )
                    (i32.const 1)
                   )
                  )
                  (array.copy $type16 $type16
                   (local.tee $4
                    (array.new_default $type16
                     (local.tee $6
                      (i32.sub
                       (call $string-boundary
                        (local.get $0)
                        (i32.const 2)
                       )
                       (local.get $5)
                      )
                     )
                    )
                   )
                   (i32.const 0)
                   (struct.get $type14 3
                    (local.get $0)
                   )
                   (local.get $5)
                   (local.get $6)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready121)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global121)
                   )
                  )
                  (if (result i32)
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (struct.get $type15 1
                        (local.tee $2
                         (struct.new $type15
                          (i32.const 1)
                          (local.get $4)
                         )
                        )
                       )
                      )
                     )
                     (i64.const 2)
                    )
                    (then
                     (struct.set $type43 1
                      (local.tee $1
                       (struct.new_default $type43)
                      )
                      (struct.new $type44
                       (struct.new $environment134
                        (local.get $2)
                        (global.get $bytes5)
                        (local.get $1)
                       )
                      )
                     )
                     (struct.set $type43 0
                      (local.get $1)
                      (i32.const 1)
                     )
                     (if
                      (i32.eqz
                       (struct.get $type43 0
                        (local.get $1)
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function134
                      (struct.get $type44 0
                       (struct.get $type43 1
                        (local.get $1)
                       )
                      )
                      (i64.const 0)
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (global.get $ready111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global111)
                     )
                    )
                    (call $string=?
                     (call $utf8->string
                      (global.get $bytes6)
                      (i64.const 1)
                      (i64.const 3)
                     )
                     (global.get $string5)
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

