fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-gc-hotpath-20261016/build/native/attempt-4-0/direct-self-environment.native-12317-0/module.bc");
}
