(module
 (rec
  (type $type30 (struct (field (ref $type31))))
  (type $type31 (struct (field (mut i64))))
  (type $environment124 (struct (field (ref $type30)) (field (ref $type29))))
  (type $type29 (struct (field (mut i32)) (field (mut (ref null $type26)))))
  (type $environment110 (struct (field (ref $type29))))
  (type $call26 (func (param (ref struct) i64) (result i64)))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type26 (struct (field (ref $call26)) (field (ref struct))))
  (type $type25 (struct))
 )
 (type $10 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type25)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global84 (mut (ref null $type26)) (ref.null none))
 (global $ready84 (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type26)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global86 (mut (ref null $type26)) (ref.null none))
 (global $ready86 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type27)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global89 (mut (ref null $type28)) (ref.null none))
 (global $ready89 (mut i32) (i32.const 0))
 (global $global102 (mut (ref null $type25)) (ref.null none))
 (global $global87 (mut (ref null $type26)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $function110 (type $call26) (param $0 (ref struct)) (param $1 i64) (result i64)
  (local $2 (ref $environment110))
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (drop
     (ref.cast (ref $environment110)
      (local.get $0)
     )
    )
    (i64.const 39)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type29 0
       (struct.get $environment110 0
        (ref.cast (ref $environment110)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type29 1
       (struct.get $environment110 0
        (local.tee $2
         (ref.cast (ref $environment110)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (i64.add
     (call $function110
      (local.get $2)
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
     (i64.const 1)
    )
   )
  )
 )
 (func $function124 (type $call26) (param $0 (ref struct)) (param $1 i64) (result i64)
  (local $2 (ref $environment124))
  (local $3 (ref $type29))
  (local $4 (ref $type31))
  (local.set $3
   (struct.get $environment124 1
    (local.tee $2
     (ref.cast (ref $environment124)
      (local.get $0)
     )
    )
   )
  )
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type31 0
     (struct.get $type30 0
      (struct.get $environment124 0
       (local.get $2)
      )
     )
    )
   )
   (else
    (struct.set $type31 0
     (local.tee $4
      (struct.get $type30 0
       (struct.get $environment124 0
        (local.get $2)
       )
      )
     )
     (i64.add
      (struct.get $type31 0
       (local.get $4)
      )
      (i64.const 1)
     )
    )
    (if
     (i64.eq
      (local.get $1)
      (i64.const 2)
     )
     (then
      (if
       (i32.eqz
        (struct.get $type29 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function124
       (struct.get $type26 1
        (struct.get $type29 1
         (local.get $3)
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (struct.get $type29 0
         (struct.get $environment124 1
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type29 1
         (struct.get $environment124 1
          (local.get $2)
         )
        )
       )
      )
      (return_call $function124
       (local.get $2)
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $main (result i64)
  (local $0 (ref $type29))
  (local $1 (ref $type26))
  (local $2 i64)
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type25)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (struct.set $type29 1
   (local.tee $0
    (struct.new_default $type29)
   )
   (struct.new $type26
    (ref.func $function124)
    (struct.new $environment124
     (struct.new $type30
      (struct.new $type31
       (i64.const 10)
      )
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type29 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type29 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global84
   (ref.as_non_null
    (struct.get $type29 1
     (local.get $0)
    )
   )
  )
  (global.set $ready84
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (struct.set $type29 1
   (local.tee $0
    (struct.new_default $type29)
   )
   (struct.new $type26
    (ref.func $function124)
    (struct.new $environment124
     (struct.new $type30
      (struct.new $type31
       (i64.const 20)
      )
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type29 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type29 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global85
   (ref.as_non_null
    (struct.get $type29 1
     (local.get $0)
    )
   )
  )
  (global.set $ready85
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global86
   (ref.as_non_null
    (global.get $global84)
   )
  )
  (global.set $ready86
   (i32.const 1)
  )
  (global.set $global88
   (struct.new_default $type27)
  )
  (global.set $ready88
   (i32.const 1)
  )
  (global.set $global89
   (struct.new_default $type28)
  )
  (global.set $ready89
   (i32.const 1)
  )
  (global.set $global102
   (struct.new_default $type25)
  )
  (drop
   (ref.as_non_null
    (global.get $global102)
   )
  )
  (struct.set $type29 1
   (local.tee $0
    (struct.new_default $type29)
   )
   (struct.new $type26
    (ref.func $function110)
    (struct.new $environment110
     (local.get $0)
    )
   )
  )
  (struct.set $type29 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type29 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global87
   (ref.as_non_null
    (struct.get $type29 1
     (local.get $0)
    )
   )
  )
  (global.set $ready87
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready84)
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch
   (if (result i64)
    (i64.eq
     (call_ref $call26
      (struct.get $type26 1
       (local.tee $1
        (ref.as_non_null
         (global.get $global84)
        )
       )
      )
      (i64.const 3)
      (struct.get $type26 0
       (local.get $1)
      )
     )
     (i64.const 13)
    )
    (then
     (if
      (i32.eqz
       (global.get $ready85)
      )
      (then
       (unreachable)
      )
     )
     (if (result i64)
      (i64.eq
       (call_ref $call26
        (struct.get $type26 1
         (local.tee $1
          (ref.as_non_null
           (global.get $global85)
          )
         )
        )
        (i64.const 2)
        (struct.get $type26 0
         (local.get $1)
        )
       )
       (i64.const 22)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready86)
        )
        (then
         (unreachable)
        )
       )
       (if (result i64)
        (i64.eq
         (call_ref $call26
          (struct.get $type26 1
           (local.tee $1
            (ref.as_non_null
             (global.get $global86)
            )
           )
          )
          (i64.const 2)
          (struct.get $type26 0
           (local.get $1)
          )
         )
         (i64.const 15)
        )
        (then
         (if
          (i32.eqz
           (global.get $ready88)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global88)
          )
         )
         (if
          (i32.eqz
           (global.get $ready88)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global88)
          )
         )
         (if
          (i32.eqz
           (global.get $ready88)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global88)
          )
         )
         (if
          (i32.eqz
           (global.get $ready88)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global88)
          )
         )
         (if
          (i32.eqz
           (global.get $ready89)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global89)
          )
         )
         (if
          (i32.eqz
           (global.get $ready89)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global89)
          )
         )
         (if
          (i32.eqz
           (global.get $ready89)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global89)
          )
         )
         (if
          (i32.eqz
           (global.get $ready89)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global89)
          )
         )
         (if
          (i32.eqz
           (global.get $ready87)
          )
          (then
           (unreachable)
          )
         )
         (select
          (i64.const 42)
          (i64.const 0)
          (i64.eq
           (call_ref $call26
            (struct.get $type26 1
             (local.tee $1
              (ref.as_non_null
               (global.get $global87)
              )
             )
            )
            (i64.const 3)
            (struct.get $type26 0
             (local.get $1)
            )
           )
           (i64.const 42)
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
      )
      (else
       (i64.const 0)
      )
     )
    )
    (else
     (i64.const 0)
    )
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (local.get $scratch)
 )
)

