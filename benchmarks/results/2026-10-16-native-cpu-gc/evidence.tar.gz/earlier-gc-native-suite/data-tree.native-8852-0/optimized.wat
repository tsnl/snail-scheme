(module
 (rec
  (type $type27 (sub (struct)))
  (type $type32 (sub (struct)))
  (type $type28 (sub (struct (field (ref $type27)))))
  (type $type29 (struct))
  (type $type25 (struct))
 )
 (type $5 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type25)) (ref.null none))
 (global $global83 (mut (ref null $type29)) (ref.null none))
 (global $global80 (mut (ref null $type28)) (ref.null none))
 (global $global81 (mut (ref null $type32)) (ref.null none))
 (export "main" (func $main))
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type25)
  )
  (global.set $global83
   (struct.new_default $type29)
  )
  (global.set $global80
   (struct.new $type28
    (struct.new_default $type27)
   )
  )
  (global.set $global81
   (struct.new_default $type32)
  )
  (drop
   (ref.as_non_null
    (global.get $global82)
   )
  )
  (drop
   (struct.get $type28 0
    (global.get $global80)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global83)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 14)
 )
)

