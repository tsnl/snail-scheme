(module
 (type $0 (func (result i32)))
 (type $1 (func))
 (table $0 1 funcref)
 (elem $0 (i32.const 1) $0)
 (export "size" (func $1))
 (export "main" (func $2))
 (func $0
  (unreachable)
 )
 (func $1 (result i32)
  (table.size $0)
 )
 (func $2 (result i32)
  (i32.const 0)
 )
)

