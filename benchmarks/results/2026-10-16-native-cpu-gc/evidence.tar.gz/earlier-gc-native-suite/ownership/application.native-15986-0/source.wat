(module
(rec (type $top-scalar (struct (field i32) (field i64))) (type $top-reference (struct (field i32) (field eqref))))
(global $execution (mut i32) (i32.const 0))
(func $main (export "main") (result i32) (local $local0 i32) (block (result i32) (if (global.get $execution) (then (unreachable))) (global.set $execution (i32.const 1)) (local.set $local0 (block (result i32) (i32.const 42))) (global.set $execution (i32.const 2)) (local.get $local0)))
)
