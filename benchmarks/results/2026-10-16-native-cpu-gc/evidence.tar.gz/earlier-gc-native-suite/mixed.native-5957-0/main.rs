unsafe extern "C" { fn native_module_init(); #[link_name = "wasm.main"] fn guest_main() -> i32; }
fn main() {
    snail_runtime::native::initialize_host();
    unsafe { native_module_init(); }
    let value = unsafe { guest_main() } as i64;
    let status = if (0..=255).contains(&value) { value as i32 } else { 1 };
    std::process::exit(snail_runtime::native::native_finish(status));
}

extern crate snail_runtime as _;
extern crate wasm_native_d467d7fde366051105b258c34aad5172b7d51e9f79aed759f144a8d7991724ca_provider_0 as _;
