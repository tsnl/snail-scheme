(module
 (type $0 (func (param i32) (result i32)))
 (type $1 (func (param i32)))
 (type $2 (func (param f32) (result f32)))
 (type $3 (func (param i32 i64 f32 f64) (result i64)))
 (type $4 (func (param i64 f64) (result f64)))
 (type $5 (func (result i32)))
 (import "fixture" "scalar_i32" (func $foreign0 (param i32) (result i32)))
 (import "fixture" "scalar_unit" (func $foreign1 (param i32)))
 (import "fixture" "scalar_f32" (func $foreign2 (param f32) (result f32)))
 (import "fixture" "mixed_scalar" (func $foreign3 (param i32 i64 f32 f64) (result i64)))
 (import "fixture" "scalar_f64" (func $foreign4 (param i64 f64) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $main (result i32)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (call $foreign1
   (call $foreign0
    (i32.const 128512)
   )
  )
  (if
   (i32.eqz
    (call $foreign0
     (f64.eq
      (call $foreign4
       (call $foreign3
        (i32.const -17)
        (i64.const -9223372036854775801)
        (call $foreign2
         (f32.const 1.25)
        )
        (f64.const -2.5)
       )
       (f64.const -2.5)
      )
      (f64.const 3.5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (i32.const 0)
 )
)

