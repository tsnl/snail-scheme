(module
 (type $0 (func (result i64)))
 (rec
  (type $type14 (struct (field i32)))
  (type $2 (func (param (ref $type15) i64 i64) (result (ref $type14))))
  (type $type5 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type15 (struct (field (ref $type16))))
  (type $type16 (array (mut i8)))
 )
 (global $execution (mut i32) (i32.const 0))
 (global $bytes0 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 1
   (i32.const 65)
  )
 ))
 (global $bytes1 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 0)
 ))
 (global $bytes2 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 2
   (i32.const 195)
   (i32.const 169)
  )
 ))
 (global $bytes3 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 4
   (i32.const 244)
   (i32.const 144)
   (i32.const 128)
   (i32.const 128)
  )
 ))
 (global $bytes4 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 3
   (i32.const 237)
   (i32.const 160)
   (i32.const 128)
  )
 ))
 (global $bytes5 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 4
   (i32.const 240)
   (i32.const 143)
   (i32.const 191)
   (i32.const 191)
  )
 ))
 (global $bytes6 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 3
   (i32.const 224)
   (i32.const 159)
   (i32.const 191)
  )
 ))
 (global $bytes7 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 2
   (i32.const 192)
   (i32.const 128)
  )
 ))
 (global $bytes8 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 3
   (i32.const 224)
   (i32.const 65)
   (i32.const 128)
  )
 ))
 (global $bytes9 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 3
   (i32.const 240)
   (i32.const 144)
   (i32.const 128)
  )
 ))
 (global $bytes10 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 2
   (i32.const 224)
   (i32.const 160)
  )
 ))
 (global $bytes11 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 1
   (i32.const 194)
  )
 ))
 (global $bytes12 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 1
   (i32.const 255)
  )
 ))
 (global $bytes13 (ref $type15) (struct.new $type15
  (array.new_fixed $type16 1
   (i32.const 128)
  )
 ))
 (global $global119 (mut (ref null $type38)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type39)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type5)) (ref.null none))
 (global $ready123 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type5)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type5)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type5)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type5)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global128 (mut (ref null $type5)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type5)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type5)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type5)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type5)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type5)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type5)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type5)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type5)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type5)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type5)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type5)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global140 (mut (ref null $type5)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (export "isolated-tail" (func $export0))
 (export "invalid-lead" (func $export1))
 (export "truncated-two" (func $export2))
 (export "truncated-three" (func $export3))
 (export "truncated-four" (func $export4))
 (export "bad-tail" (func $export5))
 (export "overlong-two" (func $export6))
 (export "overlong-three" (func $export7))
 (export "overlong-four" (func $export8))
 (export "surrogate" (func $export9))
 (export "too-large" (func $export10))
 (export "cut-start" (func $export11))
 (export "cut-end" (func $export12))
 (export "negative-start" (func $export13))
 (export "past-end" (func $export14))
 (export "reversed" (func $export15))
 (export "encode-range" (func $export16))
 (export "encode-negative" (func $export17))
 (export "main" (func $main))
 (func $utf8->string (type $2) (param $0 (ref $type15)) (param $1 i64) (param $2 i64) (result (ref $type14))
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 (ref $type16))
  (if
   (i64.gt_u
    (local.get $2)
    (i64.extend_i32_u
     (array.len
      (local.tee $11
       (struct.get $type15 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (local.tee $9
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (local.set $7
   (i32.wrap_i64
    (local.get $2)
   )
  )
  (loop $label2
   (if
    (i32.ne
     (local.get $4)
     (local.get $7)
    )
    (then
     (local.set $5
      (i32.const 1)
     )
     (if
      (i32.ge_u
       (local.tee $3
        (array.get_u $type16
         (local.get $11)
         (local.get $4)
        )
       )
       (i32.const 128)
      )
      (then
       (if
        (i32.or
         (i32.lt_u
          (local.get $3)
          (i32.const 194)
         )
         (i32.gt_u
          (local.get $3)
          (i32.const 244)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.gt_u
         (local.tee $5
          (if (result i32)
           (i32.lt_u
            (local.get $3)
            (i32.const 128)
           )
           (then
            (i32.const 1)
           )
           (else
            (if (result i32)
             (i32.lt_u
              (local.get $3)
              (i32.const 224)
             )
             (then
              (i32.const 2)
             )
             (else
              (select
               (i32.const 3)
               (i32.const 4)
               (i32.lt_u
                (local.get $3)
                (i32.const 240)
               )
              )
             )
            )
           )
          )
         )
         (i32.sub
          (local.get $7)
          (local.get $4)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (i32.const 1)
       )
       (loop $label
        (if
         (i32.gt_u
          (i32.sub
           (array.get_u $type16
            (local.get $11)
            (i32.add
             (local.get $3)
             (local.get $4)
            )
           )
           (i32.const 128)
          )
          (i32.const 63)
         )
         (then
          (unreachable)
         )
        )
        (br_if $label
         (i32.lt_u
          (local.tee $3
           (i32.add
            (local.get $3)
            (i32.const 1)
           )
          )
          (local.get $5)
         )
        )
       )
       (if
        (i32.ne
         (if (result i32)
          (i32.lt_u
           (local.tee $3
            (block $block (result i32)
             (if
              (i32.lt_u
               (local.tee $3
                (array.get_u $type16
                 (local.get $11)
                 (local.get $4)
                )
               )
               (i32.const 128)
              )
              (then
               (br $block
                (local.get $3)
               )
              )
             )
             (local.set $3
              (i32.and
               (local.get $3)
               (i32.shr_u
                (i32.const 127)
                (local.tee $10
                 (if (result i32)
                  (i32.lt_u
                   (local.get $3)
                   (i32.const 128)
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (if (result i32)
                    (i32.lt_u
                     (local.get $3)
                     (i32.const 224)
                    )
                    (then
                     (i32.const 2)
                    )
                    (else
                     (select
                      (i32.const 3)
                      (i32.const 4)
                      (i32.lt_u
                       (local.get $3)
                       (i32.const 240)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (local.set $6
              (i32.const 1)
             )
             (loop $label1
              (local.set $3
               (i32.or
                (i32.and
                 (array.get_u $type16
                  (local.get $11)
                  (i32.add
                   (local.get $4)
                   (local.get $6)
                  )
                 )
                 (i32.const 63)
                )
                (i32.shl
                 (local.get $3)
                 (i32.const 6)
                )
               )
              )
              (br_if $label1
               (i32.lt_u
                (local.tee $6
                 (i32.add
                  (local.get $6)
                  (i32.const 1)
                 )
                )
                (local.get $10)
               )
              )
             )
             (local.get $3)
            )
           )
           (i32.const 128)
          )
          (then
           (i32.const 1)
          )
          (else
           (if (result i32)
            (i32.lt_u
             (local.get $3)
             (i32.const 2048)
            )
            (then
             (i32.const 2)
            )
            (else
             (select
              (i32.const 3)
              (i32.const 4)
              (i32.lt_u
               (local.get $3)
               (i32.const 65536)
              )
             )
            )
           )
          )
         )
         (local.get $5)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.or
         (i32.le_u
          (i32.sub
           (local.get $3)
           (i32.const 55296)
          )
          (i32.const 2047)
         )
         (i32.gt_u
          (local.get $3)
          (i32.const 1114111)
         )
        )
        (then
         (unreachable)
        )
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (local.get $5)
      )
     )
     (local.set $8
      (i32.add
       (local.get $8)
       (i32.const 1)
      )
     )
     (br $label2)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (i64.sub
      (local.get $2)
      (local.get $1)
     )
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type16 $type16
   (array.new_default $type16
    (local.tee $4
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
   (i32.const 0)
   (local.get $11)
   (local.get $9)
   (local.get $4)
  )
  (struct.new $type14
   (local.get $8)
  )
 )
 (func $export0 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes13)
     (i64.const 0)
     (i64.const 1)
    )
   )
  )
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes12)
     (i64.const 0)
     (i64.const 1)
    )
   )
  )
 )
 (func $export2 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes11)
     (i64.const 0)
     (i64.const 1)
    )
   )
  )
 )
 (func $export3 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes10)
     (i64.const 0)
     (i64.const 2)
    )
   )
  )
 )
 (func $export4 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes9)
     (i64.const 0)
     (i64.const 3)
    )
   )
  )
 )
 (func $export5 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready128)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global128)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes8)
     (i64.const 0)
     (i64.const 3)
    )
   )
  )
 )
 (func $export6 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes7)
     (i64.const 0)
     (i64.const 2)
    )
   )
  )
 )
 (func $export7 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes6)
     (i64.const 0)
     (i64.const 3)
    )
   )
  )
 )
 (func $export8 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready131)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes5)
     (i64.const 0)
     (i64.const 4)
    )
   )
  )
 )
 (func $export9 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes4)
     (i64.const 0)
     (i64.const 3)
    )
   )
  )
 )
 (func $export10 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes3)
     (i64.const 0)
     (i64.const 4)
    )
   )
  )
 )
 (func $export11 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready119)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes2)
     (i64.const 1)
     (i64.const 2)
    )
   )
  )
 )
 (func $export12 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes2)
     (i64.const 0)
     (i64.const 1)
    )
   )
  )
 )
 (func $export13 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes1)
     (i64.const -1)
     (i64.const 0)
    )
   )
  )
 )
 (func $export14 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes1)
     (i64.const 1)
     (i64.const 1)
    )
   )
  )
 )
 (func $export15 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (i64.extend_i32_u
   (struct.get $type14 0
    (call $utf8->string
     (global.get $bytes0)
     (i64.const 1)
     (i64.const 0)
    )
   )
  )
 )
 (func $export16 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (unreachable)
 )
 (func $export17 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready140)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global140)
   )
  )
  (unreachable)
 )
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type38)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type39)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global123
   (struct.new_default $type5)
  )
  (global.set $ready123
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type5)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global125
   (struct.new_default $type5)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type5)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type5)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global128
   (struct.new_default $type5)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type5)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type5)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global131
   (struct.new_default $type5)
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type5)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type5)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type5)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type5)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type5)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type5)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type5)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type5)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global140
   (struct.new_default $type5)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

