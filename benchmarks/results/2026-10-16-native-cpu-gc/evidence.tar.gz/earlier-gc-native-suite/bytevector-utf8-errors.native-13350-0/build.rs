fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-gc-hotpath-20261016/build/native/attempt-4-0/bytevector-utf8-errors.native-13350-0/module.bc");
}
