#[path = "/tmp/snail-native-gc-hotpath-20261016/tests/native-support.rs"] mod support;
unsafe extern "C" { #[link_name="wasm.main"] fn guest_main()->i64;
#[link_name = "wasm.isolated-tail"] fn probe0() -> i64;
#[link_name = "wasm.invalid-lead"] fn probe1() -> i64;
#[link_name = "wasm.truncated-two"] fn probe2() -> i64;
#[link_name = "wasm.truncated-three"] fn probe3() -> i64;
#[link_name = "wasm.truncated-four"] fn probe4() -> i64;
#[link_name = "wasm.bad-tail"] fn probe5() -> i64;
#[link_name = "wasm.overlong-two"] fn probe6() -> i64;
#[link_name = "wasm.overlong-three"] fn probe7() -> i64;
#[link_name = "wasm.overlong-four"] fn probe8() -> i64;
#[link_name = "wasm.surrogate"] fn probe9() -> i64;
#[link_name = "wasm.too-large"] fn probe10() -> i64;
#[link_name = "wasm.cut-start"] fn probe11() -> i64;
#[link_name = "wasm.cut-end"] fn probe12() -> i64;
#[link_name = "wasm.negative-start"] fn probe13() -> i64;
#[link_name = "wasm.past-end"] fn probe14() -> i64;
#[link_name = "wasm.reversed"] fn probe15() -> i64;
#[link_name = "wasm.encode-range"] fn probe16() -> i64;
#[link_name = "wasm.encode-negative"] fn probe17() -> i64;}
fn main(){ let a=support::initialize(); assert_eq!(a.len(),2); unsafe {assert_eq!(guest_main(),42); match a[1].as_str(){"isolated-tail" => { probe0(); },
"invalid-lead" => { probe1(); },
"truncated-two" => { probe2(); },
"truncated-three" => { probe3(); },
"truncated-four" => { probe4(); },
"bad-tail" => { probe5(); },
"overlong-two" => { probe6(); },
"overlong-three" => { probe7(); },
"overlong-four" => { probe8(); },
"surrogate" => { probe9(); },
"too-large" => { probe10(); },
"cut-start" => { probe11(); },
"cut-end" => { probe12(); },
"negative-start" => { probe13(); },
"past-end" => { probe14(); },
"reversed" => { probe15(); },
"encode-range" => { probe16(); },
"encode-negative" => { probe17(); },_=>panic!("unknown probe")}} support::finish(0);}

extern crate snail_runtime as _;
