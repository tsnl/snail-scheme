(module
 (rec
  (type $type25 (sub (struct)))
  (type $call33 (func (param eqref (ref $type25)) (result i64)))
  (type $call31 (func (param eqref i64 (ref $type25)) (result i32)))
  (type $type28 (struct (field (mut (ref $type25)))))
  (type $4 (func (param eqref i64) (result (ref $type27))))
  (type $type27 (sub $type25 (struct (field (ref $type28)) (field (ref $type28)))))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type26 (sub $type25 (struct)))
 )
 (type $12 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty26 (ref $type26) (struct.new_default $type26))
 (global $global84 (mut (ref null $type26)) (ref.null none))
 (global $ready84 (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type29)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global86 (mut (ref null $type30)) (ref.null none))
 (global $ready86 (mut i32) (i32.const 0))
 (global $global89 (mut (ref null $type31)) (ref.null none))
 (global $ready89 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type32)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type33)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type27)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $function91 (type $4) (param $0 eqref) (param $1 i64) (result (ref $type27))
  (local $2 (ref $type26))
  (local $3 (ref $type27))
  (local $4 (ref $type27))
  (local $scratch (ref $type26))
  (local $scratch_6 (ref $type27))
  (if (result (ref $type27))
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready85)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global85)
     )
    )
    (if
     (i32.eqz
      (global.get $ready84)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type27
     (struct.new $type28
      (block (result (ref $type26))
       (local.set $scratch
        (ref.as_non_null
         (global.get $global84)
        )
       )
       (if
        (i32.eqz
         (global.get $ready84)
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.new $type28
      (ref.as_non_null
       (global.get $global84)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready90)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global90)
     )
    )
    (struct.new $type27
     (struct.new $type28
      (block (result (ref $type27))
       (local.set $scratch_6
        (call $function91
         (local.get $0)
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready90)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global90)
        )
       )
       (local.set $4
        (call $function91
         (local.get $0)
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready86)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global86)
        )
       )
       (local.get $scratch_6)
      )
     )
     (struct.new $type28
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function95 (type $call31) (param $0 eqref) (param $1 i64) (param $2 (ref $type25)) (result i32)
  (local $3 (ref $type28))
  (local $4 (ref $type26))
  (local $5 (ref $type25))
  (local $scratch (ref $type26))
  (local $scratch_7 (ref $type26))
  (if (result i32)
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (ref.test (ref $type26)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type28 0
     (struct.get $type27 0
      (ref.cast (ref $type27)
       (local.get $2)
      )
     )
     (block (result (ref (exact $type27)))
      (if
       (i32.eqz
        (global.get $ready85)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global85)
       )
      )
      (if
       (i32.eqz
        (global.get $ready84)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type27
       (struct.new $type28
        (block (result (ref $type26))
         (local.set $scratch
          (ref.as_non_null
           (global.get $global84)
          )
         )
         (if
          (i32.eqz
           (global.get $ready84)
          )
          (then
           (unreachable)
          )
         )
         (local.get $scratch)
        )
       )
       (struct.new $type28
        (ref.as_non_null
         (global.get $global84)
        )
       )
      )
     )
    )
    (if
     (ref.test (ref $type26)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type28 0
     (struct.get $type27 1
      (ref.cast (ref $type27)
       (local.get $2)
      )
     )
     (block (result (ref (exact $type27)))
      (if
       (i32.eqz
        (global.get $ready85)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global85)
       )
      )
      (if
       (i32.eqz
        (global.get $ready84)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type27
       (struct.new $type28
        (block (result (ref $type26))
         (local.set $scratch_7
          (ref.as_non_null
           (global.get $global84)
          )
         )
         (if
          (i32.eqz
           (global.get $ready84)
          )
          (then
           (unreachable)
          )
         )
         (local.get $scratch_7)
        )
       )
       (struct.new $type28
        (ref.as_non_null
         (global.get $global84)
        )
       )
      )
     )
    )
    (if
     (ref.test (ref $type26)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type28 0
      (struct.get $type27 0
       (ref.cast (ref $type27)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready89)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global89)
     )
    )
    (drop
     (call $function95
      (local.get $0)
      (local.tee $1
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (local.get $5)
     )
    )
    (if
     (ref.test (ref $type26)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type28 0
      (struct.get $type27 1
       (ref.cast (ref $type27)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready89)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global89)
     )
    )
    (return_call $function95
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function105 (type $call33) (param $0 eqref) (param $1 (ref $type25)) (result i64)
  (local $2 (ref $type27))
  (local $3 (ref $type28))
  (local $4 i64)
  (if (result i64)
   (ref.test (ref $type26)
    (local.get $1)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $3
     (struct.get $type27 1
      (local.tee $2
       (ref.cast (ref $type27)
        (local.get $1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (local.set $4
     (call $function105
      (local.get $0)
      (struct.get $type28 0
       (struct.get $type27 0
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (i64.add
     (i64.add
      (call $function105
       (local.get $0)
       (struct.get $type28 0
        (local.get $3)
       )
      )
      (local.get $4)
     )
     (i64.const 1)
    )
   )
  )
 )
 (func $main (result i64)
  (local $0 (ref $type25))
  (local $1 (ref $type27))
  (local $2 (ref $type27))
  (local $3 (ref $type28))
  (local $4 (ref $type28))
  (local $5 (ref $type28))
  (local $6 (ref $type28))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $scratch (ref $type28))
  (local $scratch_14 (ref $type28))
  (local $scratch_15 (ref $type28))
  (local $scratch_16 (ref $type28))
  (local $scratch_17 (ref $type28))
  (local $scratch_18 (ref $type28))
  (local $scratch_19 (ref $type28))
  (local $scratch_20 (ref $type28))
  (local $scratch_21 (ref $type28))
  (local $scratch_22 (ref $type28))
  (local $scratch_23 (ref $type28))
  (local $scratch_24 (ref $type28))
  (local $scratch_25 (ref $type28))
  (local $scratch_26 (ref $type28))
  (local $scratch_27 (ref $type28))
  (local $scratch_28 (ref $type28))
  (local $scratch_29 (ref $type28))
  (local $scratch_30 (ref $type28))
  (local $scratch_31 (ref $type28))
  (local $scratch_32 (ref $type28))
  (local $scratch_33 (ref $type28))
  (local $scratch_34 (ref $type28))
  (local $scratch_35 (ref $type28))
  (local $scratch_36 (ref $type28))
  (local $scratch_37 (ref $type28))
  (local $scratch_38 (ref $type28))
  (local $scratch_39 (ref $type28))
  (local $scratch_40 (ref $type28))
  (local $scratch_41 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global84
   (global.get $empty26)
  )
  (global.set $ready84
   (i32.const 1)
  )
  (global.set $global85
   (struct.new_default $type29)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global86
   (struct.new_default $type30)
  )
  (global.set $ready86
   (i32.const 1)
  )
  (global.set $global89
   (struct.new_default $type31)
  )
  (global.set $ready89
   (i32.const 1)
  )
  (global.set $global90
   (struct.new_default $type32)
  )
  (global.set $ready90
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type33)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global85)
   )
  )
  (global.set $global88
   (struct.new $type27
    (struct.new $type28
     (ref.as_non_null
      (global.get $global84)
     )
    )
    (struct.new $type28
     (ref.as_non_null
      (global.get $global84)
     )
    )
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (if
   (i32.eqz
    (global.get $ready89)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global89)
   )
  )
  (drop
   (call $function95
    (ref.null none)
    (i64.const 4)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready88)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (local.set $10
   (if (result i64)
    (ref.test (ref $type26)
     (local.tee $0
      (struct.get $type28 0
       (struct.get $type27 0
        (local.get $2)
       )
      )
     )
    )
    (then
     (i64.const 0)
    )
    (else
     (i64.add
      (i64.add
       (if (result i64)
        (ref.test (ref $type26)
         (local.tee $0
          (struct.get $type28 0
           (block (result (ref $type28))
            (local.set $scratch_16
             (struct.get $type27 1
              (local.tee $1
               (ref.cast (ref $type27)
                (local.get $0)
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready87)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global87)
             )
            )
            (local.set $10
             (if (result i64)
              (ref.test (ref $type26)
               (local.tee $0
                (struct.get $type28 0
                 (struct.get $type27 0
                  (local.get $1)
                 )
                )
               )
              )
              (then
               (i64.const 0)
              )
              (else
               (i64.add
                (i64.add
                 (if (result i64)
                  (ref.test (ref $type26)
                   (local.tee $0
                    (struct.get $type28 0
                     (block (result (ref $type28))
                      (local.set $scratch_14
                       (struct.get $type27 1
                        (local.tee $1
                         (ref.cast (ref $type27)
                          (local.get $0)
                         )
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready87)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global87)
                       )
                      )
                      (local.set $10
                       (if (result i64)
                        (ref.test (ref $type26)
                         (local.tee $0
                          (struct.get $type28 0
                           (struct.get $type27 0
                            (local.get $1)
                           )
                          )
                         )
                        )
                        (then
                         (i64.const 0)
                        )
                        (else
                         (i64.add
                          (i64.add
                           (if (result i64)
                            (ref.test (ref $type26)
                             (local.tee $0
                              (struct.get $type28 0
                               (block (result (ref $type28))
                                (local.set $scratch
                                 (struct.get $type27 1
                                  (local.tee $1
                                   (ref.cast (ref $type27)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.set $10
                                 (if (result i64)
                                  (ref.test (ref $type26)
                                   (local.tee $0
                                    (struct.get $type28 0
                                     (struct.get $type27 0
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 0)
                                  )
                                  (else
                                   (local.set $6
                                    (struct.get $type27 1
                                     (local.tee $1
                                      (ref.cast (ref $type27)
                                       (local.get $0)
                                      )
                                     )
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready87)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global87)
                                    )
                                   )
                                   (local.set $10
                                    (call $function105
                                     (ref.null none)
                                     (struct.get $type28 0
                                      (struct.get $type27 0
                                       (local.get $1)
                                      )
                                     )
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready87)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global87)
                                    )
                                   )
                                   (i64.add
                                    (i64.add
                                     (call $function105
                                      (ref.null none)
                                      (struct.get $type28 0
                                       (local.get $6)
                                      )
                                     )
                                     (local.get $10)
                                    )
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.get $scratch)
                               )
                              )
                             )
                            )
                            (then
                             (i64.const 0)
                            )
                            (else
                             (local.set $5
                              (struct.get $type27 1
                               (local.tee $1
                                (ref.cast (ref $type27)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.set $8
                              (call $function105
                               (ref.null none)
                               (struct.get $type28 0
                                (struct.get $type27 0
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (i64.add
                              (i64.add
                               (call $function105
                                (ref.null none)
                                (struct.get $type28 0
                                 (local.get $5)
                                )
                               )
                               (local.get $8)
                              )
                              (i64.const 1)
                             )
                            )
                           )
                           (local.get $10)
                          )
                          (i64.const 1)
                         )
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready87)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global87)
                       )
                      )
                      (local.get $scratch_14)
                     )
                    )
                   )
                  )
                  (then
                   (i64.const 0)
                  )
                  (else
                   (i64.add
                    (i64.add
                     (if (result i64)
                      (ref.test (ref $type26)
                       (local.tee $0
                        (struct.get $type28 0
                         (block (result (ref $type28))
                          (local.set $scratch_15
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $8
                           (if (result i64)
                            (ref.test (ref $type26)
                             (local.tee $0
                              (struct.get $type28 0
                               (struct.get $type27 0
                                (local.get $1)
                               )
                              )
                             )
                            )
                            (then
                             (i64.const 0)
                            )
                            (else
                             (local.set $5
                              (struct.get $type27 1
                               (local.tee $1
                                (ref.cast (ref $type27)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.set $8
                              (call $function105
                               (ref.null none)
                               (struct.get $type28 0
                                (struct.get $type27 0
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (i64.add
                              (i64.add
                               (call $function105
                                (ref.null none)
                                (struct.get $type28 0
                                 (local.get $5)
                                )
                               )
                               (local.get $8)
                              )
                              (i64.const 1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.get $scratch_15)
                         )
                        )
                       )
                      )
                      (then
                       (i64.const 0)
                      )
                      (else
                       (local.set $3
                        (struct.get $type27 1
                         (local.tee $1
                          (ref.cast (ref $type27)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (local.set $7
                        (call $function105
                         (ref.null none)
                         (struct.get $type28 0
                          (struct.get $type27 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (i64.add
                        (i64.add
                         (call $function105
                          (ref.null none)
                          (struct.get $type28 0
                           (local.get $3)
                          )
                         )
                         (local.get $7)
                        )
                        (i64.const 1)
                       )
                      )
                     )
                     (local.get $8)
                    )
                    (i64.const 1)
                   )
                  )
                 )
                 (local.get $10)
                )
                (i64.const 1)
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready87)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global87)
             )
            )
            (local.get $scratch_16)
           )
          )
         )
        )
        (then
         (i64.const 0)
        )
        (else
         (i64.add
          (i64.add
           (if (result i64)
            (ref.test (ref $type26)
             (local.tee $0
              (struct.get $type28 0
               (block (result (ref $type28))
                (local.set $scratch_18
                 (struct.get $type27 1
                  (local.tee $1
                   (ref.cast (ref $type27)
                    (local.get $0)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready87)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global87)
                 )
                )
                (local.set $8
                 (if (result i64)
                  (ref.test (ref $type26)
                   (local.tee $0
                    (struct.get $type28 0
                     (struct.get $type27 0
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (then
                   (i64.const 0)
                  )
                  (else
                   (i64.add
                    (i64.add
                     (if (result i64)
                      (ref.test (ref $type26)
                       (local.tee $0
                        (struct.get $type28 0
                         (block (result (ref $type28))
                          (local.set $scratch_17
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $8
                           (if (result i64)
                            (ref.test (ref $type26)
                             (local.tee $0
                              (struct.get $type28 0
                               (struct.get $type27 0
                                (local.get $1)
                               )
                              )
                             )
                            )
                            (then
                             (i64.const 0)
                            )
                            (else
                             (local.set $5
                              (struct.get $type27 1
                               (local.tee $1
                                (ref.cast (ref $type27)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.set $8
                              (call $function105
                               (ref.null none)
                               (struct.get $type28 0
                                (struct.get $type27 0
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (i64.add
                              (i64.add
                               (call $function105
                                (ref.null none)
                                (struct.get $type28 0
                                 (local.get $5)
                                )
                               )
                               (local.get $8)
                              )
                              (i64.const 1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.get $scratch_17)
                         )
                        )
                       )
                      )
                      (then
                       (i64.const 0)
                      )
                      (else
                       (local.set $3
                        (struct.get $type27 1
                         (local.tee $1
                          (ref.cast (ref $type27)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (local.set $7
                        (call $function105
                         (ref.null none)
                         (struct.get $type28 0
                          (struct.get $type27 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (i64.add
                        (i64.add
                         (call $function105
                          (ref.null none)
                          (struct.get $type28 0
                           (local.get $3)
                          )
                         )
                         (local.get $7)
                        )
                        (i64.const 1)
                       )
                      )
                     )
                     (local.get $8)
                    )
                    (i64.const 1)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready87)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global87)
                 )
                )
                (local.get $scratch_18)
               )
              )
             )
            )
            (then
             (i64.const 0)
            )
            (else
             (i64.add
              (i64.add
               (if (result i64)
                (ref.test (ref $type26)
                 (local.tee $0
                  (struct.get $type28 0
                   (block (result (ref $type28))
                    (local.set $scratch_19
                     (struct.get $type27 1
                      (local.tee $1
                       (ref.cast (ref $type27)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (local.set $7
                     (if (result i64)
                      (ref.test (ref $type26)
                       (local.tee $0
                        (struct.get $type28 0
                         (struct.get $type27 0
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (then
                       (i64.const 0)
                      )
                      (else
                       (local.set $3
                        (struct.get $type27 1
                         (local.tee $1
                          (ref.cast (ref $type27)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (local.set $7
                        (call $function105
                         (ref.null none)
                         (struct.get $type28 0
                          (struct.get $type27 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (i64.add
                        (i64.add
                         (call $function105
                          (ref.null none)
                          (struct.get $type28 0
                           (local.get $3)
                          )
                         )
                         (local.get $7)
                        )
                        (i64.const 1)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (local.get $scratch_19)
                   )
                  )
                 )
                )
                (then
                 (i64.const 0)
                )
                (else
                 (local.set $4
                  (struct.get $type27 1
                   (local.tee $1
                    (ref.cast (ref $type27)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready87)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global87)
                  )
                 )
                 (local.set $9
                  (call $function105
                   (ref.null none)
                   (struct.get $type28 0
                    (struct.get $type27 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready87)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global87)
                  )
                 )
                 (i64.add
                  (i64.add
                   (call $function105
                    (ref.null none)
                    (struct.get $type28 0
                     (local.get $4)
                    )
                   )
                   (local.get $9)
                  )
                  (i64.const 1)
                 )
                )
               )
               (local.get $7)
              )
              (i64.const 1)
             )
            )
           )
           (local.get $8)
          )
          (i64.const 1)
         )
        )
       )
       (local.get $10)
      )
      (i64.const 1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready87)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global87)
   )
  )
  (local.set $scratch_41
   (i64.add
    (i64.add
     (i64.add
      (if (result i64)
       (ref.test (ref $type26)
        (local.tee $0
         (struct.get $type28 0
          (struct.get $type27 1
           (local.get $2)
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (i64.add
         (i64.add
          (if (result i64)
           (ref.test (ref $type26)
            (local.tee $0
             (struct.get $type28 0
              (block (result (ref $type28))
               (local.set $scratch_23
                (struct.get $type27 1
                 (local.tee $1
                  (ref.cast (ref $type27)
                   (local.get $0)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready87)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global87)
                )
               )
               (local.set $8
                (if (result i64)
                 (ref.test (ref $type26)
                  (local.tee $0
                   (struct.get $type28 0
                    (struct.get $type27 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (i64.const 0)
                 )
                 (else
                  (i64.add
                   (i64.add
                    (if (result i64)
                     (ref.test (ref $type26)
                      (local.tee $0
                       (struct.get $type28 0
                        (block (result (ref $type28))
                         (local.set $scratch_21
                          (struct.get $type27 1
                           (local.tee $1
                            (ref.cast (ref $type27)
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready87)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global87)
                          )
                         )
                         (local.set $8
                          (if (result i64)
                           (ref.test (ref $type26)
                            (local.tee $0
                             (struct.get $type28 0
                              (struct.get $type27 0
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (then
                            (i64.const 0)
                           )
                           (else
                            (i64.add
                             (i64.add
                              (if (result i64)
                               (ref.test (ref $type26)
                                (local.tee $0
                                 (struct.get $type28 0
                                  (block (result (ref $type28))
                                   (local.set $scratch_20
                                    (struct.get $type27 1
                                     (local.tee $1
                                      (ref.cast (ref $type27)
                                       (local.get $0)
                                      )
                                     )
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready87)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global87)
                                    )
                                   )
                                   (local.set $8
                                    (if (result i64)
                                     (ref.test (ref $type26)
                                      (local.tee $0
                                       (struct.get $type28 0
                                        (struct.get $type27 0
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 0)
                                     )
                                     (else
                                      (local.set $6
                                       (struct.get $type27 1
                                        (local.tee $1
                                         (ref.cast (ref $type27)
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready87)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global87)
                                       )
                                      )
                                      (local.set $8
                                       (call $function105
                                        (ref.null none)
                                        (struct.get $type28 0
                                         (struct.get $type27 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready87)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global87)
                                       )
                                      )
                                      (i64.add
                                       (i64.add
                                        (call $function105
                                         (ref.null none)
                                         (struct.get $type28 0
                                          (local.get $6)
                                         )
                                        )
                                        (local.get $8)
                                       )
                                       (i64.const 1)
                                      )
                                     )
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready87)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global87)
                                    )
                                   )
                                   (local.get $scratch_20)
                                  )
                                 )
                                )
                               )
                               (then
                                (i64.const 0)
                               )
                               (else
                                (local.set $5
                                 (struct.get $type27 1
                                  (local.tee $1
                                   (ref.cast (ref $type27)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.set $7
                                 (call $function105
                                  (ref.null none)
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (i64.add
                                 (i64.add
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                 (i64.const 1)
                                )
                               )
                              )
                              (local.get $8)
                             )
                             (i64.const 1)
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready87)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global87)
                          )
                         )
                         (local.get $scratch_21)
                        )
                       )
                      )
                     )
                     (then
                      (i64.const 0)
                     )
                     (else
                      (i64.add
                       (i64.add
                        (if (result i64)
                         (ref.test (ref $type26)
                          (local.tee $0
                           (struct.get $type28 0
                            (block (result (ref $type28))
                             (local.set $scratch_22
                              (struct.get $type27 1
                               (local.tee $1
                                (ref.cast (ref $type27)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.set $7
                              (if (result i64)
                               (ref.test (ref $type26)
                                (local.tee $0
                                 (struct.get $type28 0
                                  (struct.get $type27 0
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (then
                                (i64.const 0)
                               )
                               (else
                                (local.set $5
                                 (struct.get $type27 1
                                  (local.tee $1
                                   (ref.cast (ref $type27)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.set $7
                                 (call $function105
                                  (ref.null none)
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (i64.add
                                 (i64.add
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                 (i64.const 1)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.get $scratch_22)
                            )
                           )
                          )
                         )
                         (then
                          (i64.const 0)
                         )
                         (else
                          (local.set $3
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $9
                           (call $function105
                            (ref.null none)
                            (struct.get $type28 0
                             (struct.get $type27 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (i64.add
                           (i64.add
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (local.get $3)
                             )
                            )
                            (local.get $9)
                           )
                           (i64.const 1)
                          )
                         )
                        )
                        (local.get $7)
                       )
                       (i64.const 1)
                      )
                     )
                    )
                    (local.get $8)
                   )
                   (i64.const 1)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready87)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global87)
                )
               )
               (local.get $scratch_23)
              )
             )
            )
           )
           (then
            (i64.const 0)
           )
           (else
            (i64.add
             (i64.add
              (if (result i64)
               (ref.test (ref $type26)
                (local.tee $0
                 (struct.get $type28 0
                  (block (result (ref $type28))
                   (local.set $scratch_25
                    (struct.get $type27 1
                     (local.tee $1
                      (ref.cast (ref $type27)
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready87)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global87)
                    )
                   )
                   (local.set $7
                    (if (result i64)
                     (ref.test (ref $type26)
                      (local.tee $0
                       (struct.get $type28 0
                        (struct.get $type27 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (i64.const 0)
                     )
                     (else
                      (i64.add
                       (i64.add
                        (if (result i64)
                         (ref.test (ref $type26)
                          (local.tee $0
                           (struct.get $type28 0
                            (block (result (ref $type28))
                             (local.set $scratch_24
                              (struct.get $type27 1
                               (local.tee $1
                                (ref.cast (ref $type27)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.set $7
                              (if (result i64)
                               (ref.test (ref $type26)
                                (local.tee $0
                                 (struct.get $type28 0
                                  (struct.get $type27 0
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (then
                                (i64.const 0)
                               )
                               (else
                                (local.set $5
                                 (struct.get $type27 1
                                  (local.tee $1
                                   (ref.cast (ref $type27)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.set $7
                                 (call $function105
                                  (ref.null none)
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (i64.add
                                 (i64.add
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                 (i64.const 1)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.get $scratch_24)
                            )
                           )
                          )
                         )
                         (then
                          (i64.const 0)
                         )
                         (else
                          (local.set $3
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $9
                           (call $function105
                            (ref.null none)
                            (struct.get $type28 0
                             (struct.get $type27 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (i64.add
                           (i64.add
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (local.get $3)
                             )
                            )
                            (local.get $9)
                           )
                           (i64.const 1)
                          )
                         )
                        )
                        (local.get $7)
                       )
                       (i64.const 1)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready87)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global87)
                    )
                   )
                   (local.get $scratch_25)
                  )
                 )
                )
               )
               (then
                (i64.const 0)
               )
               (else
                (i64.add
                 (i64.add
                  (if (result i64)
                   (ref.test (ref $type26)
                    (local.tee $0
                     (struct.get $type28 0
                      (block (result (ref $type28))
                       (local.set $scratch_26
                        (struct.get $type27 1
                         (local.tee $1
                          (ref.cast (ref $type27)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (local.set $9
                        (if (result i64)
                         (ref.test (ref $type26)
                          (local.tee $0
                           (struct.get $type28 0
                            (struct.get $type27 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (then
                          (i64.const 0)
                         )
                         (else
                          (local.set $3
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $9
                           (call $function105
                            (ref.null none)
                            (struct.get $type28 0
                             (struct.get $type27 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (i64.add
                           (i64.add
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (local.get $3)
                             )
                            )
                            (local.get $9)
                           )
                           (i64.const 1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (local.get $scratch_26)
                      )
                     )
                    )
                   )
                   (then
                    (i64.const 0)
                   )
                   (else
                    (local.set $4
                     (struct.get $type27 1
                      (local.tee $1
                       (ref.cast (ref $type27)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (local.set $11
                     (call $function105
                      (ref.null none)
                      (struct.get $type28 0
                       (struct.get $type27 0
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (i64.add
                     (i64.add
                      (call $function105
                       (ref.null none)
                       (struct.get $type28 0
                        (local.get $4)
                       )
                      )
                      (local.get $11)
                     )
                     (i64.const 1)
                    )
                   )
                  )
                  (local.get $9)
                 )
                 (i64.const 1)
                )
               )
              )
              (local.get $7)
             )
             (i64.const 1)
            )
           )
          )
          (local.get $8)
         )
         (i64.const 1)
        )
       )
      )
      (local.get $10)
     )
     (i64.const 1)
    )
    (block (result i64)
     (if
      (i32.eqz
       (global.get $ready90)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global90)
      )
     )
     (local.set $2
      (call $function91
       (ref.null none)
       (i64.const 4)
      )
     )
     (if
      (i32.eqz
       (global.get $ready87)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global87)
      )
     )
     (if
      (i32.eqz
       (global.get $ready87)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global87)
      )
     )
     (local.set $8
      (if (result i64)
       (ref.test (ref $type26)
        (local.tee $0
         (struct.get $type28 0
          (struct.get $type27 0
           (local.get $2)
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (i64.add
         (i64.add
          (if (result i64)
           (ref.test (ref $type26)
            (local.tee $0
             (struct.get $type28 0
              (block (result (ref $type28))
               (local.set $scratch_30
                (struct.get $type27 1
                 (local.tee $1
                  (ref.cast (ref $type27)
                   (local.get $0)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready87)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global87)
                )
               )
               (local.set $8
                (if (result i64)
                 (ref.test (ref $type26)
                  (local.tee $0
                   (struct.get $type28 0
                    (struct.get $type27 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (i64.const 0)
                 )
                 (else
                  (i64.add
                   (i64.add
                    (if (result i64)
                     (ref.test (ref $type26)
                      (local.tee $0
                       (struct.get $type28 0
                        (block (result (ref $type28))
                         (local.set $scratch_28
                          (struct.get $type27 1
                           (local.tee $1
                            (ref.cast (ref $type27)
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready87)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global87)
                          )
                         )
                         (local.set $8
                          (if (result i64)
                           (ref.test (ref $type26)
                            (local.tee $0
                             (struct.get $type28 0
                              (struct.get $type27 0
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (then
                            (i64.const 0)
                           )
                           (else
                            (i64.add
                             (i64.add
                              (if (result i64)
                               (ref.test (ref $type26)
                                (local.tee $0
                                 (struct.get $type28 0
                                  (block (result (ref $type28))
                                   (local.set $scratch_27
                                    (struct.get $type27 1
                                     (local.tee $1
                                      (ref.cast (ref $type27)
                                       (local.get $0)
                                      )
                                     )
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready87)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global87)
                                    )
                                   )
                                   (local.set $8
                                    (if (result i64)
                                     (ref.test (ref $type26)
                                      (local.tee $0
                                       (struct.get $type28 0
                                        (struct.get $type27 0
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 0)
                                     )
                                     (else
                                      (local.set $6
                                       (struct.get $type27 1
                                        (local.tee $1
                                         (ref.cast (ref $type27)
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready87)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global87)
                                       )
                                      )
                                      (local.set $8
                                       (call $function105
                                        (ref.null none)
                                        (struct.get $type28 0
                                         (struct.get $type27 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready87)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global87)
                                       )
                                      )
                                      (i64.add
                                       (i64.add
                                        (call $function105
                                         (ref.null none)
                                         (struct.get $type28 0
                                          (local.get $6)
                                         )
                                        )
                                        (local.get $8)
                                       )
                                       (i64.const 1)
                                      )
                                     )
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready87)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global87)
                                    )
                                   )
                                   (local.get $scratch_27)
                                  )
                                 )
                                )
                               )
                               (then
                                (i64.const 0)
                               )
                               (else
                                (local.set $5
                                 (struct.get $type27 1
                                  (local.tee $1
                                   (ref.cast (ref $type27)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.set $7
                                 (call $function105
                                  (ref.null none)
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (i64.add
                                 (i64.add
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                 (i64.const 1)
                                )
                               )
                              )
                              (local.get $8)
                             )
                             (i64.const 1)
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready87)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global87)
                          )
                         )
                         (local.get $scratch_28)
                        )
                       )
                      )
                     )
                     (then
                      (i64.const 0)
                     )
                     (else
                      (i64.add
                       (i64.add
                        (if (result i64)
                         (ref.test (ref $type26)
                          (local.tee $0
                           (struct.get $type28 0
                            (block (result (ref $type28))
                             (local.set $scratch_29
                              (struct.get $type27 1
                               (local.tee $1
                                (ref.cast (ref $type27)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.set $7
                              (if (result i64)
                               (ref.test (ref $type26)
                                (local.tee $0
                                 (struct.get $type28 0
                                  (struct.get $type27 0
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (then
                                (i64.const 0)
                               )
                               (else
                                (local.set $5
                                 (struct.get $type27 1
                                  (local.tee $1
                                   (ref.cast (ref $type27)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.set $7
                                 (call $function105
                                  (ref.null none)
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (i64.add
                                 (i64.add
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                 (i64.const 1)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.get $scratch_29)
                            )
                           )
                          )
                         )
                         (then
                          (i64.const 0)
                         )
                         (else
                          (local.set $3
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $9
                           (call $function105
                            (ref.null none)
                            (struct.get $type28 0
                             (struct.get $type27 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (i64.add
                           (i64.add
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (local.get $3)
                             )
                            )
                            (local.get $9)
                           )
                           (i64.const 1)
                          )
                         )
                        )
                        (local.get $7)
                       )
                       (i64.const 1)
                      )
                     )
                    )
                    (local.get $8)
                   )
                   (i64.const 1)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready87)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global87)
                )
               )
               (local.get $scratch_30)
              )
             )
            )
           )
           (then
            (i64.const 0)
           )
           (else
            (i64.add
             (i64.add
              (if (result i64)
               (ref.test (ref $type26)
                (local.tee $0
                 (struct.get $type28 0
                  (block (result (ref $type28))
                   (local.set $scratch_32
                    (struct.get $type27 1
                     (local.tee $1
                      (ref.cast (ref $type27)
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready87)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global87)
                    )
                   )
                   (local.set $7
                    (if (result i64)
                     (ref.test (ref $type26)
                      (local.tee $0
                       (struct.get $type28 0
                        (struct.get $type27 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (i64.const 0)
                     )
                     (else
                      (i64.add
                       (i64.add
                        (if (result i64)
                         (ref.test (ref $type26)
                          (local.tee $0
                           (struct.get $type28 0
                            (block (result (ref $type28))
                             (local.set $scratch_31
                              (struct.get $type27 1
                               (local.tee $1
                                (ref.cast (ref $type27)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.set $7
                              (if (result i64)
                               (ref.test (ref $type26)
                                (local.tee $0
                                 (struct.get $type28 0
                                  (struct.get $type27 0
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (then
                                (i64.const 0)
                               )
                               (else
                                (local.set $5
                                 (struct.get $type27 1
                                  (local.tee $1
                                   (ref.cast (ref $type27)
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (local.set $7
                                 (call $function105
                                  (ref.null none)
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready87)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global87)
                                 )
                                )
                                (i64.add
                                 (i64.add
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                  )
                                  (local.get $7)
                                 )
                                 (i64.const 1)
                                )
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready87)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global87)
                              )
                             )
                             (local.get $scratch_31)
                            )
                           )
                          )
                         )
                         (then
                          (i64.const 0)
                         )
                         (else
                          (local.set $3
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $9
                           (call $function105
                            (ref.null none)
                            (struct.get $type28 0
                             (struct.get $type27 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (i64.add
                           (i64.add
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (local.get $3)
                             )
                            )
                            (local.get $9)
                           )
                           (i64.const 1)
                          )
                         )
                        )
                        (local.get $7)
                       )
                       (i64.const 1)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready87)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global87)
                    )
                   )
                   (local.get $scratch_32)
                  )
                 )
                )
               )
               (then
                (i64.const 0)
               )
               (else
                (i64.add
                 (i64.add
                  (if (result i64)
                   (ref.test (ref $type26)
                    (local.tee $0
                     (struct.get $type28 0
                      (block (result (ref $type28))
                       (local.set $scratch_33
                        (struct.get $type27 1
                         (local.tee $1
                          (ref.cast (ref $type27)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (local.set $9
                        (if (result i64)
                         (ref.test (ref $type26)
                          (local.tee $0
                           (struct.get $type28 0
                            (struct.get $type27 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (then
                          (i64.const 0)
                         )
                         (else
                          (local.set $3
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $9
                           (call $function105
                            (ref.null none)
                            (struct.get $type28 0
                             (struct.get $type27 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (i64.add
                           (i64.add
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (local.get $3)
                             )
                            )
                            (local.get $9)
                           )
                           (i64.const 1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready87)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global87)
                        )
                       )
                       (local.get $scratch_33)
                      )
                     )
                    )
                   )
                   (then
                    (i64.const 0)
                   )
                   (else
                    (local.set $4
                     (struct.get $type27 1
                      (local.tee $1
                       (ref.cast (ref $type27)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (local.set $11
                     (call $function105
                      (ref.null none)
                      (struct.get $type28 0
                       (struct.get $type27 0
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (i64.add
                     (i64.add
                      (call $function105
                       (ref.null none)
                       (struct.get $type28 0
                        (local.get $4)
                       )
                      )
                      (local.get $11)
                     )
                     (i64.const 1)
                    )
                   )
                  )
                  (local.get $9)
                 )
                 (i64.const 1)
                )
               )
              )
              (local.get $7)
             )
             (i64.const 1)
            )
           )
          )
          (local.get $8)
         )
         (i64.const 1)
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready87)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global87)
      )
     )
     (i64.add
      (i64.add
       (if (result i64)
        (ref.test (ref $type26)
         (local.tee $0
          (struct.get $type28 0
           (struct.get $type27 1
            (local.get $2)
           )
          )
         )
        )
        (then
         (i64.const 0)
        )
        (else
         (i64.add
          (i64.add
           (if (result i64)
            (ref.test (ref $type26)
             (local.tee $0
              (struct.get $type28 0
               (block (result (ref $type28))
                (local.set $scratch_37
                 (struct.get $type27 1
                  (local.tee $1
                   (ref.cast (ref $type27)
                    (local.get $0)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready87)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global87)
                 )
                )
                (local.set $7
                 (if (result i64)
                  (ref.test (ref $type26)
                   (local.tee $0
                    (struct.get $type28 0
                     (struct.get $type27 0
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (then
                   (i64.const 0)
                  )
                  (else
                   (i64.add
                    (i64.add
                     (if (result i64)
                      (ref.test (ref $type26)
                       (local.tee $0
                        (struct.get $type28 0
                         (block (result (ref $type28))
                          (local.set $scratch_35
                           (struct.get $type27 1
                            (local.tee $1
                             (ref.cast (ref $type27)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.set $7
                           (if (result i64)
                            (ref.test (ref $type26)
                             (local.tee $0
                              (struct.get $type28 0
                               (struct.get $type27 0
                                (local.get $1)
                               )
                              )
                             )
                            )
                            (then
                             (i64.const 0)
                            )
                            (else
                             (i64.add
                              (i64.add
                               (if (result i64)
                                (ref.test (ref $type26)
                                 (local.tee $0
                                  (struct.get $type28 0
                                   (block (result (ref $type28))
                                    (local.set $scratch_34
                                     (struct.get $type27 1
                                      (local.tee $1
                                       (ref.cast (ref $type27)
                                        (local.get $0)
                                       )
                                      )
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready87)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global87)
                                     )
                                    )
                                    (local.set $7
                                     (if (result i64)
                                      (ref.test (ref $type26)
                                       (local.tee $0
                                        (struct.get $type28 0
                                         (struct.get $type27 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                      (then
                                       (i64.const 0)
                                      )
                                      (else
                                       (local.set $6
                                        (struct.get $type27 1
                                         (local.tee $1
                                          (ref.cast (ref $type27)
                                           (local.get $0)
                                          )
                                         )
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready87)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global87)
                                        )
                                       )
                                       (local.set $7
                                        (call $function105
                                         (ref.null none)
                                         (struct.get $type28 0
                                          (struct.get $type27 0
                                           (local.get $1)
                                          )
                                         )
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready87)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global87)
                                        )
                                       )
                                       (i64.add
                                        (i64.add
                                         (call $function105
                                          (ref.null none)
                                          (struct.get $type28 0
                                           (local.get $6)
                                          )
                                         )
                                         (local.get $7)
                                        )
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready87)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global87)
                                     )
                                    )
                                    (local.get $scratch_34)
                                   )
                                  )
                                 )
                                )
                                (then
                                 (i64.const 0)
                                )
                                (else
                                 (local.set $5
                                  (struct.get $type27 1
                                   (local.tee $1
                                    (ref.cast (ref $type27)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready87)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global87)
                                  )
                                 )
                                 (local.set $9
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (struct.get $type27 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready87)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global87)
                                  )
                                 )
                                 (i64.add
                                  (i64.add
                                   (call $function105
                                    (ref.null none)
                                    (struct.get $type28 0
                                     (local.get $5)
                                    )
                                   )
                                   (local.get $9)
                                  )
                                  (i64.const 1)
                                 )
                                )
                               )
                               (local.get $7)
                              )
                              (i64.const 1)
                             )
                            )
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready87)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global87)
                           )
                          )
                          (local.get $scratch_35)
                         )
                        )
                       )
                      )
                      (then
                       (i64.const 0)
                      )
                      (else
                       (i64.add
                        (i64.add
                         (if (result i64)
                          (ref.test (ref $type26)
                           (local.tee $0
                            (struct.get $type28 0
                             (block (result (ref $type28))
                              (local.set $scratch_36
                               (struct.get $type27 1
                                (local.tee $1
                                 (ref.cast (ref $type27)
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready87)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global87)
                               )
                              )
                              (local.set $9
                               (if (result i64)
                                (ref.test (ref $type26)
                                 (local.tee $0
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (then
                                 (i64.const 0)
                                )
                                (else
                                 (local.set $5
                                  (struct.get $type27 1
                                   (local.tee $1
                                    (ref.cast (ref $type27)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready87)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global87)
                                  )
                                 )
                                 (local.set $9
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (struct.get $type27 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready87)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global87)
                                  )
                                 )
                                 (i64.add
                                  (i64.add
                                   (call $function105
                                    (ref.null none)
                                    (struct.get $type28 0
                                     (local.get $5)
                                    )
                                   )
                                   (local.get $9)
                                  )
                                  (i64.const 1)
                                 )
                                )
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready87)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global87)
                               )
                              )
                              (local.get $scratch_36)
                             )
                            )
                           )
                          )
                          (then
                           (i64.const 0)
                          )
                          (else
                           (local.set $3
                            (struct.get $type27 1
                             (local.tee $1
                              (ref.cast (ref $type27)
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready87)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global87)
                            )
                           )
                           (local.set $11
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (struct.get $type27 0
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready87)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global87)
                            )
                           )
                           (i64.add
                            (i64.add
                             (call $function105
                              (ref.null none)
                              (struct.get $type28 0
                               (local.get $3)
                              )
                             )
                             (local.get $11)
                            )
                            (i64.const 1)
                           )
                          )
                         )
                         (local.get $9)
                        )
                        (i64.const 1)
                       )
                      )
                     )
                     (local.get $7)
                    )
                    (i64.const 1)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready87)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global87)
                 )
                )
                (local.get $scratch_37)
               )
              )
             )
            )
            (then
             (i64.const 0)
            )
            (else
             (i64.add
              (i64.add
               (if (result i64)
                (ref.test (ref $type26)
                 (local.tee $0
                  (struct.get $type28 0
                   (block (result (ref $type28))
                    (local.set $scratch_39
                     (struct.get $type27 1
                      (local.tee $1
                       (ref.cast (ref $type27)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (local.set $9
                     (if (result i64)
                      (ref.test (ref $type26)
                       (local.tee $0
                        (struct.get $type28 0
                         (struct.get $type27 0
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (then
                       (i64.const 0)
                      )
                      (else
                       (i64.add
                        (i64.add
                         (if (result i64)
                          (ref.test (ref $type26)
                           (local.tee $0
                            (struct.get $type28 0
                             (block (result (ref $type28))
                              (local.set $scratch_38
                               (struct.get $type27 1
                                (local.tee $1
                                 (ref.cast (ref $type27)
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready87)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global87)
                               )
                              )
                              (local.set $9
                               (if (result i64)
                                (ref.test (ref $type26)
                                 (local.tee $0
                                  (struct.get $type28 0
                                   (struct.get $type27 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (then
                                 (i64.const 0)
                                )
                                (else
                                 (local.set $5
                                  (struct.get $type27 1
                                   (local.tee $1
                                    (ref.cast (ref $type27)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready87)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global87)
                                  )
                                 )
                                 (local.set $9
                                  (call $function105
                                   (ref.null none)
                                   (struct.get $type28 0
                                    (struct.get $type27 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready87)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global87)
                                  )
                                 )
                                 (i64.add
                                  (i64.add
                                   (call $function105
                                    (ref.null none)
                                    (struct.get $type28 0
                                     (local.get $5)
                                    )
                                   )
                                   (local.get $9)
                                  )
                                  (i64.const 1)
                                 )
                                )
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready87)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global87)
                               )
                              )
                              (local.get $scratch_38)
                             )
                            )
                           )
                          )
                          (then
                           (i64.const 0)
                          )
                          (else
                           (local.set $3
                            (struct.get $type27 1
                             (local.tee $1
                              (ref.cast (ref $type27)
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready87)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global87)
                            )
                           )
                           (local.set $11
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (struct.get $type27 0
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready87)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global87)
                            )
                           )
                           (i64.add
                            (i64.add
                             (call $function105
                              (ref.null none)
                              (struct.get $type28 0
                               (local.get $3)
                              )
                             )
                             (local.get $11)
                            )
                            (i64.const 1)
                           )
                          )
                         )
                         (local.get $9)
                        )
                        (i64.const 1)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready87)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global87)
                     )
                    )
                    (local.get $scratch_39)
                   )
                  )
                 )
                )
                (then
                 (i64.const 0)
                )
                (else
                 (i64.add
                  (i64.add
                   (if (result i64)
                    (ref.test (ref $type26)
                     (local.tee $0
                      (struct.get $type28 0
                       (block (result (ref $type28))
                        (local.set $scratch_40
                         (struct.get $type27 1
                          (local.tee $1
                           (ref.cast (ref $type27)
                            (local.get $0)
                           )
                          )
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready87)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global87)
                         )
                        )
                        (local.set $11
                         (if (result i64)
                          (ref.test (ref $type26)
                           (local.tee $0
                            (struct.get $type28 0
                             (struct.get $type27 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (then
                           (i64.const 0)
                          )
                          (else
                           (local.set $3
                            (struct.get $type27 1
                             (local.tee $1
                              (ref.cast (ref $type27)
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready87)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global87)
                            )
                           )
                           (local.set $11
                            (call $function105
                             (ref.null none)
                             (struct.get $type28 0
                              (struct.get $type27 0
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready87)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global87)
                            )
                           )
                           (i64.add
                            (i64.add
                             (call $function105
                              (ref.null none)
                              (struct.get $type28 0
                               (local.get $3)
                              )
                             )
                             (local.get $11)
                            )
                            (i64.const 1)
                           )
                          )
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready87)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global87)
                         )
                        )
                        (local.get $scratch_40)
                       )
                      )
                     )
                    )
                    (then
                     (i64.const 0)
                    )
                    (else
                     (local.set $4
                      (struct.get $type27 1
                       (local.tee $1
                        (ref.cast (ref $type27)
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready87)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global87)
                      )
                     )
                     (local.set $12
                      (call $function105
                       (ref.null none)
                       (struct.get $type28 0
                        (struct.get $type27 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready87)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global87)
                      )
                     )
                     (i64.add
                      (i64.add
                       (call $function105
                        (ref.null none)
                        (struct.get $type28 0
                         (local.get $4)
                        )
                       )
                       (local.get $12)
                      )
                      (i64.const 1)
                     )
                    )
                   )
                   (local.get $11)
                  )
                  (i64.const 1)
                 )
                )
               )
               (local.get $9)
              )
              (i64.const 1)
             )
            )
           )
           (local.get $7)
          )
          (i64.const 1)
         )
        )
       )
       (local.get $8)
      )
      (i64.const 1)
     )
    )
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (local.get $scratch_41)
 )
)

