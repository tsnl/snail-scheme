(module (table 0 funcref) (func $f) (elem (i32.const -1) func ) (func (export "size") (result i32) (table.size 0)) (func (export "main") (result i32) (i32.const 0)))
