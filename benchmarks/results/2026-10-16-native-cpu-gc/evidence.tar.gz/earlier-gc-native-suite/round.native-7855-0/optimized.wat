(module
 (rec
  (type $call25 (func (param f64) (result f64)))
  (type $call26 (func (param f32) (result f32)))
  (type $type26 (struct (field (ref $call26))))
  (type $type25 (struct (field (ref $call25))))
 )
 (type $4 (func (param f64) (result f64)))
 (type $5 (func (param f32) (result f32)))
 (type $6 (func))
 (global $execution (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type25)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global86 (mut (ref null $type26)) (ref.null none))
 (global $ready86 (mut i32) (i32.const 0))
 (global $global89 (mut (ref null $type25)) (ref.null none))
 (global $ready89 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type26)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type25)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global92 (mut (ref null $type26)) (ref.null none))
 (global $ready92 (mut i32) (i32.const 0))
 (export "worker" (func $export0))
 (export "round32" (func $export1))
 (export "view64" (func $export2))
 (export "view32" (func $export3))
 (export "main" (func $main))
 (func $function93 (type $call26) (param $0 f32) (result f32)
  (if
   (i32.eqz
    (global.get $ready90)
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call26
   (local.get $0)
   (struct.get $type26 0
    (global.get $global90)
   )
  )
 )
 (func $function97 (type $call25) (param $0 f64) (result f64)
  (if
   (i32.eqz
    (global.get $ready89)
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call25
   (local.get $0)
   (struct.get $type25 0
    (global.get $global89)
   )
  )
 )
 (func $function101 (type $call26) (param $0 f32) (result f32)
  (f32.nearest
   (local.get $0)
  )
 )
 (func $function105 (type $call25) (param $0 f64) (result f64)
  (f64.nearest
   (local.get $0)
  )
 )
 (func $export0 (param $0 f64) (result f64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready85)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global85)
   )
  )
  (f64.nearest
   (local.get $0)
  )
 )
 (func $export1 (param $0 f32) (result f32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready86)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global86)
   )
  )
  (f32.nearest
   (local.get $0)
  )
 )
 (func $export2 (param $0 f64) (result f64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready91)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global91)
   )
  )
  (if
   (i32.eqz
    (global.get $ready89)
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call25
   (local.get $0)
   (struct.get $type25 0
    (global.get $global89)
   )
  )
 )
 (func $export3 (param $0 f32) (result f32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if
   (i32.eqz
    (global.get $ready90)
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call26
   (local.get $0)
   (struct.get $type26 0
    (global.get $global90)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global85
   (struct.new $type25
    (ref.func $function105)
   )
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global86
   (struct.new $type26
    (ref.func $function101)
   )
  )
  (global.set $ready86
   (i32.const 1)
  )
  (global.set $global89
   (struct.new $type25
    (ref.func $function105)
   )
  )
  (global.set $ready89
   (i32.const 1)
  )
  (global.set $global90
   (struct.new $type26
    (ref.func $function101)
   )
  )
  (global.set $ready90
   (i32.const 1)
  )
  (global.set $global91
   (struct.new $type25
    (ref.func $function97)
   )
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global92
   (struct.new $type26
    (ref.func $function93)
   )
  )
  (global.set $ready92
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

