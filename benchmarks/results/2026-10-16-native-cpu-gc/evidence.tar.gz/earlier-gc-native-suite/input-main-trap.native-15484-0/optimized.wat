(module
 (rec
  (type $type49 (sub (struct)))
  (type $type51 (sub $type49 (struct)))
  (type $type61 (struct (field (ref $environment353))))
  (type $environment353 (struct (field (ref $type60))))
  (type $type60 (struct (field (mut i32)) (field (mut (ref null $type61)))))
  (type $type26 (struct (field i32)))
  (type $type29 (struct (field (mut i64))))
  (type $call53 (func (param eqref (ref $type28) i32 (ref $type14) i64) (result (ref $type14))))
  (type $8 (func (param (ref $type14) i32 i32 i32) (result (ref $type16))))
  (type $9 (func (param i64) (result i32)))
  (type $10 (func (param (ref $type14) i32) (result i32)))
  (type $type28 (struct (field (ref $type26)) (field (ref $type29))))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type37 (struct))
  (type $type52 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type35 (struct))
  (type $type32 (struct))
  (type $type13 (struct))
  (type $type50 (sub $type49 (struct)))
  (type $type14 (struct (field i32) (field i32) (field (mut i32)) (field (mut (ref $type16))) (field (mut i32)) (field (mut i32))))
  (type $type16 (array (mut i8)))
 )
 (type $25 (func (result i32)))
 (type $26 (func (param i32) (result i32)))
 (type $27 (func))
 (type $28 (func (param i32) (result i64)))
 (type $29 (func (param i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign2 (param i32) (result i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign3 (param i32) (result i32)))
 (import "snail.library" "snail:io/read-packet" (func $foreign4 (param i32) (result i64)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign6 (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign10))
 (import "snail.library" "snail:io/path-character" (func $foreign11 (param i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign12 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign13 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 6)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 206)
   (i32.const 187)
   (i32.const 240)
   (i32.const 159)
   (i32.const 152)
   (i32.const 128)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $empty50 (ref $type50) (struct.new_default $type50))
 (global $global106 (mut (ref null $type13)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type32)) (ref.null none))
 (global $global123 (mut (ref null $type35)) (ref.null none))
 (global $global127 (mut (ref null $type39)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global128 (mut (ref null $type40)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type41)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type41)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type52)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type37)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type53)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type54)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type28)) (ref.null none))
 (export "main" (func $main))
 (func $string-boundary (type $10) (param $0 (ref $type14)) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref $type16))
  (if
   (i32.lt_u
    (local.tee $4
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $4)
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (then
    (return
     (local.get $1)
    )
   )
  )
  (local.set $3
   (struct.get $type14 5
    (local.get $0)
   )
  )
  (if
   (i32.lt_u
    (local.get $1)
    (select
     (i32.sub
      (local.tee $2
       (struct.get $type14 4
        (local.get $0)
       )
      )
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (i32.const 0)
    )
    (local.set $2
     (i32.const 0)
    )
   )
  )
  (if
   (i32.lt_u
    (i32.sub
     (local.get $4)
     (local.get $1)
    )
    (select
     (i32.sub
      (local.get $2)
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (struct.get $type14 2
      (local.get $0)
     )
    )
    (local.set $2
     (local.get $4)
    )
   )
  )
  (local.set $5
   (struct.get $type14 3
    (local.get $0)
   )
  )
  (loop $label
   (if
    (i32.gt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (local.set $3
      (i32.add
       (if (result i32)
        (i32.lt_u
         (local.tee $4
          (array.get_u $type16
           (local.get $5)
           (local.get $3)
          )
         )
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $4)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $4)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
       (local.get $3)
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (loop $label2
   (if
    (i32.lt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (loop $label1
      (br_if $label1
       (i32.eq
        (i32.and
         (array.get_u $type16
          (local.get $5)
          (local.tee $3
           (i32.sub
            (local.get $3)
            (i32.const 1)
           )
          )
         )
         (i32.const 192)
        )
        (i32.const 128)
       )
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label2)
    )
   )
  )
  (struct.set $type14 4
   (local.get $0)
   (local.get $1)
  )
  (struct.set $type14 5
   (local.get $0)
   (local.get $3)
  )
  (local.get $3)
 )
 (func $string-ref (type $9) (param $0 i64) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref $type14))
  (local $6 (ref $type16))
  (if
   (i64.ge_u
    (local.get $0)
    (i64.const 6)
   )
   (then
    (unreachable)
   )
  )
  (block $block (result i32)
   (if
    (i32.lt_u
     (local.tee $1
      (array.get_u $type16
       (local.tee $6
        (struct.get $type14 3
         (local.tee $5
          (global.get $string0)
         )
        )
       )
       (local.tee $3
        (call $string-boundary
         (local.get $5)
         (i32.wrap_i64
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.const 128)
    )
    (then
     (br $block
      (local.get $1)
     )
    )
   )
   (local.set $1
    (i32.and
     (local.get $1)
     (i32.shr_u
      (i32.const 127)
      (local.tee $4
       (if (result i32)
        (i32.lt_u
         (local.get $1)
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $1)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $1)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.set $2
    (i32.const 1)
   )
   (loop $label
    (local.set $1
     (i32.or
      (i32.and
       (array.get_u $type16
        (local.get $6)
        (i32.add
         (local.get $2)
         (local.get $3)
        )
       )
       (i32.const 63)
      )
      (i32.shl
       (local.get $1)
       (i32.const 6)
      )
     )
    )
    (br_if $label
     (i32.lt_u
      (local.tee $2
       (i32.add
        (local.get $2)
        (i32.const 1)
       )
      )
      (local.get $4)
     )
    )
   )
   (local.get $1)
  )
 )
 (func $string-resize (type $8) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i32) (result (ref $type16))
  (local $4 (ref $type16))
  (local $5 (ref $type16))
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local.set $4
   (struct.get $type14 3
    (local.get $0)
   )
  )
  (if
   (i32.eq
    (i32.sub
     (local.get $2)
     (local.get $1)
    )
    (local.get $3)
   )
   (then
    (return
     (local.get $4)
    )
   )
  )
  (local.set $5
   (local.get $4)
  )
  (if
   (i64.gt_u
    (local.tee $6
     (i64.add
      (i64.extend_i32_u
       (i32.sub
        (local.tee $9
         (struct.get $type14 2
          (local.get $0)
         )
        )
        (i32.sub
         (local.get $2)
         (local.get $1)
        )
       )
      )
      (i64.extend_i32_u
       (local.get $3)
      )
     )
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.lt_u
    (local.tee $10
     (array.len
      (local.get $4)
     )
    )
    (local.tee $8
     (i32.wrap_i64
      (local.get $6)
     )
    )
   )
   (then
    (if
     (i64.gt_u
      (local.tee $7
       (i64.shl
        (i64.extend_i32_u
         (local.get $10)
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967294)
     )
     (then
      (local.set $7
       (i64.const 4294967294)
      )
     )
    )
    (array.copy $type16 $type16
     (local.tee $5
      (array.new_default $type16
       (i32.wrap_i64
        (if (result i64)
         (i64.lt_u
          (local.get $7)
          (local.tee $6
           (i64.extend_i32_u
            (local.get $8)
           )
          )
         )
         (then
          (local.get $6)
         )
         (else
          (local.get $7)
         )
        )
       )
      )
     )
     (i32.const 0)
     (local.get $4)
     (i32.const 0)
     (local.get $1)
    )
   )
  )
  (array.copy $type16 $type16
   (local.get $5)
   (i32.add
    (local.get $1)
    (local.get $3)
   )
   (local.get $4)
   (local.get $2)
   (i32.sub
    (local.get $9)
    (local.get $2)
   )
  )
  (struct.set $type14 3
   (local.get $0)
   (local.get $5)
  )
  (struct.set $type14 2
   (local.get $0)
   (local.get $8)
  )
  (local.get $5)
 )
 (func $function219 (type $call53) (param $0 eqref) (param $1 (ref $type28)) (param $2 i32) (param $3 (ref $type14)) (param $4 i64) (result (ref $type14))
  (local $5 i64)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 (ref $type14))
  (local $11 (ref $type29))
  (local $12 (ref $type16))
  (local $13 (ref $type16))
  (if (result (ref $type14))
   (if (result i32)
    (i32.eq
     (local.get $2)
     (i32.const -1)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.or
      (i32.eq
       (local.get $2)
       (i32.const 13)
      )
      (i32.eq
       (local.get $2)
       (i32.const 10)
      )
     )
    )
   )
   (then
    (if
     (i32.eq
      (local.get $2)
      (i32.const 13)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready137)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global137)
       )
      )
      (if
       (i32.eqz
        (global.get $ready130)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if
       (i32.eq
        (if (result i32)
         (i32.lt_s
          (local.tee $2
           (struct.get $type26 0
            (struct.get $type28 0
             (local.get $1)
            )
           )
          )
          (i32.const 0)
         )
         (then
          (call $foreign2
           (local.get $2)
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready127)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global127)
           )
          )
          (if
           (i64.eqz
            (local.tee $5
             (struct.get $type29 0
              (local.tee $11
               (struct.get $type28 1
                (local.get $1)
               )
              )
             )
            )
           )
           (then
            (struct.set $type29 0
             (local.get $11)
             (local.tee $5
              (call $foreign4
               (struct.get $type26 0
                (struct.get $type28 0
                 (local.get $1)
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready128)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global128)
           )
          )
          (if (result i32)
           (i64.lt_s
            (local.get $5)
            (i64.const 0)
           )
           (then
            (if (result i32)
             (i64.eq
              (local.get $5)
              (i64.const -1)
             )
             (then
              (i32.const -1)
             )
             (else
              (if
               (i64.ne
                (i64.extend32_s
                 (local.tee $5
                  (i64.sub
                   (i64.const -2)
                   (local.get $5)
                  )
                 )
                )
                (local.get $5)
               )
               (then
                (unreachable)
               )
              )
              (i32.wrap_i64
               (local.get $5)
              )
             )
            )
           )
           (else
            (if
             (i64.ne
              (i64.extend32_s
               (local.tee $5
                (i64.sub
                 (i64.and
                  (local.get $5)
                  (i64.const 255)
                 )
                 (i64.const 1)
                )
               )
              )
              (local.get $5)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $5)
            )
           )
          )
         )
        )
        (i32.const 10)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready129)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global129)
         )
        )
        (drop
         (if (result i32)
          (i32.lt_s
           (local.tee $2
            (struct.get $type26 0
             (struct.get $type28 0
              (local.get $1)
             )
            )
           )
           (i32.const 0)
          )
          (then
           (call $foreign3
            (local.get $2)
           )
          )
          (else
           (if
            (i32.eqz
             (global.get $ready127)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global127)
            )
           )
           (struct.set $type29 0
            (local.tee $11
             (struct.get $type28 1
              (local.get $1)
             )
            )
            (block (result i64)
             (if
              (i64.eqz
               (local.tee $5
                (struct.get $type29 0
                 (local.get $11)
                )
               )
              )
              (then
               (struct.set $type29 0
                (local.get $11)
                (local.tee $5
                 (call $foreign4
                  (struct.get $type26 0
                   (struct.get $type28 0
                    (local.get $1)
                   )
                  )
                 )
                )
               )
              )
             )
             (select
              (i64.shr_u
               (local.get $5)
               (i64.const 8)
              )
              (i64.const 0)
              (i64.gt_s
               (local.get $5)
               (i64.const 0)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready128)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global128)
            )
           )
           (if (result i32)
            (i64.lt_s
             (local.get $5)
             (i64.const 0)
            )
            (then
             (if (result i32)
              (i64.eq
               (local.get $5)
               (i64.const -1)
              )
              (then
               (i32.const -1)
              )
              (else
               (if
                (i64.ne
                 (i64.extend32_s
                  (local.tee $5
                   (i64.sub
                    (i64.const -2)
                    (local.get $5)
                   )
                  )
                 )
                 (local.get $5)
                )
                (then
                 (unreachable)
                )
               )
               (i32.const 0)
              )
             )
            )
            (else
             (if
              (i64.ne
               (i64.extend32_s
                (local.tee $5
                 (i64.sub
                  (i64.and
                   (local.get $5)
                   (i64.const 255)
                  )
                  (i64.const 1)
                 )
                )
               )
               (local.get $5)
              )
              (then
               (unreachable)
              )
             )
             (i32.const 0)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $3)
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (if
       (i64.gt_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $9
       (call $string-boundary
        (local.get $3)
        (i32.const 0)
       )
      )
      (array.copy $type16 $type16
       (local.tee $13
        (array.new_default $type16
         (local.tee $6
          (i32.sub
           (call $string-boundary
            (local.get $3)
            (local.tee $2
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
           (local.get $9)
          )
         )
        )
       )
       (i32.const 0)
       (struct.get $type14 3
        (local.get $3)
       )
       (local.get $9)
       (local.get $6)
      )
      (struct.new $type14
       (i32.const 1)
       (local.get $2)
       (local.get $6)
       (local.get $13)
       (i32.const 0)
       (i32.const 0)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready139)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (if
     (i64.le_s
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $3)
       )
      )
      (local.get $4)
     )
     (then
      (local.set $3
       (if (result (ref $type14))
        (i64.eq
         (local.get $4)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready106)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global106)
          )
         )
         (if
          (i64.gt_u
           (local.tee $5
            (if (result i64)
             (i64.eqz
              (local.get $4)
             )
             (then
              (i64.const 64)
             )
             (else
              (select
               (i64.const 4294967294)
               (i64.shl
                (local.get $4)
                (i64.const 1)
               )
               (i64.gt_s
                (local.get $4)
                (i64.const 2147483647)
               )
              )
             )
            )
           )
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $5)
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (local.set $13
          (array.new_default $type16
           (local.tee $6
            (i32.wrap_i64
             (local.get $5)
            )
           )
          )
         )
         (if
          (i32.ne
           (struct.get $type14 0
            (local.tee $10
             (struct.new $type14
              (i32.const 1)
              (local.get $6)
              (local.get $6)
              (local.get $13)
              (i32.const 0)
              (i32.const 0)
             )
            )
           )
           (i32.const 1)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $4)
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $4)
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $10)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (call $string-boundary
           (local.get $3)
           (i32.const 0)
          )
         )
         (if
          (i32.and
           (i32.ne
            (local.tee $6
             (i32.sub
              (call $string-boundary
               (local.get $3)
               (local.tee $9
                (i32.wrap_i64
                 (local.get $4)
                )
               )
              )
              (block (result i32)
               (local.set $8
                (call $string-boundary
                 (local.get $10)
                 (i32.const 0)
                )
               )
               (local.set $9
                (call $string-boundary
                 (local.get $10)
                 (local.get $9)
                )
               )
               (local.set $12
                (struct.get $type14 3
                 (local.get $3)
                )
               )
               (local.get $7)
              )
             )
            )
            (i32.sub
             (local.get $9)
             (local.get $8)
            )
           )
           (ref.eq
            (local.get $3)
            (local.get $10)
           )
          )
          (then
           (array.copy $type16 $type16
            (local.tee $13
             (array.new_default $type16
              (local.get $6)
             )
            )
            (i32.const 0)
            (local.get $12)
            (local.get $7)
            (local.get $6)
           )
           (local.set $12
            (local.get $13)
           )
           (local.set $7
            (i32.const 0)
           )
          )
         )
         (array.copy $type16 $type16
          (call $string-resize
           (local.get $10)
           (local.get $8)
           (local.get $9)
           (local.get $6)
          )
          (local.get $8)
          (local.get $12)
          (local.get $7)
          (local.get $6)
         )
         (struct.set $type14 4
          (local.get $10)
          (i32.const 0)
         )
         (struct.set $type14 5
          (local.get $10)
          (local.get $8)
         )
         (local.get $10)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.extend_i32_s
        (local.get $2)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $3)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (call $string-resize
      (local.get $3)
      (local.tee $8
       (call $string-boundary
        (local.get $3)
        (local.tee $9
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
      )
      (i32.add
       (if (result i32)
        (i32.lt_u
         (local.tee $2
          (array.get_u $type16
           (struct.get $type14 3
            (local.get $3)
           )
           (local.get $8)
          )
         )
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $2)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $2)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
       (local.get $8)
      )
      (local.tee $6
       (if (result i32)
        (i32.lt_u
         (local.get $7)
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $7)
           (i32.const 2048)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $7)
             (i32.const 65536)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eq
      (local.tee $2
       (local.get $6)
      )
      (i32.const 1)
     )
     (then
      (array.set $type16
       (local.get $12)
       (local.get $8)
       (local.get $7)
      )
     )
     (else
      (loop $label
       (array.set $type16
        (local.get $12)
        (i32.add
         (local.tee $6
          (i32.sub
           (local.get $6)
           (i32.const 1)
          )
         )
         (local.get $8)
        )
        (i32.or
         (i32.and
          (local.get $7)
          (i32.const 63)
         )
         (i32.const 128)
        )
       )
       (local.set $7
        (i32.shr_u
         (local.get $7)
         (i32.const 6)
        )
       )
       (br_if $label
        (i32.gt_u
         (local.get $6)
         (i32.const 1)
        )
       )
      )
      (array.set $type16
       (local.get $12)
       (local.get $8)
       (i32.or
        (if (result i32)
         (i32.eq
          (local.get $2)
          (i32.const 2)
         )
         (then
          (i32.const 192)
         )
         (else
          (select
           (i32.const 224)
           (i32.const 240)
           (i32.eq
            (local.get $2)
            (i32.const 3)
           )
          )
         )
        )
        (local.get $7)
       )
      )
     )
    )
    (struct.set $type14 4
     (local.get $3)
     (local.get $9)
    )
    (struct.set $type14 5
     (local.get $3)
     (local.get $8)
    )
    (if
     (i32.eqz
      (global.get $ready129)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global129)
     )
    )
    (local.set $2
     (if (result i32)
      (i32.lt_s
       (local.tee $2
        (struct.get $type26 0
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
       (i32.const 0)
      )
      (then
       (call $foreign3
        (local.get $2)
       )
      )
      (else
       (if
        (i32.eqz
         (global.get $ready127)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global127)
        )
       )
       (struct.set $type29 0
        (local.tee $11
         (struct.get $type28 1
          (local.get $1)
         )
        )
        (block (result i64)
         (if
          (i64.eqz
           (local.tee $5
            (struct.get $type29 0
             (local.get $11)
            )
           )
          )
          (then
           (struct.set $type29 0
            (local.get $11)
            (local.tee $5
             (call $foreign4
              (struct.get $type26 0
               (struct.get $type28 0
                (local.get $1)
               )
              )
             )
            )
           )
          )
         )
         (select
          (i64.shr_u
           (local.get $5)
           (i64.const 8)
          )
          (i64.const 0)
          (i64.gt_s
           (local.get $5)
           (i64.const 0)
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready128)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global128)
        )
       )
       (if (result i32)
        (i64.lt_s
         (local.get $5)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.eq
           (local.get $5)
           (i64.const -1)
          )
          (then
           (i32.const -1)
          )
          (else
           (if
            (i64.ne
             (i64.extend32_s
              (local.tee $5
               (i64.sub
                (i64.const -2)
                (local.get $5)
               )
              )
             )
             (local.get $5)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
         )
        )
        (else
         (if
          (i64.ne
           (i64.extend32_s
            (local.tee $5
             (i64.sub
              (i64.and
               (local.get $5)
               (i64.const 255)
              )
              (i64.const 1)
             )
            )
           )
           (local.get $5)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready138)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global138)
     )
    )
    (return_call $function219
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $main
  (local $0 i64)
  (local $1 i32)
  (local $2 (ref $type60))
  (local $3 (ref $type60))
  (local $4 (ref $environment353))
  (local $5 (ref $type28))
  (local $6 (ref $type29))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type13)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (drop
   (call $foreign12)
  )
  (drop
   (call $foreign13)
  )
  (global.set $global119
   (struct.new_default $type32)
  )
  (global.set $global123
   (struct.new_default $type35)
  )
  (global.set $global127
   (struct.new_default $type39)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global128
   (struct.new_default $type40)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type41)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type41)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type52)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type37)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type53)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type54)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (call $foreign10)
  (struct.set $type60 1
   (local.tee $3
    (struct.new_default $type60)
   )
   (struct.new $type61
    (struct.new $environment353
     (local.get $3)
    )
   )
  )
  (struct.set $type60 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type61 0
    (struct.get $type60 1
     (local.get $3)
    )
   )
  )
  (call $foreign11
   (call $string-ref
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (struct.get $environment353 0
      (local.get $4)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type60 1
     (local.tee $2
      (struct.get $environment353 0
       (local.get $4)
      )
     )
    )
   )
  )
  (call $foreign11
   (call $string-ref
    (i64.const 1)
   )
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type60 1
     (local.tee $2
      (struct.get $environment353 0
       (local.get $4)
      )
     )
    )
   )
  )
  (call $foreign11
   (call $string-ref
    (i64.const 2)
   )
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type60 1
     (local.tee $2
      (struct.get $environment353 0
       (local.get $4)
      )
     )
    )
   )
  )
  (call $foreign11
   (call $string-ref
    (i64.const 3)
   )
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type60 1
     (local.tee $2
      (struct.get $environment353 0
       (local.get $4)
      )
     )
    )
   )
  )
  (call $foreign11
   (call $string-ref
    (i64.const 4)
   )
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type60 1
     (local.tee $2
      (struct.get $environment353 0
       (local.get $4)
      )
     )
    )
   )
  )
  (call $foreign11
   (call $string-ref
    (i64.const 5)
   )
  )
  (if
   (i32.eqz
    (struct.get $type60 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type60 1
     (struct.get $environment353 0
      (local.get $4)
     )
    )
   )
  )
  (global.set $global148
   (struct.new $type28
    (struct.new $type26
     (call $foreign6)
    )
    (struct.new_default $type29)
   )
  )
  (local.set $5
   (ref.as_non_null
    (global.get $global148)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (drop
   (if (result (ref $type49))
    (i32.eq
     (local.tee $1
      (if (result i32)
       (i32.lt_s
        (local.tee $1
         (struct.get $type26 0
          (struct.get $type28 0
           (local.get $5)
          )
         )
        )
        (i32.const 0)
       )
       (then
        (call $foreign3
         (local.get $1)
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready127)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global127)
         )
        )
        (struct.set $type29 0
         (local.tee $6
          (struct.get $type28 1
           (local.get $5)
          )
         )
         (block (result i64)
          (if
           (i64.eqz
            (local.tee $0
             (struct.get $type29 0
              (local.get $6)
             )
            )
           )
           (then
            (struct.set $type29 0
             (local.get $6)
             (local.tee $0
              (call $foreign4
               (struct.get $type26 0
                (struct.get $type28 0
                 (local.get $5)
                )
               )
              )
             )
            )
           )
          )
          (select
           (i64.shr_u
            (local.get $0)
            (i64.const 8)
           )
           (i64.const 0)
           (i64.gt_s
            (local.get $0)
            (i64.const 0)
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready128)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global128)
         )
        )
        (if (result i32)
         (i64.lt_s
          (local.get $0)
          (i64.const 0)
         )
         (then
          (if (result i32)
           (i64.eq
            (local.get $0)
            (i64.const -1)
           )
           (then
            (i32.const -1)
           )
           (else
            (if
             (i64.ne
              (i64.extend32_s
               (local.tee $0
                (i64.sub
                 (i64.const -2)
                 (local.get $0)
                )
               )
              )
              (local.get $0)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $0)
            )
           )
          )
         )
         (else
          (if
           (i64.ne
            (i64.extend32_s
             (local.tee $0
              (i64.sub
               (i64.and
                (local.get $0)
                (i64.const 255)
               )
               (i64.const 1)
              )
             )
            )
            (local.get $0)
           )
           (then
            (unreachable)
           )
          )
          (i32.wrap_i64
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (i32.const -1)
    )
    (then
     (global.get $empty50)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready106)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global106)
      )
     )
     (if
      (i32.eqz
       (global.get $ready138)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global138)
      )
     )
     (drop
      (call $function219
       (ref.null none)
       (local.get $5)
       (local.get $1)
       (struct.new $type14
        (i32.const 1)
        (i32.const 0)
        (i32.const 0)
        (array.new_default $type16
         (i32.const 0)
        )
        (i32.const 0)
        (i32.const 0)
       )
       (i64.const 0)
      )
     )
     (struct.new_default $type51)
    )
   )
  )
  (unreachable)
 )
)

