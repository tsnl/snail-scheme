(module
 (type $0 (func (result i32)))
 (table $0 0 funcref)
 (export "size" (func $0))
 (export "main" (func $1))
 (func $0 (result i32)
  (table.size $0)
 )
 (func $1 (result i32)
  (i32.const 0)
 )
)

