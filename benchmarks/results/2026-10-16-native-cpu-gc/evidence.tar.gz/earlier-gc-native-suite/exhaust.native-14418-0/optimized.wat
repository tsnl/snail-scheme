(module
 (rec
  (type $0 (func (param (ref $environment361) i64) (result i32)))
  (type $type63 (struct (field (ref struct))))
  (type $environment361 (struct (field (ref $type61)) (field (ref $type62))))
  (type $3 (func (result (ref $type25))))
  (type $type62 (struct (field (mut i32)) (field (mut (ref null $type63)))))
  (type $type26 (struct (field i32)))
  (type $type61 (struct (field i64)))
  (type $environment203 (struct (field (ref $type25)) (field (ref $type61)) (field (ref $type62))))
  (type $8 (func (param (ref struct) i64) (result i32)))
  (type $9 (func (param (ref $type14) i64) (result i32)))
  (type $type60 (struct))
  (type $type59 (array (mut i64)))
  (type $type25 (struct (field (ref $type26))))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type14 (struct (field (mut i32)) (field (mut i32))))
  (type $type16 (array (mut i8)))
 )
 (type $19 (func (result i32)))
 (type $20 (func (param i32)))
 (type $21 (func))
 (type $22 (func (param i32 i32)))
 (type $23 (func (param i64) (result i64)))
 (import "snail.library" "snail:io/check-output" (func $foreign0 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign1 (param i32 i32)))
 (import "snail.library" "snail:io/open-output-file" (func $foreign7 (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign10))
 (import "snail.library" "snail:io/path-character" (func $foreign11 (param i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign12 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign13 (result i32)))
 (global $global$0 (ref $type16) (array.new_fixed $type16 11
  (i32.const 101)
  (i32.const 120)
  (i32.const 104)
  (i32.const 97)
  (i32.const 117)
  (i32.const 115)
  (i32.const 116)
  (i32.const 46)
  (i32.const 116)
  (i32.const 120)
  (i32.const 116)
 ))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 0)
 ))
 (global $execution (mut i32) (i32.const 0))
 (global $global$3 (ref $type16) (array.new_fixed $type16 26
  (i32.const 98)
  (i32.const 117)
  (i32.const 102)
  (i32.const 102)
  (i32.const 101)
  (i32.const 114)
  (i32.const 101)
  (i32.const 100)
  (i32.const 32)
  (i32.const 98)
  (i32.const 101)
  (i32.const 102)
  (i32.const 111)
  (i32.const 114)
  (i32.const 101)
  (i32.const 32)
  (i32.const 101)
  (i32.const 120)
  (i32.const 104)
  (i32.const 97)
  (i32.const 117)
  (i32.const 115)
  (i32.const 116)
  (i32.const 105)
  (i32.const 111)
  (i32.const 110)
 ))
 (global $global121 (mut (ref null $type32)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type34)) (ref.null none))
 (global $global142 (mut (ref null $type55)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global143 (mut (ref null $type56)) (ref.null none))
 (global $ready143 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type25)) (ref.null none))
 (global $global151 (mut (ref null $type59)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (global $global152 (mut (ref null $type60)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 0)
 ))
 (export "read-huge" (func $export0))
 (export "main" (func $main))
 (func $string-ref (type $9) (param $0 (ref $type14)) (param $1 i64) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 (ref $type16))
  (local $7 (ref $type16))
  (if
   (i64.ge_u
    (local.get $1)
    (select
     (i64.const 11)
     (i64.const 26)
     (ref.eq
      (local.get $0)
      (global.get $string0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (block $block1 (result i32)
   (if
    (i32.lt_u
     (local.tee $2
      (array.get_u $type16
       (local.tee $7
        (select (result (ref $type16))
         (global.get $global$0)
         (global.get $global$3)
         (local.tee $5
          (ref.eq
           (local.get $0)
           (global.get $string0)
          )
         )
        )
       )
       (local.tee $3
        (block $block (result i32)
         (if
          (i32.gt_u
           (local.tee $3
            (i32.wrap_i64
             (local.get $1)
            )
           )
           (local.tee $5
            (select
             (i32.const 11)
             (i32.const 26)
             (local.get $5)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (br_if $block
           (local.get $3)
           (i32.eq
            (local.get $5)
            (select
             (i32.const 11)
             (i32.const 26)
             (ref.eq
              (local.get $0)
              (global.get $string0)
             )
            )
           )
          )
         )
         (local.set $4
          (struct.get $type14 1
           (local.get $0)
          )
         )
         (if
          (i32.lt_u
           (local.get $3)
           (select
            (i32.sub
             (local.tee $2
              (struct.get $type14 0
               (local.get $0)
              )
             )
             (local.get $3)
            )
            (i32.sub
             (local.get $3)
             (local.get $2)
            )
            (i32.gt_u
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (then
           (local.set $4
            (i32.const 0)
           )
           (local.set $2
            (i32.const 0)
           )
          )
         )
         (if
          (i32.lt_u
           (i32.sub
            (local.get $5)
            (local.get $3)
           )
           (select
            (i32.sub
             (local.get $2)
             (local.get $3)
            )
            (i32.sub
             (local.get $3)
             (local.get $2)
            )
            (i32.gt_u
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (then
           (local.set $4
            (select
             (i32.const 11)
             (i32.const 26)
             (ref.eq
              (local.get $0)
              (global.get $string0)
             )
            )
           )
           (local.set $2
            (local.get $5)
           )
          )
         )
         (local.set $6
          (select (result (ref $type16))
           (global.get $global$0)
           (global.get $global$3)
           (ref.eq
            (local.get $0)
            (global.get $string0)
           )
          )
         )
         (loop $label
          (if
           (i32.lt_u
            (local.get $2)
            (local.get $3)
           )
           (then
            (local.set $4
             (i32.add
              (if (result i32)
               (i32.lt_u
                (local.tee $5
                 (array.get_u $type16
                  (local.get $6)
                  (local.get $4)
                 )
                )
                (i32.const 128)
               )
               (then
                (i32.const 1)
               )
               (else
                (if (result i32)
                 (i32.lt_u
                  (local.get $5)
                  (i32.const 224)
                 )
                 (then
                  (i32.const 2)
                 )
                 (else
                  (select
                   (i32.const 3)
                   (i32.const 4)
                   (i32.lt_u
                    (local.get $5)
                    (i32.const 240)
                   )
                  )
                 )
                )
               )
              )
              (local.get $4)
             )
            )
            (local.set $2
             (i32.add
              (local.get $2)
              (i32.const 1)
             )
            )
            (br $label)
           )
          )
         )
         (loop $label2
          (if
           (i32.gt_u
            (local.get $2)
            (local.get $3)
           )
           (then
            (loop $label1
             (br_if $label1
              (i32.eq
               (i32.and
                (array.get_u $type16
                 (local.get $6)
                 (local.tee $4
                  (i32.sub
                   (local.get $4)
                   (i32.const 1)
                  )
                 )
                )
                (i32.const 192)
               )
               (i32.const 128)
              )
             )
            )
            (local.set $2
             (i32.sub
              (local.get $2)
              (i32.const 1)
             )
            )
            (br $label2)
           )
          )
         )
         (struct.set $type14 0
          (local.get $0)
          (local.get $3)
         )
         (struct.set $type14 1
          (local.get $0)
          (local.get $4)
         )
         (local.get $4)
        )
       )
      )
     )
     (i32.const 128)
    )
    (then
     (br $block1
      (local.get $2)
     )
    )
   )
   (local.set $2
    (i32.and
     (local.get $2)
     (i32.shr_u
      (i32.const 127)
      (local.tee $5
       (if (result i32)
        (i32.lt_u
         (local.get $2)
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $2)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $2)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.set $4
    (i32.const 1)
   )
   (loop $label3
    (local.set $2
     (i32.or
      (i32.and
       (array.get_u $type16
        (local.get $7)
        (i32.add
         (local.get $3)
         (local.get $4)
        )
       )
       (i32.const 63)
      )
      (i32.shl
       (local.get $2)
       (i32.const 6)
      )
     )
    )
    (br_if $label3
     (i32.lt_u
      (local.tee $4
       (i32.add
        (local.get $4)
        (i32.const 1)
       )
      )
      (local.get $5)
     )
    )
   )
   (local.get $2)
  )
 )
 (func $function203 (type $8) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment203))
  (local $3 i32)
  (if (result i32)
   (i64.eq
    (struct.get $type61 0
     (struct.get $environment203 1
      (ref.cast (ref $environment203)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $2
     (ref.cast (ref $environment203)
      (local.get $0)
     )
    )
    (local.set $3
     (call $string-ref
      (global.get $string1)
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready142)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global142)
     )
    )
    (call $foreign1
     (struct.get $type26 0
      (struct.get $type25 0
       (struct.get $environment203 0
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (struct.get $environment203 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type62 1
       (struct.get $environment203 2
        (local.get $2)
       )
      )
     )
    )
    (return_call $function203
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function335 (type $3) (result (ref $type25))
  (local $0 (ref $environment361))
  (local $1 (ref $type62))
  (local $2 (ref struct))
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (call $foreign10)
  (struct.set $type62 1
   (local.tee $1
    (struct.new_default $type62)
   )
   (struct.new $type63
    (struct.new $environment361
     (struct.new $type61
      (i64.const 11)
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type62 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type62 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (if (result i32)
    (i64.eqz
     (struct.get $type61 0
      (struct.get $environment361 0
       (ref.cast (ref $environment361)
        (local.tee $2
         (struct.get $type63 0
          (struct.get $type62 1
           (local.get $1)
          )
         )
        )
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (local.set $0
      (ref.cast (ref $environment361)
       (local.get $2)
      )
     )
     (call $foreign11
      (call $string-ref
       (global.get $string0)
       (i64.const 0)
      )
     )
     (if
      (i32.eqz
       (struct.get $type62 0
        (struct.get $environment361 1
         (local.get $0)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (struct.get $type62 1
        (struct.get $environment361 1
         (local.get $0)
        )
       )
      )
     )
     (if (result i32)
      (i64.eq
       (struct.get $type61 0
        (struct.get $environment361 0
         (local.get $0)
        )
       )
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign11
        (call $string-ref
         (global.get $string0)
         (i64.const 1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type62 0
          (struct.get $environment361 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (struct.get $type62 1
          (struct.get $environment361 1
           (local.get $0)
          )
         )
        )
       )
       (if (result i32)
        (i64.eq
         (struct.get $type61 0
          (struct.get $environment361 0
           (local.get $0)
          )
         )
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign11
          (call $string-ref
           (global.get $string0)
           (i64.const 2)
          )
         )
         (if
          (i32.eqz
           (struct.get $type62 0
            (struct.get $environment361 1
             (local.get $0)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (struct.get $type62 1
            (struct.get $environment361 1
             (local.get $0)
            )
           )
          )
         )
         (if (result i32)
          (i64.eq
           (struct.get $type61 0
            (struct.get $environment361 0
             (local.get $0)
            )
           )
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign11
            (call $string-ref
             (global.get $string0)
             (i64.const 3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type62 0
              (struct.get $environment361 1
               (local.get $0)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (struct.get $type62 1
              (struct.get $environment361 1
               (local.get $0)
              )
             )
            )
           )
           (if (result i32)
            (i64.eq
             (struct.get $type61 0
              (struct.get $environment361 0
               (local.get $0)
              )
             )
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign11
              (call $string-ref
               (global.get $string0)
               (i64.const 4)
              )
             )
             (if
              (i32.eqz
               (struct.get $type62 0
                (struct.get $environment361 1
                 (local.get $0)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (struct.get $type62 1
                (struct.get $environment361 1
                 (local.get $0)
                )
               )
              )
             )
             (if (result i32)
              (i64.eq
               (struct.get $type61 0
                (struct.get $environment361 0
                 (local.get $0)
                )
               )
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign11
                (call $string-ref
                 (global.get $string0)
                 (i64.const 5)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type62 0
                  (struct.get $environment361 1
                   (local.get $0)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (struct.get $type62 1
                  (struct.get $environment361 1
                   (local.get $0)
                  )
                 )
                )
               )
               (if (result i32)
                (i64.eq
                 (struct.get $type61 0
                  (struct.get $environment361 0
                   (local.get $0)
                  )
                 )
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign11
                  (call $string-ref
                   (global.get $string0)
                   (i64.const 6)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type62 0
                    (struct.get $environment361 1
                     (local.get $0)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (struct.get $type62 1
                    (struct.get $environment361 1
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (struct.get $type61 0
                    (struct.get $environment361 0
                     (local.get $0)
                    )
                   )
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign11
                    (call $string-ref
                     (global.get $string0)
                     (i64.const 7)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type62 0
                      (struct.get $environment361 1
                       (local.get $0)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (struct.get $type62 1
                      (struct.get $environment361 1
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (struct.get $type61 0
                      (struct.get $environment361 0
                       (local.get $0)
                      )
                     )
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign11
                      (call $string-ref
                       (global.get $string0)
                       (i64.const 8)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type62 0
                        (struct.get $environment361 1
                         (local.get $0)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (struct.get $type62 1
                        (struct.get $environment361 1
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (struct.get $type61 0
                        (struct.get $environment361 0
                         (local.get $0)
                        )
                       )
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign11
                        (call $string-ref
                         (global.get $string0)
                         (i64.const 9)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type62 0
                          (struct.get $environment361 1
                           (local.get $0)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (struct.get $type62 1
                          (struct.get $environment361 1
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if (result i32)
                        (i64.eq
                         (struct.get $type61 0
                          (struct.get $environment361 0
                           (local.get $0)
                          )
                         )
                         (i64.const 10)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (call $foreign11
                          (call $string-ref
                           (global.get $string0)
                           (i64.const 10)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type62 0
                            (struct.get $environment361 1
                             (local.get $0)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (struct.get $type62 1
                            (struct.get $environment361 1
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (if (result i32)
                          (i64.eq
                           (struct.get $type61 0
                            (struct.get $environment361 0
                             (local.get $0)
                            )
                           )
                           (i64.const 11)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (call $foreign11
                            (call $string-ref
                             (global.get $string0)
                             (i64.const 11)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type62 0
                              (struct.get $environment361 1
                               (local.get $0)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (struct.get $type62 1
                              (struct.get $environment361 1
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (if (result i32)
                            (i64.eq
                             (struct.get $type61 0
                              (struct.get $environment361 0
                               (local.get $0)
                              )
                             )
                             (i64.const 12)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (call $foreign11
                              (call $string-ref
                               (global.get $string0)
                               (i64.const 12)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type62 0
                                (struct.get $environment361 1
                                 (local.get $0)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (struct.get $type62 1
                                (struct.get $environment361 1
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if (result i32)
                              (i64.eq
                               (struct.get $type61 0
                                (struct.get $environment361 0
                                 (local.get $0)
                                )
                               )
                               (i64.const 13)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (call $foreign11
                                (call $string-ref
                                 (global.get $string0)
                                 (i64.const 13)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type62 0
                                  (struct.get $environment361 1
                                   (local.get $0)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (struct.get $type62 1
                                  (struct.get $environment361 1
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (call $function361
                                (local.get $0)
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (struct.new $type25
   (struct.new $type26
    (call $foreign7)
   )
  )
 )
 (func $function361 (type $0) (param $0 (ref $environment361)) (param $1 i64) (result i32)
  (if (result i32)
   (i64.eq
    (struct.get $type61 0
     (struct.get $environment361 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign11
     (call $string-ref
      (global.get $string0)
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (struct.get $environment361 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type62 1
       (struct.get $environment361 1
        (local.get $0)
       )
      )
     )
    )
    (return_call $function361
     (local.get $0)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready152)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (if
   (i32.eqz
    (global.get $ready151)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type59
   (global.get $global151)
   (i32.wrap_i64
    (local.get $0)
   )
  )
 )
 (func $main
  (local $0 (ref $type62))
  (local $1 (ref $type25))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (drop
   (call $foreign12)
  )
  (drop
   (call $foreign13)
  )
  (global.set $global121
   (struct.new_default $type32)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type34)
  )
  (global.set $global142
   (struct.new_default $type55)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global143
   (struct.new_default $type56)
  )
  (global.set $ready143
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (global.set $global150
   (call $function335)
  )
  (local.set $1
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (if
   (i32.eqz
    (global.get $ready143)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global143)
   )
  )
  (call $foreign0
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $1)
    )
   )
  )
  (struct.set $type62 1
   (local.tee $0
    (struct.new_default $type62)
   )
   (struct.new $type63
    (struct.new $environment203
     (local.get $1)
     (struct.new $type61
      (i64.const 26)
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type62 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type62 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function203
    (struct.get $type63 0
     (struct.get $type62 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (global.set $global151
   (array.new $type59
    (i64.const 7)
    (i32.const 1000000)
   )
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $global152
   (struct.new_default $type60)
  )
  (global.set $ready152
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

