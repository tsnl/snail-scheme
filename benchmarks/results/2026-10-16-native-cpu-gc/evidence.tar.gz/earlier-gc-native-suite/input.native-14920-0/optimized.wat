(module
 (type $0 (func))
 (rec
  (type $type57 (sub (struct)))
  (type $type68 (struct (field (ref $environment335))))
  (type $3 (func (param (ref $environment547) i64) (result i32)))
  (type $environment547 (struct (field (ref $type14)) (field (ref $type69)) (field (ref $type70))))
  (type $5 (func (param (ref $type14)) (result i32)))
  (type $call60 (func (param (ref $type28)) (result (ref $type57))))
  (type $type28 (struct (field (ref $type26)) (field (ref $type29))))
  (type $type29 (struct (field (mut i64))))
  (type $call61 (func (param eqref (ref $type28) i32 (ref $type14) i64) (result (ref $type14))))
  (type $10 (func (param (ref struct) i64) (result i32)))
  (type $type67 (struct (field (mut i32)) (field (mut (ref null $type68)))))
  (type $type71 (struct (field (ref struct))))
  (type $environment389 (struct (field (ref $type14)) (field (ref $type25)) (field (ref $type69)) (field (ref $type70))))
  (type $type69 (struct (field i64)))
  (type $type26 (struct (field (mut i32))))
  (type $type59 (sub $type57 (struct (field (ref $type14)))))
  (type $environment335 (struct (field (ref $type28)) (field (ref $type25)) (field (ref $type67))))
  (type $type25 (struct (field (ref $type26))))
  (type $type70 (struct (field (mut i32)) (field (mut (ref null $type71)))))
  (type $20 (func (param (ref $environment335) i64) (result i64)))
  (type $21 (func (param (ref $type14) (ref $type14)) (result i32)))
  (type $22 (func (param (ref $type14) i64 i32)))
  (type $23 (func (param (ref $type14) i32 i32 i32) (result (ref $type16))))
  (type $24 (func (param (ref $type14) i64) (result i32)))
  (type $25 (func (param (ref $type14) i32) (result i32)))
  (type $type10 (struct))
  (type $type8 (struct))
  (type $type5 (struct))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type56 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type45 (struct))
  (type $type46 (struct))
  (type $type44 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type13 (struct))
  (type $type58 (sub $type57 (struct)))
  (type $type14 (struct (field i32) (field i32) (field (mut i32)) (field (mut (ref $type16))) (field (mut i32)) (field (mut i32))))
  (type $type16 (array (mut i8)))
 )
 (type $53 (func (result i32)))
 (type $54 (func (param i32)))
 (type $55 (func (param i32) (result i32)))
 (type $56 (func (result i64)))
 (type $57 (func (param i32 i32)))
 (type $58 (func (param i32) (result i64)))
 (import "snail.library" "snail:io/peek-character" (func $foreign0 (param i32) (result i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign1 (param i32) (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign2))
 (import "snail.library" "snail:io/path-character" (func $foreign3 (param i32)))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign5 (param i32)))
 (import "snail.library" "snail:io/check-output" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign7 (param i32 i32)))
 (import "snail.library" "snail:io/read-packet" (func $foreign10 (param i32) (result i64)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign12 (result i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign18 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign19 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 12)
  (i32.const 12)
  (array.new_fixed $type16 12
   (i32.const 98)
   (i32.const 117)
   (i32.const 102)
   (i32.const 102)
   (i32.const 101)
   (i32.const 114)
   (i32.const 101)
   (i32.const 100)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 6)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 206)
   (i32.const 187)
   (i32.const 240)
   (i32.const 159)
   (i32.const 152)
   (i32.const 128)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 27)
  (i32.const 27)
  (array.new_fixed $type16 27
   (i32.const 114)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 32)
   (i32.const 102)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
   (i32.const 117)
   (i32.const 114)
   (i32.const 101)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 10)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 97)
   (i32.const 98)
   (i32.const 115)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string4 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (i32.const 4)
  (array.new_fixed $type16 4
   (i32.const 120)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string5 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (i32.const 4)
  (array.new_fixed $type16 4
   (i32.const 115)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string6 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 9)
  (i32.const 9)
  (array.new_fixed $type16 9
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 115)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $empty58 (ref $type58) (struct.new_default $type58))
 (global $global117 (mut (ref null $type13)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type32)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type34)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type35)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type36)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type37)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type38)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global318 (mut (ref null $type39)) (ref.null none))
 (global $ready318 (mut i32) (i32.const 0))
 (global $global205 (mut (ref null $type41)) (ref.null none))
 (global $ready205 (mut i32) (i32.const 0))
 (global $global237 (mut (ref null $type42)) (ref.null none))
 (global $ready237 (mut i32) (i32.const 0))
 (global $global257 (mut (ref null $type44)) (ref.null none))
 (global $ready257 (mut i32) (i32.const 0))
 (global $global287 (mut (ref null $type46)) (ref.null none))
 (global $ready287 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type45)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type48)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global140 (mut (ref null $type49)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type49)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type56)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type60)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type37)) (ref.null none))
 (global $ready148 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type61)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type62)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global151 (mut (ref null $type63)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (global $global152 (mut (ref null $type64)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type36)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type5)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global160 (mut (ref null $type8)) (ref.null none))
 (global $ready160 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type10)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type5)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type10)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type10)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global165 (mut (ref null $type10)) (ref.null none))
 (global $ready165 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type10)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global167 (mut (ref null $type10)) (ref.null none))
 (global $ready167 (mut i32) (i32.const 0))
 (global $global168 (mut (ref null $type10)) (ref.null none))
 (global $ready168 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type10)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type10)) (ref.null none))
 (global $ready170 (mut i32) (i32.const 0))
 (export "copy-lines" (func $export0))
 (export "line-storage" (func $export1))
 (export "close-input-alias" (func $export2))
 (export "input-callback-close" (func $export3))
 (export "input-escaped-alias" (func $export4))
 (export "input-missing" (func $export5))
 (export "input-callback-trap" (func $export6))
 (export "read-invalid" (func $export7))
 (export "input-raw-output" (func $export8))
 (export "input-stale-handle" (func $export9))
 (export "input-invalid-handle" (func $export10))
 (export "input-invalid-peek" (func $export11))
 (export "main" (func $main))
 (func $string-boundary (type $25) (param $0 (ref $type14)) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref $type16))
  (if
   (i32.lt_u
    (local.tee $4
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $4)
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (then
    (return
     (local.get $1)
    )
   )
  )
  (local.set $3
   (struct.get $type14 5
    (local.get $0)
   )
  )
  (if
   (i32.lt_u
    (local.get $1)
    (select
     (i32.sub
      (local.tee $2
       (struct.get $type14 4
        (local.get $0)
       )
      )
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (i32.const 0)
    )
    (local.set $2
     (i32.const 0)
    )
   )
  )
  (if
   (i32.lt_u
    (i32.sub
     (local.get $4)
     (local.get $1)
    )
    (select
     (i32.sub
      (local.get $2)
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (struct.get $type14 2
      (local.get $0)
     )
    )
    (local.set $2
     (local.get $4)
    )
   )
  )
  (local.set $5
   (struct.get $type14 3
    (local.get $0)
   )
  )
  (loop $label
   (if
    (i32.gt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (local.set $3
      (i32.add
       (if (result i32)
        (i32.lt_u
         (local.tee $4
          (array.get_u $type16
           (local.get $5)
           (local.get $3)
          )
         )
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $4)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $4)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
       (local.get $3)
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (loop $label2
   (if
    (i32.lt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (loop $label1
      (br_if $label1
       (i32.eq
        (i32.and
         (array.get_u $type16
          (local.get $5)
          (local.tee $3
           (i32.sub
            (local.get $3)
            (i32.const 1)
           )
          )
         )
         (i32.const 192)
        )
        (i32.const 128)
       )
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label2)
    )
   )
  )
  (struct.set $type14 4
   (local.get $0)
   (local.get $1)
  )
  (struct.set $type14 5
   (local.get $0)
   (local.get $3)
  )
  (local.get $3)
 )
 (func $string-ref (type $24) (param $0 (ref $type14)) (param $1 i64) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 (ref $type16))
  (if
   (i64.ge_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (block $block (result i32)
   (if
    (i32.lt_u
     (local.tee $2
      (array.get_u $type16
       (local.tee $6
        (struct.get $type14 3
         (local.get $0)
        )
       )
       (local.tee $4
        (call $string-boundary
         (local.get $0)
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
     )
     (i32.const 128)
    )
    (then
     (br $block
      (local.get $2)
     )
    )
   )
   (local.set $2
    (i32.and
     (local.get $2)
     (i32.shr_u
      (i32.const 127)
      (local.tee $5
       (if (result i32)
        (i32.lt_u
         (local.get $2)
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $2)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $2)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.set $3
    (i32.const 1)
   )
   (loop $label
    (local.set $2
     (i32.or
      (i32.and
       (array.get_u $type16
        (local.get $6)
        (i32.add
         (local.get $3)
         (local.get $4)
        )
       )
       (i32.const 63)
      )
      (i32.shl
       (local.get $2)
       (i32.const 6)
      )
     )
    )
    (br_if $label
     (i32.lt_u
      (local.tee $3
       (i32.add
        (local.get $3)
        (i32.const 1)
       )
      )
      (local.get $5)
     )
    )
   )
   (local.get $2)
  )
 )
 (func $string-resize (type $23) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i32) (result (ref $type16))
  (local $4 (ref $type16))
  (local $5 (ref $type16))
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local.set $4
   (struct.get $type14 3
    (local.get $0)
   )
  )
  (if
   (i32.eq
    (i32.sub
     (local.get $2)
     (local.get $1)
    )
    (local.get $3)
   )
   (then
    (return
     (local.get $4)
    )
   )
  )
  (local.set $5
   (local.get $4)
  )
  (if
   (i64.gt_u
    (local.tee $6
     (i64.add
      (i64.extend_i32_u
       (i32.sub
        (local.tee $9
         (struct.get $type14 2
          (local.get $0)
         )
        )
        (i32.sub
         (local.get $2)
         (local.get $1)
        )
       )
      )
      (i64.extend_i32_u
       (local.get $3)
      )
     )
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.lt_u
    (local.tee $10
     (array.len
      (local.get $4)
     )
    )
    (local.tee $8
     (i32.wrap_i64
      (local.get $6)
     )
    )
   )
   (then
    (if
     (i64.gt_u
      (local.tee $7
       (i64.shl
        (i64.extend_i32_u
         (local.get $10)
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967294)
     )
     (then
      (local.set $7
       (i64.const 4294967294)
      )
     )
    )
    (array.copy $type16 $type16
     (local.tee $5
      (array.new_default $type16
       (i32.wrap_i64
        (if (result i64)
         (i64.lt_u
          (local.get $7)
          (local.tee $6
           (i64.extend_i32_u
            (local.get $8)
           )
          )
         )
         (then
          (local.get $6)
         )
         (else
          (local.get $7)
         )
        )
       )
      )
     )
     (i32.const 0)
     (local.get $4)
     (i32.const 0)
     (local.get $1)
    )
   )
  )
  (array.copy $type16 $type16
   (local.get $5)
   (i32.add
    (local.get $1)
    (local.get $3)
   )
   (local.get $4)
   (local.get $2)
   (i32.sub
    (local.get $9)
    (local.get $2)
   )
  )
  (struct.set $type14 3
   (local.get $0)
   (local.get $5)
  )
  (struct.set $type14 2
   (local.get $0)
   (local.get $8)
  )
  (local.get $5)
 )
 (func $string-set! (type $22) (param $0 (ref $type14)) (param $1 i64) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 (ref $type16))
  (if
   (i32.ne
    (struct.get $type14 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $7
   (call $string-resize
    (local.get $0)
    (local.tee $4
     (call $string-boundary
      (local.get $0)
      (local.tee $6
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (i32.add
     (if (result i32)
      (i32.lt_u
       (local.tee $3
        (array.get_u $type16
         (struct.get $type14 3
          (local.get $0)
         )
         (local.get $4)
        )
       )
       (i32.const 128)
      )
      (then
       (i32.const 1)
      )
      (else
       (if (result i32)
        (i32.lt_u
         (local.get $3)
         (i32.const 224)
        )
        (then
         (i32.const 2)
        )
        (else
         (select
          (i32.const 3)
          (i32.const 4)
          (i32.lt_u
           (local.get $3)
           (i32.const 240)
          )
         )
        )
       )
      )
     )
     (local.get $4)
    )
    (local.tee $3
     (if (result i32)
      (i32.lt_u
       (local.get $2)
       (i32.const 128)
      )
      (then
       (i32.const 1)
      )
      (else
       (if (result i32)
        (i32.lt_u
         (local.get $2)
         (i32.const 2048)
        )
        (then
         (i32.const 2)
        )
        (else
         (select
          (i32.const 3)
          (i32.const 4)
          (i32.lt_u
           (local.get $2)
           (i32.const 65536)
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eq
    (local.tee $5
     (local.get $3)
    )
    (i32.const 1)
   )
   (then
    (array.set $type16
     (local.get $7)
     (local.get $4)
     (local.get $2)
    )
   )
   (else
    (loop $label
     (array.set $type16
      (local.get $7)
      (i32.add
       (local.tee $3
        (i32.sub
         (local.get $3)
         (i32.const 1)
        )
       )
       (local.get $4)
      )
      (i32.or
       (i32.and
        (local.get $2)
        (i32.const 63)
       )
       (i32.const 128)
      )
     )
     (local.set $2
      (i32.shr_u
       (local.get $2)
       (i32.const 6)
      )
     )
     (br_if $label
      (i32.gt_u
       (local.get $3)
       (i32.const 1)
      )
     )
    )
    (array.set $type16
     (local.get $7)
     (local.get $4)
     (i32.or
      (if (result i32)
       (i32.eq
        (local.get $5)
        (i32.const 2)
       )
       (then
        (i32.const 192)
       )
       (else
        (select
         (i32.const 224)
         (i32.const 240)
         (i32.eq
          (local.get $5)
          (i32.const 3)
         )
        )
       )
      )
      (local.get $2)
     )
    )
   )
  )
  (struct.set $type14 4
   (local.get $0)
   (local.get $6)
  )
  (struct.set $type14 5
   (local.get $0)
   (local.get $4)
  )
 )
 (func $string=? (type $21) (param $0 (ref $type14)) (param $1 (ref $type14)) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type16))
  (local $5 (ref $type16))
  (if
   (ref.eq
    (local.get $0)
    (local.get $1)
   )
   (then
    (return
     (i32.const 1)
    )
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type14 2
      (local.get $0)
     )
    )
    (struct.get $type14 2
     (local.get $1)
    )
   )
   (then
    (return
     (i32.const 0)
    )
   )
  )
  (local.set $4
   (struct.get $type14 3
    (local.get $0)
   )
  )
  (local.set $5
   (struct.get $type14 3
    (local.get $1)
   )
  )
  (loop $label
   (if
    (i32.ne
     (local.get $2)
     (local.get $3)
    )
    (then
     (if
      (i32.ne
       (array.get_u $type16
        (local.get $4)
        (local.get $2)
       )
       (array.get_u $type16
        (local.get $5)
        (local.get $2)
       )
      )
      (then
       (return
        (i32.const 0)
       )
      )
      (else
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const 1)
        )
       )
       (br $label)
      )
     )
     (unreachable)
    )
   )
  )
  (i32.const 1)
 )
 (func $function335 (type $20) (param $0 (ref $environment335)) (param $1 i64) (result i64)
  (local $2 (ref $type57))
  (local $3 (ref $type70))
  (local $4 (ref $type14))
  (local $5 (ref $type25))
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (local.set $2
   (call $function433
    (struct.get $environment335 0
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready146)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global146)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type58)
     (local.get $2)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type59)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (ref.test (ref $type58)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $2)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (call $foreign6
     (struct.get $type26 0
      (struct.get $type25 0
       (local.tee $5
        (struct.get $environment335 1
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.set $type70 1
     (local.tee $3
      (struct.new_default $type70)
     )
     (struct.new $type71
      (struct.new $environment389
       (local.get $4)
       (local.get $5)
       (struct.new $type69
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $4)
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type70 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function389
      (struct.get $type71 0
       (struct.get $type70 1
        (local.get $3)
       )
      )
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global153)
     )
    )
    (if
     (i32.eqz
      (global.get $ready151)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global151)
     )
    )
    (call $foreign7
     (struct.get $type26 0
      (struct.get $type25 0
       (struct.get $environment335 1
        (local.get $0)
       )
      )
     )
     (i32.const 10)
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment335 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type67 1
       (struct.get $environment335 2
        (local.get $0)
       )
      )
     )
    )
    (return_call $function335
     (local.get $0)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function389 (type $10) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment389))
  (local $3 i32)
  (if (result i32)
   (i64.eq
    (struct.get $type69 0
     (struct.get $environment389 2
      (ref.cast (ref $environment389)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (call $string-ref
      (struct.get $environment389 0
       (local.tee $2
        (ref.cast (ref $environment389)
         (local.get $0)
        )
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready151)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global151)
     )
    )
    (call $foreign7
     (struct.get $type26 0
      (struct.get $type25 0
       (struct.get $environment389 1
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (struct.get $environment389 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type70 1
       (struct.get $environment389 3
        (local.get $2)
       )
      )
     )
    )
    (return_call $function389
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function413 (type $call61) (param $0 eqref) (param $1 (ref $type28)) (param $2 i32) (param $3 (ref $type14)) (param $4 i64) (result (ref $type14))
  (local $5 i64)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 (ref $type14))
  (local $11 (ref $type29))
  (local $12 (ref $type16))
  (local $13 (ref $type16))
  (if (result (ref $type14))
   (if (result i32)
    (i32.eq
     (local.get $2)
     (i32.const -1)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.or
      (i32.eq
       (local.get $2)
       (i32.const 13)
      )
      (i32.eq
       (local.get $2)
       (i32.const 10)
      )
     )
    )
   )
   (then
    (if
     (i32.eq
      (local.get $2)
      (i32.const 13)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready148)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global148)
       )
      )
      (if
       (i32.eqz
        (global.get $ready141)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global141)
       )
      )
      (if
       (i32.eq
        (if (result i32)
         (i32.lt_s
          (local.tee $2
           (struct.get $type26 0
            (struct.get $type28 0
             (local.get $1)
            )
           )
          )
          (i32.const 0)
         )
         (then
          (call $foreign0
           (local.get $2)
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready138)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global138)
           )
          )
          (if
           (i64.eqz
            (local.tee $5
             (struct.get $type29 0
              (local.tee $11
               (struct.get $type28 1
                (local.get $1)
               )
              )
             )
            )
           )
           (then
            (struct.set $type29 0
             (local.get $11)
             (local.tee $5
              (call $foreign10
               (struct.get $type26 0
                (struct.get $type28 0
                 (local.get $1)
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready139)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (if (result i32)
           (i64.lt_s
            (local.get $5)
            (i64.const 0)
           )
           (then
            (if (result i32)
             (i64.eq
              (local.get $5)
              (i64.const -1)
             )
             (then
              (i32.const -1)
             )
             (else
              (if
               (i64.ne
                (i64.extend32_s
                 (local.tee $5
                  (i64.sub
                   (i64.const -2)
                   (local.get $5)
                  )
                 )
                )
                (local.get $5)
               )
               (then
                (unreachable)
               )
              )
              (i32.wrap_i64
               (local.get $5)
              )
             )
            )
           )
           (else
            (if
             (i64.ne
              (i64.extend32_s
               (local.tee $5
                (i64.sub
                 (i64.and
                  (local.get $5)
                  (i64.const 255)
                 )
                 (i64.const 1)
                )
               )
              )
              (local.get $5)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $5)
            )
           )
          )
         )
        )
        (i32.const 10)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready140)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global140)
         )
        )
        (drop
         (if (result i32)
          (i32.lt_s
           (local.tee $2
            (struct.get $type26 0
             (struct.get $type28 0
              (local.get $1)
             )
            )
           )
           (i32.const 0)
          )
          (then
           (call $foreign1
            (local.get $2)
           )
          )
          (else
           (if
            (i32.eqz
             (global.get $ready138)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global138)
            )
           )
           (struct.set $type29 0
            (local.tee $11
             (struct.get $type28 1
              (local.get $1)
             )
            )
            (block (result i64)
             (if
              (i64.eqz
               (local.tee $5
                (struct.get $type29 0
                 (local.get $11)
                )
               )
              )
              (then
               (struct.set $type29 0
                (local.get $11)
                (local.tee $5
                 (call $foreign10
                  (struct.get $type26 0
                   (struct.get $type28 0
                    (local.get $1)
                   )
                  )
                 )
                )
               )
              )
             )
             (select
              (i64.shr_u
               (local.get $5)
               (i64.const 8)
              )
              (i64.const 0)
              (i64.gt_s
               (local.get $5)
               (i64.const 0)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready139)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global139)
            )
           )
           (if (result i32)
            (i64.lt_s
             (local.get $5)
             (i64.const 0)
            )
            (then
             (if (result i32)
              (i64.eq
               (local.get $5)
               (i64.const -1)
              )
              (then
               (i32.const -1)
              )
              (else
               (if
                (i64.ne
                 (i64.extend32_s
                  (local.tee $5
                   (i64.sub
                    (i64.const -2)
                    (local.get $5)
                   )
                  )
                 )
                 (local.get $5)
                )
                (then
                 (unreachable)
                )
               )
               (i32.const 0)
              )
             )
            )
            (else
             (if
              (i64.ne
               (i64.extend32_s
                (local.tee $5
                 (i64.sub
                  (i64.and
                   (local.get $5)
                   (i64.const 255)
                  )
                  (i64.const 1)
                 )
                )
               )
               (local.get $5)
              )
              (then
               (unreachable)
              )
             )
             (i32.const 0)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $3)
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (if
       (i64.gt_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (call $string-boundary
        (local.get $3)
        (i32.const 0)
       )
      )
      (array.copy $type16 $type16
       (local.tee $12
        (array.new_default $type16
         (local.tee $6
          (i32.sub
           (call $string-boundary
            (local.get $3)
            (local.tee $2
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
           (local.get $7)
          )
         )
        )
       )
       (i32.const 0)
       (struct.get $type14 3
        (local.get $3)
       )
       (local.get $7)
       (local.get $6)
      )
      (struct.new $type14
       (i32.const 1)
       (local.get $2)
       (local.get $6)
       (local.get $12)
       (i32.const 0)
       (i32.const 0)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready150)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global150)
     )
    )
    (if
     (i64.le_s
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $3)
       )
      )
      (local.get $4)
     )
     (then
      (local.set $3
       (if (result (ref $type14))
        (i64.eq
         (local.get $4)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready117)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global117)
          )
         )
         (if
          (i64.gt_u
           (local.tee $5
            (if (result i64)
             (i64.eqz
              (local.get $4)
             )
             (then
              (i64.const 64)
             )
             (else
              (select
               (i64.const 4294967294)
               (i64.shl
                (local.get $4)
                (i64.const 1)
               )
               (i64.gt_s
                (local.get $4)
                (i64.const 2147483647)
               )
              )
             )
            )
           )
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $5)
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (local.set $12
          (array.new_default $type16
           (local.tee $6
            (i32.wrap_i64
             (local.get $5)
            )
           )
          )
         )
         (if
          (i32.ne
           (struct.get $type14 0
            (local.tee $10
             (struct.new $type14
              (i32.const 1)
              (local.get $6)
              (local.get $6)
              (local.get $12)
              (i32.const 0)
              (i32.const 0)
             )
            )
           )
           (i32.const 1)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $4)
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $4)
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $10)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $8
          (call $string-boundary
           (local.get $3)
           (i32.const 0)
          )
         )
         (if
          (i32.and
           (i32.ne
            (local.tee $6
             (i32.sub
              (call $string-boundary
               (local.get $3)
               (local.tee $7
                (i32.wrap_i64
                 (local.get $4)
                )
               )
              )
              (block (result i32)
               (local.set $9
                (call $string-boundary
                 (local.get $10)
                 (i32.const 0)
                )
               )
               (local.set $7
                (call $string-boundary
                 (local.get $10)
                 (local.get $7)
                )
               )
               (local.set $13
                (struct.get $type14 3
                 (local.get $3)
                )
               )
               (local.get $8)
              )
             )
            )
            (i32.sub
             (local.get $7)
             (local.get $9)
            )
           )
           (ref.eq
            (local.get $3)
            (local.get $10)
           )
          )
          (then
           (array.copy $type16 $type16
            (local.tee $12
             (array.new_default $type16
              (local.get $6)
             )
            )
            (i32.const 0)
            (local.get $13)
            (local.get $8)
            (local.get $6)
           )
           (local.set $13
            (local.get $12)
           )
           (local.set $8
            (i32.const 0)
           )
          )
         )
         (array.copy $type16 $type16
          (call $string-resize
           (local.get $10)
           (local.get $9)
           (local.get $7)
           (local.get $6)
          )
          (local.get $9)
          (local.get $13)
          (local.get $8)
          (local.get $6)
         )
         (struct.set $type14 4
          (local.get $10)
          (i32.const 0)
         )
         (struct.set $type14 5
          (local.get $10)
          (local.get $9)
         )
         (local.get $10)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.extend_i32_s
        (local.get $2)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (call $string-set!
     (local.get $3)
     (local.get $4)
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (global.get $ready140)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global140)
     )
    )
    (local.set $2
     (if (result i32)
      (i32.lt_s
       (local.tee $2
        (struct.get $type26 0
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
       (i32.const 0)
      )
      (then
       (call $foreign1
        (local.get $2)
       )
      )
      (else
       (if
        (i32.eqz
         (global.get $ready138)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global138)
        )
       )
       (struct.set $type29 0
        (local.tee $11
         (struct.get $type28 1
          (local.get $1)
         )
        )
        (block (result i64)
         (if
          (i64.eqz
           (local.tee $5
            (struct.get $type29 0
             (local.get $11)
            )
           )
          )
          (then
           (struct.set $type29 0
            (local.get $11)
            (local.tee $5
             (call $foreign10
              (struct.get $type26 0
               (struct.get $type28 0
                (local.get $1)
               )
              )
             )
            )
           )
          )
         )
         (select
          (i64.shr_u
           (local.get $5)
           (i64.const 8)
          )
          (i64.const 0)
          (i64.gt_s
           (local.get $5)
           (i64.const 0)
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready139)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global139)
        )
       )
       (if (result i32)
        (i64.lt_s
         (local.get $5)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.eq
           (local.get $5)
           (i64.const -1)
          )
          (then
           (i32.const -1)
          )
          (else
           (if
            (i64.ne
             (i64.extend32_s
              (local.tee $5
               (i64.sub
                (i64.const -2)
                (local.get $5)
               )
              )
             )
             (local.get $5)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
         )
        )
        (else
         (if
          (i64.ne
           (i64.extend32_s
            (local.tee $5
             (i64.sub
              (i64.and
               (local.get $5)
               (i64.const 255)
              )
              (i64.const 1)
             )
            )
           )
           (local.get $5)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready149)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global149)
     )
    )
    (return_call $function413
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function433 (type $call60) (param $0 (ref $type28)) (result (ref $type57))
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type29))
  (if
   (i32.eqz
    (global.get $ready140)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global140)
   )
  )
  (if (result (ref $type57))
   (i32.eq
    (local.tee $2
     (if (result i32)
      (i32.lt_s
       (local.tee $2
        (struct.get $type26 0
         (struct.get $type28 0
          (local.get $0)
         )
        )
       )
       (i32.const 0)
      )
      (then
       (call $foreign1
        (local.get $2)
       )
      )
      (else
       (if
        (i32.eqz
         (global.get $ready138)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global138)
        )
       )
       (struct.set $type29 0
        (local.tee $3
         (struct.get $type28 1
          (local.get $0)
         )
        )
        (block (result i64)
         (if
          (i64.eqz
           (local.tee $1
            (struct.get $type29 0
             (local.get $3)
            )
           )
          )
          (then
           (struct.set $type29 0
            (local.get $3)
            (local.tee $1
             (call $foreign10
              (struct.get $type26 0
               (struct.get $type28 0
                (local.get $0)
               )
              )
             )
            )
           )
          )
         )
         (select
          (i64.shr_u
           (local.get $1)
           (i64.const 8)
          )
          (i64.const 0)
          (i64.gt_s
           (local.get $1)
           (i64.const 0)
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready139)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global139)
        )
       )
       (if (result i32)
        (i64.lt_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.eq
           (local.get $1)
           (i64.const -1)
          )
          (then
           (i32.const -1)
          )
          (else
           (if
            (i64.ne
             (i64.extend32_s
              (local.tee $1
               (i64.sub
                (i64.const -2)
                (local.get $1)
               )
              )
             )
             (local.get $1)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
        (else
         (if
          (i64.ne
           (i64.extend32_s
            (local.tee $1
             (i64.sub
              (i64.and
               (local.get $1)
               (i64.const 255)
              )
              (i64.const 1)
             )
            )
           )
           (local.get $1)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (global.get $empty58)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready117)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (if
     (i32.eqz
      (global.get $ready149)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global149)
     )
    )
    (struct.new $type59
     (call $function413
      (ref.null none)
      (local.get $0)
      (local.get $2)
      (struct.new $type14
       (i32.const 1)
       (i32.const 0)
       (i32.const 0)
       (array.new_default $type16
        (i32.const 0)
       )
       (i32.const 0)
       (i32.const 0)
      )
      (i64.const 0)
     )
    )
   )
  )
 )
 (func $function536 (type $5) (param $0 (ref $type14)) (result i32)
  (local $1 (ref $environment547))
  (local $2 (ref $type70))
  (local $3 (ref struct))
  (call $foreign2)
  (struct.set $type70 1
   (local.tee $2
    (struct.new_default $type70)
   )
   (struct.new $type71
    (struct.new $environment547
     (local.get $0)
     (struct.new $type69
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type70 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type70 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (struct.get $type69 0
     (struct.get $environment547 1
      (ref.cast (ref $environment547)
       (local.tee $3
        (struct.get $type71 0
         (struct.get $type70 1
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign3
     (call $string-ref
      (struct.get $environment547 0
       (local.tee $1
        (ref.cast (ref $environment547)
         (local.get $3)
        )
       )
      )
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (struct.get $environment547 2
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type70 1
       (struct.get $environment547 2
        (local.get $1)
       )
      )
     )
    )
    (if (result i32)
     (i64.eq
      (struct.get $type69 0
       (struct.get $environment547 1
        (local.get $1)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (call $foreign3
       (call $string-ref
        (struct.get $environment547 0
         (local.get $1)
        )
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type70 0
         (struct.get $environment547 2
          (local.get $1)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type70 1
         (struct.get $environment547 2
          (local.get $1)
         )
        )
       )
      )
      (if (result i32)
       (i64.eq
        (struct.get $type69 0
         (struct.get $environment547 1
          (local.get $1)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $foreign3
         (call $string-ref
          (struct.get $environment547 0
           (local.get $1)
          )
          (i64.const 2)
         )
        )
        (if
         (i32.eqz
          (struct.get $type70 0
           (struct.get $environment547 2
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (struct.get $type70 1
           (struct.get $environment547 2
            (local.get $1)
           )
          )
         )
        )
        (if (result i32)
         (i64.eq
          (struct.get $type69 0
           (struct.get $environment547 1
            (local.get $1)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (call $foreign3
           (call $string-ref
            (struct.get $environment547 0
             (local.get $1)
            )
            (i64.const 3)
           )
          )
          (if
           (i32.eqz
            (struct.get $type70 0
             (struct.get $environment547 2
              (local.get $1)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (struct.get $type70 1
             (struct.get $environment547 2
              (local.get $1)
             )
            )
           )
          )
          (if (result i32)
           (i64.eq
            (struct.get $type69 0
             (struct.get $environment547 1
              (local.get $1)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (call $foreign3
             (call $string-ref
              (struct.get $environment547 0
               (local.get $1)
              )
              (i64.const 4)
             )
            )
            (if
             (i32.eqz
              (struct.get $type70 0
               (struct.get $environment547 2
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (struct.get $type70 1
               (struct.get $environment547 2
                (local.get $1)
               )
              )
             )
            )
            (if (result i32)
             (i64.eq
              (struct.get $type69 0
               (struct.get $environment547 1
                (local.get $1)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (call $foreign3
               (call $string-ref
                (struct.get $environment547 0
                 (local.get $1)
                )
                (i64.const 5)
               )
              )
              (if
               (i32.eqz
                (struct.get $type70 0
                 (struct.get $environment547 2
                  (local.get $1)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (struct.get $type70 1
                 (struct.get $environment547 2
                  (local.get $1)
                 )
                )
               )
              )
              (if (result i32)
               (i64.eq
                (struct.get $type69 0
                 (struct.get $environment547 1
                  (local.get $1)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (call $foreign3
                 (call $string-ref
                  (struct.get $environment547 0
                   (local.get $1)
                  )
                  (i64.const 6)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type70 0
                   (struct.get $environment547 2
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (struct.get $type70 1
                   (struct.get $environment547 2
                    (local.get $1)
                   )
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (struct.get $type69 0
                   (struct.get $environment547 1
                    (local.get $1)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (call $foreign3
                   (call $string-ref
                    (struct.get $environment547 0
                     (local.get $1)
                    )
                    (i64.const 7)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type70 0
                     (struct.get $environment547 2
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (struct.get $type70 1
                     (struct.get $environment547 2
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (struct.get $type69 0
                     (struct.get $environment547 1
                      (local.get $1)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign3
                     (call $string-ref
                      (struct.get $environment547 0
                       (local.get $1)
                      )
                      (i64.const 8)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type70 0
                       (struct.get $environment547 2
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (struct.get $type70 1
                       (struct.get $environment547 2
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (struct.get $type69 0
                       (struct.get $environment547 1
                        (local.get $1)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign3
                       (call $string-ref
                        (struct.get $environment547 0
                         (local.get $1)
                        )
                        (i64.const 9)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type70 0
                         (struct.get $environment547 2
                          (local.get $1)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (struct.get $type70 1
                         (struct.get $environment547 2
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (struct.get $type69 0
                         (struct.get $environment547 1
                          (local.get $1)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign3
                         (call $string-ref
                          (struct.get $environment547 0
                           (local.get $1)
                          )
                          (i64.const 10)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type70 0
                           (struct.get $environment547 2
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (struct.get $type70 1
                           (struct.get $environment547 2
                            (local.get $1)
                           )
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (struct.get $type69 0
                           (struct.get $environment547 1
                            (local.get $1)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign3
                           (call $string-ref
                            (struct.get $environment547 0
                             (local.get $1)
                            )
                            (i64.const 11)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type70 0
                             (struct.get $environment547 2
                              (local.get $1)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (struct.get $type70 1
                             (struct.get $environment547 2
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (struct.get $type69 0
                             (struct.get $environment547 1
                              (local.get $1)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign3
                             (call $string-ref
                              (struct.get $environment547 0
                               (local.get $1)
                              )
                              (i64.const 12)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type70 0
                               (struct.get $environment547 2
                                (local.get $1)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (struct.get $type70 1
                               (struct.get $environment547 2
                                (local.get $1)
                               )
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (struct.get $type69 0
                               (struct.get $environment547 1
                                (local.get $1)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign3
                               (call $string-ref
                                (struct.get $environment547 0
                                 (local.get $1)
                                )
                                (i64.const 13)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type70 0
                                 (struct.get $environment547 2
                                  (local.get $1)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (struct.get $type70 1
                                 (struct.get $environment547 2
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (struct.get $type69 0
                                 (struct.get $environment547 1
                                  (local.get $1)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign3
                                 (call $string-ref
                                  (struct.get $environment547 0
                                   (local.get $1)
                                  )
                                  (i64.const 14)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type70 0
                                   (struct.get $environment547 2
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (struct.get $type70 1
                                   (struct.get $environment547 2
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (return_call $function547
                                 (local.get $1)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function547 (type $3) (param $0 (ref $environment547)) (param $1 i64) (result i32)
  (if (result i32)
   (i64.eq
    (struct.get $type69 0
     (struct.get $environment547 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign3
     (call $string-ref
      (struct.get $environment547 0
       (local.get $0)
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (struct.get $environment547 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type70 1
       (struct.get $environment547 2
        (local.get $0)
       )
      )
     )
    )
    (return_call $function547
     (local.get $0)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (result i64)
  (local $0 i32)
  (local $1 i64)
  (local $2 (ref $type67))
  (local $3 (ref $type28))
  (local $4 (ref $type26))
  (local $5 (ref $type25))
  (local $scratch i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global159)
   )
  )
  (if
   (i32.eqz
    (global.get $ready257)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global257)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string1)
   )
  )
  (local.set $3
   (struct.new $type28
    (struct.new $type26
     (call $foreign12)
    )
    (struct.new_default $type29)
   )
  )
  (if
   (i32.eqz
    (global.get $ready318)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global318)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string6)
   )
  )
  (struct.set $type67 1
   (local.tee $2
    (struct.new_default $type67)
   )
   (struct.new $type68
    (struct.new $environment335
     (local.get $3)
     (local.tee $5
      (struct.new $type25
       (struct.new $type26
        (call $foreign4)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type67 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch
   (call $function335
    (struct.get $type68 0
     (struct.get $type67 1
      (local.get $2)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $4
         (struct.get $type25 0
          (local.get $5)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $4)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $3)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $4
         (struct.get $type28 0
          (local.get $3)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $4)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $0)
    )
   )
  )
  (local.get $scratch)
 )
 (func $export1 (result i32)
  (local $0 (ref $type57))
  (local $1 (ref $type28))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 (ref $type26))
  (local $5 i32)
  (local $6 i32)
  (local $scratch i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready160)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global160)
   )
  )
  (if
   (i32.eqz
    (global.get $ready287)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global287)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string1)
   )
  )
  (local.set $1
   (struct.new $type28
    (struct.new $type26
     (call $foreign12)
    )
    (struct.new_default $type29)
   )
  )
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (if
   (ref.test (ref $type58)
    (local.tee $0
     (call $function433
      (local.get $1)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type59 0
    (ref.cast (ref $type59)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (if
   (ref.test (ref $type58)
    (local.tee $0
     (call $function433
      (local.get $1)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type59 0
    (ref.cast (ref $type59)
     (local.get $0)
    )
   )
  )
  (call $string-set!
   (local.get $2)
   (i64.const 0)
   (i32.const 120)
  )
  (local.set $scratch
   (if (result i32)
    (ref.eq
     (local.get $2)
     (local.get $3)
    )
    (then
     (i32.const 0)
    )
    (else
     (if (result i32)
      (call $string=?
       (local.get $2)
       (global.get $string4)
      )
      (then
       (if (result i32)
        (call $string=?
         (local.get $3)
         (global.get $string5)
        )
        (then
         (if
          (i32.eqz
           (global.get $ready147)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global147)
          )
         )
         (local.set $0
          (call $function433
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready146)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global146)
          )
         )
         (if (result i32)
          (if (result i32)
           (ref.test (ref $type58)
            (local.get $0)
           )
           (then
            (i32.const 1)
           )
           (else
            (drop
             (ref.cast (ref $type59)
              (local.get $0)
             )
            )
            (i32.const 0)
           )
          )
          (then
           (if
            (i32.eqz
             (global.get $ready147)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global147)
            )
           )
           (local.set $0
            (call $function433
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready146)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global146)
            )
           )
           (if (result i32)
            (ref.test (ref $type58)
             (local.get $0)
            )
            (then
             (i32.const 1)
            )
            (else
             (drop
              (ref.cast (ref $type59)
               (local.get $0)
              )
             )
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $1)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $5
       (struct.get $type26 0
        (local.tee $4
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $5)
        (i32.const -3)
       )
       (i32.eq
        (local.get $5)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $4)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $5)
    )
   )
  )
  (local.get $scratch)
 )
 (func $export2
  (local $0 i32)
  (local $1 (ref $type28))
  (local $2 (ref $type26))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string1)
   )
  )
  (local.set $1
   (struct.new $type28
    (struct.new $type26
     (call $foreign12)
    )
    (struct.new_default $type29)
   )
  )
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (drop
   (call $function433
    (local.get $1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $1)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $2
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $1)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $2
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $0)
    )
   )
  )
 )
 (func $export3 (result i64)
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready162)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (if
   (i32.eqz
    (global.get $ready257)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global257)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string1)
   )
  )
  (local.set $0
   (call $foreign12)
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.get $0)
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (call $foreign5
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.get $0)
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (call $foreign5
     (local.get $0)
    )
   )
  )
  (i64.const 19)
 )
 (func $export4
  (local $0 i32)
  (local $1 (ref $type28))
  (local $2 (ref $type26))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (if
   (i32.eqz
    (global.get $ready237)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global237)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string1)
   )
  )
  (local.set $1
   (struct.new $type28
    (struct.new $type26
     (call $foreign12)
    )
    (struct.new_default $type29)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $1)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $2
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $1)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $2
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (drop
   (call $function433
    (local.get $1)
   )
  )
 )
 (func $export5
  (local $0 (ref $type28))
  (local $1 (ref $type26))
  (local $2 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready164)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (if
   (i32.eqz
    (global.get $ready205)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global205)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string3)
   )
  )
  (local.set $0
   (struct.new $type28
    (struct.new $type26
     (call $foreign12)
    )
    (struct.new_default $type29)
   )
  )
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (drop
   (call $function433
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $0)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $2
       (struct.get $type26 0
        (local.tee $1
         (struct.get $type28 0
          (local.get $0)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $2)
        (i32.const -3)
       )
       (i32.eq
        (local.get $2)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
 )
 (func $export6
  (local $0 (ref $type28))
  (local $scratch (ref (exact $type28)))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready165)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global165)
   )
  )
  (if
   (i32.eqz
    (global.get $ready205)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global205)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string1)
   )
  )
  (drop
   (call $function433
    (block (result (ref (exact $type28)))
     (local.set $scratch
      (struct.new $type28
       (struct.new $type26
        (call $foreign12)
       )
       (struct.new_default $type29)
      )
     )
     (if
      (i32.eqz
       (global.get $ready147)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global147)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (unreachable)
 )
 (func $export7
  (local $0 (ref $type70))
  (local $1 (ref $type25))
  (local $2 (ref $type28))
  (local $scratch (ref (exact $type28)))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string0)
   )
  )
  (local.set $1
   (struct.new $type25
    (struct.new $type26
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (call $function536
    (global.get $string1)
   )
  )
  (drop
   (call $function433
    (block (result (ref (exact $type28)))
     (local.set $scratch
      (struct.new $type28
       (struct.new $type26
        (call $foreign12)
       )
       (struct.new_default $type29)
      )
     )
     (if
      (i32.eqz
       (global.get $ready152)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global152)
      )
     )
     (call $foreign6
      (struct.get $type26 0
       (struct.get $type25 0
        (local.get $1)
       )
      )
     )
     (struct.set $type70 1
      (local.tee $0
       (struct.new_default $type70)
      )
      (struct.new $type71
       (struct.new $environment389
        (global.get $string2)
        (local.get $1)
        (struct.new $type69
         (i64.const 27)
        )
        (local.get $0)
       )
      )
     )
     (struct.set $type70 0
      (local.get $0)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type70 0
        (local.get $0)
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (call $function389
       (struct.get $type71 0
        (struct.get $type70 1
         (local.get $0)
        )
       )
       (i64.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready147)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global147)
      )
     )
     (local.get $scratch)
    )
   )
  )
 )
 (func $export8
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (call $foreign2)
  (call $foreign3
   (i32.const 120)
  )
  (drop
   (call $foreign1
    (call $foreign4)
   )
  )
 )
 (func $export9
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready168)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global168)
   )
  )
  (call $foreign2)
  (call $foreign3
   (i32.const 120)
  )
  (call $foreign5
   (local.tee $0
    (call $foreign4)
   )
  )
  (drop
   (call $foreign1
    (local.get $0)
   )
  )
 )
 (func $export10
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready169)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (drop
   (call $foreign1
    (i32.const -1)
   )
  )
 )
 (func $export11
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready170)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global170)
   )
  )
  (drop
   (call $foreign0
    (i32.const -1)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global117
   (struct.new_default $type13)
  )
  (global.set $ready117
   (i32.const 1)
  )
  (drop
   (call $foreign18)
  )
  (drop
   (call $foreign19)
  )
  (global.set $global130
   (struct.new_default $type32)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type34)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type35)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type36)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type37)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type38)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global318
   (struct.new_default $type39)
  )
  (global.set $ready318
   (i32.const 1)
  )
  (global.set $global205
   (struct.new_default $type41)
  )
  (global.set $ready205
   (i32.const 1)
  )
  (global.set $global237
   (struct.new_default $type42)
  )
  (global.set $ready237
   (i32.const 1)
  )
  (global.set $global257
   (struct.new_default $type44)
  )
  (global.set $ready257
   (i32.const 1)
  )
  (global.set $global287
   (struct.new_default $type46)
  )
  (global.set $ready287
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type45)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type48)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global140
   (struct.new_default $type49)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type49)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global146
   (struct.new_default $type56)
  )
  (global.set $ready146
   (i32.const 1)
  )
  (global.set $global147
   (struct.new_default $type60)
  )
  (global.set $ready147
   (i32.const 1)
  )
  (global.set $global148
   (struct.new_default $type37)
  )
  (global.set $ready148
   (i32.const 1)
  )
  (global.set $global149
   (struct.new_default $type61)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global150
   (struct.new_default $type62)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $global151
   (struct.new_default $type63)
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $global152
   (struct.new_default $type64)
  )
  (global.set $ready152
   (i32.const 1)
  )
  (global.set $global153
   (struct.new_default $type36)
  )
  (global.set $ready153
   (i32.const 1)
  )
  (global.set $global159
   (struct.new_default $type5)
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global160
   (struct.new_default $type8)
  )
  (global.set $ready160
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type10)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global162
   (struct.new_default $type5)
  )
  (global.set $ready162
   (i32.const 1)
  )
  (global.set $global163
   (struct.new_default $type10)
  )
  (global.set $ready163
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type10)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global165
   (struct.new_default $type10)
  )
  (global.set $ready165
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type10)
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global167
   (struct.new_default $type10)
  )
  (global.set $ready167
   (i32.const 1)
  )
  (global.set $global168
   (struct.new_default $type10)
  )
  (global.set $ready168
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type10)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global170
   (struct.new_default $type10)
  )
  (global.set $ready170
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

