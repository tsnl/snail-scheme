(module (table 1 funcref) (func $f) (elem (i32.const 1) func $f) (func (export "size") (result i32) (table.size 0)) (func (export "main") (result i32) (i32.const 0)))
