(module
 (type $0 (func (result i64)))
 (rec
  (type $type50 (struct (field (ref $environment174))))
  (type $environment189 (struct (field (ref $type51))))
  (type $3 (func (param (ref $environment376) (ref null $type12) i64) (result i64)))
  (type $4 (func (param (ref $environment361) (ref null $type12) i64) (result (ref $type20))))
  (type $type59 (struct (field (ref $environment361))))
  (type $environment361 (struct (field (ref $type55)) (field (ref $type58))))
  (type $type55 (struct (field (ref $type20))))
  (type $type52 (struct (field (ref struct))))
  (type $type58 (struct (field (mut i32)) (field (mut (ref null $type59)))))
  (type $type51 (struct (field (mut i32)) (field (mut (ref null $type52)))))
  (type $environment376 (struct (field (ref $type51))))
  (type $call31 (func (param (ref $type12)) (result (ref $type20))))
  (type $type49 (struct (field (mut i32)) (field (mut (ref null $type50)))))
  (type $type13 (array (mut i64)))
  (type $type12 (struct (field i64) (field (ref null $type12))))
  (type $type48 (struct (field (ref $type13))))
  (type $environment174 (struct (field (ref $type48)) (field (ref $type49))))
  (type $18 (func (param (ref $environment174) (ref null $type12) i64) (result (ref $type13))))
  (type $type10 (struct))
  (type $type5 (struct))
  (type $type46 (struct))
  (type $type35 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type15 (struct))
  (type $type14 (struct))
  (type $type11 (struct))
  (type $type47 (struct))
  (type $type30 (struct))
  (type $type45 (struct (field (mut i64))))
  (type $type20 (struct (field i32) (field (ref $type21))))
  (type $type21 (array (mut i8)))
 )
 (type $33 (func))
 (global $execution (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type20)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type45)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type30)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global216 (mut (ref null $type47)) (ref.null none))
 (global $ready216 (mut i32) (i32.const 0))
 (global $global$9 (ref $type21) (array.new_fixed $type21 2
  (i32.const 9)
  (i32.const 8)
 ))
 (global $global$10 (ref $type21) (array.new_fixed $type21 0))
 (global $global158 (mut (ref null $type11)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type14)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global181 (mut (ref null $type15)) (ref.null none))
 (global $ready181 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type31)) (ref.null none))
 (global $global368 (mut (ref null $type15)) (ref.null none))
 (global $ready368 (mut i32) (i32.const 0))
 (global $global319 (mut (ref null $type32)) (ref.null none))
 (global $ready319 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type35)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type46)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type5)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type5)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type5)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type5)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type5)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type5)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type5)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type10)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type10)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type10)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type10)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global143 (mut (ref null $type10)) (ref.null none))
 (global $ready143 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type10)) (ref.null none))
 (global $ready144 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type10)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type10)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type10)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type5)) (ref.null none))
 (global $ready148 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type5)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type5)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (export "negative-length" (func $export0))
 (export "overflow-length" (func $export1))
 (export "empty-invalid-fill" (func $export2))
 (export "negative-fill" (func $export3))
 (export "negative-index" (func $export4))
 (export "wrapped-index" (func $export5))
 (export "endpoint-index" (func $export6))
 (export "invalid-byte" (func $export7))
 (export "readonly-write" (func $export8))
 (export "readonly-empty-copy" (func $export9))
 (export "source-range" (func $export10))
 (export "target-range" (func $export11))
 (export "reversed-range" (func $export12))
 (export "negative-range" (func $export13))
 (export "empty-source-range" (func $export14))
 (export "empty-target-range" (func $export15))
 (export "negative-copy" (func $export16))
 (export "wrong-top" (func $export17))
 (export "wrong-string" (func $export18))
 (export "main" (func $main))
 (func $function174 (type $18) (param $0 (ref $environment174)) (param $1 (ref null $type12)) (param $2 i64) (result (ref $type13))
  (local $3 i64)
  (if (result (ref $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type48 0
     (struct.get $environment174 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (struct.get $type48 0
      (struct.get $environment174 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (struct.get $environment174 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type49 1
       (struct.get $environment174 1
        (local.get $0)
       )
      )
     )
    )
    (return_call $function174
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function351 (type $call31) (param $0 (ref $type12)) (result (ref $type20))
  (local $1 (ref null $type12))
  (local $2 (ref $environment376))
  (local $3 (ref $type51))
  (local $4 (ref $type58))
  (local $5 (ref struct))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready368)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global368)
   )
  )
  (struct.set $type51 1
   (local.tee $3
    (struct.new_default $type51)
   )
   (struct.new $type52
    (struct.new $environment376
     (local.get $3)
    )
   )
  )
  (struct.set $type51 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (struct.get $environment376 0
      (ref.cast (ref $environment376)
       (local.tee $5
        (struct.get $type52 0
         (struct.get $type51 1
          (local.get $3)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type51 1
     (struct.get $environment376 0
      (local.tee $2
       (ref.cast (ref $environment376)
        (local.get $5)
       )
      )
     )
    )
   )
  )
  (local.set $6
   (if (result i64)
    (ref.is_null
     (local.tee $1
      (struct.get $type12 1
       (local.get $0)
      )
     )
    )
    (then
     (i64.const 1)
    )
    (else
     (local.set $1
      (struct.get $type12 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (struct.get $type51 0
        (struct.get $environment376 0
         (local.get $2)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (struct.get $type51 1
        (struct.get $environment376 0
         (local.get $2)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 2)
      )
      (else
       (local.set $1
        (struct.get $type12 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type51 0
          (struct.get $environment376 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (struct.get $type51 1
          (struct.get $environment376 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 3)
        )
        (else
         (local.set $1
          (struct.get $type12 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type51 0
            (struct.get $environment376 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (struct.get $type51 1
            (struct.get $environment376 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 4)
          )
          (else
           (local.set $1
            (struct.get $type12 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type51 0
              (struct.get $environment376 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (struct.get $type51 1
              (struct.get $environment376 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 5)
            )
            (else
             (local.set $1
              (struct.get $type12 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type51 0
                (struct.get $environment376 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (struct.get $type51 1
                (struct.get $environment376 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 6)
              )
              (else
               (local.set $1
                (struct.get $type12 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type51 0
                  (struct.get $environment376 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (struct.get $type51 1
                  (struct.get $environment376 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 7)
                )
                (else
                 (local.set $1
                  (struct.get $type12 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type51 0
                    (struct.get $environment376 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (struct.get $type51 1
                    (struct.get $environment376 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 8)
                  )
                  (else
                   (local.set $1
                    (struct.get $type12 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type51 0
                      (struct.get $environment376 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (struct.get $type51 1
                      (struct.get $environment376 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 9)
                    )
                    (else
                     (local.set $1
                      (struct.get $type12 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type51 0
                        (struct.get $environment376 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (struct.get $type51 1
                        (struct.get $environment376 0
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i64.const 10)
                      )
                      (else
                       (local.set $1
                        (struct.get $type12 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type51 0
                          (struct.get $environment376 0
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (struct.get $type51 1
                          (struct.get $environment376 0
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i64.const 11)
                        )
                        (else
                         (local.set $1
                          (struct.get $type12 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type51 0
                            (struct.get $environment376 0
                             (local.get $2)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (struct.get $type51 1
                            (struct.get $environment376 0
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i64.const 12)
                          )
                          (else
                           (local.set $1
                            (struct.get $type12 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type51 0
                              (struct.get $environment376 0
                               (local.get $2)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (struct.get $type51 1
                              (struct.get $environment376 0
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i64.const 13)
                            )
                            (else
                             (local.set $1
                              (struct.get $type12 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type51 0
                                (struct.get $environment376 0
                                 (local.get $2)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (struct.get $type51 1
                                (struct.get $environment376 0
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (call $function376
                              (local.get $2)
                              (local.get $1)
                              (i64.const 14)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type58 1
   (local.tee $4
    (struct.new_default $type58)
   )
   (struct.new $type59
    (struct.new $environment361
     (struct.new $type55
      (struct.new $type20
       (i32.const 1)
       (array.new_default $type21
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type58 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type58 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function361
   (struct.get $type59 0
    (struct.get $type58 1
     (local.get $4)
    )
   )
   (local.get $0)
   (i64.const 0)
  )
 )
 (func $function361 (type $4) (param $0 (ref $environment361)) (param $1 (ref null $type12)) (param $2 i64) (result (ref $type20))
  (local $3 i64)
  (local $4 (ref $type20))
  (local $scratch (ref $type20))
  (if (result (ref $type20))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type55 0
     (struct.get $environment361 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (array.set $type21
     (struct.get $type20 1
      (block (result (ref $type20))
       (local.set $scratch
        (struct.get $type55 0
         (struct.get $environment361 0
          (local.get $0)
         )
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $3)
         (i64.const 255)
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment361 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type58 1
       (struct.get $environment361 1
        (local.get $0)
       )
      )
     )
    )
    (return_call $function361
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function376 (type $3) (param $0 (ref $environment376)) (param $1 (ref null $type12)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type12 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type51 0
         (struct.get $environment376 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type51 1
         (struct.get $environment376 0
          (local.get $0)
         )
        )
       )
      )
      (return_call $function376
       (local.get $0)
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $export0 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready131)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (unreachable)
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (unreachable)
 )
 (func $export2 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (unreachable)
 )
 (func $export3 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (unreachable)
 )
 (func $export4 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type20 1
    (global.get $global129)
   )
  )
  (unreachable)
 )
 (func $export5 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type20 1
    (global.get $global129)
   )
  )
  (unreachable)
 )
 (func $export6 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (array.get_u $type21
    (struct.get $type20 1
     (global.get $global129)
    )
    (i32.const 3)
   )
  )
 )
 (func $export7
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (unreachable)
 )
 (func $export8
  (local $0 (ref $type45))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready215)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type45 0
   (ref.as_non_null
    (global.get $global130)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (i64.mul
      (struct.get $type45 0
       (global.get $global130)
      )
      (i64.const 10)
     )
     (i64.const 1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready216)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global216)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type45 0
   (ref.as_non_null
    (global.get $global130)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (i64.mul
      (struct.get $type45 0
       (global.get $global130)
      )
      (i64.const 10)
     )
     (i64.const 2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready216)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global216)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type45 0
   (ref.as_non_null
    (global.get $global130)
   )
   (block (result i64)
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (i64.mul
      (struct.get $type45 0
       (global.get $global130)
      )
      (i64.const 10)
     )
     (i64.const 3)
    )
   )
  )
  (unreachable)
 )
 (func $export9
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (unreachable)
 )
 (func $export10
  (local $0 (ref $type20))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type21 $type21
   (struct.get $type20 1
    (ref.as_non_null
     (global.get $global129)
    )
   )
   (i32.const 0)
   (global.get $global$9)
   (i32.const 0)
   (i32.const 3)
  )
 )
 (func $export11
  (local $0 (ref $type20))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready143)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global143)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type21 $type21
   (struct.get $type20 1
    (ref.as_non_null
     (global.get $global129)
    )
   )
   (i32.const 2)
   (global.get $global$9)
   (i32.const 0)
   (i32.const 2)
  )
 )
 (func $export12
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready144)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (unreachable)
 )
 (func $export13
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (unreachable)
 )
 (func $export14
  (local $0 (ref $type20))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready146)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global146)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type21 $type21
   (struct.get $type20 1
    (ref.as_non_null
     (global.get $global129)
    )
   )
   (i32.const 0)
   (global.get $global$10)
   (i32.const 1)
   (i32.const 0)
  )
 )
 (func $export15
  (local $0 (ref $type20))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type21 $type21
   (struct.get $type20 1
    (ref.as_non_null
     (global.get $global129)
    )
   )
   (i32.const 4)
   (global.get $global$10)
   (i32.const 0)
   (i32.const 0)
  )
 )
 (func $export16 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready148)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global148)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.eqz
    (global.get $ready319)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global319)
   )
  )
  (unreachable)
 )
 (func $export17 (result i64)
  (local $0 (ref $type51))
  (local $1 (ref $type49))
  (local $2 (ref $environment189))
  (local $3 (ref struct))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready149)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global149)
   )
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (if
   (i32.eqz
    (global.get $ready181)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global181)
   )
  )
  (struct.set $type51 1
   (local.tee $0
    (struct.new_default $type51)
   )
   (struct.new $type52
    (struct.new $environment189
     (local.get $0)
    )
   )
  )
  (struct.set $type51 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (struct.get $environment189 0
      (ref.cast (ref $environment189)
       (local.tee $3
        (struct.get $type52 0
         (struct.get $type51 1
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type51 1
     (struct.get $environment189 0
      (local.tee $2
       (ref.cast (ref $environment189)
        (local.get $3)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (struct.get $environment189 0
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type51 1
     (struct.get $environment189 0
      (local.get $2)
     )
    )
   )
  )
  (struct.set $type49 1
   (local.tee $1
    (struct.new_default $type49)
   )
   (struct.new $type50
    (struct.new $environment174
     (struct.new $type48
      (array.new $type13
       (i64.const 1)
       (i32.const 2)
      )
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type49 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type49 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function174
    (struct.get $type50 0
     (struct.get $type49 1
      (local.get $1)
     )
    )
    (struct.new $type12
     (i64.const 1)
     (struct.new $type12
      (i64.const 2)
      (ref.null none)
     )
    )
    (i64.const 0)
   )
  )
  (unreachable)
 )
 (func $export18 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (unreachable)
 )
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global158
   (struct.new_default $type11)
  )
  (global.set $ready158
   (i32.const 1)
  )
  (global.set $global163
   (struct.new_default $type14)
  )
  (global.set $ready163
   (i32.const 1)
  )
  (global.set $global181
   (struct.new_default $type15)
  )
  (global.set $ready181
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type30)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global117
   (struct.new_default $type31)
  )
  (global.set $global368
   (struct.new_default $type15)
  )
  (global.set $ready368
   (i32.const 1)
  )
  (global.set $global319
   (struct.new_default $type32)
  )
  (global.set $ready319
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type35)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (global.set $global129
   (call $function351
    (struct.new $type12
     (i64.const 1)
     (struct.new $type12
      (i64.const 2)
      (struct.new $type12
       (i64.const 3)
       (ref.null none)
      )
     )
    )
   )
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type45)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global215
   (struct.new_default $type46)
  )
  (global.set $ready215
   (i32.const 1)
  )
  (global.set $global216
   (struct.new_default $type47)
  )
  (global.set $ready216
   (i32.const 1)
  )
  (global.set $global131
   (struct.new_default $type5)
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type5)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type5)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type5)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type5)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type5)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type5)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type10)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type10)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type10)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type10)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global143
   (struct.new_default $type10)
  )
  (global.set $ready143
   (i32.const 1)
  )
  (global.set $global144
   (struct.new_default $type10)
  )
  (global.set $ready144
   (i32.const 1)
  )
  (global.set $global145
   (struct.new_default $type10)
  )
  (global.set $ready145
   (i32.const 1)
  )
  (global.set $global146
   (struct.new_default $type10)
  )
  (global.set $ready146
   (i32.const 1)
  )
  (global.set $global147
   (struct.new_default $type10)
  )
  (global.set $ready147
   (i32.const 1)
  )
  (global.set $global148
   (struct.new_default $type5)
  )
  (global.set $ready148
   (i32.const 1)
  )
  (global.set $global149
   (struct.new_default $type5)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global150
   (struct.new_default $type5)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 42)
 )
)

