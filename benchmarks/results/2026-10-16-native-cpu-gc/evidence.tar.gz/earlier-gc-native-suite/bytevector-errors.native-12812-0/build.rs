fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-gc-hotpath-20261016/build/native/attempt-4-0/bytevector-errors.native-12812-0/module.bc");
}
