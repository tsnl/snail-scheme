#[path = "/tmp/snail-native-gc-hotpath-20261016/tests/native-support.rs"] mod support;
unsafe extern "C" { #[link_name="wasm.main"] fn guest_main()->i64;
#[link_name = "wasm.negative-length"] fn probe0() -> i64;
#[link_name = "wasm.overflow-length"] fn probe1() -> i64;
#[link_name = "wasm.empty-invalid-fill"] fn probe2() -> i64;
#[link_name = "wasm.negative-fill"] fn probe3() -> i64;
#[link_name = "wasm.negative-index"] fn probe4() -> i64;
#[link_name = "wasm.wrapped-index"] fn probe5() -> i64;
#[link_name = "wasm.endpoint-index"] fn probe6() -> i64;
#[link_name = "wasm.invalid-byte"] fn probe7();
#[link_name = "wasm.readonly-write"] fn probe8();
#[link_name = "wasm.readonly-empty-copy"] fn probe9();
#[link_name = "wasm.source-range"] fn probe10();
#[link_name = "wasm.target-range"] fn probe11();
#[link_name = "wasm.reversed-range"] fn probe12();
#[link_name = "wasm.negative-range"] fn probe13();
#[link_name = "wasm.empty-source-range"] fn probe14();
#[link_name = "wasm.empty-target-range"] fn probe15();
#[link_name = "wasm.negative-copy"] fn probe16() -> i64;
#[link_name = "wasm.wrong-top"] fn probe17() -> i64;
#[link_name = "wasm.wrong-string"] fn probe18() -> i64;}
fn main(){ let a=support::initialize(); assert_eq!(a.len(),2); unsafe {assert_eq!(guest_main(),42); match a[1].as_str(){"negative-length" => { probe0(); },
"overflow-length" => { probe1(); },
"empty-invalid-fill" => { probe2(); },
"negative-fill" => { probe3(); },
"negative-index" => { probe4(); },
"wrapped-index" => { probe5(); },
"endpoint-index" => { probe6(); },
"invalid-byte" => { probe7(); },
"readonly-write" => { probe8(); },
"readonly-empty-copy" => { probe9(); },
"source-range" => { probe10(); },
"target-range" => { probe11(); },
"reversed-range" => { probe12(); },
"negative-range" => { probe13(); },
"empty-source-range" => { probe14(); },
"empty-target-range" => { probe15(); },
"negative-copy" => { probe16(); },
"wrong-top" => { probe17(); },
"wrong-string" => { probe18(); },_=>panic!("unknown probe")}} support::finish(0);}

extern crate snail_runtime as _;
