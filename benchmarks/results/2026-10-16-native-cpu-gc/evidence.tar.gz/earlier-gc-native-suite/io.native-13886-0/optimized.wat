(module
 (rec
  (type $0 (func (param (ref $environment529) i64) (result i32)))
  (type $type69 (struct (field (ref struct))))
  (type $environment529 (struct (field (ref $type14)) (field (ref $type67)) (field (ref $type68))))
  (type $3 (func (param (ref $type14)) (result i32)))
  (type $type68 (struct (field (mut i32)) (field (mut (ref null $type69)))))
  (type $type67 (struct (field i64)))
  (type $environment371 (struct (field (ref $type14)) (field (ref $type25)) (field (ref $type67)) (field (ref $type68))))
  (type $7 (func (param (ref struct) i64) (result i32)))
  (type $type26 (struct (field (mut i32))))
  (type $type25 (struct (field (ref $type26))))
  (type $10 (func (param eqref i64 (ref $type25))))
  (type $11 (func (param (ref $type14) i64) (result i32)))
  (type $type10 (struct))
  (type $type8 (struct))
  (type $type7 (struct))
  (type $type5 (struct))
  (type $type66 (struct))
  (type $type65 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type44 (struct))
  (type $type42 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type36 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type16)) (field (mut i32)) (field (mut i32))))
  (type $type16 (array (mut i8)))
 )
 (type $31 (func))
 (type $32 (func (result i32)))
 (type $33 (func (param i32)))
 (type $34 (func (result i64)))
 (type $35 (func (param i32 i32)))
 (type $36 (func (param i64) (result i64)))
 (type $37 (func (result f64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/close" (func $foreign2 (param i32)))
 (import "snail.library" "snail:io/check-output" (func $foreign3 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign4 (param i32 i32)))
 (import "snail.library" "snail:io/open-output-file" (func $foreign10 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign11))
 (import "snail.library" "snail:io/file-exists" (func $foreign12 (result i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign15 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign16 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 9)
  (i32.const 9)
  (array.new_fixed $type16 9
   (i32.const 102)
   (i32.const 105)
   (i32.const 114)
   (i32.const 115)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 10)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 115)
   (i32.const 101)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 100)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 5)
  (i32.const 5)
  (array.new_fixed $type16 5
   (i32.const 102)
   (i32.const 105)
   (i32.const 114)
   (i32.const 115)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 6)
  (i32.const 6)
  (array.new_fixed $type16 6
   (i32.const 115)
   (i32.const 101)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 100)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string4 (ref $type14) (struct.new $type14
  (i32.const 8)
  (i32.const 8)
  (array.new_fixed $type16 8
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 112)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string5 (ref $type14) (struct.new $type14
  (i32.const 8)
  (i32.const 8)
  (array.new_fixed $type16 8
   (i32.const 98)
   (i32.const 117)
   (i32.const 102)
   (i32.const 102)
   (i32.const 101)
   (i32.const 114)
   (i32.const 101)
   (i32.const 100)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string6 (ref $type14) (struct.new $type14
  (i32.const 10)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 97)
   (i32.const 98)
   (i32.const 115)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string7 (ref $type14) (struct.new $type14
  (i32.const 8)
  (i32.const 8)
  (array.new_fixed $type16 8
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 0)
   (i32.const 112)
   (i32.const 97)
   (i32.const 116)
   (i32.const 104)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string8 (ref $type14) (struct.new $type14
  (i32.const 16)
  (i32.const 16)
  (array.new_fixed $type16 16
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 47)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string9 (ref $type14) (struct.new $type14
  (i32.const 11)
  (i32.const 11)
  (array.new_fixed $type16 11
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string10 (ref $type14) (struct.new $type14
  (i32.const 14)
  (i32.const 14)
  (array.new_fixed $type16 14
   (i32.const 115)
   (i32.const 101)
   (i32.const 108)
   (i32.const 102)
   (i32.const 45)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string11 (ref $type14) (struct.new $type14
  (i32.const 6)
  (i32.const 6)
  (array.new_fixed $type16 6
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string12 (ref $type14) (struct.new $type14
  (i32.const 9)
  (i32.const 9)
  (array.new_fixed $type16 9
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 97)
   (i32.const 115)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string13 (ref $type14) (struct.new $type14
  (i32.const 4)
  (i32.const 4)
  (array.new_fixed $type16 4
   (i32.const 111)
   (i32.const 110)
   (i32.const 99)
   (i32.const 101)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string14 (ref $type14) (struct.new $type14
  (i32.const 6)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 206)
   (i32.const 187)
   (i32.const 240)
   (i32.const 159)
   (i32.const 152)
   (i32.const 128)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string15 (ref $type14) (struct.new $type14
  (i32.const 10)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 117)
   (i32.const 108)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string16 (ref $type14) (struct.new $type14
  (i32.const 6)
  (i32.const 6)
  (array.new_fixed $type16 6
   (i32.const 97)
   (i32.const 110)
   (i32.const 115)
   (i32.const 119)
   (i32.const 101)
   (i32.const 114)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string17 (ref $type14) (struct.new $type14
  (i32.const 4)
  (i32.const 11)
  (array.new_fixed $type16 11
   (i32.const 0)
   (i32.const 206)
   (i32.const 187)
   (i32.const 240)
   (i32.const 159)
   (i32.const 152)
   (i32.const 128)
   (i32.const 244)
   (i32.const 143)
   (i32.const 191)
   (i32.const 191)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string18 (ref $type14) (struct.new $type14
  (i32.const 10)
  (i32.const 10)
  (array.new_fixed $type16 10
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $global134 (mut (ref null $type32)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type33)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type32)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type34)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type36)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type38)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global205 (mut (ref null $type39)) (ref.null none))
 (global $ready205 (mut i32) (i32.const 0))
 (global $global240 (mut (ref null $type40)) (ref.null none))
 (global $ready240 (mut i32) (i32.const 0))
 (global $global260 (mut (ref null $type42)) (ref.null none))
 (global $ready260 (mut i32) (i32.const 0))
 (global $global294 (mut (ref null $type44)) (ref.null none))
 (global $ready294 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type62)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global156 (mut (ref null $type63)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (global $global157 (mut (ref null $type36)) (ref.null none))
 (global $ready157 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type65)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type65)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type66)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type5)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global165 (mut (ref null $type7)) (ref.null none))
 (global $ready165 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type8)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global167 (mut (ref null $type10)) (ref.null none))
 (global $ready167 (mut i32) (i32.const 0))
 (global $global168 (mut (ref null $type10)) (ref.null none))
 (global $ready168 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type5)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global170 (mut (ref null $type10)) (ref.null none))
 (global $ready170 (mut i32) (i32.const 0))
 (global $global171 (mut (ref null $type10)) (ref.null none))
 (global $ready171 (mut i32) (i32.const 0))
 (global $global172 (mut (ref null $type8)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (global $global173 (mut (ref null $type10)) (ref.null none))
 (global $ready173 (mut i32) (i32.const 0))
 (global $global174 (mut (ref null $type10)) (ref.null none))
 (global $ready174 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type10)) (ref.null none))
 (global $ready175 (mut i32) (i32.const 0))
 (global $global176 (mut (ref null $type10)) (ref.null none))
 (global $ready176 (mut i32) (i32.const 0))
 (global $global177 (mut (ref null $type10)) (ref.null none))
 (global $ready177 (mut i32) (i32.const 0))
 (global $global178 (mut (ref null $type10)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (export "format-number" (func $export0))
 (export "unicode" (func $export1))
 (export "callback-result" (func $export2))
 (export "exists" (func $export3))
 (export "remove" (func $export4))
 (export "close-alias" (func $export5))
 (export "callback-close" (func $export6))
 (export "escaped-alias" (func $export7))
 (export "missing-directory" (func $export8))
 (export "nul-path" (func $export9))
 (export "delete-absent" (func $export10))
 (export "callback-trap" (func $export11))
 (export "close-failure" (func $export12))
 (export "invalid-character" (func $export13))
 (export "invalid-handle" (func $export14))
 (export "interrupted-path" (func $export15))
 (export "main" (func $main))
 (func $string-ref (type $11) (param $0 (ref $type14)) (param $1 i64) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 (ref $type16))
  (local $7 (ref $type16))
  (if
   (i64.ge_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (block $block1 (result i32)
   (if
    (i32.lt_u
     (local.tee $2
      (array.get_u $type16
       (local.tee $7
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (local.tee $3
        (block $block (result i32)
         (if
          (i32.gt_u
           (local.tee $3
            (i32.wrap_i64
             (local.get $1)
            )
           )
           (local.tee $5
            (struct.get $type14 0
             (local.get $0)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (br_if $block
           (local.get $3)
           (i32.eq
            (local.get $5)
            (struct.get $type14 1
             (local.get $0)
            )
           )
          )
         )
         (local.set $4
          (struct.get $type14 4
           (local.get $0)
          )
         )
         (if
          (i32.lt_u
           (local.get $3)
           (select
            (i32.sub
             (local.tee $2
              (struct.get $type14 3
               (local.get $0)
              )
             )
             (local.get $3)
            )
            (i32.sub
             (local.get $3)
             (local.get $2)
            )
            (i32.gt_u
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (then
           (local.set $4
            (i32.const 0)
           )
           (local.set $2
            (i32.const 0)
           )
          )
         )
         (if
          (i32.lt_u
           (i32.sub
            (local.get $5)
            (local.get $3)
           )
           (select
            (i32.sub
             (local.get $2)
             (local.get $3)
            )
            (i32.sub
             (local.get $3)
             (local.get $2)
            )
            (i32.gt_u
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (then
           (local.set $4
            (struct.get $type14 1
             (local.get $0)
            )
           )
           (local.set $2
            (local.get $5)
           )
          )
         )
         (local.set $6
          (struct.get $type14 2
           (local.get $0)
          )
         )
         (loop $label
          (if
           (i32.lt_u
            (local.get $2)
            (local.get $3)
           )
           (then
            (local.set $4
             (i32.add
              (if (result i32)
               (i32.lt_u
                (local.tee $5
                 (array.get_u $type16
                  (local.get $6)
                  (local.get $4)
                 )
                )
                (i32.const 128)
               )
               (then
                (i32.const 1)
               )
               (else
                (if (result i32)
                 (i32.lt_u
                  (local.get $5)
                  (i32.const 224)
                 )
                 (then
                  (i32.const 2)
                 )
                 (else
                  (select
                   (i32.const 3)
                   (i32.const 4)
                   (i32.lt_u
                    (local.get $5)
                    (i32.const 240)
                   )
                  )
                 )
                )
               )
              )
              (local.get $4)
             )
            )
            (local.set $2
             (i32.add
              (local.get $2)
              (i32.const 1)
             )
            )
            (br $label)
           )
          )
         )
         (loop $label2
          (if
           (i32.gt_u
            (local.get $2)
            (local.get $3)
           )
           (then
            (loop $label1
             (br_if $label1
              (i32.eq
               (i32.and
                (array.get_u $type16
                 (local.get $6)
                 (local.tee $4
                  (i32.sub
                   (local.get $4)
                   (i32.const 1)
                  )
                 )
                )
                (i32.const 192)
               )
               (i32.const 128)
              )
             )
            )
            (local.set $2
             (i32.sub
              (local.get $2)
              (i32.const 1)
             )
            )
            (br $label2)
           )
          )
         )
         (struct.set $type14 3
          (local.get $0)
          (local.get $3)
         )
         (struct.set $type14 4
          (local.get $0)
          (local.get $4)
         )
         (local.get $4)
        )
       )
      )
     )
     (i32.const 128)
    )
    (then
     (br $block1
      (local.get $2)
     )
    )
   )
   (local.set $2
    (i32.and
     (local.get $2)
     (i32.shr_u
      (i32.const 127)
      (local.tee $5
       (if (result i32)
        (i32.lt_u
         (local.get $2)
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $2)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $2)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.set $4
    (i32.const 1)
   )
   (loop $label3
    (local.set $2
     (i32.or
      (i32.and
       (array.get_u $type16
        (local.get $7)
        (i32.add
         (local.get $3)
         (local.get $4)
        )
       )
       (i32.const 63)
      )
      (i32.shl
       (local.get $2)
       (i32.const 6)
      )
     )
    )
    (br_if $label3
     (i32.lt_u
      (local.tee $4
       (i32.add
        (local.get $4)
        (i32.const 1)
       )
      )
      (local.get $5)
     )
    )
   )
   (local.get $2)
  )
 )
 (func $function325 (type $10) (param $0 eqref) (param $1 i64) (param $2 (ref $type25))
  (local $3 i64)
  (if
   (i64.ne
    (local.tee $3
     (i64.div_s
      (local.get $1)
      (i64.const 10)
     )
    )
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready162)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (call $function325
     (local.get $0)
     (local.get $3)
     (local.get $2)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (i64.sub
      (i64.const 48)
      (i64.rem_s
       (local.get $1)
       (i64.const 10)
      )
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $1)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $1)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (call $foreign4
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $2)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function371 (type $7) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment371))
  (local $3 i32)
  (if (result i32)
   (i64.eq
    (struct.get $type67 0
     (struct.get $environment371 2
      (ref.cast (ref $environment371)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (call $string-ref
      (struct.get $environment371 0
       (local.tee $2
        (ref.cast (ref $environment371)
         (local.get $0)
        )
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (call $foreign4
     (struct.get $type26 0
      (struct.get $type25 0
       (struct.get $environment371 1
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment371 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type68 1
       (struct.get $environment371 3
        (local.get $2)
       )
      )
     )
    )
    (return_call $function371
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function518 (type $3) (param $0 (ref $type14)) (result i32)
  (local $1 (ref $environment529))
  (local $2 (ref $type68))
  (local $3 (ref struct))
  (call $foreign0)
  (struct.set $type68 1
   (local.tee $2
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment529
     (local.get $0)
     (struct.new $type67
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type68 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (struct.get $type67 0
     (struct.get $environment529 1
      (ref.cast (ref $environment529)
       (local.tee $3
        (struct.get $type69 0
         (struct.get $type68 1
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign1
     (call $string-ref
      (struct.get $environment529 0
       (local.tee $1
        (ref.cast (ref $environment529)
         (local.get $3)
        )
       )
      )
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment529 2
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type68 1
       (struct.get $environment529 2
        (local.get $1)
       )
      )
     )
    )
    (if (result i32)
     (i64.eq
      (struct.get $type67 0
       (struct.get $environment529 1
        (local.get $1)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (call $foreign1
       (call $string-ref
        (struct.get $environment529 0
         (local.get $1)
        )
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type68 0
         (struct.get $environment529 2
          (local.get $1)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (struct.get $type68 1
         (struct.get $environment529 2
          (local.get $1)
         )
        )
       )
      )
      (if (result i32)
       (i64.eq
        (struct.get $type67 0
         (struct.get $environment529 1
          (local.get $1)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $foreign1
         (call $string-ref
          (struct.get $environment529 0
           (local.get $1)
          )
          (i64.const 2)
         )
        )
        (if
         (i32.eqz
          (struct.get $type68 0
           (struct.get $environment529 2
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (struct.get $type68 1
           (struct.get $environment529 2
            (local.get $1)
           )
          )
         )
        )
        (if (result i32)
         (i64.eq
          (struct.get $type67 0
           (struct.get $environment529 1
            (local.get $1)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (call $foreign1
           (call $string-ref
            (struct.get $environment529 0
             (local.get $1)
            )
            (i64.const 3)
           )
          )
          (if
           (i32.eqz
            (struct.get $type68 0
             (struct.get $environment529 2
              (local.get $1)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (struct.get $type68 1
             (struct.get $environment529 2
              (local.get $1)
             )
            )
           )
          )
          (if (result i32)
           (i64.eq
            (struct.get $type67 0
             (struct.get $environment529 1
              (local.get $1)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (call $foreign1
             (call $string-ref
              (struct.get $environment529 0
               (local.get $1)
              )
              (i64.const 4)
             )
            )
            (if
             (i32.eqz
              (struct.get $type68 0
               (struct.get $environment529 2
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (struct.get $type68 1
               (struct.get $environment529 2
                (local.get $1)
               )
              )
             )
            )
            (if (result i32)
             (i64.eq
              (struct.get $type67 0
               (struct.get $environment529 1
                (local.get $1)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (call $foreign1
               (call $string-ref
                (struct.get $environment529 0
                 (local.get $1)
                )
                (i64.const 5)
               )
              )
              (if
               (i32.eqz
                (struct.get $type68 0
                 (struct.get $environment529 2
                  (local.get $1)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (struct.get $type68 1
                 (struct.get $environment529 2
                  (local.get $1)
                 )
                )
               )
              )
              (if (result i32)
               (i64.eq
                (struct.get $type67 0
                 (struct.get $environment529 1
                  (local.get $1)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (call $foreign1
                 (call $string-ref
                  (struct.get $environment529 0
                   (local.get $1)
                  )
                  (i64.const 6)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type68 0
                   (struct.get $environment529 2
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (struct.get $type68 1
                   (struct.get $environment529 2
                    (local.get $1)
                   )
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (struct.get $type67 0
                   (struct.get $environment529 1
                    (local.get $1)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (call $foreign1
                   (call $string-ref
                    (struct.get $environment529 0
                     (local.get $1)
                    )
                    (i64.const 7)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type68 0
                     (struct.get $environment529 2
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (struct.get $type68 1
                     (struct.get $environment529 2
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (struct.get $type67 0
                     (struct.get $environment529 1
                      (local.get $1)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign1
                     (call $string-ref
                      (struct.get $environment529 0
                       (local.get $1)
                      )
                      (i64.const 8)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type68 0
                       (struct.get $environment529 2
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (struct.get $type68 1
                       (struct.get $environment529 2
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (struct.get $type67 0
                       (struct.get $environment529 1
                        (local.get $1)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign1
                       (call $string-ref
                        (struct.get $environment529 0
                         (local.get $1)
                        )
                        (i64.const 9)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type68 0
                         (struct.get $environment529 2
                          (local.get $1)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (struct.get $type68 1
                         (struct.get $environment529 2
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (struct.get $type67 0
                         (struct.get $environment529 1
                          (local.get $1)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign1
                         (call $string-ref
                          (struct.get $environment529 0
                           (local.get $1)
                          )
                          (i64.const 10)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type68 0
                           (struct.get $environment529 2
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (struct.get $type68 1
                           (struct.get $environment529 2
                            (local.get $1)
                           )
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (struct.get $type67 0
                           (struct.get $environment529 1
                            (local.get $1)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign1
                           (call $string-ref
                            (struct.get $environment529 0
                             (local.get $1)
                            )
                            (i64.const 11)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type68 0
                             (struct.get $environment529 2
                              (local.get $1)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (struct.get $type68 1
                             (struct.get $environment529 2
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (struct.get $type67 0
                             (struct.get $environment529 1
                              (local.get $1)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign1
                             (call $string-ref
                              (struct.get $environment529 0
                               (local.get $1)
                              )
                              (i64.const 12)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type68 0
                               (struct.get $environment529 2
                                (local.get $1)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (struct.get $type68 1
                               (struct.get $environment529 2
                                (local.get $1)
                               )
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (struct.get $type67 0
                               (struct.get $environment529 1
                                (local.get $1)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign1
                               (call $string-ref
                                (struct.get $environment529 0
                                 (local.get $1)
                                )
                                (i64.const 13)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type68 0
                                 (struct.get $environment529 2
                                  (local.get $1)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (struct.get $type68 1
                                 (struct.get $environment529 2
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (struct.get $type67 0
                                 (struct.get $environment529 1
                                  (local.get $1)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign1
                                 (call $string-ref
                                  (struct.get $environment529 0
                                   (local.get $1)
                                  )
                                  (i64.const 14)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type68 0
                                   (struct.get $environment529 2
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (struct.get $type68 1
                                   (struct.get $environment529 2
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                                (return_call $function529
                                 (local.get $1)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function529 (type $0) (param $0 (ref $environment529)) (param $1 i64) (result i32)
  (if (result i32)
   (i64.eq
    (struct.get $type67 0
     (struct.get $environment529 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign1
     (call $string-ref
      (struct.get $environment529 0
       (local.get $0)
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment529 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type68 1
       (struct.get $environment529 2
        (local.get $0)
       )
      )
     )
    )
    (return_call $function529
     (local.get $0)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type25))
  (local $2 (ref $type26))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (if
   (i32.eqz
    (global.get $ready260)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global260)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string18)
   )
  )
  (local.set $1
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (call $foreign4
     (struct.get $type26 0
      (struct.get $type25 0
       (local.get $1)
      )
     )
     (i32.const 45)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready162)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (call $function325
   (ref.null none)
   (select
    (i64.sub
     (i64.const 0)
     (local.get $0)
    )
    (local.get $0)
    (i64.gt_s
     (local.get $0)
     (i64.const 0)
    )
   )
   (local.get $1)
  )
  (if
   (i32.eqz
    (global.get $ready157)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global157)
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (call $foreign4
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $1)
    )
   )
   (i32.const 10)
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $3
       (struct.get $type26 0
        (local.tee $2
         (struct.get $type25 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $3)
        (i32.const -3)
       )
       (i32.eq
        (local.get $3)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $3)
    )
   )
  )
  (local.get $0)
 )
 (func $export1 (result i64)
  (local $0 (ref $type25))
  (local $1 (ref $type68))
  (local $2 (ref $type26))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready164)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (if
   (i32.eqz
    (global.get $ready260)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global260)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string14)
   )
  )
  (local.set $0
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (call $foreign3
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $0)
    )
   )
  )
  (struct.set $type68 1
   (local.tee $1
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment371
     (global.get $string17)
     (local.get $0)
     (struct.new $type67
      (i64.const 4)
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type68 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function371
    (struct.get $type69 0
     (struct.get $type68 1
      (local.get $1)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (call $foreign4
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $0)
    )
   )
   (i32.const 10)
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $3
       (struct.get $type26 0
        (local.tee $2
         (struct.get $type25 0
          (local.get $0)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $3)
        (i32.const -3)
       )
       (i32.eq
        (local.get $3)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $3)
    )
   )
  )
  (i64.const 42)
 )
 (func $export2 (result f64)
  (local $0 (ref $type68))
  (local $1 (ref $type25))
  (local $2 (ref $type26))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready165)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global165)
   )
  )
  (if
   (i32.eqz
    (global.get $ready294)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global294)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string15)
   )
  )
  (local.set $1
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (call $foreign3
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $1)
    )
   )
  )
  (struct.set $type68 1
   (local.tee $0
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment371
     (global.get $string16)
     (local.get $1)
     (struct.new $type67
      (i64.const 6)
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type68 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function371
    (struct.get $type69 0
     (struct.get $type68 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $3
       (struct.get $type26 0
        (local.tee $2
         (struct.get $type25 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $3)
        (i32.const -3)
       )
       (i32.eq
        (local.get $3)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $2)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $3)
    )
   )
  )
  (f64.const 1.25)
 )
 (func $export3 (result i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string14)
   )
  )
  (i32.eq
   (call $foreign12)
   (i32.const 1)
  )
 )
 (func $export4
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string14)
   )
  )
  (call $foreign11)
 )
 (func $export5
  (local $0 i32)
  (local $1 (ref $type25))
  (local $2 (ref $type68))
  (local $3 (ref $type26))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready168)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global168)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string12)
   )
  )
  (local.set $1
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (call $foreign3
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $1)
    )
   )
  )
  (struct.set $type68 1
   (local.tee $2
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment371
     (global.get $string13)
     (local.get $1)
     (struct.new $type67
      (i64.const 4)
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type68 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function371
    (struct.get $type69 0
     (struct.get $type68 1
      (local.get $2)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $3
         (struct.get $type25 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $3)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $3
         (struct.get $type25 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $3)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $0)
    )
   )
  )
 )
 (func $export6 (result i64)
  (local $0 i32)
  (local $1 (ref $type25))
  (local $2 (ref $type68))
  (local $3 (ref $type26))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready169)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (if
   (i32.eqz
    (global.get $ready260)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global260)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string10)
   )
  )
  (local.set $1
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (call $foreign3
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $1)
    )
   )
  )
  (struct.set $type68 1
   (local.tee $2
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment371
     (global.get $string11)
     (local.get $1)
     (struct.new $type67
      (i64.const 6)
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type68 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function371
    (struct.get $type69 0
     (struct.get $type68 1
      (local.get $2)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $3
         (struct.get $type25 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $3)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $0
       (struct.get $type26 0
        (local.tee $3
         (struct.get $type25 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $3)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $0)
    )
   )
  )
  (i64.const 19)
 )
 (func $export7
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready170)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global170)
   )
  )
  (if
   (i32.eqz
    (global.get $ready240)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string9)
   )
  )
  (local.set $0
   (call $foreign10)
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.get $0)
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (call $foreign2
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.get $0)
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (call $foreign2
     (local.get $0)
    )
    (local.set $0
     (i32.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (call $foreign4
   (local.get $0)
   (i32.const 120)
  )
 )
 (func $export8
  (local $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (if
   (i32.eqz
    (global.get $ready205)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global205)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string8)
   )
  )
  (local.set $0
   (call $foreign10)
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (call $foreign4
   (local.get $0)
   (i32.const 120)
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.get $0)
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $0)
        (i32.const -3)
       )
       (i32.eq
        (local.get $0)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (call $foreign2
     (local.get $0)
    )
   )
  )
 )
 (func $export9 (result i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready172)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global172)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string7)
   )
  )
  (i32.eq
   (call $foreign12)
   (i32.const 1)
  )
 )
 (func $export10
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready173)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global173)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string6)
   )
  )
  (call $foreign11)
 )
 (func $export11
  (local $0 (ref $type68))
  (local $1 (ref $type25))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready174)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global174)
   )
  )
  (if
   (i32.eqz
    (global.get $ready205)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global205)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string4)
   )
  )
  (local.set $1
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (call $foreign3
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $1)
    )
   )
  )
  (struct.set $type68 1
   (local.tee $0
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment371
     (global.get $string5)
     (local.get $1)
     (struct.new $type67
      (i64.const 8)
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type68 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function371
    (struct.get $type69 0
     (struct.get $type68 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (unreachable)
 )
 (func $export12
  (local $0 (ref $type68))
  (local $1 (ref $type25))
  (local $2 (ref $type25))
  (local $3 (ref $type26))
  (local $4 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready175)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string0)
   )
  )
  (local.set $1
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (call $function518
    (global.get $string1)
   )
  )
  (local.set $2
   (struct.new $type25
    (struct.new $type26
     (call $foreign10)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (call $foreign3
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $1)
    )
   )
  )
  (struct.set $type68 1
   (local.tee $0
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment371
     (global.get $string2)
     (local.get $1)
     (struct.new $type67
      (i64.const 5)
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type68 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function371
    (struct.get $type69 0
     (struct.get $type68 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (call $foreign3
   (struct.get $type26 0
    (struct.get $type25 0
     (local.get $2)
    )
   )
  )
  (struct.set $type68 1
   (local.tee $0
    (struct.new_default $type68)
   )
   (struct.new $type69
    (struct.new $environment371
     (global.get $string3)
     (local.get $2)
     (struct.new $type67
      (i64.const 6)
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type68 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function371
    (struct.get $type69 0
     (struct.get $type68 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $4
       (struct.get $type26 0
        (local.tee $3
         (struct.get $type25 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $4)
        (i32.const -3)
       )
       (i32.eq
        (local.get $4)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $3)
     (i32.const -1)
    )
    (call $foreign2
     (local.get $4)
    )
   )
  )
 )
 (func $export13
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (call $foreign0)
  (call $foreign1
   (i32.const 55296)
  )
 )
 (func $export14
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready177)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global177)
   )
  )
  (call $foreign2
   (i32.const -1)
  )
 )
 (func $export15
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (call $foreign0)
  (call $foreign1
   (i32.const 65)
  )
  (unreachable)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (drop
   (call $foreign15)
  )
  (drop
   (call $foreign16)
  )
  (global.set $global134
   (struct.new_default $type32)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type33)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type32)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type34)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type36)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type38)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global205
   (struct.new_default $type39)
  )
  (global.set $ready205
   (i32.const 1)
  )
  (global.set $global240
   (struct.new_default $type40)
  )
  (global.set $ready240
   (i32.const 1)
  )
  (global.set $global260
   (struct.new_default $type42)
  )
  (global.set $ready260
   (i32.const 1)
  )
  (global.set $global294
   (struct.new_default $type44)
  )
  (global.set $ready294
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type62)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global156
   (struct.new_default $type63)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $global157
   (struct.new_default $type36)
  )
  (global.set $ready157
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type65)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global162
   (struct.new_default $type65)
  )
  (global.set $ready162
   (i32.const 1)
  )
  (global.set $global163
   (struct.new_default $type66)
  )
  (global.set $ready163
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type5)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global165
   (struct.new_default $type7)
  )
  (global.set $ready165
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type8)
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global167
   (struct.new_default $type10)
  )
  (global.set $ready167
   (i32.const 1)
  )
  (global.set $global168
   (struct.new_default $type10)
  )
  (global.set $ready168
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type5)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global170
   (struct.new_default $type10)
  )
  (global.set $ready170
   (i32.const 1)
  )
  (global.set $global171
   (struct.new_default $type10)
  )
  (global.set $ready171
   (i32.const 1)
  )
  (global.set $global172
   (struct.new_default $type8)
  )
  (global.set $ready172
   (i32.const 1)
  )
  (global.set $global173
   (struct.new_default $type10)
  )
  (global.set $ready173
   (i32.const 1)
  )
  (global.set $global174
   (struct.new_default $type10)
  )
  (global.set $ready174
   (i32.const 1)
  )
  (global.set $global175
   (struct.new_default $type10)
  )
  (global.set $ready175
   (i32.const 1)
  )
  (global.set $global176
   (struct.new_default $type10)
  )
  (global.set $ready176
   (i32.const 1)
  )
  (global.set $global177
   (struct.new_default $type10)
  )
  (global.set $ready177
   (i32.const 1)
  )
  (global.set $global178
   (struct.new_default $type10)
  )
  (global.set $ready178
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

