(import (scheme base) (scheme file) (srfi 1) (wasm-native process) (sfir support))

(define freeze "/tmp/sfir-native-production-six-20261016/candidate")
(define cpu-path "/tmp/sfir-native-cpu-rootproof-evidence-20261016/paired-plan.json")
(define gc-path "/tmp/sfir-native-gc-hotpath-rootproof-20261016/artifacts.json")
(define cpu (read-json cpu-path))
(define gc (read-json gc-path))
(define cases '("fib" "fibfp" "mbrot" "array1" "bv2string" "gcbench"))
(define env "/nix/store/3qgy8q2j64v2m9jy3a5jmssacbblhd4r-coreutils-9.11/bin/env")

(define (verify-binary item hash-key)
  (let ((path (car (json-array (field item 'command)))))
    (unless (equal? (file-sha256 path) (field item hash-key))
      (error "probe binary changed" path))))

(define (cpu-arm item)
  (verify-binary item 'sha256)
  `((case . ,(field item 'case)) (name . ,(string-append "cpu-" (field item 'mode)))
    (source_route . "sfir-native") (command . ,(field item 'command))))

(define (gc-arm item budget?)
  (verify-binary item 'elf_sha256)
  `((case . "gcbench")
    (name . ,(string-append (field item 'name) (if budget? "-min256m" "")))
    (source_route . "sfir-native")
    (command . ,(list->vector
                 (append (if budget? (list env "SNAIL_GC_MIN_BYTES=268435456") '())
                         (json-array (field item 'command)))))))

(define (case-arms name)
  (append
   (map cpu-arm (filter (lambda (item) (equal? name (field item 'case)))
                       (json-array (field cpu 'native_pairs))))
   (if (equal? name "mbrot") (list (cpu-arm (field cpu 'mbrot_arrowlake_control))) '())
   (if (equal? name "gcbench")
       (append-map (lambda (item) (list (gc-arm item #f) (gc-arm item #t)))
                   (json-array (field gc 'arms))) '())
   (list `((case . ,name) (name . "v8") (source_route . "sfir-wasm")))))

(define metadata
  (list cpu-path gc-path
        "/tmp/sfir-native-cpu-rootproof-evidence-20261016/evidence-manifest.json"
        "/tmp/sfir-native-gc-hotpath-rootproof-20261016/artifact-hashes.json"
        "/tmp/sfir-native-gc-hotpath-20261016/review.json"))

(write-json
 "/tmp/snail-native-proof-evidence-20261016/build/cpu-gc-configuration.json"
 `((freeze . ,freeze) (cpu . 2)
   (quiet_window . "All task-owned build, correctness, profiling, archive and Git jobs are idle. Low-frequency host process-name snapshots retain observed activity without unrelated arguments. No external-session quiet attestation. One warmup and five rotated fresh-process samples on CPU 2, unchanged canonical inputs/counts/predicates, no retries. CPU and inline arms are uninstrumented production-linked executables. The explicitly named min256m arms alone set SNAIL_GC_MIN_BYTES=268435456 through the recorded env command; separate instrumented diagnostics retain memory/collection data. No GC stats or sampling instrumentation in timed arms.")
   (experimental_metadata . ,(list->vector (map (lambda (path) `((file . ,path) (sha256 . ,(file-sha256 path)))) metadata)))
   (arms . ,(list->vector (append-map case-arms cases)))))
