(import (scheme base) (scheme file) (srfi 1) (wasm-native process) (sfir support))

(define freeze "/tmp/sfir-native-production-six-20261016/candidate")
(define cpu-path "/tmp/snail-native-cpu-validation-20261016/mbrot-attempt-2/artifacts.json")
(define gc-path "/tmp/sfir-native-gc-hotpath-rootproof-20261016/artifacts.json")
(define callsite-path "/tmp/sfir-native-alloc-callsite-20261016/artifacts.json")
(define cpu (read-json cpu-path))
(define gc (read-json gc-path))
(define callsite (read-json callsite-path))

(define (native-arm name route path digest)
  (unless (equal? (file-sha256 path) digest) (error "prototype binary changed" path))
  `((case . ,name) (name . ,route) (source_route . "sfir-native") (command . ,(vector path))))

(define (cpu-arm mode)
  (let ((item (field (field cpu 'arms) mode)))
    (native-arm "mbrot" (string-append "product-cpu-" (symbol->string mode))
                (field item 'program) (field item 'sha256))))

(define (old-gc-arm item)
  (native-arm "gcbench" (field item 'name)
              (car (json-array (field item 'command))) (field item 'elf_sha256)))

(define (v8-arm name)
  `((case . ,name) (name . "v8") (source_route . "sfir-wasm")))

(define arms
  (append (map cpu-arm '(default v3)) (list (v8-arm "mbrot"))
          (map old-gc-arm (json-array (field gc 'arms)))
          (list (native-arm "gcbench" "callsite-inline" (field callsite 'candidate_elf)
                             (field callsite 'candidate_elf_sha256))
                (v8-arm "gcbench"))))

(write-json
 "/tmp/snail-native-proof-evidence-20261016/build/product-probes-configuration.json"
 `((freeze . ,freeze) (cpu . 2)
   (quiet_window . "All task-owned builds, tests, profiling, archive and Git jobs are idle for this window. Low-frequency host process-name snapshots retain observed activity without unrelated arguments; no external-session quiet attestation. One warmup and five rotated fresh-process samples on CPU 2, uninstrumented binaries, unchanged canonical inputs/counts/predicates, no replacement samples. Mandelbrot uses actual product CPU-option builds; GCbench compares the retained matched control and disputed-export prototype with the documented call-site successor. All GC budgets are default.")
   (experimental_metadata . ,(list->vector
                             (map (lambda (path) `((file . ,path) (sha256 . ,(file-sha256 path))))
                                  (list cpu-path gc-path callsite-path
                                        "/tmp/snail-native-cpu-validation-20261016/source.patch"
                                        "/tmp/snail-native-cpu-validation-20261016/paired-plan.json"))))
   (arms . ,(list->vector arms))))
