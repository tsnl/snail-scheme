(import (scheme base) (scheme file) (scheme write) (scheme process-context) (srfi 1) (srfi 95)
        (except (chibi filesystem) file-exists?)
        (only (chibi string) string-prefix? string-suffix?)
        (wasm-native process) (sfir support))

;; ---- Fixed evidence, with local originals left intact ----

(define root "/tmp/snail-native-cpu-gc-evidence-20261016")
(define preparation "/tmp/sfir-native-production-six-20261016/candidate")
(define coordinator "/tmp/snail-native-proof-evidence-20261016/build")
(define campaign "/tmp/sfir-native-product-probes-paired-20261016")
(define output (cadr (command-line)))
(define files '())
(define filtered '())
(define origins '())
(when (file-exists? output) (error "choose a new evidence directory" output))
(create-directory* output)

;; ---- Retain only the documented build and execution environment ----

(define environment-names
  '("PATH" "LANG" "LC_ALL" "TZ" "TMPDIR" "CHIBI_MODULE_PATH" "CHIBI_IGNORE_SYSTEM_PATH"
    "CC" "CXX" "AR" "AS" "LD" "NM" "RANLIB" "OBJCOPY" "OBJDUMP" "READELF" "STRIP"
    "RUSTC" "CARGO" "CARGO_HOME" "RUSTC_WRAPPER" "RUSTC_WORKSPACE_WRAPPER"
    "RUSTFLAGS" "CARGO_ENCODED_RUSTFLAGS" "CARGO_TARGET_DIR" "CARGO_BUILD_TARGET"
    "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS" "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER"
    "CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS" "CARGO_TARGET_WASM32_WASIP1_LINKER"
    "RUSTUP_HOME" "RUSTUP_TOOLCHAIN" "LD_LIBRARY_PATH" "LD_PRELOAD" "LIBRARY_PATH"
    "NIX_CC" "NIX_BINTOOLS" "NIX_LDFLAGS" "NIX_CFLAGS_COMPILE" "NIX_LD" "NIX_LD_LIBRARY_PATH"
    "NIX_ENFORCE_NO_NATIVE" "BINARYEN_CORES" "NODE_OPTIONS" "NODE_V8_COVERAGE" "SCHEMEHEAPDIRS"
    "SNAIL_NATIVE_SUPERVISOR" "SNAIL_NATIVE_LIBC" "SNAIL_NATIVE_GCC" "SNAIL_NATIVE_GC_INTERVAL"
    "SNAIL_GC_STATS" "SNAIL_GC_HEAP_BYTES" "SNAIL_GC_INITIAL_BYTES" "SNAIL_GC_MIN_BYTES"
    "SNAIL_NATIVE_CLEANUP_LOG" "SNAIL_NATIVE_TAIL_STRESS"
    "SNAIL_PROBE_MODE" "SNAIL_PROBE_CPU" "SNAIL_NATIVE_CPU"
    "CHIBI" "NODE" "CHEZ" "WASM_OPT" "WASM_AS" "WASM_DIS" "WASM_MERGE" "LLC" "LLVM_OPT"
    "TASKSET" "LDD" "GIT" "ENV" "REALPATH" "DATE" "TIMEOUT" "CP" "SHA256SUM"))

(define (environment-entry? entry)
  (member (symbol->string (car entry)) environment-names))

(define (filter-environment value)
  (cond ((vector? value) (list->vector (map filter-environment (vector->list value))))
        ((and (pair? value) (pair? (car value)) (symbol? (caar value)))
         (map (lambda (entry)
                (cons (car entry)
                      (if (and (memq (car entry) '(environment execution_environment))
                               (list? (cdr entry)))
                          (filter environment-entry? (cdr entry))
                          (filter-environment (cdr entry))))) value))
        (else value)))

(define (retain-json source destination relative)
  (let* ((original (read-json source)) (kept (filter-environment original)))
    (if (equal? original kept) (copy-file source destination)
        (begin (write-json destination kept)
               (set! filtered (cons `((file . ,relative) (original_sha256 . ,(file-sha256 source))) filtered))))))

(define (retain source relative)
  (unless (and (file-regular? source) (not (file-link? source)))
    (error "expected an ordinary evidence file" source))
  (let ((destination (path-join output relative)))
    (create-directory* (path-directory destination))
    ;; Interrupted build traces are intentionally incomplete JSON. Preserve the
    ;; phase-event bytes, including their missing terminators, without parsing.
    (if (and (string-suffix? ".json" source) (not (string-suffix? ".trace.json" source))
             (> (file-size source) 0))
        (retain-json source destination relative)
        (copy-file source destination))
    (chmod destination (file-mode source))
    (set! files (cons relative files))
    (set! origins (cons `((archive_path . ,relative) (source_path . ,source)) origins))))

;; ---- Exclude caches and repeated working-directory input copies ----

(define (excluded-directory? name)
  (member name '("." ".." ".git" "build" "target" "targets" "unit-target"
                "rust-target" "toolchain" "cargo-home" "runs" "node_modules"
                "workload" "__pycache__")))

(define (retain-tree source relative)
  (for-each
   (lambda (name)
     (let ((path (path-join source name)) (destination (path-join relative name)))
       (unless (or (and (file-directory? path) (excluded-directory? name)) (file-link? path)
                   (member destination '("cpu-validation/freeze-named/source" "cpu-validation/freeze-named/data"
                                         "cpu-validation/freeze-named-2/source" "cpu-validation/freeze-named-2/data")))
         (if (file-directory? path) (retain-tree path destination)
             (when (file-regular? path) (retain path destination))))))
   (sort (directory-files source) string<?)))

;; ---- The successor campaign and its independent preparation histories ----

(retain-tree "/tmp/sfir-native-alloc-callsite-20261016" "allocation-callsite")
(retain-tree "/tmp/snail-native-cpu-validation-20261016" "cpu-validation")
(for-each (lambda (name)
            (retain-tree (path-join "/tmp/snail-native-cpu-option-20261016/wasm-native/build" name)
                         (path-join "cpu-standalone" name)))
          '("standalone-2-0" "standalone-2-1"))
(retain-tree campaign "measurement")
(retain-tree (path-join coordinator "product-probes-run") "coordinator")
(for-each (lambda (name) (retain (path-join coordinator name) name))
          '("configure-product-probes.scm" "product-probes-configuration.json" "audit-product-probes.scm"))
(retain "/tmp/snail-native-shared-lto-evidence-20261016/build/observe-host.scm" "observe-host.scm")
(retain (path-join root "build/archive-product-probes.scm") "archive-product-probes.scm")
(retain (path-join root "build/append-product-probes.scm") "append-product-probes.scm")
(retain (path-join root "build/review-cpu-gc.scm") "review-cpu-gc.scm")
(retain (path-join root "build/independent-evidence-review.json") "independent-evidence-review.json")

(write-json (path-join output "environment-filtering.json")
 `((policy . "Only the explicit build/runtime environment allowlist in archive-product-probes.scm is published. Safe records retain original bytes; changed records retain original hashes below. Original local evidence is unchanged. Empty and interrupted setup JSON retains its original bytes. Caches, installed toolchains, repeated runs and duplicate CPU-freeze source/data copies are omitted; their identities remain in manifests. The original evidence.tar.gz retains the common frozen inputs and source.")
   (changed_records . ,(list->vector (reverse filtered)))))
(write-json (path-join output "archive-paths.json") (list->vector (reverse origins)))
(set! files (append '("environment-filtering.json" "archive-paths.json") files))
(write-text (path-join output "evidence-files.sha256")
            (run-command! (append '("sha256sum" "--") (sort files string<?)) `((directory . ,output))))
(display (length files)) (display " retained successor evidence files\n")

