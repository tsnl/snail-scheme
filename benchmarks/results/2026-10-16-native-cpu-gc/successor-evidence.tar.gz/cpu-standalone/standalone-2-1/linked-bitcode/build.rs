fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-option-20261016/wasm-native/build/standalone-2-1/module.bc");
}
