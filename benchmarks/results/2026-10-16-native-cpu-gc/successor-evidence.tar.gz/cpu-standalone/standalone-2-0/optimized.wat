(module
 (type $node (struct (field i64) (field (ref null $node))))
 (type $1 (func (param i64) (result i64)))
 (type $2 (func (result i64)))
 (type $3 (func))
 (import "example" "example_hide" (func $hide (param i64) (result i64)))
 (global $root (mut (ref null $node)) (ref.null none))
 (export "root" (global $root))
 (export "run" (func $0))
 (export "previous" (func $1))
 (export "take-root" (func $2))
 (export "trap" (func $3))
 (func $0 (param $0 i64) (result i64)
  (global.set $root
   (struct.new $node
    (i64.add
     (call $hide
      (local.get $0)
     )
     (i64.const 2)
    )
    (global.get $root)
   )
  )
  (struct.get $node 0
   (global.get $root)
  )
 )
 (func $1 (result i64)
  (struct.get $node 0
   (struct.get $node 1
    (global.get $root)
   )
  )
 )
 (func $2 (result i64)
  (local $0 (ref null $node))
  (local $scratch (ref null $node))
  (struct.get $node 0
   (block (result (ref null $node))
    (local.set $scratch
     (global.get $root)
    )
    (global.set $root
     (ref.null none)
    )
    (drop
     (call $hide
      (i64.const 0)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $3
  (unreachable)
 )
 ;; custom section "example.meta", size 19, contents: "opaque \"(; data ;)\""
)

