(import (scheme base) (scheme file) (scheme write) (srfi 1) (srfi 95)
        (wasm-native process) (sfir support))

;; ---- A separate campaign for the supported implementations ----

(define path "benchmarks/results/2026-10-16-native-cpu-gc/comparison.json")
(define summary (read-json path))
(define campaign "/tmp/sfir-native-product-probes-paired-20261016")
(define measurement (read-json (path-join campaign "measurement.json")))
(define plan (read-json (path-join campaign "plan.json")))
(define audit (read-json (path-join campaign "audit.json")))
(define rows (json-array (field measurement 'rows)))
(define attempts (json-array (field measurement 'attempts)))

(define (check fact detail) (unless fact (error "successor report audit" detail)))
(check (and (equal? (field audit 'status) "passed")
            (equal? (field audit 'measurement_sha256) (file-sha256 (path-join campaign "measurement.json")))
            (equal? (field audit 'plan_sha256) (file-sha256 (path-join campaign "plan.json")))) "audit binding")
(check (and (= 42 (length attempts)) (= 7 (length rows))
            (every (lambda (attempt) (equal? "passed" (field attempt 'status))) attempts)) "complete inventory")

(define (verify-row row)
  (let* ((samples (filter (lambda (attempt)
                           (and (equal? (field row 'case) (field attempt 'case))
                                (equal? (field row 'route) (field attempt 'route))
                                (equal? "sample" (field attempt 'phase)))) attempts))
         (seconds (map (lambda (attempt) (field attempt 'seconds)) samples))
         (ordered (sort seconds <)))
    (check (and (= 5 (length seconds)) (equal? seconds (json-array (field row 'seconds)))
                (= (list-ref ordered 2) (field row 'median))
                (= (car ordered) (field row 'minimum)) (= (last ordered) (field row 'maximum))) "statistics")))
(for-each verify-row rows)

(define (median name route)
  (field (find (lambda (row) (and (equal? name (field row 'case)) (equal? route (field row 'route)))) rows) 'median))
(define (comparison name control treatment)
  (let ((baseline (median name control)) (candidate (median name treatment)) (v8 (median name "v8")))
    `((case . ,name) (control . ,control) (treatment . ,treatment)
      (less_native_time_percent . ,(* 100 (- 1 (/ candidate baseline))))
      (native_over_v8 . ,(/ candidate v8)))))
(define comparisons
  (list (comparison "mbrot" "product-cpu-default" "product-cpu-v3")
        (comparison "gcbench" "runtime-inline-control" "callsite-inline")
        (comparison "gcbench" "runtime-inline-candidate" "callsite-inline")))

(define (executed-arm row)
  `((case . ,(field row 'case)) (route . ,(field row 'route))
    (command . ,(field row 'command)) (arm_dependencies . ,(field row 'arm_dependencies))))

(define successor
  `((status . ,(field measurement 'status)) (gc_budget . "default in every route")
    (protocol . ,(field plan 'protocol)) (quiet_window . ,(field plan 'quiet_window))
    (host_snapshots . 34) (external_session_quiet_attestation . #f) (audit . ,audit)
    (host_review . "Independently counted 34 timestamped process-name snapshots; no named compiler or profiler match. Percent CPU is a process-lifetime average; ambient desktop activity remains and there is no external-session quiet attestation.")
    (cpu_artifacts . ,(read-json "/tmp/snail-native-cpu-validation-20261016/mbrot-attempt-2/artifacts.json"))
    (cpu_validation . ,(read-json "/tmp/snail-native-cpu-validation-20261016/validation-final.json"))
    (callsite_artifacts . ,(read-json "/tmp/sfir-native-alloc-callsite-20261016/artifacts.json"))
    (executed_arms . ,(list->vector (map executed-arm (json-array (field plan 'rows)))))
    (comparisons . ,(list->vector comparisons))
    (rows . ,(field measurement 'rows)) (attempts . ,(field measurement 'attempts))))

;; ---- Preserve every original attempt and append the successor campaign ----

(define original (read-json "/tmp/sfir-native-cpu-gc-paired-20261016/measurement.json"))
(check (and (equal? (field summary 'rows) (field original 'rows))
            (equal? (field summary 'attempts) (field original 'attempts))) "original 138 attempts unchanged")
(write-json path (append (filter (lambda (entry) (not (eq? (car entry) 'successor_campaign))) summary)
                         (list (cons 'successor_campaign successor))))
(write comparisons) (newline)
