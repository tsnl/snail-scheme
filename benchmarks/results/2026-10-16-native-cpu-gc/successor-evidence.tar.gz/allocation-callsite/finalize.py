#!/usr/bin/env python3
"""Freeze the successful diagnostic ELF and record bounded proof/check scope."""
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path('/tmp/sfir-native-alloc-callsite-20261016')
SOURCE = Path('/tmp/snail-native-alloc-callsite-20261016')
CASE = Path('/tmp/sfir-native-production-six-20261016/candidate/timing/artifacts/gcbench')
PRIOR = Path('/tmp/sfir-native-gc-hotpath-rootproof-20261016')
BUILD = ROOT / 'candidate/program.native.native-4-2'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def functions(path):
    pattern = r'^\s*[0-9a-f]+ <([^>]+)>:\n(.*?)(?=^\s*[0-9a-f]+ <|\Z)'
    return {m.group(1): m.group(2) for m in re.finditer(pattern, path.read_text(), re.M | re.S)}


def normalized(body):
    rows = []
    for line in body.splitlines():
        match = re.match(r'\s*[0-9a-f]+:\s*(.*)', line)
        if not match:
            continue
        op = match.group(1)
        if op.startswith(('nop', 'int3', 'data16', 'cs nop', 'xchg   %ax,%ax')):
            continue
        op = re.sub(r'\b[0-9a-f]+ <([^>]+)>', r'<\1>', op)
        rows.append(re.sub(r'-?0x[0-9a-f]+\(%rip\)', 'RIP', op))
    return rows


def fixed_headers(body):
    values = re.findall(r'movq?\s+\$0x([0-9a-f]+),\(%r[a-z0-9]+\)', body)
    return dict(Counter(value for value in values if int(value, 16) in (0x21, 0x41, 0x61, 0x81, 0xa1)))


evidence = ROOT / 'evidence'
evidence.mkdir(exist_ok=True)
documented = functions(ROOT / 'attempts/elf-code/stdout.bin')
prior = functions(ROOT / 'attempts/original-two-hint-elf-code/stdout.bin')
guest = sorted(name for name in documented if re.fullmatch(r'f\.\d+', name))
comparison = []
for name in guest:
    old, new = normalized(prior[name]), normalized(documented[name])
    (evidence / (name + '.asm')).write_text(documented[name])
    (evidence / (name + '.normalized.diff')).write_text('\n'.join(
        difflib.unified_diff(old, new, fromfile='two-hint', tofile='documented')) + '\n')
    comparison.append({
        'function': name, 'same_instructions_modulo_addresses_and_padding': old == new,
        'instructions_two_hint': len(old), 'instructions_documented': len(new),
        'fixed_header_writes_two_hint': fixed_headers(prior[name]),
        'fixed_header_writes_documented': fixed_headers(documented[name]),
        'native_alloc_calls': len(re.findall(r'\b(?:call|jmp)\s+[^\n]*<native_alloc>', documented[name])),
        'collector_calls': documented[name].count('Collector::collect>'),
        'slow_allocation_calls': documented[name].count('Collector::allocate_slow>')})
(evidence / 'guest-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')

frozen = ROOT / 'frozen'
frozen.mkdir(exist_ok=True)
if (frozen / 'program.native').exists():
    assert sha(frozen / 'program.native') == sha(ROOT / 'candidate/program.native')
else:
    shutil.copy2(ROOT / 'candidate/program.native', frozen / 'program.native')
(frozen / 'program.native').chmod(0o555)
if (ROOT / 'candidate-source').exists():
    shutil.move(ROOT / 'candidate.patch', ROOT / 'failed-name-dispatch.patch')
    shutil.move(ROOT / 'candidate-source', ROOT / 'failed-name-dispatch-source')
patch = subprocess.run(['git', 'diff', '--binary'], cwd=SOURCE, check=True, capture_output=True).stdout
(ROOT / 'candidate.patch').write_bytes(patch)
snapshot = ROOT / 'source-snapshot'
snapshot.mkdir(exist_ok=True)
for name in ('wasm-native/scheme/wasm-native/llvm.sld', 'wasm-native/src/native.rs', 'wasm-native/src/native_gc.rs'):
    target = snapshot / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SOURCE / name, target)
native_original = subprocess.run(['git', 'show', 'HEAD:wasm-native/src/native.rs'], cwd=SOURCE,
                                 check=True, capture_output=True).stdout
llvm = (BUILD / 'module.ll').read_text()
prior_llvm = (PRIOR / 'candidate/program.native.native-4-0/module.ll').read_text()
allocation_calls = [line for line in llvm.splitlines() if re.search(r'\bcall i64 @native_alloc\(', line)]
build = json.loads((BUILD / 'build.json').read_text())
attempts = []
for path in sorted((ROOT / 'attempts').glob('*/capture.json')):
    capture = json.loads(path.read_text())
    attempts.append({'name': path.parent.name, 'record': str(path), 'sha256': sha(path),
                     'returncode': capture['supervisor_returncode'], 'process': capture.get('process'),
                     'sources_stable': capture['source_before_sha256'] == capture['source_after_sha256']})
unit = (ROOT / 'attempts/unit-tests/stdout.bin').read_text()
validation = (ROOT / 'attempts/validate-candidate/stdout.bin').read_text()
result_line = [line for line in validation.splitlines() if line.startswith('{')][-1]
manifest = {
    'kind': 'documented-native-allocation-callsite-probe',
    'base': json.loads((ROOT / 'setup.json').read_text())['base'],
    'worktree': str(SOURCE), 'branch': 'probe/native-alloc-callsite-20261016',
    'source_patch': str(ROOT / 'candidate.patch'), 'source_snapshot': str(snapshot),
    'candidate_elf': str(frozen / 'program.native'), 'candidate_elf_sha256': sha(frozen / 'program.native'),
    'original_build_elf': str(ROOT / 'candidate/program.native'),
    'original_build_elf_sha256': sha(ROOT / 'candidate/program.native'),
    'successful_build_directory': str(BUILD),
    'successful_build_record': str(ROOT / 'attempts/build-candidate-offline-vendor/capture.json'),
    'canonical_validation_record': str(ROOT / 'attempts/validate-candidate/capture.json'),
    'canonical_validation': json.loads(result_line),
    'clean_timing_claim': False,
    'timing_scope': 'All runs here are uncontrolled diagnostics; parent coordinates clean measurements.',
    'native_export_source_unchanged': native_original == (SOURCE / 'wasm-native/src/native.rs').read_bytes(),
    'lowered_llvm_unchanged_except_allocation_callsite_hint': llvm.replace(' alwaysinline', '') == prior_llvm,
    'all_guest_native_alloc_calls_hinted': all(line.endswith(' alwaysinline') for line in allocation_calls),
    'guest_native_alloc_callsite_count': len(allocation_calls),
    'optimized_wasm': str(BUILD / 'optimized.wasm'),
    'optimized_wasm_sha256': sha(BUILD / 'optimized.wasm'),
    'same_optimized_wasm_as_frozen_v8': sha(BUILD / 'optimized.wasm') == sha(CASE / 'program.wasm'),
    'same_optimized_wasm_as_two_hint_candidate': sha(BUILD / 'optimized.wasm') == sha(PRIOR / 'candidate/program.native.native-4-0/optimized.wasm'),
    'mandatory_binaryen_stage': json.loads((BUILD / 'native.trace.json').read_text()),
    'build_commands_reaped': all(command.get('descendants_gone') for command in build['commands']),
    'production_build_stderr_bytes': (ROOT / 'attempts/build-candidate-offline-vendor/stderr.bin').stat().st_size,
    'unit_test_results': re.findall(r'test result:.*', unit),
    'forced_gc_dynamic_array_and_root_record': str(ROOT / 'attempts/semantics-forced-gc/capture.json'),
    'small_fixture_scope': 'Existing native-runner checks scalar/packed/reference arrays at runtime lengths 0, 2 and 3, nonzero then zero-filled reuse, operand roots, subtype/identity/cyclic roots and tail calls, with SNAIL_NATIVE_GC_INTERVAL=1.',
    'machine_code_comparison': str(evidence / 'guest-comparison.json'),
    'same_normalized_guest_functions': [row['function'] for row in comparison if row['same_instructions_modulo_addresses_and_padding']],
    'machine_code_differences': {'f.12': 'Four anonymous formatting-data target addresses only; full normalized diff retained.', 'f.8': 'Dynamic-size native_array_new path now retains a native_alloc call; fixed struct allocations remain inline. Stack layout changes around that outlined call.'},
    'all_guest_fixed_header_write_counts_match_two_hint_candidate': all(row['fixed_header_writes_two_hint'] == row['fixed_header_writes_documented'] for row in comparison),
    'fixed_header_match_rule': 'Raw-base immediate stores restricted to the five header words for emitted struct sizes 8/16/24/32/40. This is a static code-shape check, not a dynamic allocation counter.',
    'zeroing_proof': 'Fixed-size zero fills remain present as constant vector/scalar stores, matching the two-hint candidate. This probe does not claim dead-zero-store elimination.',
    'slow_collector_outlined': any('Collector::collect' in name for name in documented),
    'arbitrary_size_abi_retained': 'native_alloc symbol remains, including bounds/failure handling and variable-size zeroing; native_array_new remains an unchanged caller.',
    'failure_history': [
        {'attempt': 'build-candidate', 'reason': 'String-only name dispatch encountered a structured quoted foreign symbol; changed the hint selector to equal?. Initial source/patch retained.'},
        {'attempt': 'build-candidate-structured-name', 'reason': 'Fresh isolated Cargo home lacked the frozen offline vendor config. Copied that exact config; no network or dependency change.'}],
    'process_audit': attempts,
    'all_attempt_descendants_reaped': all(row['process'] and row['process'].get('descendants_gone') and not row['process'].get('timed_out') and not row['process'].get('unexpected_descendants') and not row['process'].get('executing_descendants') for row in attempts),
    'active_task_owned_build_or_native_processes': 0,
    'pending': 'Parent-owned Astra polish and full validation; no additional runtime experiments or clean timing requested in this task.',
    'publication': 'No commit, PR, merge, publish, root-worktree change or CPU product change.'}
(ROOT / 'artifacts.json').write_text(json.dumps(manifest, indent=2) + '\n')
hashes = {str(path.relative_to(ROOT)): sha(path) for path in ROOT.rglob('*') if path.is_file() and path.name != 'artifact-hashes.json' and
          not any(part in ('unit-target', 'cargo-home') for part in path.relative_to(ROOT).parts)}
(ROOT / 'artifact-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in (
    'candidate_elf', 'candidate_elf_sha256', 'native_export_source_unchanged',
    'lowered_llvm_unchanged_except_allocation_callsite_hint',
    'guest_native_alloc_callsite_count', 'all_guest_native_alloc_calls_hinted',
    'same_optimized_wasm_as_frozen_v8', 'same_normalized_guest_functions',
    'all_guest_fixed_header_write_counts_match_two_hint_candidate',
    'production_build_stderr_bytes', 'unit_test_results', 'all_attempt_descendants_reaped')}))
