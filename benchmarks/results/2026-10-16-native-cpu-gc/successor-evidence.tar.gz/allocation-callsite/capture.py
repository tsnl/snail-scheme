#!/usr/bin/env python3
"""Retain each supervised diagnostic command, its inputs, and subtree reaping."""
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path('/tmp/sfir-native-alloc-callsite-20261016')
SOURCE = Path('/tmp/snail-native-alloc-callsite-20261016')
FROZEN = Path('/tmp/sfir-native-production-six-20261016/candidate')
CASE = FROZEN / 'timing/artifacts/gcbench'
SUPERVISOR = FROZEN / 'toolchain/snail-native-supervisor'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


record = json.loads((CASE / 'commands/native-build/record.json').read_text())
environment = os.environ.copy()
for key, value in record['environment'].items():
    if value is None:
        environment.pop(key, None)
    else:
        environment[key] = value
environment['RUSTC_WRAPPER'] = str(SOURCE / 'wasm-native/scripts/rustc-native')
environment['CARGO_HOME'] = str(ROOT / 'cargo-home')
name, command = sys.argv[1], sys.argv[2:]
attempt = ROOT / 'attempts' / name
attempt.mkdir(parents=True, exist_ok=False)
working_directory = attempt
if command[:1] == ['--cwd']:
    working_directory, command = Path(command[1]), command[2:]
environment['SNAIL_PROCESS_RECORD'] = str(attempt / 'process.json')
wrapped = [str(SUPERVISOR), '--command', '1800000', '--', *command]
sources = [SOURCE / path for path in (
    'wasm-native/src/native.rs', 'wasm-native/src/native_gc.rs',
    'wasm-native/scheme/wasm-native/llvm.sld')]
before = {str(path): sha(path) for path in sources}
dependencies = {part: sha(Path(part)) for part in command
                if part.startswith('/') and Path(part).is_file()}
started = time.monotonic()
with (CASE / 'input.txt').open('rb') as inp, (attempt / 'stdout.bin').open('wb') as out, (attempt / 'stderr.bin').open('wb') as err:
    process = subprocess.run(wrapped, env=environment, cwd=working_directory,
                             stdin=inp, stdout=out, stderr=err)
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
result = {
    'command': command, 'supervisor_command': wrapped, 'cwd': str(working_directory),
    'supervisor_returncode': process.returncode,
    'wall_seconds': time.monotonic() - started, 'environment': environment,
    'command_dependencies_sha256': dependencies,
    'source_before_sha256': before,
    'source_after_sha256': {str(path): sha(path) for path in sources},
    'resource_usage': {key: getattr(usage, key) for key in (
        'ru_maxrss', 'ru_utime', 'ru_stime', 'ru_minflt', 'ru_majflt',
        'ru_nvcsw', 'ru_nivcsw')},
    'diagnostic_only': True,
    'timing_eligibility': 'Uncontrolled diagnostic; no clean timing claim.'}
for stream in ('stdout', 'stderr'):
    path = attempt / (stream + '.bin')
    result[stream + '_sha256'] = sha(path)
    result[stream] = path.read_bytes().decode('utf-8', errors='replace')
if (attempt / 'process.json').exists():
    result['process'] = json.loads((attempt / 'process.json').read_text())
(attempt / 'capture.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'attempt': name, 'returncode': process.returncode,
    'wall_seconds': result['wall_seconds'], 'process': result.get('process'),
    'stdout_bytes': (attempt / 'stdout.bin').stat().st_size,
    'stderr_bytes': (attempt / 'stderr.bin').stat().st_size}))
sys.exit(process.returncode)
