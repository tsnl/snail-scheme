; ModuleID = '/tmp/sfir-native-alloc-callsite-20261016/micro/guest.ll'
source_filename = "/tmp/sfir-native-alloc-callsite-20261016/micro/guest.ll"

declare i64 @allocate_bytes(i64) local_unnamed_addr

define i64 @hinted() local_unnamed_addr {
  %result = tail call i64 @allocate_bytes(i64 24) #0
  ret i64 %result
}

define i64 @ordinary() local_unnamed_addr {
  %result = tail call i64 @allocate_bytes(i64 24)
  ret i64 %result
}

attributes #0 = { alwaysinline }
