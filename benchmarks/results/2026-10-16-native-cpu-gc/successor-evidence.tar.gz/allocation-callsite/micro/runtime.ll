declare i64 @slow_allocation(i64)

define i64 @allocate_bytes(i64 %bytes) {
  %result = call i64 @slow_allocation(i64 %bytes)
  ret i64 %result
}
