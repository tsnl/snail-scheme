; ModuleID = '/tmp/sfir-native-alloc-callsite-20261016/micro/linked.bc'
source_filename = "llvm-link"

define i64 @hinted() local_unnamed_addr {
  %result.i = call i64 @slow_allocation(i64 24)
  ret i64 %result.i
}

define i64 @ordinary() local_unnamed_addr {
  %result = tail call i64 @allocate_bytes(i64 24)
  ret i64 %result
}

define i64 @allocate_bytes(i64 %bytes) {
  %result = call i64 @slow_allocation(i64 %bytes)
  ret i64 %result
}

declare i64 @slow_allocation(i64)
