declare i64 @allocate_bytes(i64)

define i64 @hinted() {
  %result = call i64 @allocate_bytes(i64 24) alwaysinline
  ret i64 %result
}

define i64 @ordinary() {
  %result = call i64 @allocate_bytes(i64 24)
  ret i64 %result
}
