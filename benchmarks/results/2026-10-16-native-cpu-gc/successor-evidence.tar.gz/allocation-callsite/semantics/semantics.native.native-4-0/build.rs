fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-alloc-callsite-20261016/semantics/semantics.native.native-4-0/module.bc");
}
