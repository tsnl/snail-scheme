   64360:	push   %rax
   64361:	test   %rsi,%rsi
   64364:	je     643ba <f.19+0x5a>
   64366:	test   %rdi,%rdi
   64369:	je     643cc <f.19+0x6c>
   6436b:	mov    0x8(%rdi),%rax
   6436f:	test   %rax,%rax
   64372:	je     643cc <f.19+0x6c>
   64374:	cmpl   $0x0,0x8(%rax)
   64378:	je     643cc <f.19+0x6c>
   6437a:	cmpq   $0x0,0x10(%rax)
   6437f:	je     643cc <f.19+0x6c>
   64381:	mov    %rsi,%rax
   64384:	and    $0x7,%rax
   64388:	je     643c1 <f.19+0x61>
   6438a:	xor    %ecx,%ecx
   6438c:	nopl   0x0(%rax)
   64390:	add    %rdx,%rdx
   64393:	inc    %rcx
   64396:	cmp    %rcx,%rax
   64399:	jne    64390 <f.19+0x30>
   6439b:	mov    %rsi,%rax
   6439e:	sub    %rcx,%rax
   643a1:	cmp    $0x8,%rsi
   643a5:	jb     643ba <f.19+0x5a>
   643a7:	nopw   0x0(%rax,%rax,1)
   643b0:	shl    $0x8,%rdx
   643b4:	add    $0xfffffffffffffff8,%rax
   643b8:	jne    643b0 <f.19+0x50>
   643ba:	mov    %rdx,%rax
   643bd:	pop    %rcx
   643be:	ret    $0x8
   643c1:	mov    %rsi,%rax
   643c4:	cmp    $0x8,%rsi
   643c8:	jae    643b0 <f.19+0x50>
   643ca:	jmp    643ba <f.19+0x5a>
   643cc:	call   56d70 <native_trap>
   643d1:	int3
   643d2:	int3
   643d3:	int3
   643d4:	int3
   643d5:	int3
   643d6:	int3
   643d7:	int3
   643d8:	int3
   643d9:	int3
   643da:	int3
   643db:	int3
   643dc:	int3
   643dd:	int3
   643de:	int3
   643df:	int3
