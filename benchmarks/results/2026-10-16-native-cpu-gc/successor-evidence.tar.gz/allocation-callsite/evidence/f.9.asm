   65660:	mov    %rdx,%rax
   65663:	cmp    %rdx,%rsi
   65666:	cmovl  %rsi,%rax
   6566a:	ret    $0x8

Disassembly of section .init:
