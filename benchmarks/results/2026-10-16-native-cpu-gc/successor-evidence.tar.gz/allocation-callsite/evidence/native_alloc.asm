   582b0:	push   %rbp
   582b1:	push   %r15
   582b3:	push   %r14
   582b5:	push   %r13
   582b7:	push   %r12
   582b9:	push   %rbx
   582ba:	sub    $0x18,%rsp
   582be:	mov    0x12553(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   582c5:	test   %rbx,%rbx
   582c8:	je     584ba <native_alloc+0x20a>
   582ce:	mov    %rdi,%r14
   582d1:	mov    0x178(%rbx),%rcx
   582d8:	test   %rcx,%rcx
   582db:	je     58317 <native_alloc+0x67>
   582dd:	mov    0x170(%rbx),%rax
   582e4:	inc    %rax
   582e7:	mov    %rax,0x170(%rbx)
   582ee:	mov    %rax,%rdx
   582f1:	or     %rcx,%rdx
   582f4:	shr    $0x20,%rdx
   582f8:	je     58497 <native_alloc+0x1e7>
   582fe:	xor    %edx,%edx
   58300:	div    %rcx
   58303:	test   %rdx,%rdx
   58306:	jne    58317 <native_alloc+0x67>
   58308:	mov    0x12511(%rip),%rsi        # 6a820 <native_roots.0>
   5830f:	mov    %rbx,%rdi
   58312:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   58317:	lea    0x17(%r14),%rax
   5831b:	movabs $0x1ffffffff0,%r15
   58325:	and    %rax,%r15
   58328:	cmp    0x98(%rbx),%r15
   5832f:	ja     584a9 <native_alloc+0x1f9>
   58335:	mov    0x124e4(%rip),%r12        # 6a820 <native_roots.0>
   5833c:	mov    0xe0(%rbx),%rbp
   58343:	mov    0xe8(%rbx),%r13
   5834a:	cmp    %r13,%rbp
   5834d:	jb     5835a <native_alloc+0xaa>
   5834f:	mov    %rbx,%rdi
   58352:	mov    %r12,%rsi
   58355:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5835a:	mov    %r12,(%rsp)
   5835e:	mov    0xc8(%rbx),%r12
   58365:	test   %r12,%r12
   58368:	je     58379 <native_alloc+0xc9>
   5836a:	mov    0xd0(%rbx),%rax
   58371:	sub    %r12,%rax
   58374:	cmp    %r15,%rax
   58377:	jae    5839b <native_alloc+0xeb>
   58379:	mov    %rbx,%rdi
   5837c:	mov    %r15,%rsi
   5837f:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   58384:	mov    %rdx,%r12
   58387:	cmp    $0x1,%rax
   5838b:	jne    58416 <native_alloc+0x166>
   58391:	mov    $0x1,%eax
   58396:	jmp    58430 <native_alloc+0x180>
   5839b:	lea    (%r12,%r15,1),%rax
   5839f:	mov    %rax,0xc8(%rbx)
   583a6:	mov    0x10(%rbx),%rsi
   583aa:	mov    0xc0(%rbx),%rdi
   583b1:	cmp    %rsi,%rdi
   583b4:	jae    584bf <native_alloc+0x20f>
   583ba:	mov    0x8(%rbx),%rax
   583be:	imul   $0x38,%rdi,%rcx
   583c2:	mov    %r12,%rdx
   583c5:	sub    0x18(%rax,%rcx,1),%rdx
   583ca:	mov    %rdx,%rdi
   583cd:	shr    $0xf,%rdi
   583d1:	mov    0x10(%rax,%rcx,1),%rsi
   583d6:	cmp    %rsi,%rdi
   583d9:	jae    584cb <native_alloc+0x21b>
   583df:	add    %rcx,%rax
   583e2:	mov    %edx,%ecx
   583e4:	imul   $0x220,%rdi,%rsi
   583eb:	add    0x8(%rax),%rsi
   583ef:	shr    $0x4,%ecx
   583f2:	mov    $0x1,%eax
   583f7:	mov    $0x1,%edi
   583fc:	shl    %cl,%rdi
   583ff:	shr    $0x7,%edx
   58402:	and    $0xf8,%edx
   58408:	or     %rdi,(%rdx,%rsi,1)
   5840c:	cmp    $0x1,%rax
   58410:	je     58391 <native_alloc+0xe1>
   58416:	xor    %edx,%edx
   58418:	cmp    %r13,%rbp
   5841b:	setae  %dl
   5841e:	mov    %rbx,%rdi
   58421:	mov    %r15,%rsi
   58424:	mov    (%rsp),%rcx
   58428:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5842d:	mov    %rdx,%r12
   58430:	test   $0x1,%al
   58432:	je     584a9 <native_alloc+0x1f9>
   58434:	movq   %r14,%xmm0
   58439:	movdqa %xmm0,(%rsp)
   5843e:	lea    0x1(,%r14,4),%rax
   58446:	mov    %rax,(%r12)
   5844a:	add    $0x8,%r12
   5844e:	mov    %r12,%rdi
   58451:	xor    %esi,%esi
   58453:	mov    %r14,%rdx
   58456:	call   *0x109b4(%rip)        # 68e10 <memset@GLIBC_2.2.5>
   5845c:	add    %r15,0xe0(%rbx)
   58463:	movapd (%rsp),%xmm1
   58468:	shufpd $0x2,-0x540c1(%rip),%xmm1        # 43b0 <__abi_tag+0x407c>
   58471:	movdqu 0x110(%rbx),%xmm0
   58479:	paddq  %xmm0,%xmm1
   5847d:	movdqu %xmm1,0x110(%rbx)
   58485:	mov    %r12,%rax
   58488:	add    $0x18,%rsp
   5848c:	pop    %rbx
   5848d:	pop    %r12
   5848f:	pop    %r13
   58491:	pop    %r14
   58493:	pop    %r15
   58495:	pop    %rbp
   58496:	ret
   58497:	xor    %edx,%edx
   58499:	div    %ecx
   5849b:	test   %rdx,%rdx
   5849e:	jne    58317 <native_alloc+0x67>
   584a4:	jmp    58308 <native_alloc+0x58>
   584a9:	lea    -0x4f05c(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   584b0:	mov    $0x2f,%esi
   584b5:	call   57d70 <snail_runtime::native::fail_bytes>
   584ba:	call   56d70 <native_trap>
   584bf:	lea    0xf0fa(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   584c6:	call   207b0 <core::panicking::panic_bounds_check>
   584cb:	lea    0xf106(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   584d2:	call   207b0 <core::panicking::panic_bounds_check>
   584d7:	int3
   584d8:	int3
   584d9:	int3
   584da:	int3
   584db:	int3
   584dc:	int3
   584dd:	int3
   584de:	int3
   584df:	int3
