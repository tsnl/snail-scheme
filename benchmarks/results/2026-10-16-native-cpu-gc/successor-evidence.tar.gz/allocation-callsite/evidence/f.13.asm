   62d20:	push   %r15
   62d22:	push   %r14
   62d24:	push   %r12
   62d26:	push   %rbx
   62d27:	sub    $0x38,%rsp
   62d2b:	mov    %rsi,%rbx
   62d2e:	movq   $0x3,0x10(%rsp)
   62d37:	movq   $0x0,0x18(%rsp)
   62d40:	mov    0x7ad9(%rip),%rdx        # 6a820 <native_roots.0>
   62d47:	mov    %rdx,0x8(%rsp)
   62d4c:	lea    0x8(%rsp),%r14
   62d51:	mov    %r14,0x7ac8(%rip)        # 6a820 <native_roots.0>
   62d58:	mov    0x7aa1(%rip),%rcx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   62d5f:	lea    0x1(%rcx),%rax
   62d63:	mov    %rax,0x7a96(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   62d6a:	mov    0x7a97(%rip),%rsi        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   62d71:	cmp    %rsi,%rax
   62d74:	cmova  %rax,%rsi
   62d78:	mov    %rsi,0x7a89(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   62d7f:	mov    %rdi,0x20(%rsp)
   62d84:	movq   $0x0,0x28(%rsp)
   62d8d:	test   %rdi,%rdi
   62d90:	je     63074 <f.13+0x354>
   62d96:	mov    %edi,%eax
   62d98:	and    $0x1,%eax
   62d9b:	jne    63074 <f.13+0x354>
   62da1:	mov    0x7a70(%rip),%rsi        # 6a818 <snail_runtime::native::RUNTIME>
   62da8:	test   %rsi,%rsi
   62dab:	je     63074 <f.13+0x354>
   62db1:	mov    (%rdi),%rax
   62db4:	mov    %rax,%r8
   62db7:	test   %rax,%rax
   62dba:	je     62e21 <f.13+0x101>
   62dbc:	mov    %rax,%r8
   62dbf:	cmp    $0x16,%rax
   62dc3:	je     62e21 <f.13+0x101>
   62dc5:	mov    0x168(%rsi),%r9
   62dcc:	mov    %rax,%r8
   62dcf:	shr    $0x2,%r8
   62dd3:	lea    -0x1(%r8),%r10
   62dd7:	cmp    %r9,%r10
   62dda:	jae    63074 <f.13+0x354>
   62de0:	mov    0x160(%rsi),%r10
   62de7:	mov    -0x8(%r10,%r8,8),%r8
   62dec:	test   %r8,%r8
   62def:	je     62e21 <f.13+0x101>
   62df1:	cmp    $0x16,%r8
   62df5:	je     62e21 <f.13+0x101>
   62df7:	nopw   0x0(%rax,%rax,1)
   62e00:	shr    $0x2,%r8
   62e04:	lea    -0x1(%r8),%r11
   62e08:	cmp    %r9,%r11
   62e0b:	jae    63074 <f.13+0x354>
   62e11:	mov    -0x8(%r10,%r8,8),%r8
   62e16:	cmp    $0x16,%r8
   62e1a:	je     62e21 <f.13+0x101>
   62e1c:	test   %r8,%r8
   62e1f:	jne    62e00 <f.13+0xe0>
   62e21:	cmp    $0x16,%r8
   62e25:	jne    63074 <f.13+0x354>
   62e2b:	lea    0x79ee(%rip),%r15        # 6a820 <native_roots.0>
   62e32:	jmp    62e50 <f.13+0x130>
   62e34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   62e40:	inc    %rbx
   62e43:	sub    %r8,%rcx
   62e46:	cmp    $0x16,%r9
   62e4a:	jne    63074 <f.13+0x354>
   62e50:	cmp    %rbx,0x18(%rdi)
   62e54:	jle    63056 <f.13+0x336>
   62e5a:	test   $0x1,%dil
   62e5e:	jne    63074 <f.13+0x354>
   62e64:	test   %rax,%rax
   62e67:	je     62ed0 <f.13+0x1b0>
   62e69:	cmp    $0x16,%rax
   62e6d:	je     62ed0 <f.13+0x1b0>
   62e6f:	mov    0x168(%rsi),%rcx
   62e76:	shr    $0x2,%rax
   62e7a:	lea    -0x1(%rax),%rdx
   62e7e:	cmp    %rcx,%rdx
   62e81:	jae    63074 <f.13+0x354>
   62e87:	mov    0x160(%rsi),%rdx
   62e8e:	mov    -0x8(%rdx,%rax,8),%rax
   62e93:	test   %rax,%rax
   62e96:	je     62ed0 <f.13+0x1b0>
   62e98:	cmp    $0x16,%rax
   62e9c:	je     62ed0 <f.13+0x1b0>
   62e9e:	xchg   %ax,%ax
   62ea0:	shr    $0x2,%rax
   62ea4:	lea    -0x1(%rax),%rsi
   62ea8:	cmp    %rcx,%rsi
   62eab:	jae    63074 <f.13+0x354>
   62eb1:	mov    -0x8(%rdx,%rax,8),%rax
   62eb6:	cmp    $0x16,%rax
   62eba:	je     62ed0 <f.13+0x1b0>
   62ebc:	test   %rax,%rax
   62ebf:	jne    62ea0 <f.13+0x180>
   62ec1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   62ed0:	cmp    $0x16,%rax
   62ed4:	jne    63074 <f.13+0x354>
   62eda:	mov    %rdi,0x28(%rsp)
   62edf:	mov    0x8(%rdi),%rax
   62ee3:	test   %rax,%rax
   62ee6:	je     63074 <f.13+0x354>
   62eec:	cmpl   $0x0,0x8(%rax)
   62ef0:	je     63074 <f.13+0x354>
   62ef6:	mov    0x10(%rax),%rax
   62efa:	test   %rax,%rax
   62efd:	je     63074 <f.13+0x354>
   62f03:	mov    0x10(%rdi),%rsi
   62f07:	mov    0x8(%rax),%rdi
   62f0b:	mov    %rdi,0x30(%rsp)
   62f10:	movq   $0x3,0x18(%rsp)
   62f19:	call   5e630 <f.18>
   62f1e:	sub    $0x8,%rsp
   62f22:	mov    0x28(%rsp),%rdi
   62f27:	test   %rdi,%rdi
   62f2a:	je     63074 <f.13+0x354>
   62f30:	mov    0x20(%rdi),%rax
   62f34:	test   %rax,%rax
   62f37:	je     63074 <f.13+0x354>
   62f3d:	cmpl   $0x0,0x8(%rax)
   62f41:	je     63074 <f.13+0x354>
   62f47:	cmpq   $0x0,0x10(%rax)
   62f4c:	je     63074 <f.13+0x354>
   62f52:	xor    %r8d,%r8d
   62f55:	cmpq   $0x0,0x10(%rsp)
   62f5b:	setne  %r8b
   62f5f:	mov    0x789a(%rip),%rcx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   62f66:	mov    %r15,%rax
   62f69:	cmovne %r14,%rax
   62f6d:	mov    (%rax),%rdx
   62f70:	movq   $0x3,0x10(%rsp)
   62f79:	movq   $0x0,0x18(%rsp)
   62f82:	mov    %rdx,0x8(%rsp)
   62f87:	mov    %r14,0x7892(%rip)        # 6a820 <native_roots.0>
   62f8e:	mov    %r8,%rax
   62f91:	neg    %rax
   62f94:	add    %rcx,%rax
   62f97:	inc    %rax
   62f9a:	mov    %rax,0x785f(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   62fa1:	mov    0x7860(%rip),%rsi        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   62fa8:	cmp    %rsi,%rax
   62fab:	cmova  %rax,%rsi
   62faf:	mov    %rsi,0x7852(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   62fb6:	mov    %rdi,0x20(%rsp)
   62fbb:	movq   $0x0,0x28(%rsp)
   62fc4:	test   $0x1,%dil
   62fc8:	jne    63074 <f.13+0x354>
   62fce:	mov    0x7843(%rip),%rsi        # 6a818 <snail_runtime::native::RUNTIME>
   62fd5:	test   %rsi,%rsi
   62fd8:	je     63074 <f.13+0x354>
   62fde:	mov    (%rdi),%rax
   62fe1:	mov    %rax,%r9
   62fe4:	test   %rax,%rax
   62fe7:	je     62e40 <f.13+0x120>
   62fed:	mov    %rax,%r9
   62ff0:	cmp    $0x16,%rax
   62ff4:	je     62e40 <f.13+0x120>
   62ffa:	mov    0x168(%rsi),%r10
   63001:	mov    %rax,%r9
   63004:	shr    $0x2,%r9
   63008:	lea    -0x1(%r9),%r11
   6300c:	cmp    %r10,%r11
   6300f:	jae    63074 <f.13+0x354>
   63011:	mov    0x160(%rsi),%r11
   63018:	mov    -0x8(%r11,%r9,8),%r9
   6301d:	test   %r9,%r9
   63020:	je     62e40 <f.13+0x120>
   63026:	cmp    $0x16,%r9
   6302a:	je     62e40 <f.13+0x120>
   63030:	shr    $0x2,%r9
   63034:	lea    -0x1(%r9),%r12
   63038:	cmp    %r10,%r12
   6303b:	jae    63074 <f.13+0x354>
   6303d:	mov    -0x8(%r11,%r9,8),%r9
   63042:	cmp    $0x16,%r9
   63046:	je     62e40 <f.13+0x120>
   6304c:	test   %r9,%r9
   6304f:	jne    63030 <f.13+0x310>
   63051:	jmp    62e40 <f.13+0x120>
   63056:	mov    %rdx,0x77c3(%rip)        # 6a820 <native_roots.0>
   6305d:	mov    %rcx,0x779c(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   63064:	xor    %eax,%eax
   63066:	add    $0x38,%rsp
   6306a:	pop    %rbx
   6306b:	pop    %r12
   6306d:	pop    %r14
   6306f:	pop    %r15
   63071:	ret    $0x8
   63074:	call   56d70 <native_trap>
   63079:	int3
   6307a:	int3
   6307b:	int3
   6307c:	int3
   6307d:	int3
   6307e:	int3
   6307f:	int3
