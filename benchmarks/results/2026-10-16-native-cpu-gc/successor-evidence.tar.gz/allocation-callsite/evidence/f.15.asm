   61040:	push   %rbp
   61041:	push   %r15
   61043:	push   %r14
   61045:	push   %r13
   61047:	push   %r12
   61049:	push   %rbx
   6104a:	sub    $0x68,%rsp
   6104e:	movq   $0x6,0x18(%rsp)
   61057:	movq   $0x0,0x20(%rsp)
   61060:	mov    0x97b9(%rip),%rax        # 6a820 <native_roots.0>
   61067:	mov    %rax,0x10(%rsp)
   6106c:	lea    0x10(%rsp),%r13
   61071:	mov    %r13,0x97a8(%rip)        # 6a820 <native_roots.0>
   61078:	mov    0x9781(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   6107f:	inc    %rax
   61082:	mov    %rax,0x9777(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   61089:	mov    0x9778(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   61090:	cmp    %rcx,%rax
   61093:	cmovbe %rcx,%rax
   61097:	mov    %rax,0x976a(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   6109e:	mov    %rdi,0x28(%rsp)
   610a3:	pxor   %xmm0,%xmm0
   610a7:	movdqu %xmm0,0x30(%rsp)
   610ad:	test   %rdi,%rdi
   610b0:	je     61e03 <f.15+0xdc3>
   610b6:	cmpb   $0x0,0x989b(%rip)        # 6a958 <g.15>
   610bd:	je     61e03 <f.15+0xdc3>
   610c3:	cmpq   $0x0,0x9885(%rip)        # 6a950 <g.14>
   610cb:	je     61e03 <f.15+0xdc3>
   610d1:	mov    0x8(%rdi),%rax
   610d5:	movq   $0x3,0x20(%rsp)
   610de:	mov    0x9733(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   610e5:	test   %r12,%r12
   610e8:	je     61e03 <f.15+0xdc3>
   610ee:	mov    %rax,0x58(%rsp)
   610f3:	mov    0x178(%r12),%rcx
   610fb:	test   %rcx,%rcx
   610fe:	mov    %rsi,0x60(%rsp)
   61103:	je     61146 <f.15+0x106>
   61105:	mov    0x170(%r12),%rax
   6110d:	inc    %rax
   61110:	mov    %rax,0x170(%r12)
   61118:	mov    %rax,%rdx
   6111b:	or     %rcx,%rdx
   6111e:	shr    $0x20,%rdx
   61122:	je     61d97 <f.15+0xd57>
   61128:	xor    %edx,%edx
   6112a:	div    %rcx
   6112d:	test   %rdx,%rdx
   61130:	jne    61146 <f.15+0x106>
   61132:	lea    0x10(%rsp),%rsi
   61137:	mov    %r12,%rdi
   6113a:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6113f:	mov    0x96da(%rip),%r13        # 6a820 <native_roots.0>
   61146:	cmpq   $0x20,0x98(%r12)
   6114f:	jb     61e08 <f.15+0xdc8>
   61155:	mov    0xe0(%r12),%rbx
   6115d:	mov    0xe8(%r12),%rbp
   61165:	cmp    %rbp,%rbx
   61168:	jb     61175 <f.15+0x135>
   6116a:	mov    %r12,%rdi
   6116d:	mov    %r13,%rsi
   61170:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   61175:	mov    0xc8(%r12),%r15
   6117d:	test   %r15,%r15
   61180:	je     61193 <f.15+0x153>
   61182:	mov    0xd0(%r12),%rax
   6118a:	sub    %r15,%rax
   6118d:	cmp    $0x1f,%rax
   61191:	ja     611b7 <f.15+0x177>
   61193:	mov    $0x20,%esi
   61198:	mov    %r12,%rdi
   6119b:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   611a0:	mov    %rdx,%r15
   611a3:	cmp    $0x1,%rax
   611a7:	jne    61236 <f.15+0x1f6>
   611ad:	mov    $0x1,%eax
   611b2:	jmp    61251 <f.15+0x211>
   611b7:	lea    0x20(%r15),%rax
   611bb:	mov    %rax,0xc8(%r12)
   611c3:	mov    0x10(%r12),%rsi
   611c8:	mov    0xc0(%r12),%rdi
   611d0:	cmp    %rsi,%rdi
   611d3:	jae    61e19 <f.15+0xdd9>
   611d9:	mov    0x8(%r12),%rax
   611de:	imul   $0x38,%rdi,%rcx
   611e2:	mov    %r15,%rdx
   611e5:	sub    0x18(%rax,%rcx,1),%rdx
   611ea:	mov    %rdx,%rdi
   611ed:	shr    $0xf,%rdi
   611f1:	mov    0x10(%rax,%rcx,1),%rsi
   611f6:	cmp    %rsi,%rdi
   611f9:	jae    61e25 <f.15+0xde5>
   611ff:	add    %rcx,%rax
   61202:	mov    %edx,%ecx
   61204:	imul   $0x220,%rdi,%rsi
   6120b:	add    0x8(%rax),%rsi
   6120f:	shr    $0x4,%ecx
   61212:	mov    $0x1,%eax
   61217:	mov    $0x1,%edi
   6121c:	shl    %cl,%rdi
   6121f:	shr    $0x7,%edx
   61222:	and    $0xf8,%edx
   61228:	or     %rdi,(%rdx,%rsi,1)
   6122c:	cmp    $0x1,%rax
   61230:	je     611ad <f.15+0x16d>
   61236:	xor    %edx,%edx
   61238:	cmp    %rbp,%rbx
   6123b:	setae  %dl
   6123e:	mov    $0x20,%esi
   61243:	mov    %r12,%rdi
   61246:	mov    %r13,%rcx
   61249:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   6124e:	mov    %rdx,%r15
   61251:	test   $0x1,%al
   61253:	je     61e08 <f.15+0xdc8>
   61259:	movq   $0x61,(%r15)
   61260:	pxor   %xmm0,%xmm0
   61264:	movdqu %xmm0,0x8(%r15)
   6126a:	movq   $0x0,0x18(%r15)
   61272:	addq   $0x20,0xe0(%r12)
   6127b:	lea    0x8(%r15),%rbp
   6127f:	movdqu 0x110(%r12),%xmm0
   61289:	paddq  -0x5cda1(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   61291:	movdqu %xmm0,0x110(%r12)
   6129b:	movq   $0x7a,0x8(%r15)
   612a3:	movl   $0x0,0x10(%r15)
   612ab:	movq   $0x0,0x18(%r15)
   612b3:	mov    %rbp,0x30(%rsp)
   612b8:	mov    %rbp,0x40(%rsp)
   612bd:	lea    0x7424(%rip),%rax        # 686e8 <ref.19>
   612c4:	mov    %rax,0x48(%rsp)
   612c9:	mov    %rbp,0x50(%rsp)
   612ce:	movq   $0x6,0x20(%rsp)
   612d7:	mov    0x953a(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   612de:	test   %r12,%r12
   612e1:	je     61e03 <f.15+0xdc3>
   612e7:	mov    0x178(%r12),%rcx
   612ef:	test   %rcx,%rcx
   612f2:	je     61330 <f.15+0x2f0>
   612f4:	mov    0x170(%r12),%rax
   612fc:	inc    %rax
   612ff:	mov    %rax,0x170(%r12)
   61307:	mov    %rax,%rdx
   6130a:	or     %rcx,%rdx
   6130d:	shr    $0x20,%rdx
   61311:	je     61da9 <f.15+0xd69>
   61317:	xor    %edx,%edx
   61319:	div    %rcx
   6131c:	test   %rdx,%rdx
   6131f:	jne    61330 <f.15+0x2f0>
   61321:	mov    0x94f8(%rip),%rsi        # 6a820 <native_roots.0>
   61328:	mov    %r12,%rdi
   6132b:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   61330:	cmpq   $0x20,0x98(%r12)
   61339:	jb     61e08 <f.15+0xdc8>
   6133f:	mov    0x94da(%rip),%r13        # 6a820 <native_roots.0>
   61346:	mov    0xe0(%r12),%rbx
   6134e:	mov    0xe8(%r12),%r14
   61356:	cmp    %r14,%rbx
   61359:	jb     61366 <f.15+0x326>
   6135b:	mov    %r12,%rdi
   6135e:	mov    %r13,%rsi
   61361:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   61366:	mov    0xc8(%r12),%rdx
   6136e:	test   %rdx,%rdx
   61371:	je     61384 <f.15+0x344>
   61373:	mov    0xd0(%r12),%rax
   6137b:	sub    %rdx,%rax
   6137e:	cmp    $0x1f,%rax
   61382:	ja     613a5 <f.15+0x365>
   61384:	mov    $0x20,%esi
   61389:	mov    %r12,%rdi
   6138c:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   61391:	cmp    $0x1,%rax
   61395:	jne    61427 <f.15+0x3e7>
   6139b:	mov    $0x1,%eax
   613a0:	jmp    6143f <f.15+0x3ff>
   613a5:	lea    0x20(%rdx),%rax
   613a9:	mov    %rax,0xc8(%r12)
   613b1:	mov    0x10(%r12),%rsi
   613b6:	mov    0xc0(%r12),%rdi
   613be:	cmp    %rsi,%rdi
   613c1:	jae    61e19 <f.15+0xdd9>
   613c7:	mov    0x8(%r12),%rax
   613cc:	imul   $0x38,%rdi,%rcx
   613d0:	mov    %rdx,%r8
   613d3:	sub    0x18(%rax,%rcx,1),%r8
   613d8:	mov    %r8,%rdi
   613db:	shr    $0xf,%rdi
   613df:	mov    0x10(%rax,%rcx,1),%rsi
   613e4:	cmp    %rsi,%rdi
   613e7:	jae    61e25 <f.15+0xde5>
   613ed:	add    %rcx,%rax
   613f0:	mov    %r8d,%ecx
   613f3:	imul   $0x220,%rdi,%rsi
   613fa:	add    0x8(%rax),%rsi
   613fe:	shr    $0x4,%ecx
   61401:	mov    $0x1,%eax
   61406:	mov    $0x1,%edi
   6140b:	shl    %cl,%rdi
   6140e:	shr    $0x7,%r8d
   61412:	and    $0xf8,%r8d
   61419:	or     %rdi,(%r8,%rsi,1)
   6141d:	cmp    $0x1,%rax
   61421:	je     6139b <f.15+0x35b>
   61427:	xor    %edx,%edx
   61429:	cmp    %r14,%rbx
   6142c:	setae  %dl
   6142f:	mov    $0x20,%esi
   61434:	mov    %r12,%rdi
   61437:	mov    %r13,%rcx
   6143a:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   6143f:	test   $0x1,%al
   61441:	je     61e08 <f.15+0xdc8>
   61447:	movq   $0x41,(%rdx)
   6144e:	lea    0x8(%rdx),%rbx
   61452:	pxor   %xmm0,%xmm0
   61456:	movdqu %xmm0,0x8(%rdx)
   6145b:	addq   $0x20,0xe0(%r12)
   61464:	movdqu 0x110(%r12),%xmm0
   6146e:	paddq  -0x5cf26(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   61476:	movdqu %xmm0,0x110(%r12)
   61480:	movq   $0x72,0x8(%rdx)
   61488:	mov    %rbp,0x10(%rdx)
   6148c:	mov    %rbx,0x40(%rsp)
   61491:	lea    0x7250(%rip),%rax        # 686e8 <ref.19>
   61498:	mov    %rax,0x48(%rsp)
   6149d:	mov    %rbp,0x50(%rsp)
   614a2:	movq   $0x6,0x20(%rsp)
   614ab:	mov    0x9366(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   614b2:	test   %r12,%r12
   614b5:	je     61e03 <f.15+0xdc3>
   614bb:	mov    0x178(%r12),%rcx
   614c3:	test   %rcx,%rcx
   614c6:	je     61504 <f.15+0x4c4>
   614c8:	mov    0x170(%r12),%rax
   614d0:	inc    %rax
   614d3:	mov    %rax,0x170(%r12)
   614db:	mov    %rax,%rdx
   614de:	or     %rcx,%rdx
   614e1:	shr    $0x20,%rdx
   614e5:	je     61dbb <f.15+0xd7b>
   614eb:	xor    %edx,%edx
   614ed:	div    %rcx
   614f0:	test   %rdx,%rdx
   614f3:	jne    61504 <f.15+0x4c4>
   614f5:	mov    0x9324(%rip),%rsi        # 6a820 <native_roots.0>
   614fc:	mov    %r12,%rdi
   614ff:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   61504:	cmpq   $0x20,0x98(%r12)
   6150d:	jb     61e08 <f.15+0xdc8>
   61513:	mov    0x9306(%rip),%r13        # 6a820 <native_roots.0>
   6151a:	mov    0xe0(%r12),%rbp
   61522:	mov    0xe8(%r12),%r14
   6152a:	cmp    %r14,%rbp
   6152d:	jb     6153a <f.15+0x4fa>
   6152f:	mov    %r12,%rdi
   61532:	mov    %r13,%rsi
   61535:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6153a:	mov    0xc8(%r12),%rdx
   61542:	test   %rdx,%rdx
   61545:	je     61558 <f.15+0x518>
   61547:	mov    0xd0(%r12),%rax
   6154f:	sub    %rdx,%rax
   61552:	cmp    $0x1f,%rax
   61556:	ja     61579 <f.15+0x539>
   61558:	mov    $0x20,%esi
   6155d:	mov    %r12,%rdi
   61560:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   61565:	cmp    $0x1,%rax
   61569:	jne    615fb <f.15+0x5bb>
   6156f:	mov    $0x1,%eax
   61574:	jmp    61613 <f.15+0x5d3>
   61579:	lea    0x20(%rdx),%rax
   6157d:	mov    %rax,0xc8(%r12)
   61585:	mov    0x10(%r12),%rsi
   6158a:	mov    0xc0(%r12),%rdi
   61592:	cmp    %rsi,%rdi
   61595:	jae    61e19 <f.15+0xdd9>
   6159b:	mov    0x8(%r12),%rax
   615a0:	imul   $0x38,%rdi,%rcx
   615a4:	mov    %rdx,%r8
   615a7:	sub    0x18(%rax,%rcx,1),%r8
   615ac:	mov    %r8,%rdi
   615af:	shr    $0xf,%rdi
   615b3:	mov    0x10(%rax,%rcx,1),%rsi
   615b8:	cmp    %rsi,%rdi
   615bb:	jae    61e25 <f.15+0xde5>
   615c1:	add    %rcx,%rax
   615c4:	mov    %r8d,%ecx
   615c7:	imul   $0x220,%rdi,%rsi
   615ce:	add    0x8(%rax),%rsi
   615d2:	shr    $0x4,%ecx
   615d5:	mov    $0x1,%eax
   615da:	mov    $0x1,%edi
   615df:	shl    %cl,%rdi
   615e2:	shr    $0x7,%r8d
   615e6:	and    $0xf8,%r8d
   615ed:	or     %rdi,(%r8,%rsi,1)
   615f1:	cmp    $0x1,%rax
   615f5:	je     6156f <f.15+0x52f>
   615fb:	xor    %edx,%edx
   615fd:	cmp    %r14,%rbp
   61600:	setae  %dl
   61603:	mov    $0x20,%esi
   61608:	mov    %r12,%rdi
   6160b:	mov    %r13,%rcx
   6160e:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   61613:	test   $0x1,%al
   61615:	je     61e08 <f.15+0xdc8>
   6161b:	movq   $0x61,(%rdx)
   61622:	pxor   %xmm0,%xmm0
   61626:	movdqu %xmm0,0x8(%rdx)
   6162b:	movq   $0x0,0x18(%rdx)
   61633:	addq   $0x20,0xe0(%r12)
   6163c:	movdqu 0x110(%r12),%xmm0
   61646:	paddq  -0x5d15e(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   6164e:	lea    0x8(%rdx),%rax
   61652:	movdqu %xmm0,0x110(%r12)
   6165c:	movq   $0x92,0x8(%rdx)
   61664:	lea    0x707d(%rip),%rcx        # 686e8 <ref.19>
   6166b:	mov    %rcx,0x10(%rdx)
   6166f:	mov    %rbx,0x18(%rdx)
   61673:	mov    %rax,0x18(%r15)
   61677:	mov    0x30(%rsp),%rax
   6167c:	test   %rax,%rax
   6167f:	je     61e03 <f.15+0xdc3>
   61685:	movl   $0x1,0x8(%rax)
   6168c:	mov    0x30(%rsp),%rax
   61691:	test   %rax,%rax
   61694:	je     61e03 <f.15+0xdc3>
   6169a:	cmpl   $0x0,0x8(%rax)
   6169e:	je     61e03 <f.15+0xdc3>
   616a4:	mov    0x10(%rax),%rax
   616a8:	test   %rax,%rax
   616ab:	je     61e03 <f.15+0xdc3>
   616b1:	mov    %rax,0x38(%rsp)
   616b6:	mov    0x8(%rax),%rcx
   616ba:	test   %rcx,%rcx
   616bd:	je     61e03 <f.15+0xdc3>
   616c3:	mov    0x58(%rsp),%rsi
   616c8:	inc    %rsi
   616cb:	mov    0x10(%rax),%rdi
   616cf:	mov    0x8(%rcx),%rax
   616d3:	mov    %rdi,0x40(%rsp)
   616d8:	movq   $0x4,0x20(%rsp)
   616e1:	mov    $0x1,%edx
   616e6:	call   *%rax
   616e8:	sub    $0x8,%rsp
   616ec:	cmpq   $0x0,0x28(%rsp)
   616f2:	je     61e03 <f.15+0xdc3>
   616f8:	cmpb   $0x0,0x9259(%rip)        # 6a958 <g.15>
   616ff:	je     61e03 <f.15+0xdc3>
   61705:	cmpq   $0x0,0x9243(%rip)        # 6a950 <g.14>
   6170d:	je     61e03 <f.15+0xdc3>
   61713:	mov    %rax,0x58(%rsp)
   61718:	movq   $0x3,0x20(%rsp)
   61721:	mov    0x90f0(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   61728:	test   %r12,%r12
   6172b:	je     61e03 <f.15+0xdc3>
   61731:	mov    0x178(%r12),%rcx
   61739:	test   %rcx,%rcx
   6173c:	je     6177a <f.15+0x73a>
   6173e:	mov    0x170(%r12),%rax
   61746:	inc    %rax
   61749:	mov    %rax,0x170(%r12)
   61751:	mov    %rax,%rdx
   61754:	or     %rcx,%rdx
   61757:	shr    $0x20,%rdx
   6175b:	je     61dcd <f.15+0xd8d>
   61761:	xor    %edx,%edx
   61763:	div    %rcx
   61766:	test   %rdx,%rdx
   61769:	jne    6177a <f.15+0x73a>
   6176b:	mov    0x90ae(%rip),%rsi        # 6a820 <native_roots.0>
   61772:	mov    %r12,%rdi
   61775:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6177a:	cmpq   $0x20,0x98(%r12)
   61783:	jb     61e08 <f.15+0xdc8>
   61789:	mov    0x9090(%rip),%r13        # 6a820 <native_roots.0>
   61790:	mov    0xe0(%r12),%rbx
   61798:	mov    0xe8(%r12),%rbp
   617a0:	cmp    %rbp,%rbx
   617a3:	jb     617b0 <f.15+0x770>
   617a5:	mov    %r12,%rdi
   617a8:	mov    %r13,%rsi
   617ab:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   617b0:	mov    0xc8(%r12),%r15
   617b8:	test   %r15,%r15
   617bb:	je     617ce <f.15+0x78e>
   617bd:	mov    0xd0(%r12),%rax
   617c5:	sub    %r15,%rax
   617c8:	cmp    $0x1f,%rax
   617cc:	ja     617f2 <f.15+0x7b2>
   617ce:	mov    $0x20,%esi
   617d3:	mov    %r12,%rdi
   617d6:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   617db:	mov    %rdx,%r15
   617de:	cmp    $0x1,%rax
   617e2:	jne    61871 <f.15+0x831>
   617e8:	mov    $0x1,%eax
   617ed:	jmp    6188c <f.15+0x84c>
   617f2:	lea    0x20(%r15),%rax
   617f6:	mov    %rax,0xc8(%r12)
   617fe:	mov    0x10(%r12),%rsi
   61803:	mov    0xc0(%r12),%rdi
   6180b:	cmp    %rsi,%rdi
   6180e:	jae    61e19 <f.15+0xdd9>
   61814:	mov    0x8(%r12),%rax
   61819:	imul   $0x38,%rdi,%rcx
   6181d:	mov    %r15,%rdx
   61820:	sub    0x18(%rax,%rcx,1),%rdx
   61825:	mov    %rdx,%rdi
   61828:	shr    $0xf,%rdi
   6182c:	mov    0x10(%rax,%rcx,1),%rsi
   61831:	cmp    %rsi,%rdi
   61834:	jae    61e25 <f.15+0xde5>
   6183a:	add    %rcx,%rax
   6183d:	mov    %edx,%ecx
   6183f:	imul   $0x220,%rdi,%rsi
   61846:	add    0x8(%rax),%rsi
   6184a:	shr    $0x4,%ecx
   6184d:	mov    $0x1,%eax
   61852:	mov    $0x1,%edi
   61857:	shl    %cl,%rdi
   6185a:	shr    $0x7,%edx
   6185d:	and    $0xf8,%edx
   61863:	or     %rdi,(%rdx,%rsi,1)
   61867:	cmp    $0x1,%rax
   6186b:	je     617e8 <f.15+0x7a8>
   61871:	xor    %edx,%edx
   61873:	cmp    %rbp,%rbx
   61876:	setae  %dl
   61879:	mov    $0x20,%esi
   6187e:	mov    %r12,%rdi
   61881:	mov    %r13,%rcx
   61884:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   61889:	mov    %rdx,%r15
   6188c:	test   $0x1,%al
   6188e:	je     61e08 <f.15+0xdc8>
   61894:	movq   $0x61,(%r15)
   6189b:	pxor   %xmm0,%xmm0
   6189f:	movdqu %xmm0,0x8(%r15)
   618a5:	movq   $0x0,0x18(%r15)
   618ad:	addq   $0x20,0xe0(%r12)
   618b6:	movdqu 0x110(%r12),%xmm0
   618c0:	paddq  -0x5d3d8(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   618c8:	lea    0x8(%r15),%rbp
   618cc:	movdqu %xmm0,0x110(%r12)
   618d6:	movq   $0x7a,0x8(%r15)
   618de:	movl   $0x0,0x10(%r15)
   618e6:	movq   $0x0,0x18(%r15)
   618ee:	mov    %rbp,0x30(%rsp)
   618f3:	mov    %rbp,0x40(%rsp)
   618f8:	lea    0x6de9(%rip),%rax        # 686e8 <ref.19>
   618ff:	mov    %rax,0x48(%rsp)
   61904:	mov    %rbp,0x50(%rsp)
   61909:	movq   $0x6,0x20(%rsp)
   61912:	mov    0x8eff(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   61919:	test   %r12,%r12
   6191c:	je     61e03 <f.15+0xdc3>
   61922:	mov    0x178(%r12),%rcx
   6192a:	test   %rcx,%rcx
   6192d:	je     6196b <f.15+0x92b>
   6192f:	mov    0x170(%r12),%rax
   61937:	inc    %rax
   6193a:	mov    %rax,0x170(%r12)
   61942:	mov    %rax,%rdx
   61945:	or     %rcx,%rdx
   61948:	shr    $0x20,%rdx
   6194c:	je     61ddf <f.15+0xd9f>
   61952:	xor    %edx,%edx
   61954:	div    %rcx
   61957:	test   %rdx,%rdx
   6195a:	jne    6196b <f.15+0x92b>
   6195c:	mov    0x8ebd(%rip),%rsi        # 6a820 <native_roots.0>
   61963:	mov    %r12,%rdi
   61966:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6196b:	cmpq   $0x20,0x98(%r12)
   61974:	jb     61e08 <f.15+0xdc8>
   6197a:	mov    0x8e9f(%rip),%r13        # 6a820 <native_roots.0>
   61981:	mov    0xe0(%r12),%rbx
   61989:	mov    0xe8(%r12),%r14
   61991:	cmp    %r14,%rbx
   61994:	jb     619a1 <f.15+0x961>
   61996:	mov    %r12,%rdi
   61999:	mov    %r13,%rsi
   6199c:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   619a1:	mov    0xc8(%r12),%rdx
   619a9:	test   %rdx,%rdx
   619ac:	je     619bf <f.15+0x97f>
   619ae:	mov    0xd0(%r12),%rax
   619b6:	sub    %rdx,%rax
   619b9:	cmp    $0x1f,%rax
   619bd:	ja     619e0 <f.15+0x9a0>
   619bf:	mov    $0x20,%esi
   619c4:	mov    %r12,%rdi
   619c7:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   619cc:	cmp    $0x1,%rax
   619d0:	jne    61a62 <f.15+0xa22>
   619d6:	mov    $0x1,%eax
   619db:	jmp    61a7a <f.15+0xa3a>
   619e0:	lea    0x20(%rdx),%rax
   619e4:	mov    %rax,0xc8(%r12)
   619ec:	mov    0x10(%r12),%rsi
   619f1:	mov    0xc0(%r12),%rdi
   619f9:	cmp    %rsi,%rdi
   619fc:	jae    61e19 <f.15+0xdd9>
   61a02:	mov    0x8(%r12),%rax
   61a07:	imul   $0x38,%rdi,%rcx
   61a0b:	mov    %rdx,%r8
   61a0e:	sub    0x18(%rax,%rcx,1),%r8
   61a13:	mov    %r8,%rdi
   61a16:	shr    $0xf,%rdi
   61a1a:	mov    0x10(%rax,%rcx,1),%rsi
   61a1f:	cmp    %rsi,%rdi
   61a22:	jae    61e25 <f.15+0xde5>
   61a28:	add    %rcx,%rax
   61a2b:	mov    %r8d,%ecx
   61a2e:	imul   $0x220,%rdi,%rsi
   61a35:	add    0x8(%rax),%rsi
   61a39:	shr    $0x4,%ecx
   61a3c:	mov    $0x1,%eax
   61a41:	mov    $0x1,%edi
   61a46:	shl    %cl,%rdi
   61a49:	shr    $0x7,%r8d
   61a4d:	and    $0xf8,%r8d
   61a54:	or     %rdi,(%r8,%rsi,1)
   61a58:	cmp    $0x1,%rax
   61a5c:	je     619d6 <f.15+0x996>
   61a62:	xor    %edx,%edx
   61a64:	cmp    %r14,%rbx
   61a67:	setae  %dl
   61a6a:	mov    $0x20,%esi
   61a6f:	mov    %r12,%rdi
   61a72:	mov    %r13,%rcx
   61a75:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   61a7a:	test   $0x1,%al
   61a7c:	je     61e08 <f.15+0xdc8>
   61a82:	movq   $0x41,(%rdx)
   61a89:	lea    0x8(%rdx),%rbx
   61a8d:	pxor   %xmm0,%xmm0
   61a91:	movdqu %xmm0,0x8(%rdx)
   61a96:	addq   $0x20,0xe0(%r12)
   61a9f:	movdqu 0x110(%r12),%xmm0
   61aa9:	paddq  -0x5d561(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   61ab1:	movdqu %xmm0,0x110(%r12)
   61abb:	movq   $0x72,0x8(%rdx)
   61ac3:	mov    %rbp,0x10(%rdx)
   61ac7:	mov    %rbx,0x40(%rsp)
   61acc:	lea    0x6c15(%rip),%rax        # 686e8 <ref.19>
   61ad3:	mov    %rax,0x48(%rsp)
   61ad8:	mov    %rbp,0x50(%rsp)
   61add:	movq   $0x6,0x20(%rsp)
   61ae6:	mov    0x8d2b(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   61aed:	test   %r12,%r12
   61af0:	je     61e03 <f.15+0xdc3>
   61af6:	mov    0x178(%r12),%rcx
   61afe:	test   %rcx,%rcx
   61b01:	je     61b3f <f.15+0xaff>
   61b03:	mov    0x170(%r12),%rax
   61b0b:	inc    %rax
   61b0e:	mov    %rax,0x170(%r12)
   61b16:	mov    %rax,%rdx
   61b19:	or     %rcx,%rdx
   61b1c:	shr    $0x20,%rdx
   61b20:	je     61df1 <f.15+0xdb1>
   61b26:	xor    %edx,%edx
   61b28:	div    %rcx
   61b2b:	test   %rdx,%rdx
   61b2e:	jne    61b3f <f.15+0xaff>
   61b30:	mov    0x8ce9(%rip),%rsi        # 6a820 <native_roots.0>
   61b37:	mov    %r12,%rdi
   61b3a:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   61b3f:	cmpq   $0x20,0x98(%r12)
   61b48:	jb     61e08 <f.15+0xdc8>
   61b4e:	mov    0x8ccb(%rip),%r13        # 6a820 <native_roots.0>
   61b55:	mov    0xe0(%r12),%rbp
   61b5d:	mov    0xe8(%r12),%r14
   61b65:	cmp    %r14,%rbp
   61b68:	jb     61b75 <f.15+0xb35>
   61b6a:	mov    %r12,%rdi
   61b6d:	mov    %r13,%rsi
   61b70:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   61b75:	mov    0xc8(%r12),%rdx
   61b7d:	test   %rdx,%rdx
   61b80:	je     61b93 <f.15+0xb53>
   61b82:	mov    0xd0(%r12),%rax
   61b8a:	sub    %rdx,%rax
   61b8d:	cmp    $0x1f,%rax
   61b91:	ja     61bb4 <f.15+0xb74>
   61b93:	mov    $0x20,%esi
   61b98:	mov    %r12,%rdi
   61b9b:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   61ba0:	cmp    $0x1,%rax
   61ba4:	jne    61c36 <f.15+0xbf6>
   61baa:	mov    $0x1,%eax
   61baf:	jmp    61c4e <f.15+0xc0e>
   61bb4:	lea    0x20(%rdx),%rax
   61bb8:	mov    %rax,0xc8(%r12)
   61bc0:	mov    0x10(%r12),%rsi
   61bc5:	mov    0xc0(%r12),%rdi
   61bcd:	cmp    %rsi,%rdi
   61bd0:	jae    61e19 <f.15+0xdd9>
   61bd6:	mov    0x8(%r12),%rax
   61bdb:	imul   $0x38,%rdi,%rcx
   61bdf:	mov    %rdx,%r8
   61be2:	sub    0x18(%rax,%rcx,1),%r8
   61be7:	mov    %r8,%rdi
   61bea:	shr    $0xf,%rdi
   61bee:	mov    0x10(%rax,%rcx,1),%rsi
   61bf3:	cmp    %rsi,%rdi
   61bf6:	jae    61e25 <f.15+0xde5>
   61bfc:	add    %rcx,%rax
   61bff:	mov    %r8d,%ecx
   61c02:	imul   $0x220,%rdi,%rsi
   61c09:	add    0x8(%rax),%rsi
   61c0d:	shr    $0x4,%ecx
   61c10:	mov    $0x1,%eax
   61c15:	mov    $0x1,%edi
   61c1a:	shl    %cl,%rdi
   61c1d:	shr    $0x7,%r8d
   61c21:	and    $0xf8,%r8d
   61c28:	or     %rdi,(%r8,%rsi,1)
   61c2c:	cmp    $0x1,%rax
   61c30:	je     61baa <f.15+0xb6a>
   61c36:	xor    %edx,%edx
   61c38:	cmp    %r14,%rbp
   61c3b:	setae  %dl
   61c3e:	mov    $0x20,%esi
   61c43:	mov    %r12,%rdi
   61c46:	mov    %r13,%rcx
   61c49:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   61c4e:	test   $0x1,%al
   61c50:	je     61e08 <f.15+0xdc8>
   61c56:	movq   $0x61,(%rdx)
   61c5d:	pxor   %xmm0,%xmm0
   61c61:	movdqu %xmm0,0x8(%rdx)
   61c66:	movq   $0x0,0x18(%rdx)
   61c6e:	addq   $0x20,0xe0(%r12)
   61c77:	movdqu 0x110(%r12),%xmm0
   61c81:	paddq  -0x5d799(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   61c89:	lea    0x8(%rdx),%rax
   61c8d:	movdqu %xmm0,0x110(%r12)
   61c97:	movq   $0x92,0x8(%rdx)
   61c9f:	lea    0x6a42(%rip),%rcx        # 686e8 <ref.19>
   61ca6:	mov    %rcx,0x10(%rdx)
   61caa:	mov    %rbx,0x18(%rdx)
   61cae:	mov    %rax,0x18(%r15)
   61cb2:	mov    0x30(%rsp),%rax
   61cb7:	test   %rax,%rax
   61cba:	je     61e03 <f.15+0xdc3>
   61cc0:	movl   $0x1,0x8(%rax)
   61cc7:	mov    0x30(%rsp),%rax
   61ccc:	test   %rax,%rax
   61ccf:	mov    0x60(%rsp),%rsi
   61cd4:	je     61e03 <f.15+0xdc3>
   61cda:	cmpl   $0x0,0x8(%rax)
   61cde:	je     61e03 <f.15+0xdc3>
   61ce4:	mov    0x10(%rax),%rax
   61ce8:	test   %rax,%rax
   61ceb:	je     61e03 <f.15+0xdc3>
   61cf1:	mov    %rax,0x38(%rsp)
   61cf6:	mov    0x8(%rax),%rcx
   61cfa:	test   %rcx,%rcx
   61cfd:	je     61e03 <f.15+0xdc3>
   61d03:	mov    0x10(%rax),%rdi
   61d07:	inc    %rsi
   61d0a:	mov    0x8(%rcx),%rax
   61d0e:	mov    %rdi,0x40(%rsp)
   61d13:	movq   $0x4,0x20(%rsp)
   61d1c:	mov    $0x1,%edx
   61d21:	call   *%rax
   61d23:	sub    $0x8,%rsp
   61d27:	mov    %rax,%rsi
   61d2a:	dec    %rsi
   61d2d:	je     61e03 <f.15+0xdc3>
   61d33:	mov    %rax,%rcx
   61d36:	mov    0x58(%rsp),%rax
   61d3b:	lea    -0x2(,%rax,2),%rax
   61d43:	mov    %rax,%rdx
   61d46:	neg    %rdx
   61d49:	jno    61d54 <f.15+0xd14>
   61d4b:	test   %rcx,%rcx
   61d4e:	je     61e03 <f.15+0xdc3>
   61d54:	cmpq   $0x0,0x18(%rsp)
   61d5a:	je     61d6f <f.15+0xd2f>
   61d5c:	mov    0x10(%rsp),%rcx
   61d61:	mov    %rcx,0x8ab8(%rip)        # 6a820 <native_roots.0>
   61d68:	decq   0x8a91(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   61d6f:	mov    %rax,%rcx
   61d72:	or     %rsi,%rcx
   61d75:	shr    $0x20,%rcx
   61d79:	je     61d82 <f.15+0xd42>
   61d7b:	cqto
   61d7d:	idiv   %rsi
   61d80:	jmp    61d86 <f.15+0xd46>
   61d82:	xor    %edx,%edx
   61d84:	div    %esi
   61d86:	add    $0x68,%rsp
   61d8a:	pop    %rbx
   61d8b:	pop    %r12
   61d8d:	pop    %r13
   61d8f:	pop    %r14
   61d91:	pop    %r15
   61d93:	pop    %rbp
   61d94:	ret    $0x8
   61d97:	xor    %edx,%edx
   61d99:	div    %ecx
   61d9b:	test   %rdx,%rdx
   61d9e:	jne    61146 <f.15+0x106>
   61da4:	jmp    61132 <f.15+0xf2>
   61da9:	xor    %edx,%edx
   61dab:	div    %ecx
   61dad:	test   %rdx,%rdx
   61db0:	jne    61330 <f.15+0x2f0>
   61db6:	jmp    61321 <f.15+0x2e1>
   61dbb:	xor    %edx,%edx
   61dbd:	div    %ecx
   61dbf:	test   %rdx,%rdx
   61dc2:	jne    61504 <f.15+0x4c4>
   61dc8:	jmp    614f5 <f.15+0x4b5>
   61dcd:	xor    %edx,%edx
   61dcf:	div    %ecx
   61dd1:	test   %rdx,%rdx
   61dd4:	jne    6177a <f.15+0x73a>
   61dda:	jmp    6176b <f.15+0x72b>
   61ddf:	xor    %edx,%edx
   61de1:	div    %ecx
   61de3:	test   %rdx,%rdx
   61de6:	jne    6196b <f.15+0x92b>
   61dec:	jmp    6195c <f.15+0x91c>
   61df1:	xor    %edx,%edx
   61df3:	div    %ecx
   61df5:	test   %rdx,%rdx
   61df8:	jne    61b3f <f.15+0xaff>
   61dfe:	jmp    61b30 <f.15+0xaf0>
   61e03:	call   56d70 <native_trap>
   61e08:	lea    -0x589bb(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   61e0f:	mov    $0x2f,%esi
   61e14:	call   57d70 <snail_runtime::native::fail_bytes>
   61e19:	lea    0x57a0(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   61e20:	call   207b0 <core::panicking::panic_bounds_check>
   61e25:	lea    0x57ac(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   61e2c:	call   207b0 <core::panicking::panic_bounds_check>
   61e31:	int3
   61e32:	int3
   61e33:	int3
   61e34:	int3
   61e35:	int3
   61e36:	int3
   61e37:	int3
   61e38:	int3
   61e39:	int3
   61e3a:	int3
   61e3b:	int3
   61e3c:	int3
   61e3d:	int3
   61e3e:	int3
   61e3f:	int3
