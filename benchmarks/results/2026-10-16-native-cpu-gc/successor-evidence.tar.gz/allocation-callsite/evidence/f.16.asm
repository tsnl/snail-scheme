   63fc0:	push   %rbp
   63fc1:	push   %r14
   63fc3:	push   %rbx
   63fc4:	test   %rdi,%rdi
   63fc7:	je     64347 <f.16+0x387>
   63fcd:	mov    %edi,%eax
   63fcf:	and    $0x1,%eax
   63fd2:	jne    64347 <f.16+0x387>
   63fd8:	mov    0x6839(%rip),%rdx        # 6a818 <snail_runtime::native::RUNTIME>
   63fdf:	test   %rdx,%rdx
   63fe2:	je     64347 <f.16+0x387>
   63fe8:	mov    (%rdi),%rax
   63feb:	mov    %rax,%rcx
   63fee:	test   %rax,%rax
   63ff1:	je     64051 <f.16+0x91>
   63ff3:	mov    %rax,%rcx
   63ff6:	cmp    $0x2e,%rax
   63ffa:	je     64051 <f.16+0x91>
   63ffc:	mov    0x168(%rdx),%r8
   64003:	mov    %rax,%rcx
   64006:	shr    $0x2,%rcx
   6400a:	lea    -0x1(%rcx),%r9
   6400e:	cmp    %r8,%r9
   64011:	jae    64347 <f.16+0x387>
   64017:	mov    0x160(%rdx),%r9
   6401e:	mov    -0x8(%r9,%rcx,8),%rcx
   64023:	test   %rcx,%rcx
   64026:	je     64051 <f.16+0x91>
   64028:	cmp    $0x2e,%rcx
   6402c:	je     64051 <f.16+0x91>
   6402e:	xchg   %ax,%ax
   64030:	shr    $0x2,%rcx
   64034:	lea    -0x1(%rcx),%r10
   64038:	cmp    %r8,%r10
   6403b:	jae    64347 <f.16+0x387>
   64041:	mov    -0x8(%r9,%rcx,8),%rcx
   64046:	cmp    $0x2e,%rcx
   6404a:	je     64051 <f.16+0x91>
   6404c:	test   %rcx,%rcx
   6404f:	jne    64030 <f.16+0x70>
   64051:	cmp    $0x2e,%rcx
   64055:	jne    64347 <f.16+0x387>
   6405b:	movzbl 0x6916(%rip),%ecx        # 6a978 <g.19>
   64062:	movsd  -0x5e142(%rip),%xmm0        # 5f28 <__abi_tag+0x5bf4>
   6406a:	jmp    64079 <f.16+0xb9>
   6406c:	nopl   0x0(%rax)
   64070:	test   %r8b,%r8b
   64073:	je     64347 <f.16+0x387>
   64079:	mov    %rsi,%r8
   6407c:	mov    0x8(%rdi),%rsi
   64080:	mov    %rsi,%r9
   64083:	shr    $0x3f,%r9
   64087:	add    %rsi,%r9
   6408a:	sar    $1,%r9
   6408d:	cmp    %r8,%r9
   64090:	jle    6434c <f.16+0x38c>
   64096:	test   %rax,%rax
   64099:	je     64100 <f.16+0x140>
   6409b:	cmp    $0x2e,%rax
   6409f:	je     64100 <f.16+0x140>
   640a1:	mov    0x168(%rdx),%rsi
   640a8:	shr    $0x2,%rax
   640ac:	lea    -0x1(%rax),%r9
   640b0:	cmp    %rsi,%r9
   640b3:	jae    64347 <f.16+0x387>
   640b9:	mov    0x160(%rdx),%rdx
   640c0:	mov    -0x8(%rdx,%rax,8),%rax
   640c5:	test   %rax,%rax
   640c8:	je     64100 <f.16+0x140>
   640ca:	cmp    $0x2e,%rax
   640ce:	je     64100 <f.16+0x140>
   640d0:	shr    $0x2,%rax
   640d4:	lea    -0x1(%rax),%r9
   640d8:	cmp    %rsi,%r9
   640db:	jae    64347 <f.16+0x387>
   640e1:	mov    -0x8(%rdx,%rax,8),%rax
   640e6:	cmp    $0x2e,%rax
   640ea:	je     64100 <f.16+0x140>
   640ec:	test   %rax,%rax
   640ef:	jne    640d0 <f.16+0x110>
   640f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   64100:	cmp    $0x2e,%rax
   64104:	jne    64347 <f.16+0x387>
   6410a:	test   $0x1,%cl
   6410d:	je     64347 <f.16+0x387>
   64113:	cmpq   $0x0,0x6855(%rip)        # 6a970 <g.18>
   6411b:	je     64347 <f.16+0x387>
   64121:	mov    %r8,%rax
   64124:	shr    $0x20,%rax
   64128:	jne    64347 <f.16+0x387>
   6412e:	mov    0x10(%rdi),%rax
   64132:	test   %rax,%rax
   64135:	je     64347 <f.16+0x387>
   6413b:	test   $0x1,%al
   6413d:	jne    64347 <f.16+0x387>
   64143:	cmp    0x8(%rax),%r8
   64147:	jae    64347 <f.16+0x387>
   6414d:	lea    0x1(%r8),%rsi
   64151:	xorps  %xmm1,%xmm1
   64154:	cvtsi2sd %rsi,%xmm1
   64159:	movapd %xmm0,%xmm2
   6415d:	divsd  %xmm1,%xmm2
   64161:	movsd  %xmm2,0x10(%rax,%r8,8)
   64168:	mov    0x66a9(%rip),%rdx        # 6a818 <snail_runtime::native::RUNTIME>
   6416f:	test   %rdx,%rdx
   64172:	je     64347 <f.16+0x387>
   64178:	mov    (%rdi),%rax
   6417b:	cmp    $0x2e,%rax
   6417f:	sete   %r8b
   64183:	mov    %r8d,%ebx
   64186:	test   %rax,%rax
   64189:	je     641e0 <f.16+0x220>
   6418b:	mov    %r8d,%ebx
   6418e:	cmp    $0x2e,%rax
   64192:	je     641e0 <f.16+0x220>
   64194:	mov    0x168(%rdx),%r9
   6419b:	mov    %rax,%r10
   6419e:	shr    $0x2,%r10
   641a2:	lea    -0x1(%r10),%r11
   641a6:	cmp    %r9,%r11
   641a9:	jae    64347 <f.16+0x387>
   641af:	mov    0x160(%rdx),%r11
   641b6:	mov    -0x8(%r11,%r10,8),%r10
   641bb:	cmp    $0x2e,%r10
   641bf:	sete   %bl
   641c2:	test   %r10,%r10
   641c5:	je     641e0 <f.16+0x220>
   641c7:	cmp    $0x2e,%r10
   641cb:	jne    642f0 <f.16+0x330>
   641d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   641e0:	test   %bl,%bl
   641e2:	je     64347 <f.16+0x387>
   641e8:	mov    0x18(%rdi),%r9
   641ec:	test   %r9,%r9
   641ef:	je     64347 <f.16+0x387>
   641f5:	cmpl   $0x0,0x8(%r9)
   641fa:	je     64347 <f.16+0x387>
   64200:	mov    %r8d,%ebp
   64203:	test   %rax,%rax
   64206:	je     64250 <f.16+0x290>
   64208:	mov    %r8d,%ebp
   6420b:	cmp    $0x2e,%rax
   6420f:	je     64250 <f.16+0x290>
   64211:	mov    0x168(%rdx),%r10
   64218:	mov    %rax,%r11
   6421b:	shr    $0x2,%r11
   6421f:	lea    -0x1(%r11),%rbx
   64223:	cmp    %r10,%rbx
   64226:	jae    64347 <f.16+0x387>
   6422c:	mov    0x160(%rdx),%rbx
   64233:	mov    -0x8(%rbx,%r11,8),%r11
   64238:	cmp    $0x2e,%r11
   6423c:	sete   %bpl
   64240:	test   %r11,%r11
   64243:	je     64250 <f.16+0x290>
   64245:	cmp    $0x2e,%r11
   64249:	jne    64320 <f.16+0x360>
   6424f:	nop
   64250:	test   %bpl,%bpl
   64253:	je     64347 <f.16+0x387>
   64259:	cmpq   $0x0,0x10(%r9)
   6425e:	je     64347 <f.16+0x387>
   64264:	test   %rax,%rax
   64267:	je     64070 <f.16+0xb0>
   6426d:	cmp    $0x2e,%rax
   64271:	je     64070 <f.16+0xb0>
   64277:	mov    0x168(%rdx),%r9
   6427e:	mov    %rax,%r8
   64281:	shr    $0x2,%r8
   64285:	lea    -0x1(%r8),%r10
   64289:	cmp    %r9,%r10
   6428c:	jae    64347 <f.16+0x387>
   64292:	mov    0x160(%rdx),%r11
   64299:	mov    -0x8(%r11,%r8,8),%r10
   6429e:	cmp    $0x2e,%r10
   642a2:	sete   %r8b
   642a6:	test   %r10,%r10
   642a9:	je     64070 <f.16+0xb0>
   642af:	cmp    $0x2e,%r10
   642b3:	je     64070 <f.16+0xb0>
   642b9:	nopl   0x0(%rax)
   642c0:	shr    $0x2,%r10
   642c4:	lea    -0x1(%r10),%r8
   642c8:	cmp    %r9,%r8
   642cb:	jae    64347 <f.16+0x387>
   642cd:	mov    -0x8(%r11,%r10,8),%r10
   642d2:	cmp    $0x2e,%r10
   642d6:	je     642dd <f.16+0x31d>
   642d8:	test   %r10,%r10
   642db:	jne    642c0 <f.16+0x300>
   642dd:	cmp    $0x2e,%r10
   642e1:	je     64079 <f.16+0xb9>
   642e7:	jmp    64347 <f.16+0x387>
   642e9:	nopl   0x0(%rax)
   642f0:	shr    $0x2,%r10
   642f4:	lea    -0x1(%r10),%rbx
   642f8:	cmp    %r9,%rbx
   642fb:	jae    64347 <f.16+0x387>
   642fd:	mov    -0x8(%r11,%r10,8),%r10
   64302:	cmp    $0x2e,%r10
   64306:	je     6430d <f.16+0x34d>
   64308:	test   %r10,%r10
   6430b:	jne    642f0 <f.16+0x330>
   6430d:	cmp    $0x2e,%r10
   64311:	je     641e8 <f.16+0x228>
   64317:	jmp    64347 <f.16+0x387>
   64319:	nopl   0x0(%rax)
   64320:	shr    $0x2,%r11
   64324:	lea    -0x1(%r11),%r14
   64328:	cmp    %r10,%r14
   6432b:	jae    64347 <f.16+0x387>
   6432d:	mov    -0x8(%rbx,%r11,8),%r11
   64332:	cmp    $0x2e,%r11
   64336:	je     6433d <f.16+0x37d>
   64338:	test   %r11,%r11
   6433b:	jne    64320 <f.16+0x360>
   6433d:	cmp    $0x2e,%r11
   64341:	je     64259 <f.16+0x299>
   64347:	call   56d70 <native_trap>
   6434c:	xor    %eax,%eax
   6434e:	pop    %rbx
   6434f:	pop    %r14
   64351:	pop    %rbp
   64352:	ret    $0x8
   64355:	int3
   64356:	int3
   64357:	int3
   64358:	int3
   64359:	int3
   6435a:	int3
   6435b:	int3
   6435c:	int3
   6435d:	int3
   6435e:	int3
   6435f:	int3
