   5b930:	push   %rbp
   5b931:	push   %r15
   5b933:	push   %r14
   5b935:	push   %r13
   5b937:	push   %r12
   5b939:	push   %rbx
   5b93a:	sub    $0xf8,%rsp
   5b941:	movq   $0xf,0x50(%rsp)
   5b94a:	mov    0xeecf(%rip),%rax        # 6a820 <native_roots.0>
   5b951:	mov    %rax,0x48(%rsp)
   5b956:	mov    0xeea3(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5b95d:	inc    %rax
   5b960:	mov    %rax,0xee99(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5b967:	mov    0xee9a(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5b96e:	cmp    %rcx,%rax
   5b971:	cmovbe %rcx,%rax
   5b975:	lea    0x48(%rsp),%r15
   5b97a:	mov    %r15,0xee9f(%rip)        # 6a820 <native_roots.0>
   5b981:	mov    %rax,0xee80(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5b988:	mov    %rdi,0x60(%rsp)
   5b98d:	pxor   %xmm0,%xmm0
   5b991:	movdqu %xmm0,0x68(%rsp)
   5b997:	movdqu %xmm0,0x78(%rsp)
   5b99d:	movdqu %xmm0,0x88(%rsp)
   5b9a6:	movq   $0x0,0x98(%rsp)
   5b9b2:	movq   $0x8,0x58(%rsp)
   5b9bb:	mov    0xee56(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5b9c2:	test   %r14,%r14
   5b9c5:	je     5e600 <f.8+0x2cd0>
   5b9cb:	mov    0x178(%r14),%rcx
   5b9d2:	test   %rcx,%rcx
   5b9d5:	je     5ba16 <f.8+0xe6>
   5b9d7:	mov    0x170(%r14),%rax
   5b9de:	inc    %rax
   5b9e1:	mov    %rax,0x170(%r14)
   5b9e8:	mov    %rax,%rdx
   5b9eb:	or     %rcx,%rdx
   5b9ee:	shr    $0x20,%rdx
   5b9f2:	je     5cdc9 <f.8+0x1499>
   5b9f8:	xor    %edx,%edx
   5b9fa:	div    %rcx
   5b9fd:	test   %rdx,%rdx
   5ba00:	jne    5ba16 <f.8+0xe6>
   5ba02:	lea    0x48(%rsp),%rsi
   5ba07:	mov    %r14,%rdi
   5ba0a:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ba0f:	mov    0xee0a(%rip),%r15        # 6a820 <native_roots.0>
   5ba16:	cmpq   $0x20,0x98(%r14)
   5ba1e:	jb     5e605 <f.8+0x2cd5>
   5ba24:	mov    0xe0(%r14),%r12
   5ba2b:	mov    0xe8(%r14),%r13
   5ba32:	cmp    %r13,%r12
   5ba35:	jb     5ba42 <f.8+0x112>
   5ba37:	mov    %r14,%rdi
   5ba3a:	mov    %r15,%rsi
   5ba3d:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ba42:	mov    0xc8(%r14),%rbx
   5ba49:	test   %rbx,%rbx
   5ba4c:	je     5ba5e <f.8+0x12e>
   5ba4e:	mov    0xd0(%r14),%rax
   5ba55:	sub    %rbx,%rax
   5ba58:	cmp    $0x1f,%rax
   5ba5c:	ja     5ba82 <f.8+0x152>
   5ba5e:	mov    $0x20,%esi
   5ba63:	mov    %r14,%rdi
   5ba66:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5ba6b:	mov    %rdx,%rbx
   5ba6e:	cmp    $0x1,%rax
   5ba72:	jne    5bafd <f.8+0x1cd>
   5ba78:	mov    $0x1,%eax
   5ba7d:	jmp    5bb18 <f.8+0x1e8>
   5ba82:	lea    0x20(%rbx),%rax
   5ba86:	mov    %rax,0xc8(%r14)
   5ba8d:	mov    0x10(%r14),%rsi
   5ba91:	mov    0xc0(%r14),%rdi
   5ba98:	cmp    %rsi,%rdi
   5ba9b:	jae    5e616 <f.8+0x2ce6>
   5baa1:	mov    0x8(%r14),%rax
   5baa5:	imul   $0x38,%rdi,%rcx
   5baa9:	mov    %rbx,%rdx
   5baac:	sub    0x18(%rax,%rcx,1),%rdx
   5bab1:	mov    %rdx,%rdi
   5bab4:	shr    $0xf,%rdi
   5bab8:	mov    0x10(%rax,%rcx,1),%rsi
   5babd:	cmp    %rsi,%rdi
   5bac0:	jae    5e622 <f.8+0x2cf2>
   5bac6:	add    %rcx,%rax
   5bac9:	mov    %edx,%ecx
   5bacb:	imul   $0x220,%rdi,%rsi
   5bad2:	add    0x8(%rax),%rsi
   5bad6:	shr    $0x4,%ecx
   5bad9:	mov    $0x1,%eax
   5bade:	mov    $0x1,%edi
   5bae3:	shl    %cl,%rdi
   5bae6:	shr    $0x7,%edx
   5bae9:	and    $0xf8,%edx
   5baef:	or     %rdi,(%rdx,%rsi,1)
   5baf3:	cmp    $0x1,%rax
   5baf7:	je     5ba78 <f.8+0x148>
   5bafd:	xor    %edx,%edx
   5baff:	cmp    %r13,%r12
   5bb02:	setae  %dl
   5bb05:	mov    $0x20,%esi
   5bb0a:	mov    %r14,%rdi
   5bb0d:	mov    %r15,%rcx
   5bb10:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5bb15:	mov    %rdx,%rbx
   5bb18:	test   $0x1,%al
   5bb1a:	je     5e605 <f.8+0x2cd5>
   5bb20:	movq   $0x61,(%rbx)
   5bb27:	lea    0x8(%rbx),%r12
   5bb2b:	pxor   %xmm0,%xmm0
   5bb2f:	movdqu %xmm0,0x8(%rbx)
   5bb34:	movq   $0x0,0x18(%rbx)
   5bb3c:	addq   $0x20,0xe0(%r14)
   5bb44:	movdqu 0x110(%r14),%xmm0
   5bb4d:	paddq  -0x57665(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5bb55:	movdqu %xmm0,0x110(%r14)
   5bb5e:	movq   $0x56,0x8(%rbx)
   5bb66:	movl   $0x0,0x10(%rbx)
   5bb6d:	movq   $0x0,0x18(%rbx)
   5bb75:	mov    %r12,0x70(%rsp)
   5bb7a:	mov    %r12,0xa0(%rsp)
   5bb82:	mov    %r12,0xa8(%rsp)
   5bb8a:	movq   $0xa,0x58(%rsp)
   5bb93:	mov    0xec7e(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5bb9a:	test   %r14,%r14
   5bb9d:	je     5e600 <f.8+0x2cd0>
   5bba3:	mov    0x178(%r14),%rcx
   5bbaa:	test   %rcx,%rcx
   5bbad:	je     5bbe9 <f.8+0x2b9>
   5bbaf:	mov    0x170(%r14),%rax
   5bbb6:	inc    %rax
   5bbb9:	mov    %rax,0x170(%r14)
   5bbc0:	mov    %rax,%rdx
   5bbc3:	or     %rcx,%rdx
   5bbc6:	shr    $0x20,%rdx
   5bbca:	je     5cddb <f.8+0x14ab>
   5bbd0:	xor    %edx,%edx
   5bbd2:	div    %rcx
   5bbd5:	test   %rdx,%rdx
   5bbd8:	jne    5bbe9 <f.8+0x2b9>
   5bbda:	mov    0xec3f(%rip),%rsi        # 6a820 <native_roots.0>
   5bbe1:	mov    %r14,%rdi
   5bbe4:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5bbe9:	cmpq   $0x20,0x98(%r14)
   5bbf1:	jb     5e605 <f.8+0x2cd5>
   5bbf7:	mov    0xec22(%rip),%r15        # 6a820 <native_roots.0>
   5bbfe:	mov    0xe0(%r14),%r13
   5bc05:	mov    0xe8(%r14),%rbp
   5bc0c:	cmp    %rbp,%r13
   5bc0f:	jb     5bc1c <f.8+0x2ec>
   5bc11:	mov    %r14,%rdi
   5bc14:	mov    %r15,%rsi
   5bc17:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5bc1c:	mov    0xc8(%r14),%rdx
   5bc23:	test   %rdx,%rdx
   5bc26:	je     5bc38 <f.8+0x308>
   5bc28:	mov    0xd0(%r14),%rax
   5bc2f:	sub    %rdx,%rax
   5bc32:	cmp    $0x1f,%rax
   5bc36:	ja     5bc59 <f.8+0x329>
   5bc38:	mov    $0x20,%esi
   5bc3d:	mov    %r14,%rdi
   5bc40:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5bc45:	cmp    $0x1,%rax
   5bc49:	jne    5bcd7 <f.8+0x3a7>
   5bc4f:	mov    $0x1,%eax
   5bc54:	jmp    5bcef <f.8+0x3bf>
   5bc59:	lea    0x20(%rdx),%rax
   5bc5d:	mov    %rax,0xc8(%r14)
   5bc64:	mov    0x10(%r14),%rsi
   5bc68:	mov    0xc0(%r14),%rdi
   5bc6f:	cmp    %rsi,%rdi
   5bc72:	jae    5e616 <f.8+0x2ce6>
   5bc78:	mov    0x8(%r14),%rax
   5bc7c:	imul   $0x38,%rdi,%rcx
   5bc80:	mov    %rdx,%r8
   5bc83:	sub    0x18(%rax,%rcx,1),%r8
   5bc88:	mov    %r8,%rdi
   5bc8b:	shr    $0xf,%rdi
   5bc8f:	mov    0x10(%rax,%rcx,1),%rsi
   5bc94:	cmp    %rsi,%rdi
   5bc97:	jae    5e622 <f.8+0x2cf2>
   5bc9d:	add    %rcx,%rax
   5bca0:	mov    %r8d,%ecx
   5bca3:	imul   $0x220,%rdi,%rsi
   5bcaa:	add    0x8(%rax),%rsi
   5bcae:	shr    $0x4,%ecx
   5bcb1:	mov    $0x1,%eax
   5bcb6:	mov    $0x1,%edi
   5bcbb:	shl    %cl,%rdi
   5bcbe:	shr    $0x7,%r8d
   5bcc2:	and    $0xf8,%r8d
   5bcc9:	or     %rdi,(%r8,%rsi,1)
   5bccd:	cmp    $0x1,%rax
   5bcd1:	je     5bc4f <f.8+0x31f>
   5bcd7:	xor    %edx,%edx
   5bcd9:	cmp    %rbp,%r13
   5bcdc:	setae  %dl
   5bcdf:	mov    $0x20,%esi
   5bce4:	mov    %r14,%rdi
   5bce7:	mov    %r15,%rcx
   5bcea:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5bcef:	test   $0x1,%al
   5bcf1:	je     5e605 <f.8+0x2cd5>
   5bcf7:	movq   $0x41,(%rdx)
   5bcfe:	pxor   %xmm0,%xmm0
   5bd02:	movdqu %xmm0,0x8(%rdx)
   5bd07:	addq   $0x20,0xe0(%r14)
   5bd0f:	lea    0x8(%rdx),%r13
   5bd13:	movdqu 0x110(%r14),%xmm0
   5bd1c:	paddq  -0x577d4(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5bd24:	movdqu %xmm0,0x110(%r14)
   5bd2d:	movq   $0x4a,0x8(%rdx)
   5bd35:	mov    %r12,0x10(%rdx)
   5bd39:	mov    %r13,0xa0(%rsp)
   5bd41:	mov    %r12,0xa8(%rsp)
   5bd49:	movq   $0xa,0x58(%rsp)
   5bd52:	mov    0xeabf(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5bd59:	test   %r14,%r14
   5bd5c:	je     5e600 <f.8+0x2cd0>
   5bd62:	mov    0x178(%r14),%rcx
   5bd69:	test   %rcx,%rcx
   5bd6c:	je     5bda8 <f.8+0x478>
   5bd6e:	mov    0x170(%r14),%rax
   5bd75:	inc    %rax
   5bd78:	mov    %rax,0x170(%r14)
   5bd7f:	mov    %rax,%rdx
   5bd82:	or     %rcx,%rdx
   5bd85:	shr    $0x20,%rdx
   5bd89:	je     5cded <f.8+0x14bd>
   5bd8f:	xor    %edx,%edx
   5bd91:	div    %rcx
   5bd94:	test   %rdx,%rdx
   5bd97:	jne    5bda8 <f.8+0x478>
   5bd99:	mov    0xea80(%rip),%rsi        # 6a820 <native_roots.0>
   5bda0:	mov    %r14,%rdi
   5bda3:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5bda8:	cmpq   $0x20,0x98(%r14)
   5bdb0:	jb     5e605 <f.8+0x2cd5>
   5bdb6:	mov    0xea63(%rip),%r15        # 6a820 <native_roots.0>
   5bdbd:	mov    0xe0(%r14),%r12
   5bdc4:	mov    0xe8(%r14),%rbp
   5bdcb:	cmp    %rbp,%r12
   5bdce:	jb     5bddb <f.8+0x4ab>
   5bdd0:	mov    %r14,%rdi
   5bdd3:	mov    %r15,%rsi
   5bdd6:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5bddb:	mov    0xc8(%r14),%rdx
   5bde2:	test   %rdx,%rdx
   5bde5:	je     5bdf7 <f.8+0x4c7>
   5bde7:	mov    0xd0(%r14),%rax
   5bdee:	sub    %rdx,%rax
   5bdf1:	cmp    $0x1f,%rax
   5bdf5:	ja     5be18 <f.8+0x4e8>
   5bdf7:	mov    $0x20,%esi
   5bdfc:	mov    %r14,%rdi
   5bdff:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5be04:	cmp    $0x1,%rax
   5be08:	jne    5be96 <f.8+0x566>
   5be0e:	mov    $0x1,%eax
   5be13:	jmp    5beae <f.8+0x57e>
   5be18:	lea    0x20(%rdx),%rax
   5be1c:	mov    %rax,0xc8(%r14)
   5be23:	mov    0x10(%r14),%rsi
   5be27:	mov    0xc0(%r14),%rdi
   5be2e:	cmp    %rsi,%rdi
   5be31:	jae    5e616 <f.8+0x2ce6>
   5be37:	mov    0x8(%r14),%rax
   5be3b:	imul   $0x38,%rdi,%rcx
   5be3f:	mov    %rdx,%r8
   5be42:	sub    0x18(%rax,%rcx,1),%r8
   5be47:	mov    %r8,%rdi
   5be4a:	shr    $0xf,%rdi
   5be4e:	mov    0x10(%rax,%rcx,1),%rsi
   5be53:	cmp    %rsi,%rdi
   5be56:	jae    5e622 <f.8+0x2cf2>
   5be5c:	add    %rcx,%rax
   5be5f:	mov    %r8d,%ecx
   5be62:	imul   $0x220,%rdi,%rsi
   5be69:	add    0x8(%rax),%rsi
   5be6d:	shr    $0x4,%ecx
   5be70:	mov    $0x1,%eax
   5be75:	mov    $0x1,%edi
   5be7a:	shl    %cl,%rdi
   5be7d:	shr    $0x7,%r8d
   5be81:	and    $0xf8,%r8d
   5be88:	or     %rdi,(%r8,%rsi,1)
   5be8c:	cmp    $0x1,%rax
   5be90:	je     5be0e <f.8+0x4de>
   5be96:	xor    %edx,%edx
   5be98:	cmp    %rbp,%r12
   5be9b:	setae  %dl
   5be9e:	mov    $0x20,%esi
   5bea3:	mov    %r14,%rdi
   5bea6:	mov    %r15,%rcx
   5bea9:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5beae:	test   $0x1,%al
   5beb0:	je     5e605 <f.8+0x2cd5>
   5beb6:	movq   $0x41,(%rdx)
   5bebd:	lea    0x8(%rdx),%rax
   5bec1:	pxor   %xmm0,%xmm0
   5bec5:	movdqu %xmm0,0x8(%rdx)
   5beca:	addq   $0x20,0xe0(%r14)
   5bed2:	movdqu 0x110(%r14),%xmm0
   5bedb:	paddq  -0x57993(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5bee3:	movdqu %xmm0,0x110(%r14)
   5beec:	movq   $0x42,0x8(%rdx)
   5bef4:	mov    %r13,0x10(%rdx)
   5bef8:	mov    %rax,0x18(%rbx)
   5befc:	mov    0x70(%rsp),%rax
   5bf01:	test   %rax,%rax
   5bf04:	je     5e600 <f.8+0x2cd0>
   5bf0a:	movl   $0x1,0x8(%rax)
   5bf11:	movq   $0x8,0x58(%rsp)
   5bf1a:	mov    0xe8f7(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5bf21:	test   %r14,%r14
   5bf24:	je     5e600 <f.8+0x2cd0>
   5bf2a:	mov    0x178(%r14),%rcx
   5bf31:	test   %rcx,%rcx
   5bf34:	je     5bf70 <f.8+0x640>
   5bf36:	mov    0x170(%r14),%rax
   5bf3d:	inc    %rax
   5bf40:	mov    %rax,0x170(%r14)
   5bf47:	mov    %rax,%rdx
   5bf4a:	or     %rcx,%rdx
   5bf4d:	shr    $0x20,%rdx
   5bf51:	je     5cdff <f.8+0x14cf>
   5bf57:	xor    %edx,%edx
   5bf59:	div    %rcx
   5bf5c:	test   %rdx,%rdx
   5bf5f:	jne    5bf70 <f.8+0x640>
   5bf61:	mov    0xe8b8(%rip),%rsi        # 6a820 <native_roots.0>
   5bf68:	mov    %r14,%rdi
   5bf6b:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5bf70:	cmpq   $0x20,0x98(%r14)
   5bf78:	jb     5e605 <f.8+0x2cd5>
   5bf7e:	mov    0xe89b(%rip),%r15        # 6a820 <native_roots.0>
   5bf85:	mov    0xe0(%r14),%r12
   5bf8c:	mov    0xe8(%r14),%r13
   5bf93:	cmp    %r13,%r12
   5bf96:	jb     5bfa3 <f.8+0x673>
   5bf98:	mov    %r14,%rdi
   5bf9b:	mov    %r15,%rsi
   5bf9e:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5bfa3:	mov    0xc8(%r14),%rbx
   5bfaa:	test   %rbx,%rbx
   5bfad:	je     5bfbf <f.8+0x68f>
   5bfaf:	mov    0xd0(%r14),%rax
   5bfb6:	sub    %rbx,%rax
   5bfb9:	cmp    $0x1f,%rax
   5bfbd:	ja     5bfe3 <f.8+0x6b3>
   5bfbf:	mov    $0x20,%esi
   5bfc4:	mov    %r14,%rdi
   5bfc7:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5bfcc:	mov    %rdx,%rbx
   5bfcf:	cmp    $0x1,%rax
   5bfd3:	jne    5c05e <f.8+0x72e>
   5bfd9:	mov    $0x1,%eax
   5bfde:	jmp    5c079 <f.8+0x749>
   5bfe3:	lea    0x20(%rbx),%rax
   5bfe7:	mov    %rax,0xc8(%r14)
   5bfee:	mov    0x10(%r14),%rsi
   5bff2:	mov    0xc0(%r14),%rdi
   5bff9:	cmp    %rsi,%rdi
   5bffc:	jae    5e616 <f.8+0x2ce6>
   5c002:	mov    0x8(%r14),%rax
   5c006:	imul   $0x38,%rdi,%rcx
   5c00a:	mov    %rbx,%rdx
   5c00d:	sub    0x18(%rax,%rcx,1),%rdx
   5c012:	mov    %rdx,%rdi
   5c015:	shr    $0xf,%rdi
   5c019:	mov    0x10(%rax,%rcx,1),%rsi
   5c01e:	cmp    %rsi,%rdi
   5c021:	jae    5e622 <f.8+0x2cf2>
   5c027:	add    %rcx,%rax
   5c02a:	mov    %edx,%ecx
   5c02c:	imul   $0x220,%rdi,%rsi
   5c033:	add    0x8(%rax),%rsi
   5c037:	shr    $0x4,%ecx
   5c03a:	mov    $0x1,%eax
   5c03f:	mov    $0x1,%edi
   5c044:	shl    %cl,%rdi
   5c047:	shr    $0x7,%edx
   5c04a:	and    $0xf8,%edx
   5c050:	or     %rdi,(%rdx,%rsi,1)
   5c054:	cmp    $0x1,%rax
   5c058:	je     5bfd9 <f.8+0x6a9>
   5c05e:	xor    %edx,%edx
   5c060:	cmp    %r13,%r12
   5c063:	setae  %dl
   5c066:	mov    $0x20,%esi
   5c06b:	mov    %r14,%rdi
   5c06e:	mov    %r15,%rcx
   5c071:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5c076:	mov    %rdx,%rbx
   5c079:	test   $0x1,%al
   5c07b:	je     5e605 <f.8+0x2cd5>
   5c081:	movq   $0x61,(%rbx)
   5c088:	lea    0x8(%rbx),%r12
   5c08c:	pxor   %xmm0,%xmm0
   5c090:	movdqu %xmm0,0x8(%rbx)
   5c095:	movq   $0x0,0x18(%rbx)
   5c09d:	addq   $0x20,0xe0(%r14)
   5c0a5:	movdqu 0x110(%r14),%xmm0
   5c0ae:	paddq  -0x57bc6(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5c0b6:	movdqu %xmm0,0x110(%r14)
   5c0bf:	movq   $0x52,0x8(%rbx)
   5c0c7:	movl   $0x0,0x10(%rbx)
   5c0ce:	movq   $0x0,0x18(%rbx)
   5c0d6:	mov    %r12,0x78(%rsp)
   5c0db:	mov    %r12,0xa0(%rsp)
   5c0e3:	mov    %r12,0xa8(%rsp)
   5c0eb:	movq   $0xa,0x58(%rsp)
   5c0f4:	mov    0xe71d(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5c0fb:	test   %r14,%r14
   5c0fe:	je     5e600 <f.8+0x2cd0>
   5c104:	mov    0x178(%r14),%rcx
   5c10b:	test   %rcx,%rcx
   5c10e:	je     5c14a <f.8+0x81a>
   5c110:	mov    0x170(%r14),%rax
   5c117:	inc    %rax
   5c11a:	mov    %rax,0x170(%r14)
   5c121:	mov    %rax,%rdx
   5c124:	or     %rcx,%rdx
   5c127:	shr    $0x20,%rdx
   5c12b:	je     5ce11 <f.8+0x14e1>
   5c131:	xor    %edx,%edx
   5c133:	div    %rcx
   5c136:	test   %rdx,%rdx
   5c139:	jne    5c14a <f.8+0x81a>
   5c13b:	mov    0xe6de(%rip),%rsi        # 6a820 <native_roots.0>
   5c142:	mov    %r14,%rdi
   5c145:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c14a:	cmpq   $0x20,0x98(%r14)
   5c152:	jb     5e605 <f.8+0x2cd5>
   5c158:	mov    0xe6c1(%rip),%r15        # 6a820 <native_roots.0>
   5c15f:	mov    0xe0(%r14),%r13
   5c166:	mov    0xe8(%r14),%rbp
   5c16d:	cmp    %rbp,%r13
   5c170:	jb     5c17d <f.8+0x84d>
   5c172:	mov    %r14,%rdi
   5c175:	mov    %r15,%rsi
   5c178:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c17d:	mov    0xc8(%r14),%rdx
   5c184:	test   %rdx,%rdx
   5c187:	je     5c199 <f.8+0x869>
   5c189:	mov    0xd0(%r14),%rax
   5c190:	sub    %rdx,%rax
   5c193:	cmp    $0x1f,%rax
   5c197:	ja     5c1ba <f.8+0x88a>
   5c199:	mov    $0x20,%esi
   5c19e:	mov    %r14,%rdi
   5c1a1:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5c1a6:	cmp    $0x1,%rax
   5c1aa:	jne    5c238 <f.8+0x908>
   5c1b0:	mov    $0x1,%eax
   5c1b5:	jmp    5c250 <f.8+0x920>
   5c1ba:	lea    0x20(%rdx),%rax
   5c1be:	mov    %rax,0xc8(%r14)
   5c1c5:	mov    0x10(%r14),%rsi
   5c1c9:	mov    0xc0(%r14),%rdi
   5c1d0:	cmp    %rsi,%rdi
   5c1d3:	jae    5e616 <f.8+0x2ce6>
   5c1d9:	mov    0x8(%r14),%rax
   5c1dd:	imul   $0x38,%rdi,%rcx
   5c1e1:	mov    %rdx,%r8
   5c1e4:	sub    0x18(%rax,%rcx,1),%r8
   5c1e9:	mov    %r8,%rdi
   5c1ec:	shr    $0xf,%rdi
   5c1f0:	mov    0x10(%rax,%rcx,1),%rsi
   5c1f5:	cmp    %rsi,%rdi
   5c1f8:	jae    5e622 <f.8+0x2cf2>
   5c1fe:	add    %rcx,%rax
   5c201:	mov    %r8d,%ecx
   5c204:	imul   $0x220,%rdi,%rsi
   5c20b:	add    0x8(%rax),%rsi
   5c20f:	shr    $0x4,%ecx
   5c212:	mov    $0x1,%eax
   5c217:	mov    $0x1,%edi
   5c21c:	shl    %cl,%rdi
   5c21f:	shr    $0x7,%r8d
   5c223:	and    $0xf8,%r8d
   5c22a:	or     %rdi,(%r8,%rsi,1)
   5c22e:	cmp    $0x1,%rax
   5c232:	je     5c1b0 <f.8+0x880>
   5c238:	xor    %edx,%edx
   5c23a:	cmp    %rbp,%r13
   5c23d:	setae  %dl
   5c240:	mov    $0x20,%esi
   5c245:	mov    %r14,%rdi
   5c248:	mov    %r15,%rcx
   5c24b:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5c250:	test   $0x1,%al
   5c252:	je     5e605 <f.8+0x2cd5>
   5c258:	movq   $0x41,(%rdx)
   5c25f:	pxor   %xmm0,%xmm0
   5c263:	movdqu %xmm0,0x8(%rdx)
   5c268:	addq   $0x20,0xe0(%r14)
   5c270:	lea    0x8(%rdx),%r13
   5c274:	movdqu 0x110(%r14),%xmm0
   5c27d:	paddq  -0x57d35(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5c285:	movdqu %xmm0,0x110(%r14)
   5c28e:	movq   $0x3e,0x8(%rdx)
   5c296:	mov    %r12,0x10(%rdx)
   5c29a:	mov    %r13,0xa0(%rsp)
   5c2a2:	mov    %r12,0xa8(%rsp)
   5c2aa:	movq   $0xa,0x58(%rsp)
   5c2b3:	mov    0xe55e(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5c2ba:	test   %r14,%r14
   5c2bd:	je     5e600 <f.8+0x2cd0>
   5c2c3:	mov    0x178(%r14),%rcx
   5c2ca:	test   %rcx,%rcx
   5c2cd:	je     5c309 <f.8+0x9d9>
   5c2cf:	mov    0x170(%r14),%rax
   5c2d6:	inc    %rax
   5c2d9:	mov    %rax,0x170(%r14)
   5c2e0:	mov    %rax,%rdx
   5c2e3:	or     %rcx,%rdx
   5c2e6:	shr    $0x20,%rdx
   5c2ea:	je     5ce23 <f.8+0x14f3>
   5c2f0:	xor    %edx,%edx
   5c2f2:	div    %rcx
   5c2f5:	test   %rdx,%rdx
   5c2f8:	jne    5c309 <f.8+0x9d9>
   5c2fa:	mov    0xe51f(%rip),%rsi        # 6a820 <native_roots.0>
   5c301:	mov    %r14,%rdi
   5c304:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c309:	cmpq   $0x20,0x98(%r14)
   5c311:	jb     5e605 <f.8+0x2cd5>
   5c317:	mov    0xe502(%rip),%r15        # 6a820 <native_roots.0>
   5c31e:	mov    0xe0(%r14),%r12
   5c325:	mov    0xe8(%r14),%rbp
   5c32c:	cmp    %rbp,%r12
   5c32f:	jb     5c33c <f.8+0xa0c>
   5c331:	mov    %r14,%rdi
   5c334:	mov    %r15,%rsi
   5c337:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c33c:	mov    0xc8(%r14),%rdx
   5c343:	test   %rdx,%rdx
   5c346:	je     5c358 <f.8+0xa28>
   5c348:	mov    0xd0(%r14),%rax
   5c34f:	sub    %rdx,%rax
   5c352:	cmp    $0x1f,%rax
   5c356:	ja     5c379 <f.8+0xa49>
   5c358:	mov    $0x20,%esi
   5c35d:	mov    %r14,%rdi
   5c360:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5c365:	cmp    $0x1,%rax
   5c369:	jne    5c3f7 <f.8+0xac7>
   5c36f:	mov    $0x1,%eax
   5c374:	jmp    5c40f <f.8+0xadf>
   5c379:	lea    0x20(%rdx),%rax
   5c37d:	mov    %rax,0xc8(%r14)
   5c384:	mov    0x10(%r14),%rsi
   5c388:	mov    0xc0(%r14),%rdi
   5c38f:	cmp    %rsi,%rdi
   5c392:	jae    5e616 <f.8+0x2ce6>
   5c398:	mov    0x8(%r14),%rax
   5c39c:	imul   $0x38,%rdi,%rcx
   5c3a0:	mov    %rdx,%r8
   5c3a3:	sub    0x18(%rax,%rcx,1),%r8
   5c3a8:	mov    %r8,%rdi
   5c3ab:	shr    $0xf,%rdi
   5c3af:	mov    0x10(%rax,%rcx,1),%rsi
   5c3b4:	cmp    %rsi,%rdi
   5c3b7:	jae    5e622 <f.8+0x2cf2>
   5c3bd:	add    %rcx,%rax
   5c3c0:	mov    %r8d,%ecx
   5c3c3:	imul   $0x220,%rdi,%rsi
   5c3ca:	add    0x8(%rax),%rsi
   5c3ce:	shr    $0x4,%ecx
   5c3d1:	mov    $0x1,%eax
   5c3d6:	mov    $0x1,%edi
   5c3db:	shl    %cl,%rdi
   5c3de:	shr    $0x7,%r8d
   5c3e2:	and    $0xf8,%r8d
   5c3e9:	or     %rdi,(%r8,%rsi,1)
   5c3ed:	cmp    $0x1,%rax
   5c3f1:	je     5c36f <f.8+0xa3f>
   5c3f7:	xor    %edx,%edx
   5c3f9:	cmp    %rbp,%r12
   5c3fc:	setae  %dl
   5c3ff:	mov    $0x20,%esi
   5c404:	mov    %r14,%rdi
   5c407:	mov    %r15,%rcx
   5c40a:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5c40f:	test   $0x1,%al
   5c411:	je     5e605 <f.8+0x2cd5>
   5c417:	movq   $0x41,(%rdx)
   5c41e:	lea    0x8(%rdx),%rax
   5c422:	pxor   %xmm0,%xmm0
   5c426:	movdqu %xmm0,0x8(%rdx)
   5c42b:	addq   $0x20,0xe0(%r14)
   5c433:	movdqu 0x110(%r14),%xmm0
   5c43c:	paddq  -0x57ef4(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5c444:	movdqu %xmm0,0x110(%r14)
   5c44d:	movq   $0x3a,0x8(%rdx)
   5c455:	mov    %r13,0x10(%rdx)
   5c459:	mov    %rax,0x18(%rbx)
   5c45d:	mov    0x78(%rsp),%rax
   5c462:	test   %rax,%rax
   5c465:	je     5e600 <f.8+0x2cd0>
   5c46b:	movl   $0x1,0x8(%rax)
   5c472:	movq   $0x8,0x58(%rsp)
   5c47b:	lea    0xa32e(%rip),%rax        # 667b0 <__cxa_atexit@plt+0x10f0>
   5c482:	mov    %rax,0x10(%rsp)
   5c487:	lea    0xa2f2(%rip),%r15        # 66780 <__cxa_atexit@plt+0x10c0>
   5c48e:	lea    -0x4205(%rip),%r12        # 58290 <<&T as core::fmt::Display>::fmt>
   5c495:	mov    %r12,0x18(%rsp)
   5c49a:	lea    -0x55c08(%rip),%rbx        # 6899 <__abi_tag+0x6565>
   5c4a1:	lea    0x10(%rsp),%rsi
   5c4a6:	mov    %rbx,%rdi
   5c4a9:	call   4f6f0 <std::io::stdio::_print>
   5c4ae:	movq   $0x8,0x58(%rsp)
   5c4b7:	mov    %r15,0x10(%rsp)
   5c4bc:	mov    %r12,0x18(%rsp)
   5c4c1:	lea    0x10(%rsp),%rsi
   5c4c6:	mov    %rbx,%rdi
   5c4c9:	call   4f6f0 <std::io::stdio::_print>
   5c4ce:	mov    0x60(%rsp),%rax
   5c4d3:	test   %rax,%rax
   5c4d6:	je     5e600 <f.8+0x2cd0>
   5c4dc:	mov    0x8(%rax),%rbx
   5c4e0:	movq   $0x8,0x58(%rsp)
   5c4e9:	mov    %rbx,0xe0(%rsp)
   5c4f1:	lea    0xa228(%rip),%rax        # 66720 <__cxa_atexit@plt+0x1060>
   5c4f8:	mov    %rax,0x10(%rsp)
   5c4fd:	mov    %r12,0x18(%rsp)
   5c502:	lea    0xe0(%rsp),%r13
   5c50a:	mov    %r13,0x20(%rsp)
   5c50f:	lea    -0xcf86(%rip),%rbp        # 4f590 <<i64 as core::fmt::Display>::fmt>
   5c516:	mov    %rbp,0x28(%rsp)
   5c51b:	lea    0xa22e(%rip),%rax        # 66750 <__cxa_atexit@plt+0x1090>
   5c522:	mov    %rax,0x30(%rsp)
   5c527:	mov    %r12,0x38(%rsp)
   5c52c:	lea    -0x5575c(%rip),%rdi        # 6dd7 <__abi_tag+0x6aa3>
   5c533:	lea    0x10(%rsp),%rsi
   5c538:	call   4f6f0 <std::io::stdio::_print>
   5c53d:	movq   $0x8,0x58(%rsp)
   5c546:	mov    %r15,0x10(%rsp)
   5c54b:	mov    %r12,0x18(%rsp)
   5c550:	lea    -0x55cbe(%rip),%rdi        # 6899 <__abi_tag+0x6565>
   5c557:	lea    0x10(%rsp),%rsi
   5c55c:	call   4f6f0 <std::io::stdio::_print>
   5c561:	cmpb   $0x0,0xe440(%rip)        # 6a9a8 <g.25>
   5c568:	je     5e600 <f.8+0x2cd0>
   5c56e:	cmpq   $0x0,0xe42a(%rip)        # 6a9a0 <g.24>
   5c576:	je     5e600 <f.8+0x2cd0>
   5c57c:	movq   $0x8,0x58(%rsp)
   5c585:	lea    0xa204(%rip),%rax        # 66790 <__cxa_atexit@plt+0x10d0>
   5c58c:	mov    %rax,0x10(%rsp)
   5c591:	mov    %r12,0x18(%rsp)
   5c596:	lea    -0x55d04(%rip),%r14        # 6899 <__abi_tag+0x6565>
   5c59d:	lea    0x10(%rsp),%rsi
   5c5a2:	mov    %r14,%rdi
   5c5a5:	call   4f6f0 <std::io::stdio::_print>
   5c5aa:	movq   $0x8,0x58(%rsp)
   5c5b3:	lea    0xa1e6(%rip),%rax        # 667a0 <__cxa_atexit@plt+0x10e0>
   5c5ba:	mov    %rax,0x10(%rsp)
   5c5bf:	mov    %r12,0x18(%rsp)
   5c5c4:	lea    0x10(%rsp),%rsi
   5c5c9:	mov    %r14,%rdi
   5c5cc:	call   4f6f0 <std::io::stdio::_print>
   5c5d1:	movq   $0x8,0x58(%rsp)
   5c5da:	mov    %r15,0x10(%rsp)
   5c5df:	mov    %r12,0x18(%rsp)
   5c5e4:	lea    0x10(%rsp),%rsi
   5c5e9:	mov    %r14,%rdi
   5c5ec:	call   4f6f0 <std::io::stdio::_print>
   5c5f1:	cmpb   $0x0,0xe3a0(%rip)        # 6a998 <g.23>
   5c5f8:	je     5e600 <f.8+0x2cd0>
   5c5fe:	cmpq   $0x0,0xe38a(%rip)        # 6a990 <g.22>
   5c606:	je     5e600 <f.8+0x2cd0>
   5c60c:	movq   $0x8,0x58(%rsp)
   5c615:	lea    0xa1c4(%rip),%rax        # 667e0 <__cxa_atexit@plt+0x1120>
   5c61c:	mov    %rax,0x10(%rsp)
   5c621:	mov    %r12,0x18(%rsp)
   5c626:	lea    -0x55d94(%rip),%r14        # 6899 <__abi_tag+0x6565>
   5c62d:	lea    0x10(%rsp),%rsi
   5c632:	mov    %r14,%rdi
   5c635:	call   4f6f0 <std::io::stdio::_print>
   5c63a:	movq   $0x8,0x58(%rsp)
   5c643:	mov    %r15,0x10(%rsp)
   5c648:	mov    %r12,0x18(%rsp)
   5c64d:	lea    0x10(%rsp),%rsi
   5c652:	mov    %r14,%rdi
   5c655:	call   4f6f0 <std::io::stdio::_print>
   5c65a:	mov    0x78(%rsp),%rax
   5c65f:	test   %rax,%rax
   5c662:	je     5e600 <f.8+0x2cd0>
   5c668:	cmpl   $0x0,0x8(%rax)
   5c66c:	je     5e600 <f.8+0x2cd0>
   5c672:	mov    0x10(%rax),%rax
   5c676:	test   %rax,%rax
   5c679:	je     5e600 <f.8+0x2cd0>
   5c67f:	mov    0x8(%rax),%rdi
   5c683:	mov    %rdi,0xa0(%rsp)
   5c68b:	movq   $0x9,0x58(%rsp)
   5c694:	mov    %rbx,%rsi
   5c697:	call   5e630 <f.18>
   5c69c:	sub    $0x8,%rsp
   5c6a0:	mov    0x60(%rsp),%rax
   5c6a5:	test   %rax,%rax
   5c6a8:	je     5e600 <f.8+0x2cd0>
   5c6ae:	mov    0x10(%rax),%rax
   5c6b2:	movq   $0x8,0x58(%rsp)
   5c6bb:	mov    %rax,0xe8(%rsp)
   5c6c3:	mov    %rax,0xe0(%rsp)
   5c6cb:	lea    0xa05e(%rip),%rax        # 66730 <__cxa_atexit@plt+0x1070>
   5c6d2:	mov    %rax,0x10(%rsp)
   5c6d7:	mov    %r12,0x18(%rsp)
   5c6dc:	mov    %r13,0x20(%rsp)
   5c6e1:	mov    %rbp,0x28(%rsp)
   5c6e6:	lea    0xa073(%rip),%rax        # 66760 <__cxa_atexit@plt+0x10a0>
   5c6ed:	mov    %rax,0x30(%rsp)
   5c6f2:	mov    %r12,0x38(%rsp)
   5c6f7:	lea    -0x55927(%rip),%rdi        # 6dd7 <__abi_tag+0x6aa3>
   5c6fe:	lea    0x10(%rsp),%rsi
   5c703:	call   4f6f0 <std::io::stdio::_print>
   5c708:	movq   $0x8,0x58(%rsp)
   5c711:	mov    %r15,0x10(%rsp)
   5c716:	mov    %r12,0x18(%rsp)
   5c71b:	lea    -0x55e89(%rip),%rdi        # 6899 <__abi_tag+0x6565>
   5c722:	lea    0x10(%rsp),%rsi
   5c727:	call   4f6f0 <std::io::stdio::_print>
   5c72c:	cmpb   $0x0,0xe1d5(%rip)        # 6a908 <g.5>
   5c733:	je     5e600 <f.8+0x2cd0>
   5c739:	cmpq   $0x0,0xe1bf(%rip)        # 6a900 <g.4>
   5c741:	je     5e600 <f.8+0x2cd0>
   5c747:	mov    0x70(%rsp),%rax
   5c74c:	test   %rax,%rax
   5c74f:	je     5e600 <f.8+0x2cd0>
   5c755:	cmpl   $0x0,0x8(%rax)
   5c759:	je     5e600 <f.8+0x2cd0>
   5c75f:	mov    0x10(%rax),%rax
   5c763:	test   %rax,%rax
   5c766:	je     5e600 <f.8+0x2cd0>
   5c76c:	mov    0x8(%rax),%rax
   5c770:	mov    %rax,0x90(%rsp)
   5c778:	lea    -0x51a6f(%rip),%rbp        # ad10 <object.1.0>
   5c77f:	mov    %rbp,0xa0(%rsp)
   5c787:	movq   $0x9,0x58(%rsp)
   5c790:	mov    0xe081(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5c797:	test   %rbx,%rbx
   5c79a:	je     5e600 <f.8+0x2cd0>
   5c7a0:	mov    0x178(%rbx),%rcx
   5c7a7:	test   %rcx,%rcx
   5c7aa:	je     5c7e6 <f.8+0xeb6>
   5c7ac:	mov    0x170(%rbx),%rax
   5c7b3:	inc    %rax
   5c7b6:	mov    %rax,0x170(%rbx)
   5c7bd:	mov    %rax,%rdx
   5c7c0:	or     %rcx,%rdx
   5c7c3:	shr    $0x20,%rdx
   5c7c7:	je     5ce35 <f.8+0x1505>
   5c7cd:	xor    %edx,%edx
   5c7cf:	div    %rcx
   5c7d2:	test   %rdx,%rdx
   5c7d5:	jne    5c7e6 <f.8+0xeb6>
   5c7d7:	mov    0xe042(%rip),%rsi        # 6a820 <native_roots.0>
   5c7de:	mov    %rbx,%rdi
   5c7e1:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c7e6:	cmpq   $0x20,0x98(%rbx)
   5c7ee:	jb     5e605 <f.8+0x2cd5>
   5c7f4:	mov    0xe025(%rip),%r14        # 6a820 <native_roots.0>
   5c7fb:	mov    0xe0(%rbx),%r15
   5c802:	mov    0xe8(%rbx),%r13
   5c809:	cmp    %r13,%r15
   5c80c:	jb     5c819 <f.8+0xee9>
   5c80e:	mov    %rbx,%rdi
   5c811:	mov    %r14,%rsi
   5c814:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c819:	mov    0xc8(%rbx),%rdx
   5c820:	test   %rdx,%rdx
   5c823:	je     5c835 <f.8+0xf05>
   5c825:	mov    0xd0(%rbx),%rax
   5c82c:	sub    %rdx,%rax
   5c82f:	cmp    $0x1f,%rax
   5c833:	ja     5c856 <f.8+0xf26>
   5c835:	mov    $0x20,%esi
   5c83a:	mov    %rbx,%rdi
   5c83d:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5c842:	cmp    $0x1,%rax
   5c846:	jne    5c8d4 <f.8+0xfa4>
   5c84c:	mov    $0x1,%eax
   5c851:	jmp    5c8ec <f.8+0xfbc>
   5c856:	lea    0x20(%rdx),%rax
   5c85a:	mov    %rax,0xc8(%rbx)
   5c861:	mov    0x10(%rbx),%rsi
   5c865:	mov    0xc0(%rbx),%rdi
   5c86c:	cmp    %rsi,%rdi
   5c86f:	jae    5e616 <f.8+0x2ce6>
   5c875:	mov    0x8(%rbx),%rax
   5c879:	imul   $0x38,%rdi,%rcx
   5c87d:	mov    %rdx,%r8
   5c880:	sub    0x18(%rax,%rcx,1),%r8
   5c885:	mov    %r8,%rdi
   5c888:	shr    $0xf,%rdi
   5c88c:	mov    0x10(%rax,%rcx,1),%rsi
   5c891:	cmp    %rsi,%rdi
   5c894:	jae    5e622 <f.8+0x2cf2>
   5c89a:	add    %rcx,%rax
   5c89d:	mov    %r8d,%ecx
   5c8a0:	imul   $0x220,%rdi,%rsi
   5c8a7:	add    0x8(%rax),%rsi
   5c8ab:	shr    $0x4,%ecx
   5c8ae:	mov    $0x1,%eax
   5c8b3:	mov    $0x1,%edi
   5c8b8:	shl    %cl,%rdi
   5c8bb:	shr    $0x7,%r8d
   5c8bf:	and    $0xf8,%r8d
   5c8c6:	or     %rdi,(%r8,%rsi,1)
   5c8ca:	cmp    $0x1,%rax
   5c8ce:	je     5c84c <f.8+0xf1c>
   5c8d4:	xor    %edx,%edx
   5c8d6:	cmp    %r13,%r15
   5c8d9:	setae  %dl
   5c8dc:	mov    $0x20,%esi
   5c8e1:	mov    %rbx,%rdi
   5c8e4:	mov    %r14,%rcx
   5c8e7:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5c8ec:	test   $0x1,%al
   5c8ee:	je     5e605 <f.8+0x2cd5>
   5c8f4:	movq   $0x41,(%rdx)
   5c8fb:	pxor   %xmm0,%xmm0
   5c8ff:	movdqu %xmm0,0x8(%rdx)
   5c904:	addq   $0x20,0xe0(%rbx)
   5c90c:	lea    0x8(%rdx),%r13
   5c910:	movdqu 0x110(%rbx),%xmm0
   5c918:	paddq  -0x583d0(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5c920:	movdqu %xmm0,0x110(%rbx)
   5c928:	movq   $0x36,0x8(%rdx)
   5c930:	mov    %rbp,0x10(%rdx)
   5c934:	mov    %rbp,0xa0(%rsp)
   5c93c:	mov    %r13,0xa8(%rsp)
   5c944:	movq   $0xa,0x58(%rsp)
   5c94d:	mov    0xdec4(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5c954:	test   %rbx,%rbx
   5c957:	je     5e600 <f.8+0x2cd0>
   5c95d:	mov    0x178(%rbx),%rcx
   5c964:	test   %rcx,%rcx
   5c967:	je     5c9a3 <f.8+0x1073>
   5c969:	mov    0x170(%rbx),%rax
   5c970:	inc    %rax
   5c973:	mov    %rax,0x170(%rbx)
   5c97a:	mov    %rax,%rdx
   5c97d:	or     %rcx,%rdx
   5c980:	shr    $0x20,%rdx
   5c984:	je     5ce47 <f.8+0x1517>
   5c98a:	xor    %edx,%edx
   5c98c:	div    %rcx
   5c98f:	test   %rdx,%rdx
   5c992:	jne    5c9a3 <f.8+0x1073>
   5c994:	mov    0xde85(%rip),%rsi        # 6a820 <native_roots.0>
   5c99b:	mov    %rbx,%rdi
   5c99e:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c9a3:	cmpq   $0x20,0x98(%rbx)
   5c9ab:	jb     5e605 <f.8+0x2cd5>
   5c9b1:	mov    0xde68(%rip),%r14        # 6a820 <native_roots.0>
   5c9b8:	mov    0xe0(%rbx),%r15
   5c9bf:	mov    0xe8(%rbx),%r12
   5c9c6:	cmp    %r12,%r15
   5c9c9:	jb     5c9d6 <f.8+0x10a6>
   5c9cb:	mov    %rbx,%rdi
   5c9ce:	mov    %r14,%rsi
   5c9d1:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5c9d6:	mov    0xc8(%rbx),%rdx
   5c9dd:	test   %rdx,%rdx
   5c9e0:	je     5c9f2 <f.8+0x10c2>
   5c9e2:	mov    0xd0(%rbx),%rax
   5c9e9:	sub    %rdx,%rax
   5c9ec:	cmp    $0x1f,%rax
   5c9f0:	ja     5ca13 <f.8+0x10e3>
   5c9f2:	mov    $0x20,%esi
   5c9f7:	mov    %rbx,%rdi
   5c9fa:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5c9ff:	cmp    $0x1,%rax
   5ca03:	jne    5ca91 <f.8+0x1161>
   5ca09:	mov    $0x1,%eax
   5ca0e:	jmp    5caa9 <f.8+0x1179>
   5ca13:	lea    0x20(%rdx),%rax
   5ca17:	mov    %rax,0xc8(%rbx)
   5ca1e:	mov    0x10(%rbx),%rsi
   5ca22:	mov    0xc0(%rbx),%rdi
   5ca29:	cmp    %rsi,%rdi
   5ca2c:	jae    5e616 <f.8+0x2ce6>
   5ca32:	mov    0x8(%rbx),%rax
   5ca36:	imul   $0x38,%rdi,%rcx
   5ca3a:	mov    %rdx,%r8
   5ca3d:	sub    0x18(%rax,%rcx,1),%r8
   5ca42:	mov    %r8,%rdi
   5ca45:	shr    $0xf,%rdi
   5ca49:	mov    0x10(%rax,%rcx,1),%rsi
   5ca4e:	cmp    %rsi,%rdi
   5ca51:	jae    5e622 <f.8+0x2cf2>
   5ca57:	add    %rcx,%rax
   5ca5a:	mov    %r8d,%ecx
   5ca5d:	imul   $0x220,%rdi,%rsi
   5ca64:	add    0x8(%rax),%rsi
   5ca68:	shr    $0x4,%ecx
   5ca6b:	mov    $0x1,%eax
   5ca70:	mov    $0x1,%edi
   5ca75:	shl    %cl,%rdi
   5ca78:	shr    $0x7,%r8d
   5ca7c:	and    $0xf8,%r8d
   5ca83:	or     %rdi,(%r8,%rsi,1)
   5ca87:	cmp    $0x1,%rax
   5ca8b:	je     5ca09 <f.8+0x10d9>
   5ca91:	xor    %edx,%edx
   5ca93:	cmp    %r12,%r15
   5ca96:	setae  %dl
   5ca99:	mov    $0x20,%esi
   5ca9e:	mov    %rbx,%rdi
   5caa1:	mov    %r14,%rcx
   5caa4:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5caa9:	test   $0x1,%al
   5caab:	je     5e605 <f.8+0x2cd5>
   5cab1:	movq   $0x41,(%rdx)
   5cab8:	pxor   %xmm0,%xmm0
   5cabc:	movdqu %xmm0,0x8(%rdx)
   5cac1:	addq   $0x20,0xe0(%rbx)
   5cac9:	lea    0x8(%rdx),%r15
   5cacd:	movdqu 0x110(%rbx),%xmm0
   5cad5:	paddq  -0x5858d(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5cadd:	movdqu %xmm0,0x110(%rbx)
   5cae5:	movq   $0x36,0x8(%rdx)
   5caed:	mov    %rbp,0x10(%rdx)
   5caf1:	mov    %r15,0xa0(%rsp)
   5caf9:	mov    %r13,0xa8(%rsp)
   5cb01:	movq   $0xa,0x58(%rsp)
   5cb0a:	mov    0xdd07(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5cb11:	test   %rbx,%rbx
   5cb14:	je     5e600 <f.8+0x2cd0>
   5cb1a:	mov    0x178(%rbx),%rcx
   5cb21:	test   %rcx,%rcx
   5cb24:	je     5cb60 <f.8+0x1230>
   5cb26:	mov    0x170(%rbx),%rax
   5cb2d:	inc    %rax
   5cb30:	mov    %rax,0x170(%rbx)
   5cb37:	mov    %rax,%rdx
   5cb3a:	or     %rcx,%rdx
   5cb3d:	shr    $0x20,%rdx
   5cb41:	je     5ce59 <f.8+0x1529>
   5cb47:	xor    %edx,%edx
   5cb49:	div    %rcx
   5cb4c:	test   %rdx,%rdx
   5cb4f:	jne    5cb60 <f.8+0x1230>
   5cb51:	mov    0xdcc8(%rip),%rsi        # 6a820 <native_roots.0>
   5cb58:	mov    %rbx,%rdi
   5cb5b:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5cb60:	cmpq   $0x20,0x98(%rbx)
   5cb68:	jb     5e605 <f.8+0x2cd5>
   5cb6e:	mov    0xdcab(%rip),%r14        # 6a820 <native_roots.0>
   5cb75:	mov    0xe0(%rbx),%rbp
   5cb7c:	mov    0xe8(%rbx),%r12
   5cb83:	cmp    %r12,%rbp
   5cb86:	jb     5cb93 <f.8+0x1263>
   5cb88:	mov    %rbx,%rdi
   5cb8b:	mov    %r14,%rsi
   5cb8e:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5cb93:	mov    0xc8(%rbx),%rdx
   5cb9a:	test   %rdx,%rdx
   5cb9d:	je     5cbaf <f.8+0x127f>
   5cb9f:	mov    0xd0(%rbx),%rax
   5cba6:	sub    %rdx,%rax
   5cba9:	cmp    $0x1f,%rax
   5cbad:	ja     5cbd0 <f.8+0x12a0>
   5cbaf:	mov    $0x20,%esi
   5cbb4:	mov    %rbx,%rdi
   5cbb7:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5cbbc:	cmp    $0x1,%rax
   5cbc0:	jne    5cc4e <f.8+0x131e>
   5cbc6:	mov    $0x1,%eax
   5cbcb:	jmp    5cc66 <f.8+0x1336>
   5cbd0:	lea    0x20(%rdx),%rax
   5cbd4:	mov    %rax,0xc8(%rbx)
   5cbdb:	mov    0x10(%rbx),%rsi
   5cbdf:	mov    0xc0(%rbx),%rdi
   5cbe6:	cmp    %rsi,%rdi
   5cbe9:	jae    5e616 <f.8+0x2ce6>
   5cbef:	mov    0x8(%rbx),%rax
   5cbf3:	imul   $0x38,%rdi,%rcx
   5cbf7:	mov    %rdx,%r8
   5cbfa:	sub    0x18(%rax,%rcx,1),%r8
   5cbff:	mov    %r8,%rdi
   5cc02:	shr    $0xf,%rdi
   5cc06:	mov    0x10(%rax,%rcx,1),%rsi
   5cc0b:	cmp    %rsi,%rdi
   5cc0e:	jae    5e622 <f.8+0x2cf2>
   5cc14:	add    %rcx,%rax
   5cc17:	mov    %r8d,%ecx
   5cc1a:	imul   $0x220,%rdi,%rsi
   5cc21:	add    0x8(%rax),%rsi
   5cc25:	shr    $0x4,%ecx
   5cc28:	mov    $0x1,%eax
   5cc2d:	mov    $0x1,%edi
   5cc32:	shl    %cl,%rdi
   5cc35:	shr    $0x7,%r8d
   5cc39:	and    $0xf8,%r8d
   5cc40:	or     %rdi,(%r8,%rsi,1)
   5cc44:	cmp    $0x1,%rax
   5cc48:	je     5cbc6 <f.8+0x1296>
   5cc4e:	xor    %edx,%edx
   5cc50:	cmp    %r12,%rbp
   5cc53:	setae  %dl
   5cc56:	mov    $0x20,%esi
   5cc5b:	mov    %rbx,%rdi
   5cc5e:	mov    %r14,%rcx
   5cc61:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5cc66:	test   $0x1,%al
   5cc68:	je     5e605 <f.8+0x2cd5>
   5cc6e:	movq   $0x61,(%rdx)
   5cc75:	lea    0x8(%rdx),%rbp
   5cc79:	pxor   %xmm0,%xmm0
   5cc7d:	movdqu %xmm0,0x8(%rdx)
   5cc82:	movq   $0x0,0x18(%rdx)
   5cc8a:	addq   $0x20,0xe0(%rbx)
   5cc92:	movdqu 0x110(%rbx),%xmm0
   5cc9a:	paddq  -0x587b2(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5cca2:	movdqu %xmm0,0x110(%rbx)
   5ccaa:	movq   $0x46,0x8(%rdx)
   5ccb2:	mov    %r13,0x10(%rdx)
   5ccb6:	mov    %r15,0x18(%rdx)
   5ccba:	mov    %rbp,0x98(%rsp)
   5ccc2:	cmpq   $0x0,0xe8(%rsp)
   5cccb:	jle    5cf7b <f.8+0x164b>
   5ccd1:	mov    0x90(%rsp),%rax
   5ccd9:	test   %rax,%rax
   5ccdc:	je     5e600 <f.8+0x2cd0>
   5cce2:	mov    0x8(%rax),%r15
   5cce6:	mov    %rbp,0xa0(%rsp)
   5ccee:	mov    %r15,0xa8(%rsp)
   5ccf6:	movq   $0xa,0x58(%rsp)
   5ccff:	mov    0xdb12(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5cd06:	test   %rbx,%rbx
   5cd09:	je     5e600 <f.8+0x2cd0>
   5cd0f:	mov    0x178(%rbx),%rcx
   5cd16:	test   %rcx,%rcx
   5cd19:	je     5cd55 <f.8+0x1425>
   5cd1b:	mov    0x170(%rbx),%rax
   5cd22:	inc    %rax
   5cd25:	mov    %rax,0x170(%rbx)
   5cd2c:	mov    %rax,%rdx
   5cd2f:	or     %rcx,%rdx
   5cd32:	shr    $0x20,%rdx
   5cd36:	je     5e5ee <f.8+0x2cbe>
   5cd3c:	xor    %edx,%edx
   5cd3e:	div    %rcx
   5cd41:	test   %rdx,%rdx
   5cd44:	jne    5cd55 <f.8+0x1425>
   5cd46:	mov    0xdad3(%rip),%rsi        # 6a820 <native_roots.0>
   5cd4d:	mov    %rbx,%rdi
   5cd50:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5cd55:	cmpq   $0x20,0x98(%rbx)
   5cd5d:	jb     5e605 <f.8+0x2cd5>
   5cd63:	mov    0xdab6(%rip),%r14        # 6a820 <native_roots.0>
   5cd6a:	mov    0xe0(%rbx),%r13
   5cd71:	mov    0xe8(%rbx),%r12
   5cd78:	cmp    %r12,%r13
   5cd7b:	jb     5cd88 <f.8+0x1458>
   5cd7d:	mov    %rbx,%rdi
   5cd80:	mov    %r14,%rsi
   5cd83:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5cd88:	mov    0xc8(%rbx),%rdx
   5cd8f:	test   %rdx,%rdx
   5cd92:	je     5cda8 <f.8+0x1478>
   5cd94:	mov    0xd0(%rbx),%rax
   5cd9b:	sub    %rdx,%rax
   5cd9e:	cmp    $0x1f,%rax
   5cda2:	ja     5ce6b <f.8+0x153b>
   5cda8:	mov    $0x20,%esi
   5cdad:	mov    %rbx,%rdi
   5cdb0:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5cdb5:	cmp    $0x1,%rax
   5cdb9:	jne    5cee9 <f.8+0x15b9>
   5cdbf:	mov    $0x1,%eax
   5cdc4:	jmp    5cf01 <f.8+0x15d1>
   5cdc9:	xor    %edx,%edx
   5cdcb:	div    %ecx
   5cdcd:	test   %rdx,%rdx
   5cdd0:	jne    5ba16 <f.8+0xe6>
   5cdd6:	jmp    5ba02 <f.8+0xd2>
   5cddb:	xor    %edx,%edx
   5cddd:	div    %ecx
   5cddf:	test   %rdx,%rdx
   5cde2:	jne    5bbe9 <f.8+0x2b9>
   5cde8:	jmp    5bbda <f.8+0x2aa>
   5cded:	xor    %edx,%edx
   5cdef:	div    %ecx
   5cdf1:	test   %rdx,%rdx
   5cdf4:	jne    5bda8 <f.8+0x478>
   5cdfa:	jmp    5bd99 <f.8+0x469>
   5cdff:	xor    %edx,%edx
   5ce01:	div    %ecx
   5ce03:	test   %rdx,%rdx
   5ce06:	jne    5bf70 <f.8+0x640>
   5ce0c:	jmp    5bf61 <f.8+0x631>
   5ce11:	xor    %edx,%edx
   5ce13:	div    %ecx
   5ce15:	test   %rdx,%rdx
   5ce18:	jne    5c14a <f.8+0x81a>
   5ce1e:	jmp    5c13b <f.8+0x80b>
   5ce23:	xor    %edx,%edx
   5ce25:	div    %ecx
   5ce27:	test   %rdx,%rdx
   5ce2a:	jne    5c309 <f.8+0x9d9>
   5ce30:	jmp    5c2fa <f.8+0x9ca>
   5ce35:	xor    %edx,%edx
   5ce37:	div    %ecx
   5ce39:	test   %rdx,%rdx
   5ce3c:	jne    5c7e6 <f.8+0xeb6>
   5ce42:	jmp    5c7d7 <f.8+0xea7>
   5ce47:	xor    %edx,%edx
   5ce49:	div    %ecx
   5ce4b:	test   %rdx,%rdx
   5ce4e:	jne    5c9a3 <f.8+0x1073>
   5ce54:	jmp    5c994 <f.8+0x1064>
   5ce59:	xor    %edx,%edx
   5ce5b:	div    %ecx
   5ce5d:	test   %rdx,%rdx
   5ce60:	jne    5cb60 <f.8+0x1230>
   5ce66:	jmp    5cb51 <f.8+0x1221>
   5ce6b:	lea    0x20(%rdx),%rax
   5ce6f:	mov    %rax,0xc8(%rbx)
   5ce76:	mov    0x10(%rbx),%rsi
   5ce7a:	mov    0xc0(%rbx),%rdi
   5ce81:	cmp    %rsi,%rdi
   5ce84:	jae    5e616 <f.8+0x2ce6>
   5ce8a:	mov    0x8(%rbx),%rax
   5ce8e:	imul   $0x38,%rdi,%rcx
   5ce92:	mov    %rdx,%r8
   5ce95:	sub    0x18(%rax,%rcx,1),%r8
   5ce9a:	mov    %r8,%rdi
   5ce9d:	shr    $0xf,%rdi
   5cea1:	mov    0x10(%rax,%rcx,1),%rsi
   5cea6:	cmp    %rsi,%rdi
   5cea9:	jae    5e622 <f.8+0x2cf2>
   5ceaf:	add    %rcx,%rax
   5ceb2:	mov    %r8d,%ecx
   5ceb5:	imul   $0x220,%rdi,%rsi
   5cebc:	add    0x8(%rax),%rsi
   5cec0:	shr    $0x4,%ecx
   5cec3:	mov    $0x1,%eax
   5cec8:	mov    $0x1,%edi
   5cecd:	shl    %cl,%rdi
   5ced0:	shr    $0x7,%r8d
   5ced4:	and    $0xf8,%r8d
   5cedb:	or     %rdi,(%r8,%rsi,1)
   5cedf:	cmp    $0x1,%rax
   5cee3:	je     5cdbf <f.8+0x148f>
   5cee9:	xor    %edx,%edx
   5ceeb:	cmp    %r12,%r13
   5ceee:	setae  %dl
   5cef1:	mov    $0x20,%esi
   5cef6:	mov    %rbx,%rdi
   5cef9:	mov    %r14,%rcx
   5cefc:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5cf01:	test   $0x1,%al
   5cf03:	je     5e605 <f.8+0x2cd5>
   5cf09:	movq   $0x61,(%rdx)
   5cf10:	pxor   %xmm0,%xmm0
   5cf14:	movdqu %xmm0,0x8(%rdx)
   5cf19:	movq   $0x0,0x18(%rdx)
   5cf21:	addq   $0x20,0xe0(%rbx)
   5cf29:	movdqu 0x110(%rbx),%xmm0
   5cf31:	paddq  -0x58a49(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5cf39:	lea    0x8(%rdx),%rdi
   5cf3d:	movdqu %xmm0,0x110(%rbx)
   5cf45:	movq   $0x32,0x8(%rdx)
   5cf4d:	mov    %r15,0x10(%rdx)
   5cf51:	mov    %rbp,0x18(%rdx)
   5cf55:	mov    0xe8(%rsp),%rax
   5cf5d:	lea    -0x1(%rax),%rsi
   5cf61:	mov    %rdi,0xa0(%rsp)
   5cf69:	movq   $0x9,0x58(%rsp)
   5cf72:	call   5f1d0 <f.17>
   5cf77:	sub    $0x8,%rsp
   5cf7b:	mov    0x60(%rsp),%rax
   5cf80:	test   %rax,%rax
   5cf83:	je     5e600 <f.8+0x2cd0>
   5cf89:	mov    0x18(%rax),%rbp
   5cf8d:	movq   $0x8,0x58(%rsp)
   5cf96:	mov    %rbp,0xe0(%rsp)
   5cf9e:	lea    0x979b(%rip),%rax        # 66740 <__cxa_atexit@plt+0x1080>
   5cfa5:	mov    %rax,0x10(%rsp)
   5cfaa:	lea    -0x4d21(%rip),%rbx        # 58290 <<&T as core::fmt::Display>::fmt>
   5cfb1:	mov    %rbx,0x18(%rsp)
   5cfb6:	lea    0xe0(%rsp),%rax
   5cfbe:	mov    %rax,0x20(%rsp)
   5cfc3:	lea    -0xda3a(%rip),%rax        # 4f590 <<i64 as core::fmt::Display>::fmt>
   5cfca:	mov    %rax,0x28(%rsp)
   5cfcf:	lea    0x979a(%rip),%rax        # 66770 <__cxa_atexit@plt+0x10b0>
   5cfd6:	mov    %rax,0x30(%rsp)
   5cfdb:	mov    %rbx,0x38(%rsp)
   5cfe0:	lea    -0x56210(%rip),%rdi        # 6dd7 <__abi_tag+0x6aa3>
   5cfe7:	lea    0x10(%rsp),%rsi
   5cfec:	call   4f6f0 <std::io::stdio::_print>
   5cff1:	movq   $0x8,0x58(%rsp)
   5cffa:	lea    0x977f(%rip),%rax        # 66780 <__cxa_atexit@plt+0x10c0>
   5d001:	mov    %rax,0x10(%rsp)
   5d006:	mov    %rbx,0x18(%rsp)
   5d00b:	lea    -0x56779(%rip),%rdi        # 6899 <__abi_tag+0x6565>
   5d012:	lea    0x10(%rsp),%rsi
   5d017:	call   4f6f0 <std::io::stdio::_print>
   5d01c:	mov    %rbp,%rax
   5d01f:	shr    $0x20,%rax
   5d023:	jne    5e600 <f.8+0x2cd0>
   5d029:	movq   $0x8,0x58(%rsp)
   5d032:	mov    0xd7df(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5d039:	test   %r14,%r14
   5d03c:	je     5e600 <f.8+0x2cd0>
   5d042:	mov    0x178(%r14),%rcx
   5d049:	test   %rcx,%rcx
   5d04c:	je     5d088 <f.8+0x1758>
   5d04e:	mov    0x170(%r14),%rax
   5d055:	inc    %rax
   5d058:	mov    %rax,0x170(%r14)
   5d05f:	mov    %rax,%rdx
   5d062:	or     %rcx,%rdx
   5d065:	shr    $0x20,%rdx
   5d069:	je     5e54c <f.8+0x2c1c>
   5d06f:	xor    %edx,%edx
   5d071:	div    %rcx
   5d074:	test   %rdx,%rdx
   5d077:	jne    5d088 <f.8+0x1758>
   5d079:	mov    0xd7a0(%rip),%rsi        # 6a820 <native_roots.0>
   5d080:	mov    %r14,%rdi
   5d083:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d088:	cmpq   $0x20,0x98(%r14)
   5d090:	jb     5e605 <f.8+0x2cd5>
   5d096:	mov    0xd783(%rip),%r15        # 6a820 <native_roots.0>
   5d09d:	mov    0xe0(%r14),%r12
   5d0a4:	mov    0xe8(%r14),%r13
   5d0ab:	cmp    %r13,%r12
   5d0ae:	jb     5d0bb <f.8+0x178b>
   5d0b0:	mov    %r14,%rdi
   5d0b3:	mov    %r15,%rsi
   5d0b6:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d0bb:	mov    0xc8(%r14),%rbx
   5d0c2:	test   %rbx,%rbx
   5d0c5:	je     5d0d7 <f.8+0x17a7>
   5d0c7:	mov    0xd0(%r14),%rax
   5d0ce:	sub    %rbx,%rax
   5d0d1:	cmp    $0x1f,%rax
   5d0d5:	ja     5d0fb <f.8+0x17cb>
   5d0d7:	mov    $0x20,%esi
   5d0dc:	mov    %r14,%rdi
   5d0df:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5d0e4:	mov    %rdx,%rbx
   5d0e7:	cmp    $0x1,%rax
   5d0eb:	jne    5d176 <f.8+0x1846>
   5d0f1:	mov    $0x1,%eax
   5d0f6:	jmp    5d191 <f.8+0x1861>
   5d0fb:	lea    0x20(%rbx),%rax
   5d0ff:	mov    %rax,0xc8(%r14)
   5d106:	mov    0x10(%r14),%rsi
   5d10a:	mov    0xc0(%r14),%rdi
   5d111:	cmp    %rsi,%rdi
   5d114:	jae    5e616 <f.8+0x2ce6>
   5d11a:	mov    0x8(%r14),%rax
   5d11e:	imul   $0x38,%rdi,%rcx
   5d122:	mov    %rbx,%rdx
   5d125:	sub    0x18(%rax,%rcx,1),%rdx
   5d12a:	mov    %rdx,%rdi
   5d12d:	shr    $0xf,%rdi
   5d131:	mov    0x10(%rax,%rcx,1),%rsi
   5d136:	cmp    %rsi,%rdi
   5d139:	jae    5e622 <f.8+0x2cf2>
   5d13f:	add    %rcx,%rax
   5d142:	mov    %edx,%ecx
   5d144:	imul   $0x220,%rdi,%rsi
   5d14b:	add    0x8(%rax),%rsi
   5d14f:	shr    $0x4,%ecx
   5d152:	mov    $0x1,%eax
   5d157:	mov    $0x1,%edi
   5d15c:	shl    %cl,%rdi
   5d15f:	shr    $0x7,%edx
   5d162:	and    $0xf8,%edx
   5d168:	or     %rdi,(%rdx,%rsi,1)
   5d16c:	cmp    $0x1,%rax
   5d170:	je     5d0f1 <f.8+0x17c1>
   5d176:	xor    %edx,%edx
   5d178:	cmp    %r13,%r12
   5d17b:	setae  %dl
   5d17e:	mov    $0x20,%esi
   5d183:	mov    %r14,%rdi
   5d186:	mov    %r15,%rcx
   5d189:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5d18e:	mov    %rdx,%rbx
   5d191:	test   $0x1,%al
   5d193:	je     5e605 <f.8+0x2cd5>
   5d199:	movq   $0x61,(%rbx)
   5d1a0:	lea    0x8(%rbx),%r12
   5d1a4:	pxor   %xmm0,%xmm0
   5d1a8:	movdqu %xmm0,0x8(%rbx)
   5d1ad:	movq   $0x0,0x18(%rbx)
   5d1b5:	addq   $0x20,0xe0(%r14)
   5d1bd:	movdqu 0x110(%r14),%xmm0
   5d1c6:	paddq  -0x58cde(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5d1ce:	movdqu %xmm0,0x110(%r14)
   5d1d7:	movq   $0x5e,0x8(%rbx)
   5d1df:	movl   $0x0,0x10(%rbx)
   5d1e6:	movq   $0x0,0x18(%rbx)
   5d1ee:	mov    %r12,0x68(%rsp)
   5d1f3:	lea    0xb4de(%rip),%r15        # 686d8 <ref.16>
   5d1fa:	mov    %r15,0xa0(%rsp)
   5d202:	mov    %r12,0xa8(%rsp)
   5d20a:	movq   $0xa,0x58(%rsp)
   5d213:	lea    0x10(,%rbp,8),%rdi
   5d21b:	call   582b0 <native_alloc>
   5d220:	mov    %rax,%r14
   5d223:	test   $0x1,%r14b
   5d227:	jne    5e600 <f.8+0x2cd0>
   5d22d:	movq   $0x4f,(%r14)
   5d234:	mov    %rbp,0x8(%r14)
   5d238:	mov    %r14,0x88(%rsp)
   5d240:	mov    0x68(%rsp),%r13
   5d245:	mov    %r13,0xa0(%rsp)
   5d24d:	mov    %r14,0xa8(%rsp)
   5d255:	mov    %r15,0xb0(%rsp)
   5d25d:	mov    %r12,0xb8(%rsp)
   5d265:	movq   $0xc,0x58(%rsp)
   5d26e:	mov    0xd5a3(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5d275:	test   %r15,%r15
   5d278:	je     5e600 <f.8+0x2cd0>
   5d27e:	mov    0x178(%r15),%rcx
   5d285:	test   %rcx,%rcx
   5d288:	je     5d2c4 <f.8+0x1994>
   5d28a:	mov    0x170(%r15),%rax
   5d291:	inc    %rax
   5d294:	mov    %rax,0x170(%r15)
   5d29b:	mov    %rax,%rdx
   5d29e:	or     %rcx,%rdx
   5d2a1:	shr    $0x20,%rdx
   5d2a5:	je     5e55e <f.8+0x2c2e>
   5d2ab:	xor    %edx,%edx
   5d2ad:	div    %rcx
   5d2b0:	test   %rdx,%rdx
   5d2b3:	jne    5d2c4 <f.8+0x1994>
   5d2b5:	mov    0xd564(%rip),%rsi        # 6a820 <native_roots.0>
   5d2bc:	mov    %r15,%rdi
   5d2bf:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d2c4:	cmpq   $0x30,0x98(%r15)
   5d2cc:	jb     5e605 <f.8+0x2cd5>
   5d2d2:	mov    %r13,0xd8(%rsp)
   5d2da:	mov    %rbp,0x40(%rsp)
   5d2df:	mov    0xd53a(%rip),%r12        # 6a820 <native_roots.0>
   5d2e6:	mov    0xe0(%r15),%r13
   5d2ed:	mov    0xe8(%r15),%rbp
   5d2f4:	cmp    %rbp,%r13
   5d2f7:	jb     5d304 <f.8+0x19d4>
   5d2f9:	mov    %r15,%rdi
   5d2fc:	mov    %r12,%rsi
   5d2ff:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d304:	mov    0xc8(%r15),%rdx
   5d30b:	test   %rdx,%rdx
   5d30e:	je     5d320 <f.8+0x19f0>
   5d310:	mov    0xd0(%r15),%rax
   5d317:	sub    %rdx,%rax
   5d31a:	cmp    $0x2f,%rax
   5d31e:	ja     5d341 <f.8+0x1a11>
   5d320:	mov    $0x30,%esi
   5d325:	mov    %r15,%rdi
   5d328:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5d32d:	cmp    $0x1,%rax
   5d331:	jne    5d3bf <f.8+0x1a8f>
   5d337:	mov    $0x1,%eax
   5d33c:	jmp    5d3d7 <f.8+0x1aa7>
   5d341:	lea    0x30(%rdx),%rax
   5d345:	mov    %rax,0xc8(%r15)
   5d34c:	mov    0x10(%r15),%rsi
   5d350:	mov    0xc0(%r15),%rdi
   5d357:	cmp    %rsi,%rdi
   5d35a:	jae    5e616 <f.8+0x2ce6>
   5d360:	mov    0x8(%r15),%rax
   5d364:	imul   $0x38,%rdi,%rcx
   5d368:	mov    %rdx,%r8
   5d36b:	sub    0x18(%rax,%rcx,1),%r8
   5d370:	mov    %r8,%rdi
   5d373:	shr    $0xf,%rdi
   5d377:	mov    0x10(%rax,%rcx,1),%rsi
   5d37c:	cmp    %rsi,%rdi
   5d37f:	jae    5e622 <f.8+0x2cf2>
   5d385:	add    %rcx,%rax
   5d388:	mov    %r8d,%ecx
   5d38b:	imul   $0x220,%rdi,%rsi
   5d392:	add    0x8(%rax),%rsi
   5d396:	shr    $0x4,%ecx
   5d399:	mov    $0x1,%eax
   5d39e:	mov    $0x1,%edi
   5d3a3:	shl    %cl,%rdi
   5d3a6:	shr    $0x7,%r8d
   5d3aa:	and    $0xf8,%r8d
   5d3b1:	or     %rdi,(%r8,%rsi,1)
   5d3b5:	cmp    $0x1,%rax
   5d3b9:	je     5d337 <f.8+0x1a07>
   5d3bf:	xor    %edx,%edx
   5d3c1:	cmp    %rbp,%r13
   5d3c4:	setae  %dl
   5d3c7:	mov    $0x30,%esi
   5d3cc:	mov    %r15,%rdi
   5d3cf:	mov    %r12,%rcx
   5d3d2:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5d3d7:	mov    0x40(%rsp),%rcx
   5d3dc:	lea    0xb2f5(%rip),%rsi        # 686d8 <ref.16>
   5d3e3:	lea    0x8(%rbx),%rdi
   5d3e7:	mov    0xd8(%rsp),%r8
   5d3ef:	test   $0x1,%al
   5d3f1:	je     5e605 <f.8+0x2cd5>
   5d3f7:	movq   $0x81,(%rdx)
   5d3fe:	pxor   %xmm0,%xmm0
   5d402:	movdqu %xmm0,0x8(%rdx)
   5d407:	movdqu %xmm0,0x18(%rdx)
   5d40c:	addq   $0x30,0xe0(%r15)
   5d414:	movdqu 0x110(%r15),%xmm0
   5d41d:	paddq  -0x590b5(%rip),%xmm0        # 4370 <__abi_tag+0x403c>
   5d425:	lea    0x8(%rdx),%r12
   5d429:	movdqu %xmm0,0x110(%r15)
   5d432:	movq   $0x2e,0x8(%rdx)
   5d43a:	mov    %rcx,0x10(%rdx)
   5d43e:	mov    %r14,0x18(%rdx)
   5d442:	mov    %r8,0x20(%rdx)
   5d446:	mov    %r12,0xa0(%rsp)
   5d44e:	mov    %rsi,0xa8(%rsp)
   5d456:	mov    %rdi,0xb0(%rsp)
   5d45e:	movq   $0xb,0x58(%rsp)
   5d467:	mov    0xd3aa(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5d46e:	test   %r14,%r14
   5d471:	je     5e600 <f.8+0x2cd0>
   5d477:	mov    0x178(%r14),%rcx
   5d47e:	test   %rcx,%rcx
   5d481:	je     5d4bd <f.8+0x1b8d>
   5d483:	mov    0x170(%r14),%rax
   5d48a:	inc    %rax
   5d48d:	mov    %rax,0x170(%r14)
   5d494:	mov    %rax,%rdx
   5d497:	or     %rcx,%rdx
   5d49a:	shr    $0x20,%rdx
   5d49e:	je     5e570 <f.8+0x2c40>
   5d4a4:	xor    %edx,%edx
   5d4a6:	div    %rcx
   5d4a9:	test   %rdx,%rdx
   5d4ac:	jne    5d4bd <f.8+0x1b8d>
   5d4ae:	mov    0xd36b(%rip),%rsi        # 6a820 <native_roots.0>
   5d4b5:	mov    %r14,%rdi
   5d4b8:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d4bd:	cmpq   $0x20,0x98(%r14)
   5d4c5:	jb     5e605 <f.8+0x2cd5>
   5d4cb:	mov    0xd34e(%rip),%r15        # 6a820 <native_roots.0>
   5d4d2:	mov    0xe0(%r14),%r13
   5d4d9:	mov    0xe8(%r14),%rbp
   5d4e0:	cmp    %rbp,%r13
   5d4e3:	jb     5d4f0 <f.8+0x1bc0>
   5d4e5:	mov    %r14,%rdi
   5d4e8:	mov    %r15,%rsi
   5d4eb:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d4f0:	mov    0xc8(%r14),%rdx
   5d4f7:	test   %rdx,%rdx
   5d4fa:	je     5d50c <f.8+0x1bdc>
   5d4fc:	mov    0xd0(%r14),%rax
   5d503:	sub    %rdx,%rax
   5d506:	cmp    $0x1f,%rax
   5d50a:	ja     5d52d <f.8+0x1bfd>
   5d50c:	mov    $0x20,%esi
   5d511:	mov    %r14,%rdi
   5d514:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5d519:	cmp    $0x1,%rax
   5d51d:	jne    5d5ab <f.8+0x1c7b>
   5d523:	mov    $0x1,%eax
   5d528:	jmp    5d5c3 <f.8+0x1c93>
   5d52d:	lea    0x20(%rdx),%rax
   5d531:	mov    %rax,0xc8(%r14)
   5d538:	mov    0x10(%r14),%rsi
   5d53c:	mov    0xc0(%r14),%rdi
   5d543:	cmp    %rsi,%rdi
   5d546:	jae    5e616 <f.8+0x2ce6>
   5d54c:	mov    0x8(%r14),%rax
   5d550:	imul   $0x38,%rdi,%rcx
   5d554:	mov    %rdx,%r8
   5d557:	sub    0x18(%rax,%rcx,1),%r8
   5d55c:	mov    %r8,%rdi
   5d55f:	shr    $0xf,%rdi
   5d563:	mov    0x10(%rax,%rcx,1),%rsi
   5d568:	cmp    %rsi,%rdi
   5d56b:	jae    5e622 <f.8+0x2cf2>
   5d571:	add    %rcx,%rax
   5d574:	mov    %r8d,%ecx
   5d577:	imul   $0x220,%rdi,%rsi
   5d57e:	add    0x8(%rax),%rsi
   5d582:	shr    $0x4,%ecx
   5d585:	mov    $0x1,%eax
   5d58a:	mov    $0x1,%edi
   5d58f:	shl    %cl,%rdi
   5d592:	shr    $0x7,%r8d
   5d596:	and    $0xf8,%r8d
   5d59d:	or     %rdi,(%r8,%rsi,1)
   5d5a1:	cmp    $0x1,%rax
   5d5a5:	je     5d523 <f.8+0x1bf3>
   5d5ab:	xor    %edx,%edx
   5d5ad:	cmp    %rbp,%r13
   5d5b0:	setae  %dl
   5d5b3:	mov    $0x20,%esi
   5d5b8:	mov    %r14,%rdi
   5d5bb:	mov    %r15,%rcx
   5d5be:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5d5c3:	lea    0x91b6(%rip),%r15        # 66780 <__cxa_atexit@plt+0x10c0>
   5d5ca:	lea    -0x5341(%rip),%r13        # 58290 <<&T as core::fmt::Display>::fmt>
   5d5d1:	test   $0x1,%al
   5d5d3:	je     5e605 <f.8+0x2cd5>
   5d5d9:	movq   $0x61,(%rdx)
   5d5e0:	pxor   %xmm0,%xmm0
   5d5e4:	movdqu %xmm0,0x8(%rdx)
   5d5e9:	movq   $0x0,0x18(%rdx)
   5d5f1:	addq   $0x20,0xe0(%r14)
   5d5f9:	movdqu 0x110(%r14),%xmm0
   5d602:	paddq  -0x5911a(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5d60a:	lea    0x8(%rdx),%rax
   5d60e:	movdqu %xmm0,0x110(%r14)
   5d617:	movq   $0x82,0x8(%rdx)
   5d61f:	lea    0xb0b2(%rip),%rcx        # 686d8 <ref.16>
   5d626:	mov    %rcx,0x10(%rdx)
   5d62a:	mov    %r12,0x18(%rdx)
   5d62e:	mov    %rax,0x18(%rbx)
   5d632:	mov    0x68(%rsp),%rax
   5d637:	test   %rax,%rax
   5d63a:	je     5e600 <f.8+0x2cd0>
   5d640:	movl   $0x1,0x8(%rax)
   5d647:	mov    0x68(%rsp),%rax
   5d64c:	test   %rax,%rax
   5d64f:	je     5e600 <f.8+0x2cd0>
   5d655:	cmpl   $0x0,0x8(%rax)
   5d659:	je     5e600 <f.8+0x2cd0>
   5d65f:	mov    0x10(%rax),%rax
   5d663:	test   %rax,%rax
   5d666:	je     5e600 <f.8+0x2cd0>
   5d66c:	mov    %rax,0x80(%rsp)
   5d674:	mov    0x8(%rax),%rcx
   5d678:	test   %rcx,%rcx
   5d67b:	je     5e600 <f.8+0x2cd0>
   5d681:	mov    0x10(%rax),%rdi
   5d685:	mov    0x8(%rcx),%rax
   5d689:	mov    %rdi,0xa0(%rsp)
   5d691:	movq   $0x9,0x58(%rsp)
   5d69a:	xor    %esi,%esi
   5d69c:	call   *%rax
   5d69e:	sub    $0x8,%rsp
   5d6a2:	cmpb   $0x0,0xd2ff(%rip)        # 6a9a8 <g.25>
   5d6a9:	je     5e600 <f.8+0x2cd0>
   5d6af:	cmpq   $0x0,0xd2e9(%rip)        # 6a9a0 <g.24>
   5d6b7:	je     5e600 <f.8+0x2cd0>
   5d6bd:	movq   $0x8,0x58(%rsp)
   5d6c6:	lea    0x90c3(%rip),%rax        # 66790 <__cxa_atexit@plt+0x10d0>
   5d6cd:	mov    %rax,0x10(%rsp)
   5d6d2:	mov    %r13,0x18(%rsp)
   5d6d7:	lea    -0x56e45(%rip),%rbx        # 6899 <__abi_tag+0x6565>
   5d6de:	lea    0x10(%rsp),%rsi
   5d6e3:	mov    %rbx,%rdi
   5d6e6:	call   4f6f0 <std::io::stdio::_print>
   5d6eb:	movq   $0x8,0x58(%rsp)
   5d6f4:	lea    0x90a5(%rip),%rax        # 667a0 <__cxa_atexit@plt+0x10e0>
   5d6fb:	mov    %rax,0x10(%rsp)
   5d700:	mov    %r13,0x18(%rsp)
   5d705:	lea    0x10(%rsp),%rsi
   5d70a:	mov    %rbx,%rdi
   5d70d:	call   4f6f0 <std::io::stdio::_print>
   5d712:	movq   $0x8,0x58(%rsp)
   5d71b:	mov    %r15,0x10(%rsp)
   5d720:	mov    %r13,0x18(%rsp)
   5d725:	lea    0x10(%rsp),%rsi
   5d72a:	mov    %rbx,%rdi
   5d72d:	call   4f6f0 <std::io::stdio::_print>
   5d732:	movq   $0x8,0x58(%rsp)
   5d73b:	mov    0xd0d6(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5d742:	test   %r14,%r14
   5d745:	je     5e600 <f.8+0x2cd0>
   5d74b:	mov    0x178(%r14),%rcx
   5d752:	test   %rcx,%rcx
   5d755:	je     5d791 <f.8+0x1e61>
   5d757:	mov    0x170(%r14),%rax
   5d75e:	inc    %rax
   5d761:	mov    %rax,0x170(%r14)
   5d768:	mov    %rax,%rdx
   5d76b:	or     %rcx,%rdx
   5d76e:	shr    $0x20,%rdx
   5d772:	je     5e582 <f.8+0x2c52>
   5d778:	xor    %edx,%edx
   5d77a:	div    %rcx
   5d77d:	test   %rdx,%rdx
   5d780:	jne    5d791 <f.8+0x1e61>
   5d782:	mov    0xd097(%rip),%rsi        # 6a820 <native_roots.0>
   5d789:	mov    %r14,%rdi
   5d78c:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d791:	cmpq   $0x20,0x98(%r14)
   5d799:	jb     5e605 <f.8+0x2cd5>
   5d79f:	mov    0xd07a(%rip),%r15        # 6a820 <native_roots.0>
   5d7a6:	mov    0xe0(%r14),%rbx
   5d7ad:	mov    0xe8(%r14),%r12
   5d7b4:	cmp    %r12,%rbx
   5d7b7:	jb     5d7c4 <f.8+0x1e94>
   5d7b9:	mov    %r14,%rdi
   5d7bc:	mov    %r15,%rsi
   5d7bf:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d7c4:	mov    0xc8(%r14),%rdx
   5d7cb:	test   %rdx,%rdx
   5d7ce:	je     5d7e0 <f.8+0x1eb0>
   5d7d0:	mov    0xd0(%r14),%rax
   5d7d7:	sub    %rdx,%rax
   5d7da:	cmp    $0x1f,%rax
   5d7de:	ja     5d801 <f.8+0x1ed1>
   5d7e0:	mov    $0x20,%esi
   5d7e5:	mov    %r14,%rdi
   5d7e8:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5d7ed:	cmp    $0x1,%rax
   5d7f1:	jne    5d87f <f.8+0x1f4f>
   5d7f7:	mov    $0x1,%eax
   5d7fc:	jmp    5d897 <f.8+0x1f67>
   5d801:	lea    0x20(%rdx),%rax
   5d805:	mov    %rax,0xc8(%r14)
   5d80c:	mov    0x10(%r14),%rsi
   5d810:	mov    0xc0(%r14),%rdi
   5d817:	cmp    %rsi,%rdi
   5d81a:	jae    5e616 <f.8+0x2ce6>
   5d820:	mov    0x8(%r14),%rax
   5d824:	imul   $0x38,%rdi,%rcx
   5d828:	mov    %rdx,%r8
   5d82b:	sub    0x18(%rax,%rcx,1),%r8
   5d830:	mov    %r8,%rdi
   5d833:	shr    $0xf,%rdi
   5d837:	mov    0x10(%rax,%rcx,1),%rsi
   5d83c:	cmp    %rsi,%rdi
   5d83f:	jae    5e622 <f.8+0x2cf2>
   5d845:	add    %rcx,%rax
   5d848:	mov    %r8d,%ecx
   5d84b:	imul   $0x220,%rdi,%rsi
   5d852:	add    0x8(%rax),%rsi
   5d856:	shr    $0x4,%ecx
   5d859:	mov    $0x1,%eax
   5d85e:	mov    $0x1,%edi
   5d863:	shl    %cl,%rdi
   5d866:	shr    $0x7,%r8d
   5d86a:	and    $0xf8,%r8d
   5d871:	or     %rdi,(%r8,%rsi,1)
   5d875:	cmp    $0x1,%rax
   5d879:	je     5d7f7 <f.8+0x1ec7>
   5d87f:	xor    %edx,%edx
   5d881:	cmp    %r12,%rbx
   5d884:	setae  %dl
   5d887:	mov    $0x20,%esi
   5d88c:	mov    %r14,%rdi
   5d88f:	mov    %r15,%rcx
   5d892:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5d897:	test   $0x1,%al
   5d899:	je     5e605 <f.8+0x2cd5>
   5d89f:	movq   $0x61,(%rdx)
   5d8a6:	pxor   %xmm0,%xmm0
   5d8aa:	movdqu %xmm0,0x8(%rdx)
   5d8af:	movq   $0x0,0x18(%rdx)
   5d8b7:	addq   $0x20,0xe0(%r14)
   5d8bf:	movdqu 0x110(%r14),%xmm0
   5d8c8:	paddq  -0x593e0(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5d8d0:	lea    0x8(%rdx),%rbx
   5d8d4:	movdqu %xmm0,0x110(%r14)
   5d8dd:	movq   $0x5e,0x8(%rdx)
   5d8e5:	movl   $0x0,0x10(%rdx)
   5d8ec:	mov    %rdx,0xf0(%rsp)
   5d8f4:	movq   $0x0,0x18(%rdx)
   5d8fc:	mov    %rbx,0x68(%rsp)
   5d901:	mov    0x60(%rsp),%rax
   5d906:	test   %rax,%rax
   5d909:	je     5e600 <f.8+0x2cd0>
   5d90f:	mov    0x78(%rsp),%r15
   5d914:	mov    0x70(%rsp),%rbp
   5d919:	mov    0x20(%rax),%r13
   5d91d:	mov    %r13,0xa0(%rsp)
   5d925:	mov    %rbp,0xa8(%rsp)
   5d92d:	mov    %r15,0xb0(%rsp)
   5d935:	lea    0xad6c(%rip),%rax        # 686a8 <ref.11>
   5d93c:	mov    %rax,0xb8(%rsp)
   5d944:	mov    %rbx,0xc0(%rsp)
   5d94c:	lea    0xad45(%rip),%rax        # 68698 <ref.10>
   5d953:	mov    %rax,0xc8(%rsp)
   5d95b:	mov    %rbx,0xd0(%rsp)
   5d963:	movq   $0xf,0x58(%rsp)
   5d96c:	mov    0xcea5(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5d973:	test   %r14,%r14
   5d976:	je     5e600 <f.8+0x2cd0>
   5d97c:	mov    0x178(%r14),%rcx
   5d983:	test   %rcx,%rcx
   5d986:	je     5d9c2 <f.8+0x2092>
   5d988:	mov    0x170(%r14),%rax
   5d98f:	inc    %rax
   5d992:	mov    %rax,0x170(%r14)
   5d999:	mov    %rax,%rdx
   5d99c:	or     %rcx,%rdx
   5d99f:	shr    $0x20,%rdx
   5d9a3:	je     5e594 <f.8+0x2c64>
   5d9a9:	xor    %edx,%edx
   5d9ab:	div    %rcx
   5d9ae:	test   %rdx,%rdx
   5d9b1:	jne    5d9c2 <f.8+0x2092>
   5d9b3:	mov    0xce66(%rip),%rsi        # 6a820 <native_roots.0>
   5d9ba:	mov    %r14,%rdi
   5d9bd:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5d9c2:	cmpq   $0x30,0x98(%r14)
   5d9ca:	jb     5e605 <f.8+0x2cd5>
   5d9d0:	mov    %r15,0xd8(%rsp)
   5d9d8:	mov    %rbx,0x40(%rsp)
   5d9dd:	mov    0xce3c(%rip),%r15        # 6a820 <native_roots.0>
   5d9e4:	mov    0xe0(%r14),%r12
   5d9eb:	mov    0xe8(%r14),%rbx
   5d9f2:	cmp    %rbx,%r12
   5d9f5:	jb     5da02 <f.8+0x20d2>
   5d9f7:	mov    %r14,%rdi
   5d9fa:	mov    %r15,%rsi
   5d9fd:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5da02:	mov    0xc8(%r14),%rdx
   5da09:	test   %rdx,%rdx
   5da0c:	je     5da1e <f.8+0x20ee>
   5da0e:	mov    0xd0(%r14),%rax
   5da15:	sub    %rdx,%rax
   5da18:	cmp    $0x2f,%rax
   5da1c:	ja     5da3f <f.8+0x210f>
   5da1e:	mov    $0x30,%esi
   5da23:	mov    %r14,%rdi
   5da26:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5da2b:	cmp    $0x1,%rax
   5da2f:	jne    5dabd <f.8+0x218d>
   5da35:	mov    $0x1,%eax
   5da3a:	jmp    5dad5 <f.8+0x21a5>
   5da3f:	lea    0x30(%rdx),%rax
   5da43:	mov    %rax,0xc8(%r14)
   5da4a:	mov    0x10(%r14),%rsi
   5da4e:	mov    0xc0(%r14),%rdi
   5da55:	cmp    %rsi,%rdi
   5da58:	jae    5e616 <f.8+0x2ce6>
   5da5e:	mov    0x8(%r14),%rax
   5da62:	imul   $0x38,%rdi,%rcx
   5da66:	mov    %rdx,%r8
   5da69:	sub    0x18(%rax,%rcx,1),%r8
   5da6e:	mov    %r8,%rdi
   5da71:	shr    $0xf,%rdi
   5da75:	mov    0x10(%rax,%rcx,1),%rsi
   5da7a:	cmp    %rsi,%rdi
   5da7d:	jae    5e622 <f.8+0x2cf2>
   5da83:	add    %rcx,%rax
   5da86:	mov    %r8d,%ecx
   5da89:	imul   $0x220,%rdi,%rsi
   5da90:	add    0x8(%rax),%rsi
   5da94:	shr    $0x4,%ecx
   5da97:	mov    $0x1,%eax
   5da9c:	mov    $0x1,%edi
   5daa1:	shl    %cl,%rdi
   5daa4:	shr    $0x7,%r8d
   5daa8:	and    $0xf8,%r8d
   5daaf:	or     %rdi,(%r8,%rsi,1)
   5dab3:	cmp    $0x1,%rax
   5dab7:	je     5da35 <f.8+0x2105>
   5dabd:	xor    %edx,%edx
   5dabf:	cmp    %rbx,%r12
   5dac2:	setae  %dl
   5dac5:	mov    $0x30,%esi
   5daca:	mov    %r14,%rdi
   5dacd:	mov    %r15,%rcx
   5dad0:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5dad5:	mov    0x40(%rsp),%rcx
   5dada:	mov    0xd8(%rsp),%rsi
   5dae2:	test   $0x1,%al
   5dae4:	je     5e605 <f.8+0x2cd5>
   5daea:	movq   $0x81,(%rdx)
   5daf1:	lea    0x8(%rdx),%r12
   5daf5:	pxor   %xmm0,%xmm0
   5daf9:	movdqu %xmm0,0x8(%rdx)
   5dafe:	movdqu %xmm0,0x18(%rdx)
   5db03:	addq   $0x30,0xe0(%r14)
   5db0b:	movdqu 0x110(%r14),%xmm0
   5db14:	paddq  -0x597ac(%rip),%xmm0        # 4370 <__abi_tag+0x403c>
   5db1c:	movdqu %xmm0,0x110(%r14)
   5db25:	movq   $0x2a,0x8(%rdx)
   5db2d:	mov    %rsi,0x10(%rdx)
   5db31:	mov    %rbp,0x18(%rdx)
   5db35:	mov    %r13,0x20(%rdx)
   5db39:	mov    %r12,0xa0(%rsp)
   5db41:	lea    0xab60(%rip),%rax        # 686a8 <ref.11>
   5db48:	mov    %rax,0xa8(%rsp)
   5db50:	mov    %rcx,0xb0(%rsp)
   5db58:	lea    0xab39(%rip),%rax        # 68698 <ref.10>
   5db5f:	mov    %rax,0xb8(%rsp)
   5db67:	mov    %rcx,0xc0(%rsp)
   5db6f:	movq   $0xd,0x58(%rsp)
   5db78:	mov    0xcc99(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5db7f:	test   %r14,%r14
   5db82:	je     5e600 <f.8+0x2cd0>
   5db88:	mov    0x178(%r14),%rcx
   5db8f:	test   %rcx,%rcx
   5db92:	lea    0x8be7(%rip),%rbp        # 66780 <__cxa_atexit@plt+0x10c0>
   5db99:	je     5dbd5 <f.8+0x22a5>
   5db9b:	mov    0x170(%r14),%rax
   5dba2:	inc    %rax
   5dba5:	mov    %rax,0x170(%r14)
   5dbac:	mov    %rax,%rdx
   5dbaf:	or     %rcx,%rdx
   5dbb2:	shr    $0x20,%rdx
   5dbb6:	je     5e5a6 <f.8+0x2c76>
   5dbbc:	xor    %edx,%edx
   5dbbe:	div    %rcx
   5dbc1:	test   %rdx,%rdx
   5dbc4:	jne    5dbd5 <f.8+0x22a5>
   5dbc6:	mov    0xcc53(%rip),%rsi        # 6a820 <native_roots.0>
   5dbcd:	mov    %r14,%rdi
   5dbd0:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5dbd5:	cmpq   $0x20,0x98(%r14)
   5dbdd:	jb     5e605 <f.8+0x2cd5>
   5dbe3:	mov    0xcc36(%rip),%r15        # 6a820 <native_roots.0>
   5dbea:	mov    0xe0(%r14),%rbx
   5dbf1:	mov    0xe8(%r14),%r13
   5dbf8:	cmp    %r13,%rbx
   5dbfb:	jb     5dc08 <f.8+0x22d8>
   5dbfd:	mov    %r14,%rdi
   5dc00:	mov    %r15,%rsi
   5dc03:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5dc08:	mov    0xc8(%r14),%rdx
   5dc0f:	test   %rdx,%rdx
   5dc12:	je     5dc24 <f.8+0x22f4>
   5dc14:	mov    0xd0(%r14),%rax
   5dc1b:	sub    %rdx,%rax
   5dc1e:	cmp    $0x1f,%rax
   5dc22:	ja     5dc45 <f.8+0x2315>
   5dc24:	mov    $0x20,%esi
   5dc29:	mov    %r14,%rdi
   5dc2c:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5dc31:	cmp    $0x1,%rax
   5dc35:	jne    5dcc3 <f.8+0x2393>
   5dc3b:	mov    $0x1,%eax
   5dc40:	jmp    5dcdb <f.8+0x23ab>
   5dc45:	lea    0x20(%rdx),%rax
   5dc49:	mov    %rax,0xc8(%r14)
   5dc50:	mov    0x10(%r14),%rsi
   5dc54:	mov    0xc0(%r14),%rdi
   5dc5b:	cmp    %rsi,%rdi
   5dc5e:	jae    5e616 <f.8+0x2ce6>
   5dc64:	mov    0x8(%r14),%rax
   5dc68:	imul   $0x38,%rdi,%rcx
   5dc6c:	mov    %rdx,%r8
   5dc6f:	sub    0x18(%rax,%rcx,1),%r8
   5dc74:	mov    %r8,%rdi
   5dc77:	shr    $0xf,%rdi
   5dc7b:	mov    0x10(%rax,%rcx,1),%rsi
   5dc80:	cmp    %rsi,%rdi
   5dc83:	jae    5e622 <f.8+0x2cf2>
   5dc89:	add    %rcx,%rax
   5dc8c:	mov    %r8d,%ecx
   5dc8f:	imul   $0x220,%rdi,%rsi
   5dc96:	add    0x8(%rax),%rsi
   5dc9a:	shr    $0x4,%ecx
   5dc9d:	mov    $0x1,%eax
   5dca2:	mov    $0x1,%edi
   5dca7:	shl    %cl,%rdi
   5dcaa:	shr    $0x7,%r8d
   5dcae:	and    $0xf8,%r8d
   5dcb5:	or     %rdi,(%r8,%rsi,1)
   5dcb9:	cmp    $0x1,%rax
   5dcbd:	je     5dc3b <f.8+0x230b>
   5dcc3:	xor    %edx,%edx
   5dcc5:	cmp    %r13,%rbx
   5dcc8:	setae  %dl
   5dccb:	mov    $0x20,%esi
   5dcd0:	mov    %r14,%rdi
   5dcd3:	mov    %r15,%rcx
   5dcd6:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5dcdb:	mov    0x40(%rsp),%rcx
   5dce0:	test   $0x1,%al
   5dce2:	je     5e605 <f.8+0x2cd5>
   5dce8:	movq   $0x61,(%rdx)
   5dcef:	pxor   %xmm0,%xmm0
   5dcf3:	movdqu %xmm0,0x8(%rdx)
   5dcf8:	movq   $0x0,0x18(%rdx)
   5dd00:	addq   $0x20,0xe0(%r14)
   5dd08:	movdqu 0x110(%r14),%xmm0
   5dd11:	paddq  -0x59829(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5dd19:	lea    0x8(%rdx),%r13
   5dd1d:	movdqu %xmm0,0x110(%r14)
   5dd26:	movq   $0x82,0x8(%rdx)
   5dd2e:	lea    0xa973(%rip),%rax        # 686a8 <ref.11>
   5dd35:	mov    %rax,0x10(%rdx)
   5dd39:	mov    %r12,0x18(%rdx)
   5dd3d:	mov    %r13,0xa0(%rsp)
   5dd45:	mov    %rcx,0xa8(%rsp)
   5dd4d:	lea    0xa944(%rip),%rax        # 68698 <ref.10>
   5dd54:	mov    %rax,0xb0(%rsp)
   5dd5c:	mov    %rcx,0xb8(%rsp)
   5dd64:	movq   $0xc,0x58(%rsp)
   5dd6d:	mov    0xcaa4(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5dd74:	test   %r14,%r14
   5dd77:	je     5e600 <f.8+0x2cd0>
   5dd7d:	mov    0x178(%r14),%rcx
   5dd84:	test   %rcx,%rcx
   5dd87:	je     5ddc3 <f.8+0x2493>
   5dd89:	mov    0x170(%r14),%rax
   5dd90:	inc    %rax
   5dd93:	mov    %rax,0x170(%r14)
   5dd9a:	mov    %rax,%rdx
   5dd9d:	or     %rcx,%rdx
   5dda0:	shr    $0x20,%rdx
   5dda4:	je     5e5b8 <f.8+0x2c88>
   5ddaa:	xor    %edx,%edx
   5ddac:	div    %rcx
   5ddaf:	test   %rdx,%rdx
   5ddb2:	jne    5ddc3 <f.8+0x2493>
   5ddb4:	mov    0xca65(%rip),%rsi        # 6a820 <native_roots.0>
   5ddbb:	mov    %r14,%rdi
   5ddbe:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ddc3:	cmpq   $0x20,0x98(%r14)
   5ddcb:	jb     5e605 <f.8+0x2cd5>
   5ddd1:	mov    0xca48(%rip),%r15        # 6a820 <native_roots.0>
   5ddd8:	mov    0xe0(%r14),%rbx
   5dddf:	mov    0xe8(%r14),%r12
   5dde6:	cmp    %r12,%rbx
   5dde9:	jb     5ddf6 <f.8+0x24c6>
   5ddeb:	mov    %r14,%rdi
   5ddee:	mov    %r15,%rsi
   5ddf1:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ddf6:	mov    0xc8(%r14),%rdx
   5ddfd:	test   %rdx,%rdx
   5de00:	je     5de12 <f.8+0x24e2>
   5de02:	mov    0xd0(%r14),%rax
   5de09:	sub    %rdx,%rax
   5de0c:	cmp    $0x1f,%rax
   5de10:	ja     5de33 <f.8+0x2503>
   5de12:	mov    $0x20,%esi
   5de17:	mov    %r14,%rdi
   5de1a:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5de1f:	cmp    $0x1,%rax
   5de23:	jne    5deb1 <f.8+0x2581>
   5de29:	mov    $0x1,%eax
   5de2e:	jmp    5dec9 <f.8+0x2599>
   5de33:	lea    0x20(%rdx),%rax
   5de37:	mov    %rax,0xc8(%r14)
   5de3e:	mov    0x10(%r14),%rsi
   5de42:	mov    0xc0(%r14),%rdi
   5de49:	cmp    %rsi,%rdi
   5de4c:	jae    5e616 <f.8+0x2ce6>
   5de52:	mov    0x8(%r14),%rax
   5de56:	imul   $0x38,%rdi,%rcx
   5de5a:	mov    %rdx,%r8
   5de5d:	sub    0x18(%rax,%rcx,1),%r8
   5de62:	mov    %r8,%rdi
   5de65:	shr    $0xf,%rdi
   5de69:	mov    0x10(%rax,%rcx,1),%rsi
   5de6e:	cmp    %rsi,%rdi
   5de71:	jae    5e622 <f.8+0x2cf2>
   5de77:	add    %rcx,%rax
   5de7a:	mov    %r8d,%ecx
   5de7d:	imul   $0x220,%rdi,%rsi
   5de84:	add    0x8(%rax),%rsi
   5de88:	shr    $0x4,%ecx
   5de8b:	mov    $0x1,%eax
   5de90:	mov    $0x1,%edi
   5de95:	shl    %cl,%rdi
   5de98:	shr    $0x7,%r8d
   5de9c:	and    $0xf8,%r8d
   5dea3:	or     %rdi,(%r8,%rsi,1)
   5dea7:	cmp    $0x1,%rax
   5deab:	je     5de29 <f.8+0x24f9>
   5deb1:	xor    %edx,%edx
   5deb3:	cmp    %r12,%rbx
   5deb6:	setae  %dl
   5deb9:	mov    $0x20,%esi
   5debe:	mov    %r14,%rdi
   5dec1:	mov    %r15,%rcx
   5dec4:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5dec9:	mov    0x40(%rsp),%rcx
   5dece:	test   $0x1,%al
   5ded0:	je     5e605 <f.8+0x2cd5>
   5ded6:	movq   $0x61,(%rdx)
   5dedd:	pxor   %xmm0,%xmm0
   5dee1:	movdqu %xmm0,0x8(%rdx)
   5dee6:	movq   $0x0,0x18(%rdx)
   5deee:	addq   $0x20,0xe0(%r14)
   5def6:	movdqu 0x110(%r14),%xmm0
   5deff:	paddq  -0x59a17(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5df07:	lea    0x8(%rdx),%rbx
   5df0b:	movdqu %xmm0,0x110(%r14)
   5df14:	movq   $0x5e,0x8(%rdx)
   5df1c:	movl   $0x1,0x10(%rdx)
   5df23:	mov    %r13,0x18(%rdx)
   5df27:	mov    %rbx,0xa0(%rsp)
   5df2f:	mov    %rcx,0xa8(%rsp)
   5df37:	lea    0xa75a(%rip),%rax        # 68698 <ref.10>
   5df3e:	mov    %rax,0xb0(%rsp)
   5df46:	mov    %rcx,0xb8(%rsp)
   5df4e:	movq   $0xc,0x58(%rsp)
   5df57:	mov    0xc8ba(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5df5e:	test   %r14,%r14
   5df61:	je     5e600 <f.8+0x2cd0>
   5df67:	mov    0x178(%r14),%rcx
   5df6e:	test   %rcx,%rcx
   5df71:	je     5dfad <f.8+0x267d>
   5df73:	mov    0x170(%r14),%rax
   5df7a:	inc    %rax
   5df7d:	mov    %rax,0x170(%r14)
   5df84:	mov    %rax,%rdx
   5df87:	or     %rcx,%rdx
   5df8a:	shr    $0x20,%rdx
   5df8e:	je     5e5ca <f.8+0x2c9a>
   5df94:	xor    %edx,%edx
   5df96:	div    %rcx
   5df99:	test   %rdx,%rdx
   5df9c:	jne    5dfad <f.8+0x267d>
   5df9e:	mov    0xc87b(%rip),%rsi        # 6a820 <native_roots.0>
   5dfa5:	mov    %r14,%rdi
   5dfa8:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5dfad:	cmpq   $0x30,0x98(%r14)
   5dfb5:	jb     5e605 <f.8+0x2cd5>
   5dfbb:	mov    0xc85e(%rip),%r15        # 6a820 <native_roots.0>
   5dfc2:	mov    0xe0(%r14),%r12
   5dfc9:	mov    0xe8(%r14),%r13
   5dfd0:	cmp    %r13,%r12
   5dfd3:	jb     5dfe0 <f.8+0x26b0>
   5dfd5:	mov    %r14,%rdi
   5dfd8:	mov    %r15,%rsi
   5dfdb:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5dfe0:	mov    0xc8(%r14),%rdx
   5dfe7:	test   %rdx,%rdx
   5dfea:	je     5dffc <f.8+0x26cc>
   5dfec:	mov    0xd0(%r14),%rax
   5dff3:	sub    %rdx,%rax
   5dff6:	cmp    $0x2f,%rax
   5dffa:	ja     5e01d <f.8+0x26ed>
   5dffc:	mov    $0x30,%esi
   5e001:	mov    %r14,%rdi
   5e004:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5e009:	cmp    $0x1,%rax
   5e00d:	jne    5e09b <f.8+0x276b>
   5e013:	mov    $0x1,%eax
   5e018:	jmp    5e0b3 <f.8+0x2783>
   5e01d:	lea    0x30(%rdx),%rax
   5e021:	mov    %rax,0xc8(%r14)
   5e028:	mov    0x10(%r14),%rsi
   5e02c:	mov    0xc0(%r14),%rdi
   5e033:	cmp    %rsi,%rdi
   5e036:	jae    5e616 <f.8+0x2ce6>
   5e03c:	mov    0x8(%r14),%rax
   5e040:	imul   $0x38,%rdi,%rcx
   5e044:	mov    %rdx,%r8
   5e047:	sub    0x18(%rax,%rcx,1),%r8
   5e04c:	mov    %r8,%rdi
   5e04f:	shr    $0xf,%rdi
   5e053:	mov    0x10(%rax,%rcx,1),%rsi
   5e058:	cmp    %rsi,%rdi
   5e05b:	jae    5e622 <f.8+0x2cf2>
   5e061:	add    %rcx,%rax
   5e064:	mov    %r8d,%ecx
   5e067:	imul   $0x220,%rdi,%rsi
   5e06e:	add    0x8(%rax),%rsi
   5e072:	shr    $0x4,%ecx
   5e075:	mov    $0x1,%eax
   5e07a:	mov    $0x1,%edi
   5e07f:	shl    %cl,%rdi
   5e082:	shr    $0x7,%r8d
   5e086:	and    $0xf8,%r8d
   5e08d:	or     %rdi,(%r8,%rsi,1)
   5e091:	cmp    $0x1,%rax
   5e095:	je     5e013 <f.8+0x26e3>
   5e09b:	xor    %edx,%edx
   5e09d:	cmp    %r13,%r12
   5e0a0:	setae  %dl
   5e0a3:	mov    $0x30,%esi
   5e0a8:	mov    %r14,%rdi
   5e0ab:	mov    %r15,%rcx
   5e0ae:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5e0b3:	mov    0x40(%rsp),%rcx
   5e0b8:	test   $0x1,%al
   5e0ba:	je     5e605 <f.8+0x2cd5>
   5e0c0:	movq   $0x81,(%rdx)
   5e0c7:	pxor   %xmm0,%xmm0
   5e0cb:	movdqu %xmm0,0x8(%rdx)
   5e0d0:	movdqu %xmm0,0x18(%rdx)
   5e0d5:	addq   $0x30,0xe0(%r14)
   5e0dd:	movdqu 0x110(%r14),%xmm0
   5e0e6:	paddq  -0x59d7e(%rip),%xmm0        # 4370 <__abi_tag+0x403c>
   5e0ee:	lea    0x8(%rdx),%r12
   5e0f2:	movdqu %xmm0,0x110(%r14)
   5e0fb:	movq   $0x26,0x8(%rdx)
   5e103:	mov    0xe8(%rsp),%rax
   5e10b:	mov    %rax,0x10(%rdx)
   5e10f:	mov    %rcx,0x18(%rdx)
   5e113:	mov    %rbx,0x20(%rdx)
   5e117:	mov    %r12,0xa0(%rsp)
   5e11f:	lea    0xa572(%rip),%rax        # 68698 <ref.10>
   5e126:	mov    %rax,0xa8(%rsp)
   5e12e:	mov    %rcx,0xb0(%rsp)
   5e136:	movq   $0xb,0x58(%rsp)
   5e13f:	mov    0xc6d2(%rip),%r14        # 6a818 <snail_runtime::native::RUNTIME>
   5e146:	test   %r14,%r14
   5e149:	je     5e600 <f.8+0x2cd0>
   5e14f:	mov    0x178(%r14),%rcx
   5e156:	test   %rcx,%rcx
   5e159:	je     5e195 <f.8+0x2865>
   5e15b:	mov    0x170(%r14),%rax
   5e162:	inc    %rax
   5e165:	mov    %rax,0x170(%r14)
   5e16c:	mov    %rax,%rdx
   5e16f:	or     %rcx,%rdx
   5e172:	shr    $0x20,%rdx
   5e176:	je     5e5dc <f.8+0x2cac>
   5e17c:	xor    %edx,%edx
   5e17e:	div    %rcx
   5e181:	test   %rdx,%rdx
   5e184:	jne    5e195 <f.8+0x2865>
   5e186:	mov    0xc693(%rip),%rsi        # 6a820 <native_roots.0>
   5e18d:	mov    %r14,%rdi
   5e190:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5e195:	cmpq   $0x20,0x98(%r14)
   5e19d:	jb     5e605 <f.8+0x2cd5>
   5e1a3:	mov    0xc676(%rip),%r15        # 6a820 <native_roots.0>
   5e1aa:	mov    0xe0(%r14),%rbx
   5e1b1:	mov    0xe8(%r14),%r13
   5e1b8:	cmp    %r13,%rbx
   5e1bb:	jb     5e1c8 <f.8+0x2898>
   5e1bd:	mov    %r14,%rdi
   5e1c0:	mov    %r15,%rsi
   5e1c3:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5e1c8:	mov    0xc8(%r14),%rdx
   5e1cf:	test   %rdx,%rdx
   5e1d2:	je     5e1e4 <f.8+0x28b4>
   5e1d4:	mov    0xd0(%r14),%rax
   5e1db:	sub    %rdx,%rax
   5e1de:	cmp    $0x1f,%rax
   5e1e2:	ja     5e205 <f.8+0x28d5>
   5e1e4:	mov    $0x20,%esi
   5e1e9:	mov    %r14,%rdi
   5e1ec:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5e1f1:	cmp    $0x1,%rax
   5e1f5:	jne    5e283 <f.8+0x2953>
   5e1fb:	mov    $0x1,%eax
   5e200:	jmp    5e29b <f.8+0x296b>
   5e205:	lea    0x20(%rdx),%rax
   5e209:	mov    %rax,0xc8(%r14)
   5e210:	mov    0x10(%r14),%rsi
   5e214:	mov    0xc0(%r14),%rdi
   5e21b:	cmp    %rsi,%rdi
   5e21e:	jae    5e616 <f.8+0x2ce6>
   5e224:	mov    0x8(%r14),%rax
   5e228:	imul   $0x38,%rdi,%rcx
   5e22c:	mov    %rdx,%r8
   5e22f:	sub    0x18(%rax,%rcx,1),%r8
   5e234:	mov    %r8,%rdi
   5e237:	shr    $0xf,%rdi
   5e23b:	mov    0x10(%rax,%rcx,1),%rsi
   5e240:	cmp    %rsi,%rdi
   5e243:	jae    5e622 <f.8+0x2cf2>
   5e249:	add    %rcx,%rax
   5e24c:	mov    %r8d,%ecx
   5e24f:	imul   $0x220,%rdi,%rsi
   5e256:	add    0x8(%rax),%rsi
   5e25a:	shr    $0x4,%ecx
   5e25d:	mov    $0x1,%eax
   5e262:	mov    $0x1,%edi
   5e267:	shl    %cl,%rdi
   5e26a:	shr    $0x7,%r8d
   5e26e:	and    $0xf8,%r8d
   5e275:	or     %rdi,(%r8,%rsi,1)
   5e279:	cmp    $0x1,%rax
   5e27d:	je     5e1fb <f.8+0x28cb>
   5e283:	xor    %edx,%edx
   5e285:	cmp    %r13,%rbx
   5e288:	setae  %dl
   5e28b:	mov    $0x20,%esi
   5e290:	mov    %r14,%rdi
   5e293:	mov    %r15,%rcx
   5e296:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5e29b:	test   $0x1,%al
   5e29d:	je     5e605 <f.8+0x2cd5>
   5e2a3:	movq   $0x61,(%rdx)
   5e2aa:	pxor   %xmm0,%xmm0
   5e2ae:	movdqu %xmm0,0x8(%rdx)
   5e2b3:	movq   $0x0,0x18(%rdx)
   5e2bb:	addq   $0x20,0xe0(%r14)
   5e2c3:	movdqu 0x110(%r14),%xmm0
   5e2cc:	paddq  -0x59de4(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5e2d4:	lea    0x8(%rdx),%rax
   5e2d8:	movdqu %xmm0,0x110(%r14)
   5e2e1:	movq   $0x82,0x8(%rdx)
   5e2e9:	lea    0xa3a8(%rip),%rcx        # 68698 <ref.10>
   5e2f0:	mov    %rcx,0x10(%rdx)
   5e2f4:	mov    %r12,0x18(%rdx)
   5e2f8:	mov    0xf0(%rsp),%rcx
   5e300:	mov    %rax,0x18(%rcx)
   5e304:	mov    0x68(%rsp),%rax
   5e309:	test   %rax,%rax
   5e30c:	je     5e600 <f.8+0x2cd0>
   5e312:	movl   $0x1,0x8(%rax)
   5e319:	mov    0x68(%rsp),%rax
   5e31e:	test   %rax,%rax
   5e321:	je     5e600 <f.8+0x2cd0>
   5e327:	cmpl   $0x0,0x8(%rax)
   5e32b:	je     5e600 <f.8+0x2cd0>
   5e331:	mov    0x10(%rax),%rax
   5e335:	test   %rax,%rax
   5e338:	je     5e600 <f.8+0x2cd0>
   5e33e:	mov    %rax,0x80(%rsp)
   5e346:	mov    0x8(%rax),%rcx
   5e34a:	test   %rcx,%rcx
   5e34d:	je     5e600 <f.8+0x2cd0>
   5e353:	mov    0x10(%rax),%rdi
   5e357:	mov    0x8(%rcx),%rax
   5e35b:	mov    %rdi,0xa0(%rsp)
   5e363:	movq   $0x9,0x58(%rsp)
   5e36c:	mov    $0x4,%esi
   5e371:	call   *%rax
   5e373:	sub    $0x8,%rsp
   5e377:	cmpb   $0x0,0xc57a(%rip)        # 6a8f8 <g.3>
   5e37e:	je     5e600 <f.8+0x2cd0>
   5e384:	cmpq   $0x0,0xc564(%rip)        # 6a8f0 <g.2>
   5e38c:	je     5e600 <f.8+0x2cd0>
   5e392:	cmpb   $0x0,0xc5cf(%rip)        # 6a968 <g.17>
   5e399:	je     5e600 <f.8+0x2cd0>
   5e39f:	cmpq   $0x0,0xc5b9(%rip)        # 6a960 <g.16>
   5e3a7:	je     5e600 <f.8+0x2cd0>
   5e3ad:	mov    0x88(%rsp),%rax
   5e3b5:	test   %rax,%rax
   5e3b8:	je     5e600 <f.8+0x2cd0>
   5e3be:	test   $0x1,%al
   5e3c0:	jne    5e600 <f.8+0x2cd0>
   5e3c6:	mov    0x8(%rax),%rdx
   5e3ca:	mov    %edx,%esi
   5e3cc:	shr    $1,%esi
   5e3ce:	cmp    $0x3e9,%rsi
   5e3d5:	mov    $0x3e9,%ecx
   5e3da:	cmovb  %rsi,%rcx
   5e3de:	lea    -0x1(%rcx),%rsi
   5e3e2:	mov    %rsi,%rdi
   5e3e5:	shr    $0x20,%rdi
   5e3e9:	jne    5e600 <f.8+0x2cd0>
   5e3ef:	cmp    %rdx,%rsi
   5e3f2:	jae    5e600 <f.8+0x2cd0>
   5e3f8:	cmpb   $0x0,0xc579(%rip)        # 6a978 <g.19>
   5e3ff:	je     5e600 <f.8+0x2cd0>
   5e405:	cmpq   $0x0,0xc563(%rip)        # 6a970 <g.18>
   5e40d:	je     5e600 <f.8+0x2cd0>
   5e413:	movsd  0x8(%rax,%rcx,8),%xmm0
   5e419:	cvtsi2sd %ecx,%xmm1
   5e41d:	movsd  -0x584fd(%rip),%xmm2        # 5f28 <__abi_tag+0x5bf4>
   5e425:	divsd  %xmm1,%xmm2
   5e429:	ucomisd %xmm2,%xmm0
   5e42d:	jne    5e431 <f.8+0x2b01>
   5e42f:	jnp    5e486 <f.8+0x2b56>
   5e431:	movq   $0x8,0x58(%rsp)
   5e43a:	lea    0x83af(%rip),%rax        # 667f0 <__cxa_atexit@plt+0x1130>
   5e441:	mov    %rax,0x10(%rsp)
   5e446:	lea    -0x61bd(%rip),%r14        # 58290 <<&T as core::fmt::Display>::fmt>
   5e44d:	mov    %r14,0x18(%rsp)
   5e452:	lea    -0x57bc0(%rip),%rbx        # 6899 <__abi_tag+0x6565>
   5e459:	lea    0x10(%rsp),%rsi
   5e45e:	mov    %rbx,%rdi
   5e461:	call   4f6f0 <std::io::stdio::_print>
   5e466:	movq   $0x8,0x58(%rsp)
   5e46f:	mov    %rbp,0x10(%rsp)
   5e474:	mov    %r14,0x18(%rsp)
   5e479:	lea    0x10(%rsp),%rsi
   5e47e:	mov    %rbx,%rdi
   5e481:	call   4f6f0 <std::io::stdio::_print>
   5e486:	cmpb   $0x0,0xc51b(%rip)        # 6a9a8 <g.25>
   5e48d:	je     5e600 <f.8+0x2cd0>
   5e493:	cmpq   $0x0,0xc505(%rip)        # 6a9a0 <g.24>
   5e49b:	je     5e600 <f.8+0x2cd0>
   5e4a1:	movq   $0x8,0x58(%rsp)
   5e4aa:	lea    0x82df(%rip),%rax        # 66790 <__cxa_atexit@plt+0x10d0>
   5e4b1:	mov    %rax,0x10(%rsp)
   5e4b6:	lea    -0x622d(%rip),%r14        # 58290 <<&T as core::fmt::Display>::fmt>
   5e4bd:	mov    %r14,0x18(%rsp)
   5e4c2:	lea    -0x57c30(%rip),%rbx        # 6899 <__abi_tag+0x6565>
   5e4c9:	lea    0x10(%rsp),%rsi
   5e4ce:	mov    %rbx,%rdi
   5e4d1:	call   4f6f0 <std::io::stdio::_print>
   5e4d6:	movq   $0x8,0x58(%rsp)
   5e4df:	lea    0x82ba(%rip),%rax        # 667a0 <__cxa_atexit@plt+0x10e0>
   5e4e6:	mov    %rax,0x10(%rsp)
   5e4eb:	mov    %r14,0x18(%rsp)
   5e4f0:	lea    0x10(%rsp),%rsi
   5e4f5:	mov    %rbx,%rdi
   5e4f8:	call   4f6f0 <std::io::stdio::_print>
   5e4fd:	movq   $0x8,0x58(%rsp)
   5e506:	mov    %rbp,0x10(%rsp)
   5e50b:	mov    %r14,0x18(%rsp)
   5e510:	lea    0x10(%rsp),%rsi
   5e515:	mov    %rbx,%rdi
   5e518:	call   4f6f0 <std::io::stdio::_print>
   5e51d:	cmpq   $0x0,0x50(%rsp)
   5e523:	je     5e538 <f.8+0x2c08>
   5e525:	mov    0x48(%rsp),%rax
   5e52a:	mov    %rax,0xc2ef(%rip)        # 6a820 <native_roots.0>
   5e531:	decq   0xc2c8(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5e538:	add    $0xf8,%rsp
   5e53f:	pop    %rbx
   5e540:	pop    %r12
   5e542:	pop    %r13
   5e544:	pop    %r14
   5e546:	pop    %r15
   5e548:	pop    %rbp
   5e549:	ret    $0x8
   5e54c:	xor    %edx,%edx
   5e54e:	div    %ecx
   5e550:	test   %rdx,%rdx
   5e553:	jne    5d088 <f.8+0x1758>
   5e559:	jmp    5d079 <f.8+0x1749>
   5e55e:	xor    %edx,%edx
   5e560:	div    %ecx
   5e562:	test   %rdx,%rdx
   5e565:	jne    5d2c4 <f.8+0x1994>
   5e56b:	jmp    5d2b5 <f.8+0x1985>
   5e570:	xor    %edx,%edx
   5e572:	div    %ecx
   5e574:	test   %rdx,%rdx
   5e577:	jne    5d4bd <f.8+0x1b8d>
   5e57d:	jmp    5d4ae <f.8+0x1b7e>
   5e582:	xor    %edx,%edx
   5e584:	div    %ecx
   5e586:	test   %rdx,%rdx
   5e589:	jne    5d791 <f.8+0x1e61>
   5e58f:	jmp    5d782 <f.8+0x1e52>
   5e594:	xor    %edx,%edx
   5e596:	div    %ecx
   5e598:	test   %rdx,%rdx
   5e59b:	jne    5d9c2 <f.8+0x2092>
   5e5a1:	jmp    5d9b3 <f.8+0x2083>
   5e5a6:	xor    %edx,%edx
   5e5a8:	div    %ecx
   5e5aa:	test   %rdx,%rdx
   5e5ad:	jne    5dbd5 <f.8+0x22a5>
   5e5b3:	jmp    5dbc6 <f.8+0x2296>
   5e5b8:	xor    %edx,%edx
   5e5ba:	div    %ecx
   5e5bc:	test   %rdx,%rdx
   5e5bf:	jne    5ddc3 <f.8+0x2493>
   5e5c5:	jmp    5ddb4 <f.8+0x2484>
   5e5ca:	xor    %edx,%edx
   5e5cc:	div    %ecx
   5e5ce:	test   %rdx,%rdx
   5e5d1:	jne    5dfad <f.8+0x267d>
   5e5d7:	jmp    5df9e <f.8+0x266e>
   5e5dc:	xor    %edx,%edx
   5e5de:	div    %ecx
   5e5e0:	test   %rdx,%rdx
   5e5e3:	jne    5e195 <f.8+0x2865>
   5e5e9:	jmp    5e186 <f.8+0x2856>
   5e5ee:	xor    %edx,%edx
   5e5f0:	div    %ecx
   5e5f2:	test   %rdx,%rdx
   5e5f5:	jne    5cd55 <f.8+0x1425>
   5e5fb:	jmp    5cd46 <f.8+0x1416>
   5e600:	call   56d70 <native_trap>
   5e605:	lea    -0x551b8(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5e60c:	mov    $0x2f,%esi
   5e611:	call   57d70 <snail_runtime::native::fail_bytes>
   5e616:	lea    0x8fa3(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   5e61d:	call   207b0 <core::panicking::panic_bounds_check>
   5e622:	lea    0x8faf(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   5e629:	call   207b0 <core::panicking::panic_bounds_check>
   5e62e:	int3
   5e62f:	int3
