   63080:	push   %rbp
   63081:	push   %r15
   63083:	push   %r14
   63085:	push   %r13
   63087:	push   %r12
   63089:	push   %rbx
   6308a:	sub    $0x68,%rsp
   6308e:	mov    %rsi,0x58(%rsp)
   63093:	movq   $0x6,0x18(%rsp)
   6309c:	movq   $0x0,0x20(%rsp)
   630a5:	mov    0x7774(%rip),%rcx        # 6a820 <native_roots.0>
   630ac:	mov    %rcx,0x10(%rsp)
   630b1:	lea    0x10(%rsp),%r8
   630b6:	mov    0x7743(%rip),%rdx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   630bd:	lea    0x1(%rdx),%rax
   630c1:	mov    0x7740(%rip),%rsi        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   630c8:	cmp    %rsi,%rax
   630cb:	cmova  %rax,%rsi
   630cf:	mov    %r8,0x774a(%rip)        # 6a820 <native_roots.0>
   630d6:	mov    %rax,0x7723(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   630dd:	mov    %rsi,0x7724(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   630e4:	mov    %rdi,0x28(%rsp)
   630e9:	pxor   %xmm0,%xmm0
   630ed:	movdqu %xmm0,0x30(%rsp)
   630f3:	movq   $0x0,0x40(%rsp)
   630fc:	test   %rdi,%rdi
   630ff:	je     63183 <f.14+0x103>
   63105:	mov    %edi,%eax
   63107:	and    $0x1,%eax
   6310a:	jne    63183 <f.14+0x103>
   6310c:	mov    0x7705(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   63113:	test   %r12,%r12
   63116:	je     63183 <f.14+0x103>
   63118:	mov    (%rdi),%rax
   6311b:	mov    %rax,%rsi
   6311e:	test   %rax,%rax
   63121:	je     6317d <f.14+0xfd>
   63123:	mov    %rax,%rsi
   63126:	cmp    $0x1a,%rax
   6312a:	je     6317d <f.14+0xfd>
   6312c:	mov    0x168(%r12),%r8
   63134:	mov    %rax,%rsi
   63137:	shr    $0x2,%rsi
   6313b:	lea    -0x1(%rsi),%r9
   6313f:	cmp    %r8,%r9
   63142:	jae    63183 <f.14+0x103>
   63144:	mov    0x160(%r12),%r9
   6314c:	mov    -0x8(%r9,%rsi,8),%rsi
   63151:	test   %rsi,%rsi
   63154:	je     6317d <f.14+0xfd>
   63156:	cmp    $0x1a,%rsi
   6315a:	je     6317d <f.14+0xfd>
   6315c:	nopl   0x0(%rax)
   63160:	shr    $0x2,%rsi
   63164:	lea    -0x1(%rsi),%r10
   63168:	cmp    %r8,%r10
   6316b:	jae    63183 <f.14+0x103>
   6316d:	mov    -0x8(%r9,%rsi,8),%rsi
   63172:	cmp    $0x1a,%rsi
   63176:	je     6317d <f.14+0xfd>
   63178:	test   %rsi,%rsi
   6317b:	jne    63160 <f.14+0xe0>
   6317d:	cmp    $0x1a,%rsi
   63181:	je     6319e <f.14+0x11e>
   63183:	call   56d70 <native_trap>
   63188:	nopl   0x0(%rax,%rax,1)
   63190:	incq   0x58(%rsp)
   63195:	sub    %rsi,%rdx
   63198:	cmp    $0x1a,%r8
   6319c:	jne    63183 <f.14+0x103>
   6319e:	mov    0x58(%rsp),%rsi
   631a3:	cmp    %rsi,0x18(%rdi)
   631a7:	jle    63bcc <f.14+0xb4c>
   631ad:	test   $0x1,%dil
   631b1:	jne    63183 <f.14+0x103>
   631b3:	test   %rax,%rax
   631b6:	je     63210 <f.14+0x190>
   631b8:	cmp    $0x1a,%rax
   631bc:	je     63210 <f.14+0x190>
   631be:	mov    0x168(%r12),%rcx
   631c6:	shr    $0x2,%rax
   631ca:	lea    -0x1(%rax),%rdx
   631ce:	cmp    %rcx,%rdx
   631d1:	jae    63183 <f.14+0x103>
   631d3:	mov    0x160(%r12),%rdx
   631db:	mov    -0x8(%rdx,%rax,8),%rax
   631e0:	test   %rax,%rax
   631e3:	je     63210 <f.14+0x190>
   631e5:	cmp    $0x1a,%rax
   631e9:	je     63210 <f.14+0x190>
   631eb:	nopl   0x0(%rax,%rax,1)
   631f0:	shr    $0x2,%rax
   631f4:	lea    -0x1(%rax),%rsi
   631f8:	cmp    %rcx,%rsi
   631fb:	jae    63183 <f.14+0x103>
   631fd:	mov    -0x8(%rdx,%rax,8),%rax
   63202:	cmp    $0x1a,%rax
   63206:	je     63210 <f.14+0x190>
   63208:	test   %rax,%rax
   6320b:	jne    631f0 <f.14+0x170>
   6320d:	nopl   (%rax)
   63210:	cmp    $0x1a,%rax
   63214:	jne    63183 <f.14+0x103>
   6321a:	mov    %rdi,0x30(%rsp)
   6321f:	cmpb   $0x0,0x76e2(%rip)        # 6a908 <g.5>
   63226:	je     63183 <f.14+0x103>
   6322c:	cmpq   $0x0,0x76cc(%rip)        # 6a900 <g.4>
   63234:	je     63183 <f.14+0x103>
   6323a:	mov    0x8(%rdi),%rax
   6323e:	test   %rax,%rax
   63241:	je     63183 <f.14+0x103>
   63247:	cmpl   $0x0,0x8(%rax)
   6324b:	je     63183 <f.14+0x103>
   63251:	mov    0x10(%rdi),%rax
   63255:	mov    %rax,0x60(%rsp)
   6325a:	lea    -0x58551(%rip),%rax        # ad10 <object.1.0>
   63261:	mov    %rax,0x48(%rsp)
   63266:	movq   $0x5,0x20(%rsp)
   6326f:	mov    0x178(%r12),%rcx
   63277:	lea    0x10(%rsp),%r13
   6327c:	test   %rcx,%rcx
   6327f:	je     632c2 <f.14+0x242>
   63281:	mov    0x170(%r12),%rax
   63289:	inc    %rax
   6328c:	mov    %rax,0x170(%r12)
   63294:	mov    %rax,%rdx
   63297:	or     %rcx,%rdx
   6329a:	shr    $0x20,%rdx
   6329e:	je     63900 <f.14+0x880>
   632a4:	xor    %edx,%edx
   632a6:	div    %rcx
   632a9:	test   %rdx,%rdx
   632ac:	jne    632c2 <f.14+0x242>
   632ae:	mov    %r12,%rdi
   632b1:	lea    0x10(%rsp),%rsi
   632b6:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   632bb:	mov    0x755e(%rip),%r13        # 6a820 <native_roots.0>
   632c2:	cmpq   $0x20,0x98(%r12)
   632cb:	jb     63bed <f.14+0xb6d>
   632d1:	mov    0xe0(%r12),%r14
   632d9:	mov    0xe8(%r12),%r15
   632e1:	cmp    %r15,%r14
   632e4:	jb     632f1 <f.14+0x271>
   632e6:	mov    %r12,%rdi
   632e9:	mov    %r13,%rsi
   632ec:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   632f1:	mov    0xc8(%r12),%rdx
   632f9:	test   %rdx,%rdx
   632fc:	je     6330f <f.14+0x28f>
   632fe:	mov    0xd0(%r12),%rax
   63306:	sub    %rdx,%rax
   63309:	cmp    $0x1f,%rax
   6330d:	ja     63330 <f.14+0x2b0>
   6330f:	mov    $0x20,%esi
   63314:	mov    %r12,%rdi
   63317:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   6331c:	cmp    $0x1,%rax
   63320:	jne    633b2 <f.14+0x332>
   63326:	mov    $0x1,%eax
   6332b:	jmp    633ca <f.14+0x34a>
   63330:	lea    0x20(%rdx),%rax
   63334:	mov    %rax,0xc8(%r12)
   6333c:	mov    0x10(%r12),%rsi
   63341:	mov    0xc0(%r12),%rdi
   63349:	cmp    %rsi,%rdi
   6334c:	jae    63bfe <f.14+0xb7e>
   63352:	mov    0x8(%r12),%rax
   63357:	imul   $0x38,%rdi,%rcx
   6335b:	mov    %rdx,%r8
   6335e:	sub    0x18(%rax,%rcx,1),%r8
   63363:	mov    %r8,%rdi
   63366:	shr    $0xf,%rdi
   6336a:	mov    0x10(%rax,%rcx,1),%rsi
   6336f:	cmp    %rsi,%rdi
   63372:	jae    63c0a <f.14+0xb8a>
   63378:	add    %rcx,%rax
   6337b:	mov    %r8d,%ecx
   6337e:	imul   $0x220,%rdi,%rsi
   63385:	add    0x8(%rax),%rsi
   63389:	shr    $0x4,%ecx
   6338c:	mov    $0x1,%eax
   63391:	mov    $0x1,%edi
   63396:	shl    %cl,%rdi
   63399:	shr    $0x7,%r8d
   6339d:	and    $0xf8,%r8d
   633a4:	or     %rdi,(%r8,%rsi,1)
   633a8:	cmp    $0x1,%rax
   633ac:	je     63326 <f.14+0x2a6>
   633b2:	xor    %edx,%edx
   633b4:	cmp    %r15,%r14
   633b7:	setae  %dl
   633ba:	mov    $0x20,%esi
   633bf:	mov    %r12,%rdi
   633c2:	mov    %r13,%rcx
   633c5:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   633ca:	test   $0x1,%al
   633cc:	je     63bed <f.14+0xb6d>
   633d2:	movq   $0x41,(%rdx)
   633d9:	pxor   %xmm0,%xmm0
   633dd:	movdqu %xmm0,0x8(%rdx)
   633e2:	addq   $0x20,0xe0(%r12)
   633eb:	lea    0x8(%rdx),%r14
   633ef:	movdqu 0x110(%r12),%xmm0
   633f9:	paddq  -0x5eeb1(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   63401:	movdqu %xmm0,0x110(%r12)
   6340b:	movq   $0x36,0x8(%rdx)
   63413:	lea    -0x5870a(%rip),%rax        # ad10 <object.1.0>
   6341a:	mov    %rax,0x10(%rdx)
   6341e:	mov    %rax,0x48(%rsp)
   63423:	mov    %r14,0x50(%rsp)
   63428:	movq   $0x6,0x20(%rsp)
   63431:	mov    0x73e0(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   63438:	test   %r12,%r12
   6343b:	je     63183 <f.14+0x103>
   63441:	mov    0x178(%r12),%rcx
   63449:	test   %rcx,%rcx
   6344c:	je     6348a <f.14+0x40a>
   6344e:	mov    0x170(%r12),%rax
   63456:	inc    %rax
   63459:	mov    %rax,0x170(%r12)
   63461:	mov    %rax,%rdx
   63464:	or     %rcx,%rdx
   63467:	shr    $0x20,%rdx
   6346b:	je     63920 <f.14+0x8a0>
   63471:	xor    %edx,%edx
   63473:	div    %rcx
   63476:	test   %rdx,%rdx
   63479:	jne    6348a <f.14+0x40a>
   6347b:	mov    0x739e(%rip),%rsi        # 6a820 <native_roots.0>
   63482:	mov    %r12,%rdi
   63485:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6348a:	cmpq   $0x20,0x98(%r12)
   63493:	jb     63bed <f.14+0xb6d>
   63499:	mov    0x7380(%rip),%r13        # 6a820 <native_roots.0>
   634a0:	mov    0xe0(%r12),%r15
   634a8:	mov    0xe8(%r12),%rbp
   634b0:	cmp    %rbp,%r15
   634b3:	jb     634c0 <f.14+0x440>
   634b5:	mov    %r12,%rdi
   634b8:	mov    %r13,%rsi
   634bb:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   634c0:	mov    0xc8(%r12),%rdx
   634c8:	test   %rdx,%rdx
   634cb:	je     634de <f.14+0x45e>
   634cd:	mov    0xd0(%r12),%rax
   634d5:	sub    %rdx,%rax
   634d8:	cmp    $0x1f,%rax
   634dc:	ja     63500 <f.14+0x480>
   634de:	mov    $0x20,%esi
   634e3:	mov    %r12,%rdi
   634e6:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   634eb:	cmp    $0x1,%rax
   634ef:	jne    63582 <f.14+0x502>
   634f5:	mov    $0x1,%eax
   634fa:	jmp    6359a <f.14+0x51a>
   634ff:	nop
   63500:	lea    0x20(%rdx),%rax
   63504:	mov    %rax,0xc8(%r12)
   6350c:	mov    0x10(%r12),%rsi
   63511:	mov    0xc0(%r12),%rdi
   63519:	cmp    %rsi,%rdi
   6351c:	jae    63bfe <f.14+0xb7e>
   63522:	mov    0x8(%r12),%rax
   63527:	imul   $0x38,%rdi,%rcx
   6352b:	mov    %rdx,%r8
   6352e:	sub    0x18(%rax,%rcx,1),%r8
   63533:	mov    %r8,%rdi
   63536:	shr    $0xf,%rdi
   6353a:	mov    0x10(%rax,%rcx,1),%rsi
   6353f:	cmp    %rsi,%rdi
   63542:	jae    63c0a <f.14+0xb8a>
   63548:	add    %rcx,%rax
   6354b:	mov    %r8d,%ecx
   6354e:	imul   $0x220,%rdi,%rsi
   63555:	add    0x8(%rax),%rsi
   63559:	shr    $0x4,%ecx
   6355c:	mov    $0x1,%eax
   63561:	mov    $0x1,%edi
   63566:	shl    %cl,%rdi
   63569:	shr    $0x7,%r8d
   6356d:	and    $0xf8,%r8d
   63574:	or     %rdi,(%r8,%rsi,1)
   63578:	cmp    $0x1,%rax
   6357c:	je     634f5 <f.14+0x475>
   63582:	xor    %edx,%edx
   63584:	cmp    %rbp,%r15
   63587:	setae  %dl
   6358a:	mov    $0x20,%esi
   6358f:	mov    %r12,%rdi
   63592:	mov    %r13,%rcx
   63595:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   6359a:	test   $0x1,%al
   6359c:	je     63bed <f.14+0xb6d>
   635a2:	movq   $0x41,(%rdx)
   635a9:	pxor   %xmm0,%xmm0
   635ad:	movdqu %xmm0,0x8(%rdx)
   635b2:	addq   $0x20,0xe0(%r12)
   635bb:	lea    0x8(%rdx),%r15
   635bf:	movdqu 0x110(%r12),%xmm0
   635c9:	paddq  -0x5f081(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   635d1:	movdqu %xmm0,0x110(%r12)
   635db:	movq   $0x36,0x8(%rdx)
   635e3:	lea    -0x588da(%rip),%rax        # ad10 <object.1.0>
   635ea:	mov    %rax,0x10(%rdx)
   635ee:	mov    %r15,0x48(%rsp)
   635f3:	mov    %r14,0x50(%rsp)
   635f8:	movq   $0x6,0x20(%rsp)
   63601:	mov    0x7210(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   63608:	test   %r12,%r12
   6360b:	je     63183 <f.14+0x103>
   63611:	mov    0x178(%r12),%rcx
   63619:	test   %rcx,%rcx
   6361c:	je     6365a <f.14+0x5da>
   6361e:	mov    0x170(%r12),%rax
   63626:	inc    %rax
   63629:	mov    %rax,0x170(%r12)
   63631:	mov    %rax,%rdx
   63634:	or     %rcx,%rdx
   63637:	shr    $0x20,%rdx
   6363b:	je     63940 <f.14+0x8c0>
   63641:	xor    %edx,%edx
   63643:	div    %rcx
   63646:	test   %rdx,%rdx
   63649:	jne    6365a <f.14+0x5da>
   6364b:	mov    0x71ce(%rip),%rsi        # 6a820 <native_roots.0>
   63652:	mov    %r12,%rdi
   63655:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6365a:	cmpq   $0x20,0x98(%r12)
   63663:	jb     63bed <f.14+0xb6d>
   63669:	mov    0x71b0(%rip),%r13        # 6a820 <native_roots.0>
   63670:	mov    0xe0(%r12),%rbp
   63678:	mov    0xe8(%r12),%rbx
   63680:	cmp    %rbx,%rbp
   63683:	jb     63690 <f.14+0x610>
   63685:	mov    %r12,%rdi
   63688:	mov    %r13,%rsi
   6368b:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   63690:	mov    0xc8(%r12),%rdx
   63698:	test   %rdx,%rdx
   6369b:	je     636ae <f.14+0x62e>
   6369d:	mov    0xd0(%r12),%rax
   636a5:	sub    %rdx,%rax
   636a8:	cmp    $0x1f,%rax
   636ac:	ja     636d0 <f.14+0x650>
   636ae:	mov    $0x20,%esi
   636b3:	mov    %r12,%rdi
   636b6:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   636bb:	cmp    $0x1,%rax
   636bf:	jne    63752 <f.14+0x6d2>
   636c5:	mov    $0x1,%eax
   636ca:	jmp    6376a <f.14+0x6ea>
   636cf:	nop
   636d0:	lea    0x20(%rdx),%rax
   636d4:	mov    %rax,0xc8(%r12)
   636dc:	mov    0x10(%r12),%rsi
   636e1:	mov    0xc0(%r12),%rdi
   636e9:	cmp    %rsi,%rdi
   636ec:	jae    63bfe <f.14+0xb7e>
   636f2:	mov    0x8(%r12),%rax
   636f7:	imul   $0x38,%rdi,%rcx
   636fb:	mov    %rdx,%r8
   636fe:	sub    0x18(%rax,%rcx,1),%r8
   63703:	mov    %r8,%rdi
   63706:	shr    $0xf,%rdi
   6370a:	mov    0x10(%rax,%rcx,1),%rsi
   6370f:	cmp    %rsi,%rdi
   63712:	jae    63c0a <f.14+0xb8a>
   63718:	add    %rcx,%rax
   6371b:	mov    %r8d,%ecx
   6371e:	imul   $0x220,%rdi,%rsi
   63725:	add    0x8(%rax),%rsi
   63729:	shr    $0x4,%ecx
   6372c:	mov    $0x1,%eax
   63731:	mov    $0x1,%edi
   63736:	shl    %cl,%rdi
   63739:	shr    $0x7,%r8d
   6373d:	and    $0xf8,%r8d
   63744:	or     %rdi,(%r8,%rsi,1)
   63748:	cmp    $0x1,%rax
   6374c:	je     636c5 <f.14+0x645>
   63752:	xor    %edx,%edx
   63754:	cmp    %rbx,%rbp
   63757:	setae  %dl
   6375a:	mov    $0x20,%esi
   6375f:	mov    %r12,%rdi
   63762:	mov    %r13,%rcx
   63765:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   6376a:	test   $0x1,%al
   6376c:	je     63bed <f.14+0xb6d>
   63772:	movq   $0x61,(%rdx)
   63779:	lea    0x8(%rdx),%rbp
   6377d:	pxor   %xmm0,%xmm0
   63781:	movdqu %xmm0,0x8(%rdx)
   63786:	movq   $0x0,0x18(%rdx)
   6378e:	addq   $0x20,0xe0(%r12)
   63797:	movdqu 0x110(%r12),%xmm0
   637a1:	paddq  -0x5f2b9(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   637a9:	movdqu %xmm0,0x110(%r12)
   637b3:	movq   $0x46,0x8(%rdx)
   637bb:	mov    %r14,0x10(%rdx)
   637bf:	mov    %r15,0x18(%rdx)
   637c3:	mov    %rbp,0x38(%rsp)
   637c8:	mov    0x30(%rsp),%rdi
   637cd:	test   %rdi,%rdi
   637d0:	je     63183 <f.14+0x103>
   637d6:	mov    0x8(%rdi),%rax
   637da:	test   %rax,%rax
   637dd:	je     63183 <f.14+0x103>
   637e3:	mov    0x10(%rax),%rax
   637e7:	test   %rax,%rax
   637ea:	je     63183 <f.14+0x103>
   637f0:	mov    0x8(%rax),%rax
   637f4:	mov    %rax,0x40(%rsp)
   637f9:	cmpq   $0x0,0x60(%rsp)
   637ff:	jle    63a72 <f.14+0x9f2>
   63805:	test   %rax,%rax
   63808:	je     63183 <f.14+0x103>
   6380e:	mov    0x8(%rax),%r14
   63812:	mov    %rbp,0x48(%rsp)
   63817:	mov    %r14,0x50(%rsp)
   6381c:	movq   $0x6,0x20(%rsp)
   63825:	mov    0x6fec(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   6382c:	test   %r12,%r12
   6382f:	je     63183 <f.14+0x103>
   63835:	mov    0x178(%r12),%rcx
   6383d:	test   %rcx,%rcx
   63840:	je     6387e <f.14+0x7fe>
   63842:	mov    0x170(%r12),%rax
   6384a:	inc    %rax
   6384d:	mov    %rax,0x170(%r12)
   63855:	mov    %rax,%rdx
   63858:	or     %rcx,%rdx
   6385b:	shr    $0x20,%rdx
   6385f:	je     63bba <f.14+0xb3a>
   63865:	xor    %edx,%edx
   63867:	div    %rcx
   6386a:	test   %rdx,%rdx
   6386d:	jne    6387e <f.14+0x7fe>
   6386f:	mov    0x6faa(%rip),%rsi        # 6a820 <native_roots.0>
   63876:	mov    %r12,%rdi
   63879:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6387e:	cmpq   $0x20,0x98(%r12)
   63887:	jb     63bed <f.14+0xb6d>
   6388d:	mov    0x6f8c(%rip),%r13        # 6a820 <native_roots.0>
   63894:	mov    0xe0(%r12),%r15
   6389c:	mov    0xe8(%r12),%rbx
   638a4:	cmp    %rbx,%r15
   638a7:	jb     638b4 <f.14+0x834>
   638a9:	mov    %r12,%rdi
   638ac:	mov    %r13,%rsi
   638af:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   638b4:	mov    0xc8(%r12),%rdx
   638bc:	test   %rdx,%rdx
   638bf:	je     638d6 <f.14+0x856>
   638c1:	mov    0xd0(%r12),%rax
   638c9:	sub    %rdx,%rax
   638cc:	cmp    $0x1f,%rax
   638d0:	ja     63952 <f.14+0x8d2>
   638d6:	mov    $0x20,%esi
   638db:	mov    %r12,%rdi
   638de:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   638e3:	cmp    $0x1,%rax
   638e7:	jne    639d4 <f.14+0x954>
   638ed:	mov    $0x1,%eax
   638f2:	jmp    639ec <f.14+0x96c>
   638f7:	nopw   0x0(%rax,%rax,1)
   63900:	xor    %edx,%edx
   63902:	div    %ecx
   63904:	test   %rdx,%rdx
   63907:	jne    632c2 <f.14+0x242>
   6390d:	jmp    632ae <f.14+0x22e>
   63912:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   63920:	xor    %edx,%edx
   63922:	div    %ecx
   63924:	test   %rdx,%rdx
   63927:	jne    6348a <f.14+0x40a>
   6392d:	jmp    6347b <f.14+0x3fb>
   63932:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   63940:	xor    %edx,%edx
   63942:	div    %ecx
   63944:	test   %rdx,%rdx
   63947:	jne    6365a <f.14+0x5da>
   6394d:	jmp    6364b <f.14+0x5cb>
   63952:	lea    0x20(%rdx),%rax
   63956:	mov    %rax,0xc8(%r12)
   6395e:	mov    0x10(%r12),%rsi
   63963:	mov    0xc0(%r12),%rdi
   6396b:	cmp    %rsi,%rdi
   6396e:	jae    63bfe <f.14+0xb7e>
   63974:	mov    0x8(%r12),%rax
   63979:	imul   $0x38,%rdi,%rcx
   6397d:	mov    %rdx,%r8
   63980:	sub    0x18(%rax,%rcx,1),%r8
   63985:	mov    %r8,%rdi
   63988:	shr    $0xf,%rdi
   6398c:	mov    0x10(%rax,%rcx,1),%rsi
   63991:	cmp    %rsi,%rdi
   63994:	jae    63c0a <f.14+0xb8a>
   6399a:	add    %rcx,%rax
   6399d:	mov    %r8d,%ecx
   639a0:	imul   $0x220,%rdi,%rsi
   639a7:	add    0x8(%rax),%rsi
   639ab:	shr    $0x4,%ecx
   639ae:	mov    $0x1,%eax
   639b3:	mov    $0x1,%edi
   639b8:	shl    %cl,%rdi
   639bb:	shr    $0x7,%r8d
   639bf:	and    $0xf8,%r8d
   639c6:	or     %rdi,(%r8,%rsi,1)
   639ca:	cmp    $0x1,%rax
   639ce:	je     638ed <f.14+0x86d>
   639d4:	xor    %edx,%edx
   639d6:	cmp    %rbx,%r15
   639d9:	setae  %dl
   639dc:	mov    $0x20,%esi
   639e1:	mov    %r12,%rdi
   639e4:	mov    %r13,%rcx
   639e7:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   639ec:	test   $0x1,%al
   639ee:	je     63bed <f.14+0xb6d>
   639f4:	movq   $0x61,(%rdx)
   639fb:	lea    0x8(%rdx),%rdi
   639ff:	pxor   %xmm0,%xmm0
   63a03:	movdqu %xmm0,0x8(%rdx)
   63a08:	movq   $0x0,0x18(%rdx)
   63a10:	addq   $0x20,0xe0(%r12)
   63a19:	movdqu 0x110(%r12),%xmm0
   63a23:	paddq  -0x5f53b(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   63a2b:	movdqu %xmm0,0x110(%r12)
   63a35:	movq   $0x32,0x8(%rdx)
   63a3d:	mov    %r14,0x10(%rdx)
   63a41:	mov    %rbp,0x18(%rdx)
   63a45:	mov    0x60(%rsp),%rsi
   63a4a:	dec    %rsi
   63a4d:	mov    %rdi,0x48(%rsp)
   63a52:	movq   $0x5,0x20(%rsp)
   63a5b:	call   5f1d0 <f.17>
   63a60:	sub    $0x8,%rsp
   63a64:	mov    0x30(%rsp),%rdi
   63a69:	test   %rdi,%rdi
   63a6c:	je     63183 <f.14+0x103>
   63a72:	mov    0x20(%rdi),%rax
   63a76:	test   %rax,%rax
   63a79:	je     63183 <f.14+0x103>
   63a7f:	cmpl   $0x0,0x8(%rax)
   63a83:	je     63183 <f.14+0x103>
   63a89:	cmpq   $0x0,0x10(%rax)
   63a8e:	je     63183 <f.14+0x103>
   63a94:	xor    %esi,%esi
   63a96:	cmpq   $0x0,0x18(%rsp)
   63a9c:	setne  %sil
   63aa0:	lea    0x6d79(%rip),%rax        # 6a820 <native_roots.0>
   63aa7:	lea    0x10(%rsp),%r8
   63aac:	cmovne %r8,%rax
   63ab0:	mov    0x6d49(%rip),%rdx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   63ab7:	mov    (%rax),%rcx
   63aba:	movq   $0x6,0x18(%rsp)
   63ac3:	movq   $0x0,0x20(%rsp)
   63acc:	mov    %rcx,0x10(%rsp)
   63ad1:	mov    %r8,0x6d48(%rip)        # 6a820 <native_roots.0>
   63ad8:	mov    %rsi,%rax
   63adb:	neg    %rax
   63ade:	add    %rdx,%rax
   63ae1:	inc    %rax
   63ae4:	mov    %rax,0x6d15(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   63aeb:	mov    0x6d16(%rip),%r8        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   63af2:	cmp    %r8,%rax
   63af5:	cmova  %rax,%r8
   63af9:	mov    %r8,0x6d08(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   63b00:	mov    %rdi,0x28(%rsp)
   63b05:	lea    0x30(%rsp),%rax
   63b0a:	pxor   %xmm0,%xmm0
   63b0e:	movdqu %xmm0,(%rax)
   63b12:	movq   $0x0,0x10(%rax)
   63b1a:	test   $0x1,%dil
   63b1e:	jne    63183 <f.14+0x103>
   63b24:	mov    0x6ced(%rip),%r12        # 6a818 <snail_runtime::native::RUNTIME>
   63b2b:	test   %r12,%r12
   63b2e:	je     63183 <f.14+0x103>
   63b34:	mov    (%rdi),%rax
   63b37:	mov    %rax,%r8
   63b3a:	test   %rax,%rax
   63b3d:	je     63190 <f.14+0x110>
   63b43:	mov    %rax,%r8
   63b46:	cmp    $0x1a,%rax
   63b4a:	je     63190 <f.14+0x110>
   63b50:	mov    0x168(%r12),%r9
   63b58:	mov    %rax,%r8
   63b5b:	shr    $0x2,%r8
   63b5f:	lea    -0x1(%r8),%r10
   63b63:	cmp    %r9,%r10
   63b66:	jae    63183 <f.14+0x103>
   63b6c:	mov    0x160(%r12),%r10
   63b74:	mov    -0x8(%r10,%r8,8),%r8
   63b79:	test   %r8,%r8
   63b7c:	je     63190 <f.14+0x110>
   63b82:	cmp    $0x1a,%r8
   63b86:	je     63190 <f.14+0x110>
   63b8c:	nopl   0x0(%rax)
   63b90:	shr    $0x2,%r8
   63b94:	lea    -0x1(%r8),%r11
   63b98:	cmp    %r9,%r11
   63b9b:	jae    63183 <f.14+0x103>
   63ba1:	mov    -0x8(%r10,%r8,8),%r8
   63ba6:	cmp    $0x1a,%r8
   63baa:	je     63190 <f.14+0x110>
   63bb0:	test   %r8,%r8
   63bb3:	jne    63b90 <f.14+0xb10>
   63bb5:	jmp    63190 <f.14+0x110>
   63bba:	xor    %edx,%edx
   63bbc:	div    %ecx
   63bbe:	test   %rdx,%rdx
   63bc1:	jne    6387e <f.14+0x7fe>
   63bc7:	jmp    6386f <f.14+0x7ef>
   63bcc:	mov    %rcx,0x6c4d(%rip)        # 6a820 <native_roots.0>
   63bd3:	mov    %rdx,0x6c26(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   63bda:	xor    %eax,%eax
   63bdc:	add    $0x68,%rsp
   63be0:	pop    %rbx
   63be1:	pop    %r12
   63be3:	pop    %r13
   63be5:	pop    %r14
   63be7:	pop    %r15
   63be9:	pop    %rbp
   63bea:	ret    $0x8
   63bed:	lea    -0x5a7a0(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   63bf4:	mov    $0x2f,%esi
   63bf9:	call   57d70 <snail_runtime::native::fail_bytes>
   63bfe:	lea    0x39bb(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   63c05:	call   207b0 <core::panicking::panic_bounds_check>
   63c0a:	lea    0x39c7(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   63c11:	call   207b0 <core::panicking::panic_bounds_check>
   63c16:	int3
   63c17:	int3
   63c18:	int3
   63c19:	int3
   63c1a:	int3
   63c1b:	int3
   63c1c:	int3
   63c1d:	int3
   63c1e:	int3
   63c1f:	int3
