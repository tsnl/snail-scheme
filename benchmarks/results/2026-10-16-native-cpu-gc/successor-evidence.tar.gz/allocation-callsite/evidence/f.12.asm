   61e40:	push   %rbp
   61e41:	push   %r15
   61e43:	push   %r14
   61e45:	push   %r13
   61e47:	push   %r12
   61e49:	push   %rbx
   61e4a:	sub    $0xa8,%rsp
   61e51:	movq   $0x7,0x30(%rsp)
   61e5a:	movq   $0x0,0x38(%rsp)
   61e63:	mov    0x89b6(%rip),%rax        # 6a820 <native_roots.0>
   61e6a:	mov    %rax,0x28(%rsp)
   61e6f:	mov    0x898a(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   61e76:	inc    %rax
   61e79:	mov    %rax,0x8980(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   61e80:	mov    0x8981(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   61e87:	cmp    %rcx,%rax
   61e8a:	cmovbe %rcx,%rax
   61e8e:	lea    0x28(%rsp),%rcx
   61e93:	mov    %rcx,0x8986(%rip)        # 6a820 <native_roots.0>
   61e9a:	mov    %rax,0x8967(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   61ea1:	mov    %rdi,0x40(%rsp)
   61ea6:	pxor   %xmm0,%xmm0
   61eaa:	movdqu %xmm0,0x48(%rsp)
   61eb0:	mov    0x18(%rdi),%rax
   61eb4:	movq   $0x3,0x38(%rsp)
   61ebd:	mov    %rsi,0x78(%rsp)
   61ec2:	mov    %rsi,0x98(%rsp)
   61eca:	mov    %rax,0xa0(%rsp)
   61ed2:	lea    0x98(%rsp),%rax
   61eda:	mov    %rax,0x8(%rsp)
   61edf:	lea    -0x12956(%rip),%rax        # 4f590 <<i64 as core::fmt::Display>::fmt>
   61ee6:	mov    %rax,0x10(%rsp)
   61eeb:	lea    0xa0(%rsp),%rcx
   61ef3:	mov    %rcx,0x18(%rsp)
   61ef8:	mov    %rax,0x20(%rsp)
   61efd:	lea    -0x5b87a(%rip),%rdi        # 668a <__abi_tag+0x6356>
   61f04:	lea    0x8(%rsp),%rsi
   61f09:	call   4f6f0 <std::io::stdio::_print>
   61f0e:	movq   $0x3,0x38(%rsp)
   61f17:	lea    0x4862(%rip),%rbx        # 66780 <__cxa_atexit@plt+0x10c0>
   61f1e:	mov    %rbx,0x8(%rsp)
   61f23:	lea    -0x9c9a(%rip),%r15        # 58290 <<&T as core::fmt::Display>::fmt>
   61f2a:	mov    %r15,0x10(%rsp)
   61f2f:	lea    -0x5b69d(%rip),%rdi        # 6899 <__abi_tag+0x6565>
   61f36:	lea    0x8(%rsp),%rsi
   61f3b:	call   4f6f0 <std::io::stdio::_print>
   61f40:	cmpb   $0x0,0x8a51(%rip)        # 6a998 <g.23>
   61f47:	je     62ce5 <f.12+0xea5>
   61f4d:	cmpq   $0x0,0x8a3b(%rip)        # 6a990 <g.22>
   61f55:	je     62ce5 <f.12+0xea5>
   61f5b:	movq   $0x3,0x38(%rsp)
   61f64:	lea    0x4855(%rip),%rax        # 667c0 <__cxa_atexit@plt+0x1100>
   61f6b:	mov    %rax,0x8(%rsp)
   61f70:	mov    %r15,0x10(%rsp)
   61f75:	lea    -0x5b6e3(%rip),%r14        # 6899 <__abi_tag+0x6565>
   61f7c:	lea    0x8(%rsp),%rsi
   61f81:	mov    %r14,%rdi
   61f84:	call   4f6f0 <std::io::stdio::_print>
   61f89:	movq   $0x3,0x38(%rsp)
   61f92:	mov    %rbx,0x8(%rsp)
   61f97:	mov    %r15,0x10(%rsp)
   61f9c:	lea    0x8(%rsp),%rsi
   61fa1:	mov    %r14,%rdi
   61fa4:	call   4f6f0 <std::io::stdio::_print>
   61fa9:	movq   $0x3,0x38(%rsp)
   61fb2:	mov    0x885f(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   61fb9:	test   %r15,%r15
   61fbc:	je     62ce5 <f.12+0xea5>
   61fc2:	mov    0x178(%r15),%rcx
   61fc9:	test   %rcx,%rcx
   61fcc:	je     62008 <f.12+0x1c8>
   61fce:	mov    0x170(%r15),%rax
   61fd5:	inc    %rax
   61fd8:	mov    %rax,0x170(%r15)
   61fdf:	mov    %rax,%rdx
   61fe2:	or     %rcx,%rdx
   61fe5:	shr    $0x20,%rdx
   61fe9:	je     62c79 <f.12+0xe39>
   61fef:	xor    %edx,%edx
   61ff1:	div    %rcx
   61ff4:	test   %rdx,%rdx
   61ff7:	jne    62008 <f.12+0x1c8>
   61ff9:	mov    0x8820(%rip),%rsi        # 6a820 <native_roots.0>
   62000:	mov    %r15,%rdi
   62003:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   62008:	cmpq   $0x20,0x98(%r15)
   62010:	jb     62cea <f.12+0xeaa>
   62016:	mov    0x8803(%rip),%r12        # 6a820 <native_roots.0>
   6201d:	mov    0xe0(%r15),%rbx
   62024:	mov    0xe8(%r15),%r13
   6202b:	cmp    %r13,%rbx
   6202e:	jb     6203b <f.12+0x1fb>
   62030:	mov    %r15,%rdi
   62033:	mov    %r12,%rsi
   62036:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6203b:	mov    0xc8(%r15),%r14
   62042:	test   %r14,%r14
   62045:	je     62057 <f.12+0x217>
   62047:	mov    0xd0(%r15),%rax
   6204e:	sub    %r14,%rax
   62051:	cmp    $0x1f,%rax
   62055:	ja     6207b <f.12+0x23b>
   62057:	mov    $0x20,%esi
   6205c:	mov    %r15,%rdi
   6205f:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   62064:	mov    %rdx,%r14
   62067:	cmp    $0x1,%rax
   6206b:	jne    620f6 <f.12+0x2b6>
   62071:	mov    $0x1,%eax
   62076:	jmp    62111 <f.12+0x2d1>
   6207b:	lea    0x20(%r14),%rax
   6207f:	mov    %rax,0xc8(%r15)
   62086:	mov    0x10(%r15),%rsi
   6208a:	mov    0xc0(%r15),%rdi
   62091:	cmp    %rsi,%rdi
   62094:	jae    62cfb <f.12+0xebb>
   6209a:	mov    0x8(%r15),%rax
   6209e:	imul   $0x38,%rdi,%rcx
   620a2:	mov    %r14,%rdx
   620a5:	sub    0x18(%rax,%rcx,1),%rdx
   620aa:	mov    %rdx,%rdi
   620ad:	shr    $0xf,%rdi
   620b1:	mov    0x10(%rax,%rcx,1),%rsi
   620b6:	cmp    %rsi,%rdi
   620b9:	jae    62d07 <f.12+0xec7>
   620bf:	add    %rcx,%rax
   620c2:	mov    %edx,%ecx
   620c4:	imul   $0x220,%rdi,%rsi
   620cb:	add    0x8(%rax),%rsi
   620cf:	shr    $0x4,%ecx
   620d2:	mov    $0x1,%eax
   620d7:	mov    $0x1,%edi
   620dc:	shl    %cl,%rdi
   620df:	shr    $0x7,%edx
   620e2:	and    $0xf8,%edx
   620e8:	or     %rdi,(%rdx,%rsi,1)
   620ec:	cmp    $0x1,%rax
   620f0:	je     62071 <f.12+0x231>
   620f6:	xor    %edx,%edx
   620f8:	cmp    %r13,%rbx
   620fb:	setae  %dl
   620fe:	mov    $0x20,%esi
   62103:	mov    %r15,%rdi
   62106:	mov    %r12,%rcx
   62109:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   6210e:	mov    %rdx,%r14
   62111:	test   $0x1,%al
   62113:	je     62cea <f.12+0xeaa>
   62119:	movq   $0x61,(%r14)
   62120:	pxor   %xmm0,%xmm0
   62124:	movdqu %xmm0,0x8(%r14)
   6212a:	movq   $0x0,0x18(%r14)
   62132:	addq   $0x20,0xe0(%r15)
   6213a:	movdqu 0x110(%r15),%xmm0
   62143:	paddq  -0x5dc5b(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   6214b:	lea    0x8(%r14),%rbx
   6214f:	movdqu %xmm0,0x110(%r15)
   62158:	movq   $0x5e,0x8(%r14)
   62160:	movl   $0x0,0x10(%r14)
   62168:	movq   $0x0,0x18(%r14)
   62170:	mov    %rbx,0x48(%rsp)
   62175:	mov    0x40(%rsp),%rax
   6217a:	test   %rax,%rax
   6217d:	je     62ce5 <f.12+0xea5>
   62183:	movdqu 0x10(%rax),%xmm0
   62188:	mov    %rbx,0x58(%rsp)
   6218d:	movdqa %xmm0,0x80(%rsp)
   62196:	movq   %xmm0,0x60(%rsp)
   6219c:	lea    0x6525(%rip),%rax        # 686c8 <ref.14>
   621a3:	mov    %rax,0x68(%rsp)
   621a8:	mov    %rbx,0x70(%rsp)
   621ad:	movq   $0x7,0x38(%rsp)
   621b6:	mov    0x865b(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   621bd:	test   %r15,%r15
   621c0:	je     62ce5 <f.12+0xea5>
   621c6:	mov    0x178(%r15),%rcx
   621cd:	test   %rcx,%rcx
   621d0:	je     6220c <f.12+0x3cc>
   621d2:	mov    0x170(%r15),%rax
   621d9:	inc    %rax
   621dc:	mov    %rax,0x170(%r15)
   621e3:	mov    %rax,%rdx
   621e6:	or     %rcx,%rdx
   621e9:	shr    $0x20,%rdx
   621ed:	je     62c8b <f.12+0xe4b>
   621f3:	xor    %edx,%edx
   621f5:	div    %rcx
   621f8:	test   %rdx,%rdx
   621fb:	jne    6220c <f.12+0x3cc>
   621fd:	mov    0x861c(%rip),%rsi        # 6a820 <native_roots.0>
   62204:	mov    %r15,%rdi
   62207:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6220c:	cmpq   $0x30,0x98(%r15)
   62214:	jb     62cea <f.12+0xeaa>
   6221a:	mov    0x85ff(%rip),%r12        # 6a820 <native_roots.0>
   62221:	mov    0xe0(%r15),%rbp
   62228:	mov    0xe8(%r15),%r13
   6222f:	cmp    %r13,%rbp
   62232:	jb     6223f <f.12+0x3ff>
   62234:	mov    %r15,%rdi
   62237:	mov    %r12,%rsi
   6223a:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6223f:	mov    0xc8(%r15),%rdx
   62246:	test   %rdx,%rdx
   62249:	je     6225b <f.12+0x41b>
   6224b:	mov    0xd0(%r15),%rax
   62252:	sub    %rdx,%rax
   62255:	cmp    $0x2f,%rax
   62259:	ja     6227c <f.12+0x43c>
   6225b:	mov    $0x30,%esi
   62260:	mov    %r15,%rdi
   62263:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   62268:	cmp    $0x1,%rax
   6226c:	jne    622fa <f.12+0x4ba>
   62272:	mov    $0x1,%eax
   62277:	jmp    62312 <f.12+0x4d2>
   6227c:	lea    0x30(%rdx),%rax
   62280:	mov    %rax,0xc8(%r15)
   62287:	mov    0x10(%r15),%rsi
   6228b:	mov    0xc0(%r15),%rdi
   62292:	cmp    %rsi,%rdi
   62295:	jae    62cfb <f.12+0xebb>
   6229b:	mov    0x8(%r15),%rax
   6229f:	imul   $0x38,%rdi,%rcx
   622a3:	mov    %rdx,%r8
   622a6:	sub    0x18(%rax,%rcx,1),%r8
   622ab:	mov    %r8,%rdi
   622ae:	shr    $0xf,%rdi
   622b2:	mov    0x10(%rax,%rcx,1),%rsi
   622b7:	cmp    %rsi,%rdi
   622ba:	jae    62d07 <f.12+0xec7>
   622c0:	add    %rcx,%rax
   622c3:	mov    %r8d,%ecx
   622c6:	imul   $0x220,%rdi,%rsi
   622cd:	add    0x8(%rax),%rsi
   622d1:	shr    $0x4,%ecx
   622d4:	mov    $0x1,%eax
   622d9:	mov    $0x1,%edi
   622de:	shl    %cl,%rdi
   622e1:	shr    $0x7,%r8d
   622e5:	and    $0xf8,%r8d
   622ec:	or     %rdi,(%r8,%rsi,1)
   622f0:	cmp    $0x1,%rax
   622f4:	je     62272 <f.12+0x432>
   622fa:	xor    %edx,%edx
   622fc:	cmp    %r13,%rbp
   622ff:	setae  %dl
   62302:	mov    $0x30,%esi
   62307:	mov    %r15,%rdi
   6230a:	mov    %r12,%rcx
   6230d:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   62312:	test   $0x1,%al
   62314:	je     62cea <f.12+0xeaa>
   6231a:	movq   $0xa1,(%rdx)
   62321:	pxor   %xmm0,%xmm0
   62325:	movdqu %xmm0,0x8(%rdx)
   6232a:	movdqu %xmm0,0x18(%rdx)
   6232f:	movq   $0x0,0x28(%rdx)
   62337:	addq   $0x30,0xe0(%r15)
   6233f:	movdqu 0x110(%r15),%xmm0
   62348:	paddq  -0x5ddf0(%rip),%xmm0        # 4560 <__abi_tag+0x422c>
   62350:	lea    0x8(%rdx),%rbp
   62354:	movdqu %xmm0,0x110(%r15)
   6235d:	movq   $0x1a,0x8(%rdx)
   62365:	movdqa 0x80(%rsp),%xmm0
   6236e:	movdqu %xmm0,0x10(%rdx)
   62373:	mov    0x78(%rsp),%rax
   62378:	mov    %rax,0x20(%rdx)
   6237c:	mov    %rbx,0x28(%rdx)
   62380:	mov    %rbp,0x58(%rsp)
   62385:	lea    0x633c(%rip),%rax        # 686c8 <ref.14>
   6238c:	mov    %rax,0x60(%rsp)
   62391:	mov    %rbx,0x68(%rsp)
   62396:	movq   $0x6,0x38(%rsp)
   6239f:	mov    0x8472(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   623a6:	test   %r15,%r15
   623a9:	je     62ce5 <f.12+0xea5>
   623af:	mov    0x178(%r15),%rcx
   623b6:	test   %rcx,%rcx
   623b9:	je     623f5 <f.12+0x5b5>
   623bb:	mov    0x170(%r15),%rax
   623c2:	inc    %rax
   623c5:	mov    %rax,0x170(%r15)
   623cc:	mov    %rax,%rdx
   623cf:	or     %rcx,%rdx
   623d2:	shr    $0x20,%rdx
   623d6:	je     62c9d <f.12+0xe5d>
   623dc:	xor    %edx,%edx
   623de:	div    %rcx
   623e1:	test   %rdx,%rdx
   623e4:	jne    623f5 <f.12+0x5b5>
   623e6:	mov    0x8433(%rip),%rsi        # 6a820 <native_roots.0>
   623ed:	mov    %r15,%rdi
   623f0:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   623f5:	cmpq   $0x20,0x98(%r15)
   623fd:	jb     62cea <f.12+0xeaa>
   62403:	mov    0x8416(%rip),%r12        # 6a820 <native_roots.0>
   6240a:	mov    0xe0(%r15),%rbx
   62411:	mov    0xe8(%r15),%r13
   62418:	cmp    %r13,%rbx
   6241b:	jb     62428 <f.12+0x5e8>
   6241d:	mov    %r15,%rdi
   62420:	mov    %r12,%rsi
   62423:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   62428:	mov    0xc8(%r15),%rdx
   6242f:	test   %rdx,%rdx
   62432:	je     62444 <f.12+0x604>
   62434:	mov    0xd0(%r15),%rax
   6243b:	sub    %rdx,%rax
   6243e:	cmp    $0x1f,%rax
   62442:	ja     62465 <f.12+0x625>
   62444:	mov    $0x20,%esi
   62449:	mov    %r15,%rdi
   6244c:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   62451:	cmp    $0x1,%rax
   62455:	jne    624e3 <f.12+0x6a3>
   6245b:	mov    $0x1,%eax
   62460:	jmp    624fb <f.12+0x6bb>
   62465:	lea    0x20(%rdx),%rax
   62469:	mov    %rax,0xc8(%r15)
   62470:	mov    0x10(%r15),%rsi
   62474:	mov    0xc0(%r15),%rdi
   6247b:	cmp    %rsi,%rdi
   6247e:	jae    62cfb <f.12+0xebb>
   62484:	mov    0x8(%r15),%rax
   62488:	imul   $0x38,%rdi,%rcx
   6248c:	mov    %rdx,%r8
   6248f:	sub    0x18(%rax,%rcx,1),%r8
   62494:	mov    %r8,%rdi
   62497:	shr    $0xf,%rdi
   6249b:	mov    0x10(%rax,%rcx,1),%rsi
   624a0:	cmp    %rsi,%rdi
   624a3:	jae    62d07 <f.12+0xec7>
   624a9:	add    %rcx,%rax
   624ac:	mov    %r8d,%ecx
   624af:	imul   $0x220,%rdi,%rsi
   624b6:	add    0x8(%rax),%rsi
   624ba:	shr    $0x4,%ecx
   624bd:	mov    $0x1,%eax
   624c2:	mov    $0x1,%edi
   624c7:	shl    %cl,%rdi
   624ca:	shr    $0x7,%r8d
   624ce:	and    $0xf8,%r8d
   624d5:	or     %rdi,(%r8,%rsi,1)
   624d9:	cmp    $0x1,%rax
   624dd:	je     6245b <f.12+0x61b>
   624e3:	xor    %edx,%edx
   624e5:	cmp    %r13,%rbx
   624e8:	setae  %dl
   624eb:	mov    $0x20,%esi
   624f0:	mov    %r15,%rdi
   624f3:	mov    %r12,%rcx
   624f6:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   624fb:	test   $0x1,%al
   624fd:	je     62cea <f.12+0xeaa>
   62503:	movq   $0x61,(%rdx)
   6250a:	pxor   %xmm0,%xmm0
   6250e:	movdqu %xmm0,0x8(%rdx)
   62513:	movq   $0x0,0x18(%rdx)
   6251b:	addq   $0x20,0xe0(%r15)
   62523:	movdqu 0x110(%r15),%xmm0
   6252c:	paddq  -0x5e044(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   62534:	lea    0x8(%rdx),%rax
   62538:	movdqu %xmm0,0x110(%r15)
   62541:	movq   $0x82,0x8(%rdx)
   62549:	lea    0x6178(%rip),%rcx        # 686c8 <ref.14>
   62550:	mov    %rcx,0x10(%rdx)
   62554:	mov    %rbp,0x18(%rdx)
   62558:	mov    %rax,0x18(%r14)
   6255c:	mov    0x48(%rsp),%rax
   62561:	test   %rax,%rax
   62564:	je     62ce5 <f.12+0xea5>
   6256a:	movl   $0x1,0x8(%rax)
   62571:	mov    0x48(%rsp),%rax
   62576:	test   %rax,%rax
   62579:	lea    0x4200(%rip),%rbx        # 66780 <__cxa_atexit@plt+0x10c0>
   62580:	lea    -0xa2f7(%rip),%r15        # 58290 <<&T as core::fmt::Display>::fmt>
   62587:	je     62ce5 <f.12+0xea5>
   6258d:	cmpl   $0x0,0x8(%rax)
   62591:	je     62ce5 <f.12+0xea5>
   62597:	mov    0x10(%rax),%rax
   6259b:	test   %rax,%rax
   6259e:	je     62ce5 <f.12+0xea5>
   625a4:	mov    %rax,0x50(%rsp)
   625a9:	mov    0x8(%rax),%rcx
   625ad:	test   %rcx,%rcx
   625b0:	je     62ce5 <f.12+0xea5>
   625b6:	mov    0x10(%rax),%rdi
   625ba:	mov    0x8(%rcx),%rax
   625be:	mov    %rdi,0x58(%rsp)
   625c3:	movq   $0x4,0x38(%rsp)
   625cc:	xor    %esi,%esi
   625ce:	call   *%rax
   625d0:	sub    $0x8,%rsp
   625d4:	cmpb   $0x0,0x83bd(%rip)        # 6a998 <g.23>
   625db:	je     62ce5 <f.12+0xea5>
   625e1:	cmpq   $0x0,0x83a7(%rip)        # 6a990 <g.22>
   625e9:	je     62ce5 <f.12+0xea5>
   625ef:	movq   $0x3,0x38(%rsp)
   625f8:	lea    0x41d1(%rip),%rax        # 667d0 <__cxa_atexit@plt+0x1110>
   625ff:	mov    %rax,0x8(%rsp)
   62604:	mov    %r15,0x10(%rsp)
   62609:	lea    -0x5bd77(%rip),%r14        # 6899 <__abi_tag+0x6565>
   62610:	lea    0x8(%rsp),%rsi
   62615:	mov    %r14,%rdi
   62618:	call   4f6f0 <std::io::stdio::_print>
   6261d:	movq   $0x3,0x38(%rsp)
   62626:	mov    %rbx,0x8(%rsp)
   6262b:	mov    %r15,0x10(%rsp)
   62630:	lea    0x8(%rsp),%rsi
   62635:	mov    %r14,%rdi
   62638:	call   4f6f0 <std::io::stdio::_print>
   6263d:	movq   $0x3,0x38(%rsp)
   62646:	mov    0x81cb(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   6264d:	test   %r15,%r15
   62650:	je     62ce5 <f.12+0xea5>
   62656:	mov    0x178(%r15),%rcx
   6265d:	test   %rcx,%rcx
   62660:	je     6269c <f.12+0x85c>
   62662:	mov    0x170(%r15),%rax
   62669:	inc    %rax
   6266c:	mov    %rax,0x170(%r15)
   62673:	mov    %rax,%rdx
   62676:	or     %rcx,%rdx
   62679:	shr    $0x20,%rdx
   6267d:	je     62caf <f.12+0xe6f>
   62683:	xor    %edx,%edx
   62685:	div    %rcx
   62688:	test   %rdx,%rdx
   6268b:	jne    6269c <f.12+0x85c>
   6268d:	mov    0x818c(%rip),%rsi        # 6a820 <native_roots.0>
   62694:	mov    %r15,%rdi
   62697:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6269c:	cmpq   $0x20,0x98(%r15)
   626a4:	jb     62cea <f.12+0xeaa>
   626aa:	mov    0x816f(%rip),%r12        # 6a820 <native_roots.0>
   626b1:	mov    0xe0(%r15),%rbx
   626b8:	mov    0xe8(%r15),%r13
   626bf:	cmp    %r13,%rbx
   626c2:	jb     626cf <f.12+0x88f>
   626c4:	mov    %r15,%rdi
   626c7:	mov    %r12,%rsi
   626ca:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   626cf:	mov    0xc8(%r15),%r14
   626d6:	test   %r14,%r14
   626d9:	je     626eb <f.12+0x8ab>
   626db:	mov    0xd0(%r15),%rax
   626e2:	sub    %r14,%rax
   626e5:	cmp    $0x1f,%rax
   626e9:	ja     6270f <f.12+0x8cf>
   626eb:	mov    $0x20,%esi
   626f0:	mov    %r15,%rdi
   626f3:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   626f8:	mov    %rdx,%r14
   626fb:	cmp    $0x1,%rax
   626ff:	jne    6278a <f.12+0x94a>
   62705:	mov    $0x1,%eax
   6270a:	jmp    627a5 <f.12+0x965>
   6270f:	lea    0x20(%r14),%rax
   62713:	mov    %rax,0xc8(%r15)
   6271a:	mov    0x10(%r15),%rsi
   6271e:	mov    0xc0(%r15),%rdi
   62725:	cmp    %rsi,%rdi
   62728:	jae    62cfb <f.12+0xebb>
   6272e:	mov    0x8(%r15),%rax
   62732:	imul   $0x38,%rdi,%rcx
   62736:	mov    %r14,%rdx
   62739:	sub    0x18(%rax,%rcx,1),%rdx
   6273e:	mov    %rdx,%rdi
   62741:	shr    $0xf,%rdi
   62745:	mov    0x10(%rax,%rcx,1),%rsi
   6274a:	cmp    %rsi,%rdi
   6274d:	jae    62d07 <f.12+0xec7>
   62753:	add    %rcx,%rax
   62756:	mov    %edx,%ecx
   62758:	imul   $0x220,%rdi,%rsi
   6275f:	add    0x8(%rax),%rsi
   62763:	shr    $0x4,%ecx
   62766:	mov    $0x1,%eax
   6276b:	mov    $0x1,%edi
   62770:	shl    %cl,%rdi
   62773:	shr    $0x7,%edx
   62776:	and    $0xf8,%edx
   6277c:	or     %rdi,(%rdx,%rsi,1)
   62780:	cmp    $0x1,%rax
   62784:	je     62705 <f.12+0x8c5>
   6278a:	xor    %edx,%edx
   6278c:	cmp    %r13,%rbx
   6278f:	setae  %dl
   62792:	mov    $0x20,%esi
   62797:	mov    %r15,%rdi
   6279a:	mov    %r12,%rcx
   6279d:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   627a2:	mov    %rdx,%r14
   627a5:	test   $0x1,%al
   627a7:	je     62cea <f.12+0xeaa>
   627ad:	movq   $0x61,(%r14)
   627b4:	pxor   %xmm0,%xmm0
   627b8:	movdqu %xmm0,0x8(%r14)
   627be:	movq   $0x0,0x18(%r14)
   627c6:	addq   $0x20,0xe0(%r15)
   627ce:	movdqu 0x110(%r15),%xmm0
   627d7:	paddq  -0x5e2ef(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   627df:	lea    0x8(%r14),%rcx
   627e3:	movdqu %xmm0,0x110(%r15)
   627ec:	movq   $0x5e,0x8(%r14)
   627f4:	movl   $0x0,0x10(%r14)
   627fc:	movq   $0x0,0x18(%r14)
   62804:	mov    %rcx,0x48(%rsp)
   62809:	mov    0x40(%rsp),%rax
   6280e:	test   %rax,%rax
   62811:	je     62ce5 <f.12+0xea5>
   62817:	mov    0x8(%rax),%r12
   6281b:	mov    0x18(%rax),%rbx
   6281f:	mov    %rcx,0x58(%rsp)
   62824:	mov    %r12,0x60(%rsp)
   62829:	lea    0x5e88(%rip),%rax        # 686b8 <ref.13>
   62830:	mov    %rax,0x68(%rsp)
   62835:	mov    %rcx,0x70(%rsp)
   6283a:	movq   $0x7,0x38(%rsp)
   62843:	mov    0x7fce(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   6284a:	test   %r15,%r15
   6284d:	je     62ce5 <f.12+0xea5>
   62853:	mov    0x178(%r15),%rcx
   6285a:	test   %rcx,%rcx
   6285d:	je     62899 <f.12+0xa59>
   6285f:	mov    0x170(%r15),%rax
   62866:	inc    %rax
   62869:	mov    %rax,0x170(%r15)
   62870:	mov    %rax,%rdx
   62873:	or     %rcx,%rdx
   62876:	shr    $0x20,%rdx
   6287a:	je     62cc1 <f.12+0xe81>
   62880:	xor    %edx,%edx
   62882:	div    %rcx
   62885:	test   %rdx,%rdx
   62888:	jne    62899 <f.12+0xa59>
   6288a:	mov    0x7f8f(%rip),%rsi        # 6a820 <native_roots.0>
   62891:	mov    %r15,%rdi
   62894:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   62899:	cmpq   $0x30,0x98(%r15)
   628a1:	jb     62cea <f.12+0xeaa>
   628a7:	mov    %r12,0x80(%rsp)
   628af:	mov    0x7f6a(%rip),%r12        # 6a820 <native_roots.0>
   628b6:	mov    0xe0(%r15),%r13
   628bd:	mov    0xe8(%r15),%rbp
   628c4:	cmp    %rbp,%r13
   628c7:	jb     628d4 <f.12+0xa94>
   628c9:	mov    %r15,%rdi
   628cc:	mov    %r12,%rsi
   628cf:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   628d4:	mov    0xc8(%r15),%rdx
   628db:	test   %rdx,%rdx
   628de:	je     628f0 <f.12+0xab0>
   628e0:	mov    0xd0(%r15),%rax
   628e7:	sub    %rdx,%rax
   628ea:	cmp    $0x2f,%rax
   628ee:	ja     62911 <f.12+0xad1>
   628f0:	mov    $0x30,%esi
   628f5:	mov    %r15,%rdi
   628f8:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   628fd:	cmp    $0x1,%rax
   62901:	jne    6298f <f.12+0xb4f>
   62907:	mov    $0x1,%eax
   6290c:	jmp    629a7 <f.12+0xb67>
   62911:	lea    0x30(%rdx),%rax
   62915:	mov    %rax,0xc8(%r15)
   6291c:	mov    0x10(%r15),%rsi
   62920:	mov    0xc0(%r15),%rdi
   62927:	cmp    %rsi,%rdi
   6292a:	jae    62cfb <f.12+0xebb>
   62930:	mov    0x8(%r15),%rax
   62934:	imul   $0x38,%rdi,%rcx
   62938:	mov    %rdx,%r8
   6293b:	sub    0x18(%rax,%rcx,1),%r8
   62940:	mov    %r8,%rdi
   62943:	shr    $0xf,%rdi
   62947:	mov    0x10(%rax,%rcx,1),%rsi
   6294c:	cmp    %rsi,%rdi
   6294f:	jae    62d07 <f.12+0xec7>
   62955:	add    %rcx,%rax
   62958:	mov    %r8d,%ecx
   6295b:	imul   $0x220,%rdi,%rsi
   62962:	add    0x8(%rax),%rsi
   62966:	shr    $0x4,%ecx
   62969:	mov    $0x1,%eax
   6296e:	mov    $0x1,%edi
   62973:	shl    %cl,%rdi
   62976:	shr    $0x7,%r8d
   6297a:	and    $0xf8,%r8d
   62981:	or     %rdi,(%r8,%rsi,1)
   62985:	cmp    $0x1,%rax
   62989:	je     62907 <f.12+0xac7>
   6298f:	xor    %edx,%edx
   62991:	cmp    %rbp,%r13
   62994:	setae  %dl
   62997:	mov    $0x30,%esi
   6299c:	mov    %r15,%rdi
   6299f:	mov    %r12,%rcx
   629a2:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   629a7:	lea    0x8(%r14),%rcx
   629ab:	mov    0x80(%rsp),%rsi
   629b3:	test   $0x1,%al
   629b5:	je     62cea <f.12+0xeaa>
   629bb:	movq   $0xa1,(%rdx)
   629c2:	pxor   %xmm0,%xmm0
   629c6:	movdqu %xmm0,0x8(%rdx)
   629cb:	movdqu %xmm0,0x18(%rdx)
   629d0:	movq   $0x0,0x28(%rdx)
   629d8:	addq   $0x30,0xe0(%r15)
   629e0:	lea    0x8(%rdx),%r12
   629e4:	movdqu 0x110(%r15),%xmm0
   629ed:	paddq  -0x5e495(%rip),%xmm0        # 4560 <__abi_tag+0x422c>
   629f5:	movdqu %xmm0,0x110(%r15)
   629fe:	movq   $0x16,0x8(%rdx)
   62a06:	mov    %rsi,0x10(%rdx)
   62a0a:	mov    %rbx,0x18(%rdx)
   62a0e:	mov    0x78(%rsp),%rax
   62a13:	mov    %rax,0x20(%rdx)
   62a17:	mov    %rcx,0x28(%rdx)
   62a1b:	mov    %r12,0x58(%rsp)
   62a20:	lea    0x5c91(%rip),%rax        # 686b8 <ref.13>
   62a27:	mov    %rax,0x60(%rsp)
   62a2c:	mov    %rcx,0x68(%rsp)
   62a31:	movq   $0x6,0x38(%rsp)
   62a3a:	mov    0x7dd7(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   62a41:	test   %rbx,%rbx
   62a44:	je     62ce5 <f.12+0xea5>
   62a4a:	mov    0x178(%rbx),%rcx
   62a51:	test   %rcx,%rcx
   62a54:	je     62a90 <f.12+0xc50>
   62a56:	mov    0x170(%rbx),%rax
   62a5d:	inc    %rax
   62a60:	mov    %rax,0x170(%rbx)
   62a67:	mov    %rax,%rdx
   62a6a:	or     %rcx,%rdx
   62a6d:	shr    $0x20,%rdx
   62a71:	je     62cd3 <f.12+0xe93>
   62a77:	xor    %edx,%edx
   62a79:	div    %rcx
   62a7c:	test   %rdx,%rdx
   62a7f:	jne    62a90 <f.12+0xc50>
   62a81:	mov    0x7d98(%rip),%rsi        # 6a820 <native_roots.0>
   62a88:	mov    %rbx,%rdi
   62a8b:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   62a90:	cmpq   $0x20,0x98(%rbx)
   62a98:	jb     62cea <f.12+0xeaa>
   62a9e:	mov    0x7d7b(%rip),%r15        # 6a820 <native_roots.0>
   62aa5:	mov    0xe0(%rbx),%r13
   62aac:	mov    0xe8(%rbx),%rbp
   62ab3:	cmp    %rbp,%r13
   62ab6:	jb     62ac3 <f.12+0xc83>
   62ab8:	mov    %rbx,%rdi
   62abb:	mov    %r15,%rsi
   62abe:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   62ac3:	mov    0xc8(%rbx),%rdx
   62aca:	test   %rdx,%rdx
   62acd:	je     62adf <f.12+0xc9f>
   62acf:	mov    0xd0(%rbx),%rax
   62ad6:	sub    %rdx,%rax
   62ad9:	cmp    $0x1f,%rax
   62add:	ja     62b00 <f.12+0xcc0>
   62adf:	mov    $0x20,%esi
   62ae4:	mov    %rbx,%rdi
   62ae7:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   62aec:	cmp    $0x1,%rax
   62af0:	jne    62b7e <f.12+0xd3e>
   62af6:	mov    $0x1,%eax
   62afb:	jmp    62b96 <f.12+0xd56>
   62b00:	lea    0x20(%rdx),%rax
   62b04:	mov    %rax,0xc8(%rbx)
   62b0b:	mov    0x10(%rbx),%rsi
   62b0f:	mov    0xc0(%rbx),%rdi
   62b16:	cmp    %rsi,%rdi
   62b19:	jae    62cfb <f.12+0xebb>
   62b1f:	mov    0x8(%rbx),%rax
   62b23:	imul   $0x38,%rdi,%rcx
   62b27:	mov    %rdx,%r8
   62b2a:	sub    0x18(%rax,%rcx,1),%r8
   62b2f:	mov    %r8,%rdi
   62b32:	shr    $0xf,%rdi
   62b36:	mov    0x10(%rax,%rcx,1),%rsi
   62b3b:	cmp    %rsi,%rdi
   62b3e:	jae    62d07 <f.12+0xec7>
   62b44:	add    %rcx,%rax
   62b47:	mov    %r8d,%ecx
   62b4a:	imul   $0x220,%rdi,%rsi
   62b51:	add    0x8(%rax),%rsi
   62b55:	shr    $0x4,%ecx
   62b58:	mov    $0x1,%eax
   62b5d:	mov    $0x1,%edi
   62b62:	shl    %cl,%rdi
   62b65:	shr    $0x7,%r8d
   62b69:	and    $0xf8,%r8d
   62b70:	or     %rdi,(%r8,%rsi,1)
   62b74:	cmp    $0x1,%rax
   62b78:	je     62af6 <f.12+0xcb6>
   62b7e:	xor    %edx,%edx
   62b80:	cmp    %rbp,%r13
   62b83:	setae  %dl
   62b86:	mov    $0x20,%esi
   62b8b:	mov    %rbx,%rdi
   62b8e:	mov    %r15,%rcx
   62b91:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   62b96:	test   $0x1,%al
   62b98:	je     62cea <f.12+0xeaa>
   62b9e:	movq   $0x61,(%rdx)
   62ba5:	pxor   %xmm0,%xmm0
   62ba9:	movdqu %xmm0,0x8(%rdx)
   62bae:	movq   $0x0,0x18(%rdx)
   62bb6:	addq   $0x20,0xe0(%rbx)
   62bbe:	movdqu 0x110(%rbx),%xmm0
   62bc6:	paddq  -0x5e6de(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   62bce:	lea    0x8(%rdx),%rax
   62bd2:	movdqu %xmm0,0x110(%rbx)
   62bda:	movq   $0x82,0x8(%rdx)
   62be2:	lea    0x5acf(%rip),%rcx        # 686b8 <ref.13>
   62be9:	mov    %rcx,0x10(%rdx)
   62bed:	mov    %r12,0x18(%rdx)
   62bf1:	mov    %rax,0x18(%r14)
   62bf5:	mov    0x48(%rsp),%rax
   62bfa:	test   %rax,%rax
   62bfd:	je     62ce5 <f.12+0xea5>
   62c03:	movl   $0x1,0x8(%rax)
   62c0a:	mov    0x48(%rsp),%rax
   62c0f:	test   %rax,%rax
   62c12:	je     62ce5 <f.12+0xea5>
   62c18:	cmpl   $0x0,0x8(%rax)
   62c1c:	je     62ce5 <f.12+0xea5>
   62c22:	mov    0x10(%rax),%rax
   62c26:	test   %rax,%rax
   62c29:	je     62ce5 <f.12+0xea5>
   62c2f:	mov    %rax,0x50(%rsp)
   62c34:	mov    0x8(%rax),%rcx
   62c38:	test   %rcx,%rcx
   62c3b:	je     62ce5 <f.12+0xea5>
   62c41:	mov    0x10(%rax),%rdi
   62c45:	mov    0x8(%rcx),%rax
   62c49:	cmpq   $0x0,0x30(%rsp)
   62c4f:	je     62c64 <f.12+0xe24>
   62c51:	mov    0x28(%rsp),%rcx
   62c56:	mov    %rcx,0x7bc3(%rip)        # 6a820 <native_roots.0>
   62c5d:	decq   0x7b9c(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   62c64:	xor    %esi,%esi
   62c66:	add    $0xa8,%rsp
   62c6d:	pop    %rbx
   62c6e:	pop    %r12
   62c70:	pop    %r13
   62c72:	pop    %r14
   62c74:	pop    %r15
   62c76:	pop    %rbp
   62c77:	jmp    *%rax
   62c79:	xor    %edx,%edx
   62c7b:	div    %ecx
   62c7d:	test   %rdx,%rdx
   62c80:	jne    62008 <f.12+0x1c8>
   62c86:	jmp    61ff9 <f.12+0x1b9>
   62c8b:	xor    %edx,%edx
   62c8d:	div    %ecx
   62c8f:	test   %rdx,%rdx
   62c92:	jne    6220c <f.12+0x3cc>
   62c98:	jmp    621fd <f.12+0x3bd>
   62c9d:	xor    %edx,%edx
   62c9f:	div    %ecx
   62ca1:	test   %rdx,%rdx
   62ca4:	jne    623f5 <f.12+0x5b5>
   62caa:	jmp    623e6 <f.12+0x5a6>
   62caf:	xor    %edx,%edx
   62cb1:	div    %ecx
   62cb3:	test   %rdx,%rdx
   62cb6:	jne    6269c <f.12+0x85c>
   62cbc:	jmp    6268d <f.12+0x84d>
   62cc1:	xor    %edx,%edx
   62cc3:	div    %ecx
   62cc5:	test   %rdx,%rdx
   62cc8:	jne    62899 <f.12+0xa59>
   62cce:	jmp    6288a <f.12+0xa4a>
   62cd3:	xor    %edx,%edx
   62cd5:	div    %ecx
   62cd7:	test   %rdx,%rdx
   62cda:	jne    62a90 <f.12+0xc50>
   62ce0:	jmp    62a81 <f.12+0xc41>
   62ce5:	call   56d70 <native_trap>
   62cea:	lea    -0x5989d(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   62cf1:	mov    $0x2f,%esi
   62cf6:	call   57d70 <snail_runtime::native::fail_bytes>
   62cfb:	lea    0x48be(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   62d02:	call   207b0 <core::panicking::panic_bounds_check>
   62d07:	lea    0x48ca(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   62d0e:	call   207b0 <core::panicking::panic_bounds_check>
   62d13:	int3
   62d14:	int3
   62d15:	int3
   62d16:	int3
   62d17:	int3
   62d18:	int3
   62d19:	int3
   62d1a:	int3
   62d1b:	int3
   62d1c:	int3
   62d1d:	int3
   62d1e:	int3
   62d1f:	int3
