   643e0:	push   %rbp
   643e1:	push   %r15
   643e3:	push   %r14
   643e5:	push   %r13
   643e7:	push   %r12
   643e9:	push   %rbx
   643ea:	sub    $0x58,%rsp
   643ee:	mov    %rsi,0x8(%rsp)
   643f3:	movq   $0x6,0x18(%rsp)
   643fc:	movq   $0x0,0x20(%rsp)
   64405:	mov    0x6414(%rip),%rax        # 6a820 <native_roots.0>
   6440c:	mov    %rax,0x10(%rsp)
   64411:	mov    0x63e8(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   64418:	inc    %rax
   6441b:	mov    %rax,0x63de(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   64422:	mov    0x63df(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   64429:	cmp    %rcx,%rax
   6442c:	cmovbe %rcx,%rax
   64430:	lea    0x10(%rsp),%r12
   64435:	mov    %r12,0x63e4(%rip)        # 6a820 <native_roots.0>
   6443c:	mov    %rax,0x63c5(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   64443:	mov    %rdi,0x28(%rsp)
   64448:	pxor   %xmm0,%xmm0
   6444c:	movdqu %xmm0,0x30(%rsp)
   64452:	cmpb   $0x0,0x64ff(%rip)        # 6a958 <g.15>
   64459:	je     655ad <f.7+0x11cd>
   6445f:	cmpq   $0x0,0x64e9(%rip)        # 6a950 <g.14>
   64467:	je     655ad <f.7+0x11cd>
   6446d:	movq   $0x3,0x20(%rsp)
   64476:	mov    0x639b(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   6447d:	test   %r15,%r15
   64480:	je     655ad <f.7+0x11cd>
   64486:	mov    0x178(%r15),%rcx
   6448d:	test   %rcx,%rcx
   64490:	je     644d1 <f.7+0xf1>
   64492:	mov    0x170(%r15),%rax
   64499:	inc    %rax
   6449c:	mov    %rax,0x170(%r15)
   644a3:	mov    %rax,%rdx
   644a6:	or     %rcx,%rdx
   644a9:	shr    $0x20,%rdx
   644ad:	je     654fa <f.7+0x111a>
   644b3:	xor    %edx,%edx
   644b5:	div    %rcx
   644b8:	test   %rdx,%rdx
   644bb:	jne    644d1 <f.7+0xf1>
   644bd:	lea    0x10(%rsp),%rsi
   644c2:	mov    %r15,%rdi
   644c5:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   644ca:	mov    0x634f(%rip),%r12        # 6a820 <native_roots.0>
   644d1:	cmpq   $0x20,0x98(%r15)
   644d9:	jb     6559c <f.7+0x11bc>
   644df:	mov    0xe0(%r15),%rbx
   644e6:	mov    0xe8(%r15),%r13
   644ed:	cmp    %r13,%rbx
   644f0:	jb     644fd <f.7+0x11d>
   644f2:	mov    %r15,%rdi
   644f5:	mov    %r12,%rsi
   644f8:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   644fd:	mov    0xc8(%r15),%r14
   64504:	test   %r14,%r14
   64507:	je     64519 <f.7+0x139>
   64509:	mov    0xd0(%r15),%rax
   64510:	sub    %r14,%rax
   64513:	cmp    $0x1f,%rax
   64517:	ja     6453d <f.7+0x15d>
   64519:	mov    $0x20,%esi
   6451e:	mov    %r15,%rdi
   64521:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   64526:	mov    %rdx,%r14
   64529:	cmp    $0x1,%rax
   6452d:	jne    645b8 <f.7+0x1d8>
   64533:	mov    $0x1,%eax
   64538:	jmp    645d3 <f.7+0x1f3>
   6453d:	lea    0x20(%r14),%rax
   64541:	mov    %rax,0xc8(%r15)
   64548:	mov    0x10(%r15),%rsi
   6454c:	mov    0xc0(%r15),%rdi
   64553:	cmp    %rsi,%rdi
   64556:	jae    655b2 <f.7+0x11d2>
   6455c:	mov    0x8(%r15),%rax
   64560:	imul   $0x38,%rdi,%rcx
   64564:	mov    %r14,%rdx
   64567:	sub    0x18(%rax,%rcx,1),%rdx
   6456c:	mov    %rdx,%rdi
   6456f:	shr    $0xf,%rdi
   64573:	mov    0x10(%rax,%rcx,1),%rsi
   64578:	cmp    %rsi,%rdi
   6457b:	jae    655be <f.7+0x11de>
   64581:	add    %rcx,%rax
   64584:	mov    %edx,%ecx
   64586:	imul   $0x220,%rdi,%rsi
   6458d:	add    0x8(%rax),%rsi
   64591:	shr    $0x4,%ecx
   64594:	mov    $0x1,%eax
   64599:	mov    $0x1,%edi
   6459e:	shl    %cl,%rdi
   645a1:	shr    $0x7,%edx
   645a4:	and    $0xf8,%edx
   645aa:	or     %rdi,(%rdx,%rsi,1)
   645ae:	cmp    $0x1,%rax
   645b2:	je     64533 <f.7+0x153>
   645b8:	xor    %edx,%edx
   645ba:	cmp    %r13,%rbx
   645bd:	setae  %dl
   645c0:	mov    $0x20,%esi
   645c5:	mov    %r15,%rdi
   645c8:	mov    %r12,%rcx
   645cb:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   645d0:	mov    %rdx,%r14
   645d3:	test   $0x1,%al
   645d5:	je     6559c <f.7+0x11bc>
   645db:	movq   $0x61,(%r14)
   645e2:	pxor   %xmm0,%xmm0
   645e6:	movdqu %xmm0,0x8(%r14)
   645ec:	movq   $0x0,0x18(%r14)
   645f4:	addq   $0x20,0xe0(%r15)
   645fc:	lea    0x8(%r14),%rbx
   64600:	movdqu 0x110(%r15),%xmm0
   64609:	paddq  -0x60121(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   64611:	movdqu %xmm0,0x110(%r15)
   6461a:	movq   $0x7a,0x8(%r14)
   64622:	movl   $0x0,0x10(%r14)
   6462a:	movq   $0x0,0x18(%r14)
   64632:	mov    %rbx,0x30(%rsp)
   64637:	mov    %rbx,0x40(%rsp)
   6463c:	lea    0x40a5(%rip),%rax        # 686e8 <ref.19>
   64643:	mov    %rax,0x48(%rsp)
   64648:	mov    %rbx,0x50(%rsp)
   6464d:	movq   $0x6,0x20(%rsp)
   64656:	mov    0x61bb(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   6465d:	test   %r15,%r15
   64660:	je     655ad <f.7+0x11cd>
   64666:	mov    0x178(%r15),%rcx
   6466d:	test   %rcx,%rcx
   64670:	je     646ac <f.7+0x2cc>
   64672:	mov    0x170(%r15),%rax
   64679:	inc    %rax
   6467c:	mov    %rax,0x170(%r15)
   64683:	mov    %rax,%rdx
   64686:	or     %rcx,%rdx
   64689:	shr    $0x20,%rdx
   6468d:	je     6550c <f.7+0x112c>
   64693:	xor    %edx,%edx
   64695:	div    %rcx
   64698:	test   %rdx,%rdx
   6469b:	jne    646ac <f.7+0x2cc>
   6469d:	mov    0x617c(%rip),%rsi        # 6a820 <native_roots.0>
   646a4:	mov    %r15,%rdi
   646a7:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   646ac:	cmpq   $0x20,0x98(%r15)
   646b4:	jb     6559c <f.7+0x11bc>
   646ba:	mov    0x615f(%rip),%r12        # 6a820 <native_roots.0>
   646c1:	mov    0xe0(%r15),%rbp
   646c8:	mov    0xe8(%r15),%r13
   646cf:	cmp    %r13,%rbp
   646d2:	jb     646df <f.7+0x2ff>
   646d4:	mov    %r15,%rdi
   646d7:	mov    %r12,%rsi
   646da:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   646df:	mov    0xc8(%r15),%rdx
   646e6:	test   %rdx,%rdx
   646e9:	je     646fb <f.7+0x31b>
   646eb:	mov    0xd0(%r15),%rax
   646f2:	sub    %rdx,%rax
   646f5:	cmp    $0x1f,%rax
   646f9:	ja     6471c <f.7+0x33c>
   646fb:	mov    $0x20,%esi
   64700:	mov    %r15,%rdi
   64703:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   64708:	cmp    $0x1,%rax
   6470c:	jne    6479a <f.7+0x3ba>
   64712:	mov    $0x1,%eax
   64717:	jmp    647b2 <f.7+0x3d2>
   6471c:	lea    0x20(%rdx),%rax
   64720:	mov    %rax,0xc8(%r15)
   64727:	mov    0x10(%r15),%rsi
   6472b:	mov    0xc0(%r15),%rdi
   64732:	cmp    %rsi,%rdi
   64735:	jae    655b2 <f.7+0x11d2>
   6473b:	mov    0x8(%r15),%rax
   6473f:	imul   $0x38,%rdi,%rcx
   64743:	mov    %rdx,%r8
   64746:	sub    0x18(%rax,%rcx,1),%r8
   6474b:	mov    %r8,%rdi
   6474e:	shr    $0xf,%rdi
   64752:	mov    0x10(%rax,%rcx,1),%rsi
   64757:	cmp    %rsi,%rdi
   6475a:	jae    655be <f.7+0x11de>
   64760:	add    %rcx,%rax
   64763:	mov    %r8d,%ecx
   64766:	imul   $0x220,%rdi,%rsi
   6476d:	add    0x8(%rax),%rsi
   64771:	shr    $0x4,%ecx
   64774:	mov    $0x1,%eax
   64779:	mov    $0x1,%edi
   6477e:	shl    %cl,%rdi
   64781:	shr    $0x7,%r8d
   64785:	and    $0xf8,%r8d
   6478c:	or     %rdi,(%r8,%rsi,1)
   64790:	cmp    $0x1,%rax
   64794:	je     64712 <f.7+0x332>
   6479a:	xor    %edx,%edx
   6479c:	cmp    %r13,%rbp
   6479f:	setae  %dl
   647a2:	mov    $0x20,%esi
   647a7:	mov    %r15,%rdi
   647aa:	mov    %r12,%rcx
   647ad:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   647b2:	test   $0x1,%al
   647b4:	je     6559c <f.7+0x11bc>
   647ba:	movq   $0x41,(%rdx)
   647c1:	lea    0x8(%rdx),%rbp
   647c5:	pxor   %xmm0,%xmm0
   647c9:	movdqu %xmm0,0x8(%rdx)
   647ce:	addq   $0x20,0xe0(%r15)
   647d6:	movdqu 0x110(%r15),%xmm0
   647df:	paddq  -0x60297(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   647e7:	movdqu %xmm0,0x110(%r15)
   647f0:	movq   $0x72,0x8(%rdx)
   647f8:	mov    %rbx,0x10(%rdx)
   647fc:	mov    %rbp,0x40(%rsp)
   64801:	lea    0x3ee0(%rip),%rax        # 686e8 <ref.19>
   64808:	mov    %rax,0x48(%rsp)
   6480d:	mov    %rbx,0x50(%rsp)
   64812:	movq   $0x6,0x20(%rsp)
   6481b:	mov    0x5ff6(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   64822:	test   %r15,%r15
   64825:	je     655ad <f.7+0x11cd>
   6482b:	mov    0x178(%r15),%rcx
   64832:	test   %rcx,%rcx
   64835:	je     64871 <f.7+0x491>
   64837:	mov    0x170(%r15),%rax
   6483e:	inc    %rax
   64841:	mov    %rax,0x170(%r15)
   64848:	mov    %rax,%rdx
   6484b:	or     %rcx,%rdx
   6484e:	shr    $0x20,%rdx
   64852:	je     6551e <f.7+0x113e>
   64858:	xor    %edx,%edx
   6485a:	div    %rcx
   6485d:	test   %rdx,%rdx
   64860:	jne    64871 <f.7+0x491>
   64862:	mov    0x5fb7(%rip),%rsi        # 6a820 <native_roots.0>
   64869:	mov    %r15,%rdi
   6486c:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64871:	cmpq   $0x20,0x98(%r15)
   64879:	jb     6559c <f.7+0x11bc>
   6487f:	mov    0x5f9a(%rip),%r12        # 6a820 <native_roots.0>
   64886:	mov    0xe0(%r15),%rbx
   6488d:	mov    0xe8(%r15),%r13
   64894:	cmp    %r13,%rbx
   64897:	jb     648a4 <f.7+0x4c4>
   64899:	mov    %r15,%rdi
   6489c:	mov    %r12,%rsi
   6489f:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   648a4:	mov    0xc8(%r15),%rdx
   648ab:	test   %rdx,%rdx
   648ae:	je     648c0 <f.7+0x4e0>
   648b0:	mov    0xd0(%r15),%rax
   648b7:	sub    %rdx,%rax
   648ba:	cmp    $0x1f,%rax
   648be:	ja     648e1 <f.7+0x501>
   648c0:	mov    $0x20,%esi
   648c5:	mov    %r15,%rdi
   648c8:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   648cd:	cmp    $0x1,%rax
   648d1:	jne    6495f <f.7+0x57f>
   648d7:	mov    $0x1,%eax
   648dc:	jmp    64977 <f.7+0x597>
   648e1:	lea    0x20(%rdx),%rax
   648e5:	mov    %rax,0xc8(%r15)
   648ec:	mov    0x10(%r15),%rsi
   648f0:	mov    0xc0(%r15),%rdi
   648f7:	cmp    %rsi,%rdi
   648fa:	jae    655b2 <f.7+0x11d2>
   64900:	mov    0x8(%r15),%rax
   64904:	imul   $0x38,%rdi,%rcx
   64908:	mov    %rdx,%r8
   6490b:	sub    0x18(%rax,%rcx,1),%r8
   64910:	mov    %r8,%rdi
   64913:	shr    $0xf,%rdi
   64917:	mov    0x10(%rax,%rcx,1),%rsi
   6491c:	cmp    %rsi,%rdi
   6491f:	jae    655be <f.7+0x11de>
   64925:	add    %rcx,%rax
   64928:	mov    %r8d,%ecx
   6492b:	imul   $0x220,%rdi,%rsi
   64932:	add    0x8(%rax),%rsi
   64936:	shr    $0x4,%ecx
   64939:	mov    $0x1,%eax
   6493e:	mov    $0x1,%edi
   64943:	shl    %cl,%rdi
   64946:	shr    $0x7,%r8d
   6494a:	and    $0xf8,%r8d
   64951:	or     %rdi,(%r8,%rsi,1)
   64955:	cmp    $0x1,%rax
   64959:	je     648d7 <f.7+0x4f7>
   6495f:	xor    %edx,%edx
   64961:	cmp    %r13,%rbx
   64964:	setae  %dl
   64967:	mov    $0x20,%esi
   6496c:	mov    %r15,%rdi
   6496f:	mov    %r12,%rcx
   64972:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   64977:	test   $0x1,%al
   64979:	je     6559c <f.7+0x11bc>
   6497f:	movq   $0x61,(%rdx)
   64986:	pxor   %xmm0,%xmm0
   6498a:	movdqu %xmm0,0x8(%rdx)
   6498f:	movq   $0x0,0x18(%rdx)
   64997:	addq   $0x20,0xe0(%r15)
   6499f:	movdqu 0x110(%r15),%xmm0
   649a8:	paddq  -0x604c0(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   649b0:	lea    0x8(%rdx),%rax
   649b4:	movdqu %xmm0,0x110(%r15)
   649bd:	movq   $0x92,0x8(%rdx)
   649c5:	lea    0x3d1c(%rip),%rcx        # 686e8 <ref.19>
   649cc:	mov    %rcx,0x10(%rdx)
   649d0:	mov    %rbp,0x18(%rdx)
   649d4:	mov    %rax,0x18(%r14)
   649d8:	mov    0x30(%rsp),%rax
   649dd:	test   %rax,%rax
   649e0:	je     655ad <f.7+0x11cd>
   649e6:	movl   $0x1,0x8(%rax)
   649ed:	mov    0x30(%rsp),%rax
   649f2:	test   %rax,%rax
   649f5:	je     655ad <f.7+0x11cd>
   649fb:	cmpl   $0x0,0x8(%rax)
   649ff:	je     655ad <f.7+0x11cd>
   64a05:	mov    0x10(%rax),%rax
   64a09:	test   %rax,%rax
   64a0c:	je     655ad <f.7+0x11cd>
   64a12:	mov    %rax,0x38(%rsp)
   64a17:	mov    0x8(%rax),%rcx
   64a1b:	test   %rcx,%rcx
   64a1e:	je     655ad <f.7+0x11cd>
   64a24:	mov    0x8(%rsp),%rdx
   64a29:	lea    -0x1(%rdx),%rsi
   64a2d:	mov    0x10(%rax),%rdi
   64a31:	mov    0x8(%rcx),%rax
   64a35:	mov    %rdi,0x40(%rsp)
   64a3a:	movq   $0x4,0x20(%rsp)
   64a43:	mov    $0x1,%edx
   64a48:	call   *%rax
   64a4a:	sub    $0x8,%rsp
   64a4e:	movq   $0x3,0x20(%rsp)
   64a57:	mov    0x5dba(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   64a5e:	test   %r15,%r15
   64a61:	je     655ad <f.7+0x11cd>
   64a67:	mov    %rax,%r14
   64a6a:	mov    0x178(%r15),%rcx
   64a71:	test   %rcx,%rcx
   64a74:	je     64ab0 <f.7+0x6d0>
   64a76:	mov    0x170(%r15),%rax
   64a7d:	inc    %rax
   64a80:	mov    %rax,0x170(%r15)
   64a87:	mov    %rax,%rdx
   64a8a:	or     %rcx,%rdx
   64a8d:	shr    $0x20,%rdx
   64a91:	je     65530 <f.7+0x1150>
   64a97:	xor    %edx,%edx
   64a99:	div    %rcx
   64a9c:	test   %rdx,%rdx
   64a9f:	jne    64ab0 <f.7+0x6d0>
   64aa1:	mov    0x5d78(%rip),%rsi        # 6a820 <native_roots.0>
   64aa8:	mov    %r15,%rdi
   64aab:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64ab0:	cmpq   $0x20,0x98(%r15)
   64ab8:	jb     6559c <f.7+0x11bc>
   64abe:	mov    0x5d5b(%rip),%r12        # 6a820 <native_roots.0>
   64ac5:	mov    0xe0(%r15),%rbx
   64acc:	mov    0xe8(%r15),%r13
   64ad3:	cmp    %r13,%rbx
   64ad6:	jb     64ae3 <f.7+0x703>
   64ad8:	mov    %r15,%rdi
   64adb:	mov    %r12,%rsi
   64ade:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64ae3:	mov    0xc8(%r15),%rdx
   64aea:	test   %rdx,%rdx
   64aed:	je     64aff <f.7+0x71f>
   64aef:	mov    0xd0(%r15),%rax
   64af6:	sub    %rdx,%rax
   64af9:	cmp    $0x1f,%rax
   64afd:	ja     64b20 <f.7+0x740>
   64aff:	mov    $0x20,%esi
   64b04:	mov    %r15,%rdi
   64b07:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   64b0c:	cmp    $0x1,%rax
   64b10:	jne    64b9e <f.7+0x7be>
   64b16:	mov    $0x1,%eax
   64b1b:	jmp    64bb6 <f.7+0x7d6>
   64b20:	lea    0x20(%rdx),%rax
   64b24:	mov    %rax,0xc8(%r15)
   64b2b:	mov    0x10(%r15),%rsi
   64b2f:	mov    0xc0(%r15),%rdi
   64b36:	cmp    %rsi,%rdi
   64b39:	jae    655b2 <f.7+0x11d2>
   64b3f:	mov    0x8(%r15),%rax
   64b43:	imul   $0x38,%rdi,%rcx
   64b47:	mov    %rdx,%r8
   64b4a:	sub    0x18(%rax,%rcx,1),%r8
   64b4f:	mov    %r8,%rdi
   64b52:	shr    $0xf,%rdi
   64b56:	mov    0x10(%rax,%rcx,1),%rsi
   64b5b:	cmp    %rsi,%rdi
   64b5e:	jae    655be <f.7+0x11de>
   64b64:	add    %rcx,%rax
   64b67:	mov    %r8d,%ecx
   64b6a:	imul   $0x220,%rdi,%rsi
   64b71:	add    0x8(%rax),%rsi
   64b75:	shr    $0x4,%ecx
   64b78:	mov    $0x1,%eax
   64b7d:	mov    $0x1,%edi
   64b82:	shl    %cl,%rdi
   64b85:	shr    $0x7,%r8d
   64b89:	and    $0xf8,%r8d
   64b90:	or     %rdi,(%r8,%rsi,1)
   64b94:	cmp    $0x1,%rax
   64b98:	je     64b16 <f.7+0x736>
   64b9e:	xor    %edx,%edx
   64ba0:	cmp    %r13,%rbx
   64ba3:	setae  %dl
   64ba6:	mov    $0x20,%esi
   64bab:	mov    %r15,%rdi
   64bae:	mov    %r12,%rcx
   64bb1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   64bb6:	test   $0x1,%al
   64bb8:	je     6559c <f.7+0x11bc>
   64bbe:	movq   $0x41,(%rdx)
   64bc5:	pxor   %xmm0,%xmm0
   64bc9:	movdqu %xmm0,0x8(%rdx)
   64bce:	addq   $0x20,0xe0(%r15)
   64bd6:	movdqu 0x110(%r15),%xmm0
   64bdf:	paddq  -0x60697(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   64be7:	lea    0x8(%rdx),%rbx
   64beb:	movdqu %xmm0,0x110(%r15)
   64bf4:	movq   $0x96,0x8(%rdx)
   64bfc:	movq   $0x0,0x10(%rdx)
   64c04:	mov    %rbx,0x40(%rsp)
   64c09:	movq   $0x4,0x20(%rsp)
   64c12:	mov    0x5bff(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   64c19:	test   %r15,%r15
   64c1c:	je     655ad <f.7+0x11cd>
   64c22:	mov    0x178(%r15),%rcx
   64c29:	test   %rcx,%rcx
   64c2c:	je     64c68 <f.7+0x888>
   64c2e:	mov    0x170(%r15),%rax
   64c35:	inc    %rax
   64c38:	mov    %rax,0x170(%r15)
   64c3f:	mov    %rax,%rdx
   64c42:	or     %rcx,%rdx
   64c45:	shr    $0x20,%rdx
   64c49:	je     65542 <f.7+0x1162>
   64c4f:	xor    %edx,%edx
   64c51:	div    %rcx
   64c54:	test   %rdx,%rdx
   64c57:	jne    64c68 <f.7+0x888>
   64c59:	mov    0x5bc0(%rip),%rsi        # 6a820 <native_roots.0>
   64c60:	mov    %r15,%rdi
   64c63:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64c68:	cmpq   $0x20,0x98(%r15)
   64c70:	jb     6559c <f.7+0x11bc>
   64c76:	mov    0x5ba3(%rip),%r12        # 6a820 <native_roots.0>
   64c7d:	mov    0xe0(%r15),%r13
   64c84:	mov    0xe8(%r15),%rbp
   64c8b:	cmp    %rbp,%r13
   64c8e:	jb     64c9b <f.7+0x8bb>
   64c90:	mov    %r15,%rdi
   64c93:	mov    %r12,%rsi
   64c96:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64c9b:	mov    0xc8(%r15),%rdx
   64ca2:	test   %rdx,%rdx
   64ca5:	je     64cb7 <f.7+0x8d7>
   64ca7:	mov    0xd0(%r15),%rax
   64cae:	sub    %rdx,%rax
   64cb1:	cmp    $0x1f,%rax
   64cb5:	ja     64cd8 <f.7+0x8f8>
   64cb7:	mov    $0x20,%esi
   64cbc:	mov    %r15,%rdi
   64cbf:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   64cc4:	cmp    $0x1,%rax
   64cc8:	jne    64d56 <f.7+0x976>
   64cce:	mov    $0x1,%eax
   64cd3:	jmp    64d6e <f.7+0x98e>
   64cd8:	lea    0x20(%rdx),%rax
   64cdc:	mov    %rax,0xc8(%r15)
   64ce3:	mov    0x10(%r15),%rsi
   64ce7:	mov    0xc0(%r15),%rdi
   64cee:	cmp    %rsi,%rdi
   64cf1:	jae    655b2 <f.7+0x11d2>
   64cf7:	mov    0x8(%r15),%rax
   64cfb:	imul   $0x38,%rdi,%rcx
   64cff:	mov    %rdx,%r8
   64d02:	sub    0x18(%rax,%rcx,1),%r8
   64d07:	mov    %r8,%rdi
   64d0a:	shr    $0xf,%rdi
   64d0e:	mov    0x10(%rax,%rcx,1),%rsi
   64d13:	cmp    %rsi,%rdi
   64d16:	jae    655be <f.7+0x11de>
   64d1c:	add    %rcx,%rax
   64d1f:	mov    %r8d,%ecx
   64d22:	imul   $0x220,%rdi,%rsi
   64d29:	add    0x8(%rax),%rsi
   64d2d:	shr    $0x4,%ecx
   64d30:	mov    $0x1,%eax
   64d35:	mov    $0x1,%edi
   64d3a:	shl    %cl,%rdi
   64d3d:	shr    $0x7,%r8d
   64d41:	and    $0xf8,%r8d
   64d48:	or     %rdi,(%r8,%rsi,1)
   64d4c:	cmp    $0x1,%rax
   64d50:	je     64cce <f.7+0x8ee>
   64d56:	xor    %edx,%edx
   64d58:	cmp    %rbp,%r13
   64d5b:	setae  %dl
   64d5e:	mov    $0x20,%esi
   64d63:	mov    %r15,%rdi
   64d66:	mov    %r12,%rcx
   64d69:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   64d6e:	test   $0x1,%al
   64d70:	je     6559c <f.7+0x11bc>
   64d76:	movq   $0x41,(%rdx)
   64d7d:	pxor   %xmm0,%xmm0
   64d81:	movdqu %xmm0,0x8(%rdx)
   64d86:	addq   $0x20,0xe0(%r15)
   64d8e:	movdqu 0x110(%r15),%xmm0
   64d97:	paddq  -0x6084f(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   64d9f:	lea    0x8(%rdx),%r13
   64da3:	movdqu %xmm0,0x110(%r15)
   64dac:	movq   $0x6a,0x8(%rdx)
   64db4:	mov    %rbx,0x10(%rdx)
   64db8:	mov    %r13,0x40(%rsp)
   64dbd:	movq   $0x4,0x20(%rsp)
   64dc6:	mov    0x5a4b(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   64dcd:	test   %r15,%r15
   64dd0:	je     655ad <f.7+0x11cd>
   64dd6:	mov    0x178(%r15),%rcx
   64ddd:	test   %rcx,%rcx
   64de0:	je     64e1c <f.7+0xa3c>
   64de2:	mov    0x170(%r15),%rax
   64de9:	inc    %rax
   64dec:	mov    %rax,0x170(%r15)
   64df3:	mov    %rax,%rdx
   64df6:	or     %rcx,%rdx
   64df9:	shr    $0x20,%rdx
   64dfd:	je     65554 <f.7+0x1174>
   64e03:	xor    %edx,%edx
   64e05:	div    %rcx
   64e08:	test   %rdx,%rdx
   64e0b:	jne    64e1c <f.7+0xa3c>
   64e0d:	mov    0x5a0c(%rip),%rsi        # 6a820 <native_roots.0>
   64e14:	mov    %r15,%rdi
   64e17:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64e1c:	cmpq   $0x20,0x98(%r15)
   64e24:	jb     6559c <f.7+0x11bc>
   64e2a:	mov    0x59ef(%rip),%r12        # 6a820 <native_roots.0>
   64e31:	mov    0xe0(%r15),%rbx
   64e38:	mov    0xe8(%r15),%rbp
   64e3f:	cmp    %rbp,%rbx
   64e42:	jb     64e4f <f.7+0xa6f>
   64e44:	mov    %r15,%rdi
   64e47:	mov    %r12,%rsi
   64e4a:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64e4f:	mov    0xc8(%r15),%rdx
   64e56:	test   %rdx,%rdx
   64e59:	je     64e6b <f.7+0xa8b>
   64e5b:	mov    0xd0(%r15),%rax
   64e62:	sub    %rdx,%rax
   64e65:	cmp    $0x1f,%rax
   64e69:	ja     64e8c <f.7+0xaac>
   64e6b:	mov    $0x20,%esi
   64e70:	mov    %r15,%rdi
   64e73:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   64e78:	cmp    $0x1,%rax
   64e7c:	jne    64f0a <f.7+0xb2a>
   64e82:	mov    $0x1,%eax
   64e87:	jmp    64f22 <f.7+0xb42>
   64e8c:	lea    0x20(%rdx),%rax
   64e90:	mov    %rax,0xc8(%r15)
   64e97:	mov    0x10(%r15),%rsi
   64e9b:	mov    0xc0(%r15),%rdi
   64ea2:	cmp    %rsi,%rdi
   64ea5:	jae    655b2 <f.7+0x11d2>
   64eab:	mov    0x8(%r15),%rax
   64eaf:	imul   $0x38,%rdi,%rcx
   64eb3:	mov    %rdx,%r8
   64eb6:	sub    0x18(%rax,%rcx,1),%r8
   64ebb:	mov    %r8,%rdi
   64ebe:	shr    $0xf,%rdi
   64ec2:	mov    0x10(%rax,%rcx,1),%rsi
   64ec7:	cmp    %rsi,%rdi
   64eca:	jae    655be <f.7+0x11de>
   64ed0:	add    %rcx,%rax
   64ed3:	mov    %r8d,%ecx
   64ed6:	imul   $0x220,%rdi,%rsi
   64edd:	add    0x8(%rax),%rsi
   64ee1:	shr    $0x4,%ecx
   64ee4:	mov    $0x1,%eax
   64ee9:	mov    $0x1,%edi
   64eee:	shl    %cl,%rdi
   64ef1:	shr    $0x7,%r8d
   64ef5:	and    $0xf8,%r8d
   64efc:	or     %rdi,(%r8,%rsi,1)
   64f00:	cmp    $0x1,%rax
   64f04:	je     64e82 <f.7+0xaa2>
   64f0a:	xor    %edx,%edx
   64f0c:	cmp    %rbp,%rbx
   64f0f:	setae  %dl
   64f12:	mov    $0x20,%esi
   64f17:	mov    %r15,%rdi
   64f1a:	mov    %r12,%rcx
   64f1d:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   64f22:	test   $0x1,%al
   64f24:	je     6559c <f.7+0x11bc>
   64f2a:	movq   $0x61,(%rdx)
   64f31:	pxor   %xmm0,%xmm0
   64f35:	movdqu %xmm0,0x8(%rdx)
   64f3a:	movq   $0x0,0x18(%rdx)
   64f42:	addq   $0x20,0xe0(%r15)
   64f4a:	lea    0x8(%rdx),%rbx
   64f4e:	movdqu 0x110(%r15),%xmm0
   64f57:	paddq  -0x60a6f(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   64f5f:	movdqu %xmm0,0x110(%r15)
   64f68:	movq   $0x66,0x8(%rdx)
   64f70:	mov    0x8(%rsp),%rax
   64f75:	mov    %rax,0x10(%rdx)
   64f79:	mov    %r13,0x18(%rdx)
   64f7d:	mov    %rbx,0x40(%rsp)
   64f82:	movq   $0x4,0x20(%rsp)
   64f8b:	mov    0x5886(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   64f92:	test   %r15,%r15
   64f95:	je     655ad <f.7+0x11cd>
   64f9b:	mov    0x178(%r15),%rcx
   64fa2:	test   %rcx,%rcx
   64fa5:	je     64fe1 <f.7+0xc01>
   64fa7:	mov    0x170(%r15),%rax
   64fae:	inc    %rax
   64fb1:	mov    %rax,0x170(%r15)
   64fb8:	mov    %rax,%rdx
   64fbb:	or     %rcx,%rdx
   64fbe:	shr    $0x20,%rdx
   64fc2:	je     65566 <f.7+0x1186>
   64fc8:	xor    %edx,%edx
   64fca:	div    %rcx
   64fcd:	test   %rdx,%rdx
   64fd0:	jne    64fe1 <f.7+0xc01>
   64fd2:	mov    0x5847(%rip),%rsi        # 6a820 <native_roots.0>
   64fd9:	mov    %r15,%rdi
   64fdc:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   64fe1:	cmpq   $0x20,0x98(%r15)
   64fe9:	jb     6559c <f.7+0x11bc>
   64fef:	mov    0x582a(%rip),%r12        # 6a820 <native_roots.0>
   64ff6:	mov    0xe0(%r15),%r13
   64ffd:	mov    0xe8(%r15),%rbp
   65004:	cmp    %rbp,%r13
   65007:	jb     65014 <f.7+0xc34>
   65009:	mov    %r15,%rdi
   6500c:	mov    %r12,%rsi
   6500f:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   65014:	mov    0xc8(%r15),%rdx
   6501b:	test   %rdx,%rdx
   6501e:	je     65030 <f.7+0xc50>
   65020:	mov    0xd0(%r15),%rax
   65027:	sub    %rdx,%rax
   6502a:	cmp    $0x1f,%rax
   6502e:	ja     65051 <f.7+0xc71>
   65030:	mov    $0x20,%esi
   65035:	mov    %r15,%rdi
   65038:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   6503d:	cmp    $0x1,%rax
   65041:	jne    650cf <f.7+0xcef>
   65047:	mov    $0x1,%eax
   6504c:	jmp    650e7 <f.7+0xd07>
   65051:	lea    0x20(%rdx),%rax
   65055:	mov    %rax,0xc8(%r15)
   6505c:	mov    0x10(%r15),%rsi
   65060:	mov    0xc0(%r15),%rdi
   65067:	cmp    %rsi,%rdi
   6506a:	jae    655b2 <f.7+0x11d2>
   65070:	mov    0x8(%r15),%rax
   65074:	imul   $0x38,%rdi,%rcx
   65078:	mov    %rdx,%r8
   6507b:	sub    0x18(%rax,%rcx,1),%r8
   65080:	mov    %r8,%rdi
   65083:	shr    $0xf,%rdi
   65087:	mov    0x10(%rax,%rcx,1),%rsi
   6508c:	cmp    %rsi,%rdi
   6508f:	jae    655be <f.7+0x11de>
   65095:	add    %rcx,%rax
   65098:	mov    %r8d,%ecx
   6509b:	imul   $0x220,%rdi,%rsi
   650a2:	add    0x8(%rax),%rsi
   650a6:	shr    $0x4,%ecx
   650a9:	mov    $0x1,%eax
   650ae:	mov    $0x1,%edi
   650b3:	shl    %cl,%rdi
   650b6:	shr    $0x7,%r8d
   650ba:	and    $0xf8,%r8d
   650c1:	or     %rdi,(%r8,%rsi,1)
   650c5:	cmp    $0x1,%rax
   650c9:	je     65047 <f.7+0xc67>
   650cf:	xor    %edx,%edx
   650d1:	cmp    %rbp,%r13
   650d4:	setae  %dl
   650d7:	mov    $0x20,%esi
   650dc:	mov    %r15,%rdi
   650df:	mov    %r12,%rcx
   650e2:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   650e7:	test   $0x1,%al
   650e9:	je     6559c <f.7+0x11bc>
   650ef:	movq   $0x41,(%rdx)
   650f6:	pxor   %xmm0,%xmm0
   650fa:	movdqu %xmm0,0x8(%rdx)
   650ff:	addq   $0x20,0xe0(%r15)
   65107:	movdqu 0x110(%r15),%xmm0
   65110:	paddq  -0x60bc8(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   65118:	lea    0x8(%rdx),%r13
   6511c:	movdqu %xmm0,0x110(%r15)
   65125:	movq   $0x96,0x8(%rdx)
   6512d:	mov    %rbx,0x10(%rdx)
   65131:	mov    %r13,0x40(%rsp)
   65136:	movq   $0x4,0x20(%rsp)
   6513f:	mov    0x56d2(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   65146:	test   %r15,%r15
   65149:	je     655ad <f.7+0x11cd>
   6514f:	mov    0x178(%r15),%rcx
   65156:	test   %rcx,%rcx
   65159:	je     65195 <f.7+0xdb5>
   6515b:	mov    0x170(%r15),%rax
   65162:	inc    %rax
   65165:	mov    %rax,0x170(%r15)
   6516c:	mov    %rax,%rdx
   6516f:	or     %rcx,%rdx
   65172:	shr    $0x20,%rdx
   65176:	je     65578 <f.7+0x1198>
   6517c:	xor    %edx,%edx
   6517e:	div    %rcx
   65181:	test   %rdx,%rdx
   65184:	jne    65195 <f.7+0xdb5>
   65186:	mov    0x5693(%rip),%rsi        # 6a820 <native_roots.0>
   6518d:	mov    %r15,%rdi
   65190:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   65195:	cmpq   $0x20,0x98(%r15)
   6519d:	jb     6559c <f.7+0x11bc>
   651a3:	mov    0x5676(%rip),%r12        # 6a820 <native_roots.0>
   651aa:	mov    0xe0(%r15),%rbx
   651b1:	mov    0xe8(%r15),%rbp
   651b8:	cmp    %rbp,%rbx
   651bb:	jb     651c8 <f.7+0xde8>
   651bd:	mov    %r15,%rdi
   651c0:	mov    %r12,%rsi
   651c3:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   651c8:	mov    0xc8(%r15),%rdx
   651cf:	test   %rdx,%rdx
   651d2:	je     651e4 <f.7+0xe04>
   651d4:	mov    0xd0(%r15),%rax
   651db:	sub    %rdx,%rax
   651de:	cmp    $0x1f,%rax
   651e2:	ja     65205 <f.7+0xe25>
   651e4:	mov    $0x20,%esi
   651e9:	mov    %r15,%rdi
   651ec:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   651f1:	cmp    $0x1,%rax
   651f5:	jne    65283 <f.7+0xea3>
   651fb:	mov    $0x1,%eax
   65200:	jmp    6529b <f.7+0xebb>
   65205:	lea    0x20(%rdx),%rax
   65209:	mov    %rax,0xc8(%r15)
   65210:	mov    0x10(%r15),%rsi
   65214:	mov    0xc0(%r15),%rdi
   6521b:	cmp    %rsi,%rdi
   6521e:	jae    655b2 <f.7+0x11d2>
   65224:	mov    0x8(%r15),%rax
   65228:	imul   $0x38,%rdi,%rcx
   6522c:	mov    %rdx,%r8
   6522f:	sub    0x18(%rax,%rcx,1),%r8
   65234:	mov    %r8,%rdi
   65237:	shr    $0xf,%rdi
   6523b:	mov    0x10(%rax,%rcx,1),%rsi
   65240:	cmp    %rsi,%rdi
   65243:	jae    655be <f.7+0x11de>
   65249:	add    %rcx,%rax
   6524c:	mov    %r8d,%ecx
   6524f:	imul   $0x220,%rdi,%rsi
   65256:	add    0x8(%rax),%rsi
   6525a:	shr    $0x4,%ecx
   6525d:	mov    $0x1,%eax
   65262:	mov    $0x1,%edi
   65267:	shl    %cl,%rdi
   6526a:	shr    $0x7,%r8d
   6526e:	and    $0xf8,%r8d
   65275:	or     %rdi,(%r8,%rsi,1)
   65279:	cmp    $0x1,%rax
   6527d:	je     651fb <f.7+0xe1b>
   65283:	xor    %edx,%edx
   65285:	cmp    %rbp,%rbx
   65288:	setae  %dl
   6528b:	mov    $0x20,%esi
   65290:	mov    %r15,%rdi
   65293:	mov    %r12,%rcx
   65296:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   6529b:	test   $0x1,%al
   6529d:	je     6559c <f.7+0x11bc>
   652a3:	movq   $0x41,(%rdx)
   652aa:	pxor   %xmm0,%xmm0
   652ae:	movdqu %xmm0,0x8(%rdx)
   652b3:	addq   $0x20,0xe0(%r15)
   652bb:	movdqu 0x110(%r15),%xmm0
   652c4:	paddq  -0x60d7c(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   652cc:	lea    0x8(%rdx),%rbx
   652d0:	movdqu %xmm0,0x110(%r15)
   652d9:	movq   $0x6a,0x8(%rdx)
   652e1:	mov    %r13,0x10(%rdx)
   652e5:	mov    %rbx,0x40(%rsp)
   652ea:	movq   $0x4,0x20(%rsp)
   652f3:	mov    0x551e(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   652fa:	test   %r15,%r15
   652fd:	je     655ad <f.7+0x11cd>
   65303:	mov    0x178(%r15),%rcx
   6530a:	test   %rcx,%rcx
   6530d:	je     65349 <f.7+0xf69>
   6530f:	mov    0x170(%r15),%rax
   65316:	inc    %rax
   65319:	mov    %rax,0x170(%r15)
   65320:	mov    %rax,%rdx
   65323:	or     %rcx,%rdx
   65326:	shr    $0x20,%rdx
   6532a:	je     6558a <f.7+0x11aa>
   65330:	xor    %edx,%edx
   65332:	div    %rcx
   65335:	test   %rdx,%rdx
   65338:	jne    65349 <f.7+0xf69>
   6533a:	mov    0x54df(%rip),%rsi        # 6a820 <native_roots.0>
   65341:	mov    %r15,%rdi
   65344:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   65349:	cmpq   $0x30,0x98(%r15)
   65351:	jb     6559c <f.7+0x11bc>
   65357:	mov    0x54c2(%rip),%r12        # 6a820 <native_roots.0>
   6535e:	mov    0xe0(%r15),%r13
   65365:	mov    0xe8(%r15),%rbp
   6536c:	cmp    %rbp,%r13
   6536f:	jb     6537c <f.7+0xf9c>
   65371:	mov    %r15,%rdi
   65374:	mov    %r12,%rsi
   65377:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6537c:	mov    0xc8(%r15),%rdx
   65383:	test   %rdx,%rdx
   65386:	je     65398 <f.7+0xfb8>
   65388:	mov    0xd0(%r15),%rax
   6538f:	sub    %rdx,%rax
   65392:	cmp    $0x2f,%rax
   65396:	ja     653b9 <f.7+0xfd9>
   65398:	mov    $0x30,%esi
   6539d:	mov    %r15,%rdi
   653a0:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   653a5:	cmp    $0x1,%rax
   653a9:	jne    65437 <f.7+0x1057>
   653af:	mov    $0x1,%eax
   653b4:	jmp    6544f <f.7+0x106f>
   653b9:	lea    0x30(%rdx),%rax
   653bd:	mov    %rax,0xc8(%r15)
   653c4:	mov    0x10(%r15),%rsi
   653c8:	mov    0xc0(%r15),%rdi
   653cf:	cmp    %rsi,%rdi
   653d2:	jae    655b2 <f.7+0x11d2>
   653d8:	mov    0x8(%r15),%rax
   653dc:	imul   $0x38,%rdi,%rcx
   653e0:	mov    %rdx,%r8
   653e3:	sub    0x18(%rax,%rcx,1),%r8
   653e8:	mov    %r8,%rdi
   653eb:	shr    $0xf,%rdi
   653ef:	mov    0x10(%rax,%rcx,1),%rsi
   653f4:	cmp    %rsi,%rdi
   653f7:	jae    655be <f.7+0x11de>
   653fd:	add    %rcx,%rax
   65400:	mov    %r8d,%ecx
   65403:	imul   $0x220,%rdi,%rsi
   6540a:	add    0x8(%rax),%rsi
   6540e:	shr    $0x4,%ecx
   65411:	mov    $0x1,%eax
   65416:	mov    $0x1,%edi
   6541b:	shl    %cl,%rdi
   6541e:	shr    $0x7,%r8d
   65422:	and    $0xf8,%r8d
   65429:	or     %rdi,(%r8,%rsi,1)
   6542d:	cmp    $0x1,%rax
   65431:	je     653af <f.7+0xfcf>
   65437:	xor    %edx,%edx
   65439:	cmp    %rbp,%r13
   6543c:	setae  %dl
   6543f:	mov    $0x30,%esi
   65444:	mov    %r15,%rdi
   65447:	mov    %r12,%rcx
   6544a:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   6544f:	test   $0x1,%al
   65451:	je     6559c <f.7+0x11bc>
   65457:	movq   $0xa1,(%rdx)
   6545e:	lea    0x8(%rdx),%rdi
   65462:	pxor   %xmm0,%xmm0
   65466:	movdqu %xmm0,0x8(%rdx)
   6546b:	movdqu %xmm0,0x18(%rdx)
   65470:	movq   $0x0,0x28(%rdx)
   65478:	addq   $0x30,0xe0(%r15)
   65480:	movdqu 0x110(%r15),%xmm0
   65489:	paddq  -0x60f31(%rip),%xmm0        # 4560 <__abi_tag+0x422c>
   65491:	movdqu %xmm0,0x110(%r15)
   6549a:	lea    -0x4(,%r14,4),%rax
   654a2:	movq   $0x62,0x8(%rdx)
   654aa:	mov    0x8(%rsp),%rcx
   654af:	mov    %rcx,0x10(%rdx)
   654b3:	add    $0xfffffffffffffffe,%rcx
   654b7:	mov    %rcx,0x18(%rdx)
   654bb:	mov    %rax,0x20(%rdx)
   654bf:	mov    %rbx,0x28(%rdx)
   654c3:	cmpq   $0x0,0x18(%rsp)
   654c9:	je     654de <f.7+0x10fe>
   654cb:	mov    0x10(%rsp),%rax
   654d0:	mov    %rax,0x5349(%rip)        # 6a820 <native_roots.0>
   654d7:	decq   0x5322(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   654de:	call   5b930 <f.8>
   654e3:	sub    $0x8,%rsp
   654e7:	xor    %eax,%eax
   654e9:	add    $0x58,%rsp
   654ed:	pop    %rbx
   654ee:	pop    %r12
   654f0:	pop    %r13
   654f2:	pop    %r14
   654f4:	pop    %r15
   654f6:	pop    %rbp
   654f7:	ret    $0x8
   654fa:	xor    %edx,%edx
   654fc:	div    %ecx
   654fe:	test   %rdx,%rdx
   65501:	jne    644d1 <f.7+0xf1>
   65507:	jmp    644bd <f.7+0xdd>
   6550c:	xor    %edx,%edx
   6550e:	div    %ecx
   65510:	test   %rdx,%rdx
   65513:	jne    646ac <f.7+0x2cc>
   65519:	jmp    6469d <f.7+0x2bd>
   6551e:	xor    %edx,%edx
   65520:	div    %ecx
   65522:	test   %rdx,%rdx
   65525:	jne    64871 <f.7+0x491>
   6552b:	jmp    64862 <f.7+0x482>
   65530:	xor    %edx,%edx
   65532:	div    %ecx
   65534:	test   %rdx,%rdx
   65537:	jne    64ab0 <f.7+0x6d0>
   6553d:	jmp    64aa1 <f.7+0x6c1>
   65542:	xor    %edx,%edx
   65544:	div    %ecx
   65546:	test   %rdx,%rdx
   65549:	jne    64c68 <f.7+0x888>
   6554f:	jmp    64c59 <f.7+0x879>
   65554:	xor    %edx,%edx
   65556:	div    %ecx
   65558:	test   %rdx,%rdx
   6555b:	jne    64e1c <f.7+0xa3c>
   65561:	jmp    64e0d <f.7+0xa2d>
   65566:	xor    %edx,%edx
   65568:	div    %ecx
   6556a:	test   %rdx,%rdx
   6556d:	jne    64fe1 <f.7+0xc01>
   65573:	jmp    64fd2 <f.7+0xbf2>
   65578:	xor    %edx,%edx
   6557a:	div    %ecx
   6557c:	test   %rdx,%rdx
   6557f:	jne    65195 <f.7+0xdb5>
   65585:	jmp    65186 <f.7+0xda6>
   6558a:	xor    %edx,%edx
   6558c:	div    %ecx
   6558e:	test   %rdx,%rdx
   65591:	jne    65349 <f.7+0xf69>
   65597:	jmp    6533a <f.7+0xf5a>
   6559c:	lea    -0x5c14f(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   655a3:	mov    $0x2f,%esi
   655a8:	call   57d70 <snail_runtime::native::fail_bytes>
   655ad:	call   56d70 <native_trap>
   655b2:	lea    0x2007(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   655b9:	call   207b0 <core::panicking::panic_bounds_check>
   655be:	lea    0x2013(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   655c5:	call   207b0 <core::panicking::panic_bounds_check>
   655ca:	int3
   655cb:	int3
   655cc:	int3
   655cd:	int3
   655ce:	int3
   655cf:	int3
