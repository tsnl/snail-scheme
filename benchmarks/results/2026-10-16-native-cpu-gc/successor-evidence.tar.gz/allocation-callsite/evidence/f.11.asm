   63c20:	push   %rbp
   63c21:	push   %r15
   63c23:	push   %r14
   63c25:	push   %r13
   63c27:	push   %r12
   63c29:	push   %rbx
   63c2a:	sub    $0x58,%rsp
   63c2e:	movq   $0x4,0x20(%rsp)
   63c37:	movq   $0x0,0x28(%rsp)
   63c40:	mov    0x6bd9(%rip),%rax        # 6a820 <native_roots.0>
   63c47:	mov    %rax,0x18(%rsp)
   63c4c:	lea    0x18(%rsp),%rax
   63c51:	mov    %rax,0x6bc8(%rip)        # 6a820 <native_roots.0>
   63c58:	mov    0x6ba1(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   63c5f:	inc    %rax
   63c62:	mov    %rax,0x6b97(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   63c69:	mov    0x6b98(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   63c70:	cmp    %rcx,%rax
   63c73:	cmovbe %rcx,%rax
   63c77:	mov    %rax,0x6b8a(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   63c7e:	mov    %rdi,0x30(%rsp)
   63c83:	movq   $0x0,0x38(%rsp)
   63c8c:	test   %rdi,%rdi
   63c8f:	je     63f8e <f.11+0x36e>
   63c95:	mov    %edi,%eax
   63c97:	and    $0x1,%eax
   63c9a:	jne    63f8e <f.11+0x36e>
   63ca0:	mov    0x6b71(%rip),%rdx        # 6a818 <snail_runtime::native::RUNTIME>
   63ca7:	test   %rdx,%rdx
   63caa:	je     63f8e <f.11+0x36e>
   63cb0:	mov    %rsi,%rbx
   63cb3:	mov    (%rdi),%rax
   63cb6:	test   %rax,%rax
   63cb9:	je     63d11 <f.11+0xf1>
   63cbb:	cmp    $0x2a,%rax
   63cbf:	je     63d11 <f.11+0xf1>
   63cc1:	mov    0x168(%rdx),%rcx
   63cc8:	shr    $0x2,%rax
   63ccc:	lea    -0x1(%rax),%rsi
   63cd0:	cmp    %rcx,%rsi
   63cd3:	jae    63f8e <f.11+0x36e>
   63cd9:	mov    0x160(%rdx),%rdx
   63ce0:	mov    -0x8(%rdx,%rax,8),%rax
   63ce5:	test   %rax,%rax
   63ce8:	je     63d11 <f.11+0xf1>
   63cea:	cmp    $0x2a,%rax
   63cee:	je     63d11 <f.11+0xf1>
   63cf0:	shr    $0x2,%rax
   63cf4:	lea    -0x1(%rax),%rsi
   63cf8:	cmp    %rcx,%rsi
   63cfb:	jae    63f8e <f.11+0x36e>
   63d01:	mov    -0x8(%rdx,%rax,8),%rax
   63d06:	cmp    $0x2a,%rax
   63d0a:	je     63d11 <f.11+0xf1>
   63d0c:	test   %rax,%rax
   63d0f:	jne    63cf0 <f.11+0xd0>
   63d11:	cmp    $0x2a,%rax
   63d15:	jne    63f8e <f.11+0x36e>
   63d1b:	mov    %rdi,0x38(%rsp)
   63d20:	mov    0x18(%rdi),%rax
   63d24:	test   %rax,%rax
   63d27:	je     63f8e <f.11+0x36e>
   63d2d:	mov    0x8(%rax),%rax
   63d31:	test   %rax,%rax
   63d34:	je     63f8e <f.11+0x36e>
   63d3a:	mov    0x8(%rax),%rdi
   63d3e:	mov    %rdi,0x40(%rsp)
   63d43:	movq   $0x3,0x28(%rsp)
   63d4c:	mov    %rbx,%rsi
   63d4f:	call   61040 <f.15>
   63d54:	sub    $0x8,%rsp
   63d58:	mov    %rax,%rbp
   63d5b:	mov    0x38(%rsp),%rax
   63d60:	test   %rax,%rax
   63d63:	je     63f8e <f.11+0x36e>
   63d69:	mov    0x8(%rax),%r12
   63d6d:	mov    0x10(%rax),%r13
   63d71:	mov    %r13,0x40(%rsp)
   63d76:	mov    %r12,0x48(%rsp)
   63d7b:	movq   $0x4,0x28(%rsp)
   63d84:	mov    0x6a8d(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   63d8b:	test   %r15,%r15
   63d8e:	je     63f8e <f.11+0x36e>
   63d94:	mov    0x178(%r15),%rcx
   63d9b:	test   %rcx,%rcx
   63d9e:	je     63dda <f.11+0x1ba>
   63da0:	mov    0x170(%r15),%rax
   63da7:	inc    %rax
   63daa:	mov    %rax,0x170(%r15)
   63db1:	mov    %rax,%rdx
   63db4:	or     %rcx,%rdx
   63db7:	shr    $0x20,%rdx
   63dbb:	je     63f7c <f.11+0x35c>
   63dc1:	xor    %edx,%edx
   63dc3:	div    %rcx
   63dc6:	test   %rdx,%rdx
   63dc9:	jne    63dda <f.11+0x1ba>
   63dcb:	mov    0x6a4e(%rip),%rsi        # 6a820 <native_roots.0>
   63dd2:	mov    %r15,%rdi
   63dd5:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   63dda:	cmpq   $0x30,0x98(%r15)
   63de2:	jb     63f93 <f.11+0x373>
   63de8:	mov    %r13,0x50(%rsp)
   63ded:	mov    %r12,0x10(%rsp)
   63df2:	mov    %rbx,%r13
   63df5:	mov    0x6a24(%rip),%r12        # 6a820 <native_roots.0>
   63dfc:	mov    0xe0(%r15),%r14
   63e03:	mov    0xe8(%r15),%rbx
   63e0a:	cmp    %rbx,%r14
   63e0d:	jb     63e1a <f.11+0x1fa>
   63e0f:	mov    %r15,%rdi
   63e12:	mov    %r12,%rsi
   63e15:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   63e1a:	mov    0xc8(%r15),%rdx
   63e21:	test   %rdx,%rdx
   63e24:	je     63e36 <f.11+0x216>
   63e26:	mov    0xd0(%r15),%rax
   63e2d:	sub    %rdx,%rax
   63e30:	cmp    $0x2f,%rax
   63e34:	ja     63e57 <f.11+0x237>
   63e36:	mov    $0x30,%esi
   63e3b:	mov    %r15,%rdi
   63e3e:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   63e43:	cmp    $0x1,%rax
   63e47:	jne    63ed5 <f.11+0x2b5>
   63e4d:	mov    $0x1,%eax
   63e52:	jmp    63eed <f.11+0x2cd>
   63e57:	lea    0x30(%rdx),%rax
   63e5b:	mov    %rax,0xc8(%r15)
   63e62:	mov    0x10(%r15),%rsi
   63e66:	mov    0xc0(%r15),%rdi
   63e6d:	cmp    %rsi,%rdi
   63e70:	jae    63fa4 <f.11+0x384>
   63e76:	mov    0x8(%r15),%rax
   63e7a:	imul   $0x38,%rdi,%rcx
   63e7e:	mov    %rdx,%r8
   63e81:	sub    0x18(%rax,%rcx,1),%r8
   63e86:	mov    %r8,%rdi
   63e89:	shr    $0xf,%rdi
   63e8d:	mov    0x10(%rax,%rcx,1),%rsi
   63e92:	cmp    %rsi,%rdi
   63e95:	jae    63fb0 <f.11+0x390>
   63e9b:	add    %rcx,%rax
   63e9e:	mov    %r8d,%ecx
   63ea1:	imul   $0x220,%rdi,%rsi
   63ea8:	add    0x8(%rax),%rsi
   63eac:	shr    $0x4,%ecx
   63eaf:	mov    $0x1,%eax
   63eb4:	mov    $0x1,%edi
   63eb9:	shl    %cl,%rdi
   63ebc:	shr    $0x7,%r8d
   63ec0:	and    $0xf8,%r8d
   63ec7:	or     %rdi,(%r8,%rsi,1)
   63ecb:	cmp    $0x1,%rax
   63ecf:	je     63e4d <f.11+0x22d>
   63ed5:	xor    %edx,%edx
   63ed7:	cmp    %rbx,%r14
   63eda:	setae  %dl
   63edd:	mov    $0x30,%esi
   63ee2:	mov    %r15,%rdi
   63ee5:	mov    %r12,%rcx
   63ee8:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   63eed:	mov    0x10(%rsp),%rcx
   63ef2:	test   $0x1,%al
   63ef4:	mov    0x50(%rsp),%rax
   63ef9:	je     63f93 <f.11+0x373>
   63eff:	movq   $0x81,(%rdx)
   63f06:	xorps  %xmm0,%xmm0
   63f09:	movups %xmm0,0x8(%rdx)
   63f0d:	movups %xmm0,0x18(%rdx)
   63f11:	addq   $0x30,0xe0(%r15)
   63f19:	movdqu 0x110(%r15),%xmm0
   63f22:	paddq  -0x5fbba(%rip),%xmm0        # 4370 <__abi_tag+0x403c>
   63f2a:	lea    0x8(%rdx),%rdi
   63f2e:	movdqu %xmm0,0x110(%r15)
   63f37:	movq   $0x22,0x8(%rdx)
   63f3f:	mov    %rcx,0x10(%rdx)
   63f43:	mov    %rax,0x18(%rdx)
   63f47:	mov    %r13,0x20(%rdx)
   63f4b:	cmpq   $0x0,0x20(%rsp)
   63f51:	je     63f66 <f.11+0x346>
   63f53:	mov    0x18(%rsp),%rax
   63f58:	mov    %rax,0x68c1(%rip)        # 6a820 <native_roots.0>
   63f5f:	decq   0x689a(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   63f66:	mov    %rbp,%rsi
   63f69:	add    $0x58,%rsp
   63f6d:	pop    %rbx
   63f6e:	pop    %r12
   63f70:	pop    %r13
   63f72:	pop    %r14
   63f74:	pop    %r15
   63f76:	pop    %rbp
   63f77:	jmp    61e40 <f.12>
   63f7c:	xor    %edx,%edx
   63f7e:	div    %ecx
   63f80:	test   %rdx,%rdx
   63f83:	jne    63dda <f.11+0x1ba>
   63f89:	jmp    63dcb <f.11+0x1ab>
   63f8e:	call   56d70 <native_trap>
   63f93:	lea    -0x5ab46(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   63f9a:	mov    $0x2f,%esi
   63f9f:	call   57d70 <snail_runtime::native::fail_bytes>
   63fa4:	lea    0x3615(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   63fab:	call   207b0 <core::panicking::panic_bounds_check>
   63fb0:	lea    0x3621(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   63fb7:	call   207b0 <core::panicking::panic_bounds_check>
   63fbc:	int3
   63fbd:	int3
   63fbe:	int3
   63fbf:	int3
