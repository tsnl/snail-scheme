   5e630:	push   %rbp
   5e631:	push   %r15
   5e633:	push   %r14
   5e635:	push   %r13
   5e637:	push   %r12
   5e639:	push   %rbx
   5e63a:	sub    $0x58,%rsp
   5e63e:	movq   $0x7,0x10(%rsp)
   5e647:	movq   $0x0,0x18(%rsp)
   5e650:	mov    0xc1c9(%rip),%rax        # 6a820 <native_roots.0>
   5e657:	mov    %rax,0x8(%rsp)
   5e65c:	mov    0xc19d(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5e663:	inc    %rax
   5e666:	mov    %rax,0xc193(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5e66d:	mov    0xc194(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5e674:	cmp    %rcx,%rax
   5e677:	cmovbe %rcx,%rax
   5e67b:	lea    0x8(%rsp),%r14
   5e680:	mov    %r14,0xc199(%rip)        # 6a820 <native_roots.0>
   5e687:	mov    %rax,0xc17a(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5e68e:	mov    %rdi,0x20(%rsp)
   5e693:	pxor   %xmm0,%xmm0
   5e697:	movdqu %xmm0,0x28(%rsp)
   5e69d:	movdqu %xmm0,0x38(%rsp)
   5e6a3:	test   %rsi,%rsi
   5e6a6:	jle    5e856 <f.18+0x226>
   5e6ac:	test   %rdi,%rdi
   5e6af:	je     5f19c <f.18+0xb6c>
   5e6b5:	mov    0x8(%rdi),%rax
   5e6b9:	test   %rax,%rax
   5e6bc:	je     5f19c <f.18+0xb6c>
   5e6c2:	cmpl   $0x0,0x8(%rax)
   5e6c6:	je     5f19c <f.18+0xb6c>
   5e6cc:	mov    %rax,0x28(%rsp)
   5e6d1:	cmpq   $0x0,0x10(%rax)
   5e6d6:	je     5f19c <f.18+0xb6c>
   5e6dc:	mov    %rsi,%rbx
   5e6df:	dec    %rbx
   5e6e2:	mov    %rdi,0x48(%rsp)
   5e6e7:	movq   $0x6,0x18(%rsp)
   5e6f0:	mov    %rbx,%rsi
   5e6f3:	call   5e630 <f.18>
   5e6f8:	sub    $0x8,%rsp
   5e6fc:	mov    %rax,0x40(%rsp)
   5e701:	mov    0x28(%rsp),%rax
   5e706:	test   %rax,%rax
   5e709:	je     5f19c <f.18+0xb6c>
   5e70f:	cmpl   $0x0,0x8(%rax)
   5e713:	je     5f19c <f.18+0xb6c>
   5e719:	mov    0x20(%rsp),%rdi
   5e71e:	test   %rdi,%rdi
   5e721:	je     5f19c <f.18+0xb6c>
   5e727:	mov    0x8(%rdi),%rax
   5e72b:	test   %rax,%rax
   5e72e:	je     5f19c <f.18+0xb6c>
   5e734:	cmpq   $0x0,0x10(%rax)
   5e739:	je     5f19c <f.18+0xb6c>
   5e73f:	mov    %rdi,0x48(%rsp)
   5e744:	movq   $0x6,0x18(%rsp)
   5e74d:	mov    %rbx,%rsi
   5e750:	call   5e630 <f.18>
   5e755:	sub    $0x8,%rsp
   5e759:	mov    %rax,0x38(%rsp)
   5e75e:	cmpb   $0x0,0xc1a3(%rip)        # 6a908 <g.5>
   5e765:	je     5f19c <f.18+0xb6c>
   5e76b:	cmpq   $0x0,0xc18d(%rip)        # 6a900 <g.4>
   5e773:	je     5f19c <f.18+0xb6c>
   5e779:	mov    0x40(%rsp),%r12
   5e77e:	mov    %r12,0x48(%rsp)
   5e783:	movq   $0x6,0x18(%rsp)
   5e78c:	mov    0xc085(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5e793:	test   %rbx,%rbx
   5e796:	je     5f19c <f.18+0xb6c>
   5e79c:	mov    0x178(%rbx),%rcx
   5e7a3:	test   %rcx,%rcx
   5e7a6:	je     5e7e2 <f.18+0x1b2>
   5e7a8:	mov    0x170(%rbx),%rax
   5e7af:	inc    %rax
   5e7b2:	mov    %rax,0x170(%rbx)
   5e7b9:	mov    %rax,%rdx
   5e7bc:	or     %rcx,%rdx
   5e7bf:	shr    $0x20,%rdx
   5e7c3:	je     5ecad <f.18+0x67d>
   5e7c9:	xor    %edx,%edx
   5e7cb:	div    %rcx
   5e7ce:	test   %rdx,%rdx
   5e7d1:	jne    5e7e2 <f.18+0x1b2>
   5e7d3:	mov    0xc046(%rip),%rsi        # 6a820 <native_roots.0>
   5e7da:	mov    %rbx,%rdi
   5e7dd:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5e7e2:	cmpq   $0x20,0x98(%rbx)
   5e7ea:	jb     5f1a1 <f.18+0xb71>
   5e7f0:	mov    0xc029(%rip),%r14        # 6a820 <native_roots.0>
   5e7f7:	mov    0xe0(%rbx),%r15
   5e7fe:	mov    0xe8(%rbx),%r13
   5e805:	cmp    %r13,%r15
   5e808:	jb     5e815 <f.18+0x1e5>
   5e80a:	mov    %rbx,%rdi
   5e80d:	mov    %r14,%rsi
   5e810:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5e815:	mov    0xc8(%rbx),%rdx
   5e81c:	test   %rdx,%rdx
   5e81f:	je     5e835 <f.18+0x205>
   5e821:	mov    0xd0(%rbx),%rax
   5e828:	sub    %rdx,%rax
   5e82b:	cmp    $0x1f,%rax
   5e82f:	ja     5e94e <f.18+0x31e>
   5e835:	mov    $0x20,%esi
   5e83a:	mov    %rbx,%rdi
   5e83d:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5e842:	cmp    $0x1,%rax
   5e846:	jne    5e9cc <f.18+0x39c>
   5e84c:	mov    $0x1,%eax
   5e851:	jmp    5e9e4 <f.18+0x3b4>
   5e856:	cmpb   $0x0,0xc0ab(%rip)        # 6a908 <g.5>
   5e85d:	je     5f19c <f.18+0xb6c>
   5e863:	cmpq   $0x0,0xc095(%rip)        # 6a900 <g.4>
   5e86b:	je     5f19c <f.18+0xb6c>
   5e871:	lea    -0x53b68(%rip),%r13        # ad10 <object.1.0>
   5e878:	mov    %r13,0x48(%rsp)
   5e87d:	movq   $0x6,0x18(%rsp)
   5e886:	mov    0xbf8b(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5e88d:	test   %rbx,%rbx
   5e890:	je     5f19c <f.18+0xb6c>
   5e896:	mov    0x178(%rbx),%rcx
   5e89d:	test   %rcx,%rcx
   5e8a0:	je     5e8e1 <f.18+0x2b1>
   5e8a2:	mov    0x170(%rbx),%rax
   5e8a9:	inc    %rax
   5e8ac:	mov    %rax,0x170(%rbx)
   5e8b3:	mov    %rax,%rdx
   5e8b6:	or     %rcx,%rdx
   5e8b9:	shr    $0x20,%rdx
   5e8bd:	je     5f166 <f.18+0xb36>
   5e8c3:	xor    %edx,%edx
   5e8c5:	div    %rcx
   5e8c8:	test   %rdx,%rdx
   5e8cb:	jne    5e8e1 <f.18+0x2b1>
   5e8cd:	lea    0x8(%rsp),%rsi
   5e8d2:	mov    %rbx,%rdi
   5e8d5:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5e8da:	mov    0xbf3f(%rip),%r14        # 6a820 <native_roots.0>
   5e8e1:	cmpq   $0x20,0x98(%rbx)
   5e8e9:	jb     5f1a1 <f.18+0xb71>
   5e8ef:	mov    0xe0(%rbx),%r15
   5e8f6:	mov    0xe8(%rbx),%r12
   5e8fd:	cmp    %r12,%r15
   5e900:	jb     5e90d <f.18+0x2dd>
   5e902:	mov    %rbx,%rdi
   5e905:	mov    %r14,%rsi
   5e908:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5e90d:	mov    0xc8(%rbx),%rdx
   5e914:	test   %rdx,%rdx
   5e917:	je     5e92d <f.18+0x2fd>
   5e919:	mov    0xd0(%rbx),%rax
   5e920:	sub    %rdx,%rax
   5e923:	cmp    $0x1f,%rax
   5e927:	ja     5ece3 <f.18+0x6b3>
   5e92d:	mov    $0x20,%esi
   5e932:	mov    %rbx,%rdi
   5e935:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5e93a:	cmp    $0x1,%rax
   5e93e:	jne    5ed61 <f.18+0x731>
   5e944:	mov    $0x1,%eax
   5e949:	jmp    5ed79 <f.18+0x749>
   5e94e:	lea    0x20(%rdx),%rax
   5e952:	mov    %rax,0xc8(%rbx)
   5e959:	mov    0x10(%rbx),%rsi
   5e95d:	mov    0xc0(%rbx),%rdi
   5e964:	cmp    %rsi,%rdi
   5e967:	jae    5f1b2 <f.18+0xb82>
   5e96d:	mov    0x8(%rbx),%rax
   5e971:	imul   $0x38,%rdi,%rcx
   5e975:	mov    %rdx,%r8
   5e978:	sub    0x18(%rax,%rcx,1),%r8
   5e97d:	mov    %r8,%rdi
   5e980:	shr    $0xf,%rdi
   5e984:	mov    0x10(%rax,%rcx,1),%rsi
   5e989:	cmp    %rsi,%rdi
   5e98c:	jae    5f1be <f.18+0xb8e>
   5e992:	add    %rcx,%rax
   5e995:	mov    %r8d,%ecx
   5e998:	imul   $0x220,%rdi,%rsi
   5e99f:	add    0x8(%rax),%rsi
   5e9a3:	shr    $0x4,%ecx
   5e9a6:	mov    $0x1,%eax
   5e9ab:	mov    $0x1,%edi
   5e9b0:	shl    %cl,%rdi
   5e9b3:	shr    $0x7,%r8d
   5e9b7:	and    $0xf8,%r8d
   5e9be:	or     %rdi,(%r8,%rsi,1)
   5e9c2:	cmp    $0x1,%rax
   5e9c6:	je     5e84c <f.18+0x21c>
   5e9cc:	xor    %edx,%edx
   5e9ce:	cmp    %r13,%r15
   5e9d1:	setae  %dl
   5e9d4:	mov    $0x20,%esi
   5e9d9:	mov    %rbx,%rdi
   5e9dc:	mov    %r14,%rcx
   5e9df:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5e9e4:	test   $0x1,%al
   5e9e6:	je     5f1a1 <f.18+0xb71>
   5e9ec:	movq   $0x41,(%rdx)
   5e9f3:	lea    0x8(%rdx),%r15
   5e9f7:	pxor   %xmm0,%xmm0
   5e9fb:	movdqu %xmm0,0x8(%rdx)
   5ea00:	addq   $0x20,0xe0(%rbx)
   5ea08:	movdqu 0x110(%rbx),%xmm0
   5ea10:	paddq  -0x5a4c8(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5ea18:	movdqu %xmm0,0x110(%rbx)
   5ea20:	movq   $0x36,0x8(%rdx)
   5ea28:	mov    %r12,0x10(%rdx)
   5ea2c:	mov    0x38(%rsp),%r13
   5ea31:	mov    %r13,0x48(%rsp)
   5ea36:	mov    %r15,0x50(%rsp)
   5ea3b:	movq   $0x7,0x18(%rsp)
   5ea44:	mov    0xbdcd(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5ea4b:	test   %rbx,%rbx
   5ea4e:	je     5f19c <f.18+0xb6c>
   5ea54:	mov    0x178(%rbx),%rcx
   5ea5b:	test   %rcx,%rcx
   5ea5e:	je     5ea9a <f.18+0x46a>
   5ea60:	mov    0x170(%rbx),%rax
   5ea67:	inc    %rax
   5ea6a:	mov    %rax,0x170(%rbx)
   5ea71:	mov    %rax,%rdx
   5ea74:	or     %rcx,%rdx
   5ea77:	shr    $0x20,%rdx
   5ea7b:	je     5ecbf <f.18+0x68f>
   5ea81:	xor    %edx,%edx
   5ea83:	div    %rcx
   5ea86:	test   %rdx,%rdx
   5ea89:	jne    5ea9a <f.18+0x46a>
   5ea8b:	mov    0xbd8e(%rip),%rsi        # 6a820 <native_roots.0>
   5ea92:	mov    %rbx,%rdi
   5ea95:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ea9a:	cmpq   $0x20,0x98(%rbx)
   5eaa2:	jb     5f1a1 <f.18+0xb71>
   5eaa8:	mov    0xbd71(%rip),%r14        # 6a820 <native_roots.0>
   5eaaf:	mov    0xe0(%rbx),%r12
   5eab6:	mov    0xe8(%rbx),%rbp
   5eabd:	cmp    %rbp,%r12
   5eac0:	jb     5eacd <f.18+0x49d>
   5eac2:	mov    %rbx,%rdi
   5eac5:	mov    %r14,%rsi
   5eac8:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5eacd:	mov    0xc8(%rbx),%rdx
   5ead4:	test   %rdx,%rdx
   5ead7:	je     5eae9 <f.18+0x4b9>
   5ead9:	mov    0xd0(%rbx),%rax
   5eae0:	sub    %rdx,%rax
   5eae3:	cmp    $0x1f,%rax
   5eae7:	ja     5eb0a <f.18+0x4da>
   5eae9:	mov    $0x20,%esi
   5eaee:	mov    %rbx,%rdi
   5eaf1:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5eaf6:	cmp    $0x1,%rax
   5eafa:	jne    5eb88 <f.18+0x558>
   5eb00:	mov    $0x1,%eax
   5eb05:	jmp    5eba0 <f.18+0x570>
   5eb0a:	lea    0x20(%rdx),%rax
   5eb0e:	mov    %rax,0xc8(%rbx)
   5eb15:	mov    0x10(%rbx),%rsi
   5eb19:	mov    0xc0(%rbx),%rdi
   5eb20:	cmp    %rsi,%rdi
   5eb23:	jae    5f1b2 <f.18+0xb82>
   5eb29:	mov    0x8(%rbx),%rax
   5eb2d:	imul   $0x38,%rdi,%rcx
   5eb31:	mov    %rdx,%r8
   5eb34:	sub    0x18(%rax,%rcx,1),%r8
   5eb39:	mov    %r8,%rdi
   5eb3c:	shr    $0xf,%rdi
   5eb40:	mov    0x10(%rax,%rcx,1),%rsi
   5eb45:	cmp    %rsi,%rdi
   5eb48:	jae    5f1be <f.18+0xb8e>
   5eb4e:	add    %rcx,%rax
   5eb51:	mov    %r8d,%ecx
   5eb54:	imul   $0x220,%rdi,%rsi
   5eb5b:	add    0x8(%rax),%rsi
   5eb5f:	shr    $0x4,%ecx
   5eb62:	mov    $0x1,%eax
   5eb67:	mov    $0x1,%edi
   5eb6c:	shl    %cl,%rdi
   5eb6f:	shr    $0x7,%r8d
   5eb73:	and    $0xf8,%r8d
   5eb7a:	or     %rdi,(%r8,%rsi,1)
   5eb7e:	cmp    $0x1,%rax
   5eb82:	je     5eb00 <f.18+0x4d0>
   5eb88:	xor    %edx,%edx
   5eb8a:	cmp    %rbp,%r12
   5eb8d:	setae  %dl
   5eb90:	mov    $0x20,%esi
   5eb95:	mov    %rbx,%rdi
   5eb98:	mov    %r14,%rcx
   5eb9b:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5eba0:	test   $0x1,%al
   5eba2:	je     5f1a1 <f.18+0xb71>
   5eba8:	movq   $0x41,(%rdx)
   5ebaf:	pxor   %xmm0,%xmm0
   5ebb3:	movdqu %xmm0,0x8(%rdx)
   5ebb8:	addq   $0x20,0xe0(%rbx)
   5ebc0:	lea    0x8(%rdx),%r12
   5ebc4:	movdqu 0x110(%rbx),%xmm0
   5ebcc:	paddq  -0x5a684(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5ebd4:	movdqu %xmm0,0x110(%rbx)
   5ebdc:	movq   $0x36,0x8(%rdx)
   5ebe4:	mov    %r13,0x10(%rdx)
   5ebe8:	mov    %r12,0x48(%rsp)
   5ebed:	mov    %r15,0x50(%rsp)
   5ebf2:	movq   $0x7,0x18(%rsp)
   5ebfb:	mov    0xbc16(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5ec02:	test   %rbx,%rbx
   5ec05:	je     5f19c <f.18+0xb6c>
   5ec0b:	mov    0x178(%rbx),%rcx
   5ec12:	test   %rcx,%rcx
   5ec15:	je     5ec51 <f.18+0x621>
   5ec17:	mov    0x170(%rbx),%rax
   5ec1e:	inc    %rax
   5ec21:	mov    %rax,0x170(%rbx)
   5ec28:	mov    %rax,%rdx
   5ec2b:	or     %rcx,%rdx
   5ec2e:	shr    $0x20,%rdx
   5ec32:	je     5ecd1 <f.18+0x6a1>
   5ec38:	xor    %edx,%edx
   5ec3a:	div    %rcx
   5ec3d:	test   %rdx,%rdx
   5ec40:	jne    5ec51 <f.18+0x621>
   5ec42:	mov    0xbbd7(%rip),%rsi        # 6a820 <native_roots.0>
   5ec49:	mov    %rbx,%rdi
   5ec4c:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ec51:	cmpq   $0x20,0x98(%rbx)
   5ec59:	jb     5f1a1 <f.18+0xb71>
   5ec5f:	mov    0xbbba(%rip),%r14        # 6a820 <native_roots.0>
   5ec66:	mov    0xe0(%rbx),%r13
   5ec6d:	mov    0xe8(%rbx),%rbp
   5ec74:	cmp    %rbp,%r13
   5ec77:	jb     5ec84 <f.18+0x654>
   5ec79:	mov    %rbx,%rdi
   5ec7c:	mov    %r14,%rsi
   5ec7f:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ec84:	mov    0xc8(%rbx),%rdx
   5ec8b:	test   %rdx,%rdx
   5ec8e:	je     5f030 <f.18+0xa00>
   5ec94:	mov    0xd0(%rbx),%rax
   5ec9b:	sub    %rdx,%rax
   5ec9e:	cmp    $0x1f,%rax
   5eca2:	jbe    5f030 <f.18+0xa00>
   5eca8:	jmp    5f051 <f.18+0xa21>
   5ecad:	xor    %edx,%edx
   5ecaf:	div    %ecx
   5ecb1:	test   %rdx,%rdx
   5ecb4:	jne    5e7e2 <f.18+0x1b2>
   5ecba:	jmp    5e7d3 <f.18+0x1a3>
   5ecbf:	xor    %edx,%edx
   5ecc1:	div    %ecx
   5ecc3:	test   %rdx,%rdx
   5ecc6:	jne    5ea9a <f.18+0x46a>
   5eccc:	jmp    5ea8b <f.18+0x45b>
   5ecd1:	xor    %edx,%edx
   5ecd3:	div    %ecx
   5ecd5:	test   %rdx,%rdx
   5ecd8:	jne    5ec51 <f.18+0x621>
   5ecde:	jmp    5ec42 <f.18+0x612>
   5ece3:	lea    0x20(%rdx),%rax
   5ece7:	mov    %rax,0xc8(%rbx)
   5ecee:	mov    0x10(%rbx),%rsi
   5ecf2:	mov    0xc0(%rbx),%rdi
   5ecf9:	cmp    %rsi,%rdi
   5ecfc:	jae    5f1b2 <f.18+0xb82>
   5ed02:	mov    0x8(%rbx),%rax
   5ed06:	imul   $0x38,%rdi,%rcx
   5ed0a:	mov    %rdx,%r8
   5ed0d:	sub    0x18(%rax,%rcx,1),%r8
   5ed12:	mov    %r8,%rdi
   5ed15:	shr    $0xf,%rdi
   5ed19:	mov    0x10(%rax,%rcx,1),%rsi
   5ed1e:	cmp    %rsi,%rdi
   5ed21:	jae    5f1be <f.18+0xb8e>
   5ed27:	add    %rcx,%rax
   5ed2a:	mov    %r8d,%ecx
   5ed2d:	imul   $0x220,%rdi,%rsi
   5ed34:	add    0x8(%rax),%rsi
   5ed38:	shr    $0x4,%ecx
   5ed3b:	mov    $0x1,%eax
   5ed40:	mov    $0x1,%edi
   5ed45:	shl    %cl,%rdi
   5ed48:	shr    $0x7,%r8d
   5ed4c:	and    $0xf8,%r8d
   5ed53:	or     %rdi,(%r8,%rsi,1)
   5ed57:	cmp    $0x1,%rax
   5ed5b:	je     5e944 <f.18+0x314>
   5ed61:	xor    %edx,%edx
   5ed63:	cmp    %r12,%r15
   5ed66:	setae  %dl
   5ed69:	mov    $0x20,%esi
   5ed6e:	mov    %rbx,%rdi
   5ed71:	mov    %r14,%rcx
   5ed74:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5ed79:	test   $0x1,%al
   5ed7b:	je     5f1a1 <f.18+0xb71>
   5ed81:	movq   $0x41,(%rdx)
   5ed88:	pxor   %xmm0,%xmm0
   5ed8c:	movdqu %xmm0,0x8(%rdx)
   5ed91:	addq   $0x20,0xe0(%rbx)
   5ed99:	lea    0x8(%rdx),%r15
   5ed9d:	movdqu 0x110(%rbx),%xmm0
   5eda5:	paddq  -0x5a85d(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5edad:	movdqu %xmm0,0x110(%rbx)
   5edb5:	movq   $0x36,0x8(%rdx)
   5edbd:	mov    %r13,0x10(%rdx)
   5edc1:	mov    %r13,0x48(%rsp)
   5edc6:	mov    %r15,0x50(%rsp)
   5edcb:	movq   $0x7,0x18(%rsp)
   5edd4:	mov    0xba3d(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5eddb:	test   %rbx,%rbx
   5edde:	je     5f19c <f.18+0xb6c>
   5ede4:	mov    0x178(%rbx),%rcx
   5edeb:	test   %rcx,%rcx
   5edee:	je     5ee2a <f.18+0x7fa>
   5edf0:	mov    0x170(%rbx),%rax
   5edf7:	inc    %rax
   5edfa:	mov    %rax,0x170(%rbx)
   5ee01:	mov    %rax,%rdx
   5ee04:	or     %rcx,%rdx
   5ee07:	shr    $0x20,%rdx
   5ee0b:	je     5f178 <f.18+0xb48>
   5ee11:	xor    %edx,%edx
   5ee13:	div    %rcx
   5ee16:	test   %rdx,%rdx
   5ee19:	jne    5ee2a <f.18+0x7fa>
   5ee1b:	mov    0xb9fe(%rip),%rsi        # 6a820 <native_roots.0>
   5ee22:	mov    %rbx,%rdi
   5ee25:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ee2a:	cmpq   $0x20,0x98(%rbx)
   5ee32:	jb     5f1a1 <f.18+0xb71>
   5ee38:	mov    0xb9e1(%rip),%r14        # 6a820 <native_roots.0>
   5ee3f:	mov    0xe0(%rbx),%r12
   5ee46:	mov    0xe8(%rbx),%rbp
   5ee4d:	cmp    %rbp,%r12
   5ee50:	jb     5ee5d <f.18+0x82d>
   5ee52:	mov    %rbx,%rdi
   5ee55:	mov    %r14,%rsi
   5ee58:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ee5d:	mov    0xc8(%rbx),%rdx
   5ee64:	test   %rdx,%rdx
   5ee67:	je     5ee79 <f.18+0x849>
   5ee69:	mov    0xd0(%rbx),%rax
   5ee70:	sub    %rdx,%rax
   5ee73:	cmp    $0x1f,%rax
   5ee77:	ja     5ee9a <f.18+0x86a>
   5ee79:	mov    $0x20,%esi
   5ee7e:	mov    %rbx,%rdi
   5ee81:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5ee86:	cmp    $0x1,%rax
   5ee8a:	jne    5ef18 <f.18+0x8e8>
   5ee90:	mov    $0x1,%eax
   5ee95:	jmp    5ef30 <f.18+0x900>
   5ee9a:	lea    0x20(%rdx),%rax
   5ee9e:	mov    %rax,0xc8(%rbx)
   5eea5:	mov    0x10(%rbx),%rsi
   5eea9:	mov    0xc0(%rbx),%rdi
   5eeb0:	cmp    %rsi,%rdi
   5eeb3:	jae    5f1b2 <f.18+0xb82>
   5eeb9:	mov    0x8(%rbx),%rax
   5eebd:	imul   $0x38,%rdi,%rcx
   5eec1:	mov    %rdx,%r8
   5eec4:	sub    0x18(%rax,%rcx,1),%r8
   5eec9:	mov    %r8,%rdi
   5eecc:	shr    $0xf,%rdi
   5eed0:	mov    0x10(%rax,%rcx,1),%rsi
   5eed5:	cmp    %rsi,%rdi
   5eed8:	jae    5f1be <f.18+0xb8e>
   5eede:	add    %rcx,%rax
   5eee1:	mov    %r8d,%ecx
   5eee4:	imul   $0x220,%rdi,%rsi
   5eeeb:	add    0x8(%rax),%rsi
   5eeef:	shr    $0x4,%ecx
   5eef2:	mov    $0x1,%eax
   5eef7:	mov    $0x1,%edi
   5eefc:	shl    %cl,%rdi
   5eeff:	shr    $0x7,%r8d
   5ef03:	and    $0xf8,%r8d
   5ef0a:	or     %rdi,(%r8,%rsi,1)
   5ef0e:	cmp    $0x1,%rax
   5ef12:	je     5ee90 <f.18+0x860>
   5ef18:	xor    %edx,%edx
   5ef1a:	cmp    %rbp,%r12
   5ef1d:	setae  %dl
   5ef20:	mov    $0x20,%esi
   5ef25:	mov    %rbx,%rdi
   5ef28:	mov    %r14,%rcx
   5ef2b:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5ef30:	test   $0x1,%al
   5ef32:	je     5f1a1 <f.18+0xb71>
   5ef38:	movq   $0x41,(%rdx)
   5ef3f:	pxor   %xmm0,%xmm0
   5ef43:	movdqu %xmm0,0x8(%rdx)
   5ef48:	addq   $0x20,0xe0(%rbx)
   5ef50:	lea    0x8(%rdx),%r12
   5ef54:	movdqu 0x110(%rbx),%xmm0
   5ef5c:	paddq  -0x5aa14(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5ef64:	movdqu %xmm0,0x110(%rbx)
   5ef6c:	movq   $0x36,0x8(%rdx)
   5ef74:	mov    %r13,0x10(%rdx)
   5ef78:	mov    %r12,0x48(%rsp)
   5ef7d:	mov    %r15,0x50(%rsp)
   5ef82:	movq   $0x7,0x18(%rsp)
   5ef8b:	mov    0xb886(%rip),%rbx        # 6a818 <snail_runtime::native::RUNTIME>
   5ef92:	test   %rbx,%rbx
   5ef95:	je     5f19c <f.18+0xb6c>
   5ef9b:	mov    0x178(%rbx),%rcx
   5efa2:	test   %rcx,%rcx
   5efa5:	je     5efe1 <f.18+0x9b1>
   5efa7:	mov    0x170(%rbx),%rax
   5efae:	inc    %rax
   5efb1:	mov    %rax,0x170(%rbx)
   5efb8:	mov    %rax,%rdx
   5efbb:	or     %rcx,%rdx
   5efbe:	shr    $0x20,%rdx
   5efc2:	je     5f18a <f.18+0xb5a>
   5efc8:	xor    %edx,%edx
   5efca:	div    %rcx
   5efcd:	test   %rdx,%rdx
   5efd0:	jne    5efe1 <f.18+0x9b1>
   5efd2:	mov    0xb847(%rip),%rsi        # 6a820 <native_roots.0>
   5efd9:	mov    %rbx,%rdi
   5efdc:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5efe1:	cmpq   $0x20,0x98(%rbx)
   5efe9:	jb     5f1a1 <f.18+0xb71>
   5efef:	mov    0xb82a(%rip),%r14        # 6a820 <native_roots.0>
   5eff6:	mov    0xe0(%rbx),%r13
   5effd:	mov    0xe8(%rbx),%rbp
   5f004:	cmp    %rbp,%r13
   5f007:	jb     5f014 <f.18+0x9e4>
   5f009:	mov    %rbx,%rdi
   5f00c:	mov    %r14,%rsi
   5f00f:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5f014:	mov    0xc8(%rbx),%rdx
   5f01b:	test   %rdx,%rdx
   5f01e:	je     5f030 <f.18+0xa00>
   5f020:	mov    0xd0(%rbx),%rax
   5f027:	sub    %rdx,%rax
   5f02a:	cmp    $0x1f,%rax
   5f02e:	ja     5f051 <f.18+0xa21>
   5f030:	mov    $0x20,%esi
   5f035:	mov    %rbx,%rdi
   5f038:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5f03d:	cmp    $0x1,%rax
   5f041:	jne    5f0cf <f.18+0xa9f>
   5f047:	mov    $0x1,%eax
   5f04c:	jmp    5f0e7 <f.18+0xab7>
   5f051:	lea    0x20(%rdx),%rax
   5f055:	mov    %rax,0xc8(%rbx)
   5f05c:	mov    0x10(%rbx),%rsi
   5f060:	mov    0xc0(%rbx),%rdi
   5f067:	cmp    %rsi,%rdi
   5f06a:	jae    5f1b2 <f.18+0xb82>
   5f070:	mov    0x8(%rbx),%rax
   5f074:	imul   $0x38,%rdi,%rcx
   5f078:	mov    %rdx,%r8
   5f07b:	sub    0x18(%rax,%rcx,1),%r8
   5f080:	mov    %r8,%rdi
   5f083:	shr    $0xf,%rdi
   5f087:	mov    0x10(%rax,%rcx,1),%rsi
   5f08c:	cmp    %rsi,%rdi
   5f08f:	jae    5f1be <f.18+0xb8e>
   5f095:	add    %rcx,%rax
   5f098:	mov    %r8d,%ecx
   5f09b:	imul   $0x220,%rdi,%rsi
   5f0a2:	add    0x8(%rax),%rsi
   5f0a6:	shr    $0x4,%ecx
   5f0a9:	mov    $0x1,%eax
   5f0ae:	mov    $0x1,%edi
   5f0b3:	shl    %cl,%rdi
   5f0b6:	shr    $0x7,%r8d
   5f0ba:	and    $0xf8,%r8d
   5f0c1:	or     %rdi,(%r8,%rsi,1)
   5f0c5:	cmp    $0x1,%rax
   5f0c9:	je     5f047 <f.18+0xa17>
   5f0cf:	xor    %edx,%edx
   5f0d1:	cmp    %rbp,%r13
   5f0d4:	setae  %dl
   5f0d7:	mov    $0x20,%esi
   5f0dc:	mov    %rbx,%rdi
   5f0df:	mov    %r14,%rcx
   5f0e2:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5f0e7:	test   $0x1,%al
   5f0e9:	je     5f1a1 <f.18+0xb71>
   5f0ef:	movq   $0x61,(%rdx)
   5f0f6:	lea    0x8(%rdx),%rax
   5f0fa:	pxor   %xmm0,%xmm0
   5f0fe:	movdqu %xmm0,0x8(%rdx)
   5f103:	movq   $0x0,0x18(%rdx)
   5f10b:	addq   $0x20,0xe0(%rbx)
   5f113:	movdqu 0x110(%rbx),%xmm0
   5f11b:	paddq  -0x5ac33(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5f123:	movdqu %xmm0,0x110(%rbx)
   5f12b:	movq   $0x46,(%rax)
   5f132:	mov    %r15,0x8(%rax)
   5f136:	mov    %r12,0x10(%rax)
   5f13a:	cmpq   $0x0,0x10(%rsp)
   5f140:	je     5f155 <f.18+0xb25>
   5f142:	mov    0x8(%rsp),%rcx
   5f147:	mov    %rcx,0xb6d2(%rip)        # 6a820 <native_roots.0>
   5f14e:	decq   0xb6ab(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5f155:	add    $0x58,%rsp
   5f159:	pop    %rbx
   5f15a:	pop    %r12
   5f15c:	pop    %r13
   5f15e:	pop    %r14
   5f160:	pop    %r15
   5f162:	pop    %rbp
   5f163:	ret    $0x8
   5f166:	xor    %edx,%edx
   5f168:	div    %ecx
   5f16a:	test   %rdx,%rdx
   5f16d:	jne    5e8e1 <f.18+0x2b1>
   5f173:	jmp    5e8cd <f.18+0x29d>
   5f178:	xor    %edx,%edx
   5f17a:	div    %ecx
   5f17c:	test   %rdx,%rdx
   5f17f:	jne    5ee2a <f.18+0x7fa>
   5f185:	jmp    5ee1b <f.18+0x7eb>
   5f18a:	xor    %edx,%edx
   5f18c:	div    %ecx
   5f18e:	test   %rdx,%rdx
   5f191:	jne    5efe1 <f.18+0x9b1>
   5f197:	jmp    5efd2 <f.18+0x9a2>
   5f19c:	call   56d70 <native_trap>
   5f1a1:	lea    -0x55d54(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5f1a8:	mov    $0x2f,%esi
   5f1ad:	call   57d70 <snail_runtime::native::fail_bytes>
   5f1b2:	lea    0x8407(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   5f1b9:	call   207b0 <core::panicking::panic_bounds_check>
   5f1be:	lea    0x8413(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   5f1c5:	call   207b0 <core::panicking::panic_bounds_check>
   5f1ca:	int3
   5f1cb:	int3
   5f1cc:	int3
   5f1cd:	int3
   5f1ce:	int3
   5f1cf:	int3
