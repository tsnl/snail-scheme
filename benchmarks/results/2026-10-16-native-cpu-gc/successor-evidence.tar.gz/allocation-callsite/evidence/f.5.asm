   5a230:	push   %rbp
   5a231:	push   %r15
   5a233:	push   %r14
   5a235:	push   %r13
   5a237:	push   %r12
   5a239:	push   %rbx
   5a23a:	sub    $0x78,%rsp
   5a23e:	mov    %rsi,%rbx
   5a241:	movq   $0x7,0x18(%rsp)
   5a24a:	movq   $0x0,0x20(%rsp)
   5a253:	mov    0x105c6(%rip),%rsi        # 6a820 <native_roots.0>
   5a25a:	mov    %rsi,0x10(%rsp)
   5a25f:	lea    0x10(%rsp),%rcx
   5a264:	mov    0x10595(%rip),%rdx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5a26b:	inc    %rdx
   5a26e:	mov    0x10593(%rip),%rax        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5a275:	cmp    %rax,%rdx
   5a278:	cmova  %rdx,%rax
   5a27c:	mov    %rcx,0x1059d(%rip)        # 6a820 <native_roots.0>
   5a283:	mov    %rdx,0x10576(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5a28a:	mov    %rax,0x10577(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5a291:	mov    %rdi,0x28(%rsp)
   5a296:	pxor   %xmm0,%xmm0
   5a29a:	movdqu %xmm0,0x30(%rsp)
   5a2a0:	movq   $0x0,0x40(%rsp)
   5a2a9:	test   %rdi,%rdi
   5a2ac:	je     5b8f6 <f.5+0x16c6>
   5a2b2:	mov    %edi,%eax
   5a2b4:	and    $0x1,%eax
   5a2b7:	jne    5b8f6 <f.5+0x16c6>
   5a2bd:	mov    0x10554(%rip),%rax        # 6a818 <snail_runtime::native::RUNTIME>
   5a2c4:	test   %rax,%rax
   5a2c7:	je     5b8f6 <f.5+0x16c6>
   5a2cd:	mov    (%rdi),%rcx
   5a2d0:	mov    %rcx,%r8
   5a2d3:	test   %rcx,%rcx
   5a2d6:	je     5a353 <f.5+0x123>
   5a2d8:	mov    %rcx,%r8
   5a2db:	cmp    $0x76,%rcx
   5a2df:	je     5a353 <f.5+0x123>
   5a2e1:	mov    0x168(%rax),%r9
   5a2e8:	mov    %rcx,%r8
   5a2eb:	shr    $0x2,%r8
   5a2ef:	lea    -0x1(%r8),%r10
   5a2f3:	cmp    %r9,%r10
   5a2f6:	jae    5b8f6 <f.5+0x16c6>
   5a2fc:	mov    0x160(%rax),%r10
   5a303:	mov    -0x8(%r10,%r8,8),%r8
   5a308:	test   %r8,%r8
   5a30b:	je     5a353 <f.5+0x123>
   5a30d:	cmp    $0x76,%r8
   5a311:	je     5a353 <f.5+0x123>
   5a313:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5a320:	shr    $0x2,%r8
   5a324:	lea    -0x1(%r8),%r11
   5a328:	cmp    %r9,%r11
   5a32b:	jae    5b8f6 <f.5+0x16c6>
   5a331:	mov    -0x8(%r10,%r8,8),%r8
   5a336:	cmp    $0x76,%r8
   5a33a:	je     5a353 <f.5+0x123>
   5a33c:	test   %r8,%r8
   5a33f:	jne    5a320 <f.5+0xf0>
   5a341:	jmp    5a353 <f.5+0x123>
   5a343:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5a350:	inc    %rbx
   5a353:	cmp    $0x76,%r8
   5a357:	jne    5b8f6 <f.5+0x16c6>
   5a35d:	cmp    %rbx,0x8(%rdi)
   5a361:	je     5b8d2 <f.5+0x16a2>
   5a367:	test   $0x1,%dil
   5a36b:	jne    5b8f6 <f.5+0x16c6>
   5a371:	test   %rcx,%rcx
   5a374:	je     5a3e0 <f.5+0x1b0>
   5a376:	cmp    $0x76,%rcx
   5a37a:	je     5a3e0 <f.5+0x1b0>
   5a37c:	mov    0x168(%rax),%rdx
   5a383:	shr    $0x2,%rcx
   5a387:	lea    -0x1(%rcx),%rsi
   5a38b:	cmp    %rdx,%rsi
   5a38e:	jae    5b8f6 <f.5+0x16c6>
   5a394:	mov    0x160(%rax),%rax
   5a39b:	mov    -0x8(%rax,%rcx,8),%rcx
   5a3a0:	test   %rcx,%rcx
   5a3a3:	je     5a3e0 <f.5+0x1b0>
   5a3a5:	cmp    $0x76,%rcx
   5a3a9:	je     5a3e0 <f.5+0x1b0>
   5a3ab:	nopl   0x0(%rax,%rax,1)
   5a3b0:	shr    $0x2,%rcx
   5a3b4:	lea    -0x1(%rcx),%rsi
   5a3b8:	cmp    %rdx,%rsi
   5a3bb:	jae    5b8f6 <f.5+0x16c6>
   5a3c1:	mov    -0x8(%rax,%rcx,8),%rcx
   5a3c6:	cmp    $0x76,%rcx
   5a3ca:	je     5a3e0 <f.5+0x1b0>
   5a3cc:	test   %rcx,%rcx
   5a3cf:	jne    5a3b0 <f.5+0x180>
   5a3d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5a3e0:	cmp    $0x76,%rcx
   5a3e4:	jne    5b8f6 <f.5+0x16c6>
   5a3ea:	cmpb   $0x0,0x105d7(%rip)        # 6a9c8 <g.29>
   5a3f1:	je     5b8f6 <f.5+0x16c6>
   5a3f7:	cmpb   $0x0,0x1058a(%rip)        # 6a988 <g.21>
   5a3fe:	je     5b8f6 <f.5+0x16c6>
   5a404:	cmpq   $0x0,0x10574(%rip)        # 6a980 <g.20>
   5a40c:	je     5b8f6 <f.5+0x16c6>
   5a412:	mov    0x105a7(%rip),%rax        # 6a9c0 <g.28>
   5a419:	movq   $0x4,0x20(%rsp)
   5a422:	mov    %rax,0x68(%rsp)
   5a427:	lea    0x68(%rsp),%rax
   5a42c:	cmpb   $0x0,0x10585(%rip)        # 6a9b8 <g.27>
   5a433:	je     5b8f6 <f.5+0x16c6>
   5a439:	cmpq   $0x0,0x1056f(%rip)        # 6a9b0 <g.26>
   5a441:	je     5b8f6 <f.5+0x16c6>
   5a447:	cmpb   $0x0,0x1050a(%rip)        # 6a958 <g.15>
   5a44e:	je     5b8f6 <f.5+0x16c6>
   5a454:	cmpq   $0x0,0x104f4(%rip)        # 6a950 <g.14>
   5a45c:	je     5b8f6 <f.5+0x16c6>
   5a462:	mov    0x68(%rsp),%rax
   5a467:	mov    %rax,0x60(%rsp)
   5a46c:	movq   $0x4,0x20(%rsp)
   5a475:	mov    0x1039c(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5a47c:	test   %r15,%r15
   5a47f:	je     5b8f6 <f.5+0x16c6>
   5a485:	mov    0x178(%r15),%rcx
   5a48c:	test   %rcx,%rcx
   5a48f:	je     5a4cb <f.5+0x29b>
   5a491:	mov    0x170(%r15),%rax
   5a498:	inc    %rax
   5a49b:	mov    %rax,0x170(%r15)
   5a4a2:	mov    %rax,%rdx
   5a4a5:	or     %rcx,%rdx
   5a4a8:	shr    $0x20,%rdx
   5a4ac:	je     5b7c0 <f.5+0x1590>
   5a4b2:	xor    %edx,%edx
   5a4b4:	div    %rcx
   5a4b7:	test   %rdx,%rdx
   5a4ba:	jne    5a4cb <f.5+0x29b>
   5a4bc:	mov    0x1035d(%rip),%rsi        # 6a820 <native_roots.0>
   5a4c3:	mov    %r15,%rdi
   5a4c6:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5a4cb:	mov    %rbx,0x70(%rsp)
   5a4d0:	cmpq   $0x20,0x98(%r15)
   5a4d8:	jb     5b8fb <f.5+0x16cb>
   5a4de:	mov    0x1033b(%rip),%r12        # 6a820 <native_roots.0>
   5a4e5:	mov    0xe0(%r15),%rbx
   5a4ec:	mov    0xe8(%r15),%r13
   5a4f3:	cmp    %r13,%rbx
   5a4f6:	jb     5a503 <f.5+0x2d3>
   5a4f8:	mov    %r15,%rdi
   5a4fb:	mov    %r12,%rsi
   5a4fe:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5a503:	mov    0xc8(%r15),%r14
   5a50a:	test   %r14,%r14
   5a50d:	je     5a51f <f.5+0x2ef>
   5a50f:	mov    0xd0(%r15),%rax
   5a516:	sub    %r14,%rax
   5a519:	cmp    $0x1f,%rax
   5a51d:	ja     5a550 <f.5+0x320>
   5a51f:	mov    $0x20,%esi
   5a524:	mov    %r15,%rdi
   5a527:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5a52c:	mov    %rdx,%r14
   5a52f:	cmp    $0x1,%rax
   5a533:	jne    5a5cb <f.5+0x39b>
   5a539:	mov    $0x1,%eax
   5a53e:	jmp    5a5e6 <f.5+0x3b6>
   5a543:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5a550:	lea    0x20(%r14),%rax
   5a554:	mov    %rax,0xc8(%r15)
   5a55b:	mov    0x10(%r15),%rsi
   5a55f:	mov    0xc0(%r15),%rdi
   5a566:	cmp    %rsi,%rdi
   5a569:	jae    5b918 <f.5+0x16e8>
   5a56f:	mov    0x8(%r15),%rax
   5a573:	imul   $0x38,%rdi,%rcx
   5a577:	mov    %r14,%rdx
   5a57a:	sub    0x18(%rax,%rcx,1),%rdx
   5a57f:	mov    %rdx,%rdi
   5a582:	shr    $0xf,%rdi
   5a586:	mov    0x10(%rax,%rcx,1),%rsi
   5a58b:	cmp    %rsi,%rdi
   5a58e:	jae    5b90c <f.5+0x16dc>
   5a594:	add    %rcx,%rax
   5a597:	mov    %edx,%ecx
   5a599:	imul   $0x220,%rdi,%rsi
   5a5a0:	add    0x8(%rax),%rsi
   5a5a4:	shr    $0x4,%ecx
   5a5a7:	mov    $0x1,%eax
   5a5ac:	mov    $0x1,%edi
   5a5b1:	shl    %cl,%rdi
   5a5b4:	shr    $0x7,%edx
   5a5b7:	and    $0xf8,%edx
   5a5bd:	or     %rdi,(%rdx,%rsi,1)
   5a5c1:	cmp    $0x1,%rax
   5a5c5:	je     5a539 <f.5+0x309>
   5a5cb:	xor    %edx,%edx
   5a5cd:	cmp    %r13,%rbx
   5a5d0:	setae  %dl
   5a5d3:	mov    $0x20,%esi
   5a5d8:	mov    %r15,%rdi
   5a5db:	mov    %r12,%rcx
   5a5de:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5a5e3:	mov    %rdx,%r14
   5a5e6:	test   $0x1,%al
   5a5e8:	je     5b8fb <f.5+0x16cb>
   5a5ee:	movq   $0x61,(%r14)
   5a5f5:	lea    0x8(%r14),%r13
   5a5f9:	pxor   %xmm0,%xmm0
   5a5fd:	movdqu %xmm0,0x8(%r14)
   5a603:	movq   $0x0,0x18(%r14)
   5a60b:	addq   $0x20,0xe0(%r15)
   5a613:	movdqu 0x110(%r15),%xmm0
   5a61c:	paddq  -0x56134(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5a624:	movdqu %xmm0,0x110(%r15)
   5a62d:	movq   $0x7a,0x8(%r14)
   5a635:	movl   $0x0,0x10(%r14)
   5a63d:	movq   $0x0,0x18(%r14)
   5a645:	mov    %r13,0x30(%rsp)
   5a64a:	mov    %r13,0x48(%rsp)
   5a64f:	lea    0xe092(%rip),%rax        # 686e8 <ref.19>
   5a656:	mov    %rax,0x50(%rsp)
   5a65b:	mov    %r13,0x58(%rsp)
   5a660:	movq   $0x7,0x20(%rsp)
   5a669:	mov    0x101a8(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5a670:	test   %r15,%r15
   5a673:	je     5b8f6 <f.5+0x16c6>
   5a679:	mov    0x178(%r15),%rcx
   5a680:	test   %rcx,%rcx
   5a683:	je     5a6bf <f.5+0x48f>
   5a685:	mov    0x170(%r15),%rax
   5a68c:	inc    %rax
   5a68f:	mov    %rax,0x170(%r15)
   5a696:	mov    %rax,%rdx
   5a699:	or     %rcx,%rdx
   5a69c:	shr    $0x20,%rdx
   5a6a0:	je     5b7e0 <f.5+0x15b0>
   5a6a6:	xor    %edx,%edx
   5a6a8:	div    %rcx
   5a6ab:	test   %rdx,%rdx
   5a6ae:	jne    5a6bf <f.5+0x48f>
   5a6b0:	mov    0x10169(%rip),%rsi        # 6a820 <native_roots.0>
   5a6b7:	mov    %r15,%rdi
   5a6ba:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5a6bf:	cmpq   $0x20,0x98(%r15)
   5a6c7:	jb     5b8fb <f.5+0x16cb>
   5a6cd:	mov    0x1014c(%rip),%r12        # 6a820 <native_roots.0>
   5a6d4:	mov    0xe0(%r15),%rbx
   5a6db:	mov    0xe8(%r15),%rbp
   5a6e2:	cmp    %rbp,%rbx
   5a6e5:	jb     5a6f2 <f.5+0x4c2>
   5a6e7:	mov    %r15,%rdi
   5a6ea:	mov    %r12,%rsi
   5a6ed:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5a6f2:	mov    0xc8(%r15),%rdx
   5a6f9:	test   %rdx,%rdx
   5a6fc:	je     5a70e <f.5+0x4de>
   5a6fe:	mov    0xd0(%r15),%rax
   5a705:	sub    %rdx,%rax
   5a708:	cmp    $0x1f,%rax
   5a70c:	ja     5a730 <f.5+0x500>
   5a70e:	mov    $0x20,%esi
   5a713:	mov    %r15,%rdi
   5a716:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5a71b:	cmp    $0x1,%rax
   5a71f:	jne    5a7ae <f.5+0x57e>
   5a725:	mov    $0x1,%eax
   5a72a:	jmp    5a7c6 <f.5+0x596>
   5a72f:	nop
   5a730:	lea    0x20(%rdx),%rax
   5a734:	mov    %rax,0xc8(%r15)
   5a73b:	mov    0x10(%r15),%rsi
   5a73f:	mov    0xc0(%r15),%rdi
   5a746:	cmp    %rsi,%rdi
   5a749:	jae    5b918 <f.5+0x16e8>
   5a74f:	mov    0x8(%r15),%rax
   5a753:	imul   $0x38,%rdi,%rcx
   5a757:	mov    %rdx,%r8
   5a75a:	sub    0x18(%rax,%rcx,1),%r8
   5a75f:	mov    %r8,%rdi
   5a762:	shr    $0xf,%rdi
   5a766:	mov    0x10(%rax,%rcx,1),%rsi
   5a76b:	cmp    %rsi,%rdi
   5a76e:	jae    5b90c <f.5+0x16dc>
   5a774:	add    %rcx,%rax
   5a777:	mov    %r8d,%ecx
   5a77a:	imul   $0x220,%rdi,%rsi
   5a781:	add    0x8(%rax),%rsi
   5a785:	shr    $0x4,%ecx
   5a788:	mov    $0x1,%eax
   5a78d:	mov    $0x1,%edi
   5a792:	shl    %cl,%rdi
   5a795:	shr    $0x7,%r8d
   5a799:	and    $0xf8,%r8d
   5a7a0:	or     %rdi,(%r8,%rsi,1)
   5a7a4:	cmp    $0x1,%rax
   5a7a8:	je     5a725 <f.5+0x4f5>
   5a7ae:	xor    %edx,%edx
   5a7b0:	cmp    %rbp,%rbx
   5a7b3:	setae  %dl
   5a7b6:	mov    $0x20,%esi
   5a7bb:	mov    %r15,%rdi
   5a7be:	mov    %r12,%rcx
   5a7c1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5a7c6:	test   $0x1,%al
   5a7c8:	je     5b8fb <f.5+0x16cb>
   5a7ce:	movq   $0x41,(%rdx)
   5a7d5:	pxor   %xmm0,%xmm0
   5a7d9:	movdqu %xmm0,0x8(%rdx)
   5a7de:	addq   $0x20,0xe0(%r15)
   5a7e6:	lea    0x8(%rdx),%rbx
   5a7ea:	movdqu 0x110(%r15),%xmm0
   5a7f3:	paddq  -0x562ab(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5a7fb:	movdqu %xmm0,0x110(%r15)
   5a804:	movq   $0x72,0x8(%rdx)
   5a80c:	mov    %r13,0x10(%rdx)
   5a810:	mov    %rbx,0x48(%rsp)
   5a815:	lea    0xdecc(%rip),%rax        # 686e8 <ref.19>
   5a81c:	mov    %rax,0x50(%rsp)
   5a821:	mov    %r13,0x58(%rsp)
   5a826:	movq   $0x7,0x20(%rsp)
   5a82f:	mov    0xffe2(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5a836:	test   %r15,%r15
   5a839:	je     5b8f6 <f.5+0x16c6>
   5a83f:	mov    0x178(%r15),%rcx
   5a846:	test   %rcx,%rcx
   5a849:	je     5a885 <f.5+0x655>
   5a84b:	mov    0x170(%r15),%rax
   5a852:	inc    %rax
   5a855:	mov    %rax,0x170(%r15)
   5a85c:	mov    %rax,%rdx
   5a85f:	or     %rcx,%rdx
   5a862:	shr    $0x20,%rdx
   5a866:	je     5b800 <f.5+0x15d0>
   5a86c:	xor    %edx,%edx
   5a86e:	div    %rcx
   5a871:	test   %rdx,%rdx
   5a874:	jne    5a885 <f.5+0x655>
   5a876:	mov    0xffa3(%rip),%rsi        # 6a820 <native_roots.0>
   5a87d:	mov    %r15,%rdi
   5a880:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5a885:	cmpq   $0x20,0x98(%r15)
   5a88d:	jb     5b8fb <f.5+0x16cb>
   5a893:	mov    0xff86(%rip),%r12        # 6a820 <native_roots.0>
   5a89a:	mov    0xe0(%r15),%r13
   5a8a1:	mov    0xe8(%r15),%rbp
   5a8a8:	cmp    %rbp,%r13
   5a8ab:	jb     5a8b8 <f.5+0x688>
   5a8ad:	mov    %r15,%rdi
   5a8b0:	mov    %r12,%rsi
   5a8b3:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5a8b8:	mov    0xc8(%r15),%rdx
   5a8bf:	test   %rdx,%rdx
   5a8c2:	je     5a8d4 <f.5+0x6a4>
   5a8c4:	mov    0xd0(%r15),%rax
   5a8cb:	sub    %rdx,%rax
   5a8ce:	cmp    $0x1f,%rax
   5a8d2:	ja     5a900 <f.5+0x6d0>
   5a8d4:	mov    $0x20,%esi
   5a8d9:	mov    %r15,%rdi
   5a8dc:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5a8e1:	cmp    $0x1,%rax
   5a8e5:	jne    5a97e <f.5+0x74e>
   5a8eb:	mov    $0x1,%eax
   5a8f0:	jmp    5a996 <f.5+0x766>
   5a8f5:	data16 cs nopw 0x0(%rax,%rax,1)
   5a900:	lea    0x20(%rdx),%rax
   5a904:	mov    %rax,0xc8(%r15)
   5a90b:	mov    0x10(%r15),%rsi
   5a90f:	mov    0xc0(%r15),%rdi
   5a916:	cmp    %rsi,%rdi
   5a919:	jae    5b918 <f.5+0x16e8>
   5a91f:	mov    0x8(%r15),%rax
   5a923:	imul   $0x38,%rdi,%rcx
   5a927:	mov    %rdx,%r8
   5a92a:	sub    0x18(%rax,%rcx,1),%r8
   5a92f:	mov    %r8,%rdi
   5a932:	shr    $0xf,%rdi
   5a936:	mov    0x10(%rax,%rcx,1),%rsi
   5a93b:	cmp    %rsi,%rdi
   5a93e:	jae    5b90c <f.5+0x16dc>
   5a944:	add    %rcx,%rax
   5a947:	mov    %r8d,%ecx
   5a94a:	imul   $0x220,%rdi,%rsi
   5a951:	add    0x8(%rax),%rsi
   5a955:	shr    $0x4,%ecx
   5a958:	mov    $0x1,%eax
   5a95d:	mov    $0x1,%edi
   5a962:	shl    %cl,%rdi
   5a965:	shr    $0x7,%r8d
   5a969:	and    $0xf8,%r8d
   5a970:	or     %rdi,(%r8,%rsi,1)
   5a974:	cmp    $0x1,%rax
   5a978:	je     5a8eb <f.5+0x6bb>
   5a97e:	xor    %edx,%edx
   5a980:	cmp    %rbp,%r13
   5a983:	setae  %dl
   5a986:	mov    $0x20,%esi
   5a98b:	mov    %r15,%rdi
   5a98e:	mov    %r12,%rcx
   5a991:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5a996:	test   $0x1,%al
   5a998:	je     5b8fb <f.5+0x16cb>
   5a99e:	movq   $0x61,(%rdx)
   5a9a5:	lea    0x8(%rdx),%rax
   5a9a9:	pxor   %xmm0,%xmm0
   5a9ad:	movdqu %xmm0,0x8(%rdx)
   5a9b2:	movq   $0x0,0x18(%rdx)
   5a9ba:	addq   $0x20,0xe0(%r15)
   5a9c2:	movdqu 0x110(%r15),%xmm0
   5a9cb:	paddq  -0x564e3(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5a9d3:	movdqu %xmm0,0x110(%r15)
   5a9dc:	movq   $0x92,0x8(%rdx)
   5a9e4:	lea    0xdcfd(%rip),%rcx        # 686e8 <ref.19>
   5a9eb:	mov    %rcx,0x10(%rdx)
   5a9ef:	mov    %rbx,0x18(%rdx)
   5a9f3:	mov    %rax,0x18(%r14)
   5a9f7:	mov    0x30(%rsp),%rax
   5a9fc:	test   %rax,%rax
   5a9ff:	je     5b8f6 <f.5+0x16c6>
   5aa05:	movl   $0x1,0x8(%rax)
   5aa0c:	mov    0x30(%rsp),%rax
   5aa11:	test   %rax,%rax
   5aa14:	je     5b8f6 <f.5+0x16c6>
   5aa1a:	cmpl   $0x0,0x8(%rax)
   5aa1e:	je     5b8f6 <f.5+0x16c6>
   5aa24:	mov    0x10(%rax),%rax
   5aa28:	test   %rax,%rax
   5aa2b:	je     5b8f6 <f.5+0x16c6>
   5aa31:	mov    %rax,0x38(%rsp)
   5aa36:	mov    0x8(%rax),%rcx
   5aa3a:	test   %rcx,%rcx
   5aa3d:	je     5b8f6 <f.5+0x16c6>
   5aa43:	mov    0x60(%rsp),%rdx
   5aa48:	lea    -0x1(%rdx),%rsi
   5aa4c:	mov    0x10(%rax),%rdi
   5aa50:	mov    0x8(%rcx),%rax
   5aa54:	mov    %rdi,0x48(%rsp)
   5aa59:	movq   $0x5,0x20(%rsp)
   5aa62:	mov    $0x1,%edx
   5aa67:	call   *%rax
   5aa69:	sub    $0x8,%rsp
   5aa6d:	movq   $0x4,0x20(%rsp)
   5aa76:	mov    0xfd9b(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5aa7d:	test   %r15,%r15
   5aa80:	je     5b8f6 <f.5+0x16c6>
   5aa86:	mov    %rax,%r14
   5aa89:	mov    0x178(%r15),%rcx
   5aa90:	test   %rcx,%rcx
   5aa93:	je     5aacf <f.5+0x89f>
   5aa95:	mov    0x170(%r15),%rax
   5aa9c:	inc    %rax
   5aa9f:	mov    %rax,0x170(%r15)
   5aaa6:	mov    %rax,%rdx
   5aaa9:	or     %rcx,%rdx
   5aaac:	shr    $0x20,%rdx
   5aab0:	je     5b820 <f.5+0x15f0>
   5aab6:	xor    %edx,%edx
   5aab8:	div    %rcx
   5aabb:	test   %rdx,%rdx
   5aabe:	jne    5aacf <f.5+0x89f>
   5aac0:	mov    0xfd59(%rip),%rsi        # 6a820 <native_roots.0>
   5aac7:	mov    %r15,%rdi
   5aaca:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5aacf:	cmpq   $0x20,0x98(%r15)
   5aad7:	jb     5b8fb <f.5+0x16cb>
   5aadd:	mov    0xfd3c(%rip),%r12        # 6a820 <native_roots.0>
   5aae4:	mov    0xe0(%r15),%rbx
   5aaeb:	mov    0xe8(%r15),%r13
   5aaf2:	cmp    %r13,%rbx
   5aaf5:	jb     5ab02 <f.5+0x8d2>
   5aaf7:	mov    %r15,%rdi
   5aafa:	mov    %r12,%rsi
   5aafd:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ab02:	mov    0xc8(%r15),%rdx
   5ab09:	test   %rdx,%rdx
   5ab0c:	je     5ab1e <f.5+0x8ee>
   5ab0e:	mov    0xd0(%r15),%rax
   5ab15:	sub    %rdx,%rax
   5ab18:	cmp    $0x1f,%rax
   5ab1c:	ja     5ab40 <f.5+0x910>
   5ab1e:	mov    $0x20,%esi
   5ab23:	mov    %r15,%rdi
   5ab26:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5ab2b:	cmp    $0x1,%rax
   5ab2f:	jne    5abbe <f.5+0x98e>
   5ab35:	mov    $0x1,%eax
   5ab3a:	jmp    5abd6 <f.5+0x9a6>
   5ab3f:	nop
   5ab40:	lea    0x20(%rdx),%rax
   5ab44:	mov    %rax,0xc8(%r15)
   5ab4b:	mov    0x10(%r15),%rsi
   5ab4f:	mov    0xc0(%r15),%rdi
   5ab56:	cmp    %rsi,%rdi
   5ab59:	jae    5b918 <f.5+0x16e8>
   5ab5f:	mov    0x8(%r15),%rax
   5ab63:	imul   $0x38,%rdi,%rcx
   5ab67:	mov    %rdx,%r8
   5ab6a:	sub    0x18(%rax,%rcx,1),%r8
   5ab6f:	mov    %r8,%rdi
   5ab72:	shr    $0xf,%rdi
   5ab76:	mov    0x10(%rax,%rcx,1),%rsi
   5ab7b:	cmp    %rsi,%rdi
   5ab7e:	jae    5b90c <f.5+0x16dc>
   5ab84:	add    %rcx,%rax
   5ab87:	mov    %r8d,%ecx
   5ab8a:	imul   $0x220,%rdi,%rsi
   5ab91:	add    0x8(%rax),%rsi
   5ab95:	shr    $0x4,%ecx
   5ab98:	mov    $0x1,%eax
   5ab9d:	mov    $0x1,%edi
   5aba2:	shl    %cl,%rdi
   5aba5:	shr    $0x7,%r8d
   5aba9:	and    $0xf8,%r8d
   5abb0:	or     %rdi,(%r8,%rsi,1)
   5abb4:	cmp    $0x1,%rax
   5abb8:	je     5ab35 <f.5+0x905>
   5abbe:	xor    %edx,%edx
   5abc0:	cmp    %r13,%rbx
   5abc3:	setae  %dl
   5abc6:	mov    $0x20,%esi
   5abcb:	mov    %r15,%rdi
   5abce:	mov    %r12,%rcx
   5abd1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5abd6:	test   $0x1,%al
   5abd8:	je     5b8fb <f.5+0x16cb>
   5abde:	movq   $0x41,(%rdx)
   5abe5:	lea    0x8(%rdx),%r13
   5abe9:	pxor   %xmm0,%xmm0
   5abed:	movdqu %xmm0,0x8(%rdx)
   5abf2:	addq   $0x20,0xe0(%r15)
   5abfa:	movdqu 0x110(%r15),%xmm0
   5ac03:	paddq  -0x566bb(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5ac0b:	movdqu %xmm0,0x110(%r15)
   5ac14:	movq   $0x96,0x8(%rdx)
   5ac1c:	movq   $0x0,0x10(%rdx)
   5ac24:	mov    %r13,0x48(%rsp)
   5ac29:	movq   $0x5,0x20(%rsp)
   5ac32:	mov    0xfbdf(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5ac39:	test   %r15,%r15
   5ac3c:	je     5b8f6 <f.5+0x16c6>
   5ac42:	mov    0x178(%r15),%rcx
   5ac49:	test   %rcx,%rcx
   5ac4c:	je     5ac88 <f.5+0xa58>
   5ac4e:	mov    0x170(%r15),%rax
   5ac55:	inc    %rax
   5ac58:	mov    %rax,0x170(%r15)
   5ac5f:	mov    %rax,%rdx
   5ac62:	or     %rcx,%rdx
   5ac65:	shr    $0x20,%rdx
   5ac69:	je     5b840 <f.5+0x1610>
   5ac6f:	xor    %edx,%edx
   5ac71:	div    %rcx
   5ac74:	test   %rdx,%rdx
   5ac77:	jne    5ac88 <f.5+0xa58>
   5ac79:	mov    0xfba0(%rip),%rsi        # 6a820 <native_roots.0>
   5ac80:	mov    %r15,%rdi
   5ac83:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ac88:	cmpq   $0x20,0x98(%r15)
   5ac90:	jb     5b8fb <f.5+0x16cb>
   5ac96:	mov    0xfb83(%rip),%r12        # 6a820 <native_roots.0>
   5ac9d:	mov    0xe0(%r15),%rbx
   5aca4:	mov    0xe8(%r15),%rbp
   5acab:	cmp    %rbp,%rbx
   5acae:	jb     5acbb <f.5+0xa8b>
   5acb0:	mov    %r15,%rdi
   5acb3:	mov    %r12,%rsi
   5acb6:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5acbb:	mov    0xc8(%r15),%rdx
   5acc2:	test   %rdx,%rdx
   5acc5:	je     5acd7 <f.5+0xaa7>
   5acc7:	mov    0xd0(%r15),%rax
   5acce:	sub    %rdx,%rax
   5acd1:	cmp    $0x1f,%rax
   5acd5:	ja     5ad00 <f.5+0xad0>
   5acd7:	mov    $0x20,%esi
   5acdc:	mov    %r15,%rdi
   5acdf:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5ace4:	cmp    $0x1,%rax
   5ace8:	jne    5ad7e <f.5+0xb4e>
   5acee:	mov    $0x1,%eax
   5acf3:	jmp    5ad96 <f.5+0xb66>
   5acf8:	nopl   0x0(%rax,%rax,1)
   5ad00:	lea    0x20(%rdx),%rax
   5ad04:	mov    %rax,0xc8(%r15)
   5ad0b:	mov    0x10(%r15),%rsi
   5ad0f:	mov    0xc0(%r15),%rdi
   5ad16:	cmp    %rsi,%rdi
   5ad19:	jae    5b918 <f.5+0x16e8>
   5ad1f:	mov    0x8(%r15),%rax
   5ad23:	imul   $0x38,%rdi,%rcx
   5ad27:	mov    %rdx,%r8
   5ad2a:	sub    0x18(%rax,%rcx,1),%r8
   5ad2f:	mov    %r8,%rdi
   5ad32:	shr    $0xf,%rdi
   5ad36:	mov    0x10(%rax,%rcx,1),%rsi
   5ad3b:	cmp    %rsi,%rdi
   5ad3e:	jae    5b90c <f.5+0x16dc>
   5ad44:	add    %rcx,%rax
   5ad47:	mov    %r8d,%ecx
   5ad4a:	imul   $0x220,%rdi,%rsi
   5ad51:	add    0x8(%rax),%rsi
   5ad55:	shr    $0x4,%ecx
   5ad58:	mov    $0x1,%eax
   5ad5d:	mov    $0x1,%edi
   5ad62:	shl    %cl,%rdi
   5ad65:	shr    $0x7,%r8d
   5ad69:	and    $0xf8,%r8d
   5ad70:	or     %rdi,(%r8,%rsi,1)
   5ad74:	cmp    $0x1,%rax
   5ad78:	je     5acee <f.5+0xabe>
   5ad7e:	xor    %edx,%edx
   5ad80:	cmp    %rbp,%rbx
   5ad83:	setae  %dl
   5ad86:	mov    $0x20,%esi
   5ad8b:	mov    %r15,%rdi
   5ad8e:	mov    %r12,%rcx
   5ad91:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5ad96:	test   $0x1,%al
   5ad98:	je     5b8fb <f.5+0x16cb>
   5ad9e:	movq   $0x41,(%rdx)
   5ada5:	lea    0x8(%rdx),%rbx
   5ada9:	pxor   %xmm0,%xmm0
   5adad:	movdqu %xmm0,0x8(%rdx)
   5adb2:	addq   $0x20,0xe0(%r15)
   5adba:	movdqu 0x110(%r15),%xmm0
   5adc3:	paddq  -0x5687b(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5adcb:	movdqu %xmm0,0x110(%r15)
   5add4:	movq   $0x6a,0x8(%rdx)
   5addc:	mov    %r13,0x10(%rdx)
   5ade0:	mov    %rbx,0x48(%rsp)
   5ade5:	movq   $0x5,0x20(%rsp)
   5adee:	mov    0xfa23(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5adf5:	test   %r15,%r15
   5adf8:	je     5b8f6 <f.5+0x16c6>
   5adfe:	mov    0x178(%r15),%rcx
   5ae05:	test   %rcx,%rcx
   5ae08:	je     5ae44 <f.5+0xc14>
   5ae0a:	mov    0x170(%r15),%rax
   5ae11:	inc    %rax
   5ae14:	mov    %rax,0x170(%r15)
   5ae1b:	mov    %rax,%rdx
   5ae1e:	or     %rcx,%rdx
   5ae21:	shr    $0x20,%rdx
   5ae25:	je     5b860 <f.5+0x1630>
   5ae2b:	xor    %edx,%edx
   5ae2d:	div    %rcx
   5ae30:	test   %rdx,%rdx
   5ae33:	jne    5ae44 <f.5+0xc14>
   5ae35:	mov    0xf9e4(%rip),%rsi        # 6a820 <native_roots.0>
   5ae3c:	mov    %r15,%rdi
   5ae3f:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ae44:	cmpq   $0x20,0x98(%r15)
   5ae4c:	jb     5b8fb <f.5+0x16cb>
   5ae52:	mov    0xf9c7(%rip),%r12        # 6a820 <native_roots.0>
   5ae59:	mov    0xe0(%r15),%r13
   5ae60:	mov    0xe8(%r15),%rbp
   5ae67:	cmp    %rbp,%r13
   5ae6a:	jb     5ae77 <f.5+0xc47>
   5ae6c:	mov    %r15,%rdi
   5ae6f:	mov    %r12,%rsi
   5ae72:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5ae77:	mov    0xc8(%r15),%rdx
   5ae7e:	test   %rdx,%rdx
   5ae81:	je     5ae93 <f.5+0xc63>
   5ae83:	mov    0xd0(%r15),%rax
   5ae8a:	sub    %rdx,%rax
   5ae8d:	cmp    $0x1f,%rax
   5ae91:	ja     5aec0 <f.5+0xc90>
   5ae93:	mov    $0x20,%esi
   5ae98:	mov    %r15,%rdi
   5ae9b:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5aea0:	cmp    $0x1,%rax
   5aea4:	jne    5af3e <f.5+0xd0e>
   5aeaa:	mov    $0x1,%eax
   5aeaf:	jmp    5af56 <f.5+0xd26>
   5aeb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   5aec0:	lea    0x20(%rdx),%rax
   5aec4:	mov    %rax,0xc8(%r15)
   5aecb:	mov    0x10(%r15),%rsi
   5aecf:	mov    0xc0(%r15),%rdi
   5aed6:	cmp    %rsi,%rdi
   5aed9:	jae    5b918 <f.5+0x16e8>
   5aedf:	mov    0x8(%r15),%rax
   5aee3:	imul   $0x38,%rdi,%rcx
   5aee7:	mov    %rdx,%r8
   5aeea:	sub    0x18(%rax,%rcx,1),%r8
   5aeef:	mov    %r8,%rdi
   5aef2:	shr    $0xf,%rdi
   5aef6:	mov    0x10(%rax,%rcx,1),%rsi
   5aefb:	cmp    %rsi,%rdi
   5aefe:	jae    5b90c <f.5+0x16dc>
   5af04:	add    %rcx,%rax
   5af07:	mov    %r8d,%ecx
   5af0a:	imul   $0x220,%rdi,%rsi
   5af11:	add    0x8(%rax),%rsi
   5af15:	shr    $0x4,%ecx
   5af18:	mov    $0x1,%eax
   5af1d:	mov    $0x1,%edi
   5af22:	shl    %cl,%rdi
   5af25:	shr    $0x7,%r8d
   5af29:	and    $0xf8,%r8d
   5af30:	or     %rdi,(%r8,%rsi,1)
   5af34:	cmp    $0x1,%rax
   5af38:	je     5aeaa <f.5+0xc7a>
   5af3e:	xor    %edx,%edx
   5af40:	cmp    %rbp,%r13
   5af43:	setae  %dl
   5af46:	mov    $0x20,%esi
   5af4b:	mov    %r15,%rdi
   5af4e:	mov    %r12,%rcx
   5af51:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5af56:	test   $0x1,%al
   5af58:	je     5b8fb <f.5+0x16cb>
   5af5e:	movq   $0x61,(%rdx)
   5af65:	pxor   %xmm0,%xmm0
   5af69:	movdqu %xmm0,0x8(%rdx)
   5af6e:	movq   $0x0,0x18(%rdx)
   5af76:	addq   $0x20,0xe0(%r15)
   5af7e:	lea    0x8(%rdx),%r13
   5af82:	movdqu 0x110(%r15),%xmm0
   5af8b:	paddq  -0x56aa3(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5af93:	movdqu %xmm0,0x110(%r15)
   5af9c:	movq   $0x66,0x8(%rdx)
   5afa4:	mov    0x60(%rsp),%rax
   5afa9:	mov    %rax,0x10(%rdx)
   5afad:	mov    %rbx,0x18(%rdx)
   5afb1:	mov    %r13,0x48(%rsp)
   5afb6:	movq   $0x5,0x20(%rsp)
   5afbf:	mov    0xf852(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5afc6:	test   %r15,%r15
   5afc9:	je     5b8f6 <f.5+0x16c6>
   5afcf:	mov    0x178(%r15),%rcx
   5afd6:	test   %rcx,%rcx
   5afd9:	je     5b015 <f.5+0xde5>
   5afdb:	mov    0x170(%r15),%rax
   5afe2:	inc    %rax
   5afe5:	mov    %rax,0x170(%r15)
   5afec:	mov    %rax,%rdx
   5afef:	or     %rcx,%rdx
   5aff2:	shr    $0x20,%rdx
   5aff6:	je     5b880 <f.5+0x1650>
   5affc:	xor    %edx,%edx
   5affe:	div    %rcx
   5b001:	test   %rdx,%rdx
   5b004:	jne    5b015 <f.5+0xde5>
   5b006:	mov    0xf813(%rip),%rsi        # 6a820 <native_roots.0>
   5b00d:	mov    %r15,%rdi
   5b010:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5b015:	cmpq   $0x20,0x98(%r15)
   5b01d:	jb     5b8fb <f.5+0x16cb>
   5b023:	mov    0xf7f6(%rip),%r12        # 6a820 <native_roots.0>
   5b02a:	mov    0xe0(%r15),%rbx
   5b031:	mov    0xe8(%r15),%rbp
   5b038:	cmp    %rbp,%rbx
   5b03b:	jb     5b048 <f.5+0xe18>
   5b03d:	mov    %r15,%rdi
   5b040:	mov    %r12,%rsi
   5b043:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5b048:	mov    0xc8(%r15),%rdx
   5b04f:	test   %rdx,%rdx
   5b052:	je     5b064 <f.5+0xe34>
   5b054:	mov    0xd0(%r15),%rax
   5b05b:	sub    %rdx,%rax
   5b05e:	cmp    $0x1f,%rax
   5b062:	ja     5b090 <f.5+0xe60>
   5b064:	mov    $0x20,%esi
   5b069:	mov    %r15,%rdi
   5b06c:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5b071:	cmp    $0x1,%rax
   5b075:	jne    5b10e <f.5+0xede>
   5b07b:	mov    $0x1,%eax
   5b080:	jmp    5b126 <f.5+0xef6>
   5b085:	data16 cs nopw 0x0(%rax,%rax,1)
   5b090:	lea    0x20(%rdx),%rax
   5b094:	mov    %rax,0xc8(%r15)
   5b09b:	mov    0x10(%r15),%rsi
   5b09f:	mov    0xc0(%r15),%rdi
   5b0a6:	cmp    %rsi,%rdi
   5b0a9:	jae    5b918 <f.5+0x16e8>
   5b0af:	mov    0x8(%r15),%rax
   5b0b3:	imul   $0x38,%rdi,%rcx
   5b0b7:	mov    %rdx,%r8
   5b0ba:	sub    0x18(%rax,%rcx,1),%r8
   5b0bf:	mov    %r8,%rdi
   5b0c2:	shr    $0xf,%rdi
   5b0c6:	mov    0x10(%rax,%rcx,1),%rsi
   5b0cb:	cmp    %rsi,%rdi
   5b0ce:	jae    5b90c <f.5+0x16dc>
   5b0d4:	add    %rcx,%rax
   5b0d7:	mov    %r8d,%ecx
   5b0da:	imul   $0x220,%rdi,%rsi
   5b0e1:	add    0x8(%rax),%rsi
   5b0e5:	shr    $0x4,%ecx
   5b0e8:	mov    $0x1,%eax
   5b0ed:	mov    $0x1,%edi
   5b0f2:	shl    %cl,%rdi
   5b0f5:	shr    $0x7,%r8d
   5b0f9:	and    $0xf8,%r8d
   5b100:	or     %rdi,(%r8,%rsi,1)
   5b104:	cmp    $0x1,%rax
   5b108:	je     5b07b <f.5+0xe4b>
   5b10e:	xor    %edx,%edx
   5b110:	cmp    %rbp,%rbx
   5b113:	setae  %dl
   5b116:	mov    $0x20,%esi
   5b11b:	mov    %r15,%rdi
   5b11e:	mov    %r12,%rcx
   5b121:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5b126:	test   $0x1,%al
   5b128:	je     5b8fb <f.5+0x16cb>
   5b12e:	movq   $0x41,(%rdx)
   5b135:	lea    0x8(%rdx),%rbx
   5b139:	pxor   %xmm0,%xmm0
   5b13d:	movdqu %xmm0,0x8(%rdx)
   5b142:	addq   $0x20,0xe0(%r15)
   5b14a:	movdqu 0x110(%r15),%xmm0
   5b153:	paddq  -0x56c0b(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5b15b:	movdqu %xmm0,0x110(%r15)
   5b164:	movq   $0x96,0x8(%rdx)
   5b16c:	mov    %r13,0x10(%rdx)
   5b170:	mov    %rbx,0x48(%rsp)
   5b175:	movq   $0x5,0x20(%rsp)
   5b17e:	mov    0xf693(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5b185:	test   %r15,%r15
   5b188:	je     5b8f6 <f.5+0x16c6>
   5b18e:	mov    0x178(%r15),%rcx
   5b195:	test   %rcx,%rcx
   5b198:	je     5b1d4 <f.5+0xfa4>
   5b19a:	mov    0x170(%r15),%rax
   5b1a1:	inc    %rax
   5b1a4:	mov    %rax,0x170(%r15)
   5b1ab:	mov    %rax,%rdx
   5b1ae:	or     %rcx,%rdx
   5b1b1:	shr    $0x20,%rdx
   5b1b5:	je     5b8a0 <f.5+0x1670>
   5b1bb:	xor    %edx,%edx
   5b1bd:	div    %rcx
   5b1c0:	test   %rdx,%rdx
   5b1c3:	jne    5b1d4 <f.5+0xfa4>
   5b1c5:	mov    0xf654(%rip),%rsi        # 6a820 <native_roots.0>
   5b1cc:	mov    %r15,%rdi
   5b1cf:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5b1d4:	cmpq   $0x20,0x98(%r15)
   5b1dc:	jb     5b8fb <f.5+0x16cb>
   5b1e2:	mov    0xf637(%rip),%r12        # 6a820 <native_roots.0>
   5b1e9:	mov    0xe0(%r15),%r13
   5b1f0:	mov    0xe8(%r15),%rbp
   5b1f7:	cmp    %rbp,%r13
   5b1fa:	jb     5b207 <f.5+0xfd7>
   5b1fc:	mov    %r15,%rdi
   5b1ff:	mov    %r12,%rsi
   5b202:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5b207:	mov    0xc8(%r15),%rdx
   5b20e:	test   %rdx,%rdx
   5b211:	je     5b223 <f.5+0xff3>
   5b213:	mov    0xd0(%r15),%rax
   5b21a:	sub    %rdx,%rax
   5b21d:	cmp    $0x1f,%rax
   5b221:	ja     5b250 <f.5+0x1020>
   5b223:	mov    $0x20,%esi
   5b228:	mov    %r15,%rdi
   5b22b:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5b230:	cmp    $0x1,%rax
   5b234:	jne    5b2ce <f.5+0x109e>
   5b23a:	mov    $0x1,%eax
   5b23f:	jmp    5b2e6 <f.5+0x10b6>
   5b244:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b250:	lea    0x20(%rdx),%rax
   5b254:	mov    %rax,0xc8(%r15)
   5b25b:	mov    0x10(%r15),%rsi
   5b25f:	mov    0xc0(%r15),%rdi
   5b266:	cmp    %rsi,%rdi
   5b269:	jae    5b918 <f.5+0x16e8>
   5b26f:	mov    0x8(%r15),%rax
   5b273:	imul   $0x38,%rdi,%rcx
   5b277:	mov    %rdx,%r8
   5b27a:	sub    0x18(%rax,%rcx,1),%r8
   5b27f:	mov    %r8,%rdi
   5b282:	shr    $0xf,%rdi
   5b286:	mov    0x10(%rax,%rcx,1),%rsi
   5b28b:	cmp    %rsi,%rdi
   5b28e:	jae    5b90c <f.5+0x16dc>
   5b294:	add    %rcx,%rax
   5b297:	mov    %r8d,%ecx
   5b29a:	imul   $0x220,%rdi,%rsi
   5b2a1:	add    0x8(%rax),%rsi
   5b2a5:	shr    $0x4,%ecx
   5b2a8:	mov    $0x1,%eax
   5b2ad:	mov    $0x1,%edi
   5b2b2:	shl    %cl,%rdi
   5b2b5:	shr    $0x7,%r8d
   5b2b9:	and    $0xf8,%r8d
   5b2c0:	or     %rdi,(%r8,%rsi,1)
   5b2c4:	cmp    $0x1,%rax
   5b2c8:	je     5b23a <f.5+0x100a>
   5b2ce:	xor    %edx,%edx
   5b2d0:	cmp    %rbp,%r13
   5b2d3:	setae  %dl
   5b2d6:	mov    $0x20,%esi
   5b2db:	mov    %r15,%rdi
   5b2de:	mov    %r12,%rcx
   5b2e1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5b2e6:	test   $0x1,%al
   5b2e8:	je     5b8fb <f.5+0x16cb>
   5b2ee:	movq   $0x41,(%rdx)
   5b2f5:	lea    0x8(%rdx),%r13
   5b2f9:	pxor   %xmm0,%xmm0
   5b2fd:	movdqu %xmm0,0x8(%rdx)
   5b302:	addq   $0x20,0xe0(%r15)
   5b30a:	movdqu 0x110(%r15),%xmm0
   5b313:	paddq  -0x56dcb(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5b31b:	movdqu %xmm0,0x110(%r15)
   5b324:	movq   $0x6a,0x8(%rdx)
   5b32c:	mov    %rbx,0x10(%rdx)
   5b330:	mov    %r13,0x48(%rsp)
   5b335:	movq   $0x5,0x20(%rsp)
   5b33e:	mov    0xf4d3(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5b345:	test   %r15,%r15
   5b348:	je     5b8f6 <f.5+0x16c6>
   5b34e:	mov    0x178(%r15),%rcx
   5b355:	test   %rcx,%rcx
   5b358:	je     5b394 <f.5+0x1164>
   5b35a:	mov    0x170(%r15),%rax
   5b361:	inc    %rax
   5b364:	mov    %rax,0x170(%r15)
   5b36b:	mov    %rax,%rdx
   5b36e:	or     %rcx,%rdx
   5b371:	shr    $0x20,%rdx
   5b375:	je     5b8c0 <f.5+0x1690>
   5b37b:	xor    %edx,%edx
   5b37d:	div    %rcx
   5b380:	test   %rdx,%rdx
   5b383:	jne    5b394 <f.5+0x1164>
   5b385:	mov    0xf494(%rip),%rsi        # 6a820 <native_roots.0>
   5b38c:	mov    %r15,%rdi
   5b38f:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5b394:	cmpq   $0x30,0x98(%r15)
   5b39c:	jb     5b8fb <f.5+0x16cb>
   5b3a2:	mov    0xf477(%rip),%r12        # 6a820 <native_roots.0>
   5b3a9:	mov    0xe0(%r15),%rbx
   5b3b0:	mov    0xe8(%r15),%rbp
   5b3b7:	cmp    %rbp,%rbx
   5b3ba:	jb     5b3c7 <f.5+0x1197>
   5b3bc:	mov    %r15,%rdi
   5b3bf:	mov    %r12,%rsi
   5b3c2:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5b3c7:	mov    0xc8(%r15),%rdx
   5b3ce:	test   %rdx,%rdx
   5b3d1:	je     5b3e3 <f.5+0x11b3>
   5b3d3:	mov    0xd0(%r15),%rax
   5b3da:	sub    %rdx,%rax
   5b3dd:	cmp    $0x2f,%rax
   5b3e1:	ja     5b410 <f.5+0x11e0>
   5b3e3:	mov    $0x30,%esi
   5b3e8:	mov    %r15,%rdi
   5b3eb:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5b3f0:	cmp    $0x1,%rax
   5b3f4:	jne    5b48e <f.5+0x125e>
   5b3fa:	mov    $0x1,%eax
   5b3ff:	jmp    5b4a6 <f.5+0x1276>
   5b404:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b410:	lea    0x30(%rdx),%rax
   5b414:	mov    %rax,0xc8(%r15)
   5b41b:	mov    0x10(%r15),%rsi
   5b41f:	mov    0xc0(%r15),%rdi
   5b426:	cmp    %rsi,%rdi
   5b429:	jae    5b918 <f.5+0x16e8>
   5b42f:	mov    0x8(%r15),%rax
   5b433:	imul   $0x38,%rdi,%rcx
   5b437:	mov    %rdx,%r8
   5b43a:	sub    0x18(%rax,%rcx,1),%r8
   5b43f:	mov    %r8,%rdi
   5b442:	shr    $0xf,%rdi
   5b446:	mov    0x10(%rax,%rcx,1),%rsi
   5b44b:	cmp    %rsi,%rdi
   5b44e:	jae    5b90c <f.5+0x16dc>
   5b454:	add    %rcx,%rax
   5b457:	mov    %r8d,%ecx
   5b45a:	imul   $0x220,%rdi,%rsi
   5b461:	add    0x8(%rax),%rsi
   5b465:	shr    $0x4,%ecx
   5b468:	mov    $0x1,%eax
   5b46d:	mov    $0x1,%edi
   5b472:	shl    %cl,%rdi
   5b475:	shr    $0x7,%r8d
   5b479:	and    $0xf8,%r8d
   5b480:	or     %rdi,(%r8,%rsi,1)
   5b484:	cmp    $0x1,%rax
   5b488:	je     5b3fa <f.5+0x11ca>
   5b48e:	xor    %edx,%edx
   5b490:	cmp    %rbp,%rbx
   5b493:	setae  %dl
   5b496:	mov    $0x30,%esi
   5b49b:	mov    %r15,%rdi
   5b49e:	mov    %r12,%rcx
   5b4a1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5b4a6:	test   $0x1,%al
   5b4a8:	je     5b8fb <f.5+0x16cb>
   5b4ae:	mov    0x60(%rsp),%rsi
   5b4b3:	lea    -0x2(%rsi),%rax
   5b4b7:	movq   $0xa1,(%rdx)
   5b4be:	pxor   %xmm0,%xmm0
   5b4c2:	movdqu %xmm0,0x8(%rdx)
   5b4c7:	movdqu %xmm0,0x18(%rdx)
   5b4cc:	movq   $0x0,0x28(%rdx)
   5b4d4:	addq   $0x30,0xe0(%r15)
   5b4dc:	lea    -0x4(,%r14,4),%rcx
   5b4e4:	lea    0x8(%rdx),%rdi
   5b4e8:	movdqu 0x110(%r15),%xmm0
   5b4f1:	paddq  -0x56f99(%rip),%xmm0        # 4560 <__abi_tag+0x422c>
   5b4f9:	movdqu %xmm0,0x110(%r15)
   5b502:	movq   $0x62,0x8(%rdx)
   5b50a:	mov    %rsi,0x10(%rdx)
   5b50e:	mov    %rax,0x18(%rdx)
   5b512:	mov    %rcx,0x20(%rdx)
   5b516:	mov    %r13,0x28(%rdx)
   5b51a:	mov    %rdi,0x48(%rsp)
   5b51f:	movq   $0x5,0x20(%rsp)
   5b528:	call   5b930 <f.8>
   5b52d:	sub    $0x8,%rsp
   5b531:	mov    0x28(%rsp),%rdi
   5b536:	test   %rdi,%rdi
   5b539:	mov    0x70(%rsp),%rbx
   5b53e:	je     5b8f6 <f.5+0x16c6>
   5b544:	mov    %edi,%eax
   5b546:	and    $0x1,%eax
   5b549:	jne    5b8f6 <f.5+0x16c6>
   5b54f:	mov    0xf2c2(%rip),%rax        # 6a818 <snail_runtime::native::RUNTIME>
   5b556:	test   %rax,%rax
   5b559:	je     5b8f6 <f.5+0x16c6>
   5b55f:	mov    (%rdi),%rdx
   5b562:	cmp    $0x76,%rdx
   5b566:	sete   %cl
   5b569:	mov    %ecx,%r10d
   5b56c:	test   %rdx,%rdx
   5b56f:	je     5b5c0 <f.5+0x1390>
   5b571:	mov    %ecx,%r10d
   5b574:	cmp    $0x76,%rdx
   5b578:	je     5b5c0 <f.5+0x1390>
   5b57a:	mov    0x168(%rax),%rsi
   5b581:	mov    %rdx,%r8
   5b584:	shr    $0x2,%r8
   5b588:	lea    -0x1(%r8),%r9
   5b58c:	cmp    %rsi,%r9
   5b58f:	jae    5b8f6 <f.5+0x16c6>
   5b595:	mov    0x160(%rax),%r9
   5b59c:	mov    -0x8(%r9,%r8,8),%r8
   5b5a1:	cmp    $0x76,%r8
   5b5a5:	sete   %r10b
   5b5a9:	test   %r8,%r8
   5b5ac:	je     5b5c0 <f.5+0x1390>
   5b5ae:	cmp    $0x76,%r8
   5b5b2:	jne    5b760 <f.5+0x1530>
   5b5b8:	nopl   0x0(%rax,%rax,1)
   5b5c0:	test   %r10b,%r10b
   5b5c3:	je     5b8f6 <f.5+0x16c6>
   5b5c9:	mov    0x10(%rdi),%rsi
   5b5cd:	test   %rsi,%rsi
   5b5d0:	je     5b8f6 <f.5+0x16c6>
   5b5d6:	cmpl   $0x0,0x8(%rsi)
   5b5da:	je     5b8f6 <f.5+0x16c6>
   5b5e0:	test   %rdx,%rdx
   5b5e3:	je     5b630 <f.5+0x1400>
   5b5e5:	cmp    $0x76,%rdx
   5b5e9:	je     5b630 <f.5+0x1400>
   5b5eb:	mov    0x168(%rax),%rsi
   5b5f2:	shr    $0x2,%rdx
   5b5f6:	lea    -0x1(%rdx),%rcx
   5b5fa:	cmp    %rsi,%rcx
   5b5fd:	jae    5b8f6 <f.5+0x16c6>
   5b603:	mov    0x160(%rax),%r8
   5b60a:	mov    -0x8(%r8,%rdx,8),%rdx
   5b60f:	cmp    $0x76,%rdx
   5b613:	sete   %cl
   5b616:	test   %rdx,%rdx
   5b619:	je     5b630 <f.5+0x1400>
   5b61b:	cmp    $0x76,%rdx
   5b61f:	jne    5b790 <f.5+0x1560>
   5b625:	data16 cs nopw 0x0(%rax,%rax,1)
   5b630:	test   %cl,%cl
   5b632:	je     5b8f6 <f.5+0x16c6>
   5b638:	mov    %rdi,0x40(%rsp)
   5b63d:	mov    0x10(%rdi),%rcx
   5b641:	test   %rcx,%rcx
   5b644:	je     5b8f6 <f.5+0x16c6>
   5b64a:	cmpq   $0x0,0x10(%rcx)
   5b64f:	je     5b8f6 <f.5+0x16c6>
   5b655:	xor    %edx,%edx
   5b657:	cmpq   $0x0,0x18(%rsp)
   5b65d:	lea    0x10(%rsp),%r8
   5b662:	mov    %r8,%rcx
   5b665:	lea    0xf1b4(%rip),%rsi        # 6a820 <native_roots.0>
   5b66c:	cmove  %rsi,%rcx
   5b670:	sete   %dl
   5b673:	add    0xf186(%rip),%rdx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5b67a:	mov    (%rcx),%rsi
   5b67d:	movq   $0x7,0x18(%rsp)
   5b686:	movq   $0x0,0x20(%rsp)
   5b68f:	mov    %rsi,0x10(%rsp)
   5b694:	mov    0xf16d(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5b69b:	cmp    %rcx,%rdx
   5b69e:	cmova  %rdx,%rcx
   5b6a2:	mov    %r8,0xf177(%rip)        # 6a820 <native_roots.0>
   5b6a9:	mov    %rdx,0xf150(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5b6b0:	mov    %rcx,0xf151(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5b6b7:	lea    0x30(%rsp),%rcx
   5b6bc:	pxor   %xmm0,%xmm0
   5b6c0:	movdqu %xmm0,(%rcx)
   5b6c4:	movq   $0x0,0x10(%rcx)
   5b6cc:	mov    (%rdi),%rcx
   5b6cf:	mov    %rcx,%r8
   5b6d2:	test   %rcx,%rcx
   5b6d5:	je     5a350 <f.5+0x120>
   5b6db:	mov    %rcx,%r8
   5b6de:	cmp    $0x76,%rcx
   5b6e2:	je     5a350 <f.5+0x120>
   5b6e8:	mov    0x168(%rax),%r9
   5b6ef:	mov    %rcx,%r8
   5b6f2:	shr    $0x2,%r8
   5b6f6:	lea    -0x1(%r8),%r10
   5b6fa:	cmp    %r9,%r10
   5b6fd:	jae    5b8f6 <f.5+0x16c6>
   5b703:	mov    0x160(%rax),%r10
   5b70a:	mov    -0x8(%r10,%r8,8),%r8
   5b70f:	test   %r8,%r8
   5b712:	je     5a350 <f.5+0x120>
   5b718:	cmp    $0x76,%r8
   5b71c:	je     5a350 <f.5+0x120>
   5b722:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b730:	shr    $0x2,%r8
   5b734:	lea    -0x1(%r8),%r11
   5b738:	cmp    %r9,%r11
   5b73b:	jae    5b8f6 <f.5+0x16c6>
   5b741:	mov    -0x8(%r10,%r8,8),%r8
   5b746:	cmp    $0x76,%r8
   5b74a:	je     5a350 <f.5+0x120>
   5b750:	test   %r8,%r8
   5b753:	jne    5b730 <f.5+0x1500>
   5b755:	jmp    5a350 <f.5+0x120>
   5b75a:	nopw   0x0(%rax,%rax,1)
   5b760:	shr    $0x2,%r8
   5b764:	lea    -0x1(%r8),%r10
   5b768:	cmp    %rsi,%r10
   5b76b:	jae    5b8f6 <f.5+0x16c6>
   5b771:	mov    -0x8(%r9,%r8,8),%r8
   5b776:	cmp    $0x76,%r8
   5b77a:	je     5b781 <f.5+0x1551>
   5b77c:	test   %r8,%r8
   5b77f:	jne    5b760 <f.5+0x1530>
   5b781:	cmp    $0x76,%r8
   5b785:	je     5b5c9 <f.5+0x1399>
   5b78b:	jmp    5b8f6 <f.5+0x16c6>
   5b790:	shr    $0x2,%rdx
   5b794:	lea    -0x1(%rdx),%rcx
   5b798:	cmp    %rsi,%rcx
   5b79b:	jae    5b8f6 <f.5+0x16c6>
   5b7a1:	mov    -0x8(%r8,%rdx,8),%rdx
   5b7a6:	cmp    $0x76,%rdx
   5b7aa:	je     5b7b1 <f.5+0x1581>
   5b7ac:	test   %rdx,%rdx
   5b7af:	jne    5b790 <f.5+0x1560>
   5b7b1:	cmp    $0x76,%rdx
   5b7b5:	je     5b638 <f.5+0x1408>
   5b7bb:	jmp    5b8f6 <f.5+0x16c6>
   5b7c0:	xor    %edx,%edx
   5b7c2:	div    %ecx
   5b7c4:	test   %rdx,%rdx
   5b7c7:	jne    5a4cb <f.5+0x29b>
   5b7cd:	jmp    5a4bc <f.5+0x28c>
   5b7d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b7e0:	xor    %edx,%edx
   5b7e2:	div    %ecx
   5b7e4:	test   %rdx,%rdx
   5b7e7:	jne    5a6bf <f.5+0x48f>
   5b7ed:	jmp    5a6b0 <f.5+0x480>
   5b7f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b800:	xor    %edx,%edx
   5b802:	div    %ecx
   5b804:	test   %rdx,%rdx
   5b807:	jne    5a885 <f.5+0x655>
   5b80d:	jmp    5a876 <f.5+0x646>
   5b812:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b820:	xor    %edx,%edx
   5b822:	div    %ecx
   5b824:	test   %rdx,%rdx
   5b827:	jne    5aacf <f.5+0x89f>
   5b82d:	jmp    5aac0 <f.5+0x890>
   5b832:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b840:	xor    %edx,%edx
   5b842:	div    %ecx
   5b844:	test   %rdx,%rdx
   5b847:	jne    5ac88 <f.5+0xa58>
   5b84d:	jmp    5ac79 <f.5+0xa49>
   5b852:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b860:	xor    %edx,%edx
   5b862:	div    %ecx
   5b864:	test   %rdx,%rdx
   5b867:	jne    5ae44 <f.5+0xc14>
   5b86d:	jmp    5ae35 <f.5+0xc05>
   5b872:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b880:	xor    %edx,%edx
   5b882:	div    %ecx
   5b884:	test   %rdx,%rdx
   5b887:	jne    5b015 <f.5+0xde5>
   5b88d:	jmp    5b006 <f.5+0xdd6>
   5b892:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b8a0:	xor    %edx,%edx
   5b8a2:	div    %ecx
   5b8a4:	test   %rdx,%rdx
   5b8a7:	jne    5b1d4 <f.5+0xfa4>
   5b8ad:	jmp    5b1c5 <f.5+0xf95>
   5b8b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5b8c0:	xor    %edx,%edx
   5b8c2:	div    %ecx
   5b8c4:	test   %rdx,%rdx
   5b8c7:	jne    5b394 <f.5+0x1164>
   5b8cd:	jmp    5b385 <f.5+0x1155>
   5b8d2:	mov    %rsi,0xef47(%rip)        # 6a820 <native_roots.0>
   5b8d9:	dec    %rdx
   5b8dc:	mov    %rdx,0xef1d(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5b8e3:	xor    %eax,%eax
   5b8e5:	add    $0x78,%rsp
   5b8e9:	pop    %rbx
   5b8ea:	pop    %r12
   5b8ec:	pop    %r13
   5b8ee:	pop    %r14
   5b8f0:	pop    %r15
   5b8f2:	pop    %rbp
   5b8f3:	ret    $0x8
   5b8f6:	call   56d70 <native_trap>
   5b8fb:	lea    -0x524ae(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5b902:	mov    $0x2f,%esi
   5b907:	call   57d70 <snail_runtime::native::fail_bytes>
   5b90c:	lea    0xbcc5(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   5b913:	call   207b0 <core::panicking::panic_bounds_check>
   5b918:	lea    0xbca1(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   5b91f:	call   207b0 <core::panicking::panic_bounds_check>
   5b924:	int3
   5b925:	int3
   5b926:	int3
   5b927:	int3
   5b928:	int3
   5b929:	int3
   5b92a:	int3
   5b92b:	int3
   5b92c:	int3
   5b92d:	int3
   5b92e:	int3
   5b92f:	int3
