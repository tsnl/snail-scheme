   5f1d0:	push   %rbp
   5f1d1:	push   %r15
   5f1d3:	push   %r14
   5f1d5:	push   %r13
   5f1d7:	push   %r12
   5f1d9:	push   %rbx
   5f1da:	sub    $0x68,%rsp
   5f1de:	mov    %rsi,0x60(%rsp)
   5f1e3:	movq   $0x6,0x18(%rsp)
   5f1ec:	movq   $0x0,0x20(%rsp)
   5f1f5:	mov    0xb624(%rip),%rax        # 6a820 <native_roots.0>
   5f1fc:	mov    %rax,0x10(%rsp)
   5f201:	mov    0xb5f8(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5f208:	inc    %rax
   5f20b:	mov    %rax,0xb5ee(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   5f212:	mov    0xb5ef(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5f219:	cmp    %rcx,%rax
   5f21c:	cmovbe %rcx,%rax
   5f220:	lea    0x10(%rsp),%rsi
   5f225:	mov    %rsi,0xb5f4(%rip)        # 6a820 <native_roots.0>
   5f22c:	mov    %rax,0xb5d5(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   5f233:	mov    %rdi,0x28(%rsp)
   5f238:	pxor   %xmm0,%xmm0
   5f23c:	movdqu %xmm0,0x30(%rsp)
   5f242:	cmpb   $0x1,0xb6bf(%rip)        # 6a908 <g.5>
   5f249:	jne    608e0 <f.17+0x1710>
   5f24f:	nop
   5f250:	cmpq   $0x0,0xb6a8(%rip)        # 6a900 <g.4>
   5f258:	je     608e0 <f.17+0x1710>
   5f25e:	cmpb   $0x0,0xb6d3(%rip)        # 6a938 <g.11>
   5f265:	je     608e0 <f.17+0x1710>
   5f26b:	cmpq   $0x0,0xb6bd(%rip)        # 6a930 <g.10>
   5f273:	je     608e0 <f.17+0x1710>
   5f279:	mov    0x10(%rdi),%rax
   5f27d:	mov    %rax,0x30(%rsp)
   5f282:	test   %rax,%rax
   5f285:	je     608e0 <f.17+0x1710>
   5f28b:	mov    %eax,%ecx
   5f28d:	and    $0x1,%ecx
   5f290:	jne    608e0 <f.17+0x1710>
   5f296:	mov    0xb57b(%rip),%r8        # 6a818 <snail_runtime::native::RUNTIME>
   5f29d:	test   %r8,%r8
   5f2a0:	je     608e0 <f.17+0x1710>
   5f2a6:	mov    (%rax),%rcx
   5f2a9:	test   %rcx,%rcx
   5f2ac:	je     5f320 <f.17+0x150>
   5f2ae:	cmp    $0xaa,%rcx
   5f2b5:	je     5f320 <f.17+0x150>
   5f2b7:	mov    0x168(%r8),%rdx
   5f2be:	shr    $0x2,%rcx
   5f2c2:	lea    -0x1(%rcx),%rdi
   5f2c6:	cmp    %rdx,%rdi
   5f2c9:	jae    608e0 <f.17+0x1710>
   5f2cf:	mov    0x160(%r8),%r8
   5f2d6:	mov    -0x8(%r8,%rcx,8),%rcx
   5f2db:	test   %rcx,%rcx
   5f2de:	je     5f320 <f.17+0x150>
   5f2e0:	cmp    $0xaa,%rcx
   5f2e7:	je     5f320 <f.17+0x150>
   5f2e9:	nopl   0x0(%rax)
   5f2f0:	shr    $0x2,%rcx
   5f2f4:	lea    -0x1(%rcx),%rdi
   5f2f8:	cmp    %rdx,%rdi
   5f2fb:	jae    608e0 <f.17+0x1710>
   5f301:	mov    -0x8(%r8,%rcx,8),%rcx
   5f306:	cmp    $0xaa,%rcx
   5f30d:	je     5f320 <f.17+0x150>
   5f30f:	test   %rcx,%rcx
   5f312:	jne    5f2f0 <f.17+0x120>
   5f314:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   5f320:	cmp    $0xaa,%rcx
   5f327:	je     608e0 <f.17+0x1710>
   5f32d:	mov    0xb4e4(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5f334:	test   %r15,%r15
   5f337:	je     608e0 <f.17+0x1710>
   5f33d:	mov    (%rax),%rcx
   5f340:	test   %rcx,%rcx
   5f343:	je     5f3b0 <f.17+0x1e0>
   5f345:	cmp    $0x46,%rcx
   5f349:	je     5f3b0 <f.17+0x1e0>
   5f34b:	mov    0x168(%r15),%rdx
   5f352:	shr    $0x2,%rcx
   5f356:	lea    -0x1(%rcx),%rdi
   5f35a:	cmp    %rdx,%rdi
   5f35d:	jae    608e0 <f.17+0x1710>
   5f363:	mov    0x160(%r15),%r8
   5f36a:	mov    -0x8(%r8,%rcx,8),%rcx
   5f36f:	test   %rcx,%rcx
   5f372:	je     5f3b0 <f.17+0x1e0>
   5f374:	cmp    $0x46,%rcx
   5f378:	je     5f3b0 <f.17+0x1e0>
   5f37a:	nopw   0x0(%rax,%rax,1)
   5f380:	shr    $0x2,%rcx
   5f384:	lea    -0x1(%rcx),%rdi
   5f388:	cmp    %rdx,%rdi
   5f38b:	jae    608e0 <f.17+0x1710>
   5f391:	mov    -0x8(%r8,%rcx,8),%rcx
   5f396:	cmp    $0x46,%rcx
   5f39a:	je     5f3b0 <f.17+0x1e0>
   5f39c:	test   %rcx,%rcx
   5f39f:	jne    5f380 <f.17+0x1b0>
   5f3a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5f3b0:	cmp    $0x46,%rcx
   5f3b4:	jne    608e0 <f.17+0x1710>
   5f3ba:	mov    0x8(%rax),%r13
   5f3be:	lea    -0x546b5(%rip),%rax        # ad10 <object.1.0>
   5f3c5:	mov    %rax,0x40(%rsp)
   5f3ca:	mov    %r13,0x48(%rsp)
   5f3cf:	movq   $0x5,0x20(%rsp)
   5f3d8:	mov    0x178(%r15),%rcx
   5f3df:	mov    %rsi,%r12
   5f3e2:	test   %rcx,%rcx
   5f3e5:	je     5f424 <f.17+0x254>
   5f3e7:	mov    0x170(%r15),%rax
   5f3ee:	inc    %rax
   5f3f1:	mov    %rax,0x170(%r15)
   5f3f8:	mov    %rax,%rdx
   5f3fb:	or     %rcx,%rdx
   5f3fe:	shr    $0x20,%rdx
   5f402:	je     602d0 <f.17+0x1100>
   5f408:	xor    %edx,%edx
   5f40a:	div    %rcx
   5f40d:	mov    %rsi,%r12
   5f410:	test   %rdx,%rdx
   5f413:	jne    5f424 <f.17+0x254>
   5f415:	mov    %r15,%rdi
   5f418:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5f41d:	mov    0xb3fc(%rip),%r12        # 6a820 <native_roots.0>
   5f424:	cmpq   $0x20,0x98(%r15)
   5f42c:	jb     608e5 <f.17+0x1715>
   5f432:	mov    0xe0(%r15),%r14
   5f439:	mov    0xe8(%r15),%rbx
   5f440:	cmp    %rbx,%r14
   5f443:	jb     5f450 <f.17+0x280>
   5f445:	mov    %r15,%rdi
   5f448:	mov    %r12,%rsi
   5f44b:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5f450:	mov    0xc8(%r15),%rdx
   5f457:	test   %rdx,%rdx
   5f45a:	je     5f46c <f.17+0x29c>
   5f45c:	mov    0xd0(%r15),%rax
   5f463:	sub    %rdx,%rax
   5f466:	cmp    $0x1f,%rax
   5f46a:	ja     5f490 <f.17+0x2c0>
   5f46c:	mov    $0x20,%esi
   5f471:	mov    %r15,%rdi
   5f474:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5f479:	cmp    $0x1,%rax
   5f47d:	jne    5f50e <f.17+0x33e>
   5f483:	mov    $0x1,%eax
   5f488:	jmp    5f526 <f.17+0x356>
   5f48d:	nopl   (%rax)
   5f490:	lea    0x20(%rdx),%rax
   5f494:	mov    %rax,0xc8(%r15)
   5f49b:	mov    0x10(%r15),%rsi
   5f49f:	mov    0xc0(%r15),%rdi
   5f4a6:	cmp    %rsi,%rdi
   5f4a9:	jae    608f6 <f.17+0x1726>
   5f4af:	mov    0x8(%r15),%rax
   5f4b3:	imul   $0x38,%rdi,%rcx
   5f4b7:	mov    %rdx,%r8
   5f4ba:	sub    0x18(%rax,%rcx,1),%r8
   5f4bf:	mov    %r8,%rdi
   5f4c2:	shr    $0xf,%rdi
   5f4c6:	mov    0x10(%rax,%rcx,1),%rsi
   5f4cb:	cmp    %rsi,%rdi
   5f4ce:	jae    60902 <f.17+0x1732>
   5f4d4:	add    %rcx,%rax
   5f4d7:	mov    %r8d,%ecx
   5f4da:	imul   $0x220,%rdi,%rsi
   5f4e1:	add    0x8(%rax),%rsi
   5f4e5:	shr    $0x4,%ecx
   5f4e8:	mov    $0x1,%eax
   5f4ed:	mov    $0x1,%edi
   5f4f2:	shl    %cl,%rdi
   5f4f5:	shr    $0x7,%r8d
   5f4f9:	and    $0xf8,%r8d
   5f500:	or     %rdi,(%r8,%rsi,1)
   5f504:	cmp    $0x1,%rax
   5f508:	je     5f483 <f.17+0x2b3>
   5f50e:	xor    %edx,%edx
   5f510:	cmp    %rbx,%r14
   5f513:	setae  %dl
   5f516:	mov    $0x20,%esi
   5f51b:	mov    %r15,%rdi
   5f51e:	mov    %r12,%rcx
   5f521:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5f526:	test   $0x1,%al
   5f528:	je     608e5 <f.17+0x1715>
   5f52e:	movq   $0x41,(%rdx)
   5f535:	pxor   %xmm0,%xmm0
   5f539:	movdqu %xmm0,0x8(%rdx)
   5f53e:	addq   $0x20,0xe0(%r15)
   5f546:	lea    0x8(%rdx),%r14
   5f54a:	movdqu 0x110(%r15),%xmm0
   5f553:	paddq  -0x5b00b(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5f55b:	movdqu %xmm0,0x110(%r15)
   5f564:	movq   $0x36,0x8(%rdx)
   5f56c:	lea    -0x54863(%rip),%rax        # ad10 <object.1.0>
   5f573:	mov    %rax,0x10(%rdx)
   5f577:	mov    %rax,0x40(%rsp)
   5f57c:	mov    %r14,0x48(%rsp)
   5f581:	mov    %r13,0x50(%rsp)
   5f586:	movq   $0x6,0x20(%rsp)
   5f58f:	mov    0xb282(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5f596:	test   %r15,%r15
   5f599:	je     608e0 <f.17+0x1710>
   5f59f:	mov    0x178(%r15),%rcx
   5f5a6:	test   %rcx,%rcx
   5f5a9:	je     5f5e5 <f.17+0x415>
   5f5ab:	mov    0x170(%r15),%rax
   5f5b2:	inc    %rax
   5f5b5:	mov    %rax,0x170(%r15)
   5f5bc:	mov    %rax,%rdx
   5f5bf:	or     %rcx,%rdx
   5f5c2:	shr    $0x20,%rdx
   5f5c6:	je     602f0 <f.17+0x1120>
   5f5cc:	xor    %edx,%edx
   5f5ce:	div    %rcx
   5f5d1:	test   %rdx,%rdx
   5f5d4:	jne    5f5e5 <f.17+0x415>
   5f5d6:	mov    0xb243(%rip),%rsi        # 6a820 <native_roots.0>
   5f5dd:	mov    %r15,%rdi
   5f5e0:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5f5e5:	cmpq   $0x20,0x98(%r15)
   5f5ed:	jb     608e5 <f.17+0x1715>
   5f5f3:	mov    0xb226(%rip),%r12        # 6a820 <native_roots.0>
   5f5fa:	mov    0xe0(%r15),%rbp
   5f601:	mov    0xe8(%r15),%rbx
   5f608:	cmp    %rbx,%rbp
   5f60b:	jb     5f618 <f.17+0x448>
   5f60d:	mov    %r15,%rdi
   5f610:	mov    %r12,%rsi
   5f613:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5f618:	mov    0xc8(%r15),%rdx
   5f61f:	test   %rdx,%rdx
   5f622:	je     5f634 <f.17+0x464>
   5f624:	mov    0xd0(%r15),%rax
   5f62b:	sub    %rdx,%rax
   5f62e:	cmp    $0x1f,%rax
   5f632:	ja     5f660 <f.17+0x490>
   5f634:	mov    $0x20,%esi
   5f639:	mov    %r15,%rdi
   5f63c:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5f641:	cmp    $0x1,%rax
   5f645:	jne    5f6de <f.17+0x50e>
   5f64b:	mov    $0x1,%eax
   5f650:	jmp    5f6f6 <f.17+0x526>
   5f655:	data16 cs nopw 0x0(%rax,%rax,1)
   5f660:	lea    0x20(%rdx),%rax
   5f664:	mov    %rax,0xc8(%r15)
   5f66b:	mov    0x10(%r15),%rsi
   5f66f:	mov    0xc0(%r15),%rdi
   5f676:	cmp    %rsi,%rdi
   5f679:	jae    608f6 <f.17+0x1726>
   5f67f:	mov    0x8(%r15),%rax
   5f683:	imul   $0x38,%rdi,%rcx
   5f687:	mov    %rdx,%r8
   5f68a:	sub    0x18(%rax,%rcx,1),%r8
   5f68f:	mov    %r8,%rdi
   5f692:	shr    $0xf,%rdi
   5f696:	mov    0x10(%rax,%rcx,1),%rsi
   5f69b:	cmp    %rsi,%rdi
   5f69e:	jae    60902 <f.17+0x1732>
   5f6a4:	add    %rcx,%rax
   5f6a7:	mov    %r8d,%ecx
   5f6aa:	imul   $0x220,%rdi,%rsi
   5f6b1:	add    0x8(%rax),%rsi
   5f6b5:	shr    $0x4,%ecx
   5f6b8:	mov    $0x1,%eax
   5f6bd:	mov    $0x1,%edi
   5f6c2:	shl    %cl,%rdi
   5f6c5:	shr    $0x7,%r8d
   5f6c9:	and    $0xf8,%r8d
   5f6d0:	or     %rdi,(%r8,%rsi,1)
   5f6d4:	cmp    $0x1,%rax
   5f6d8:	je     5f64b <f.17+0x47b>
   5f6de:	xor    %edx,%edx
   5f6e0:	cmp    %rbx,%rbp
   5f6e3:	setae  %dl
   5f6e6:	mov    $0x20,%esi
   5f6eb:	mov    %r15,%rdi
   5f6ee:	mov    %r12,%rcx
   5f6f1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5f6f6:	test   $0x1,%al
   5f6f8:	je     608e5 <f.17+0x1715>
   5f6fe:	movq   $0x41,(%rdx)
   5f705:	pxor   %xmm0,%xmm0
   5f709:	movdqu %xmm0,0x8(%rdx)
   5f70e:	addq   $0x20,0xe0(%r15)
   5f716:	lea    0x8(%rdx),%rbp
   5f71a:	movdqu 0x110(%r15),%xmm0
   5f723:	paddq  -0x5b1db(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5f72b:	movdqu %xmm0,0x110(%r15)
   5f734:	movq   $0x36,0x8(%rdx)
   5f73c:	lea    -0x54a33(%rip),%rax        # ad10 <object.1.0>
   5f743:	mov    %rax,0x10(%rdx)
   5f747:	mov    %rbp,0x40(%rsp)
   5f74c:	mov    %r14,0x48(%rsp)
   5f751:	mov    %r13,0x50(%rsp)
   5f756:	movq   $0x6,0x20(%rsp)
   5f75f:	mov    0xb0b2(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5f766:	test   %r15,%r15
   5f769:	je     608e0 <f.17+0x1710>
   5f76f:	mov    0x178(%r15),%rcx
   5f776:	test   %rcx,%rcx
   5f779:	je     5f7b5 <f.17+0x5e5>
   5f77b:	mov    0x170(%r15),%rax
   5f782:	inc    %rax
   5f785:	mov    %rax,0x170(%r15)
   5f78c:	mov    %rax,%rdx
   5f78f:	or     %rcx,%rdx
   5f792:	shr    $0x20,%rdx
   5f796:	je     60310 <f.17+0x1140>
   5f79c:	xor    %edx,%edx
   5f79e:	div    %rcx
   5f7a1:	test   %rdx,%rdx
   5f7a4:	jne    5f7b5 <f.17+0x5e5>
   5f7a6:	mov    0xb073(%rip),%rsi        # 6a820 <native_roots.0>
   5f7ad:	mov    %r15,%rdi
   5f7b0:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5f7b5:	cmpq   $0x20,0x98(%r15)
   5f7bd:	jb     608e5 <f.17+0x1715>
   5f7c3:	mov    %r14,%r12
   5f7c6:	mov    %r13,0x58(%rsp)
   5f7cb:	mov    0xb04e(%rip),%r14        # 6a820 <native_roots.0>
   5f7d2:	mov    0xe0(%r15),%rbx
   5f7d9:	mov    0xe8(%r15),%r13
   5f7e0:	cmp    %r13,%rbx
   5f7e3:	jb     5f7f0 <f.17+0x620>
   5f7e5:	mov    %r15,%rdi
   5f7e8:	mov    %r14,%rsi
   5f7eb:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5f7f0:	mov    0xc8(%r15),%rdx
   5f7f7:	test   %rdx,%rdx
   5f7fa:	je     5f80c <f.17+0x63c>
   5f7fc:	mov    0xd0(%r15),%rax
   5f803:	sub    %rdx,%rax
   5f806:	cmp    $0x1f,%rax
   5f80a:	ja     5f830 <f.17+0x660>
   5f80c:	mov    $0x20,%esi
   5f811:	mov    %r15,%rdi
   5f814:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5f819:	cmp    $0x1,%rax
   5f81d:	jne    5f8ae <f.17+0x6de>
   5f823:	mov    $0x1,%eax
   5f828:	jmp    5f8c6 <f.17+0x6f6>
   5f82d:	nopl   (%rax)
   5f830:	lea    0x20(%rdx),%rax
   5f834:	mov    %rax,0xc8(%r15)
   5f83b:	mov    0x10(%r15),%rsi
   5f83f:	mov    0xc0(%r15),%rdi
   5f846:	cmp    %rsi,%rdi
   5f849:	jae    608f6 <f.17+0x1726>
   5f84f:	mov    0x8(%r15),%rax
   5f853:	imul   $0x38,%rdi,%rcx
   5f857:	mov    %rdx,%r8
   5f85a:	sub    0x18(%rax,%rcx,1),%r8
   5f85f:	mov    %r8,%rdi
   5f862:	shr    $0xf,%rdi
   5f866:	mov    0x10(%rax,%rcx,1),%rsi
   5f86b:	cmp    %rsi,%rdi
   5f86e:	jae    60902 <f.17+0x1732>
   5f874:	add    %rcx,%rax
   5f877:	mov    %r8d,%ecx
   5f87a:	imul   $0x220,%rdi,%rsi
   5f881:	add    0x8(%rax),%rsi
   5f885:	shr    $0x4,%ecx
   5f888:	mov    $0x1,%eax
   5f88d:	mov    $0x1,%edi
   5f892:	shl    %cl,%rdi
   5f895:	shr    $0x7,%r8d
   5f899:	and    $0xf8,%r8d
   5f8a0:	or     %rdi,(%r8,%rsi,1)
   5f8a4:	cmp    $0x1,%rax
   5f8a8:	je     5f823 <f.17+0x653>
   5f8ae:	xor    %edx,%edx
   5f8b0:	cmp    %r13,%rbx
   5f8b3:	setae  %dl
   5f8b6:	mov    $0x20,%esi
   5f8bb:	mov    %r15,%rdi
   5f8be:	mov    %r14,%rcx
   5f8c1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5f8c6:	mov    0x58(%rsp),%r14
   5f8cb:	test   $0x1,%al
   5f8cd:	je     608e5 <f.17+0x1715>
   5f8d3:	movq   $0x61,(%rdx)
   5f8da:	pxor   %xmm0,%xmm0
   5f8de:	movdqu %xmm0,0x8(%rdx)
   5f8e3:	movq   $0x0,0x18(%rdx)
   5f8eb:	addq   $0x20,0xe0(%r15)
   5f8f3:	movdqu 0x110(%r15),%xmm0
   5f8fc:	paddq  -0x5b414(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   5f904:	movdqu %xmm0,0x110(%r15)
   5f90d:	movq   $0x46,0x8(%rdx)
   5f915:	mov    %r12,0x10(%rdx)
   5f919:	mov    %rbp,0x18(%rdx)
   5f91d:	test   %r14,%r14
   5f920:	je     608e0 <f.17+0x1710>
   5f926:	add    $0x8,%rdx
   5f92a:	mov    %rdx,0x8(%r14)
   5f92e:	cmpb   $0x0,0xafd3(%rip)        # 6a908 <g.5>
   5f935:	je     608e0 <f.17+0x1710>
   5f93b:	cmpq   $0x0,0xafbd(%rip)        # 6a900 <g.4>
   5f943:	je     608e0 <f.17+0x1710>
   5f949:	cmpb   $0x0,0xaff8(%rip)        # 6a948 <g.13>
   5f950:	je     608e0 <f.17+0x1710>
   5f956:	cmpq   $0x0,0xafe2(%rip)        # 6a940 <g.12>
   5f95e:	je     608e0 <f.17+0x1710>
   5f964:	mov    0x28(%rsp),%rax
   5f969:	test   %rax,%rax
   5f96c:	je     608e0 <f.17+0x1710>
   5f972:	mov    0x10(%rax),%rax
   5f976:	mov    %rax,0x30(%rsp)
   5f97b:	test   %rax,%rax
   5f97e:	je     608e0 <f.17+0x1710>
   5f984:	mov    %eax,%ecx
   5f986:	and    $0x1,%ecx
   5f989:	jne    608e0 <f.17+0x1710>
   5f98f:	mov    0xae82(%rip),%rsi        # 6a818 <snail_runtime::native::RUNTIME>
   5f996:	test   %rsi,%rsi
   5f999:	je     608e0 <f.17+0x1710>
   5f99f:	mov    (%rax),%rcx
   5f9a2:	test   %rcx,%rcx
   5f9a5:	je     5fa20 <f.17+0x850>
   5f9a7:	cmp    $0xaa,%rcx
   5f9ae:	je     5fa20 <f.17+0x850>
   5f9b0:	mov    0x168(%rsi),%rdx
   5f9b7:	shr    $0x2,%rcx
   5f9bb:	lea    -0x1(%rcx),%rdi
   5f9bf:	cmp    %rdx,%rdi
   5f9c2:	jae    608e0 <f.17+0x1710>
   5f9c8:	mov    0x160(%rsi),%rsi
   5f9cf:	mov    -0x8(%rsi,%rcx,8),%rcx
   5f9d4:	test   %rcx,%rcx
   5f9d7:	je     5fa20 <f.17+0x850>
   5f9d9:	cmp    $0xaa,%rcx
   5f9e0:	je     5fa20 <f.17+0x850>
   5f9e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5f9f0:	shr    $0x2,%rcx
   5f9f4:	lea    -0x1(%rcx),%rdi
   5f9f8:	cmp    %rdx,%rdi
   5f9fb:	jae    608e0 <f.17+0x1710>
   5fa01:	mov    -0x8(%rsi,%rcx,8),%rcx
   5fa06:	cmp    $0xaa,%rcx
   5fa0d:	je     5fa20 <f.17+0x850>
   5fa0f:	test   %rcx,%rcx
   5fa12:	jne    5f9f0 <f.17+0x820>
   5fa14:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   5fa20:	cmp    $0xaa,%rcx
   5fa27:	je     608e0 <f.17+0x1710>
   5fa2d:	mov    0xade4(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5fa34:	test   %r15,%r15
   5fa37:	je     608e0 <f.17+0x1710>
   5fa3d:	mov    (%rax),%rcx
   5fa40:	test   %rcx,%rcx
   5fa43:	je     5fab0 <f.17+0x8e0>
   5fa45:	cmp    $0x46,%rcx
   5fa49:	je     5fab0 <f.17+0x8e0>
   5fa4b:	mov    0x168(%r15),%rdx
   5fa52:	shr    $0x2,%rcx
   5fa56:	lea    -0x1(%rcx),%rsi
   5fa5a:	cmp    %rdx,%rsi
   5fa5d:	jae    608e0 <f.17+0x1710>
   5fa63:	mov    0x160(%r15),%rsi
   5fa6a:	mov    -0x8(%rsi,%rcx,8),%rcx
   5fa6f:	test   %rcx,%rcx
   5fa72:	je     5fab0 <f.17+0x8e0>
   5fa74:	cmp    $0x46,%rcx
   5fa78:	je     5fab0 <f.17+0x8e0>
   5fa7a:	nopw   0x0(%rax,%rax,1)
   5fa80:	shr    $0x2,%rcx
   5fa84:	lea    -0x1(%rcx),%rdi
   5fa88:	cmp    %rdx,%rdi
   5fa8b:	jae    608e0 <f.17+0x1710>
   5fa91:	mov    -0x8(%rsi,%rcx,8),%rcx
   5fa96:	cmp    $0x46,%rcx
   5fa9a:	je     5fab0 <f.17+0x8e0>
   5fa9c:	test   %rcx,%rcx
   5fa9f:	jne    5fa80 <f.17+0x8b0>
   5faa1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5fab0:	cmp    $0x46,%rcx
   5fab4:	jne    608e0 <f.17+0x1710>
   5faba:	mov    0x10(%rax),%r13
   5fabe:	lea    -0x54db5(%rip),%rax        # ad10 <object.1.0>
   5fac5:	mov    %rax,0x40(%rsp)
   5faca:	mov    %r13,0x48(%rsp)
   5facf:	movq   $0x5,0x20(%rsp)
   5fad8:	mov    0x178(%r15),%rcx
   5fadf:	test   %rcx,%rcx
   5fae2:	je     5fb1e <f.17+0x94e>
   5fae4:	mov    0x170(%r15),%rax
   5faeb:	inc    %rax
   5faee:	mov    %rax,0x170(%r15)
   5faf5:	mov    %rax,%rdx
   5faf8:	or     %rcx,%rdx
   5fafb:	shr    $0x20,%rdx
   5faff:	je     60330 <f.17+0x1160>
   5fb05:	xor    %edx,%edx
   5fb07:	div    %rcx
   5fb0a:	test   %rdx,%rdx
   5fb0d:	jne    5fb1e <f.17+0x94e>
   5fb0f:	mov    0xad0a(%rip),%rsi        # 6a820 <native_roots.0>
   5fb16:	mov    %r15,%rdi
   5fb19:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5fb1e:	cmpq   $0x20,0x98(%r15)
   5fb26:	jb     608e5 <f.17+0x1715>
   5fb2c:	mov    0xaced(%rip),%r12        # 6a820 <native_roots.0>
   5fb33:	mov    0xe0(%r15),%rbx
   5fb3a:	mov    0xe8(%r15),%r14
   5fb41:	cmp    %r14,%rbx
   5fb44:	jb     5fb51 <f.17+0x981>
   5fb46:	mov    %r15,%rdi
   5fb49:	mov    %r12,%rsi
   5fb4c:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5fb51:	mov    0xc8(%r15),%rdx
   5fb58:	test   %rdx,%rdx
   5fb5b:	je     5fb6d <f.17+0x99d>
   5fb5d:	mov    0xd0(%r15),%rax
   5fb64:	sub    %rdx,%rax
   5fb67:	cmp    $0x1f,%rax
   5fb6b:	ja     5fb90 <f.17+0x9c0>
   5fb6d:	mov    $0x20,%esi
   5fb72:	mov    %r15,%rdi
   5fb75:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5fb7a:	cmp    $0x1,%rax
   5fb7e:	jne    5fc0e <f.17+0xa3e>
   5fb84:	mov    $0x1,%eax
   5fb89:	jmp    5fc26 <f.17+0xa56>
   5fb8e:	xchg   %ax,%ax
   5fb90:	lea    0x20(%rdx),%rax
   5fb94:	mov    %rax,0xc8(%r15)
   5fb9b:	mov    0x10(%r15),%rsi
   5fb9f:	mov    0xc0(%r15),%rdi
   5fba6:	cmp    %rsi,%rdi
   5fba9:	jae    608f6 <f.17+0x1726>
   5fbaf:	mov    0x8(%r15),%rax
   5fbb3:	imul   $0x38,%rdi,%rcx
   5fbb7:	mov    %rdx,%r8
   5fbba:	sub    0x18(%rax,%rcx,1),%r8
   5fbbf:	mov    %r8,%rdi
   5fbc2:	shr    $0xf,%rdi
   5fbc6:	mov    0x10(%rax,%rcx,1),%rsi
   5fbcb:	cmp    %rsi,%rdi
   5fbce:	jae    60902 <f.17+0x1732>
   5fbd4:	add    %rcx,%rax
   5fbd7:	mov    %r8d,%ecx
   5fbda:	imul   $0x220,%rdi,%rsi
   5fbe1:	add    0x8(%rax),%rsi
   5fbe5:	shr    $0x4,%ecx
   5fbe8:	mov    $0x1,%eax
   5fbed:	mov    $0x1,%edi
   5fbf2:	shl    %cl,%rdi
   5fbf5:	shr    $0x7,%r8d
   5fbf9:	and    $0xf8,%r8d
   5fc00:	or     %rdi,(%r8,%rsi,1)
   5fc04:	cmp    $0x1,%rax
   5fc08:	je     5fb84 <f.17+0x9b4>
   5fc0e:	xor    %edx,%edx
   5fc10:	cmp    %r14,%rbx
   5fc13:	setae  %dl
   5fc16:	mov    $0x20,%esi
   5fc1b:	mov    %r15,%rdi
   5fc1e:	mov    %r12,%rcx
   5fc21:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5fc26:	test   $0x1,%al
   5fc28:	je     608e5 <f.17+0x1715>
   5fc2e:	movq   $0x41,(%rdx)
   5fc35:	pxor   %xmm0,%xmm0
   5fc39:	movdqu %xmm0,0x8(%rdx)
   5fc3e:	addq   $0x20,0xe0(%r15)
   5fc46:	lea    0x8(%rdx),%r14
   5fc4a:	movdqu 0x110(%r15),%xmm0
   5fc53:	paddq  -0x5b70b(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5fc5b:	movdqu %xmm0,0x110(%r15)
   5fc64:	movq   $0x36,0x8(%rdx)
   5fc6c:	lea    -0x54f63(%rip),%rax        # ad10 <object.1.0>
   5fc73:	mov    %rax,0x10(%rdx)
   5fc77:	mov    %rax,0x40(%rsp)
   5fc7c:	mov    %r14,0x48(%rsp)
   5fc81:	mov    %r13,0x50(%rsp)
   5fc86:	movq   $0x6,0x20(%rsp)
   5fc8f:	mov    0xab82(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5fc96:	test   %r15,%r15
   5fc99:	je     608e0 <f.17+0x1710>
   5fc9f:	mov    0x178(%r15),%rcx
   5fca6:	test   %rcx,%rcx
   5fca9:	je     5fce5 <f.17+0xb15>
   5fcab:	mov    0x170(%r15),%rax
   5fcb2:	inc    %rax
   5fcb5:	mov    %rax,0x170(%r15)
   5fcbc:	mov    %rax,%rdx
   5fcbf:	or     %rcx,%rdx
   5fcc2:	shr    $0x20,%rdx
   5fcc6:	je     60350 <f.17+0x1180>
   5fccc:	xor    %edx,%edx
   5fcce:	div    %rcx
   5fcd1:	test   %rdx,%rdx
   5fcd4:	jne    5fce5 <f.17+0xb15>
   5fcd6:	mov    0xab43(%rip),%rsi        # 6a820 <native_roots.0>
   5fcdd:	mov    %r15,%rdi
   5fce0:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5fce5:	cmpq   $0x20,0x98(%r15)
   5fced:	jb     608e5 <f.17+0x1715>
   5fcf3:	mov    0xab26(%rip),%r12        # 6a820 <native_roots.0>
   5fcfa:	mov    0xe0(%r15),%rbx
   5fd01:	mov    0xe8(%r15),%rbp
   5fd08:	cmp    %rbp,%rbx
   5fd0b:	jb     5fd18 <f.17+0xb48>
   5fd0d:	mov    %r15,%rdi
   5fd10:	mov    %r12,%rsi
   5fd13:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5fd18:	mov    0xc8(%r15),%rdx
   5fd1f:	test   %rdx,%rdx
   5fd22:	je     5fd34 <f.17+0xb64>
   5fd24:	mov    0xd0(%r15),%rax
   5fd2b:	sub    %rdx,%rax
   5fd2e:	cmp    $0x1f,%rax
   5fd32:	ja     5fd60 <f.17+0xb90>
   5fd34:	mov    $0x20,%esi
   5fd39:	mov    %r15,%rdi
   5fd3c:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5fd41:	cmp    $0x1,%rax
   5fd45:	jne    5fdde <f.17+0xc0e>
   5fd4b:	mov    $0x1,%eax
   5fd50:	jmp    5fdf6 <f.17+0xc26>
   5fd55:	data16 cs nopw 0x0(%rax,%rax,1)
   5fd60:	lea    0x20(%rdx),%rax
   5fd64:	mov    %rax,0xc8(%r15)
   5fd6b:	mov    0x10(%r15),%rsi
   5fd6f:	mov    0xc0(%r15),%rdi
   5fd76:	cmp    %rsi,%rdi
   5fd79:	jae    608f6 <f.17+0x1726>
   5fd7f:	mov    0x8(%r15),%rax
   5fd83:	imul   $0x38,%rdi,%rcx
   5fd87:	mov    %rdx,%r8
   5fd8a:	sub    0x18(%rax,%rcx,1),%r8
   5fd8f:	mov    %r8,%rdi
   5fd92:	shr    $0xf,%rdi
   5fd96:	mov    0x10(%rax,%rcx,1),%rsi
   5fd9b:	cmp    %rsi,%rdi
   5fd9e:	jae    60902 <f.17+0x1732>
   5fda4:	add    %rcx,%rax
   5fda7:	mov    %r8d,%ecx
   5fdaa:	imul   $0x220,%rdi,%rsi
   5fdb1:	add    0x8(%rax),%rsi
   5fdb5:	shr    $0x4,%ecx
   5fdb8:	mov    $0x1,%eax
   5fdbd:	mov    $0x1,%edi
   5fdc2:	shl    %cl,%rdi
   5fdc5:	shr    $0x7,%r8d
   5fdc9:	and    $0xf8,%r8d
   5fdd0:	or     %rdi,(%r8,%rsi,1)
   5fdd4:	cmp    $0x1,%rax
   5fdd8:	je     5fd4b <f.17+0xb7b>
   5fdde:	xor    %edx,%edx
   5fde0:	cmp    %rbp,%rbx
   5fde3:	setae  %dl
   5fde6:	mov    $0x20,%esi
   5fdeb:	mov    %r15,%rdi
   5fdee:	mov    %r12,%rcx
   5fdf1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5fdf6:	test   $0x1,%al
   5fdf8:	je     608e5 <f.17+0x1715>
   5fdfe:	movq   $0x41,(%rdx)
   5fe05:	pxor   %xmm0,%xmm0
   5fe09:	movdqu %xmm0,0x8(%rdx)
   5fe0e:	addq   $0x20,0xe0(%r15)
   5fe16:	lea    0x8(%rdx),%rbp
   5fe1a:	movdqu 0x110(%r15),%xmm0
   5fe23:	paddq  -0x5b8db(%rip),%xmm0        # 4550 <__abi_tag+0x421c>
   5fe2b:	movdqu %xmm0,0x110(%r15)
   5fe34:	movq   $0x36,0x8(%rdx)
   5fe3c:	lea    -0x55133(%rip),%rax        # ad10 <object.1.0>
   5fe43:	mov    %rax,0x10(%rdx)
   5fe47:	mov    %rbp,0x40(%rsp)
   5fe4c:	mov    %r14,0x48(%rsp)
   5fe51:	mov    %r13,0x50(%rsp)
   5fe56:	movq   $0x6,0x20(%rsp)
   5fe5f:	mov    0xa9b2(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   5fe66:	test   %r15,%r15
   5fe69:	je     608e0 <f.17+0x1710>
   5fe6f:	mov    0x178(%r15),%rcx
   5fe76:	test   %rcx,%rcx
   5fe79:	je     5feb5 <f.17+0xce5>
   5fe7b:	mov    0x170(%r15),%rax
   5fe82:	inc    %rax
   5fe85:	mov    %rax,0x170(%r15)
   5fe8c:	mov    %rax,%rdx
   5fe8f:	or     %rcx,%rdx
   5fe92:	shr    $0x20,%rdx
   5fe96:	je     60370 <f.17+0x11a0>
   5fe9c:	xor    %edx,%edx
   5fe9e:	div    %rcx
   5fea1:	test   %rdx,%rdx
   5fea4:	jne    5feb5 <f.17+0xce5>
   5fea6:	mov    0xa973(%rip),%rsi        # 6a820 <native_roots.0>
   5fead:	mov    %r15,%rdi
   5feb0:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5feb5:	cmpq   $0x20,0x98(%r15)
   5febd:	jb     608e5 <f.17+0x1715>
   5fec3:	mov    %r14,%r12
   5fec6:	mov    %r13,0x58(%rsp)
   5fecb:	mov    0xa94e(%rip),%r14        # 6a820 <native_roots.0>
   5fed2:	mov    0xe0(%r15),%rbx
   5fed9:	mov    0xe8(%r15),%r13
   5fee0:	cmp    %r13,%rbx
   5fee3:	jb     5fef0 <f.17+0xd20>
   5fee5:	mov    %r15,%rdi
   5fee8:	mov    %r14,%rsi
   5feeb:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   5fef0:	mov    0xc8(%r15),%rdx
   5fef7:	test   %rdx,%rdx
   5fefa:	je     5ff0c <f.17+0xd3c>
   5fefc:	mov    0xd0(%r15),%rax
   5ff03:	sub    %rdx,%rax
   5ff06:	cmp    $0x1f,%rax
   5ff0a:	ja     5ff30 <f.17+0xd60>
   5ff0c:	mov    $0x20,%esi
   5ff11:	mov    %r15,%rdi
   5ff14:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   5ff19:	cmp    $0x1,%rax
   5ff1d:	jne    5ffae <f.17+0xdde>
   5ff23:	mov    $0x1,%eax
   5ff28:	jmp    5ffc6 <f.17+0xdf6>
   5ff2d:	nopl   (%rax)
   5ff30:	lea    0x20(%rdx),%rax
   5ff34:	mov    %rax,0xc8(%r15)
   5ff3b:	mov    0x10(%r15),%rsi
   5ff3f:	mov    0xc0(%r15),%rdi
   5ff46:	cmp    %rsi,%rdi
   5ff49:	jae    608f6 <f.17+0x1726>
   5ff4f:	mov    0x8(%r15),%rax
   5ff53:	imul   $0x38,%rdi,%rcx
   5ff57:	mov    %rdx,%r8
   5ff5a:	sub    0x18(%rax,%rcx,1),%r8
   5ff5f:	mov    %r8,%rdi
   5ff62:	shr    $0xf,%rdi
   5ff66:	mov    0x10(%rax,%rcx,1),%rsi
   5ff6b:	cmp    %rsi,%rdi
   5ff6e:	jae    60902 <f.17+0x1732>
   5ff74:	add    %rcx,%rax
   5ff77:	mov    %r8d,%ecx
   5ff7a:	imul   $0x220,%rdi,%rsi
   5ff81:	add    0x8(%rax),%rsi
   5ff85:	shr    $0x4,%ecx
   5ff88:	mov    $0x1,%eax
   5ff8d:	mov    $0x1,%edi
   5ff92:	shl    %cl,%rdi
   5ff95:	shr    $0x7,%r8d
   5ff99:	and    $0xf8,%r8d
   5ffa0:	or     %rdi,(%r8,%rsi,1)
   5ffa4:	cmp    $0x1,%rax
   5ffa8:	je     5ff23 <f.17+0xd53>
   5ffae:	xor    %edx,%edx
   5ffb0:	cmp    %r13,%rbx
   5ffb3:	setae  %dl
   5ffb6:	mov    $0x20,%esi
   5ffbb:	mov    %r15,%rdi
   5ffbe:	mov    %r14,%rcx
   5ffc1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   5ffc6:	mov    0x58(%rsp),%r14
   5ffcb:	test   $0x1,%al
   5ffcd:	je     608e5 <f.17+0x1715>
   5ffd3:	movq   $0x61,(%rdx)
   5ffda:	pxor   %xmm0,%xmm0
   5ffde:	movdqu %xmm0,0x8(%rdx)
   5ffe3:	movq   $0x0,0x18(%rdx)
   5ffeb:	addq   $0x20,0xe0(%r15)
   5fff3:	movdqu 0x110(%r15),%xmm0
   5fffc:	paddq  -0x5bb14(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   60004:	movdqu %xmm0,0x110(%r15)
   6000d:	movq   $0x46,0x8(%rdx)
   60015:	mov    %r12,0x10(%rdx)
   60019:	mov    %rbp,0x18(%rdx)
   6001d:	test   %r14,%r14
   60020:	je     608e0 <f.17+0x1710>
   60026:	add    $0x8,%rdx
   6002a:	mov    %rdx,0x8(%r14)
   6002e:	cmpb   $0x0,0xa8e3(%rip)        # 6a918 <g.7>
   60035:	je     608e0 <f.17+0x1710>
   6003b:	cmpq   $0x0,0xa8cd(%rip)        # 6a910 <g.6>
   60043:	je     608e0 <f.17+0x1710>
   60049:	mov    0x28(%rsp),%rax
   6004e:	test   %rax,%rax
   60051:	je     608e0 <f.17+0x1710>
   60057:	mov    0x10(%rax),%rcx
   6005b:	mov    %rcx,0x30(%rsp)
   60060:	test   %rcx,%rcx
   60063:	je     608e0 <f.17+0x1710>
   60069:	mov    %ecx,%edx
   6006b:	and    $0x1,%edx
   6006e:	jne    608e0 <f.17+0x1710>
   60074:	mov    0xa79d(%rip),%rdi        # 6a818 <snail_runtime::native::RUNTIME>
   6007b:	test   %rdi,%rdi
   6007e:	je     608e0 <f.17+0x1710>
   60084:	mov    (%rcx),%rdx
   60087:	test   %rdx,%rdx
   6008a:	je     60100 <f.17+0xf30>
   6008c:	cmp    $0xaa,%rdx
   60093:	je     60100 <f.17+0xf30>
   60095:	mov    0x168(%rdi),%rsi
   6009c:	shr    $0x2,%rdx
   600a0:	lea    -0x1(%rdx),%r8
   600a4:	cmp    %rsi,%r8
   600a7:	jae    608e0 <f.17+0x1710>
   600ad:	mov    0x160(%rdi),%rdi
   600b4:	mov    -0x8(%rdi,%rdx,8),%rdx
   600b9:	test   %rdx,%rdx
   600bc:	je     60100 <f.17+0xf30>
   600be:	cmp    $0xaa,%rdx
   600c5:	je     60100 <f.17+0xf30>
   600c7:	nopw   0x0(%rax,%rax,1)
   600d0:	shr    $0x2,%rdx
   600d4:	lea    -0x1(%rdx),%r8
   600d8:	cmp    %rsi,%r8
   600db:	jae    608e0 <f.17+0x1710>
   600e1:	mov    -0x8(%rdi,%rdx,8),%rdx
   600e6:	cmp    $0xaa,%rdx
   600ed:	je     60100 <f.17+0xf30>
   600ef:	test   %rdx,%rdx
   600f2:	jne    600d0 <f.17+0xf00>
   600f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   60100:	cmp    $0xaa,%rdx
   60107:	je     608e0 <f.17+0x1710>
   6010d:	mov    0xa704(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   60114:	test   %r15,%r15
   60117:	je     608e0 <f.17+0x1710>
   6011d:	mov    (%rcx),%rdx
   60120:	test   %rdx,%rdx
   60123:	je     60190 <f.17+0xfc0>
   60125:	cmp    $0x46,%rdx
   60129:	je     60190 <f.17+0xfc0>
   6012b:	mov    0x168(%r15),%rsi
   60132:	shr    $0x2,%rdx
   60136:	lea    -0x1(%rdx),%rdi
   6013a:	cmp    %rsi,%rdi
   6013d:	jae    608e0 <f.17+0x1710>
   60143:	mov    0x160(%r15),%rdi
   6014a:	mov    -0x8(%rdi,%rdx,8),%rdx
   6014f:	test   %rdx,%rdx
   60152:	je     60190 <f.17+0xfc0>
   60154:	cmp    $0x46,%rdx
   60158:	je     60190 <f.17+0xfc0>
   6015a:	nopw   0x0(%rax,%rax,1)
   60160:	shr    $0x2,%rdx
   60164:	lea    -0x1(%rdx),%r8
   60168:	cmp    %rsi,%r8
   6016b:	jae    608e0 <f.17+0x1710>
   60171:	mov    -0x8(%rdi,%rdx,8),%rdx
   60176:	cmp    $0x46,%rdx
   6017a:	je     60190 <f.17+0xfc0>
   6017c:	test   %rdx,%rdx
   6017f:	jne    60160 <f.17+0xf90>
   60181:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60190:	cmp    $0x46,%rdx
   60194:	jne    608e0 <f.17+0x1710>
   6019a:	mov    0x8(%rcx),%rcx
   6019e:	test   %rcx,%rcx
   601a1:	je     608e0 <f.17+0x1710>
   601a7:	mov    0x8(%rcx),%r14
   601ab:	mov    %r14,0x30(%rsp)
   601b0:	mov    0x8(%rax),%rax
   601b4:	test   %rax,%rax
   601b7:	je     608e0 <f.17+0x1710>
   601bd:	cmpl   $0x0,0x8(%rax)
   601c1:	je     608e0 <f.17+0x1710>
   601c7:	mov    0x10(%rax),%rax
   601cb:	test   %rax,%rax
   601ce:	je     608e0 <f.17+0x1710>
   601d4:	mov    0x8(%rax),%rax
   601d8:	mov    %rax,0x38(%rsp)
   601dd:	cmpq   $0x0,0x60(%rsp)
   601e3:	jle    6048e <f.17+0x12be>
   601e9:	test   %rax,%rax
   601ec:	je     608e0 <f.17+0x1710>
   601f2:	mov    0x8(%rax),%r13
   601f6:	mov    %r14,0x40(%rsp)
   601fb:	mov    %r13,0x48(%rsp)
   60200:	movq   $0x5,0x20(%rsp)
   60209:	mov    0x178(%r15),%rcx
   60210:	test   %rcx,%rcx
   60213:	je     6024f <f.17+0x107f>
   60215:	mov    0x170(%r15),%rax
   6021c:	inc    %rax
   6021f:	mov    %rax,0x170(%r15)
   60226:	mov    %rax,%rdx
   60229:	or     %rcx,%rdx
   6022c:	shr    $0x20,%rdx
   60230:	je     608a2 <f.17+0x16d2>
   60236:	xor    %edx,%edx
   60238:	div    %rcx
   6023b:	test   %rdx,%rdx
   6023e:	jne    6024f <f.17+0x107f>
   60240:	mov    0xa5d9(%rip),%rsi        # 6a820 <native_roots.0>
   60247:	mov    %r15,%rdi
   6024a:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   6024f:	cmpq   $0x20,0x98(%r15)
   60257:	jb     608e5 <f.17+0x1715>
   6025d:	mov    0xa5bc(%rip),%r12        # 6a820 <native_roots.0>
   60264:	mov    0xe0(%r15),%rbx
   6026b:	mov    0xe8(%r15),%rbp
   60272:	cmp    %rbp,%rbx
   60275:	jb     60282 <f.17+0x10b2>
   60277:	mov    %r15,%rdi
   6027a:	mov    %r12,%rsi
   6027d:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   60282:	mov    0xc8(%r15),%rdx
   60289:	test   %rdx,%rdx
   6028c:	je     602a2 <f.17+0x10d2>
   6028e:	mov    0xd0(%r15),%rax
   60295:	sub    %rdx,%rax
   60298:	cmp    $0x1f,%rax
   6029c:	ja     60382 <f.17+0x11b2>
   602a2:	mov    $0x20,%esi
   602a7:	mov    %r15,%rdi
   602aa:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   602af:	cmp    $0x1,%rax
   602b3:	jne    60400 <f.17+0x1230>
   602b9:	mov    $0x1,%eax
   602be:	jmp    60418 <f.17+0x1248>
   602c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   602d0:	xor    %edx,%edx
   602d2:	div    %ecx
   602d4:	mov    %rsi,%r12
   602d7:	test   %rdx,%rdx
   602da:	jne    5f424 <f.17+0x254>
   602e0:	jmp    5f415 <f.17+0x245>
   602e5:	data16 cs nopw 0x0(%rax,%rax,1)
   602f0:	xor    %edx,%edx
   602f2:	div    %ecx
   602f4:	test   %rdx,%rdx
   602f7:	jne    5f5e5 <f.17+0x415>
   602fd:	jmp    5f5d6 <f.17+0x406>
   60302:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60310:	xor    %edx,%edx
   60312:	div    %ecx
   60314:	test   %rdx,%rdx
   60317:	jne    5f7b5 <f.17+0x5e5>
   6031d:	jmp    5f7a6 <f.17+0x5d6>
   60322:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60330:	xor    %edx,%edx
   60332:	div    %ecx
   60334:	test   %rdx,%rdx
   60337:	jne    5fb1e <f.17+0x94e>
   6033d:	jmp    5fb0f <f.17+0x93f>
   60342:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60350:	xor    %edx,%edx
   60352:	div    %ecx
   60354:	test   %rdx,%rdx
   60357:	jne    5fce5 <f.17+0xb15>
   6035d:	jmp    5fcd6 <f.17+0xb06>
   60362:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60370:	xor    %edx,%edx
   60372:	div    %ecx
   60374:	test   %rdx,%rdx
   60377:	jne    5feb5 <f.17+0xce5>
   6037d:	jmp    5fea6 <f.17+0xcd6>
   60382:	lea    0x20(%rdx),%rax
   60386:	mov    %rax,0xc8(%r15)
   6038d:	mov    0x10(%r15),%rsi
   60391:	mov    0xc0(%r15),%rdi
   60398:	cmp    %rsi,%rdi
   6039b:	jae    608f6 <f.17+0x1726>
   603a1:	mov    0x8(%r15),%rax
   603a5:	imul   $0x38,%rdi,%rcx
   603a9:	mov    %rdx,%r8
   603ac:	sub    0x18(%rax,%rcx,1),%r8
   603b1:	mov    %r8,%rdi
   603b4:	shr    $0xf,%rdi
   603b8:	mov    0x10(%rax,%rcx,1),%rsi
   603bd:	cmp    %rsi,%rdi
   603c0:	jae    60902 <f.17+0x1732>
   603c6:	add    %rcx,%rax
   603c9:	mov    %r8d,%ecx
   603cc:	imul   $0x220,%rdi,%rsi
   603d3:	add    0x8(%rax),%rsi
   603d7:	shr    $0x4,%ecx
   603da:	mov    $0x1,%eax
   603df:	mov    $0x1,%edi
   603e4:	shl    %cl,%rdi
   603e7:	shr    $0x7,%r8d
   603eb:	and    $0xf8,%r8d
   603f2:	or     %rdi,(%r8,%rsi,1)
   603f6:	cmp    $0x1,%rax
   603fa:	je     602b9 <f.17+0x10e9>
   60400:	xor    %edx,%edx
   60402:	cmp    %rbp,%rbx
   60405:	setae  %dl
   60408:	mov    $0x20,%esi
   6040d:	mov    %r15,%rdi
   60410:	mov    %r12,%rcx
   60413:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   60418:	test   $0x1,%al
   6041a:	je     608e5 <f.17+0x1715>
   60420:	movq   $0x61,(%rdx)
   60427:	lea    0x8(%rdx),%rdi
   6042b:	pxor   %xmm0,%xmm0
   6042f:	movdqu %xmm0,0x8(%rdx)
   60434:	movq   $0x0,0x18(%rdx)
   6043c:	addq   $0x20,0xe0(%r15)
   60444:	movdqu 0x110(%r15),%xmm0
   6044d:	paddq  -0x5bf65(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   60455:	movdqu %xmm0,0x110(%r15)
   6045e:	movq   $0x32,0x8(%rdx)
   60466:	mov    %r13,0x10(%rdx)
   6046a:	mov    %r14,0x18(%rdx)
   6046e:	mov    0x60(%rsp),%rax
   60473:	lea    -0x1(%rax),%rsi
   60477:	mov    %rdi,0x40(%rsp)
   6047c:	movq   $0x4,0x20(%rsp)
   60485:	call   5f1d0 <f.17>
   6048a:	sub    $0x8,%rsp
   6048e:	cmpb   $0x0,0xa493(%rip)        # 6a928 <g.9>
   60495:	je     608e0 <f.17+0x1710>
   6049b:	cmpq   $0x0,0xa47d(%rip)        # 6a920 <g.8>
   604a3:	je     608e0 <f.17+0x1710>
   604a9:	mov    0x28(%rsp),%rax
   604ae:	test   %rax,%rax
   604b1:	je     608e0 <f.17+0x1710>
   604b7:	mov    0x10(%rax),%rcx
   604bb:	mov    %rcx,0x30(%rsp)
   604c0:	test   %rcx,%rcx
   604c3:	je     608e0 <f.17+0x1710>
   604c9:	mov    %ecx,%edx
   604cb:	and    $0x1,%edx
   604ce:	jne    608e0 <f.17+0x1710>
   604d4:	mov    0xa33d(%rip),%rdi        # 6a818 <snail_runtime::native::RUNTIME>
   604db:	test   %rdi,%rdi
   604de:	je     608e0 <f.17+0x1710>
   604e4:	mov    (%rcx),%rdx
   604e7:	test   %rdx,%rdx
   604ea:	je     60560 <f.17+0x1390>
   604ec:	cmp    $0xaa,%rdx
   604f3:	je     60560 <f.17+0x1390>
   604f5:	mov    0x168(%rdi),%rsi
   604fc:	shr    $0x2,%rdx
   60500:	lea    -0x1(%rdx),%r8
   60504:	cmp    %rsi,%r8
   60507:	jae    608e0 <f.17+0x1710>
   6050d:	mov    0x160(%rdi),%rdi
   60514:	mov    -0x8(%rdi,%rdx,8),%rdx
   60519:	test   %rdx,%rdx
   6051c:	je     60560 <f.17+0x1390>
   6051e:	cmp    $0xaa,%rdx
   60525:	je     60560 <f.17+0x1390>
   60527:	nopw   0x0(%rax,%rax,1)
   60530:	shr    $0x2,%rdx
   60534:	lea    -0x1(%rdx),%r8
   60538:	cmp    %rsi,%r8
   6053b:	jae    608e0 <f.17+0x1710>
   60541:	mov    -0x8(%rdi,%rdx,8),%rdx
   60546:	cmp    $0xaa,%rdx
   6054d:	je     60560 <f.17+0x1390>
   6054f:	test   %rdx,%rdx
   60552:	jne    60530 <f.17+0x1360>
   60554:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   60560:	cmp    $0xaa,%rdx
   60567:	je     608e0 <f.17+0x1710>
   6056d:	mov    0xa2a4(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   60574:	test   %r15,%r15
   60577:	je     608e0 <f.17+0x1710>
   6057d:	mov    (%rcx),%rdx
   60580:	test   %rdx,%rdx
   60583:	je     605f0 <f.17+0x1420>
   60585:	cmp    $0x46,%rdx
   60589:	je     605f0 <f.17+0x1420>
   6058b:	mov    0x168(%r15),%rsi
   60592:	shr    $0x2,%rdx
   60596:	lea    -0x1(%rdx),%rdi
   6059a:	cmp    %rsi,%rdi
   6059d:	jae    608e0 <f.17+0x1710>
   605a3:	mov    0x160(%r15),%rdi
   605aa:	mov    -0x8(%rdi,%rdx,8),%rdx
   605af:	test   %rdx,%rdx
   605b2:	je     605f0 <f.17+0x1420>
   605b4:	cmp    $0x46,%rdx
   605b8:	je     605f0 <f.17+0x1420>
   605ba:	nopw   0x0(%rax,%rax,1)
   605c0:	shr    $0x2,%rdx
   605c4:	lea    -0x1(%rdx),%r8
   605c8:	cmp    %rsi,%r8
   605cb:	jae    608e0 <f.17+0x1710>
   605d1:	mov    -0x8(%rdi,%rdx,8),%rdx
   605d6:	cmp    $0x46,%rdx
   605da:	je     605f0 <f.17+0x1420>
   605dc:	test   %rdx,%rdx
   605df:	jne    605c0 <f.17+0x13f0>
   605e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   605f0:	cmp    $0x46,%rdx
   605f4:	jne    608e0 <f.17+0x1710>
   605fa:	mov    0x10(%rcx),%rcx
   605fe:	test   %rcx,%rcx
   60601:	je     608e0 <f.17+0x1710>
   60607:	mov    0x8(%rcx),%r14
   6060b:	mov    %r14,0x30(%rsp)
   60610:	mov    0x8(%rax),%rax
   60614:	test   %rax,%rax
   60617:	je     608e0 <f.17+0x1710>
   6061d:	cmpl   $0x0,0x8(%rax)
   60621:	je     608e0 <f.17+0x1710>
   60627:	mov    0x10(%rax),%rax
   6062b:	test   %rax,%rax
   6062e:	je     608e0 <f.17+0x1710>
   60634:	mov    0x8(%rax),%rax
   60638:	mov    %rax,0x38(%rsp)
   6063d:	cmpq   $0x0,0x60(%rsp)
   60643:	jle    608b4 <f.17+0x16e4>
   60649:	test   %rax,%rax
   6064c:	je     608e0 <f.17+0x1710>
   60652:	mov    0x8(%rax),%r13
   60656:	mov    %r14,0x40(%rsp)
   6065b:	mov    %r13,0x48(%rsp)
   60660:	movq   $0x5,0x20(%rsp)
   60669:	mov    0x178(%r15),%rcx
   60670:	test   %rcx,%rcx
   60673:	je     606af <f.17+0x14df>
   60675:	mov    0x170(%r15),%rax
   6067c:	inc    %rax
   6067f:	mov    %rax,0x170(%r15)
   60686:	mov    %rax,%rdx
   60689:	or     %rcx,%rdx
   6068c:	shr    $0x20,%rdx
   60690:	je     60890 <f.17+0x16c0>
   60696:	xor    %edx,%edx
   60698:	div    %rcx
   6069b:	test   %rdx,%rdx
   6069e:	jne    606af <f.17+0x14df>
   606a0:	mov    0xa179(%rip),%rsi        # 6a820 <native_roots.0>
   606a7:	mov    %r15,%rdi
   606aa:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   606af:	cmpq   $0x20,0x98(%r15)
   606b7:	jb     608e5 <f.17+0x1715>
   606bd:	mov    0xa15c(%rip),%r12        # 6a820 <native_roots.0>
   606c4:	mov    0xe0(%r15),%rbx
   606cb:	mov    0xe8(%r15),%rbp
   606d2:	cmp    %rbp,%rbx
   606d5:	jb     606e2 <f.17+0x1512>
   606d7:	mov    %r15,%rdi
   606da:	mov    %r12,%rsi
   606dd:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   606e2:	mov    0xc8(%r15),%rdx
   606e9:	test   %rdx,%rdx
   606ec:	je     606fe <f.17+0x152e>
   606ee:	mov    0xd0(%r15),%rax
   606f5:	sub    %rdx,%rax
   606f8:	cmp    $0x1f,%rax
   606fc:	ja     60720 <f.17+0x1550>
   606fe:	mov    $0x20,%esi
   60703:	mov    %r15,%rdi
   60706:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   6070b:	cmp    $0x1,%rax
   6070f:	jne    6079e <f.17+0x15ce>
   60715:	mov    $0x1,%eax
   6071a:	jmp    607b6 <f.17+0x15e6>
   6071f:	nop
   60720:	lea    0x20(%rdx),%rax
   60724:	mov    %rax,0xc8(%r15)
   6072b:	mov    0x10(%r15),%rsi
   6072f:	mov    0xc0(%r15),%rdi
   60736:	cmp    %rsi,%rdi
   60739:	jae    608f6 <f.17+0x1726>
   6073f:	mov    0x8(%r15),%rax
   60743:	imul   $0x38,%rdi,%rcx
   60747:	mov    %rdx,%r8
   6074a:	sub    0x18(%rax,%rcx,1),%r8
   6074f:	mov    %r8,%rdi
   60752:	shr    $0xf,%rdi
   60756:	mov    0x10(%rax,%rcx,1),%rsi
   6075b:	cmp    %rsi,%rdi
   6075e:	jae    60902 <f.17+0x1732>
   60764:	add    %rcx,%rax
   60767:	mov    %r8d,%ecx
   6076a:	imul   $0x220,%rdi,%rsi
   60771:	add    0x8(%rax),%rsi
   60775:	shr    $0x4,%ecx
   60778:	mov    $0x1,%eax
   6077d:	mov    $0x1,%edi
   60782:	shl    %cl,%rdi
   60785:	shr    $0x7,%r8d
   60789:	and    $0xf8,%r8d
   60790:	or     %rdi,(%r8,%rsi,1)
   60794:	cmp    $0x1,%rax
   60798:	je     60715 <f.17+0x1545>
   6079e:	xor    %edx,%edx
   607a0:	cmp    %rbp,%rbx
   607a3:	setae  %dl
   607a6:	mov    $0x20,%esi
   607ab:	mov    %r15,%rdi
   607ae:	mov    %r12,%rcx
   607b1:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   607b6:	test   $0x1,%al
   607b8:	je     608e5 <f.17+0x1715>
   607be:	movq   $0x61,(%rdx)
   607c5:	lea    0x8(%rdx),%rdi
   607c9:	xorps  %xmm1,%xmm1
   607cc:	movups %xmm1,0x8(%rdx)
   607d0:	movq   $0x0,0x18(%rdx)
   607d8:	addq   $0x20,0xe0(%r15)
   607e0:	movdqu 0x110(%r15),%xmm0
   607e9:	paddq  -0x5c301(%rip),%xmm0        # 44f0 <__abi_tag+0x41bc>
   607f1:	movdqu %xmm0,0x110(%r15)
   607fa:	movq   $0x32,0x8(%rdx)
   60802:	mov    %r13,0x10(%rdx)
   60806:	mov    %r14,0x18(%rdx)
   6080a:	decq   0x60(%rsp)
   6080f:	xor    %eax,%eax
   60811:	cmpq   $0x0,0x18(%rsp)
   60817:	sete   %al
   6081a:	lea    0x10(%rsp),%rsi
   6081f:	mov    %rsi,%rcx
   60822:	lea    0x9ff7(%rip),%rdx        # 6a820 <native_roots.0>
   60829:	cmove  %rdx,%rcx
   6082d:	add    0x9fcc(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   60834:	mov    (%rcx),%rcx
   60837:	movq   $0x6,0x18(%rsp)
   60840:	movq   $0x0,0x20(%rsp)
   60849:	mov    %rcx,0x10(%rsp)
   6084e:	mov    %rsi,0x9fcb(%rip)        # 6a820 <native_roots.0>
   60855:	mov    %rax,0x9fa4(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   6085c:	mov    0x9fa5(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   60863:	cmp    %rcx,%rax
   60866:	cmovbe %rcx,%rax
   6086a:	mov    %rax,0x9f97(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   60871:	mov    %rdi,0x28(%rsp)
   60876:	lea    0x30(%rsp),%rax
   6087b:	movups %xmm1,(%rax)
   6087e:	cmpb   $0x0,0xa083(%rip)        # 6a908 <g.5>
   60885:	jne    5f250 <f.17+0x80>
   6088b:	jmp    608e0 <f.17+0x1710>
   6088d:	nopl   (%rax)
   60890:	xor    %edx,%edx
   60892:	div    %ecx
   60894:	test   %rdx,%rdx
   60897:	jne    606af <f.17+0x14df>
   6089d:	jmp    606a0 <f.17+0x14d0>
   608a2:	xor    %edx,%edx
   608a4:	div    %ecx
   608a6:	test   %rdx,%rdx
   608a9:	jne    6024f <f.17+0x107f>
   608af:	jmp    60240 <f.17+0x1070>
   608b4:	cmpq   $0x0,0x18(%rsp)
   608ba:	je     608cf <f.17+0x16ff>
   608bc:	mov    0x10(%rsp),%rax
   608c1:	mov    %rax,0x9f58(%rip)        # 6a820 <native_roots.0>
   608c8:	decq   0x9f31(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   608cf:	add    $0x68,%rsp
   608d3:	pop    %rbx
   608d4:	pop    %r12
   608d6:	pop    %r13
   608d8:	pop    %r14
   608da:	pop    %r15
   608dc:	pop    %rbp
   608dd:	ret    $0x8
   608e0:	call   56d70 <native_trap>
   608e5:	lea    -0x57498(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   608ec:	mov    $0x2f,%esi
   608f1:	call   57d70 <snail_runtime::native::fail_bytes>
   608f6:	lea    0x6cc3(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   608fd:	call   207b0 <core::panicking::panic_bounds_check>
   60902:	lea    0x6ccf(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   60909:	call   207b0 <core::panicking::panic_bounds_check>
   6090e:	int3
   6090f:	int3
