   60910:	push   %rbp
   60911:	push   %r15
   60913:	push   %r14
   60915:	push   %r13
   60917:	push   %r12
   60919:	push   %rbx
   6091a:	sub    $0x58,%rsp
   6091e:	mov    %rsi,%rbx
   60921:	movq   $0x5,0x20(%rsp)
   6092a:	movq   $0x0,0x28(%rsp)
   60933:	mov    0x9ee6(%rip),%rsi        # 6a820 <native_roots.0>
   6093a:	mov    %rsi,0x18(%rsp)
   6093f:	lea    0x18(%rsp),%rax
   60944:	mov    %rax,0x9ed5(%rip)        # 6a820 <native_roots.0>
   6094b:	mov    0x9eae(%rip),%rdx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   60952:	inc    %rdx
   60955:	mov    %rdx,0x9ea4(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   6095c:	mov    0x9ea5(%rip),%rax        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   60963:	cmp    %rax,%rdx
   60966:	cmova  %rdx,%rax
   6096a:	mov    %rax,0x9e97(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   60971:	mov    %rdi,0x30(%rsp)
   60976:	pxor   %xmm0,%xmm0
   6097a:	movdqu %xmm0,0x38(%rsp)
   60980:	test   %rdi,%rdi
   60983:	je     61006 <f.10+0x6f6>
   60989:	mov    %edi,%eax
   6098b:	and    $0x1,%eax
   6098e:	jne    61006 <f.10+0x6f6>
   60994:	mov    0x9e7d(%rip),%rax        # 6a818 <snail_runtime::native::RUNTIME>
   6099b:	test   %rax,%rax
   6099e:	je     61006 <f.10+0x6f6>
   609a4:	mov    (%rdi),%rcx
   609a7:	mov    %rcx,%r8
   609aa:	test   %rcx,%rcx
   609ad:	je     60a24 <f.10+0x114>
   609af:	mov    %rcx,%r8
   609b2:	cmp    $0x26,%rcx
   609b6:	je     60a24 <f.10+0x114>
   609b8:	mov    0x168(%rax),%r9
   609bf:	mov    %rcx,%r8
   609c2:	shr    $0x2,%r8
   609c6:	lea    -0x1(%r8),%r10
   609ca:	cmp    %r9,%r10
   609cd:	jae    61006 <f.10+0x6f6>
   609d3:	mov    0x160(%rax),%r10
   609da:	mov    -0x8(%r10,%r8,8),%r8
   609df:	test   %r8,%r8
   609e2:	je     60a24 <f.10+0x114>
   609e4:	cmp    $0x26,%r8
   609e8:	je     60a24 <f.10+0x114>
   609ea:	nopw   0x0(%rax,%rax,1)
   609f0:	shr    $0x2,%r8
   609f4:	lea    -0x1(%r8),%r11
   609f8:	cmp    %r9,%r11
   609fb:	jae    61006 <f.10+0x6f6>
   60a01:	mov    -0x8(%r10,%r8,8),%r8
   60a06:	cmp    $0x26,%r8
   60a0a:	je     60a24 <f.10+0x114>
   60a0c:	test   %r8,%r8
   60a0f:	jne    609f0 <f.10+0xe0>
   60a11:	jmp    60a24 <f.10+0x114>
   60a13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60a20:	add    $0x2,%rbx
   60a24:	cmp    $0x26,%r8
   60a28:	jne    61006 <f.10+0x6f6>
   60a2e:	cmp    %rbx,0x8(%rdi)
   60a32:	jl     60fe2 <f.10+0x6d2>
   60a38:	test   $0x1,%dil
   60a3c:	jne    61006 <f.10+0x6f6>
   60a42:	cmp    $0x26,%rcx
   60a46:	sete   %dl
   60a49:	mov    %edx,%r10d
   60a4c:	test   %rcx,%rcx
   60a4f:	je     60aa0 <f.10+0x190>
   60a51:	mov    %edx,%r10d
   60a54:	cmp    $0x26,%rcx
   60a58:	je     60aa0 <f.10+0x190>
   60a5a:	mov    0x168(%rax),%rsi
   60a61:	mov    %rcx,%r8
   60a64:	shr    $0x2,%r8
   60a68:	lea    -0x1(%r8),%r9
   60a6c:	cmp    %rsi,%r9
   60a6f:	jae    61006 <f.10+0x6f6>
   60a75:	mov    0x160(%rax),%r9
   60a7c:	mov    -0x8(%r9,%r8,8),%r8
   60a81:	cmp    $0x26,%r8
   60a85:	sete   %r10b
   60a89:	test   %r8,%r8
   60a8c:	je     60aa0 <f.10+0x190>
   60a8e:	cmp    $0x26,%r8
   60a92:	jne    60d10 <f.10+0x400>
   60a98:	nopl   0x0(%rax,%rax,1)
   60aa0:	test   %r10b,%r10b
   60aa3:	je     61006 <f.10+0x6f6>
   60aa9:	mov    0x18(%rdi),%rsi
   60aad:	test   %rsi,%rsi
   60ab0:	je     61006 <f.10+0x6f6>
   60ab6:	cmpl   $0x0,0x8(%rsi)
   60aba:	je     61006 <f.10+0x6f6>
   60ac0:	test   %rcx,%rcx
   60ac3:	je     60b10 <f.10+0x200>
   60ac5:	cmp    $0x26,%rcx
   60ac9:	je     60b10 <f.10+0x200>
   60acb:	mov    0x168(%rax),%rsi
   60ad2:	shr    $0x2,%rcx
   60ad6:	lea    -0x1(%rcx),%rdx
   60ada:	cmp    %rsi,%rdx
   60add:	jae    61006 <f.10+0x6f6>
   60ae3:	mov    0x160(%rax),%r8
   60aea:	mov    -0x8(%r8,%rcx,8),%rcx
   60aef:	cmp    $0x26,%rcx
   60af3:	sete   %dl
   60af6:	test   %rcx,%rcx
   60af9:	je     60b10 <f.10+0x200>
   60afb:	cmp    $0x26,%rcx
   60aff:	jne    60d40 <f.10+0x430>
   60b05:	data16 cs nopw 0x0(%rax,%rax,1)
   60b10:	test   %dl,%dl
   60b12:	je     61006 <f.10+0x6f6>
   60b18:	mov    %rdi,0x38(%rsp)
   60b1d:	mov    0x18(%rdi),%rcx
   60b21:	test   %rcx,%rcx
   60b24:	je     61006 <f.10+0x6f6>
   60b2a:	mov    0x10(%rcx),%rcx
   60b2e:	test   %rcx,%rcx
   60b31:	je     61006 <f.10+0x6f6>
   60b37:	mov    0x10(%rcx),%rcx
   60b3b:	test   %rcx,%rcx
   60b3e:	je     61006 <f.10+0x6f6>
   60b44:	mov    %ecx,%edx
   60b46:	and    $0x1,%edx
   60b49:	jne    61006 <f.10+0x6f6>
   60b4f:	mov    (%rcx),%rdx
   60b52:	test   %rdx,%rdx
   60b55:	je     60bc0 <f.10+0x2b0>
   60b57:	cmp    $0x2a,%rdx
   60b5b:	je     60bc0 <f.10+0x2b0>
   60b5d:	mov    0x168(%rax),%rsi
   60b64:	shr    $0x2,%rdx
   60b68:	lea    -0x1(%rdx),%rdi
   60b6c:	cmp    %rsi,%rdi
   60b6f:	jae    61006 <f.10+0x6f6>
   60b75:	mov    0x160(%rax),%rax
   60b7c:	mov    -0x8(%rax,%rdx,8),%rdx
   60b81:	test   %rdx,%rdx
   60b84:	je     60bc0 <f.10+0x2b0>
   60b86:	cmp    $0x2a,%rdx
   60b8a:	je     60bc0 <f.10+0x2b0>
   60b8c:	nopl   0x0(%rax)
   60b90:	shr    $0x2,%rdx
   60b94:	lea    -0x1(%rdx),%rdi
   60b98:	cmp    %rsi,%rdi
   60b9b:	jae    61006 <f.10+0x6f6>
   60ba1:	mov    -0x8(%rax,%rdx,8),%rdx
   60ba6:	cmp    $0x2a,%rdx
   60baa:	je     60bc0 <f.10+0x2b0>
   60bac:	test   %rdx,%rdx
   60baf:	jne    60b90 <f.10+0x280>
   60bb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60bc0:	cmp    $0x2a,%rdx
   60bc4:	jne    61006 <f.10+0x6f6>
   60bca:	mov    %rcx,0x40(%rsp)
   60bcf:	mov    0x18(%rcx),%rax
   60bd3:	test   %rax,%rax
   60bd6:	je     61006 <f.10+0x6f6>
   60bdc:	mov    0x8(%rax),%rax
   60be0:	test   %rax,%rax
   60be3:	je     61006 <f.10+0x6f6>
   60be9:	mov    0x8(%rax),%rdi
   60bed:	mov    %rdi,0x48(%rsp)
   60bf2:	movq   $0x4,0x28(%rsp)
   60bfb:	mov    %rbx,%rsi
   60bfe:	call   61040 <f.15>
   60c03:	sub    $0x8,%rsp
   60c07:	mov    %rax,%r14
   60c0a:	mov    0x40(%rsp),%rax
   60c0f:	test   %rax,%rax
   60c12:	je     61006 <f.10+0x6f6>
   60c18:	mov    0x8(%rax),%rbp
   60c1c:	mov    0x10(%rax),%r13
   60c20:	mov    %r13,0x48(%rsp)
   60c25:	mov    %rbp,0x50(%rsp)
   60c2a:	movq   $0x5,0x28(%rsp)
   60c33:	mov    0x9bde(%rip),%r15        # 6a818 <snail_runtime::native::RUNTIME>
   60c3a:	test   %r15,%r15
   60c3d:	je     61006 <f.10+0x6f6>
   60c43:	mov    0x178(%r15),%rcx
   60c4a:	test   %rcx,%rcx
   60c4d:	je     60c89 <f.10+0x379>
   60c4f:	mov    0x170(%r15),%rax
   60c56:	inc    %rax
   60c59:	mov    %rax,0x170(%r15)
   60c60:	mov    %rax,%rdx
   60c63:	or     %rcx,%rdx
   60c66:	shr    $0x20,%rdx
   60c6a:	je     60fd0 <f.10+0x6c0>
   60c70:	xor    %edx,%edx
   60c72:	div    %rcx
   60c75:	test   %rdx,%rdx
   60c78:	jne    60c89 <f.10+0x379>
   60c7a:	mov    0x9b9f(%rip),%rsi        # 6a820 <native_roots.0>
   60c81:	mov    %r15,%rdi
   60c84:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   60c89:	cmpq   $0x30,0x98(%r15)
   60c91:	jb     6100b <f.10+0x6fb>
   60c97:	mov    %rbx,0x8(%rsp)
   60c9c:	mov    0x9b7d(%rip),%rax        # 6a820 <native_roots.0>
   60ca3:	mov    %rax,0x10(%rsp)
   60ca8:	mov    0xe0(%r15),%rbx
   60caf:	mov    0xe8(%r15),%r12
   60cb6:	cmp    %r12,%rbx
   60cb9:	jb     60cc8 <f.10+0x3b8>
   60cbb:	mov    %r15,%rdi
   60cbe:	mov    0x10(%rsp),%rsi
   60cc3:	call   58c80 <snail_runtime::native_gc::Collector::collect>
   60cc8:	mov    0xc8(%r15),%rdx
   60ccf:	test   %rdx,%rdx
   60cd2:	je     60ce8 <f.10+0x3d8>
   60cd4:	mov    0xd0(%r15),%rax
   60cdb:	sub    %rdx,%rax
   60cde:	cmp    $0x2f,%rax
   60ce2:	ja     60d70 <f.10+0x460>
   60ce8:	mov    $0x30,%esi
   60ced:	mov    %r15,%rdi
   60cf0:	call   584e0 <snail_runtime::native_gc::Collector::allocate_slow>
   60cf5:	cmp    $0x1,%rax
   60cf9:	jne    60dee <f.10+0x4de>
   60cff:	mov    $0x1,%eax
   60d04:	jmp    60e08 <f.10+0x4f8>
   60d09:	nopl   0x0(%rax)
   60d10:	shr    $0x2,%r8
   60d14:	lea    -0x1(%r8),%r10
   60d18:	cmp    %rsi,%r10
   60d1b:	jae    61006 <f.10+0x6f6>
   60d21:	mov    -0x8(%r9,%r8,8),%r8
   60d26:	cmp    $0x26,%r8
   60d2a:	je     60d31 <f.10+0x421>
   60d2c:	test   %r8,%r8
   60d2f:	jne    60d10 <f.10+0x400>
   60d31:	cmp    $0x26,%r8
   60d35:	je     60aa9 <f.10+0x199>
   60d3b:	jmp    61006 <f.10+0x6f6>
   60d40:	shr    $0x2,%rcx
   60d44:	lea    -0x1(%rcx),%rdx
   60d48:	cmp    %rsi,%rdx
   60d4b:	jae    61006 <f.10+0x6f6>
   60d51:	mov    -0x8(%r8,%rcx,8),%rcx
   60d56:	cmp    $0x26,%rcx
   60d5a:	je     60d61 <f.10+0x451>
   60d5c:	test   %rcx,%rcx
   60d5f:	jne    60d40 <f.10+0x430>
   60d61:	cmp    $0x26,%rcx
   60d65:	je     60b18 <f.10+0x208>
   60d6b:	jmp    61006 <f.10+0x6f6>
   60d70:	lea    0x30(%rdx),%rax
   60d74:	mov    %rax,0xc8(%r15)
   60d7b:	mov    0x10(%r15),%rsi
   60d7f:	mov    0xc0(%r15),%rdi
   60d86:	cmp    %rsi,%rdi
   60d89:	jae    6101c <f.10+0x70c>
   60d8f:	mov    0x8(%r15),%rax
   60d93:	imul   $0x38,%rdi,%rcx
   60d97:	mov    %rdx,%r8
   60d9a:	sub    0x18(%rax,%rcx,1),%r8
   60d9f:	mov    %r8,%rdi
   60da2:	shr    $0xf,%rdi
   60da6:	mov    0x10(%rax,%rcx,1),%rsi
   60dab:	cmp    %rsi,%rdi
   60dae:	jae    61028 <f.10+0x718>
   60db4:	add    %rcx,%rax
   60db7:	mov    %r8d,%ecx
   60dba:	imul   $0x220,%rdi,%rsi
   60dc1:	add    0x8(%rax),%rsi
   60dc5:	shr    $0x4,%ecx
   60dc8:	mov    $0x1,%eax
   60dcd:	mov    $0x1,%edi
   60dd2:	shl    %cl,%rdi
   60dd5:	shr    $0x7,%r8d
   60dd9:	and    $0xf8,%r8d
   60de0:	or     %rdi,(%r8,%rsi,1)
   60de4:	cmp    $0x1,%rax
   60de8:	je     60cff <f.10+0x3ef>
   60dee:	xor    %edx,%edx
   60df0:	cmp    %r12,%rbx
   60df3:	setae  %dl
   60df6:	mov    $0x30,%esi
   60dfb:	mov    %r15,%rdi
   60dfe:	mov    0x10(%rsp),%rcx
   60e03:	call   589e0 <snail_runtime::native_gc::Collector::retry_allocation>
   60e08:	mov    0x8(%rsp),%rbx
   60e0d:	test   $0x1,%al
   60e0f:	je     6100b <f.10+0x6fb>
   60e15:	movq   $0x81,(%rdx)
   60e1c:	lea    0x8(%rdx),%rdi
   60e20:	pxor   %xmm0,%xmm0
   60e24:	movdqu %xmm0,0x8(%rdx)
   60e29:	movdqu %xmm0,0x18(%rdx)
   60e2e:	addq   $0x30,0xe0(%r15)
   60e36:	movdqu 0x110(%r15),%xmm0
   60e3f:	paddq  -0x5cad7(%rip),%xmm0        # 4370 <__abi_tag+0x403c>
   60e47:	movdqu %xmm0,0x110(%r15)
   60e50:	movq   $0x22,0x8(%rdx)
   60e58:	mov    %rbp,0x10(%rdx)
   60e5c:	mov    %r13,0x18(%rdx)
   60e60:	mov    %rbx,0x20(%rdx)
   60e64:	mov    %rdi,0x48(%rsp)
   60e69:	movq   $0x4,0x28(%rsp)
   60e72:	mov    %r14,%rsi
   60e75:	call   61e40 <f.12>
   60e7a:	sub    $0x8,%rsp
   60e7e:	mov    0x38(%rsp),%rdi
   60e83:	test   %rdi,%rdi
   60e86:	je     61006 <f.10+0x6f6>
   60e8c:	mov    0x10(%rdi),%rax
   60e90:	test   %rax,%rax
   60e93:	je     61006 <f.10+0x6f6>
   60e99:	cmpl   $0x0,0x8(%rax)
   60e9d:	je     61006 <f.10+0x6f6>
   60ea3:	cmpq   $0x0,0x10(%rax)
   60ea8:	je     61006 <f.10+0x6f6>
   60eae:	xor    %edx,%edx
   60eb0:	cmpq   $0x0,0x20(%rsp)
   60eb6:	sete   %dl
   60eb9:	lea    0x18(%rsp),%rcx
   60ebe:	mov    %rcx,%rax
   60ec1:	lea    0x9958(%rip),%rsi        # 6a820 <native_roots.0>
   60ec8:	cmove  %rsi,%rax
   60ecc:	add    0x992d(%rip),%rdx        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   60ed3:	mov    (%rax),%rsi
   60ed6:	movq   $0x5,0x20(%rsp)
   60edf:	movq   $0x0,0x28(%rsp)
   60ee8:	mov    %rsi,0x18(%rsp)
   60eed:	mov    %rcx,0x992c(%rip)        # 6a820 <native_roots.0>
   60ef4:	mov    %rdx,0x9905(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   60efb:	mov    0x9906(%rip),%rax        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   60f02:	cmp    %rax,%rdx
   60f05:	cmova  %rdx,%rax
   60f09:	mov    %rax,0x98f8(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   60f10:	mov    %rdi,0x30(%rsp)
   60f15:	lea    0x38(%rsp),%rax
   60f1a:	pxor   %xmm0,%xmm0
   60f1e:	movdqu %xmm0,(%rax)
   60f22:	test   $0x1,%dil
   60f26:	jne    61006 <f.10+0x6f6>
   60f2c:	mov    0x98e5(%rip),%rax        # 6a818 <snail_runtime::native::RUNTIME>
   60f33:	test   %rax,%rax
   60f36:	je     61006 <f.10+0x6f6>
   60f3c:	mov    (%rdi),%rcx
   60f3f:	mov    %rcx,%r8
   60f42:	test   %rcx,%rcx
   60f45:	je     60a20 <f.10+0x110>
   60f4b:	mov    %rcx,%r8
   60f4e:	cmp    $0x26,%rcx
   60f52:	je     60a20 <f.10+0x110>
   60f58:	mov    0x168(%rax),%r9
   60f5f:	mov    %rcx,%r8
   60f62:	shr    $0x2,%r8
   60f66:	lea    -0x1(%r8),%r10
   60f6a:	cmp    %r9,%r10
   60f6d:	jae    61006 <f.10+0x6f6>
   60f73:	mov    0x160(%rax),%r10
   60f7a:	mov    -0x8(%r10,%r8,8),%r8
   60f7f:	test   %r8,%r8
   60f82:	je     60a20 <f.10+0x110>
   60f88:	cmp    $0x26,%r8
   60f8c:	je     60a20 <f.10+0x110>
   60f92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   60fa0:	shr    $0x2,%r8
   60fa4:	lea    -0x1(%r8),%r11
   60fa8:	cmp    %r9,%r11
   60fab:	jae    61006 <f.10+0x6f6>
   60fad:	mov    -0x8(%r10,%r8,8),%r8
   60fb2:	cmp    $0x26,%r8
   60fb6:	je     60a20 <f.10+0x110>
   60fbc:	test   %r8,%r8
   60fbf:	jne    60fa0 <f.10+0x690>
   60fc1:	jmp    60a20 <f.10+0x110>
   60fc6:	cs nopw 0x0(%rax,%rax,1)
   60fd0:	xor    %edx,%edx
   60fd2:	div    %ecx
   60fd4:	test   %rdx,%rdx
   60fd7:	jne    60c89 <f.10+0x379>
   60fdd:	jmp    60c7a <f.10+0x36a>
   60fe2:	mov    %rsi,0x9837(%rip)        # 6a820 <native_roots.0>
   60fe9:	dec    %rdx
   60fec:	mov    %rdx,0x980d(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   60ff3:	xor    %eax,%eax
   60ff5:	add    $0x58,%rsp
   60ff9:	pop    %rbx
   60ffa:	pop    %r12
   60ffc:	pop    %r13
   60ffe:	pop    %r14
   61000:	pop    %r15
   61002:	pop    %rbp
   61003:	ret    $0x8
   61006:	call   56d70 <native_trap>
   6100b:	lea    -0x57bbe(%rip),%rdi        # 9454 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   61012:	mov    $0x2f,%esi
   61017:	call   57d70 <snail_runtime::native::fail_bytes>
   6101c:	lea    0x659d(%rip),%rdx        # 675c0 <__cxa_atexit@plt+0x1f00>
   61023:	call   207b0 <core::panicking::panic_bounds_check>
   61028:	lea    0x65a9(%rip),%rdx        # 675d8 <__cxa_atexit@plt+0x1f18>
   6102f:	call   207b0 <core::panicking::panic_bounds_check>
   61034:	int3
   61035:	int3
   61036:	int3
   61037:	int3
   61038:	int3
   61039:	int3
   6103a:	int3
   6103b:	int3
   6103c:	int3
   6103d:	int3
   6103e:	int3
   6103f:	int3
