   655d0:	movq   $0x1,-0x18(%rsp)
   655d9:	mov    0x5240(%rip),%rax        # 6a820 <native_roots.0>
   655e0:	mov    %rax,-0x20(%rsp)
   655e5:	lea    -0x20(%rsp),%rax
   655ea:	mov    %rax,0x522f(%rip)        # 6a820 <native_roots.0>
   655f1:	mov    0x5208(%rip),%rax        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   655f8:	inc    %rax
   655fb:	mov    %rax,0x51fe(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   65602:	mov    0x51ff(%rip),%rcx        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   65609:	cmp    %rcx,%rax
   6560c:	cmovbe %rcx,%rax
   65610:	mov    %rax,0x51f1(%rip)        # 6a808 <snail_runtime::native::PEAK_ROOT_DEPTH>
   65617:	mov    %rdi,-0x8(%rsp)
   6561c:	movq   $0x1,-0x10(%rsp)
   65625:	mov    %rdx,-0x28(%rsp)
   6562a:	lea    -0x28(%rsp),%rax
   6562f:	mov    -0x28(%rsp),%rax
   65634:	cmpq   $0x0,-0x18(%rsp)
   6563a:	je     6564f <f.6+0x7f>
   6563c:	mov    -0x20(%rsp),%rcx
   65641:	mov    %rcx,0x51d8(%rip)        # 6a820 <native_roots.0>
   65648:	decq   0x51b1(%rip)        # 6a800 <snail_runtime::native::ROOT_DEPTH>
   6564f:	ret    $0x8
   65652:	int3
   65653:	int3
   65654:	int3
   65655:	int3
   65656:	int3
   65657:	int3
   65658:	int3
   65659:	int3
   6565a:	int3
   6565b:	int3
   6565c:	int3
   6565d:	int3
   6565e:	int3
   6565f:	int3
