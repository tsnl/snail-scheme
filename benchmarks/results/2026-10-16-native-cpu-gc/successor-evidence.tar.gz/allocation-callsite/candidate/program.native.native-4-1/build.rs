fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-alloc-callsite-20261016/candidate/program.native.native-4-1/module.bc");
}
