unsafe extern "C" { fn native_module_init(); #[link_name = "wasm.main"] fn guest_main() -> i32; }
fn main() {
    snail_runtime::native::initialize_host();
    unsafe { native_module_init(); }
    let value = unsafe { guest_main() } as i64;
    let status = if (0..=255).contains(&value) { value as i32 } else { 1 };
    std::process::exit(snail_runtime::native::native_finish(status));
}

extern crate snail_runtime as _;
extern crate wasm_native_2505a5ae8158a6167e3aa0dba58b58af7a93c090866ebb6bcde7b5e43b59d18b_provider_0 as _;
