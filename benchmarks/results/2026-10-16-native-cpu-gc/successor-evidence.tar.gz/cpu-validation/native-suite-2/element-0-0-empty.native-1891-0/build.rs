fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/native-suite-2/element-0-0-empty.native-1891-0/module.bc");
}
