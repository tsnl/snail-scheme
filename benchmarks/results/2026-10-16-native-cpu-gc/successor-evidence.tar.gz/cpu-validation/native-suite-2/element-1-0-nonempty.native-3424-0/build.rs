fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/native-suite-2/element-1-0-nonempty.native-3424-0/module.bc");
}
