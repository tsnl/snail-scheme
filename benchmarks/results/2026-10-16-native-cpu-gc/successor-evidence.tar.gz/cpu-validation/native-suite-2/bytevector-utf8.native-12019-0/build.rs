fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/native-suite-2/bytevector-utf8.native-12019-0/module.bc");
}
