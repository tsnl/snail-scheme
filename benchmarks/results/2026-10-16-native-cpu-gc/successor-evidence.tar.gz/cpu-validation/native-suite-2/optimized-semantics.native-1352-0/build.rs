fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/native-suite-2/optimized-semantics.native-1352-0/module.bc");
}
