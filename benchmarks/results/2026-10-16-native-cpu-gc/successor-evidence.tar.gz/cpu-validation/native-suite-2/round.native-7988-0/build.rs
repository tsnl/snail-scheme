fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/native-suite-2/round.native-7988-0/module.bc");
}
