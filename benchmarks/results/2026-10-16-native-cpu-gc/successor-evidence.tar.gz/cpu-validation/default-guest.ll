; ModuleID = '/tmp/snail-native-cpu-option-20261016/wasm-native/build/standalone-2-0/module.bc'
source_filename = "/tmp/snail-native-cpu-option-20261016/wasm-native/build/standalone-2-0/module.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@g.0 = internal global i64 0
@native_gc_parents_count = local_unnamed_addr constant i64 4
@native_gc_parents = local_unnamed_addr constant [4 x i64] zeroinitializer
@gc.fields.0 = private constant [1 x i32] [i32 2]
@gc.fields.1 = private constant [0 x i32] poison
@gc.fields.2 = private constant [0 x i32] poison
@gc.fields.3 = private constant [0 x i32] poison
@native_gc_layouts_count = local_unnamed_addr constant i64 4
@native_gc_layouts = local_unnamed_addr constant [4 x { i32, i32, ptr }] [{ i32, i32, ptr } { i32 1, i32 1, ptr @gc.fields.0 }, { i32, i32, ptr } { i32 1, i32 0, ptr @gc.fields.1 }, { i32, i32, ptr } { i32 1, i32 0, ptr @gc.fields.2 }, { i32, i32, ptr } { i32 1, i32 0, ptr @gc.fields.3 }]
@native_gc_globals_count = local_unnamed_addr constant i64 1
@native_gc_globals = local_unnamed_addr constant [1 x ptr] [ptr @g.0]
@native_gc_tables_count = local_unnamed_addr constant i64 0
@native_gc_tables = local_unnamed_addr constant [0 x ptr] poison

declare void @native_roots_enter(ptr, i64) local_unnamed_addr

declare void @native_roots_leave(ptr) local_unnamed_addr

; Function Attrs: cold noreturn
declare void @native_trap() local_unnamed_addr #0

declare i64 @native_alloc(i64) local_unnamed_addr

declare i64 @example_hide(i64) local_unnamed_addr

define i64 @wasm-global.root() local_unnamed_addr {
entry:
  %roots = alloca { ptr, i64, i64, [0 x i64] }, align 8
  call void @native_roots_enter(ptr nonnull %roots, i64 0)
  %v1 = load i64, ptr @g.0, align 8
  call void @native_roots_leave(ptr nonnull %roots)
  ret i64 %v1
}

define i64 @wasm.run(i64 %arg0) local_unnamed_addr {
entry:
  %roots.i.i = alloca { ptr, i64, i64, [0 x i64] }, align 8
  %roots.i = alloca { ptr, i64, i64, [1 x i64] }, align 8
  %roots = alloca { ptr, i64, i64, [0 x i64] }, align 8
  call void @native_roots_enter(ptr nonnull %roots, i64 0)
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %v1, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %roots.i)
  call void @native_roots_enter(ptr nonnull %roots.i, i64 1)
  %v5.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 16
  store i64 0, ptr %v5.i, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %roots.i.i)
  call void @native_roots_enter(ptr nonnull %roots.i.i, i64 0)
  %v1.i.i = getelementptr inbounds nuw i8, ptr %roots.i.i, i64 16
  store i64 0, ptr %v1.i.i, align 8
  %v2.i.i = call i64 @example_hide(i64 %arg0)
  call void @native_roots_leave(ptr nonnull %roots.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %roots.i.i)
  %v8.i = load i64, ptr @g.0, align 8
  %v9.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 24
  store i64 %v8.i, ptr %v9.i, align 8
  store i64 1, ptr %v5.i, align 8
  %v11.i = call i64 @native_alloc(i64 24)
  %v12.not.i = icmp eq i64 %v11.i, 0
  br i1 %v12.not.i, label %trap13.i, label %f.1.exit

trap13.i:                                         ; preds = %entry
  call void @native_trap()
  unreachable

f.1.exit:                                         ; preds = %entry
  %v7.i = add i64 %v2.i.i, 2
  %v15.i = inttoptr i64 %v11.i to ptr
  store i64 6, ptr %v15.i, align 1
  %v21.i = getelementptr i8, ptr %v15.i, i64 8
  store i64 %v7.i, ptr %v21.i, align 1
  %v26.i = getelementptr i8, ptr %v15.i, i64 16
  store i64 %v8.i, ptr %v26.i, align 1
  store i64 %v11.i, ptr @g.0, align 8
  %v33.i = load i64, ptr %v21.i, align 1
  call void @native_roots_leave(ptr nonnull %roots.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %roots.i)
  call void @native_roots_leave(ptr nonnull %roots)
  ret i64 %v33.i
}

define i64 @wasm.previous() local_unnamed_addr {
entry:
  %roots = alloca { ptr, i64, i64, [0 x i64] }, align 8
  call void @native_roots_enter(ptr nonnull %roots, i64 0)
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %v1, align 8
  %v3.i = load i64, ptr @g.0, align 8
  %v4.not.i = icmp eq i64 %v3.i, 0
  br i1 %v4.not.i, label %trap5.i, label %ok6.i

trap5.i:                                          ; preds = %entry
  call void @native_trap()
  unreachable

ok6.i:                                            ; preds = %entry
  %v7.i = inttoptr i64 %v3.i to ptr
  %v8.i = getelementptr i8, ptr %v7.i, i64 16
  %v9.i = load i64, ptr %v8.i, align 1
  %v10.not.i = icmp eq i64 %v9.i, 0
  br i1 %v10.not.i, label %trap11.i, label %f.2.exit

trap11.i:                                         ; preds = %ok6.i
  call void @native_trap()
  unreachable

f.2.exit:                                         ; preds = %ok6.i
  %v13.i = inttoptr i64 %v9.i to ptr
  %v14.i = getelementptr i8, ptr %v13.i, i64 8
  %v15.i = load i64, ptr %v14.i, align 1
  call void @native_roots_leave(ptr nonnull %roots)
  ret i64 %v15.i
}

define i64 @wasm.take-root() local_unnamed_addr {
entry:
  %roots.i.i = alloca { ptr, i64, i64, [0 x i64] }, align 8
  %roots.i = alloca { ptr, i64, i64, [2 x i64] }, align 8
  %roots = alloca { ptr, i64, i64, [0 x i64] }, align 8
  call void @native_roots_enter(ptr nonnull %roots, i64 0)
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %v1, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %roots.i)
  call void @native_roots_enter(ptr nonnull %roots.i, i64 2)
  %v1.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 24
  %v2.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 32
  store i64 0, ptr %v1.i, align 8
  %v7.i = load i64, ptr @g.0, align 8
  store i64 %v7.i, ptr %v2.i, align 8
  store i64 0, ptr @g.0, align 8
  %v8.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 16
  store i64 2, ptr %v8.i, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %roots.i.i)
  call void @native_roots_enter(ptr nonnull %roots.i.i, i64 0)
  %v1.i.i = getelementptr inbounds nuw i8, ptr %roots.i.i, i64 16
  store i64 0, ptr %v1.i.i, align 8
  %v2.i.i = call i64 @example_hide(i64 0)
  call void @native_roots_leave(ptr nonnull %roots.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %roots.i.i)
  %v10.i = load i64, ptr %v2.i, align 8
  %v12.not.i = icmp eq i64 %v10.i, 0
  br i1 %v12.not.i, label %trap13.i, label %f.3.exit

trap13.i:                                         ; preds = %entry
  call void @native_trap()
  unreachable

f.3.exit:                                         ; preds = %entry
  %v15.i = inttoptr i64 %v10.i to ptr
  %v16.i = getelementptr i8, ptr %v15.i, i64 8
  %v17.i = load i64, ptr %v16.i, align 1
  call void @native_roots_leave(ptr nonnull %roots.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %roots.i)
  call void @native_roots_leave(ptr nonnull %roots)
  ret i64 %v17.i
}

; Function Attrs: cold noreturn
define void @wasm.trap() local_unnamed_addr #0 {
entry:
  %roots = alloca { ptr, i64, i64, [0 x i64] }, align 8
  call void @native_roots_enter(ptr nonnull %roots, i64 0)
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %v1, align 8
  call void @native_trap()
  unreachable
}

define void @native_module_init() local_unnamed_addr {
entry:
  %roots = alloca { ptr, i64, i64, [0 x i64] }, align 8
  call void @native_roots_enter(ptr nonnull %roots, i64 0)
  call void @native_roots_leave(ptr nonnull %roots)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

attributes #0 = { cold noreturn }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
