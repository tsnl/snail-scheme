; ModuleID = '/tmp/snail-native-cpu-option-20261016/wasm-native/build/native-programs/x86_64-unknown-linux-gnu/release/deps/e3c1ac4bc10df265-d3e8529.wasm_native_b7a126c3cc5ef8eeb061504ad475ced3d621e87b9bcd5f0a48b0728806bf3dbc_provider_0.6f6d154e97766edc-cgu.0.rcgu.bc'
source_filename = "wasm_native_b7a126c3cc5ef8eeb061504ad475ced3d621e87b9bcd5f0a48b0728806bf3dbc_provider_0.6f6d154e97766edc-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nounwind nonlazybind uwtable
define noundef i64 @example_hide(i64 noundef %0) unnamed_addr #0 {
  %2 = alloca [8 x i8], align 8
  tail call void @native_gc_collect() #2
  call void @llvm.lifetime.start.p0(ptr nonnull %2)
  store i64 %0, ptr %2, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %2) #2, !srcloc !3
  %3 = load i64, ptr %2, align 8, !noundef !4
  call void @llvm.lifetime.end.p0(ptr nonnull %2)
  ret i64 %3
}

; Function Attrs: nounwind nonlazybind uwtable
declare void @native_gc_collect() unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

attributes #0 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 2, !"RtLibUseGOT", i32 1}
!2 = !{!"rustc version 1.95.0 (59807616e 2026-04-14)"}
!3 = !{i64 1258305158936649}
!4 = !{}
