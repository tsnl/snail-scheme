; ModuleID = '/tmp/snail-native-cpu-option-20261016/wasm-native/build/native-programs/x86_64-unknown-linux-gnu/release/deps/ea86919bc8569075-5c971325848.wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf.d4a9892edf139057-cgu.0.rcgu.no-opt.bc'
source_filename = "wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf.d4a9892edf139057-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@0 = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1
@1 = private unnamed_addr constant [115 x i8] c"/home/nti/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs\00", align 1
@2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @1, [16 x i8] c"r\00\00\00\00\00\00\00\B9\03\00\00 \00\00\00" }>, align 8
@3 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN4core3ops8function6FnOnce40call_once$u7b$$u7b$vtable.shim$u7d$$u7d$17h85bde0790c2517dfE", ptr @"_ZN3std2rt10lang_start28_$u7b$$u7b$closure$u7d$$u7d$17h7a7b080b6c12358bE", ptr @"_ZN3std2rt10lang_start28_$u7b$$u7b$closure$u7d$$u7d$17h7a7b080b6c12358bE" }>, align 8
@4 = private unnamed_addr constant [40 x i8] c"there is no such thing as a release load", align 1
@5 = private unnamed_addr constant [114 x i8] c"/home/nti/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/sync/atomic.rs\00", align 1
@6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @5, [16 x i8] c"q\00\00\00\00\00\00\005\0F\00\00\18\00\00\00" }>, align 8
@7 = private unnamed_addr constant [49 x i8] c"there is no such thing as an acquire-release load", align 1
@8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @5, [16 x i8] c"q\00\00\00\00\00\00\006\0F\00\00\17\00\00\00" }>, align 8
@9 = private unnamed_addr constant [42 x i8] c"there is no such thing as an acquire store", align 1
@10 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @5, [16 x i8] c"q\00\00\00\00\00\00\00&\0F\00\00\18\00\00\00" }>, align 8
@11 = private unnamed_addr constant [50 x i8] c"there is no such thing as an acquire-release store", align 1
@12 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @5, [16 x i8] c"q\00\00\00\00\00\00\00'\0F\00\00\17\00\00\00" }>, align 8
@13 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h0ed91271bd9e113cE" }>, align 8
@14 = private unnamed_addr constant <{ [8 x i8], [8 x i8] }> <{ [8 x i8] zeroinitializer, [8 x i8] undef }>, align 8
@15 = private unnamed_addr constant [125 x i8] c"/home/nti/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/iter/traits/exact_size.rs\00", align 1
@16 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @15, [16 x i8] c"|\00\00\00\00\00\00\00z\00\00\00\09\00\00\00" }>, align 8
@17 = private unnamed_addr constant [8 x i8] c"\03\00\00\00\00\00\00\00", align 8
@18 = private unnamed_addr constant [58 x i8] c"assertion failed: native::native_gc_collections() > before", align 1
@19 = private unnamed_addr constant [83 x i8] c"/tmp/snail-native-cpu-option-20261016/wasm-native/tests/.snail-native-entry-2-0.rs\00", align 1
@20 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\00&\00\00\00\09\00\00\00" }>, align 8
@21 = private unnamed_addr constant [51 x i8] c"assertion failed: RECLAIMED.load(Ordering::Relaxed)", align 1
@22 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\00)\00\00\00\09\00\00\00" }>, align 8
@native_roots = external global ptr
@23 = private unnamed_addr constant [48 x i8] c"assertion failed: native::native_roots.is_null()", align 1
@24 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\00*\00\00\00\09\00\00\00" }>, align 8
@25 = private unnamed_addr constant [52 x i8] c"assertion failed: !RECLAIMED.load(Ordering::Relaxed)", align 1
@26 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\00'\00\00\00\09\00\00\00" }>, align 8
@27 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\00%\00\00\00\09\00\00\00" }>, align 8
@28 = private unnamed_addr constant [4 x i8] c"trap", align 1
@29 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @28, [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@30 = private unnamed_addr constant [8 x i8] c"*\00\00\00\00\00\00\00", align 8
@31 = private unnamed_addr constant [3 x i8] c"42\0A", align 1
@32 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\007\00\00\00\05\00\00\00" }>, align 8
@33 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\006\00\00\00\05\00\00\00" }>, align 8
@34 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @19, [16 x i8] c"R\00\00\00\00\00\00\005\00\00\00\05\00\00\00" }>, align 8
@_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf9RECLAIMED17ha15bf2b8a0879b61E = internal global [1 x i8] zeroinitializer, align 1

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef zeroext i1 @_RNvXsR_NtNtCsgEmfK2I1SDS_4core3fmt3numxNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %0, ptr noalias noundef align 8 dereferenceable(24) %1) unnamed_addr #0 {
  %3 = alloca [1 x i8], align 1
  %4 = getelementptr inbounds i8, ptr %1, i64 16
  %5 = load i32, ptr %4, align 8, !noundef !4
  %6 = and i32 %5, 33554432
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %8, label %13

8:                                                ; preds = %2
  %9 = getelementptr inbounds i8, ptr %1, i64 16
  %10 = load i32, ptr %9, align 8, !noundef !4
  %11 = and i32 %10, 67108864
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %16, label %19

13:                                               ; preds = %2
  %14 = call noundef zeroext i1 @_RNvXsD_NtNtCsgEmfK2I1SDS_4core3fmt3numxNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %0, ptr noalias noundef align 8 dereferenceable(24) %1) #13
  %15 = zext i1 %14 to i8
  store i8 %15, ptr %3, align 1
  br label %23

16:                                               ; preds = %8
  %17 = call noundef zeroext i1 @_RNvXse_NtNtNtCsgEmfK2I1SDS_4core3fmt3num3impxNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %0, ptr noalias noundef align 8 dereferenceable(24) %1) #13
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %3, align 1
  br label %22

19:                                               ; preds = %8
  %20 = call noundef zeroext i1 @_RNvXsF_NtNtCsgEmfK2I1SDS_4core3fmt3numxNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %0, ptr noalias noundef align 8 dereferenceable(24) %1) #13
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %3, align 1
  br label %22

22:                                               ; preds = %19, %16
  br label %23

23:                                               ; preds = %22, %13
  %24 = load i8, ptr %3, align 1, !range !5, !noundef !4
  %25 = trunc nuw i8 %24 to i1
  ret i1 %25
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i8 @_RNvXsZ_NtCsjrHSEGnQ3l9_3std7processuNtB5_11Termination6report() unnamed_addr #0 {
  ret i8 0
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvXs_NtCslNYArtu3iFV_5alloc5allocNtB4_6GlobalNtNtCsgEmfK2I1SDS_4core5alloc9Allocator10deallocate(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %0, ptr noundef nonnull %1, i64 noundef range(i64 1, -9223372036854775807) %2, i64 noundef %3) unnamed_addr #0 {
  %5 = icmp eq i64 %3, 0
  br i1 %5, label %6, label %7

6:                                                ; preds = %7, %4
  ret void

7:                                                ; preds = %4
  %8 = icmp ne ptr %1, null
  call void @llvm.assume(i1 %8)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef %1, i64 noundef %3, i64 noundef %2) #13
  br label %6
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$9size_hint17he244edca7f20423cE"(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24) %0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %1) unnamed_addr #0 {
  %3 = alloca [8 x i8], align 8
  br label %4

4:                                                ; preds = %2
  %5 = getelementptr inbounds i8, ptr %1, i64 24
  %6 = load ptr, ptr %5, align 8, !nonnull !4, !noundef !4
  %7 = getelementptr inbounds i8, ptr %1, i64 8
  %8 = load ptr, ptr %7, align 8, !nonnull !4, !noundef !4
  %9 = icmp ne ptr %6, null
  call void @llvm.assume(i1 %9)
  %10 = icmp ne ptr %8, null
  call void @llvm.assume(i1 %10)
  %11 = icmp ne ptr %6, null
  call void @llvm.assume(i1 %11)
  br label %12

12:                                               ; preds = %4
  br label %13

13:                                               ; preds = %12
  br label %14

14:                                               ; preds = %13
  %15 = ptrtoint ptr %6 to i64
  %16 = ptrtoint ptr %8 to i64
  %17 = sub nuw i64 %15, %16
  %18 = udiv exact i64 %17, 24
  store i64 %18, ptr %3, align 8
  br label %20

19:                                               ; No predecessors!
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking5panic(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @0, i64 noundef 73, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @2) #14
  unreachable

20:                                               ; preds = %14
  %21 = load i64, ptr %3, align 8, !noundef !4
  %22 = load i64, ptr %3, align 8, !noundef !4
  store i64 %21, ptr %0, align 8
  %23 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 1, ptr %23, align 8
  %24 = getelementptr inbounds i8, ptr %23, i64 8
  store i64 %22, ptr %24, align 8
  ret void

25:                                               ; No predecessors!
  unreachable

26:                                               ; No predecessors!
  unreachable

27:                                               ; No predecessors!
  unreachable
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i64 @"_ZN145_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..option..Option$LT$core..convert..Infallible$GT$$GT$$GT$13from_residual17hebc962e0860f82aaE"() unnamed_addr #0 {
  call void @llvm.assume(i1 true)
  ret i64 0
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN157_$LT$$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$..drop..DropGuard$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17h7e178579a2bf6409E"(ptr noalias noundef align 8 dereferenceable(8) %0) unnamed_addr #1 {
  %2 = alloca [8 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %4 = load ptr, ptr %0, align 8, !nonnull !4, !align !6, !noundef !4
  call void @llvm.lifetime.start.p0(ptr %3)
  %5 = load ptr, ptr %0, align 8, !nonnull !4, !align !6, !noundef !4
  %6 = load ptr, ptr %5, align 8, !nonnull !4, !noundef !4
  %7 = load ptr, ptr %0, align 8, !nonnull !4, !align !6, !noundef !4
  %8 = getelementptr inbounds i8, ptr %7, i64 16
  %9 = load i64, ptr %8, align 8, !noundef !4
  call void @llvm.lifetime.start.p0(ptr %2)
  br label %10

10:                                               ; preds = %1
  store i64 %9, ptr %2, align 8
  br label %11

11:                                               ; preds = %10
  %12 = load i64, ptr %2, align 8, !range !7, !noundef !4
  store i64 %12, ptr %3, align 8
  %13 = getelementptr inbounds i8, ptr %3, i64 8
  store ptr %6, ptr %13, align 8
  call void @llvm.lifetime.end.p0(ptr %2)
  call void @"_ZN4core3ptr77drop_in_place$LT$alloc..raw_vec..RawVec$LT$std..ffi..os_str..OsString$GT$$GT$17hf5d20a1534306527E"(ptr noalias noundef align 8 dereferenceable(16) %3) #13
  call void @llvm.lifetime.end.p0(ptr %3)
  ret void

14:                                               ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
define hidden noundef i64 @_ZN3std2rt10lang_start17h488d9eea15142c0dE(ptr noundef nonnull %0, i64 noundef %1, ptr noundef %2, i8 noundef %3) unnamed_addr #1 {
  %5 = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr %5)
  store ptr %0, ptr %5, align 8
  %6 = call noundef i64 @_RNvNtCsjrHSEGnQ3l9_3std2rt19lang_start_internal(ptr noundef nonnull align 1 %5, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48) @3, i64 noundef %1, ptr noundef %2, i8 noundef %3) #13
  call void @llvm.lifetime.end.p0(ptr %5)
  ret i64 %6
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i32 @"_ZN3std2rt10lang_start28_$u7b$$u7b$closure$u7d$$u7d$17h7a7b080b6c12358bE"(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %0) unnamed_addr #0 {
  %2 = load ptr, ptr %0, align 8, !nonnull !4, !noundef !4
  call void @_ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf79bb0ab9f44bfeeE(ptr noundef nonnull %2) #15
  %3 = call noundef i8 @_RNvXsZ_NtCsjrHSEGnQ3l9_3std7processuNtB5_11Termination6report() #16
  %4 = zext i8 %3 to i32
  ret i32 %4
}

; Function Attrs: noinline nounwind nonlazybind uwtable
define internal void @_ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf79bb0ab9f44bfeeE(ptr noundef nonnull %0) unnamed_addr #2 {
  call void @_ZN4core3ops8function6FnOnce9call_once17hbf5f0f1dae22e66fE(ptr noundef nonnull %0) #16
  call void asm sideeffect "", "~{memory}"(), !srcloc !8
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h0ed91271bd9e113cE"(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %0, ptr noalias noundef align 8 dereferenceable(24) %1) unnamed_addr #1 {
  %3 = load ptr, ptr %0, align 8, !nonnull !4, !align !6, !noundef !4
  %4 = call noundef zeroext i1 @_RNvXsR_NtNtCsgEmfK2I1SDS_4core3fmt3numxNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %3, ptr noalias noundef align 8 dereferenceable(24) %1) #16
  ret i1 %4
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i32 @"_ZN4core3ops8function6FnOnce40call_once$u7b$$u7b$vtable.shim$u7d$$u7d$17h85bde0790c2517dfE"(ptr noundef %0) unnamed_addr #0 {
  %2 = alloca [0 x i8], align 1
  %3 = load ptr, ptr %0, align 8, !nonnull !4, !noundef !4
  %4 = call noundef i32 @_ZN4core3ops8function6FnOnce9call_once17h96ead0262611d2beE(ptr noundef nonnull %3) #16
  ret i32 %4
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i32 @_ZN4core3ops8function6FnOnce9call_once17h96ead0262611d2beE(ptr noundef nonnull %0) unnamed_addr #0 {
  %2 = alloca [0 x i8], align 1
  %3 = alloca [8 x i8], align 8
  store ptr %0, ptr %3, align 8
  %4 = call noundef i32 @"_ZN3std2rt10lang_start28_$u7b$$u7b$closure$u7d$$u7d$17h7a7b080b6c12358bE"(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %3) #16
  ret i32 %4
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_ZN4core3ops8function6FnOnce9call_once17hbf5f0f1dae22e66fE(ptr noundef nonnull %0) unnamed_addr #0 {
  %2 = alloca [0 x i8], align 1
  call void %0() #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr180drop_in_place$LT$$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$..drop..DropGuard$LT$std..ffi..os_str..OsString$C$alloc..alloc..Global$GT$$GT$17h72dc382babf7cd75E"(ptr noalias noundef align 8 dereferenceable(8) %0) unnamed_addr #1 {
  call void @"_ZN157_$LT$$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$..drop..DropGuard$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17h7e178579a2bf6409E"(ptr noalias noundef align 8 dereferenceable(8) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr35drop_in_place$LT$std..env..Args$GT$17h80b628ec642406faE"(ptr noalias noundef align 8 dereferenceable(32) %0) unnamed_addr #1 {
  call void @"_ZN4core3ptr37drop_in_place$LT$std..env..ArgsOs$GT$17hd612d848ecd17b8eE"(ptr noalias noundef align 8 dereferenceable(32) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr37drop_in_place$LT$std..env..ArgsOs$GT$17hd612d848ecd17b8eE"(ptr noalias noundef align 8 dereferenceable(32) %0) unnamed_addr #1 {
  call void @"_ZN4core3ptr49drop_in_place$LT$std..sys..args..common..Args$GT$17h64f4f909f72adfe9E"(ptr noalias noundef align 8 dereferenceable(32) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17haf5a50d2dbe9c21cE"(ptr noalias noundef align 8 dereferenceable(24) %0) unnamed_addr #1 {
  call void @"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h1c010bbeaf56ca47E"(ptr noalias noundef align 8 dereferenceable(24) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h1c010bbeaf56ca47E"(ptr noalias noundef align 8 dereferenceable(24) %0) unnamed_addr #1 {
  call void @"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17he18820bc71364064E"(ptr noalias noundef align 8 dereferenceable(24) %0) #13
  call void @"_ZN4core3ptr53drop_in_place$LT$alloc..raw_vec..RawVec$LT$u8$GT$$GT$17hef1ca602f05a973dE"(ptr noalias noundef align 8 dereferenceable(16) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr47drop_in_place$LT$std..ffi..os_str..OsString$GT$17h40e7bfbb1176977fE"(ptr noalias noundef align 8 dereferenceable(24) %0) unnamed_addr #1 {
  call void @"_ZN4core3ptr49drop_in_place$LT$std..sys..os_str..bytes..Buf$GT$17h366338acc0a4e7ffE"(ptr noalias noundef align 8 dereferenceable(24) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr49drop_in_place$LT$std..sys..args..common..Args$GT$17h64f4f909f72adfe9E"(ptr noalias noundef align 8 dereferenceable(32) %0) unnamed_addr #1 {
  call void @"_ZN4core3ptr86drop_in_place$LT$alloc..vec..into_iter..IntoIter$LT$std..ffi..os_str..OsString$GT$$GT$17h29485032661d5d3dE"(ptr noalias noundef align 8 dereferenceable(32) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr49drop_in_place$LT$std..sys..os_str..bytes..Buf$GT$17h366338acc0a4e7ffE"(ptr noalias noundef align 8 dereferenceable(24) %0) unnamed_addr #1 {
  call void @"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h1c010bbeaf56ca47E"(ptr noalias noundef align 8 dereferenceable(24) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr53drop_in_place$LT$alloc..raw_vec..RawVec$LT$u8$GT$$GT$17hef1ca602f05a973dE"(ptr noalias noundef align 8 dereferenceable(16) %0) unnamed_addr #1 {
  call void @"_ZN77_$LT$alloc..raw_vec..RawVec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17he7f832a3468f79d4E"(ptr noalias noundef align 8 dereferenceable(16) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr57drop_in_place$LT$$u5b$std..ffi..os_str..OsString$u5d$$GT$17h181271c552e99187E"(ptr noalias noundef nonnull align 8 %0, i64 noundef %1) unnamed_addr #1 {
  %3 = alloca [8 x i8], align 8
  store i64 0, ptr %3, align 8
  br label %4

4:                                                ; preds = %7, %2
  %5 = load i64, ptr %3, align 8, !noundef !4
  %6 = icmp eq i64 %5, %1
  br i1 %6, label %12, label %7

7:                                                ; preds = %4
  %8 = load i64, ptr %3, align 8, !noundef !4
  %9 = getelementptr inbounds nuw { { { { { i64, ptr, {} }, {} }, i64 } } }, ptr %0, i64 %8
  %10 = load i64, ptr %3, align 8, !noundef !4
  %11 = add i64 %10, 1
  store i64 %11, ptr %3, align 8
  call void @"_ZN4core3ptr47drop_in_place$LT$std..ffi..os_str..OsString$GT$17h40e7bfbb1176977fE"(ptr noalias noundef align 8 dereferenceable(24) %9) #13
  br label %4

12:                                               ; preds = %4
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr70drop_in_place$LT$core..option..Option$LT$alloc..string..String$GT$$GT$17h7a2f5bd062c02b6bE"(ptr noalias noundef align 8 dereferenceable(24) %0) unnamed_addr #1 {
  %2 = load i64, ptr %0, align 8, !range !9, !noundef !4
  %3 = icmp eq i64 %2, -9223372036854775808
  %4 = select i1 %3, i64 0, i64 1
  %5 = icmp eq i64 %4, 0
  br i1 %5, label %6, label %7

6:                                                ; preds = %7, %1
  ret void

7:                                                ; preds = %1
  call void @"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17haf5a50d2dbe9c21cE"(ptr noalias noundef align 8 dereferenceable(24) %0) #13
  br label %6
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr77drop_in_place$LT$alloc..raw_vec..RawVec$LT$std..ffi..os_str..OsString$GT$$GT$17hf5d20a1534306527E"(ptr noalias noundef align 8 dereferenceable(16) %0) unnamed_addr #1 {
  call void @"_ZN77_$LT$alloc..raw_vec..RawVec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17h27a389819af71bdeE"(ptr noalias noundef align 8 dereferenceable(16) %0) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN4core3ptr86drop_in_place$LT$alloc..vec..into_iter..IntoIter$LT$std..ffi..os_str..OsString$GT$$GT$17h29485032661d5d3dE"(ptr noalias noundef align 8 dereferenceable(32) %0) unnamed_addr #1 {
  call void @"_ZN86_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hbfa558e68bc3aaddE"(ptr noalias noundef align 8 dereferenceable(32) %0) #13
  ret void
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i64 @_ZN4core4iter6traits8iterator8Iterator8try_fold17hf1346b1b862f2c92E(ptr noalias noundef align 8 dereferenceable(32) %0, i64 noundef range(i64 1, 0) %1) unnamed_addr #0 personality ptr @rust_eh_personality {
  %3 = alloca [16 x i8], align 8
  %4 = alloca [1 x i8], align 1
  %5 = alloca [32 x i8], align 8
  %6 = alloca [8 x i8], align 8
  %7 = alloca [24 x i8], align 8
  %8 = alloca [24 x i8], align 8
  %9 = alloca [8 x i8], align 8
  %10 = alloca [8 x i8], align 8
  %11 = alloca [0 x i8], align 1
  call void @llvm.lifetime.start.p0(ptr %9)
  store i8 1, ptr %4, align 1
  store i64 %1, ptr %9, align 8
  br label %12

12:                                               ; preds = %36, %2
  call void @llvm.lifetime.start.p0(ptr %8)
  call void @_RNvXsa_NtCsjrHSEGnQ3l9_3std3envNtB5_4ArgsNtNtNtNtCsgEmfK2I1SDS_4core4iter6traits8iterator8Iterator4next(ptr noalias noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %8, ptr noalias noundef align 8 dereferenceable(32) %0) #13
  br label %13

13:                                               ; preds = %12
  %14 = load i64, ptr %8, align 8, !range !9, !noundef !4
  %15 = icmp eq i64 %14, -9223372036854775808
  %16 = select i1 %15, i64 0, i64 1
  %17 = trunc nuw i64 %16 to i1
  br i1 %17, label %18, label %24

18:                                               ; preds = %13
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %8, i64 24, i1 false)
  call void @llvm.lifetime.start.p0(ptr %6)
  call void @llvm.lifetime.start.p0(ptr %5)
  store i8 0, ptr %4, align 1
  %19 = load i64, ptr %9, align 8, !range !10, !noundef !4
  store i64 %19, ptr %5, align 8
  %20 = getelementptr inbounds i8, ptr %5, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %7, i64 24, i1 false)
  %21 = load i64, ptr %5, align 8, !range !10, !noundef !4
  %22 = getelementptr inbounds i8, ptr %5, i64 8
  %23 = call noundef i64 @"_ZN87_$LT$I$u20$as$u20$core..iter..traits..iterator..Iterator..advance_by..SpecAdvanceBy$GT$15spec_advance_by28_$u7b$$u7b$closure$u7d$$u7d$17h69176f1cff7a2bcfE"(ptr noalias noundef nonnull align 1 %11, i64 noundef %21, ptr noalias noundef align 8 captures(address) dereferenceable(24) %22) #16
  br label %27

24:                                               ; preds = %13
  call void @llvm.lifetime.end.p0(ptr %8)
  store i8 0, ptr %4, align 1
  %25 = load i64, ptr %9, align 8, !range !10, !noundef !4
  %26 = call noundef i64 @"_ZN75_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..ops..try_trait..Try$GT$11from_output17h7863267ac070888bE"(i64 noundef %25) #16
  store i64 %26, ptr %10, align 8
  br label %41

27:                                               ; preds = %18
  call void @llvm.lifetime.end.p0(ptr %5)
  %28 = call noundef i64 @"_ZN75_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h54815570a4ceaac2E"(i64 noundef %23) #16
  store i64 %28, ptr %6, align 8
  br label %29

29:                                               ; preds = %27
  %30 = load i64, ptr %6, align 8, !noundef !4
  %31 = icmp eq i64 %30, 0
  %32 = select i1 %31, i64 1, i64 0
  %33 = trunc nuw i64 %32 to i1
  br i1 %33, label %34, label %36

34:                                               ; preds = %29
  %35 = call noundef i64 @"_ZN145_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..option..Option$LT$core..convert..Infallible$GT$$GT$$GT$13from_residual17hebc962e0860f82aaE"() #16
  store i64 %35, ptr %10, align 8
  br label %38

36:                                               ; preds = %29
  %37 = load i64, ptr %6, align 8, !range !10, !noundef !4
  store i8 1, ptr %4, align 1
  store i64 %37, ptr %9, align 8
  call void @llvm.lifetime.end.p0(ptr %6)
  call void @llvm.lifetime.end.p0(ptr %8)
  br label %12

38:                                               ; preds = %34
  call void @llvm.lifetime.end.p0(ptr %6)
  call void @llvm.lifetime.end.p0(ptr %8)
  call void @llvm.lifetime.end.p0(ptr %9)
  br label %39

39:                                               ; preds = %41, %38
  %40 = load i64, ptr %10, align 8, !noundef !4
  ret i64 %40

41:                                               ; preds = %24
  call void @llvm.lifetime.end.p0(ptr %9)
  br label %39

42:                                               ; No predecessors!
  unreachable

43:                                               ; No predecessors!
  %44 = load i8, ptr %4, align 1, !range !5, !noundef !4
  %45 = trunc nuw i8 %44 to i1
  br i1 %45, label %52, label %46

46:                                               ; preds = %52, %43
  %47 = load ptr, ptr %3, align 8, !noundef !4
  %48 = getelementptr inbounds i8, ptr %3, i64 8
  %49 = load i32, ptr %48, align 8, !noundef !4
  call void @llvm.lifetime.end.p0(ptr %3)
  %50 = insertvalue { ptr, i32 } poison, ptr %47, 0
  %51 = insertvalue { ptr, i32 } %50, i32 %49, 1
  resume { ptr, i32 } %51

52:                                               ; preds = %43
  br label %46
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i8 @_ZN4core4sync6atomic11atomic_load17hda3be9b670ff7a93E(ptr noundef %0, i8 noundef range(i8 0, 5) %1) unnamed_addr #0 {
  %3 = alloca [1 x i8], align 1
  %4 = zext i8 %1 to i64
  switch i64 %4, label %5 [
    i64 0, label %6
    i64 1, label %8
    i64 2, label %10
    i64 3, label %12
    i64 4, label %14
  ], !prof !11

5:                                                ; preds = %2
  unreachable

6:                                                ; preds = %2
  %7 = load atomic i8, ptr %0 monotonic, align 1
  store i8 %7, ptr %3, align 1
  br label %16

8:                                                ; preds = %2
  call void @llvm.assume(i1 true)
  %9 = icmp ne ptr inttoptr (i64 81 to ptr), null
  call void @llvm.assume(i1 %9)
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking9panic_fmt(ptr noundef nonnull @4, ptr noundef nonnull inttoptr (i64 81 to ptr), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @6) #14
  unreachable

10:                                               ; preds = %2
  %11 = load atomic i8, ptr %0 acquire, align 1
  store i8 %11, ptr %3, align 1
  br label %16

12:                                               ; preds = %2
  call void @llvm.assume(i1 true)
  %13 = icmp ne ptr inttoptr (i64 99 to ptr), null
  call void @llvm.assume(i1 %13)
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking9panic_fmt(ptr noundef nonnull @7, ptr noundef nonnull inttoptr (i64 99 to ptr), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @8) #14
  unreachable

14:                                               ; preds = %2
  %15 = load atomic i8, ptr %0 seq_cst, align 1
  store i8 %15, ptr %3, align 1
  br label %16

16:                                               ; preds = %14, %10, %6
  %17 = load i8, ptr %3, align 1, !noundef !4
  ret i8 %17
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_ZN4core4sync6atomic12atomic_store17h41066cc265df446bE(ptr noundef %0, i8 noundef %1, i8 noundef range(i8 0, 5) %2) unnamed_addr #0 {
  %4 = zext i8 %2 to i64
  switch i64 %4, label %5 [
    i64 0, label %6
    i64 1, label %7
    i64 2, label %8
    i64 3, label %10
    i64 4, label %12
  ], !prof !12

5:                                                ; preds = %3
  unreachable

6:                                                ; preds = %3
  store atomic i8 %1, ptr %0 monotonic, align 1
  br label %13

7:                                                ; preds = %3
  store atomic i8 %1, ptr %0 release, align 1
  br label %13

8:                                                ; preds = %3
  call void @llvm.assume(i1 true)
  %9 = icmp ne ptr inttoptr (i64 85 to ptr), null
  call void @llvm.assume(i1 %9)
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking9panic_fmt(ptr noundef nonnull @9, ptr noundef nonnull inttoptr (i64 85 to ptr), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @10) #14
  unreachable

10:                                               ; preds = %3
  call void @llvm.assume(i1 true)
  %11 = icmp ne ptr inttoptr (i64 101 to ptr), null
  call void @llvm.assume(i1 %11)
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking9panic_fmt(ptr noundef nonnull @11, ptr noundef nonnull inttoptr (i64 101 to ptr), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @12) #14
  unreachable

12:                                               ; preds = %3
  store atomic i8 %1, ptr %0 seq_cst, align 1
  br label %13

13:                                               ; preds = %12, %7, %6
  ret void
}

; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
define internal void @_ZN4core9panicking13assert_failed17h8b7d59cf8e69e97eE(i8 noundef range(i8 0, 3) %0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %2, ptr noundef %3, ptr %4, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %5) unnamed_addr #3 {
  %7 = alloca [8 x i8], align 8
  %8 = alloca [8 x i8], align 8
  store ptr %1, ptr %8, align 8
  store ptr %2, ptr %7, align 8
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking19assert_failed_inner(i8 noundef %0, ptr noundef nonnull align 1 %8, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @13, ptr noundef nonnull align 1 %7, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @13, ptr noundef %3, ptr %4, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %5) #14
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
define internal { ptr, i64 } @"_ZN5alloc3vec9into_iter21IntoIter$LT$T$C$A$GT$16as_raw_mut_slice17h00ae20bae8197bfbE"(ptr noalias noundef align 8 dereferenceable(32) %0) unnamed_addr #1 {
  %2 = alloca [16 x i8], align 8
  %3 = alloca [24 x i8], align 8
  %4 = alloca [16 x i8], align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8, !nonnull !4, !noundef !4
  %7 = icmp ne ptr %6, null
  call void @llvm.assume(i1 %7)
  call void @llvm.lifetime.start.p0(ptr %4)
  call void @llvm.lifetime.start.p0(ptr %2)
  call void @llvm.lifetime.start.p0(ptr %3)
  call void @"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$9size_hint17he244edca7f20423cE"(ptr noalias noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %3, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %0) #16
  %8 = load i64, ptr %3, align 8, !noundef !4
  %9 = getelementptr inbounds i8, ptr %3, i64 8
  %10 = load i64, ptr %9, align 8, !range !13, !noundef !4
  %11 = getelementptr inbounds i8, ptr %9, i64 8
  %12 = load i64, ptr %11, align 8
  store i64 %10, ptr %4, align 8
  %13 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %12, ptr %13, align 8
  call void @llvm.lifetime.end.p0(ptr %3)
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %8, ptr %14, align 8
  store i64 1, ptr %2, align 8
  %15 = load i64, ptr %4, align 8, !range !13, !noundef !4
  %16 = getelementptr inbounds i8, ptr %4, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = trunc nuw i64 %15 to i1
  %19 = call i1 @llvm.expect.i1(i1 %18, i1 true)
  br i1 %19, label %20, label %25

20:                                               ; preds = %1
  %21 = getelementptr inbounds i8, ptr %4, i64 8
  %22 = load i64, ptr %21, align 8, !noundef !4
  %23 = icmp eq i64 %22, %8
  %24 = call i1 @llvm.expect.i1(i1 %23, i1 true)
  br i1 %24, label %29, label %26

25:                                               ; preds = %1
  br label %26

26:                                               ; preds = %25, %20
  %27 = load ptr, ptr @14, align 8, !noundef !4
  %28 = load ptr, ptr getelementptr inbounds (i8, ptr @14, i64 8), align 8
  call void @_RINvNtCsgEmfK2I1SDS_4core9panicking13assert_failedINtNtB4_6option6OptionjEBM_EB4_(i8 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16) %4, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16) %2, ptr noundef %27, ptr %28, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @16) #14
  unreachable

29:                                               ; preds = %20
  call void @llvm.lifetime.end.p0(ptr %2)
  call void @llvm.lifetime.end.p0(ptr %4)
  %30 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %8, 1
  ret { ptr, i64 } %31

32:                                               ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$10deallocate17h77606815d1a5df37E"(ptr noalias noundef align 8 dereferenceable(16) %0, i64 noundef range(i64 1, -9223372036854775807) %1, i64 noundef %2) unnamed_addr #1 {
  %4 = alloca [24 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr %4)
  call void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$14current_memory17hd86efb97ce6f397eE"(ptr noalias noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %4, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16) %0, i64 noundef %1, i64 noundef %2) #16
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %6 = load i64, ptr %5, align 8, !range !9, !noundef !4
  %7 = icmp eq i64 %6, 0
  %8 = select i1 %7, i64 0, i64 1
  %9 = trunc nuw i64 %8 to i1
  br i1 %9, label %10, label %17

10:                                               ; preds = %3
  %11 = load ptr, ptr %4, align 8, !nonnull !4, !noundef !4
  %12 = getelementptr inbounds i8, ptr %4, i64 8
  %13 = load i64, ptr %12, align 8, !range !14, !noundef !4
  %14 = getelementptr inbounds i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8, !noundef !4
  %16 = getelementptr inbounds i8, ptr %0, i64 16
  call void @_RNvXs_NtCslNYArtu3iFV_5alloc5allocNtB4_6GlobalNtNtCsgEmfK2I1SDS_4core5alloc9Allocator10deallocate(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %16, ptr noundef nonnull %11, i64 noundef %13, i64 noundef %15) #16
  call void @llvm.lifetime.end.p0(ptr %4)
  br label %18

17:                                               ; preds = %3
  call void @llvm.lifetime.end.p0(ptr %4)
  br label %18

18:                                               ; preds = %17, %10
  ret void

19:                                               ; No predecessors!
  unreachable
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$14current_memory17hd86efb97ce6f397eE"(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24) %0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16) %1, i64 noundef range(i64 1, -9223372036854775807) %2, i64 noundef %3) unnamed_addr #0 {
  %5 = alloca [24 x i8], align 8
  %6 = icmp eq i64 %3, 0
  br i1 %6, label %7, label %9

7:                                                ; preds = %13, %4
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 0, ptr %8, align 8
  br label %17

9:                                                ; preds = %4
  %10 = load i64, ptr %1, align 8, !range !7, !noundef !4
  %11 = icmp ule i64 %10, 9223372036854775807
  call void @llvm.assume(i1 %11)
  %12 = icmp eq i64 %10, 0
  br i1 %12, label %13, label %14

13:                                               ; preds = %9
  br label %7

14:                                               ; preds = %9
  %15 = load i64, ptr %1, align 8, !range !7, !noundef !4
  %16 = icmp ule i64 %15, 9223372036854775807
  call void @llvm.assume(i1 %16)
  br label %18

17:                                               ; preds = %22, %7
  ret void

18:                                               ; preds = %14
  %19 = mul nuw i64 %3, %15
  %20 = sub i64 %2, 1
  %21 = icmp ule i64 %20, 9223372036854775807
  call void @llvm.assume(i1 %21)
  br label %22

22:                                               ; preds = %18
  call void @llvm.lifetime.start.p0(ptr %5)
  %23 = getelementptr inbounds i8, ptr %1, i64 8
  %24 = load ptr, ptr %23, align 8, !nonnull !4, !noundef !4
  store ptr %24, ptr %5, align 8
  %25 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 %2, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  store i64 %19, ptr %26, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %5, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(ptr %5)
  br label %17

27:                                               ; No predecessors!
  unreachable

28:                                               ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17he18820bc71364064E"(ptr noalias noundef align 8 dereferenceable(24) %0) unnamed_addr #1 {
  %2 = getelementptr inbounds i8, ptr %0, i64 8
  %3 = load ptr, ptr %2, align 8, !nonnull !4, !noundef !4
  %4 = icmp ne ptr %3, null
  call void @llvm.assume(i1 %4)
  %5 = getelementptr inbounds i8, ptr %0, i64 16
  %6 = load i64, ptr %5, align 8, !noundef !4
  ret void
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i64 @"_ZN75_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..ops..try_trait..Try$GT$11from_output17h7863267ac070888bE"(i64 noundef range(i64 1, 0) %0) unnamed_addr #0 {
  %2 = sub i64 %0, 1
  %3 = icmp ule i64 %2, -2
  call void @llvm.assume(i1 %3)
  ret i64 %0
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i64 @"_ZN75_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h54815570a4ceaac2E"(i64 noundef %0) unnamed_addr #0 {
  %2 = alloca [8 x i8], align 8
  %3 = alloca [8 x i8], align 8
  store i64 %0, ptr %3, align 8
  %4 = load i64, ptr %3, align 8, !noundef !4
  %5 = icmp eq i64 %4, 0
  %6 = select i1 %5, i64 0, i64 1
  %7 = trunc nuw i64 %6 to i1
  br i1 %7, label %8, label %10

8:                                                ; preds = %1
  %9 = load i64, ptr %3, align 8, !range !10, !noundef !4
  store i64 %9, ptr %2, align 8
  br label %11

10:                                               ; preds = %1
  store i64 0, ptr %2, align 8
  br label %11

11:                                               ; preds = %10, %8
  %12 = load i64, ptr %2, align 8, !noundef !4
  ret i64 %12

13:                                               ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf18check_import_roots17h487a4b0225d2cd57E() unnamed_addr #1 {
  %1 = alloca [8 x i8], align 8
  %2 = call noundef i64 @wasm-global.root() #13
  %3 = inttoptr i64 %2 to ptr
  call void @llvm.assume(i1 true)
  call void @native_gc_watch(ptr noundef %3, ptr noundef @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf9reclaimed17h8855a6f3d5be4824E, ptr noundef null, ptr noundef null, ptr noundef null) #13
  %4 = call noundef i64 @native_gc_collections() #13
  %5 = call noundef i64 @wasm.take-root() #13
  store i64 %5, ptr %1, align 8
  %6 = load i64, ptr %1, align 8, !noundef !4
  %7 = icmp eq i64 %6, 3
  %8 = call i1 @llvm.expect.i1(i1 %7, i1 true)
  br i1 %8, label %9, label %13

9:                                                ; preds = %0
  %10 = call noundef i64 @native_gc_collections() #13
  %11 = icmp ugt i64 %10, %4
  %12 = call i1 @llvm.expect.i1(i1 %11, i1 true)
  br i1 %12, label %17, label %16

13:                                               ; preds = %0
  %14 = load ptr, ptr @14, align 8, !noundef !4
  %15 = load ptr, ptr getelementptr inbounds (i8, ptr @14, i64 8), align 8
  call void @_ZN4core9panicking13assert_failed17h8b7d59cf8e69e97eE(i8 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) @17, ptr noundef %14, ptr %15, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @27) #14
  unreachable

16:                                               ; preds = %9
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking5panic(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @18, i64 noundef 58, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @20) #14
  unreachable

17:                                               ; preds = %9
  %18 = call noundef i8 @_ZN4core4sync6atomic11atomic_load17hda3be9b670ff7a93E(ptr noundef @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf9RECLAIMED17ha15bf2b8a0879b61E, i8 noundef 0) #16
  %19 = icmp eq i8 %18, 0
  %20 = call i1 @llvm.expect.i1(i1 %19, i1 true)
  br i1 %20, label %21, label %25

21:                                               ; preds = %17
  call void @native_gc_collect() #13
  %22 = call noundef i8 @_ZN4core4sync6atomic11atomic_load17hda3be9b670ff7a93E(ptr noundef @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf9RECLAIMED17ha15bf2b8a0879b61E, i8 noundef 0) #16
  %23 = icmp eq i8 %22, 0
  %24 = call i1 @llvm.expect.i1(i1 %23, i1 false)
  br i1 %24, label %26, label %27

25:                                               ; preds = %17
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking5panic(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @25, i64 noundef 52, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @26) #14
  unreachable

26:                                               ; preds = %21
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking5panic(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @21, i64 noundef 51, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @22) #14
  unreachable

27:                                               ; preds = %21
  %28 = load ptr, ptr @native_roots, align 8, !noundef !4
  %29 = ptrtoint ptr %28 to i64
  %30 = icmp eq i64 %29, 0
  %31 = call i1 @llvm.expect.i1(i1 %30, i1 true)
  br i1 %31, label %32, label %33

32:                                               ; preds = %27
  ret void

33:                                               ; preds = %27
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking5panic(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @23, i64 noundef 48, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @24) #14
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
define hidden void @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf4main17h0be1e2fb9f40e0a9E() unnamed_addr #1 {
  %1 = alloca [4 x i8], align 4
  %2 = alloca [8 x i8], align 8
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  %5 = alloca [32 x i8], align 8
  %6 = alloca [24 x i8], align 8
  %7 = alloca [16 x i8], align 8
  call void @_ZN13snail_runtime6native15initialize_host17h2e31f31a54e78133E() #13
  call void @native_module_init() #13
  call void @llvm.lifetime.start.p0(ptr %7)
  call void @llvm.lifetime.start.p0(ptr %6)
  call void @llvm.lifetime.start.p0(ptr %5)
  call void @_RNvNtCsjrHSEGnQ3l9_3std3env4args(ptr noalias noundef sret([32 x i8]) align 8 captures(none) dereferenceable(32) %5) #13
  %8 = call noundef i64 @_ZN4core4iter6traits8iterator8Iterator8try_fold17hf1346b1b862f2c92E(ptr noalias noundef align 8 dereferenceable(32) %5, i64 noundef 1) #16
  %9 = icmp eq i64 %8, 0
  %10 = select i1 %9, i64 0, i64 1
  %11 = trunc nuw i64 %10 to i1
  br i1 %11, label %12, label %13

12:                                               ; preds = %0
  call void @llvm.assume(i1 true)
  store i64 -9223372036854775808, ptr %6, align 8
  br label %14

13:                                               ; preds = %0
  call void @_RNvXsa_NtCsjrHSEGnQ3l9_3std3envNtB5_4ArgsNtNtNtNtCsgEmfK2I1SDS_4core4iter6traits8iterator8Iterator4next(ptr noalias noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %6, ptr noalias noundef align 8 dereferenceable(32) %5) #13
  br label %14

14:                                               ; preds = %13, %12
  %15 = load i64, ptr %6, align 8, !range !9, !noundef !4
  %16 = icmp eq i64 %15, -9223372036854775808
  %17 = select i1 %16, i64 0, i64 1
  %18 = trunc nuw i64 %17 to i1
  br i1 %18, label %19, label %32

19:                                               ; preds = %14
  %20 = getelementptr inbounds i8, ptr %6, i64 8
  %21 = load ptr, ptr %20, align 8, !nonnull !4, !noundef !4
  %22 = icmp ne ptr %21, null
  call void @llvm.assume(i1 %22)
  %23 = getelementptr inbounds i8, ptr %6, i64 16
  %24 = load i64, ptr %23, align 8, !noundef !4
  store ptr %21, ptr %7, align 8
  %25 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %24, ptr %25, align 8
  %26 = load ptr, ptr %7, align 8, !nonnull !4, !align !15, !noundef !4
  %27 = getelementptr inbounds i8, ptr %7, i64 8
  %28 = load i64, ptr %27, align 8, !noundef !4
  %29 = load ptr, ptr @29, align 8, !nonnull !4, !align !15, !noundef !4
  %30 = load i64, ptr getelementptr inbounds (i8, ptr @29, i64 8), align 8, !noundef !4
  %31 = icmp eq i64 %28, 4
  br i1 %31, label %34, label %38

32:                                               ; preds = %14
  br label %33

33:                                               ; preds = %38, %32
  br label %39

34:                                               ; preds = %19
  call void @llvm.lifetime.start.p0(ptr %1)
  %35 = call i32 @memcmp(ptr %26, ptr %29, i64 %28)
  store i32 %35, ptr %1, align 4
  %36 = load i32, ptr %1, align 4, !noundef !4
  call void @llvm.lifetime.end.p0(ptr %1)
  %37 = icmp eq i32 %36, 0
  br i1 %37, label %44, label %39

38:                                               ; preds = %19
  br label %33

39:                                               ; preds = %34, %33
  call void @"_ZN4core3ptr70drop_in_place$LT$core..option..Option$LT$alloc..string..String$GT$$GT$17h7a2f5bd062c02b6bE"(ptr noalias noundef align 8 dereferenceable(24) %6) #13
  call void @"_ZN4core3ptr35drop_in_place$LT$std..env..Args$GT$17h80b628ec642406faE"(ptr noalias noundef align 8 dereferenceable(32) %5) #13
  call void @llvm.lifetime.end.p0(ptr %5)
  call void @llvm.lifetime.end.p0(ptr %6)
  call void @llvm.lifetime.end.p0(ptr %7)
  %40 = call noundef i64 @wasm.run(i64 noundef 40) #13
  store i64 %40, ptr %4, align 8
  %41 = load i64, ptr %4, align 8, !noundef !4
  %42 = icmp eq i64 %41, 42
  %43 = call i1 @llvm.expect.i1(i1 %42, i1 true)
  br i1 %43, label %45, label %50

44:                                               ; preds = %34
  call void @"_ZN4core3ptr70drop_in_place$LT$core..option..Option$LT$alloc..string..String$GT$$GT$17h7a2f5bd062c02b6bE"(ptr noalias noundef align 8 dereferenceable(24) %6) #13
  call void @"_ZN4core3ptr35drop_in_place$LT$std..env..Args$GT$17h80b628ec642406faE"(ptr noalias noundef align 8 dereferenceable(32) %5) #13
  call void @llvm.lifetime.end.p0(ptr %5)
  call void @llvm.lifetime.end.p0(ptr %6)
  call void @llvm.lifetime.end.p0(ptr %7)
  call void @wasm.trap() #13
  call void @_RNvNtCsjrHSEGnQ3l9_3std7process4exit(i32 noundef 2) #17
  unreachable

45:                                               ; preds = %39
  %46 = call noundef i64 @wasm.run(i64 noundef 1) #13
  store i64 %46, ptr %3, align 8
  %47 = load i64, ptr %3, align 8, !noundef !4
  %48 = icmp eq i64 %47, 3
  %49 = call i1 @llvm.expect.i1(i1 %48, i1 true)
  br i1 %49, label %53, label %58

50:                                               ; preds = %39
  %51 = load ptr, ptr @14, align 8, !noundef !4
  %52 = load ptr, ptr getelementptr inbounds (i8, ptr @14, i64 8), align 8
  call void @_ZN4core9panicking13assert_failed17h8b7d59cf8e69e97eE(i8 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %4, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) @30, ptr noundef %51, ptr %52, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @34) #14
  unreachable

53:                                               ; preds = %45
  %54 = call noundef i64 @wasm.previous() #13
  store i64 %54, ptr %2, align 8
  %55 = load i64, ptr %2, align 8, !noundef !4
  %56 = icmp eq i64 %55, 42
  %57 = call i1 @llvm.expect.i1(i1 %56, i1 true)
  br i1 %57, label %61, label %64

58:                                               ; preds = %45
  %59 = load ptr, ptr @14, align 8, !noundef !4
  %60 = load ptr, ptr getelementptr inbounds (i8, ptr @14, i64 8), align 8
  call void @_ZN4core9panicking13assert_failed17h8b7d59cf8e69e97eE(i8 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %3, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) @17, ptr noundef %59, ptr %60, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @33) #14
  unreachable

61:                                               ; preds = %53
  call void @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf18check_import_roots17h487a4b0225d2cd57E() #13
  call void @llvm.assume(i1 true)
  %62 = icmp ne ptr inttoptr (i64 7 to ptr), null
  call void @llvm.assume(i1 %62)
  call void @_RNvNtNtCsjrHSEGnQ3l9_3std2io5stdio6__print(ptr noundef nonnull @31, ptr noundef nonnull inttoptr (i64 7 to ptr)) #13
  %63 = call noundef i32 @native_finish(i32 noundef 0) #13
  call void @_RNvNtCsjrHSEGnQ3l9_3std7process4exit(i32 noundef %63) #17
  unreachable

64:                                               ; preds = %53
  %65 = load ptr, ptr @14, align 8, !noundef !4
  %66 = load ptr, ptr getelementptr inbounds (i8, ptr @14, i64 8), align 8
  call void @_ZN4core9panicking13assert_failed17h8b7d59cf8e69e97eE(i8 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %2, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) @30, ptr noundef %65, ptr %66, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @32) #14
  unreachable

67:                                               ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf9reclaimed17h8855a6f3d5be4824E(ptr noundef %0, ptr noundef %1) unnamed_addr #1 {
  call void @_ZN4core4sync6atomic12atomic_store17h41066cc265df446bE(ptr noundef @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf9RECLAIMED17ha15bf2b8a0879b61E, i8 noundef 1, i8 noundef 0) #16
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN77_$LT$alloc..raw_vec..RawVec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17h27a389819af71bdeE"(ptr noalias noundef align 8 dereferenceable(16) %0) unnamed_addr #1 {
  call void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$10deallocate17h77606815d1a5df37E"(ptr noalias noundef align 8 dereferenceable(16) %0, i64 noundef 8, i64 noundef 24) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN77_$LT$alloc..raw_vec..RawVec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17he7f832a3468f79d4E"(ptr noalias noundef align 8 dereferenceable(16) %0) unnamed_addr #1 {
  call void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$10deallocate17h77606815d1a5df37E"(ptr noalias noundef align 8 dereferenceable(16) %0, i64 noundef 1, i64 noundef 1) #13
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
define internal void @"_ZN86_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hbfa558e68bc3aaddE"(ptr noalias noundef align 8 dereferenceable(32) %0) unnamed_addr #1 personality ptr @rust_eh_personality {
  %2 = alloca [16 x i8], align 8
  %3 = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr %3)
  store ptr %0, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8, !nonnull !4, !align !6, !noundef !4
  %5 = call { ptr, i64 } @"_ZN5alloc3vec9into_iter21IntoIter$LT$T$C$A$GT$16as_raw_mut_slice17h00ae20bae8197bfbE"(ptr noalias noundef align 8 dereferenceable(32) %4) #13
  %6 = extractvalue { ptr, i64 } %5, 0
  %7 = extractvalue { ptr, i64 } %5, 1
  br label %8

8:                                                ; preds = %1
  call void @"_ZN4core3ptr57drop_in_place$LT$$u5b$std..ffi..os_str..OsString$u5d$$GT$17h181271c552e99187E"(ptr noalias noundef nonnull align 8 %6, i64 noundef %7) #13
  br label %9

9:                                                ; preds = %8
  call void @"_ZN4core3ptr180drop_in_place$LT$$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$..drop..DropGuard$LT$std..ffi..os_str..OsString$C$alloc..alloc..Global$GT$$GT$17h72dc382babf7cd75E"(ptr noalias noundef align 8 dereferenceable(8) %3) #13
  call void @llvm.lifetime.end.p0(ptr %3)
  ret void

10:                                               ; No predecessors!
  call void @"_ZN4core3ptr180drop_in_place$LT$$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$..drop..DropGuard$LT$std..ffi..os_str..OsString$C$alloc..alloc..Global$GT$$GT$17h72dc382babf7cd75E"(ptr noalias noundef align 8 dereferenceable(8) %3) #18
  %11 = load ptr, ptr %2, align 8, !noundef !4
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  %13 = load i32, ptr %12, align 8, !noundef !4
  call void @llvm.lifetime.end.p0(ptr %2)
  %14 = insertvalue { ptr, i32 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i32 } %14, i32 %13, 1
  resume { ptr, i32 } %15
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef i64 @"_ZN87_$LT$I$u20$as$u20$core..iter..traits..iterator..Iterator..advance_by..SpecAdvanceBy$GT$15spec_advance_by28_$u7b$$u7b$closure$u7d$$u7d$17h69176f1cff7a2bcfE"(ptr noalias noundef nonnull align 1 %0, i64 noundef range(i64 1, 0) %1, ptr dead_on_return noalias noundef align 8 captures(address) dereferenceable(24) %2) unnamed_addr #0 {
  %4 = sub i64 %1, 1
  %5 = icmp ule i64 %4, -2
  call void @llvm.assume(i1 %5)
  %6 = sub i64 %1, 1
  call void @"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17haf5a50d2dbe9c21cE"(ptr noalias noundef align 8 dereferenceable(24) %2) #13
  ret i64 %6
}

; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXse_NtNtNtCsgEmfK2I1SDS_4core3fmt3num3impxNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXsF_NtNtCsgEmfK2I1SDS_4core3fmt3numxNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXsD_NtNtCsgEmfK2I1SDS_4core3fmt3numxNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #4

; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr allocptr noundef captures(address), i64 noundef, i64 noundef range(i64 1, -9223372036854775807)) unnamed_addr #5

; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsgEmfK2I1SDS_4core9panicking5panic(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #7

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #7

; Function Attrs: nounwind nonlazybind uwtable
declare noundef i64 @_RNvNtCsjrHSEGnQ3l9_3std2rt19lang_start_internal(ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48), i64 noundef, ptr noundef, i8 noundef) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvXsa_NtCsjrHSEGnQ3l9_3std3envNtB5_4ArgsNtNtNtNtCsgEmfK2I1SDS_4core4iter6traits8iterator8Iterator4next(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24), ptr noalias noundef align 8 dereferenceable(32)) unnamed_addr #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #8

; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsgEmfK2I1SDS_4core9panicking9panic_fmt(ptr noundef nonnull, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #6

; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsgEmfK2I1SDS_4core9panicking19assert_failed_inner(i8 noundef range(i8 0, 3), ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noundef, ptr, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.expect.i1(i1, i1) #9

; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RINvNtCsgEmfK2I1SDS_4core9panicking13assert_failedINtNtB4_6option6OptionjEBM_EB4_(i8 noundef range(i8 0, 3), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16), ptr noundef, ptr, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #3

; Function Attrs: nounwind nonlazybind uwtable
declare noundef i64 @wasm-global.root() unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @native_gc_watch(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef i64 @native_gc_collections() unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef i64 @wasm.take-root() unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @native_gc_collect() unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @_ZN13snail_runtime6native15initialize_host17h2e31f31a54e78133E() unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @native_module_init() unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvNtCsjrHSEGnQ3l9_3std3env4args(ptr dead_on_unwind noalias noundef writable sret([32 x i8]) align 8 captures(none) dereferenceable(32)) unnamed_addr #1

; Function Attrs: nonlazybind
declare i32 @memcmp(ptr, ptr, i64) #10

; Function Attrs: nounwind nonlazybind uwtable
declare void @wasm.trap() unnamed_addr #1

; Function Attrs: noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsjrHSEGnQ3l9_3std7process4exit(i32 noundef) unnamed_addr #11

; Function Attrs: nounwind nonlazybind uwtable
declare noundef i64 @wasm.run(i64 noundef) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef i64 @wasm.previous() unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvNtNtCsjrHSEGnQ3l9_3std2io5stdio6__print(ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef i32 @native_finish(i32 noundef) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #12 {
  %3 = sext i32 %0 to i64
  %4 = call i64 @_ZN3std2rt10lang_start17h488d9eea15142c0dE(ptr @_ZN76wasm_native_fe15fe66e3f9af23f089b6e62185780e24000ab3014772805028e5ba8ec96faf4main17h0be1e2fb9f40e0a9E, i64 %3, ptr %1, i8 0)
  %5 = trunc i64 %4 to i32
  ret i32 %5
}

attributes #0 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64-v3" }
attributes #1 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64-v3" }
attributes #2 = { noinline nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64-v3" }
attributes #3 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64-v3" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #5 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64-v3" }
attributes #6 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64-v3" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #9 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #10 = { nonlazybind }
attributes #11 = { noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64-v3" }
attributes #12 = { nonlazybind "target-cpu"="x86-64-v3" }
attributes #13 = { nounwind }
attributes #14 = { noinline noreturn nounwind }
attributes #15 = { noinline nounwind }
attributes #16 = { inlinehint nounwind }
attributes #17 = { noreturn nounwind }
attributes #18 = { cold nounwind }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{i32 2, !"RtLibUseGOT", i32 1}
!3 = !{!"rustc version 1.95.0 (59807616e 2026-04-14)"}
!4 = !{}
!5 = !{i8 0, i8 2}
!6 = !{i64 8}
!7 = !{i64 0, i64 -9223372036854775808}
!8 = !{i64 17661601309966079}
!9 = !{i64 0, i64 -9223372036854775807}
!10 = !{i64 1, i64 0}
!11 = !{!"branch_weights", i32 1, i32 2000, i32 1, i32 2000, i32 1, i32 2000}
!12 = !{!"branch_weights", i32 1, i32 2000, i32 2000, i32 1, i32 1, i32 2000}
!13 = !{i64 0, i64 2}
!14 = !{i64 1, i64 -9223372036854775807}
!15 = !{i64 1}
