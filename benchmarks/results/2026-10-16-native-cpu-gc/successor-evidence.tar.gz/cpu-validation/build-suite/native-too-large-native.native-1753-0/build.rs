fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/build-suite/native-too-large-native.native-1753-0/module.bc");
}
