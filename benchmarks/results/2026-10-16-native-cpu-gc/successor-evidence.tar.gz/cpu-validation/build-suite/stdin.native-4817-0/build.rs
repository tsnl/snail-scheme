fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/build-suite/stdin.native-4817-0/module.bc");
}
