(module
 (rec
  (type $type43 (sub (struct)))
  (type $1 (func (param (ref $type28)) (result i32)))
  (type $type45 (sub $type43 (struct (field i32))))
  (type $type26 (struct (field (mut i32))))
  (type $type29 (struct (field (mut i64))))
  (type $call5 (func (param eqref) (result i64)))
  (type $type5 (struct))
  (type $type55 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type30 (struct))
  (type $type28 (struct (field (ref $type26)) (field (ref $type29))))
  (type $type27 (struct))
  (type $type25 (struct (field (ref $type26))))
  (type $type44 (sub $type43 (struct)))
 )
 (type $21 (func (param i32) (result i32)))
 (type $22 (func (result i32)))
 (type $23 (func (param i32 i32)))
 (type $24 (func (param i32) (result i64)))
 (type $25 (func (param i32)))
 (type $26 (func (result i64)))
 (import "snail.library" "snail:io/write-character" (func $foreign1 (param i32 i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign2 (param i32) (result i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign3 (param i32) (result i32)))
 (import "snail.library" "snail:io/read-packet" (func $foreign4 (param i32) (result i64)))
 (import "snail.library" "snail:io/close" (func $foreign5 (param i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign12 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign13 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty44 (ref $type44) (struct.new_default $type44))
 (global $global117 (mut (ref null $type25)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type27)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type28)) (ref.null none))
 (global $global120 (mut (ref null $type30)) (ref.null none))
 (global $global128 (mut (ref null $type37)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type38)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type39)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type40)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type41)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type41)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type42)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type46)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type47)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type47)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global143 (mut (ref null $type55)) (ref.null none))
 (global $ready143 (mut i32) (i32.const 0))
 (global $global151 (mut (ref null $type28)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (global $global152 (mut (ref null $type28)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type25)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global154 (mut (ref null $type5)) (ref.null none))
 (global $ready154 (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $function155 (type $call5) (param $0 eqref) (result i64)
  (local $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type28))
  (local $5 (ref $type43))
  (local $6 (ref $type29))
  (local $7 (ref $type26))
  (local $8 (ref $type25))
  (local $scratch (ref $type28))
  (local $scratch_10 (ref $type28))
  (local $scratch_11 (ref $type25))
  (if
   (i32.eqz
    (global.get $ready151)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (ref.as_non_null
    (global.get $global151)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (local.set $2
   (if (result i32)
    (i32.lt_s
     (local.tee $2
      (struct.get $type26 0
       (struct.get $type28 0
        (local.get $4)
       )
      )
     )
     (i32.const 0)
    )
    (then
     (call $foreign2
      (local.get $2)
     )
    )
    (else
     (if
      (i32.eqz
       (global.get $ready130)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global130)
      )
     )
     (if
      (i64.eqz
       (local.tee $1
        (struct.get $type29 0
         (local.tee $6
          (struct.get $type28 1
           (local.get $4)
          )
         )
        )
       )
      )
      (then
       (struct.set $type29 0
        (local.get $6)
        (local.tee $1
         (call $foreign4
          (struct.get $type26 0
           (struct.get $type28 0
            (local.get $4)
           )
          )
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready131)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global131)
      )
     )
     (if (result i32)
      (i64.lt_s
       (local.get $1)
       (i64.const 0)
      )
      (then
       (if (result i32)
        (i64.eq
         (local.get $1)
         (i64.const -1)
        )
        (then
         (i32.const -1)
        )
        (else
         (if
          (i64.ne
           (i64.extend32_s
            (local.tee $1
             (i64.sub
              (i64.const -2)
              (local.get $1)
             )
            )
           )
           (local.get $1)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (else
       (if
        (i64.ne
         (i64.extend32_s
          (local.tee $1
           (i64.sub
            (i64.and
             (local.get $1)
             (i64.const 255)
            )
            (i64.const 1)
           )
          )
         )
         (local.get $1)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $5
   (if (result (ref $type43))
    (i32.eq
     (local.get $2)
     (i32.const -1)
    )
    (then
     (global.get $empty44)
    )
    (else
     (if
      (i64.gt_u
       (local.tee $1
        (i64.extend_i32_s
         (local.get $2)
        )
       )
       (i64.const 1114111)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.and
       (i64.le_u
        (local.get $1)
        (i64.const 57343)
       )
       (i64.ge_u
        (local.get $1)
        (i64.const 55296)
       )
      )
      (then
       (unreachable)
      )
     )
     (struct.new $type45
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready151)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (ref.as_non_null
    (global.get $global151)
   )
  )
  (if
   (i32.eqz
    (global.get $ready128)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global128)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (local.get $4)
   )
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (local.tee $2
       (struct.get $type26 0
        (local.tee $7
         (struct.get $type28 0
          (local.get $4)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.or
       (i32.eq
        (local.get $2)
        (i32.const -3)
       )
       (i32.eq
        (local.get $2)
        (i32.const -2)
       )
      )
     )
    )
   )
   (then
    (struct.set $type26 0
     (local.get $7)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $2)
    )
   )
  )
  (if (result i64)
   (ref.test (ref $type44)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function302
      (block (result (ref $type28))
       (local.set $scratch
        (ref.as_non_null
         (global.get $global152)
        )
       )
       (if
        (i32.eqz
         (global.get $ready136)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global136)
        )
       )
       (if
        (i32.eqz
         (global.get $ready132)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global132)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $5
     (if (result (ref $type43))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty44)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type45
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready134)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (if (result i64)
     (if (result i32)
      (ref.test (ref $type44)
       (local.get $5)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type45)
         (local.get $5)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i64.const 0)
     )
     (else
      (unreachable)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type45 0
      (ref.cast (ref $type45)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function302
      (block (result (ref $type28))
       (local.set $scratch_10
        (ref.as_non_null
         (global.get $global152)
        )
       )
       (if
        (i32.eqz
         (global.get $ready136)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global136)
        )
       )
       (if
        (i32.eqz
         (global.get $ready132)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global132)
        )
       )
       (local.get $scratch_10)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (ref.test (ref $type44)
      (local.tee $5
       (if (result (ref $type43))
        (i32.eq
         (local.get $2)
         (i32.const -1)
        )
        (then
         (global.get $empty44)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $1
            (i64.extend_i32_s
             (local.get $2)
            )
           )
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $1)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $1)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type45
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i32.eq
        (local.get $3)
        (local.tee $2
         (struct.get $type45 0
          (ref.cast (ref $type45)
           (local.get $5)
          )
         )
        )
       )
       (then
        (if
         (i32.eqz
          (global.get $ready153)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (struct.get $type26 0
          (struct.get $type25 0
           (block (result (ref $type25))
            (local.set $scratch_11
             (ref.as_non_null
              (global.get $global153)
             )
            )
            (if
             (i32.eqz
              (global.get $ready143)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global143)
             )
            )
            (local.get $scratch_11)
           )
          )
         )
         (local.get $2)
        )
        (if
         (i32.eqz
          (global.get $ready154)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global154)
         )
        )
        (return_call $function155
         (local.get $0)
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function302 (type $1) (param $0 (ref $type28)) (result i32)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type29))
  (if (result i32)
   (i32.lt_s
    (local.tee $2
     (struct.get $type26 0
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
    (i32.const 0)
   )
   (then
    (call $foreign3
     (local.get $2)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (struct.set $type29 0
     (local.tee $3
      (struct.get $type28 1
       (local.get $0)
      )
     )
     (block (result i64)
      (if
       (i64.eqz
        (local.tee $1
         (struct.get $type29 0
          (local.get $3)
         )
        )
       )
       (then
        (struct.set $type29 0
         (local.get $3)
         (local.tee $1
          (call $foreign4
           (struct.get $type26 0
            (struct.get $type28 0
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (select
       (i64.shr_u
        (local.get $1)
        (i64.const 8)
       )
       (i64.const 0)
       (i64.gt_s
        (local.get $1)
        (i64.const 0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready131)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global131)
     )
    )
    (if (result i32)
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const -1)
       )
       (then
        (i32.const -1)
       )
       (else
        (if
         (i64.ne
          (i64.extend32_s
           (local.tee $1
            (i64.sub
             (i64.const -2)
             (local.get $1)
            )
           )
          )
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (else
      (if
       (i64.ne
        (i64.extend32_s
         (local.tee $1
          (i64.sub
           (i64.and
            (local.get $1)
            (i64.const 255)
           )
           (i64.const 1)
          )
         )
        )
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $main (result i64)
  (local $0 (ref $type28))
  (local $1 i64)
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global117
   (struct.new $type25
    (struct.new $type26
     (call $foreign12)
    )
   )
  )
  (global.set $ready117
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type27)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global119
   (struct.new $type28
    (struct.new $type26
     (call $foreign13)
    )
    (struct.new_default $type29)
   )
  )
  (global.set $global120
   (struct.new_default $type30)
  )
  (global.set $global128
   (struct.new_default $type37)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type38)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type39)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global131
   (struct.new_default $type40)
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type41)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type41)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type42)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type46)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type47)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type47)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global143
   (struct.new_default $type55)
  )
  (global.set $ready143
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (global.set $global151
   (local.tee $0
    (ref.as_non_null
     (global.get $global119)
    )
   )
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $global152
   (local.get $0)
  )
  (global.set $ready152
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready117)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global153
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (global.set $ready153
   (i32.const 1)
  )
  (global.set $global154
   (struct.new_default $type5)
  )
  (global.set $ready154
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global154)
   )
  )
  (local.set $scratch
   (call $function155
    (ref.null none)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (local.get $scratch)
 )
)

