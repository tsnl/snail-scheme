(module
(rec (type $top-scalar (struct (field i32) (field i64))) (type $top-reference (struct (field i32) (field eqref))) (type $type0 (struct (field (mut i64)))))
(global $execution (mut i32) (i32.const 0))
(func $main (export "main") (local $local0 i64) (local $local1 (ref null $type0)) (local $local2 i64) (block (if (global.get $execution) (then (unreachable))) (global.set $execution (i32.const 1)) (drop (block (result i32) (block (result i32) (local.set $local1 (block (result (ref $type0)) (local.set $local0 (i64.const 0)) (struct.new $type0 (local.get $local0)))) (local.set $local2 (i64.const 1)) (block (result i32) (struct.set $type0 0 (ref.as_non_null (local.get $local1)) (local.get $local2)) (i32.const 0))))) (global.set $execution (i32.const 2))))
)
