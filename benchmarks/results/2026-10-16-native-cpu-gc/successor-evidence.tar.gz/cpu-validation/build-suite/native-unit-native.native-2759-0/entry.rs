unsafe extern "C" { fn native_module_init(); #[link_name = "wasm.main"] fn guest_main(); }
fn main() {
    snail_runtime::native::initialize_host();
    unsafe { native_module_init(); }
    unsafe { guest_main(); }
    let status = 0;
    std::process::exit(snail_runtime::native::native_finish(status));
}
