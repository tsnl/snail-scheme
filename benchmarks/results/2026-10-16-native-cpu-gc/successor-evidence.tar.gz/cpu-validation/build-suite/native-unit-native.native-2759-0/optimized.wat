(module
 (type $0 (func))
 (global $execution (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

