(module
 (rec
  (type $type12 (struct))
  (type $type66 (struct (field (ref $environment165))))
  (type $type68 (struct (field (ref $environment180))))
  (type $environment180 (struct (field (ref $type67))))
  (type $type67 (struct (field (mut i32)) (field (mut (ref null $type68)))))
  (type $5 (func (param (ref $environment390) i64) (result i32)))
  (type $type71 (struct (field (ref struct))))
  (type $environment390 (struct (field (ref $type69)) (field (ref $type70))))
  (type $8 (func (result (ref $type30))))
  (type $type70 (struct (field (mut i32)) (field (mut (ref null $type71)))))
  (type $type31 (struct (field i32)))
  (type $type69 (struct (field i64)))
  (type $environment232 (struct (field (ref $type30)) (field (ref $type69)) (field (ref $type70))))
  (type $13 (func (param (ref struct) i64) (result i32)))
  (type $type65 (struct (field (mut i32)) (field (mut (ref null $type66)))))
  (type $type13 (array (mut i64)))
  (type $type64 (struct (field (ref $type13))))
  (type $environment165 (struct (field (ref $type64)) (field (ref $type65))))
  (type $18 (func (param (ref $environment165) (ref null $type12) i64) (result (ref $type13))))
  (type $19 (func (param (ref $type19) i64) (result i32)))
  (type $type30 (struct (field (ref $type31))))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type39 (struct))
  (type $type37 (struct))
  (type $type15 (struct))
  (type $type14 (struct))
  (type $type11 (struct))
  (type $type19 (struct (field (mut i32)) (field (mut i32))))
  (type $type21 (array (mut i8)))
 )
 (type $30 (func (result i32)))
 (type $31 (func (param i32)))
 (type $32 (func (param i32 i32)))
 (type $33 (func))
 (type $34 (func (result i64)))
 (import "snail.library" "snail:io/check-output" (func $foreign0 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign1 (param i32 i32)))
 (import "snail.library" "snail:io/open-output-file" (func $foreign7 (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign10))
 (import "snail.library" "snail:io/path-character" (func $foreign11 (param i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign12 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign13 (result i32)))
 (global $global$0 (ref $type21) (array.new_fixed $type21 72
  (i32.const 47)
  (i32.const 116)
  (i32.const 109)
  (i32.const 112)
  (i32.const 47)
  (i32.const 115)
  (i32.const 110)
  (i32.const 97)
  (i32.const 105)
  (i32.const 108)
  (i32.const 45)
  (i32.const 110)
  (i32.const 97)
  (i32.const 116)
  (i32.const 105)
  (i32.const 118)
  (i32.const 101)
  (i32.const 45)
  (i32.const 99)
  (i32.const 112)
  (i32.const 117)
  (i32.const 45)
  (i32.const 118)
  (i32.const 97)
  (i32.const 108)
  (i32.const 105)
  (i32.const 100)
  (i32.const 97)
  (i32.const 116)
  (i32.const 105)
  (i32.const 111)
  (i32.const 110)
  (i32.const 45)
  (i32.const 50)
  (i32.const 48)
  (i32.const 50)
  (i32.const 54)
  (i32.const 49)
  (i32.const 48)
  (i32.const 49)
  (i32.const 54)
  (i32.const 47)
  (i32.const 98)
  (i32.const 117)
  (i32.const 105)
  (i32.const 108)
  (i32.const 100)
  (i32.const 45)
  (i32.const 115)
  (i32.const 117)
  (i32.const 105)
  (i32.const 116)
  (i32.const 101)
  (i32.const 47)
  (i32.const 99)
  (i32.const 108)
  (i32.const 101)
  (i32.const 97)
  (i32.const 110)
  (i32.const 117)
  (i32.const 112)
  (i32.const 45)
  (i32.const 110)
  (i32.const 97)
  (i32.const 116)
  (i32.const 105)
  (i32.const 118)
  (i32.const 101)
  (i32.const 46)
  (i32.const 116)
  (i32.const 120)
  (i32.const 116)
 ))
 (global $string0 (ref $type19) (struct.new $type19
  (i32.const 0)
  (i32.const 0)
 ))
 (global $global$2 (ref $type21) (array.new_fixed $type21 20
  (i32.const 98)
  (i32.const 117)
  (i32.const 102)
  (i32.const 102)
  (i32.const 101)
  (i32.const 114)
  (i32.const 101)
  (i32.const 100)
  (i32.const 32)
  (i32.const 98)
  (i32.const 101)
  (i32.const 102)
  (i32.const 111)
  (i32.const 114)
  (i32.const 101)
  (i32.const 32)
  (i32.const 116)
  (i32.const 114)
  (i32.const 97)
  (i32.const 112)
 ))
 (global $execution (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type11)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global154 (mut (ref null $type14)) (ref.null none))
 (global $ready154 (mut i32) (i32.const 0))
 (global $global172 (mut (ref null $type15)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type37)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type39)) (ref.null none))
 (global $global140 (mut (ref null $type60)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type61)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type30)) (ref.null none))
 (global $string1 (ref $type19) (struct.new $type19
  (i32.const 0)
  (i32.const 0)
 ))
 (export "main" (func $main))
 (func $string-ref (type $19) (param $0 (ref $type19)) (param $1 i64) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 (ref $type21))
  (local $7 (ref $type21))
  (if
   (i64.ge_u
    (local.get $1)
    (select
     (i64.const 72)
     (i64.const 20)
     (ref.eq
      (local.get $0)
      (global.get $string0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (block $block1 (result i32)
   (if
    (i32.lt_u
     (local.tee $2
      (array.get_u $type21
       (local.tee $7
        (select (result (ref $type21))
         (global.get $global$0)
         (global.get $global$2)
         (local.tee $5
          (ref.eq
           (local.get $0)
           (global.get $string0)
          )
         )
        )
       )
       (local.tee $3
        (block $block (result i32)
         (if
          (i32.gt_u
           (local.tee $3
            (i32.wrap_i64
             (local.get $1)
            )
           )
           (local.tee $5
            (select
             (i32.const 72)
             (i32.const 20)
             (local.get $5)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (br_if $block
           (local.get $3)
           (i32.eq
            (local.get $5)
            (select
             (i32.const 72)
             (i32.const 20)
             (ref.eq
              (local.get $0)
              (global.get $string0)
             )
            )
           )
          )
         )
         (local.set $4
          (struct.get $type19 1
           (local.get $0)
          )
         )
         (if
          (i32.lt_u
           (local.get $3)
           (select
            (i32.sub
             (local.tee $2
              (struct.get $type19 0
               (local.get $0)
              )
             )
             (local.get $3)
            )
            (i32.sub
             (local.get $3)
             (local.get $2)
            )
            (i32.gt_u
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (then
           (local.set $4
            (i32.const 0)
           )
           (local.set $2
            (i32.const 0)
           )
          )
         )
         (if
          (i32.lt_u
           (i32.sub
            (local.get $5)
            (local.get $3)
           )
           (select
            (i32.sub
             (local.get $2)
             (local.get $3)
            )
            (i32.sub
             (local.get $3)
             (local.get $2)
            )
            (i32.gt_u
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (then
           (local.set $4
            (select
             (i32.const 72)
             (i32.const 20)
             (ref.eq
              (local.get $0)
              (global.get $string0)
             )
            )
           )
           (local.set $2
            (local.get $5)
           )
          )
         )
         (local.set $6
          (select (result (ref $type21))
           (global.get $global$0)
           (global.get $global$2)
           (ref.eq
            (local.get $0)
            (global.get $string0)
           )
          )
         )
         (loop $label
          (if
           (i32.lt_u
            (local.get $2)
            (local.get $3)
           )
           (then
            (local.set $4
             (i32.add
              (if (result i32)
               (i32.lt_u
                (local.tee $5
                 (array.get_u $type21
                  (local.get $6)
                  (local.get $4)
                 )
                )
                (i32.const 128)
               )
               (then
                (i32.const 1)
               )
               (else
                (if (result i32)
                 (i32.lt_u
                  (local.get $5)
                  (i32.const 224)
                 )
                 (then
                  (i32.const 2)
                 )
                 (else
                  (select
                   (i32.const 3)
                   (i32.const 4)
                   (i32.lt_u
                    (local.get $5)
                    (i32.const 240)
                   )
                  )
                 )
                )
               )
              )
              (local.get $4)
             )
            )
            (local.set $2
             (i32.add
              (local.get $2)
              (i32.const 1)
             )
            )
            (br $label)
           )
          )
         )
         (loop $label2
          (if
           (i32.gt_u
            (local.get $2)
            (local.get $3)
           )
           (then
            (loop $label1
             (br_if $label1
              (i32.eq
               (i32.and
                (array.get_u $type21
                 (local.get $6)
                 (local.tee $4
                  (i32.sub
                   (local.get $4)
                   (i32.const 1)
                  )
                 )
                )
                (i32.const 192)
               )
               (i32.const 128)
              )
             )
            )
            (local.set $2
             (i32.sub
              (local.get $2)
              (i32.const 1)
             )
            )
            (br $label2)
           )
          )
         )
         (struct.set $type19 0
          (local.get $0)
          (local.get $3)
         )
         (struct.set $type19 1
          (local.get $0)
          (local.get $4)
         )
         (local.get $4)
        )
       )
      )
     )
     (i32.const 128)
    )
    (then
     (br $block1
      (local.get $2)
     )
    )
   )
   (local.set $2
    (i32.and
     (local.get $2)
     (i32.shr_u
      (i32.const 127)
      (local.tee $5
       (if (result i32)
        (i32.lt_u
         (local.get $2)
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $2)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $2)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.set $4
    (i32.const 1)
   )
   (loop $label3
    (local.set $2
     (i32.or
      (i32.and
       (array.get_u $type21
        (local.get $7)
        (i32.add
         (local.get $3)
         (local.get $4)
        )
       )
       (i32.const 63)
      )
      (i32.shl
       (local.get $2)
       (i32.const 6)
      )
     )
    )
    (br_if $label3
     (i32.lt_u
      (local.tee $4
       (i32.add
        (local.get $4)
        (i32.const 1)
       )
      )
      (local.get $5)
     )
    )
   )
   (local.get $2)
  )
 )
 (func $function165 (type $18) (param $0 (ref $environment165)) (param $1 (ref null $type12)) (param $2 i64) (result (ref $type13))
  (if (result (ref $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type64 0
     (struct.get $environment165 0
      (local.get $0)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (struct.get $type64 0
      (struct.get $environment165 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (i64.const 1)
    )
    (drop
     (ref.as_non_null
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type65 0
       (struct.get $environment165 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type65 1
       (struct.get $environment165 1
        (local.get $0)
       )
      )
     )
    )
    (return_call $function165
     (local.get $0)
     (ref.null none)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function232 (type $13) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment232))
  (local $3 i32)
  (if (result i32)
   (i64.eq
    (struct.get $type69 0
     (struct.get $environment232 1
      (ref.cast (ref $environment232)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $2
     (ref.cast (ref $environment232)
      (local.get $0)
     )
    )
    (local.set $3
     (call $string-ref
      (global.get $string1)
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready140)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global140)
     )
    )
    (call $foreign1
     (struct.get $type31 0
      (struct.get $type30 0
       (struct.get $environment232 0
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (struct.get $environment232 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type70 1
       (struct.get $environment232 2
        (local.get $2)
       )
      )
     )
    )
    (return_call $function232
     (local.get $2)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function364 (type $8) (result (ref $type30))
  (local $0 (ref $environment390))
  (local $1 (ref $type70))
  (local $2 (ref struct))
  (if
   (i32.eqz
    (global.get $ready119)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (call $foreign10)
  (struct.set $type70 1
   (local.tee $1
    (struct.new_default $type70)
   )
   (struct.new $type71
    (struct.new $environment390
     (struct.new $type69
      (i64.const 72)
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type70 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type70 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (if (result i32)
    (i64.eqz
     (struct.get $type69 0
      (struct.get $environment390 0
       (ref.cast (ref $environment390)
        (local.tee $2
         (struct.get $type71 0
          (struct.get $type70 1
           (local.get $1)
          )
         )
        )
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (local.set $0
      (ref.cast (ref $environment390)
       (local.get $2)
      )
     )
     (call $foreign11
      (call $string-ref
       (global.get $string0)
       (i64.const 0)
      )
     )
     (if
      (i32.eqz
       (struct.get $type70 0
        (struct.get $environment390 1
         (local.get $0)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (struct.get $type70 1
        (struct.get $environment390 1
         (local.get $0)
        )
       )
      )
     )
     (if (result i32)
      (i64.eq
       (struct.get $type69 0
        (struct.get $environment390 0
         (local.get $0)
        )
       )
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign11
        (call $string-ref
         (global.get $string0)
         (i64.const 1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type70 0
          (struct.get $environment390 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (struct.get $type70 1
          (struct.get $environment390 1
           (local.get $0)
          )
         )
        )
       )
       (if (result i32)
        (i64.eq
         (struct.get $type69 0
          (struct.get $environment390 0
           (local.get $0)
          )
         )
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign11
          (call $string-ref
           (global.get $string0)
           (i64.const 2)
          )
         )
         (if
          (i32.eqz
           (struct.get $type70 0
            (struct.get $environment390 1
             (local.get $0)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (struct.get $type70 1
            (struct.get $environment390 1
             (local.get $0)
            )
           )
          )
         )
         (if (result i32)
          (i64.eq
           (struct.get $type69 0
            (struct.get $environment390 0
             (local.get $0)
            )
           )
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign11
            (call $string-ref
             (global.get $string0)
             (i64.const 3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type70 0
              (struct.get $environment390 1
               (local.get $0)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (struct.get $type70 1
              (struct.get $environment390 1
               (local.get $0)
              )
             )
            )
           )
           (if (result i32)
            (i64.eq
             (struct.get $type69 0
              (struct.get $environment390 0
               (local.get $0)
              )
             )
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign11
              (call $string-ref
               (global.get $string0)
               (i64.const 4)
              )
             )
             (if
              (i32.eqz
               (struct.get $type70 0
                (struct.get $environment390 1
                 (local.get $0)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (struct.get $type70 1
                (struct.get $environment390 1
                 (local.get $0)
                )
               )
              )
             )
             (if (result i32)
              (i64.eq
               (struct.get $type69 0
                (struct.get $environment390 0
                 (local.get $0)
                )
               )
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign11
                (call $string-ref
                 (global.get $string0)
                 (i64.const 5)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type70 0
                  (struct.get $environment390 1
                   (local.get $0)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (struct.get $type70 1
                  (struct.get $environment390 1
                   (local.get $0)
                  )
                 )
                )
               )
               (if (result i32)
                (i64.eq
                 (struct.get $type69 0
                  (struct.get $environment390 0
                   (local.get $0)
                  )
                 )
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign11
                  (call $string-ref
                   (global.get $string0)
                   (i64.const 6)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type70 0
                    (struct.get $environment390 1
                     (local.get $0)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (struct.get $type70 1
                    (struct.get $environment390 1
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (struct.get $type69 0
                    (struct.get $environment390 0
                     (local.get $0)
                    )
                   )
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign11
                    (call $string-ref
                     (global.get $string0)
                     (i64.const 7)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type70 0
                      (struct.get $environment390 1
                       (local.get $0)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (struct.get $type70 1
                      (struct.get $environment390 1
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (struct.get $type69 0
                      (struct.get $environment390 0
                       (local.get $0)
                      )
                     )
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign11
                      (call $string-ref
                       (global.get $string0)
                       (i64.const 8)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type70 0
                        (struct.get $environment390 1
                         (local.get $0)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (struct.get $type70 1
                        (struct.get $environment390 1
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (struct.get $type69 0
                        (struct.get $environment390 0
                         (local.get $0)
                        )
                       )
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign11
                        (call $string-ref
                         (global.get $string0)
                         (i64.const 9)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type70 0
                          (struct.get $environment390 1
                           (local.get $0)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (struct.get $type70 1
                          (struct.get $environment390 1
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if (result i32)
                        (i64.eq
                         (struct.get $type69 0
                          (struct.get $environment390 0
                           (local.get $0)
                          )
                         )
                         (i64.const 10)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (call $foreign11
                          (call $string-ref
                           (global.get $string0)
                           (i64.const 10)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type70 0
                            (struct.get $environment390 1
                             (local.get $0)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (struct.get $type70 1
                            (struct.get $environment390 1
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (if (result i32)
                          (i64.eq
                           (struct.get $type69 0
                            (struct.get $environment390 0
                             (local.get $0)
                            )
                           )
                           (i64.const 11)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (call $foreign11
                            (call $string-ref
                             (global.get $string0)
                             (i64.const 11)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type70 0
                              (struct.get $environment390 1
                               (local.get $0)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (struct.get $type70 1
                              (struct.get $environment390 1
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (if (result i32)
                            (i64.eq
                             (struct.get $type69 0
                              (struct.get $environment390 0
                               (local.get $0)
                              )
                             )
                             (i64.const 12)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (call $foreign11
                              (call $string-ref
                               (global.get $string0)
                               (i64.const 12)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type70 0
                                (struct.get $environment390 1
                                 (local.get $0)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (struct.get $type70 1
                                (struct.get $environment390 1
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (if (result i32)
                              (i64.eq
                               (struct.get $type69 0
                                (struct.get $environment390 0
                                 (local.get $0)
                                )
                               )
                               (i64.const 13)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (call $foreign11
                                (call $string-ref
                                 (global.get $string0)
                                 (i64.const 13)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type70 0
                                  (struct.get $environment390 1
                                   (local.get $0)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (struct.get $type70 1
                                  (struct.get $environment390 1
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (call $function390
                                (local.get $0)
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (struct.new $type30
   (struct.new $type31
    (call $foreign7)
   )
  )
 )
 (func $function390 (type $5) (param $0 (ref $environment390)) (param $1 i64) (result i32)
  (if (result i32)
   (i64.eq
    (struct.get $type69 0
     (struct.get $environment390 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign11
     (call $string-ref
      (global.get $string0)
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (struct.get $environment390 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (struct.get $type70 1
       (struct.get $environment390 1
        (local.get $0)
       )
      )
     )
    )
    (return_call $function390
     (local.get $0)
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $main (result i64)
  (local $0 (ref $type70))
  (local $1 (ref $type67))
  (local $2 (ref $type65))
  (local $3 (ref $type30))
  (local $4 (ref $environment180))
  (local $5 i64)
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global149
   (struct.new_default $type11)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global154
   (struct.new_default $type14)
  )
  (global.set $ready154
   (i32.const 1)
  )
  (global.set $global172
   (struct.new_default $type15)
  )
  (global.set $ready172
   (i32.const 1)
  )
  (drop
   (call $foreign12)
  )
  (drop
   (call $foreign13)
  )
  (global.set $global119
   (struct.new_default $type37)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type39)
  )
  (global.set $global140
   (struct.new_default $type60)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type61)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (global.set $global148
   (call $function364)
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global148)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (call $foreign0
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $3)
    )
   )
  )
  (struct.set $type70 1
   (local.tee $0
    (struct.new_default $type70)
   )
   (struct.new $type71
    (struct.new $environment232
     (local.get $3)
     (struct.new $type69
      (i64.const 20)
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type70 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type70 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function232
    (struct.get $type71 0
     (struct.get $type70 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready149)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global149)
   )
  )
  (if
   (i32.eqz
    (global.get $ready154)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global154)
   )
  )
  (if
   (i32.eqz
    (global.get $ready172)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global172)
   )
  )
  (struct.set $type67 1
   (local.tee $1
    (struct.new_default $type67)
   )
   (struct.new $type68
    (struct.new $environment180
     (local.get $1)
    )
   )
  )
  (struct.set $type67 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (struct.get $environment180 0
      (local.tee $4
       (struct.get $type68 0
        (struct.get $type67 1
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (struct.get $type67 1
     (struct.get $environment180 0
      (local.get $4)
     )
    )
   )
  )
  (struct.set $type65 1
   (local.tee $2
    (struct.new_default $type65)
   )
   (struct.new $type66
    (struct.new $environment165
     (struct.new $type64
      (array.new_fixed $type13 1
       (i64.const 1)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type65 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type65 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch
   (array.get $type13
    (call $function165
     (struct.get $type66 0
      (struct.get $type65 1
       (local.get $2)
      )
     )
     (struct.new_default $type12)
     (i64.const 0)
    )
    (i32.const 2)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
  (local.get $scratch)
 )
)

