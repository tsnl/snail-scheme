fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/build-suite/cleanup-native.native-4314-0/module.bc");
}
