(module
 (type $0 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const -1)
 )
)

