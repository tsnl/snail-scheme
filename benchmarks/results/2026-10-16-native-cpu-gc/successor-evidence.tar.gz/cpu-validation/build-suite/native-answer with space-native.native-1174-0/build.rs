fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/build-suite/native-answer with space-native.native-1174-0/module.bc");
}
