(module
 (type $0 (func (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (export "main" (func $main))
 (func $main (result i32)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i32.const 42)
 )
)

