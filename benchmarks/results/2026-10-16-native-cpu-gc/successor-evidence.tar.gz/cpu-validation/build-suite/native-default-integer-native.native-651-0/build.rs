fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/build-suite/native-default-integer-native.native-651-0/module.bc");
}
