fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/build-suite/published.native-3262-0/module.bc");
}
