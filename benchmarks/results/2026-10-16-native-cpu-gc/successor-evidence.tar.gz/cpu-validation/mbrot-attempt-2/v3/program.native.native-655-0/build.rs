fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/mbrot-attempt-2/v3/program.native.native-655-0/module.bc");
}
