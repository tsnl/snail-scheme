fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/mbrot-attempt-2/default/program.native.native-10-0/module.bc");
}
