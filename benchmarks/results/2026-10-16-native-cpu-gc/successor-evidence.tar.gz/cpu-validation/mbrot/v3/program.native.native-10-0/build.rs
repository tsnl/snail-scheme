fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/mbrot/v3/program.native.native-10-0/module.bc");
}
