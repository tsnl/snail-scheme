fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/adapter/saved-default-linked-v3/program.native-4-0/module.o");
}
