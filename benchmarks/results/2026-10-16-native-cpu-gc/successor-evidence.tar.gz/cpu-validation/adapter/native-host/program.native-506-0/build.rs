fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-cpu-validation-20261016/adapter/native-host/program.native-506-0/module.bc");
}
