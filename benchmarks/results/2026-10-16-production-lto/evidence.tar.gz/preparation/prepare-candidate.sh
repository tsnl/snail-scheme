#!/bin/sh
set -eu
task_root=/tmp/snail-native-shared-lto-current-20261016
cd "$task_root"
exec env -u NODE_OPTIONS -u NODE_V8_COVERAGE -u LD_PRELOAD -u SNAIL_GC_STATS -u SNAIL_NATIVE_GC_INTERVAL -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS \
  RUSTC_WRAPPER="$task_root/wasm-native/scripts/rustc-native" \
  chibi-scheme -I src -I wasm-native/scheme -I benchmarks benchmarks/sfir/timing.scm prepare \
  --output /tmp/sfir-native-production-six-20261016/candidate \
  --benchmarks fib fibfp mbrot array1 bv2string gcbench --compile-timeout 1800 --run-timeout 1800 --cpu 2
