fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/timing/artifacts/fibfp/program.native.native-799834-0/module.o");
}
