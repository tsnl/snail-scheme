fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/timing/artifacts/array1/program.native.native-806507-0/module.o");
}
