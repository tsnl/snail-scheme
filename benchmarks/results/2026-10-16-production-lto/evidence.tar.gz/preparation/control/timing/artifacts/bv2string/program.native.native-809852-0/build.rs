fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/timing/artifacts/bv2string/program.native.native-809852-0/module.o");
}
