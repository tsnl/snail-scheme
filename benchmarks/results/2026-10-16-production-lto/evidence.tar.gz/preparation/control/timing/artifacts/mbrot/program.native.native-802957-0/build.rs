fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/timing/artifacts/mbrot/program.native.native-802957-0/module.o");
}
