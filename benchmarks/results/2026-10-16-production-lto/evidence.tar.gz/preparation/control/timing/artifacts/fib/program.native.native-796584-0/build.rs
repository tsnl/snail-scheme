fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/timing/artifacts/fib/program.native.native-796584-0/module.o");
}
