fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/validation/bv2string/program.native.native-789234-0/module.o");
}
