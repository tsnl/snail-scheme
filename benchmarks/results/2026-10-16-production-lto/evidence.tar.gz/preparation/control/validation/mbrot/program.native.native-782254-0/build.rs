fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/validation/mbrot/program.native.native-782254-0/module.o");
}
