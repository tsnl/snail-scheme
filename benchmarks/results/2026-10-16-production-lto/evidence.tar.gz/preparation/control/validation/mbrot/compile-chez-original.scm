(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-native-production-six-20261016/control/source/benchmarks/sfir/mbrot/chez-original.scm" "/tmp/sfir-native-production-six-20261016/control/validation/mbrot/chez-original.so"))
