fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/validation/fibfp/program.native.native-779038-0/module.o");
}
