fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/validation/array1/program.native.native-785894-0/module.o");
}
