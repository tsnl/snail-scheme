(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-native-production-six-20261016/control/source/benchmarks/sfir/array1/chez-original.scm" "/tmp/sfir-native-production-six-20261016/control/validation/array1/chez-original.so"))
