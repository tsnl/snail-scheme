(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-native-production-six-20261016/control/source/benchmarks/sfir/gcbench/chez-adapted.scm" "/tmp/sfir-native-production-six-20261016/control/validation/gcbench/chez-adapted.so"))
