fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/control/validation/gcbench/program.native.native-792729-0/module.o");
}
