import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
const root = '/tmp/sfir-native-production-six-20261016';
const read = path => JSON.parse(fs.readFileSync(path, 'utf8'));
const hash = path => crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex');
const names = ['fib', 'fibfp', 'mbrot', 'array1', 'bv2string', 'gcbench'];
const output = [];
for (const name of names) {
  const item = {name, arms: {}};
  for (const arm of ['control', 'candidate']) {
    const directory = `${root}/${arm}`;
    const row = read(`${directory}/validation.json`).cases.find(row => row.name === name);
    assert.equal(row.scheduler_validation, 'passed', `${arm}/${name}`);
    for (const key of ['wasm_validation', 'native_validation', 'chez_validation', 'rust_wasm_validation', 'rust_native_validation']) {
      assert.equal(row[key], 'passed', `${arm}/${name}/${key}`);
    }
    assert.equal(row.chez_adapted_validation, ['fib', 'fibfp', 'array1'].includes(name) ? 'unavailable' : 'passed');
    const process = read(`${directory}/${row.validation_process}`);
    assert.equal(process.returncode, 0);
    assert.equal(process.descendants_gone, true);
    assert.equal(process.timeout, false);
    assert.deepEqual(process.unexpected_descendants, []);
    assert.deepEqual(process.executing_descendants, []);
    const target = `${directory}/validation/${name}`;
    assert.equal(read(`${target}/native-parity.json`).status, 'passed');
    const attempts = fs.readdirSync(target).filter(name => name.startsWith('program.native.native-'));
    assert.equal(attempts.length, 1);
    const raw = hash(`${target}/program.wasm.raw.wasm`);
    const optimized = hash(`${target}/program.wasm`);
    assert.equal(raw, row.raw_sha256);
    assert.equal(optimized, row.optimized_sha256);
    assert.equal(hash(`${target}/${attempts[0]}/optimized.wasm`), optimized);
    item.arms[arm] = {rawSha256: raw, optimizedSha256: optimized, availableRoutesPassed: row.chez_adapted_validation === 'passed' ? 6 : 5};
  }
  assert.deepEqual(item.arms.control, item.arms.candidate);
  output.push(item);
}
const result = {status: 'passed', cases: output, totalAvailableRoutesPassed: 66,
  unavailableAdaptedRows: 6, performanceSamples: false};
fs.writeFileSync(`${root}/wasm-parity.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({status: result.status, cases: output.length, routesPassed: result.totalAvailableRoutesPassed, unavailable: result.unavailableAdaptedRows}));
