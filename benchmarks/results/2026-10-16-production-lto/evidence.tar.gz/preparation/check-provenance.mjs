import assert from 'node:assert/strict';
import fs from 'node:fs';
const root = '/tmp/sfir-native-production-six-20261016';
const manifests = ['control', 'candidate'].map(arm => JSON.parse(fs.readFileSync(`${root}/${arm}/manifest.json`, 'utf8')));
const [control, candidate] = manifests;
assert.equal(control.source_revision, 'bb2e90f713ad96b381b1843438c56724620c046e');
assert.equal(candidate.source_revision, 'f320ef2f1b160ed85b3823696d4a916ab352f0d4');
assert.equal(control.source_status, '');
assert.equal(candidate.source_status, '');
assert.deepEqual(control.cases, candidate.cases);
assert.deepEqual(control.inputs, candidate.inputs);
assert.deepEqual(Object.keys(control.files), Object.keys(candidate.files));
const changed = Object.keys(control.files).filter(path => control.files[path] !== candidate.files[path]);
const expected = [
  'benchmarks/sfir/README.md', 'benchmarks/sfir/support.sld',
  'benchmarks/sfir/support/integer-provider.rs', 'benchmarks/sfir/support/scalar-provider.rs',
  'scripts/build-native.scm', 'wasm-native/README.md', 'wasm-native/scheme/wasm-native.sld',
  'wasm-native/scheme/wasm-native/native-build.sld', 'wasm-native/tests/standalone.scm'
];
assert.deepEqual(changed.sort(), expected.sort());
const inactive = ['NODE_OPTIONS', 'NODE_V8_COVERAGE', 'LD_PRELOAD', 'SNAIL_GC_STATS',
  'SNAIL_NATIVE_GC_INTERVAL', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
  'CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS'];
for (const manifest of manifests) {
  for (const key of inactive) {
    assert([null, undefined, '', false].includes(manifest.execution_environment[key]), key);
  }
}
const result = {control: control.source_revision, candidate: candidate.source_revision,
  cases: control.cases.map(value => value.name), workloadAndInputIdentitiesEqual: true,
  frontendLoweringAndRustRuntimeIdentitiesEqual: true, intendedBuildAndProviderDifferences: changed,
  observationAndExtraRustFlagsInactive: true, measurements: 'not started'};
fs.writeFileSync(`${root}/provenance.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
