0000000000013d70 <wasm_native_13c215a62028f942bc36e3d5b4019f7cec8ef5659c6930aa3d0ba91c5a28a44d::run::h5e83c3f7a6dc9c5d>:
   13d70:      	pushq	%rbp
   13d71:      	pushq	%r14
   13d73:      	pushq	%rbx
   13d74:      	subq	$0x50, %rsp
   13d78:      	callq	*0x4c8f2(%rip)          # 0x60670 <writev+0x60670>
   13d7e:      	callq	*0x4c8f4(%rip)          # 0x60678 <writev+0x60678>
   13d84:      	callq	*0x4c8f6(%rip)          # 0x60680 <writev+0x60680>
   13d8a:      	callq	0x53fb0 <<std::sys::pal::unix::time::Timespec>::now>
   13d8f:      	movq	%rax, %r14
   13d92:      	movl	%edx, %ebp
   13d94:      	movl	$0x64, %edi
   13d99:      	callq	*0x4c8e9(%rip)          # 0x60688 <writev+0x60688>
   13d9f:      	movq	%rax, %rbx
   13da2:      	movq	%rax, 0x28(%rsp)
   13da7:      	callq	0x53fb0 <<std::sys::pal::unix::time::Timespec>::now>
   13dac:      	movq	%rax, 0x40(%rsp)
   13db1:      	movl	%edx, 0x48(%rsp)
   13db5:      	movq	%r14, 0x30(%rsp)
   13dba:      	movl	%ebp, 0x38(%rsp)
   13dbe:      	leaq	0x8(%rsp), %rdi
   13dc3:      	leaq	0x40(%rsp), %rsi
   13dc8:      	leaq	0x30(%rsp), %r14
   13dcd:      	movq	%r14, %rdx
   13dd0:      	callq	0x53ee0 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   13dd5:      	cmpb	$0x0, 0x8(%rsp)
   13dda:      	xorpd	%xmm0, %xmm0
   13dde:      	jne	0x13e16 <wasm_native_13c215a62028f942bc36e3d5b4019f7cec8ef5659c6930aa3d0ba91c5a28a44d::run::h5e83c3f7a6dc9c5d+0xa6>
   13de0:      	movsd	0x10(%rsp), %xmm1
   13de6:      	unpcklps	-0xf80d(%rip), %xmm1    # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x45e0 <writev+0x45e0>
   13ded:      	subpd	-0xf865(%rip), %xmm1    # 0x4590 <writev+0x4590>
   13df5:      	movapd	%xmm1, %xmm2
   13df9:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   13dfd:      	xorps	%xmm0, %xmm0
   13e00:      	cvtsi2sdl	0x18(%rsp), %xmm0
   13e06:      	addsd	%xmm1, %xmm2
   13e0a:      	divsd	-0xf602(%rip), %xmm0    # 0x4810 <writev+0x4810>
   13e12:      	addsd	%xmm2, %xmm0
   13e16:      	movsd	%xmm0, 0x30(%rsp)
   13e1c:      	cmpq	$0x1, %rbx
   13e20:      	jne	0x13e83 <wasm_native_13c215a62028f942bc36e3d5b4019f7cec8ef5659c6930aa3d0ba91c5a28a44d::run::h5e83c3f7a6dc9c5d+0x113>
   13e22:      	leaq	0x28(%rsp), %rax
   13e27:      	movq	%rax, 0x8(%rsp)
   13e2c:      	leaq	0x6c0d(%rip), %rax      # 0x1aa40 <<i64 as core::fmt::Display>::fmt>
   13e33:      	movq	%rax, 0x10(%rsp)
   13e38:      	movq	%r14, 0x18(%rsp)
   13e3d:      	leaq	0x8adc(%rip), %rax      # 0x1c920 <<f64 as core::fmt::Display>::fmt>
   13e44:      	movq	%rax, 0x20(%rsp)
   13e49:      	leaq	-0xdb64(%rip), %rdi     # 0x62ec <writev+0x62ec>
   13e50:      	leaq	0x8(%rsp), %rsi
   13e55:      	callq	0x58e30 <std::io::stdio::_print>
   13e5a:      	leaq	0x8(%rsp), %rdi
   13e5f:      	callq	0x27440 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13e64:      	movq	0x8(%rsp), %rbx
   13e69:      	testq	%rbx, %rbx
   13e6c:      	jle	0x13e79 <wasm_native_13c215a62028f942bc36e3d5b4019f7cec8ef5659c6930aa3d0ba91c5a28a44d::run::h5e83c3f7a6dc9c5d+0x109>
   13e6e:      	movq	0x10(%rsp), %rdi
   13e73:      	callq	*0x4c817(%rip)          # 0x60690 <writev+0x60690>
   13e79:      	xorl	%eax, %eax
   13e7b:      	negq	%rbx
   13e7e:      	setno	%al
   13e81:      	jmp	0x13ea5 <wasm_native_13c215a62028f942bc36e3d5b4019f7cec8ef5659c6930aa3d0ba91c5a28a44d::run::h5e83c3f7a6dc9c5d+0x135>
   13e83:      	leaq	0x8(%rsp), %rdi
   13e88:      	callq	0x27440 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13e8d:      	cmpq	$0x0, 0x8(%rsp)
   13e93:      	jle	0x13ea0 <wasm_native_13c215a62028f942bc36e3d5b4019f7cec8ef5659c6930aa3d0ba91c5a28a44d::run::h5e83c3f7a6dc9c5d+0x130>
   13e95:      	movq	0x10(%rsp), %rdi
   13e9a:      	callq	*0x4c7f0(%rip)          # 0x60690 <writev+0x60690>
   13ea0:      	movl	$0x1, %eax
   13ea5:      	addq	$0x50, %rsp
   13ea9:      	popq	%rbx
   13eaa:      	popq	%r14
   13eac:      	popq	%rbp
   13ead:      	retq
   13eae:      	int3
   13eaf:      	int3
