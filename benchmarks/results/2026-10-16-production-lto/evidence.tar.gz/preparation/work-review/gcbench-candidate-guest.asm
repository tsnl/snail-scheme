0000000000058d60 <f.5>:
   58d60:      	pushq	%rbp
   58d61:      	pushq	%r15
   58d63:      	pushq	%r14
   58d65:      	pushq	%r13
   58d67:      	pushq	%r12
   58d69:      	pushq	%rbx
   58d6a:      	subq	$0x68, %rsp
   58d6e:      	movq	%rsi, %rbx
   58d71:      	movq	$0x7, 0x10(%rsp)
   58d7a:      	movq	$0x0, 0x18(%rsp)
   58d83:      	movq	0xb146(%rip), %rsi      # 0x63ed0 <native_roots.0>
   58d8a:      	movq	%rsi, 0x8(%rsp)
   58d8f:      	leaq	0x8(%rsp), %rcx
   58d94:      	movq	0xb115(%rip), %rdx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58d9b:      	incq	%rdx
   58d9e:      	movq	0xb113(%rip), %rax      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58da5:      	cmpq	%rax, %rdx
   58da8:      	cmovaq	%rdx, %rax
   58dac:      	movq	%rcx, 0xb11d(%rip)      # 0x63ed0 <native_roots.0>
   58db3:      	movq	%rdx, 0xb0f6(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58dba:      	movq	%rax, 0xb0f7(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58dc1:      	movq	%rdi, 0x20(%rsp)
   58dc6:      	xorps	%xmm0, %xmm0
   58dc9:      	movups	%xmm0, 0x28(%rsp)
   58dce:      	movq	$0x0, 0x38(%rsp)
   58dd7:      	testq	%rdi, %rdi
   58dda:      	je	0x59946 <f.5+0xbe6>
   58de0:      	movl	%edi, %eax
   58de2:      	andl	$0x1, %eax
   58de5:      	jne	0x59946 <f.5+0xbe6>
   58deb:      	movq	0xb0d6(%rip), %rax      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58df2:      	testq	%rax, %rax
   58df5:      	je	0x59946 <f.5+0xbe6>
   58dfb:      	movq	(%rdi), %rcx
   58dfe:      	movq	%rcx, %r8
   58e01:      	testq	%rcx, %rcx
   58e04:      	je	0x58e71 <f.5+0x111>
   58e06:      	movq	%rcx, %r8
   58e09:      	cmpq	$0x76, %rcx
   58e0d:      	je	0x58e71 <f.5+0x111>
   58e0f:      	movq	0x168(%rax), %r9
   58e16:      	movq	%rcx, %r8
   58e19:      	shrq	$0x2, %r8
   58e1d:      	leaq	-0x1(%r8), %r10
   58e21:      	cmpq	%r9, %r10
   58e24:      	jae	0x59946 <f.5+0xbe6>
   58e2a:      	movq	0x160(%rax), %r10
   58e31:      	movq	-0x8(%r10,%r8,8), %r8
   58e36:      	testq	%r8, %r8
   58e39:      	je	0x58e71 <f.5+0x111>
   58e3b:      	cmpq	$0x76, %r8
   58e3f:      	je	0x58e71 <f.5+0x111>
   58e41:      	nopw	%cs:(%rax,%rax)
   58e50:      	shrq	$0x2, %r8
   58e54:      	leaq	-0x1(%r8), %r11
   58e58:      	cmpq	%r9, %r11
   58e5b:      	jae	0x59946 <f.5+0xbe6>
   58e61:      	movq	-0x8(%r10,%r8,8), %r8
   58e66:      	cmpq	$0x76, %r8
   58e6a:      	je	0x58e71 <f.5+0x111>
   58e6c:      	testq	%r8, %r8
   58e6f:      	jne	0x58e50 <f.5+0xf0>
   58e71:      	cmpq	$0x76, %r8
   58e75:      	jne	0x59946 <f.5+0xbe6>
   58e7b:      	leaq	0x8f16(%rip), %r13      # 0x61d98 <ref.19>
   58e82:      	jmp	0x58e9d <f.5+0x13d>
   58e84:      	nopw	%cs:(%rax,%rax)
   58e90:      	incq	%rbx
   58e93:      	cmpq	$0x76, %r8
   58e97:      	jne	0x59946 <f.5+0xbe6>
   58e9d:      	cmpq	%rbx, 0x8(%rdi)
   58ea1:      	je	0x59922 <f.5+0xbc2>
   58ea7:      	testb	$0x1, %dil
   58eab:      	jne	0x59946 <f.5+0xbe6>
   58eb1:      	testq	%rcx, %rcx
   58eb4:      	je	0x58f20 <f.5+0x1c0>
   58eb6:      	cmpq	$0x76, %rcx
   58eba:      	je	0x58f20 <f.5+0x1c0>
   58ebc:      	movq	0x168(%rax), %rdx
   58ec3:      	shrq	$0x2, %rcx
   58ec7:      	leaq	-0x1(%rcx), %rsi
   58ecb:      	cmpq	%rdx, %rsi
   58ece:      	jae	0x59946 <f.5+0xbe6>
   58ed4:      	movq	0x160(%rax), %rax
   58edb:      	movq	-0x8(%rax,%rcx,8), %rcx
   58ee0:      	testq	%rcx, %rcx
   58ee3:      	je	0x58f20 <f.5+0x1c0>
   58ee5:      	cmpq	$0x76, %rcx
   58ee9:      	je	0x58f20 <f.5+0x1c0>
   58eeb:      	nopl	(%rax,%rax)
   58ef0:      	shrq	$0x2, %rcx
   58ef4:      	leaq	-0x1(%rcx), %rsi
   58ef8:      	cmpq	%rdx, %rsi
   58efb:      	jae	0x59946 <f.5+0xbe6>
   58f01:      	movq	-0x8(%rax,%rcx,8), %rcx
   58f06:      	cmpq	$0x76, %rcx
   58f0a:      	je	0x58f20 <f.5+0x1c0>
   58f0c:      	testq	%rcx, %rcx
   58f0f:      	jne	0x58ef0 <f.5+0x190>
   58f11:      	nopw	%cs:(%rax,%rax)
   58f20:      	cmpq	$0x76, %rcx
   58f24:      	jne	0x59946 <f.5+0xbe6>
   58f2a:      	cmpb	$0x0, 0xb147(%rip)      # 0x64078 <g.29>
   58f31:      	je	0x59946 <f.5+0xbe6>
   58f37:      	cmpb	$0x0, 0xb0fa(%rip)      # 0x64038 <g.21>
   58f3e:      	je	0x59946 <f.5+0xbe6>
   58f44:      	cmpq	$0x0, 0xb0e4(%rip)      # 0x64030 <g.20>
   58f4c:      	je	0x59946 <f.5+0xbe6>
   58f52:      	movq	0xb117(%rip), %rax      # 0x64070 <g.28>
   58f59:      	movq	$0x4, 0x18(%rsp)
   58f62:      	movq	%rax, 0x58(%rsp)
   58f67:      	leaq	0x58(%rsp), %rax
   58f6c:      	cmpb	$0x0, 0xb0f5(%rip)      # 0x64068 <g.27>
   58f73:      	je	0x59946 <f.5+0xbe6>
   58f79:      	cmpq	$0x0, 0xb0df(%rip)      # 0x64060 <g.26>
   58f81:      	je	0x59946 <f.5+0xbe6>
   58f87:      	cmpb	$0x0, 0xb07a(%rip)      # 0x64008 <g.15>
   58f8e:      	je	0x59946 <f.5+0xbe6>
   58f94:      	cmpq	$0x0, 0xb064(%rip)      # 0x64000 <g.14>
   58f9c:      	je	0x59946 <f.5+0xbe6>
   58fa2:      	movq	0x58(%rsp), %rbp
   58fa7:      	movq	$0x4, 0x18(%rsp)
   58fb0:      	movq	0xaf11(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58fb7:      	testq	%rdi, %rdi
   58fba:      	je	0x59946 <f.5+0xbe6>
   58fc0:      	movq	0x178(%rdi), %rcx
   58fc7:      	testq	%rcx, %rcx
   58fca:      	je	0x59009 <f.5+0x2a9>
   58fcc:      	movq	0x170(%rdi), %rax
   58fd3:      	incq	%rax
   58fd6:      	movq	%rax, 0x170(%rdi)
   58fdd:      	movq	%rax, %rdx
   58fe0:      	orq	%rcx, %rdx
   58fe3:      	shrq	$0x20, %rdx
   58fe7:      	je	0x59810 <f.5+0xab0>
   58fed:      	xorl	%edx, %edx
   58fef:      	divq	%rcx
   58ff2:      	testq	%rdx, %rdx
   58ff5:      	jne	0x59009 <f.5+0x2a9>
   58ff7:      	movq	0xaed2(%rip), %rsi      # 0x63ed0 <native_roots.0>
   58ffe:      	movq	%rdi, %r14
   59001:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59006:      	movq	%r14, %rdi
   59009:      	movq	0xaec0(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59010:      	movl	$0x18, %esi
   59015:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5901a:      	testq	%rax, %rax
   5901d:      	je	0x5994b <f.5+0xbeb>
   59023:      	movq	%rax, %r14
   59026:      	movq	$0x7a, (%rax)
   5902d:      	movl	$0x0, 0x8(%rax)
   59034:      	movq	$0x0, 0x10(%rax)
   5903c:      	movq	%rax, 0x28(%rsp)
   59041:      	movq	%rax, 0x40(%rsp)
   59046:      	movq	%r13, 0x48(%rsp)
   5904b:      	movq	%rax, 0x50(%rsp)
   59050:      	movq	$0x7, 0x18(%rsp)
   59059:      	movq	0xae68(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59060:      	testq	%rdi, %rdi
   59063:      	je	0x59946 <f.5+0xbe6>
   59069:      	movq	0x178(%rdi), %rcx
   59070:      	testq	%rcx, %rcx
   59073:      	je	0x590b2 <f.5+0x352>
   59075:      	movq	0x170(%rdi), %rax
   5907c:      	incq	%rax
   5907f:      	movq	%rax, 0x170(%rdi)
   59086:      	movq	%rax, %rdx
   59089:      	orq	%rcx, %rdx
   5908c:      	shrq	$0x20, %rdx
   59090:      	je	0x59830 <f.5+0xad0>
   59096:      	xorl	%edx, %edx
   59098:      	divq	%rcx
   5909b:      	testq	%rdx, %rdx
   5909e:      	jne	0x590b2 <f.5+0x352>
   590a0:      	movq	0xae29(%rip), %rsi      # 0x63ed0 <native_roots.0>
   590a7:      	movq	%rdi, %r15
   590aa:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   590af:      	movq	%r15, %rdi
   590b2:      	movq	0xae17(%rip), %rdx      # 0x63ed0 <native_roots.0>
   590b9:      	movl	$0x10, %esi
   590be:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   590c3:      	testq	%rax, %rax
   590c6:      	je	0x5994b <f.5+0xbeb>
   590cc:      	movq	%rax, %r15
   590cf:      	movq	$0x72, (%rax)
   590d6:      	movq	%r14, 0x8(%rax)
   590da:      	movq	%rax, 0x40(%rsp)
   590df:      	movq	%r13, 0x48(%rsp)
   590e4:      	movq	%r14, 0x50(%rsp)
   590e9:      	movq	$0x7, 0x18(%rsp)
   590f2:      	movq	0xadcf(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   590f9:      	testq	%rdi, %rdi
   590fc:      	je	0x59946 <f.5+0xbe6>
   59102:      	movq	0x178(%rdi), %rcx
   59109:      	testq	%rcx, %rcx
   5910c:      	je	0x5914b <f.5+0x3eb>
   5910e:      	movq	0x170(%rdi), %rax
   59115:      	incq	%rax
   59118:      	movq	%rax, 0x170(%rdi)
   5911f:      	movq	%rax, %rdx
   59122:      	orq	%rcx, %rdx
   59125:      	shrq	$0x20, %rdx
   59129:      	je	0x59850 <f.5+0xaf0>
   5912f:      	xorl	%edx, %edx
   59131:      	divq	%rcx
   59134:      	testq	%rdx, %rdx
   59137:      	jne	0x5914b <f.5+0x3eb>
   59139:      	movq	0xad90(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59140:      	movq	%rdi, %r12
   59143:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59148:      	movq	%r12, %rdi
   5914b:      	movq	0xad7e(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59152:      	movl	$0x18, %esi
   59157:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5915c:      	testq	%rax, %rax
   5915f:      	je	0x5994b <f.5+0xbeb>
   59165:      	movq	$0x92, (%rax)
   5916c:      	movq	%r13, 0x8(%rax)
   59170:      	movq	%r15, 0x10(%rax)
   59174:      	movq	%rax, 0x10(%r14)
   59178:      	movq	0x28(%rsp), %rax
   5917d:      	testq	%rax, %rax
   59180:      	je	0x59946 <f.5+0xbe6>
   59186:      	movl	$0x1, 0x8(%rax)
   5918d:      	movq	0x28(%rsp), %rax
   59192:      	testq	%rax, %rax
   59195:      	je	0x59946 <f.5+0xbe6>
   5919b:      	cmpl	$0x0, 0x8(%rax)
   5919f:      	je	0x59946 <f.5+0xbe6>
   591a5:      	movq	0x10(%rax), %rax
   591a9:      	testq	%rax, %rax
   591ac:      	je	0x59946 <f.5+0xbe6>
   591b2:      	movq	%rax, 0x30(%rsp)
   591b7:      	movq	0x8(%rax), %rcx
   591bb:      	testq	%rcx, %rcx
   591be:      	je	0x59946 <f.5+0xbe6>
   591c4:      	leaq	-0x1(%rbp), %rsi
   591c8:      	movq	0x10(%rax), %rdi
   591cc:      	movq	0x8(%rcx), %rax
   591d0:      	movq	%rdi, 0x40(%rsp)
   591d5:      	movq	$0x5, 0x18(%rsp)
   591de:      	movl	$0x1, %edx
   591e3:      	callq	*%rax
   591e5:      	subq	$0x8, %rsp
   591e9:      	movq	$0x4, 0x18(%rsp)
   591f2:      	movq	0xaccf(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   591f9:      	testq	%rdi, %rdi
   591fc:      	je	0x59946 <f.5+0xbe6>
   59202:      	movq	%rax, %r14
   59205:      	movq	0x178(%rdi), %rcx
   5920c:      	testq	%rcx, %rcx
   5920f:      	je	0x5924e <f.5+0x4ee>
   59211:      	movq	0x170(%rdi), %rax
   59218:      	incq	%rax
   5921b:      	movq	%rax, 0x170(%rdi)
   59222:      	movq	%rax, %rdx
   59225:      	orq	%rcx, %rdx
   59228:      	shrq	$0x20, %rdx
   5922c:      	je	0x59870 <f.5+0xb10>
   59232:      	xorl	%edx, %edx
   59234:      	divq	%rcx
   59237:      	testq	%rdx, %rdx
   5923a:      	jne	0x5924e <f.5+0x4ee>
   5923c:      	movq	0xac8d(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59243:      	movq	%rdi, %r15
   59246:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5924b:      	movq	%r15, %rdi
   5924e:      	movq	0xac7b(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59255:      	movl	$0x10, %esi
   5925a:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5925f:      	testq	%rax, %rax
   59262:      	je	0x5994b <f.5+0xbeb>
   59268:      	movq	%rax, %r12
   5926b:      	movq	$0x96, (%rax)
   59272:      	movq	$0x0, 0x8(%rax)
   5927a:      	movq	%rax, 0x40(%rsp)
   5927f:      	movq	$0x5, 0x18(%rsp)
   59288:      	movq	0xac39(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5928f:      	testq	%rdi, %rdi
   59292:      	je	0x59946 <f.5+0xbe6>
   59298:      	movq	0x178(%rdi), %rcx
   5929f:      	testq	%rcx, %rcx
   592a2:      	je	0x592e1 <f.5+0x581>
   592a4:      	movq	0x170(%rdi), %rax
   592ab:      	incq	%rax
   592ae:      	movq	%rax, 0x170(%rdi)
   592b5:      	movq	%rax, %rdx
   592b8:      	orq	%rcx, %rdx
   592bb:      	shrq	$0x20, %rdx
   592bf:      	je	0x59890 <f.5+0xb30>
   592c5:      	xorl	%edx, %edx
   592c7:      	divq	%rcx
   592ca:      	testq	%rdx, %rdx
   592cd:      	jne	0x592e1 <f.5+0x581>
   592cf:      	movq	0xabfa(%rip), %rsi      # 0x63ed0 <native_roots.0>
   592d6:      	movq	%rdi, %r15
   592d9:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   592de:      	movq	%r15, %rdi
   592e1:      	movq	0xabe8(%rip), %rdx      # 0x63ed0 <native_roots.0>
   592e8:      	movl	$0x10, %esi
   592ed:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   592f2:      	testq	%rax, %rax
   592f5:      	je	0x5994b <f.5+0xbeb>
   592fb:      	movq	%rax, %r15
   592fe:      	movq	$0x6a, (%rax)
   59305:      	movq	%r12, 0x8(%rax)
   59309:      	movq	%rax, 0x40(%rsp)
   5930e:      	movq	$0x5, 0x18(%rsp)
   59317:      	movq	0xabaa(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5931e:      	testq	%rdi, %rdi
   59321:      	je	0x59946 <f.5+0xbe6>
   59327:      	movq	0x178(%rdi), %rcx
   5932e:      	testq	%rcx, %rcx
   59331:      	je	0x59370 <f.5+0x610>
   59333:      	movq	0x170(%rdi), %rax
   5933a:      	incq	%rax
   5933d:      	movq	%rax, 0x170(%rdi)
   59344:      	movq	%rax, %rdx
   59347:      	orq	%rcx, %rdx
   5934a:      	shrq	$0x20, %rdx
   5934e:      	je	0x598b0 <f.5+0xb50>
   59354:      	xorl	%edx, %edx
   59356:      	divq	%rcx
   59359:      	testq	%rdx, %rdx
   5935c:      	jne	0x59370 <f.5+0x610>
   5935e:      	movq	0xab6b(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59365:      	movq	%rdi, %r12
   59368:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5936d:      	movq	%r12, %rdi
   59370:      	movq	0xab59(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59377:      	movl	$0x18, %esi
   5937c:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59381:      	testq	%rax, %rax
   59384:      	je	0x5994b <f.5+0xbeb>
   5938a:      	movq	%rax, %r12
   5938d:      	movq	$0x66, (%rax)
   59394:      	movq	%rbp, 0x8(%rax)
   59398:      	movq	%r15, 0x10(%rax)
   5939c:      	movq	%rax, 0x40(%rsp)
   593a1:      	movq	$0x5, 0x18(%rsp)
   593aa:      	movq	0xab17(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   593b1:      	testq	%rdi, %rdi
   593b4:      	je	0x59946 <f.5+0xbe6>
   593ba:      	movq	0x178(%rdi), %rcx
   593c1:      	testq	%rcx, %rcx
   593c4:      	je	0x59403 <f.5+0x6a3>
   593c6:      	movq	0x170(%rdi), %rax
   593cd:      	incq	%rax
   593d0:      	movq	%rax, 0x170(%rdi)
   593d7:      	movq	%rax, %rdx
   593da:      	orq	%rcx, %rdx
   593dd:      	shrq	$0x20, %rdx
   593e1:      	je	0x598d0 <f.5+0xb70>
   593e7:      	xorl	%edx, %edx
   593e9:      	divq	%rcx
   593ec:      	testq	%rdx, %rdx
   593ef:      	jne	0x59403 <f.5+0x6a3>
   593f1:      	movq	0xaad8(%rip), %rsi      # 0x63ed0 <native_roots.0>
   593f8:      	movq	%rdi, %r15
   593fb:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59400:      	movq	%r15, %rdi
   59403:      	movq	%rbp, 0x60(%rsp)
   59408:      	movq	%r14, %rbp
   5940b:      	movq	%rbx, %r14
   5940e:      	movq	%r13, %rbx
   59411:      	movq	0xaab8(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59418:      	movl	$0x10, %esi
   5941d:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59422:      	testq	%rax, %rax
   59425:      	je	0x5994b <f.5+0xbeb>
   5942b:      	movq	%rax, %r13
   5942e:      	movq	$0x96, (%rax)
   59435:      	movq	%r12, 0x8(%rax)
   59439:      	movq	%rax, 0x40(%rsp)
   5943e:      	movq	$0x5, 0x18(%rsp)
   59447:      	movq	0xaa7a(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5944e:      	testq	%rdi, %rdi
   59451:      	je	0x59946 <f.5+0xbe6>
   59457:      	movq	0x178(%rdi), %rcx
   5945e:      	testq	%rcx, %rcx
   59461:      	je	0x594a0 <f.5+0x740>
   59463:      	movq	0x170(%rdi), %rax
   5946a:      	incq	%rax
   5946d:      	movq	%rax, 0x170(%rdi)
   59474:      	movq	%rax, %rdx
   59477:      	orq	%rcx, %rdx
   5947a:      	shrq	$0x20, %rdx
   5947e:      	je	0x598f0 <f.5+0xb90>
   59484:      	xorl	%edx, %edx
   59486:      	divq	%rcx
   59489:      	testq	%rdx, %rdx
   5948c:      	jne	0x594a0 <f.5+0x740>
   5948e:      	movq	0xaa3b(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59495:      	movq	%rdi, %r15
   59498:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5949d:      	movq	%r15, %rdi
   594a0:      	movq	0xaa29(%rip), %rdx      # 0x63ed0 <native_roots.0>
   594a7:      	movl	$0x10, %esi
   594ac:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   594b1:      	testq	%rax, %rax
   594b4:      	je	0x5994b <f.5+0xbeb>
   594ba:      	movq	%rax, %r15
   594bd:      	movq	$0x6a, (%rax)
   594c4:      	movq	%r13, 0x8(%rax)
   594c8:      	movq	%rax, 0x40(%rsp)
   594cd:      	movq	$0x5, 0x18(%rsp)
   594d6:      	movq	0xa9eb(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   594dd:      	testq	%rdi, %rdi
   594e0:      	je	0x59946 <f.5+0xbe6>
   594e6:      	movq	0x178(%rdi), %rcx
   594ed:      	testq	%rcx, %rcx
   594f0:      	movq	%rbx, %r13
   594f3:      	movq	%r14, %rbx
   594f6:      	je	0x59535 <f.5+0x7d5>
   594f8:      	movq	0x170(%rdi), %rax
   594ff:      	incq	%rax
   59502:      	movq	%rax, 0x170(%rdi)
   59509:      	movq	%rax, %rdx
   5950c:      	orq	%rcx, %rdx
   5950f:      	shrq	$0x20, %rdx
   59513:      	je	0x59910 <f.5+0xbb0>
   59519:      	xorl	%edx, %edx
   5951b:      	divq	%rcx
   5951e:      	testq	%rdx, %rdx
   59521:      	jne	0x59535 <f.5+0x7d5>
   59523:      	movq	0xa9a6(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5952a:      	movq	%rdi, %r12
   5952d:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59532:      	movq	%r12, %rdi
   59535:      	movq	0xa994(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5953c:      	movl	$0x28, %esi
   59541:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59546:      	testq	%rax, %rax
   59549:      	je	0x5994b <f.5+0xbeb>
   5954f:      	leaq	-0x4(,%rbp,4), %rcx
   59557:      	movq	$0x62, (%rax)
   5955e:      	movq	0x60(%rsp), %rdx
   59563:      	movq	%rdx, 0x8(%rax)
   59567:      	addq	$-0x2, %rdx
   5956b:      	movq	%rdx, 0x10(%rax)
   5956f:      	movq	%rcx, 0x18(%rax)
   59573:      	movq	%r15, 0x20(%rax)
   59577:      	movq	%rax, 0x40(%rsp)
   5957c:      	movq	$0x5, 0x18(%rsp)
   59585:      	movq	%rax, %rdi
   59588:      	callq	0x59960 <f.8>
   5958d:      	subq	$0x8, %rsp
   59591:      	movq	0x20(%rsp), %rdi
   59596:      	testq	%rdi, %rdi
   59599:      	je	0x59946 <f.5+0xbe6>
   5959f:      	movl	%edi, %eax
   595a1:      	andl	$0x1, %eax
   595a4:      	jne	0x59946 <f.5+0xbe6>
   595aa:      	movq	0xa917(%rip), %rax      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   595b1:      	testq	%rax, %rax
   595b4:      	je	0x59946 <f.5+0xbe6>
   595ba:      	movq	(%rdi), %rdx
   595bd:      	cmpq	$0x76, %rdx
   595c1:      	sete	%cl
   595c4:      	movl	%ecx, %r10d
   595c7:      	testq	%rdx, %rdx
   595ca:      	je	0x59620 <f.5+0x8c0>
   595cc:      	movl	%ecx, %r10d
   595cf:      	cmpq	$0x76, %rdx
   595d3:      	je	0x59620 <f.5+0x8c0>
   595d5:      	movq	0x168(%rax), %rsi
   595dc:      	movq	%rdx, %r8
   595df:      	shrq	$0x2, %r8
   595e3:      	leaq	-0x1(%r8), %r9
   595e7:      	cmpq	%rsi, %r9
   595ea:      	jae	0x59946 <f.5+0xbe6>
   595f0:      	movq	0x160(%rax), %r9
   595f7:      	movq	-0x8(%r9,%r8,8), %r8
   595fc:      	cmpq	$0x76, %r8
   59600:      	sete	%r10b
   59604:      	testq	%r8, %r8
   59607:      	je	0x59620 <f.5+0x8c0>
   59609:      	cmpq	$0x76, %r8
   5960d:      	jne	0x597b0 <f.5+0xa50>
   59613:      	nopw	%cs:(%rax,%rax)
   59620:      	testb	%r10b, %r10b
   59623:      	je	0x59946 <f.5+0xbe6>
   59629:      	movq	0x10(%rdi), %rsi
   5962d:      	testq	%rsi, %rsi
   59630:      	je	0x59946 <f.5+0xbe6>
   59636:      	cmpl	$0x0, 0x8(%rsi)
   5963a:      	je	0x59946 <f.5+0xbe6>
   59640:      	testq	%rdx, %rdx
   59643:      	je	0x59690 <f.5+0x930>
   59645:      	cmpq	$0x76, %rdx
   59649:      	je	0x59690 <f.5+0x930>
   5964b:      	movq	0x168(%rax), %rsi
   59652:      	shrq	$0x2, %rdx
   59656:      	leaq	-0x1(%rdx), %rcx
   5965a:      	cmpq	%rsi, %rcx
   5965d:      	jae	0x59946 <f.5+0xbe6>
   59663:      	movq	0x160(%rax), %r8
   5966a:      	movq	-0x8(%r8,%rdx,8), %rdx
   5966f:      	cmpq	$0x76, %rdx
   59673:      	sete	%cl
   59676:      	testq	%rdx, %rdx
   59679:      	je	0x59690 <f.5+0x930>
   5967b:      	cmpq	$0x76, %rdx
   5967f:      	jne	0x597e0 <f.5+0xa80>
   59685:      	nopw	%cs:(%rax,%rax)
   59690:      	testb	%cl, %cl
   59692:      	je	0x59946 <f.5+0xbe6>
   59698:      	movq	%rdi, 0x38(%rsp)
   5969d:      	movq	0x10(%rdi), %rcx
   596a1:      	testq	%rcx, %rcx
   596a4:      	je	0x59946 <f.5+0xbe6>
   596aa:      	cmpq	$0x0, 0x10(%rcx)
   596af:      	je	0x59946 <f.5+0xbe6>
   596b5:      	xorl	%edx, %edx
   596b7:      	cmpq	$0x0, 0x10(%rsp)
   596bd:      	leaq	0x8(%rsp), %r8
   596c2:      	movq	%r8, %rcx
   596c5:      	leaq	0xa804(%rip), %rsi      # 0x63ed0 <native_roots.0>
   596cc:      	cmoveq	%rsi, %rcx
   596d0:      	sete	%dl
   596d3:      	addq	0xa7d6(%rip), %rdx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   596da:      	movq	(%rcx), %rsi
   596dd:      	movq	$0x7, 0x10(%rsp)
   596e6:      	movq	$0x0, 0x18(%rsp)
   596ef:      	movq	%rsi, 0x8(%rsp)
   596f4:      	movq	0xa7bd(%rip), %rcx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   596fb:      	cmpq	%rcx, %rdx
   596fe:      	cmovaq	%rdx, %rcx
   59702:      	movq	%r8, 0xa7c7(%rip)       # 0x63ed0 <native_roots.0>
   59709:      	movq	%rdx, 0xa7a0(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59710:      	movq	%rcx, 0xa7a1(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59717:      	leaq	0x28(%rsp), %rcx
   5971c:      	xorps	%xmm0, %xmm0
   5971f:      	movups	%xmm0, (%rcx)
   59722:      	movq	$0x0, 0x10(%rcx)
   5972a:      	movq	(%rdi), %rcx
   5972d:      	movq	%rcx, %r8
   59730:      	testq	%rcx, %rcx
   59733:      	je	0x58e90 <f.5+0x130>
   59739:      	movq	%rcx, %r8
   5973c:      	cmpq	$0x76, %rcx
   59740:      	je	0x58e90 <f.5+0x130>
   59746:      	movq	0x168(%rax), %r9
   5974d:      	movq	%rcx, %r8
   59750:      	shrq	$0x2, %r8
   59754:      	leaq	-0x1(%r8), %r10
   59758:      	cmpq	%r9, %r10
   5975b:      	jae	0x59946 <f.5+0xbe6>
   59761:      	movq	0x160(%rax), %r10
   59768:      	movq	-0x8(%r10,%r8,8), %r8
   5976d:      	testq	%r8, %r8
   59770:      	je	0x58e90 <f.5+0x130>
   59776:      	cmpq	$0x76, %r8
   5977a:      	je	0x58e90 <f.5+0x130>
   59780:      	shrq	$0x2, %r8
   59784:      	leaq	-0x1(%r8), %r11
   59788:      	cmpq	%r9, %r11
   5978b:      	jae	0x59946 <f.5+0xbe6>
   59791:      	movq	-0x8(%r10,%r8,8), %r8
   59796:      	cmpq	$0x76, %r8
   5979a:      	je	0x58e90 <f.5+0x130>
   597a0:      	testq	%r8, %r8
   597a3:      	jne	0x59780 <f.5+0xa20>
   597a5:      	jmp	0x58e90 <f.5+0x130>
   597aa:      	nopw	(%rax,%rax)
   597b0:      	shrq	$0x2, %r8
   597b4:      	leaq	-0x1(%r8), %r10
   597b8:      	cmpq	%rsi, %r10
   597bb:      	jae	0x59946 <f.5+0xbe6>
   597c1:      	movq	-0x8(%r9,%r8,8), %r8
   597c6:      	cmpq	$0x76, %r8
   597ca:      	je	0x597d1 <f.5+0xa71>
   597cc:      	testq	%r8, %r8
   597cf:      	jne	0x597b0 <f.5+0xa50>
   597d1:      	cmpq	$0x76, %r8
   597d5:      	je	0x59629 <f.5+0x8c9>
   597db:      	jmp	0x59946 <f.5+0xbe6>
   597e0:      	shrq	$0x2, %rdx
   597e4:      	leaq	-0x1(%rdx), %rcx
   597e8:      	cmpq	%rsi, %rcx
   597eb:      	jae	0x59946 <f.5+0xbe6>
   597f1:      	movq	-0x8(%r8,%rdx,8), %rdx
   597f6:      	cmpq	$0x76, %rdx
   597fa:      	je	0x59801 <f.5+0xaa1>
   597fc:      	testq	%rdx, %rdx
   597ff:      	jne	0x597e0 <f.5+0xa80>
   59801:      	cmpq	$0x76, %rdx
   59805:      	je	0x59698 <f.5+0x938>
   5980b:      	jmp	0x59946 <f.5+0xbe6>
   59810:      	xorl	%edx, %edx
   59812:      	divl	%ecx
   59814:      	testq	%rdx, %rdx
   59817:      	jne	0x59009 <f.5+0x2a9>
   5981d:      	jmp	0x58ff7 <f.5+0x297>
   59822:      	nopw	%cs:(%rax,%rax)
   59830:      	xorl	%edx, %edx
   59832:      	divl	%ecx
   59834:      	testq	%rdx, %rdx
   59837:      	jne	0x590b2 <f.5+0x352>
   5983d:      	jmp	0x590a0 <f.5+0x340>
   59842:      	nopw	%cs:(%rax,%rax)
   59850:      	xorl	%edx, %edx
   59852:      	divl	%ecx
   59854:      	testq	%rdx, %rdx
   59857:      	jne	0x5914b <f.5+0x3eb>
   5985d:      	jmp	0x59139 <f.5+0x3d9>
   59862:      	nopw	%cs:(%rax,%rax)
   59870:      	xorl	%edx, %edx
   59872:      	divl	%ecx
   59874:      	testq	%rdx, %rdx
   59877:      	jne	0x5924e <f.5+0x4ee>
   5987d:      	jmp	0x5923c <f.5+0x4dc>
   59882:      	nopw	%cs:(%rax,%rax)
   59890:      	xorl	%edx, %edx
   59892:      	divl	%ecx
   59894:      	testq	%rdx, %rdx
   59897:      	jne	0x592e1 <f.5+0x581>
   5989d:      	jmp	0x592cf <f.5+0x56f>
   598a2:      	nopw	%cs:(%rax,%rax)
   598b0:      	xorl	%edx, %edx
   598b2:      	divl	%ecx
   598b4:      	testq	%rdx, %rdx
   598b7:      	jne	0x59370 <f.5+0x610>
   598bd:      	jmp	0x5935e <f.5+0x5fe>
   598c2:      	nopw	%cs:(%rax,%rax)
   598d0:      	xorl	%edx, %edx
   598d2:      	divl	%ecx
   598d4:      	testq	%rdx, %rdx
   598d7:      	jne	0x59403 <f.5+0x6a3>
   598dd:      	jmp	0x593f1 <f.5+0x691>
   598e2:      	nopw	%cs:(%rax,%rax)
   598f0:      	xorl	%edx, %edx
   598f2:      	divl	%ecx
   598f4:      	testq	%rdx, %rdx
   598f7:      	jne	0x594a0 <f.5+0x740>
   598fd:      	jmp	0x5948e <f.5+0x72e>
   59902:      	nopw	%cs:(%rax,%rax)
   59910:      	xorl	%edx, %edx
   59912:      	divl	%ecx
   59914:      	testq	%rdx, %rdx
   59917:      	jne	0x59535 <f.5+0x7d5>
   5991d:      	jmp	0x59523 <f.5+0x7c3>
   59922:      	movq	%rsi, 0xa5a7(%rip)      # 0x63ed0 <native_roots.0>
   59929:      	decq	%rdx
   5992c:      	movq	%rdx, 0xa57d(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59933:      	xorl	%eax, %eax
   59935:      	addq	$0x68, %rsp
   59939:      	popq	%rbx
   5993a:      	popq	%r12
   5993c:      	popq	%r13
   5993e:      	popq	%r14
   59940:      	popq	%r15
   59942:      	popq	%rbp
   59943:      	retq	$0x8
   59946:      	callq	0x55920 <native_trap>
   5994b:      	leaq	-0x5053e(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   59952:      	movl	$0x2f, %esi
   59957:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5995c:      	int3
   5995d:      	int3
   5995e:      	int3
   5995f:      	int3

0000000000059960 <f.8>:
   59960:      	pushq	%rbp
   59961:      	pushq	%r15
   59963:      	pushq	%r14
   59965:      	pushq	%r13
   59967:      	pushq	%r12
   59969:      	pushq	%rbx
   5996a:      	subq	$0xd8, %rsp
   59971:      	movq	$0xf, 0x40(%rsp)
   5997a:      	movq	0xa54f(%rip), %rax      # 0x63ed0 <native_roots.0>
   59981:      	movq	%rax, 0x38(%rsp)
   59986:      	movq	0xa523(%rip), %rax      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5998d:      	incq	%rax
   59990:      	movq	%rax, 0xa519(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59997:      	movq	0xa51a(%rip), %rcx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5999e:      	cmpq	%rcx, %rax
   599a1:      	cmovbeq	%rcx, %rax
   599a5:      	leaq	0x38(%rsp), %rcx
   599aa:      	movq	%rcx, 0xa51f(%rip)      # 0x63ed0 <native_roots.0>
   599b1:      	movq	%rax, 0xa500(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   599b8:      	movq	%rdi, 0x50(%rsp)
   599bd:      	xorpd	%xmm0, %xmm0
   599c1:      	movupd	%xmm0, 0x58(%rsp)
   599c7:      	movupd	%xmm0, 0x68(%rsp)
   599cd:      	movupd	%xmm0, 0x78(%rsp)
   599d3:      	movq	$0x0, 0x88(%rsp)
   599df:      	movq	$0x8, 0x48(%rsp)
   599e8:      	movq	0xa4d9(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   599ef:      	testq	%rdi, %rdi
   599f2:      	je	0x5afd5 <f.8+0x1675>
   599f8:      	movq	0x178(%rdi), %rsi
   599ff:      	testq	%rsi, %rsi
   59a02:      	je	0x59a46 <f.8+0xe6>
   59a04:      	movq	0x170(%rdi), %rax
   59a0b:      	incq	%rax
   59a0e:      	movq	%rax, 0x170(%rdi)
   59a15:      	movq	%rax, %rdx
   59a18:      	orq	%rsi, %rdx
   59a1b:      	shrq	$0x20, %rdx
   59a1f:      	je	0x5ae6d <f.8+0x150d>
   59a25:      	xorl	%edx, %edx
   59a27:      	divq	%rsi
   59a2a:      	testq	%rdx, %rdx
   59a2d:      	jne	0x59a46 <f.8+0xe6>
   59a2f:      	leaq	0x38(%rsp), %rsi
   59a34:      	movq	%rdi, %rbx
   59a37:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59a3c:      	movq	%rbx, %rdi
   59a3f:      	movq	0xa48a(%rip), %rcx      # 0x63ed0 <native_roots.0>
   59a46:      	movl	$0x18, %esi
   59a4b:      	movq	%rcx, %rdx
   59a4e:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59a53:      	testq	%rax, %rax
   59a56:      	je	0x5afda <f.8+0x167a>
   59a5c:      	movq	%rax, %rbx
   59a5f:      	movq	$0x56, (%rax)
   59a66:      	movl	$0x0, 0x8(%rax)
   59a6d:      	movq	$0x0, 0x10(%rax)
   59a75:      	movq	%rax, 0x60(%rsp)
   59a7a:      	movq	%rax, 0x90(%rsp)
   59a82:      	movq	%rax, 0x98(%rsp)
   59a8a:      	movq	$0xa, 0x48(%rsp)
   59a93:      	movq	0xa42e(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59a9a:      	testq	%rdi, %rdi
   59a9d:      	je	0x5afd5 <f.8+0x1675>
   59aa3:      	movq	0x178(%rdi), %rcx
   59aaa:      	testq	%rcx, %rcx
   59aad:      	je	0x59aec <f.8+0x18c>
   59aaf:      	movq	0x170(%rdi), %rax
   59ab6:      	incq	%rax
   59ab9:      	movq	%rax, 0x170(%rdi)
   59ac0:      	movq	%rax, %rdx
   59ac3:      	orq	%rcx, %rdx
   59ac6:      	shrq	$0x20, %rdx
   59aca:      	je	0x5ae7f <f.8+0x151f>
   59ad0:      	xorl	%edx, %edx
   59ad2:      	divq	%rcx
   59ad5:      	testq	%rdx, %rdx
   59ad8:      	jne	0x59aec <f.8+0x18c>
   59ada:      	movq	0xa3ef(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59ae1:      	movq	%rdi, %r14
   59ae4:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59ae9:      	movq	%r14, %rdi
   59aec:      	movq	0xa3dd(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59af3:      	movl	$0x10, %esi
   59af8:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59afd:      	testq	%rax, %rax
   59b00:      	je	0x5afda <f.8+0x167a>
   59b06:      	movq	%rax, %r14
   59b09:      	movq	$0x4a, (%rax)
   59b10:      	movq	%rbx, 0x8(%rax)
   59b14:      	movq	%rax, 0x90(%rsp)
   59b1c:      	movq	%rbx, 0x98(%rsp)
   59b24:      	movq	$0xa, 0x48(%rsp)
   59b2d:      	movq	0xa394(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59b34:      	testq	%rdi, %rdi
   59b37:      	je	0x5afd5 <f.8+0x1675>
   59b3d:      	movq	0x178(%rdi), %rcx
   59b44:      	testq	%rcx, %rcx
   59b47:      	je	0x59b86 <f.8+0x226>
   59b49:      	movq	0x170(%rdi), %rax
   59b50:      	incq	%rax
   59b53:      	movq	%rax, 0x170(%rdi)
   59b5a:      	movq	%rax, %rdx
   59b5d:      	orq	%rcx, %rdx
   59b60:      	shrq	$0x20, %rdx
   59b64:      	je	0x5ae91 <f.8+0x1531>
   59b6a:      	xorl	%edx, %edx
   59b6c:      	divq	%rcx
   59b6f:      	testq	%rdx, %rdx
   59b72:      	jne	0x59b86 <f.8+0x226>
   59b74:      	movq	0xa355(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59b7b:      	movq	%rdi, %r15
   59b7e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59b83:      	movq	%r15, %rdi
   59b86:      	movq	0xa343(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59b8d:      	movl	$0x10, %esi
   59b92:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59b97:      	testq	%rax, %rax
   59b9a:      	je	0x5afda <f.8+0x167a>
   59ba0:      	movq	$0x42, (%rax)
   59ba7:      	movq	%r14, 0x8(%rax)
   59bab:      	movq	%rax, 0x10(%rbx)
   59baf:      	movq	0x60(%rsp), %rax
   59bb4:      	testq	%rax, %rax
   59bb7:      	je	0x5afd5 <f.8+0x1675>
   59bbd:      	movl	$0x1, 0x8(%rax)
   59bc4:      	movq	$0x8, 0x48(%rsp)
   59bcd:      	movq	0xa2f4(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59bd4:      	testq	%rdi, %rdi
   59bd7:      	je	0x5afd5 <f.8+0x1675>
   59bdd:      	movq	0x178(%rdi), %rcx
   59be4:      	testq	%rcx, %rcx
   59be7:      	je	0x59c26 <f.8+0x2c6>
   59be9:      	movq	0x170(%rdi), %rax
   59bf0:      	incq	%rax
   59bf3:      	movq	%rax, 0x170(%rdi)
   59bfa:      	movq	%rax, %rdx
   59bfd:      	orq	%rcx, %rdx
   59c00:      	shrq	$0x20, %rdx
   59c04:      	je	0x5aea3 <f.8+0x1543>
   59c0a:      	xorl	%edx, %edx
   59c0c:      	divq	%rcx
   59c0f:      	testq	%rdx, %rdx
   59c12:      	jne	0x59c26 <f.8+0x2c6>
   59c14:      	movq	0xa2b5(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59c1b:      	movq	%rdi, %rbx
   59c1e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59c23:      	movq	%rbx, %rdi
   59c26:      	movq	0xa2a3(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59c2d:      	movl	$0x18, %esi
   59c32:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59c37:      	testq	%rax, %rax
   59c3a:      	je	0x5afda <f.8+0x167a>
   59c40:      	movq	%rax, %rbx
   59c43:      	movq	$0x52, (%rax)
   59c4a:      	movl	$0x0, 0x8(%rax)
   59c51:      	movq	$0x0, 0x10(%rax)
   59c59:      	movq	%rax, 0x68(%rsp)
   59c5e:      	movq	%rax, 0x90(%rsp)
   59c66:      	movq	%rax, 0x98(%rsp)
   59c6e:      	movq	$0xa, 0x48(%rsp)
   59c77:      	movq	0xa24a(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59c7e:      	testq	%rdi, %rdi
   59c81:      	je	0x5afd5 <f.8+0x1675>
   59c87:      	movq	0x178(%rdi), %rcx
   59c8e:      	testq	%rcx, %rcx
   59c91:      	je	0x59cd0 <f.8+0x370>
   59c93:      	movq	0x170(%rdi), %rax
   59c9a:      	incq	%rax
   59c9d:      	movq	%rax, 0x170(%rdi)
   59ca4:      	movq	%rax, %rdx
   59ca7:      	orq	%rcx, %rdx
   59caa:      	shrq	$0x20, %rdx
   59cae:      	je	0x5aeb5 <f.8+0x1555>
   59cb4:      	xorl	%edx, %edx
   59cb6:      	divq	%rcx
   59cb9:      	testq	%rdx, %rdx
   59cbc:      	jne	0x59cd0 <f.8+0x370>
   59cbe:      	movq	0xa20b(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59cc5:      	movq	%rdi, %r14
   59cc8:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59ccd:      	movq	%r14, %rdi
   59cd0:      	movq	0xa1f9(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59cd7:      	movl	$0x10, %esi
   59cdc:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59ce1:      	testq	%rax, %rax
   59ce4:      	je	0x5afda <f.8+0x167a>
   59cea:      	movq	%rax, %r14
   59ced:      	movq	$0x3e, (%rax)
   59cf4:      	movq	%rbx, 0x8(%rax)
   59cf8:      	movq	%rax, 0x90(%rsp)
   59d00:      	movq	%rbx, 0x98(%rsp)
   59d08:      	movq	$0xa, 0x48(%rsp)
   59d11:      	movq	0xa1b0(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59d18:      	testq	%rdi, %rdi
   59d1b:      	je	0x5afd5 <f.8+0x1675>
   59d21:      	movq	0x178(%rdi), %rcx
   59d28:      	testq	%rcx, %rcx
   59d2b:      	je	0x59d6a <f.8+0x40a>
   59d2d:      	movq	0x170(%rdi), %rax
   59d34:      	incq	%rax
   59d37:      	movq	%rax, 0x170(%rdi)
   59d3e:      	movq	%rax, %rdx
   59d41:      	orq	%rcx, %rdx
   59d44:      	shrq	$0x20, %rdx
   59d48:      	je	0x5aec7 <f.8+0x1567>
   59d4e:      	xorl	%edx, %edx
   59d50:      	divq	%rcx
   59d53:      	testq	%rdx, %rdx
   59d56:      	jne	0x59d6a <f.8+0x40a>
   59d58:      	movq	0xa171(%rip), %rsi      # 0x63ed0 <native_roots.0>
   59d5f:      	movq	%rdi, %r15
   59d62:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59d67:      	movq	%r15, %rdi
   59d6a:      	movq	0xa15f(%rip), %rdx      # 0x63ed0 <native_roots.0>
   59d71:      	movl	$0x10, %esi
   59d76:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59d7b:      	testq	%rax, %rax
   59d7e:      	je	0x5afda <f.8+0x167a>
   59d84:      	movq	$0x3a, (%rax)
   59d8b:      	movq	%r14, 0x8(%rax)
   59d8f:      	movq	%rax, 0x10(%rbx)
   59d93:      	movq	0x68(%rsp), %rax
   59d98:      	testq	%rax, %rax
   59d9b:      	je	0x5afd5 <f.8+0x1675>
   59da1:      	movl	$0x1, 0x8(%rax)
   59da8:      	movq	$0x8, 0x48(%rsp)
   59db1:      	leaq	0x60a8(%rip), %rax      # 0x5fe60 <writev+0x5fe60>
   59db8:      	movq	%rax, 0x8(%rsp)
   59dbd:      	leaq	0x606c(%rip), %r13      # 0x5fe30 <writev+0x5fe30>
   59dc4:      	leaq	-0x2f8b(%rip), %r15     # 0x56e40 <_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$::fmt::h4581551deb22294e>
   59dcb:      	movq	%r15, 0x10(%rsp)
   59dd0:      	leaq	-0x535d5(%rip), %rbx    # 0x6802 <writev+0x6802>
   59dd7:      	leaq	0x8(%rsp), %rsi
   59ddc:      	movq	%rbx, %rdi
   59ddf:      	callq	0x4e2a0 <std::io::stdio::_print>
   59de4:      	movq	$0x8, 0x48(%rsp)
   59ded:      	movq	%r13, 0x8(%rsp)
   59df2:      	movq	%r15, 0x10(%rsp)
   59df7:      	leaq	0x8(%rsp), %rsi
   59dfc:      	movq	%rbx, %rdi
   59dff:      	callq	0x4e2a0 <std::io::stdio::_print>
   59e04:      	movq	0x50(%rsp), %rax
   59e09:      	testq	%rax, %rax
   59e0c:      	je	0x5afd5 <f.8+0x1675>
   59e12:      	movq	0x8(%rax), %rbx
   59e16:      	movq	$0x8, 0x48(%rsp)
   59e1f:      	movq	%rbx, 0xc8(%rsp)
   59e27:      	leaq	0x5fa2(%rip), %rax      # 0x5fdd0 <writev+0x5fdd0>
   59e2e:      	movq	%rax, 0x8(%rsp)
   59e33:      	movq	%r15, 0x10(%rsp)
   59e38:      	leaq	0xc8(%rsp), %r12
   59e40:      	movq	%r12, 0x18(%rsp)
   59e45:      	leaq	-0xbd0c(%rip), %rbp     # 0x4e140 <<i64 as core::fmt::Display>::fmt>
   59e4c:      	movq	%rbp, 0x20(%rsp)
   59e51:      	leaq	0x5fa8(%rip), %rax      # 0x5fe00 <writev+0x5fe00>
   59e58:      	movq	%rax, 0x28(%rsp)
   59e5d:      	movq	%r15, 0x30(%rsp)
   59e62:      	leaq	-0x53129(%rip), %rdi    # 0x6d40 <writev+0x6d40>
   59e69:      	leaq	0x8(%rsp), %rsi
   59e6e:      	callq	0x4e2a0 <std::io::stdio::_print>
   59e73:      	movq	$0x8, 0x48(%rsp)
   59e7c:      	movq	%r13, 0x8(%rsp)
   59e81:      	movq	%r15, 0x10(%rsp)
   59e86:      	leaq	-0x5368b(%rip), %rdi    # 0x6802 <writev+0x6802>
   59e8d:      	leaq	0x8(%rsp), %rsi
   59e92:      	callq	0x4e2a0 <std::io::stdio::_print>
   59e97:      	cmpb	$0x0, 0xa1ba(%rip)      # 0x64058 <g.25>
   59e9e:      	je	0x5afd5 <f.8+0x1675>
   59ea4:      	cmpq	$0x0, 0xa1a4(%rip)      # 0x64050 <g.24>
   59eac:      	je	0x5afd5 <f.8+0x1675>
   59eb2:      	movq	$0x8, 0x48(%rsp)
   59ebb:      	leaq	0x5f7e(%rip), %rax      # 0x5fe40 <writev+0x5fe40>
   59ec2:      	movq	%rax, 0x8(%rsp)
   59ec7:      	movq	%r15, 0x10(%rsp)
   59ecc:      	leaq	-0x536d1(%rip), %r14    # 0x6802 <writev+0x6802>
   59ed3:      	leaq	0x8(%rsp), %rsi
   59ed8:      	movq	%r14, %rdi
   59edb:      	callq	0x4e2a0 <std::io::stdio::_print>
   59ee0:      	movq	$0x8, 0x48(%rsp)
   59ee9:      	leaq	0x5f60(%rip), %rax      # 0x5fe50 <writev+0x5fe50>
   59ef0:      	movq	%rax, 0x8(%rsp)
   59ef5:      	movq	%r15, 0x10(%rsp)
   59efa:      	leaq	0x8(%rsp), %rsi
   59eff:      	movq	%r14, %rdi
   59f02:      	callq	0x4e2a0 <std::io::stdio::_print>
   59f07:      	movq	$0x8, 0x48(%rsp)
   59f10:      	movq	%r13, 0x8(%rsp)
   59f15:      	movq	%r15, 0x10(%rsp)
   59f1a:      	leaq	0x8(%rsp), %rsi
   59f1f:      	movq	%r14, %rdi
   59f22:      	callq	0x4e2a0 <std::io::stdio::_print>
   59f27:      	cmpb	$0x0, 0xa11a(%rip)      # 0x64048 <g.23>
   59f2e:      	je	0x5afd5 <f.8+0x1675>
   59f34:      	cmpq	$0x0, 0xa104(%rip)      # 0x64040 <g.22>
   59f3c:      	je	0x5afd5 <f.8+0x1675>
   59f42:      	movq	$0x8, 0x48(%rsp)
   59f4b:      	leaq	0x5f3e(%rip), %rax      # 0x5fe90 <writev+0x5fe90>
   59f52:      	movq	%rax, 0x8(%rsp)
   59f57:      	movq	%r15, 0x10(%rsp)
   59f5c:      	leaq	-0x53761(%rip), %r14    # 0x6802 <writev+0x6802>
   59f63:      	leaq	0x8(%rsp), %rsi
   59f68:      	movq	%r14, %rdi
   59f6b:      	callq	0x4e2a0 <std::io::stdio::_print>
   59f70:      	movq	$0x8, 0x48(%rsp)
   59f79:      	movq	%r13, 0x8(%rsp)
   59f7e:      	movq	%r15, 0x10(%rsp)
   59f83:      	leaq	0x8(%rsp), %rsi
   59f88:      	movq	%r14, %rdi
   59f8b:      	callq	0x4e2a0 <std::io::stdio::_print>
   59f90:      	movq	0x68(%rsp), %rax
   59f95:      	testq	%rax, %rax
   59f98:      	je	0x5afd5 <f.8+0x1675>
   59f9e:      	cmpl	$0x0, 0x8(%rax)
   59fa2:      	je	0x5afd5 <f.8+0x1675>
   59fa8:      	movq	0x10(%rax), %rax
   59fac:      	testq	%rax, %rax
   59faf:      	je	0x5afd5 <f.8+0x1675>
   59fb5:      	movq	0x8(%rax), %rdi
   59fb9:      	movq	%rdi, 0x90(%rsp)
   59fc1:      	movq	$0x9, 0x48(%rsp)
   59fca:      	movq	%rbx, %rsi
   59fcd:      	callq	0x5aff0 <f.18>
   59fd2:      	subq	$0x8, %rsp
   59fd6:      	movq	0x50(%rsp), %rax
   59fdb:      	testq	%rax, %rax
   59fde:      	je	0x5afd5 <f.8+0x1675>
   59fe4:      	movq	0x10(%rax), %rax
   59fe8:      	movq	$0x8, 0x48(%rsp)
   59ff1:      	movq	%rax, 0xd0(%rsp)
   59ff9:      	movq	%rax, 0xc8(%rsp)
   5a001:      	leaq	0x5dd8(%rip), %rax      # 0x5fde0 <writev+0x5fde0>
   5a008:      	movq	%rax, 0x8(%rsp)
   5a00d:      	movq	%r15, 0x10(%rsp)
   5a012:      	movq	%r12, 0x18(%rsp)
   5a017:      	movq	%rbp, 0x20(%rsp)
   5a01c:      	leaq	0x5ded(%rip), %rax      # 0x5fe10 <writev+0x5fe10>
   5a023:      	movq	%rax, 0x28(%rsp)
   5a028:      	movq	%r15, 0x30(%rsp)
   5a02d:      	leaq	-0x532f4(%rip), %rdi    # 0x6d40 <writev+0x6d40>
   5a034:      	leaq	0x8(%rsp), %rsi
   5a039:      	callq	0x4e2a0 <std::io::stdio::_print>
   5a03e:      	movq	$0x8, 0x48(%rsp)
   5a047:      	movq	%r13, 0x8(%rsp)
   5a04c:      	movq	%r15, 0x10(%rsp)
   5a051:      	leaq	-0x53856(%rip), %rdi    # 0x6802 <writev+0x6802>
   5a058:      	leaq	0x8(%rsp), %rsi
   5a05d:      	callq	0x4e2a0 <std::io::stdio::_print>
   5a062:      	cmpb	$0x0, 0x9f4f(%rip)      # 0x63fb8 <g.5>
   5a069:      	je	0x5afd5 <f.8+0x1675>
   5a06f:      	cmpq	$0x0, 0x9f39(%rip)      # 0x63fb0 <g.4>
   5a077:      	je	0x5afd5 <f.8+0x1675>
   5a07d:      	movq	0x60(%rsp), %rax
   5a082:      	testq	%rax, %rax
   5a085:      	je	0x5afd5 <f.8+0x1675>
   5a08b:      	cmpl	$0x0, 0x8(%rax)
   5a08f:      	je	0x5afd5 <f.8+0x1675>
   5a095:      	movq	0x10(%rax), %rax
   5a099:      	testq	%rax, %rax
   5a09c:      	je	0x5afd5 <f.8+0x1675>
   5a0a2:      	movq	0x8(%rax), %rax
   5a0a6:      	movq	%rax, 0x80(%rsp)
   5a0ae:      	leaq	-0x4f3e5(%rip), %r12    # 0xacd0 <object.1.0>
   5a0b5:      	movq	%r12, 0x90(%rsp)
   5a0bd:      	movq	$0x9, 0x48(%rsp)
   5a0c6:      	movq	0x9dfb(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a0cd:      	testq	%rdi, %rdi
   5a0d0:      	je	0x5afd5 <f.8+0x1675>
   5a0d6:      	movq	0x178(%rdi), %rcx
   5a0dd:      	testq	%rcx, %rcx
   5a0e0:      	je	0x5a11f <f.8+0x7bf>
   5a0e2:      	movq	0x170(%rdi), %rax
   5a0e9:      	incq	%rax
   5a0ec:      	movq	%rax, 0x170(%rdi)
   5a0f3:      	movq	%rax, %rdx
   5a0f6:      	orq	%rcx, %rdx
   5a0f9:      	shrq	$0x20, %rdx
   5a0fd:      	je	0x5aed9 <f.8+0x1579>
   5a103:      	xorl	%edx, %edx
   5a105:      	divq	%rcx
   5a108:      	testq	%rdx, %rdx
   5a10b:      	jne	0x5a11f <f.8+0x7bf>
   5a10d:      	movq	0x9dbc(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a114:      	movq	%rdi, %rbx
   5a117:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a11c:      	movq	%rbx, %rdi
   5a11f:      	movq	0x9daa(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a126:      	movl	$0x10, %esi
   5a12b:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a130:      	testq	%rax, %rax
   5a133:      	je	0x5afda <f.8+0x167a>
   5a139:      	movq	%rax, %rbx
   5a13c:      	movq	$0x36, (%rax)
   5a143:      	movq	%r12, 0x8(%rax)
   5a147:      	movq	%r12, 0x90(%rsp)
   5a14f:      	movq	%rax, 0x98(%rsp)
   5a157:      	movq	$0xa, 0x48(%rsp)
   5a160:      	movq	0x9d61(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a167:      	testq	%rdi, %rdi
   5a16a:      	je	0x5afd5 <f.8+0x1675>
   5a170:      	movq	0x178(%rdi), %rcx
   5a177:      	testq	%rcx, %rcx
   5a17a:      	je	0x5a1b9 <f.8+0x859>
   5a17c:      	movq	0x170(%rdi), %rax
   5a183:      	incq	%rax
   5a186:      	movq	%rax, 0x170(%rdi)
   5a18d:      	movq	%rax, %rdx
   5a190:      	orq	%rcx, %rdx
   5a193:      	shrq	$0x20, %rdx
   5a197:      	je	0x5aeeb <f.8+0x158b>
   5a19d:      	xorl	%edx, %edx
   5a19f:      	divq	%rcx
   5a1a2:      	testq	%rdx, %rdx
   5a1a5:      	jne	0x5a1b9 <f.8+0x859>
   5a1a7:      	movq	0x9d22(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a1ae:      	movq	%rdi, %r14
   5a1b1:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a1b6:      	movq	%r14, %rdi
   5a1b9:      	movq	0x9d10(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a1c0:      	movl	$0x10, %esi
   5a1c5:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a1ca:      	testq	%rax, %rax
   5a1cd:      	je	0x5afda <f.8+0x167a>
   5a1d3:      	movq	%rax, %r15
   5a1d6:      	movq	$0x36, (%rax)
   5a1dd:      	movq	%r12, 0x8(%rax)
   5a1e1:      	movq	%rax, 0x90(%rsp)
   5a1e9:      	movq	%rbx, 0x98(%rsp)
   5a1f1:      	movq	$0xa, 0x48(%rsp)
   5a1fa:      	movq	0x9cc7(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a201:      	testq	%rdi, %rdi
   5a204:      	je	0x5afd5 <f.8+0x1675>
   5a20a:      	movq	0x178(%rdi), %rcx
   5a211:      	testq	%rcx, %rcx
   5a214:      	je	0x5a253 <f.8+0x8f3>
   5a216:      	movq	0x170(%rdi), %rax
   5a21d:      	incq	%rax
   5a220:      	movq	%rax, 0x170(%rdi)
   5a227:      	movq	%rax, %rdx
   5a22a:      	orq	%rcx, %rdx
   5a22d:      	shrq	$0x20, %rdx
   5a231:      	je	0x5aefd <f.8+0x159d>
   5a237:      	xorl	%edx, %edx
   5a239:      	divq	%rcx
   5a23c:      	testq	%rdx, %rdx
   5a23f:      	jne	0x5a253 <f.8+0x8f3>
   5a241:      	movq	0x9c88(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a248:      	movq	%rdi, %r14
   5a24b:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a250:      	movq	%r14, %rdi
   5a253:      	movq	0x9c76(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a25a:      	movl	$0x18, %esi
   5a25f:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a264:      	testq	%rax, %rax
   5a267:      	je	0x5afda <f.8+0x167a>
   5a26d:      	movq	%rax, %r14
   5a270:      	movq	$0x46, (%rax)
   5a277:      	movq	%rbx, 0x8(%rax)
   5a27b:      	movq	%r15, 0x10(%rax)
   5a27f:      	movq	%rax, 0x88(%rsp)
   5a287:      	cmpq	$0x0, 0xd0(%rsp)
   5a290:      	jle	0x5a36f <f.8+0xa0f>
   5a296:      	movq	0x80(%rsp), %rax
   5a29e:      	testq	%rax, %rax
   5a2a1:      	je	0x5afd5 <f.8+0x1675>
   5a2a7:      	movq	0x8(%rax), %r15
   5a2ab:      	movq	%r14, 0x90(%rsp)
   5a2b3:      	movq	%r15, 0x98(%rsp)
   5a2bb:      	movq	$0xa, 0x48(%rsp)
   5a2c4:      	movq	0x9bfd(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a2cb:      	testq	%rdi, %rdi
   5a2ce:      	je	0x5afd5 <f.8+0x1675>
   5a2d4:      	movq	0x178(%rdi), %rcx
   5a2db:      	testq	%rcx, %rcx
   5a2de:      	je	0x5a31d <f.8+0x9bd>
   5a2e0:      	movq	0x170(%rdi), %rax
   5a2e7:      	incq	%rax
   5a2ea:      	movq	%rax, 0x170(%rdi)
   5a2f1:      	movq	%rax, %rdx
   5a2f4:      	orq	%rcx, %rdx
   5a2f7:      	shrq	$0x20, %rdx
   5a2fb:      	je	0x5afc3 <f.8+0x1663>
   5a301:      	xorl	%edx, %edx
   5a303:      	divq	%rcx
   5a306:      	testq	%rdx, %rdx
   5a309:      	jne	0x5a31d <f.8+0x9bd>
   5a30b:      	movq	0x9bbe(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a312:      	movq	%rdi, %rbx
   5a315:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a31a:      	movq	%rbx, %rdi
   5a31d:      	movq	0x9bac(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a324:      	movl	$0x18, %esi
   5a329:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a32e:      	testq	%rax, %rax
   5a331:      	je	0x5afda <f.8+0x167a>
   5a337:      	movq	$0x32, (%rax)
   5a33e:      	movq	%r15, 0x8(%rax)
   5a342:      	movq	%r14, 0x10(%rax)
   5a346:      	movq	0xd0(%rsp), %rcx
   5a34e:      	leaq	-0x1(%rcx), %rsi
   5a352:      	movq	%rax, 0x90(%rsp)
   5a35a:      	movq	$0x9, 0x48(%rsp)
   5a363:      	movq	%rax, %rdi
   5a366:      	callq	0x5b420 <f.17>
   5a36b:      	subq	$0x8, %rsp
   5a36f:      	movq	0x50(%rsp), %rax
   5a374:      	testq	%rax, %rax
   5a377:      	leaq	-0x353e(%rip), %rbx     # 0x56e40 <_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$::fmt::h4581551deb22294e>
   5a37e:      	je	0x5afd5 <f.8+0x1675>
   5a384:      	movq	0x18(%rax), %r12
   5a388:      	movq	$0x8, 0x48(%rsp)
   5a391:      	movq	%r12, 0xc8(%rsp)
   5a399:      	leaq	0x5a50(%rip), %rax      # 0x5fdf0 <writev+0x5fdf0>
   5a3a0:      	movq	%rax, 0x8(%rsp)
   5a3a5:      	movq	%rbx, 0x10(%rsp)
   5a3aa:      	leaq	0xc8(%rsp), %rax
   5a3b2:      	movq	%rax, 0x18(%rsp)
   5a3b7:      	movq	%rbp, 0x20(%rsp)
   5a3bc:      	leaq	0x5a5d(%rip), %rax      # 0x5fe20 <writev+0x5fe20>
   5a3c3:      	movq	%rax, 0x28(%rsp)
   5a3c8:      	movq	%rbx, 0x30(%rsp)
   5a3cd:      	leaq	-0x53694(%rip), %rdi    # 0x6d40 <writev+0x6d40>
   5a3d4:      	leaq	0x8(%rsp), %rsi
   5a3d9:      	callq	0x4e2a0 <std::io::stdio::_print>
   5a3de:      	movq	$0x8, 0x48(%rsp)
   5a3e7:      	movq	%r13, 0x8(%rsp)
   5a3ec:      	movq	%rbx, 0x10(%rsp)
   5a3f1:      	leaq	-0x53bf6(%rip), %rdi    # 0x6802 <writev+0x6802>
   5a3f8:      	leaq	0x8(%rsp), %rsi
   5a3fd:      	callq	0x4e2a0 <std::io::stdio::_print>
   5a402:      	movq	%r12, %rax
   5a405:      	shrq	$0x20, %rax
   5a409:      	jne	0x5afd5 <f.8+0x1675>
   5a40f:      	movq	$0x8, 0x48(%rsp)
   5a418:      	movq	0x9aa9(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a41f:      	testq	%rdi, %rdi
   5a422:      	je	0x5afd5 <f.8+0x1675>
   5a428:      	movq	0x178(%rdi), %rcx
   5a42f:      	testq	%rcx, %rcx
   5a432:      	je	0x5a471 <f.8+0xb11>
   5a434:      	movq	0x170(%rdi), %rax
   5a43b:      	incq	%rax
   5a43e:      	movq	%rax, 0x170(%rdi)
   5a445:      	movq	%rax, %rdx
   5a448:      	orq	%rcx, %rdx
   5a44b:      	shrq	$0x20, %rdx
   5a44f:      	je	0x5af0f <f.8+0x15af>
   5a455:      	xorl	%edx, %edx
   5a457:      	divq	%rcx
   5a45a:      	testq	%rdx, %rdx
   5a45d:      	jne	0x5a471 <f.8+0xb11>
   5a45f:      	movq	0x9a6a(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a466:      	movq	%rdi, %rbx
   5a469:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a46e:      	movq	%rbx, %rdi
   5a471:      	movq	0x9a58(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a478:      	movl	$0x18, %esi
   5a47d:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a482:      	testq	%rax, %rax
   5a485:      	je	0x5afda <f.8+0x167a>
   5a48b:      	movq	%rax, %rbx
   5a48e:      	movq	$0x5e, (%rax)
   5a495:      	movl	$0x0, 0x8(%rax)
   5a49c:      	movq	$0x0, 0x10(%rax)
   5a4a4:      	movq	%rax, 0x58(%rsp)
   5a4a9:      	leaq	0x78d8(%rip), %rbp      # 0x61d88 <ref.16>
   5a4b0:      	movq	%rbp, 0x90(%rsp)
   5a4b8:      	movq	%rax, 0x98(%rsp)
   5a4c0:      	movq	$0xa, 0x48(%rsp)
   5a4c9:      	movq	0x99f8(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a4d0:      	testq	%rdi, %rdi
   5a4d3:      	je	0x5afd5 <f.8+0x1675>
   5a4d9:      	leaq	0x10(,%r12,8), %rsi
   5a4e1:      	movq	0x178(%rdi), %rcx
   5a4e8:      	testq	%rcx, %rcx
   5a4eb:      	je	0x5a533 <f.8+0xbd3>
   5a4ed:      	movq	0x170(%rdi), %rax
   5a4f4:      	incq	%rax
   5a4f7:      	movq	%rax, 0x170(%rdi)
   5a4fe:      	movq	%rax, %rdx
   5a501:      	orq	%rcx, %rdx
   5a504:      	shrq	$0x20, %rdx
   5a508:      	je	0x5af21 <f.8+0x15c1>
   5a50e:      	xorl	%edx, %edx
   5a510:      	divq	%rcx
   5a513:      	testq	%rdx, %rdx
   5a516:      	jne	0x5a533 <f.8+0xbd3>
   5a518:      	movq	0x99b1(%rip), %rax      # 0x63ed0 <native_roots.0>
   5a51f:      	movq	%rdi, %r14
   5a522:      	movq	%rsi, %r15
   5a525:      	movq	%rax, %rsi
   5a528:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a52d:      	movq	%r15, %rsi
   5a530:      	movq	%r14, %rdi
   5a533:      	movq	0x9996(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a53a:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a53f:      	testq	%rax, %rax
   5a542:      	je	0x5afda <f.8+0x167a>
   5a548:      	movq	%rax, %r14
   5a54b:      	testb	$0x1, %r14b
   5a54f:      	jne	0x5afd5 <f.8+0x1675>
   5a555:      	movq	$0x4f, (%r14)
   5a55c:      	movq	%r12, 0x8(%r14)
   5a560:      	movq	%r14, 0x78(%rsp)
   5a565:      	movq	0x58(%rsp), %r13
   5a56a:      	movq	%r13, 0x90(%rsp)
   5a572:      	movq	%r14, 0x98(%rsp)
   5a57a:      	movq	%rbp, 0xa0(%rsp)
   5a582:      	movq	%rbx, 0xa8(%rsp)
   5a58a:      	movq	$0xc, 0x48(%rsp)
   5a593:      	movq	0x992e(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a59a:      	testq	%rdi, %rdi
   5a59d:      	je	0x5afd5 <f.8+0x1675>
   5a5a3:      	movq	0x178(%rdi), %rcx
   5a5aa:      	testq	%rcx, %rcx
   5a5ad:      	je	0x5a5ec <f.8+0xc8c>
   5a5af:      	movq	0x170(%rdi), %rax
   5a5b6:      	incq	%rax
   5a5b9:      	movq	%rax, 0x170(%rdi)
   5a5c0:      	movq	%rax, %rdx
   5a5c3:      	orq	%rcx, %rdx
   5a5c6:      	shrq	$0x20, %rdx
   5a5ca:      	je	0x5af33 <f.8+0x15d3>
   5a5d0:      	xorl	%edx, %edx
   5a5d2:      	divq	%rcx
   5a5d5:      	testq	%rdx, %rdx
   5a5d8:      	jne	0x5a5ec <f.8+0xc8c>
   5a5da:      	movq	0x98ef(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a5e1:      	movq	%rdi, %r15
   5a5e4:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a5e9:      	movq	%r15, %rdi
   5a5ec:      	movq	0x98dd(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a5f3:      	movl	$0x20, %esi
   5a5f8:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a5fd:      	testq	%rax, %rax
   5a600:      	je	0x5afda <f.8+0x167a>
   5a606:      	movq	%rax, %r15
   5a609:      	movq	$0x2e, (%rax)
   5a610:      	movq	%r12, 0x8(%rax)
   5a614:      	movq	%r14, 0x10(%rax)
   5a618:      	movq	%r13, 0x18(%rax)
   5a61c:      	movq	%rax, 0x90(%rsp)
   5a624:      	movq	%rbp, 0x98(%rsp)
   5a62c:      	movq	%rbx, 0xa0(%rsp)
   5a634:      	movq	$0xb, 0x48(%rsp)
   5a63d:      	movq	0x9884(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a644:      	testq	%rdi, %rdi
   5a647:      	je	0x5afd5 <f.8+0x1675>
   5a64d:      	movq	0x178(%rdi), %rcx
   5a654:      	testq	%rcx, %rcx
   5a657:      	leaq	0x57d2(%rip), %r12      # 0x5fe30 <writev+0x5fe30>
   5a65e:      	je	0x5a69d <f.8+0xd3d>
   5a660:      	movq	0x170(%rdi), %rax
   5a667:      	incq	%rax
   5a66a:      	movq	%rax, 0x170(%rdi)
   5a671:      	movq	%rax, %rdx
   5a674:      	orq	%rcx, %rdx
   5a677:      	shrq	$0x20, %rdx
   5a67b:      	je	0x5af45 <f.8+0x15e5>
   5a681:      	xorl	%edx, %edx
   5a683:      	divq	%rcx
   5a686:      	testq	%rdx, %rdx
   5a689:      	jne	0x5a69d <f.8+0xd3d>
   5a68b:      	movq	0x983e(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a692:      	movq	%rdi, %r14
   5a695:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a69a:      	movq	%r14, %rdi
   5a69d:      	movq	0x982c(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a6a4:      	movl	$0x18, %esi
   5a6a9:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a6ae:      	testq	%rax, %rax
   5a6b1:      	je	0x5afda <f.8+0x167a>
   5a6b7:      	movq	$0x82, (%rax)
   5a6be:      	movq	%rbp, 0x8(%rax)
   5a6c2:      	movq	%r15, 0x10(%rax)
   5a6c6:      	movq	%rax, 0x10(%rbx)
   5a6ca:      	movq	0x58(%rsp), %rax
   5a6cf:      	testq	%rax, %rax
   5a6d2:      	je	0x5afd5 <f.8+0x1675>
   5a6d8:      	movl	$0x1, 0x8(%rax)
   5a6df:      	movq	0x58(%rsp), %rax
   5a6e4:      	testq	%rax, %rax
   5a6e7:      	leaq	-0x38ae(%rip), %r14     # 0x56e40 <_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$::fmt::h4581551deb22294e>
   5a6ee:      	je	0x5afd5 <f.8+0x1675>
   5a6f4:      	cmpl	$0x0, 0x8(%rax)
   5a6f8:      	je	0x5afd5 <f.8+0x1675>
   5a6fe:      	movq	0x10(%rax), %rax
   5a702:      	testq	%rax, %rax
   5a705:      	je	0x5afd5 <f.8+0x1675>
   5a70b:      	movq	%rax, 0x70(%rsp)
   5a710:      	movq	0x8(%rax), %rcx
   5a714:      	testq	%rcx, %rcx
   5a717:      	je	0x5afd5 <f.8+0x1675>
   5a71d:      	movq	0x10(%rax), %rdi
   5a721:      	movq	0x8(%rcx), %rax
   5a725:      	movq	%rdi, 0x90(%rsp)
   5a72d:      	movq	$0x9, 0x48(%rsp)
   5a736:      	xorl	%esi, %esi
   5a738:      	callq	*%rax
   5a73a:      	subq	$0x8, %rsp
   5a73e:      	cmpb	$0x0, 0x9913(%rip)      # 0x64058 <g.25>
   5a745:      	je	0x5afd5 <f.8+0x1675>
   5a74b:      	cmpq	$0x0, 0x98fd(%rip)      # 0x64050 <g.24>
   5a753:      	je	0x5afd5 <f.8+0x1675>
   5a759:      	movq	$0x8, 0x48(%rsp)
   5a762:      	leaq	0x56d7(%rip), %rax      # 0x5fe40 <writev+0x5fe40>
   5a769:      	movq	%rax, 0x8(%rsp)
   5a76e:      	movq	%r14, 0x10(%rsp)
   5a773:      	leaq	-0x53f78(%rip), %rbx    # 0x6802 <writev+0x6802>
   5a77a:      	leaq	0x8(%rsp), %rsi
   5a77f:      	movq	%rbx, %rdi
   5a782:      	callq	0x4e2a0 <std::io::stdio::_print>
   5a787:      	movq	$0x8, 0x48(%rsp)
   5a790:      	leaq	0x56b9(%rip), %rax      # 0x5fe50 <writev+0x5fe50>
   5a797:      	movq	%rax, 0x8(%rsp)
   5a79c:      	movq	%r14, 0x10(%rsp)
   5a7a1:      	leaq	0x8(%rsp), %rsi
   5a7a6:      	movq	%rbx, %rdi
   5a7a9:      	callq	0x4e2a0 <std::io::stdio::_print>
   5a7ae:      	movq	$0x8, 0x48(%rsp)
   5a7b7:      	movq	%r12, 0x8(%rsp)
   5a7bc:      	movq	%r14, 0x10(%rsp)
   5a7c1:      	leaq	0x8(%rsp), %rsi
   5a7c6:      	movq	%rbx, %rdi
   5a7c9:      	callq	0x4e2a0 <std::io::stdio::_print>
   5a7ce:      	movq	$0x8, 0x48(%rsp)
   5a7d7:      	movq	0x96ea(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a7de:      	testq	%rdi, %rdi
   5a7e1:      	je	0x5afd5 <f.8+0x1675>
   5a7e7:      	movq	0x178(%rdi), %rcx
   5a7ee:      	testq	%rcx, %rcx
   5a7f1:      	je	0x5a830 <f.8+0xed0>
   5a7f3:      	movq	0x170(%rdi), %rax
   5a7fa:      	incq	%rax
   5a7fd:      	movq	%rax, 0x170(%rdi)
   5a804:      	movq	%rax, %rdx
   5a807:      	orq	%rcx, %rdx
   5a80a:      	shrq	$0x20, %rdx
   5a80e:      	je	0x5af57 <f.8+0x15f7>
   5a814:      	xorl	%edx, %edx
   5a816:      	divq	%rcx
   5a819:      	testq	%rdx, %rdx
   5a81c:      	jne	0x5a830 <f.8+0xed0>
   5a81e:      	movq	0x96ab(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a825:      	movq	%rdi, %rbx
   5a828:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a82d:      	movq	%rbx, %rdi
   5a830:      	movq	0x9699(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a837:      	movl	$0x18, %esi
   5a83c:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a841:      	testq	%rax, %rax
   5a844:      	je	0x5afda <f.8+0x167a>
   5a84a:      	movq	%rax, %rbx
   5a84d:      	movq	$0x5e, (%rax)
   5a854:      	movl	$0x0, 0x8(%rax)
   5a85b:      	movq	$0x0, 0x10(%rax)
   5a863:      	movq	%rax, 0x58(%rsp)
   5a868:      	movq	0x50(%rsp), %rax
   5a86d:      	testq	%rax, %rax
   5a870:      	je	0x5afd5 <f.8+0x1675>
   5a876:      	movq	0x68(%rsp), %r15
   5a87b:      	movq	0x60(%rsp), %r13
   5a880:      	movq	0x20(%rax), %r12
   5a884:      	movq	%r12, 0x90(%rsp)
   5a88c:      	movq	%r13, 0x98(%rsp)
   5a894:      	movq	%r15, 0xa0(%rsp)
   5a89c:      	leaq	0x74b5(%rip), %rbp      # 0x61d58 <ref.11>
   5a8a3:      	movq	%rbp, 0xa8(%rsp)
   5a8ab:      	movq	%rbx, 0xb0(%rsp)
   5a8b3:      	leaq	0x748e(%rip), %rax      # 0x61d48 <ref.10>
   5a8ba:      	movq	%rax, 0xb8(%rsp)
   5a8c2:      	movq	%rbx, 0xc0(%rsp)
   5a8ca:      	movq	$0xf, 0x48(%rsp)
   5a8d3:      	movq	0x95ee(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a8da:      	testq	%rdi, %rdi
   5a8dd:      	je	0x5afd5 <f.8+0x1675>
   5a8e3:      	movq	0x178(%rdi), %rcx
   5a8ea:      	testq	%rcx, %rcx
   5a8ed:      	je	0x5a92c <f.8+0xfcc>
   5a8ef:      	movq	0x170(%rdi), %rax
   5a8f6:      	incq	%rax
   5a8f9:      	movq	%rax, 0x170(%rdi)
   5a900:      	movq	%rax, %rdx
   5a903:      	orq	%rcx, %rdx
   5a906:      	shrq	$0x20, %rdx
   5a90a:      	je	0x5af69 <f.8+0x1609>
   5a910:      	xorl	%edx, %edx
   5a912:      	divq	%rcx
   5a915:      	testq	%rdx, %rdx
   5a918:      	jne	0x5a92c <f.8+0xfcc>
   5a91a:      	movq	0x95af(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a921:      	movq	%rdi, %r14
   5a924:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a929:      	movq	%r14, %rdi
   5a92c:      	movq	0x959d(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a933:      	movl	$0x20, %esi
   5a938:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a93d:      	testq	%rax, %rax
   5a940:      	je	0x5afda <f.8+0x167a>
   5a946:      	movq	%rax, %r14
   5a949:      	movq	$0x2a, (%rax)
   5a950:      	movq	%r15, 0x8(%rax)
   5a954:      	movq	%r13, 0x10(%rax)
   5a958:      	movq	%r12, 0x18(%rax)
   5a95c:      	movq	%rax, 0x90(%rsp)
   5a964:      	movq	%rbp, 0x98(%rsp)
   5a96c:      	movq	%rbx, 0xa0(%rsp)
   5a974:      	leaq	0x73cd(%rip), %r13      # 0x61d48 <ref.10>
   5a97b:      	movq	%r13, 0xa8(%rsp)
   5a983:      	movq	%rbx, 0xb0(%rsp)
   5a98b:      	movq	$0xd, 0x48(%rsp)
   5a994:      	movq	0x952d(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a99b:      	testq	%rdi, %rdi
   5a99e:      	je	0x5afd5 <f.8+0x1675>
   5a9a4:      	movq	0x178(%rdi), %rcx
   5a9ab:      	testq	%rcx, %rcx
   5a9ae:      	leaq	0x547b(%rip), %r12      # 0x5fe30 <writev+0x5fe30>
   5a9b5:      	je	0x5a9f4 <f.8+0x1094>
   5a9b7:      	movq	0x170(%rdi), %rax
   5a9be:      	incq	%rax
   5a9c1:      	movq	%rax, 0x170(%rdi)
   5a9c8:      	movq	%rax, %rdx
   5a9cb:      	orq	%rcx, %rdx
   5a9ce:      	shrq	$0x20, %rdx
   5a9d2:      	je	0x5af7b <f.8+0x161b>
   5a9d8:      	xorl	%edx, %edx
   5a9da:      	divq	%rcx
   5a9dd:      	testq	%rdx, %rdx
   5a9e0:      	jne	0x5a9f4 <f.8+0x1094>
   5a9e2:      	movq	0x94e7(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5a9e9:      	movq	%rdi, %r15
   5a9ec:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a9f1:      	movq	%r15, %rdi
   5a9f4:      	movq	0x94d5(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5a9fb:      	movl	$0x18, %esi
   5aa00:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5aa05:      	testq	%rax, %rax
   5aa08:      	je	0x5afda <f.8+0x167a>
   5aa0e:      	movq	%rax, %r15
   5aa11:      	movq	$0x82, (%rax)
   5aa18:      	movq	%rbp, 0x8(%rax)
   5aa1c:      	movq	%r14, 0x10(%rax)
   5aa20:      	movq	%rax, 0x90(%rsp)
   5aa28:      	movq	%rbx, 0x98(%rsp)
   5aa30:      	movq	%r13, 0xa0(%rsp)
   5aa38:      	movq	%rbx, 0xa8(%rsp)
   5aa40:      	movq	$0xc, 0x48(%rsp)
   5aa49:      	movq	0x9478(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5aa50:      	testq	%rdi, %rdi
   5aa53:      	je	0x5afd5 <f.8+0x1675>
   5aa59:      	movq	0x178(%rdi), %rcx
   5aa60:      	testq	%rcx, %rcx
   5aa63:      	je	0x5aaa2 <f.8+0x1142>
   5aa65:      	movq	0x170(%rdi), %rax
   5aa6c:      	incq	%rax
   5aa6f:      	movq	%rax, 0x170(%rdi)
   5aa76:      	movq	%rax, %rdx
   5aa79:      	orq	%rcx, %rdx
   5aa7c:      	shrq	$0x20, %rdx
   5aa80:      	je	0x5af8d <f.8+0x162d>
   5aa86:      	xorl	%edx, %edx
   5aa88:      	divq	%rcx
   5aa8b:      	testq	%rdx, %rdx
   5aa8e:      	jne	0x5aaa2 <f.8+0x1142>
   5aa90:      	movq	0x9439(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5aa97:      	movq	%rdi, %r14
   5aa9a:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5aa9f:      	movq	%r14, %rdi
   5aaa2:      	movq	0x9427(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5aaa9:      	movl	$0x18, %esi
   5aaae:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5aab3:      	testq	%rax, %rax
   5aab6:      	je	0x5afda <f.8+0x167a>
   5aabc:      	movq	%rax, %r14
   5aabf:      	movq	$0x5e, (%rax)
   5aac6:      	movl	$0x1, 0x8(%rax)
   5aacd:      	movq	%r15, 0x10(%rax)
   5aad1:      	movq	%rax, 0x90(%rsp)
   5aad9:      	movq	%rbx, 0x98(%rsp)
   5aae1:      	movq	%r13, 0xa0(%rsp)
   5aae9:      	movq	%rbx, 0xa8(%rsp)
   5aaf1:      	movq	$0xc, 0x48(%rsp)
   5aafa:      	movq	0x93c7(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5ab01:      	testq	%rdi, %rdi
   5ab04:      	je	0x5afd5 <f.8+0x1675>
   5ab0a:      	movq	0x178(%rdi), %rcx
   5ab11:      	testq	%rcx, %rcx
   5ab14:      	je	0x5ab53 <f.8+0x11f3>
   5ab16:      	movq	0x170(%rdi), %rax
   5ab1d:      	incq	%rax
   5ab20:      	movq	%rax, 0x170(%rdi)
   5ab27:      	movq	%rax, %rdx
   5ab2a:      	orq	%rcx, %rdx
   5ab2d:      	shrq	$0x20, %rdx
   5ab31:      	je	0x5af9f <f.8+0x163f>
   5ab37:      	xorl	%edx, %edx
   5ab39:      	divq	%rcx
   5ab3c:      	testq	%rdx, %rdx
   5ab3f:      	jne	0x5ab53 <f.8+0x11f3>
   5ab41:      	movq	0x9388(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5ab48:      	movq	%rdi, %r15
   5ab4b:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5ab50:      	movq	%r15, %rdi
   5ab53:      	movq	0x9376(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5ab5a:      	movl	$0x20, %esi
   5ab5f:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5ab64:      	testq	%rax, %rax
   5ab67:      	je	0x5afda <f.8+0x167a>
   5ab6d:      	movq	%rax, %r15
   5ab70:      	movq	$0x26, (%rax)
   5ab77:      	movq	0xd0(%rsp), %rax
   5ab7f:      	movq	%rax, 0x8(%r15)
   5ab83:      	movq	%rbx, 0x10(%r15)
   5ab87:      	movq	%r14, 0x18(%r15)
   5ab8b:      	movq	%r15, 0x90(%rsp)
   5ab93:      	movq	%r13, 0x98(%rsp)
   5ab9b:      	movq	%rbx, 0xa0(%rsp)
   5aba3:      	movq	$0xb, 0x48(%rsp)
   5abac:      	movq	0x9315(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5abb3:      	testq	%rdi, %rdi
   5abb6:      	je	0x5afd5 <f.8+0x1675>
   5abbc:      	movq	0x178(%rdi), %rcx
   5abc3:      	testq	%rcx, %rcx
   5abc6:      	je	0x5ac05 <f.8+0x12a5>
   5abc8:      	movq	0x170(%rdi), %rax
   5abcf:      	incq	%rax
   5abd2:      	movq	%rax, 0x170(%rdi)
   5abd9:      	movq	%rax, %rdx
   5abdc:      	orq	%rcx, %rdx
   5abdf:      	shrq	$0x20, %rdx
   5abe3:      	je	0x5afb1 <f.8+0x1651>
   5abe9:      	xorl	%edx, %edx
   5abeb:      	divq	%rcx
   5abee:      	testq	%rdx, %rdx
   5abf1:      	jne	0x5ac05 <f.8+0x12a5>
   5abf3:      	movq	0x92d6(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5abfa:      	movq	%rdi, %r14
   5abfd:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5ac02:      	movq	%r14, %rdi
   5ac05:      	movq	0x92c4(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5ac0c:      	movl	$0x18, %esi
   5ac11:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5ac16:      	testq	%rax, %rax
   5ac19:      	je	0x5afda <f.8+0x167a>
   5ac1f:      	movq	$0x82, (%rax)
   5ac26:      	movq	%r13, 0x8(%rax)
   5ac2a:      	movq	%r15, 0x10(%rax)
   5ac2e:      	movq	%rax, 0x10(%rbx)
   5ac32:      	movq	0x58(%rsp), %rax
   5ac37:      	testq	%rax, %rax
   5ac3a:      	je	0x5afd5 <f.8+0x1675>
   5ac40:      	movl	$0x1, 0x8(%rax)
   5ac47:      	movq	0x58(%rsp), %rax
   5ac4c:      	testq	%rax, %rax
   5ac4f:      	leaq	-0x3e16(%rip), %r14     # 0x56e40 <_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$::fmt::h4581551deb22294e>
   5ac56:      	je	0x5afd5 <f.8+0x1675>
   5ac5c:      	cmpl	$0x0, 0x8(%rax)
   5ac60:      	je	0x5afd5 <f.8+0x1675>
   5ac66:      	movq	0x10(%rax), %rax
   5ac6a:      	testq	%rax, %rax
   5ac6d:      	je	0x5afd5 <f.8+0x1675>
   5ac73:      	movq	%rax, 0x70(%rsp)
   5ac78:      	movq	0x8(%rax), %rcx
   5ac7c:      	testq	%rcx, %rcx
   5ac7f:      	je	0x5afd5 <f.8+0x1675>
   5ac85:      	movq	0x10(%rax), %rdi
   5ac89:      	movq	0x8(%rcx), %rax
   5ac8d:      	movq	%rdi, 0x90(%rsp)
   5ac95:      	movq	$0x9, 0x48(%rsp)
   5ac9e:      	movl	$0x4, %esi
   5aca3:      	callq	*%rax
   5aca5:      	subq	$0x8, %rsp
   5aca9:      	cmpb	$0x0, 0x92f8(%rip)      # 0x63fa8 <g.3>
   5acb0:      	je	0x5afd5 <f.8+0x1675>
   5acb6:      	cmpq	$0x0, 0x92e2(%rip)      # 0x63fa0 <g.2>
   5acbe:      	je	0x5afd5 <f.8+0x1675>
   5acc4:      	cmpb	$0x0, 0x934d(%rip)      # 0x64018 <g.17>
   5accb:      	je	0x5afd5 <f.8+0x1675>
   5acd1:      	cmpq	$0x0, 0x9337(%rip)      # 0x64010 <g.16>
   5acd9:      	je	0x5afd5 <f.8+0x1675>
   5acdf:      	movq	0x78(%rsp), %rax
   5ace4:      	testq	%rax, %rax
   5ace7:      	je	0x5afd5 <f.8+0x1675>
   5aced:      	testb	$0x1, %al
   5acef:      	jne	0x5afd5 <f.8+0x1675>
   5acf5:      	movq	0x8(%rax), %rdx
   5acf9:      	movl	%edx, %esi
   5acfb:      	shrl	%esi
   5acfd:      	cmpq	$0x3e9, %rsi            # imm = 0x3E9
   5ad04:      	movl	$0x3e9, %ecx            # imm = 0x3E9
   5ad09:      	cmovbq	%rsi, %rcx
   5ad0d:      	leaq	-0x1(%rcx), %rsi
   5ad11:      	movq	%rsi, %rdi
   5ad14:      	shrq	$0x20, %rdi
   5ad18:      	jne	0x5afd5 <f.8+0x1675>
   5ad1e:      	cmpq	%rdx, %rsi
   5ad21:      	jae	0x5afd5 <f.8+0x1675>
   5ad27:      	cmpb	$0x0, 0x92fa(%rip)      # 0x64028 <g.19>
   5ad2e:      	je	0x5afd5 <f.8+0x1675>
   5ad34:      	cmpq	$0x0, 0x92e4(%rip)      # 0x64020 <g.18>
   5ad3c:      	je	0x5afd5 <f.8+0x1675>
   5ad42:      	movsd	0x8(%rax,%rcx,8), %xmm0
   5ad48:      	cvtsi2sd	%ecx, %xmm1
   5ad4c:      	movsd	-0x54e7c(%rip), %xmm2   # 0x5ed8 <writev+0x5ed8>
   5ad54:      	divsd	%xmm1, %xmm2
   5ad58:      	ucomisd	%xmm2, %xmm0
   5ad5c:      	jne	0x5ad60 <f.8+0x1400>
   5ad5e:      	jnp	0x5adae <f.8+0x144e>
   5ad60:      	movq	$0x8, 0x48(%rsp)
   5ad69:      	leaq	0x5130(%rip), %rax      # 0x5fea0 <writev+0x5fea0>
   5ad70:      	movq	%rax, 0x8(%rsp)
   5ad75:      	movq	%r14, 0x10(%rsp)
   5ad7a:      	leaq	-0x5457f(%rip), %rbx    # 0x6802 <writev+0x6802>
   5ad81:      	leaq	0x8(%rsp), %rsi
   5ad86:      	movq	%rbx, %rdi
   5ad89:      	callq	0x4e2a0 <std::io::stdio::_print>
   5ad8e:      	movq	$0x8, 0x48(%rsp)
   5ad97:      	movq	%r12, 0x8(%rsp)
   5ad9c:      	movq	%r14, 0x10(%rsp)
   5ada1:      	leaq	0x8(%rsp), %rsi
   5ada6:      	movq	%rbx, %rdi
   5ada9:      	callq	0x4e2a0 <std::io::stdio::_print>
   5adae:      	cmpb	$0x0, 0x92a3(%rip)      # 0x64058 <g.25>
   5adb5:      	je	0x5afd5 <f.8+0x1675>
   5adbb:      	cmpq	$0x0, 0x928d(%rip)      # 0x64050 <g.24>
   5adc3:      	je	0x5afd5 <f.8+0x1675>
   5adc9:      	movq	$0x8, 0x48(%rsp)
   5add2:      	leaq	0x5067(%rip), %rax      # 0x5fe40 <writev+0x5fe40>
   5add9:      	movq	%rax, 0x8(%rsp)
   5adde:      	movq	%r14, 0x10(%rsp)
   5ade3:      	leaq	-0x545e8(%rip), %rbx    # 0x6802 <writev+0x6802>
   5adea:      	leaq	0x8(%rsp), %rsi
   5adef:      	movq	%rbx, %rdi
   5adf2:      	callq	0x4e2a0 <std::io::stdio::_print>
   5adf7:      	movq	$0x8, 0x48(%rsp)
   5ae00:      	leaq	0x5049(%rip), %rax      # 0x5fe50 <writev+0x5fe50>
   5ae07:      	movq	%rax, 0x8(%rsp)
   5ae0c:      	movq	%r14, 0x10(%rsp)
   5ae11:      	leaq	0x8(%rsp), %rsi
   5ae16:      	movq	%rbx, %rdi
   5ae19:      	callq	0x4e2a0 <std::io::stdio::_print>
   5ae1e:      	movq	$0x8, 0x48(%rsp)
   5ae27:      	movq	%r12, 0x8(%rsp)
   5ae2c:      	movq	%r14, 0x10(%rsp)
   5ae31:      	leaq	0x8(%rsp), %rsi
   5ae36:      	movq	%rbx, %rdi
   5ae39:      	callq	0x4e2a0 <std::io::stdio::_print>
   5ae3e:      	cmpq	$0x0, 0x40(%rsp)
   5ae44:      	je	0x5ae59 <f.8+0x14f9>
   5ae46:      	movq	0x38(%rsp), %rax
   5ae4b:      	movq	%rax, 0x907e(%rip)      # 0x63ed0 <native_roots.0>
   5ae52:      	decq	0x9057(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5ae59:      	addq	$0xd8, %rsp
   5ae60:      	popq	%rbx
   5ae61:      	popq	%r12
   5ae63:      	popq	%r13
   5ae65:      	popq	%r14
   5ae67:      	popq	%r15
   5ae69:      	popq	%rbp
   5ae6a:      	retq	$0x8
   5ae6d:      	xorl	%edx, %edx
   5ae6f:      	divl	%esi
   5ae71:      	testq	%rdx, %rdx
   5ae74:      	jne	0x59a46 <f.8+0xe6>
   5ae7a:      	jmp	0x59a2f <f.8+0xcf>
   5ae7f:      	xorl	%edx, %edx
   5ae81:      	divl	%ecx
   5ae83:      	testq	%rdx, %rdx
   5ae86:      	jne	0x59aec <f.8+0x18c>
   5ae8c:      	jmp	0x59ada <f.8+0x17a>
   5ae91:      	xorl	%edx, %edx
   5ae93:      	divl	%ecx
   5ae95:      	testq	%rdx, %rdx
   5ae98:      	jne	0x59b86 <f.8+0x226>
   5ae9e:      	jmp	0x59b74 <f.8+0x214>
   5aea3:      	xorl	%edx, %edx
   5aea5:      	divl	%ecx
   5aea7:      	testq	%rdx, %rdx
   5aeaa:      	jne	0x59c26 <f.8+0x2c6>
   5aeb0:      	jmp	0x59c14 <f.8+0x2b4>
   5aeb5:      	xorl	%edx, %edx
   5aeb7:      	divl	%ecx
   5aeb9:      	testq	%rdx, %rdx
   5aebc:      	jne	0x59cd0 <f.8+0x370>
   5aec2:      	jmp	0x59cbe <f.8+0x35e>
   5aec7:      	xorl	%edx, %edx
   5aec9:      	divl	%ecx
   5aecb:      	testq	%rdx, %rdx
   5aece:      	jne	0x59d6a <f.8+0x40a>
   5aed4:      	jmp	0x59d58 <f.8+0x3f8>
   5aed9:      	xorl	%edx, %edx
   5aedb:      	divl	%ecx
   5aedd:      	testq	%rdx, %rdx
   5aee0:      	jne	0x5a11f <f.8+0x7bf>
   5aee6:      	jmp	0x5a10d <f.8+0x7ad>
   5aeeb:      	xorl	%edx, %edx
   5aeed:      	divl	%ecx
   5aeef:      	testq	%rdx, %rdx
   5aef2:      	jne	0x5a1b9 <f.8+0x859>
   5aef8:      	jmp	0x5a1a7 <f.8+0x847>
   5aefd:      	xorl	%edx, %edx
   5aeff:      	divl	%ecx
   5af01:      	testq	%rdx, %rdx
   5af04:      	jne	0x5a253 <f.8+0x8f3>
   5af0a:      	jmp	0x5a241 <f.8+0x8e1>
   5af0f:      	xorl	%edx, %edx
   5af11:      	divl	%ecx
   5af13:      	testq	%rdx, %rdx
   5af16:      	jne	0x5a471 <f.8+0xb11>
   5af1c:      	jmp	0x5a45f <f.8+0xaff>
   5af21:      	xorl	%edx, %edx
   5af23:      	divl	%ecx
   5af25:      	testq	%rdx, %rdx
   5af28:      	jne	0x5a533 <f.8+0xbd3>
   5af2e:      	jmp	0x5a518 <f.8+0xbb8>
   5af33:      	xorl	%edx, %edx
   5af35:      	divl	%ecx
   5af37:      	testq	%rdx, %rdx
   5af3a:      	jne	0x5a5ec <f.8+0xc8c>
   5af40:      	jmp	0x5a5da <f.8+0xc7a>
   5af45:      	xorl	%edx, %edx
   5af47:      	divl	%ecx
   5af49:      	testq	%rdx, %rdx
   5af4c:      	jne	0x5a69d <f.8+0xd3d>
   5af52:      	jmp	0x5a68b <f.8+0xd2b>
   5af57:      	xorl	%edx, %edx
   5af59:      	divl	%ecx
   5af5b:      	testq	%rdx, %rdx
   5af5e:      	jne	0x5a830 <f.8+0xed0>
   5af64:      	jmp	0x5a81e <f.8+0xebe>
   5af69:      	xorl	%edx, %edx
   5af6b:      	divl	%ecx
   5af6d:      	testq	%rdx, %rdx
   5af70:      	jne	0x5a92c <f.8+0xfcc>
   5af76:      	jmp	0x5a91a <f.8+0xfba>
   5af7b:      	xorl	%edx, %edx
   5af7d:      	divl	%ecx
   5af7f:      	testq	%rdx, %rdx
   5af82:      	jne	0x5a9f4 <f.8+0x1094>
   5af88:      	jmp	0x5a9e2 <f.8+0x1082>
   5af8d:      	xorl	%edx, %edx
   5af8f:      	divl	%ecx
   5af91:      	testq	%rdx, %rdx
   5af94:      	jne	0x5aaa2 <f.8+0x1142>
   5af9a:      	jmp	0x5aa90 <f.8+0x1130>
   5af9f:      	xorl	%edx, %edx
   5afa1:      	divl	%ecx
   5afa3:      	testq	%rdx, %rdx
   5afa6:      	jne	0x5ab53 <f.8+0x11f3>
   5afac:      	jmp	0x5ab41 <f.8+0x11e1>
   5afb1:      	xorl	%edx, %edx
   5afb3:      	divl	%ecx
   5afb5:      	testq	%rdx, %rdx
   5afb8:      	jne	0x5ac05 <f.8+0x12a5>
   5afbe:      	jmp	0x5abf3 <f.8+0x1293>
   5afc3:      	xorl	%edx, %edx
   5afc5:      	divl	%ecx
   5afc7:      	testq	%rdx, %rdx
   5afca:      	jne	0x5a31d <f.8+0x9bd>
   5afd0:      	jmp	0x5a30b <f.8+0x9ab>
   5afd5:      	callq	0x55920 <native_trap>
   5afda:      	leaq	-0x51bcd(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5afe1:      	movl	$0x2f, %esi
   5afe6:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5afeb:      	int3
   5afec:      	int3
   5afed:      	int3
   5afee:      	int3
   5afef:      	int3

000000000005aff0 <f.18>:
   5aff0:      	pushq	%r15
   5aff2:      	pushq	%r14
   5aff4:      	pushq	%rbx
   5aff5:      	subq	$0x60, %rsp
   5aff9:      	movq	$0x7, 0x18(%rsp)
   5b002:      	movq	$0x0, 0x20(%rsp)
   5b00b:      	movq	0x8ebe(%rip), %rax      # 0x63ed0 <native_roots.0>
   5b012:      	movq	%rax, 0x10(%rsp)
   5b017:      	movq	0x8e92(%rip), %rax      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b01e:      	incq	%rax
   5b021:      	movq	%rax, 0x8e88(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b028:      	movq	0x8e89(%rip), %rcx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b02f:      	cmpq	%rcx, %rax
   5b032:      	cmovbeq	%rcx, %rax
   5b036:      	leaq	0x10(%rsp), %rcx
   5b03b:      	movq	%rcx, 0x8e8e(%rip)      # 0x63ed0 <native_roots.0>
   5b042:      	movq	%rax, 0x8e6f(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b049:      	movq	%rdi, 0x28(%rsp)
   5b04e:      	xorps	%xmm0, %xmm0
   5b051:      	movups	%xmm0, 0x30(%rsp)
   5b056:      	movups	%xmm0, 0x40(%rsp)
   5b05b:      	testq	%rsi, %rsi
   5b05e:      	jle	0x5b1cf <f.18+0x1df>
   5b064:      	testq	%rdi, %rdi
   5b067:      	je	0x5b40a <f.18+0x41a>
   5b06d:      	movq	0x8(%rdi), %rax
   5b071:      	testq	%rax, %rax
   5b074:      	je	0x5b40a <f.18+0x41a>
   5b07a:      	cmpl	$0x0, 0x8(%rax)
   5b07e:      	je	0x5b40a <f.18+0x41a>
   5b084:      	movq	%rax, 0x30(%rsp)
   5b089:      	cmpq	$0x0, 0x10(%rax)
   5b08e:      	je	0x5b40a <f.18+0x41a>
   5b094:      	movq	%rsi, %rbx
   5b097:      	decq	%rbx
   5b09a:      	movq	%rdi, 0x50(%rsp)
   5b09f:      	movq	$0x6, 0x20(%rsp)
   5b0a8:      	movq	%rbx, %rsi
   5b0ab:      	callq	0x5aff0 <f.18>
   5b0b0:      	subq	$0x8, %rsp
   5b0b4:      	movq	%rax, 0x48(%rsp)
   5b0b9:      	movq	0x30(%rsp), %rax
   5b0be:      	testq	%rax, %rax
   5b0c1:      	je	0x5b40a <f.18+0x41a>
   5b0c7:      	cmpl	$0x0, 0x8(%rax)
   5b0cb:      	je	0x5b40a <f.18+0x41a>
   5b0d1:      	movq	0x28(%rsp), %rdi
   5b0d6:      	testq	%rdi, %rdi
   5b0d9:      	je	0x5b40a <f.18+0x41a>
   5b0df:      	movq	0x8(%rdi), %rax
   5b0e3:      	testq	%rax, %rax
   5b0e6:      	je	0x5b40a <f.18+0x41a>
   5b0ec:      	cmpq	$0x0, 0x10(%rax)
   5b0f1:      	je	0x5b40a <f.18+0x41a>
   5b0f7:      	movq	%rdi, 0x50(%rsp)
   5b0fc:      	movq	$0x6, 0x20(%rsp)
   5b105:      	movq	%rbx, %rsi
   5b108:      	callq	0x5aff0 <f.18>
   5b10d:      	subq	$0x8, %rsp
   5b111:      	movq	%rax, 0x40(%rsp)
   5b116:      	cmpb	$0x0, 0x8e9b(%rip)      # 0x63fb8 <g.5>
   5b11d:      	je	0x5b40a <f.18+0x41a>
   5b123:      	cmpq	$0x0, 0x8e85(%rip)      # 0x63fb0 <g.4>
   5b12b:      	je	0x5b40a <f.18+0x41a>
   5b131:      	movq	0x48(%rsp), %r14
   5b136:      	movq	%r14, 0x50(%rsp)
   5b13b:      	movq	$0x6, 0x20(%rsp)
   5b144:      	movq	0x8d7d(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b14b:      	testq	%rdi, %rdi
   5b14e:      	je	0x5b40a <f.18+0x41a>
   5b154:      	movq	0x178(%rdi), %rcx
   5b15b:      	testq	%rcx, %rcx
   5b15e:      	je	0x5b19d <f.18+0x1ad>
   5b160:      	movq	0x170(%rdi), %rax
   5b167:      	incq	%rax
   5b16a:      	movq	%rax, 0x170(%rdi)
   5b171:      	movq	%rax, %rdx
   5b174:      	orq	%rcx, %rdx
   5b177:      	shrq	$0x20, %rdx
   5b17b:      	je	0x5b3e6 <f.18+0x3f6>
   5b181:      	xorl	%edx, %edx
   5b183:      	divq	%rcx
   5b186:      	testq	%rdx, %rdx
   5b189:      	jne	0x5b19d <f.18+0x1ad>
   5b18b:      	movq	0x8d3e(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5b192:      	movq	%rdi, %rbx
   5b195:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b19a:      	movq	%rbx, %rdi
   5b19d:      	movq	0x8d2c(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5b1a4:      	movl	$0x10, %esi
   5b1a9:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b1ae:      	testq	%rax, %rax
   5b1b1:      	je	0x5b40f <f.18+0x41f>
   5b1b7:      	movq	%rax, %rbx
   5b1ba:      	movq	$0x36, (%rax)
   5b1c1:      	movq	%r14, 0x8(%rax)
   5b1c5:      	movq	0x40(%rsp), %r15
   5b1ca:      	jmp	0x5b281 <f.18+0x291>
   5b1cf:      	cmpb	$0x0, 0x8de2(%rip)      # 0x63fb8 <g.5>
   5b1d6:      	je	0x5b40a <f.18+0x41a>
   5b1dc:      	cmpq	$0x0, 0x8dcc(%rip)      # 0x63fb0 <g.4>
   5b1e4:      	je	0x5b40a <f.18+0x41a>
   5b1ea:      	leaq	-0x50521(%rip), %r15    # 0xacd0 <object.1.0>
   5b1f1:      	movq	%r15, 0x50(%rsp)
   5b1f6:      	movq	$0x6, 0x20(%rsp)
   5b1ff:      	movq	0x8cc2(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b206:      	testq	%rdi, %rdi
   5b209:      	je	0x5b40a <f.18+0x41a>
   5b20f:      	movq	0x178(%rdi), %rsi
   5b216:      	testq	%rsi, %rsi
   5b219:      	je	0x5b25d <f.18+0x26d>
   5b21b:      	movq	0x170(%rdi), %rax
   5b222:      	incq	%rax
   5b225:      	movq	%rax, 0x170(%rdi)
   5b22c:      	movq	%rax, %rdx
   5b22f:      	orq	%rsi, %rdx
   5b232:      	shrq	$0x20, %rdx
   5b236:      	je	0x5b3f8 <f.18+0x408>
   5b23c:      	xorl	%edx, %edx
   5b23e:      	divq	%rsi
   5b241:      	testq	%rdx, %rdx
   5b244:      	jne	0x5b25d <f.18+0x26d>
   5b246:      	leaq	0x10(%rsp), %rsi
   5b24b:      	movq	%rdi, %rbx
   5b24e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b253:      	movq	%rbx, %rdi
   5b256:      	movq	0x8c73(%rip), %rcx      # 0x63ed0 <native_roots.0>
   5b25d:      	movl	$0x10, %esi
   5b262:      	movq	%rcx, %rdx
   5b265:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b26a:      	testq	%rax, %rax
   5b26d:      	je	0x5b40f <f.18+0x41f>
   5b273:      	movq	%rax, %rbx
   5b276:      	movq	$0x36, (%rax)
   5b27d:      	movq	%r15, 0x8(%rax)
   5b281:      	movq	%r15, 0x50(%rsp)
   5b286:      	movq	%rbx, 0x58(%rsp)
   5b28b:      	movq	$0x7, 0x20(%rsp)
   5b294:      	movq	0x8c2d(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b29b:      	testq	%rdi, %rdi
   5b29e:      	je	0x5b40a <f.18+0x41a>
   5b2a4:      	movq	0x178(%rdi), %rcx
   5b2ab:      	testq	%rcx, %rcx
   5b2ae:      	je	0x5b2ed <f.18+0x2fd>
   5b2b0:      	movq	0x170(%rdi), %rax
   5b2b7:      	incq	%rax
   5b2ba:      	movq	%rax, 0x170(%rdi)
   5b2c1:      	movq	%rax, %rdx
   5b2c4:      	orq	%rcx, %rdx
   5b2c7:      	shrq	$0x20, %rdx
   5b2cb:      	je	0x5b3c9 <f.18+0x3d9>
   5b2d1:      	xorl	%edx, %edx
   5b2d3:      	divq	%rcx
   5b2d6:      	testq	%rdx, %rdx
   5b2d9:      	jne	0x5b2ed <f.18+0x2fd>
   5b2db:      	movq	0x8bee(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5b2e2:      	movq	%rdi, %r14
   5b2e5:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b2ea:      	movq	%r14, %rdi
   5b2ed:      	movq	0x8bdc(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5b2f4:      	movl	$0x10, %esi
   5b2f9:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b2fe:      	testq	%rax, %rax
   5b301:      	je	0x5b40f <f.18+0x41f>
   5b307:      	movq	%rax, %r14
   5b30a:      	movq	$0x36, (%rax)
   5b311:      	movq	%r15, 0x8(%rax)
   5b315:      	movq	%rax, 0x50(%rsp)
   5b31a:      	movq	%rbx, 0x58(%rsp)
   5b31f:      	movq	$0x7, 0x20(%rsp)
   5b328:      	movq	0x8b99(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b32f:      	testq	%rdi, %rdi
   5b332:      	je	0x5b40a <f.18+0x41a>
   5b338:      	movq	0x178(%rdi), %rcx
   5b33f:      	testq	%rcx, %rcx
   5b342:      	je	0x5b37d <f.18+0x38d>
   5b344:      	movq	0x170(%rdi), %rax
   5b34b:      	incq	%rax
   5b34e:      	movq	%rax, 0x170(%rdi)
   5b355:      	movq	%rax, %rdx
   5b358:      	orq	%rcx, %rdx
   5b35b:      	shrq	$0x20, %rdx
   5b35f:      	je	0x5b3db <f.18+0x3eb>
   5b361:      	xorl	%edx, %edx
   5b363:      	divq	%rcx
   5b366:      	testq	%rdx, %rdx
   5b369:      	jne	0x5b37d <f.18+0x38d>
   5b36b:      	movq	0x8b5e(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5b372:      	movq	%rdi, %r15
   5b375:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b37a:      	movq	%r15, %rdi
   5b37d:      	movq	0x8b4c(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5b384:      	movl	$0x18, %esi
   5b389:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b38e:      	testq	%rax, %rax
   5b391:      	je	0x5b40f <f.18+0x41f>
   5b393:      	movq	$0x46, (%rax)
   5b39a:      	movq	%rbx, 0x8(%rax)
   5b39e:      	movq	%r14, 0x10(%rax)
   5b3a2:      	cmpq	$0x0, 0x18(%rsp)
   5b3a8:      	je	0x5b3bd <f.18+0x3cd>
   5b3aa:      	movq	0x10(%rsp), %rcx
   5b3af:      	movq	%rcx, 0x8b1a(%rip)      # 0x63ed0 <native_roots.0>
   5b3b6:      	decq	0x8af3(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b3bd:      	addq	$0x60, %rsp
   5b3c1:      	popq	%rbx
   5b3c2:      	popq	%r14
   5b3c4:      	popq	%r15
   5b3c6:      	retq	$0x8
   5b3c9:      	xorl	%edx, %edx
   5b3cb:      	divl	%ecx
   5b3cd:      	testq	%rdx, %rdx
   5b3d0:      	jne	0x5b2ed <f.18+0x2fd>
   5b3d6:      	jmp	0x5b2db <f.18+0x2eb>
   5b3db:      	xorl	%edx, %edx
   5b3dd:      	divl	%ecx
   5b3df:      	testq	%rdx, %rdx
   5b3e2:      	jne	0x5b37d <f.18+0x38d>
   5b3e4:      	jmp	0x5b36b <f.18+0x37b>
   5b3e6:      	xorl	%edx, %edx
   5b3e8:      	divl	%ecx
   5b3ea:      	testq	%rdx, %rdx
   5b3ed:      	jne	0x5b19d <f.18+0x1ad>
   5b3f3:      	jmp	0x5b18b <f.18+0x19b>
   5b3f8:      	xorl	%edx, %edx
   5b3fa:      	divl	%esi
   5b3fc:      	testq	%rdx, %rdx
   5b3ff:      	jne	0x5b25d <f.18+0x26d>
   5b405:      	jmp	0x5b246 <f.18+0x256>
   5b40a:      	callq	0x55920 <native_trap>
   5b40f:      	leaq	-0x52002(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5b416:      	movl	$0x2f, %esi
   5b41b:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>

000000000005b420 <f.17>:
   5b420:      	pushq	%rbp
   5b421:      	pushq	%r15
   5b423:      	pushq	%r14
   5b425:      	pushq	%r13
   5b427:      	pushq	%r12
   5b429:      	pushq	%rbx
   5b42a:      	subq	$0x58, %rsp
   5b42e:      	movq	$0x6, 0x18(%rsp)
   5b437:      	movq	$0x0, 0x20(%rsp)
   5b440:      	movq	0x8a89(%rip), %rcx      # 0x63ed0 <native_roots.0>
   5b447:      	movq	%rcx, 0x10(%rsp)
   5b44c:      	movq	0x8a5d(%rip), %rcx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b453:      	incq	%rcx
   5b456:      	movq	%rcx, 0x8a53(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b45d:      	movq	0x8a54(%rip), %rdx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b464:      	cmpq	%rdx, %rcx
   5b467:      	cmovbeq	%rdx, %rcx
   5b46b:      	leaq	0x10(%rsp), %r13
   5b470:      	movq	%r13, 0x8a59(%rip)      # 0x63ed0 <native_roots.0>
   5b477:      	movq	%rcx, 0x8a3a(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b47e:      	movq	%rdi, 0x28(%rsp)
   5b483:      	xorps	%xmm0, %xmm0
   5b486:      	movups	%xmm0, 0x30(%rsp)
   5b48b:      	cmpb	$0x1, 0x8b26(%rip)      # 0x63fb8 <g.5>
   5b492:      	jne	0x5c170 <f.17+0xd50>
   5b498:      	movq	%rsi, %rbx
   5b49b:      	movq	%rdi, %rax
   5b49e:      	leaq	-0x507d5(%rip), %rbp    # 0xacd0 <object.1.0>
   5b4a5:      	nopw	%cs:(%rax,%rax)
   5b4b0:      	cmpq	$0x0, 0x8af8(%rip)      # 0x63fb0 <g.4>
   5b4b8:      	je	0x5c170 <f.17+0xd50>
   5b4be:      	cmpb	$0x0, 0x8b23(%rip)      # 0x63fe8 <g.11>
   5b4c5:      	je	0x5c170 <f.17+0xd50>
   5b4cb:      	cmpq	$0x0, 0x8b0d(%rip)      # 0x63fe0 <g.10>
   5b4d3:      	je	0x5c170 <f.17+0xd50>
   5b4d9:      	movq	0x10(%rax), %rax
   5b4dd:      	movq	%rax, 0x30(%rsp)
   5b4e2:      	testq	%rax, %rax
   5b4e5:      	je	0x5c170 <f.17+0xd50>
   5b4eb:      	movl	%eax, %ecx
   5b4ed:      	andl	$0x1, %ecx
   5b4f0:      	jne	0x5c170 <f.17+0xd50>
   5b4f6:      	movq	0x89cb(%rip), %rsi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b4fd:      	testq	%rsi, %rsi
   5b500:      	je	0x5c170 <f.17+0xd50>
   5b506:      	movq	(%rax), %rcx
   5b509:      	testq	%rcx, %rcx
   5b50c:      	je	0x5b580 <f.17+0x160>
   5b50e:      	cmpq	$0xaa, %rcx
   5b515:      	je	0x5b580 <f.17+0x160>
   5b517:      	movq	0x168(%rsi), %rdx
   5b51e:      	shrq	$0x2, %rcx
   5b522:      	leaq	-0x1(%rcx), %rdi
   5b526:      	cmpq	%rdx, %rdi
   5b529:      	jae	0x5c170 <f.17+0xd50>
   5b52f:      	movq	0x160(%rsi), %rsi
   5b536:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b53b:      	testq	%rcx, %rcx
   5b53e:      	je	0x5b580 <f.17+0x160>
   5b540:      	cmpq	$0xaa, %rcx
   5b547:      	je	0x5b580 <f.17+0x160>
   5b549:      	nopl	(%rax)
   5b550:      	shrq	$0x2, %rcx
   5b554:      	leaq	-0x1(%rcx), %rdi
   5b558:      	cmpq	%rdx, %rdi
   5b55b:      	jae	0x5c170 <f.17+0xd50>
   5b561:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b566:      	cmpq	$0xaa, %rcx
   5b56d:      	je	0x5b580 <f.17+0x160>
   5b56f:      	testq	%rcx, %rcx
   5b572:      	jne	0x5b550 <f.17+0x130>
   5b574:      	nopw	%cs:(%rax,%rax)
   5b580:      	cmpq	$0xaa, %rcx
   5b587:      	je	0x5c170 <f.17+0xd50>
   5b58d:      	movq	0x8934(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b594:      	testq	%rdi, %rdi
   5b597:      	je	0x5c170 <f.17+0xd50>
   5b59d:      	movq	(%rax), %rcx
   5b5a0:      	testq	%rcx, %rcx
   5b5a3:      	je	0x5b610 <f.17+0x1f0>
   5b5a5:      	cmpq	$0x46, %rcx
   5b5a9:      	je	0x5b610 <f.17+0x1f0>
   5b5ab:      	movq	0x168(%rdi), %rdx
   5b5b2:      	shrq	$0x2, %rcx
   5b5b6:      	leaq	-0x1(%rcx), %rsi
   5b5ba:      	cmpq	%rdx, %rsi
   5b5bd:      	jae	0x5c170 <f.17+0xd50>
   5b5c3:      	movq	0x160(%rdi), %rsi
   5b5ca:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b5cf:      	testq	%rcx, %rcx
   5b5d2:      	je	0x5b610 <f.17+0x1f0>
   5b5d4:      	cmpq	$0x46, %rcx
   5b5d8:      	je	0x5b610 <f.17+0x1f0>
   5b5da:      	nopw	(%rax,%rax)
   5b5e0:      	shrq	$0x2, %rcx
   5b5e4:      	leaq	-0x1(%rcx), %r8
   5b5e8:      	cmpq	%rdx, %r8
   5b5eb:      	jae	0x5c170 <f.17+0xd50>
   5b5f1:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b5f6:      	cmpq	$0x46, %rcx
   5b5fa:      	je	0x5b610 <f.17+0x1f0>
   5b5fc:      	testq	%rcx, %rcx
   5b5ff:      	jne	0x5b5e0 <f.17+0x1c0>
   5b601:      	nopw	%cs:(%rax,%rax)
   5b610:      	cmpq	$0x46, %rcx
   5b614:      	jne	0x5c170 <f.17+0xd50>
   5b61a:      	movq	0x8(%rax), %r14
   5b61e:      	movq	%rbp, 0x40(%rsp)
   5b623:      	movq	%r14, 0x48(%rsp)
   5b628:      	movq	$0x5, 0x20(%rsp)
   5b631:      	movq	0x178(%rdi), %rcx
   5b638:      	movq	%r13, %rdx
   5b63b:      	testq	%rcx, %rcx
   5b63e:      	je	0x5b686 <f.17+0x266>
   5b640:      	movq	0x170(%rdi), %rax
   5b647:      	incq	%rax
   5b64a:      	movq	%rax, 0x170(%rdi)
   5b651:      	movq	%rax, %rdx
   5b654:      	orq	%rcx, %rdx
   5b657:      	shrq	$0x20, %rdx
   5b65b:      	je	0x5c060 <f.17+0xc40>
   5b661:      	xorl	%edx, %edx
   5b663:      	divq	%rcx
   5b666:      	movq	%rdx, %rax
   5b669:      	movq	%r13, %rdx
   5b66c:      	testq	%rax, %rax
   5b66f:      	jne	0x5b686 <f.17+0x266>
   5b671:      	movq	%rdi, %r15
   5b674:      	movq	%r13, %rsi
   5b677:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b67c:      	movq	%r15, %rdi
   5b67f:      	movq	0x884a(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5b686:      	movl	$0x10, %esi
   5b68b:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b690:      	testq	%rax, %rax
   5b693:      	je	0x5c175 <f.17+0xd55>
   5b699:      	movq	%rax, %r15
   5b69c:      	movq	$0x36, (%rax)
   5b6a3:      	movq	%rbp, 0x8(%rax)
   5b6a7:      	movq	%rbp, 0x40(%rsp)
   5b6ac:      	movq	%rax, 0x48(%rsp)
   5b6b1:      	movq	%r14, 0x50(%rsp)
   5b6b6:      	movq	$0x6, 0x20(%rsp)
   5b6bf:      	movq	0x8802(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b6c6:      	testq	%rdi, %rdi
   5b6c9:      	je	0x5c170 <f.17+0xd50>
   5b6cf:      	movq	0x178(%rdi), %rcx
   5b6d6:      	testq	%rcx, %rcx
   5b6d9:      	je	0x5b718 <f.17+0x2f8>
   5b6db:      	movq	0x170(%rdi), %rax
   5b6e2:      	incq	%rax
   5b6e5:      	movq	%rax, 0x170(%rdi)
   5b6ec:      	movq	%rax, %rdx
   5b6ef:      	orq	%rcx, %rdx
   5b6f2:      	shrq	$0x20, %rdx
   5b6f6:      	je	0x5c080 <f.17+0xc60>
   5b6fc:      	xorl	%edx, %edx
   5b6fe:      	divq	%rcx
   5b701:      	testq	%rdx, %rdx
   5b704:      	jne	0x5b718 <f.17+0x2f8>
   5b706:      	movq	0x87c3(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5b70d:      	movq	%rdi, %r12
   5b710:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b715:      	movq	%r12, %rdi
   5b718:      	movq	0x87b1(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5b71f:      	movl	$0x10, %esi
   5b724:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b729:      	testq	%rax, %rax
   5b72c:      	je	0x5c175 <f.17+0xd55>
   5b732:      	movq	%rax, %r12
   5b735:      	movq	$0x36, (%rax)
   5b73c:      	movq	%rbp, 0x8(%rax)
   5b740:      	movq	%rax, 0x40(%rsp)
   5b745:      	movq	%r15, 0x48(%rsp)
   5b74a:      	movq	%r14, 0x50(%rsp)
   5b74f:      	movq	$0x6, 0x20(%rsp)
   5b758:      	movq	0x8769(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b75f:      	testq	%rdi, %rdi
   5b762:      	je	0x5c170 <f.17+0xd50>
   5b768:      	movq	0x178(%rdi), %rcx
   5b76f:      	testq	%rcx, %rcx
   5b772:      	je	0x5b7b6 <f.17+0x396>
   5b774:      	movq	0x170(%rdi), %rax
   5b77b:      	incq	%rax
   5b77e:      	movq	%rax, 0x170(%rdi)
   5b785:      	movq	%rax, %rdx
   5b788:      	orq	%rcx, %rdx
   5b78b:      	shrq	$0x20, %rdx
   5b78f:      	je	0x5c0a0 <f.17+0xc80>
   5b795:      	xorl	%edx, %edx
   5b797:      	divq	%rcx
   5b79a:      	testq	%rdx, %rdx
   5b79d:      	jne	0x5b7b6 <f.17+0x396>
   5b79f:      	movq	0x872a(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5b7a6:      	movq	%rdi, %r13
   5b7a9:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b7ae:      	movq	%r13, %rdi
   5b7b1:      	leaq	0x10(%rsp), %r13
   5b7b6:      	movq	0x8713(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5b7bd:      	movl	$0x18, %esi
   5b7c2:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b7c7:      	testq	%rax, %rax
   5b7ca:      	je	0x5c175 <f.17+0xd55>
   5b7d0:      	movq	$0x46, (%rax)
   5b7d7:      	movq	%r15, 0x8(%rax)
   5b7db:      	movq	%r12, 0x10(%rax)
   5b7df:      	testq	%r14, %r14
   5b7e2:      	je	0x5c170 <f.17+0xd50>
   5b7e8:      	movq	%rax, 0x8(%r14)
   5b7ec:      	cmpb	$0x0, 0x87c5(%rip)      # 0x63fb8 <g.5>
   5b7f3:      	je	0x5c170 <f.17+0xd50>
   5b7f9:      	cmpq	$0x0, 0x87af(%rip)      # 0x63fb0 <g.4>
   5b801:      	je	0x5c170 <f.17+0xd50>
   5b807:      	cmpb	$0x0, 0x87ea(%rip)      # 0x63ff8 <g.13>
   5b80e:      	je	0x5c170 <f.17+0xd50>
   5b814:      	cmpq	$0x0, 0x87d4(%rip)      # 0x63ff0 <g.12>
   5b81c:      	je	0x5c170 <f.17+0xd50>
   5b822:      	movq	0x28(%rsp), %rax
   5b827:      	testq	%rax, %rax
   5b82a:      	je	0x5c170 <f.17+0xd50>
   5b830:      	movq	0x10(%rax), %rax
   5b834:      	movq	%rax, 0x30(%rsp)
   5b839:      	testq	%rax, %rax
   5b83c:      	je	0x5c170 <f.17+0xd50>
   5b842:      	movl	%eax, %ecx
   5b844:      	andl	$0x1, %ecx
   5b847:      	jne	0x5c170 <f.17+0xd50>
   5b84d:      	movq	0x8674(%rip), %rsi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b854:      	testq	%rsi, %rsi
   5b857:      	je	0x5c170 <f.17+0xd50>
   5b85d:      	movq	(%rax), %rcx
   5b860:      	testq	%rcx, %rcx
   5b863:      	je	0x5b8d0 <f.17+0x4b0>
   5b865:      	cmpq	$0xaa, %rcx
   5b86c:      	je	0x5b8d0 <f.17+0x4b0>
   5b86e:      	movq	0x168(%rsi), %rdx
   5b875:      	shrq	$0x2, %rcx
   5b879:      	leaq	-0x1(%rcx), %rdi
   5b87d:      	cmpq	%rdx, %rdi
   5b880:      	jae	0x5c170 <f.17+0xd50>
   5b886:      	movq	0x160(%rsi), %rsi
   5b88d:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b892:      	testq	%rcx, %rcx
   5b895:      	je	0x5b8d0 <f.17+0x4b0>
   5b897:      	cmpq	$0xaa, %rcx
   5b89e:      	je	0x5b8d0 <f.17+0x4b0>
   5b8a0:      	shrq	$0x2, %rcx
   5b8a4:      	leaq	-0x1(%rcx), %rdi
   5b8a8:      	cmpq	%rdx, %rdi
   5b8ab:      	jae	0x5c170 <f.17+0xd50>
   5b8b1:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b8b6:      	cmpq	$0xaa, %rcx
   5b8bd:      	je	0x5b8d0 <f.17+0x4b0>
   5b8bf:      	testq	%rcx, %rcx
   5b8c2:      	jne	0x5b8a0 <f.17+0x480>
   5b8c4:      	nopw	%cs:(%rax,%rax)
   5b8d0:      	cmpq	$0xaa, %rcx
   5b8d7:      	je	0x5c170 <f.17+0xd50>
   5b8dd:      	movq	0x85e4(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b8e4:      	testq	%rdi, %rdi
   5b8e7:      	je	0x5c170 <f.17+0xd50>
   5b8ed:      	movq	(%rax), %rcx
   5b8f0:      	testq	%rcx, %rcx
   5b8f3:      	je	0x5b960 <f.17+0x540>
   5b8f5:      	cmpq	$0x46, %rcx
   5b8f9:      	je	0x5b960 <f.17+0x540>
   5b8fb:      	movq	0x168(%rdi), %rdx
   5b902:      	shrq	$0x2, %rcx
   5b906:      	leaq	-0x1(%rcx), %rsi
   5b90a:      	cmpq	%rdx, %rsi
   5b90d:      	jae	0x5c170 <f.17+0xd50>
   5b913:      	movq	0x160(%rdi), %rsi
   5b91a:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b91f:      	testq	%rcx, %rcx
   5b922:      	je	0x5b960 <f.17+0x540>
   5b924:      	cmpq	$0x46, %rcx
   5b928:      	je	0x5b960 <f.17+0x540>
   5b92a:      	nopw	(%rax,%rax)
   5b930:      	shrq	$0x2, %rcx
   5b934:      	leaq	-0x1(%rcx), %r8
   5b938:      	cmpq	%rdx, %r8
   5b93b:      	jae	0x5c170 <f.17+0xd50>
   5b941:      	movq	-0x8(%rsi,%rcx,8), %rcx
   5b946:      	cmpq	$0x46, %rcx
   5b94a:      	je	0x5b960 <f.17+0x540>
   5b94c:      	testq	%rcx, %rcx
   5b94f:      	jne	0x5b930 <f.17+0x510>
   5b951:      	nopw	%cs:(%rax,%rax)
   5b960:      	cmpq	$0x46, %rcx
   5b964:      	jne	0x5c170 <f.17+0xd50>
   5b96a:      	movq	0x10(%rax), %r14
   5b96e:      	movq	%rbp, 0x40(%rsp)
   5b973:      	movq	%r14, 0x48(%rsp)
   5b978:      	movq	$0x5, 0x20(%rsp)
   5b981:      	movq	0x178(%rdi), %rcx
   5b988:      	testq	%rcx, %rcx
   5b98b:      	je	0x5b9ca <f.17+0x5aa>
   5b98d:      	movq	0x170(%rdi), %rax
   5b994:      	incq	%rax
   5b997:      	movq	%rax, 0x170(%rdi)
   5b99e:      	movq	%rax, %rdx
   5b9a1:      	orq	%rcx, %rdx
   5b9a4:      	shrq	$0x20, %rdx
   5b9a8:      	je	0x5c0c0 <f.17+0xca0>
   5b9ae:      	xorl	%edx, %edx
   5b9b0:      	divq	%rcx
   5b9b3:      	testq	%rdx, %rdx
   5b9b6:      	jne	0x5b9ca <f.17+0x5aa>
   5b9b8:      	movq	0x8511(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5b9bf:      	movq	%rdi, %r15
   5b9c2:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b9c7:      	movq	%r15, %rdi
   5b9ca:      	movq	0x84ff(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5b9d1:      	movl	$0x10, %esi
   5b9d6:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b9db:      	testq	%rax, %rax
   5b9de:      	je	0x5c175 <f.17+0xd55>
   5b9e4:      	movq	%rax, %r15
   5b9e7:      	movq	$0x36, (%rax)
   5b9ee:      	movq	%rbp, 0x8(%rax)
   5b9f2:      	movq	%rbp, 0x40(%rsp)
   5b9f7:      	movq	%rax, 0x48(%rsp)
   5b9fc:      	movq	%r14, 0x50(%rsp)
   5ba01:      	movq	$0x6, 0x20(%rsp)
   5ba0a:      	movq	0x84b7(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5ba11:      	testq	%rdi, %rdi
   5ba14:      	je	0x5c170 <f.17+0xd50>
   5ba1a:      	movq	0x178(%rdi), %rcx
   5ba21:      	testq	%rcx, %rcx
   5ba24:      	je	0x5ba63 <f.17+0x643>
   5ba26:      	movq	0x170(%rdi), %rax
   5ba2d:      	incq	%rax
   5ba30:      	movq	%rax, 0x170(%rdi)
   5ba37:      	movq	%rax, %rdx
   5ba3a:      	orq	%rcx, %rdx
   5ba3d:      	shrq	$0x20, %rdx
   5ba41:      	je	0x5c0e0 <f.17+0xcc0>
   5ba47:      	xorl	%edx, %edx
   5ba49:      	divq	%rcx
   5ba4c:      	testq	%rdx, %rdx
   5ba4f:      	jne	0x5ba63 <f.17+0x643>
   5ba51:      	movq	0x8478(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5ba58:      	movq	%rdi, %r12
   5ba5b:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5ba60:      	movq	%r12, %rdi
   5ba63:      	movq	0x8466(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5ba6a:      	movl	$0x10, %esi
   5ba6f:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5ba74:      	testq	%rax, %rax
   5ba77:      	je	0x5c175 <f.17+0xd55>
   5ba7d:      	movq	%rax, %r12
   5ba80:      	movq	$0x36, (%rax)
   5ba87:      	movq	%rbp, 0x8(%rax)
   5ba8b:      	movq	%rax, 0x40(%rsp)
   5ba90:      	movq	%r15, 0x48(%rsp)
   5ba95:      	movq	%r14, 0x50(%rsp)
   5ba9a:      	movq	$0x6, 0x20(%rsp)
   5baa3:      	movq	0x841e(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5baaa:      	testq	%rdi, %rdi
   5baad:      	je	0x5c170 <f.17+0xd50>
   5bab3:      	movq	0x178(%rdi), %rcx
   5baba:      	testq	%rcx, %rcx
   5babd:      	je	0x5bb01 <f.17+0x6e1>
   5babf:      	movq	0x170(%rdi), %rax
   5bac6:      	incq	%rax
   5bac9:      	movq	%rax, 0x170(%rdi)
   5bad0:      	movq	%rax, %rdx
   5bad3:      	orq	%rcx, %rdx
   5bad6:      	shrq	$0x20, %rdx
   5bada:      	je	0x5c100 <f.17+0xce0>
   5bae0:      	xorl	%edx, %edx
   5bae2:      	divq	%rcx
   5bae5:      	testq	%rdx, %rdx
   5bae8:      	jne	0x5bb01 <f.17+0x6e1>
   5baea:      	movq	0x83df(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5baf1:      	movq	%rdi, %r13
   5baf4:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5baf9:      	movq	%r13, %rdi
   5bafc:      	leaq	0x10(%rsp), %r13
   5bb01:      	movq	0x83c8(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5bb08:      	movl	$0x18, %esi
   5bb0d:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5bb12:      	testq	%rax, %rax
   5bb15:      	je	0x5c175 <f.17+0xd55>
   5bb1b:      	movq	$0x46, (%rax)
   5bb22:      	movq	%r15, 0x8(%rax)
   5bb26:      	movq	%r12, 0x10(%rax)
   5bb2a:      	testq	%r14, %r14
   5bb2d:      	je	0x5c170 <f.17+0xd50>
   5bb33:      	movq	%rax, 0x8(%r14)
   5bb37:      	cmpb	$0x0, 0x848a(%rip)      # 0x63fc8 <g.7>
   5bb3e:      	je	0x5c170 <f.17+0xd50>
   5bb44:      	cmpq	$0x0, 0x8474(%rip)      # 0x63fc0 <g.6>
   5bb4c:      	je	0x5c170 <f.17+0xd50>
   5bb52:      	movq	0x28(%rsp), %rax
   5bb57:      	testq	%rax, %rax
   5bb5a:      	je	0x5c170 <f.17+0xd50>
   5bb60:      	movq	0x10(%rax), %rcx
   5bb64:      	movq	%rcx, 0x30(%rsp)
   5bb69:      	testq	%rcx, %rcx
   5bb6c:      	je	0x5c170 <f.17+0xd50>
   5bb72:      	movl	%ecx, %edx
   5bb74:      	andl	$0x1, %edx
   5bb77:      	jne	0x5c170 <f.17+0xd50>
   5bb7d:      	movq	0x8344(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5bb84:      	testq	%rdi, %rdi
   5bb87:      	je	0x5c170 <f.17+0xd50>
   5bb8d:      	movq	(%rcx), %rdx
   5bb90:      	testq	%rdx, %rdx
   5bb93:      	je	0x5bc00 <f.17+0x7e0>
   5bb95:      	cmpq	$0xaa, %rdx
   5bb9c:      	je	0x5bc00 <f.17+0x7e0>
   5bb9e:      	movq	0x168(%rdi), %rsi
   5bba5:      	shrq	$0x2, %rdx
   5bba9:      	leaq	-0x1(%rdx), %r8
   5bbad:      	cmpq	%rsi, %r8
   5bbb0:      	jae	0x5c170 <f.17+0xd50>
   5bbb6:      	movq	0x160(%rdi), %rdi
   5bbbd:      	movq	-0x8(%rdi,%rdx,8), %rdx
   5bbc2:      	testq	%rdx, %rdx
   5bbc5:      	je	0x5bc00 <f.17+0x7e0>
   5bbc7:      	cmpq	$0xaa, %rdx
   5bbce:      	je	0x5bc00 <f.17+0x7e0>
   5bbd0:      	shrq	$0x2, %rdx
   5bbd4:      	leaq	-0x1(%rdx), %r8
   5bbd8:      	cmpq	%rsi, %r8
   5bbdb:      	jae	0x5c170 <f.17+0xd50>
   5bbe1:      	movq	-0x8(%rdi,%rdx,8), %rdx
   5bbe6:      	cmpq	$0xaa, %rdx
   5bbed:      	je	0x5bc00 <f.17+0x7e0>
   5bbef:      	testq	%rdx, %rdx
   5bbf2:      	jne	0x5bbd0 <f.17+0x7b0>
   5bbf4:      	nopw	%cs:(%rax,%rax)
   5bc00:      	cmpq	$0xaa, %rdx
   5bc07:      	je	0x5c170 <f.17+0xd50>
   5bc0d:      	movq	0x82b4(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5bc14:      	testq	%rdi, %rdi
   5bc17:      	je	0x5c170 <f.17+0xd50>
   5bc1d:      	movq	(%rcx), %rdx
   5bc20:      	testq	%rdx, %rdx
   5bc23:      	je	0x5bc90 <f.17+0x870>
   5bc25:      	cmpq	$0x46, %rdx
   5bc29:      	je	0x5bc90 <f.17+0x870>
   5bc2b:      	movq	0x168(%rdi), %rsi
   5bc32:      	shrq	$0x2, %rdx
   5bc36:      	leaq	-0x1(%rdx), %r8
   5bc3a:      	cmpq	%rsi, %r8
   5bc3d:      	jae	0x5c170 <f.17+0xd50>
   5bc43:      	movq	0x160(%rdi), %r8
   5bc4a:      	movq	-0x8(%r8,%rdx,8), %rdx
   5bc4f:      	testq	%rdx, %rdx
   5bc52:      	je	0x5bc90 <f.17+0x870>
   5bc54:      	cmpq	$0x46, %rdx
   5bc58:      	je	0x5bc90 <f.17+0x870>
   5bc5a:      	nopw	(%rax,%rax)
   5bc60:      	shrq	$0x2, %rdx
   5bc64:      	leaq	-0x1(%rdx), %r9
   5bc68:      	cmpq	%rsi, %r9
   5bc6b:      	jae	0x5c170 <f.17+0xd50>
   5bc71:      	movq	-0x8(%r8,%rdx,8), %rdx
   5bc76:      	cmpq	$0x46, %rdx
   5bc7a:      	je	0x5bc90 <f.17+0x870>
   5bc7c:      	testq	%rdx, %rdx
   5bc7f:      	jne	0x5bc60 <f.17+0x840>
   5bc81:      	nopw	%cs:(%rax,%rax)
   5bc90:      	cmpq	$0x46, %rdx
   5bc94:      	jne	0x5c170 <f.17+0xd50>
   5bc9a:      	movq	0x8(%rcx), %rcx
   5bc9e:      	testq	%rcx, %rcx
   5bca1:      	je	0x5c170 <f.17+0xd50>
   5bca7:      	movq	0x8(%rcx), %r14
   5bcab:      	movq	%r14, 0x30(%rsp)
   5bcb0:      	movq	0x8(%rax), %rax
   5bcb4:      	testq	%rax, %rax
   5bcb7:      	je	0x5c170 <f.17+0xd50>
   5bcbd:      	cmpl	$0x0, 0x8(%rax)
   5bcc1:      	je	0x5c170 <f.17+0xd50>
   5bcc7:      	movq	0x10(%rax), %rax
   5bccb:      	testq	%rax, %rax
   5bcce:      	je	0x5c170 <f.17+0xd50>
   5bcd4:      	movq	0x8(%rax), %rax
   5bcd8:      	movq	%rax, 0x38(%rsp)
   5bcdd:      	testq	%rbx, %rbx
   5bce0:      	jle	0x5bd96 <f.17+0x976>
   5bce6:      	testq	%rax, %rax
   5bce9:      	je	0x5c170 <f.17+0xd50>
   5bcef:      	movq	0x8(%rax), %r12
   5bcf3:      	movq	%r14, 0x40(%rsp)
   5bcf8:      	movq	%r12, 0x48(%rsp)
   5bcfd:      	movq	$0x5, 0x20(%rsp)
   5bd06:      	movq	0x178(%rdi), %rcx
   5bd0d:      	testq	%rcx, %rcx
   5bd10:      	je	0x5bd4f <f.17+0x92f>
   5bd12:      	movq	0x170(%rdi), %rax
   5bd19:      	incq	%rax
   5bd1c:      	movq	%rax, 0x170(%rdi)
   5bd23:      	movq	%rax, %rdx
   5bd26:      	orq	%rcx, %rdx
   5bd29:      	shrq	$0x20, %rdx
   5bd2d:      	je	0x5c132 <f.17+0xd12>
   5bd33:      	xorl	%edx, %edx
   5bd35:      	divq	%rcx
   5bd38:      	testq	%rdx, %rdx
   5bd3b:      	jne	0x5bd4f <f.17+0x92f>
   5bd3d:      	movq	0x818c(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5bd44:      	movq	%rdi, %r15
   5bd47:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5bd4c:      	movq	%r15, %rdi
   5bd4f:      	movq	0x817a(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5bd56:      	movl	$0x18, %esi
   5bd5b:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5bd60:      	testq	%rax, %rax
   5bd63:      	je	0x5c175 <f.17+0xd55>
   5bd69:      	movq	$0x32, (%rax)
   5bd70:      	movq	%r12, 0x8(%rax)
   5bd74:      	movq	%r14, 0x10(%rax)
   5bd78:      	leaq	-0x1(%rbx), %rsi
   5bd7c:      	movq	%rax, 0x40(%rsp)
   5bd81:      	movq	$0x4, 0x20(%rsp)
   5bd8a:      	movq	%rax, %rdi
   5bd8d:      	callq	0x5b420 <f.17>
   5bd92:      	subq	$0x8, %rsp
   5bd96:      	cmpb	$0x0, 0x823b(%rip)      # 0x63fd8 <g.9>
   5bd9d:      	je	0x5c170 <f.17+0xd50>
   5bda3:      	cmpq	$0x0, 0x8225(%rip)      # 0x63fd0 <g.8>
   5bdab:      	je	0x5c170 <f.17+0xd50>
   5bdb1:      	movq	0x28(%rsp), %rax
   5bdb6:      	testq	%rax, %rax
   5bdb9:      	je	0x5c170 <f.17+0xd50>
   5bdbf:      	movq	0x10(%rax), %rcx
   5bdc3:      	movq	%rcx, 0x30(%rsp)
   5bdc8:      	testq	%rcx, %rcx
   5bdcb:      	je	0x5c170 <f.17+0xd50>
   5bdd1:      	movl	%ecx, %edx
   5bdd3:      	andl	$0x1, %edx
   5bdd6:      	jne	0x5c170 <f.17+0xd50>
   5bddc:      	movq	0x80e5(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5bde3:      	testq	%rdi, %rdi
   5bde6:      	je	0x5c170 <f.17+0xd50>
   5bdec:      	movq	(%rcx), %rdx
   5bdef:      	testq	%rdx, %rdx
   5bdf2:      	je	0x5be60 <f.17+0xa40>
   5bdf4:      	cmpq	$0xaa, %rdx
   5bdfb:      	je	0x5be60 <f.17+0xa40>
   5bdfd:      	movq	0x168(%rdi), %rsi
   5be04:      	shrq	$0x2, %rdx
   5be08:      	leaq	-0x1(%rdx), %r8
   5be0c:      	cmpq	%rsi, %r8
   5be0f:      	jae	0x5c170 <f.17+0xd50>
   5be15:      	movq	0x160(%rdi), %rdi
   5be1c:      	movq	-0x8(%rdi,%rdx,8), %rdx
   5be21:      	testq	%rdx, %rdx
   5be24:      	je	0x5be60 <f.17+0xa40>
   5be26:      	cmpq	$0xaa, %rdx
   5be2d:      	je	0x5be60 <f.17+0xa40>
   5be2f:      	nop
   5be30:      	shrq	$0x2, %rdx
   5be34:      	leaq	-0x1(%rdx), %r8
   5be38:      	cmpq	%rsi, %r8
   5be3b:      	jae	0x5c170 <f.17+0xd50>
   5be41:      	movq	-0x8(%rdi,%rdx,8), %rdx
   5be46:      	cmpq	$0xaa, %rdx
   5be4d:      	je	0x5be60 <f.17+0xa40>
   5be4f:      	testq	%rdx, %rdx
   5be52:      	jne	0x5be30 <f.17+0xa10>
   5be54:      	nopw	%cs:(%rax,%rax)
   5be60:      	cmpq	$0xaa, %rdx
   5be67:      	je	0x5c170 <f.17+0xd50>
   5be6d:      	movq	0x8054(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5be74:      	testq	%rdi, %rdi
   5be77:      	je	0x5c170 <f.17+0xd50>
   5be7d:      	movq	(%rcx), %rdx
   5be80:      	testq	%rdx, %rdx
   5be83:      	je	0x5bef0 <f.17+0xad0>
   5be85:      	cmpq	$0x46, %rdx
   5be89:      	je	0x5bef0 <f.17+0xad0>
   5be8b:      	movq	0x168(%rdi), %rsi
   5be92:      	shrq	$0x2, %rdx
   5be96:      	leaq	-0x1(%rdx), %r8
   5be9a:      	cmpq	%rsi, %r8
   5be9d:      	jae	0x5c170 <f.17+0xd50>
   5bea3:      	movq	0x160(%rdi), %r8
   5beaa:      	movq	-0x8(%r8,%rdx,8), %rdx
   5beaf:      	testq	%rdx, %rdx
   5beb2:      	je	0x5bef0 <f.17+0xad0>
   5beb4:      	cmpq	$0x46, %rdx
   5beb8:      	je	0x5bef0 <f.17+0xad0>
   5beba:      	nopw	(%rax,%rax)
   5bec0:      	shrq	$0x2, %rdx
   5bec4:      	leaq	-0x1(%rdx), %r9
   5bec8:      	cmpq	%rsi, %r9
   5becb:      	jae	0x5c170 <f.17+0xd50>
   5bed1:      	movq	-0x8(%r8,%rdx,8), %rdx
   5bed6:      	cmpq	$0x46, %rdx
   5beda:      	je	0x5bef0 <f.17+0xad0>
   5bedc:      	testq	%rdx, %rdx
   5bedf:      	jne	0x5bec0 <f.17+0xaa0>
   5bee1:      	nopw	%cs:(%rax,%rax)
   5bef0:      	cmpq	$0x46, %rdx
   5bef4:      	jne	0x5c170 <f.17+0xd50>
   5befa:      	movq	0x10(%rcx), %rcx
   5befe:      	testq	%rcx, %rcx
   5bf01:      	je	0x5c170 <f.17+0xd50>
   5bf07:      	movq	0x8(%rcx), %r14
   5bf0b:      	movq	%r14, 0x30(%rsp)
   5bf10:      	movq	0x8(%rax), %rax
   5bf14:      	testq	%rax, %rax
   5bf17:      	je	0x5c170 <f.17+0xd50>
   5bf1d:      	cmpl	$0x0, 0x8(%rax)
   5bf21:      	je	0x5c170 <f.17+0xd50>
   5bf27:      	movq	0x10(%rax), %rax
   5bf2b:      	testq	%rax, %rax
   5bf2e:      	je	0x5c170 <f.17+0xd50>
   5bf34:      	movq	0x8(%rax), %rax
   5bf38:      	movq	%rax, 0x38(%rsp)
   5bf3d:      	testq	%rbx, %rbx
   5bf40:      	jle	0x5c144 <f.17+0xd24>
   5bf46:      	testq	%rax, %rax
   5bf49:      	je	0x5c170 <f.17+0xd50>
   5bf4f:      	movq	0x8(%rax), %r12
   5bf53:      	movq	%r14, 0x40(%rsp)
   5bf58:      	movq	%r12, 0x48(%rsp)
   5bf5d:      	movq	$0x5, 0x20(%rsp)
   5bf66:      	movq	0x178(%rdi), %rcx
   5bf6d:      	testq	%rcx, %rcx
   5bf70:      	je	0x5bfaf <f.17+0xb8f>
   5bf72:      	movq	0x170(%rdi), %rax
   5bf79:      	incq	%rax
   5bf7c:      	movq	%rax, 0x170(%rdi)
   5bf83:      	movq	%rax, %rdx
   5bf86:      	orq	%rcx, %rdx
   5bf89:      	shrq	$0x20, %rdx
   5bf8d:      	je	0x5c120 <f.17+0xd00>
   5bf93:      	xorl	%edx, %edx
   5bf95:      	divq	%rcx
   5bf98:      	testq	%rdx, %rdx
   5bf9b:      	jne	0x5bfaf <f.17+0xb8f>
   5bf9d:      	movq	0x7f2c(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5bfa4:      	movq	%rdi, %r15
   5bfa7:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5bfac:      	movq	%r15, %rdi
   5bfaf:      	movq	0x7f1a(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5bfb6:      	movl	$0x18, %esi
   5bfbb:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5bfc0:      	testq	%rax, %rax
   5bfc3:      	je	0x5c175 <f.17+0xd55>
   5bfc9:      	movq	$0x32, (%rax)
   5bfd0:      	movq	%r12, 0x8(%rax)
   5bfd4:      	movq	%r14, 0x10(%rax)
   5bfd8:      	decq	%rbx
   5bfdb:      	xorl	%ecx, %ecx
   5bfdd:      	cmpq	$0x0, 0x18(%rsp)
   5bfe3:      	sete	%cl
   5bfe6:      	movq	%r13, %rdx
   5bfe9:      	leaq	0x7ee0(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5bff0:      	cmoveq	%rsi, %rdx
   5bff4:      	addq	0x7eb5(%rip), %rcx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5bffb:      	movq	(%rdx), %rdx
   5bffe:      	movq	$0x6, 0x18(%rsp)
   5c007:      	movq	$0x0, 0x20(%rsp)
   5c010:      	movq	%rdx, 0x10(%rsp)
   5c015:      	movq	%r13, 0x7eb4(%rip)      # 0x63ed0 <native_roots.0>
   5c01c:      	movq	%rcx, 0x7e8d(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c023:      	movq	0x7e8e(%rip), %rdx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c02a:      	cmpq	%rdx, %rcx
   5c02d:      	cmovbeq	%rdx, %rcx
   5c031:      	movq	%rcx, 0x7e80(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c038:      	movq	%rax, 0x28(%rsp)
   5c03d:      	xorps	%xmm0, %xmm0
   5c040:      	leaq	0x30(%rsp), %rcx
   5c045:      	movups	%xmm0, (%rcx)
   5c048:      	cmpb	$0x0, 0x7f69(%rip)      # 0x63fb8 <g.5>
   5c04f:      	jne	0x5b4b0 <f.17+0x90>
   5c055:      	jmp	0x5c170 <f.17+0xd50>
   5c05a:      	nopw	(%rax,%rax)
   5c060:      	xorl	%edx, %edx
   5c062:      	divl	%ecx
   5c064:      	movl	%edx, %eax
   5c066:      	movq	%r13, %rdx
   5c069:      	testq	%rax, %rax
   5c06c:      	jne	0x5b686 <f.17+0x266>
   5c072:      	jmp	0x5b671 <f.17+0x251>
   5c077:      	nopw	(%rax,%rax)
   5c080:      	xorl	%edx, %edx
   5c082:      	divl	%ecx
   5c084:      	testq	%rdx, %rdx
   5c087:      	jne	0x5b718 <f.17+0x2f8>
   5c08d:      	jmp	0x5b706 <f.17+0x2e6>
   5c092:      	nopw	%cs:(%rax,%rax)
   5c0a0:      	xorl	%edx, %edx
   5c0a2:      	divl	%ecx
   5c0a4:      	testq	%rdx, %rdx
   5c0a7:      	jne	0x5b7b6 <f.17+0x396>
   5c0ad:      	jmp	0x5b79f <f.17+0x37f>
   5c0b2:      	nopw	%cs:(%rax,%rax)
   5c0c0:      	xorl	%edx, %edx
   5c0c2:      	divl	%ecx
   5c0c4:      	testq	%rdx, %rdx
   5c0c7:      	jne	0x5b9ca <f.17+0x5aa>
   5c0cd:      	jmp	0x5b9b8 <f.17+0x598>
   5c0d2:      	nopw	%cs:(%rax,%rax)
   5c0e0:      	xorl	%edx, %edx
   5c0e2:      	divl	%ecx
   5c0e4:      	testq	%rdx, %rdx
   5c0e7:      	jne	0x5ba63 <f.17+0x643>
   5c0ed:      	jmp	0x5ba51 <f.17+0x631>
   5c0f2:      	nopw	%cs:(%rax,%rax)
   5c100:      	xorl	%edx, %edx
   5c102:      	divl	%ecx
   5c104:      	testq	%rdx, %rdx
   5c107:      	jne	0x5bb01 <f.17+0x6e1>
   5c10d:      	jmp	0x5baea <f.17+0x6ca>
   5c112:      	nopw	%cs:(%rax,%rax)
   5c120:      	xorl	%edx, %edx
   5c122:      	divl	%ecx
   5c124:      	testq	%rdx, %rdx
   5c127:      	jne	0x5bfaf <f.17+0xb8f>
   5c12d:      	jmp	0x5bf9d <f.17+0xb7d>
   5c132:      	xorl	%edx, %edx
   5c134:      	divl	%ecx
   5c136:      	testq	%rdx, %rdx
   5c139:      	jne	0x5bd4f <f.17+0x92f>
   5c13f:      	jmp	0x5bd3d <f.17+0x91d>
   5c144:      	cmpq	$0x0, 0x18(%rsp)
   5c14a:      	je	0x5c15f <f.17+0xd3f>
   5c14c:      	movq	0x10(%rsp), %rax
   5c151:      	movq	%rax, 0x7d78(%rip)      # 0x63ed0 <native_roots.0>
   5c158:      	decq	0x7d51(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c15f:      	addq	$0x58, %rsp
   5c163:      	popq	%rbx
   5c164:      	popq	%r12
   5c166:      	popq	%r13
   5c168:      	popq	%r14
   5c16a:      	popq	%r15
   5c16c:      	popq	%rbp
   5c16d:      	retq	$0x8
   5c170:      	callq	0x55920 <native_trap>
   5c175:      	leaq	-0x52d68(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5c17c:      	movl	$0x2f, %esi
   5c181:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5c186:      	int3
   5c187:      	int3
   5c188:      	int3
   5c189:      	int3
   5c18a:      	int3
   5c18b:      	int3
   5c18c:      	int3
   5c18d:      	int3
   5c18e:      	int3
   5c18f:      	int3

000000000005c190 <f.10>:
   5c190:      	pushq	%rbp
   5c191:      	pushq	%r15
   5c193:      	pushq	%r14
   5c195:      	pushq	%r13
   5c197:      	pushq	%r12
   5c199:      	pushq	%rbx
   5c19a:      	subq	$0x58, %rsp
   5c19e:      	movq	%rsi, %rbx
   5c1a1:      	movq	$0x5, 0x18(%rsp)
   5c1aa:      	movq	$0x0, 0x20(%rsp)
   5c1b3:      	movq	0x7d16(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5c1ba:      	movq	%rsi, 0x10(%rsp)
   5c1bf:      	leaq	0x10(%rsp), %r12
   5c1c4:      	movq	%r12, 0x7d05(%rip)      # 0x63ed0 <native_roots.0>
   5c1cb:      	movq	0x7cde(%rip), %rdx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c1d2:      	incq	%rdx
   5c1d5:      	movq	%rdx, 0x7cd4(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c1dc:      	movq	0x7cd5(%rip), %rax      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c1e3:      	cmpq	%rax, %rdx
   5c1e6:      	cmovaq	%rdx, %rax
   5c1ea:      	movq	%rax, 0x7cc7(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c1f1:      	movq	%rdi, 0x28(%rsp)
   5c1f6:      	xorps	%xmm0, %xmm0
   5c1f9:      	movups	%xmm0, 0x30(%rsp)
   5c1fe:      	testq	%rdi, %rdi
   5c201:      	je	0x5c756 <f.10+0x5c6>
   5c207:      	movl	%edi, %eax
   5c209:      	andl	$0x1, %eax
   5c20c:      	jne	0x5c756 <f.10+0x5c6>
   5c212:      	movq	0x7caf(%rip), %rax      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c219:      	testq	%rax, %rax
   5c21c:      	je	0x5c756 <f.10+0x5c6>
   5c222:      	movq	(%rdi), %rcx
   5c225:      	movq	%rcx, %r8
   5c228:      	testq	%rcx, %rcx
   5c22b:      	je	0x5c291 <f.10+0x101>
   5c22d:      	movq	%rcx, %r8
   5c230:      	cmpq	$0x26, %rcx
   5c234:      	je	0x5c291 <f.10+0x101>
   5c236:      	movq	0x168(%rax), %r9
   5c23d:      	movq	%rcx, %r8
   5c240:      	shrq	$0x2, %r8
   5c244:      	leaq	-0x1(%r8), %r10
   5c248:      	cmpq	%r9, %r10
   5c24b:      	jae	0x5c756 <f.10+0x5c6>
   5c251:      	movq	0x160(%rax), %r10
   5c258:      	movq	-0x8(%r10,%r8,8), %r8
   5c25d:      	testq	%r8, %r8
   5c260:      	je	0x5c291 <f.10+0x101>
   5c262:      	cmpq	$0x26, %r8
   5c266:      	je	0x5c291 <f.10+0x101>
   5c268:      	nopl	(%rax,%rax)
   5c270:      	shrq	$0x2, %r8
   5c274:      	leaq	-0x1(%r8), %r11
   5c278:      	cmpq	%r9, %r11
   5c27b:      	jae	0x5c756 <f.10+0x5c6>
   5c281:      	movq	-0x8(%r10,%r8,8), %r8
   5c286:      	cmpq	$0x26, %r8
   5c28a:      	je	0x5c291 <f.10+0x101>
   5c28c:      	testq	%r8, %r8
   5c28f:      	jne	0x5c270 <f.10+0xe0>
   5c291:      	cmpq	$0x26, %r8
   5c295:      	jne	0x5c756 <f.10+0x5c6>
   5c29b:      	leaq	0x30(%rsp), %r15
   5c2a0:      	jmp	0x5c2be <f.10+0x12e>
   5c2a2:      	nopw	%cs:(%rax,%rax)
   5c2b0:      	addq	$0x2, %rbx
   5c2b4:      	cmpq	$0x26, %r8
   5c2b8:      	jne	0x5c756 <f.10+0x5c6>
   5c2be:      	cmpq	%rbx, 0x8(%rdi)
   5c2c2:      	jl	0x5c732 <f.10+0x5a2>
   5c2c8:      	testb	$0x1, %dil
   5c2cc:      	jne	0x5c756 <f.10+0x5c6>
   5c2d2:      	cmpq	$0x26, %rcx
   5c2d6:      	sete	%dl
   5c2d9:      	movl	%edx, %r10d
   5c2dc:      	testq	%rcx, %rcx
   5c2df:      	je	0x5c330 <f.10+0x1a0>
   5c2e1:      	movl	%edx, %r10d
   5c2e4:      	cmpq	$0x26, %rcx
   5c2e8:      	je	0x5c330 <f.10+0x1a0>
   5c2ea:      	movq	0x168(%rax), %rsi
   5c2f1:      	movq	%rcx, %r8
   5c2f4:      	shrq	$0x2, %r8
   5c2f8:      	leaq	-0x1(%r8), %r9
   5c2fc:      	cmpq	%rsi, %r9
   5c2ff:      	jae	0x5c756 <f.10+0x5c6>
   5c305:      	movq	0x160(%rax), %r9
   5c30c:      	movq	-0x8(%r9,%r8,8), %r8
   5c311:      	cmpq	$0x26, %r8
   5c315:      	sete	%r10b
   5c319:      	testq	%r8, %r8
   5c31c:      	je	0x5c330 <f.10+0x1a0>
   5c31e:      	cmpq	$0x26, %r8
   5c322:      	jne	0x5c6c0 <f.10+0x530>
   5c328:      	nopl	(%rax,%rax)
   5c330:      	testb	%r10b, %r10b
   5c333:      	je	0x5c756 <f.10+0x5c6>
   5c339:      	movq	0x18(%rdi), %rsi
   5c33d:      	testq	%rsi, %rsi
   5c340:      	je	0x5c756 <f.10+0x5c6>
   5c346:      	cmpl	$0x0, 0x8(%rsi)
   5c34a:      	je	0x5c756 <f.10+0x5c6>
   5c350:      	testq	%rcx, %rcx
   5c353:      	je	0x5c3a0 <f.10+0x210>
   5c355:      	cmpq	$0x26, %rcx
   5c359:      	je	0x5c3a0 <f.10+0x210>
   5c35b:      	movq	0x168(%rax), %rsi
   5c362:      	shrq	$0x2, %rcx
   5c366:      	leaq	-0x1(%rcx), %rdx
   5c36a:      	cmpq	%rsi, %rdx
   5c36d:      	jae	0x5c756 <f.10+0x5c6>
   5c373:      	movq	0x160(%rax), %r8
   5c37a:      	movq	-0x8(%r8,%rcx,8), %rcx
   5c37f:      	cmpq	$0x26, %rcx
   5c383:      	sete	%dl
   5c386:      	testq	%rcx, %rcx
   5c389:      	je	0x5c3a0 <f.10+0x210>
   5c38b:      	cmpq	$0x26, %rcx
   5c38f:      	jne	0x5c6f0 <f.10+0x560>
   5c395:      	nopw	%cs:(%rax,%rax)
   5c3a0:      	testb	%dl, %dl
   5c3a2:      	je	0x5c756 <f.10+0x5c6>
   5c3a8:      	movq	%rdi, 0x30(%rsp)
   5c3ad:      	movq	0x18(%rdi), %rcx
   5c3b1:      	testq	%rcx, %rcx
   5c3b4:      	je	0x5c756 <f.10+0x5c6>
   5c3ba:      	movq	0x10(%rcx), %rcx
   5c3be:      	testq	%rcx, %rcx
   5c3c1:      	je	0x5c756 <f.10+0x5c6>
   5c3c7:      	movq	0x10(%rcx), %rcx
   5c3cb:      	testq	%rcx, %rcx
   5c3ce:      	je	0x5c756 <f.10+0x5c6>
   5c3d4:      	movl	%ecx, %edx
   5c3d6:      	andl	$0x1, %edx
   5c3d9:      	jne	0x5c756 <f.10+0x5c6>
   5c3df:      	movq	(%rcx), %rdx
   5c3e2:      	testq	%rdx, %rdx
   5c3e5:      	je	0x5c450 <f.10+0x2c0>
   5c3e7:      	cmpq	$0x2a, %rdx
   5c3eb:      	je	0x5c450 <f.10+0x2c0>
   5c3ed:      	movq	0x168(%rax), %rsi
   5c3f4:      	shrq	$0x2, %rdx
   5c3f8:      	leaq	-0x1(%rdx), %rdi
   5c3fc:      	cmpq	%rsi, %rdi
   5c3ff:      	jae	0x5c756 <f.10+0x5c6>
   5c405:      	movq	0x160(%rax), %rax
   5c40c:      	movq	-0x8(%rax,%rdx,8), %rdx
   5c411:      	testq	%rdx, %rdx
   5c414:      	je	0x5c450 <f.10+0x2c0>
   5c416:      	cmpq	$0x2a, %rdx
   5c41a:      	je	0x5c450 <f.10+0x2c0>
   5c41c:      	nopl	(%rax)
   5c420:      	shrq	$0x2, %rdx
   5c424:      	leaq	-0x1(%rdx), %rdi
   5c428:      	cmpq	%rsi, %rdi
   5c42b:      	jae	0x5c756 <f.10+0x5c6>
   5c431:      	movq	-0x8(%rax,%rdx,8), %rdx
   5c436:      	cmpq	$0x2a, %rdx
   5c43a:      	je	0x5c450 <f.10+0x2c0>
   5c43c:      	testq	%rdx, %rdx
   5c43f:      	jne	0x5c420 <f.10+0x290>
   5c441:      	nopw	%cs:(%rax,%rax)
   5c450:      	cmpq	$0x2a, %rdx
   5c454:      	jne	0x5c756 <f.10+0x5c6>
   5c45a:      	movq	%rcx, 0x38(%rsp)
   5c45f:      	movq	0x18(%rcx), %rax
   5c463:      	testq	%rax, %rax
   5c466:      	je	0x5c756 <f.10+0x5c6>
   5c46c:      	movq	0x8(%rax), %rax
   5c470:      	testq	%rax, %rax
   5c473:      	je	0x5c756 <f.10+0x5c6>
   5c479:      	movq	0x8(%rax), %rdi
   5c47d:      	movq	%rdi, 0x40(%rsp)
   5c482:      	movq	$0x4, 0x20(%rsp)
   5c48b:      	movq	%rbx, %rsi
   5c48e:      	callq	0x5c770 <f.15>
   5c493:      	subq	$0x8, %rsp
   5c497:      	movq	%rax, %r14
   5c49a:      	movq	0x38(%rsp), %rax
   5c49f:      	testq	%rax, %rax
   5c4a2:      	je	0x5c756 <f.10+0x5c6>
   5c4a8:      	movq	0x8(%rax), %r13
   5c4ac:      	movq	0x10(%rax), %rbp
   5c4b0:      	movq	%rbp, 0x40(%rsp)
   5c4b5:      	movq	%r13, 0x48(%rsp)
   5c4ba:      	movq	$0x5, 0x20(%rsp)
   5c4c3:      	movq	0x79fe(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c4ca:      	testq	%rdi, %rdi
   5c4cd:      	je	0x5c756 <f.10+0x5c6>
   5c4d3:      	movq	0x178(%rdi), %rcx
   5c4da:      	testq	%rcx, %rcx
   5c4dd:      	je	0x5c532 <f.10+0x3a2>
   5c4df:      	movq	0x170(%rdi), %rax
   5c4e6:      	incq	%rax
   5c4e9:      	movq	%rax, 0x170(%rdi)
   5c4f0:      	movq	%rax, %rdx
   5c4f3:      	orq	%rcx, %rdx
   5c4f6:      	shrq	$0x20, %rdx
   5c4fa:      	je	0x5c720 <f.10+0x590>
   5c500:      	xorl	%edx, %edx
   5c502:      	divq	%rcx
   5c505:      	testq	%rdx, %rdx
   5c508:      	jne	0x5c532 <f.10+0x3a2>
   5c50a:      	movq	0x79bf(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5c511:      	movq	%rbx, 0x50(%rsp)
   5c516:      	movq	%r12, %rbx
   5c519:      	movq	%r15, %r12
   5c51c:      	movq	%rdi, %r15
   5c51f:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c524:      	movq	%r15, %rdi
   5c527:      	movq	%r12, %r15
   5c52a:      	movq	%rbx, %r12
   5c52d:      	movq	0x50(%rsp), %rbx
   5c532:      	movq	0x7997(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5c539:      	movl	$0x20, %esi
   5c53e:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c543:      	testq	%rax, %rax
   5c546:      	je	0x5c75b <f.10+0x5cb>
   5c54c:      	movq	$0x22, (%rax)
   5c553:      	movq	%r13, 0x8(%rax)
   5c557:      	movq	%rbp, 0x10(%rax)
   5c55b:      	movq	%rbx, 0x18(%rax)
   5c55f:      	movq	%rax, 0x40(%rsp)
   5c564:      	movq	$0x4, 0x20(%rsp)
   5c56d:      	movq	%rax, %rdi
   5c570:      	movq	%r14, %rsi
   5c573:      	callq	0x5cdb0 <f.12>
   5c578:      	subq	$0x8, %rsp
   5c57c:      	movq	0x30(%rsp), %rdi
   5c581:      	testq	%rdi, %rdi
   5c584:      	je	0x5c756 <f.10+0x5c6>
   5c58a:      	movq	0x10(%rdi), %rax
   5c58e:      	testq	%rax, %rax
   5c591:      	je	0x5c756 <f.10+0x5c6>
   5c597:      	cmpl	$0x0, 0x8(%rax)
   5c59b:      	je	0x5c756 <f.10+0x5c6>
   5c5a1:      	cmpq	$0x0, 0x10(%rax)
   5c5a6:      	je	0x5c756 <f.10+0x5c6>
   5c5ac:      	xorl	%edx, %edx
   5c5ae:      	cmpq	$0x0, 0x18(%rsp)
   5c5b4:      	sete	%dl
   5c5b7:      	movq	%r12, %rax
   5c5ba:      	leaq	0x790f(%rip), %rcx      # 0x63ed0 <native_roots.0>
   5c5c1:      	cmoveq	%rcx, %rax
   5c5c5:      	addq	0x78e4(%rip), %rdx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c5cc:      	movq	(%rax), %rsi
   5c5cf:      	movq	$0x5, 0x18(%rsp)
   5c5d8:      	movq	$0x0, 0x20(%rsp)
   5c5e1:      	movq	%rsi, 0x10(%rsp)
   5c5e6:      	movq	%r12, 0x78e3(%rip)      # 0x63ed0 <native_roots.0>
   5c5ed:      	movq	%rdx, 0x78bc(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c5f4:      	movq	0x78bd(%rip), %rax      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c5fb:      	cmpq	%rax, %rdx
   5c5fe:      	cmovaq	%rdx, %rax
   5c602:      	movq	%rax, 0x78af(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c609:      	movq	%rdi, 0x28(%rsp)
   5c60e:      	xorps	%xmm0, %xmm0
   5c611:      	movups	%xmm0, (%r15)
   5c615:      	testb	$0x1, %dil
   5c619:      	jne	0x5c756 <f.10+0x5c6>
   5c61f:      	movq	0x78a2(%rip), %rax      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c626:      	testq	%rax, %rax
   5c629:      	je	0x5c756 <f.10+0x5c6>
   5c62f:      	movq	(%rdi), %rcx
   5c632:      	movq	%rcx, %r8
   5c635:      	testq	%rcx, %rcx
   5c638:      	je	0x5c2b0 <f.10+0x120>
   5c63e:      	movq	%rcx, %r8
   5c641:      	cmpq	$0x26, %rcx
   5c645:      	je	0x5c2b0 <f.10+0x120>
   5c64b:      	movq	0x168(%rax), %r9
   5c652:      	movq	%rcx, %r8
   5c655:      	shrq	$0x2, %r8
   5c659:      	leaq	-0x1(%r8), %r10
   5c65d:      	cmpq	%r9, %r10
   5c660:      	jae	0x5c756 <f.10+0x5c6>
   5c666:      	movq	0x160(%rax), %r10
   5c66d:      	movq	-0x8(%r10,%r8,8), %r8
   5c672:      	testq	%r8, %r8
   5c675:      	je	0x5c2b0 <f.10+0x120>
   5c67b:      	cmpq	$0x26, %r8
   5c67f:      	je	0x5c2b0 <f.10+0x120>
   5c685:      	nopw	%cs:(%rax,%rax)
   5c690:      	shrq	$0x2, %r8
   5c694:      	leaq	-0x1(%r8), %r11
   5c698:      	cmpq	%r9, %r11
   5c69b:      	jae	0x5c756 <f.10+0x5c6>
   5c6a1:      	movq	-0x8(%r10,%r8,8), %r8
   5c6a6:      	cmpq	$0x26, %r8
   5c6aa:      	je	0x5c2b0 <f.10+0x120>
   5c6b0:      	testq	%r8, %r8
   5c6b3:      	jne	0x5c690 <f.10+0x500>
   5c6b5:      	jmp	0x5c2b0 <f.10+0x120>
   5c6ba:      	nopw	(%rax,%rax)
   5c6c0:      	shrq	$0x2, %r8
   5c6c4:      	leaq	-0x1(%r8), %r10
   5c6c8:      	cmpq	%rsi, %r10
   5c6cb:      	jae	0x5c756 <f.10+0x5c6>
   5c6d1:      	movq	-0x8(%r9,%r8,8), %r8
   5c6d6:      	cmpq	$0x26, %r8
   5c6da:      	je	0x5c6e1 <f.10+0x551>
   5c6dc:      	testq	%r8, %r8
   5c6df:      	jne	0x5c6c0 <f.10+0x530>
   5c6e1:      	cmpq	$0x26, %r8
   5c6e5:      	je	0x5c339 <f.10+0x1a9>
   5c6eb:      	jmp	0x5c756 <f.10+0x5c6>
   5c6ed:      	nopl	(%rax)
   5c6f0:      	shrq	$0x2, %rcx
   5c6f4:      	leaq	-0x1(%rcx), %rdx
   5c6f8:      	cmpq	%rsi, %rdx
   5c6fb:      	jae	0x5c756 <f.10+0x5c6>
   5c6fd:      	movq	-0x8(%r8,%rcx,8), %rcx
   5c702:      	cmpq	$0x26, %rcx
   5c706:      	je	0x5c70d <f.10+0x57d>
   5c708:      	testq	%rcx, %rcx
   5c70b:      	jne	0x5c6f0 <f.10+0x560>
   5c70d:      	cmpq	$0x26, %rcx
   5c711:      	je	0x5c3a8 <f.10+0x218>
   5c717:      	jmp	0x5c756 <f.10+0x5c6>
   5c719:      	nopl	(%rax)
   5c720:      	xorl	%edx, %edx
   5c722:      	divl	%ecx
   5c724:      	testq	%rdx, %rdx
   5c727:      	jne	0x5c532 <f.10+0x3a2>
   5c72d:      	jmp	0x5c50a <f.10+0x37a>
   5c732:      	movq	%rsi, 0x7797(%rip)      # 0x63ed0 <native_roots.0>
   5c739:      	decq	%rdx
   5c73c:      	movq	%rdx, 0x776d(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c743:      	xorl	%eax, %eax
   5c745:      	addq	$0x58, %rsp
   5c749:      	popq	%rbx
   5c74a:      	popq	%r12
   5c74c:      	popq	%r13
   5c74e:      	popq	%r14
   5c750:      	popq	%r15
   5c752:      	popq	%rbp
   5c753:      	retq	$0x8
   5c756:      	callq	0x55920 <native_trap>
   5c75b:      	leaq	-0x5334e(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5c762:      	movl	$0x2f, %esi
   5c767:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5c76c:      	int3
   5c76d:      	int3
   5c76e:      	int3
   5c76f:      	int3

000000000005c770 <f.15>:
   5c770:      	pushq	%rbp
   5c771:      	pushq	%r15
   5c773:      	pushq	%r14
   5c775:      	pushq	%r13
   5c777:      	pushq	%r12
   5c779:      	pushq	%rbx
   5c77a:      	subq	$0x58, %rsp
   5c77e:      	movq	$0x6, 0x18(%rsp)
   5c787:      	movq	$0x0, 0x20(%rsp)
   5c790:      	movq	0x7739(%rip), %rax      # 0x63ed0 <native_roots.0>
   5c797:      	movq	%rax, 0x10(%rsp)
   5c79c:      	leaq	0x10(%rsp), %rcx
   5c7a1:      	movq	%rcx, 0x7728(%rip)      # 0x63ed0 <native_roots.0>
   5c7a8:      	movq	0x7701(%rip), %rax      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c7af:      	incq	%rax
   5c7b2:      	movq	%rax, 0x76f7(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c7b9:      	movq	0x76f8(%rip), %rdx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c7c0:      	cmpq	%rdx, %rax
   5c7c3:      	cmovbeq	%rdx, %rax
   5c7c7:      	movq	%rax, 0x76ea(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c7ce:      	movq	%rdi, 0x28(%rsp)
   5c7d3:      	xorps	%xmm0, %xmm0
   5c7d6:      	movups	%xmm0, 0x30(%rsp)
   5c7db:      	testq	%rdi, %rdi
   5c7de:      	je	0x5cd97 <f.15+0x627>
   5c7e4:      	cmpb	$0x0, 0x781d(%rip)      # 0x64008 <g.15>
   5c7eb:      	je	0x5cd97 <f.15+0x627>
   5c7f1:      	cmpq	$0x0, 0x7807(%rip)      # 0x64000 <g.14>
   5c7f9:      	je	0x5cd97 <f.15+0x627>
   5c7ff:      	movq	0x8(%rdi), %r14
   5c803:      	movq	$0x3, 0x20(%rsp)
   5c80c:      	movq	0x76b5(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c813:      	testq	%rdi, %rdi
   5c816:      	je	0x5cd97 <f.15+0x627>
   5c81c:      	movq	%rsi, %rbx
   5c81f:      	movq	0x178(%rdi), %rsi
   5c826:      	testq	%rsi, %rsi
   5c829:      	je	0x5c86d <f.15+0xfd>
   5c82b:      	movq	0x170(%rdi), %rax
   5c832:      	incq	%rax
   5c835:      	movq	%rax, 0x170(%rdi)
   5c83c:      	movq	%rax, %rdx
   5c83f:      	orq	%rsi, %rdx
   5c842:      	shrq	$0x20, %rdx
   5c846:      	je	0x5cd2b <f.15+0x5bb>
   5c84c:      	xorl	%edx, %edx
   5c84e:      	divq	%rsi
   5c851:      	testq	%rdx, %rdx
   5c854:      	jne	0x5c86d <f.15+0xfd>
   5c856:      	leaq	0x10(%rsp), %rsi
   5c85b:      	movq	%rdi, %r15
   5c85e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c863:      	movq	%r15, %rdi
   5c866:      	movq	0x7663(%rip), %rcx      # 0x63ed0 <native_roots.0>
   5c86d:      	movl	$0x18, %esi
   5c872:      	movq	%rcx, %rdx
   5c875:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c87a:      	testq	%rax, %rax
   5c87d:      	je	0x5cd9c <f.15+0x62c>
   5c883:      	movq	%rax, %r15
   5c886:      	movq	$0x7a, (%rax)
   5c88d:      	movl	$0x0, 0x8(%rax)
   5c894:      	movq	$0x0, 0x10(%rax)
   5c89c:      	movq	%rax, 0x30(%rsp)
   5c8a1:      	movq	%rax, 0x40(%rsp)
   5c8a6:      	leaq	0x54eb(%rip), %rbp      # 0x61d98 <ref.19>
   5c8ad:      	movq	%rbp, 0x48(%rsp)
   5c8b2:      	movq	%rax, 0x50(%rsp)
   5c8b7:      	movq	$0x6, 0x20(%rsp)
   5c8c0:      	movq	0x7601(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c8c7:      	testq	%rdi, %rdi
   5c8ca:      	je	0x5cd97 <f.15+0x627>
   5c8d0:      	movq	0x178(%rdi), %rcx
   5c8d7:      	testq	%rcx, %rcx
   5c8da:      	je	0x5c919 <f.15+0x1a9>
   5c8dc:      	movq	0x170(%rdi), %rax
   5c8e3:      	incq	%rax
   5c8e6:      	movq	%rax, 0x170(%rdi)
   5c8ed:      	movq	%rax, %rdx
   5c8f0:      	orq	%rcx, %rdx
   5c8f3:      	shrq	$0x20, %rdx
   5c8f7:      	je	0x5cd3d <f.15+0x5cd>
   5c8fd:      	xorl	%edx, %edx
   5c8ff:      	divq	%rcx
   5c902:      	testq	%rdx, %rdx
   5c905:      	jne	0x5c919 <f.15+0x1a9>
   5c907:      	movq	0x75c2(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5c90e:      	movq	%rdi, %r12
   5c911:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c916:      	movq	%r12, %rdi
   5c919:      	movq	0x75b0(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5c920:      	movl	$0x10, %esi
   5c925:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c92a:      	testq	%rax, %rax
   5c92d:      	je	0x5cd9c <f.15+0x62c>
   5c933:      	movq	%rax, %r12
   5c936:      	movq	$0x72, (%rax)
   5c93d:      	movq	%r15, 0x8(%rax)
   5c941:      	movq	%rax, 0x40(%rsp)
   5c946:      	movq	%rbp, 0x48(%rsp)
   5c94b:      	movq	%r15, 0x50(%rsp)
   5c950:      	movq	$0x6, 0x20(%rsp)
   5c959:      	movq	0x7568(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c960:      	testq	%rdi, %rdi
   5c963:      	je	0x5cd97 <f.15+0x627>
   5c969:      	movq	0x178(%rdi), %rcx
   5c970:      	testq	%rcx, %rcx
   5c973:      	je	0x5c9b2 <f.15+0x242>
   5c975:      	movq	0x170(%rdi), %rax
   5c97c:      	incq	%rax
   5c97f:      	movq	%rax, 0x170(%rdi)
   5c986:      	movq	%rax, %rdx
   5c989:      	orq	%rcx, %rdx
   5c98c:      	shrq	$0x20, %rdx
   5c990:      	je	0x5cd4f <f.15+0x5df>
   5c996:      	xorl	%edx, %edx
   5c998:      	divq	%rcx
   5c99b:      	testq	%rdx, %rdx
   5c99e:      	jne	0x5c9b2 <f.15+0x242>
   5c9a0:      	movq	0x7529(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5c9a7:      	movq	%rdi, %r13
   5c9aa:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c9af:      	movq	%r13, %rdi
   5c9b2:      	movq	0x7517(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5c9b9:      	movl	$0x18, %esi
   5c9be:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c9c3:      	testq	%rax, %rax
   5c9c6:      	je	0x5cd9c <f.15+0x62c>
   5c9cc:      	movq	$0x92, (%rax)
   5c9d3:      	movq	%rbp, 0x8(%rax)
   5c9d7:      	movq	%r12, 0x10(%rax)
   5c9db:      	movq	%rax, 0x10(%r15)
   5c9df:      	movq	0x30(%rsp), %rax
   5c9e4:      	testq	%rax, %rax
   5c9e7:      	je	0x5cd97 <f.15+0x627>
   5c9ed:      	movl	$0x1, 0x8(%rax)
   5c9f4:      	movq	0x30(%rsp), %rax
   5c9f9:      	testq	%rax, %rax
   5c9fc:      	je	0x5cd97 <f.15+0x627>
   5ca02:      	cmpl	$0x0, 0x8(%rax)
   5ca06:      	je	0x5cd97 <f.15+0x627>
   5ca0c:      	movq	0x10(%rax), %rax
   5ca10:      	testq	%rax, %rax
   5ca13:      	je	0x5cd97 <f.15+0x627>
   5ca19:      	movq	%rax, 0x38(%rsp)
   5ca1e:      	movq	0x8(%rax), %rcx
   5ca22:      	testq	%rcx, %rcx
   5ca25:      	je	0x5cd97 <f.15+0x627>
   5ca2b:      	incq	%r14
   5ca2e:      	movq	0x10(%rax), %rdi
   5ca32:      	movq	0x8(%rcx), %rax
   5ca36:      	movq	%rdi, 0x40(%rsp)
   5ca3b:      	movq	$0x4, 0x20(%rsp)
   5ca44:      	movl	$0x1, %edx
   5ca49:      	movq	%r14, %rsi
   5ca4c:      	callq	*%rax
   5ca4e:      	subq	$0x8, %rsp
   5ca52:      	cmpq	$0x0, 0x28(%rsp)
   5ca58:      	je	0x5cd97 <f.15+0x627>
   5ca5e:      	cmpb	$0x0, 0x75a3(%rip)      # 0x64008 <g.15>
   5ca65:      	je	0x5cd97 <f.15+0x627>
   5ca6b:      	cmpq	$0x0, 0x758d(%rip)      # 0x64000 <g.14>
   5ca73:      	je	0x5cd97 <f.15+0x627>
   5ca79:      	movq	$0x3, 0x20(%rsp)
   5ca82:      	movq	0x743f(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5ca89:      	testq	%rdi, %rdi
   5ca8c:      	je	0x5cd97 <f.15+0x627>
   5ca92:      	movq	%rax, %r14
   5ca95:      	movq	0x178(%rdi), %rcx
   5ca9c:      	testq	%rcx, %rcx
   5ca9f:      	je	0x5cade <f.15+0x36e>
   5caa1:      	movq	0x170(%rdi), %rax
   5caa8:      	incq	%rax
   5caab:      	movq	%rax, 0x170(%rdi)
   5cab2:      	movq	%rax, %rdx
   5cab5:      	orq	%rcx, %rdx
   5cab8:      	shrq	$0x20, %rdx
   5cabc:      	je	0x5cd61 <f.15+0x5f1>
   5cac2:      	xorl	%edx, %edx
   5cac4:      	divq	%rcx
   5cac7:      	testq	%rdx, %rdx
   5caca:      	jne	0x5cade <f.15+0x36e>
   5cacc:      	movq	0x73fd(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5cad3:      	movq	%rdi, %r15
   5cad6:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5cadb:      	movq	%r15, %rdi
   5cade:      	movq	0x73eb(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5cae5:      	movl	$0x18, %esi
   5caea:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5caef:      	testq	%rax, %rax
   5caf2:      	je	0x5cd9c <f.15+0x62c>
   5caf8:      	movq	%rax, %r15
   5cafb:      	movq	$0x7a, (%rax)
   5cb02:      	movl	$0x0, 0x8(%rax)
   5cb09:      	movq	$0x0, 0x10(%rax)
   5cb11:      	movq	%rax, 0x30(%rsp)
   5cb16:      	movq	%rax, 0x40(%rsp)
   5cb1b:      	movq	%rbp, 0x48(%rsp)
   5cb20:      	movq	%rax, 0x50(%rsp)
   5cb25:      	movq	$0x6, 0x20(%rsp)
   5cb2e:      	movq	0x7393(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5cb35:      	testq	%rdi, %rdi
   5cb38:      	je	0x5cd97 <f.15+0x627>
   5cb3e:      	movq	0x178(%rdi), %rcx
   5cb45:      	testq	%rcx, %rcx
   5cb48:      	je	0x5cb87 <f.15+0x417>
   5cb4a:      	movq	0x170(%rdi), %rax
   5cb51:      	incq	%rax
   5cb54:      	movq	%rax, 0x170(%rdi)
   5cb5b:      	movq	%rax, %rdx
   5cb5e:      	orq	%rcx, %rdx
   5cb61:      	shrq	$0x20, %rdx
   5cb65:      	je	0x5cd73 <f.15+0x603>
   5cb6b:      	xorl	%edx, %edx
   5cb6d:      	divq	%rcx
   5cb70:      	testq	%rdx, %rdx
   5cb73:      	jne	0x5cb87 <f.15+0x417>
   5cb75:      	movq	0x7354(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5cb7c:      	movq	%rdi, %r12
   5cb7f:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5cb84:      	movq	%r12, %rdi
   5cb87:      	movq	0x7342(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5cb8e:      	movl	$0x10, %esi
   5cb93:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5cb98:      	testq	%rax, %rax
   5cb9b:      	je	0x5cd9c <f.15+0x62c>
   5cba1:      	movq	%rax, %r12
   5cba4:      	movq	$0x72, (%rax)
   5cbab:      	movq	%r15, 0x8(%rax)
   5cbaf:      	movq	%rax, 0x40(%rsp)
   5cbb4:      	movq	%rbp, 0x48(%rsp)
   5cbb9:      	movq	%r15, 0x50(%rsp)
   5cbbe:      	movq	$0x6, 0x20(%rsp)
   5cbc7:      	movq	0x72fa(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5cbce:      	testq	%rdi, %rdi
   5cbd1:      	je	0x5cd97 <f.15+0x627>
   5cbd7:      	movq	0x178(%rdi), %rcx
   5cbde:      	testq	%rcx, %rcx
   5cbe1:      	je	0x5cc20 <f.15+0x4b0>
   5cbe3:      	movq	0x170(%rdi), %rax
   5cbea:      	incq	%rax
   5cbed:      	movq	%rax, 0x170(%rdi)
   5cbf4:      	movq	%rax, %rdx
   5cbf7:      	orq	%rcx, %rdx
   5cbfa:      	shrq	$0x20, %rdx
   5cbfe:      	je	0x5cd85 <f.15+0x615>
   5cc04:      	xorl	%edx, %edx
   5cc06:      	divq	%rcx
   5cc09:      	testq	%rdx, %rdx
   5cc0c:      	jne	0x5cc20 <f.15+0x4b0>
   5cc0e:      	movq	0x72bb(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5cc15:      	movq	%rdi, %r13
   5cc18:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5cc1d:      	movq	%r13, %rdi
   5cc20:      	movq	0x72a9(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5cc27:      	movl	$0x18, %esi
   5cc2c:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5cc31:      	testq	%rax, %rax
   5cc34:      	je	0x5cd9c <f.15+0x62c>
   5cc3a:      	movq	$0x92, (%rax)
   5cc41:      	movq	%rbp, 0x8(%rax)
   5cc45:      	movq	%r12, 0x10(%rax)
   5cc49:      	movq	%rax, 0x10(%r15)
   5cc4d:      	movq	0x30(%rsp), %rax
   5cc52:      	testq	%rax, %rax
   5cc55:      	je	0x5cd97 <f.15+0x627>
   5cc5b:      	movl	$0x1, 0x8(%rax)
   5cc62:      	movq	0x30(%rsp), %rax
   5cc67:      	testq	%rax, %rax
   5cc6a:      	je	0x5cd97 <f.15+0x627>
   5cc70:      	cmpl	$0x0, 0x8(%rax)
   5cc74:      	je	0x5cd97 <f.15+0x627>
   5cc7a:      	movq	0x10(%rax), %rax
   5cc7e:      	testq	%rax, %rax
   5cc81:      	je	0x5cd97 <f.15+0x627>
   5cc87:      	movq	%rax, 0x38(%rsp)
   5cc8c:      	movq	0x8(%rax), %rcx
   5cc90:      	testq	%rcx, %rcx
   5cc93:      	je	0x5cd97 <f.15+0x627>
   5cc99:      	movq	0x10(%rax), %rdi
   5cc9d:      	incq	%rbx
   5cca0:      	movq	0x8(%rcx), %rax
   5cca4:      	movq	%rdi, 0x40(%rsp)
   5cca9:      	movq	$0x4, 0x20(%rsp)
   5ccb2:      	movl	$0x1, %edx
   5ccb7:      	movq	%rbx, %rsi
   5ccba:      	callq	*%rax
   5ccbc:      	subq	$0x8, %rsp
   5ccc0:      	movq	%rax, %rsi
   5ccc3:      	decq	%rsi
   5ccc6:      	je	0x5cd97 <f.15+0x627>
   5cccc:      	movq	%rax, %rcx
   5cccf:      	leaq	-0x2(,%r14,2), %rax
   5ccd7:      	movq	%rax, %rdx
   5ccda:      	negq	%rdx
   5ccdd:      	jno	0x5cce8 <f.15+0x578>
   5ccdf:      	testq	%rcx, %rcx
   5cce2:      	je	0x5cd97 <f.15+0x627>
   5cce8:      	cmpq	$0x0, 0x18(%rsp)
   5ccee:      	je	0x5cd03 <f.15+0x593>
   5ccf0:      	movq	0x10(%rsp), %rcx
   5ccf5:      	movq	%rcx, 0x71d4(%rip)      # 0x63ed0 <native_roots.0>
   5ccfc:      	decq	0x71ad(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cd03:      	movq	%rax, %rcx
   5cd06:      	orq	%rsi, %rcx
   5cd09:      	shrq	$0x20, %rcx
   5cd0d:      	je	0x5cd16 <f.15+0x5a6>
   5cd0f:      	cqto
   5cd11:      	idivq	%rsi
   5cd14:      	jmp	0x5cd1a <f.15+0x5aa>
   5cd16:      	xorl	%edx, %edx
   5cd18:      	divl	%esi
   5cd1a:      	addq	$0x58, %rsp
   5cd1e:      	popq	%rbx
   5cd1f:      	popq	%r12
   5cd21:      	popq	%r13
   5cd23:      	popq	%r14
   5cd25:      	popq	%r15
   5cd27:      	popq	%rbp
   5cd28:      	retq	$0x8
   5cd2b:      	xorl	%edx, %edx
   5cd2d:      	divl	%esi
   5cd2f:      	testq	%rdx, %rdx
   5cd32:      	jne	0x5c86d <f.15+0xfd>
   5cd38:      	jmp	0x5c856 <f.15+0xe6>
   5cd3d:      	xorl	%edx, %edx
   5cd3f:      	divl	%ecx
   5cd41:      	testq	%rdx, %rdx
   5cd44:      	jne	0x5c919 <f.15+0x1a9>
   5cd4a:      	jmp	0x5c907 <f.15+0x197>
   5cd4f:      	xorl	%edx, %edx
   5cd51:      	divl	%ecx
   5cd53:      	testq	%rdx, %rdx
   5cd56:      	jne	0x5c9b2 <f.15+0x242>
   5cd5c:      	jmp	0x5c9a0 <f.15+0x230>
   5cd61:      	xorl	%edx, %edx
   5cd63:      	divl	%ecx
   5cd65:      	testq	%rdx, %rdx
   5cd68:      	jne	0x5cade <f.15+0x36e>
   5cd6e:      	jmp	0x5cacc <f.15+0x35c>
   5cd73:      	xorl	%edx, %edx
   5cd75:      	divl	%ecx
   5cd77:      	testq	%rdx, %rdx
   5cd7a:      	jne	0x5cb87 <f.15+0x417>
   5cd80:      	jmp	0x5cb75 <f.15+0x405>
   5cd85:      	xorl	%edx, %edx
   5cd87:      	divl	%ecx
   5cd89:      	testq	%rdx, %rdx
   5cd8c:      	jne	0x5cc20 <f.15+0x4b0>
   5cd92:      	jmp	0x5cc0e <f.15+0x49e>
   5cd97:      	callq	0x55920 <native_trap>
   5cd9c:      	leaq	-0x5398f(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5cda3:      	movl	$0x2f, %esi
   5cda8:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5cdad:      	int3
   5cdae:      	int3
   5cdaf:      	int3

000000000005cdb0 <f.12>:
   5cdb0:      	pushq	%rbp
   5cdb1:      	pushq	%r15
   5cdb3:      	pushq	%r14
   5cdb5:      	pushq	%r13
   5cdb7:      	pushq	%r12
   5cdb9:      	pushq	%rbx
   5cdba:      	subq	$0xa8, %rsp
   5cdc1:      	movq	%rsi, %rbx
   5cdc4:      	movq	$0x7, 0x38(%rsp)
   5cdcd:      	movq	$0x0, 0x40(%rsp)
   5cdd6:      	movq	0x70f3(%rip), %rax      # 0x63ed0 <native_roots.0>
   5cddd:      	movq	%rax, 0x30(%rsp)
   5cde2:      	movq	0x70c7(%rip), %rax      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cde9:      	incq	%rax
   5cdec:      	movq	%rax, 0x70bd(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cdf3:      	movq	0x70be(%rip), %rcx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5cdfa:      	cmpq	%rcx, %rax
   5cdfd:      	cmovbeq	%rcx, %rax
   5ce01:      	leaq	0x30(%rsp), %rcx
   5ce06:      	movq	%rcx, 0x70c3(%rip)      # 0x63ed0 <native_roots.0>
   5ce0d:      	movq	%rax, 0x70a4(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5ce14:      	movq	%rdi, 0x48(%rsp)
   5ce19:      	xorps	%xmm0, %xmm0
   5ce1c:      	movups	%xmm0, 0x50(%rsp)
   5ce21:      	movq	0x18(%rdi), %rax
   5ce25:      	movq	$0x3, 0x40(%rsp)
   5ce2e:      	movq	%rsi, 0x80(%rsp)
   5ce36:      	movq	%rax, 0x88(%rsp)
   5ce3e:      	leaq	0x80(%rsp), %rax
   5ce46:      	movq	%rax, 0x10(%rsp)
   5ce4b:      	leaq	-0xed12(%rip), %rax     # 0x4e140 <<i64 as core::fmt::Display>::fmt>
   5ce52:      	movq	%rax, 0x18(%rsp)
   5ce57:      	leaq	0x88(%rsp), %rcx
   5ce5f:      	movq	%rcx, 0x20(%rsp)
   5ce64:      	movq	%rax, 0x28(%rsp)
   5ce69:      	leaq	-0x56836(%rip), %rdi    # 0x663a <writev+0x663a>
   5ce70:      	leaq	0x10(%rsp), %rsi
   5ce75:      	callq	0x4e2a0 <std::io::stdio::_print>
   5ce7a:      	movq	$0x3, 0x40(%rsp)
   5ce83:      	leaq	0x2fa6(%rip), %r12      # 0x5fe30 <writev+0x5fe30>
   5ce8a:      	movq	%r12, 0x10(%rsp)
   5ce8f:      	leaq	-0x6056(%rip), %rbp     # 0x56e40 <_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$::fmt::h4581551deb22294e>
   5ce96:      	movq	%rbp, 0x18(%rsp)
   5ce9b:      	leaq	-0x566a0(%rip), %rdi    # 0x6802 <writev+0x6802>
   5cea2:      	leaq	0x10(%rsp), %rsi
   5cea7:      	callq	0x4e2a0 <std::io::stdio::_print>
   5ceac:      	cmpb	$0x0, 0x7195(%rip)      # 0x64048 <g.23>
   5ceb3:      	je	0x5d4e5 <f.12+0x735>
   5ceb9:      	cmpq	$0x0, 0x717f(%rip)      # 0x64040 <g.22>
   5cec1:      	je	0x5d4e5 <f.12+0x735>
   5cec7:      	movq	$0x3, 0x40(%rsp)
   5ced0:      	leaq	0x2f99(%rip), %rax      # 0x5fe70 <writev+0x5fe70>
   5ced7:      	movq	%rax, 0x10(%rsp)
   5cedc:      	movq	%rbp, 0x18(%rsp)
   5cee1:      	leaq	-0x566e6(%rip), %r14    # 0x6802 <writev+0x6802>
   5cee8:      	leaq	0x10(%rsp), %rsi
   5ceed:      	movq	%r14, %rdi
   5cef0:      	callq	0x4e2a0 <std::io::stdio::_print>
   5cef5:      	movq	$0x3, 0x40(%rsp)
   5cefe:      	movq	%r12, 0x10(%rsp)
   5cf03:      	movq	%rbp, 0x18(%rsp)
   5cf08:      	leaq	0x10(%rsp), %rsi
   5cf0d:      	movq	%r14, %rdi
   5cf10:      	callq	0x4e2a0 <std::io::stdio::_print>
   5cf15:      	movq	$0x3, 0x40(%rsp)
   5cf1e:      	movq	0x6fa3(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5cf25:      	testq	%rdi, %rdi
   5cf28:      	je	0x5d4e5 <f.12+0x735>
   5cf2e:      	movq	0x178(%rdi), %rcx
   5cf35:      	testq	%rcx, %rcx
   5cf38:      	je	0x5cf77 <f.12+0x1c7>
   5cf3a:      	movq	0x170(%rdi), %rax
   5cf41:      	incq	%rax
   5cf44:      	movq	%rax, 0x170(%rdi)
   5cf4b:      	movq	%rax, %rdx
   5cf4e:      	orq	%rcx, %rdx
   5cf51:      	shrq	$0x20, %rdx
   5cf55:      	je	0x5d479 <f.12+0x6c9>
   5cf5b:      	xorl	%edx, %edx
   5cf5d:      	divq	%rcx
   5cf60:      	testq	%rdx, %rdx
   5cf63:      	jne	0x5cf77 <f.12+0x1c7>
   5cf65:      	movq	0x6f64(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5cf6c:      	movq	%rdi, %r14
   5cf6f:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5cf74:      	movq	%r14, %rdi
   5cf77:      	movq	0x6f52(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5cf7e:      	movl	$0x18, %esi
   5cf83:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5cf88:      	testq	%rax, %rax
   5cf8b:      	je	0x5d4ea <f.12+0x73a>
   5cf91:      	movq	%rax, %r14
   5cf94:      	movq	$0x5e, (%rax)
   5cf9b:      	movl	$0x0, 0x8(%rax)
   5cfa2:      	movq	$0x0, 0x10(%rax)
   5cfaa:      	movq	%rax, 0x50(%rsp)
   5cfaf:      	movq	0x48(%rsp), %rax
   5cfb4:      	testq	%rax, %rax
   5cfb7:      	je	0x5d4e5 <f.12+0x735>
   5cfbd:      	movups	0x10(%rax), %xmm0
   5cfc1:      	movq	%r14, 0x60(%rsp)
   5cfc6:      	movlps	%xmm0, 0x68(%rsp)
   5cfcb:      	leaq	0x4da6(%rip), %r13      # 0x61d78 <ref.14>
   5cfd2:      	movq	%r13, 0x70(%rsp)
   5cfd7:      	movq	%r14, 0x78(%rsp)
   5cfdc:      	movq	$0x7, 0x40(%rsp)
   5cfe5:      	movq	0x6edc(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5cfec:      	testq	%rdi, %rdi
   5cfef:      	je	0x5d4e5 <f.12+0x735>
   5cff5:      	movaps	%xmm0, 0x90(%rsp)
   5cffd:      	movq	0x178(%rdi), %rcx
   5d004:      	testq	%rcx, %rcx
   5d007:      	je	0x5d046 <f.12+0x296>
   5d009:      	movq	0x170(%rdi), %rax
   5d010:      	incq	%rax
   5d013:      	movq	%rax, 0x170(%rdi)
   5d01a:      	movq	%rax, %rdx
   5d01d:      	orq	%rcx, %rdx
   5d020:      	shrq	$0x20, %rdx
   5d024:      	je	0x5d48b <f.12+0x6db>
   5d02a:      	xorl	%edx, %edx
   5d02c:      	divq	%rcx
   5d02f:      	testq	%rdx, %rdx
   5d032:      	jne	0x5d046 <f.12+0x296>
   5d034:      	movq	0x6e95(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5d03b:      	movq	%rdi, %r15
   5d03e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d043:      	movq	%r15, %rdi
   5d046:      	movq	0x6e83(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5d04d:      	movl	$0x28, %esi
   5d052:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d057:      	testq	%rax, %rax
   5d05a:      	je	0x5d4ea <f.12+0x73a>
   5d060:      	movq	%rax, %r15
   5d063:      	movq	$0x1a, (%rax)
   5d06a:      	movaps	0x90(%rsp), %xmm0
   5d072:      	movups	%xmm0, 0x8(%rax)
   5d076:      	movq	%rbx, 0x18(%rax)
   5d07a:      	movq	%r14, 0x20(%rax)
   5d07e:      	movq	%rax, 0x60(%rsp)
   5d083:      	movq	%r13, 0x68(%rsp)
   5d088:      	movq	%r14, 0x70(%rsp)
   5d08d:      	movq	$0x6, 0x40(%rsp)
   5d096:      	movq	0x6e2b(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d09d:      	testq	%rdi, %rdi
   5d0a0:      	je	0x5d4e5 <f.12+0x735>
   5d0a6:      	movq	0x178(%rdi), %rcx
   5d0ad:      	testq	%rcx, %rcx
   5d0b0:      	je	0x5d0f6 <f.12+0x346>
   5d0b2:      	movq	0x170(%rdi), %rax
   5d0b9:      	incq	%rax
   5d0bc:      	movq	%rax, 0x170(%rdi)
   5d0c3:      	movq	%rax, %rdx
   5d0c6:      	orq	%rcx, %rdx
   5d0c9:      	shrq	$0x20, %rdx
   5d0cd:      	je	0x5d49d <f.12+0x6ed>
   5d0d3:      	xorl	%edx, %edx
   5d0d5:      	divq	%rcx
   5d0d8:      	testq	%rdx, %rdx
   5d0db:      	jne	0x5d0f6 <f.12+0x346>
   5d0dd:      	movq	0x6dec(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5d0e4:      	movq	%rdi, %r12
   5d0e7:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d0ec:      	movq	%r12, %rdi
   5d0ef:      	leaq	0x2d3a(%rip), %r12      # 0x5fe30 <writev+0x5fe30>
   5d0f6:      	movq	0x6dd3(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5d0fd:      	movl	$0x18, %esi
   5d102:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d107:      	testq	%rax, %rax
   5d10a:      	je	0x5d4ea <f.12+0x73a>
   5d110:      	movq	$0x82, (%rax)
   5d117:      	movq	%r13, 0x8(%rax)
   5d11b:      	movq	%r15, 0x10(%rax)
   5d11f:      	movq	%rax, 0x10(%r14)
   5d123:      	movq	0x50(%rsp), %rax
   5d128:      	testq	%rax, %rax
   5d12b:      	je	0x5d4e5 <f.12+0x735>
   5d131:      	movl	$0x1, 0x8(%rax)
   5d138:      	movq	0x50(%rsp), %rax
   5d13d:      	testq	%rax, %rax
   5d140:      	je	0x5d4e5 <f.12+0x735>
   5d146:      	cmpl	$0x0, 0x8(%rax)
   5d14a:      	je	0x5d4e5 <f.12+0x735>
   5d150:      	movq	0x10(%rax), %rax
   5d154:      	testq	%rax, %rax
   5d157:      	je	0x5d4e5 <f.12+0x735>
   5d15d:      	movq	%rax, 0x58(%rsp)
   5d162:      	movq	0x8(%rax), %rcx
   5d166:      	testq	%rcx, %rcx
   5d169:      	je	0x5d4e5 <f.12+0x735>
   5d16f:      	movq	0x10(%rax), %rdi
   5d173:      	movq	0x8(%rcx), %rax
   5d177:      	movq	%rdi, 0x60(%rsp)
   5d17c:      	movq	$0x4, 0x40(%rsp)
   5d185:      	xorl	%esi, %esi
   5d187:      	callq	*%rax
   5d189:      	subq	$0x8, %rsp
   5d18d:      	cmpb	$0x0, 0x6eb4(%rip)      # 0x64048 <g.23>
   5d194:      	je	0x5d4e5 <f.12+0x735>
   5d19a:      	cmpq	$0x0, 0x6e9e(%rip)      # 0x64040 <g.22>
   5d1a2:      	je	0x5d4e5 <f.12+0x735>
   5d1a8:      	movq	$0x3, 0x40(%rsp)
   5d1b1:      	leaq	0x2cc8(%rip), %rax      # 0x5fe80 <writev+0x5fe80>
   5d1b8:      	movq	%rax, 0x10(%rsp)
   5d1bd:      	movq	%rbp, 0x18(%rsp)
   5d1c2:      	leaq	-0x569c7(%rip), %r14    # 0x6802 <writev+0x6802>
   5d1c9:      	leaq	0x10(%rsp), %rsi
   5d1ce:      	movq	%r14, %rdi
   5d1d1:      	callq	0x4e2a0 <std::io::stdio::_print>
   5d1d6:      	movq	$0x3, 0x40(%rsp)
   5d1df:      	movq	%r12, 0x10(%rsp)
   5d1e4:      	movq	%rbp, 0x18(%rsp)
   5d1e9:      	leaq	0x10(%rsp), %rsi
   5d1ee:      	movq	%r14, %rdi
   5d1f1:      	callq	0x4e2a0 <std::io::stdio::_print>
   5d1f6:      	movq	$0x3, 0x40(%rsp)
   5d1ff:      	movq	0x6cc2(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d206:      	testq	%rdi, %rdi
   5d209:      	je	0x5d4e5 <f.12+0x735>
   5d20f:      	movq	0x178(%rdi), %rcx
   5d216:      	testq	%rcx, %rcx
   5d219:      	je	0x5d258 <f.12+0x4a8>
   5d21b:      	movq	0x170(%rdi), %rax
   5d222:      	incq	%rax
   5d225:      	movq	%rax, 0x170(%rdi)
   5d22c:      	movq	%rax, %rdx
   5d22f:      	orq	%rcx, %rdx
   5d232:      	shrq	$0x20, %rdx
   5d236:      	je	0x5d4af <f.12+0x6ff>
   5d23c:      	xorl	%edx, %edx
   5d23e:      	divq	%rcx
   5d241:      	testq	%rdx, %rdx
   5d244:      	jne	0x5d258 <f.12+0x4a8>
   5d246:      	movq	0x6c83(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5d24d:      	movq	%rdi, %r14
   5d250:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d255:      	movq	%r14, %rdi
   5d258:      	movq	0x6c71(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5d25f:      	movl	$0x18, %esi
   5d264:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d269:      	testq	%rax, %rax
   5d26c:      	je	0x5d4ea <f.12+0x73a>
   5d272:      	movq	%rax, %r14
   5d275:      	movq	$0x5e, (%rax)
   5d27c:      	movl	$0x0, 0x8(%rax)
   5d283:      	movq	$0x0, 0x10(%rax)
   5d28b:      	movq	%rax, 0x50(%rsp)
   5d290:      	movq	0x48(%rsp), %rax
   5d295:      	testq	%rax, %rax
   5d298:      	je	0x5d4e5 <f.12+0x735>
   5d29e:      	movq	0x8(%rax), %r13
   5d2a2:      	movq	0x18(%rax), %rbp
   5d2a6:      	movq	%r14, 0x60(%rsp)
   5d2ab:      	movq	%r13, 0x68(%rsp)
   5d2b0:      	leaq	0x4ab1(%rip), %r12      # 0x61d68 <ref.13>
   5d2b7:      	movq	%r12, 0x70(%rsp)
   5d2bc:      	movq	%r14, 0x78(%rsp)
   5d2c1:      	movq	$0x7, 0x40(%rsp)
   5d2ca:      	movq	0x6bf7(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d2d1:      	testq	%rdi, %rdi
   5d2d4:      	je	0x5d4e5 <f.12+0x735>
   5d2da:      	movq	0x178(%rdi), %rcx
   5d2e1:      	testq	%rcx, %rcx
   5d2e4:      	je	0x5d323 <f.12+0x573>
   5d2e6:      	movq	0x170(%rdi), %rax
   5d2ed:      	incq	%rax
   5d2f0:      	movq	%rax, 0x170(%rdi)
   5d2f7:      	movq	%rax, %rdx
   5d2fa:      	orq	%rcx, %rdx
   5d2fd:      	shrq	$0x20, %rdx
   5d301:      	je	0x5d4c1 <f.12+0x711>
   5d307:      	xorl	%edx, %edx
   5d309:      	divq	%rcx
   5d30c:      	testq	%rdx, %rdx
   5d30f:      	jne	0x5d323 <f.12+0x573>
   5d311:      	movq	0x6bb8(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5d318:      	movq	%rdi, %r15
   5d31b:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d320:      	movq	%r15, %rdi
   5d323:      	movq	0x6ba6(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5d32a:      	movl	$0x28, %esi
   5d32f:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d334:      	testq	%rax, %rax
   5d337:      	je	0x5d4ea <f.12+0x73a>
   5d33d:      	movq	%rax, %r15
   5d340:      	movq	$0x16, (%rax)
   5d347:      	movq	%r13, 0x8(%rax)
   5d34b:      	movq	%rbp, 0x10(%rax)
   5d34f:      	movq	%rbx, 0x18(%rax)
   5d353:      	movq	%r14, 0x20(%rax)
   5d357:      	movq	%rax, 0x60(%rsp)
   5d35c:      	movq	%r12, 0x68(%rsp)
   5d361:      	movq	%r14, 0x70(%rsp)
   5d366:      	movq	$0x6, 0x40(%rsp)
   5d36f:      	movq	0x6b52(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d376:      	testq	%rdi, %rdi
   5d379:      	je	0x5d4e5 <f.12+0x735>
   5d37f:      	movq	0x178(%rdi), %rcx
   5d386:      	testq	%rcx, %rcx
   5d389:      	je	0x5d3c8 <f.12+0x618>
   5d38b:      	movq	0x170(%rdi), %rax
   5d392:      	incq	%rax
   5d395:      	movq	%rax, 0x170(%rdi)
   5d39c:      	movq	%rax, %rdx
   5d39f:      	orq	%rcx, %rdx
   5d3a2:      	shrq	$0x20, %rdx
   5d3a6:      	je	0x5d4d3 <f.12+0x723>
   5d3ac:      	xorl	%edx, %edx
   5d3ae:      	divq	%rcx
   5d3b1:      	testq	%rdx, %rdx
   5d3b4:      	jne	0x5d3c8 <f.12+0x618>
   5d3b6:      	movq	0x6b13(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5d3bd:      	movq	%rdi, %rbx
   5d3c0:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d3c5:      	movq	%rbx, %rdi
   5d3c8:      	movq	0x6b01(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5d3cf:      	movl	$0x18, %esi
   5d3d4:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d3d9:      	testq	%rax, %rax
   5d3dc:      	je	0x5d4ea <f.12+0x73a>
   5d3e2:      	movq	$0x82, (%rax)
   5d3e9:      	movq	%r12, 0x8(%rax)
   5d3ed:      	movq	%r15, 0x10(%rax)
   5d3f1:      	movq	%rax, 0x10(%r14)
   5d3f5:      	movq	0x50(%rsp), %rax
   5d3fa:      	testq	%rax, %rax
   5d3fd:      	je	0x5d4e5 <f.12+0x735>
   5d403:      	movl	$0x1, 0x8(%rax)
   5d40a:      	movq	0x50(%rsp), %rax
   5d40f:      	testq	%rax, %rax
   5d412:      	je	0x5d4e5 <f.12+0x735>
   5d418:      	cmpl	$0x0, 0x8(%rax)
   5d41c:      	je	0x5d4e5 <f.12+0x735>
   5d422:      	movq	0x10(%rax), %rax
   5d426:      	testq	%rax, %rax
   5d429:      	je	0x5d4e5 <f.12+0x735>
   5d42f:      	movq	%rax, 0x58(%rsp)
   5d434:      	movq	0x8(%rax), %rcx
   5d438:      	testq	%rcx, %rcx
   5d43b:      	je	0x5d4e5 <f.12+0x735>
   5d441:      	movq	0x10(%rax), %rdi
   5d445:      	movq	0x8(%rcx), %rax
   5d449:      	cmpq	$0x0, 0x38(%rsp)
   5d44f:      	je	0x5d464 <f.12+0x6b4>
   5d451:      	movq	0x30(%rsp), %rcx
   5d456:      	movq	%rcx, 0x6a73(%rip)      # 0x63ed0 <native_roots.0>
   5d45d:      	decq	0x6a4c(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d464:      	xorl	%esi, %esi
   5d466:      	addq	$0xa8, %rsp
   5d46d:      	popq	%rbx
   5d46e:      	popq	%r12
   5d470:      	popq	%r13
   5d472:      	popq	%r14
   5d474:      	popq	%r15
   5d476:      	popq	%rbp
   5d477:      	jmpq	*%rax
   5d479:      	xorl	%edx, %edx
   5d47b:      	divl	%ecx
   5d47d:      	testq	%rdx, %rdx
   5d480:      	jne	0x5cf77 <f.12+0x1c7>
   5d486:      	jmp	0x5cf65 <f.12+0x1b5>
   5d48b:      	xorl	%edx, %edx
   5d48d:      	divl	%ecx
   5d48f:      	testq	%rdx, %rdx
   5d492:      	jne	0x5d046 <f.12+0x296>
   5d498:      	jmp	0x5d034 <f.12+0x284>
   5d49d:      	xorl	%edx, %edx
   5d49f:      	divl	%ecx
   5d4a1:      	testq	%rdx, %rdx
   5d4a4:      	jne	0x5d0f6 <f.12+0x346>
   5d4aa:      	jmp	0x5d0dd <f.12+0x32d>
   5d4af:      	xorl	%edx, %edx
   5d4b1:      	divl	%ecx
   5d4b3:      	testq	%rdx, %rdx
   5d4b6:      	jne	0x5d258 <f.12+0x4a8>
   5d4bc:      	jmp	0x5d246 <f.12+0x496>
   5d4c1:      	xorl	%edx, %edx
   5d4c3:      	divl	%ecx
   5d4c5:      	testq	%rdx, %rdx
   5d4c8:      	jne	0x5d323 <f.12+0x573>
   5d4ce:      	jmp	0x5d311 <f.12+0x561>
   5d4d3:      	xorl	%edx, %edx
   5d4d5:      	divl	%ecx
   5d4d7:      	testq	%rdx, %rdx
   5d4da:      	jne	0x5d3c8 <f.12+0x618>
   5d4e0:      	jmp	0x5d3b6 <f.12+0x606>
   5d4e5:      	callq	0x55920 <native_trap>
   5d4ea:      	leaq	-0x540dd(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5d4f1:      	movl	$0x2f, %esi
   5d4f6:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5d4fb:      	int3
   5d4fc:      	int3
   5d4fd:      	int3
   5d4fe:      	int3
   5d4ff:      	int3

000000000005d500 <f.13>:
   5d500:      	pushq	%r15
   5d502:      	pushq	%r14
   5d504:      	pushq	%r12
   5d506:      	pushq	%rbx
   5d507:      	subq	$0x38, %rsp
   5d50b:      	movq	%rsi, %rbx
   5d50e:      	movq	$0x3, 0x10(%rsp)
   5d517:      	movq	$0x0, 0x18(%rsp)
   5d520:      	movq	0x69a9(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5d527:      	movq	%rdx, 0x8(%rsp)
   5d52c:      	leaq	0x8(%rsp), %r14
   5d531:      	movq	%r14, 0x6998(%rip)      # 0x63ed0 <native_roots.0>
   5d538:      	movq	0x6971(%rip), %rcx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d53f:      	leaq	0x1(%rcx), %rax
   5d543:      	movq	%rax, 0x6966(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d54a:      	movq	0x6967(%rip), %rsi      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d551:      	cmpq	%rsi, %rax
   5d554:      	cmovaq	%rax, %rsi
   5d558:      	movq	%rsi, 0x6959(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d55f:      	movq	%rdi, 0x20(%rsp)
   5d564:      	movq	$0x0, 0x28(%rsp)
   5d56d:      	testq	%rdi, %rdi
   5d570:      	je	0x5d854 <f.13+0x354>
   5d576:      	movl	%edi, %eax
   5d578:      	andl	$0x1, %eax
   5d57b:      	jne	0x5d854 <f.13+0x354>
   5d581:      	movq	0x6940(%rip), %rsi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d588:      	testq	%rsi, %rsi
   5d58b:      	je	0x5d854 <f.13+0x354>
   5d591:      	movq	(%rdi), %rax
   5d594:      	movq	%rax, %r8
   5d597:      	testq	%rax, %rax
   5d59a:      	je	0x5d601 <f.13+0x101>
   5d59c:      	movq	%rax, %r8
   5d59f:      	cmpq	$0x16, %rax
   5d5a3:      	je	0x5d601 <f.13+0x101>
   5d5a5:      	movq	0x168(%rsi), %r9
   5d5ac:      	movq	%rax, %r8
   5d5af:      	shrq	$0x2, %r8
   5d5b3:      	leaq	-0x1(%r8), %r10
   5d5b7:      	cmpq	%r9, %r10
   5d5ba:      	jae	0x5d854 <f.13+0x354>
   5d5c0:      	movq	0x160(%rsi), %r10
   5d5c7:      	movq	-0x8(%r10,%r8,8), %r8
   5d5cc:      	testq	%r8, %r8
   5d5cf:      	je	0x5d601 <f.13+0x101>
   5d5d1:      	cmpq	$0x16, %r8
   5d5d5:      	je	0x5d601 <f.13+0x101>
   5d5d7:      	nopw	(%rax,%rax)
   5d5e0:      	shrq	$0x2, %r8
   5d5e4:      	leaq	-0x1(%r8), %r11
   5d5e8:      	cmpq	%r9, %r11
   5d5eb:      	jae	0x5d854 <f.13+0x354>
   5d5f1:      	movq	-0x8(%r10,%r8,8), %r8
   5d5f6:      	cmpq	$0x16, %r8
   5d5fa:      	je	0x5d601 <f.13+0x101>
   5d5fc:      	testq	%r8, %r8
   5d5ff:      	jne	0x5d5e0 <f.13+0xe0>
   5d601:      	cmpq	$0x16, %r8
   5d605:      	jne	0x5d854 <f.13+0x354>
   5d60b:      	leaq	0x68be(%rip), %r15      # 0x63ed0 <native_roots.0>
   5d612:      	jmp	0x5d630 <f.13+0x130>
   5d614:      	nopw	%cs:(%rax,%rax)
   5d620:      	incq	%rbx
   5d623:      	subq	%r8, %rcx
   5d626:      	cmpq	$0x16, %r9
   5d62a:      	jne	0x5d854 <f.13+0x354>
   5d630:      	cmpq	%rbx, 0x18(%rdi)
   5d634:      	jle	0x5d836 <f.13+0x336>
   5d63a:      	testb	$0x1, %dil
   5d63e:      	jne	0x5d854 <f.13+0x354>
   5d644:      	testq	%rax, %rax
   5d647:      	je	0x5d6b0 <f.13+0x1b0>
   5d649:      	cmpq	$0x16, %rax
   5d64d:      	je	0x5d6b0 <f.13+0x1b0>
   5d64f:      	movq	0x168(%rsi), %rcx
   5d656:      	shrq	$0x2, %rax
   5d65a:      	leaq	-0x1(%rax), %rdx
   5d65e:      	cmpq	%rcx, %rdx
   5d661:      	jae	0x5d854 <f.13+0x354>
   5d667:      	movq	0x160(%rsi), %rdx
   5d66e:      	movq	-0x8(%rdx,%rax,8), %rax
   5d673:      	testq	%rax, %rax
   5d676:      	je	0x5d6b0 <f.13+0x1b0>
   5d678:      	cmpq	$0x16, %rax
   5d67c:      	je	0x5d6b0 <f.13+0x1b0>
   5d67e:      	nop
   5d680:      	shrq	$0x2, %rax
   5d684:      	leaq	-0x1(%rax), %rsi
   5d688:      	cmpq	%rcx, %rsi
   5d68b:      	jae	0x5d854 <f.13+0x354>
   5d691:      	movq	-0x8(%rdx,%rax,8), %rax
   5d696:      	cmpq	$0x16, %rax
   5d69a:      	je	0x5d6b0 <f.13+0x1b0>
   5d69c:      	testq	%rax, %rax
   5d69f:      	jne	0x5d680 <f.13+0x180>
   5d6a1:      	nopw	%cs:(%rax,%rax)
   5d6b0:      	cmpq	$0x16, %rax
   5d6b4:      	jne	0x5d854 <f.13+0x354>
   5d6ba:      	movq	%rdi, 0x28(%rsp)
   5d6bf:      	movq	0x8(%rdi), %rax
   5d6c3:      	testq	%rax, %rax
   5d6c6:      	je	0x5d854 <f.13+0x354>
   5d6cc:      	cmpl	$0x0, 0x8(%rax)
   5d6d0:      	je	0x5d854 <f.13+0x354>
   5d6d6:      	movq	0x10(%rax), %rax
   5d6da:      	testq	%rax, %rax
   5d6dd:      	je	0x5d854 <f.13+0x354>
   5d6e3:      	movq	0x10(%rdi), %rsi
   5d6e7:      	movq	0x8(%rax), %rdi
   5d6eb:      	movq	%rdi, 0x30(%rsp)
   5d6f0:      	movq	$0x3, 0x18(%rsp)
   5d6f9:      	callq	0x5aff0 <f.18>
   5d6fe:      	subq	$0x8, %rsp
   5d702:      	movq	0x28(%rsp), %rdi
   5d707:      	testq	%rdi, %rdi
   5d70a:      	je	0x5d854 <f.13+0x354>
   5d710:      	movq	0x20(%rdi), %rax
   5d714:      	testq	%rax, %rax
   5d717:      	je	0x5d854 <f.13+0x354>
   5d71d:      	cmpl	$0x0, 0x8(%rax)
   5d721:      	je	0x5d854 <f.13+0x354>
   5d727:      	cmpq	$0x0, 0x10(%rax)
   5d72c:      	je	0x5d854 <f.13+0x354>
   5d732:      	xorl	%r8d, %r8d
   5d735:      	cmpq	$0x0, 0x10(%rsp)
   5d73b:      	setne	%r8b
   5d73f:      	movq	0x676a(%rip), %rcx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d746:      	movq	%r15, %rax
   5d749:      	cmovneq	%r14, %rax
   5d74d:      	movq	(%rax), %rdx
   5d750:      	movq	$0x3, 0x10(%rsp)
   5d759:      	movq	$0x0, 0x18(%rsp)
   5d762:      	movq	%rdx, 0x8(%rsp)
   5d767:      	movq	%r14, 0x6762(%rip)      # 0x63ed0 <native_roots.0>
   5d76e:      	movq	%r8, %rax
   5d771:      	negq	%rax
   5d774:      	addq	%rcx, %rax
   5d777:      	incq	%rax
   5d77a:      	movq	%rax, 0x672f(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d781:      	movq	0x6730(%rip), %rsi      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d788:      	cmpq	%rsi, %rax
   5d78b:      	cmovaq	%rax, %rsi
   5d78f:      	movq	%rsi, 0x6722(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d796:      	movq	%rdi, 0x20(%rsp)
   5d79b:      	movq	$0x0, 0x28(%rsp)
   5d7a4:      	testb	$0x1, %dil
   5d7a8:      	jne	0x5d854 <f.13+0x354>
   5d7ae:      	movq	0x6713(%rip), %rsi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d7b5:      	testq	%rsi, %rsi
   5d7b8:      	je	0x5d854 <f.13+0x354>
   5d7be:      	movq	(%rdi), %rax
   5d7c1:      	movq	%rax, %r9
   5d7c4:      	testq	%rax, %rax
   5d7c7:      	je	0x5d620 <f.13+0x120>
   5d7cd:      	movq	%rax, %r9
   5d7d0:      	cmpq	$0x16, %rax
   5d7d4:      	je	0x5d620 <f.13+0x120>
   5d7da:      	movq	0x168(%rsi), %r10
   5d7e1:      	movq	%rax, %r9
   5d7e4:      	shrq	$0x2, %r9
   5d7e8:      	leaq	-0x1(%r9), %r11
   5d7ec:      	cmpq	%r10, %r11
   5d7ef:      	jae	0x5d854 <f.13+0x354>
   5d7f1:      	movq	0x160(%rsi), %r11
   5d7f8:      	movq	-0x8(%r11,%r9,8), %r9
   5d7fd:      	testq	%r9, %r9
   5d800:      	je	0x5d620 <f.13+0x120>
   5d806:      	cmpq	$0x16, %r9
   5d80a:      	je	0x5d620 <f.13+0x120>
   5d810:      	shrq	$0x2, %r9
   5d814:      	leaq	-0x1(%r9), %r12
   5d818:      	cmpq	%r10, %r12
   5d81b:      	jae	0x5d854 <f.13+0x354>
   5d81d:      	movq	-0x8(%r11,%r9,8), %r9
   5d822:      	cmpq	$0x16, %r9
   5d826:      	je	0x5d620 <f.13+0x120>
   5d82c:      	testq	%r9, %r9
   5d82f:      	jne	0x5d810 <f.13+0x310>
   5d831:      	jmp	0x5d620 <f.13+0x120>
   5d836:      	movq	%rdx, 0x6693(%rip)      # 0x63ed0 <native_roots.0>
   5d83d:      	movq	%rcx, 0x666c(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d844:      	xorl	%eax, %eax
   5d846:      	addq	$0x38, %rsp
   5d84a:      	popq	%rbx
   5d84b:      	popq	%r12
   5d84d:      	popq	%r14
   5d84f:      	popq	%r15
   5d851:      	retq	$0x8
   5d854:      	callq	0x55920 <native_trap>
   5d859:      	int3
   5d85a:      	int3
   5d85b:      	int3
   5d85c:      	int3
   5d85d:      	int3
   5d85e:      	int3
   5d85f:      	int3

000000000005d860 <f.14>:
   5d860:      	pushq	%rbp
   5d861:      	pushq	%r15
   5d863:      	pushq	%r14
   5d865:      	pushq	%r13
   5d867:      	pushq	%r12
   5d869:      	pushq	%rbx
   5d86a:      	subq	$0x58, %rsp
   5d86e:      	movq	%rsi, %rbx
   5d871:      	movq	$0x6, 0x18(%rsp)
   5d87a:      	movq	$0x0, 0x20(%rsp)
   5d883:      	movq	0x6646(%rip), %rcx      # 0x63ed0 <native_roots.0>
   5d88a:      	movq	%rcx, 0x10(%rsp)
   5d88f:      	leaq	0x10(%rsp), %r8
   5d894:      	movq	0x6615(%rip), %rdx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d89b:      	leaq	0x1(%rdx), %rax
   5d89f:      	movq	0x6612(%rip), %rsi      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d8a6:      	cmpq	%rsi, %rax
   5d8a9:      	cmovaq	%rax, %rsi
   5d8ad:      	movq	%r8, 0x661c(%rip)       # 0x63ed0 <native_roots.0>
   5d8b4:      	movq	%rax, 0x65f5(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d8bb:      	movq	%rsi, 0x65f6(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d8c2:      	movq	%rdi, 0x28(%rsp)
   5d8c7:      	xorps	%xmm0, %xmm0
   5d8ca:      	movups	%xmm0, 0x30(%rsp)
   5d8cf:      	movq	$0x0, 0x40(%rsp)
   5d8d8:      	testq	%rdi, %rdi
   5d8db:      	je	0x5df05 <f.14+0x6a5>
   5d8e1:      	movl	%edi, %eax
   5d8e3:      	andl	$0x1, %eax
   5d8e6:      	jne	0x5df05 <f.14+0x6a5>
   5d8ec:      	movq	0x65d5(%rip), %r12      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d8f3:      	testq	%r12, %r12
   5d8f6:      	je	0x5df05 <f.14+0x6a5>
   5d8fc:      	movq	(%rdi), %rax
   5d8ff:      	movq	%rax, %rsi
   5d902:      	testq	%rax, %rax
   5d905:      	je	0x5d971 <f.14+0x111>
   5d907:      	movq	%rax, %rsi
   5d90a:      	cmpq	$0x1a, %rax
   5d90e:      	je	0x5d971 <f.14+0x111>
   5d910:      	movq	0x168(%r12), %r8
   5d918:      	movq	%rax, %rsi
   5d91b:      	shrq	$0x2, %rsi
   5d91f:      	leaq	-0x1(%rsi), %r9
   5d923:      	cmpq	%r8, %r9
   5d926:      	jae	0x5df05 <f.14+0x6a5>
   5d92c:      	movq	0x160(%r12), %r9
   5d934:      	movq	-0x8(%r9,%rsi,8), %rsi
   5d939:      	testq	%rsi, %rsi
   5d93c:      	je	0x5d971 <f.14+0x111>
   5d93e:      	cmpq	$0x1a, %rsi
   5d942:      	je	0x5d971 <f.14+0x111>
   5d944:      	nopw	%cs:(%rax,%rax)
   5d950:      	shrq	$0x2, %rsi
   5d954:      	leaq	-0x1(%rsi), %r10
   5d958:      	cmpq	%r8, %r10
   5d95b:      	jae	0x5df05 <f.14+0x6a5>
   5d961:      	movq	-0x8(%r9,%rsi,8), %rsi
   5d966:      	cmpq	$0x1a, %rsi
   5d96a:      	je	0x5d971 <f.14+0x111>
   5d96c:      	testq	%rsi, %rsi
   5d96f:      	jne	0x5d950 <f.14+0xf0>
   5d971:      	cmpq	$0x1a, %rsi
   5d975:      	jne	0x5df05 <f.14+0x6a5>
   5d97b:      	leaq	-0x52cb2(%rip), %r14    # 0xacd0 <object.1.0>
   5d982:      	jmp	0x5d9a0 <f.14+0x140>
   5d984:      	nopw	%cs:(%rax,%rax)
   5d990:      	incq	%rbx
   5d993:      	subq	%rsi, %rdx
   5d996:      	cmpq	$0x1a, %r8
   5d99a:      	jne	0x5df05 <f.14+0x6a5>
   5d9a0:      	cmpq	%rbx, 0x18(%rdi)
   5d9a4:      	jle	0x5dee4 <f.14+0x684>
   5d9aa:      	testb	$0x1, %dil
   5d9ae:      	jne	0x5df05 <f.14+0x6a5>
   5d9b4:      	testq	%rax, %rax
   5d9b7:      	je	0x5da20 <f.14+0x1c0>
   5d9b9:      	cmpq	$0x1a, %rax
   5d9bd:      	je	0x5da20 <f.14+0x1c0>
   5d9bf:      	movq	0x168(%r12), %rcx
   5d9c7:      	shrq	$0x2, %rax
   5d9cb:      	leaq	-0x1(%rax), %rdx
   5d9cf:      	cmpq	%rcx, %rdx
   5d9d2:      	jae	0x5df05 <f.14+0x6a5>
   5d9d8:      	movq	0x160(%r12), %rdx
   5d9e0:      	movq	-0x8(%rdx,%rax,8), %rax
   5d9e5:      	testq	%rax, %rax
   5d9e8:      	je	0x5da20 <f.14+0x1c0>
   5d9ea:      	cmpq	$0x1a, %rax
   5d9ee:      	je	0x5da20 <f.14+0x1c0>
   5d9f0:      	shrq	$0x2, %rax
   5d9f4:      	leaq	-0x1(%rax), %rsi
   5d9f8:      	cmpq	%rcx, %rsi
   5d9fb:      	jae	0x5df05 <f.14+0x6a5>
   5da01:      	movq	-0x8(%rdx,%rax,8), %rax
   5da06:      	cmpq	$0x1a, %rax
   5da0a:      	je	0x5da20 <f.14+0x1c0>
   5da0c:      	testq	%rax, %rax
   5da0f:      	jne	0x5d9f0 <f.14+0x190>
   5da11:      	nopw	%cs:(%rax,%rax)
   5da20:      	cmpq	$0x1a, %rax
   5da24:      	jne	0x5df05 <f.14+0x6a5>
   5da2a:      	movq	%rdi, 0x30(%rsp)
   5da2f:      	cmpb	$0x0, 0x6582(%rip)      # 0x63fb8 <g.5>
   5da36:      	je	0x5df05 <f.14+0x6a5>
   5da3c:      	cmpq	$0x0, 0x656c(%rip)      # 0x63fb0 <g.4>
   5da44:      	je	0x5df05 <f.14+0x6a5>
   5da4a:      	movq	0x8(%rdi), %rax
   5da4e:      	testq	%rax, %rax
   5da51:      	je	0x5df05 <f.14+0x6a5>
   5da57:      	cmpl	$0x0, 0x8(%rax)
   5da5b:      	je	0x5df05 <f.14+0x6a5>
   5da61:      	movq	0x10(%rdi), %r15
   5da65:      	movq	%r14, 0x48(%rsp)
   5da6a:      	movq	$0x5, 0x20(%rsp)
   5da73:      	movq	0x178(%r12), %rcx
   5da7b:      	leaq	0x10(%rsp), %rdx
   5da80:      	testq	%rcx, %rcx
   5da83:      	je	0x5dace <f.14+0x26e>
   5da85:      	movq	0x170(%r12), %rax
   5da8d:      	incq	%rax
   5da90:      	movq	%rax, 0x170(%r12)
   5da98:      	movq	%rax, %rdx
   5da9b:      	orq	%rcx, %rdx
   5da9e:      	shrq	$0x20, %rdx
   5daa2:      	je	0x5de80 <f.14+0x620>
   5daa8:      	xorl	%edx, %edx
   5daaa:      	divq	%rcx
   5daad:      	movq	%rdx, %rax
   5dab0:      	leaq	0x10(%rsp), %rdx
   5dab5:      	testq	%rax, %rax
   5dab8:      	jne	0x5dace <f.14+0x26e>
   5daba:      	movq	%r12, %rdi
   5dabd:      	leaq	0x10(%rsp), %rsi
   5dac2:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5dac7:      	movq	0x6402(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5dace:      	movl	$0x10, %esi
   5dad3:      	movq	%r12, %rdi
   5dad6:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5dadb:      	testq	%rax, %rax
   5dade:      	je	0x5df0a <f.14+0x6aa>
   5dae4:      	movq	%rax, %r12
   5dae7:      	movq	$0x36, (%rax)
   5daee:      	movq	%r14, 0x8(%rax)
   5daf2:      	movq	%r14, 0x48(%rsp)
   5daf7:      	movq	%rax, 0x50(%rsp)
   5dafc:      	movq	$0x6, 0x20(%rsp)
   5db05:      	movq	0x63bc(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5db0c:      	testq	%rdi, %rdi
   5db0f:      	je	0x5df05 <f.14+0x6a5>
   5db15:      	movq	0x178(%rdi), %rcx
   5db1c:      	testq	%rcx, %rcx
   5db1f:      	je	0x5db5e <f.14+0x2fe>
   5db21:      	movq	0x170(%rdi), %rax
   5db28:      	incq	%rax
   5db2b:      	movq	%rax, 0x170(%rdi)
   5db32:      	movq	%rax, %rdx
   5db35:      	orq	%rcx, %rdx
   5db38:      	shrq	$0x20, %rdx
   5db3c:      	je	0x5dea0 <f.14+0x640>
   5db42:      	xorl	%edx, %edx
   5db44:      	divq	%rcx
   5db47:      	testq	%rdx, %rdx
   5db4a:      	jne	0x5db5e <f.14+0x2fe>
   5db4c:      	movq	0x637d(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5db53:      	movq	%rdi, %r13
   5db56:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5db5b:      	movq	%r13, %rdi
   5db5e:      	movq	0x636b(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5db65:      	movl	$0x10, %esi
   5db6a:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5db6f:      	testq	%rax, %rax
   5db72:      	je	0x5df0a <f.14+0x6aa>
   5db78:      	movq	%rax, %rbp
   5db7b:      	movq	$0x36, (%rax)
   5db82:      	movq	%r14, 0x8(%rax)
   5db86:      	movq	%rax, 0x48(%rsp)
   5db8b:      	movq	%r12, 0x50(%rsp)
   5db90:      	movq	$0x6, 0x20(%rsp)
   5db99:      	movq	0x6328(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5dba0:      	testq	%rdi, %rdi
   5dba3:      	je	0x5df05 <f.14+0x6a5>
   5dba9:      	movq	0x178(%rdi), %rcx
   5dbb0:      	testq	%rcx, %rcx
   5dbb3:      	je	0x5dbf2 <f.14+0x392>
   5dbb5:      	movq	0x170(%rdi), %rax
   5dbbc:      	incq	%rax
   5dbbf:      	movq	%rax, 0x170(%rdi)
   5dbc6:      	movq	%rax, %rdx
   5dbc9:      	orq	%rcx, %rdx
   5dbcc:      	shrq	$0x20, %rdx
   5dbd0:      	je	0x5dec0 <f.14+0x660>
   5dbd6:      	xorl	%edx, %edx
   5dbd8:      	divq	%rcx
   5dbdb:      	testq	%rdx, %rdx
   5dbde:      	jne	0x5dbf2 <f.14+0x392>
   5dbe0:      	movq	0x62e9(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5dbe7:      	movq	%rdi, %r13
   5dbea:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5dbef:      	movq	%r13, %rdi
   5dbf2:      	movq	0x62d7(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5dbf9:      	movl	$0x18, %esi
   5dbfe:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5dc03:      	testq	%rax, %rax
   5dc06:      	je	0x5df0a <f.14+0x6aa>
   5dc0c:      	movq	%rax, %r13
   5dc0f:      	movq	$0x46, (%rax)
   5dc16:      	movq	%r12, 0x8(%rax)
   5dc1a:      	movq	%rbp, 0x10(%rax)
   5dc1e:      	movq	%rax, 0x38(%rsp)
   5dc23:      	movq	0x30(%rsp), %rdi
   5dc28:      	testq	%rdi, %rdi
   5dc2b:      	je	0x5df05 <f.14+0x6a5>
   5dc31:      	movq	0x8(%rdi), %rax
   5dc35:      	testq	%rax, %rax
   5dc38:      	je	0x5df05 <f.14+0x6a5>
   5dc3e:      	movq	0x10(%rax), %rax
   5dc42:      	testq	%rax, %rax
   5dc45:      	je	0x5df05 <f.14+0x6a5>
   5dc4b:      	movq	0x8(%rax), %rax
   5dc4f:      	movq	%rax, 0x40(%rsp)
   5dc54:      	testq	%r15, %r15
   5dc57:      	jle	0x5dd2d <f.14+0x4cd>
   5dc5d:      	testq	%rax, %rax
   5dc60:      	je	0x5df05 <f.14+0x6a5>
   5dc66:      	movq	0x8(%rax), %rbp
   5dc6a:      	movq	%r13, 0x48(%rsp)
   5dc6f:      	movq	%rbp, 0x50(%rsp)
   5dc74:      	movq	$0x6, 0x20(%rsp)
   5dc7d:      	movq	0x6244(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5dc84:      	testq	%rdi, %rdi
   5dc87:      	je	0x5df05 <f.14+0x6a5>
   5dc8d:      	movq	0x178(%rdi), %rcx
   5dc94:      	testq	%rcx, %rcx
   5dc97:      	je	0x5dcd6 <f.14+0x476>
   5dc99:      	movq	0x170(%rdi), %rax
   5dca0:      	incq	%rax
   5dca3:      	movq	%rax, 0x170(%rdi)
   5dcaa:      	movq	%rax, %rdx
   5dcad:      	orq	%rcx, %rdx
   5dcb0:      	shrq	$0x20, %rdx
   5dcb4:      	je	0x5ded2 <f.14+0x672>
   5dcba:      	xorl	%edx, %edx
   5dcbc:      	divq	%rcx
   5dcbf:      	testq	%rdx, %rdx
   5dcc2:      	jne	0x5dcd6 <f.14+0x476>
   5dcc4:      	movq	0x6205(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5dccb:      	movq	%rdi, %r12
   5dcce:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5dcd3:      	movq	%r12, %rdi
   5dcd6:      	movq	0x61f3(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5dcdd:      	movl	$0x18, %esi
   5dce2:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5dce7:      	testq	%rax, %rax
   5dcea:      	je	0x5df0a <f.14+0x6aa>
   5dcf0:      	movq	$0x32, (%rax)
   5dcf7:      	movq	%rbp, 0x8(%rax)
   5dcfb:      	movq	%r13, 0x10(%rax)
   5dcff:      	decq	%r15
   5dd02:      	movq	%rax, 0x48(%rsp)
   5dd07:      	movq	$0x5, 0x20(%rsp)
   5dd10:      	movq	%rax, %rdi
   5dd13:      	movq	%r15, %rsi
   5dd16:      	callq	0x5b420 <f.17>
   5dd1b:      	subq	$0x8, %rsp
   5dd1f:      	movq	0x30(%rsp), %rdi
   5dd24:      	testq	%rdi, %rdi
   5dd27:      	je	0x5df05 <f.14+0x6a5>
   5dd2d:      	movq	0x20(%rdi), %rax
   5dd31:      	testq	%rax, %rax
   5dd34:      	je	0x5df05 <f.14+0x6a5>
   5dd3a:      	cmpl	$0x0, 0x8(%rax)
   5dd3e:      	je	0x5df05 <f.14+0x6a5>
   5dd44:      	cmpq	$0x0, 0x10(%rax)
   5dd49:      	je	0x5df05 <f.14+0x6a5>
   5dd4f:      	xorl	%esi, %esi
   5dd51:      	cmpq	$0x0, 0x18(%rsp)
   5dd57:      	setne	%sil
   5dd5b:      	leaq	0x616e(%rip), %rax      # 0x63ed0 <native_roots.0>
   5dd62:      	leaq	0x10(%rsp), %r8
   5dd67:      	cmovneq	%r8, %rax
   5dd6b:      	movq	0x613e(%rip), %rdx      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5dd72:      	movq	(%rax), %rcx
   5dd75:      	movq	$0x6, 0x18(%rsp)
   5dd7e:      	movq	$0x0, 0x20(%rsp)
   5dd87:      	movq	%rcx, 0x10(%rsp)
   5dd8c:      	movq	%r8, 0x613d(%rip)       # 0x63ed0 <native_roots.0>
   5dd93:      	movq	%rsi, %rax
   5dd96:      	negq	%rax
   5dd99:      	addq	%rdx, %rax
   5dd9c:      	incq	%rax
   5dd9f:      	movq	%rax, 0x610a(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5dda6:      	movq	0x610b(%rip), %r8       # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5ddad:      	cmpq	%r8, %rax
   5ddb0:      	cmovaq	%rax, %r8
   5ddb4:      	movq	%r8, 0x60fd(%rip)       # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5ddbb:      	movq	%rdi, 0x28(%rsp)
   5ddc0:      	leaq	0x30(%rsp), %rax
   5ddc5:      	xorps	%xmm0, %xmm0
   5ddc8:      	movups	%xmm0, (%rax)
   5ddcb:      	movq	$0x0, 0x10(%rax)
   5ddd3:      	testb	$0x1, %dil
   5ddd7:      	jne	0x5df05 <f.14+0x6a5>
   5dddd:      	movq	0x60e4(%rip), %r12      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5dde4:      	testq	%r12, %r12
   5dde7:      	je	0x5df05 <f.14+0x6a5>
   5dded:      	movq	(%rdi), %rax
   5ddf0:      	movq	%rax, %r8
   5ddf3:      	testq	%rax, %rax
   5ddf6:      	je	0x5d990 <f.14+0x130>
   5ddfc:      	movq	%rax, %r8
   5ddff:      	cmpq	$0x1a, %rax
   5de03:      	je	0x5d990 <f.14+0x130>
   5de09:      	movq	0x168(%r12), %r9
   5de11:      	movq	%rax, %r8
   5de14:      	shrq	$0x2, %r8
   5de18:      	leaq	-0x1(%r8), %r10
   5de1c:      	cmpq	%r9, %r10
   5de1f:      	jae	0x5df05 <f.14+0x6a5>
   5de25:      	movq	0x160(%r12), %r10
   5de2d:      	movq	-0x8(%r10,%r8,8), %r8
   5de32:      	testq	%r8, %r8
   5de35:      	je	0x5d990 <f.14+0x130>
   5de3b:      	cmpq	$0x1a, %r8
   5de3f:      	je	0x5d990 <f.14+0x130>
   5de45:      	nopw	%cs:(%rax,%rax)
   5de50:      	shrq	$0x2, %r8
   5de54:      	leaq	-0x1(%r8), %r11
   5de58:      	cmpq	%r9, %r11
   5de5b:      	jae	0x5df05 <f.14+0x6a5>
   5de61:      	movq	-0x8(%r10,%r8,8), %r8
   5de66:      	cmpq	$0x1a, %r8
   5de6a:      	je	0x5d990 <f.14+0x130>
   5de70:      	testq	%r8, %r8
   5de73:      	jne	0x5de50 <f.14+0x5f0>
   5de75:      	jmp	0x5d990 <f.14+0x130>
   5de7a:      	nopw	(%rax,%rax)
   5de80:      	xorl	%edx, %edx
   5de82:      	divl	%ecx
   5de84:      	movl	%edx, %eax
   5de86:      	leaq	0x10(%rsp), %rdx
   5de8b:      	testq	%rax, %rax
   5de8e:      	jne	0x5dace <f.14+0x26e>
   5de94:      	jmp	0x5daba <f.14+0x25a>
   5de99:      	nopl	(%rax)
   5dea0:      	xorl	%edx, %edx
   5dea2:      	divl	%ecx
   5dea4:      	testq	%rdx, %rdx
   5dea7:      	jne	0x5db5e <f.14+0x2fe>
   5dead:      	jmp	0x5db4c <f.14+0x2ec>
   5deb2:      	nopw	%cs:(%rax,%rax)
   5dec0:      	xorl	%edx, %edx
   5dec2:      	divl	%ecx
   5dec4:      	testq	%rdx, %rdx
   5dec7:      	jne	0x5dbf2 <f.14+0x392>
   5decd:      	jmp	0x5dbe0 <f.14+0x380>
   5ded2:      	xorl	%edx, %edx
   5ded4:      	divl	%ecx
   5ded6:      	testq	%rdx, %rdx
   5ded9:      	jne	0x5dcd6 <f.14+0x476>
   5dedf:      	jmp	0x5dcc4 <f.14+0x464>
   5dee4:      	movq	%rcx, 0x5fe5(%rip)      # 0x63ed0 <native_roots.0>
   5deeb:      	movq	%rdx, 0x5fbe(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5def2:      	xorl	%eax, %eax
   5def4:      	addq	$0x58, %rsp
   5def8:      	popq	%rbx
   5def9:      	popq	%r12
   5defb:      	popq	%r13
   5defd:      	popq	%r14
   5deff:      	popq	%r15
   5df01:      	popq	%rbp
   5df02:      	retq	$0x8
   5df05:      	callq	0x55920 <native_trap>
   5df0a:      	leaq	-0x54afd(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5df11:      	movl	$0x2f, %esi
   5df16:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5df1b:      	int3
   5df1c:      	int3
   5df1d:      	int3
   5df1e:      	int3
   5df1f:      	int3

000000000005df20 <f.11>:
   5df20:      	pushq	%r15
   5df22:      	pushq	%r14
   5df24:      	pushq	%r13
   5df26:      	pushq	%r12
   5df28:      	pushq	%rbx
   5df29:      	subq	$0x40, %rsp
   5df2d:      	movq	$0x4, 0x10(%rsp)
   5df36:      	movq	$0x0, 0x18(%rsp)
   5df3f:      	movq	0x5f8a(%rip), %rax      # 0x63ed0 <native_roots.0>
   5df46:      	movq	%rax, 0x8(%rsp)
   5df4b:      	leaq	0x8(%rsp), %rax
   5df50:      	movq	%rax, 0x5f79(%rip)      # 0x63ed0 <native_roots.0>
   5df57:      	movq	0x5f52(%rip), %rax      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5df5e:      	incq	%rax
   5df61:      	movq	%rax, 0x5f48(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5df68:      	movq	0x5f49(%rip), %rcx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5df6f:      	cmpq	%rcx, %rax
   5df72:      	cmovbeq	%rcx, %rax
   5df76:      	movq	%rax, 0x5f3b(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5df7d:      	movq	%rdi, 0x20(%rsp)
   5df82:      	movq	$0x0, 0x28(%rsp)
   5df8b:      	testq	%rdi, %rdi
   5df8e:      	je	0x5e140 <f.11+0x220>
   5df94:      	movl	%edi, %eax
   5df96:      	andl	$0x1, %eax
   5df99:      	jne	0x5e140 <f.11+0x220>
   5df9f:      	movq	0x5f22(%rip), %rdx      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5dfa6:      	testq	%rdx, %rdx
   5dfa9:      	je	0x5e140 <f.11+0x220>
   5dfaf:      	movq	%rsi, %rbx
   5dfb2:      	movq	(%rdi), %rax
   5dfb5:      	testq	%rax, %rax
   5dfb8:      	je	0x5e011 <f.11+0xf1>
   5dfba:      	cmpq	$0x2a, %rax
   5dfbe:      	je	0x5e011 <f.11+0xf1>
   5dfc0:      	movq	0x168(%rdx), %rcx
   5dfc7:      	shrq	$0x2, %rax
   5dfcb:      	leaq	-0x1(%rax), %rsi
   5dfcf:      	cmpq	%rcx, %rsi
   5dfd2:      	jae	0x5e140 <f.11+0x220>
   5dfd8:      	movq	0x160(%rdx), %rdx
   5dfdf:      	movq	-0x8(%rdx,%rax,8), %rax
   5dfe4:      	testq	%rax, %rax
   5dfe7:      	je	0x5e011 <f.11+0xf1>
   5dfe9:      	cmpq	$0x2a, %rax
   5dfed:      	je	0x5e011 <f.11+0xf1>
   5dfef:      	nop
   5dff0:      	shrq	$0x2, %rax
   5dff4:      	leaq	-0x1(%rax), %rsi
   5dff8:      	cmpq	%rcx, %rsi
   5dffb:      	jae	0x5e140 <f.11+0x220>
   5e001:      	movq	-0x8(%rdx,%rax,8), %rax
   5e006:      	cmpq	$0x2a, %rax
   5e00a:      	je	0x5e011 <f.11+0xf1>
   5e00c:      	testq	%rax, %rax
   5e00f:      	jne	0x5dff0 <f.11+0xd0>
   5e011:      	cmpq	$0x2a, %rax
   5e015:      	jne	0x5e140 <f.11+0x220>
   5e01b:      	movq	%rdi, 0x28(%rsp)
   5e020:      	movq	0x18(%rdi), %rax
   5e024:      	testq	%rax, %rax
   5e027:      	je	0x5e140 <f.11+0x220>
   5e02d:      	movq	0x8(%rax), %rax
   5e031:      	testq	%rax, %rax
   5e034:      	je	0x5e140 <f.11+0x220>
   5e03a:      	movq	0x8(%rax), %rdi
   5e03e:      	movq	%rdi, 0x30(%rsp)
   5e043:      	movq	$0x3, 0x18(%rsp)
   5e04c:      	movq	%rbx, %rsi
   5e04f:      	callq	0x5c770 <f.15>
   5e054:      	subq	$0x8, %rsp
   5e058:      	movq	%rax, %r14
   5e05b:      	movq	0x28(%rsp), %rax
   5e060:      	testq	%rax, %rax
   5e063:      	je	0x5e140 <f.11+0x220>
   5e069:      	movq	0x8(%rax), %r12
   5e06d:      	movq	0x10(%rax), %r13
   5e071:      	movq	%r13, 0x30(%rsp)
   5e076:      	movq	%r12, 0x38(%rsp)
   5e07b:      	movq	$0x4, 0x18(%rsp)
   5e084:      	movq	0x5e3d(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e08b:      	testq	%rdi, %rdi
   5e08e:      	je	0x5e140 <f.11+0x220>
   5e094:      	movq	0x178(%rdi), %rcx
   5e09b:      	testq	%rcx, %rcx
   5e09e:      	je	0x5e0d9 <f.11+0x1b9>
   5e0a0:      	movq	0x170(%rdi), %rax
   5e0a7:      	incq	%rax
   5e0aa:      	movq	%rax, 0x170(%rdi)
   5e0b1:      	movq	%rax, %rdx
   5e0b4:      	orq	%rcx, %rdx
   5e0b7:      	shrq	$0x20, %rdx
   5e0bb:      	je	0x5e135 <f.11+0x215>
   5e0bd:      	xorl	%edx, %edx
   5e0bf:      	divq	%rcx
   5e0c2:      	testq	%rdx, %rdx
   5e0c5:      	jne	0x5e0d9 <f.11+0x1b9>
   5e0c7:      	movq	0x5e02(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5e0ce:      	movq	%rdi, %r15
   5e0d1:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e0d6:      	movq	%r15, %rdi
   5e0d9:      	movq	0x5df0(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5e0e0:      	movl	$0x20, %esi
   5e0e5:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e0ea:      	testq	%rax, %rax
   5e0ed:      	je	0x5e145 <f.11+0x225>
   5e0ef:      	movq	$0x22, (%rax)
   5e0f6:      	movq	%r12, 0x8(%rax)
   5e0fa:      	movq	%r13, 0x10(%rax)
   5e0fe:      	movq	%rbx, 0x18(%rax)
   5e102:      	cmpq	$0x0, 0x10(%rsp)
   5e108:      	je	0x5e11d <f.11+0x1fd>
   5e10a:      	movq	0x8(%rsp), %rcx
   5e10f:      	movq	%rcx, 0x5dba(%rip)      # 0x63ed0 <native_roots.0>
   5e116:      	decq	0x5d93(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5e11d:      	movq	%rax, %rdi
   5e120:      	movq	%r14, %rsi
   5e123:      	addq	$0x40, %rsp
   5e127:      	popq	%rbx
   5e128:      	popq	%r12
   5e12a:      	popq	%r13
   5e12c:      	popq	%r14
   5e12e:      	popq	%r15
   5e130:      	jmp	0x5cdb0 <f.12>
   5e135:      	xorl	%edx, %edx
   5e137:      	divl	%ecx
   5e139:      	testq	%rdx, %rdx
   5e13c:      	jne	0x5e0d9 <f.11+0x1b9>
   5e13e:      	jmp	0x5e0c7 <f.11+0x1a7>
   5e140:      	callq	0x55920 <native_trap>
   5e145:      	leaq	-0x54d38(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5e14c:      	movl	$0x2f, %esi
   5e151:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5e156:      	int3
   5e157:      	int3
   5e158:      	int3
   5e159:      	int3
   5e15a:      	int3
   5e15b:      	int3
   5e15c:      	int3
   5e15d:      	int3
   5e15e:      	int3
   5e15f:      	int3

000000000005e160 <f.16>:
   5e160:      	pushq	%rbp
   5e161:      	pushq	%r14
   5e163:      	pushq	%rbx
   5e164:      	testq	%rdi, %rdi
   5e167:      	je	0x5e4e7 <f.16+0x387>
   5e16d:      	movl	%edi, %eax
   5e16f:      	andl	$0x1, %eax
   5e172:      	jne	0x5e4e7 <f.16+0x387>
   5e178:      	movq	0x5d49(%rip), %rdx      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e17f:      	testq	%rdx, %rdx
   5e182:      	je	0x5e4e7 <f.16+0x387>
   5e188:      	movq	(%rdi), %rax
   5e18b:      	movq	%rax, %rcx
   5e18e:      	testq	%rax, %rax
   5e191:      	je	0x5e1f1 <f.16+0x91>
   5e193:      	movq	%rax, %rcx
   5e196:      	cmpq	$0x2e, %rax
   5e19a:      	je	0x5e1f1 <f.16+0x91>
   5e19c:      	movq	0x168(%rdx), %r8
   5e1a3:      	movq	%rax, %rcx
   5e1a6:      	shrq	$0x2, %rcx
   5e1aa:      	leaq	-0x1(%rcx), %r9
   5e1ae:      	cmpq	%r8, %r9
   5e1b1:      	jae	0x5e4e7 <f.16+0x387>
   5e1b7:      	movq	0x160(%rdx), %r9
   5e1be:      	movq	-0x8(%r9,%rcx,8), %rcx
   5e1c3:      	testq	%rcx, %rcx
   5e1c6:      	je	0x5e1f1 <f.16+0x91>
   5e1c8:      	cmpq	$0x2e, %rcx
   5e1cc:      	je	0x5e1f1 <f.16+0x91>
   5e1ce:      	nop
   5e1d0:      	shrq	$0x2, %rcx
   5e1d4:      	leaq	-0x1(%rcx), %r10
   5e1d8:      	cmpq	%r8, %r10
   5e1db:      	jae	0x5e4e7 <f.16+0x387>
   5e1e1:      	movq	-0x8(%r9,%rcx,8), %rcx
   5e1e6:      	cmpq	$0x2e, %rcx
   5e1ea:      	je	0x5e1f1 <f.16+0x91>
   5e1ec:      	testq	%rcx, %rcx
   5e1ef:      	jne	0x5e1d0 <f.16+0x70>
   5e1f1:      	cmpq	$0x2e, %rcx
   5e1f5:      	jne	0x5e4e7 <f.16+0x387>
   5e1fb:      	movzbl	0x5e26(%rip), %ecx      # 0x64028 <g.19>
   5e202:      	movsd	-0x58332(%rip), %xmm0   # 0x5ed8 <writev+0x5ed8>
   5e20a:      	jmp	0x5e219 <f.16+0xb9>
   5e20c:      	nopl	(%rax)
   5e210:      	testb	%r8b, %r8b
   5e213:      	je	0x5e4e7 <f.16+0x387>
   5e219:      	movq	%rsi, %r8
   5e21c:      	movq	0x8(%rdi), %rsi
   5e220:      	movq	%rsi, %r9
   5e223:      	shrq	$0x3f, %r9
   5e227:      	addq	%rsi, %r9
   5e22a:      	sarq	%r9
   5e22d:      	cmpq	%r8, %r9
   5e230:      	jle	0x5e4ec <f.16+0x38c>
   5e236:      	testq	%rax, %rax
   5e239:      	je	0x5e2a0 <f.16+0x140>
   5e23b:      	cmpq	$0x2e, %rax
   5e23f:      	je	0x5e2a0 <f.16+0x140>
   5e241:      	movq	0x168(%rdx), %rsi
   5e248:      	shrq	$0x2, %rax
   5e24c:      	leaq	-0x1(%rax), %r9
   5e250:      	cmpq	%rsi, %r9
   5e253:      	jae	0x5e4e7 <f.16+0x387>
   5e259:      	movq	0x160(%rdx), %rdx
   5e260:      	movq	-0x8(%rdx,%rax,8), %rax
   5e265:      	testq	%rax, %rax
   5e268:      	je	0x5e2a0 <f.16+0x140>
   5e26a:      	cmpq	$0x2e, %rax
   5e26e:      	je	0x5e2a0 <f.16+0x140>
   5e270:      	shrq	$0x2, %rax
   5e274:      	leaq	-0x1(%rax), %r9
   5e278:      	cmpq	%rsi, %r9
   5e27b:      	jae	0x5e4e7 <f.16+0x387>
   5e281:      	movq	-0x8(%rdx,%rax,8), %rax
   5e286:      	cmpq	$0x2e, %rax
   5e28a:      	je	0x5e2a0 <f.16+0x140>
   5e28c:      	testq	%rax, %rax
   5e28f:      	jne	0x5e270 <f.16+0x110>
   5e291:      	nopw	%cs:(%rax,%rax)
   5e2a0:      	cmpq	$0x2e, %rax
   5e2a4:      	jne	0x5e4e7 <f.16+0x387>
   5e2aa:      	testb	$0x1, %cl
   5e2ad:      	je	0x5e4e7 <f.16+0x387>
   5e2b3:      	cmpq	$0x0, 0x5d65(%rip)      # 0x64020 <g.18>
   5e2bb:      	je	0x5e4e7 <f.16+0x387>
   5e2c1:      	movq	%r8, %rax
   5e2c4:      	shrq	$0x20, %rax
   5e2c8:      	jne	0x5e4e7 <f.16+0x387>
   5e2ce:      	movq	0x10(%rdi), %rax
   5e2d2:      	testq	%rax, %rax
   5e2d5:      	je	0x5e4e7 <f.16+0x387>
   5e2db:      	testb	$0x1, %al
   5e2dd:      	jne	0x5e4e7 <f.16+0x387>
   5e2e3:      	cmpq	0x8(%rax), %r8
   5e2e7:      	jae	0x5e4e7 <f.16+0x387>
   5e2ed:      	leaq	0x1(%r8), %rsi
   5e2f1:      	xorps	%xmm1, %xmm1
   5e2f4:      	cvtsi2sd	%rsi, %xmm1
   5e2f9:      	movapd	%xmm0, %xmm2
   5e2fd:      	divsd	%xmm1, %xmm2
   5e301:      	movsd	%xmm2, 0x10(%rax,%r8,8)
   5e308:      	movq	0x5bb9(%rip), %rdx      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e30f:      	testq	%rdx, %rdx
   5e312:      	je	0x5e4e7 <f.16+0x387>
   5e318:      	movq	(%rdi), %rax
   5e31b:      	cmpq	$0x2e, %rax
   5e31f:      	sete	%r8b
   5e323:      	movl	%r8d, %ebx
   5e326:      	testq	%rax, %rax
   5e329:      	je	0x5e380 <f.16+0x220>
   5e32b:      	movl	%r8d, %ebx
   5e32e:      	cmpq	$0x2e, %rax
   5e332:      	je	0x5e380 <f.16+0x220>
   5e334:      	movq	0x168(%rdx), %r9
   5e33b:      	movq	%rax, %r10
   5e33e:      	shrq	$0x2, %r10
   5e342:      	leaq	-0x1(%r10), %r11
   5e346:      	cmpq	%r9, %r11
   5e349:      	jae	0x5e4e7 <f.16+0x387>
   5e34f:      	movq	0x160(%rdx), %r11
   5e356:      	movq	-0x8(%r11,%r10,8), %r10
   5e35b:      	cmpq	$0x2e, %r10
   5e35f:      	sete	%bl
   5e362:      	testq	%r10, %r10
   5e365:      	je	0x5e380 <f.16+0x220>
   5e367:      	cmpq	$0x2e, %r10
   5e36b:      	jne	0x5e490 <f.16+0x330>
   5e371:      	nopw	%cs:(%rax,%rax)
   5e380:      	testb	%bl, %bl
   5e382:      	je	0x5e4e7 <f.16+0x387>
   5e388:      	movq	0x18(%rdi), %r9
   5e38c:      	testq	%r9, %r9
   5e38f:      	je	0x5e4e7 <f.16+0x387>
   5e395:      	cmpl	$0x0, 0x8(%r9)
   5e39a:      	je	0x5e4e7 <f.16+0x387>
   5e3a0:      	movl	%r8d, %ebp
   5e3a3:      	testq	%rax, %rax
   5e3a6:      	je	0x5e3f0 <f.16+0x290>
   5e3a8:      	movl	%r8d, %ebp
   5e3ab:      	cmpq	$0x2e, %rax
   5e3af:      	je	0x5e3f0 <f.16+0x290>
   5e3b1:      	movq	0x168(%rdx), %r10
   5e3b8:      	movq	%rax, %r11
   5e3bb:      	shrq	$0x2, %r11
   5e3bf:      	leaq	-0x1(%r11), %rbx
   5e3c3:      	cmpq	%r10, %rbx
   5e3c6:      	jae	0x5e4e7 <f.16+0x387>
   5e3cc:      	movq	0x160(%rdx), %rbx
   5e3d3:      	movq	-0x8(%rbx,%r11,8), %r11
   5e3d8:      	cmpq	$0x2e, %r11
   5e3dc:      	sete	%bpl
   5e3e0:      	testq	%r11, %r11
   5e3e3:      	je	0x5e3f0 <f.16+0x290>
   5e3e5:      	cmpq	$0x2e, %r11
   5e3e9:      	jne	0x5e4c0 <f.16+0x360>
   5e3ef:      	nop
   5e3f0:      	testb	%bpl, %bpl
   5e3f3:      	je	0x5e4e7 <f.16+0x387>
   5e3f9:      	cmpq	$0x0, 0x10(%r9)
   5e3fe:      	je	0x5e4e7 <f.16+0x387>
   5e404:      	testq	%rax, %rax
   5e407:      	je	0x5e210 <f.16+0xb0>
   5e40d:      	cmpq	$0x2e, %rax
   5e411:      	je	0x5e210 <f.16+0xb0>
   5e417:      	movq	0x168(%rdx), %r9
   5e41e:      	movq	%rax, %r8
   5e421:      	shrq	$0x2, %r8
   5e425:      	leaq	-0x1(%r8), %r10
   5e429:      	cmpq	%r9, %r10
   5e42c:      	jae	0x5e4e7 <f.16+0x387>
   5e432:      	movq	0x160(%rdx), %r11
   5e439:      	movq	-0x8(%r11,%r8,8), %r10
   5e43e:      	cmpq	$0x2e, %r10
   5e442:      	sete	%r8b
   5e446:      	testq	%r10, %r10
   5e449:      	je	0x5e210 <f.16+0xb0>
   5e44f:      	cmpq	$0x2e, %r10
   5e453:      	je	0x5e210 <f.16+0xb0>
   5e459:      	nopl	(%rax)
   5e460:      	shrq	$0x2, %r10
   5e464:      	leaq	-0x1(%r10), %r8
   5e468:      	cmpq	%r9, %r8
   5e46b:      	jae	0x5e4e7 <f.16+0x387>
   5e46d:      	movq	-0x8(%r11,%r10,8), %r10
   5e472:      	cmpq	$0x2e, %r10
   5e476:      	je	0x5e47d <f.16+0x31d>
   5e478:      	testq	%r10, %r10
   5e47b:      	jne	0x5e460 <f.16+0x300>
   5e47d:      	cmpq	$0x2e, %r10
   5e481:      	je	0x5e219 <f.16+0xb9>
   5e487:      	jmp	0x5e4e7 <f.16+0x387>
   5e489:      	nopl	(%rax)
   5e490:      	shrq	$0x2, %r10
   5e494:      	leaq	-0x1(%r10), %rbx
   5e498:      	cmpq	%r9, %rbx
   5e49b:      	jae	0x5e4e7 <f.16+0x387>
   5e49d:      	movq	-0x8(%r11,%r10,8), %r10
   5e4a2:      	cmpq	$0x2e, %r10
   5e4a6:      	je	0x5e4ad <f.16+0x34d>
   5e4a8:      	testq	%r10, %r10
   5e4ab:      	jne	0x5e490 <f.16+0x330>
   5e4ad:      	cmpq	$0x2e, %r10
   5e4b1:      	je	0x5e388 <f.16+0x228>
   5e4b7:      	jmp	0x5e4e7 <f.16+0x387>
   5e4b9:      	nopl	(%rax)
   5e4c0:      	shrq	$0x2, %r11
   5e4c4:      	leaq	-0x1(%r11), %r14
   5e4c8:      	cmpq	%r10, %r14
   5e4cb:      	jae	0x5e4e7 <f.16+0x387>
   5e4cd:      	movq	-0x8(%rbx,%r11,8), %r11
   5e4d2:      	cmpq	$0x2e, %r11
   5e4d6:      	je	0x5e4dd <f.16+0x37d>
   5e4d8:      	testq	%r11, %r11
   5e4db:      	jne	0x5e4c0 <f.16+0x360>
   5e4dd:      	cmpq	$0x2e, %r11
   5e4e1:      	je	0x5e3f9 <f.16+0x299>
   5e4e7:      	callq	0x55920 <native_trap>
   5e4ec:      	xorl	%eax, %eax
   5e4ee:      	popq	%rbx
   5e4ef:      	popq	%r14
   5e4f1:      	popq	%rbp
   5e4f2:      	retq	$0x8
   5e4f5:      	int3
   5e4f6:      	int3
   5e4f7:      	int3
   5e4f8:      	int3
   5e4f9:      	int3
   5e4fa:      	int3
   5e4fb:      	int3
   5e4fc:      	int3
   5e4fd:      	int3
   5e4fe:      	int3
   5e4ff:      	int3

000000000005e500 <f.19>:
   5e500:      	pushq	%rax
   5e501:      	testq	%rsi, %rsi
   5e504:      	je	0x5e52a <f.19+0x2a>
   5e506:      	testq	%rdi, %rdi
   5e509:      	je	0x5e531 <f.19+0x31>
   5e50b:      	movq	0x8(%rdi), %rax
   5e50f:      	nop
   5e510:      	testq	%rax, %rax
   5e513:      	je	0x5e531 <f.19+0x31>
   5e515:      	cmpl	$0x0, 0x8(%rax)
   5e519:      	je	0x5e531 <f.19+0x31>
   5e51b:      	cmpq	$0x0, 0x10(%rax)
   5e520:      	je	0x5e531 <f.19+0x31>
   5e522:      	addq	%rdx, %rdx
   5e525:      	decq	%rsi
   5e528:      	jne	0x5e510 <f.19+0x10>
   5e52a:      	movq	%rdx, %rax
   5e52d:      	popq	%rcx
   5e52e:      	retq	$0x8
   5e531:      	callq	0x55920 <native_trap>
   5e536:      	int3
   5e537:      	int3
   5e538:      	int3
   5e539:      	int3
   5e53a:      	int3
   5e53b:      	int3
   5e53c:      	int3
   5e53d:      	int3
   5e53e:      	int3
   5e53f:      	int3

000000000005e540 <f.7>:
   5e540:      	pushq	%r15
   5e542:      	pushq	%r14
   5e544:      	pushq	%r13
   5e546:      	pushq	%r12
   5e548:      	pushq	%rbx
   5e549:      	subq	$0x50, %rsp
   5e54d:      	movq	$0x6, 0x10(%rsp)
   5e556:      	movq	$0x0, 0x18(%rsp)
   5e55f:      	movq	0x596a(%rip), %rax      # 0x63ed0 <native_roots.0>
   5e566:      	movq	%rax, 0x8(%rsp)
   5e56b:      	movq	0x593e(%rip), %rax      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5e572:      	incq	%rax
   5e575:      	movq	%rax, 0x5934(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5e57c:      	movq	0x5935(%rip), %rcx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5e583:      	cmpq	%rcx, %rax
   5e586:      	cmovbeq	%rcx, %rax
   5e58a:      	leaq	0x8(%rsp), %rcx
   5e58f:      	movq	%rcx, 0x593a(%rip)      # 0x63ed0 <native_roots.0>
   5e596:      	movq	%rax, 0x591b(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5e59d:      	movq	%rdi, 0x20(%rsp)
   5e5a2:      	xorps	%xmm0, %xmm0
   5e5a5:      	movups	%xmm0, 0x28(%rsp)
   5e5aa:      	cmpb	$0x0, 0x5a57(%rip)      # 0x64008 <g.15>
   5e5b1:      	je	0x5ec62 <f.7+0x722>
   5e5b7:      	cmpq	$0x0, 0x5a41(%rip)      # 0x64000 <g.14>
   5e5bf:      	je	0x5ec62 <f.7+0x722>
   5e5c5:      	movq	$0x3, 0x18(%rsp)
   5e5ce:      	movq	0x58f3(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e5d5:      	testq	%rdi, %rdi
   5e5d8:      	je	0x5ec62 <f.7+0x722>
   5e5de:      	movq	%rsi, %rbx
   5e5e1:      	movq	0x178(%rdi), %rsi
   5e5e8:      	testq	%rsi, %rsi
   5e5eb:      	je	0x5e62f <f.7+0xef>
   5e5ed:      	movq	0x170(%rdi), %rax
   5e5f4:      	incq	%rax
   5e5f7:      	movq	%rax, 0x170(%rdi)
   5e5fe:      	movq	%rax, %rdx
   5e601:      	orq	%rsi, %rdx
   5e604:      	shrq	$0x20, %rdx
   5e608:      	je	0x5ebc0 <f.7+0x680>
   5e60e:      	xorl	%edx, %edx
   5e610:      	divq	%rsi
   5e613:      	testq	%rdx, %rdx
   5e616:      	jne	0x5e62f <f.7+0xef>
   5e618:      	leaq	0x8(%rsp), %rsi
   5e61d:      	movq	%rdi, %r14
   5e620:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e625:      	movq	%r14, %rdi
   5e628:      	movq	0x58a1(%rip), %rcx      # 0x63ed0 <native_roots.0>
   5e62f:      	movl	$0x18, %esi
   5e634:      	movq	%rcx, %rdx
   5e637:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e63c:      	testq	%rax, %rax
   5e63f:      	je	0x5ec67 <f.7+0x727>
   5e645:      	movq	%rax, %r14
   5e648:      	movq	$0x7a, (%rax)
   5e64f:      	movl	$0x0, 0x8(%rax)
   5e656:      	movq	$0x0, 0x10(%rax)
   5e65e:      	movq	%rax, 0x28(%rsp)
   5e663:      	movq	%rax, 0x38(%rsp)
   5e668:      	leaq	0x3729(%rip), %r13      # 0x61d98 <ref.19>
   5e66f:      	movq	%r13, 0x40(%rsp)
   5e674:      	movq	%rax, 0x48(%rsp)
   5e679:      	movq	$0x6, 0x18(%rsp)
   5e682:      	movq	0x583f(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e689:      	testq	%rdi, %rdi
   5e68c:      	je	0x5ec62 <f.7+0x722>
   5e692:      	movq	0x178(%rdi), %rcx
   5e699:      	testq	%rcx, %rcx
   5e69c:      	je	0x5e6db <f.7+0x19b>
   5e69e:      	movq	0x170(%rdi), %rax
   5e6a5:      	incq	%rax
   5e6a8:      	movq	%rax, 0x170(%rdi)
   5e6af:      	movq	%rax, %rdx
   5e6b2:      	orq	%rcx, %rdx
   5e6b5:      	shrq	$0x20, %rdx
   5e6b9:      	je	0x5ebd2 <f.7+0x692>
   5e6bf:      	xorl	%edx, %edx
   5e6c1:      	divq	%rcx
   5e6c4:      	testq	%rdx, %rdx
   5e6c7:      	jne	0x5e6db <f.7+0x19b>
   5e6c9:      	movq	0x5800(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5e6d0:      	movq	%rdi, %r15
   5e6d3:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e6d8:      	movq	%r15, %rdi
   5e6db:      	movq	0x57ee(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5e6e2:      	movl	$0x10, %esi
   5e6e7:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e6ec:      	testq	%rax, %rax
   5e6ef:      	je	0x5ec67 <f.7+0x727>
   5e6f5:      	movq	%rax, %r15
   5e6f8:      	movq	$0x72, (%rax)
   5e6ff:      	movq	%r14, 0x8(%rax)
   5e703:      	movq	%rax, 0x38(%rsp)
   5e708:      	movq	%r13, 0x40(%rsp)
   5e70d:      	movq	%r14, 0x48(%rsp)
   5e712:      	movq	$0x6, 0x18(%rsp)
   5e71b:      	movq	0x57a6(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e722:      	testq	%rdi, %rdi
   5e725:      	je	0x5ec62 <f.7+0x722>
   5e72b:      	movq	0x178(%rdi), %rcx
   5e732:      	testq	%rcx, %rcx
   5e735:      	je	0x5e774 <f.7+0x234>
   5e737:      	movq	0x170(%rdi), %rax
   5e73e:      	incq	%rax
   5e741:      	movq	%rax, 0x170(%rdi)
   5e748:      	movq	%rax, %rdx
   5e74b:      	orq	%rcx, %rdx
   5e74e:      	shrq	$0x20, %rdx
   5e752:      	je	0x5ebe4 <f.7+0x6a4>
   5e758:      	xorl	%edx, %edx
   5e75a:      	divq	%rcx
   5e75d:      	testq	%rdx, %rdx
   5e760:      	jne	0x5e774 <f.7+0x234>
   5e762:      	movq	0x5767(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5e769:      	movq	%rdi, %r12
   5e76c:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e771:      	movq	%r12, %rdi
   5e774:      	movq	0x5755(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5e77b:      	movl	$0x18, %esi
   5e780:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e785:      	testq	%rax, %rax
   5e788:      	je	0x5ec67 <f.7+0x727>
   5e78e:      	movq	$0x92, (%rax)
   5e795:      	movq	%r13, 0x8(%rax)
   5e799:      	movq	%r15, 0x10(%rax)
   5e79d:      	movq	%rax, 0x10(%r14)
   5e7a1:      	movq	0x28(%rsp), %rax
   5e7a6:      	testq	%rax, %rax
   5e7a9:      	je	0x5ec62 <f.7+0x722>
   5e7af:      	movl	$0x1, 0x8(%rax)
   5e7b6:      	movq	0x28(%rsp), %rax
   5e7bb:      	testq	%rax, %rax
   5e7be:      	je	0x5ec62 <f.7+0x722>
   5e7c4:      	cmpl	$0x0, 0x8(%rax)
   5e7c8:      	je	0x5ec62 <f.7+0x722>
   5e7ce:      	movq	0x10(%rax), %rax
   5e7d2:      	testq	%rax, %rax
   5e7d5:      	je	0x5ec62 <f.7+0x722>
   5e7db:      	movq	%rax, 0x30(%rsp)
   5e7e0:      	movq	0x8(%rax), %rcx
   5e7e4:      	testq	%rcx, %rcx
   5e7e7:      	je	0x5ec62 <f.7+0x722>
   5e7ed:      	leaq	-0x1(%rbx), %rsi
   5e7f1:      	movq	0x10(%rax), %rdi
   5e7f5:      	movq	0x8(%rcx), %rax
   5e7f9:      	movq	%rdi, 0x38(%rsp)
   5e7fe:      	movq	$0x4, 0x18(%rsp)
   5e807:      	movl	$0x1, %edx
   5e80c:      	callq	*%rax
   5e80e:      	subq	$0x8, %rsp
   5e812:      	movq	$0x3, 0x18(%rsp)
   5e81b:      	movq	0x56a6(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e822:      	testq	%rdi, %rdi
   5e825:      	je	0x5ec62 <f.7+0x722>
   5e82b:      	movq	%rax, %r14
   5e82e:      	movq	0x178(%rdi), %rcx
   5e835:      	testq	%rcx, %rcx
   5e838:      	je	0x5e877 <f.7+0x337>
   5e83a:      	movq	0x170(%rdi), %rax
   5e841:      	incq	%rax
   5e844:      	movq	%rax, 0x170(%rdi)
   5e84b:      	movq	%rax, %rdx
   5e84e:      	orq	%rcx, %rdx
   5e851:      	shrq	$0x20, %rdx
   5e855:      	je	0x5ebf6 <f.7+0x6b6>
   5e85b:      	xorl	%edx, %edx
   5e85d:      	divq	%rcx
   5e860:      	testq	%rdx, %rdx
   5e863:      	jne	0x5e877 <f.7+0x337>
   5e865:      	movq	0x5664(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5e86c:      	movq	%rdi, %r15
   5e86f:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e874:      	movq	%r15, %rdi
   5e877:      	movq	0x5652(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5e87e:      	movl	$0x10, %esi
   5e883:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e888:      	testq	%rax, %rax
   5e88b:      	je	0x5ec67 <f.7+0x727>
   5e891:      	movq	%rax, %r12
   5e894:      	movq	$0x96, (%rax)
   5e89b:      	movq	$0x0, 0x8(%rax)
   5e8a3:      	movq	%rax, 0x38(%rsp)
   5e8a8:      	movq	$0x4, 0x18(%rsp)
   5e8b1:      	movq	0x5610(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e8b8:      	testq	%rdi, %rdi
   5e8bb:      	je	0x5ec62 <f.7+0x722>
   5e8c1:      	movq	0x178(%rdi), %rcx
   5e8c8:      	testq	%rcx, %rcx
   5e8cb:      	je	0x5e90a <f.7+0x3ca>
   5e8cd:      	movq	0x170(%rdi), %rax
   5e8d4:      	incq	%rax
   5e8d7:      	movq	%rax, 0x170(%rdi)
   5e8de:      	movq	%rax, %rdx
   5e8e1:      	orq	%rcx, %rdx
   5e8e4:      	shrq	$0x20, %rdx
   5e8e8:      	je	0x5ec08 <f.7+0x6c8>
   5e8ee:      	xorl	%edx, %edx
   5e8f0:      	divq	%rcx
   5e8f3:      	testq	%rdx, %rdx
   5e8f6:      	jne	0x5e90a <f.7+0x3ca>
   5e8f8:      	movq	0x55d1(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5e8ff:      	movq	%rdi, %r15
   5e902:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e907:      	movq	%r15, %rdi
   5e90a:      	movq	0x55bf(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5e911:      	movl	$0x10, %esi
   5e916:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e91b:      	testq	%rax, %rax
   5e91e:      	je	0x5ec67 <f.7+0x727>
   5e924:      	movq	%rax, %r15
   5e927:      	movq	$0x6a, (%rax)
   5e92e:      	movq	%r12, 0x8(%rax)
   5e932:      	movq	%rax, 0x38(%rsp)
   5e937:      	movq	$0x4, 0x18(%rsp)
   5e940:      	movq	0x5581(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e947:      	testq	%rdi, %rdi
   5e94a:      	je	0x5ec62 <f.7+0x722>
   5e950:      	movq	0x178(%rdi), %rcx
   5e957:      	testq	%rcx, %rcx
   5e95a:      	je	0x5e999 <f.7+0x459>
   5e95c:      	movq	0x170(%rdi), %rax
   5e963:      	incq	%rax
   5e966:      	movq	%rax, 0x170(%rdi)
   5e96d:      	movq	%rax, %rdx
   5e970:      	orq	%rcx, %rdx
   5e973:      	shrq	$0x20, %rdx
   5e977:      	je	0x5ec1a <f.7+0x6da>
   5e97d:      	xorl	%edx, %edx
   5e97f:      	divq	%rcx
   5e982:      	testq	%rdx, %rdx
   5e985:      	jne	0x5e999 <f.7+0x459>
   5e987:      	movq	0x5542(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5e98e:      	movq	%rdi, %r12
   5e991:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e996:      	movq	%r12, %rdi
   5e999:      	movq	0x5530(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5e9a0:      	movl	$0x18, %esi
   5e9a5:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e9aa:      	testq	%rax, %rax
   5e9ad:      	je	0x5ec67 <f.7+0x727>
   5e9b3:      	movq	%rax, %r12
   5e9b6:      	movq	$0x66, (%rax)
   5e9bd:      	movq	%rbx, 0x8(%rax)
   5e9c1:      	movq	%r15, 0x10(%rax)
   5e9c5:      	movq	%rax, 0x38(%rsp)
   5e9ca:      	movq	$0x4, 0x18(%rsp)
   5e9d3:      	movq	0x54ee(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e9da:      	testq	%rdi, %rdi
   5e9dd:      	je	0x5ec62 <f.7+0x722>
   5e9e3:      	movq	0x178(%rdi), %rcx
   5e9ea:      	testq	%rcx, %rcx
   5e9ed:      	je	0x5ea2c <f.7+0x4ec>
   5e9ef:      	movq	0x170(%rdi), %rax
   5e9f6:      	incq	%rax
   5e9f9:      	movq	%rax, 0x170(%rdi)
   5ea00:      	movq	%rax, %rdx
   5ea03:      	orq	%rcx, %rdx
   5ea06:      	shrq	$0x20, %rdx
   5ea0a:      	je	0x5ec2c <f.7+0x6ec>
   5ea10:      	xorl	%edx, %edx
   5ea12:      	divq	%rcx
   5ea15:      	testq	%rdx, %rdx
   5ea18:      	jne	0x5ea2c <f.7+0x4ec>
   5ea1a:      	movq	0x54af(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5ea21:      	movq	%rdi, %r15
   5ea24:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5ea29:      	movq	%r15, %rdi
   5ea2c:      	movq	0x549d(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5ea33:      	movl	$0x10, %esi
   5ea38:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5ea3d:      	testq	%rax, %rax
   5ea40:      	je	0x5ec67 <f.7+0x727>
   5ea46:      	movq	%rax, %r13
   5ea49:      	movq	$0x96, (%rax)
   5ea50:      	movq	%r12, 0x8(%rax)
   5ea54:      	movq	%rax, 0x38(%rsp)
   5ea59:      	movq	$0x4, 0x18(%rsp)
   5ea62:      	movq	0x545f(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5ea69:      	testq	%rdi, %rdi
   5ea6c:      	je	0x5ec62 <f.7+0x722>
   5ea72:      	movq	0x178(%rdi), %rcx
   5ea79:      	testq	%rcx, %rcx
   5ea7c:      	je	0x5eabb <f.7+0x57b>
   5ea7e:      	movq	0x170(%rdi), %rax
   5ea85:      	incq	%rax
   5ea88:      	movq	%rax, 0x170(%rdi)
   5ea8f:      	movq	%rax, %rdx
   5ea92:      	orq	%rcx, %rdx
   5ea95:      	shrq	$0x20, %rdx
   5ea99:      	je	0x5ec3e <f.7+0x6fe>
   5ea9f:      	xorl	%edx, %edx
   5eaa1:      	divq	%rcx
   5eaa4:      	testq	%rdx, %rdx
   5eaa7:      	jne	0x5eabb <f.7+0x57b>
   5eaa9:      	movq	0x5420(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5eab0:      	movq	%rdi, %r15
   5eab3:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5eab8:      	movq	%r15, %rdi
   5eabb:      	movq	0x540e(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5eac2:      	movl	$0x10, %esi
   5eac7:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5eacc:      	testq	%rax, %rax
   5eacf:      	je	0x5ec67 <f.7+0x727>
   5ead5:      	movq	%rax, %r15
   5ead8:      	movq	$0x6a, (%rax)
   5eadf:      	movq	%r13, 0x8(%rax)
   5eae3:      	movq	%rax, 0x38(%rsp)
   5eae8:      	movq	$0x4, 0x18(%rsp)
   5eaf1:      	movq	0x53d0(%rip), %rdi      # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5eaf8:      	testq	%rdi, %rdi
   5eafb:      	je	0x5ec62 <f.7+0x722>
   5eb01:      	movq	0x178(%rdi), %rcx
   5eb08:      	testq	%rcx, %rcx
   5eb0b:      	je	0x5eb4a <f.7+0x60a>
   5eb0d:      	movq	0x170(%rdi), %rax
   5eb14:      	incq	%rax
   5eb17:      	movq	%rax, 0x170(%rdi)
   5eb1e:      	movq	%rax, %rdx
   5eb21:      	orq	%rcx, %rdx
   5eb24:      	shrq	$0x20, %rdx
   5eb28:      	je	0x5ec50 <f.7+0x710>
   5eb2e:      	xorl	%edx, %edx
   5eb30:      	divq	%rcx
   5eb33:      	testq	%rdx, %rdx
   5eb36:      	jne	0x5eb4a <f.7+0x60a>
   5eb38:      	movq	0x5391(%rip), %rsi      # 0x63ed0 <native_roots.0>
   5eb3f:      	movq	%rdi, %r12
   5eb42:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5eb47:      	movq	%r12, %rdi
   5eb4a:      	movq	0x537f(%rip), %rdx      # 0x63ed0 <native_roots.0>
   5eb51:      	movl	$0x28, %esi
   5eb56:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5eb5b:      	testq	%rax, %rax
   5eb5e:      	je	0x5ec67 <f.7+0x727>
   5eb64:      	leaq	-0x4(,%r14,4), %rcx
   5eb6c:      	movq	$0x62, (%rax)
   5eb73:      	movq	%rbx, 0x8(%rax)
   5eb77:      	addq	$-0x2, %rbx
   5eb7b:      	movq	%rbx, 0x10(%rax)
   5eb7f:      	movq	%rcx, 0x18(%rax)
   5eb83:      	movq	%r15, 0x20(%rax)
   5eb87:      	cmpq	$0x0, 0x10(%rsp)
   5eb8d:      	je	0x5eba2 <f.7+0x662>
   5eb8f:      	movq	0x8(%rsp), %rcx
   5eb94:      	movq	%rcx, 0x5335(%rip)      # 0x63ed0 <native_roots.0>
   5eb9b:      	decq	0x530e(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5eba2:      	movq	%rax, %rdi
   5eba5:      	callq	0x59960 <f.8>
   5ebaa:      	subq	$0x8, %rsp
   5ebae:      	xorl	%eax, %eax
   5ebb0:      	addq	$0x50, %rsp
   5ebb4:      	popq	%rbx
   5ebb5:      	popq	%r12
   5ebb7:      	popq	%r13
   5ebb9:      	popq	%r14
   5ebbb:      	popq	%r15
   5ebbd:      	retq	$0x8
   5ebc0:      	xorl	%edx, %edx
   5ebc2:      	divl	%esi
   5ebc4:      	testq	%rdx, %rdx
   5ebc7:      	jne	0x5e62f <f.7+0xef>
   5ebcd:      	jmp	0x5e618 <f.7+0xd8>
   5ebd2:      	xorl	%edx, %edx
   5ebd4:      	divl	%ecx
   5ebd6:      	testq	%rdx, %rdx
   5ebd9:      	jne	0x5e6db <f.7+0x19b>
   5ebdf:      	jmp	0x5e6c9 <f.7+0x189>
   5ebe4:      	xorl	%edx, %edx
   5ebe6:      	divl	%ecx
   5ebe8:      	testq	%rdx, %rdx
   5ebeb:      	jne	0x5e774 <f.7+0x234>
   5ebf1:      	jmp	0x5e762 <f.7+0x222>
   5ebf6:      	xorl	%edx, %edx
   5ebf8:      	divl	%ecx
   5ebfa:      	testq	%rdx, %rdx
   5ebfd:      	jne	0x5e877 <f.7+0x337>
   5ec03:      	jmp	0x5e865 <f.7+0x325>
   5ec08:      	xorl	%edx, %edx
   5ec0a:      	divl	%ecx
   5ec0c:      	testq	%rdx, %rdx
   5ec0f:      	jne	0x5e90a <f.7+0x3ca>
   5ec15:      	jmp	0x5e8f8 <f.7+0x3b8>
   5ec1a:      	xorl	%edx, %edx
   5ec1c:      	divl	%ecx
   5ec1e:      	testq	%rdx, %rdx
   5ec21:      	jne	0x5e999 <f.7+0x459>
   5ec27:      	jmp	0x5e987 <f.7+0x447>
   5ec2c:      	xorl	%edx, %edx
   5ec2e:      	divl	%ecx
   5ec30:      	testq	%rdx, %rdx
   5ec33:      	jne	0x5ea2c <f.7+0x4ec>
   5ec39:      	jmp	0x5ea1a <f.7+0x4da>
   5ec3e:      	xorl	%edx, %edx
   5ec40:      	divl	%ecx
   5ec42:      	testq	%rdx, %rdx
   5ec45:      	jne	0x5eabb <f.7+0x57b>
   5ec4b:      	jmp	0x5eaa9 <f.7+0x569>
   5ec50:      	xorl	%edx, %edx
   5ec52:      	divl	%ecx
   5ec54:      	testq	%rdx, %rdx
   5ec57:      	jne	0x5eb4a <f.7+0x60a>
   5ec5d:      	jmp	0x5eb38 <f.7+0x5f8>
   5ec62:      	callq	0x55920 <native_trap>
   5ec67:      	leaq	-0x5585a(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   5ec6e:      	movl	$0x2f, %esi
   5ec73:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5ec78:      	int3
   5ec79:      	int3
   5ec7a:      	int3
   5ec7b:      	int3
   5ec7c:      	int3
   5ec7d:      	int3
   5ec7e:      	int3
   5ec7f:      	int3

000000000005ec80 <f.6>:
   5ec80:      	movq	$0x1, -0x18(%rsp)
   5ec89:      	movq	0x5240(%rip), %rax      # 0x63ed0 <native_roots.0>
   5ec90:      	movq	%rax, -0x20(%rsp)
   5ec95:      	leaq	-0x20(%rsp), %rax
   5ec9a:      	movq	%rax, 0x522f(%rip)      # 0x63ed0 <native_roots.0>
   5eca1:      	movq	0x5208(%rip), %rax      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5eca8:      	incq	%rax
   5ecab:      	movq	%rax, 0x51fe(%rip)      # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5ecb2:      	movq	0x51ff(%rip), %rcx      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5ecb9:      	cmpq	%rcx, %rax
   5ecbc:      	cmovbeq	%rcx, %rax
   5ecc0:      	movq	%rax, 0x51f1(%rip)      # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5ecc7:      	movq	%rdi, -0x8(%rsp)
   5eccc:      	movq	$0x1, -0x10(%rsp)
   5ecd5:      	movq	%rdx, -0x28(%rsp)
   5ecda:      	leaq	-0x28(%rsp), %rax
   5ecdf:      	movq	-0x28(%rsp), %rax
   5ece4:      	cmpq	$0x0, -0x18(%rsp)
   5ecea:      	je	0x5ecff <f.6+0x7f>
   5ecec:      	movq	-0x20(%rsp), %rcx
   5ecf1:      	movq	%rcx, 0x51d8(%rip)      # 0x63ed0 <native_roots.0>
   5ecf8:      	decq	0x51b1(%rip)            # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5ecff:      	retq	$0x8
   5ed02:      	int3
   5ed03:      	int3
   5ed04:      	int3
   5ed05:      	int3
   5ed06:      	int3
   5ed07:      	int3
   5ed08:      	int3
   5ed09:      	int3
   5ed0a:      	int3
   5ed0b:      	int3
   5ed0c:      	int3
   5ed0d:      	int3
   5ed0e:      	int3
   5ed0f:      	int3

000000000005ed10 <f.9>:
   5ed10:      	movq	%rdx, %rax
   5ed13:      	cmpq	%rdx, %rsi
   5ed16:      	cmovlq	%rsi, %rax
   5ed1a:      	retq	$0x8

Disassembly of section .init:
