0000000000057e70 <f.2>:
   57e70:      	pushq	%rbp
   57e71:      	pushq	%r15
   57e73:      	pushq	%r14
   57e75:      	pushq	%r13
   57e77:      	pushq	%r12
   57e79:      	pushq	%rbx
   57e7a:      	subq	$0x78, %rsp
   57e7e:      	movq	%rsi, %rbx
   57e81:      	movq	$0x9, 0x18(%rsp)
   57e8a:      	movq	$0x0, 0x20(%rsp)
   57e93:      	movq	0x65ae(%rip), %rcx      # 0x5e448 <native_roots.0>
   57e9a:      	movq	%rcx, 0x10(%rsp)
   57e9f:      	leaq	0x10(%rsp), %r9
   57ea4:      	movq	0x657d(%rip), %rax      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   57eab:      	leaq	0x1(%rax), %rsi
   57eaf:      	movq	0x657a(%rip), %r8       # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   57eb6:      	cmpq	%r8, %rsi
   57eb9:      	cmovaq	%rsi, %r8
   57ebd:      	movq	%r9, 0x6584(%rip)       # 0x5e448 <native_roots.0>
   57ec4:      	movq	%rsi, 0x655d(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   57ecb:      	movq	%r8, 0x655e(%rip)       # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   57ed2:      	movq	%rdi, 0x28(%rsp)
   57ed7:      	xorps	%xmm0, %xmm0
   57eda:      	movups	%xmm0, 0x30(%rsp)
   57edf:      	movups	%xmm0, 0x40(%rsp)
   57ee4:      	testq	%rdi, %rdi
   57ee7:      	je	0x58727 <f.2+0x8b7>
   57eed:      	movq	%rdi, 0x38(%rsp)
   57ef2:      	cmpq	%rbx, 0x8(%rdi)
   57ef6:      	jle	0x58705 <f.2+0x895>
   57efc:      	nopl	(%rax)
   57f00:      	cmpb	$0x0, 0x6659(%rip)      # 0x5e560 <g.10>
   57f07:      	je	0x58727 <f.2+0x8b7>
   57f0d:      	cmpb	$0x0, 0x660c(%rip)      # 0x5e520 <g.2>
   57f14:      	je	0x58727 <f.2+0x8b7>
   57f1a:      	cmpq	$0x0, 0x65f6(%rip)      # 0x5e518 <g.1>
   57f22:      	je	0x58727 <f.2+0x8b7>
   57f28:      	movq	0x6629(%rip), %rax      # 0x5e558 <g.9>
   57f2f:      	movq	$0x5, 0x20(%rsp)
   57f38:      	movq	%rax, 0x70(%rsp)
   57f3d:      	leaq	0x70(%rsp), %rax
   57f42:      	cmpb	$0x0, 0x6607(%rip)      # 0x5e550 <g.8>
   57f49:      	je	0x58727 <f.2+0x8b7>
   57f4f:      	cmpq	$0x0, 0x65f1(%rip)      # 0x5e548 <g.7>
   57f57:      	je	0x58727 <f.2+0x8b7>
   57f5d:      	movq	0x70(%rsp), %r14
   57f62:      	movq	%r14, %rax
   57f65:      	shrq	$0x20, %rax
   57f69:      	jne	0x58727 <f.2+0x8b7>
   57f6f:      	movq	$0x5, 0x20(%rsp)
   57f78:      	movq	0x64c1(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   57f7f:      	testq	%rdi, %rdi
   57f82:      	je	0x58727 <f.2+0x8b7>
   57f88:      	movq	0x178(%rdi), %rcx
   57f8f:      	testq	%rcx, %rcx
   57f92:      	je	0x57fd1 <f.2+0x161>
   57f94:      	movq	0x170(%rdi), %rax
   57f9b:      	incq	%rax
   57f9e:      	movq	%rax, 0x170(%rdi)
   57fa5:      	movq	%rax, %rdx
   57fa8:      	orq	%rcx, %rdx
   57fab:      	shrq	$0x20, %rdx
   57faf:      	je	0x58630 <f.2+0x7c0>
   57fb5:      	xorl	%edx, %edx
   57fb7:      	divq	%rcx
   57fba:      	testq	%rdx, %rdx
   57fbd:      	jne	0x57fd1 <f.2+0x161>
   57fbf:      	movq	0x6482(%rip), %rsi      # 0x5e448 <native_roots.0>
   57fc6:      	movq	%rdi, %r15
   57fc9:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   57fce:      	movq	%r15, %rdi
   57fd1:      	movq	0x6470(%rip), %rdx      # 0x5e448 <native_roots.0>
   57fd8:      	movl	$0x18, %esi
   57fdd:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   57fe2:      	testq	%rax, %rax
   57fe5:      	je	0x5872c <f.2+0x8bc>
   57feb:      	movq	%rax, %r15
   57fee:      	movq	$0x3a, (%rax)
   57ff5:      	movl	$0x0, 0x8(%rax)
   57ffc:      	movq	$0x0, 0x10(%rax)
   58004:      	movq	%rax, 0x30(%rsp)
   58009:      	leaq	0x44d8(%rip), %rax      # 0x5c4e8 <ref.7>
   58010:      	movq	%rax, 0x50(%rsp)
   58015:      	movq	%r15, 0x58(%rsp)
   5801a:      	movq	$0x7, 0x20(%rsp)
   58023:      	movq	0x6416(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5802a:      	testq	%rdi, %rdi
   5802d:      	je	0x58727 <f.2+0x8b7>
   58033:      	movq	0x178(%rdi), %rcx
   5803a:      	testq	%rcx, %rcx
   5803d:      	je	0x5807c <f.2+0x20c>
   5803f:      	movq	0x170(%rdi), %rax
   58046:      	incq	%rax
   58049:      	movq	%rax, 0x170(%rdi)
   58050:      	movq	%rax, %rdx
   58053:      	orq	%rcx, %rdx
   58056:      	shrq	$0x20, %rdx
   5805a:      	je	0x58650 <f.2+0x7e0>
   58060:      	xorl	%edx, %edx
   58062:      	divq	%rcx
   58065:      	testq	%rdx, %rdx
   58068:      	jne	0x5807c <f.2+0x20c>
   5806a:      	movq	0x63d7(%rip), %rsi      # 0x5e448 <native_roots.0>
   58071:      	movq	%rdi, %r12
   58074:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58079:      	movq	%r12, %rdi
   5807c:      	movq	0x63c5(%rip), %rdx      # 0x5e448 <native_roots.0>
   58083:      	movl	$0x10, %esi
   58088:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5808d:      	testq	%rax, %rax
   58090:      	je	0x5872c <f.2+0x8bc>
   58096:      	testb	$0x1, %al
   58098:      	jne	0x58727 <f.2+0x8b7>
   5809e:      	movq	$0x2b, (%rax)
   580a5:      	movq	$0x0, 0x8(%rax)
   580ad:      	movq	%rax, 0x50(%rsp)
   580b2:      	leaq	0x442f(%rip), %r12      # 0x5c4e8 <ref.7>
   580b9:      	movq	%r12, 0x58(%rsp)
   580be:      	movq	%r15, 0x60(%rsp)
   580c3:      	movq	$0x8, 0x20(%rsp)
   580cc:      	movl	$0x2f, %edi
   580d1:      	movl	%r14d, %esi
   580d4:      	movq	%rax, %rdx
   580d7:      	callq	0x57d30 <native_array_new>
   580dc:      	movq	%rax, 0x48(%rsp)
   580e1:      	movq	0x30(%rsp), %rbp
   580e6:      	movq	%rbp, 0x50(%rsp)
   580eb:      	movq	%rax, 0x58(%rsp)
   580f0:      	movq	%r12, 0x60(%rsp)
   580f5:      	movq	%r15, 0x68(%rsp)
   580fa:      	movq	$0x9, 0x20(%rsp)
   58103:      	movq	0x6336(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5810a:      	testq	%rdi, %rdi
   5810d:      	je	0x58727 <f.2+0x8b7>
   58113:      	movq	%rax, %r13
   58116:      	movq	0x178(%rdi), %rcx
   5811d:      	testq	%rcx, %rcx
   58120:      	je	0x5815f <f.2+0x2ef>
   58122:      	movq	0x170(%rdi), %rax
   58129:      	incq	%rax
   5812c:      	movq	%rax, 0x170(%rdi)
   58133:      	movq	%rax, %rdx
   58136:      	orq	%rcx, %rdx
   58139:      	shrq	$0x20, %rdx
   5813d:      	je	0x58670 <f.2+0x800>
   58143:      	xorl	%edx, %edx
   58145:      	divq	%rcx
   58148:      	testq	%rdx, %rdx
   5814b:      	jne	0x5815f <f.2+0x2ef>
   5814d:      	movq	0x62f4(%rip), %rsi      # 0x5e448 <native_roots.0>
   58154:      	movq	%rdi, %r12
   58157:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5815c:      	movq	%r12, %rdi
   5815f:      	movq	0x62e2(%rip), %rdx      # 0x5e448 <native_roots.0>
   58166:      	movl	$0x20, %esi
   5816b:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58170:      	testq	%rax, %rax
   58173:      	je	0x5872c <f.2+0x8bc>
   58179:      	movq	%rax, %r12
   5817c:      	movq	$0x26, (%rax)
   58183:      	movq	%r14, 0x8(%rax)
   58187:      	movq	%r13, 0x10(%rax)
   5818b:      	movq	%rbp, 0x18(%rax)
   5818f:      	movq	%rax, 0x50(%rsp)
   58194:      	leaq	0x434d(%rip), %rax      # 0x5c4e8 <ref.7>
   5819b:      	movq	%rax, 0x58(%rsp)
   581a0:      	movq	%r15, 0x60(%rsp)
   581a5:      	movq	$0x8, 0x20(%rsp)
   581ae:      	movq	0x628b(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   581b5:      	testq	%rdi, %rdi
   581b8:      	je	0x58727 <f.2+0x8b7>
   581be:      	movq	0x178(%rdi), %rcx
   581c5:      	testq	%rcx, %rcx
   581c8:      	je	0x58207 <f.2+0x397>
   581ca:      	movq	0x170(%rdi), %rax
   581d1:      	incq	%rax
   581d4:      	movq	%rax, 0x170(%rdi)
   581db:      	movq	%rax, %rdx
   581de:      	orq	%rcx, %rdx
   581e1:      	shrq	$0x20, %rdx
   581e5:      	je	0x58690 <f.2+0x820>
   581eb:      	xorl	%edx, %edx
   581ed:      	divq	%rcx
   581f0:      	testq	%rdx, %rdx
   581f3:      	jne	0x58207 <f.2+0x397>
   581f5:      	movq	0x624c(%rip), %rsi      # 0x5e448 <native_roots.0>
   581fc:      	movq	%rdi, %r13
   581ff:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58204:      	movq	%r13, %rdi
   58207:      	movq	0x623a(%rip), %rdx      # 0x5e448 <native_roots.0>
   5820e:      	movl	$0x18, %esi
   58213:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58218:      	testq	%rax, %rax
   5821b:      	je	0x5872c <f.2+0x8bc>
   58221:      	movq	$0x32, (%rax)
   58228:      	leaq	0x42b9(%rip), %rcx      # 0x5c4e8 <ref.7>
   5822f:      	movq	%rcx, 0x8(%rax)
   58233:      	movq	%r12, 0x10(%rax)
   58237:      	movq	%rax, 0x10(%r15)
   5823b:      	movq	0x30(%rsp), %rax
   58240:      	testq	%rax, %rax
   58243:      	je	0x58727 <f.2+0x8b7>
   58249:      	movl	$0x1, 0x8(%rax)
   58250:      	movq	0x30(%rsp), %rax
   58255:      	testq	%rax, %rax
   58258:      	je	0x58727 <f.2+0x8b7>
   5825e:      	cmpl	$0x0, 0x8(%rax)
   58262:      	je	0x58727 <f.2+0x8b7>
   58268:      	movq	0x10(%rax), %rax
   5826c:      	testq	%rax, %rax
   5826f:      	je	0x58727 <f.2+0x8b7>
   58275:      	movq	%rax, 0x40(%rsp)
   5827a:      	movq	0x8(%rax), %rcx
   5827e:      	testq	%rcx, %rcx
   58281:      	je	0x58727 <f.2+0x8b7>
   58287:      	leaq	-0x1(%r14), %r15
   5828b:      	movq	0x10(%rax), %rdi
   5828f:      	movq	0x8(%rcx), %rax
   58293:      	movq	%rdi, 0x50(%rsp)
   58298:      	movq	$0x6, 0x20(%rsp)
   582a1:      	movq	%r15, %rsi
   582a4:      	callq	*%rax
   582a6:      	subq	$0x8, %rsp
   582aa:      	cmpb	$0x0, 0x628f(%rip)      # 0x5e540 <g.6>
   582b1:      	je	0x58727 <f.2+0x8b7>
   582b7:      	cmpq	$0x0, 0x6279(%rip)      # 0x5e538 <g.5>
   582bf:      	je	0x58727 <f.2+0x8b7>
   582c5:      	movq	$0x5, 0x20(%rsp)
   582ce:      	movq	0x616b(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   582d5:      	testq	%rdi, %rdi
   582d8:      	je	0x58727 <f.2+0x8b7>
   582de:      	movq	0x178(%rdi), %rcx
   582e5:      	testq	%rcx, %rcx
   582e8:      	je	0x58327 <f.2+0x4b7>
   582ea:      	movq	0x170(%rdi), %rax
   582f1:      	incq	%rax
   582f4:      	movq	%rax, 0x170(%rdi)
   582fb:      	movq	%rax, %rdx
   582fe:      	orq	%rcx, %rdx
   58301:      	shrq	$0x20, %rdx
   58305:      	je	0x586b0 <f.2+0x840>
   5830b:      	xorl	%edx, %edx
   5830d:      	divq	%rcx
   58310:      	testq	%rdx, %rdx
   58313:      	jne	0x58327 <f.2+0x4b7>
   58315:      	movq	0x612c(%rip), %rsi      # 0x5e448 <native_roots.0>
   5831c:      	movq	%rdi, %r12
   5831f:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58324:      	movq	%r12, %rdi
   58327:      	movq	0x611a(%rip), %rdx      # 0x5e448 <native_roots.0>
   5832e:      	movl	$0x18, %esi
   58333:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58338:      	testq	%rax, %rax
   5833b:      	je	0x5872c <f.2+0x8bc>
   58341:      	movq	%rax, %r12
   58344:      	movq	$0x3a, (%rax)
   5834b:      	movl	$0x0, 0x8(%rax)
   58352:      	movq	$0x0, 0x10(%rax)
   5835a:      	movq	%rax, 0x30(%rsp)
   5835f:      	movq	0x48(%rsp), %rbp
   58364:      	movq	%rax, 0x50(%rsp)
   58369:      	movq	%rbp, 0x58(%rsp)
   5836e:      	leaq	0x4153(%rip), %rax      # 0x5c4c8 <ref.4>
   58375:      	movq	%rax, 0x60(%rsp)
   5837a:      	movq	%r12, 0x68(%rsp)
   5837f:      	movq	$0x9, 0x20(%rsp)
   58388:      	movq	0x60b1(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5838f:      	testq	%rdi, %rdi
   58392:      	je	0x58727 <f.2+0x8b7>
   58398:      	movq	0x178(%rdi), %rcx
   5839f:      	testq	%rcx, %rcx
   583a2:      	je	0x583e1 <f.2+0x571>
   583a4:      	movq	0x170(%rdi), %rax
   583ab:      	incq	%rax
   583ae:      	movq	%rax, 0x170(%rdi)
   583b5:      	movq	%rax, %rdx
   583b8:      	orq	%rcx, %rdx
   583bb:      	shrq	$0x20, %rdx
   583bf:      	je	0x586d0 <f.2+0x860>
   583c5:      	xorl	%edx, %edx
   583c7:      	divq	%rcx
   583ca:      	testq	%rdx, %rdx
   583cd:      	jne	0x583e1 <f.2+0x571>
   583cf:      	movq	0x6072(%rip), %rsi      # 0x5e448 <native_roots.0>
   583d6:      	movq	%rdi, %r13
   583d9:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   583de:      	movq	%r13, %rdi
   583e1:      	movq	0x6060(%rip), %rdx      # 0x5e448 <native_roots.0>
   583e8:      	movl	$0x20, %esi
   583ed:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   583f2:      	testq	%rax, %rax
   583f5:      	je	0x5872c <f.2+0x8bc>
   583fb:      	movq	%rax, %r13
   583fe:      	movq	$0x1e, (%rax)
   58405:      	movq	%rbp, 0x8(%rax)
   58409:      	movq	%r14, 0x10(%rax)
   5840d:      	movq	%r12, 0x18(%rax)
   58411:      	movq	%rax, 0x50(%rsp)
   58416:      	leaq	0x40ab(%rip), %rax      # 0x5c4c8 <ref.4>
   5841d:      	movq	%rax, 0x58(%rsp)
   58422:      	movq	%r12, 0x60(%rsp)
   58427:      	movq	$0x8, 0x20(%rsp)
   58430:      	movq	0x6009(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58437:      	testq	%rdi, %rdi
   5843a:      	je	0x58727 <f.2+0x8b7>
   58440:      	movq	0x178(%rdi), %rcx
   58447:      	testq	%rcx, %rcx
   5844a:      	je	0x58489 <f.2+0x619>
   5844c:      	movq	0x170(%rdi), %rax
   58453:      	incq	%rax
   58456:      	movq	%rax, 0x170(%rdi)
   5845d:      	movq	%rax, %rdx
   58460:      	orq	%rcx, %rdx
   58463:      	shrq	$0x20, %rdx
   58467:      	je	0x586f0 <f.2+0x880>
   5846d:      	xorl	%edx, %edx
   5846f:      	divq	%rcx
   58472:      	testq	%rdx, %rdx
   58475:      	jne	0x58489 <f.2+0x619>
   58477:      	movq	0x5fca(%rip), %rsi      # 0x5e448 <native_roots.0>
   5847e:      	movq	%rdi, %r14
   58481:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58486:      	movq	%r14, %rdi
   58489:      	movq	0x5fb8(%rip), %rdx      # 0x5e448 <native_roots.0>
   58490:      	movl	$0x18, %esi
   58495:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5849a:      	testq	%rax, %rax
   5849d:      	je	0x5872c <f.2+0x8bc>
   584a3:      	movq	$0x32, (%rax)
   584aa:      	leaq	0x4017(%rip), %rcx      # 0x5c4c8 <ref.4>
   584b1:      	movq	%rcx, 0x8(%rax)
   584b5:      	movq	%r13, 0x10(%rax)
   584b9:      	movq	%rax, 0x10(%r12)
   584be:      	movq	0x30(%rsp), %rax
   584c3:      	testq	%rax, %rax
   584c6:      	je	0x58727 <f.2+0x8b7>
   584cc:      	movl	$0x1, 0x8(%rax)
   584d3:      	movq	0x30(%rsp), %rax
   584d8:      	testq	%rax, %rax
   584db:      	je	0x58727 <f.2+0x8b7>
   584e1:      	cmpl	$0x0, 0x8(%rax)
   584e5:      	je	0x58727 <f.2+0x8b7>
   584eb:      	movq	0x10(%rax), %rax
   584ef:      	testq	%rax, %rax
   584f2:      	je	0x58727 <f.2+0x8b7>
   584f8:      	movq	%rax, 0x40(%rsp)
   584fd:      	movq	0x8(%rax), %rcx
   58501:      	testq	%rcx, %rcx
   58504:      	je	0x58727 <f.2+0x8b7>
   5850a:      	movq	0x10(%rax), %rdi
   5850e:      	movq	0x8(%rcx), %rax
   58512:      	movq	%rdi, 0x50(%rsp)
   58517:      	movq	$0x6, 0x20(%rsp)
   58520:      	movq	%r15, %rsi
   58523:      	callq	*%rax
   58525:      	subq	$0x8, %rsp
   58529:      	movq	0x48(%rsp), %rax
   5852e:      	testq	%rax, %rax
   58531:      	je	0x58727 <f.2+0x8b7>
   58537:      	testb	$0x1, %al
   58539:      	jne	0x58727 <f.2+0x8b7>
   5853f:      	cmpq	$0x0, 0x8(%rax)
   58544:      	je	0x58727 <f.2+0x8b7>
   5854a:      	movq	0x10(%rax), %rax
   5854e:      	testq	%rax, %rax
   58551:      	je	0x58727 <f.2+0x8b7>
   58557:      	testb	$0x1, %al
   58559:      	jne	0x58727 <f.2+0x8b7>
   5855f:      	cmpq	$0x0, 0x8(%rax)
   58564:      	je	0x58727 <f.2+0x8b7>
   5856a:      	movq	0x38(%rsp), %rsi
   5856f:      	testq	%rsi, %rsi
   58572:      	je	0x58727 <f.2+0x8b7>
   58578:      	movq	0x10(%rsi), %rcx
   5857c:      	testq	%rcx, %rcx
   5857f:      	je	0x58727 <f.2+0x8b7>
   58585:      	cmpl	$0x0, 0x8(%rcx)
   58589:      	je	0x58727 <f.2+0x8b7>
   5858f:      	cmpq	$0x0, 0x10(%rcx)
   58594:      	je	0x58727 <f.2+0x8b7>
   5859a:      	movq	0x10(%rax), %rdx
   5859e:      	incq	%rbx
   585a1:      	xorl	%eax, %eax
   585a3:      	cmpq	$0x0, 0x18(%rsp)
   585a9:      	sete	%al
   585ac:      	leaq	0x10(%rsp), %rdi
   585b1:      	movq	%rdi, %rcx
   585b4:      	leaq	0x5e8d(%rip), %r8       # 0x5e448 <native_roots.0>
   585bb:      	cmoveq	%r8, %rcx
   585bf:      	addq	0x5e62(%rip), %rax      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   585c6:      	movq	(%rcx), %rcx
   585c9:      	movq	$0x9, 0x18(%rsp)
   585d2:      	movq	$0x0, 0x20(%rsp)
   585db:      	movq	%rcx, 0x10(%rsp)
   585e0:      	movq	%rdi, 0x5e61(%rip)      # 0x5e448 <native_roots.0>
   585e7:      	movq	0x5e42(%rip), %rdi      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   585ee:      	cmpq	%rdi, %rax
   585f1:      	cmovaq	%rax, %rdi
   585f5:      	movq	%rax, 0x5e2c(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   585fc:      	movq	%rdi, 0x5e2d(%rip)      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58603:      	movq	%rsi, 0x28(%rsp)
   58608:      	leaq	0x30(%rsp), %rdi
   5860d:      	xorps	%xmm0, %xmm0
   58610:      	movups	%xmm0, 0x10(%rdi)
   58614:      	movups	%xmm0, (%rdi)
   58617:      	movq	%rsi, 0x38(%rsp)
   5861c:      	cmpq	%rbx, 0x8(%rsi)
   58620:      	jg	0x57f00 <f.2+0x90>
   58626:      	jmp	0x58702 <f.2+0x892>
   5862b:      	nopl	(%rax,%rax)
   58630:      	xorl	%edx, %edx
   58632:      	divl	%ecx
   58634:      	testq	%rdx, %rdx
   58637:      	jne	0x57fd1 <f.2+0x161>
   5863d:      	jmp	0x57fbf <f.2+0x14f>
   58642:      	nopw	%cs:(%rax,%rax)
   58650:      	xorl	%edx, %edx
   58652:      	divl	%ecx
   58654:      	testq	%rdx, %rdx
   58657:      	jne	0x5807c <f.2+0x20c>
   5865d:      	jmp	0x5806a <f.2+0x1fa>
   58662:      	nopw	%cs:(%rax,%rax)
   58670:      	xorl	%edx, %edx
   58672:      	divl	%ecx
   58674:      	testq	%rdx, %rdx
   58677:      	jne	0x5815f <f.2+0x2ef>
   5867d:      	jmp	0x5814d <f.2+0x2dd>
   58682:      	nopw	%cs:(%rax,%rax)
   58690:      	xorl	%edx, %edx
   58692:      	divl	%ecx
   58694:      	testq	%rdx, %rdx
   58697:      	jne	0x58207 <f.2+0x397>
   5869d:      	jmp	0x581f5 <f.2+0x385>
   586a2:      	nopw	%cs:(%rax,%rax)
   586b0:      	xorl	%edx, %edx
   586b2:      	divl	%ecx
   586b4:      	testq	%rdx, %rdx
   586b7:      	jne	0x58327 <f.2+0x4b7>
   586bd:      	jmp	0x58315 <f.2+0x4a5>
   586c2:      	nopw	%cs:(%rax,%rax)
   586d0:      	xorl	%edx, %edx
   586d2:      	divl	%ecx
   586d4:      	testq	%rdx, %rdx
   586d7:      	jne	0x583e1 <f.2+0x571>
   586dd:      	jmp	0x583cf <f.2+0x55f>
   586e2:      	nopw	%cs:(%rax,%rax)
   586f0:      	xorl	%edx, %edx
   586f2:      	divl	%ecx
   586f4:      	testq	%rdx, %rdx
   586f7:      	jne	0x58489 <f.2+0x619>
   586fd:      	jmp	0x58477 <f.2+0x607>
   58702:      	decq	%rax
   58705:      	movq	%rcx, 0x5d3c(%rip)      # 0x5e448 <native_roots.0>
   5870c:      	movq	%rax, 0x5d15(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58713:      	movq	%rdx, %rax
   58716:      	addq	$0x78, %rsp
   5871a:      	popq	%rbx
   5871b:      	popq	%r12
   5871d:      	popq	%r13
   5871f:      	popq	%r14
   58721:      	popq	%r15
   58723:      	popq	%rbp
   58724:      	retq	$0x8
   58727:      	callq	0x54910 <native_trap>
   5872c:      	leaq	-0x4f917(%rip), %rdi    # 0x8e1c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   58733:      	movl	$0x2f, %esi
   58738:      	callq	0x55910 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5873d:      	int3
   5873e:      	int3
   5873f:      	int3

0000000000058740 <f.4>:
   58740:      	pushq	%rbp
   58741:      	pushq	%r15
   58743:      	pushq	%r14
   58745:      	pushq	%r13
   58747:      	pushq	%r12
   58749:      	pushq	%rbx
   5874a:      	subq	$0x68, %rsp
   5874e:      	movq	%rsi, %r14
   58751:      	movq	%rdi, %rax
   58754:      	movq	$0x9, 0x10(%rsp)
   5875d:      	movq	$0x0, 0x18(%rsp)
   58766:      	movq	0x5cdb(%rip), %rdx      # 0x5e448 <native_roots.0>
   5876d:      	movq	%rdx, 0x8(%rsp)
   58772:      	leaq	0x8(%rsp), %rcx
   58777:      	movq	0x5caa(%rip), %rsi      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5877e:      	leaq	0x1(%rsi), %rdi
   58782:      	movq	0x5ca7(%rip), %r8       # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58789:      	cmpq	%r8, %rdi
   5878c:      	cmovaq	%rdi, %r8
   58790:      	movq	%rcx, 0x5cb1(%rip)      # 0x5e448 <native_roots.0>
   58797:      	movq	%rdi, 0x5c8a(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5879e:      	movq	%r8, 0x5c8b(%rip)       # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   587a5:      	movq	%rax, 0x20(%rsp)
   587aa:      	xorps	%xmm0, %xmm0
   587ad:      	movups	%xmm0, 0x28(%rsp)
   587b2:      	movq	$0x0, 0x38(%rsp)
   587bb:      	testq	%r14, %r14
   587be:      	js	0x58ae5 <f.4+0x3a5>
   587c4:      	testq	%rax, %rax
   587c7:      	je	0x58b3c <f.4+0x3fc>
   587cd:      	movl	%eax, %edx
   587cf:      	andl	$0x1, %edx
   587d2:      	jne	0x58b3c <f.4+0x3fc>
   587d8:      	movq	0x5c61(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   587df:      	testq	%rdi, %rdi
   587e2:      	je	0x58b3c <f.4+0x3fc>
   587e8:      	movq	(%rax), %rdx
   587eb:      	testq	%rdx, %rdx
   587ee:      	je	0x58851 <f.4+0x111>
   587f0:      	cmpq	$0x1e, %rdx
   587f4:      	je	0x58851 <f.4+0x111>
   587f6:      	movq	0x168(%rdi), %rsi
   587fd:      	shrq	$0x2, %rdx
   58801:      	leaq	-0x1(%rdx), %r8
   58805:      	cmpq	%rsi, %r8
   58808:      	jae	0x58b3c <f.4+0x3fc>
   5880e:      	movq	0x160(%rdi), %r8
   58815:      	movq	-0x8(%r8,%rdx,8), %rdx
   5881a:      	testq	%rdx, %rdx
   5881d:      	je	0x58851 <f.4+0x111>
   5881f:      	cmpq	$0x1e, %rdx
   58823:      	je	0x58851 <f.4+0x111>
   58825:      	nopw	%cs:(%rax,%rax)
   58830:      	shrq	$0x2, %rdx
   58834:      	leaq	-0x1(%rdx), %r9
   58838:      	cmpq	%rsi, %r9
   5883b:      	jae	0x58b3c <f.4+0x3fc>
   58841:      	movq	-0x8(%r8,%rdx,8), %rdx
   58846:      	cmpq	$0x1e, %rdx
   5884a:      	je	0x58851 <f.4+0x111>
   5884c:      	testq	%rdx, %rdx
   5884f:      	jne	0x58830 <f.4+0xf0>
   58851:      	cmpq	$0x1e, %rdx
   58855:      	jne	0x58b3c <f.4+0x3fc>
   5885b:      	movq	%rax, 0x30(%rsp)
   58860:      	movq	0x10(%rax), %rbx
   58864:      	movq	$0x4, 0x18(%rsp)
   5886d:      	movq	0x178(%rdi), %rsi
   58874:      	testq	%rsi, %rsi
   58877:      	je	0x588bb <f.4+0x17b>
   58879:      	movq	0x170(%rdi), %rax
   58880:      	incq	%rax
   58883:      	movq	%rax, 0x170(%rdi)
   5888a:      	movq	%rax, %rdx
   5888d:      	orq	%rsi, %rdx
   58890:      	shrq	$0x20, %rdx
   58894:      	je	0x58b06 <f.4+0x3c6>
   5889a:      	xorl	%edx, %edx
   5889c:      	divq	%rsi
   5889f:      	testq	%rdx, %rdx
   588a2:      	jne	0x588bb <f.4+0x17b>
   588a4:      	leaq	0x8(%rsp), %rsi
   588a9:      	movq	%rdi, %r15
   588ac:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   588b1:      	movq	%r15, %rdi
   588b4:      	movq	0x5b8d(%rip), %rcx      # 0x5e448 <native_roots.0>
   588bb:      	movl	$0x18, %esi
   588c0:      	movq	%rcx, %rdx
   588c3:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   588c8:      	testq	%rax, %rax
   588cb:      	je	0x58b41 <f.4+0x401>
   588d1:      	movq	%rax, %r15
   588d4:      	movq	$0x3a, (%rax)
   588db:      	movl	$0x0, 0x8(%rax)
   588e2:      	movq	$0x0, 0x10(%rax)
   588ea:      	movq	%rax, 0x28(%rsp)
   588ef:      	movq	0x30(%rsp), %rax
   588f4:      	testq	%rax, %rax
   588f7:      	je	0x58b3c <f.4+0x3fc>
   588fd:      	movq	0x8(%rax), %rbp
   58901:      	movq	0x18(%rax), %r13
   58905:      	movq	%r15, 0x40(%rsp)
   5890a:      	movq	%r13, 0x48(%rsp)
   5890f:      	movq	%rbp, 0x50(%rsp)
   58914:      	leaq	0x3bbd(%rip), %rax      # 0x5c4d8 <ref.5>
   5891b:      	movq	%rax, 0x58(%rsp)
   58920:      	movq	%r15, 0x60(%rsp)
   58925:      	movq	$0x9, 0x18(%rsp)
   5892e:      	movq	0x5b0b(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58935:      	testq	%rdi, %rdi
   58938:      	je	0x58b3c <f.4+0x3fc>
   5893e:      	movq	0x178(%rdi), %rcx
   58945:      	testq	%rcx, %rcx
   58948:      	je	0x58987 <f.4+0x247>
   5894a:      	movq	0x170(%rdi), %rax
   58951:      	incq	%rax
   58954:      	movq	%rax, 0x170(%rdi)
   5895b:      	movq	%rax, %rdx
   5895e:      	orq	%rcx, %rdx
   58961:      	shrq	$0x20, %rdx
   58965:      	je	0x58b18 <f.4+0x3d8>
   5896b:      	xorl	%edx, %edx
   5896d:      	divq	%rcx
   58970:      	testq	%rdx, %rdx
   58973:      	jne	0x58987 <f.4+0x247>
   58975:      	movq	0x5acc(%rip), %rsi      # 0x5e448 <native_roots.0>
   5897c:      	movq	%rdi, %r12
   5897f:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58984:      	movq	%r12, %rdi
   58987:      	movq	0x5aba(%rip), %rdx      # 0x5e448 <native_roots.0>
   5898e:      	movl	$0x28, %esi
   58993:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58998:      	testq	%rax, %rax
   5899b:      	je	0x58b41 <f.4+0x401>
   589a1:      	movq	%rax, %r12
   589a4:      	movq	$0x16, (%rax)
   589ab:      	movq	%rbp, 0x8(%rax)
   589af:      	movq	%r13, 0x10(%rax)
   589b3:      	movq	%r14, 0x18(%rax)
   589b7:      	movq	%r15, 0x20(%rax)
   589bb:      	movq	%rax, 0x40(%rsp)
   589c0:      	leaq	0x3b11(%rip), %r13      # 0x5c4d8 <ref.5>
   589c7:      	movq	%r13, 0x48(%rsp)
   589cc:      	movq	%r15, 0x50(%rsp)
   589d1:      	movq	$0x7, 0x18(%rsp)
   589da:      	movq	0x5a5f(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   589e1:      	testq	%rdi, %rdi
   589e4:      	je	0x58b3c <f.4+0x3fc>
   589ea:      	movq	0x178(%rdi), %rcx
   589f1:      	testq	%rcx, %rcx
   589f4:      	je	0x58a33 <f.4+0x2f3>
   589f6:      	movq	0x170(%rdi), %rax
   589fd:      	incq	%rax
   58a00:      	movq	%rax, 0x170(%rdi)
   58a07:      	movq	%rax, %rdx
   58a0a:      	orq	%rcx, %rdx
   58a0d:      	shrq	$0x20, %rdx
   58a11:      	je	0x58b2a <f.4+0x3ea>
   58a17:      	xorl	%edx, %edx
   58a19:      	divq	%rcx
   58a1c:      	testq	%rdx, %rdx
   58a1f:      	jne	0x58a33 <f.4+0x2f3>
   58a21:      	movq	0x5a20(%rip), %rsi      # 0x5e448 <native_roots.0>
   58a28:      	movq	%rdi, %r14
   58a2b:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58a30:      	movq	%r14, %rdi
   58a33:      	movq	0x5a0e(%rip), %rdx      # 0x5e448 <native_roots.0>
   58a3a:      	movl	$0x18, %esi
   58a3f:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58a44:      	testq	%rax, %rax
   58a47:      	je	0x58b41 <f.4+0x401>
   58a4d:      	movq	$0x32, (%rax)
   58a54:      	movq	%r13, 0x8(%rax)
   58a58:      	movq	%r12, 0x10(%rax)
   58a5c:      	movq	%rax, 0x10(%r15)
   58a60:      	movq	0x28(%rsp), %rax
   58a65:      	testq	%rax, %rax
   58a68:      	je	0x58b3c <f.4+0x3fc>
   58a6e:      	movl	$0x1, 0x8(%rax)
   58a75:      	movq	0x28(%rsp), %rax
   58a7a:      	testq	%rax, %rax
   58a7d:      	je	0x58b3c <f.4+0x3fc>
   58a83:      	cmpl	$0x0, 0x8(%rax)
   58a87:      	je	0x58b3c <f.4+0x3fc>
   58a8d:      	movq	0x10(%rax), %rax
   58a91:      	testq	%rax, %rax
   58a94:      	je	0x58b3c <f.4+0x3fc>
   58a9a:      	movq	%rax, 0x38(%rsp)
   58a9f:      	movq	0x8(%rax), %rcx
   58aa3:      	testq	%rcx, %rcx
   58aa6:      	je	0x58b3c <f.4+0x3fc>
   58aac:      	decq	%rbx
   58aaf:      	movq	0x10(%rax), %rdi
   58ab3:      	movq	0x8(%rcx), %rax
   58ab7:      	cmpq	$0x0, 0x10(%rsp)
   58abd:      	je	0x58ad2 <f.4+0x392>
   58abf:      	movq	0x8(%rsp), %rcx
   58ac4:      	movq	%rcx, 0x597d(%rip)      # 0x5e448 <native_roots.0>
   58acb:      	decq	0x5956(%rip)            # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58ad2:      	movq	%rbx, %rsi
   58ad5:      	addq	$0x68, %rsp
   58ad9:      	popq	%rbx
   58ada:      	popq	%r12
   58adc:      	popq	%r13
   58ade:      	popq	%r14
   58ae0:      	popq	%r15
   58ae2:      	popq	%rbp
   58ae3:      	jmpq	*%rax
   58ae5:      	movq	%rdx, 0x595c(%rip)      # 0x5e448 <native_roots.0>
   58aec:      	movq	%rsi, 0x5935(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58af3:      	xorl	%eax, %eax
   58af5:      	addq	$0x68, %rsp
   58af9:      	popq	%rbx
   58afa:      	popq	%r12
   58afc:      	popq	%r13
   58afe:      	popq	%r14
   58b00:      	popq	%r15
   58b02:      	popq	%rbp
   58b03:      	retq	$0x8
   58b06:      	xorl	%edx, %edx
   58b08:      	divl	%esi
   58b0a:      	testq	%rdx, %rdx
   58b0d:      	jne	0x588bb <f.4+0x17b>
   58b13:      	jmp	0x588a4 <f.4+0x164>
   58b18:      	xorl	%edx, %edx
   58b1a:      	divl	%ecx
   58b1c:      	testq	%rdx, %rdx
   58b1f:      	jne	0x58987 <f.4+0x247>
   58b25:      	jmp	0x58975 <f.4+0x235>
   58b2a:      	xorl	%edx, %edx
   58b2c:      	divl	%ecx
   58b2e:      	testq	%rdx, %rdx
   58b31:      	jne	0x58a33 <f.4+0x2f3>
   58b37:      	jmp	0x58a21 <f.4+0x2e1>
   58b3c:      	callq	0x54910 <native_trap>
   58b41:      	leaq	-0x4fd2c(%rip), %rdi    # 0x8e1c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   58b48:      	movl	$0x2f, %esi
   58b4d:      	callq	0x55910 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   58b52:      	int3
   58b53:      	int3
   58b54:      	int3
   58b55:      	int3
   58b56:      	int3
   58b57:      	int3
   58b58:      	int3
   58b59:      	int3
   58b5a:      	int3
   58b5b:      	int3
   58b5c:      	int3
   58b5d:      	int3
   58b5e:      	int3
   58b5f:      	int3

0000000000058b60 <f.5>:
   58b60:      	pushq	%rbp
   58b61:      	pushq	%r15
   58b63:      	pushq	%r14
   58b65:      	pushq	%r13
   58b67:      	pushq	%r12
   58b69:      	pushq	%rbx
   58b6a:      	subq	$0x98, %rsp
   58b71:      	movq	%rsi, %rbx
   58b74:      	movq	$0x7, 0x18(%rsp)
   58b7d:      	movq	$0x0, 0x20(%rsp)
   58b86:      	movq	0x58bb(%rip), %rcx      # 0x5e448 <native_roots.0>
   58b8d:      	movq	%rcx, 0x10(%rsp)
   58b92:      	leaq	0x10(%rsp), %r13
   58b97:      	movq	0x588a(%rip), %rax      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58b9e:      	leaq	0x1(%rax), %rdx
   58ba2:      	movq	0x5887(%rip), %rsi      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58ba9:      	cmpq	%rsi, %rdx
   58bac:      	cmovaq	%rdx, %rsi
   58bb0:      	movq	%r13, 0x5891(%rip)      # 0x5e448 <native_roots.0>
   58bb7:      	movq	%rdx, 0x586a(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58bbe:      	movq	%rsi, 0x586b(%rip)      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58bc5:      	movq	%rdi, 0x28(%rsp)
   58bca:      	xorpd	%xmm0, %xmm0
   58bce:      	movupd	%xmm0, 0x30(%rsp)
   58bd4:      	movq	$0x0, 0x40(%rsp)
   58bdd:      	testq	%rbx, %rbx
   58be0:      	js	0x59157 <f.5+0x5f7>
   58be6:      	movq	%rbx, %rax
   58be9:      	shrq	$0x20, %rax
   58bed:      	movq	%rax, 0x68(%rsp)
   58bf2:      	nopw	%cs:(%rax,%rax)
   58c00:      	cmpq	$0x0, 0x68(%rsp)
   58c06:      	jne	0x5922f <f.5+0x6cf>
   58c0c:      	testq	%rdi, %rdi
   58c0f:      	je	0x5922f <f.5+0x6cf>
   58c15:      	movl	%edi, %eax
   58c17:      	andl	$0x1, %eax
   58c1a:      	jne	0x5922f <f.5+0x6cf>
   58c20:      	movq	0x5819(%rip), %r15      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58c27:      	testq	%r15, %r15
   58c2a:      	je	0x5922f <f.5+0x6cf>
   58c30:      	movq	(%rdi), %rax
   58c33:      	testq	%rax, %rax
   58c36:      	je	0x58ca0 <f.5+0x140>
   58c38:      	cmpq	$0x16, %rax
   58c3c:      	je	0x58ca0 <f.5+0x140>
   58c3e:      	movq	0x168(%r15), %rcx
   58c45:      	shrq	$0x2, %rax
   58c49:      	leaq	-0x1(%rax), %rdx
   58c4d:      	cmpq	%rcx, %rdx
   58c50:      	jae	0x5922f <f.5+0x6cf>
   58c56:      	movq	0x160(%r15), %rdx
   58c5d:      	movq	-0x8(%rdx,%rax,8), %rax
   58c62:      	testq	%rax, %rax
   58c65:      	je	0x58ca0 <f.5+0x140>
   58c67:      	cmpq	$0x16, %rax
   58c6b:      	je	0x58ca0 <f.5+0x140>
   58c6d:      	nopl	(%rax)
   58c70:      	shrq	$0x2, %rax
   58c74:      	leaq	-0x1(%rax), %rsi
   58c78:      	cmpq	%rcx, %rsi
   58c7b:      	jae	0x5922f <f.5+0x6cf>
   58c81:      	movq	-0x8(%rdx,%rax,8), %rax
   58c86:      	cmpq	$0x16, %rax
   58c8a:      	je	0x58ca0 <f.5+0x140>
   58c8c:      	testq	%rax, %rax
   58c8f:      	jne	0x58c70 <f.5+0x110>
   58c91:      	nopw	%cs:(%rax,%rax)
   58ca0:      	cmpq	$0x16, %rax
   58ca4:      	jne	0x5922f <f.5+0x6cf>
   58caa:      	movq	%rdi, 0x30(%rsp)
   58caf:      	movq	0x8(%rdi), %rax
   58cb3:      	testq	%rax, %rax
   58cb6:      	je	0x5922f <f.5+0x6cf>
   58cbc:      	testb	$0x1, %al
   58cbe:      	jne	0x5922f <f.5+0x6cf>
   58cc4:      	cmpq	0x8(%rax), %rbx
   58cc8:      	jae	0x5922f <f.5+0x6cf>
   58cce:      	cmpb	$0x0, 0x585b(%rip)      # 0x5e530 <g.4>
   58cd5:      	je	0x5922f <f.5+0x6cf>
   58cdb:      	cmpq	$0x0, 0x5845(%rip)      # 0x5e528 <g.3>
   58ce3:      	je	0x5922f <f.5+0x6cf>
   58ce9:      	movq	0x10(%rax,%rbx,8), %rbp
   58cee:      	movq	%rbp, 0x48(%rsp)
   58cf3:      	movq	$0x5, 0x20(%rsp)
   58cfc:      	movq	0x178(%r15), %rcx
   58d03:      	movq	%r13, %rdx
   58d06:      	testq	%rcx, %rcx
   58d09:      	je	0x58d4e <f.5+0x1ee>
   58d0b:      	movq	0x170(%r15), %rax
   58d12:      	incq	%rax
   58d15:      	movq	%rax, 0x170(%r15)
   58d1c:      	movq	%rax, %rdx
   58d1f:      	orq	%rcx, %rdx
   58d22:      	shrq	$0x20, %rdx
   58d26:      	je	0x59100 <f.5+0x5a0>
   58d2c:      	xorl	%edx, %edx
   58d2e:      	divq	%rcx
   58d31:      	movq	%rdx, %rax
   58d34:      	movq	%r13, %rdx
   58d37:      	testq	%rax, %rax
   58d3a:      	jne	0x58d4e <f.5+0x1ee>
   58d3c:      	movq	%r15, %rdi
   58d3f:      	movq	%r13, %rsi
   58d42:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58d47:      	movq	0x56fa(%rip), %rdx      # 0x5e448 <native_roots.0>
   58d4e:      	movl	$0x18, %esi
   58d53:      	movq	%r15, %rdi
   58d56:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58d5b:      	testq	%rax, %rax
   58d5e:      	je	0x59234 <f.5+0x6d4>
   58d64:      	movq	%rax, %r15
   58d67:      	movq	$0x12, (%rax)
   58d6e:      	movl	$0x0, 0x8(%rax)
   58d75:      	movq	$0x0, 0x10(%rax)
   58d7d:      	movq	%rax, 0x38(%rsp)
   58d82:      	cvtsi2sd	%rbx, %xmm1
   58d87:      	movsd	-0x53347(%rip), %xmm0   # 0x5a48 <writev+0x5a48>
   58d8f:      	mulsd	%xmm0, %xmm1
   58d93:      	addsd	-0x5338b(%rip), %xmm1   # 0x5a10 <writev+0x5a10>
   58d9b:      	movq	0x30(%rsp), %rax
   58da0:      	testq	%rax, %rax
   58da3:      	je	0x5922f <f.5+0x6cf>
   58da9:      	movq	0x18(%rax), %r14
   58dad:      	cvtsi2sd	%r14, %xmm2
   58db2:      	mulsd	%xmm0, %xmm2
   58db6:      	addsd	-0x53396(%rip), %xmm2   # 0x5a28 <writev+0x5a28>
   58dbe:      	movapd	%xmm2, 0x70(%rsp)
   58dc4:      	movq	%r15, 0x48(%rsp)
   58dc9:      	movq	%r15, 0x50(%rsp)
   58dce:      	movq	%rbp, 0x58(%rsp)
   58dd3:      	movq	$0x7, 0x20(%rsp)
   58ddc:      	movq	0x565d(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58de3:      	testq	%rdi, %rdi
   58de6:      	je	0x5922f <f.5+0x6cf>
   58dec:      	movapd	%xmm1, 0x80(%rsp)
   58df5:      	movq	0x178(%rdi), %rcx
   58dfc:      	testq	%rcx, %rcx
   58dff:      	je	0x58e3e <f.5+0x2de>
   58e01:      	movq	0x170(%rdi), %rax
   58e08:      	incq	%rax
   58e0b:      	movq	%rax, 0x170(%rdi)
   58e12:      	movq	%rax, %rdx
   58e15:      	orq	%rcx, %rdx
   58e18:      	shrq	$0x20, %rdx
   58e1c:      	je	0x59120 <f.5+0x5c0>
   58e22:      	xorl	%edx, %edx
   58e24:      	divq	%rcx
   58e27:      	testq	%rdx, %rdx
   58e2a:      	jne	0x58e3e <f.5+0x2de>
   58e2c:      	movq	0x5615(%rip), %rsi      # 0x5e448 <native_roots.0>
   58e33:      	movq	%rdi, %r12
   58e36:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58e3b:      	movq	%r12, %rdi
   58e3e:      	movq	0x5603(%rip), %rdx      # 0x5e448 <native_roots.0>
   58e45:      	movl	$0x20, %esi
   58e4a:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58e4f:      	testq	%rax, %rax
   58e52:      	je	0x59234 <f.5+0x6d4>
   58e58:      	movq	%rax, %r12
   58e5b:      	movq	$0xe, (%rax)
   58e62:      	movaps	0x80(%rsp), %xmm0
   58e6a:      	movsd	%xmm0, 0x8(%rax)
   58e6f:      	movaps	0x70(%rsp), %xmm0
   58e74:      	movsd	%xmm0, 0x10(%rax)
   58e79:      	movq	%r15, 0x18(%rax)
   58e7d:      	movq	%rax, 0x48(%rsp)
   58e82:      	movq	%r15, 0x50(%rsp)
   58e87:      	movq	%rbp, 0x58(%rsp)
   58e8c:      	movq	$0x7, 0x20(%rsp)
   58e95:      	movq	0x55a4(%rip), %rdi      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58e9c:      	testq	%rdi, %rdi
   58e9f:      	je	0x5922f <f.5+0x6cf>
   58ea5:      	movq	0x178(%rdi), %rcx
   58eac:      	testq	%rcx, %rcx
   58eaf:      	je	0x58efe <f.5+0x39e>
   58eb1:      	movq	0x170(%rdi), %rax
   58eb8:      	incq	%rax
   58ebb:      	movq	%rax, 0x170(%rdi)
   58ec2:      	movq	%rax, %rdx
   58ec5:      	orq	%rcx, %rdx
   58ec8:      	shrq	$0x20, %rdx
   58ecc:      	je	0x59140 <f.5+0x5e0>
   58ed2:      	xorl	%edx, %edx
   58ed4:      	divq	%rcx
   58ed7:      	testq	%rdx, %rdx
   58eda:      	jne	0x58efe <f.5+0x39e>
   58edc:      	movq	0x5565(%rip), %rsi      # 0x5e448 <native_roots.0>
   58ee3:      	movq	%rbx, 0x60(%rsp)
   58ee8:      	movq	%r13, %rbx
   58eeb:      	movq	%rdi, %r13
   58eee:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58ef3:      	movq	%r13, %rdi
   58ef6:      	movq	%rbx, %r13
   58ef9:      	movq	0x60(%rsp), %rbx
   58efe:      	movq	0x5543(%rip), %rdx      # 0x5e448 <native_roots.0>
   58f05:      	movl	$0x10, %esi
   58f0a:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58f0f:      	testq	%rax, %rax
   58f12:      	je	0x59234 <f.5+0x6d4>
   58f18:      	movq	$0xa, (%rax)
   58f1f:      	movq	%r12, 0x8(%rax)
   58f23:      	movq	%rax, 0x10(%r15)
   58f27:      	movq	0x38(%rsp), %rax
   58f2c:      	testq	%rax, %rax
   58f2f:      	movsd	-0x53517(%rip), %xmm3   # 0x5a20 <writev+0x5a20>
   58f37:      	je	0x5922f <f.5+0x6cf>
   58f3d:      	movl	$0x1, 0x8(%rax)
   58f44:      	movq	0x38(%rsp), %rax
   58f49:      	testq	%rax, %rax
   58f4c:      	movapd	0x80(%rsp), %xmm4
   58f55:      	je	0x5922f <f.5+0x6cf>
   58f5b:      	cmpl	$0x0, 0x8(%rax)
   58f5f:      	je	0x5922f <f.5+0x6cf>
   58f65:      	movq	0x10(%rax), %rax
   58f69:      	testq	%rax, %rax
   58f6c:      	je	0x5922f <f.5+0x6cf>
   58f72:      	movq	0x8(%rax), %rcx
   58f76:      	movq	%rbp, 0x48(%rsp)
   58f7b:      	movq	%rcx, 0x50(%rsp)
   58f80:      	movq	$0x6, 0x20(%rsp)
   58f89:      	unpcklpd	0x70(%rsp), %xmm4       # xmm4 = xmm4[0],mem[0]
   58f8f:      	xorl	%eax, %eax
   58f91:      	nopw	%cs:(%rax,%rax)
   58fa0:      	movapd	%xmm4, %xmm0
   58fa4:      	mulpd	%xmm4, %xmm0
   58fa8:      	movapd	%xmm0, %xmm1
   58fac:      	unpckhpd	%xmm0, %xmm1            # xmm1 = xmm1[1],xmm0[1]
   58fb0:      	movapd	%xmm1, %xmm2
   58fb4:      	addsd	%xmm0, %xmm2
   58fb8:      	ucomisd	%xmm3, %xmm2
   58fbc:      	ja	0x5901e <f.5+0x4be>
   58fbe:      	testq	%rcx, %rcx
   58fc1:      	je	0x5922f <f.5+0x6cf>
   58fc7:      	movq	0x18(%rcx), %rdx
   58fcb:      	testq	%rdx, %rdx
   58fce:      	je	0x5922f <f.5+0x6cf>
   58fd4:      	cmpl	$0x0, 0x8(%rdx)
   58fd8:      	je	0x5922f <f.5+0x6cf>
   58fde:      	movq	0x10(%rdx), %rdx
   58fe2:      	testq	%rdx, %rdx
   58fe5:      	je	0x5922f <f.5+0x6cf>
   58feb:      	movapd	%xmm4, %xmm2
   58fef:      	unpckhpd	%xmm4, %xmm2            # xmm2 = xmm2[1],xmm4[1]
   58ff3:      	mulsd	%xmm4, %xmm2
   58ff7:      	movupd	0x8(%rcx), %xmm4
   58ffc:      	movq	0x8(%rdx), %rcx
   59000:      	addsd	%xmm2, %xmm2
   59004:      	subsd	%xmm1, %xmm0
   59008:      	unpcklpd	%xmm2, %xmm0            # xmm0 = xmm0[0],xmm2[0]
   5900c:      	addpd	%xmm0, %xmm4
   59010:      	incq	%rax
   59013:      	cmpq	$0x40, %rax
   59017:      	jne	0x58fa0 <f.5+0x440>
   59019:      	movl	$0x40, %eax
   5901e:      	movq	%r14, %rcx
   59021:      	shrq	$0x20, %rcx
   59025:      	jne	0x5922f <f.5+0x6cf>
   5902b:      	testq	%rbp, %rbp
   5902e:      	je	0x5922f <f.5+0x6cf>
   59034:      	testb	$0x1, %bpl
   59038:      	jne	0x5922f <f.5+0x6cf>
   5903e:      	cmpq	0x8(%rbp), %r14
   59042:      	jae	0x5922f <f.5+0x6cf>
   59048:      	movq	%rax, 0x10(%rbp,%r14,8)
   5904d:      	movq	0x30(%rsp), %rdi
   59052:      	testq	%rdi, %rdi
   59055:      	je	0x5922f <f.5+0x6cf>
   5905b:      	movq	0x20(%rdi), %rax
   5905f:      	testq	%rax, %rax
   59062:      	je	0x5922f <f.5+0x6cf>
   59068:      	cmpl	$0x0, 0x8(%rax)
   5906c:      	je	0x5922f <f.5+0x6cf>
   59072:      	cmpq	$0x0, 0x10(%rax)
   59077:      	je	0x5922f <f.5+0x6cf>
   5907d:      	xorl	%eax, %eax
   5907f:      	cmpq	$0x0, 0x18(%rsp)
   59085:      	movq	%r13, %rcx
   59088:      	leaq	0x53b9(%rip), %rdx      # 0x5e448 <native_roots.0>
   5908f:      	cmoveq	%rdx, %rcx
   59093:      	sete	%al
   59096:      	addq	0x538b(%rip), %rax      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5909d:      	movq	0x538c(%rip), %rdx      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   590a4:      	cmpq	%rdx, %rax
   590a7:      	cmovaq	%rax, %rdx
   590ab:      	movq	(%rcx), %rcx
   590ae:      	movq	$0x7, 0x18(%rsp)
   590b7:      	movq	$0x0, 0x20(%rsp)
   590c0:      	movq	%rcx, 0x10(%rsp)
   590c5:      	movq	%r13, 0x537c(%rip)      # 0x5e448 <native_roots.0>
   590cc:      	movq	%rax, 0x5355(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   590d3:      	movq	%rdx, 0x5356(%rip)      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   590da:      	movq	%rdi, 0x28(%rsp)
   590df:      	xorpd	%xmm0, %xmm0
   590e3:      	leaq	0x30(%rsp), %rdx
   590e8:      	movupd	%xmm0, (%rdx)
   590ec:      	movq	$0x0, 0x10(%rdx)
   590f4:      	subq	$0x1, %rbx
   590f8:      	jae	0x58c00 <f.5+0xa0>
   590fe:      	jmp	0x59152 <f.5+0x5f2>
   59100:      	xorl	%edx, %edx
   59102:      	divl	%ecx
   59104:      	movl	%edx, %eax
   59106:      	movq	%r13, %rdx
   59109:      	testq	%rax, %rax
   5910c:      	jne	0x58d4e <f.5+0x1ee>
   59112:      	jmp	0x58d3c <f.5+0x1dc>
   59117:      	nopw	(%rax,%rax)
   59120:      	xorl	%edx, %edx
   59122:      	divl	%ecx
   59124:      	testq	%rdx, %rdx
   59127:      	jne	0x58e3e <f.5+0x2de>
   5912d:      	jmp	0x58e2c <f.5+0x2cc>
   59132:      	nopw	%cs:(%rax,%rax)
   59140:      	xorl	%edx, %edx
   59142:      	divl	%ecx
   59144:      	testq	%rdx, %rdx
   59147:      	jne	0x58efe <f.5+0x39e>
   5914d:      	jmp	0x58edc <f.5+0x37c>
   59152:      	decq	%rax
   59155:      	jmp	0x59160 <f.5+0x600>
   59157:      	testq	%rdi, %rdi
   5915a:      	je	0x5922f <f.5+0x6cf>
   59160:      	testb	$0x1, %dil
   59164:      	jne	0x5922f <f.5+0x6cf>
   5916a:      	movq	0x52cf(%rip), %r8       # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59171:      	testq	%r8, %r8
   59174:      	je	0x5922f <f.5+0x6cf>
   5917a:      	movq	(%rdi), %rdx
   5917d:      	testq	%rdx, %rdx
   59180:      	je	0x591dd <f.5+0x67d>
   59182:      	cmpq	$0x16, %rdx
   59186:      	je	0x591dd <f.5+0x67d>
   59188:      	movq	0x168(%r8), %rsi
   5918f:      	shrq	$0x2, %rdx
   59193:      	leaq	-0x1(%rdx), %r9
   59197:      	cmpq	%rsi, %r9
   5919a:      	jae	0x5922f <f.5+0x6cf>
   591a0:      	movq	0x160(%r8), %r8
   591a7:      	movq	-0x8(%r8,%rdx,8), %rdx
   591ac:      	testq	%rdx, %rdx
   591af:      	je	0x591dd <f.5+0x67d>
   591b1:      	cmpq	$0x16, %rdx
   591b5:      	je	0x591dd <f.5+0x67d>
   591b7:      	nopw	(%rax,%rax)
   591c0:      	shrq	$0x2, %rdx
   591c4:      	leaq	-0x1(%rdx), %r9
   591c8:      	cmpq	%rsi, %r9
   591cb:      	jae	0x5922f <f.5+0x6cf>
   591cd:      	movq	-0x8(%r8,%rdx,8), %rdx
   591d2:      	cmpq	$0x16, %rdx
   591d6:      	je	0x591dd <f.5+0x67d>
   591d8:      	testq	%rdx, %rdx
   591db:      	jne	0x591c0 <f.5+0x660>
   591dd:      	cmpq	$0x16, %rdx
   591e1:      	jne	0x5922f <f.5+0x6cf>
   591e3:      	movq	%rdi, 0x30(%rsp)
   591e8:      	movq	0x10(%rdi), %rdx
   591ec:      	testq	%rdx, %rdx
   591ef:      	je	0x5922f <f.5+0x6cf>
   591f1:      	cmpl	$0x0, 0x8(%rdx)
   591f5:      	je	0x5922f <f.5+0x6cf>
   591f7:      	movq	0x10(%rdx), %rdx
   591fb:      	testq	%rdx, %rdx
   591fe:      	je	0x5922f <f.5+0x6cf>
   59200:      	movq	0x18(%rdi), %rsi
   59204:      	movq	0x10(%rdx), %rdi
   59208:      	movq	%rcx, 0x5239(%rip)      # 0x5e448 <native_roots.0>
   5920f:      	movq	%rax, 0x5212(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59216:      	decq	%rsi
   59219:      	addq	$0x98, %rsp
   59220:      	popq	%rbx
   59221:      	popq	%r12
   59223:      	popq	%r13
   59225:      	popq	%r14
   59227:      	popq	%r15
   59229:      	popq	%rbp
   5922a:      	jmp	0x58740 <f.4>
   5922f:      	callq	0x54910 <native_trap>
   59234:      	leaq	-0x5041f(%rip), %rdi    # 0x8e1c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5923b:      	movl	$0x2f, %esi
   59240:      	callq	0x55910 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   59245:      	int3
   59246:      	int3
   59247:      	int3
   59248:      	int3
   59249:      	int3
   5924a:      	int3
   5924b:      	int3
   5924c:      	int3
   5924d:      	int3
   5924e:      	int3
   5924f:      	int3

0000000000059250 <f.7>:
   59250:      	pushq	%rbp
   59251:      	pushq	%r15
   59253:      	pushq	%r14
   59255:      	pushq	%r13
   59257:      	pushq	%r12
   59259:      	pushq	%rbx
   5925a:      	subq	$0x38, %rsp
   5925e:      	movq	%rsi, %rbx
   59261:      	movq	$0x4, 0x8(%rsp)
   5926a:      	movq	$0x0, 0x10(%rsp)
   59273:      	movq	0x51ce(%rip), %rcx      # 0x5e448 <native_roots.0>
   5927a:      	movq	%rcx, (%rsp)
   5927e:      	movq	%rsp, %r14
   59281:      	movq	%r14, 0x51c0(%rip)      # 0x5e448 <native_roots.0>
   59288:      	movq	0x5199(%rip), %rax      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5928f:      	leaq	0x1(%rax), %rdx
   59293:      	movq	%rdx, 0x518e(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5929a:      	movq	0x518f(%rip), %rsi      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   592a1:      	cmpq	%rsi, %rdx
   592a4:      	cmovaq	%rdx, %rsi
   592a8:      	movq	%rsi, 0x5181(%rip)      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   592af:      	movq	%rdi, 0x18(%rsp)
   592b4:      	xorps	%xmm0, %xmm0
   592b7:      	movups	%xmm0, 0x20(%rsp)
   592bc:      	testq	%rbx, %rbx
   592bf:      	js	0x594ad <f.7+0x25d>
   592c5:      	testq	%rdi, %rdi
   592c8:      	sete	%al
   592cb:      	movl	%edi, %ecx
   592cd:      	orb	%al, %cl
   592cf:      	testb	$0x1, %cl
   592d2:      	jne	0x592ff <f.7+0xaf>
   592d4:      	movq	0x5165(%rip), %rdx      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   592db:      	testq	%rdx, %rdx
   592de:      	je	0x594a5 <f.7+0x255>
   592e4:      	movq	(%rdi), %rax
   592e7:      	testq	%rax, %rax
   592ea:      	je	0x592f6 <f.7+0xa6>
   592ec:      	cmpq	$0x26, %rax
   592f0:      	jne	0x594ce <f.7+0x27e>
   592f6:      	cmpq	$0x26, %rax
   592fa:      	sete	%al
   592fd:      	jmp	0x59301 <f.7+0xb1>
   592ff:      	xorl	%eax, %eax
   59301:      	leaq	0x20(%rsp), %r15
   59306:      	movq	%rbx, %r12
   59309:      	shrq	$0x20, %r12
   5930d:      	leaq	0x5134(%rip), %r13      # 0x5e448 <native_roots.0>
   59314:      	jmp	0x59327 <f.7+0xd7>
   59316:      	nopw	%cs:(%rax,%rax)
   59320:      	cmpq	$0x26, %rax
   59324:      	sete	%al
   59327:      	testb	$0x1, %al
   59329:      	je	0x594a5 <f.7+0x255>
   5932f:      	movq	%rdi, 0x20(%rsp)
   59334:      	testq	%rdi, %rdi
   59337:      	je	0x594a5 <f.7+0x255>
   5933d:      	movq	0x8(%rdi), %rsi
   59341:      	movq	%rsi, %rax
   59344:      	shrq	$0x20, %rax
   59348:      	jne	0x594a5 <f.7+0x255>
   5934e:      	testq	%r12, %r12
   59351:      	jne	0x594a5 <f.7+0x255>
   59357:      	movq	0x10(%rdi), %rbp
   5935b:      	movq	%rbp, 0x30(%rsp)
   59360:      	movq	$0x4, 0x10(%rsp)
   59369:      	movl	$0x2b, %edi
   5936e:      	xorl	%edx, %edx
   59370:      	callq	0x57d30 <native_array_new>
   59375:      	testq	%rbp, %rbp
   59378:      	je	0x594a5 <f.7+0x255>
   5937e:      	testb	$0x1, %bpl
   59382:      	jne	0x594a5 <f.7+0x255>
   59388:      	cmpq	0x8(%rbp), %rbx
   5938c:      	jae	0x594a5 <f.7+0x255>
   59392:      	movq	%rax, 0x10(%rbp,%rbx,8)
   59397:      	movq	0x20(%rsp), %rdi
   5939c:      	testq	%rdi, %rdi
   5939f:      	je	0x594a5 <f.7+0x255>
   593a5:      	movq	0x18(%rdi), %rax
   593a9:      	testq	%rax, %rax
   593ac:      	je	0x594a5 <f.7+0x255>
   593b2:      	cmpl	$0x0, 0x8(%rax)
   593b6:      	je	0x594a5 <f.7+0x255>
   593bc:      	cmpq	$0x0, 0x10(%rax)
   593c1:      	je	0x594a5 <f.7+0x255>
   593c7:      	xorl	%eax, %eax
   593c9:      	cmpq	$0x0, 0x8(%rsp)
   593cf:      	sete	%al
   593d2:      	movq	%r14, %rcx
   593d5:      	cmoveq	%r13, %rcx
   593d9:      	addq	0x5048(%rip), %rax      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   593e0:      	movq	(%rcx), %rcx
   593e3:      	movq	$0x4, 0x8(%rsp)
   593ec:      	movq	$0x0, 0x10(%rsp)
   593f5:      	movq	%rcx, (%rsp)
   593f9:      	movq	%r14, 0x5048(%rip)      # 0x5e448 <native_roots.0>
   59400:      	movq	%rax, 0x5021(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59407:      	movq	0x5022(%rip), %rdx      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5940e:      	cmpq	%rdx, %rax
   59411:      	cmovaq	%rax, %rdx
   59415:      	movq	%rdx, 0x5014(%rip)      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5941c:      	movq	%rdi, 0x18(%rsp)
   59421:      	xorps	%xmm0, %xmm0
   59424:      	movups	%xmm0, (%r15)
   59428:      	testq	%rbx, %rbx
   5942b:      	je	0x594aa <f.7+0x25a>
   5942d:      	decq	%rbx
   59430:      	xorl	%eax, %eax
   59432:      	testb	$0x1, %dil
   59436:      	jne	0x59327 <f.7+0xd7>
   5943c:      	movq	0x4ffd(%rip), %rdx      # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59443:      	testq	%rdx, %rdx
   59446:      	je	0x594a5 <f.7+0x255>
   59448:      	movq	(%rdi), %rax
   5944b:      	testq	%rax, %rax
   5944e:      	je	0x59320 <f.7+0xd0>
   59454:      	cmpq	$0x26, %rax
   59458:      	je	0x59320 <f.7+0xd0>
   5945e:      	movq	0x168(%rdx), %rcx
   59465:      	shrq	$0x2, %rax
   59469:      	leaq	-0x1(%rax), %rsi
   5946d:      	cmpq	%rcx, %rsi
   59470:      	jae	0x594a5 <f.7+0x255>
   59472:      	movq	0x160(%rdx), %rdx
   59479:      	nopl	(%rax)
   59480:      	movq	-0x8(%rdx,%rax,8), %rax
   59485:      	testq	%rax, %rax
   59488:      	je	0x59320 <f.7+0xd0>
   5948e:      	cmpq	$0x26, %rax
   59492:      	je	0x59320 <f.7+0xd0>
   59498:      	shrq	$0x2, %rax
   5949c:      	leaq	-0x1(%rax), %rsi
   594a0:      	cmpq	%rcx, %rsi
   594a3:      	jb	0x59480 <f.7+0x230>
   594a5:      	callq	0x54910 <native_trap>
   594aa:      	decq	%rax
   594ad:      	movq	%rcx, 0x4f94(%rip)      # 0x5e448 <native_roots.0>
   594b4:      	movq	%rax, 0x4f6d(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   594bb:      	xorl	%eax, %eax
   594bd:      	addq	$0x38, %rsp
   594c1:      	popq	%rbx
   594c2:      	popq	%r12
   594c4:      	popq	%r13
   594c6:      	popq	%r14
   594c8:      	popq	%r15
   594ca:      	popq	%rbp
   594cb:      	retq	$0x8
   594ce:      	movq	0x168(%rdx), %rcx
   594d5:      	shrq	$0x2, %rax
   594d9:      	leaq	-0x1(%rax), %rsi
   594dd:      	cmpq	%rcx, %rsi
   594e0:      	jae	0x594a5 <f.7+0x255>
   594e2:      	movq	0x160(%rdx), %rdx
   594e9:      	nopl	(%rax)
   594f0:      	movq	-0x8(%rdx,%rax,8), %rax
   594f5:      	testq	%rax, %rax
   594f8:      	je	0x592f6 <f.7+0xa6>
   594fe:      	cmpq	$0x26, %rax
   59502:      	je	0x592f6 <f.7+0xa6>
   59508:      	shrq	$0x2, %rax
   5950c:      	leaq	-0x1(%rax), %rsi
   59510:      	cmpq	%rcx, %rsi
   59513:      	jb	0x594f0 <f.7+0x2a0>
   59515:      	jmp	0x594a5 <f.7+0x255>
   59517:      	int3
   59518:      	int3
   59519:      	int3
   5951a:      	int3
   5951b:      	int3
   5951c:      	int3
   5951d:      	int3
   5951e:      	int3
   5951f:      	int3

0000000000059520 <f.3>:
   59520:      	movq	$0x1, -0x18(%rsp)
   59529:      	movq	0x4f18(%rip), %rax      # 0x5e448 <native_roots.0>
   59530:      	movq	%rax, -0x20(%rsp)
   59535:      	leaq	-0x20(%rsp), %rax
   5953a:      	movq	%rax, 0x4f07(%rip)      # 0x5e448 <native_roots.0>
   59541:      	movq	0x4ee0(%rip), %rax      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59548:      	incq	%rax
   5954b:      	movq	%rax, 0x4ed6(%rip)      # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59552:      	movq	0x4ed7(%rip), %rcx      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59559:      	cmpq	%rcx, %rax
   5955c:      	cmovbeq	%rcx, %rax
   59560:      	movq	%rax, 0x4ec9(%rip)      # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59567:      	movq	%rdi, -0x8(%rsp)
   5956c:      	movq	$0x1, -0x10(%rsp)
   59575:      	movq	%rdx, -0x28(%rsp)
   5957a:      	leaq	-0x28(%rsp), %rax
   5957f:      	movq	-0x28(%rsp), %rax
   59584:      	cmpq	$0x0, -0x18(%rsp)
   5958a:      	je	0x5959f <f.3+0x7f>
   5958c:      	movq	-0x20(%rsp), %rcx
   59591:      	movq	%rcx, 0x4eb0(%rip)      # 0x5e448 <native_roots.0>
   59598:      	decq	0x4e89(%rip)            # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5959f:      	retq	$0x8

Disassembly of section .init:
