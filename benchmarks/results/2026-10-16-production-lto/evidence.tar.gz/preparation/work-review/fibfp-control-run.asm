0000000000012f90 <wasm_native_861690fa9409df3720afc49857d3c8651f13485137b07087a368d1e3797c9741::run::h2006b2c19fd62806>:
   12f90:      	pushq	%rbp
   12f91:      	pushq	%rbx
   12f92:      	subq	$0x58, %rsp
   12f96:      	callq	*0x6e414(%rip)          # 0x813b0 <writev+0x813b0>
   12f9c:      	callq	*0x6e416(%rip)          # 0x813b8 <writev+0x813b8>
   12fa2:      	callq	*0x6e418(%rip)          # 0x813c0 <writev+0x813c0>
   12fa8:      	callq	0x52980 <<std::sys::pal::unix::time::Timespec>::now>
   12fad:      	movq	%rax, %rbx
   12fb0:      	movl	%edx, %ebp
   12fb2:      	movl	$0xa, %edi
   12fb7:      	callq	*0x6e40b(%rip)          # 0x813c8 <writev+0x813c8>
   12fbd:      	movsd	%xmm0, 0x28(%rsp)
   12fc3:      	movsd	%xmm0, 0x30(%rsp)
   12fc9:      	callq	0x52980 <<std::sys::pal::unix::time::Timespec>::now>
   12fce:      	movq	%rax, 0x48(%rsp)
   12fd3:      	movl	%edx, 0x50(%rsp)
   12fd7:      	movq	%rbx, 0x38(%rsp)
   12fdc:      	movl	%ebp, 0x40(%rsp)
   12fe0:      	leaq	0x8(%rsp), %rdi
   12fe5:      	leaq	0x48(%rsp), %rsi
   12fea:      	leaq	0x38(%rsp), %rbx
   12fef:      	movq	%rbx, %rdx
   12ff2:      	callq	0x528b0 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   12ff7:      	cmpb	$0x0, 0x8(%rsp)
   12ffc:      	xorpd	%xmm0, %xmm0
   13000:      	jne	0x13038 <wasm_native_861690fa9409df3720afc49857d3c8651f13485137b07087a368d1e3797c9741::run::h2006b2c19fd62806+0xa8>
   13002:      	movsd	0x10(%rsp), %xmm1
   13008:      	unpcklps	-0xf0bf(%rip), %xmm1    # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x3f50 <writev+0x3f50>
   1300f:      	subpd	-0xf117(%rip), %xmm1    # 0x3f00 <writev+0x3f00>
   13017:      	movapd	%xmm1, %xmm2
   1301b:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   1301f:      	xorps	%xmm0, %xmm0
   13022:      	cvtsi2sdl	0x18(%rsp), %xmm0
   13028:      	addsd	%xmm1, %xmm2
   1302c:      	divsd	-0xeeb4(%rip), %xmm0    # 0x4180 <writev+0x4180>
   13034:      	addsd	%xmm2, %xmm0
   13038:      	movsd	0x28(%rsp), %xmm1
   1303e:      	ucomisd	-0xee8e(%rip), %xmm1    # 0x41b8 <writev+0x41b8>
   13046:      	movsd	%xmm0, 0x38(%rsp)
   1304c:      	jne	0x130af <wasm_native_861690fa9409df3720afc49857d3c8651f13485137b07087a368d1e3797c9741::run::h2006b2c19fd62806+0x11f>
   1304e:      	jp	0x130af <wasm_native_861690fa9409df3720afc49857d3c8651f13485137b07087a368d1e3797c9741::run::h2006b2c19fd62806+0x11f>
   13050:      	leaq	0x30(%rsp), %rax
   13055:      	movq	%rax, 0x8(%rsp)
   1305a:      	leaq	0x881f(%rip), %rax      # 0x1b880 <<f64 as core::fmt::Display>::fmt>
   13061:      	movq	%rax, 0x10(%rsp)
   13066:      	movq	%rbx, 0x18(%rsp)
   1306b:      	movq	%rax, 0x20(%rsp)
   13070:      	leaq	-0xd403(%rip), %rdi     # 0x5c74 <writev+0x5c74>
   13077:      	leaq	0x8(%rsp), %rsi
   1307c:      	callq	0x57800 <std::io::stdio::_print>
   13081:      	leaq	0x8(%rsp), %rdi
   13086:      	callq	0x262c0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   1308b:      	movq	0x8(%rsp), %rbx
   13090:      	testq	%rbx, %rbx
   13093:      	jle	0x130a0 <wasm_native_861690fa9409df3720afc49857d3c8651f13485137b07087a368d1e3797c9741::run::h2006b2c19fd62806+0x110>
   13095:      	movq	0x10(%rsp), %rdi
   1309a:      	callq	*0x6e330(%rip)          # 0x813d0 <writev+0x813d0>
   130a0:      	xorl	%eax, %eax
   130a2:      	negq	%rbx
   130a5:      	setno	%al
   130a8:      	addq	$0x58, %rsp
   130ac:      	popq	%rbx
   130ad:      	popq	%rbp
   130ae:      	retq
   130af:      	leaq	0x8(%rsp), %rdi
   130b4:      	callq	0x262c0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   130b9:      	cmpq	$0x0, 0x8(%rsp)
   130bf:      	jle	0x130cc <wasm_native_861690fa9409df3720afc49857d3c8651f13485137b07087a368d1e3797c9741::run::h2006b2c19fd62806+0x13c>
   130c1:      	movq	0x10(%rsp), %rdi
   130c6:      	callq	*0x6e304(%rip)          # 0x813d0 <writev+0x813d0>
   130cc:      	movl	$0x1, %eax
   130d1:      	addq	$0x58, %rsp
   130d5:      	popq	%rbx
   130d6:      	popq	%rbp
   130d7:      	retq
   130d8:      	int3
   130d9:      	int3
   130da:      	int3
   130db:      	int3
   130dc:      	int3
   130dd:      	int3
   130de:      	int3
   130df:      	int3
