000000000004ba30 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05>:
   4ba30:      	pushq	%rbp
   4ba31:      	pushq	%r15
   4ba33:      	pushq	%r14
   4ba35:      	pushq	%r13
   4ba37:      	pushq	%r12
   4ba39:      	pushq	%rbx
   4ba3a:      	subq	$0x3c8, %rsp            # imm = 0x3C8
   4ba41:      	cmpq	$0x0, 0x178c7(%rip)     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4ba49:      	jne	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4ba4f:      	movl	$0x510, %edi            # imm = 0x510
   4ba54:      	callq	*0x15cfe(%rip)          # 0x61758 <writev+0x61758>
   4ba5a:      	testq	%rax, %rax
   4ba5d:      	je	0x4d4bd <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a8d>
   4ba63:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4ba6d:      	movq	%rax, 0x28(%rsp)
   4ba72:      	movq	%rax, %r13
   4ba75:      	addq	$0x10, %r13
   4ba79:      	leaq	0x15648(%rip), %rbp     # 0x610c8 <native_gc_layouts+0x8>
   4ba80:      	xorl	%r14d, %r14d
   4ba83:      	movabsq	$0x3e7f374811212d, %rax # imm = 0x3E7F374811212D
   4ba8d:      	jmp	0x4bab6 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x86>
   4ba8f:      	nop
   4ba90:      	movq	%rcx, %r12
   4ba93:      	jne	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4ba99:      	movq	%r12, -0x10(%r13)
   4ba9d:      	movq	%rbx, -0x8(%r13)
   4baa1:      	movq	%r12, (%r13)
   4baa5:      	incq	%r14
   4baa8:      	addq	$0x18, %r13
   4baac:      	addq	$0x10, %rbp
   4bab0:      	cmpq	$0x36, %r14
   4bab4:      	je	0x4bb24 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xf4>
   4bab6:      	cmpl	$0x2, -0x8(%rbp)
   4baba:      	jae	0x4ba90 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x60>
   4babc:      	btq	%r14, %rax
   4bac0:      	jae	0x4bad0 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xa0>
   4bac2:      	movl	$0x4, %ebx
   4bac7:      	xorl	%r12d, %r12d
   4baca:      	jmp	0x4ba99 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x69>
   4bacc:      	nopl	(%rax)
   4bad0:      	movl	-0x4(%rbp), %r12d
   4bad4:      	leaq	(,%r12,4), %r15
   4badc:      	movq	(%rbp), %rax
   4bae0:      	movq	%rax, 0x10(%rsp)
   4bae5:      	movq	%r15, %rdi
   4bae8:      	callq	*0x15c6a(%rip)          # 0x61758 <writev+0x61758>
   4baee:      	testq	%rax, %rax
   4baf1:      	je	0x4d4b5 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a85>
   4baf7:      	movq	%rax, %rbx
   4bafa:      	movq	%rax, %rdi
   4bafd:      	movq	0x10(%rsp), %rsi
   4bb02:      	movq	%r15, %rdx
   4bb05:      	callq	*0x15d45(%rip)          # 0x61850 <writev+0x61850>
   4bb0b:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4bb15:      	movabsq	$0x3e7f374811212d, %rax # imm = 0x3E7F374811212D
   4bb1f:      	jmp	0x4ba99 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x69>
   4bb24:      	movl	$0x78, %edi
   4bb29:      	callq	*0x15c29(%rip)          # 0x61758 <writev+0x61758>
   4bb2f:      	testq	%rax, %rax
   4bb32:      	je	0x4d4c7 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a97>
   4bb38:      	movq	%rax, %r15
   4bb3b:      	movq	0x1594e(%rip), %rax     # 0x61490 <native_gc_globals+0x70>
   4bb42:      	movq	%rax, 0x70(%r15)
   4bb46:      	movaps	0x15933(%rip), %xmm0    # 0x61480 <native_gc_globals+0x60>
   4bb4d:      	movups	%xmm0, 0x60(%r15)
   4bb52:      	movaps	0x15917(%rip), %xmm0    # 0x61470 <native_gc_globals+0x50>
   4bb59:      	movups	%xmm0, 0x50(%r15)
   4bb5e:      	movaps	0x158fb(%rip), %xmm0    # 0x61460 <native_gc_globals+0x40>
   4bb65:      	movups	%xmm0, 0x40(%r15)
   4bb6a:      	movaps	0x158df(%rip), %xmm0    # 0x61450 <native_gc_globals+0x30>
   4bb71:      	movups	%xmm0, 0x30(%r15)
   4bb76:      	movaps	0x158c3(%rip), %xmm0    # 0x61440 <native_gc_globals+0x20>
   4bb7d:      	movups	%xmm0, 0x20(%r15)
   4bb82:      	movaps	0x158a7(%rip), %xmm0    # 0x61430 <native_gc_globals+0x10>
   4bb89:      	movups	%xmm0, 0x10(%r15)
   4bb8e:      	movapd	0x1588a(%rip), %xmm0    # 0x61420 <native_gc_globals>
   4bb96:      	movupd	%xmm0, (%r15)
   4bb9b:      	movl	$0x1, %edi
   4bba0:      	movl	$0x1b0, %esi            # imm = 0x1B0
   4bba5:      	callq	*0x15b05(%rip)          # 0x616b0 <writev+0x616b0>
   4bbab:      	testq	%rax, %rax
   4bbae:      	je	0x4d4d1 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1aa1>
   4bbb4:      	movq	%rax, %r13
   4bbb7:      	movabsq	$0x3fffffffffff8000, %rbx # imm = 0x3FFFFFFFFFFF8000
   4bbc1:      	leaq	-0x42a9d(%rip), %rsi    # 0x912b <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4bbc8:      	leaq	0x80(%rsp), %rdi
   4bbd0:      	movl	$0x13, %edx
   4bbd5:      	callq	0x55790 <std::env::_var_os>
   4bbda:      	movq	0x80(%rsp), %rax
   4bbe2:      	negq	%rax
   4bbe5:      	jo	0x4bc27 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1f7>
   4bbe7:      	jae	0x4bbf7 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1c7>
   4bbe9:      	movq	0x88(%rsp), %rdi
   4bbf1:      	callq	*0x15ac1(%rip)          # 0x616b8 <writev+0x616b8>
   4bbf7:      	leaq	-0x42ad3(%rip), %rdi    # 0x912b <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4bbfe:      	movl	$0x13, %esi
   4bc03:      	xorl	%edx, %edx
   4bc05:      	callq	0x55980 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4bc0a:      	movq	%rax, %rdx
   4bc0d:      	addq	$-0x8000, %rax          # imm = 0x8000
   4bc13:      	cmpq	%rbx, %rax
   4bc16:      	jae	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4bc1c:      	andq	%rbx, %rdx
   4bc1f:      	movq	%rdx, %rbp
   4bc22:      	movq	%rdx, %r14
   4bc25:      	jmp	0x4bc32 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x202>
   4bc27:      	movl	$0x10000000, %edx       # imm = 0x10000000
   4bc2c:      	xorl	%r14d, %r14d
   4bc2f:      	movq	%rbx, %rbp
   4bc32:      	leaq	-0x42afb(%rip), %rdi    # 0x913e <core::num::flt2dec::strategy::dragon::POW5TO256+0x60a>
   4bc39:      	movl	$0x16, %esi
   4bc3e:      	callq	0x55980 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4bc43:      	movq	%rax, %r12
   4bc46:      	addq	$-0x8000, %rax          # imm = 0x8000
   4bc4c:      	cmpq	%rbx, %rax
   4bc4f:      	jae	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4bc55:      	movq	%r13, 0x10(%rsp)
   4bc5a:      	andq	%rbx, %r12
   4bc5d:      	cmpq	%rbp, %r12
   4bc60:      	ja	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4bc66:      	leaq	-0x42b19(%rip), %rdi    # 0x9154 <core::num::flt2dec::strategy::dragon::POW5TO256+0x620>
   4bc6d:      	movl	$0x12, %esi
   4bc72:      	movl	$0x800000, %edx         # imm = 0x800000
   4bc77:      	callq	0x55980 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4bc7c:      	movq	%rax, %r13
   4bc7f:      	leaq	-0x42b20(%rip), %rsi    # 0x9166 <core::num::flt2dec::strategy::dragon::POW5TO256+0x632>
   4bc86:      	leaq	0x80(%rsp), %rdi
   4bc8e:      	movl	$0xe, %edx
   4bc93:      	callq	0x55790 <std::env::_var_os>
   4bc98:      	movq	0x80(%rsp), %rax
   4bca0:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4bcaa:      	cmpq	%rcx, %rax
   4bcad:      	setne	%bl
   4bcb0:      	testq	%rax, %rax
   4bcb3:      	jle	0x4bcc3 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x293>
   4bcb5:      	movq	0x88(%rsp), %rdi
   4bcbd:      	callq	*0x159f5(%rip)          # 0x616b8 <writev+0x616b8>
   4bcc3:      	movq	$0x0, 0x80(%rsp)
   4bccf:      	movq	$0x8, 0x88(%rsp)
   4bcdb:      	xorpd	%xmm0, %xmm0
   4bcdf:      	movupd	%xmm0, 0x90(%rsp)
   4bce8:      	movupd	%xmm0, 0x138(%rsp)
   4bcf1:      	movupd	%xmm0, 0x148(%rsp)
   4bcfa:      	movupd	%xmm0, 0x158(%rsp)
   4bd03:      	movq	%r12, 0x110(%rsp)
   4bd0b:      	movq	%rbp, 0x118(%rsp)
   4bd13:      	movq	%r14, 0x120(%rsp)
   4bd1b:      	movq	%r13, 0x128(%rsp)
   4bd23:      	movb	%bl, 0x130(%rsp)
   4bd2a:      	movq	%r13, 0x168(%rsp)
   4bd32:      	movq	$0x8, 0xa0(%rsp)
   4bd3e:      	movupd	%xmm0, 0xa8(%rsp)
   4bd47:      	movq	$0x8, 0xb8(%rsp)
   4bd53:      	movq	$0x0, 0xc0(%rsp)
   4bd5f:      	movq	$0x36, 0xc8(%rsp)
   4bd6b:      	movq	0x28(%rsp), %rax
   4bd70:      	movq	%rax, 0xd0(%rsp)
   4bd78:      	movq	$0x36, 0xd8(%rsp)
   4bd84:      	movq	$0xf, 0xe0(%rsp)
   4bd90:      	movq	%r15, 0xe8(%rsp)
   4bd98:      	movq	$0xf, 0xf0(%rsp)
   4bda4:      	movq	$0x0, 0xf8(%rsp)
   4bdb0:      	movq	$0x8, 0x100(%rsp)
   4bdbc:      	movq	$0x0, 0x108(%rsp)
   4bdc8:      	movupd	%xmm0, 0x1c0(%rsp)
   4bdd1:      	movupd	%xmm0, 0x1b0(%rsp)
   4bdda:      	movupd	%xmm0, 0x1a0(%rsp)
   4bde3:      	movupd	%xmm0, 0x190(%rsp)
   4bdec:      	movupd	%xmm0, 0x180(%rsp)
   4bdf5:      	movupd	%xmm0, 0x170(%rsp)
   4bdfe:      	movq	$0x0, 0x1d0(%rsp)
   4be0a:      	leaq	0x80(%rsp), %r14
   4be12:      	movq	%r14, %rdi
   4be15:      	movq	%r12, %rsi
   4be18:      	callq	0x55bd0 <snail_runtime::native_gc::Collector::add_region::h9dcdb0f5d1e85429>
   4be1d:      	movq	0x80(%rsp), %r13
   4be25:      	movq	0x88(%rsp), %rcx
   4be2d:      	movq	%rcx, 0x38(%rsp)
   4be32:      	movq	0x90(%rsp), %rbx
   4be3a:      	movq	0x98(%rsp), %rcx
   4be42:      	movq	%rcx, 0x60(%rsp)
   4be47:      	movq	0xa0(%rsp), %rcx
   4be4f:      	movq	%rcx, 0x48(%rsp)
   4be54:      	movq	0xb0(%rsp), %rcx
   4be5c:      	movq	%rcx, 0x68(%rsp)
   4be61:      	movq	0xb8(%rsp), %rcx
   4be69:      	movq	%rcx, 0x50(%rsp)
   4be6e:      	movq	0xc8(%rsp), %rcx
   4be76:      	movq	%rcx, 0x70(%rsp)
   4be7b:      	movq	0xd0(%rsp), %rcx
   4be83:      	movq	%rcx, 0x40(%rsp)
   4be88:      	movq	0xd8(%rsp), %r15
   4be90:      	movq	0xe0(%rsp), %rcx
   4be98:      	movq	%rcx, 0x78(%rsp)
   4be9d:      	movq	0xe8(%rsp), %rcx
   4bea5:      	movq	%rcx, 0x58(%rsp)
   4beaa:      	movq	0xf8(%rsp), %rbp
   4beb2:      	movq	0x100(%rsp), %r12
   4beba:      	testb	%al, %al
   4bebc:      	movq	%rbp, 0x28(%rsp)
   4bec1:      	je	0x4d4db <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1aab>
   4bec7:      	leaq	0x108(%rsp), %rsi
   4becf:      	movq	0xf0(%rsp), %rax
   4bed7:      	movq	%rax, 0x210(%rsp)
   4bedf:      	movq	0xa8(%rsp), %rax
   4bee7:      	movq	%rax, 0x200(%rsp)
   4beef:      	movq	0xc0(%rsp), %rax
   4bef7:      	movq	%rax, 0x208(%rsp)
   4beff:      	leaq	0x228(%rsp), %rdi
   4bf07:      	movl	$0xd0, %edx
   4bf0c:      	callq	*0x1593e(%rip)          # 0x61850 <writev+0x61850>
   4bf12:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4bf1c:      	cmpq	%rax, %r13
   4bf1f:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4bf25:      	leaq	0x2f8(%rsp), %rdi
   4bf2d:      	leaq	0x228(%rsp), %rsi
   4bf35:      	movl	$0xd0, %edx
   4bf3a:      	callq	*0x15910(%rip)          # 0x61850 <writev+0x61850>
   4bf40:      	movupd	-0x42bbd(%rip), %xmm0   # 0x938b <core::num::flt2dec::strategy::dragon::POW5TO256+0x857>
   4bf48:      	movapd	%xmm0, 0x80(%rsp)
   4bf51:      	movabsq	$0x4c41565245544e49, %rax # imm = 0x4C41565245544E49
   4bf5b:      	movq	%rax, 0x90(%rsp)
   4bf63:      	movb	$0x0, 0x98(%rsp)
   4bf6b:      	movb	$0x1, %al
   4bf6d:      	testb	%al, %al
   4bf6f:      	je	0x4bf7d <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x54d>
   4bf71:      	movabsq	$0x414e5f4c49414e53, %rax # imm = 0x414E5F4C49414E53
   4bf7b:      	jmp	0x4bf97 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x567>
   4bf7d:      	xorl	%eax, %eax
   4bf7f:      	nop
   4bf80:      	cmpb	$0x0, 0x80(%rsp,%rax)
   4bf88:      	je	0x4c003 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x5d3>
   4bf8a:      	incq	%rax
   4bf8d:      	jne	0x4bf80 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x550>
   4bf8f:      	movq	0x80(%rsp), %rax
   4bf97:      	movq	0x88(%rsp), %rcx
   4bf9f:      	movabsq	$0x101010101010100, %rdx # imm = 0x101010101010100
   4bfa9:      	movq	%rdx, %rsi
   4bfac:      	subq	%rax, %rsi
   4bfaf:      	orq	%rax, %rsi
   4bfb2:      	subq	%rcx, %rdx
   4bfb5:      	orq	%rcx, %rdx
   4bfb8:      	andq	%rsi, %rdx
   4bfbb:      	notq	%rdx
   4bfbe:      	movabsq	$-0x7f7f7f7f7f7f7f80, %rax # imm = 0x8080808080808080
   4bfc8:      	xorl	%ecx, %ecx
   4bfca:      	testq	%rax, %rdx
   4bfcd:      	sete	%cl
   4bfd0:      	shll	$0x4, %ecx
   4bfd3:      	leaq	(%rsp,%rcx), %rdx
   4bfd7:      	addq	$0x80, %rdx
   4bfde:      	movq	%rcx, %rsi
   4bfe1:      	xorq	$0x19, %rsi
   4bfe5:      	xorl	%eax, %eax
   4bfe7:      	nopw	(%rax,%rax)
   4bff0:      	cmpb	$0x0, (%rdx,%rax)
   4bff4:      	je	0x4c000 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x5d0>
   4bff6:      	incq	%rax
   4bff9:      	cmpq	%rax, %rsi
   4bffc:      	jne	0x4bff0 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x5c0>
   4bffe:      	jmp	0x4c051 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x621>
   4c000:      	addq	%rcx, %rax
   4c003:      	cmpq	$0x18, %rax
   4c007:      	jne	0x4c051 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x621>
   4c009:      	movq	%r13, 0x8(%rsp)
   4c00e:      	leaq	0x228(%rsp), %rdi
   4c016:      	leaq	0x80(%rsp), %rsi
   4c01e:      	callq	0x46c60 <std::sys::env::unix::getenv::{closure#0}>
   4c023:      	movq	0x228(%rsp), %rdx
   4c02b:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4c035:      	leaq	0x1(%rcx), %rax
   4c039:      	cmpq	%rax, %rdx
   4c03c:      	jne	0x4d0be <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x168e>
   4c042:      	movq	0x230(%rsp), %rax
   4c04a:      	movq	0x8(%rsp), %r13
   4c04f:      	jmp	0x4c06d <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x63d>
   4c051:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4c05b:      	incq	%rax
   4c05e:      	movq	%rax, 0x228(%rsp)
   4c066:      	leaq	0x14493(%rip), %rax     # 0x60500 <writev+0x60500>
   4c06d:      	movl	%eax, %ecx
   4c06f:      	andl	$0x3, %ecx
   4c072:      	leal	-0x2(%rcx), %edx
   4c075:      	cmpl	$0x2, %edx
   4c078:      	jb	0x4c0c7 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x697>
   4c07a:      	testq	%rcx, %rcx
   4c07d:      	je	0x4c0c7 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x697>
   4c07f:      	movq	%r13, %r14
   4c082:      	leaq	-0x1(%rax), %rcx
   4c086:      	movq	%rcx, 0x8(%rsp)
   4c08b:      	movq	-0x1(%rax), %rbp
   4c08f:      	movq	0x7(%rax), %r13
   4c093:      	movq	(%r13), %rax
   4c097:      	testq	%rax, %rax
   4c09a:      	je	0x4c0a1 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x671>
   4c09c:      	movq	%rbp, %rdi
   4c09f:      	callq	*%rax
   4c0a1:      	cmpq	$0x0, 0x8(%r13)
   4c0a6:      	je	0x4c0b1 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x681>
   4c0a8:      	movq	%rbp, %rdi
   4c0ab:      	callq	*0x15607(%rip)          # 0x616b8 <writev+0x616b8>
   4c0b1:      	movq	0x8(%rsp), %rdi
   4c0b6:      	callq	*0x155fc(%rip)          # 0x616b8 <writev+0x616b8>
   4c0bc:      	movq	%r14, %r13
   4c0bf:      	leaq	0x80(%rsp), %r14
   4c0c7:      	xorl	%ebp, %ebp
   4c0c9:      	movl	$0x180, %edi            # imm = 0x180
   4c0ce:      	callq	*0x15684(%rip)          # 0x61758 <writev+0x61758>
   4c0d4:      	testq	%rax, %rax
   4c0d7:      	je	0x4d246 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1816>
   4c0dd:      	movq	%r13, %rcx
   4c0e0:      	movq	%rax, %r13
   4c0e3:      	movq	%rcx, (%rax)
   4c0e6:      	movq	0x38(%rsp), %rcx
   4c0eb:      	movq	%rcx, 0x8(%rax)
   4c0ef:      	movq	%rbx, 0x10(%rax)
   4c0f3:      	movq	0x60(%rsp), %rcx
   4c0f8:      	movq	%rcx, 0x18(%rax)
   4c0fc:      	movq	0x48(%rsp), %rcx
   4c101:      	movq	%rcx, 0x20(%rax)
   4c105:      	movq	0x200(%rsp), %rcx
   4c10d:      	movq	%rcx, 0x28(%rax)
   4c111:      	movq	0x68(%rsp), %rcx
   4c116:      	movq	%rcx, 0x30(%rax)
   4c11a:      	movq	0x50(%rsp), %rcx
   4c11f:      	movq	%rcx, 0x38(%rax)
   4c123:      	movq	0x208(%rsp), %rcx
   4c12b:      	movq	%rcx, 0x40(%rax)
   4c12f:      	movq	0x70(%rsp), %rcx
   4c134:      	movq	%rcx, 0x48(%rax)
   4c138:      	movq	0x40(%rsp), %rcx
   4c13d:      	movq	%rcx, 0x50(%rax)
   4c141:      	movq	%r15, 0x58(%rax)
   4c145:      	movq	0x78(%rsp), %rcx
   4c14a:      	movq	%rcx, 0x60(%rax)
   4c14e:      	movq	0x58(%rsp), %rcx
   4c153:      	movq	%rcx, 0x68(%rax)
   4c157:      	movq	0x210(%rsp), %rcx
   4c15f:      	movq	%rcx, 0x70(%rax)
   4c163:      	movq	0x28(%rsp), %rcx
   4c168:      	movq	%rcx, 0x78(%rax)
   4c16c:      	movq	%r12, 0x80(%rax)
   4c173:      	addq	$0x88, %rax
   4c179:      	leaq	0x2f8(%rsp), %rsi
   4c181:      	movl	$0xd0, %edx
   4c186:      	movq	%rax, %rdi
   4c189:      	callq	*0x156c1(%rip)          # 0x61850 <writev+0x61850>
   4c18f:      	movq	$0x36, 0x158(%r13)
   4c19a:      	movq	0x10(%rsp), %rax
   4c19f:      	movq	%rax, 0x160(%r13)
   4c1a6:      	movq	$0x36, 0x168(%r13)
   4c1b1:      	movq	$0x0, 0x170(%r13)
   4c1bc:      	movq	%rbp, 0x178(%r13)
   4c1c3:      	movq	%r13, 0x17146(%rip)     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c1ca:      	leaq	0x9bef(%rip), %rdi      # 0x55dc0 <snail_runtime::native::report_statistics::hf13e5e332de61a4a>
   4c1d1:      	callq	0x12ad0 <atexit>
   4c1d6:      	movq	$0x2, 0x88(%rsp)
   4c1e2:      	movq	$0x0, 0x90(%rsp)
   4c1ee:      	movq	0x17123(%rip), %rax     # 0x63318 <native_roots.0>
   4c1f5:      	movq	%rax, 0x80(%rsp)
   4c1fd:      	movq	0x170f4(%rip), %rax     # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4c204:      	incq	%rax
   4c207:      	movq	%rax, 0x170ea(%rip)     # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4c20e:      	movq	0x170eb(%rip), %rcx     # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4c215:      	cmpq	%rcx, %rax
   4c218:      	cmovbeq	%rcx, %rax
   4c21c:      	movq	%r14, 0x170f5(%rip)     # 0x63318 <native_roots.0>
   4c223:      	movq	%rax, 0x170d6(%rip)     # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4c22a:      	cmpl	$0x0, 0x171b3(%rip)     # 0x633e4 <g.0>
   4c231:      	jne	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c237:      	movl	$0x1, 0x171a3(%rip)     # 0x633e4 <g.0>
   4c241:      	movq	$0x0, 0x98(%rsp)
   4c24d:      	leaq	0x14e54(%rip), %r15     # 0x610a8 <ref.18>
   4c254:      	movq	%r15, 0xa0(%rsp)
   4c25c:      	movq	$0x2, 0x90(%rsp)
   4c268:      	movq	0x170a1(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c26f:      	testq	%rdi, %rdi
   4c272:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c278:      	movq	0x178(%rdi), %rcx
   4c27f:      	testq	%rcx, %rcx
   4c282:      	je	0x4c2c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x899>
   4c284:      	movq	0x170(%rdi), %rax
   4c28b:      	incq	%rax
   4c28e:      	movq	%rax, 0x170(%rdi)
   4c295:      	movq	%rax, %rdx
   4c298:      	orq	%rcx, %rdx
   4c29b:      	shrq	$0x20, %rdx
   4c29f:      	je	0x4cf9e <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x156e>
   4c2a5:      	xorl	%edx, %edx
   4c2a7:      	divq	%rcx
   4c2aa:      	testq	%rdx, %rdx
   4c2ad:      	jne	0x4c2c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x899>
   4c2af:      	leaq	0x80(%rsp), %rsi
   4c2b7:      	movq	%rdi, %rbx
   4c2ba:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c2bf:      	movq	%rbx, %rdi
   4c2c2:      	movq	0x1704f(%rip), %r14     # 0x63318 <native_roots.0>
   4c2c9:      	movl	$0x18, %esi
   4c2ce:      	movq	%r14, %rdx
   4c2d1:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c2d6:      	testq	%rax, %rax
   4c2d9:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c2df:      	movq	$0xc2, (%rax)
   4c2e6:      	movq	%r15, 0x8(%rax)
   4c2ea:      	movq	$0x0, 0x10(%rax)
   4c2f2:      	movq	%rax, 0x170ef(%rip)     # 0x633e8 <g.3>
   4c2f9:      	movb	$0x1, 0x170f0(%rip)     # 0x633f0 <g.4>
   4c300:      	movq	$0x0, 0x90(%rsp)
   4c30c:      	movq	0x16ffd(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c313:      	testq	%rdi, %rdi
   4c316:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c31c:      	movq	0x178(%rdi), %rcx
   4c323:      	testq	%rcx, %rcx
   4c326:      	je	0x4c365 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x935>
   4c328:      	movq	0x170(%rdi), %rax
   4c32f:      	incq	%rax
   4c332:      	movq	%rax, 0x170(%rdi)
   4c339:      	movq	%rax, %rdx
   4c33c:      	orq	%rcx, %rdx
   4c33f:      	shrq	$0x20, %rdx
   4c343:      	je	0x4cfb0 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1580>
   4c349:      	xorl	%edx, %edx
   4c34b:      	divq	%rcx
   4c34e:      	testq	%rdx, %rdx
   4c351:      	jne	0x4c365 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x935>
   4c353:      	movq	0x16fbe(%rip), %rsi     # 0x63318 <native_roots.0>
   4c35a:      	movq	%rdi, %rbx
   4c35d:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c362:      	movq	%rbx, %rdi
   4c365:      	movq	0x16fac(%rip), %rdx     # 0x63318 <native_roots.0>
   4c36c:      	movl	$0x8, %esi
   4c371:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c376:      	testq	%rax, %rax
   4c379:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c37f:      	movq	$0xbe, (%rax)
   4c386:      	movq	%rax, 0x1706b(%rip)     # 0x633f8 <g.5>
   4c38d:      	movb	$0x1, 0x1706c(%rip)     # 0x63400 <g.6>
   4c394:      	movq	$0x0, 0x90(%rsp)
   4c3a0:      	movq	0x16f69(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c3a7:      	testq	%rdi, %rdi
   4c3aa:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c3b0:      	movq	0x178(%rdi), %rcx
   4c3b7:      	testq	%rcx, %rcx
   4c3ba:      	je	0x4c3f9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x9c9>
   4c3bc:      	movq	0x170(%rdi), %rax
   4c3c3:      	incq	%rax
   4c3c6:      	movq	%rax, 0x170(%rdi)
   4c3cd:      	movq	%rax, %rdx
   4c3d0:      	orq	%rcx, %rdx
   4c3d3:      	shrq	$0x20, %rdx
   4c3d7:      	je	0x4cfc2 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1592>
   4c3dd:      	xorl	%edx, %edx
   4c3df:      	divq	%rcx
   4c3e2:      	testq	%rdx, %rdx
   4c3e5:      	jne	0x4c3f9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x9c9>
   4c3e7:      	movq	0x16f2a(%rip), %rsi     # 0x63318 <native_roots.0>
   4c3ee:      	movq	%rdi, %rbx
   4c3f1:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c3f6:      	movq	%rbx, %rdi
   4c3f9:      	movq	0x16f18(%rip), %rdx     # 0x63318 <native_roots.0>
   4c400:      	movl	$0x8, %esi
   4c405:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c40a:      	testq	%rax, %rax
   4c40d:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c413:      	movq	$0xba, (%rax)
   4c41a:      	movq	%rax, 0x16fe7(%rip)     # 0x63408 <g.7>
   4c421:      	movb	$0x1, 0x16fe8(%rip)     # 0x63410 <g.8>
   4c428:      	movq	$0x0, 0x90(%rsp)
   4c434:      	movq	0x16ed5(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c43b:      	testq	%rdi, %rdi
   4c43e:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c444:      	movq	0x178(%rdi), %rcx
   4c44b:      	testq	%rcx, %rcx
   4c44e:      	je	0x4c48d <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xa5d>
   4c450:      	movq	0x170(%rdi), %rax
   4c457:      	incq	%rax
   4c45a:      	movq	%rax, 0x170(%rdi)
   4c461:      	movq	%rax, %rdx
   4c464:      	orq	%rcx, %rdx
   4c467:      	shrq	$0x20, %rdx
   4c46b:      	je	0x4cfd4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x15a4>
   4c471:      	xorl	%edx, %edx
   4c473:      	divq	%rcx
   4c476:      	testq	%rdx, %rdx
   4c479:      	jne	0x4c48d <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xa5d>
   4c47b:      	movq	0x16e96(%rip), %rsi     # 0x63318 <native_roots.0>
   4c482:      	movq	%rdi, %rbx
   4c485:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c48a:      	movq	%rbx, %rdi
   4c48d:      	movq	0x16e84(%rip), %rdx     # 0x63318 <native_roots.0>
   4c494:      	movl	$0x8, %esi
   4c499:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c49e:      	testq	%rax, %rax
   4c4a1:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c4a7:      	movq	$0xb6, (%rax)
   4c4ae:      	movq	%rax, 0x16f63(%rip)     # 0x63418 <g.9>
   4c4b5:      	movb	$0x1, 0x16f64(%rip)     # 0x63420 <g.10>
   4c4bc:      	movq	$0x0, 0x90(%rsp)
   4c4c8:      	movq	0x16e41(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c4cf:      	testq	%rdi, %rdi
   4c4d2:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c4d8:      	movq	0x178(%rdi), %rcx
   4c4df:      	testq	%rcx, %rcx
   4c4e2:      	je	0x4c521 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xaf1>
   4c4e4:      	movq	0x170(%rdi), %rax
   4c4eb:      	incq	%rax
   4c4ee:      	movq	%rax, 0x170(%rdi)
   4c4f5:      	movq	%rax, %rdx
   4c4f8:      	orq	%rcx, %rdx
   4c4fb:      	shrq	$0x20, %rdx
   4c4ff:      	je	0x4cfe6 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x15b6>
   4c505:      	xorl	%edx, %edx
   4c507:      	divq	%rcx
   4c50a:      	testq	%rdx, %rdx
   4c50d:      	jne	0x4c521 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xaf1>
   4c50f:      	movq	0x16e02(%rip), %rsi     # 0x63318 <native_roots.0>
   4c516:      	movq	%rdi, %rbx
   4c519:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c51e:      	movq	%rbx, %rdi
   4c521:      	movq	0x16df0(%rip), %rdx     # 0x63318 <native_roots.0>
   4c528:      	movl	$0x8, %esi
   4c52d:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c532:      	testq	%rax, %rax
   4c535:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c53b:      	movq	$0xb2, (%rax)
   4c542:      	movq	%rax, 0x16edf(%rip)     # 0x63428 <g.11>
   4c549:      	movb	$0x1, 0x16ee0(%rip)     # 0x63430 <g.12>
   4c550:      	movq	$0x0, 0x90(%rsp)
   4c55c:      	movq	0x16dad(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c563:      	testq	%rdi, %rdi
   4c566:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c56c:      	movq	0x178(%rdi), %rcx
   4c573:      	testq	%rcx, %rcx
   4c576:      	je	0x4c5b5 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xb85>
   4c578:      	movq	0x170(%rdi), %rax
   4c57f:      	incq	%rax
   4c582:      	movq	%rax, 0x170(%rdi)
   4c589:      	movq	%rax, %rdx
   4c58c:      	orq	%rcx, %rdx
   4c58f:      	shrq	$0x20, %rdx
   4c593:      	je	0x4cff8 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x15c8>
   4c599:      	xorl	%edx, %edx
   4c59b:      	divq	%rcx
   4c59e:      	testq	%rdx, %rdx
   4c5a1:      	jne	0x4c5b5 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xb85>
   4c5a3:      	movq	0x16d6e(%rip), %rsi     # 0x63318 <native_roots.0>
   4c5aa:      	movq	%rdi, %rbx
   4c5ad:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c5b2:      	movq	%rbx, %rdi
   4c5b5:      	movq	0x16d5c(%rip), %rdx     # 0x63318 <native_roots.0>
   4c5bc:      	movl	$0x8, %esi
   4c5c1:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c5c6:      	testq	%rax, %rax
   4c5c9:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c5cf:      	movq	$0xae, (%rax)
   4c5d6:      	movq	%rax, 0x16e5b(%rip)     # 0x63438 <g.13>
   4c5dd:      	movb	$0x1, 0x16e5c(%rip)     # 0x63440 <g.14>
   4c5e4:      	movq	$0x0, 0x90(%rsp)
   4c5f0:      	movq	0x16d19(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c5f7:      	testq	%rdi, %rdi
   4c5fa:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c600:      	movq	0x178(%rdi), %rcx
   4c607:      	testq	%rcx, %rcx
   4c60a:      	je	0x4c649 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xc19>
   4c60c:      	movq	0x170(%rdi), %rax
   4c613:      	incq	%rax
   4c616:      	movq	%rax, 0x170(%rdi)
   4c61d:      	movq	%rax, %rdx
   4c620:      	orq	%rcx, %rdx
   4c623:      	shrq	$0x20, %rdx
   4c627:      	je	0x4d00a <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x15da>
   4c62d:      	xorl	%edx, %edx
   4c62f:      	divq	%rcx
   4c632:      	testq	%rdx, %rdx
   4c635:      	jne	0x4c649 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xc19>
   4c637:      	movq	0x16cda(%rip), %rsi     # 0x63318 <native_roots.0>
   4c63e:      	movq	%rdi, %rbx
   4c641:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c646:      	movq	%rbx, %rdi
   4c649:      	movq	0x16cc8(%rip), %rdx     # 0x63318 <native_roots.0>
   4c650:      	movl	$0x8, %esi
   4c655:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c65a:      	testq	%rax, %rax
   4c65d:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c663:      	movq	$0xaa, (%rax)
   4c66a:      	movq	%rax, 0x16dd7(%rip)     # 0x63448 <g.15>
   4c671:      	movb	$0x1, 0x16dd8(%rip)     # 0x63450 <g.16>
   4c678:      	movq	$0x0, 0x90(%rsp)
   4c684:      	movq	0x16c85(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c68b:      	testq	%rdi, %rdi
   4c68e:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c694:      	movq	0x178(%rdi), %rcx
   4c69b:      	testq	%rcx, %rcx
   4c69e:      	je	0x4c6dd <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xcad>
   4c6a0:      	movq	0x170(%rdi), %rax
   4c6a7:      	incq	%rax
   4c6aa:      	movq	%rax, 0x170(%rdi)
   4c6b1:      	movq	%rax, %rdx
   4c6b4:      	orq	%rcx, %rdx
   4c6b7:      	shrq	$0x20, %rdx
   4c6bb:      	je	0x4d01c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x15ec>
   4c6c1:      	xorl	%edx, %edx
   4c6c3:      	divq	%rcx
   4c6c6:      	testq	%rdx, %rdx
   4c6c9:      	jne	0x4c6dd <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xcad>
   4c6cb:      	movq	0x16c46(%rip), %rsi     # 0x63318 <native_roots.0>
   4c6d2:      	movq	%rdi, %rbx
   4c6d5:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c6da:      	movq	%rbx, %rdi
   4c6dd:      	movq	0x16c34(%rip), %rdx     # 0x63318 <native_roots.0>
   4c6e4:      	movl	$0x8, %esi
   4c6e9:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c6ee:      	testq	%rax, %rax
   4c6f1:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c6f7:      	movq	$0xa6, (%rax)
   4c6fe:      	movq	%rax, 0x16d53(%rip)     # 0x63458 <g.17>
   4c705:      	movb	$0x1, 0x16d54(%rip)     # 0x63460 <g.18>
   4c70c:      	movq	$0x0, 0x98(%rsp)
   4c718:      	leaq	0x14919(%rip), %r14     # 0x61038 <ref.9>
   4c71f:      	movq	%r14, 0xa0(%rsp)
   4c727:      	movq	$0x2, 0x90(%rsp)
   4c733:      	movq	0x16bd6(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c73a:      	testq	%rdi, %rdi
   4c73d:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c743:      	movq	0x178(%rdi), %rcx
   4c74a:      	testq	%rcx, %rcx
   4c74d:      	je	0x4c78c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xd5c>
   4c74f:      	movq	0x170(%rdi), %rax
   4c756:      	incq	%rax
   4c759:      	movq	%rax, 0x170(%rdi)
   4c760:      	movq	%rax, %rdx
   4c763:      	orq	%rcx, %rdx
   4c766:      	shrq	$0x20, %rdx
   4c76a:      	je	0x4d02e <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x15fe>
   4c770:      	xorl	%edx, %edx
   4c772:      	divq	%rcx
   4c775:      	testq	%rdx, %rdx
   4c778:      	jne	0x4c78c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xd5c>
   4c77a:      	movq	0x16b97(%rip), %rsi     # 0x63318 <native_roots.0>
   4c781:      	movq	%rdi, %rbx
   4c784:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c789:      	movq	%rbx, %rdi
   4c78c:      	movq	0x16b85(%rip), %rdx     # 0x63318 <native_roots.0>
   4c793:      	movl	$0x18, %esi
   4c798:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c79d:      	testq	%rax, %rax
   4c7a0:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c7a6:      	movq	$0xa2, (%rax)
   4c7ad:      	movq	%r14, 0x8(%rax)
   4c7b1:      	movq	$0x0, 0x10(%rax)
   4c7b9:      	movq	%rax, 0x16ca8(%rip)     # 0x63468 <g.19>
   4c7c0:      	movb	$0x1, 0x16ca9(%rip)     # 0x63470 <g.20>
   4c7c7:      	movq	$0x0, 0x90(%rsp)
   4c7d3:      	movq	0x16b36(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c7da:      	testq	%rdi, %rdi
   4c7dd:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c7e3:      	movq	0x178(%rdi), %rcx
   4c7ea:      	testq	%rcx, %rcx
   4c7ed:      	je	0x4c82c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xdfc>
   4c7ef:      	movq	0x170(%rdi), %rax
   4c7f6:      	incq	%rax
   4c7f9:      	movq	%rax, 0x170(%rdi)
   4c800:      	movq	%rax, %rdx
   4c803:      	orq	%rcx, %rdx
   4c806:      	shrq	$0x20, %rdx
   4c80a:      	je	0x4d040 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1610>
   4c810:      	xorl	%edx, %edx
   4c812:      	divq	%rcx
   4c815:      	testq	%rdx, %rdx
   4c818:      	jne	0x4c82c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xdfc>
   4c81a:      	movq	0x16af7(%rip), %rsi     # 0x63318 <native_roots.0>
   4c821:      	movq	%rdi, %rbx
   4c824:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c829:      	movq	%rbx, %rdi
   4c82c:      	movq	0x16ae5(%rip), %rdx     # 0x63318 <native_roots.0>
   4c833:      	movl	$0x10, %esi
   4c838:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c83d:      	testq	%rax, %rax
   4c840:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c846:      	movq	$0x9e, (%rax)
   4c84d:      	movq	$0x0, 0x8(%rax)
   4c855:      	movq	%rax, 0x16c1c(%rip)     # 0x63478 <g.21>
   4c85c:      	movb	$0x1, 0x16c1d(%rip)     # 0x63480 <g.22>
   4c863:      	movq	$0x0, 0x90(%rsp)
   4c86f:      	movq	0x16a9a(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c876:      	testq	%rdi, %rdi
   4c879:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c87f:      	movq	0x178(%rdi), %rcx
   4c886:      	testq	%rcx, %rcx
   4c889:      	je	0x4c8c8 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xe98>
   4c88b:      	movq	0x170(%rdi), %rax
   4c892:      	incq	%rax
   4c895:      	movq	%rax, 0x170(%rdi)
   4c89c:      	movq	%rax, %rdx
   4c89f:      	orq	%rcx, %rdx
   4c8a2:      	shrq	$0x20, %rdx
   4c8a6:      	je	0x4d052 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1622>
   4c8ac:      	xorl	%edx, %edx
   4c8ae:      	divq	%rcx
   4c8b1:      	testq	%rdx, %rdx
   4c8b4:      	jne	0x4c8c8 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xe98>
   4c8b6:      	movq	0x16a5b(%rip), %rsi     # 0x63318 <native_roots.0>
   4c8bd:      	movq	%rdi, %rbx
   4c8c0:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c8c5:      	movq	%rbx, %rdi
   4c8c8:      	movq	0x16a49(%rip), %rdx     # 0x63318 <native_roots.0>
   4c8cf:      	movl	$0x8, %esi
   4c8d4:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c8d9:      	testq	%rax, %rax
   4c8dc:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c8e2:      	movq	$0x9a, (%rax)
   4c8e9:      	movq	%rax, 0x16b98(%rip)     # 0x63488 <g.23>
   4c8f0:      	movb	$0x1, 0x16b99(%rip)     # 0x63490 <g.24>
   4c8f7:      	movq	$0x0, 0x90(%rsp)
   4c903:      	movq	0x16a06(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c90a:      	testq	%rdi, %rdi
   4c90d:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4c913:      	movq	0x178(%rdi), %rcx
   4c91a:      	testq	%rcx, %rcx
   4c91d:      	je	0x4c95c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xf2c>
   4c91f:      	movq	0x170(%rdi), %rax
   4c926:      	incq	%rax
   4c929:      	movq	%rax, 0x170(%rdi)
   4c930:      	movq	%rax, %rdx
   4c933:      	orq	%rcx, %rdx
   4c936:      	shrq	$0x20, %rdx
   4c93a:      	je	0x4d064 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1634>
   4c940:      	xorl	%edx, %edx
   4c942:      	divq	%rcx
   4c945:      	testq	%rdx, %rdx
   4c948:      	jne	0x4c95c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xf2c>
   4c94a:      	movq	0x169c7(%rip), %rsi     # 0x63318 <native_roots.0>
   4c951:      	movq	%rdi, %rbx
   4c954:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c959:      	movq	%rbx, %rdi
   4c95c:      	movq	0x169b5(%rip), %rdx     # 0x63318 <native_roots.0>
   4c963:      	movl	$0x8, %esi
   4c968:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c96d:      	testq	%rax, %rax
   4c970:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4c976:      	movq	$0x96, (%rax)
   4c97d:      	movq	%rax, 0x16b14(%rip)     # 0x63498 <g.25>
   4c984:      	movb	$0x1, 0x16b15(%rip)     # 0x634a0 <g.26>
   4c98b:      	movq	$0x0, 0x90(%rsp)
   4c997:      	movq	$0x3e8, 0x228(%rsp)     # imm = 0x3E8
   4c9a3:      	leaq	0x228(%rsp), %rax
   4c9ab:      	movq	0x228(%rsp), %rax
   4c9b3:      	movq	%rax, 0x16aee(%rip)     # 0x634a8 <g.27>
   4c9ba:      	movb	$0x1, 0x16aef(%rip)     # 0x634b0 <g.28>
   4c9c1:      	movq	$0x0, 0x90(%rsp)
   4c9cd:      	movq	$0x3e8, 0x228(%rsp)     # imm = 0x3E8
   4c9d9:      	leaq	0x228(%rsp), %rax
   4c9e1:      	movq	0x228(%rsp), %rax
   4c9e9:      	movq	%rax, 0x16ac8(%rip)     # 0x634b8 <g.29>
   4c9f0:      	movb	$0x1, 0x16ac9(%rip)     # 0x634c0 <g.30>
   4c9f7:      	movq	$0x0, 0x90(%rsp)
   4ca03:      	movq	$0x0, 0x228(%rsp)
   4ca0f:      	leaq	0x228(%rsp), %rax
   4ca17:      	movq	0x228(%rsp), %rax
   4ca1f:      	movq	%rax, 0x16aa2(%rip)     # 0x634c8 <g.31>
   4ca26:      	movb	$0x1, 0x16aa3(%rip)     # 0x634d0 <g.32>
   4ca2d:      	movq	$0x0, 0x98(%rsp)
   4ca39:      	leaq	0x145d8(%rip), %r14     # 0x61018 <ref.6>
   4ca40:      	movq	%r14, 0xa0(%rsp)
   4ca48:      	movq	$0x2, 0x90(%rsp)
   4ca54:      	movq	0x168b5(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4ca5b:      	testq	%rdi, %rdi
   4ca5e:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4ca64:      	movq	0x178(%rdi), %rcx
   4ca6b:      	testq	%rcx, %rcx
   4ca6e:      	je	0x4caad <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x107d>
   4ca70:      	movq	0x170(%rdi), %rax
   4ca77:      	incq	%rax
   4ca7a:      	movq	%rax, 0x170(%rdi)
   4ca81:      	movq	%rax, %rdx
   4ca84:      	orq	%rcx, %rdx
   4ca87:      	shrq	$0x20, %rdx
   4ca8b:      	je	0x4d076 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1646>
   4ca91:      	xorl	%edx, %edx
   4ca93:      	divq	%rcx
   4ca96:      	testq	%rdx, %rdx
   4ca99:      	jne	0x4caad <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x107d>
   4ca9b:      	movq	0x16876(%rip), %rsi     # 0x63318 <native_roots.0>
   4caa2:      	movq	%rdi, %rbx
   4caa5:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4caaa:      	movq	%rbx, %rdi
   4caad:      	movq	0x16864(%rip), %rdx     # 0x63318 <native_roots.0>
   4cab4:      	movl	$0x18, %esi
   4cab9:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cabe:      	testq	%rax, %rax
   4cac1:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4cac7:      	movq	$0x92, (%rax)
   4cace:      	movq	%r14, 0x8(%rax)
   4cad2:      	movq	$0x0, 0x10(%rax)
   4cada:      	movq	%rax, 0x169f7(%rip)     # 0x634d8 <g.33>
   4cae1:      	movl	$0x2, 0x168f9(%rip)     # 0x633e4 <g.0>
   4caeb:      	cmpq	$0x0, 0x88(%rsp)
   4caf4:      	je	0x4cb0c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x10dc>
   4caf6:      	movq	0x80(%rsp), %rax
   4cafe:      	movq	%rax, 0x16813(%rip)     # 0x63318 <native_roots.0>
   4cb05:      	decq	0x167ec(%rip)           # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4cb0c:      	callq	0x4d780 <<std::sys::pal::unix::time::Timespec>::now>
   4cb11:      	movq	%rax, %rbx
   4cb14:      	movl	%edx, %ebp
   4cb16:      	movq	$0x5, 0x88(%rsp)
   4cb22:      	movq	$0x0, 0x90(%rsp)
   4cb2e:      	movq	0x167e3(%rip), %rax     # 0x63318 <native_roots.0>
   4cb35:      	movq	%rax, 0x80(%rsp)
   4cb3d:      	leaq	0x80(%rsp), %rcx
   4cb45:      	movq	%rcx, 0x167cc(%rip)     # 0x63318 <native_roots.0>
   4cb4c:      	movq	0x167a5(%rip), %rax     # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4cb53:      	incq	%rax
   4cb56:      	movq	%rax, 0x1679b(%rip)     # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4cb5d:      	movq	0x1679c(%rip), %rdx     # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4cb64:      	cmpq	%rdx, %rax
   4cb67:      	cmovbeq	%rdx, %rax
   4cb6b:      	movq	%rax, 0x1678e(%rip)     # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4cb72:      	xorpd	%xmm0, %xmm0
   4cb76:      	movupd	%xmm0, 0x98(%rsp)
   4cb7f:      	cmpl	$0x2, 0x1685e(%rip)     # 0x633e4 <g.0>
   4cb86:      	jne	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cb8c:      	cmpq	$0x0, 0x16944(%rip)     # 0x634d8 <g.33>
   4cb94:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cb9a:      	movq	$0x2, 0x90(%rsp)
   4cba6:      	movq	0x16763(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cbad:      	testq	%rdi, %rdi
   4cbb0:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cbb6:      	movq	0x178(%rdi), %rsi
   4cbbd:      	testq	%rsi, %rsi
   4cbc0:      	je	0x4cc07 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x11d7>
   4cbc2:      	movq	0x170(%rdi), %rax
   4cbc9:      	incq	%rax
   4cbcc:      	movq	%rax, 0x170(%rdi)
   4cbd3:      	movq	%rax, %rdx
   4cbd6:      	orq	%rsi, %rdx
   4cbd9:      	shrq	$0x20, %rdx
   4cbdd:      	je	0x4d088 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1658>
   4cbe3:      	xorl	%edx, %edx
   4cbe5:      	divq	%rsi
   4cbe8:      	testq	%rdx, %rdx
   4cbeb:      	jne	0x4cc07 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x11d7>
   4cbed:      	leaq	0x80(%rsp), %rsi
   4cbf5:      	movq	%rdi, %r14
   4cbf8:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4cbfd:      	movq	%r14, %rdi
   4cc00:      	movq	0x16711(%rip), %rcx     # 0x63318 <native_roots.0>
   4cc07:      	movl	$0x18, %esi
   4cc0c:      	movq	%rcx, %rdx
   4cc0f:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cc14:      	testq	%rax, %rax
   4cc17:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4cc1d:      	movq	%rax, %r14
   4cc20:      	movq	$0x7a, (%rax)
   4cc27:      	movl	$0x0, 0x8(%rax)
   4cc2e:      	movq	$0x0, 0x10(%rax)
   4cc36:      	movq	%rax, 0x98(%rsp)
   4cc3e:      	movq	%rax, 0xa8(%rsp)
   4cc46:      	leaq	0x143db(%rip), %r13     # 0x61028 <ref.7>
   4cc4d:      	movq	%r13, 0xb0(%rsp)
   4cc55:      	movq	%rax, 0xb8(%rsp)
   4cc5d:      	movq	$0x5, 0x90(%rsp)
   4cc69:      	movq	0x166a0(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cc70:      	testq	%rdi, %rdi
   4cc73:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cc79:      	movq	0x178(%rdi), %rcx
   4cc80:      	testq	%rcx, %rcx
   4cc83:      	je	0x4ccc2 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1292>
   4cc85:      	movq	0x170(%rdi), %rax
   4cc8c:      	incq	%rax
   4cc8f:      	movq	%rax, 0x170(%rdi)
   4cc96:      	movq	%rax, %rdx
   4cc99:      	orq	%rcx, %rdx
   4cc9c:      	shrq	$0x20, %rdx
   4cca0:      	je	0x4d09a <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x166a>
   4cca6:      	xorl	%edx, %edx
   4cca8:      	divq	%rcx
   4ccab:      	testq	%rdx, %rdx
   4ccae:      	jne	0x4ccc2 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1292>
   4ccb0:      	movq	0x16661(%rip), %rsi     # 0x63318 <native_roots.0>
   4ccb7:      	movq	%rdi, %r15
   4ccba:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4ccbf:      	movq	%r15, %rdi
   4ccc2:      	movq	0x1664f(%rip), %rdx     # 0x63318 <native_roots.0>
   4ccc9:      	movl	$0x18, %esi
   4ccce:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4ccd3:      	testq	%rax, %rax
   4ccd6:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4ccdc:      	movq	%rax, %r15
   4ccdf:      	movq	$0x76, (%rax)
   4cce6:      	movq	$0x64, 0x8(%rax)
   4ccee:      	movq	%r14, 0x10(%rax)
   4ccf2:      	movq	%rax, 0xa8(%rsp)
   4ccfa:      	movq	%r13, 0xb0(%rsp)
   4cd02:      	movq	%r14, 0xb8(%rsp)
   4cd0a:      	movq	$0x5, 0x90(%rsp)
   4cd16:      	movq	0x165f3(%rip), %rdi     # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cd1d:      	testq	%rdi, %rdi
   4cd20:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cd26:      	movq	0x178(%rdi), %rcx
   4cd2d:      	testq	%rcx, %rcx
   4cd30:      	je	0x4cd6f <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x133f>
   4cd32:      	movq	0x170(%rdi), %rax
   4cd39:      	incq	%rax
   4cd3c:      	movq	%rax, 0x170(%rdi)
   4cd43:      	movq	%rax, %rdx
   4cd46:      	orq	%rcx, %rdx
   4cd49:      	shrq	$0x20, %rdx
   4cd4d:      	je	0x4d0ac <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x167c>
   4cd53:      	xorl	%edx, %edx
   4cd55:      	divq	%rcx
   4cd58:      	testq	%rdx, %rdx
   4cd5b:      	jne	0x4cd6f <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x133f>
   4cd5d:      	movq	0x165b4(%rip), %rsi     # 0x63318 <native_roots.0>
   4cd64:      	movq	%rdi, %r12
   4cd67:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4cd6c:      	movq	%r12, %rdi
   4cd6f:      	movq	0x165a2(%rip), %rdx     # 0x63318 <native_roots.0>
   4cd76:      	movl	$0x18, %esi
   4cd7b:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cd80:      	testq	%rax, %rax
   4cd83:      	je	0x4d4a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a74>
   4cd89:      	movq	$0xa2, (%rax)
   4cd90:      	movq	%r13, 0x8(%rax)
   4cd94:      	movq	%r15, 0x10(%rax)
   4cd98:      	movq	%rax, 0x10(%r14)
   4cd9c:      	movq	0x98(%rsp), %rax
   4cda4:      	testq	%rax, %rax
   4cda7:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cdad:      	movl	$0x1, 0x8(%rax)
   4cdb4:      	movq	0x98(%rsp), %rax
   4cdbc:      	testq	%rax, %rax
   4cdbf:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cdc5:      	cmpl	$0x0, 0x8(%rax)
   4cdc9:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cdcf:      	movq	0x10(%rax), %rax
   4cdd3:      	testq	%rax, %rax
   4cdd6:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cddc:      	movq	%rax, 0xa0(%rsp)
   4cde4:      	movq	0x8(%rax), %rcx
   4cde8:      	testq	%rcx, %rcx
   4cdeb:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4cdf1:      	movq	0x10(%rax), %rdi
   4cdf5:      	movq	0x8(%rcx), %rax
   4cdf9:      	cmpq	$0x0, 0x88(%rsp)
   4ce02:      	je	0x4ce1a <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x13ea>
   4ce04:      	movq	0x80(%rsp), %rcx
   4ce0c:      	movq	%rcx, 0x16505(%rip)     # 0x63318 <native_roots.0>
   4ce13:      	decq	0x164de(%rip)           # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4ce1a:      	xorl	%esi, %esi
   4ce1c:      	xorl	%edx, %edx
   4ce1e:      	callq	*%rax
   4ce20:      	subq	$0x8, %rsp
   4ce24:      	movq	%rax, %r14
   4ce27:      	movq	%rax, 0x218(%rsp)
   4ce2f:      	callq	0x4d780 <<std::sys::pal::unix::time::Timespec>::now>
   4ce34:      	movq	%rax, 0x2f8(%rsp)
   4ce3c:      	movl	%edx, 0x300(%rsp)
   4ce43:      	movq	%rbx, 0x228(%rsp)
   4ce4b:      	movl	%ebp, 0x230(%rsp)
   4ce52:      	leaq	0x80(%rsp), %rdi
   4ce5a:      	leaq	0x2f8(%rsp), %rbx
   4ce62:      	leaq	0x228(%rsp), %rdx
   4ce6a:      	movq	%rbx, %rsi
   4ce6d:      	callq	0x4d850 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   4ce72:      	cmpb	$0x0, 0x80(%rsp)
   4ce7a:      	xorpd	%xmm0, %xmm0
   4ce7e:      	jne	0x4cebc <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x148c>
   4ce80:      	movsd	0x88(%rsp), %xmm1
   4ce89:      	unpcklps	-0x48b20(%rip), %xmm1   # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x4370 <writev+0x4370>
   4ce90:      	subpd	-0x48b88(%rip), %xmm1   # 0x4310 <writev+0x4310>
   4ce98:      	movapd	%xmm1, %xmm2
   4ce9c:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   4cea0:      	xorps	%xmm0, %xmm0
   4cea3:      	cvtsi2sdl	0x90(%rsp), %xmm0
   4ceac:      	addsd	%xmm1, %xmm2
   4ceb0:      	divsd	-0x46fd0(%rip), %xmm0   # 0x5ee8 <writev+0x5ee8>
   4ceb8:      	addsd	%xmm2, %xmm0
   4cebc:      	movsd	%xmm0, 0x220(%rsp)
   4cec5:      	cmpq	$0x1, %r14
   4cec9:      	jne	0x4cf6e <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x153e>
   4cecf:      	leaq	0x218(%rsp), %rax
   4ced7:      	movq	%rax, 0x228(%rsp)
   4cedf:      	leaq	0x134a(%rip), %rax      # 0x4e230 <<i64 as core::fmt::Display>::fmt>
   4cee6:      	movq	%rax, 0x230(%rsp)
   4ceee:      	leaq	0x220(%rsp), %rax
   4cef6:      	movq	%rax, 0x238(%rsp)
   4cefe:      	leaq	0x144b(%rip), %rax      # 0x4e350 <<f64 as core::fmt::Display>::fmt>
   4cf05:      	movq	%rax, 0x240(%rsp)
   4cf0d:      	leaq	-0x4308d(%rip), %rax    # 0x9e87 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1353>
   4cf14:      	movq	%rax, 0x2f8(%rsp)
   4cf1c:      	movq	$0x6, 0x300(%rsp)
   4cf28:      	movl	0x1599a(%rip), %eax     # 0x628c8 <std::io::stdio::STDOUT+0x38>
   4cf2e:      	testl	%eax, %eax
   4cf30:      	jne	0x4d250 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1820>
   4cf36:      	movq	%fs:-0x8, %r14
   4cf3f:      	testq	%r14, %r14
   4cf42:      	je	0x4d267 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1837>
   4cf48:      	movq	0x15941(%rip), %rax     # 0x62890 <std::io::stdio::STDOUT>
   4cf4f:      	cmpq	%rax, %r14
   4cf52:      	jne	0x4d2a2 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1872>
   4cf58:      	movl	0x1593e(%rip), %ebp     # 0x6289c <std::io::stdio::STDOUT+0xc>
   4cf5e:      	cmpl	$-0x1, %ebp
   4cf61:      	je	0x4d409 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x19d9>
   4cf67:      	incl	%ebp
   4cf69:      	jmp	0x4d2be <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x188e>
   4cf6e:      	leaq	0x80(%rsp), %rdi
   4cf76:      	callq	0x4d920 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4cf7b:      	cmpq	$0x0, 0x80(%rsp)
   4cf84:      	jle	0x4cf94 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1564>
   4cf86:      	movq	0x88(%rsp), %rdi
   4cf8e:      	callq	*0x14724(%rip)          # 0x616b8 <writev+0x616b8>
   4cf94:      	movl	$0x1, %eax
   4cf99:      	jmp	0x4d3f2 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x19c2>
   4cf9e:      	xorl	%edx, %edx
   4cfa0:      	divl	%ecx
   4cfa2:      	testq	%rdx, %rdx
   4cfa5:      	jne	0x4c2c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x899>
   4cfab:      	jmp	0x4c2af <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x87f>
   4cfb0:      	xorl	%edx, %edx
   4cfb2:      	divl	%ecx
   4cfb4:      	testq	%rdx, %rdx
   4cfb7:      	jne	0x4c365 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x935>
   4cfbd:      	jmp	0x4c353 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x923>
   4cfc2:      	xorl	%edx, %edx
   4cfc4:      	divl	%ecx
   4cfc6:      	testq	%rdx, %rdx
   4cfc9:      	jne	0x4c3f9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x9c9>
   4cfcf:      	jmp	0x4c3e7 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x9b7>
   4cfd4:      	xorl	%edx, %edx
   4cfd6:      	divl	%ecx
   4cfd8:      	testq	%rdx, %rdx
   4cfdb:      	jne	0x4c48d <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xa5d>
   4cfe1:      	jmp	0x4c47b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xa4b>
   4cfe6:      	xorl	%edx, %edx
   4cfe8:      	divl	%ecx
   4cfea:      	testq	%rdx, %rdx
   4cfed:      	jne	0x4c521 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xaf1>
   4cff3:      	jmp	0x4c50f <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xadf>
   4cff8:      	xorl	%edx, %edx
   4cffa:      	divl	%ecx
   4cffc:      	testq	%rdx, %rdx
   4cfff:      	jne	0x4c5b5 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xb85>
   4d005:      	jmp	0x4c5a3 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xb73>
   4d00a:      	xorl	%edx, %edx
   4d00c:      	divl	%ecx
   4d00e:      	testq	%rdx, %rdx
   4d011:      	jne	0x4c649 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xc19>
   4d017:      	jmp	0x4c637 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xc07>
   4d01c:      	xorl	%edx, %edx
   4d01e:      	divl	%ecx
   4d020:      	testq	%rdx, %rdx
   4d023:      	jne	0x4c6dd <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xcad>
   4d029:      	jmp	0x4c6cb <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xc9b>
   4d02e:      	xorl	%edx, %edx
   4d030:      	divl	%ecx
   4d032:      	testq	%rdx, %rdx
   4d035:      	jne	0x4c78c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xd5c>
   4d03b:      	jmp	0x4c77a <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xd4a>
   4d040:      	xorl	%edx, %edx
   4d042:      	divl	%ecx
   4d044:      	testq	%rdx, %rdx
   4d047:      	jne	0x4c82c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xdfc>
   4d04d:      	jmp	0x4c81a <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xdea>
   4d052:      	xorl	%edx, %edx
   4d054:      	divl	%ecx
   4d056:      	testq	%rdx, %rdx
   4d059:      	jne	0x4c8c8 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xe98>
   4d05f:      	jmp	0x4c8b6 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xe86>
   4d064:      	xorl	%edx, %edx
   4d066:      	divl	%ecx
   4d068:      	testq	%rdx, %rdx
   4d06b:      	jne	0x4c95c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xf2c>
   4d071:      	jmp	0x4c94a <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0xf1a>
   4d076:      	xorl	%edx, %edx
   4d078:      	divl	%ecx
   4d07a:      	testq	%rdx, %rdx
   4d07d:      	jne	0x4caad <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x107d>
   4d083:      	jmp	0x4ca9b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x106b>
   4d088:      	xorl	%edx, %edx
   4d08a:      	divl	%esi
   4d08c:      	testq	%rdx, %rdx
   4d08f:      	jne	0x4cc07 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x11d7>
   4d095:      	jmp	0x4cbed <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x11bd>
   4d09a:      	xorl	%edx, %edx
   4d09c:      	divl	%ecx
   4d09e:      	testq	%rdx, %rdx
   4d0a1:      	jne	0x4ccc2 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1292>
   4d0a7:      	jmp	0x4ccb0 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1280>
   4d0ac:      	xorl	%edx, %edx
   4d0ae:      	divl	%ecx
   4d0b0:      	testq	%rdx, %rdx
   4d0b3:      	jne	0x4cd6f <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x133f>
   4d0b9:      	jmp	0x4cd5d <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x132d>
   4d0be:      	cmpq	%rcx, %rdx
   4d0c1:      	jne	0x4d0cf <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x169f>
   4d0c3:      	xorl	%ebp, %ebp
   4d0c5:      	movq	0x8(%rsp), %r13
   4d0ca:      	jmp	0x4c0c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x699>
   4d0cf:      	movq	%rdx, 0x20(%rsp)
   4d0d4:      	movq	0x230(%rsp), %rsi
   4d0dc:      	movq	0x238(%rsp), %r13
   4d0e4:      	leaq	0x80(%rsp), %rdi
   4d0ec:      	movq	%rsi, 0x30(%rsp)
   4d0f1:      	movq	%r13, %rdx
   4d0f4:      	callq	0x1a740 <core::str::converts::from_utf8>
   4d0f9:      	cmpb	$0x0, 0x80(%rsp)
   4d101:      	je	0x4d120 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x16f0>
   4d103:      	xorl	%ebp, %ebp
   4d105:      	cmpq	$0x0, 0x20(%rsp)
   4d10b:      	movq	0x8(%rsp), %r13
   4d110:      	movq	0x30(%rsp), %rdi
   4d115:      	jg	0x4d229 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17f9>
   4d11b:      	jmp	0x4c0c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x699>
   4d120:      	testq	%r13, %r13
   4d123:      	je	0x4d14e <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x171e>
   4d125:      	cmpq	$0x1, %r13
   4d129:      	movq	0x30(%rsp), %rdi
   4d12e:      	jne	0x4d16e <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x173e>
   4d130:      	movzbl	(%rdi), %eax
   4d133:      	xorl	%ebp, %ebp
   4d135:      	cmpl	$0x2b, %eax
   4d138:      	movq	0x20(%rsp), %r11
   4d13d:      	je	0x4d21b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17eb>
   4d143:      	cmpl	$0x2d, %eax
   4d146:      	je	0x4d21b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17eb>
   4d14c:      	jmp	0x4d176 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1746>
   4d14e:      	movq	%r13, %rbp
   4d151:      	movq	0x30(%rsp), %rdi
   4d156:      	movq	0x20(%rsp), %r11
   4d15b:      	testq	%r11, %r11
   4d15e:      	movq	0x8(%rsp), %r13
   4d163:      	jne	0x4d229 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17f9>
   4d169:      	jmp	0x4c0c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x699>
   4d16e:      	movzbl	(%rdi), %eax
   4d171:      	movq	0x20(%rsp), %r11
   4d176:      	xorl	%ecx, %ecx
   4d178:      	cmpb	$0x2b, %al
   4d17a:      	sete	%cl
   4d17d:      	movq	%rcx, %rax
   4d180:      	negq	%rax
   4d183:      	movq	%r13, %rdx
   4d186:      	subq	%rcx, %rdx
   4d189:      	addq	%rdi, %rcx
   4d18c:      	cmpq	$0x11, %rdx
   4d190:      	jae	0x4d1cb <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x179b>
   4d192:      	testq	%rdx, %rdx
   4d195:      	je	0x4d208 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17d8>
   4d197:      	addq	%rax, %r13
   4d19a:      	negq	%r13
   4d19d:      	xorl	%eax, %eax
   4d19f:      	xorl	%ebp, %ebp
   4d1a1:      	movzbl	(%rcx,%rax), %edx
   4d1a5:      	addl	$-0x30, %edx
   4d1a8:      	cmpl	$0x9, %edx
   4d1ab:      	ja	0x4d219 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17e9>
   4d1ad:      	leaq	(,%rbp,4), %rsi
   4d1b5:      	addq	%rbp, %rsi
   4d1b8:      	movl	%edx, %edx
   4d1ba:      	leaq	(%rdx,%rsi,2), %rbp
   4d1be:      	incq	%rax
   4d1c1:      	movq	%r13, %rdx
   4d1c4:      	addq	%rax, %rdx
   4d1c7:      	jne	0x4d1a1 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1771>
   4d1c9:      	jmp	0x4d21b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17eb>
   4d1cb:      	addq	%rax, %r13
   4d1ce:      	negq	%r13
   4d1d1:      	xorl	%ebp, %ebp
   4d1d3:      	movl	$0xa, %esi
   4d1d8:      	xorl	%r9d, %r9d
   4d1db:      	xorl	%eax, %eax
   4d1dd:      	movq	%r13, %rdx
   4d1e0:      	addq	%r9, %rdx
   4d1e3:      	je	0x4d234 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1804>
   4d1e5:      	mulq	%rsi
   4d1e8:      	jo	0x4d21b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17eb>
   4d1ea:      	movzbl	(%rcx,%r9), %r8d
   4d1ef:      	addl	$-0x30, %r8d
   4d1f3:      	addq	%r8, %rax
   4d1f6:      	setb	%dl
   4d1f9:      	cmpl	$0x9, %r8d
   4d1fd:      	ja	0x4d21b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17eb>
   4d1ff:      	incq	%r9
   4d202:      	testb	%dl, %dl
   4d204:      	je	0x4d1dd <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17ad>
   4d206:      	jmp	0x4d21b <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17eb>
   4d208:      	xorl	%ebp, %ebp
   4d20a:      	testq	%r11, %r11
   4d20d:      	movq	0x8(%rsp), %r13
   4d212:      	jne	0x4d229 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17f9>
   4d214:      	jmp	0x4c0c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x699>
   4d219:      	xorl	%ebp, %ebp
   4d21b:      	testq	%r11, %r11
   4d21e:      	movq	0x8(%rsp), %r13
   4d223:      	je	0x4c0c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x699>
   4d229:      	callq	*0x14489(%rip)          # 0x616b8 <writev+0x616b8>
   4d22f:      	jmp	0x4c0c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x699>
   4d234:      	movq	%rax, %rbp
   4d237:      	testq	%r11, %r11
   4d23a:      	movq	0x8(%rsp), %r13
   4d23f:      	jne	0x4d229 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x17f9>
   4d241:      	jmp	0x4c0c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x699>
   4d246:      	movl	$0x180, %edi            # imm = 0x180
   4d24b:      	callq	0x13ce0 <alloc::alloc::handle_alloc_error>
   4d250:      	callq	0x4e382 <<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::get_or_init<std::io::stdio::stdout::{closure#0}>::{closure#0}, !>>
   4d255:      	movq	%fs:-0x8, %r14
   4d25e:      	testq	%r14, %r14
   4d261:      	jne	0x4cf48 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1518>
   4d267:      	movq	0x1613a(%rip), %rax     # 0x633a8 <<std::thread::id::ThreadId>::new::COUNTER>
   4d26e:      	nop
   4d270:      	cmpq	$-0x1, %rax
   4d274:      	je	0x4d404 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x19d4>
   4d27a:      	leaq	0x1(%rax), %r14
   4d27e:      	lock
   4d27f:      	cmpxchgq	%r14, 0x16121(%rip)     # 0x633a8 <<std::thread::id::ThreadId>::new::COUNTER>
   4d287:      	jne	0x4d270 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1840>
   4d289:      	movq	%r14, %fs:-0x8
   4d292:      	movq	0x155f7(%rip), %rax     # 0x62890 <std::io::stdio::STDOUT>
   4d299:      	cmpq	%rax, %r14
   4d29c:      	je	0x4cf58 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1528>
   4d2a2:      	movl	$0x1, %ebp
   4d2a7:      	xorl	%eax, %eax
   4d2a9:      	lock
   4d2aa:      	cmpxchgl	%ebp, 0x155e7(%rip)     # 0x62898 <std::io::stdio::STDOUT+0x8>
   4d2b1:      	jne	0x4d421 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x19f1>
   4d2b7:      	movq	%r14, 0x155d2(%rip)     # 0x62890 <std::io::stdio::STDOUT>
   4d2be:      	movl	%ebp, 0x155d8(%rip)     # 0x6289c <std::io::stdio::STDOUT+0xc>
   4d2c4:      	leaq	0x155c5(%rip), %rax     # 0x62890 <std::io::stdio::STDOUT>
   4d2cb:      	movq	%rax, 0x18(%rsp)
   4d2d0:      	leaq	0x18(%rsp), %r12
   4d2d5:      	movq	%r12, 0x80(%rsp)
   4d2dd:      	leaq	0x88(%rsp), %r14
   4d2e5:      	movq	$0x0, 0x88(%rsp)
   4d2f1:      	leaq	0x13160(%rip), %rsi     # 0x60458 <writev+0x60458>
   4d2f8:      	leaq	-0x47387(%rip), %rdx    # 0x5f78 <writev+0x5f78>
   4d2ff:      	leaq	0x80(%rsp), %rdi
   4d307:      	leaq	0x228(%rsp), %rcx
   4d30f:      	callq	0x137e0 <core::fmt::write>
   4d314:      	movq	0x88(%rsp), %rcx
   4d31c:      	testb	%al, %al
   4d31e:      	je	0x4d340 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1910>
   4d320:      	movq	%rcx, %r15
   4d323:      	testq	%rcx, %rcx
   4d326:      	jne	0x4d390 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1960>
   4d328:      	leaq	-0x43e83(%rip), %rdi    # 0x94ac <core::num::flt2dec::strategy::dragon::POW5TO256+0x978>
   4d32f:      	leaq	0x130da(%rip), %rdx     # 0x60410 <writev+0x60410>
   4d336:      	movl	$0xad, %esi
   4d33b:      	callq	0x13d10 <core::panicking::panic_fmt>
   4d340:      	testq	%rcx, %rcx
   4d343:      	je	0x4d38d <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x195d>
   4d345:      	movl	%ecx, %eax
   4d347:      	andl	$0x3, %eax
   4d34a:      	xorl	%r15d, %r15d
   4d34d:      	leal	-0x2(%rax), %edx
   4d350:      	cmpl	$0x2, %edx
   4d353:      	jb	0x4d390 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1960>
   4d355:      	testq	%rax, %rax
   4d358:      	je	0x4d390 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1960>
   4d35a:      	leaq	-0x1(%rcx), %r14
   4d35e:      	movq	-0x1(%rcx), %r15
   4d362:      	movq	0x7(%rcx), %r13
   4d366:      	movq	(%r13), %rax
   4d36a:      	testq	%rax, %rax
   4d36d:      	je	0x4d374 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1944>
   4d36f:      	movq	%r15, %rdi
   4d372:      	callq	*%rax
   4d374:      	cmpq	$0x0, 0x8(%r13)
   4d379:      	je	0x4d384 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1954>
   4d37b:      	movq	%r15, %rdi
   4d37e:      	callq	*0x14334(%rip)          # 0x616b8 <writev+0x616b8>
   4d384:      	movq	%r14, %rdi
   4d387:      	callq	*0x1432b(%rip)          # 0x616b8 <writev+0x616b8>
   4d38d:      	xorl	%r15d, %r15d
   4d390:      	movq	0x18(%rsp), %rsi
   4d395:      	decl	0xc(%rsi)
   4d398:      	jne	0x4d3af <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x197f>
   4d39a:      	movq	$0x0, (%rsi)
   4d3a1:      	xorl	%eax, %eax
   4d3a3:      	xchgl	%eax, 0x8(%rsi)
   4d3a6:      	cmpl	$0x2, %eax
   4d3a9:      	je	0x4d432 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a02>
   4d3af:      	testq	%r15, %r15
   4d3b2:      	jne	0x4d456 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1a26>
   4d3b8:      	leaq	0x80(%rsp), %rdi
   4d3c0:      	callq	0x4d920 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4d3c5:      	movq	0x80(%rsp), %rbx
   4d3cd:      	testq	%rbx, %rbx
   4d3d0:      	jle	0x4d3e0 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x19b0>
   4d3d2:      	movq	0x88(%rsp), %rdi
   4d3da:      	callq	*0x142d8(%rip)          # 0x616b8 <writev+0x616b8>
   4d3e0:      	xorl	%eax, %eax
   4d3e2:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4d3ec:      	cmpq	%rcx, %rbx
   4d3ef:      	setne	%al
   4d3f2:      	addq	$0x3c8, %rsp            # imm = 0x3C8
   4d3f9:      	popq	%rbx
   4d3fa:      	popq	%r12
   4d3fc:      	popq	%r13
   4d3fe:      	popq	%r14
   4d400:      	popq	%r15
   4d402:      	popq	%rbp
   4d403:      	retq
   4d404:      	callq	0x48380 <<std::thread::id::ThreadId>::new::exhausted>
   4d409:      	leaq	-0x4376c(%rip), %rdi    # 0x9ca4 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1170>
   4d410:      	leaq	0x134b1(%rip), %rdx     # 0x608c8 <writev+0x608c8>
   4d417:      	movl	$0x26, %esi
   4d41c:      	callq	0x4e3e0 <core::option::expect_failed>
   4d421:      	leaq	0x15470(%rip), %rdi     # 0x62898 <std::io::stdio::STDOUT+0x8>
   4d428:      	callq	0x47010 <<std::sys::sync::mutex::futex::Mutex>::lock_contended>
   4d42d:      	jmp	0x4d2b7 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1887>
   4d432:      	addq	$0x8, %rsi
   4d436:      	movl	$0xca, %edi
   4d43b:      	movl	$0x81, %edx
   4d440:      	movl	$0x1, %ecx
   4d445:      	xorl	%eax, %eax
   4d447:      	callq	*0x14273(%rip)          # 0x616c0 <writev+0x616c0>
   4d44d:      	testq	%r15, %r15
   4d450:      	je	0x4d3b8 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1988>
   4d456:      	movq	%r15, 0x18(%rsp)
   4d45b:      	movq	%rbx, 0x80(%rsp)
   4d463:      	leaq	-0x33eaa(%rip), %rax    # 0x195c0 <<&str as core::fmt::Display>::fmt>
   4d46a:      	movq	%rax, 0x88(%rsp)
   4d472:      	movq	%r12, 0x90(%rsp)
   4d47a:      	leaq	0x153f(%rip), %rax      # 0x4e9c0 <<std::io::error::Error as core::fmt::Display>::fmt>
   4d481:      	movq	%rax, 0x98(%rsp)
   4d489:      	leaq	-0x4676c(%rip), %rdi    # 0x6d24 <writev+0x6d24>
   4d490:      	leaq	0x13051(%rip), %rdx     # 0x604e8 <writev+0x604e8>
   4d497:      	leaq	0x80(%rsp), %rsi
   4d49f:      	callq	0x13d10 <core::panicking::panic_fmt>
   4d4a4:      	leaq	-0x4414f(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   4d4ab:      	movl	$0x2f, %esi
   4d4b0:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   4d4b5:      	movq	%r15, %rdi
   4d4b8:      	callq	0x13ce0 <alloc::alloc::handle_alloc_error>
   4d4bd:      	movl	$0x510, %edi            # imm = 0x510
   4d4c2:      	callq	0x13ce0 <alloc::alloc::handle_alloc_error>
   4d4c7:      	movl	$0x78, %edi
   4d4cc:      	callq	0x13ce0 <alloc::alloc::handle_alloc_error>
   4d4d1:      	movl	$0x1b0, %edi            # imm = 0x1B0
   4d4d6:      	callq	0x13ce0 <alloc::alloc::handle_alloc_error>
   4d4db:      	movq	%r13, 0x8(%rsp)
   4d4e0:      	movq	%r12, 0x10(%rsp)
   4d4e5:      	testq	%rbx, %rbx
   4d4e8:      	jne	0x4d510 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1ae0>
   4d4ea:      	cmpq	$0x0, 0x8(%rsp)
   4d4f0:      	jne	0x4d556 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b26>
   4d4f2:      	cmpq	$0x0, 0x60(%rsp)
   4d4f8:      	jne	0x4d569 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b39>
   4d4fa:      	cmpq	$0x0, 0x68(%rsp)
   4d500:      	jne	0x4d57c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b4c>
   4d502:      	testq	%r15, %r15
   4d505:      	je	0x4d58c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b5c>
   4d50b:      	jmp	0x4d5a9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b79>
   4d510:      	movq	0x38(%rsp), %rax
   4d515:      	leaq	0x18(%rax), %r14
   4d519:      	movq	0x14150(%rip), %r13     # 0x61670 <writev+0x61670>
   4d520:      	movq	0x14191(%rip), %rbp     # 0x616b8 <writev+0x616b8>
   4d527:      	jmp	0x4d539 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b09>
   4d529:      	nopl	(%rax)
   4d530:      	addq	$0x38, %r14
   4d534:      	decq	%rbx
   4d537:      	je	0x4d4ea <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1aba>
   4d539:      	movq	-0x8(%r14), %rsi
   4d53d:      	movq	(%r14), %rdi
   4d540:      	shlq	$0xf, %rsi
   4d544:      	callq	*%r13
   4d547:      	cmpq	$0x0, -0x18(%r14)
   4d54c:      	je	0x4d530 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b00>
   4d54e:      	movq	-0x10(%r14), %rdi
   4d552:      	callq	*%rbp
   4d554:      	jmp	0x4d530 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b00>
   4d556:      	movq	0x38(%rsp), %rdi
   4d55b:      	callq	*0x14157(%rip)          # 0x616b8 <writev+0x616b8>
   4d561:      	cmpq	$0x0, 0x60(%rsp)
   4d567:      	je	0x4d4fa <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1aca>
   4d569:      	movq	0x48(%rsp), %rdi
   4d56e:      	callq	*0x14144(%rip)          # 0x616b8 <writev+0x616b8>
   4d574:      	cmpq	$0x0, 0x68(%rsp)
   4d57a:      	je	0x4d502 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1ad2>
   4d57c:      	movq	0x50(%rsp), %rdi
   4d581:      	callq	*0x14131(%rip)          # 0x616b8 <writev+0x616b8>
   4d587:      	testq	%r15, %r15
   4d58a:      	jne	0x4d5a9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b79>
   4d58c:      	cmpq	$0x0, 0x70(%rsp)
   4d592:      	jne	0x4d5d8 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1ba8>
   4d594:      	cmpq	$0x0, 0x78(%rsp)
   4d59a:      	jne	0x4d5eb <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1bbb>
   4d59c:      	cmpq	$0x0, 0x28(%rsp)
   4d5a2:      	jne	0x4d5fe <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1bce>
   4d5a4:      	callq	0x55770 <native_trap>
   4d5a9:      	movq	0x40(%rsp), %rax
   4d5ae:      	leaq	0x8(%rax), %rbx
   4d5b2:      	movq	0x140ff(%rip), %r14     # 0x616b8 <writev+0x616b8>
   4d5b9:      	jmp	0x4d5c9 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b99>
   4d5bb:      	nopl	(%rax,%rax)
   4d5c0:      	addq	$0x18, %rbx
   4d5c4:      	decq	%r15
   4d5c7:      	je	0x4d58c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b5c>
   4d5c9:      	cmpq	$0x0, -0x8(%rbx)
   4d5ce:      	jle	0x4d5c0 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b90>
   4d5d0:      	movq	(%rbx), %rdi
   4d5d3:      	callq	*%r14
   4d5d6:      	jmp	0x4d5c0 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b90>
   4d5d8:      	movq	0x40(%rsp), %rdi
   4d5dd:      	callq	*0x140d5(%rip)          # 0x616b8 <writev+0x616b8>
   4d5e3:      	cmpq	$0x0, 0x78(%rsp)
   4d5e9:      	je	0x4d59c <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b6c>
   4d5eb:      	movq	0x58(%rsp), %rdi
   4d5f0:      	callq	*0x140c2(%rip)          # 0x616b8 <writev+0x616b8>
   4d5f6:      	cmpq	$0x0, 0x28(%rsp)
   4d5fc:      	je	0x4d5a4 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1b74>
   4d5fe:      	movq	0x10(%rsp), %rdi
   4d603:      	callq	*0x140af(%rip)          # 0x616b8 <writev+0x616b8>
   4d609:      	callq	0x55770 <native_trap>
   4d60e:      	movq	%rax, %rbx
   4d611:      	cmpq	$0x0, 0x8(%r13)
   4d616:      	je	0x4d621 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1bf1>
   4d618:      	movq	%r15, %rdi
   4d61b:      	callq	*0x14097(%rip)          # 0x616b8 <writev+0x616b8>
   4d621:      	movq	%r14, %rdi
   4d624:      	callq	*0x1408e(%rip)          # 0x616b8 <writev+0x616b8>
   4d62a:      	movq	0x18(%rsp), %rdi
   4d62f:      	callq	0x4e980 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4d634:      	movq	%rbx, %rdi
   4d637:      	callq	0x5e100 <_Unwind_Resume@plt>
   4d63c:      	movq	%rax, %rbx
   4d63f:      	cmpq	$0x0, 0x8(%r13)
   4d644:      	je	0x4d64f <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1c1f>
   4d646:      	movq	%rbp, %rdi
   4d649:      	callq	*0x14069(%rip)          # 0x616b8 <writev+0x616b8>
   4d64f:      	movq	0x8(%rsp), %rdi
   4d654:      	callq	*0x1405e(%rip)          # 0x616b8 <writev+0x616b8>
   4d65a:      	movq	%rbx, %rdi
   4d65d:      	callq	0x5e100 <_Unwind_Resume@plt>
   4d662:      	movq	%rax, %rbx
   4d665:      	cmpq	$0x0, 0x88(%rsp)
   4d66e:      	je	0x4d678 <wasm_native_ea4c7e51c5a1e59ae6c8c37095aa9520684d9c2d0c73b5ae94b637eb803abe9f::run::hb4646ff9b2791a05+0x1c48>
   4d670:      	movq	%r14, %rdi
   4d673:      	callq	0x21740 <core::ptr::drop_in_place::<std::io::error::Error>>
   4d678:      	movq	0x18(%rsp), %rdi
   4d67d:      	callq	0x4e980 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4d682:      	movq	%rbx, %rdi
   4d685:      	callq	0x5e100 <_Unwind_Resume@plt>
   4d68a:      	callq	0x1475c <core::panicking::panic_in_cleanup>
   4d68f:      	movq	%rax, %rbx
   4d692:      	leaq	0x18(%rsp), %rdi
   4d697:      	callq	0x21740 <core::ptr::drop_in_place::<std::io::error::Error>>
   4d69c:      	movq	%rbx, %rdi
   4d69f:      	callq	0x5e100 <_Unwind_Resume@plt>
   4d6a4:      	callq	0x1475c <core::panicking::panic_in_cleanup>
   4d6a9:      	int3
   4d6aa:      	int3
   4d6ab:      	int3
   4d6ac:      	int3
   4d6ad:      	int3
   4d6ae:      	int3
   4d6af:      	int3
