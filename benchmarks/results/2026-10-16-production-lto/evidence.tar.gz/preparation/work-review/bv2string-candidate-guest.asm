0000000000058ee0 <f.7>:
   58ee0:      	pushq	%rbp
   58ee1:      	pushq	%r15
   58ee3:      	pushq	%r14
   58ee5:      	pushq	%r13
   58ee7:      	pushq	%r12
   58ee9:      	pushq	%rbx
   58eea:      	subq	$0x118, %rsp            # imm = 0x118
   58ef1:      	movq	%rsi, %rbx
   58ef4:      	movq	$0x1b, 0x10(%rsp)
   58efd:      	movq	$0x0, 0x18(%rsp)
   58f06:      	movq	0xa40b(%rip), %rcx      # 0x63318 <native_roots.0>
   58f0d:      	movq	%rcx, 0x8(%rsp)
   58f12:      	leaq	0x8(%rsp), %rax
   58f17:      	movq	%rax, 0xa3fa(%rip)      # 0x63318 <native_roots.0>
   58f1e:      	movq	0xa3d3(%rip), %rsi      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58f25:      	leaq	0x1(%rsi), %rax
   58f29:      	movq	0xa3d0(%rip), %r8       # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58f30:      	cmpq	%r8, %rax
   58f33:      	cmovaq	%rax, %r8
   58f37:      	movq	%rax, 0xa3ba(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58f3e:      	movq	%r8, 0xa3bb(%rip)       # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58f45:      	movq	%rdi, 0x20(%rsp)
   58f4a:      	xorps	%xmm0, %xmm0
   58f4d:      	movups	%xmm0, 0x28(%rsp)
   58f52:      	movups	%xmm0, 0x38(%rsp)
   58f57:      	movups	%xmm0, 0x48(%rsp)
   58f5c:      	movups	%xmm0, 0x58(%rsp)
   58f61:      	movups	%xmm0, 0x68(%rsp)
   58f66:      	movups	%xmm0, 0x78(%rsp)
   58f6b:      	movups	%xmm0, 0x88(%rsp)
   58f73:      	movups	%xmm0, 0x98(%rsp)
   58f7b:      	movups	%xmm0, 0xa8(%rsp)
   58f83:      	movups	%xmm0, 0xb8(%rsp)
   58f8b:      	movq	$0x0, 0xc8(%rsp)
   58f97:      	testq	%rdi, %rdi
   58f9a:      	je	0x5b1a5 <f.7+0x22c5>
   58fa0:      	leaq	0x80e1(%rip), %r13      # 0x61088 <ref.16>
   58fa7:      	movq	%rdi, 0x60(%rsp)
   58fac:      	cmpq	%rbx, 0x8(%rdi)
   58fb0:      	jle	0x5b165 <f.7+0x2285>
   58fb6:      	nopw	%cs:(%rax,%rax)
   58fc0:      	cmpb	$0x0, 0xa4e9(%rip)      # 0x634b0 <g.28>
   58fc7:      	je	0x5b1a5 <f.7+0x22c5>
   58fcd:      	cmpb	$0x0, 0xa49c(%rip)      # 0x63470 <g.20>
   58fd4:      	je	0x5b1a5 <f.7+0x22c5>
   58fda:      	cmpq	$0x0, 0xa486(%rip)      # 0x63468 <g.19>
   58fe2:      	je	0x5b1a5 <f.7+0x22c5>
   58fe8:      	movq	0xa4b9(%rip), %rax      # 0x634a8 <g.27>
   58fef:      	movq	$0x16, 0x18(%rsp)
   58ff8:      	movq	%rax, 0xf8(%rsp)
   59000:      	leaq	0xf8(%rsp), %rax
   59008:      	cmpb	$0x0, 0xa4b1(%rip)      # 0x634c0 <g.30>
   5900f:      	je	0x5b1a5 <f.7+0x22c5>
   59015:      	cmpb	$0x0, 0xa454(%rip)      # 0x63470 <g.20>
   5901c:      	je	0x5b1a5 <f.7+0x22c5>
   59022:      	cmpq	$0x0, 0xa43e(%rip)      # 0x63468 <g.19>
   5902a:      	je	0x5b1a5 <f.7+0x22c5>
   59030:      	movq	0xf8(%rsp), %rcx
   59038:      	movq	0xa479(%rip), %rax      # 0x634b8 <g.29>
   5903f:      	movq	$0x16, 0x18(%rsp)
   59048:      	movq	%rax, 0xf8(%rsp)
   59050:      	leaq	0xf8(%rsp), %rax
   59058:      	cmpb	$0x0, 0xa441(%rip)      # 0x634a0 <g.26>
   5905f:      	je	0x5b1a5 <f.7+0x22c5>
   59065:      	cmpq	$0x0, 0xa42b(%rip)      # 0x63498 <g.25>
   5906d:      	je	0x5b1a5 <f.7+0x22c5>
   59073:      	movq	%rcx, 0x110(%rsp)
   5907b:      	movq	0xf8(%rsp), %rax
   59083:      	movq	%rax, 0x108(%rsp)
   5908b:      	movq	%r13, 0xd0(%rsp)
   59093:      	movq	$0x17, 0x18(%rsp)
   5909c:      	movq	0xa26d(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   590a3:      	testq	%rdi, %rdi
   590a6:      	je	0x5b1a5 <f.7+0x22c5>
   590ac:      	movq	0x178(%rdi), %rcx
   590b3:      	testq	%rcx, %rcx
   590b6:      	je	0x590f5 <f.7+0x215>
   590b8:      	movq	0x170(%rdi), %rax
   590bf:      	incq	%rax
   590c2:      	movq	%rax, 0x170(%rdi)
   590c9:      	movq	%rax, %rdx
   590cc:      	orq	%rcx, %rdx
   590cf:      	shrq	$0x20, %rdx
   590d3:      	je	0x5ac70 <f.7+0x1d90>
   590d9:      	xorl	%edx, %edx
   590db:      	divq	%rcx
   590de:      	testq	%rdx, %rdx
   590e1:      	jne	0x590f5 <f.7+0x215>
   590e3:      	movq	0xa22e(%rip), %rsi      # 0x63318 <native_roots.0>
   590ea:      	movq	%rdi, %r14
   590ed:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   590f2:      	movq	%r14, %rdi
   590f5:      	movq	0xa21c(%rip), %rdx      # 0x63318 <native_roots.0>
   590fc:      	movl	$0x18, %esi
   59101:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59106:      	testq	%rax, %rax
   59109:      	je	0x5b1aa <f.7+0x22ca>
   5910f:      	movq	%rax, %r14
   59112:      	movq	$0x56, (%rax)
   59119:      	movl	$0x0, 0x8(%rax)
   59120:      	movq	$0x0, 0x10(%rax)
   59128:      	movq	%rax, 0x70(%rsp)
   5912d:      	movq	%rax, 0xd0(%rsp)
   59135:      	movq	%r13, 0xd8(%rsp)
   5913d:      	movq	$0x18, 0x18(%rsp)
   59146:      	movq	0xa1c3(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5914d:      	testq	%rdi, %rdi
   59150:      	je	0x5b1a5 <f.7+0x22c5>
   59156:      	movq	0x178(%rdi), %rcx
   5915d:      	testq	%rcx, %rcx
   59160:      	je	0x5919f <f.7+0x2bf>
   59162:      	movq	0x170(%rdi), %rax
   59169:      	incq	%rax
   5916c:      	movq	%rax, 0x170(%rdi)
   59173:      	movq	%rax, %rdx
   59176:      	orq	%rcx, %rdx
   59179:      	shrq	$0x20, %rdx
   5917d:      	je	0x5ac90 <f.7+0x1db0>
   59183:      	xorl	%edx, %edx
   59185:      	divq	%rcx
   59188:      	testq	%rdx, %rdx
   5918b:      	jne	0x5919f <f.7+0x2bf>
   5918d:      	movq	0xa184(%rip), %rsi      # 0x63318 <native_roots.0>
   59194:      	movq	%rdi, %r15
   59197:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5919c:      	movq	%r15, %rdi
   5919f:      	movq	0xa172(%rip), %rdx      # 0x63318 <native_roots.0>
   591a6:      	movl	$0x18, %esi
   591ab:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   591b0:      	testq	%rax, %rax
   591b3:      	je	0x5b1aa <f.7+0x22ca>
   591b9:      	movq	%rax, %r15
   591bc:      	movq	$0x52, (%rax)
   591c3:      	movl	$0x0, 0x8(%rax)
   591ca:      	movq	$0x0, 0x10(%rax)
   591d2:      	movq	%rax, 0x88(%rsp)
   591da:      	movq	%rax, 0xd0(%rsp)
   591e2:      	movq	%r14, 0xd8(%rsp)
   591ea:      	movq	%r13, 0xe0(%rsp)
   591f2:      	movq	$0x19, 0x18(%rsp)
   591fb:      	movq	0xa10e(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59202:      	testq	%rdi, %rdi
   59205:      	je	0x5b1a5 <f.7+0x22c5>
   5920b:      	movq	0x178(%rdi), %rcx
   59212:      	testq	%rcx, %rcx
   59215:      	je	0x59254 <f.7+0x374>
   59217:      	movq	0x170(%rdi), %rax
   5921e:      	incq	%rax
   59221:      	movq	%rax, 0x170(%rdi)
   59228:      	movq	%rax, %rdx
   5922b:      	orq	%rcx, %rdx
   5922e:      	shrq	$0x20, %rdx
   59232:      	je	0x5acb0 <f.7+0x1dd0>
   59238:      	xorl	%edx, %edx
   5923a:      	divq	%rcx
   5923d:      	testq	%rdx, %rdx
   59240:      	jne	0x59254 <f.7+0x374>
   59242:      	movq	0xa0cf(%rip), %rsi      # 0x63318 <native_roots.0>
   59249:      	movq	%rdi, %r12
   5924c:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59251:      	movq	%r12, %rdi
   59254:      	movq	0xa0bd(%rip), %rdx      # 0x63318 <native_roots.0>
   5925b:      	movl	$0x18, %esi
   59260:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59265:      	testq	%rax, %rax
   59268:      	je	0x5b1aa <f.7+0x22ca>
   5926e:      	movq	%rax, %r12
   59271:      	movq	$0x56, (%rax)
   59278:      	movl	$0x0, 0x8(%rax)
   5927f:      	movq	$0x0, 0x10(%rax)
   59287:      	movq	%rax, 0x78(%rsp)
   5928c:      	movq	%rax, 0xd0(%rsp)
   59294:      	movq	%r15, 0xd8(%rsp)
   5929c:      	movq	%r14, 0xe0(%rsp)
   592a4:      	movq	%r13, 0xe8(%rsp)
   592ac:      	movq	$0x1a, 0x18(%rsp)
   592b5:      	movq	0xa054(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   592bc:      	testq	%rdi, %rdi
   592bf:      	je	0x5b1a5 <f.7+0x22c5>
   592c5:      	movq	0x178(%rdi), %rcx
   592cc:      	testq	%rcx, %rcx
   592cf:      	je	0x5930e <f.7+0x42e>
   592d1:      	movq	0x170(%rdi), %rax
   592d8:      	incq	%rax
   592db:      	movq	%rax, 0x170(%rdi)
   592e2:      	movq	%rax, %rdx
   592e5:      	orq	%rcx, %rdx
   592e8:      	shrq	$0x20, %rdx
   592ec:      	je	0x5acd0 <f.7+0x1df0>
   592f2:      	xorl	%edx, %edx
   592f4:      	divq	%rcx
   592f7:      	testq	%rdx, %rdx
   592fa:      	jne	0x5930e <f.7+0x42e>
   592fc:      	movq	0xa015(%rip), %rsi      # 0x63318 <native_roots.0>
   59303:      	movq	%rdi, %r13
   59306:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5930b:      	movq	%r13, %rdi
   5930e:      	movq	0xa003(%rip), %rdx      # 0x63318 <native_roots.0>
   59315:      	movl	$0x18, %esi
   5931a:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5931f:      	testq	%rax, %rax
   59322:      	je	0x5b1aa <f.7+0x22ca>
   59328:      	movq	%rax, %r13
   5932b:      	movq	$0x56, (%rax)
   59332:      	movl	$0x0, 0x8(%rax)
   59339:      	movq	$0x0, 0x10(%rax)
   59341:      	movq	%rax, 0x80(%rsp)
   59349:      	movq	%rax, 0xd0(%rsp)
   59351:      	movq	%r12, 0xd8(%rsp)
   59359:      	movq	%r15, 0xe0(%rsp)
   59361:      	movq	%r14, 0xe8(%rsp)
   59369:      	leaq	0x7d18(%rip), %rax      # 0x61088 <ref.16>
   59370:      	movq	%rax, 0xf0(%rsp)
   59378:      	movq	$0x1b, 0x18(%rsp)
   59381:      	movq	0x9f88(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59388:      	testq	%rdi, %rdi
   5938b:      	je	0x5b1a5 <f.7+0x22c5>
   59391:      	movq	0x178(%rdi), %rcx
   59398:      	testq	%rcx, %rcx
   5939b:      	je	0x593da <f.7+0x4fa>
   5939d:      	movq	0x170(%rdi), %rax
   593a4:      	incq	%rax
   593a7:      	movq	%rax, 0x170(%rdi)
   593ae:      	movq	%rax, %rdx
   593b1:      	orq	%rcx, %rdx
   593b4:      	shrq	$0x20, %rdx
   593b8:      	je	0x5acf0 <f.7+0x1e10>
   593be:      	xorl	%edx, %edx
   593c0:      	divq	%rcx
   593c3:      	testq	%rdx, %rdx
   593c6:      	jne	0x593da <f.7+0x4fa>
   593c8:      	movq	0x9f49(%rip), %rsi      # 0x63318 <native_roots.0>
   593cf:      	movq	%rdi, %rbp
   593d2:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   593d7:      	movq	%rbp, %rdi
   593da:      	movq	0x9f37(%rip), %rdx      # 0x63318 <native_roots.0>
   593e1:      	movl	$0x28, %esi
   593e6:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   593eb:      	testq	%rax, %rax
   593ee:      	je	0x5b1aa <f.7+0x22ca>
   593f4:      	movq	%rax, %rbp
   593f7:      	movq	$0x3e, (%rax)
   593fe:      	movq	%r14, 0x8(%rax)
   59402:      	movq	%r15, 0x10(%rax)
   59406:      	movq	%r12, 0x18(%rax)
   5940a:      	movq	%r13, 0x20(%rax)
   5940e:      	movq	%rax, 0xd0(%rsp)
   59416:      	leaq	0x7c6b(%rip), %r15      # 0x61088 <ref.16>
   5941d:      	movq	%r15, 0xd8(%rsp)
   59425:      	movq	$0x18, 0x18(%rsp)
   5942e:      	movq	0x9edb(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59435:      	testq	%rdi, %rdi
   59438:      	je	0x5b1a5 <f.7+0x22c5>
   5943e:      	movq	0x178(%rdi), %rcx
   59445:      	testq	%rcx, %rcx
   59448:      	leaq	0x7c29(%rip), %r13      # 0x61078 <ref.14>
   5944f:      	je	0x5948e <f.7+0x5ae>
   59451:      	movq	0x170(%rdi), %rax
   59458:      	incq	%rax
   5945b:      	movq	%rax, 0x170(%rdi)
   59462:      	movq	%rax, %rdx
   59465:      	orq	%rcx, %rdx
   59468:      	shrq	$0x20, %rdx
   5946c:      	je	0x5ad10 <f.7+0x1e30>
   59472:      	xorl	%edx, %edx
   59474:      	divq	%rcx
   59477:      	testq	%rdx, %rdx
   5947a:      	jne	0x5948e <f.7+0x5ae>
   5947c:      	movq	0x9e95(%rip), %rsi      # 0x63318 <native_roots.0>
   59483:      	movq	%rdi, %r14
   59486:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5948b:      	movq	%r14, %rdi
   5948e:      	movq	0x9e83(%rip), %rdx      # 0x63318 <native_roots.0>
   59495:      	movl	$0x18, %esi
   5949a:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5949f:      	testq	%rax, %rax
   594a2:      	je	0x5b1aa <f.7+0x22ca>
   594a8:      	movq	%rax, %r14
   594ab:      	movq	$0x92, (%rax)
   594b2:      	movq	%r15, 0x8(%rax)
   594b6:      	movq	%rbp, 0x10(%rax)
   594ba:      	movq	%rax, 0xd0(%rsp)
   594c2:      	movq	$0x17, 0x18(%rsp)
   594cb:      	movq	0x9e3e(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   594d2:      	testq	%rdi, %rdi
   594d5:      	je	0x5b1a5 <f.7+0x22c5>
   594db:      	movq	0x178(%rdi), %rcx
   594e2:      	testq	%rcx, %rcx
   594e5:      	je	0x59524 <f.7+0x644>
   594e7:      	movq	0x170(%rdi), %rax
   594ee:      	incq	%rax
   594f1:      	movq	%rax, 0x170(%rdi)
   594f8:      	movq	%rax, %rdx
   594fb:      	orq	%rcx, %rdx
   594fe:      	shrq	$0x20, %rdx
   59502:      	je	0x5ad30 <f.7+0x1e50>
   59508:      	xorl	%edx, %edx
   5950a:      	divq	%rcx
   5950d:      	testq	%rdx, %rdx
   59510:      	jne	0x59524 <f.7+0x644>
   59512:      	movq	0x9dff(%rip), %rsi      # 0x63318 <native_roots.0>
   59519:      	movq	%rdi, %r15
   5951c:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59521:      	movq	%r15, %rdi
   59524:      	movq	0x9ded(%rip), %rdx      # 0x63318 <native_roots.0>
   5952b:      	movl	$0x10, %esi
   59530:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59535:      	testq	%rax, %rax
   59538:      	je	0x5b1aa <f.7+0x22ca>
   5953e:      	movq	$0x4e, (%rax)
   59545:      	movq	%r14, 0x8(%rax)
   59549:      	movq	%rax, 0x90(%rsp)
   59551:      	movq	0x70(%rsp), %rax
   59556:      	testq	%rax, %rax
   59559:      	je	0x5b1a5 <f.7+0x22c5>
   5955f:      	movq	%rbx, 0x100(%rsp)
   59567:      	movq	$0x2bd, 0x10(%rax)      # imm = 0x2BD
   5956f:      	movq	0x70(%rsp), %rax
   59574:      	testq	%rax, %rax
   59577:      	je	0x5b1a5 <f.7+0x22c5>
   5957d:      	movl	$0x1, 0x8(%rax)
   59584:      	movq	0x88(%rsp), %rbx
   5958c:      	movq	%rbx, 0xd0(%rsp)
   59594:      	movq	$0x17, 0x18(%rsp)
   5959d:      	movq	0x9d6c(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   595a4:      	testq	%rdi, %rdi
   595a7:      	je	0x5b1a5 <f.7+0x22c5>
   595ad:      	movq	0x178(%rdi), %rcx
   595b4:      	testq	%rcx, %rcx
   595b7:      	je	0x595f6 <f.7+0x716>
   595b9:      	movq	0x170(%rdi), %rax
   595c0:      	incq	%rax
   595c3:      	movq	%rax, 0x170(%rdi)
   595ca:      	movq	%rax, %rdx
   595cd:      	orq	%rcx, %rdx
   595d0:      	shrq	$0x20, %rdx
   595d4:      	je	0x5ad50 <f.7+0x1e70>
   595da:      	xorl	%edx, %edx
   595dc:      	divq	%rcx
   595df:      	testq	%rdx, %rdx
   595e2:      	jne	0x595f6 <f.7+0x716>
   595e4:      	movq	0x9d2d(%rip), %rsi      # 0x63318 <native_roots.0>
   595eb:      	movq	%rdi, %r14
   595ee:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   595f3:      	movq	%r14, %rdi
   595f6:      	movq	0x9d1b(%rip), %rdx      # 0x63318 <native_roots.0>
   595fd:      	movl	$0x10, %esi
   59602:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59607:      	testq	%rax, %rax
   5960a:      	je	0x5b1aa <f.7+0x22ca>
   59610:      	movq	$0x3a, (%rax)
   59617:      	movq	$0x1, 0x8(%rax)
   5961f:      	testq	%rbx, %rbx
   59622:      	je	0x5b1a5 <f.7+0x22c5>
   59628:      	movq	%rax, 0x10(%rbx)
   5962c:      	movq	0x88(%rsp), %rax
   59634:      	testq	%rax, %rax
   59637:      	je	0x5b1a5 <f.7+0x22c5>
   5963d:      	movl	$0x1, 0x8(%rax)
   59644:      	movq	0x78(%rsp), %rax
   59649:      	testq	%rax, %rax
   5964c:      	je	0x5b1a5 <f.7+0x22c5>
   59652:      	movq	$0xb583b, 0x10(%rax)    # imm = 0xB583B
   5965a:      	movq	0x78(%rsp), %rax
   5965f:      	testq	%rax, %rax
   59662:      	je	0x5b1a5 <f.7+0x22c5>
   59668:      	movl	$0x1, 0x8(%rax)
   5966f:      	movq	0x80(%rsp), %rax
   59677:      	testq	%rax, %rax
   5967a:      	je	0x5b1a5 <f.7+0x22c5>
   59680:      	movq	$0x7ffff, 0x10(%rax)    # imm = 0x7FFFF
   59688:      	movq	0x80(%rsp), %rax
   59690:      	testq	%rax, %rax
   59693:      	je	0x5b1a5 <f.7+0x22c5>
   59699:      	movl	$0x1, 0x8(%rax)
   596a0:      	movq	$0x16, 0x18(%rsp)
   596a9:      	movq	0x9c60(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   596b0:      	testq	%rdi, %rdi
   596b3:      	je	0x5b1a5 <f.7+0x22c5>
   596b9:      	movq	0x178(%rdi), %rcx
   596c0:      	testq	%rcx, %rcx
   596c3:      	je	0x59702 <f.7+0x822>
   596c5:      	movq	0x170(%rdi), %rax
   596cc:      	incq	%rax
   596cf:      	movq	%rax, 0x170(%rdi)
   596d6:      	movq	%rax, %rdx
   596d9:      	orq	%rcx, %rdx
   596dc:      	shrq	$0x20, %rdx
   596e0:      	je	0x5ad70 <f.7+0x1e90>
   596e6:      	xorl	%edx, %edx
   596e8:      	divq	%rcx
   596eb:      	testq	%rdx, %rdx
   596ee:      	jne	0x59702 <f.7+0x822>
   596f0:      	movq	0x9c21(%rip), %rsi      # 0x63318 <native_roots.0>
   596f7:      	movq	%rdi, %r14
   596fa:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   596ff:      	movq	%r14, %rdi
   59702:      	movq	0x9c0f(%rip), %rdx      # 0x63318 <native_roots.0>
   59709:      	movl	$0x18, %esi
   5970e:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59713:      	testq	%rax, %rax
   59716:      	je	0x5b1aa <f.7+0x22ca>
   5971c:      	movq	%rax, %r14
   5971f:      	movq	$0x5a, (%rax)
   59726:      	movl	$0x0, 0x8(%rax)
   5972d:      	movq	$0x0, 0x10(%rax)
   59735:      	movq	%rax, 0x68(%rsp)
   5973a:      	movq	0x90(%rsp), %rbx
   59742:      	movq	%rax, 0xd0(%rsp)
   5974a:      	movq	%rbx, 0xd8(%rsp)
   59752:      	movq	%rax, 0xe0(%rsp)
   5975a:      	movq	$0x19, 0x18(%rsp)
   59763:      	movq	0x9ba6(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5976a:      	testq	%rdi, %rdi
   5976d:      	je	0x5b1a5 <f.7+0x22c5>
   59773:      	movq	0x178(%rdi), %rcx
   5977a:      	testq	%rcx, %rcx
   5977d:      	je	0x597bc <f.7+0x8dc>
   5977f:      	movq	0x170(%rdi), %rax
   59786:      	incq	%rax
   59789:      	movq	%rax, 0x170(%rdi)
   59790:      	movq	%rax, %rdx
   59793:      	orq	%rcx, %rdx
   59796:      	shrq	$0x20, %rdx
   5979a:      	je	0x5ad90 <f.7+0x1eb0>
   597a0:      	xorl	%edx, %edx
   597a2:      	divq	%rcx
   597a5:      	testq	%rdx, %rdx
   597a8:      	jne	0x597bc <f.7+0x8dc>
   597aa:      	movq	0x9b67(%rip), %rsi      # 0x63318 <native_roots.0>
   597b1:      	movq	%rdi, %r15
   597b4:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   597b9:      	movq	%r15, %rdi
   597bc:      	movq	0x9b55(%rip), %rdx      # 0x63318 <native_roots.0>
   597c3:      	movl	$0x18, %esi
   597c8:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   597cd:      	testq	%rax, %rax
   597d0:      	je	0x5b1aa <f.7+0x22ca>
   597d6:      	movq	%rax, %r15
   597d9:      	movq	$0x36, (%rax)
   597e0:      	movq	%rbx, 0x8(%rax)
   597e4:      	movq	%r14, 0x10(%rax)
   597e8:      	movq	%rax, 0xd0(%rsp)
   597f0:      	movq	%r14, 0xd8(%rsp)
   597f8:      	movq	$0x18, 0x18(%rsp)
   59801:      	movq	0x9b08(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59808:      	testq	%rdi, %rdi
   5980b:      	je	0x5b1a5 <f.7+0x22c5>
   59811:      	movq	0x178(%rdi), %rcx
   59818:      	testq	%rcx, %rcx
   5981b:      	je	0x5985a <f.7+0x97a>
   5981d:      	movq	0x170(%rdi), %rax
   59824:      	incq	%rax
   59827:      	movq	%rax, 0x170(%rdi)
   5982e:      	movq	%rax, %rdx
   59831:      	orq	%rcx, %rdx
   59834:      	shrq	$0x20, %rdx
   59838:      	je	0x5adb0 <f.7+0x1ed0>
   5983e:      	xorl	%edx, %edx
   59840:      	divq	%rcx
   59843:      	testq	%rdx, %rdx
   59846:      	jne	0x5985a <f.7+0x97a>
   59848:      	movq	0x9ac9(%rip), %rsi      # 0x63318 <native_roots.0>
   5984f:      	movq	%rdi, %r12
   59852:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59857:      	movq	%r12, %rdi
   5985a:      	movq	0x9ab7(%rip), %rdx      # 0x63318 <native_roots.0>
   59861:      	movl	$0x10, %esi
   59866:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5986b:      	testq	%rax, %rax
   5986e:      	je	0x5b1aa <f.7+0x22ca>
   59874:      	movq	$0x32, (%rax)
   5987b:      	movq	%r15, 0x8(%rax)
   5987f:      	movq	%rax, 0x10(%r14)
   59883:      	movq	0x68(%rsp), %rax
   59888:      	testq	%rax, %rax
   5988b:      	je	0x5b1a5 <f.7+0x22c5>
   59891:      	movl	$0x1, 0x8(%rax)
   59898:      	movq	0x68(%rsp), %rbx
   5989d:      	movq	0x90(%rsp), %r15
   598a5:      	movq	%rbx, 0xd0(%rsp)
   598ad:      	movq	%r15, 0xd8(%rsp)
   598b5:      	movq	%r13, 0xe0(%rsp)
   598bd:      	leaq	0x7794(%rip), %rax      # 0x61058 <ref.12>
   598c4:      	movq	%rax, 0xe8(%rsp)
   598cc:      	movq	$0x1a, 0x18(%rsp)
   598d5:      	movq	0x9a34(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   598dc:      	testq	%rdi, %rdi
   598df:      	je	0x5b1a5 <f.7+0x22c5>
   598e5:      	movq	0x178(%rdi), %rcx
   598ec:      	testq	%rcx, %rcx
   598ef:      	je	0x5992e <f.7+0xa4e>
   598f1:      	movq	0x170(%rdi), %rax
   598f8:      	incq	%rax
   598fb:      	movq	%rax, 0x170(%rdi)
   59902:      	movq	%rax, %rdx
   59905:      	orq	%rcx, %rdx
   59908:      	shrq	$0x20, %rdx
   5990c:      	je	0x5add0 <f.7+0x1ef0>
   59912:      	xorl	%edx, %edx
   59914:      	divq	%rcx
   59917:      	testq	%rdx, %rdx
   5991a:      	jne	0x5992e <f.7+0xa4e>
   5991c:      	movq	0x99f5(%rip), %rsi      # 0x63318 <native_roots.0>
   59923:      	movq	%rdi, %r14
   59926:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5992b:      	movq	%r14, %rdi
   5992e:      	movq	0x99e3(%rip), %rdx      # 0x63318 <native_roots.0>
   59935:      	movl	$0x18, %esi
   5993a:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5993f:      	testq	%rax, %rax
   59942:      	je	0x5b1aa <f.7+0x22ca>
   59948:      	movq	%rax, %r14
   5994b:      	movq	$0x2e, (%rax)
   59952:      	movq	%r15, 0x8(%rax)
   59956:      	movq	%rbx, 0x10(%rax)
   5995a:      	movq	%rax, 0xd0(%rsp)
   59962:      	movq	%r13, 0xd8(%rsp)
   5996a:      	leaq	0x76e7(%rip), %rbx      # 0x61058 <ref.12>
   59971:      	movq	%rbx, 0xe0(%rsp)
   59979:      	movq	$0x19, 0x18(%rsp)
   59982:      	movq	0x9987(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59989:      	testq	%rdi, %rdi
   5998c:      	je	0x5b1a5 <f.7+0x22c5>
   59992:      	movq	0x178(%rdi), %rcx
   59999:      	testq	%rcx, %rcx
   5999c:      	je	0x599db <f.7+0xafb>
   5999e:      	movq	0x170(%rdi), %rax
   599a5:      	incq	%rax
   599a8:      	movq	%rax, 0x170(%rdi)
   599af:      	movq	%rax, %rdx
   599b2:      	orq	%rcx, %rdx
   599b5:      	shrq	$0x20, %rdx
   599b9:      	je	0x5adf0 <f.7+0x1f10>
   599bf:      	xorl	%edx, %edx
   599c1:      	divq	%rcx
   599c4:      	testq	%rdx, %rdx
   599c7:      	jne	0x599db <f.7+0xafb>
   599c9:      	movq	0x9948(%rip), %rsi      # 0x63318 <native_roots.0>
   599d0:      	movq	%rdi, %r15
   599d3:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   599d8:      	movq	%r15, %rdi
   599db:      	movq	0x9936(%rip), %rdx      # 0x63318 <native_roots.0>
   599e2:      	movl	$0x18, %esi
   599e7:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   599ec:      	testq	%rax, %rax
   599ef:      	je	0x5b1aa <f.7+0x22ca>
   599f5:      	movq	%rax, %r15
   599f8:      	movq	$0x92, (%rax)
   599ff:      	movq	%r13, 0x8(%rax)
   59a03:      	movq	%r14, 0x10(%rax)
   59a07:      	movq	%rax, 0xd0(%rsp)
   59a0f:      	movq	%rbx, 0xd8(%rsp)
   59a17:      	movq	$0x18, 0x18(%rsp)
   59a20:      	movq	0x98e9(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59a27:      	testq	%rdi, %rdi
   59a2a:      	je	0x5b1a5 <f.7+0x22c5>
   59a30:      	movq	0x178(%rdi), %rcx
   59a37:      	testq	%rcx, %rcx
   59a3a:      	je	0x59a79 <f.7+0xb99>
   59a3c:      	movq	0x170(%rdi), %rax
   59a43:      	incq	%rax
   59a46:      	movq	%rax, 0x170(%rdi)
   59a4d:      	movq	%rax, %rdx
   59a50:      	orq	%rcx, %rdx
   59a53:      	shrq	$0x20, %rdx
   59a57:      	je	0x5ae10 <f.7+0x1f30>
   59a5d:      	xorl	%edx, %edx
   59a5f:      	divq	%rcx
   59a62:      	testq	%rdx, %rdx
   59a65:      	jne	0x59a79 <f.7+0xb99>
   59a67:      	movq	0x98aa(%rip), %rsi      # 0x63318 <native_roots.0>
   59a6e:      	movq	%rdi, %r14
   59a71:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59a76:      	movq	%r14, %rdi
   59a79:      	movq	0x9898(%rip), %rdx      # 0x63318 <native_roots.0>
   59a80:      	movl	$0x10, %esi
   59a85:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59a8a:      	testq	%rax, %rax
   59a8d:      	je	0x5b1aa <f.7+0x22ca>
   59a93:      	movq	%rax, %r12
   59a96:      	movq	$0x4e, (%rax)
   59a9d:      	movq	%r15, 0x8(%rax)
   59aa1:      	movq	%rax, 0xd0(%rsp)
   59aa9:      	movq	%rbx, 0xd8(%rsp)
   59ab1:      	movq	$0x18, 0x18(%rsp)
   59aba:      	movq	0x984f(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59ac1:      	testq	%rdi, %rdi
   59ac4:      	je	0x5b1a5 <f.7+0x22c5>
   59aca:      	movq	0x178(%rdi), %rcx
   59ad1:      	testq	%rcx, %rcx
   59ad4:      	je	0x59b13 <f.7+0xc33>
   59ad6:      	movq	0x170(%rdi), %rax
   59add:      	incq	%rax
   59ae0:      	movq	%rax, 0x170(%rdi)
   59ae7:      	movq	%rax, %rdx
   59aea:      	orq	%rcx, %rdx
   59aed:      	shrq	$0x20, %rdx
   59af1:      	je	0x5ae30 <f.7+0x1f50>
   59af7:      	xorl	%edx, %edx
   59af9:      	divq	%rcx
   59afc:      	testq	%rdx, %rdx
   59aff:      	jne	0x59b13 <f.7+0xc33>
   59b01:      	movq	0x9810(%rip), %rsi      # 0x63318 <native_roots.0>
   59b08:      	movq	%rdi, %r14
   59b0b:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59b10:      	movq	%r14, %rdi
   59b13:      	movq	0x97fe(%rip), %rdx      # 0x63318 <native_roots.0>
   59b1a:      	movl	$0x10, %esi
   59b1f:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59b24:      	testq	%rax, %rax
   59b27:      	je	0x5b1aa <f.7+0x22ca>
   59b2d:      	movq	%rax, %r14
   59b30:      	movq	$0x4a, (%rax)
   59b37:      	movq	%r12, 0x8(%rax)
   59b3b:      	movq	%rax, 0xd0(%rsp)
   59b43:      	movq	%rbx, 0xd8(%rsp)
   59b4b:      	movq	$0x18, 0x18(%rsp)
   59b54:      	movq	0x97b5(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59b5b:      	testq	%rdi, %rdi
   59b5e:      	je	0x5b1a5 <f.7+0x22c5>
   59b64:      	movq	0x178(%rdi), %rcx
   59b6b:      	testq	%rcx, %rcx
   59b6e:      	je	0x59bad <f.7+0xccd>
   59b70:      	movq	0x170(%rdi), %rax
   59b77:      	incq	%rax
   59b7a:      	movq	%rax, 0x170(%rdi)
   59b81:      	movq	%rax, %rdx
   59b84:      	orq	%rcx, %rdx
   59b87:      	shrq	$0x20, %rdx
   59b8b:      	je	0x5ae50 <f.7+0x1f70>
   59b91:      	xorl	%edx, %edx
   59b93:      	divq	%rcx
   59b96:      	testq	%rdx, %rdx
   59b99:      	jne	0x59bad <f.7+0xccd>
   59b9b:      	movq	0x9776(%rip), %rsi      # 0x63318 <native_roots.0>
   59ba2:      	movq	%rdi, %r15
   59ba5:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59baa:      	movq	%r15, %rdi
   59bad:      	movq	0x9764(%rip), %rdx      # 0x63318 <native_roots.0>
   59bb4:      	movl	$0x18, %esi
   59bb9:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59bbe:      	testq	%rax, %rax
   59bc1:      	je	0x5b1aa <f.7+0x22ca>
   59bc7:      	movq	%rax, %r15
   59bca:      	movq	$0xc2, (%rax)
   59bd1:      	movq	%rbx, 0x8(%rax)
   59bd5:      	movq	%r14, 0x10(%rax)
   59bd9:      	movq	%rax, 0xd0(%rsp)
   59be1:      	movq	$0x17, 0x18(%rsp)
   59bea:      	movq	0x971f(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59bf1:      	testq	%rdi, %rdi
   59bf4:      	je	0x5b1a5 <f.7+0x22c5>
   59bfa:      	movq	0x178(%rdi), %rcx
   59c01:      	testq	%rcx, %rcx
   59c04:      	je	0x59c43 <f.7+0xd63>
   59c06:      	movq	0x170(%rdi), %rax
   59c0d:      	incq	%rax
   59c10:      	movq	%rax, 0x170(%rdi)
   59c17:      	movq	%rax, %rdx
   59c1a:      	orq	%rcx, %rdx
   59c1d:      	shrq	$0x20, %rdx
   59c21:      	je	0x5ae70 <f.7+0x1f90>
   59c27:      	xorl	%edx, %edx
   59c29:      	divq	%rcx
   59c2c:      	testq	%rdx, %rdx
   59c2f:      	jne	0x59c43 <f.7+0xd63>
   59c31:      	movq	0x96e0(%rip), %rsi      # 0x63318 <native_roots.0>
   59c38:      	movq	%rdi, %r14
   59c3b:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59c40:      	movq	%r14, %rdi
   59c43:      	movq	0x96ce(%rip), %rdx      # 0x63318 <native_roots.0>
   59c4a:      	movl	$0x18, %esi
   59c4f:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59c54:      	testq	%rax, %rax
   59c57:      	je	0x5b1aa <f.7+0x22ca>
   59c5d:      	movq	$0x66, (%rax)
   59c64:      	movl	$0x1, 0x8(%rax)
   59c6b:      	movq	%r15, 0x10(%rax)
   59c6f:      	movq	%rax, 0x40(%rsp)
   59c74:      	cmpl	$0x0, 0x8(%rax)
   59c78:      	je	0x5b1a5 <f.7+0x22c5>
   59c7e:      	movq	0x10(%rax), %rax
   59c82:      	testq	%rax, %rax
   59c85:      	je	0x5b1a5 <f.7+0x22c5>
   59c8b:      	movq	0x10(%rax), %rax
   59c8f:      	testq	%rax, %rax
   59c92:      	je	0x5b1a5 <f.7+0x22c5>
   59c98:      	movl	%eax, %ecx
   59c9a:      	andl	$0x1, %ecx
   59c9d:      	jne	0x5b1a5 <f.7+0x22c5>
   59ca3:      	movq	0x9666(%rip), %rsi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59caa:      	testq	%rsi, %rsi
   59cad:      	je	0x5b1a5 <f.7+0x22c5>
   59cb3:      	movq	(%rax), %rcx
   59cb6:      	testq	%rcx, %rcx
   59cb9:      	je	0x59d20 <f.7+0xe40>
   59cbb:      	cmpq	$0x4a, %rcx
   59cbf:      	je	0x59d20 <f.7+0xe40>
   59cc1:      	movq	0x168(%rsi), %rdx
   59cc8:      	shrq	$0x2, %rcx
   59ccc:      	leaq	-0x1(%rcx), %rdi
   59cd0:      	cmpq	%rdx, %rdi
   59cd3:      	jae	0x5b1a5 <f.7+0x22c5>
   59cd9:      	movq	0x160(%rsi), %rsi
   59ce0:      	movq	-0x8(%rsi,%rcx,8), %rcx
   59ce5:      	testq	%rcx, %rcx
   59ce8:      	je	0x59d20 <f.7+0xe40>
   59cea:      	cmpq	$0x4a, %rcx
   59cee:      	je	0x59d20 <f.7+0xe40>
   59cf0:      	shrq	$0x2, %rcx
   59cf4:      	leaq	-0x1(%rcx), %rdi
   59cf8:      	cmpq	%rdx, %rdi
   59cfb:      	jae	0x5b1a5 <f.7+0x22c5>
   59d01:      	movq	-0x8(%rsi,%rcx,8), %rcx
   59d06:      	cmpq	$0x4a, %rcx
   59d0a:      	je	0x59d20 <f.7+0xe40>
   59d0c:      	testq	%rcx, %rcx
   59d0f:      	jne	0x59cf0 <f.7+0xe10>
   59d11:      	nopw	%cs:(%rax,%rax)
   59d20:      	cmpq	$0x4a, %rcx
   59d24:      	jne	0x5b1a5 <f.7+0x22c5>
   59d2a:      	movq	%rax, 0xa8(%rsp)
   59d32:      	movq	0x8(%rax), %rax
   59d36:      	testq	%rax, %rax
   59d39:      	je	0x5b1a5 <f.7+0x22c5>
   59d3f:      	movq	0x8(%rax), %rax
   59d43:      	movq	%rax, 0xb0(%rsp)
   59d4b:      	testq	%rax, %rax
   59d4e:      	je	0x5b1a5 <f.7+0x22c5>
   59d54:      	movq	0x8(%rax), %rcx
   59d58:      	testq	%rcx, %rcx
   59d5b:      	je	0x5b1a5 <f.7+0x22c5>
   59d61:      	movq	0x10(%rax), %rdi
   59d65:      	movq	0x8(%rcx), %rax
   59d69:      	movq	%rdi, 0xd0(%rsp)
   59d71:      	movq	$0x17, 0x18(%rsp)
   59d7a:      	movl	$0xa, %esi
   59d7f:      	callq	*%rax
   59d81:      	subq	$0x8, %rsp
   59d85:      	cmpb	$0x0, 0x9664(%rip)      # 0x633f0 <g.4>
   59d8c:      	je	0x5b1a5 <f.7+0x22c5>
   59d92:      	cmpq	$0x0, 0x964e(%rip)      # 0x633e8 <g.3>
   59d9a:      	je	0x5b1a5 <f.7+0x22c5>
   59da0:      	movq	%rax, %r15
   59da3:      	shrq	$0x20, %rax
   59da7:      	jne	0x5b1a5 <f.7+0x22c5>
   59dad:      	movq	$0x16, 0x18(%rsp)
   59db6:      	movq	0x9553(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59dbd:      	testq	%rdi, %rdi
   59dc0:      	je	0x5b1a5 <f.7+0x22c5>
   59dc6:      	movq	0x178(%rdi), %rcx
   59dcd:      	testq	%rcx, %rcx
   59dd0:      	je	0x59e0f <f.7+0xf2f>
   59dd2:      	movq	0x170(%rdi), %rax
   59dd9:      	incq	%rax
   59ddc:      	movq	%rax, 0x170(%rdi)
   59de3:      	movq	%rax, %rdx
   59de6:      	orq	%rcx, %rdx
   59de9:      	shrq	$0x20, %rdx
   59ded:      	je	0x5ae90 <f.7+0x1fb0>
   59df3:      	xorl	%edx, %edx
   59df5:      	divq	%rcx
   59df8:      	testq	%rdx, %rdx
   59dfb:      	jne	0x59e0f <f.7+0xf2f>
   59dfd:      	movq	0x9514(%rip), %rsi      # 0x63318 <native_roots.0>
   59e04:      	movq	%rdi, %r14
   59e07:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59e0c:      	movq	%r14, %rdi
   59e0f:      	movq	0x9502(%rip), %rdx      # 0x63318 <native_roots.0>
   59e16:      	movl	$0x18, %esi
   59e1b:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59e20:      	testq	%rax, %rax
   59e23:      	je	0x5b1aa <f.7+0x22ca>
   59e29:      	movq	%rax, %r14
   59e2c:      	movq	$0x66, (%rax)
   59e33:      	movl	$0x0, 0x8(%rax)
   59e3a:      	movq	$0x0, 0x10(%rax)
   59e42:      	movq	%rax, 0x38(%rsp)
   59e47:      	movq	0xa8(%rsp), %rax
   59e4f:      	testq	%rax, %rax
   59e52:      	je	0x5b1a5 <f.7+0x22c5>
   59e58:      	movq	0x8(%rax), %rbp
   59e5c:      	movq	%rbp, 0xd0(%rsp)
   59e64:      	leaq	0x71fd(%rip), %rbx      # 0x61068 <ref.13>
   59e6b:      	movq	%rbx, 0xd8(%rsp)
   59e73:      	movq	%r14, 0xe0(%rsp)
   59e7b:      	movq	$0x19, 0x18(%rsp)
   59e84:      	movl	%r15d, %edi
   59e87:      	callq	0x58e20 <native_array_new>
   59e8c:      	movq	%rax, 0xd0(%rsp)
   59e94:      	movq	%rbp, 0xd8(%rsp)
   59e9c:      	movq	%rbx, 0xe0(%rsp)
   59ea4:      	movq	%r14, 0xe8(%rsp)
   59eac:      	movq	$0x1a, 0x18(%rsp)
   59eb5:      	movq	0x9454(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59ebc:      	testq	%rdi, %rdi
   59ebf:      	je	0x5b1a5 <f.7+0x22c5>
   59ec5:      	movq	%rax, %r13
   59ec8:      	movq	0x178(%rdi), %rcx
   59ecf:      	testq	%rcx, %rcx
   59ed2:      	je	0x59f11 <f.7+0x1031>
   59ed4:      	movq	0x170(%rdi), %rax
   59edb:      	incq	%rax
   59ede:      	movq	%rax, 0x170(%rdi)
   59ee5:      	movq	%rax, %rdx
   59ee8:      	orq	%rcx, %rdx
   59eeb:      	shrq	$0x20, %rdx
   59eef:      	je	0x5aeb0 <f.7+0x1fd0>
   59ef5:      	xorl	%edx, %edx
   59ef7:      	divq	%rcx
   59efa:      	testq	%rdx, %rdx
   59efd:      	jne	0x59f11 <f.7+0x1031>
   59eff:      	movq	0x9412(%rip), %rsi      # 0x63318 <native_roots.0>
   59f06:      	movq	%rdi, %r12
   59f09:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59f0e:      	movq	%r12, %rdi
   59f11:      	movq	0x9400(%rip), %rdx      # 0x63318 <native_roots.0>
   59f18:      	movl	$0x10, %esi
   59f1d:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59f22:      	testq	%rax, %rax
   59f25:      	je	0x5b1aa <f.7+0x22ca>
   59f2b:      	movq	%rax, %r12
   59f2e:      	movq	$0x82, (%rax)
   59f35:      	movq	%r13, 0x8(%rax)
   59f39:      	movq	0x38(%rsp), %rbx
   59f3e:      	movq	%rbx, 0xd0(%rsp)
   59f46:      	movq	%rax, 0xd8(%rsp)
   59f4e:      	movq	%rbp, 0xe0(%rsp)
   59f56:      	leaq	0x710b(%rip), %rax      # 0x61068 <ref.13>
   59f5d:      	movq	%rax, 0xe8(%rsp)
   59f65:      	movq	%r14, 0xf0(%rsp)
   59f6d:      	movq	$0x1b, 0x18(%rsp)
   59f76:      	movq	0x9393(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59f7d:      	testq	%rdi, %rdi
   59f80:      	je	0x5b1a5 <f.7+0x22c5>
   59f86:      	movq	0x178(%rdi), %rcx
   59f8d:      	testq	%rcx, %rcx
   59f90:      	je	0x59fcf <f.7+0x10ef>
   59f92:      	movq	0x170(%rdi), %rax
   59f99:      	incq	%rax
   59f9c:      	movq	%rax, 0x170(%rdi)
   59fa3:      	movq	%rax, %rdx
   59fa6:      	orq	%rcx, %rdx
   59fa9:      	shrq	$0x20, %rdx
   59fad:      	je	0x5aed0 <f.7+0x1ff0>
   59fb3:      	xorl	%edx, %edx
   59fb5:      	divq	%rcx
   59fb8:      	testq	%rdx, %rdx
   59fbb:      	jne	0x59fcf <f.7+0x10ef>
   59fbd:      	movq	0x9354(%rip), %rsi      # 0x63318 <native_roots.0>
   59fc4:      	movq	%rdi, %r13
   59fc7:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59fcc:      	movq	%r13, %rdi
   59fcf:      	movq	0x9342(%rip), %rdx      # 0x63318 <native_roots.0>
   59fd6:      	movl	$0x28, %esi
   59fdb:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59fe0:      	testq	%rax, %rax
   59fe3:      	je	0x5b1aa <f.7+0x22ca>
   59fe9:      	movq	%rax, %r13
   59fec:      	movq	$0x2a, (%rax)
   59ff3:      	movq	%rbp, 0x8(%rax)
   59ff7:      	movq	%r15, 0x10(%rax)
   59ffb:      	movq	%r12, 0x18(%rax)
   59fff:      	movq	%rbx, 0x20(%rax)
   5a003:      	movq	%rax, 0xd0(%rsp)
   5a00b:      	leaq	0x7056(%rip), %rax      # 0x61068 <ref.13>
   5a012:      	movq	%rax, 0xd8(%rsp)
   5a01a:      	movq	%r14, 0xe0(%rsp)
   5a022:      	movq	$0x19, 0x18(%rsp)
   5a02b:      	movq	0x92de(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a032:      	testq	%rdi, %rdi
   5a035:      	je	0x5b1a5 <f.7+0x22c5>
   5a03b:      	movq	0x178(%rdi), %rcx
   5a042:      	testq	%rcx, %rcx
   5a045:      	je	0x5a084 <f.7+0x11a4>
   5a047:      	movq	0x170(%rdi), %rax
   5a04e:      	incq	%rax
   5a051:      	movq	%rax, 0x170(%rdi)
   5a058:      	movq	%rax, %rdx
   5a05b:      	orq	%rcx, %rdx
   5a05e:      	shrq	$0x20, %rdx
   5a062:      	je	0x5aef0 <f.7+0x2010>
   5a068:      	xorl	%edx, %edx
   5a06a:      	divq	%rcx
   5a06d:      	testq	%rdx, %rdx
   5a070:      	jne	0x5a084 <f.7+0x11a4>
   5a072:      	movq	0x929f(%rip), %rsi      # 0x63318 <native_roots.0>
   5a079:      	movq	%rdi, %r15
   5a07c:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a081:      	movq	%r15, %rdi
   5a084:      	movq	0x928d(%rip), %rdx      # 0x63318 <native_roots.0>
   5a08b:      	movl	$0x18, %esi
   5a090:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a095:      	testq	%rax, %rax
   5a098:      	je	0x5b1aa <f.7+0x22ca>
   5a09e:      	movq	$0xc2, (%rax)
   5a0a5:      	leaq	0x6fbc(%rip), %rcx      # 0x61068 <ref.13>
   5a0ac:      	movq	%rcx, 0x8(%rax)
   5a0b0:      	movq	%r13, 0x10(%rax)
   5a0b4:      	movq	%rax, 0x10(%r14)
   5a0b8:      	movq	0x38(%rsp), %rax
   5a0bd:      	testq	%rax, %rax
   5a0c0:      	je	0x5b1a5 <f.7+0x22c5>
   5a0c6:      	movl	$0x1, 0x8(%rax)
   5a0cd:      	movq	0x38(%rsp), %rax
   5a0d2:      	testq	%rax, %rax
   5a0d5:      	leaq	0x6fac(%rip), %r13      # 0x61088 <ref.16>
   5a0dc:      	je	0x5b1a5 <f.7+0x22c5>
   5a0e2:      	cmpl	$0x0, 0x8(%rax)
   5a0e6:      	je	0x5b1a5 <f.7+0x22c5>
   5a0ec:      	movq	0x10(%rax), %rax
   5a0f0:      	testq	%rax, %rax
   5a0f3:      	je	0x5b1a5 <f.7+0x22c5>
   5a0f9:      	movq	%rax, 0xb8(%rsp)
   5a101:      	movq	0x8(%rax), %rcx
   5a105:      	testq	%rcx, %rcx
   5a108:      	je	0x5b1a5 <f.7+0x22c5>
   5a10e:      	movq	0x10(%rax), %rdi
   5a112:      	movq	0x8(%rcx), %rax
   5a116:      	movq	%rdi, 0xd0(%rsp)
   5a11e:      	movq	$0x17, 0x18(%rsp)
   5a127:      	xorl	%esi, %esi
   5a129:      	callq	*%rax
   5a12b:      	subq	$0x8, %rsp
   5a12f:      	movq	%rax, 0x98(%rsp)
   5a137:      	cmpb	$0x0, 0x92c2(%rip)      # 0x63400 <g.6>
   5a13e:      	je	0x5b1a5 <f.7+0x22c5>
   5a144:      	cmpq	$0x0, 0x92ac(%rip)      # 0x633f8 <g.5>
   5a14c:      	je	0x5b1a5 <f.7+0x22c5>
   5a152:      	cmpb	$0x0, 0x92b7(%rip)      # 0x63410 <g.8>
   5a159:      	je	0x5b1a5 <f.7+0x22c5>
   5a15f:      	cmpq	$0x0, 0x92a1(%rip)      # 0x63408 <g.7>
   5a167:      	je	0x5b1a5 <f.7+0x22c5>
   5a16d:      	testq	%rax, %rax
   5a170:      	je	0x5b1a5 <f.7+0x22c5>
   5a176:      	movq	0x8(%rax), %rcx
   5a17a:      	testq	%rcx, %rcx
   5a17d:      	je	0x5b1a5 <f.7+0x22c5>
   5a183:      	testb	$0x1, %cl
   5a186:      	jne	0x5b1a5 <f.7+0x22c5>
   5a18c:      	movl	0x8(%rcx), %esi
   5a18f:      	movq	%rax, 0xd0(%rsp)
   5a197:      	movq	$0x17, 0x18(%rsp)
   5a1a0:      	movq	%rax, %rdi
   5a1a3:      	callq	0x5b1c0 <f.5>
   5a1a8:      	subq	$0x8, %rsp
   5a1ac:      	movq	%rax, 0x48(%rsp)
   5a1b1:      	movq	%rax, 0xd0(%rsp)
   5a1b9:      	movq	$0x17, 0x18(%rsp)
   5a1c2:      	movq	0x9147(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a1c9:      	testq	%rdi, %rdi
   5a1cc:      	je	0x5b1a5 <f.7+0x22c5>
   5a1d2:      	movq	%rax, %r15
   5a1d5:      	movq	0x178(%rdi), %rcx
   5a1dc:      	testq	%rcx, %rcx
   5a1df:      	je	0x5a21e <f.7+0x133e>
   5a1e1:      	movq	0x170(%rdi), %rax
   5a1e8:      	incq	%rax
   5a1eb:      	movq	%rax, 0x170(%rdi)
   5a1f2:      	movq	%rax, %rdx
   5a1f5:      	orq	%rcx, %rdx
   5a1f8:      	shrq	$0x20, %rdx
   5a1fc:      	je	0x5af10 <f.7+0x2030>
   5a202:      	xorl	%edx, %edx
   5a204:      	divq	%rcx
   5a207:      	testq	%rdx, %rdx
   5a20a:      	jne	0x5a21e <f.7+0x133e>
   5a20c:      	movq	0x9105(%rip), %rsi      # 0x63318 <native_roots.0>
   5a213:      	movq	%rdi, %r14
   5a216:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a21b:      	movq	%r14, %rdi
   5a21e:      	movq	0x90f3(%rip), %rdx      # 0x63318 <native_roots.0>
   5a225:      	movl	$0x10, %esi
   5a22a:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a22f:      	testq	%rax, %rax
   5a232:      	je	0x5b1aa <f.7+0x22ca>
   5a238:      	movq	%rax, %r14
   5a23b:      	movq	$0x22, (%rax)
   5a242:      	movq	%r15, 0x8(%rax)
   5a246:      	movq	0x48(%rsp), %rdi
   5a24b:      	testq	%rdi, %rdi
   5a24e:      	je	0x5b1a5 <f.7+0x22c5>
   5a254:      	movl	0x8(%rdi), %r15d
   5a258:      	movq	%r14, 0xd0(%rsp)
   5a260:      	movq	%rdi, 0xd8(%rsp)
   5a268:      	movq	$0x18, 0x18(%rsp)
   5a271:      	xorl	%esi, %esi
   5a273:      	callq	0x5b4e0 <f.4>
   5a278:      	subq	$0x8, %rsp
   5a27c:      	movl	%eax, %ebp
   5a27e:      	movq	0x48(%rsp), %rdi
   5a283:      	movq	%r14, 0xd0(%rsp)
   5a28b:      	movq	%rdi, 0xd8(%rsp)
   5a293:      	movq	$0x18, 0x18(%rsp)
   5a29c:      	movl	%r15d, %esi
   5a29f:      	callq	0x5b4e0 <f.4>
   5a2a4:      	subq	$0x8, %rsp
   5a2a8:      	movl	%eax, %r15d
   5a2ab:      	subl	%ebp, %r15d
   5a2ae:      	movq	%r14, 0xd0(%rsp)
   5a2b6:      	movq	$0x17, 0x18(%rsp)
   5a2bf:      	movl	%r15d, %edi
   5a2c2:      	callq	0x58e20 <native_array_new>
   5a2c7:      	movq	%rax, 0xc0(%rsp)
   5a2cf:      	movq	0x48(%rsp), %rcx
   5a2d4:      	testq	%rcx, %rcx
   5a2d7:      	je	0x5b1a5 <f.7+0x22c5>
   5a2dd:      	testb	$0x1, %al
   5a2df:      	jne	0x5b1a5 <f.7+0x22c5>
   5a2e5:      	movq	0x18(%rcx), %rcx
   5a2e9:      	testq	%rcx, %rcx
   5a2ec:      	je	0x5b1a5 <f.7+0x22c5>
   5a2f2:      	movl	%ecx, %edx
   5a2f4:      	andl	$0x1, %edx
   5a2f7:      	jne	0x5b1a5 <f.7+0x22c5>
   5a2fd:      	movl	%r15d, %edx
   5a300:      	cmpq	%rdx, 0x8(%rax)
   5a304:      	jb	0x5b1a5 <f.7+0x22c5>
   5a30a:      	movl	%ebp, %esi
   5a30c:      	leaq	(%rdx,%rsi), %rdi
   5a310:      	cmpq	0x8(%rcx), %rdi
   5a314:      	ja	0x5b1a5 <f.7+0x22c5>
   5a31a:      	addq	%rcx, %rsi
   5a31d:      	addq	$0x10, %rsi
   5a321:      	addq	$0x10, %rax
   5a325:      	movq	%rax, %rdi
   5a328:      	callq	*0x750a(%rip)           # 0x61838 <writev+0x61838>
   5a32e:      	movq	0xc0(%rsp), %rbx
   5a336:      	movq	%rbx, 0xd0(%rsp)
   5a33e:      	movq	%r14, 0xd8(%rsp)
   5a346:      	movq	$0x18, 0x18(%rsp)
   5a34f:      	movq	0x8fba(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a356:      	testq	%rdi, %rdi
   5a359:      	je	0x5b1a5 <f.7+0x22c5>
   5a35f:      	movq	0x178(%rdi), %rcx
   5a366:      	testq	%rcx, %rcx
   5a369:      	leaq	0x6cd8(%rip), %rbp      # 0x61048 <ref.10>
   5a370:      	je	0x5a3af <f.7+0x14cf>
   5a372:      	movq	0x170(%rdi), %rax
   5a379:      	incq	%rax
   5a37c:      	movq	%rax, 0x170(%rdi)
   5a383:      	movq	%rax, %rdx
   5a386:      	orq	%rcx, %rdx
   5a389:      	shrq	$0x20, %rdx
   5a38d:      	je	0x5af30 <f.7+0x2050>
   5a393:      	xorl	%edx, %edx
   5a395:      	divq	%rcx
   5a398:      	testq	%rdx, %rdx
   5a39b:      	jne	0x5a3af <f.7+0x14cf>
   5a39d:      	movq	0x8f74(%rip), %rsi      # 0x63318 <native_roots.0>
   5a3a4:      	movq	%rdi, %r15
   5a3a7:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a3ac:      	movq	%r15, %rdi
   5a3af:      	movq	0x8f62(%rip), %rdx      # 0x63318 <native_roots.0>
   5a3b6:      	movl	$0x10, %esi
   5a3bb:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a3c0:      	testq	%rax, %rax
   5a3c3:      	je	0x5b1aa <f.7+0x22ca>
   5a3c9:      	movq	$0x82, (%rax)
   5a3d0:      	movq	%rbx, 0x8(%rax)
   5a3d4:      	movq	%rax, 0xa0(%rsp)
   5a3dc:      	movq	0x8(%rax), %rcx
   5a3e0:      	testq	%rcx, %rcx
   5a3e3:      	je	0x5b1a5 <f.7+0x22c5>
   5a3e9:      	testb	$0x1, %cl
   5a3ec:      	jne	0x5b1a5 <f.7+0x22c5>
   5a3f2:      	movl	0x8(%rcx), %esi
   5a3f5:      	movq	%r14, 0xd0(%rsp)
   5a3fd:      	movq	%rax, 0xd8(%rsp)
   5a405:      	movq	$0x18, 0x18(%rsp)
   5a40e:      	movq	%rax, %rdi
   5a411:      	callq	0x5b1c0 <f.5>
   5a416:      	subq	$0x8, %rsp
   5a41a:      	movq	%r14, 0xd0(%rsp)
   5a422:      	movq	%rax, 0xd8(%rsp)
   5a42a:      	movq	$0x18, 0x18(%rsp)
   5a433:      	movq	%r14, %rdi
   5a436:      	movq	%rax, %rsi
   5a439:      	callq	0x5b5e0 <f.11>
   5a43e:      	subq	$0x8, %rsp
   5a442:      	movq	$0x16, 0x18(%rsp)
   5a44b:      	movq	0x8ebe(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a452:      	testq	%rdi, %rdi
   5a455:      	je	0x5b1a5 <f.7+0x22c5>
   5a45b:      	movq	0x178(%rdi), %rcx
   5a462:      	testq	%rcx, %rcx
   5a465:      	je	0x5a4a4 <f.7+0x15c4>
   5a467:      	movq	0x170(%rdi), %rax
   5a46e:      	incq	%rax
   5a471:      	movq	%rax, 0x170(%rdi)
   5a478:      	movq	%rax, %rdx
   5a47b:      	orq	%rcx, %rdx
   5a47e:      	shrq	$0x20, %rdx
   5a482:      	je	0x5af50 <f.7+0x2070>
   5a488:      	xorl	%edx, %edx
   5a48a:      	divq	%rcx
   5a48d:      	testq	%rdx, %rdx
   5a490:      	jne	0x5a4a4 <f.7+0x15c4>
   5a492:      	movq	0x8e7f(%rip), %rsi      # 0x63318 <native_roots.0>
   5a499:      	movq	%rdi, %r14
   5a49c:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a4a1:      	movq	%r14, %rdi
   5a4a4:      	movq	0x8e6d(%rip), %rdx      # 0x63318 <native_roots.0>
   5a4ab:      	movl	$0x18, %esi
   5a4b0:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a4b5:      	testq	%rax, %rax
   5a4b8:      	je	0x5b1aa <f.7+0x22ca>
   5a4be:      	movq	%rax, %r14
   5a4c1:      	movq	$0x62, (%rax)
   5a4c8:      	movl	$0x0, 0x8(%rax)
   5a4cf:      	movq	$0x0, 0x10(%rax)
   5a4d7:      	movq	%rax, 0x50(%rsp)
   5a4dc:      	movq	0x40(%rsp), %rbx
   5a4e1:      	movq	%rax, 0xd0(%rsp)
   5a4e9:      	movq	%rbx, 0xd8(%rsp)
   5a4f1:      	movq	%rbp, 0xe0(%rsp)
   5a4f9:      	movq	%rax, 0xe8(%rsp)
   5a501:      	movq	$0x1a, 0x18(%rsp)
   5a50a:      	movq	0x8dff(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a511:      	testq	%rdi, %rdi
   5a514:      	je	0x5b1a5 <f.7+0x22c5>
   5a51a:      	movq	0x178(%rdi), %rcx
   5a521:      	testq	%rcx, %rcx
   5a524:      	je	0x5a563 <f.7+0x1683>
   5a526:      	movq	0x170(%rdi), %rax
   5a52d:      	incq	%rax
   5a530:      	movq	%rax, 0x170(%rdi)
   5a537:      	movq	%rax, %rdx
   5a53a:      	orq	%rcx, %rdx
   5a53d:      	shrq	$0x20, %rdx
   5a541:      	je	0x5af70 <f.7+0x2090>
   5a547:      	xorl	%edx, %edx
   5a549:      	divq	%rcx
   5a54c:      	testq	%rdx, %rdx
   5a54f:      	jne	0x5a563 <f.7+0x1683>
   5a551:      	movq	0x8dc0(%rip), %rsi      # 0x63318 <native_roots.0>
   5a558:      	movq	%rdi, %r15
   5a55b:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a560:      	movq	%r15, %rdi
   5a563:      	movq	0x8dae(%rip), %rdx      # 0x63318 <native_roots.0>
   5a56a:      	movl	$0x28, %esi
   5a56f:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a574:      	testq	%rax, %rax
   5a577:      	je	0x5b1aa <f.7+0x22ca>
   5a57d:      	movq	%rax, %r15
   5a580:      	movq	$0x1e, (%rax)
   5a587:      	movq	0x110(%rsp), %rax
   5a58f:      	movq	%rax, 0x8(%r15)
   5a593:      	movq	0x108(%rsp), %rax
   5a59b:      	movq	%rax, 0x10(%r15)
   5a59f:      	movq	%rbx, 0x18(%r15)
   5a5a3:      	movq	%r14, 0x20(%r15)
   5a5a7:      	movq	%r15, 0xd0(%rsp)
   5a5af:      	movq	%rbp, 0xd8(%rsp)
   5a5b7:      	movq	%r14, 0xe0(%rsp)
   5a5bf:      	movq	$0x19, 0x18(%rsp)
   5a5c8:      	movq	0x8d41(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a5cf:      	testq	%rdi, %rdi
   5a5d2:      	je	0x5b1a5 <f.7+0x22c5>
   5a5d8:      	movq	0x178(%rdi), %rcx
   5a5df:      	testq	%rcx, %rcx
   5a5e2:      	movq	0x100(%rsp), %rbx
   5a5ea:      	je	0x5a629 <f.7+0x1749>
   5a5ec:      	movq	0x170(%rdi), %rax
   5a5f3:      	incq	%rax
   5a5f6:      	movq	%rax, 0x170(%rdi)
   5a5fd:      	movq	%rax, %rdx
   5a600:      	orq	%rcx, %rdx
   5a603:      	shrq	$0x20, %rdx
   5a607:      	je	0x5af90 <f.7+0x20b0>
   5a60d:      	xorl	%edx, %edx
   5a60f:      	divq	%rcx
   5a612:      	testq	%rdx, %rdx
   5a615:      	jne	0x5a629 <f.7+0x1749>
   5a617:      	movq	0x8cfa(%rip), %rsi      # 0x63318 <native_roots.0>
   5a61e:      	movq	%rdi, %r12
   5a621:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a626:      	movq	%r12, %rdi
   5a629:      	movq	0x8ce8(%rip), %rdx      # 0x63318 <native_roots.0>
   5a630:      	movl	$0x18, %esi
   5a635:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a63a:      	testq	%rax, %rax
   5a63d:      	je	0x5b1aa <f.7+0x22ca>
   5a643:      	movq	$0x42, (%rax)
   5a64a:      	movq	%rbp, 0x8(%rax)
   5a64e:      	movq	%r15, 0x10(%rax)
   5a652:      	movq	%rax, 0x10(%r14)
   5a656:      	movq	0x50(%rsp), %rax
   5a65b:      	testq	%rax, %rax
   5a65e:      	je	0x5b1a5 <f.7+0x22c5>
   5a664:      	movl	$0x1, 0x8(%rax)
   5a66b:      	movq	0x50(%rsp), %rax
   5a670:      	testq	%rax, %rax
   5a673:      	je	0x5b1a5 <f.7+0x22c5>
   5a679:      	cmpl	$0x0, 0x8(%rax)
   5a67d:      	je	0x5b1a5 <f.7+0x22c5>
   5a683:      	movq	0x10(%rax), %rax
   5a687:      	testq	%rax, %rax
   5a68a:      	je	0x5b1a5 <f.7+0x22c5>
   5a690:      	movq	%rax, 0xc8(%rsp)
   5a698:      	movq	0x8(%rax), %rcx
   5a69c:      	testq	%rcx, %rcx
   5a69f:      	je	0x5b1a5 <f.7+0x22c5>
   5a6a5:      	movq	0x10(%rax), %rdi
   5a6a9:      	movq	0x8(%rcx), %rax
   5a6ad:      	movq	%rdi, 0xd0(%rsp)
   5a6b5:      	movq	$0x17, 0x18(%rsp)
   5a6be:      	xorl	%esi, %esi
   5a6c0:      	callq	*%rax
   5a6c2:      	subq	$0x8, %rsp
   5a6c6:      	cmpb	$0x0, 0x8db3(%rip)      # 0x63480 <g.22>
   5a6cd:      	je	0x5b1a5 <f.7+0x22c5>
   5a6d3:      	movq	0x8d9e(%rip), %rax      # 0x63478 <g.21>
   5a6da:      	testq	%rax, %rax
   5a6dd:      	je	0x5b1a5 <f.7+0x22c5>
   5a6e3:      	movq	0x8(%rax), %rax
   5a6e7:      	movq	%rax, 0x28(%rsp)
   5a6ec:      	cmpb	$0x0, 0x8d2d(%rip)      # 0x63420 <g.10>
   5a6f3:      	je	0x5b1a5 <f.7+0x22c5>
   5a6f9:      	cmpq	$0x0, 0x8d17(%rip)      # 0x63418 <g.9>
   5a701:      	je	0x5b1a5 <f.7+0x22c5>
   5a707:      	movq	$0x16, 0x18(%rsp)
   5a710:      	movq	0x8bf9(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a717:      	testq	%rdi, %rdi
   5a71a:      	je	0x5b1a5 <f.7+0x22c5>
   5a720:      	movq	0x178(%rdi), %rcx
   5a727:      	testq	%rcx, %rcx
   5a72a:      	je	0x5a769 <f.7+0x1889>
   5a72c:      	movq	0x170(%rdi), %rax
   5a733:      	incq	%rax
   5a736:      	movq	%rax, 0x170(%rdi)
   5a73d:      	movq	%rax, %rdx
   5a740:      	orq	%rcx, %rdx
   5a743:      	shrq	$0x20, %rdx
   5a747:      	je	0x5afb0 <f.7+0x20d0>
   5a74d:      	xorl	%edx, %edx
   5a74f:      	divq	%rcx
   5a752:      	testq	%rdx, %rdx
   5a755:      	jne	0x5a769 <f.7+0x1889>
   5a757:      	movq	0x8bba(%rip), %rsi      # 0x63318 <native_roots.0>
   5a75e:      	movq	%rdi, %r14
   5a761:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a766:      	movq	%r14, %rdi
   5a769:      	movq	0x8ba8(%rip), %rdx      # 0x63318 <native_roots.0>
   5a770:      	movl	$0x18, %esi
   5a775:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a77a:      	testq	%rax, %rax
   5a77d:      	je	0x5b1aa <f.7+0x22ca>
   5a783:      	movq	%rax, %r14
   5a786:      	movq	$0x5e, (%rax)
   5a78d:      	movl	$0x0, 0x8(%rax)
   5a794:      	movq	$0x0, 0x10(%rax)
   5a79c:      	movq	%rax, 0x58(%rsp)
   5a7a1:      	movq	%rax, 0xd0(%rsp)
   5a7a9:      	movq	%rax, 0xd8(%rsp)
   5a7b1:      	movq	$0x18, 0x18(%rsp)
   5a7ba:      	movq	0x8b4f(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a7c1:      	testq	%rdi, %rdi
   5a7c4:      	je	0x5b1a5 <f.7+0x22c5>
   5a7ca:      	movq	0x178(%rdi), %rcx
   5a7d1:      	testq	%rcx, %rcx
   5a7d4:      	je	0x5a813 <f.7+0x1933>
   5a7d6:      	movq	0x170(%rdi), %rax
   5a7dd:      	incq	%rax
   5a7e0:      	movq	%rax, 0x170(%rdi)
   5a7e7:      	movq	%rax, %rdx
   5a7ea:      	orq	%rcx, %rdx
   5a7ed:      	shrq	$0x20, %rdx
   5a7f1:      	je	0x5afd0 <f.7+0x20f0>
   5a7f7:      	xorl	%edx, %edx
   5a7f9:      	divq	%rcx
   5a7fc:      	testq	%rdx, %rdx
   5a7ff:      	jne	0x5a813 <f.7+0x1933>
   5a801:      	movq	0x8b10(%rip), %rsi      # 0x63318 <native_roots.0>
   5a808:      	movq	%rdi, %r15
   5a80b:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a810:      	movq	%r15, %rdi
   5a813:      	movq	0x8afe(%rip), %rdx      # 0x63318 <native_roots.0>
   5a81a:      	movl	$0x10, %esi
   5a81f:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a824:      	testq	%rax, %rax
   5a827:      	je	0x5b1aa <f.7+0x22ca>
   5a82d:      	movq	%rax, %r15
   5a830:      	movq	$0x6a, (%rax)
   5a837:      	movq	%r14, 0x8(%rax)
   5a83b:      	movq	%rax, 0xd0(%rsp)
   5a843:      	movq	%r14, 0xd8(%rsp)
   5a84b:      	movq	$0x18, 0x18(%rsp)
   5a854:      	movq	0x8ab5(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5a85b:      	testq	%rdi, %rdi
   5a85e:      	je	0x5b1a5 <f.7+0x22c5>
   5a864:      	movq	0x178(%rdi), %rcx
   5a86b:      	testq	%rcx, %rcx
   5a86e:      	je	0x5a8ad <f.7+0x19cd>
   5a870:      	movq	0x170(%rdi), %rax
   5a877:      	incq	%rax
   5a87a:      	movq	%rax, 0x170(%rdi)
   5a881:      	movq	%rax, %rdx
   5a884:      	orq	%rcx, %rdx
   5a887:      	shrq	$0x20, %rdx
   5a88b:      	je	0x5aff0 <f.7+0x2110>
   5a891:      	xorl	%edx, %edx
   5a893:      	divq	%rcx
   5a896:      	testq	%rdx, %rdx
   5a899:      	jne	0x5a8ad <f.7+0x19cd>
   5a89b:      	movq	0x8a76(%rip), %rsi      # 0x63318 <native_roots.0>
   5a8a2:      	movq	%rdi, %r12
   5a8a5:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5a8aa:      	movq	%r12, %rdi
   5a8ad:      	movq	0x8a64(%rip), %rdx      # 0x63318 <native_roots.0>
   5a8b4:      	movl	$0x10, %esi
   5a8b9:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5a8be:      	testq	%rax, %rax
   5a8c1:      	je	0x5b1aa <f.7+0x22ca>
   5a8c7:      	movq	$0x16, (%rax)
   5a8ce:      	movq	%r15, 0x8(%rax)
   5a8d2:      	movq	%rax, 0x10(%r14)
   5a8d6:      	movq	0x58(%rsp), %rax
   5a8db:      	testq	%rax, %rax
   5a8de:      	je	0x5b1a5 <f.7+0x22c5>
   5a8e4:      	movl	$0x1, 0x8(%rax)
   5a8eb:      	movq	0x58(%rsp), %rax
   5a8f0:      	testq	%rax, %rax
   5a8f3:      	je	0x5b1a5 <f.7+0x22c5>
   5a8f9:      	cmpl	$0x0, 0x8(%rax)
   5a8fd:      	je	0x5b1a5 <f.7+0x22c5>
   5a903:      	movq	0x10(%rax), %rax
   5a907:      	testq	%rax, %rax
   5a90a:      	je	0x5b1a5 <f.7+0x22c5>
   5a910:      	movq	0x8(%rax), %rax
   5a914:      	movq	%rax, 0x30(%rsp)
   5a919:      	movq	0x28(%rsp), %rcx
   5a91e:      	testq	%rcx, %rcx
   5a921:      	je	0x5ac60 <f.7+0x1d80>
   5a927:      	movq	0x8(%rcx), %rcx
   5a92b:      	movq	%rcx, 0x28(%rsp)
   5a930:      	testq	%rax, %rax
   5a933:      	je	0x5b1a5 <f.7+0x22c5>
   5a939:      	movq	0x8(%rax), %rdx
   5a93d:      	testq	%rdx, %rdx
   5a940:      	je	0x5b1a5 <f.7+0x22c5>
   5a946:      	cmpl	$0x0, 0x8(%rdx)
   5a94a:      	je	0x5b1a5 <f.7+0x22c5>
   5a950:      	cmpq	$0x0, 0x10(%rdx)
   5a955:      	je	0x5b1a5 <f.7+0x22c5>
   5a95b:      	testq	%rcx, %rcx
   5a95e:      	je	0x5b010 <f.7+0x2130>
   5a964:      	movq	0x8(%rcx), %rcx
   5a968:      	movq	%rcx, 0x28(%rsp)
   5a96d:      	movq	0x8(%rax), %rdx
   5a971:      	testq	%rdx, %rdx
   5a974:      	je	0x5b1a5 <f.7+0x22c5>
   5a97a:      	cmpl	$0x0, 0x8(%rdx)
   5a97e:      	je	0x5b1a5 <f.7+0x22c5>
   5a984:      	cmpq	$0x0, 0x10(%rdx)
   5a989:      	je	0x5b1a5 <f.7+0x22c5>
   5a98f:      	testq	%rcx, %rcx
   5a992:      	je	0x5b017 <f.7+0x2137>
   5a998:      	movq	0x8(%rcx), %rcx
   5a99c:      	movq	%rcx, 0x28(%rsp)
   5a9a1:      	movq	0x8(%rax), %rdx
   5a9a5:      	testq	%rdx, %rdx
   5a9a8:      	je	0x5b1a5 <f.7+0x22c5>
   5a9ae:      	cmpl	$0x0, 0x8(%rdx)
   5a9b2:      	je	0x5b1a5 <f.7+0x22c5>
   5a9b8:      	cmpq	$0x0, 0x10(%rdx)
   5a9bd:      	je	0x5b1a5 <f.7+0x22c5>
   5a9c3:      	testq	%rcx, %rcx
   5a9c6:      	je	0x5b01e <f.7+0x213e>
   5a9cc:      	movq	0x8(%rcx), %rcx
   5a9d0:      	movq	%rcx, 0x28(%rsp)
   5a9d5:      	movq	0x8(%rax), %rdx
   5a9d9:      	testq	%rdx, %rdx
   5a9dc:      	je	0x5b1a5 <f.7+0x22c5>
   5a9e2:      	cmpl	$0x0, 0x8(%rdx)
   5a9e6:      	je	0x5b1a5 <f.7+0x22c5>
   5a9ec:      	cmpq	$0x0, 0x10(%rdx)
   5a9f1:      	je	0x5b1a5 <f.7+0x22c5>
   5a9f7:      	testq	%rcx, %rcx
   5a9fa:      	je	0x5b025 <f.7+0x2145>
   5aa00:      	movq	0x8(%rcx), %rcx
   5aa04:      	movq	%rcx, 0x28(%rsp)
   5aa09:      	movq	0x8(%rax), %rdx
   5aa0d:      	testq	%rdx, %rdx
   5aa10:      	je	0x5b1a5 <f.7+0x22c5>
   5aa16:      	cmpl	$0x0, 0x8(%rdx)
   5aa1a:      	je	0x5b1a5 <f.7+0x22c5>
   5aa20:      	cmpq	$0x0, 0x10(%rdx)
   5aa25:      	je	0x5b1a5 <f.7+0x22c5>
   5aa2b:      	testq	%rcx, %rcx
   5aa2e:      	je	0x5b02c <f.7+0x214c>
   5aa34:      	movq	0x8(%rcx), %rcx
   5aa38:      	movq	%rcx, 0x28(%rsp)
   5aa3d:      	movq	0x8(%rax), %rdx
   5aa41:      	testq	%rdx, %rdx
   5aa44:      	je	0x5b1a5 <f.7+0x22c5>
   5aa4a:      	cmpl	$0x0, 0x8(%rdx)
   5aa4e:      	je	0x5b1a5 <f.7+0x22c5>
   5aa54:      	cmpq	$0x0, 0x10(%rdx)
   5aa59:      	je	0x5b1a5 <f.7+0x22c5>
   5aa5f:      	testq	%rcx, %rcx
   5aa62:      	je	0x5b033 <f.7+0x2153>
   5aa68:      	movq	0x8(%rcx), %rcx
   5aa6c:      	movq	%rcx, 0x28(%rsp)
   5aa71:      	movq	0x8(%rax), %rdx
   5aa75:      	testq	%rdx, %rdx
   5aa78:      	je	0x5b1a5 <f.7+0x22c5>
   5aa7e:      	cmpl	$0x0, 0x8(%rdx)
   5aa82:      	je	0x5b1a5 <f.7+0x22c5>
   5aa88:      	cmpq	$0x0, 0x10(%rdx)
   5aa8d:      	je	0x5b1a5 <f.7+0x22c5>
   5aa93:      	testq	%rcx, %rcx
   5aa96:      	je	0x5b03a <f.7+0x215a>
   5aa9c:      	movq	0x8(%rcx), %rcx
   5aaa0:      	movq	%rcx, 0x28(%rsp)
   5aaa5:      	movq	0x8(%rax), %rdx
   5aaa9:      	testq	%rdx, %rdx
   5aaac:      	je	0x5b1a5 <f.7+0x22c5>
   5aab2:      	cmpl	$0x0, 0x8(%rdx)
   5aab6:      	je	0x5b1a5 <f.7+0x22c5>
   5aabc:      	cmpq	$0x0, 0x10(%rdx)
   5aac1:      	je	0x5b1a5 <f.7+0x22c5>
   5aac7:      	testq	%rcx, %rcx
   5aaca:      	je	0x5b041 <f.7+0x2161>
   5aad0:      	movq	0x8(%rcx), %rcx
   5aad4:      	movq	%rcx, 0x28(%rsp)
   5aad9:      	movq	0x8(%rax), %rdx
   5aadd:      	testq	%rdx, %rdx
   5aae0:      	je	0x5b1a5 <f.7+0x22c5>
   5aae6:      	cmpl	$0x0, 0x8(%rdx)
   5aaea:      	je	0x5b1a5 <f.7+0x22c5>
   5aaf0:      	cmpq	$0x0, 0x10(%rdx)
   5aaf5:      	je	0x5b1a5 <f.7+0x22c5>
   5aafb:      	testq	%rcx, %rcx
   5aafe:      	je	0x5b048 <f.7+0x2168>
   5ab04:      	movq	0x8(%rcx), %rcx
   5ab08:      	movq	%rcx, 0x28(%rsp)
   5ab0d:      	movq	0x8(%rax), %rdx
   5ab11:      	testq	%rdx, %rdx
   5ab14:      	je	0x5b1a5 <f.7+0x22c5>
   5ab1a:      	cmpl	$0x0, 0x8(%rdx)
   5ab1e:      	je	0x5b1a5 <f.7+0x22c5>
   5ab24:      	cmpq	$0x0, 0x10(%rdx)
   5ab29:      	je	0x5b1a5 <f.7+0x22c5>
   5ab2f:      	testq	%rcx, %rcx
   5ab32:      	je	0x5b04f <f.7+0x216f>
   5ab38:      	movq	0x8(%rcx), %rcx
   5ab3c:      	movq	%rcx, 0x28(%rsp)
   5ab41:      	movq	0x8(%rax), %rdx
   5ab45:      	testq	%rdx, %rdx
   5ab48:      	je	0x5b1a5 <f.7+0x22c5>
   5ab4e:      	cmpl	$0x0, 0x8(%rdx)
   5ab52:      	je	0x5b1a5 <f.7+0x22c5>
   5ab58:      	cmpq	$0x0, 0x10(%rdx)
   5ab5d:      	je	0x5b1a5 <f.7+0x22c5>
   5ab63:      	testq	%rcx, %rcx
   5ab66:      	je	0x5b056 <f.7+0x2176>
   5ab6c:      	movq	0x8(%rcx), %rcx
   5ab70:      	movq	%rcx, 0x28(%rsp)
   5ab75:      	movq	0x8(%rax), %rdx
   5ab79:      	testq	%rdx, %rdx
   5ab7c:      	je	0x5b1a5 <f.7+0x22c5>
   5ab82:      	cmpl	$0x0, 0x8(%rdx)
   5ab86:      	je	0x5b1a5 <f.7+0x22c5>
   5ab8c:      	cmpq	$0x0, 0x10(%rdx)
   5ab91:      	je	0x5b1a5 <f.7+0x22c5>
   5ab97:      	testq	%rcx, %rcx
   5ab9a:      	je	0x5b05d <f.7+0x217d>
   5aba0:      	movq	0x8(%rcx), %rcx
   5aba4:      	movq	%rcx, 0x28(%rsp)
   5aba9:      	movq	0x8(%rax), %rdx
   5abad:      	testq	%rdx, %rdx
   5abb0:      	je	0x5b1a5 <f.7+0x22c5>
   5abb6:      	cmpl	$0x0, 0x8(%rdx)
   5abba:      	je	0x5b1a5 <f.7+0x22c5>
   5abc0:      	cmpq	$0x0, 0x10(%rdx)
   5abc5:      	je	0x5b1a5 <f.7+0x22c5>
   5abcb:      	testq	%rcx, %rcx
   5abce:      	je	0x5b064 <f.7+0x2184>
   5abd4:      	movq	0x8(%rcx), %rcx
   5abd8:      	movq	%rcx, 0x28(%rsp)
   5abdd:      	movq	0x8(%rax), %rdx
   5abe1:      	testq	%rdx, %rdx
   5abe4:      	je	0x5b1a5 <f.7+0x22c5>
   5abea:      	cmpl	$0x0, 0x8(%rdx)
   5abee:      	je	0x5b1a5 <f.7+0x22c5>
   5abf4:      	cmpq	$0x0, 0x10(%rdx)
   5abf9:      	je	0x5b1a5 <f.7+0x22c5>
   5abff:      	movq	%rax, 0xd0(%rsp)
   5ac07:      	movq	%rcx, 0xd8(%rsp)
   5ac0f:      	movq	$0x18, 0x18(%rsp)
   5ac18:      	testq	%rcx, %rcx
   5ac1b:      	je	0x5b06b <f.7+0x218b>
   5ac21:      	movq	0x8(%rax), %rax
   5ac25:      	movl	$0xe, %edx
   5ac2a:      	nopw	(%rax,%rax)
   5ac30:      	testq	%rax, %rax
   5ac33:      	je	0x5b1a5 <f.7+0x22c5>
   5ac39:      	cmpl	$0x0, 0x8(%rax)
   5ac3d:      	je	0x5b1a5 <f.7+0x22c5>
   5ac43:      	cmpq	$0x0, 0x10(%rax)
   5ac48:      	je	0x5b1a5 <f.7+0x22c5>
   5ac4e:      	movq	0x8(%rcx), %rcx
   5ac52:      	incq	%rdx
   5ac55:      	testq	%rcx, %rcx
   5ac58:      	jne	0x5ac30 <f.7+0x1d50>
   5ac5a:      	jmp	0x5b070 <f.7+0x2190>
   5ac5f:      	nop
   5ac60:      	xorl	%edx, %edx
   5ac62:      	jmp	0x5b070 <f.7+0x2190>
   5ac67:      	nopw	(%rax,%rax)
   5ac70:      	xorl	%edx, %edx
   5ac72:      	divl	%ecx
   5ac74:      	testq	%rdx, %rdx
   5ac77:      	jne	0x590f5 <f.7+0x215>
   5ac7d:      	jmp	0x590e3 <f.7+0x203>
   5ac82:      	nopw	%cs:(%rax,%rax)
   5ac90:      	xorl	%edx, %edx
   5ac92:      	divl	%ecx
   5ac94:      	testq	%rdx, %rdx
   5ac97:      	jne	0x5919f <f.7+0x2bf>
   5ac9d:      	jmp	0x5918d <f.7+0x2ad>
   5aca2:      	nopw	%cs:(%rax,%rax)
   5acb0:      	xorl	%edx, %edx
   5acb2:      	divl	%ecx
   5acb4:      	testq	%rdx, %rdx
   5acb7:      	jne	0x59254 <f.7+0x374>
   5acbd:      	jmp	0x59242 <f.7+0x362>
   5acc2:      	nopw	%cs:(%rax,%rax)
   5acd0:      	xorl	%edx, %edx
   5acd2:      	divl	%ecx
   5acd4:      	testq	%rdx, %rdx
   5acd7:      	jne	0x5930e <f.7+0x42e>
   5acdd:      	jmp	0x592fc <f.7+0x41c>
   5ace2:      	nopw	%cs:(%rax,%rax)
   5acf0:      	xorl	%edx, %edx
   5acf2:      	divl	%ecx
   5acf4:      	testq	%rdx, %rdx
   5acf7:      	jne	0x593da <f.7+0x4fa>
   5acfd:      	jmp	0x593c8 <f.7+0x4e8>
   5ad02:      	nopw	%cs:(%rax,%rax)
   5ad10:      	xorl	%edx, %edx
   5ad12:      	divl	%ecx
   5ad14:      	testq	%rdx, %rdx
   5ad17:      	jne	0x5948e <f.7+0x5ae>
   5ad1d:      	jmp	0x5947c <f.7+0x59c>
   5ad22:      	nopw	%cs:(%rax,%rax)
   5ad30:      	xorl	%edx, %edx
   5ad32:      	divl	%ecx
   5ad34:      	testq	%rdx, %rdx
   5ad37:      	jne	0x59524 <f.7+0x644>
   5ad3d:      	jmp	0x59512 <f.7+0x632>
   5ad42:      	nopw	%cs:(%rax,%rax)
   5ad50:      	xorl	%edx, %edx
   5ad52:      	divl	%ecx
   5ad54:      	testq	%rdx, %rdx
   5ad57:      	jne	0x595f6 <f.7+0x716>
   5ad5d:      	jmp	0x595e4 <f.7+0x704>
   5ad62:      	nopw	%cs:(%rax,%rax)
   5ad70:      	xorl	%edx, %edx
   5ad72:      	divl	%ecx
   5ad74:      	testq	%rdx, %rdx
   5ad77:      	jne	0x59702 <f.7+0x822>
   5ad7d:      	jmp	0x596f0 <f.7+0x810>
   5ad82:      	nopw	%cs:(%rax,%rax)
   5ad90:      	xorl	%edx, %edx
   5ad92:      	divl	%ecx
   5ad94:      	testq	%rdx, %rdx
   5ad97:      	jne	0x597bc <f.7+0x8dc>
   5ad9d:      	jmp	0x597aa <f.7+0x8ca>
   5ada2:      	nopw	%cs:(%rax,%rax)
   5adb0:      	xorl	%edx, %edx
   5adb2:      	divl	%ecx
   5adb4:      	testq	%rdx, %rdx
   5adb7:      	jne	0x5985a <f.7+0x97a>
   5adbd:      	jmp	0x59848 <f.7+0x968>
   5adc2:      	nopw	%cs:(%rax,%rax)
   5add0:      	xorl	%edx, %edx
   5add2:      	divl	%ecx
   5add4:      	testq	%rdx, %rdx
   5add7:      	jne	0x5992e <f.7+0xa4e>
   5addd:      	jmp	0x5991c <f.7+0xa3c>
   5ade2:      	nopw	%cs:(%rax,%rax)
   5adf0:      	xorl	%edx, %edx
   5adf2:      	divl	%ecx
   5adf4:      	testq	%rdx, %rdx
   5adf7:      	jne	0x599db <f.7+0xafb>
   5adfd:      	jmp	0x599c9 <f.7+0xae9>
   5ae02:      	nopw	%cs:(%rax,%rax)
   5ae10:      	xorl	%edx, %edx
   5ae12:      	divl	%ecx
   5ae14:      	testq	%rdx, %rdx
   5ae17:      	jne	0x59a79 <f.7+0xb99>
   5ae1d:      	jmp	0x59a67 <f.7+0xb87>
   5ae22:      	nopw	%cs:(%rax,%rax)
   5ae30:      	xorl	%edx, %edx
   5ae32:      	divl	%ecx
   5ae34:      	testq	%rdx, %rdx
   5ae37:      	jne	0x59b13 <f.7+0xc33>
   5ae3d:      	jmp	0x59b01 <f.7+0xc21>
   5ae42:      	nopw	%cs:(%rax,%rax)
   5ae50:      	xorl	%edx, %edx
   5ae52:      	divl	%ecx
   5ae54:      	testq	%rdx, %rdx
   5ae57:      	jne	0x59bad <f.7+0xccd>
   5ae5d:      	jmp	0x59b9b <f.7+0xcbb>
   5ae62:      	nopw	%cs:(%rax,%rax)
   5ae70:      	xorl	%edx, %edx
   5ae72:      	divl	%ecx
   5ae74:      	testq	%rdx, %rdx
   5ae77:      	jne	0x59c43 <f.7+0xd63>
   5ae7d:      	jmp	0x59c31 <f.7+0xd51>
   5ae82:      	nopw	%cs:(%rax,%rax)
   5ae90:      	xorl	%edx, %edx
   5ae92:      	divl	%ecx
   5ae94:      	testq	%rdx, %rdx
   5ae97:      	jne	0x59e0f <f.7+0xf2f>
   5ae9d:      	jmp	0x59dfd <f.7+0xf1d>
   5aea2:      	nopw	%cs:(%rax,%rax)
   5aeb0:      	xorl	%edx, %edx
   5aeb2:      	divl	%ecx
   5aeb4:      	testq	%rdx, %rdx
   5aeb7:      	jne	0x59f11 <f.7+0x1031>
   5aebd:      	jmp	0x59eff <f.7+0x101f>
   5aec2:      	nopw	%cs:(%rax,%rax)
   5aed0:      	xorl	%edx, %edx
   5aed2:      	divl	%ecx
   5aed4:      	testq	%rdx, %rdx
   5aed7:      	jne	0x59fcf <f.7+0x10ef>
   5aedd:      	jmp	0x59fbd <f.7+0x10dd>
   5aee2:      	nopw	%cs:(%rax,%rax)
   5aef0:      	xorl	%edx, %edx
   5aef2:      	divl	%ecx
   5aef4:      	testq	%rdx, %rdx
   5aef7:      	jne	0x5a084 <f.7+0x11a4>
   5aefd:      	jmp	0x5a072 <f.7+0x1192>
   5af02:      	nopw	%cs:(%rax,%rax)
   5af10:      	xorl	%edx, %edx
   5af12:      	divl	%ecx
   5af14:      	testq	%rdx, %rdx
   5af17:      	jne	0x5a21e <f.7+0x133e>
   5af1d:      	jmp	0x5a20c <f.7+0x132c>
   5af22:      	nopw	%cs:(%rax,%rax)
   5af30:      	xorl	%edx, %edx
   5af32:      	divl	%ecx
   5af34:      	testq	%rdx, %rdx
   5af37:      	jne	0x5a3af <f.7+0x14cf>
   5af3d:      	jmp	0x5a39d <f.7+0x14bd>
   5af42:      	nopw	%cs:(%rax,%rax)
   5af50:      	xorl	%edx, %edx
   5af52:      	divl	%ecx
   5af54:      	testq	%rdx, %rdx
   5af57:      	jne	0x5a4a4 <f.7+0x15c4>
   5af5d:      	jmp	0x5a492 <f.7+0x15b2>
   5af62:      	nopw	%cs:(%rax,%rax)
   5af70:      	xorl	%edx, %edx
   5af72:      	divl	%ecx
   5af74:      	testq	%rdx, %rdx
   5af77:      	jne	0x5a563 <f.7+0x1683>
   5af7d:      	jmp	0x5a551 <f.7+0x1671>
   5af82:      	nopw	%cs:(%rax,%rax)
   5af90:      	xorl	%edx, %edx
   5af92:      	divl	%ecx
   5af94:      	testq	%rdx, %rdx
   5af97:      	jne	0x5a629 <f.7+0x1749>
   5af9d:      	jmp	0x5a617 <f.7+0x1737>
   5afa2:      	nopw	%cs:(%rax,%rax)
   5afb0:      	xorl	%edx, %edx
   5afb2:      	divl	%ecx
   5afb4:      	testq	%rdx, %rdx
   5afb7:      	jne	0x5a769 <f.7+0x1889>
   5afbd:      	jmp	0x5a757 <f.7+0x1877>
   5afc2:      	nopw	%cs:(%rax,%rax)
   5afd0:      	xorl	%edx, %edx
   5afd2:      	divl	%ecx
   5afd4:      	testq	%rdx, %rdx
   5afd7:      	jne	0x5a813 <f.7+0x1933>
   5afdd:      	jmp	0x5a801 <f.7+0x1921>
   5afe2:      	nopw	%cs:(%rax,%rax)
   5aff0:      	xorl	%edx, %edx
   5aff2:      	divl	%ecx
   5aff4:      	testq	%rdx, %rdx
   5aff7:      	jne	0x5a8ad <f.7+0x19cd>
   5affd:      	jmp	0x5a89b <f.7+0x19bb>
   5b002:      	nopw	%cs:(%rax,%rax)
   5b010:      	movl	$0x1, %edx
   5b015:      	jmp	0x5b070 <f.7+0x2190>
   5b017:      	movl	$0x2, %edx
   5b01c:      	jmp	0x5b070 <f.7+0x2190>
   5b01e:      	movl	$0x3, %edx
   5b023:      	jmp	0x5b070 <f.7+0x2190>
   5b025:      	movl	$0x4, %edx
   5b02a:      	jmp	0x5b070 <f.7+0x2190>
   5b02c:      	movl	$0x5, %edx
   5b031:      	jmp	0x5b070 <f.7+0x2190>
   5b033:      	movl	$0x6, %edx
   5b038:      	jmp	0x5b070 <f.7+0x2190>
   5b03a:      	movl	$0x7, %edx
   5b03f:      	jmp	0x5b070 <f.7+0x2190>
   5b041:      	movl	$0x8, %edx
   5b046:      	jmp	0x5b070 <f.7+0x2190>
   5b048:      	movl	$0x9, %edx
   5b04d:      	jmp	0x5b070 <f.7+0x2190>
   5b04f:      	movl	$0xa, %edx
   5b054:      	jmp	0x5b070 <f.7+0x2190>
   5b056:      	movl	$0xb, %edx
   5b05b:      	jmp	0x5b070 <f.7+0x2190>
   5b05d:      	movl	$0xc, %edx
   5b062:      	jmp	0x5b070 <f.7+0x2190>
   5b064:      	movl	$0xd, %edx
   5b069:      	jmp	0x5b070 <f.7+0x2190>
   5b06b:      	movl	$0xe, %edx
   5b070:      	movq	0x60(%rsp), %rdi
   5b075:      	testq	%rdi, %rdi
   5b078:      	je	0x5b1a5 <f.7+0x22c5>
   5b07e:      	movq	0x10(%rdi), %rax
   5b082:      	testq	%rax, %rax
   5b085:      	je	0x5b1a5 <f.7+0x22c5>
   5b08b:      	cmpl	$0x0, 0x8(%rax)
   5b08f:      	je	0x5b1a5 <f.7+0x22c5>
   5b095:      	cmpq	$0x0, 0x10(%rax)
   5b09a:      	je	0x5b1a5 <f.7+0x22c5>
   5b0a0:      	incq	%rbx
   5b0a3:      	xorl	%eax, %eax
   5b0a5:      	cmpq	$0x0, 0x10(%rsp)
   5b0ab:      	setne	%al
   5b0ae:      	movq	0x8243(%rip), %r8       # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b0b5:      	leaq	0x825c(%rip), %rcx      # 0x63318 <native_roots.0>
   5b0bc:      	leaq	0x8(%rsp), %r9
   5b0c1:      	cmovneq	%r9, %rcx
   5b0c5:      	movq	%r8, %rsi
   5b0c8:      	subq	%rax, %rsi
   5b0cb:      	movq	(%rcx), %rcx
   5b0ce:      	movq	$0x1b, 0x10(%rsp)
   5b0d7:      	movq	$0x0, 0x18(%rsp)
   5b0e0:      	movq	%rcx, 0x8(%rsp)
   5b0e5:      	movq	%r9, 0x822c(%rip)       # 0x63318 <native_roots.0>
   5b0ec:      	negq	%rax
   5b0ef:      	addq	%r8, %rax
   5b0f2:      	incq	%rax
   5b0f5:      	movq	%rax, 0x81fc(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b0fc:      	movq	0x81fd(%rip), %r8       # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b103:      	cmpq	%r8, %rax
   5b106:      	cmovaq	%rax, %r8
   5b10a:      	movq	%r8, 0x81ef(%rip)       # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b111:      	movq	%rdi, 0x20(%rsp)
   5b116:      	xorps	%xmm0, %xmm0
   5b119:      	leaq	0x28(%rsp), %rax
   5b11e:      	movups	%xmm0, 0x90(%rax)
   5b125:      	movups	%xmm0, 0x80(%rax)
   5b12c:      	movups	%xmm0, 0x70(%rax)
   5b130:      	movups	%xmm0, 0x60(%rax)
   5b134:      	movups	%xmm0, 0x50(%rax)
   5b138:      	movups	%xmm0, 0x40(%rax)
   5b13c:      	movups	%xmm0, 0x30(%rax)
   5b140:      	movups	%xmm0, 0x20(%rax)
   5b144:      	movups	%xmm0, 0x10(%rax)
   5b148:      	movups	%xmm0, (%rax)
   5b14b:      	movq	$0x0, 0xa0(%rax)
   5b156:      	movq	%rdi, 0x60(%rsp)
   5b15b:      	cmpq	%rbx, 0x8(%rdi)
   5b15f:      	jg	0x58fc0 <f.7+0xe0>
   5b165:      	testq	%rbx, %rbx
   5b168:      	jle	0x5b181 <f.7+0x22a1>
   5b16a:      	cmpb	$0x0, 0x835f(%rip)      # 0x634d0 <g.32>
   5b171:      	je	0x5b1a5 <f.7+0x22c5>
   5b173:      	xorl	%eax, %eax
   5b175:      	cmpq	%rdx, 0x834c(%rip)      # 0x634c8 <g.31>
   5b17c:      	sete	%al
   5b17f:      	jmp	0x5b183 <f.7+0x22a3>
   5b181:      	xorl	%eax, %eax
   5b183:      	movq	%rcx, 0x818e(%rip)      # 0x63318 <native_roots.0>
   5b18a:      	movq	%rsi, 0x8167(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b191:      	addq	$0x118, %rsp            # imm = 0x118
   5b198:      	popq	%rbx
   5b199:      	popq	%r12
   5b19b:      	popq	%r13
   5b19d:      	popq	%r14
   5b19f:      	popq	%r15
   5b1a1:      	popq	%rbp
   5b1a2:      	retq	$0x8
   5b1a5:      	callq	0x55770 <native_trap>
   5b1aa:      	leaq	-0x51e55(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5b1b1:      	movl	$0x2f, %esi
   5b1b6:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5b1bb:      	int3
   5b1bc:      	int3
   5b1bd:      	int3
   5b1be:      	int3
   5b1bf:      	int3

000000000005b1c0 <f.5>:
   5b1c0:      	pushq	%rbp
   5b1c1:      	pushq	%r15
   5b1c3:      	pushq	%r14
   5b1c5:      	pushq	%r13
   5b1c7:      	pushq	%r12
   5b1c9:      	pushq	%rbx
   5b1ca:      	subq	$0x48, %rsp
   5b1ce:      	movq	$0x4, 0x18(%rsp)
   5b1d7:      	movq	$0x0, 0x20(%rsp)
   5b1e0:      	movq	0x8131(%rip), %rax      # 0x63318 <native_roots.0>
   5b1e7:      	movq	%rax, 0x10(%rsp)
   5b1ec:      	movq	0x8105(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b1f3:      	incq	%rax
   5b1f6:      	movq	%rax, 0x80fb(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b1fd:      	movq	0x80fc(%rip), %rcx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b204:      	cmpq	%rcx, %rax
   5b207:      	cmovbeq	%rcx, %rax
   5b20b:      	leaq	0x10(%rsp), %rcx
   5b210:      	movq	%rcx, 0x8101(%rip)      # 0x63318 <native_roots.0>
   5b217:      	movq	%rax, 0x80e2(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b21e:      	movq	%rdi, 0x28(%rsp)
   5b223:      	xorps	%xmm0, %xmm0
   5b226:      	movups	%xmm0, 0x30(%rsp)
   5b22b:      	movq	0x8(%rdi), %rax
   5b22f:      	movq	%rax, 0x30(%rsp)
   5b234:      	testq	%rax, %rax
   5b237:      	je	0x5b4c4 <f.5+0x304>
   5b23d:      	testb	$0x1, %al
   5b23f:      	jne	0x5b4c4 <f.5+0x304>
   5b245:      	movq	%rsi, %rbx
   5b248:      	movl	0x8(%rax), %eax
   5b24b:      	cmpq	%rax, %rsi
   5b24e:      	ja	0x5b4c4 <f.5+0x304>
   5b254:      	xorl	%ebp, %ebp
   5b256:      	testq	%rbx, %rbx
   5b259:      	je	0x5b392 <f.5+0x1d2>
   5b25f:      	movl	$0x2, %r15d
   5b265:      	xorl	%r14d, %r14d
   5b268:      	jmp	0x5b27e <f.5+0xbe>
   5b26a:      	nopw	(%rax,%rax)
   5b270:      	addl	%r12d, %r14d
   5b273:      	incl	%ebp
   5b275:      	cmpl	%ebx, %r14d
   5b278:      	je	0x5b384 <f.5+0x1c4>
   5b27e:      	movq	0x30(%rsp), %rdi
   5b283:      	testq	%rdi, %rdi
   5b286:      	je	0x5b4c4 <f.5+0x304>
   5b28c:      	testb	$0x1, %dil
   5b290:      	jne	0x5b4c4 <f.5+0x304>
   5b296:      	movl	%r14d, %r14d
   5b299:      	movq	0x8(%rdi), %rax
   5b29d:      	cmpq	%r14, %rax
   5b2a0:      	jbe	0x5b4c4 <f.5+0x304>
   5b2a6:      	movzbl	0x10(%rdi,%r14), %r13d
   5b2ac:      	movl	$0x1, %r12d
   5b2b2:      	testb	%r13b, %r13b
   5b2b5:      	jns	0x5b270 <f.5+0xb0>
   5b2b7:      	leal	0xb(%r13), %ecx
   5b2bb:      	cmpb	$-0x34, %cl
   5b2be:      	jbe	0x5b4c4 <f.5+0x304>
   5b2c4:      	cmpb	$-0x10, %r13b
   5b2c8:      	movl	$0x4, %r12d
   5b2ce:      	sbbl	$0x0, %r12d
   5b2d2:      	cmpb	$-0x20, %r13b
   5b2d6:      	cmovbl	%r15d, %r12d
   5b2da:      	movl	%ebx, %ecx
   5b2dc:      	subl	%r14d, %ecx
   5b2df:      	cmpl	%ecx, %r12d
   5b2e2:      	ja	0x5b4c4 <f.5+0x304>
   5b2e8:      	movl	%r12d, %ecx
   5b2eb:      	movl	$0x1, %edx
   5b2f0:      	leal	(%r14,%rdx), %esi
   5b2f4:      	cmpq	%rsi, %rax
   5b2f7:      	jbe	0x5b4c4 <f.5+0x304>
   5b2fd:      	cmpb	$-0x40, 0x10(%rdi,%rsi)
   5b302:      	jge	0x5b4c4 <f.5+0x304>
   5b308:      	incq	%rdx
   5b30b:      	cmpq	%rdx, %rcx
   5b30e:      	jne	0x5b2f0 <f.5+0x130>
   5b310:      	movq	%rdi, 0x40(%rsp)
   5b315:      	movq	$0x4, 0x20(%rsp)
   5b31e:      	movl	%r14d, %esi
   5b321:      	callq	0x5cd00 <f.3>
   5b326:      	subq	$0x8, %rsp
   5b32a:      	cmpl	$0x80, %eax
   5b32f:      	jb	0x5b4c4 <f.5+0x304>
   5b335:      	xorl	%ecx, %ecx
   5b337:      	cmpb	$-0x20, %r13b
   5b33b:      	setb	%cl
   5b33e:      	cmpl	$0x10000, %eax          # imm = 0x10000
   5b343:      	movl	$0x4, %edx
   5b348:      	sbbl	$0x0, %edx
   5b34b:      	xorl	%esi, %esi
   5b34d:      	cmpl	%r12d, %edx
   5b350:      	sete	%sil
   5b354:      	cmpl	$0x800, %eax            # imm = 0x800
   5b359:      	cmovael	%esi, %ecx
   5b35c:      	testb	%cl, %cl
   5b35e:      	je	0x5b4c4 <f.5+0x304>
   5b364:      	cmpl	$0x10ffff, %eax         # imm = 0x10FFFF
   5b369:      	ja	0x5b4c4 <f.5+0x304>
   5b36f:      	andl	$0xfffff800, %eax       # imm = 0xFFFFF800
   5b374:      	cmpl	$0xd800, %eax           # imm = 0xD800
   5b379:      	jne	0x5b270 <f.5+0xb0>
   5b37f:      	jmp	0x5b4c4 <f.5+0x304>
   5b384:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
   5b389:      	cmpq	%rax, %rbx
   5b38c:      	je	0x5b4c4 <f.5+0x304>
   5b392:      	movq	$0x3, 0x20(%rsp)
   5b39b:      	movl	%ebx, %edi
   5b39d:      	callq	0x58e20 <native_array_new>
   5b3a2:      	movq	%rax, 0x38(%rsp)
   5b3a7:      	testb	$0x1, %al
   5b3a9:      	jne	0x5b4c4 <f.5+0x304>
   5b3af:      	movq	0x30(%rsp), %rsi
   5b3b4:      	testq	%rsi, %rsi
   5b3b7:      	je	0x5b4c4 <f.5+0x304>
   5b3bd:      	movl	%esi, %ecx
   5b3bf:      	andl	$0x1, %ecx
   5b3c2:      	jne	0x5b4c4 <f.5+0x304>
   5b3c8:      	cmpq	%rbx, 0x8(%rax)
   5b3cc:      	jb	0x5b4c4 <f.5+0x304>
   5b3d2:      	cmpq	0x8(%rsi), %rbx
   5b3d6:      	ja	0x5b4c4 <f.5+0x304>
   5b3dc:      	addq	$0x10, %rsi
   5b3e0:      	addq	$0x10, %rax
   5b3e4:      	movq	%rax, %rdi
   5b3e7:      	movq	%rbx, %rdx
   5b3ea:      	callq	*0x6448(%rip)           # 0x61838 <writev+0x61838>
   5b3f0:      	movq	0x38(%rsp), %r15
   5b3f5:      	movq	%r15, 0x40(%rsp)
   5b3fa:      	movq	$0x4, 0x20(%rsp)
   5b403:      	movq	0x7f06(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b40a:      	testq	%rdi, %rdi
   5b40d:      	je	0x5b4c4 <f.5+0x304>
   5b413:      	movq	0x178(%rdi), %rcx
   5b41a:      	testq	%rcx, %rcx
   5b41d:      	je	0x5b458 <f.5+0x298>
   5b41f:      	movq	0x170(%rdi), %rax
   5b426:      	incq	%rax
   5b429:      	movq	%rax, 0x170(%rdi)
   5b430:      	movq	%rax, %rdx
   5b433:      	orq	%rcx, %rdx
   5b436:      	shrq	$0x20, %rdx
   5b43a:      	je	0x5b4b9 <f.5+0x2f9>
   5b43c:      	xorl	%edx, %edx
   5b43e:      	divq	%rcx
   5b441:      	testq	%rdx, %rdx
   5b444:      	jne	0x5b458 <f.5+0x298>
   5b446:      	movq	0x7ecb(%rip), %rsi      # 0x63318 <native_roots.0>
   5b44d:      	movq	%rdi, %r14
   5b450:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b455:      	movq	%r14, %rdi
   5b458:      	movq	0x7eb9(%rip), %rdx      # 0x63318 <native_roots.0>
   5b45f:      	movl	$0x30, %esi
   5b464:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b469:      	testq	%rax, %rax
   5b46c:      	je	0x5b4c9 <f.5+0x309>
   5b46e:      	movq	$0xc6, (%rax)
   5b475:      	movl	%ebp, 0x8(%rax)
   5b478:      	movl	%ebx, 0x10(%rax)
   5b47b:      	movq	%r15, 0x18(%rax)
   5b47f:      	movl	$0x0, 0x20(%rax)
   5b486:      	movl	$0x0, 0x28(%rax)
   5b48d:      	cmpq	$0x0, 0x18(%rsp)
   5b493:      	je	0x5b4a8 <f.5+0x2e8>
   5b495:      	movq	0x10(%rsp), %rcx
   5b49a:      	movq	%rcx, 0x7e77(%rip)      # 0x63318 <native_roots.0>
   5b4a1:      	decq	0x7e50(%rip)            # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b4a8:      	addq	$0x48, %rsp
   5b4ac:      	popq	%rbx
   5b4ad:      	popq	%r12
   5b4af:      	popq	%r13
   5b4b1:      	popq	%r14
   5b4b3:      	popq	%r15
   5b4b5:      	popq	%rbp
   5b4b6:      	retq	$0x8
   5b4b9:      	xorl	%edx, %edx
   5b4bb:      	divl	%ecx
   5b4bd:      	testq	%rdx, %rdx
   5b4c0:      	jne	0x5b458 <f.5+0x298>
   5b4c2:      	jmp	0x5b446 <f.5+0x286>
   5b4c4:      	callq	0x55770 <native_trap>
   5b4c9:      	leaq	-0x52174(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5b4d0:      	movl	$0x2f, %esi
   5b4d5:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5b4da:      	int3
   5b4db:      	int3
   5b4dc:      	int3
   5b4dd:      	int3
   5b4de:      	int3
   5b4df:      	int3

000000000005b4e0 <f.4>:
   5b4e0:      	pushq	%rbx
   5b4e1:      	testq	%rdi, %rdi
   5b4e4:      	je	0x5b5d2 <f.4+0xf2>
   5b4ea:      	movl	0x8(%rdi), %edx
   5b4ed:      	movl	%edx, %ecx
   5b4ef:      	subl	%esi, %ecx
   5b4f1:      	jb	0x5b5d2 <f.4+0xf2>
   5b4f7:      	movl	0x10(%rdi), %r8d
   5b4fb:      	cmpl	%r8d, %edx
   5b4fe:      	je	0x5b5cc <f.4+0xec>
   5b504:      	movl	0x20(%rdi), %r9d
   5b508:      	movl	%esi, %eax
   5b50a:      	subl	%r9d, %eax
   5b50d:      	movl	%r9d, %r11d
   5b510:      	subl	%esi, %r11d
   5b513:      	cmovbl	%eax, %r11d
   5b517:      	xorl	%eax, %eax
   5b519:      	movl	$0x0, %r10d
   5b51f:      	cmpl	%r11d, %esi
   5b522:      	jb	0x5b52a <f.4+0x4a>
   5b524:      	movl	0x28(%rdi), %eax
   5b527:      	movl	%r9d, %r10d
   5b52a:      	movl	%esi, %r9d
   5b52d:      	subl	%r10d, %r9d
   5b530:      	movl	%r10d, %r11d
   5b533:      	subl	%esi, %r11d
   5b536:      	cmovbl	%r9d, %r11d
   5b53a:      	cmpl	%r11d, %ecx
   5b53d:      	cmovbl	%r8d, %eax
   5b541:      	cmovael	%r10d, %edx
   5b545:      	movq	0x18(%rdi), %rcx
   5b549:      	movl	%esi, %r8d
   5b54c:      	subl	%edx, %r8d
   5b54f:      	jbe	0x5b5a0 <f.4+0xc0>
   5b551:      	testq	%rcx, %rcx
   5b554:      	je	0x5b5d2 <f.4+0xf2>
   5b556:      	testb	$0x1, %cl
   5b559:      	jne	0x5b5d2 <f.4+0xf2>
   5b55b:      	movq	0x8(%rcx), %rdx
   5b55f:      	movl	$0x2, %r9d
   5b565:      	movl	$0x1, %r10d
   5b56b:      	nopl	(%rax,%rax)
   5b570:      	movl	%eax, %r11d
   5b573:      	cmpq	%r11, %rdx
   5b576:      	jbe	0x5b5d2 <f.4+0xf2>
   5b578:      	movzbl	0x10(%rcx,%r11), %ebx
   5b57e:      	cmpb	$-0x10, %bl
   5b581:      	movl	$0x4, %eax
   5b586:      	sbbl	$0x0, %eax
   5b589:      	cmpb	$-0x20, %bl
   5b58c:      	cmovbl	%r9d, %eax
   5b590:      	testb	%bl, %bl
   5b592:      	cmovnsl	%r10d, %eax
   5b596:      	addl	%r11d, %eax
   5b599:      	decl	%r8d
   5b59c:      	jne	0x5b570 <f.4+0x90>
   5b59e:      	jmp	0x5b5c4 <f.4+0xe4>
   5b5a0:      	jae	0x5b5c4 <f.4+0xe4>
   5b5a2:      	testq	%rcx, %rcx
   5b5a5:      	je	0x5b5d2 <f.4+0xf2>
   5b5a7:      	testb	$0x1, %cl
   5b5aa:      	jne	0x5b5d2 <f.4+0xf2>
   5b5ac:      	movq	0x8(%rcx), %r8
   5b5b0:      	decl	%eax
   5b5b2:      	cmpq	%rax, %r8
   5b5b5:      	jbe	0x5b5d2 <f.4+0xf2>
   5b5b7:      	cmpb	$-0x40, 0x10(%rcx,%rax)
   5b5bc:      	jl	0x5b5b0 <f.4+0xd0>
   5b5be:      	decl	%edx
   5b5c0:      	cmpl	%edx, %esi
   5b5c2:      	jb	0x5b5b0 <f.4+0xd0>
   5b5c4:      	movl	%esi, 0x20(%rdi)
   5b5c7:      	movl	%eax, 0x28(%rdi)
   5b5ca:      	movl	%eax, %esi
   5b5cc:      	movl	%esi, %eax
   5b5ce:      	popq	%rbx
   5b5cf:      	retq	$0x8
   5b5d2:      	callq	0x55770 <native_trap>
   5b5d7:      	int3
   5b5d8:      	int3
   5b5d9:      	int3
   5b5da:      	int3
   5b5db:      	int3
   5b5dc:      	int3
   5b5dd:      	int3
   5b5de:      	int3
   5b5df:      	int3

000000000005b5e0 <f.11>:
   5b5e0:      	pushq	%r15
   5b5e2:      	pushq	%r14
   5b5e4:      	pushq	%r12
   5b5e6:      	pushq	%rbx
   5b5e7:      	subq	$0x88, %rsp
   5b5ee:      	movq	$0xc, 0x18(%rsp)
   5b5f7:      	movq	$0x0, 0x20(%rsp)
   5b600:      	movq	0x7d11(%rip), %rax      # 0x63318 <native_roots.0>
   5b607:      	movq	%rax, 0x10(%rsp)
   5b60c:      	movq	0x7ce5(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b613:      	incq	%rax
   5b616:      	movq	%rax, 0x7cdb(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5b61d:      	movq	0x7cdc(%rip), %rcx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b624:      	cmpq	%rcx, %rax
   5b627:      	cmovbeq	%rcx, %rax
   5b62b:      	leaq	0x10(%rsp), %rcx
   5b630:      	movq	%rcx, 0x7ce1(%rip)      # 0x63318 <native_roots.0>
   5b637:      	movq	%rax, 0x7cc2(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5b63e:      	movq	%rdi, 0x28(%rsp)
   5b643:      	movq	%rsi, 0x30(%rsp)
   5b648:      	xorps	%xmm0, %xmm0
   5b64b:      	movups	%xmm0, 0x38(%rsp)
   5b650:      	movups	%xmm0, 0x48(%rsp)
   5b655:      	movups	%xmm0, 0x58(%rsp)
   5b65a:      	movq	0x8(%rdi), %rdx
   5b65e:      	movq	%rdx, 0x48(%rsp)
   5b663:      	cmpq	%rsi, %rdx
   5b666:      	jne	0x5b66f <f.11+0x8f>
   5b668:      	xorl	%edi, %edi
   5b66a:      	jmp	0x5b6fd <f.11+0x11d>
   5b66f:      	testq	%rdx, %rdx
   5b672:      	je	0x5bdb8 <f.11+0x7d8>
   5b678:      	movl	0x10(%rdx), %eax
   5b67b:      	movb	$0x1, %dil
   5b67e:      	cmpl	0x10(%rsi), %eax
   5b681:      	jne	0x5b6fd <f.11+0x11d>
   5b683:      	movq	0x18(%rdx), %rdx
   5b687:      	movq	%rdx, 0x50(%rsp)
   5b68c:      	movq	0x18(%rsi), %rsi
   5b690:      	movq	%rsi, 0x58(%rsp)
   5b695:      	testq	%rax, %rax
   5b698:      	je	0x5b668 <f.11+0x88>
   5b69a:      	testq	%rdx, %rdx
   5b69d:      	je	0x5bdb8 <f.11+0x7d8>
   5b6a3:      	testb	$0x1, %dl
   5b6a6:      	jne	0x5bdb8 <f.11+0x7d8>
   5b6ac:      	movq	0x8(%rdx), %r8
   5b6b0:      	testq	%rsi, %rsi
   5b6b3:      	je	0x5bdb5 <f.11+0x7d5>
   5b6b9:      	testb	$0x1, %sil
   5b6bd:      	jne	0x5bdb5 <f.11+0x7d5>
   5b6c3:      	decq	%rax
   5b6c6:      	xorl	%r9d, %r9d
   5b6c9:      	nopl	(%rax)
   5b6d0:      	cmpq	%r9, %r8
   5b6d3:      	je	0x5bdb8 <f.11+0x7d8>
   5b6d9:      	cmpq	%r9, 0x8(%rsi)
   5b6dd:      	jbe	0x5bdb8 <f.11+0x7d8>
   5b6e3:      	movzbl	0x10(%rdx,%r9), %edi
   5b6e9:      	cmpb	0x10(%rsi,%r9), %dil
   5b6ee:      	setne	%dil
   5b6f2:      	jne	0x5b6fd <f.11+0x11d>
   5b6f4:      	cmpq	%r9, %rax
   5b6f7:      	leaq	0x1(%r9), %r9
   5b6fb:      	jne	0x5b6d0 <f.11+0xf0>
   5b6fd:      	cmpb	$0x0, 0x7d8c(%rip)      # 0x63490 <g.24>
   5b704:      	je	0x5bdb8 <f.11+0x7d8>
   5b70a:      	cmpq	$0x0, 0x7d76(%rip)      # 0x63488 <g.23>
   5b712:      	je	0x5bdb8 <f.11+0x7d8>
   5b718:      	cmpb	$0x0, 0x7d11(%rip)      # 0x63430 <g.12>
   5b71f:      	je	0x5bdb8 <f.11+0x7d8>
   5b725:      	cmpq	$0x0, 0x7cfb(%rip)      # 0x63428 <g.11>
   5b72d:      	je	0x5bdb8 <f.11+0x7d8>
   5b733:      	testb	%dil, %dil
   5b736:      	je	0x5bd02 <f.11+0x722>
   5b73c:      	cmpb	$0x0, 0x7d0d(%rip)      # 0x63450 <g.16>
   5b743:      	je	0x5bdb8 <f.11+0x7d8>
   5b749:      	cmpq	$0x0, 0x7cf7(%rip)      # 0x63448 <g.15>
   5b751:      	je	0x5bdb8 <f.11+0x7d8>
   5b757:      	movq	$0x8, 0x20(%rsp)
   5b760:      	movq	0x7ba9(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b767:      	testq	%rdi, %rdi
   5b76a:      	je	0x5bdb8 <f.11+0x7d8>
   5b770:      	movq	0x178(%rdi), %rsi
   5b777:      	testq	%rsi, %rsi
   5b77a:      	je	0x5b7be <f.11+0x1de>
   5b77c:      	movq	0x170(%rdi), %rax
   5b783:      	incq	%rax
   5b786:      	movq	%rax, 0x170(%rdi)
   5b78d:      	movq	%rax, %rdx
   5b790:      	orq	%rsi, %rdx
   5b793:      	shrq	$0x20, %rdx
   5b797:      	je	0x5bd26 <f.11+0x746>
   5b79d:      	xorl	%edx, %edx
   5b79f:      	divq	%rsi
   5b7a2:      	testq	%rdx, %rdx
   5b7a5:      	jne	0x5b7be <f.11+0x1de>
   5b7a7:      	leaq	0x10(%rsp), %rsi
   5b7ac:      	movq	%rdi, %rbx
   5b7af:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b7b4:      	movq	%rbx, %rdi
   5b7b7:      	movq	0x7b5a(%rip), %rcx      # 0x63318 <native_roots.0>
   5b7be:      	movl	$0x18, %esi
   5b7c3:      	movq	%rcx, %rdx
   5b7c6:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b7cb:      	testq	%rax, %rax
   5b7ce:      	je	0x5bda4 <f.11+0x7c4>
   5b7d4:      	movq	%rax, %rbx
   5b7d7:      	movq	$0x62, (%rax)
   5b7de:      	movl	$0x0, 0x8(%rax)
   5b7e5:      	movq	$0x0, 0x10(%rax)
   5b7ed:      	movq	%rax, 0x38(%rsp)
   5b7f2:      	movq	%rax, 0x68(%rsp)
   5b7f7:      	leaq	0x7ac2(%rip), %r15      # 0x632c0 <object.2.1>
   5b7fe:      	movq	%r15, 0x70(%rsp)
   5b803:      	leaq	0x588e(%rip), %r12      # 0x61098 <ref.17>
   5b80a:      	movq	%r12, 0x78(%rsp)
   5b80f:      	movq	%rax, 0x80(%rsp)
   5b817:      	movq	$0xc, 0x20(%rsp)
   5b820:      	movq	0x7ae9(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b827:      	testq	%rdi, %rdi
   5b82a:      	je	0x5bdb8 <f.11+0x7d8>
   5b830:      	movq	0x178(%rdi), %rcx
   5b837:      	testq	%rcx, %rcx
   5b83a:      	je	0x5b879 <f.11+0x299>
   5b83c:      	movq	0x170(%rdi), %rax
   5b843:      	incq	%rax
   5b846:      	movq	%rax, 0x170(%rdi)
   5b84d:      	movq	%rax, %rdx
   5b850:      	orq	%rcx, %rdx
   5b853:      	shrq	$0x20, %rdx
   5b857:      	je	0x5bd38 <f.11+0x758>
   5b85d:      	xorl	%edx, %edx
   5b85f:      	divq	%rcx
   5b862:      	testq	%rdx, %rdx
   5b865:      	jne	0x5b879 <f.11+0x299>
   5b867:      	movq	0x7aaa(%rip), %rsi      # 0x63318 <native_roots.0>
   5b86e:      	movq	%rdi, %r14
   5b871:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b876:      	movq	%r14, %rdi
   5b879:      	movq	0x7a98(%rip), %rdx      # 0x63318 <native_roots.0>
   5b880:      	movl	$0x18, %esi
   5b885:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b88a:      	testq	%rax, %rax
   5b88d:      	je	0x5bda4 <f.11+0x7c4>
   5b893:      	movq	%rax, %r14
   5b896:      	movq	$0xa, (%rax)
   5b89d:      	movq	%r15, 0x8(%rax)
   5b8a1:      	movq	%rbx, 0x10(%rax)
   5b8a5:      	movq	%rax, 0x68(%rsp)
   5b8aa:      	movq	%r12, 0x70(%rsp)
   5b8af:      	movq	%rbx, 0x78(%rsp)
   5b8b4:      	movq	$0xb, 0x20(%rsp)
   5b8bd:      	movq	0x7a4c(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b8c4:      	testq	%rdi, %rdi
   5b8c7:      	je	0x5bdb8 <f.11+0x7d8>
   5b8cd:      	movq	0x178(%rdi), %rcx
   5b8d4:      	testq	%rcx, %rcx
   5b8d7:      	je	0x5b916 <f.11+0x336>
   5b8d9:      	movq	0x170(%rdi), %rax
   5b8e0:      	incq	%rax
   5b8e3:      	movq	%rax, 0x170(%rdi)
   5b8ea:      	movq	%rax, %rdx
   5b8ed:      	orq	%rcx, %rdx
   5b8f0:      	shrq	$0x20, %rdx
   5b8f4:      	je	0x5bd4a <f.11+0x76a>
   5b8fa:      	xorl	%edx, %edx
   5b8fc:      	divq	%rcx
   5b8ff:      	testq	%rdx, %rdx
   5b902:      	jne	0x5b916 <f.11+0x336>
   5b904:      	movq	0x7a0d(%rip), %rsi      # 0x63318 <native_roots.0>
   5b90b:      	movq	%rdi, %r15
   5b90e:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5b913:      	movq	%r15, %rdi
   5b916:      	movq	0x79fb(%rip), %rdx      # 0x63318 <native_roots.0>
   5b91d:      	movl	$0x18, %esi
   5b922:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5b927:      	testq	%rax, %rax
   5b92a:      	je	0x5bda4 <f.11+0x7c4>
   5b930:      	movq	$0x42, (%rax)
   5b937:      	movq	%r12, 0x8(%rax)
   5b93b:      	movq	%r14, 0x10(%rax)
   5b93f:      	movq	%rax, 0x10(%rbx)
   5b943:      	movq	0x38(%rsp), %rax
   5b948:      	testq	%rax, %rax
   5b94b:      	je	0x5bdb8 <f.11+0x7d8>
   5b951:      	movl	$0x1, 0x8(%rax)
   5b958:      	movq	0x38(%rsp), %rax
   5b95d:      	testq	%rax, %rax
   5b960:      	je	0x5bdb8 <f.11+0x7d8>
   5b966:      	cmpl	$0x0, 0x8(%rax)
   5b96a:      	je	0x5bdb8 <f.11+0x7d8>
   5b970:      	movq	0x10(%rax), %rax
   5b974:      	testq	%rax, %rax
   5b977:      	je	0x5bdb8 <f.11+0x7d8>
   5b97d:      	movq	%rax, 0x40(%rsp)
   5b982:      	movq	0x8(%rax), %rcx
   5b986:      	testq	%rcx, %rcx
   5b989:      	je	0x5bdb8 <f.11+0x7d8>
   5b98f:      	movq	0x10(%rax), %rdi
   5b993:      	movq	0x8(%rcx), %rax
   5b997:      	movq	%rdi, 0x68(%rsp)
   5b99c:      	movq	$0x9, 0x20(%rsp)
   5b9a5:      	xorl	%esi, %esi
   5b9a7:      	callq	*%rax
   5b9a9:      	subq	$0x8, %rsp
   5b9ad:      	cmpb	$0x0, 0x7a9c(%rip)      # 0x63450 <g.16>
   5b9b4:      	je	0x5bdb8 <f.11+0x7d8>
   5b9ba:      	cmpq	$0x0, 0x7a86(%rip)      # 0x63448 <g.15>
   5b9c2:      	je	0x5bdb8 <f.11+0x7d8>
   5b9c8:      	movq	$0x8, 0x20(%rsp)
   5b9d1:      	movq	0x7938(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5b9d8:      	testq	%rdi, %rdi
   5b9db:      	je	0x5bdb8 <f.11+0x7d8>
   5b9e1:      	movq	0x178(%rdi), %rcx
   5b9e8:      	testq	%rcx, %rcx
   5b9eb:      	je	0x5ba2a <f.11+0x44a>
   5b9ed:      	movq	0x170(%rdi), %rax
   5b9f4:      	incq	%rax
   5b9f7:      	movq	%rax, 0x170(%rdi)
   5b9fe:      	movq	%rax, %rdx
   5ba01:      	orq	%rcx, %rdx
   5ba04:      	shrq	$0x20, %rdx
   5ba08:      	je	0x5bd5c <f.11+0x77c>
   5ba0e:      	xorl	%edx, %edx
   5ba10:      	divq	%rcx
   5ba13:      	testq	%rdx, %rdx
   5ba16:      	jne	0x5ba2a <f.11+0x44a>
   5ba18:      	movq	0x78f9(%rip), %rsi      # 0x63318 <native_roots.0>
   5ba1f:      	movq	%rdi, %rbx
   5ba22:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5ba27:      	movq	%rbx, %rdi
   5ba2a:      	movq	0x78e7(%rip), %rdx      # 0x63318 <native_roots.0>
   5ba31:      	movl	$0x18, %esi
   5ba36:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5ba3b:      	testq	%rax, %rax
   5ba3e:      	je	0x5bda4 <f.11+0x7c4>
   5ba44:      	movq	%rax, %rbx
   5ba47:      	movq	$0x62, (%rax)
   5ba4e:      	movl	$0x0, 0x8(%rax)
   5ba55:      	movq	$0x0, 0x10(%rax)
   5ba5d:      	movq	%rax, 0x38(%rsp)
   5ba62:      	movq	%rax, 0x68(%rsp)
   5ba67:      	leaq	0x77f2(%rip), %r15      # 0x63260 <object.1.1>
   5ba6e:      	movq	%r15, 0x70(%rsp)
   5ba73:      	movq	%r12, 0x78(%rsp)
   5ba78:      	movq	%rax, 0x80(%rsp)
   5ba80:      	movq	$0xc, 0x20(%rsp)
   5ba89:      	movq	0x7880(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5ba90:      	testq	%rdi, %rdi
   5ba93:      	je	0x5bdb8 <f.11+0x7d8>
   5ba99:      	movq	0x178(%rdi), %rcx
   5baa0:      	testq	%rcx, %rcx
   5baa3:      	je	0x5bae2 <f.11+0x502>
   5baa5:      	movq	0x170(%rdi), %rax
   5baac:      	incq	%rax
   5baaf:      	movq	%rax, 0x170(%rdi)
   5bab6:      	movq	%rax, %rdx
   5bab9:      	orq	%rcx, %rdx
   5babc:      	shrq	$0x20, %rdx
   5bac0:      	je	0x5bd6e <f.11+0x78e>
   5bac6:      	xorl	%edx, %edx
   5bac8:      	divq	%rcx
   5bacb:      	testq	%rdx, %rdx
   5bace:      	jne	0x5bae2 <f.11+0x502>
   5bad0:      	movq	0x7841(%rip), %rsi      # 0x63318 <native_roots.0>
   5bad7:      	movq	%rdi, %r14
   5bada:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5badf:      	movq	%r14, %rdi
   5bae2:      	movq	0x782f(%rip), %rdx      # 0x63318 <native_roots.0>
   5bae9:      	movl	$0x18, %esi
   5baee:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5baf3:      	testq	%rax, %rax
   5baf6:      	je	0x5bda4 <f.11+0x7c4>
   5bafc:      	movq	%rax, %r14
   5baff:      	movq	$0xa, (%rax)
   5bb06:      	movq	%r15, 0x8(%rax)
   5bb0a:      	movq	%rbx, 0x10(%rax)
   5bb0e:      	movq	%rax, 0x68(%rsp)
   5bb13:      	movq	%r12, 0x70(%rsp)
   5bb18:      	movq	%rbx, 0x78(%rsp)
   5bb1d:      	movq	$0xb, 0x20(%rsp)
   5bb26:      	movq	0x77e3(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5bb2d:      	testq	%rdi, %rdi
   5bb30:      	je	0x5bdb8 <f.11+0x7d8>
   5bb36:      	movq	0x178(%rdi), %rcx
   5bb3d:      	testq	%rcx, %rcx
   5bb40:      	je	0x5bb7f <f.11+0x59f>
   5bb42:      	movq	0x170(%rdi), %rax
   5bb49:      	incq	%rax
   5bb4c:      	movq	%rax, 0x170(%rdi)
   5bb53:      	movq	%rax, %rdx
   5bb56:      	orq	%rcx, %rdx
   5bb59:      	shrq	$0x20, %rdx
   5bb5d:      	je	0x5bd80 <f.11+0x7a0>
   5bb63:      	xorl	%edx, %edx
   5bb65:      	divq	%rcx
   5bb68:      	testq	%rdx, %rdx
   5bb6b:      	jne	0x5bb7f <f.11+0x59f>
   5bb6d:      	movq	0x77a4(%rip), %rsi      # 0x63318 <native_roots.0>
   5bb74:      	movq	%rdi, %r15
   5bb77:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5bb7c:      	movq	%r15, %rdi
   5bb7f:      	movq	0x7792(%rip), %rdx      # 0x63318 <native_roots.0>
   5bb86:      	movl	$0x18, %esi
   5bb8b:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5bb90:      	testq	%rax, %rax
   5bb93:      	je	0x5bda4 <f.11+0x7c4>
   5bb99:      	movq	$0x42, (%rax)
   5bba0:      	movq	%r12, 0x8(%rax)
   5bba4:      	movq	%r14, 0x10(%rax)
   5bba8:      	movq	%rax, 0x10(%rbx)
   5bbac:      	movq	0x38(%rsp), %rax
   5bbb1:      	testq	%rax, %rax
   5bbb4:      	je	0x5bdb8 <f.11+0x7d8>
   5bbba:      	movl	$0x1, 0x8(%rax)
   5bbc1:      	movq	0x38(%rsp), %rax
   5bbc6:      	testq	%rax, %rax
   5bbc9:      	je	0x5bdb8 <f.11+0x7d8>
   5bbcf:      	cmpl	$0x0, 0x8(%rax)
   5bbd3:      	je	0x5bdb8 <f.11+0x7d8>
   5bbd9:      	movq	0x10(%rax), %rax
   5bbdd:      	testq	%rax, %rax
   5bbe0:      	je	0x5bdb8 <f.11+0x7d8>
   5bbe6:      	movq	%rax, 0x40(%rsp)
   5bbeb:      	movq	0x8(%rax), %rcx
   5bbef:      	testq	%rcx, %rcx
   5bbf2:      	je	0x5bdb8 <f.11+0x7d8>
   5bbf8:      	movq	0x10(%rax), %rdi
   5bbfc:      	movq	0x8(%rcx), %rax
   5bc00:      	movq	%rdi, 0x68(%rsp)
   5bc05:      	movq	$0x9, 0x20(%rsp)
   5bc0e:      	xorl	%esi, %esi
   5bc10:      	callq	*%rax
   5bc12:      	subq	$0x8, %rsp
   5bc16:      	cmpb	$0x0, 0x7843(%rip)      # 0x63460 <g.18>
   5bc1d:      	je	0x5bdb8 <f.11+0x7d8>
   5bc23:      	cmpq	$0x0, 0x782d(%rip)      # 0x63458 <g.17>
   5bc2b:      	je	0x5bdb8 <f.11+0x7d8>
   5bc31:      	movq	$0x8, 0x20(%rsp)
   5bc3a:      	movl	$0xa, %edi
   5bc3f:      	callq	0x56c90 <write_character>
   5bc44:      	cmpb	$0x0, 0x7835(%rip)      # 0x63480 <g.22>
   5bc4b:      	je	0x5bdb8 <f.11+0x7d8>
   5bc51:      	movq	0x7820(%rip), %r14      # 0x63478 <g.21>
   5bc58:      	testq	%r14, %r14
   5bc5b:      	je	0x5bdb8 <f.11+0x7d8>
   5bc61:      	movq	0x8(%r14), %r15
   5bc65:      	movq	%r15, 0x68(%rsp)
   5bc6a:      	movq	%r14, 0x70(%rsp)
   5bc6f:      	movq	$0xa, 0x20(%rsp)
   5bc78:      	movq	0x7691(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5bc7f:      	testq	%rdi, %rdi
   5bc82:      	je	0x5bdb8 <f.11+0x7d8>
   5bc88:      	movq	0x178(%rdi), %rcx
   5bc8f:      	testq	%rcx, %rcx
   5bc92:      	je	0x5bcd1 <f.11+0x6f1>
   5bc94:      	movq	0x170(%rdi), %rax
   5bc9b:      	incq	%rax
   5bc9e:      	movq	%rax, 0x170(%rdi)
   5bca5:      	movq	%rax, %rdx
   5bca8:      	orq	%rcx, %rdx
   5bcab:      	shrq	$0x20, %rdx
   5bcaf:      	je	0x5bd92 <f.11+0x7b2>
   5bcb5:      	xorl	%edx, %edx
   5bcb7:      	divq	%rcx
   5bcba:      	testq	%rdx, %rdx
   5bcbd:      	jne	0x5bcd1 <f.11+0x6f1>
   5bcbf:      	movq	0x7652(%rip), %rsi      # 0x63318 <native_roots.0>
   5bcc6:      	movq	%rdi, %rbx
   5bcc9:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5bcce:      	movq	%rbx, %rdi
   5bcd1:      	movq	0x7640(%rip), %rdx      # 0x63318 <native_roots.0>
   5bcd8:      	movl	$0x10, %esi
   5bcdd:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5bce2:      	testq	%rax, %rax
   5bce5:      	je	0x5bda4 <f.11+0x7c4>
   5bceb:      	movq	$0x6e, (%rax)
   5bcf2:      	movq	%r15, 0x8(%rax)
   5bcf6:      	movq	%rax, 0x8(%r14)
   5bcfa:      	cmpq	$0x0, 0x18(%rsp)
   5bd00:      	je	0x5bd15 <f.11+0x735>
   5bd02:      	movq	0x10(%rsp), %rax
   5bd07:      	movq	%rax, 0x760a(%rip)      # 0x63318 <native_roots.0>
   5bd0e:      	decq	0x75e3(%rip)            # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5bd15:      	addq	$0x88, %rsp
   5bd1c:      	popq	%rbx
   5bd1d:      	popq	%r12
   5bd1f:      	popq	%r14
   5bd21:      	popq	%r15
   5bd23:      	retq	$0x8
   5bd26:      	xorl	%edx, %edx
   5bd28:      	divl	%esi
   5bd2a:      	testq	%rdx, %rdx
   5bd2d:      	jne	0x5b7be <f.11+0x1de>
   5bd33:      	jmp	0x5b7a7 <f.11+0x1c7>
   5bd38:      	xorl	%edx, %edx
   5bd3a:      	divl	%ecx
   5bd3c:      	testq	%rdx, %rdx
   5bd3f:      	jne	0x5b879 <f.11+0x299>
   5bd45:      	jmp	0x5b867 <f.11+0x287>
   5bd4a:      	xorl	%edx, %edx
   5bd4c:      	divl	%ecx
   5bd4e:      	testq	%rdx, %rdx
   5bd51:      	jne	0x5b916 <f.11+0x336>
   5bd57:      	jmp	0x5b904 <f.11+0x324>
   5bd5c:      	xorl	%edx, %edx
   5bd5e:      	divl	%ecx
   5bd60:      	testq	%rdx, %rdx
   5bd63:      	jne	0x5ba2a <f.11+0x44a>
   5bd69:      	jmp	0x5ba18 <f.11+0x438>
   5bd6e:      	xorl	%edx, %edx
   5bd70:      	divl	%ecx
   5bd72:      	testq	%rdx, %rdx
   5bd75:      	jne	0x5bae2 <f.11+0x502>
   5bd7b:      	jmp	0x5bad0 <f.11+0x4f0>
   5bd80:      	xorl	%edx, %edx
   5bd82:      	divl	%ecx
   5bd84:      	testq	%rdx, %rdx
   5bd87:      	jne	0x5bb7f <f.11+0x59f>
   5bd8d:      	jmp	0x5bb6d <f.11+0x58d>
   5bd92:      	xorl	%edx, %edx
   5bd94:      	divl	%ecx
   5bd96:      	testq	%rdx, %rdx
   5bd99:      	jne	0x5bcd1 <f.11+0x6f1>
   5bd9f:      	jmp	0x5bcbf <f.11+0x6df>
   5bda4:      	leaq	-0x52a4f(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5bdab:      	movl	$0x2f, %esi
   5bdb0:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5bdb5:      	testq	%r8, %r8
   5bdb8:      	callq	0x55770 <native_trap>
   5bdbd:      	int3
   5bdbe:      	int3
   5bdbf:      	int3

000000000005bdc0 <f.10>:
   5bdc0:      	pushq	%rbp
   5bdc1:      	pushq	%r15
   5bdc3:      	pushq	%r14
   5bdc5:      	pushq	%r13
   5bdc7:      	pushq	%r12
   5bdc9:      	pushq	%rbx
   5bdca:      	subq	$0xa8, %rsp
   5bdd1:      	movq	$0xf, 0x18(%rsp)
   5bdda:      	movq	$0x0, 0x20(%rsp)
   5bde3:      	movq	0x752e(%rip), %rdx      # 0x63318 <native_roots.0>
   5bdea:      	movq	%rdx, 0x10(%rsp)
   5bdef:      	leaq	0x10(%rsp), %rax
   5bdf4:      	movq	%rax, 0x751d(%rip)      # 0x63318 <native_roots.0>
   5bdfb:      	movq	0x74f6(%rip), %rcx      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5be02:      	incq	%rcx
   5be05:      	movq	%rcx, 0x74ec(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5be0c:      	movq	0x74ed(%rip), %rax      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5be13:      	cmpq	%rax, %rcx
   5be16:      	cmovaq	%rcx, %rax
   5be1a:      	movq	%rax, 0x74df(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5be21:      	movq	%rdi, 0x28(%rsp)
   5be26:      	xorps	%xmm0, %xmm0
   5be29:      	movups	%xmm0, 0x30(%rsp)
   5be2e:      	movups	%xmm0, 0x40(%rsp)
   5be33:      	movups	%xmm0, 0x50(%rsp)
   5be38:      	movups	%xmm0, 0x60(%rsp)
   5be3d:      	movq	$0x0, 0x70(%rsp)
   5be46:      	testq	%rdi, %rdi
   5be49:      	je	0x5c959 <f.10+0xb99>
   5be4f:      	movl	%edi, %eax
   5be51:      	andl	$0x1, %eax
   5be54:      	jne	0x5c959 <f.10+0xb99>
   5be5a:      	movq	0x74af(%rip), %rax      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5be61:      	testq	%rax, %rax
   5be64:      	je	0x5c959 <f.10+0xb99>
   5be6a:      	movq	%rsi, %rbx
   5be6d:      	movq	(%rdi), %rsi
   5be70:      	movq	%rsi, %r8
   5be73:      	testq	%rsi, %rsi
   5be76:      	je	0x5bef3 <f.10+0x133>
   5be78:      	movq	%rsi, %r8
   5be7b:      	cmpq	$0x1e, %rsi
   5be7f:      	je	0x5bef3 <f.10+0x133>
   5be81:      	movq	0x168(%rax), %r9
   5be88:      	movq	%rsi, %r8
   5be8b:      	shrq	$0x2, %r8
   5be8f:      	leaq	-0x1(%r8), %r10
   5be93:      	cmpq	%r9, %r10
   5be96:      	jae	0x5c959 <f.10+0xb99>
   5be9c:      	movq	0x160(%rax), %r10
   5bea3:      	movq	-0x8(%r10,%r8,8), %r8
   5bea8:      	testq	%r8, %r8
   5beab:      	je	0x5bef3 <f.10+0x133>
   5bead:      	cmpq	$0x1e, %r8
   5beb1:      	je	0x5bef3 <f.10+0x133>
   5beb3:      	nopw	%cs:(%rax,%rax)
   5bec0:      	shrq	$0x2, %r8
   5bec4:      	leaq	-0x1(%r8), %r11
   5bec8:      	cmpq	%r9, %r11
   5becb:      	jae	0x5c959 <f.10+0xb99>
   5bed1:      	movq	-0x8(%r10,%r8,8), %r8
   5bed6:      	cmpq	$0x1e, %r8
   5beda:      	je	0x5bef3 <f.10+0x133>
   5bedc:      	testq	%r8, %r8
   5bedf:      	jne	0x5bec0 <f.10+0x100>
   5bee1:      	jmp	0x5bef3 <f.10+0x133>
   5bee3:      	nopw	%cs:(%rax,%rax)
   5bef0:      	incq	%rbx
   5bef3:      	cmpq	$0x1e, %r8
   5bef7:      	jne	0x5c959 <f.10+0xb99>
   5befd:      	cmpq	%rbx, 0x8(%rdi)
   5bf01:      	je	0x5c932 <f.10+0xb72>
   5bf07:      	testb	$0x1, %dil
   5bf0b:      	jne	0x5c959 <f.10+0xb99>
   5bf11:      	testq	%rsi, %rsi
   5bf14:      	je	0x5bf80 <f.10+0x1c0>
   5bf16:      	cmpq	$0x1e, %rsi
   5bf1a:      	je	0x5bf80 <f.10+0x1c0>
   5bf1c:      	movq	0x168(%rax), %rcx
   5bf23:      	shrq	$0x2, %rsi
   5bf27:      	leaq	-0x1(%rsi), %rdx
   5bf2b:      	cmpq	%rcx, %rdx
   5bf2e:      	jae	0x5c959 <f.10+0xb99>
   5bf34:      	movq	0x160(%rax), %rdx
   5bf3b:      	movq	-0x8(%rdx,%rsi,8), %rsi
   5bf40:      	testq	%rsi, %rsi
   5bf43:      	je	0x5bf80 <f.10+0x1c0>
   5bf45:      	cmpq	$0x1e, %rsi
   5bf49:      	je	0x5bf80 <f.10+0x1c0>
   5bf4b:      	nopl	(%rax,%rax)
   5bf50:      	shrq	$0x2, %rsi
   5bf54:      	leaq	-0x1(%rsi), %r8
   5bf58:      	cmpq	%rcx, %r8
   5bf5b:      	jae	0x5c959 <f.10+0xb99>
   5bf61:      	movq	-0x8(%rdx,%rsi,8), %rsi
   5bf66:      	cmpq	$0x1e, %rsi
   5bf6a:      	je	0x5bf80 <f.10+0x1c0>
   5bf6c:      	testq	%rsi, %rsi
   5bf6f:      	jne	0x5bf50 <f.10+0x190>
   5bf71:      	nopw	%cs:(%rax,%rax)
   5bf80:      	cmpq	$0x1e, %rsi
   5bf84:      	jne	0x5c959 <f.10+0xb99>
   5bf8a:      	movq	%rdi, 0x30(%rsp)
   5bf8f:      	movq	0x18(%rdi), %rcx
   5bf93:      	testq	%rcx, %rcx
   5bf96:      	je	0x5c959 <f.10+0xb99>
   5bf9c:      	cmpl	$0x0, 0x8(%rcx)
   5bfa0:      	je	0x5c959 <f.10+0xb99>
   5bfa6:      	movq	0x10(%rcx), %rcx
   5bfaa:      	testq	%rcx, %rcx
   5bfad:      	je	0x5c959 <f.10+0xb99>
   5bfb3:      	movq	0x10(%rcx), %rcx
   5bfb7:      	testq	%rcx, %rcx
   5bfba:      	je	0x5c959 <f.10+0xb99>
   5bfc0:      	movl	%ecx, %edx
   5bfc2:      	andl	$0x1, %edx
   5bfc5:      	jne	0x5c959 <f.10+0xb99>
   5bfcb:      	movq	0x10(%rdi), %rsi
   5bfcf:      	movq	(%rcx), %rdx
   5bfd2:      	testq	%rdx, %rdx
   5bfd5:      	je	0x5c040 <f.10+0x280>
   5bfd7:      	cmpq	$0x4a, %rdx
   5bfdb:      	je	0x5c040 <f.10+0x280>
   5bfdd:      	movq	0x168(%rax), %rdi
   5bfe4:      	shrq	$0x2, %rdx
   5bfe8:      	leaq	-0x1(%rdx), %r8
   5bfec:      	cmpq	%rdi, %r8
   5bfef:      	jae	0x5c959 <f.10+0xb99>
   5bff5:      	movq	0x160(%rax), %rax
   5bffc:      	movq	-0x8(%rax,%rdx,8), %rdx
   5c001:      	testq	%rdx, %rdx
   5c004:      	je	0x5c040 <f.10+0x280>
   5c006:      	cmpq	$0x4a, %rdx
   5c00a:      	je	0x5c040 <f.10+0x280>
   5c00c:      	nopl	(%rax)
   5c010:      	shrq	$0x2, %rdx
   5c014:      	leaq	-0x1(%rdx), %r8
   5c018:      	cmpq	%rdi, %r8
   5c01b:      	jae	0x5c959 <f.10+0xb99>
   5c021:      	movq	-0x8(%rax,%rdx,8), %rdx
   5c026:      	cmpq	$0x4a, %rdx
   5c02a:      	je	0x5c040 <f.10+0x280>
   5c02c:      	testq	%rdx, %rdx
   5c02f:      	jne	0x5c010 <f.10+0x250>
   5c031:      	nopw	%cs:(%rax,%rax)
   5c040:      	cmpq	$0x4a, %rdx
   5c044:      	jne	0x5c959 <f.10+0xb99>
   5c04a:      	movq	%rcx, 0x58(%rsp)
   5c04f:      	movq	0x8(%rcx), %rax
   5c053:      	testq	%rax, %rax
   5c056:      	je	0x5c959 <f.10+0xb99>
   5c05c:      	movq	0x8(%rax), %rax
   5c060:      	movq	%rax, 0x60(%rsp)
   5c065:      	testq	%rax, %rax
   5c068:      	je	0x5c959 <f.10+0xb99>
   5c06e:      	movq	0x8(%rax), %rcx
   5c072:      	testq	%rcx, %rcx
   5c075:      	je	0x5c959 <f.10+0xb99>
   5c07b:      	movq	0x10(%rax), %rdi
   5c07f:      	movq	0x8(%rcx), %rax
   5c083:      	movq	%rdi, 0x78(%rsp)
   5c088:      	movq	$0xb, 0x20(%rsp)
   5c091:      	callq	*%rax
   5c093:      	subq	$0x8, %rsp
   5c097:      	cmpb	$0x0, 0x7352(%rip)      # 0x633f0 <g.4>
   5c09e:      	je	0x5c959 <f.10+0xb99>
   5c0a4:      	cmpq	$0x0, 0x733c(%rip)      # 0x633e8 <g.3>
   5c0ac:      	je	0x5c959 <f.10+0xb99>
   5c0b2:      	movq	%rax, %r15
   5c0b5:      	shrq	$0x20, %rax
   5c0b9:      	jne	0x5c959 <f.10+0xb99>
   5c0bf:      	movq	$0xa, 0x20(%rsp)
   5c0c8:      	movq	0x7241(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c0cf:      	testq	%rdi, %rdi
   5c0d2:      	je	0x5c959 <f.10+0xb99>
   5c0d8:      	movq	0x178(%rdi), %rcx
   5c0df:      	testq	%rcx, %rcx
   5c0e2:      	je	0x5c121 <f.10+0x361>
   5c0e4:      	movq	0x170(%rdi), %rax
   5c0eb:      	incq	%rax
   5c0ee:      	movq	%rax, 0x170(%rdi)
   5c0f5:      	movq	%rax, %rdx
   5c0f8:      	orq	%rcx, %rdx
   5c0fb:      	shrq	$0x20, %rdx
   5c0ff:      	je	0x5c880 <f.10+0xac0>
   5c105:      	xorl	%edx, %edx
   5c107:      	divq	%rcx
   5c10a:      	testq	%rdx, %rdx
   5c10d:      	jne	0x5c121 <f.10+0x361>
   5c10f:      	movq	0x7202(%rip), %rsi      # 0x63318 <native_roots.0>
   5c116:      	movq	%rdi, %r14
   5c119:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c11e:      	movq	%r14, %rdi
   5c121:      	movq	0x71f0(%rip), %rdx      # 0x63318 <native_roots.0>
   5c128:      	movl	$0x18, %esi
   5c12d:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c132:      	testq	%rax, %rax
   5c135:      	je	0x5c95e <f.10+0xb9e>
   5c13b:      	movq	%rax, %r14
   5c13e:      	movq	$0x66, (%rax)
   5c145:      	movl	$0x0, 0x8(%rax)
   5c14c:      	movq	$0x0, 0x10(%rax)
   5c154:      	movq	%rax, 0x38(%rsp)
   5c159:      	movq	0x58(%rsp), %rax
   5c15e:      	testq	%rax, %rax
   5c161:      	je	0x5c959 <f.10+0xb99>
   5c167:      	movq	0x8(%rax), %rbp
   5c16b:      	movq	%rbp, 0x78(%rsp)
   5c170:      	leaq	0x4ef1(%rip), %r12      # 0x61068 <ref.13>
   5c177:      	movq	%r12, 0x80(%rsp)
   5c17f:      	movq	%r14, 0x88(%rsp)
   5c187:      	movq	$0xd, 0x20(%rsp)
   5c190:      	movl	%r15d, %edi
   5c193:      	callq	0x58e20 <native_array_new>
   5c198:      	movq	%rax, 0x78(%rsp)
   5c19d:      	movq	%rbp, 0x80(%rsp)
   5c1a5:      	movq	%r12, 0x88(%rsp)
   5c1ad:      	movq	%r14, 0x90(%rsp)
   5c1b5:      	movq	$0xe, 0x20(%rsp)
   5c1be:      	movq	0x714b(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c1c5:      	testq	%rdi, %rdi
   5c1c8:      	je	0x5c959 <f.10+0xb99>
   5c1ce:      	movq	%rax, %r13
   5c1d1:      	movq	0x178(%rdi), %rcx
   5c1d8:      	testq	%rcx, %rcx
   5c1db:      	je	0x5c21a <f.10+0x45a>
   5c1dd:      	movq	0x170(%rdi), %rax
   5c1e4:      	incq	%rax
   5c1e7:      	movq	%rax, 0x170(%rdi)
   5c1ee:      	movq	%rax, %rdx
   5c1f1:      	orq	%rcx, %rdx
   5c1f4:      	shrq	$0x20, %rdx
   5c1f8:      	je	0x5c8a0 <f.10+0xae0>
   5c1fe:      	xorl	%edx, %edx
   5c200:      	divq	%rcx
   5c203:      	testq	%rdx, %rdx
   5c206:      	jne	0x5c21a <f.10+0x45a>
   5c208:      	movq	0x7109(%rip), %rsi      # 0x63318 <native_roots.0>
   5c20f:      	movq	%rdi, %r12
   5c212:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c217:      	movq	%r12, %rdi
   5c21a:      	movq	%rbx, 0xa0(%rsp)
   5c222:      	movq	0x70ef(%rip), %rdx      # 0x63318 <native_roots.0>
   5c229:      	movl	$0x10, %esi
   5c22e:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c233:      	testq	%rax, %rax
   5c236:      	je	0x5c95e <f.10+0xb9e>
   5c23c:      	movq	%rax, %r12
   5c23f:      	movq	$0x82, (%rax)
   5c246:      	movq	%r13, 0x8(%rax)
   5c24a:      	movq	0x38(%rsp), %rbx
   5c24f:      	movq	%rbx, 0x78(%rsp)
   5c254:      	movq	%rax, 0x80(%rsp)
   5c25c:      	movq	%rbp, 0x88(%rsp)
   5c264:      	leaq	0x4dfd(%rip), %rax      # 0x61068 <ref.13>
   5c26b:      	movq	%rax, 0x90(%rsp)
   5c273:      	movq	%r14, 0x98(%rsp)
   5c27b:      	movq	$0xf, 0x20(%rsp)
   5c284:      	movq	0x7085(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c28b:      	testq	%rdi, %rdi
   5c28e:      	je	0x5c959 <f.10+0xb99>
   5c294:      	movq	0x178(%rdi), %rcx
   5c29b:      	testq	%rcx, %rcx
   5c29e:      	je	0x5c2dd <f.10+0x51d>
   5c2a0:      	movq	0x170(%rdi), %rax
   5c2a7:      	incq	%rax
   5c2aa:      	movq	%rax, 0x170(%rdi)
   5c2b1:      	movq	%rax, %rdx
   5c2b4:      	orq	%rcx, %rdx
   5c2b7:      	shrq	$0x20, %rdx
   5c2bb:      	je	0x5c8c0 <f.10+0xb00>
   5c2c1:      	xorl	%edx, %edx
   5c2c3:      	divq	%rcx
   5c2c6:      	testq	%rdx, %rdx
   5c2c9:      	jne	0x5c2dd <f.10+0x51d>
   5c2cb:      	movq	0x7046(%rip), %rsi      # 0x63318 <native_roots.0>
   5c2d2:      	movq	%rdi, %r13
   5c2d5:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c2da:      	movq	%r13, %rdi
   5c2dd:      	movq	0x7034(%rip), %rdx      # 0x63318 <native_roots.0>
   5c2e4:      	movl	$0x28, %esi
   5c2e9:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c2ee:      	testq	%rax, %rax
   5c2f1:      	je	0x5c95e <f.10+0xb9e>
   5c2f7:      	movq	%rax, %r13
   5c2fa:      	movq	$0x2a, (%rax)
   5c301:      	movq	%rbp, 0x8(%rax)
   5c305:      	movq	%r15, 0x10(%rax)
   5c309:      	movq	%r12, 0x18(%rax)
   5c30d:      	movq	%rbx, 0x20(%rax)
   5c311:      	movq	%rax, 0x78(%rsp)
   5c316:      	leaq	0x4d4b(%rip), %rax      # 0x61068 <ref.13>
   5c31d:      	movq	%rax, 0x80(%rsp)
   5c325:      	movq	%r14, 0x88(%rsp)
   5c32d:      	movq	$0xd, 0x20(%rsp)
   5c336:      	movq	0x6fd3(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c33d:      	testq	%rdi, %rdi
   5c340:      	je	0x5c959 <f.10+0xb99>
   5c346:      	movq	0x178(%rdi), %rcx
   5c34d:      	testq	%rcx, %rcx
   5c350:      	je	0x5c38f <f.10+0x5cf>
   5c352:      	movq	0x170(%rdi), %rax
   5c359:      	incq	%rax
   5c35c:      	movq	%rax, 0x170(%rdi)
   5c363:      	movq	%rax, %rdx
   5c366:      	orq	%rcx, %rdx
   5c369:      	shrq	$0x20, %rdx
   5c36d:      	je	0x5c8e0 <f.10+0xb20>
   5c373:      	xorl	%edx, %edx
   5c375:      	divq	%rcx
   5c378:      	testq	%rdx, %rdx
   5c37b:      	jne	0x5c38f <f.10+0x5cf>
   5c37d:      	movq	0x6f94(%rip), %rsi      # 0x63318 <native_roots.0>
   5c384:      	movq	%rdi, %r15
   5c387:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c38c:      	movq	%r15, %rdi
   5c38f:      	movq	0x6f82(%rip), %rdx      # 0x63318 <native_roots.0>
   5c396:      	movl	$0x18, %esi
   5c39b:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c3a0:      	testq	%rax, %rax
   5c3a3:      	je	0x5c95e <f.10+0xb9e>
   5c3a9:      	movq	$0xc2, (%rax)
   5c3b0:      	leaq	0x4cb1(%rip), %rcx      # 0x61068 <ref.13>
   5c3b7:      	movq	%rcx, 0x8(%rax)
   5c3bb:      	movq	%r13, 0x10(%rax)
   5c3bf:      	movq	%rax, 0x10(%r14)
   5c3c3:      	movq	0x38(%rsp), %rax
   5c3c8:      	testq	%rax, %rax
   5c3cb:      	je	0x5c959 <f.10+0xb99>
   5c3d1:      	movl	$0x1, 0x8(%rax)
   5c3d8:      	movq	0x38(%rsp), %rax
   5c3dd:      	testq	%rax, %rax
   5c3e0:      	je	0x5c959 <f.10+0xb99>
   5c3e6:      	cmpl	$0x0, 0x8(%rax)
   5c3ea:      	je	0x5c959 <f.10+0xb99>
   5c3f0:      	movq	0x10(%rax), %rax
   5c3f4:      	testq	%rax, %rax
   5c3f7:      	je	0x5c959 <f.10+0xb99>
   5c3fd:      	movq	%rax, 0x68(%rsp)
   5c402:      	movq	0x8(%rax), %rcx
   5c406:      	testq	%rcx, %rcx
   5c409:      	je	0x5c959 <f.10+0xb99>
   5c40f:      	movq	0x10(%rax), %rdi
   5c413:      	movq	0x8(%rcx), %rax
   5c417:      	movq	%rdi, 0x78(%rsp)
   5c41c:      	movq	$0xb, 0x20(%rsp)
   5c425:      	xorl	%esi, %esi
   5c427:      	callq	*%rax
   5c429:      	subq	$0x8, %rsp
   5c42d:      	movq	%rax, 0x48(%rsp)
   5c432:      	cmpb	$0x0, 0x6fc7(%rip)      # 0x63400 <g.6>
   5c439:      	je	0x5c959 <f.10+0xb99>
   5c43f:      	cmpq	$0x0, 0x6fb1(%rip)      # 0x633f8 <g.5>
   5c447:      	je	0x5c959 <f.10+0xb99>
   5c44d:      	cmpb	$0x0, 0x6fbc(%rip)      # 0x63410 <g.8>
   5c454:      	je	0x5c959 <f.10+0xb99>
   5c45a:      	cmpq	$0x0, 0x6fa6(%rip)      # 0x63408 <g.7>
   5c462:      	je	0x5c959 <f.10+0xb99>
   5c468:      	testq	%rax, %rax
   5c46b:      	je	0x5c959 <f.10+0xb99>
   5c471:      	movq	0x8(%rax), %rcx
   5c475:      	testq	%rcx, %rcx
   5c478:      	je	0x5c959 <f.10+0xb99>
   5c47e:      	testb	$0x1, %cl
   5c481:      	jne	0x5c959 <f.10+0xb99>
   5c487:      	movl	0x8(%rcx), %esi
   5c48a:      	movq	%rax, 0x78(%rsp)
   5c48f:      	movq	$0xb, 0x20(%rsp)
   5c498:      	movq	%rax, %rdi
   5c49b:      	callq	0x5b1c0 <f.5>
   5c4a0:      	subq	$0x8, %rsp
   5c4a4:      	movq	%rax, 0x40(%rsp)
   5c4a9:      	movq	%rax, 0x78(%rsp)
   5c4ae:      	movq	$0xb, 0x20(%rsp)
   5c4b7:      	movq	0x6e52(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c4be:      	testq	%rdi, %rdi
   5c4c1:      	je	0x5c959 <f.10+0xb99>
   5c4c7:      	movq	%rax, %r15
   5c4ca:      	movq	0x178(%rdi), %rcx
   5c4d1:      	testq	%rcx, %rcx
   5c4d4:      	je	0x5c513 <f.10+0x753>
   5c4d6:      	movq	0x170(%rdi), %rax
   5c4dd:      	incq	%rax
   5c4e0:      	movq	%rax, 0x170(%rdi)
   5c4e7:      	movq	%rax, %rdx
   5c4ea:      	orq	%rcx, %rdx
   5c4ed:      	shrq	$0x20, %rdx
   5c4f1:      	je	0x5c900 <f.10+0xb40>
   5c4f7:      	xorl	%edx, %edx
   5c4f9:      	divq	%rcx
   5c4fc:      	testq	%rdx, %rdx
   5c4ff:      	jne	0x5c513 <f.10+0x753>
   5c501:      	movq	0x6e10(%rip), %rsi      # 0x63318 <native_roots.0>
   5c508:      	movq	%rdi, %r14
   5c50b:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c510:      	movq	%r14, %rdi
   5c513:      	movq	0x6dfe(%rip), %rdx      # 0x63318 <native_roots.0>
   5c51a:      	movl	$0x10, %esi
   5c51f:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c524:      	testq	%rax, %rax
   5c527:      	je	0x5c95e <f.10+0xb9e>
   5c52d:      	movq	%rax, %r14
   5c530:      	movq	$0x22, (%rax)
   5c537:      	movq	%r15, 0x8(%rax)
   5c53b:      	movq	0x40(%rsp), %rdi
   5c540:      	testq	%rdi, %rdi
   5c543:      	je	0x5c959 <f.10+0xb99>
   5c549:      	movl	0x8(%rdi), %r15d
   5c54d:      	movq	%r14, 0x78(%rsp)
   5c552:      	movq	%rdi, 0x80(%rsp)
   5c55a:      	movq	$0xc, 0x20(%rsp)
   5c563:      	xorl	%esi, %esi
   5c565:      	callq	0x5b4e0 <f.4>
   5c56a:      	subq	$0x8, %rsp
   5c56e:      	movl	%eax, %ebp
   5c570:      	movq	0x40(%rsp), %rdi
   5c575:      	movq	%r14, 0x78(%rsp)
   5c57a:      	movq	%rdi, 0x80(%rsp)
   5c582:      	movq	$0xc, 0x20(%rsp)
   5c58b:      	movl	%r15d, %esi
   5c58e:      	callq	0x5b4e0 <f.4>
   5c593:      	subq	$0x8, %rsp
   5c597:      	movl	%eax, %r15d
   5c59a:      	subl	%ebp, %r15d
   5c59d:      	movq	%r14, 0x78(%rsp)
   5c5a2:      	movq	$0xb, 0x20(%rsp)
   5c5ab:      	movl	%r15d, %edi
   5c5ae:      	callq	0x58e20 <native_array_new>
   5c5b3:      	movq	%rax, 0x70(%rsp)
   5c5b8:      	movq	0x40(%rsp), %rcx
   5c5bd:      	testq	%rcx, %rcx
   5c5c0:      	je	0x5c959 <f.10+0xb99>
   5c5c6:      	testb	$0x1, %al
   5c5c8:      	jne	0x5c959 <f.10+0xb99>
   5c5ce:      	movq	0x18(%rcx), %rcx
   5c5d2:      	testq	%rcx, %rcx
   5c5d5:      	je	0x5c959 <f.10+0xb99>
   5c5db:      	movl	%ecx, %edx
   5c5dd:      	andl	$0x1, %edx
   5c5e0:      	jne	0x5c959 <f.10+0xb99>
   5c5e6:      	movl	%r15d, %edx
   5c5e9:      	cmpq	%rdx, 0x8(%rax)
   5c5ed:      	jb	0x5c959 <f.10+0xb99>
   5c5f3:      	movl	%ebp, %esi
   5c5f5:      	leaq	(%rdx,%rsi), %rdi
   5c5f9:      	cmpq	0x8(%rcx), %rdi
   5c5fd:      	ja	0x5c959 <f.10+0xb99>
   5c603:      	addq	%rcx, %rsi
   5c606:      	addq	$0x10, %rsi
   5c60a:      	addq	$0x10, %rax
   5c60e:      	movq	%rax, %rdi
   5c611:      	callq	*0x5221(%rip)           # 0x61838 <writev+0x61838>
   5c617:      	movq	0x70(%rsp), %rbx
   5c61c:      	movq	%rbx, 0x78(%rsp)
   5c621:      	movq	%r14, 0x80(%rsp)
   5c629:      	movq	$0xc, 0x20(%rsp)
   5c632:      	movq	0x6cd7(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c639:      	testq	%rdi, %rdi
   5c63c:      	je	0x5c959 <f.10+0xb99>
   5c642:      	movq	0x178(%rdi), %rcx
   5c649:      	testq	%rcx, %rcx
   5c64c:      	je	0x5c68b <f.10+0x8cb>
   5c64e:      	movq	0x170(%rdi), %rax
   5c655:      	incq	%rax
   5c658:      	movq	%rax, 0x170(%rdi)
   5c65f:      	movq	%rax, %rdx
   5c662:      	orq	%rcx, %rdx
   5c665:      	shrq	$0x20, %rdx
   5c669:      	je	0x5c920 <f.10+0xb60>
   5c66f:      	xorl	%edx, %edx
   5c671:      	divq	%rcx
   5c674:      	testq	%rdx, %rdx
   5c677:      	jne	0x5c68b <f.10+0x8cb>
   5c679:      	movq	0x6c98(%rip), %rsi      # 0x63318 <native_roots.0>
   5c680:      	movq	%rdi, %r15
   5c683:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5c688:      	movq	%r15, %rdi
   5c68b:      	movq	0x6c86(%rip), %rdx      # 0x63318 <native_roots.0>
   5c692:      	movl	$0x10, %esi
   5c697:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5c69c:      	testq	%rax, %rax
   5c69f:      	je	0x5c95e <f.10+0xb9e>
   5c6a5:      	movq	$0x82, (%rax)
   5c6ac:      	movq	%rbx, 0x8(%rax)
   5c6b0:      	movq	%rax, 0x50(%rsp)
   5c6b5:      	movq	0x8(%rax), %rcx
   5c6b9:      	testq	%rcx, %rcx
   5c6bc:      	je	0x5c959 <f.10+0xb99>
   5c6c2:      	testb	$0x1, %cl
   5c6c5:      	movq	0xa0(%rsp), %rbx
   5c6cd:      	jne	0x5c959 <f.10+0xb99>
   5c6d3:      	movl	0x8(%rcx), %esi
   5c6d6:      	movq	%r14, 0x78(%rsp)
   5c6db:      	movq	%rax, 0x80(%rsp)
   5c6e3:      	movq	$0xc, 0x20(%rsp)
   5c6ec:      	movq	%rax, %rdi
   5c6ef:      	callq	0x5b1c0 <f.5>
   5c6f4:      	subq	$0x8, %rsp
   5c6f8:      	movq	%r14, 0x78(%rsp)
   5c6fd:      	movq	%rax, 0x80(%rsp)
   5c705:      	movq	$0xc, 0x20(%rsp)
   5c70e:      	movq	%r14, %rdi
   5c711:      	movq	%rax, %rsi
   5c714:      	callq	0x5b5e0 <f.11>
   5c719:      	subq	$0x8, %rsp
   5c71d:      	movq	0x30(%rsp), %rdi
   5c722:      	testq	%rdi, %rdi
   5c725:      	je	0x5c959 <f.10+0xb99>
   5c72b:      	movq	0x20(%rdi), %rax
   5c72f:      	testq	%rax, %rax
   5c732:      	je	0x5c959 <f.10+0xb99>
   5c738:      	cmpl	$0x0, 0x8(%rax)
   5c73c:      	je	0x5c959 <f.10+0xb99>
   5c742:      	cmpq	$0x0, 0x10(%rax)
   5c747:      	je	0x5c959 <f.10+0xb99>
   5c74d:      	xorl	%ecx, %ecx
   5c74f:      	cmpq	$0x0, 0x18(%rsp)
   5c755:      	sete	%cl
   5c758:      	leaq	0x10(%rsp), %rsi
   5c75d:      	movq	%rsi, %rax
   5c760:      	leaq	0x6bb1(%rip), %rdx      # 0x63318 <native_roots.0>
   5c767:      	cmoveq	%rdx, %rax
   5c76b:      	addq	0x6b86(%rip), %rcx      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c772:      	movq	(%rax), %rdx
   5c775:      	movq	$0xf, 0x18(%rsp)
   5c77e:      	movq	$0x0, 0x20(%rsp)
   5c787:      	movq	%rdx, 0x10(%rsp)
   5c78c:      	movq	%rsi, 0x6b85(%rip)      # 0x63318 <native_roots.0>
   5c793:      	movq	%rcx, 0x6b5e(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c79a:      	movq	0x6b5f(%rip), %rax      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c7a1:      	cmpq	%rax, %rcx
   5c7a4:      	cmovaq	%rcx, %rax
   5c7a8:      	movq	%rax, 0x6b51(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c7af:      	movq	%rdi, 0x28(%rsp)
   5c7b4:      	leaq	0x30(%rsp), %rax
   5c7b9:      	xorps	%xmm0, %xmm0
   5c7bc:      	movups	%xmm0, 0x30(%rax)
   5c7c0:      	movups	%xmm0, 0x20(%rax)
   5c7c4:      	movups	%xmm0, 0x10(%rax)
   5c7c8:      	movups	%xmm0, (%rax)
   5c7cb:      	movq	$0x0, 0x40(%rax)
   5c7d3:      	testb	$0x1, %dil
   5c7d7:      	jne	0x5c959 <f.10+0xb99>
   5c7dd:      	movq	0x6b2c(%rip), %rax      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c7e4:      	testq	%rax, %rax
   5c7e7:      	je	0x5c959 <f.10+0xb99>
   5c7ed:      	movq	(%rdi), %rsi
   5c7f0:      	movq	%rsi, %r8
   5c7f3:      	testq	%rsi, %rsi
   5c7f6:      	je	0x5bef0 <f.10+0x130>
   5c7fc:      	movq	%rsi, %r8
   5c7ff:      	cmpq	$0x1e, %rsi
   5c803:      	je	0x5bef0 <f.10+0x130>
   5c809:      	movq	0x168(%rax), %r9
   5c810:      	movq	%rsi, %r8
   5c813:      	shrq	$0x2, %r8
   5c817:      	leaq	-0x1(%r8), %r10
   5c81b:      	cmpq	%r9, %r10
   5c81e:      	jae	0x5c959 <f.10+0xb99>
   5c824:      	movq	0x160(%rax), %r10
   5c82b:      	movq	-0x8(%r10,%r8,8), %r8
   5c830:      	testq	%r8, %r8
   5c833:      	je	0x5bef0 <f.10+0x130>
   5c839:      	cmpq	$0x1e, %r8
   5c83d:      	je	0x5bef0 <f.10+0x130>
   5c843:      	nopw	%cs:(%rax,%rax)
   5c850:      	shrq	$0x2, %r8
   5c854:      	leaq	-0x1(%r8), %r11
   5c858:      	cmpq	%r9, %r11
   5c85b:      	jae	0x5c959 <f.10+0xb99>
   5c861:      	movq	-0x8(%r10,%r8,8), %r8
   5c866:      	cmpq	$0x1e, %r8
   5c86a:      	je	0x5bef0 <f.10+0x130>
   5c870:      	testq	%r8, %r8
   5c873:      	jne	0x5c850 <f.10+0xa90>
   5c875:      	jmp	0x5bef0 <f.10+0x130>
   5c87a:      	nopw	(%rax,%rax)
   5c880:      	xorl	%edx, %edx
   5c882:      	divl	%ecx
   5c884:      	testq	%rdx, %rdx
   5c887:      	jne	0x5c121 <f.10+0x361>
   5c88d:      	jmp	0x5c10f <f.10+0x34f>
   5c892:      	nopw	%cs:(%rax,%rax)
   5c8a0:      	xorl	%edx, %edx
   5c8a2:      	divl	%ecx
   5c8a4:      	testq	%rdx, %rdx
   5c8a7:      	jne	0x5c21a <f.10+0x45a>
   5c8ad:      	jmp	0x5c208 <f.10+0x448>
   5c8b2:      	nopw	%cs:(%rax,%rax)
   5c8c0:      	xorl	%edx, %edx
   5c8c2:      	divl	%ecx
   5c8c4:      	testq	%rdx, %rdx
   5c8c7:      	jne	0x5c2dd <f.10+0x51d>
   5c8cd:      	jmp	0x5c2cb <f.10+0x50b>
   5c8d2:      	nopw	%cs:(%rax,%rax)
   5c8e0:      	xorl	%edx, %edx
   5c8e2:      	divl	%ecx
   5c8e4:      	testq	%rdx, %rdx
   5c8e7:      	jne	0x5c38f <f.10+0x5cf>
   5c8ed:      	jmp	0x5c37d <f.10+0x5bd>
   5c8f2:      	nopw	%cs:(%rax,%rax)
   5c900:      	xorl	%edx, %edx
   5c902:      	divl	%ecx
   5c904:      	testq	%rdx, %rdx
   5c907:      	jne	0x5c513 <f.10+0x753>
   5c90d:      	jmp	0x5c501 <f.10+0x741>
   5c912:      	nopw	%cs:(%rax,%rax)
   5c920:      	xorl	%edx, %edx
   5c922:      	divl	%ecx
   5c924:      	testq	%rdx, %rdx
   5c927:      	jne	0x5c68b <f.10+0x8cb>
   5c92d:      	jmp	0x5c679 <f.10+0x8b9>
   5c932:      	movq	%rdx, 0x69df(%rip)      # 0x63318 <native_roots.0>
   5c939:      	decq	%rcx
   5c93c:      	movq	%rcx, 0x69b5(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c943:      	xorl	%eax, %eax
   5c945:      	addq	$0xa8, %rsp
   5c94c:      	popq	%rbx
   5c94d:      	popq	%r12
   5c94f:      	popq	%r13
   5c951:      	popq	%r14
   5c953:      	popq	%r15
   5c955:      	popq	%rbp
   5c956:      	retq	$0x8
   5c959:      	callq	0x55770 <native_trap>
   5c95e:      	leaq	-0x53609(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5c965:      	movl	$0x2f, %esi
   5c96a:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5c96f:      	int3

000000000005c970 <f.17>:
   5c970:      	pushq	%r15
   5c972:      	pushq	%r14
   5c974:      	pushq	%r13
   5c976:      	pushq	%r12
   5c978:      	pushq	%rbx
   5c979:      	subq	$0x50, %rsp
   5c97d:      	movq	$0x5, 0x18(%rsp)
   5c986:      	movq	$0x0, 0x20(%rsp)
   5c98f:      	movq	0x6982(%rip), %rdx      # 0x63318 <native_roots.0>
   5c996:      	movq	%rdx, 0x10(%rsp)
   5c99b:      	leaq	0x10(%rsp), %r15
   5c9a0:      	movq	%r15, 0x6971(%rip)      # 0x63318 <native_roots.0>
   5c9a7:      	movq	0x694a(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c9ae:      	incq	%rax
   5c9b1:      	movq	%rax, 0x6940(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5c9b8:      	movq	0x6941(%rip), %rcx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c9bf:      	cmpq	%rcx, %rax
   5c9c2:      	cmovaq	%rax, %rcx
   5c9c6:      	movq	%rcx, 0x6933(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5c9cd:      	movq	%rdi, 0x28(%rsp)
   5c9d2:      	xorps	%xmm0, %xmm0
   5c9d5:      	movups	%xmm0, 0x30(%rsp)
   5c9da:      	testq	%rdi, %rdi
   5c9dd:      	je	0x5ccf9 <f.17+0x389>
   5c9e3:      	movl	%edi, %ecx
   5c9e5:      	andl	$0x1, %ecx
   5c9e8:      	jne	0x5ccf9 <f.17+0x389>
   5c9ee:      	movq	%rsi, %rbx
   5c9f1:      	movq	0x6918(%rip), %rsi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5c9f8:      	testq	%rsi, %rsi
   5c9fb:      	je	0x5ccf9 <f.17+0x389>
   5ca01:      	movq	(%rdi), %rcx
   5ca04:      	movq	%rcx, %r8
   5ca07:      	testq	%rcx, %rcx
   5ca0a:      	je	0x5ca71 <f.17+0x101>
   5ca0c:      	movq	%rcx, %r8
   5ca0f:      	cmpq	$0xa, %rcx
   5ca13:      	je	0x5ca71 <f.17+0x101>
   5ca15:      	movq	0x168(%rsi), %r9
   5ca1c:      	movq	%rcx, %r8
   5ca1f:      	shrq	$0x2, %r8
   5ca23:      	leaq	-0x1(%r8), %r10
   5ca27:      	cmpq	%r9, %r10
   5ca2a:      	jae	0x5ccf9 <f.17+0x389>
   5ca30:      	movq	0x160(%rsi), %r10
   5ca37:      	movq	-0x8(%r10,%r8,8), %r8
   5ca3c:      	testq	%r8, %r8
   5ca3f:      	je	0x5ca71 <f.17+0x101>
   5ca41:      	cmpq	$0xa, %r8
   5ca45:      	je	0x5ca71 <f.17+0x101>
   5ca47:      	nopw	(%rax,%rax)
   5ca50:      	shrq	$0x2, %r8
   5ca54:      	leaq	-0x1(%r8), %r11
   5ca58:      	cmpq	%r9, %r11
   5ca5b:      	jae	0x5ccf9 <f.17+0x389>
   5ca61:      	movq	-0x8(%r10,%r8,8), %r8
   5ca66:      	cmpq	$0xa, %r8
   5ca6a:      	je	0x5ca71 <f.17+0x101>
   5ca6c:      	testq	%r8, %r8
   5ca6f:      	jne	0x5ca50 <f.17+0xe0>
   5ca71:      	cmpq	$0xa, %r8
   5ca75:      	jne	0x5ccf9 <f.17+0x389>
   5ca7b:      	leaq	0x30(%rsp), %r12
   5ca80:      	leaq	0x6891(%rip), %r13      # 0x63318 <native_roots.0>
   5ca87:      	jmp	0x5ca9d <f.17+0x12d>
   5ca89:      	nopl	(%rax)
   5ca90:      	incq	%rbx
   5ca93:      	cmpq	$0xa, %r8
   5ca97:      	jne	0x5ccf9 <f.17+0x389>
   5ca9d:      	movq	0x8(%rdi), %r8
   5caa1:      	testq	%r8, %r8
   5caa4:      	je	0x5ccf9 <f.17+0x389>
   5caaa:      	movl	0x8(%r8), %r8d
   5caae:      	cmpq	%r8, %rbx
   5cab1:      	je	0x5ccd6 <f.17+0x366>
   5cab7:      	testb	$0x1, %dil
   5cabb:      	jne	0x5ccf9 <f.17+0x389>
   5cac1:      	testq	%rcx, %rcx
   5cac4:      	je	0x5cb30 <f.17+0x1c0>
   5cac6:      	cmpq	$0xa, %rcx
   5caca:      	je	0x5cb30 <f.17+0x1c0>
   5cacc:      	movq	0x168(%rsi), %rax
   5cad3:      	shrq	$0x2, %rcx
   5cad7:      	leaq	-0x1(%rcx), %rdx
   5cadb:      	cmpq	%rax, %rdx
   5cade:      	jae	0x5ccf9 <f.17+0x389>
   5cae4:      	movq	0x160(%rsi), %rdx
   5caeb:      	movq	-0x8(%rdx,%rcx,8), %rcx
   5caf0:      	testq	%rcx, %rcx
   5caf3:      	je	0x5cb30 <f.17+0x1c0>
   5caf5:      	cmpq	$0xa, %rcx
   5caf9:      	je	0x5cb30 <f.17+0x1c0>
   5cafb:      	nopl	(%rax,%rax)
   5cb00:      	shrq	$0x2, %rcx
   5cb04:      	leaq	-0x1(%rcx), %rsi
   5cb08:      	cmpq	%rax, %rsi
   5cb0b:      	jae	0x5ccf9 <f.17+0x389>
   5cb11:      	movq	-0x8(%rdx,%rcx,8), %rcx
   5cb16:      	cmpq	$0xa, %rcx
   5cb1a:      	je	0x5cb30 <f.17+0x1c0>
   5cb1c:      	testq	%rcx, %rcx
   5cb1f:      	jne	0x5cb00 <f.17+0x190>
   5cb21:      	nopw	%cs:(%rax,%rax)
   5cb30:      	cmpq	$0xa, %rcx
   5cb34:      	jne	0x5ccf9 <f.17+0x389>
   5cb3a:      	movq	%rdi, 0x30(%rsp)
   5cb3f:      	movq	0x8(%rdi), %rdi
   5cb43:      	movq	%rdi, 0x38(%rsp)
   5cb48:      	testq	%rdi, %rdi
   5cb4b:      	je	0x5ccf9 <f.17+0x389>
   5cb51:      	movl	0x8(%rdi), %eax
   5cb54:      	cmpq	%rax, %rbx
   5cb57:      	jae	0x5ccf9 <f.17+0x389>
   5cb5d:      	movq	0x18(%rdi), %r14
   5cb61:      	movq	%r14, 0x40(%rsp)
   5cb66:      	movq	%rdi, 0x48(%rsp)
   5cb6b:      	movq	$0x5, 0x20(%rsp)
   5cb74:      	movl	%ebx, %esi
   5cb76:      	callq	0x5b4e0 <f.4>
   5cb7b:      	subq	$0x8, %rsp
   5cb7f:      	movq	%r14, 0x40(%rsp)
   5cb84:      	movq	$0x4, 0x20(%rsp)
   5cb8d:      	movq	%r14, %rdi
   5cb90:      	movl	%eax, %esi
   5cb92:      	callq	0x5cd00 <f.3>
   5cb97:      	subq	$0x8, %rsp
   5cb9b:      	movq	$0x3, 0x20(%rsp)
   5cba4:      	movl	%eax, %edi
   5cba6:      	callq	0x56c90 <write_character>
   5cbab:      	movq	0x30(%rsp), %rdi
   5cbb0:      	testq	%rdi, %rdi
   5cbb3:      	je	0x5ccf9 <f.17+0x389>
   5cbb9:      	movq	0x10(%rdi), %rax
   5cbbd:      	testq	%rax, %rax
   5cbc0:      	je	0x5ccf9 <f.17+0x389>
   5cbc6:      	cmpl	$0x0, 0x8(%rax)
   5cbca:      	je	0x5ccf9 <f.17+0x389>
   5cbd0:      	cmpq	$0x0, 0x10(%rax)
   5cbd5:      	je	0x5ccf9 <f.17+0x389>
   5cbdb:      	xorl	%eax, %eax
   5cbdd:      	cmpq	$0x0, 0x18(%rsp)
   5cbe3:      	sete	%al
   5cbe6:      	movq	%r15, %rcx
   5cbe9:      	cmoveq	%r13, %rcx
   5cbed:      	addq	0x6704(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cbf4:      	movq	(%rcx), %rdx
   5cbf7:      	movq	$0x5, 0x18(%rsp)
   5cc00:      	movq	$0x0, 0x20(%rsp)
   5cc09:      	movq	%rdx, 0x10(%rsp)
   5cc0e:      	movq	%r15, 0x6703(%rip)      # 0x63318 <native_roots.0>
   5cc15:      	movq	%rax, 0x66dc(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cc1c:      	movq	0x66dd(%rip), %rcx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5cc23:      	cmpq	%rcx, %rax
   5cc26:      	cmovaq	%rax, %rcx
   5cc2a:      	movq	%rcx, 0x66cf(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5cc31:      	movq	%rdi, 0x28(%rsp)
   5cc36:      	xorps	%xmm0, %xmm0
   5cc39:      	movups	%xmm0, (%r12)
   5cc3e:      	testb	$0x1, %dil
   5cc42:      	jne	0x5ccf9 <f.17+0x389>
   5cc48:      	movq	0x66c1(%rip), %rsi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5cc4f:      	testq	%rsi, %rsi
   5cc52:      	je	0x5ccf9 <f.17+0x389>
   5cc58:      	movq	(%rdi), %rcx
   5cc5b:      	movq	%rcx, %r8
   5cc5e:      	testq	%rcx, %rcx
   5cc61:      	je	0x5ca90 <f.17+0x120>
   5cc67:      	movq	%rcx, %r8
   5cc6a:      	cmpq	$0xa, %rcx
   5cc6e:      	je	0x5ca90 <f.17+0x120>
   5cc74:      	movq	0x168(%rsi), %r9
   5cc7b:      	movq	%rcx, %r8
   5cc7e:      	shrq	$0x2, %r8
   5cc82:      	leaq	-0x1(%r8), %r10
   5cc86:      	cmpq	%r9, %r10
   5cc89:      	jae	0x5ccf9 <f.17+0x389>
   5cc8b:      	movq	0x160(%rsi), %r10
   5cc92:      	movq	-0x8(%r10,%r8,8), %r8
   5cc97:      	testq	%r8, %r8
   5cc9a:      	je	0x5ca90 <f.17+0x120>
   5cca0:      	cmpq	$0xa, %r8
   5cca4:      	je	0x5ca90 <f.17+0x120>
   5ccaa:      	nopw	(%rax,%rax)
   5ccb0:      	shrq	$0x2, %r8
   5ccb4:      	leaq	-0x1(%r8), %r11
   5ccb8:      	cmpq	%r9, %r11
   5ccbb:      	jae	0x5ccf9 <f.17+0x389>
   5ccbd:      	movq	-0x8(%r10,%r8,8), %r8
   5ccc2:      	cmpq	$0xa, %r8
   5ccc6:      	je	0x5ca90 <f.17+0x120>
   5cccc:      	testq	%r8, %r8
   5cccf:      	jne	0x5ccb0 <f.17+0x340>
   5ccd1:      	jmp	0x5ca90 <f.17+0x120>
   5ccd6:      	movq	%rdx, 0x663b(%rip)      # 0x63318 <native_roots.0>
   5ccdd:      	decq	%rax
   5cce0:      	movq	%rax, 0x6611(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cce7:      	xorl	%eax, %eax
   5cce9:      	addq	$0x50, %rsp
   5cced:      	popq	%rbx
   5ccee:      	popq	%r12
   5ccf0:      	popq	%r13
   5ccf2:      	popq	%r14
   5ccf4:      	popq	%r15
   5ccf6:      	retq	$0x8
   5ccf9:      	callq	0x55770 <native_trap>
   5ccfe:      	int3
   5ccff:      	int3

000000000005cd00 <f.3>:
   5cd00:      	pushq	%rax
   5cd01:      	testq	%rdi, %rdi
   5cd04:      	je	0x5cd72 <f.3+0x72>
   5cd06:      	testb	$0x1, %dil
   5cd0a:      	jne	0x5cd72 <f.3+0x72>
   5cd0c:      	movq	0x8(%rdi), %rdx
   5cd10:      	movl	%esi, %eax
   5cd12:      	cmpq	%rax, %rdx
   5cd15:      	jbe	0x5cd72 <f.3+0x72>
   5cd17:      	movzbl	0x10(%rdi,%rax), %eax
   5cd1c:      	testb	%al, %al
   5cd1e:      	jns	0x5cd6e <f.3+0x6e>
   5cd20:      	cmpb	$-0x10, %al
   5cd22:      	movl	$0x4, %r8d
   5cd28:      	sbbl	$0x0, %r8d
   5cd2c:      	cmpb	$-0x20, %al
   5cd2e:      	movl	$0x2, %ecx
   5cd33:      	cmovael	%r8d, %ecx
   5cd37:      	movl	$0x7f, %r8d
   5cd3d:      	shrl	%cl, %r8d
   5cd40:      	andl	%r8d, %eax
   5cd43:      	incl	%esi
   5cd45:      	decq	%rcx
   5cd48:      	nopl	(%rax,%rax)
   5cd50:      	movl	%esi, %esi
   5cd52:      	cmpq	%rsi, %rdx
   5cd55:      	jbe	0x5cd72 <f.3+0x72>
   5cd57:      	movzbl	0x10(%rdi,%rsi), %r8d
   5cd5d:      	andl	$0x3f, %r8d
   5cd61:      	shll	$0x6, %eax
   5cd64:      	orl	%r8d, %eax
   5cd67:      	incl	%esi
   5cd69:      	decq	%rcx
   5cd6c:      	jne	0x5cd50 <f.3+0x50>
   5cd6e:      	popq	%rcx
   5cd6f:      	retq	$0x8
   5cd72:      	callq	0x55770 <native_trap>
   5cd77:      	int3
   5cd78:      	int3
   5cd79:      	int3
   5cd7a:      	int3
   5cd7b:      	int3
   5cd7c:      	int3
   5cd7d:      	int3
   5cd7e:      	int3
   5cd7f:      	int3

000000000005cd80 <f.13>:
   5cd80:      	pushq	%r15
   5cd82:      	pushq	%r14
   5cd84:      	pushq	%r12
   5cd86:      	pushq	%rbx
   5cd87:      	subq	$0x48, %rsp
   5cd8b:      	movq	$0x4, 0x18(%rsp)
   5cd94:      	movq	$0x0, 0x20(%rsp)
   5cd9d:      	movq	0x6574(%rip), %rdx      # 0x63318 <native_roots.0>
   5cda4:      	movq	%rdx, 0x10(%rsp)
   5cda9:      	leaq	0x10(%rsp), %r14
   5cdae:      	movq	%r14, 0x6563(%rip)      # 0x63318 <native_roots.0>
   5cdb5:      	movq	0x653c(%rip), %rcx      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cdbc:      	incq	%rcx
   5cdbf:      	movq	%rcx, 0x6532(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cdc6:      	movq	0x6533(%rip), %rax      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5cdcd:      	cmpq	%rax, %rcx
   5cdd0:      	cmovaq	%rcx, %rax
   5cdd4:      	movq	%rax, 0x6525(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5cddb:      	movq	%rdi, 0x28(%rsp)
   5cde0:      	xorps	%xmm0, %xmm0
   5cde3:      	movups	%xmm0, 0x30(%rsp)
   5cde8:      	testq	%rdi, %rdi
   5cdeb:      	je	0x5d099 <f.13+0x319>
   5cdf1:      	movl	%edi, %eax
   5cdf3:      	andl	$0x1, %eax
   5cdf6:      	jne	0x5d099 <f.13+0x319>
   5cdfc:      	movq	0x650d(%rip), %r8       # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5ce03:      	testq	%r8, %r8
   5ce06:      	je	0x5d099 <f.13+0x319>
   5ce0c:      	movq	%rsi, %rbx
   5ce0f:      	movq	(%rdi), %rax
   5ce12:      	testq	%rax, %rax
   5ce15:      	je	0x5ce71 <f.13+0xf1>
   5ce17:      	cmpq	$0x2a, %rax
   5ce1b:      	je	0x5ce71 <f.13+0xf1>
   5ce1d:      	movq	0x168(%r8), %rsi
   5ce24:      	shrq	$0x2, %rax
   5ce28:      	leaq	-0x1(%rax), %r9
   5ce2c:      	cmpq	%rsi, %r9
   5ce2f:      	jae	0x5d099 <f.13+0x319>
   5ce35:      	movq	0x160(%r8), %r8
   5ce3c:      	movq	-0x8(%r8,%rax,8), %rax
   5ce41:      	testq	%rax, %rax
   5ce44:      	je	0x5ce71 <f.13+0xf1>
   5ce46:      	cmpq	$0x2a, %rax
   5ce4a:      	je	0x5ce71 <f.13+0xf1>
   5ce4c:      	nopl	(%rax)
   5ce50:      	shrq	$0x2, %rax
   5ce54:      	leaq	-0x1(%rax), %r9
   5ce58:      	cmpq	%rsi, %r9
   5ce5b:      	jae	0x5d099 <f.13+0x319>
   5ce61:      	movq	-0x8(%r8,%rax,8), %rax
   5ce66:      	cmpq	$0x2a, %rax
   5ce6a:      	je	0x5ce71 <f.13+0xf1>
   5ce6c:      	testq	%rax, %rax
   5ce6f:      	jne	0x5ce50 <f.13+0xd0>
   5ce71:      	cmpq	$0x2a, %rax
   5ce75:      	jne	0x5d099 <f.13+0x319>
   5ce7b:      	leaq	0x30(%rsp), %r15
   5ce80:      	leaq	0x6491(%rip), %r12      # 0x63318 <native_roots.0>
   5ce87:      	jmp	0x5ce9d <f.13+0x11d>
   5ce89:      	nopl	(%rax)
   5ce90:      	incq	%rbx
   5ce93:      	cmpq	$0x2a, %rax
   5ce97:      	jne	0x5d099 <f.13+0x319>
   5ce9d:      	movq	%rdi, 0x30(%rsp)
   5cea2:      	cmpq	%rbx, 0x10(%rdi)
   5cea6:      	je	0x5d076 <f.13+0x2f6>
   5ceac:      	movq	0x8(%rdi), %rax
   5ceb0:      	testq	%rax, %rax
   5ceb3:      	je	0x5d099 <f.13+0x319>
   5ceb9:      	movq	0x8(%rax), %rax
   5cebd:      	movq	%rax, 0x38(%rsp)
   5cec2:      	testq	%rax, %rax
   5cec5:      	je	0x5d099 <f.13+0x319>
   5cecb:      	movq	0x8(%rax), %rcx
   5cecf:      	testq	%rcx, %rcx
   5ced2:      	je	0x5d099 <f.13+0x319>
   5ced8:      	movq	0x10(%rax), %rdi
   5cedc:      	movq	0x8(%rcx), %rax
   5cee0:      	movq	%rdi, 0x40(%rsp)
   5cee5:      	movq	$0x4, 0x20(%rsp)
   5ceee:      	movl	$0x80, %esi
   5cef3:      	callq	*%rax
   5cef5:      	subq	$0x8, %rsp
   5cef9:      	movq	%rbx, %rcx
   5cefc:      	shrq	$0x20, %rcx
   5cf00:      	jne	0x5d099 <f.13+0x319>
   5cf06:      	cmpq	$0x100, %rax            # imm = 0x100
   5cf0c:      	jae	0x5d099 <f.13+0x319>
   5cf12:      	movq	0x30(%rsp), %rcx
   5cf17:      	testq	%rcx, %rcx
   5cf1a:      	je	0x5d099 <f.13+0x319>
   5cf20:      	movq	0x18(%rcx), %rcx
   5cf24:      	testq	%rcx, %rcx
   5cf27:      	je	0x5d099 <f.13+0x319>
   5cf2d:      	movq	0x8(%rcx), %rcx
   5cf31:      	testq	%rcx, %rcx
   5cf34:      	je	0x5d099 <f.13+0x319>
   5cf3a:      	testb	$0x1, %cl
   5cf3d:      	jne	0x5d099 <f.13+0x319>
   5cf43:      	cmpq	0x8(%rcx), %rbx
   5cf47:      	jae	0x5d099 <f.13+0x319>
   5cf4d:      	movb	%al, 0x10(%rcx,%rbx)
   5cf51:      	movq	0x30(%rsp), %rdi
   5cf56:      	testq	%rdi, %rdi
   5cf59:      	je	0x5d099 <f.13+0x319>
   5cf5f:      	movq	0x20(%rdi), %rax
   5cf63:      	testq	%rax, %rax
   5cf66:      	je	0x5d099 <f.13+0x319>
   5cf6c:      	cmpl	$0x0, 0x8(%rax)
   5cf70:      	je	0x5d099 <f.13+0x319>
   5cf76:      	cmpq	$0x0, 0x10(%rax)
   5cf7b:      	je	0x5d099 <f.13+0x319>
   5cf81:      	xorl	%ecx, %ecx
   5cf83:      	cmpq	$0x0, 0x18(%rsp)
   5cf89:      	sete	%cl
   5cf8c:      	movq	%r14, %rax
   5cf8f:      	cmoveq	%r12, %rax
   5cf93:      	addq	0x635e(%rip), %rcx      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cf9a:      	movq	(%rax), %rdx
   5cf9d:      	movq	$0x4, 0x18(%rsp)
   5cfa6:      	movq	$0x0, 0x20(%rsp)
   5cfaf:      	movq	%rdx, 0x10(%rsp)
   5cfb4:      	movq	%r14, 0x635d(%rip)      # 0x63318 <native_roots.0>
   5cfbb:      	movq	%rcx, 0x6336(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5cfc2:      	movq	0x6337(%rip), %rax      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5cfc9:      	cmpq	%rax, %rcx
   5cfcc:      	cmovaq	%rcx, %rax
   5cfd0:      	movq	%rax, 0x6329(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5cfd7:      	movq	%rdi, 0x28(%rsp)
   5cfdc:      	xorps	%xmm0, %xmm0
   5cfdf:      	movups	%xmm0, (%r15)
   5cfe3:      	testb	$0x1, %dil
   5cfe7:      	jne	0x5d099 <f.13+0x319>
   5cfed:      	movq	0x631c(%rip), %r8       # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5cff4:      	testq	%r8, %r8
   5cff7:      	je	0x5d099 <f.13+0x319>
   5cffd:      	movq	(%rdi), %rax
   5d000:      	testq	%rax, %rax
   5d003:      	je	0x5ce90 <f.13+0x110>
   5d009:      	cmpq	$0x2a, %rax
   5d00d:      	je	0x5ce90 <f.13+0x110>
   5d013:      	movq	0x168(%r8), %rsi
   5d01a:      	shrq	$0x2, %rax
   5d01e:      	leaq	-0x1(%rax), %r9
   5d022:      	cmpq	%rsi, %r9
   5d025:      	jae	0x5d099 <f.13+0x319>
   5d027:      	movq	0x160(%r8), %r8
   5d02e:      	movq	-0x8(%r8,%rax,8), %rax
   5d033:      	testq	%rax, %rax
   5d036:      	je	0x5ce90 <f.13+0x110>
   5d03c:      	cmpq	$0x2a, %rax
   5d040:      	je	0x5ce90 <f.13+0x110>
   5d046:      	nopw	%cs:(%rax,%rax)
   5d050:      	shrq	$0x2, %rax
   5d054:      	leaq	-0x1(%rax), %r9
   5d058:      	cmpq	%rsi, %r9
   5d05b:      	jae	0x5d099 <f.13+0x319>
   5d05d:      	movq	-0x8(%r8,%rax,8), %rax
   5d062:      	cmpq	$0x2a, %rax
   5d066:      	je	0x5ce90 <f.13+0x110>
   5d06c:      	testq	%rax, %rax
   5d06f:      	jne	0x5d050 <f.13+0x2d0>
   5d071:      	jmp	0x5ce90 <f.13+0x110>
   5d076:      	movq	0x18(%rdi), %rax
   5d07a:      	movq	%rdx, 0x6297(%rip)      # 0x63318 <native_roots.0>
   5d081:      	decq	%rcx
   5d084:      	movq	%rcx, 0x626d(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d08b:      	addq	$0x48, %rsp
   5d08f:      	popq	%rbx
   5d090:      	popq	%r12
   5d092:      	popq	%r14
   5d094:      	popq	%r15
   5d096:      	retq	$0x8
   5d099:      	callq	0x55770 <native_trap>
   5d09e:      	int3
   5d09f:      	int3

000000000005d0a0 <f.12>:
   5d0a0:      	pushq	%rbp
   5d0a1:      	pushq	%r15
   5d0a3:      	pushq	%r14
   5d0a5:      	pushq	%r13
   5d0a7:      	pushq	%r12
   5d0a9:      	pushq	%rbx
   5d0aa:      	subq	$0x78, %rsp
   5d0ae:      	movq	$0xa, 0x18(%rsp)
   5d0b7:      	movq	$0x0, 0x20(%rsp)
   5d0c0:      	movq	0x6251(%rip), %rax      # 0x63318 <native_roots.0>
   5d0c7:      	movq	%rax, 0x10(%rsp)
   5d0cc:      	movq	0x6225(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d0d3:      	incq	%rax
   5d0d6:      	movq	%rax, 0x621b(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d0dd:      	movq	0x621c(%rip), %rcx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d0e4:      	cmpq	%rcx, %rax
   5d0e7:      	cmovbeq	%rcx, %rax
   5d0eb:      	leaq	0x10(%rsp), %rcx
   5d0f0:      	movq	%rcx, 0x6221(%rip)      # 0x63318 <native_roots.0>
   5d0f7:      	movq	%rax, 0x6202(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d0fe:      	movq	%rdi, 0x28(%rsp)
   5d103:      	xorps	%xmm0, %xmm0
   5d106:      	movups	%xmm0, 0x30(%rsp)
   5d10b:      	movups	%xmm0, 0x40(%rsp)
   5d110:      	testq	%rdi, %rdi
   5d113:      	je	0x5d5c0 <f.12+0x520>
   5d119:      	movl	%edi, %eax
   5d11b:      	andl	$0x1, %eax
   5d11e:      	jne	0x5d5c0 <f.12+0x520>
   5d124:      	movq	0x61e5(%rip), %rdx      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d12b:      	testq	%rdx, %rdx
   5d12e:      	je	0x5d5c0 <f.12+0x520>
   5d134:      	movq	(%rdi), %rax
   5d137:      	testq	%rax, %rax
   5d13a:      	je	0x5d1a1 <f.12+0x101>
   5d13c:      	cmpq	$0x4a, %rax
   5d140:      	je	0x5d1a1 <f.12+0x101>
   5d142:      	movq	0x168(%rdx), %rcx
   5d149:      	shrq	$0x2, %rax
   5d14d:      	leaq	-0x1(%rax), %r8
   5d151:      	cmpq	%rcx, %r8
   5d154:      	jae	0x5d5c0 <f.12+0x520>
   5d15a:      	movq	0x160(%rdx), %rdx
   5d161:      	movq	-0x8(%rdx,%rax,8), %rax
   5d166:      	testq	%rax, %rax
   5d169:      	je	0x5d1a1 <f.12+0x101>
   5d16b:      	cmpq	$0x4a, %rax
   5d16f:      	je	0x5d1a1 <f.12+0x101>
   5d171:      	nopw	%cs:(%rax,%rax)
   5d180:      	shrq	$0x2, %rax
   5d184:      	leaq	-0x1(%rax), %r8
   5d188:      	cmpq	%rcx, %r8
   5d18b:      	jae	0x5d5c0 <f.12+0x520>
   5d191:      	movq	-0x8(%rdx,%rax,8), %rax
   5d196:      	cmpq	$0x4a, %rax
   5d19a:      	je	0x5d1a1 <f.12+0x101>
   5d19c:      	testq	%rax, %rax
   5d19f:      	jne	0x5d180 <f.12+0xe0>
   5d1a1:      	cmpq	$0x4a, %rax
   5d1a5:      	jne	0x5d5c0 <f.12+0x520>
   5d1ab:      	movq	%rdi, 0x38(%rsp)
   5d1b0:      	movq	0x8(%rdi), %rax
   5d1b4:      	testq	%rax, %rax
   5d1b7:      	je	0x5d5c0 <f.12+0x520>
   5d1bd:      	movq	0x8(%rax), %rax
   5d1c1:      	movq	%rax, 0x40(%rsp)
   5d1c6:      	testq	%rax, %rax
   5d1c9:      	je	0x5d5c0 <f.12+0x520>
   5d1cf:      	movq	0x8(%rax), %rcx
   5d1d3:      	testq	%rcx, %rcx
   5d1d6:      	je	0x5d5c0 <f.12+0x520>
   5d1dc:      	movq	0x10(%rax), %rdi
   5d1e0:      	movq	0x8(%rcx), %rax
   5d1e4:      	movq	%rdi, 0x50(%rsp)
   5d1e9:      	movq	$0x6, 0x20(%rsp)
   5d1f2:      	callq	*%rax
   5d1f4:      	subq	$0x8, %rsp
   5d1f8:      	cmpb	$0x0, 0x61f1(%rip)      # 0x633f0 <g.4>
   5d1ff:      	je	0x5d5c0 <f.12+0x520>
   5d205:      	cmpq	$0x0, 0x61db(%rip)      # 0x633e8 <g.3>
   5d20d:      	je	0x5d5c0 <f.12+0x520>
   5d213:      	movq	%rax, %r14
   5d216:      	shrq	$0x20, %rax
   5d21a:      	jne	0x5d5c0 <f.12+0x520>
   5d220:      	movq	$0x5, 0x20(%rsp)
   5d229:      	movq	0x60e0(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d230:      	testq	%rdi, %rdi
   5d233:      	je	0x5d5c0 <f.12+0x520>
   5d239:      	movq	0x178(%rdi), %rcx
   5d240:      	testq	%rcx, %rcx
   5d243:      	je	0x5d282 <f.12+0x1e2>
   5d245:      	movq	0x170(%rdi), %rax
   5d24c:      	incq	%rax
   5d24f:      	movq	%rax, 0x170(%rdi)
   5d256:      	movq	%rax, %rdx
   5d259:      	orq	%rcx, %rdx
   5d25c:      	shrq	$0x20, %rdx
   5d260:      	je	0x5d578 <f.12+0x4d8>
   5d266:      	xorl	%edx, %edx
   5d268:      	divq	%rcx
   5d26b:      	testq	%rdx, %rdx
   5d26e:      	jne	0x5d282 <f.12+0x1e2>
   5d270:      	movq	0x60a1(%rip), %rsi      # 0x63318 <native_roots.0>
   5d277:      	movq	%rdi, %rbx
   5d27a:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d27f:      	movq	%rbx, %rdi
   5d282:      	movq	0x608f(%rip), %rdx      # 0x63318 <native_roots.0>
   5d289:      	movl	$0x18, %esi
   5d28e:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d293:      	testq	%rax, %rax
   5d296:      	je	0x5d5c5 <f.12+0x525>
   5d29c:      	movq	%rax, %rbx
   5d29f:      	movq	$0x66, (%rax)
   5d2a6:      	movl	$0x0, 0x8(%rax)
   5d2ad:      	movq	$0x0, 0x10(%rax)
   5d2b5:      	movq	%rax, 0x30(%rsp)
   5d2ba:      	movq	0x38(%rsp), %rax
   5d2bf:      	testq	%rax, %rax
   5d2c2:      	je	0x5d5c0 <f.12+0x520>
   5d2c8:      	movq	0x8(%rax), %rbp
   5d2cc:      	movq	%rbp, 0x50(%rsp)
   5d2d1:      	leaq	0x3d90(%rip), %r15      # 0x61068 <ref.13>
   5d2d8:      	movq	%r15, 0x58(%rsp)
   5d2dd:      	movq	%rbx, 0x60(%rsp)
   5d2e2:      	movq	$0x8, 0x20(%rsp)
   5d2eb:      	movl	%r14d, %edi
   5d2ee:      	callq	0x58e20 <native_array_new>
   5d2f3:      	movq	%rax, 0x50(%rsp)
   5d2f8:      	movq	%rbp, 0x58(%rsp)
   5d2fd:      	movq	%r15, 0x60(%rsp)
   5d302:      	movq	%rbx, 0x68(%rsp)
   5d307:      	movq	$0x9, 0x20(%rsp)
   5d310:      	movq	0x5ff9(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d317:      	testq	%rdi, %rdi
   5d31a:      	je	0x5d5c0 <f.12+0x520>
   5d320:      	movq	%rax, %r12
   5d323:      	movq	0x178(%rdi), %rcx
   5d32a:      	testq	%rcx, %rcx
   5d32d:      	je	0x5d36c <f.12+0x2cc>
   5d32f:      	movq	0x170(%rdi), %rax
   5d336:      	incq	%rax
   5d339:      	movq	%rax, 0x170(%rdi)
   5d340:      	movq	%rax, %rdx
   5d343:      	orq	%rcx, %rdx
   5d346:      	shrq	$0x20, %rdx
   5d34a:      	je	0x5d58a <f.12+0x4ea>
   5d350:      	xorl	%edx, %edx
   5d352:      	divq	%rcx
   5d355:      	testq	%rdx, %rdx
   5d358:      	jne	0x5d36c <f.12+0x2cc>
   5d35a:      	movq	0x5fb7(%rip), %rsi      # 0x63318 <native_roots.0>
   5d361:      	movq	%rdi, %r15
   5d364:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d369:      	movq	%r15, %rdi
   5d36c:      	movq	0x5fa5(%rip), %rdx      # 0x63318 <native_roots.0>
   5d373:      	movl	$0x10, %esi
   5d378:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d37d:      	testq	%rax, %rax
   5d380:      	je	0x5d5c5 <f.12+0x525>
   5d386:      	movq	%rax, %r15
   5d389:      	movq	$0x82, (%rax)
   5d390:      	movq	%r12, 0x8(%rax)
   5d394:      	movq	0x30(%rsp), %r13
   5d399:      	movq	%r13, 0x50(%rsp)
   5d39e:      	movq	%rax, 0x58(%rsp)
   5d3a3:      	movq	%rbp, 0x60(%rsp)
   5d3a8:      	leaq	0x3cb9(%rip), %rax      # 0x61068 <ref.13>
   5d3af:      	movq	%rax, 0x68(%rsp)
   5d3b4:      	movq	%rbx, 0x70(%rsp)
   5d3b9:      	movq	$0xa, 0x20(%rsp)
   5d3c2:      	movq	0x5f47(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d3c9:      	testq	%rdi, %rdi
   5d3cc:      	je	0x5d5c0 <f.12+0x520>
   5d3d2:      	movq	0x178(%rdi), %rcx
   5d3d9:      	testq	%rcx, %rcx
   5d3dc:      	je	0x5d41b <f.12+0x37b>
   5d3de:      	movq	0x170(%rdi), %rax
   5d3e5:      	incq	%rax
   5d3e8:      	movq	%rax, 0x170(%rdi)
   5d3ef:      	movq	%rax, %rdx
   5d3f2:      	orq	%rcx, %rdx
   5d3f5:      	shrq	$0x20, %rdx
   5d3f9:      	je	0x5d59c <f.12+0x4fc>
   5d3ff:      	xorl	%edx, %edx
   5d401:      	divq	%rcx
   5d404:      	testq	%rdx, %rdx
   5d407:      	jne	0x5d41b <f.12+0x37b>
   5d409:      	movq	0x5f08(%rip), %rsi      # 0x63318 <native_roots.0>
   5d410:      	movq	%rdi, %r12
   5d413:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d418:      	movq	%r12, %rdi
   5d41b:      	movq	0x5ef6(%rip), %rdx      # 0x63318 <native_roots.0>
   5d422:      	movl	$0x28, %esi
   5d427:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d42c:      	testq	%rax, %rax
   5d42f:      	je	0x5d5c5 <f.12+0x525>
   5d435:      	movq	%rax, %r12
   5d438:      	movq	$0x2a, (%rax)
   5d43f:      	movq	%rbp, 0x8(%rax)
   5d443:      	movq	%r14, 0x10(%rax)
   5d447:      	movq	%r15, 0x18(%rax)
   5d44b:      	movq	%r13, 0x20(%rax)
   5d44f:      	movq	%rax, 0x50(%rsp)
   5d454:      	leaq	0x3c0d(%rip), %rax      # 0x61068 <ref.13>
   5d45b:      	movq	%rax, 0x58(%rsp)
   5d460:      	movq	%rbx, 0x60(%rsp)
   5d465:      	movq	$0x8, 0x20(%rsp)
   5d46e:      	movq	0x5e9b(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d475:      	testq	%rdi, %rdi
   5d478:      	je	0x5d5c0 <f.12+0x520>
   5d47e:      	movq	0x178(%rdi), %rcx
   5d485:      	testq	%rcx, %rcx
   5d488:      	je	0x5d4c7 <f.12+0x427>
   5d48a:      	movq	0x170(%rdi), %rax
   5d491:      	incq	%rax
   5d494:      	movq	%rax, 0x170(%rdi)
   5d49b:      	movq	%rax, %rdx
   5d49e:      	orq	%rcx, %rdx
   5d4a1:      	shrq	$0x20, %rdx
   5d4a5:      	je	0x5d5ae <f.12+0x50e>
   5d4ab:      	xorl	%edx, %edx
   5d4ad:      	divq	%rcx
   5d4b0:      	testq	%rdx, %rdx
   5d4b3:      	jne	0x5d4c7 <f.12+0x427>
   5d4b5:      	movq	0x5e5c(%rip), %rsi      # 0x63318 <native_roots.0>
   5d4bc:      	movq	%rdi, %r14
   5d4bf:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5d4c4:      	movq	%r14, %rdi
   5d4c7:      	movq	0x5e4a(%rip), %rdx      # 0x63318 <native_roots.0>
   5d4ce:      	movl	$0x18, %esi
   5d4d3:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5d4d8:      	testq	%rax, %rax
   5d4db:      	je	0x5d5c5 <f.12+0x525>
   5d4e1:      	movq	$0xc2, (%rax)
   5d4e8:      	leaq	0x3b79(%rip), %rcx      # 0x61068 <ref.13>
   5d4ef:      	movq	%rcx, 0x8(%rax)
   5d4f3:      	movq	%r12, 0x10(%rax)
   5d4f7:      	movq	%rax, 0x10(%rbx)
   5d4fb:      	movq	0x30(%rsp), %rax
   5d500:      	testq	%rax, %rax
   5d503:      	je	0x5d5c0 <f.12+0x520>
   5d509:      	movl	$0x1, 0x8(%rax)
   5d510:      	movq	0x30(%rsp), %rax
   5d515:      	testq	%rax, %rax
   5d518:      	je	0x5d5c0 <f.12+0x520>
   5d51e:      	cmpl	$0x0, 0x8(%rax)
   5d522:      	je	0x5d5c0 <f.12+0x520>
   5d528:      	movq	0x10(%rax), %rax
   5d52c:      	testq	%rax, %rax
   5d52f:      	je	0x5d5c0 <f.12+0x520>
   5d535:      	movq	%rax, 0x48(%rsp)
   5d53a:      	movq	0x8(%rax), %rcx
   5d53e:      	testq	%rcx, %rcx
   5d541:      	je	0x5d5c0 <f.12+0x520>
   5d543:      	movq	0x10(%rax), %rdi
   5d547:      	movq	0x8(%rcx), %rax
   5d54b:      	cmpq	$0x0, 0x18(%rsp)
   5d551:      	je	0x5d566 <f.12+0x4c6>
   5d553:      	movq	0x10(%rsp), %rcx
   5d558:      	movq	%rcx, 0x5db9(%rip)      # 0x63318 <native_roots.0>
   5d55f:      	decq	0x5d92(%rip)            # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d566:      	xorl	%esi, %esi
   5d568:      	addq	$0x78, %rsp
   5d56c:      	popq	%rbx
   5d56d:      	popq	%r12
   5d56f:      	popq	%r13
   5d571:      	popq	%r14
   5d573:      	popq	%r15
   5d575:      	popq	%rbp
   5d576:      	jmpq	*%rax
   5d578:      	xorl	%edx, %edx
   5d57a:      	divl	%ecx
   5d57c:      	testq	%rdx, %rdx
   5d57f:      	jne	0x5d282 <f.12+0x1e2>
   5d585:      	jmp	0x5d270 <f.12+0x1d0>
   5d58a:      	xorl	%edx, %edx
   5d58c:      	divl	%ecx
   5d58e:      	testq	%rdx, %rdx
   5d591:      	jne	0x5d36c <f.12+0x2cc>
   5d597:      	jmp	0x5d35a <f.12+0x2ba>
   5d59c:      	xorl	%edx, %edx
   5d59e:      	divl	%ecx
   5d5a0:      	testq	%rdx, %rdx
   5d5a3:      	jne	0x5d41b <f.12+0x37b>
   5d5a9:      	jmp	0x5d409 <f.12+0x369>
   5d5ae:      	xorl	%edx, %edx
   5d5b0:      	divl	%ecx
   5d5b2:      	testq	%rdx, %rdx
   5d5b5:      	jne	0x5d4c7 <f.12+0x427>
   5d5bb:      	jmp	0x5d4b5 <f.12+0x415>
   5d5c0:      	callq	0x55770 <native_trap>
   5d5c5:      	leaq	-0x54270(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5d5cc:      	movl	$0x2f, %esi
   5d5d1:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5d5d6:      	int3
   5d5d7:      	int3
   5d5d8:      	int3
   5d5d9:      	int3
   5d5da:      	int3
   5d5db:      	int3
   5d5dc:      	int3
   5d5dd:      	int3
   5d5de:      	int3
   5d5df:      	int3

000000000005d5e0 <f.14>:
   5d5e0:      	pushq	%r15
   5d5e2:      	pushq	%r14
   5d5e4:      	pushq	%r13
   5d5e6:      	pushq	%r12
   5d5e8:      	pushq	%rbx
   5d5e9:      	subq	$0x60, %rsp
   5d5ed:      	movq	%rsi, %rbx
   5d5f0:      	movq	$0x3, 0x38(%rsp)
   5d5f9:      	movq	$0x0, 0x40(%rsp)
   5d602:      	movq	0x5d0f(%rip), %rax      # 0x63318 <native_roots.0>
   5d609:      	movq	%rax, 0x30(%rsp)
   5d60e:      	leaq	0x30(%rsp), %r15
   5d613:      	movq	%r15, 0x5cfe(%rip)      # 0x63318 <native_roots.0>
   5d61a:      	movq	0x5cd7(%rip), %rcx      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d621:      	leaq	0x1(%rcx), %rdx
   5d625:      	movq	%rdx, 0x5ccc(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d62c:      	movq	0x5ccd(%rip), %rsi      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d633:      	cmpq	%rsi, %rdx
   5d636:      	cmovaq	%rdx, %rsi
   5d63a:      	movq	%rsi, 0x5cbf(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d641:      	movq	%rdi, 0x48(%rsp)
   5d646:      	movq	$0x0, 0x50(%rsp)
   5d64f:      	testq	%rdi, %rdi
   5d652:      	je	0x5d961 <f.14+0x381>
   5d658:      	movl	%edi, %edx
   5d65a:      	andl	$0x1, %edx
   5d65d:      	jne	0x5d961 <f.14+0x381>
   5d663:      	movq	0x5ca6(%rip), %r8       # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d66a:      	testq	%r8, %r8
   5d66d:      	je	0x5d919 <f.14+0x339>
   5d673:      	movq	(%rdi), %rdx
   5d676:      	testq	%rdx, %rdx
   5d679:      	je	0x5d6d1 <f.14+0xf1>
   5d67b:      	cmpq	$0x2e, %rdx
   5d67f:      	je	0x5d6d1 <f.14+0xf1>
   5d681:      	movq	0x168(%r8), %rsi
   5d688:      	shrq	$0x2, %rdx
   5d68c:      	leaq	-0x1(%rdx), %r9
   5d690:      	cmpq	%rsi, %r9
   5d693:      	jae	0x5d919 <f.14+0x339>
   5d699:      	movq	0x160(%r8), %r8
   5d6a0:      	movq	-0x8(%r8,%rdx,8), %rdx
   5d6a5:      	testq	%rdx, %rdx
   5d6a8:      	je	0x5d6d1 <f.14+0xf1>
   5d6aa:      	cmpq	$0x2e, %rdx
   5d6ae:      	je	0x5d6d1 <f.14+0xf1>
   5d6b0:      	shrq	$0x2, %rdx
   5d6b4:      	leaq	-0x1(%rdx), %r9
   5d6b8:      	cmpq	%rsi, %r9
   5d6bb:      	jae	0x5d919 <f.14+0x339>
   5d6c1:      	movq	-0x8(%r8,%rdx,8), %rdx
   5d6c6:      	cmpq	$0x2e, %rdx
   5d6ca:      	je	0x5d6d1 <f.14+0xf1>
   5d6cc:      	testq	%rdx, %rdx
   5d6cf:      	jne	0x5d6b0 <f.14+0xd0>
   5d6d1:      	cmpq	$0x4000, %rbx           # imm = 0x4000
   5d6d8:      	jge	0x5d72e <f.14+0x14e>
   5d6da:      	cmpq	$0x2e, %rdx
   5d6de:      	jne	0x5d919 <f.14+0x339>
   5d6e4:      	testq	%rdi, %rdi
   5d6e7:      	je	0x5d919 <f.14+0x339>
   5d6ed:      	movq	0x8(%rdi), %rdx
   5d6f1:      	testq	%rdx, %rdx
   5d6f4:      	je	0x5d919 <f.14+0x339>
   5d6fa:      	movq	0x8(%rdx), %rdx
   5d6fe:      	testq	%rdx, %rdx
   5d701:      	je	0x5d919 <f.14+0x339>
   5d707:      	movq	0x10(%rdx), %rdi
   5d70b:      	movq	%rax, 0x5c06(%rip)      # 0x63318 <native_roots.0>
   5d712:      	movq	%rcx, 0x5bdf(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d719:      	movq	%rbx, %rsi
   5d71c:      	addq	$0x60, %rsp
   5d720:      	popq	%rbx
   5d721:      	popq	%r12
   5d723:      	popq	%r13
   5d725:      	popq	%r14
   5d727:      	popq	%r15
   5d729:      	jmp	0x5d970 <f.16>
   5d72e:      	cmpq	$0x2e, %rdx
   5d732:      	jne	0x5d919 <f.14+0x339>
   5d738:      	movq	%rdi, 0x50(%rsp)
   5d73d:      	testq	%rdi, %rdi
   5d740:      	je	0x5d919 <f.14+0x339>
   5d746:      	movq	0x8(%rdi), %rax
   5d74a:      	testq	%rax, %rax
   5d74d:      	je	0x5d919 <f.14+0x339>
   5d753:      	movq	0x8(%rax), %rax
   5d757:      	testq	%rax, %rax
   5d75a:      	je	0x5d919 <f.14+0x339>
   5d760:      	movq	0x10(%rax), %rdi
   5d764:      	movq	%rdi, 0x58(%rsp)
   5d769:      	movq	$0x3, 0x40(%rsp)
   5d772:      	movl	$0x4000, %esi           # imm = 0x4000
   5d777:      	callq	0x5d970 <f.16>
   5d77c:      	subq	$0x8, %rsp
   5d780:      	movq	%rax, %r14
   5d783:      	movq	0x50(%rsp), %rax
   5d788:      	testq	%rax, %rax
   5d78b:      	je	0x5d919 <f.14+0x339>
   5d791:      	movq	0x10(%rax), %rax
   5d795:      	testq	%rax, %rax
   5d798:      	je	0x5d919 <f.14+0x339>
   5d79e:      	cmpl	$0x0, 0x8(%rax)
   5d7a2:      	je	0x5d919 <f.14+0x339>
   5d7a8:      	movq	0x10(%rax), %rax
   5d7ac:      	testq	%rax, %rax
   5d7af:      	je	0x5d919 <f.14+0x339>
   5d7b5:      	movq	0x8(%rax), %rdx
   5d7b9:      	xorl	%ecx, %ecx
   5d7bb:      	cmpq	$0x0, 0x38(%rsp)
   5d7c1:      	sete	%cl
   5d7c4:      	leaq	0x5b4d(%rip), %r12      # 0x63318 <native_roots.0>
   5d7cb:      	cmoveq	%r12, %r15
   5d7cf:      	addq	0x5b22(%rip), %rcx      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d7d6:      	movq	(%r15), %rsi
   5d7d9:      	movq	$0x2, 0x10(%rsp)
   5d7e2:      	movq	$0x0, 0x18(%rsp)
   5d7eb:      	movq	%rsi, 0x8(%rsp)
   5d7f0:      	leaq	0x8(%rsp), %r15
   5d7f5:      	movq	%r15, 0x5b1c(%rip)      # 0x63318 <native_roots.0>
   5d7fc:      	movq	%rcx, 0x5af5(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d803:      	movq	0x5af6(%rip), %rax      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d80a:      	cmpq	%rax, %rcx
   5d80d:      	cmovaq	%rcx, %rax
   5d811:      	movq	%rax, 0x5ae8(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d818:      	movq	%rdx, 0x20(%rsp)
   5d81d:      	cmpb	$0x1, 0x5c1c(%rip)      # 0x63440 <g.14>
   5d824:      	jne	0x5d919 <f.14+0x339>
   5d82a:      	movq	%rbx, %r13
   5d82d:      	nopl	(%rax)
   5d830:      	cmpq	$0x0, 0x5c00(%rip)      # 0x63438 <g.13>
   5d838:      	je	0x5d919 <f.14+0x339>
   5d83e:      	shrq	$0xe, %r13
   5d842:      	je	0x5d91e <f.14+0x33e>
   5d848:      	testq	%rdx, %rdx
   5d84b:      	je	0x5d919 <f.14+0x339>
   5d851:      	movq	0x8(%rdx), %rax
   5d855:      	testq	%rax, %rax
   5d858:      	je	0x5d919 <f.14+0x339>
   5d85e:      	movq	0x8(%rax), %rax
   5d862:      	testq	%rax, %rax
   5d865:      	je	0x5d919 <f.14+0x339>
   5d86b:      	movq	0x10(%rax), %rdi
   5d86f:      	movq	%rdi, 0x28(%rsp)
   5d874:      	movq	$0x2, 0x18(%rsp)
   5d87d:      	movl	$0x4000, %esi           # imm = 0x4000
   5d882:      	callq	0x5d970 <f.16>
   5d887:      	subq	$0x8, %rsp
   5d88b:      	movq	0x20(%rsp), %rdx
   5d890:      	testq	%rdx, %rdx
   5d893:      	je	0x5d919 <f.14+0x339>
   5d899:      	movq	0x10(%rdx), %rcx
   5d89d:      	testq	%rcx, %rcx
   5d8a0:      	je	0x5d919 <f.14+0x339>
   5d8a2:      	cmpl	$0x0, 0x8(%rcx)
   5d8a6:      	je	0x5d919 <f.14+0x339>
   5d8a8:      	cmpq	$0x0, 0x10(%rcx)
   5d8ad:      	je	0x5d919 <f.14+0x339>
   5d8af:      	shlq	$0xe, %r14
   5d8b3:      	addq	%rax, %r14
   5d8b6:      	xorl	%ecx, %ecx
   5d8b8:      	cmpq	$0x0, 0x10(%rsp)
   5d8be:      	sete	%cl
   5d8c1:      	movq	%r15, %rax
   5d8c4:      	cmoveq	%r12, %rax
   5d8c8:      	addq	0x5a29(%rip), %rcx      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d8cf:      	movq	(%rax), %rsi
   5d8d2:      	movq	$0x2, 0x10(%rsp)
   5d8db:      	movq	$0x0, 0x18(%rsp)
   5d8e4:      	movq	%rsi, 0x8(%rsp)
   5d8e9:      	movq	%r15, 0x5a28(%rip)      # 0x63318 <native_roots.0>
   5d8f0:      	movq	0x5a09(%rip), %rax      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d8f7:      	cmpq	%rax, %rcx
   5d8fa:      	cmovaq	%rcx, %rax
   5d8fe:      	movq	%rcx, 0x59f3(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d905:      	movq	%rax, 0x59f4(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5d90c:      	cmpb	$0x0, 0x5b2d(%rip)      # 0x63440 <g.14>
   5d913:      	jne	0x5d830 <f.14+0x250>
   5d919:      	callq	0x55770 <native_trap>
   5d91e:      	movq	%r14, %rax
   5d921:      	orq	%rbx, %rax
   5d924:      	shrq	$0x20, %rax
   5d928:      	je	0x5d937 <f.14+0x357>
   5d92a:      	movq	%r14, %rax
   5d92d:      	cqto
   5d92f:      	idivq	%rbx
   5d932:      	movq	%rdx, %rax
   5d935:      	jmp	0x5d940 <f.14+0x360>
   5d937:      	movl	%r14d, %eax
   5d93a:      	xorl	%edx, %edx
   5d93c:      	divl	%ebx
   5d93e:      	movl	%edx, %eax
   5d940:      	movq	%rsi, 0x59d1(%rip)      # 0x63318 <native_roots.0>
   5d947:      	decq	%rcx
   5d94a:      	movq	%rcx, 0x59a7(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5d951:      	addq	$0x60, %rsp
   5d955:      	popq	%rbx
   5d956:      	popq	%r12
   5d958:      	popq	%r13
   5d95a:      	popq	%r14
   5d95c:      	popq	%r15
   5d95e:      	retq	$0x8
   5d961:      	cmpq	$0x4000, %rbx           # imm = 0x4000
   5d968:      	callq	0x55770 <native_trap>
   5d96d:      	int3
   5d96e:      	int3
   5d96f:      	int3

000000000005d970 <f.16>:
   5d970:      	pushq	%rax
   5d971:      	testq	%rdi, %rdi
   5d974:      	je	0x5db7f <f.16+0x20f>
   5d97a:      	movl	%edi, %eax
   5d97c:      	andl	$0x1, %eax
   5d97f:      	jne	0x5db7f <f.16+0x20f>
   5d985:      	movq	0x5984(%rip), %rax      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5d98c:      	testq	%rax, %rax
   5d98f:      	je	0x5db7f <f.16+0x20f>
   5d995:      	movq	(%rdi), %rdx
   5d998:      	cmpq	$0x3e, %rdx
   5d99c:      	sete	%cl
   5d99f:      	movl	%ecx, %r11d
   5d9a2:      	testq	%rdx, %rdx
   5d9a5:      	je	0x5d9ee <f.16+0x7e>
   5d9a7:      	movl	%ecx, %r11d
   5d9aa:      	cmpq	$0x3e, %rdx
   5d9ae:      	je	0x5d9ee <f.16+0x7e>
   5d9b0:      	movq	0x168(%rax), %r8
   5d9b7:      	movq	%rdx, %r9
   5d9ba:      	shrq	$0x2, %r9
   5d9be:      	leaq	-0x1(%r9), %r10
   5d9c2:      	cmpq	%r8, %r10
   5d9c5:      	jae	0x5db7f <f.16+0x20f>
   5d9cb:      	movq	0x160(%rax), %r10
   5d9d2:      	movq	-0x8(%r10,%r9,8), %r9
   5d9d7:      	cmpq	$0x3e, %r9
   5d9db:      	sete	%r11b
   5d9df:      	testq	%r9, %r9
   5d9e2:      	je	0x5d9ee <f.16+0x7e>
   5d9e4:      	cmpq	$0x3e, %r9
   5d9e8:      	jne	0x5db00 <f.16+0x190>
   5d9ee:      	testb	%r11b, %r11b
   5d9f1:      	je	0x5db7f <f.16+0x20f>
   5d9f7:      	movq	0x10(%rdi), %r8
   5d9fb:      	testq	%r8, %r8
   5d9fe:      	je	0x5db7f <f.16+0x20f>
   5da04:      	cmpl	$0x0, 0x8(%r8)
   5da09:      	je	0x5db7f <f.16+0x20f>
   5da0f:      	testq	%rdx, %rdx
   5da12:      	je	0x5da54 <f.16+0xe4>
   5da14:      	cmpq	$0x3e, %rdx
   5da18:      	je	0x5da54 <f.16+0xe4>
   5da1a:      	movq	0x168(%rax), %r9
   5da21:      	shrq	$0x2, %rdx
   5da25:      	leaq	-0x1(%rdx), %rcx
   5da29:      	cmpq	%r9, %rcx
   5da2c:      	jae	0x5db7f <f.16+0x20f>
   5da32:      	movq	0x160(%rax), %r10
   5da39:      	movq	-0x8(%r10,%rdx,8), %rax
   5da3e:      	cmpq	$0x3e, %rax
   5da42:      	sete	%cl
   5da45:      	testq	%rax, %rax
   5da48:      	je	0x5da54 <f.16+0xe4>
   5da4a:      	cmpq	$0x3e, %rax
   5da4e:      	jne	0x5db30 <f.16+0x1c0>
   5da54:      	testb	%cl, %cl
   5da56:      	je	0x5db7f <f.16+0x20f>
   5da5c:      	movq	0x10(%r8), %rcx
   5da60:      	testq	%rcx, %rcx
   5da63:      	je	0x5db7f <f.16+0x20f>
   5da69:      	movq	0x8(%rdi), %rdx
   5da6d:      	testq	%rdx, %rdx
   5da70:      	je	0x5db7f <f.16+0x20f>
   5da76:      	cmpl	$0x0, 0x8(%rdx)
   5da7a:      	je	0x5db7f <f.16+0x20f>
   5da80:      	movq	0x18(%rdi), %r8
   5da84:      	testq	%r8, %r8
   5da87:      	je	0x5db7f <f.16+0x20f>
   5da8d:      	cmpl	$0x0, 0x8(%r8)
   5da92:      	je	0x5db7f <f.16+0x20f>
   5da98:      	movq	0x20(%rdi), %rax
   5da9c:      	testq	%rax, %rax
   5da9f:      	je	0x5db7f <f.16+0x20f>
   5daa5:      	cmpl	$0x0, 0x8(%rax)
   5daa9:      	je	0x5db7f <f.16+0x20f>
   5daaf:      	movq	0x10(%rax), %r9
   5dab3:      	cmpq	$-0x1, %r9
   5dab7:      	je	0x5db7f <f.16+0x20f>
   5dabd:      	cmpq	$-0x2, %r9
   5dac1:      	je	0x5dbbf <f.16+0x24f>
   5dac7:      	movq	0x8(%rcx), %rax
   5dacb:      	imulq	0x10(%rdx), %rax
   5dad0:      	addq	0x10(%r8), %rax
   5dad4:      	incq	%r9
   5dad7:      	movq	%rax, %rdx
   5dada:      	orq	%r9, %rdx
   5dadd:      	shrq	$0x20, %rdx
   5dae1:      	je	0x5db59 <f.16+0x1e9>
   5dae3:      	cqto
   5dae5:      	idivq	%r9
   5dae8:      	movq	%rdx, 0x8(%rcx)
   5daec:      	movq	0x10(%rdi), %rax
   5daf0:      	testq	%rax, %rax
   5daf3:      	jne	0x5db6b <f.16+0x1fb>
   5daf5:      	jmp	0x5db7f <f.16+0x20f>
   5dafa:      	nopw	(%rax,%rax)
   5db00:      	shrq	$0x2, %r9
   5db04:      	leaq	-0x1(%r9), %r11
   5db08:      	cmpq	%r8, %r11
   5db0b:      	jae	0x5db7f <f.16+0x20f>
   5db0d:      	movq	-0x8(%r10,%r9,8), %r9
   5db12:      	cmpq	$0x3e, %r9
   5db16:      	je	0x5db1d <f.16+0x1ad>
   5db18:      	testq	%r9, %r9
   5db1b:      	jne	0x5db00 <f.16+0x190>
   5db1d:      	cmpq	$0x3e, %r9
   5db21:      	je	0x5d9f7 <f.16+0x87>
   5db27:      	jmp	0x5db7f <f.16+0x20f>
   5db29:      	nopl	(%rax)
   5db30:      	shrq	$0x2, %rax
   5db34:      	leaq	-0x1(%rax), %rcx
   5db38:      	cmpq	%r9, %rcx
   5db3b:      	jae	0x5db7f <f.16+0x20f>
   5db3d:      	movq	-0x8(%r10,%rax,8), %rax
   5db42:      	cmpq	$0x3e, %rax
   5db46:      	je	0x5db4d <f.16+0x1dd>
   5db48:      	testq	%rax, %rax
   5db4b:      	jne	0x5db30 <f.16+0x1c0>
   5db4d:      	cmpq	$0x3e, %rax
   5db51:      	je	0x5da5c <f.16+0xec>
   5db57:      	jmp	0x5db7f <f.16+0x20f>
   5db59:      	xorl	%edx, %edx
   5db5b:      	divl	%r9d
   5db5e:      	movq	%rdx, 0x8(%rcx)
   5db62:      	movq	0x10(%rdi), %rax
   5db66:      	testq	%rax, %rax
   5db69:      	je	0x5db7f <f.16+0x20f>
   5db6b:      	cmpl	$0x0, 0x8(%rax)
   5db6f:      	je	0x5db7f <f.16+0x20f>
   5db71:      	movq	0x10(%rax), %rax
   5db75:      	testq	%rax, %rax
   5db78:      	je	0x5db7f <f.16+0x20f>
   5db7a:      	testq	%rsi, %rsi
   5db7d:      	jne	0x5db84 <f.16+0x214>
   5db7f:      	callq	0x55770 <native_trap>
   5db84:      	cmpq	$-0x1, %rsi
   5db88:      	je	0x5dbd0 <f.16+0x260>
   5db8a:      	movq	0x8(%rax), %rcx
   5db8e:      	leaq	0x7(%rcx), %rax
   5db92:      	testq	%rcx, %rcx
   5db95:      	cmovnsq	%rcx, %rax
   5db99:      	sarq	$0x3, %rax
   5db9d:      	movq	%rax, %rcx
   5dba0:      	orq	%rsi, %rcx
   5dba3:      	shrq	$0x20, %rcx
   5dba7:      	je	0x5dbb5 <f.16+0x245>
   5dba9:      	cqto
   5dbab:      	idivq	%rsi
   5dbae:      	movq	%rdx, %rax
   5dbb1:      	popq	%rcx
   5dbb2:      	retq	$0x8
   5dbb5:      	xorl	%edx, %edx
   5dbb7:      	divl	%esi
   5dbb9:      	movl	%edx, %eax
   5dbbb:      	popq	%rcx
   5dbbc:      	retq	$0x8
   5dbbf:      	xorl	%edx, %edx
   5dbc1:      	movq	%rdx, 0x8(%rcx)
   5dbc5:      	movq	0x10(%rdi), %rax
   5dbc9:      	testq	%rax, %rax
   5dbcc:      	jne	0x5db6b <f.16+0x1fb>
   5dbce:      	jmp	0x5db7f <f.16+0x20f>
   5dbd0:      	xorl	%eax, %eax
   5dbd2:      	popq	%rcx
   5dbd3:      	retq	$0x8
   5dbd6:      	int3
   5dbd7:      	int3
   5dbd8:      	int3
   5dbd9:      	int3
   5dbda:      	int3
   5dbdb:      	int3
   5dbdc:      	int3
   5dbdd:      	int3
   5dbde:      	int3
   5dbdf:      	int3

000000000005dbe0 <f.6>:
   5dbe0:      	pushq	%r15
   5dbe2:      	pushq	%r14
   5dbe4:      	pushq	%r12
   5dbe6:      	pushq	%rbx
   5dbe7:      	subq	$0x58, %rsp
   5dbeb:      	movq	$0x6, 0x18(%rsp)
   5dbf4:      	movq	0x571d(%rip), %rax      # 0x63318 <native_roots.0>
   5dbfb:      	movq	%rax, 0x10(%rsp)
   5dc00:      	leaq	0x10(%rsp), %rcx
   5dc05:      	movq	0x56ec(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5dc0c:      	incq	%rax
   5dc0f:      	movq	%rax, 0x56e2(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5dc16:      	movq	0x56e3(%rip), %rdx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5dc1d:      	cmpq	%rdx, %rax
   5dc20:      	cmovbeq	%rdx, %rax
   5dc24:      	movq	%rcx, 0x56ed(%rip)      # 0x63318 <native_roots.0>
   5dc2b:      	movq	%rax, 0x56ce(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5dc32:      	movq	%rdi, 0x28(%rsp)
   5dc37:      	xorps	%xmm0, %xmm0
   5dc3a:      	movups	%xmm0, 0x30(%rsp)
   5dc3f:      	movq	$0x3, 0x20(%rsp)
   5dc48:      	movq	0x56c1(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5dc4f:      	testq	%rdi, %rdi
   5dc52:      	je	0x5decd <f.6+0x2ed>
   5dc58:      	movq	%rsi, %rbx
   5dc5b:      	movq	0x178(%rdi), %rsi
   5dc62:      	testq	%rsi, %rsi
   5dc65:      	je	0x5dca9 <f.6+0xc9>
   5dc67:      	movq	0x170(%rdi), %rax
   5dc6e:      	incq	%rax
   5dc71:      	movq	%rax, 0x170(%rdi)
   5dc78:      	movq	%rax, %rdx
   5dc7b:      	orq	%rsi, %rdx
   5dc7e:      	shrq	$0x20, %rdx
   5dc82:      	je	0x5de97 <f.6+0x2b7>
   5dc88:      	xorl	%edx, %edx
   5dc8a:      	divq	%rsi
   5dc8d:      	testq	%rdx, %rdx
   5dc90:      	jne	0x5dca9 <f.6+0xc9>
   5dc92:      	leaq	0x10(%rsp), %rsi
   5dc97:      	movq	%rdi, %r14
   5dc9a:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5dc9f:      	movq	%r14, %rdi
   5dca2:      	movq	0x566f(%rip), %rcx      # 0x63318 <native_roots.0>
   5dca9:      	movl	$0x18, %esi
   5dcae:      	movq	%rcx, %rdx
   5dcb1:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5dcb6:      	testq	%rax, %rax
   5dcb9:      	je	0x5ded2 <f.6+0x2f2>
   5dcbf:      	movq	%rax, %r14
   5dcc2:      	movq	$0x7a, (%rax)
   5dcc9:      	movl	$0x0, 0x8(%rax)
   5dcd0:      	movq	$0x0, 0x10(%rax)
   5dcd8:      	movq	%rax, 0x30(%rsp)
   5dcdd:      	movq	%rax, 0x40(%rsp)
   5dce2:      	leaq	0x333f(%rip), %r12      # 0x61028 <ref.7>
   5dce9:      	movq	%r12, 0x48(%rsp)
   5dcee:      	movq	%rax, 0x50(%rsp)
   5dcf3:      	movq	$0x6, 0x20(%rsp)
   5dcfc:      	movq	0x560d(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5dd03:      	testq	%rdi, %rdi
   5dd06:      	je	0x5decd <f.6+0x2ed>
   5dd0c:      	movq	0x178(%rdi), %rcx
   5dd13:      	testq	%rcx, %rcx
   5dd16:      	je	0x5dd55 <f.6+0x175>
   5dd18:      	movq	0x170(%rdi), %rax
   5dd1f:      	incq	%rax
   5dd22:      	movq	%rax, 0x170(%rdi)
   5dd29:      	movq	%rax, %rdx
   5dd2c:      	orq	%rcx, %rdx
   5dd2f:      	shrq	$0x20, %rdx
   5dd33:      	je	0x5dea9 <f.6+0x2c9>
   5dd39:      	xorl	%edx, %edx
   5dd3b:      	divq	%rcx
   5dd3e:      	testq	%rdx, %rdx
   5dd41:      	jne	0x5dd55 <f.6+0x175>
   5dd43:      	movq	0x55ce(%rip), %rsi      # 0x63318 <native_roots.0>
   5dd4a:      	movq	%rdi, %r15
   5dd4d:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5dd52:      	movq	%r15, %rdi
   5dd55:      	movq	0x55bc(%rip), %rdx      # 0x63318 <native_roots.0>
   5dd5c:      	movl	$0x18, %esi
   5dd61:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5dd66:      	testq	%rax, %rax
   5dd69:      	je	0x5ded2 <f.6+0x2f2>
   5dd6f:      	movq	%rax, %r15
   5dd72:      	movq	$0x76, (%rax)
   5dd79:      	movq	%rbx, 0x8(%rax)
   5dd7d:      	movq	%r14, 0x10(%rax)
   5dd81:      	movq	%rax, 0x40(%rsp)
   5dd86:      	movq	%r12, 0x48(%rsp)
   5dd8b:      	movq	%r14, 0x50(%rsp)
   5dd90:      	movq	$0x6, 0x20(%rsp)
   5dd99:      	movq	0x5570(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5dda0:      	testq	%rdi, %rdi
   5dda3:      	je	0x5decd <f.6+0x2ed>
   5dda9:      	movq	0x178(%rdi), %rcx
   5ddb0:      	testq	%rcx, %rcx
   5ddb3:      	je	0x5ddf2 <f.6+0x212>
   5ddb5:      	movq	0x170(%rdi), %rax
   5ddbc:      	incq	%rax
   5ddbf:      	movq	%rax, 0x170(%rdi)
   5ddc6:      	movq	%rax, %rdx
   5ddc9:      	orq	%rcx, %rdx
   5ddcc:      	shrq	$0x20, %rdx
   5ddd0:      	je	0x5debb <f.6+0x2db>
   5ddd6:      	xorl	%edx, %edx
   5ddd8:      	divq	%rcx
   5dddb:      	testq	%rdx, %rdx
   5ddde:      	jne	0x5ddf2 <f.6+0x212>
   5dde0:      	movq	0x5531(%rip), %rsi      # 0x63318 <native_roots.0>
   5dde7:      	movq	%rdi, %rbx
   5ddea:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5ddef:      	movq	%rbx, %rdi
   5ddf2:      	movq	0x551f(%rip), %rdx      # 0x63318 <native_roots.0>
   5ddf9:      	movl	$0x18, %esi
   5ddfe:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5de03:      	testq	%rax, %rax
   5de06:      	je	0x5ded2 <f.6+0x2f2>
   5de0c:      	movq	$0xa2, (%rax)
   5de13:      	movq	%r12, 0x8(%rax)
   5de17:      	movq	%r15, 0x10(%rax)
   5de1b:      	movq	%rax, 0x10(%r14)
   5de1f:      	movq	0x30(%rsp), %rax
   5de24:      	testq	%rax, %rax
   5de27:      	je	0x5decd <f.6+0x2ed>
   5de2d:      	movl	$0x1, 0x8(%rax)
   5de34:      	movq	0x30(%rsp), %rax
   5de39:      	testq	%rax, %rax
   5de3c:      	je	0x5decd <f.6+0x2ed>
   5de42:      	cmpl	$0x0, 0x8(%rax)
   5de46:      	je	0x5decd <f.6+0x2ed>
   5de4c:      	movq	0x10(%rax), %rax
   5de50:      	testq	%rax, %rax
   5de53:      	je	0x5decd <f.6+0x2ed>
   5de55:      	movq	%rax, 0x38(%rsp)
   5de5a:      	movq	0x8(%rax), %rcx
   5de5e:      	testq	%rcx, %rcx
   5de61:      	je	0x5decd <f.6+0x2ed>
   5de63:      	movq	0x10(%rax), %rdi
   5de67:      	movq	0x8(%rcx), %rax
   5de6b:      	cmpq	$0x0, 0x18(%rsp)
   5de71:      	je	0x5de86 <f.6+0x2a6>
   5de73:      	movq	0x10(%rsp), %rcx
   5de78:      	movq	%rcx, 0x5499(%rip)      # 0x63318 <native_roots.0>
   5de7f:      	decq	0x5472(%rip)            # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5de86:      	xorl	%esi, %esi
   5de88:      	xorl	%edx, %edx
   5de8a:      	addq	$0x58, %rsp
   5de8e:      	popq	%rbx
   5de8f:      	popq	%r12
   5de91:      	popq	%r14
   5de93:      	popq	%r15
   5de95:      	jmpq	*%rax
   5de97:      	xorl	%edx, %edx
   5de99:      	divl	%esi
   5de9b:      	testq	%rdx, %rdx
   5de9e:      	jne	0x5dca9 <f.6+0xc9>
   5dea4:      	jmp	0x5dc92 <f.6+0xb2>
   5dea9:      	xorl	%edx, %edx
   5deab:      	divl	%ecx
   5dead:      	testq	%rdx, %rdx
   5deb0:      	jne	0x5dd55 <f.6+0x175>
   5deb6:      	jmp	0x5dd43 <f.6+0x163>
   5debb:      	xorl	%edx, %edx
   5debd:      	divl	%ecx
   5debf:      	testq	%rdx, %rdx
   5dec2:      	jne	0x5ddf2 <f.6+0x212>
   5dec8:      	jmp	0x5dde0 <f.6+0x200>
   5decd:      	callq	0x55770 <native_trap>
   5ded2:      	leaq	-0x54b7d(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5ded9:      	movl	$0x2f, %esi
   5dede:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   5dee3:      	int3
   5dee4:      	int3
   5dee5:      	int3
   5dee6:      	int3
   5dee7:      	int3
   5dee8:      	int3
   5dee9:      	int3
   5deea:      	int3
   5deeb:      	int3
   5deec:      	int3
   5deed:      	int3
   5deee:      	int3
   5deef:      	int3

000000000005def0 <f.9>:
   5def0:      	movq	$0x1, -0x18(%rsp)
   5def9:      	movq	0x5418(%rip), %rax      # 0x63318 <native_roots.0>
   5df00:      	movq	%rax, -0x20(%rsp)
   5df05:      	leaq	-0x20(%rsp), %rax
   5df0a:      	movq	%rax, 0x5407(%rip)      # 0x63318 <native_roots.0>
   5df11:      	movq	0x53e0(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5df18:      	incq	%rax
   5df1b:      	movq	%rax, 0x53d6(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5df22:      	movq	0x53d7(%rip), %rcx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5df29:      	cmpq	%rcx, %rax
   5df2c:      	cmovbeq	%rcx, %rax
   5df30:      	movq	%rax, 0x53c9(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5df37:      	movq	%rdi, -0x8(%rsp)
   5df3c:      	movq	$0x1, -0x10(%rsp)
   5df45:      	movq	%rdx, -0x28(%rsp)
   5df4a:      	leaq	-0x28(%rsp), %rax
   5df4f:      	movq	-0x28(%rsp), %rax
   5df54:      	cmpq	$0x0, -0x18(%rsp)
   5df5a:      	je	0x5df6f <f.9+0x7f>
   5df5c:      	movq	-0x20(%rsp), %rcx
   5df61:      	movq	%rcx, 0x53b0(%rip)      # 0x63318 <native_roots.0>
   5df68:      	decq	0x5389(%rip)            # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5df6f:      	retq	$0x8
   5df72:      	int3
   5df73:      	int3
   5df74:      	int3
   5df75:      	int3
   5df76:      	int3
   5df77:      	int3
   5df78:      	int3
   5df79:      	int3
   5df7a:      	int3
   5df7b:      	int3
   5df7c:      	int3
   5df7d:      	int3
   5df7e:      	int3
   5df7f:      	int3

000000000005df80 <f.18>:
   5df80:      	pushq	%r14
   5df82:      	pushq	%rbx
   5df83:      	subq	$0x28, %rsp
   5df87:      	movq	$0x2, 0x8(%rsp)
   5df90:      	movq	$0x0, 0x10(%rsp)
   5df99:      	movq	0x5378(%rip), %rax      # 0x63318 <native_roots.0>
   5dfa0:      	movq	%rax, (%rsp)
   5dfa4:      	movq	%rsp, %rax
   5dfa7:      	movq	%rax, 0x536a(%rip)      # 0x63318 <native_roots.0>
   5dfae:      	movq	0x5343(%rip), %rax      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5dfb5:      	incq	%rax
   5dfb8:      	movq	%rax, 0x5339(%rip)      # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5dfbf:      	movq	0x533a(%rip), %rcx      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5dfc6:      	cmpq	%rcx, %rax
   5dfc9:      	cmovbeq	%rcx, %rax
   5dfcd:      	movq	%rax, 0x532c(%rip)      # 0x63300 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5dfd4:      	movq	%rdi, 0x18(%rsp)
   5dfd9:      	movq	%rsi, %rax
   5dfdc:      	shrq	$0x20, %rax
   5dfe0:      	jne	0x5e0ac <f.18+0x12c>
   5dfe6:      	movq	$0x1, 0x10(%rsp)
   5dfef:      	movl	%esi, %edi
   5dff1:      	callq	0x58e20 <native_array_new>
   5dff6:      	movq	%rax, 0x20(%rsp)
   5dffb:      	movq	$0x2, 0x10(%rsp)
   5e004:      	movq	0x5305(%rip), %rdi      # 0x63310 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5e00b:      	testq	%rdi, %rdi
   5e00e:      	je	0x5e0ac <f.18+0x12c>
   5e014:      	movq	%rax, %rbx
   5e017:      	movq	0x178(%rdi), %rcx
   5e01e:      	testq	%rcx, %rcx
   5e021:      	je	0x5e05c <f.18+0xdc>
   5e023:      	movq	0x170(%rdi), %rax
   5e02a:      	incq	%rax
   5e02d:      	movq	%rax, 0x170(%rdi)
   5e034:      	movq	%rax, %rdx
   5e037:      	orq	%rcx, %rdx
   5e03a:      	shrq	$0x20, %rdx
   5e03e:      	je	0x5e0a1 <f.18+0x121>
   5e040:      	xorl	%edx, %edx
   5e042:      	divq	%rcx
   5e045:      	testq	%rdx, %rdx
   5e048:      	jne	0x5e05c <f.18+0xdc>
   5e04a:      	movq	0x52c7(%rip), %rsi      # 0x63318 <native_roots.0>
   5e051:      	movq	%rdi, %r14
   5e054:      	callq	0x570d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5e059:      	movq	%r14, %rdi
   5e05c:      	movq	0x52b5(%rip), %rdx      # 0x63318 <native_roots.0>
   5e063:      	movl	$0x10, %esi
   5e068:      	callq	0x56f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5e06d:      	testq	%rax, %rax
   5e070:      	je	0x5e0b1 <f.18+0x131>
   5e072:      	movq	$0x82, (%rax)
   5e079:      	movq	%rbx, 0x8(%rax)
   5e07d:      	cmpq	$0x0, 0x8(%rsp)
   5e083:      	je	0x5e097 <f.18+0x117>
   5e085:      	movq	(%rsp), %rcx
   5e089:      	movq	%rcx, 0x5288(%rip)      # 0x63318 <native_roots.0>
   5e090:      	decq	0x5261(%rip)            # 0x632f8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5e097:      	addq	$0x28, %rsp
   5e09b:      	popq	%rbx
   5e09c:      	popq	%r14
   5e09e:      	retq	$0x8
   5e0a1:      	xorl	%edx, %edx
   5e0a3:      	divl	%ecx
   5e0a5:      	testq	%rdx, %rdx
   5e0a8:      	jne	0x5e05c <f.18+0xdc>
   5e0aa:      	jmp	0x5e04a <f.18+0xca>
   5e0ac:      	callq	0x55770 <native_trap>
   5e0b1:      	leaq	-0x54d5c(%rip), %rdi    # 0x935c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5e0b8:      	movl	$0x2f, %esi
   5e0bd:      	callq	0x56770 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>

Disassembly of section .init:
