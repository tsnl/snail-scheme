import fs from 'node:fs';
import crypto from 'node:crypto';
const root = '/tmp/sfir-native-production-six-20261016';
const review = `${root}/work-review`;
const names = ['fib', 'fibfp', 'mbrot', 'array1', 'bv2string', 'gcbench'];
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const requireFact = (ok, message) => { if (!ok) throw new Error(message); };
const arms = {};
for (const arm of ['control', 'candidate']) {
  const base = `${root}/${arm}`;
  const manifest = read(`${base}/manifest.json`);
  const plan = read(`${base}/timing/plan.json`);
  requireFact(manifest.timing_plan_sha256 === sha(`${base}/timing/plan.json`), `${arm} plan hash`);
  requireFact(plan.rows.filter(row => row.eligibility === 'ready').length === 33, `${arm} ready rows`);
  requireFact(plan.rows.filter(row => row.eligibility === 'unavailable').length === 3, `${arm} unavailable rows`);
  let checkedFiles = 0;
  for (const row of plan.rows) {
    if (row.eligibility !== 'ready') continue;
    requireFact(row.validation.status === 'passed', `${arm} ${row.case}/${row.route} predicate`);
    const record = read(`${base}/${row.validation.record}`);
    requireFact(record.returncode === 0 && record.timeout === false && record.descendants_gone
      && record.unexpected_descendants.length === 0
      && record.executing_descendants.length === 0, `${arm} ${row.case}/${row.route} process`);
    for (const [file, expected] of Object.entries(row.files)) {
      requireFact(sha(`${base}/${file}`) === expected, `${arm}/${file}`);
      checkedFiles++;
    }
  }
  arms[arm] = {revision: manifest.source_revision, manifestSha256: sha(`${base}/manifest.json`),
    planSha256: sha(`${base}/timing/plan.json`), ready: 33, unavailable: 3, checkedRowFiles: checkedFiles, cases: {}};
  for (const name of names) {
    const directory = `${base}/timing/artifacts/${name}`;
    const row = plan.rows.find(row => row.case === name && row.route === 'sfir-native');
    const config = fs.readFileSync(`${directory}/case-config.rs`, 'utf8');
    requireFact(config.includes('pub const OBSERVE_BARRIERS: bool = false;'), `${arm}/${name} observers`);
    requireFact(row.native_parity.status === 'passed', `${arm}/${name} native parity`);
    const attempts = fs.readdirSync(directory).filter(file => /^program.native.native-/.test(file));
    requireFact(attempts.length === 1, `${arm}/${name} attempt count`);
    const attempt = `${directory}/${attempts[0]}`;
    const assemblyFile = `${review}/${name}-${arm}.asm`;
    const assembly = fs.readFileSync(assemblyFile, 'utf8');
    const sections = assembly.split(/\n(?=[0-9a-f]+ <)/);
    const run = sections.find(section => /^[0-9a-f]+ <wasm_native_.*::run::/.test(section));
    requireFact(run, `${arm}/${name} timed run`);
    fs.writeFileSync(`${review}/${name}-${arm}-run.asm`, run);
    fs.writeFileSync(`${review}/${name}-${arm}-guest.asm`, sections.filter(section => /^[0-9a-f]+ <f\.\d+>:/.test(section)).join('\n'));
    const references = {};
    if (arm === 'candidate') {
      const relocations = fs.readFileSync(`${review}/${name}-candidate-relocations.txt`, 'utf8');
      const llvm = fs.readFileSync(`${attempt}/module.ll`, 'utf8');
      for (const match of assembly.matchAll(/# 0x([0-9a-f]+) <(ref\.\d+)>/g)) {
        const [, address, ref] = match;
        const declaration = llvm.match(new RegExp(`@${ref.replace('.', '\\.')} = internal constant \\{ i64, ptr \\} \\{ i64 \\d+, ptr @(f\\.\\d+) \\}`));
        requireFact(declaration, `${name}/${ref} LLVM declaration`);
        const symbol = declaration[1];
        const entry = assembly.match(new RegExp(`^([0-9a-f]+) <${symbol.replace('.', '\\.')}>:`, 'm'))?.[1];
        requireFact(entry, `${name}/${ref} final symbol`);
        const slot = (BigInt(`0x${address}`) + 8n).toString(16).padStart(16, '0');
        const relocation = relocations.split('\n').find(line => line.startsWith(slot));
        requireFact(relocation?.includes('R_X86_64_RELATIVE') && BigInt(`0x${relocation.trim().split(/\s+/).at(-1)}`) === BigInt(`0x${entry}`), `${name}/${ref} final relocation`);
        references[ref] = {descriptor: `0x${address}`, function: symbol, entry: `0x${BigInt(`0x${entry}`).toString(16)}`, relocation};
      }
    }
    const build = read(`${attempt}/build.json`);
    const commands = build.commands.map(item => item.command);
    const cargo = commands.find(command => command.includes('build') && command.some(item => item.endsWith('/cargo')));
    requireFact(cargo, `${arm}/${name} cargo command`);
    arms[arm].cases[name] = {binary: `${directory}/program.native`, binarySha256: sha(`${directory}/program.native`),
      configSha256: sha(`${directory}/case-config.rs`), entrySha256: sha(`${directory}/scalar-timing-entry.rs`),
      rawWasmSha256: sha(`${directory}/program.wasm.raw.wasm`), optimizedWasmSha256: sha(`${directory}/program.wasm`),
      llvmSha256: sha(`${attempt}/module.ll`), assemblySha256: sha(assemblyFile),
      configuredCount: Number(config.match(/CONFIGURED_COUNT: i64 = (\d+)/)[1]), cargo, references};
    requireFact(sha(`${attempt}/optimized.wasm`) === sha(`${directory}/program.wasm`), `${arm}/${name} actual lower input`);
  }
}
for (const name of names) {
  for (const field of ['configSha256', 'entrySha256', 'rawWasmSha256', 'optimizedWasmSha256', 'llvmSha256']) {
    requireFact(arms.control.cases[name][field] === arms.candidate.cases[name][field], `${name} ${field} parity`);
  }
}
const result = {status: 'passed', basis: 'Exact observation-disabled production binaries; static disassembly review is separate from hook-count validation. No performance measurement in this audit.', arms};
fs.writeFileSync(`${review}/identities.json`, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({status: result.status, arms: Object.fromEntries(Object.entries(arms).map(([arm, data]) => [arm, {revision: data.revision, manifestSha256: data.manifestSha256, planSha256: data.planSha256, checkedRowFiles: data.checkedRowFiles,
  cases: Object.fromEntries(Object.entries(data.cases).map(([name, value]) => [name, {binarySha256: value.binarySha256, configuredCount: value.configuredCount, verifiedReferenceCount: Object.keys(value.references).length}]))}]))}, null, 2));
