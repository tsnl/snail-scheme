0000000000058fd0 <f.2>:
   58fd0:      	pushq	%rbp
   58fd1:      	pushq	%r15
   58fd3:      	pushq	%r14
   58fd5:      	pushq	%r13
   58fd7:      	pushq	%r12
   58fd9:      	pushq	%rbx
   58fda:      	subq	$0x88, %rsp
   58fe1:      	movq	%rdx, %r12
   58fe4:      	movq	%rsi, %rbx
   58fe7:      	movq	%rdi, %r14
   58fea:      	leaq	0x8(%rsp), %rdi
   58fef:      	movl	$0x9, %esi
   58ff4:      	callq	0x2a020 <native_roots_enter>
   58ff9:      	movq	%r14, 0x20(%rsp)
   58ffe:      	testq	%r14, %r14
   59001:      	movq	$0x0, 0x28(%rsp)
   5900a:      	movq	$0x0, 0x30(%rsp)
   59013:      	movq	$0x0, 0x38(%rsp)
   5901c:      	movq	$0x0, 0x40(%rsp)
   59025:      	je	0x594b8 <f.2+0x4e8>
   5902b:      	movq	%r14, 0x30(%rsp)
   59030:      	cmpq	%rbx, 0x8(%r14)
   59034:      	jle	0x59497 <f.2+0x4c7>
   5903a:      	leaq	0x3db7(%rip), %rbp      # 0x5cdf8 <ref.7>
   59041:      	nopw	%cs:(%rax,%rax)
   5904b:      	nopl	(%rax,%rax)
   59050:      	cmpb	$0x0, 0x5e99(%rip)      # 0x5eef0 <g.10>
   59057:      	je	0x594b8 <f.2+0x4e8>
   5905d:      	cmpb	$0x0, 0x5e4c(%rip)      # 0x5eeb0 <g.2>
   59064:      	je	0x594b8 <f.2+0x4e8>
   5906a:      	cmpq	$0x0, 0x5e36(%rip)      # 0x5eea8 <g.1>
   59072:      	je	0x594b8 <f.2+0x4e8>
   59078:      	movq	0x5e69(%rip), %r14      # 0x5eee8 <g.9>
   5907f:      	movq	$0x5, 0x18(%rsp)
   59088:      	leaq	0x70(%rsp), %r15
   5908d:      	movq	%r15, %rdi
   59090:      	xorl	%esi, %esi
   59092:      	callq	0x2a020 <native_roots_enter>
   59097:      	movq	$0x0, 0x80(%rsp)
   590a3:      	movq	%r14, %rdi
   590a6:      	callq	0x14210 <hide_i64>
   590ab:      	movq	%rax, %r12
   590ae:      	movq	%r15, %rdi
   590b1:      	callq	0x2a070 <native_roots_leave>
   590b6:      	cmpb	$0x0, 0x5e23(%rip)      # 0x5eee0 <g.8>
   590bd:      	je	0x594b8 <f.2+0x4e8>
   590c3:      	cmpq	$0x0, 0x5e0d(%rip)      # 0x5eed8 <g.7>
   590cb:      	je	0x594b8 <f.2+0x4e8>
   590d1:      	movq	%rbx, 0x68(%rsp)
   590d6:      	movq	%r12, %rax
   590d9:      	shrq	$0x20, %rax
   590dd:      	jne	0x594b8 <f.2+0x4e8>
   590e3:      	movq	$0x5, 0x18(%rsp)
   590ec:      	movl	$0x18, %edi
   590f1:      	callq	0x27c90 <native_alloc>
   590f6:      	testq	%rax, %rax
   590f9:      	je	0x594b8 <f.2+0x4e8>
   590ff:      	movq	%rax, %r13
   59102:      	movq	$0x3a, (%rax)
   59109:      	movl	$0x0, 0x8(%rax)
   59110:      	movq	$0x0, 0x10(%rax)
   59118:      	movq	%rax, 0x28(%rsp)
   5911d:      	movq	%rbp, 0x48(%rsp)
   59122:      	movq	%rax, 0x50(%rsp)
   59127:      	movq	$0x7, 0x18(%rsp)
   59130:      	movl	$0x2b, %edi
   59135:      	xorl	%esi, %esi
   59137:      	xorl	%edx, %edx
   59139:      	movl	$0x8, %ecx
   5913e:      	callq	0x29c60 <native_array_new>
   59143:      	movq	%rax, 0x48(%rsp)
   59148:      	movq	%rbp, 0x50(%rsp)
   5914d:      	movq	%r13, 0x58(%rsp)
   59152:      	movq	$0x8, 0x18(%rsp)
   5915b:      	movl	$0x2f, %edi
   59160:      	movl	%r12d, %esi
   59163:      	movq	%rax, %rdx
   59166:      	movl	$0x8, %ecx
   5916b:      	callq	0x29c60 <native_array_new>
   59170:      	movq	%rax, %r14
   59173:      	movq	%rax, 0x40(%rsp)
   59178:      	movq	0x28(%rsp), %r15
   5917d:      	movq	%r15, 0x48(%rsp)
   59182:      	movq	%rax, 0x50(%rsp)
   59187:      	movq	%rbp, 0x58(%rsp)
   5918c:      	movq	%r13, 0x60(%rsp)
   59191:      	movq	$0x9, 0x18(%rsp)
   5919a:      	movl	$0x20, %edi
   5919f:      	callq	0x27c90 <native_alloc>
   591a4:      	testq	%rax, %rax
   591a7:      	je	0x594b8 <f.2+0x4e8>
   591ad:      	movq	%rbp, %rbx
   591b0:      	movq	%rax, %rbp
   591b3:      	movq	$0x26, (%rax)
   591ba:      	movq	%r12, 0x8(%rax)
   591be:      	movq	%r14, 0x10(%rax)
   591c2:      	movq	%r15, 0x18(%rax)
   591c6:      	movq	%rax, 0x48(%rsp)
   591cb:      	movq	%rbx, 0x50(%rsp)
   591d0:      	movq	%r13, 0x58(%rsp)
   591d5:      	movq	$0x8, 0x18(%rsp)
   591de:      	movl	$0x18, %edi
   591e3:      	callq	0x27c90 <native_alloc>
   591e8:      	testq	%rax, %rax
   591eb:      	je	0x594b8 <f.2+0x4e8>
   591f1:      	movq	$0x32, (%rax)
   591f8:      	movq	%rbx, 0x8(%rax)
   591fc:      	movq	%rbp, 0x10(%rax)
   59200:      	movq	%rax, 0x10(%r13)
   59204:      	movq	0x28(%rsp), %rax
   59209:      	testq	%rax, %rax
   5920c:      	je	0x594b8 <f.2+0x4e8>
   59212:      	movl	$0x1, 0x8(%rax)
   59219:      	movq	0x28(%rsp), %rax
   5921e:      	testq	%rax, %rax
   59221:      	leaq	0x3bb0(%rip), %rbx      # 0x5cdd8 <ref.4>
   59228:      	je	0x594b8 <f.2+0x4e8>
   5922e:      	cmpl	$0x0, 0x8(%rax)
   59232:      	je	0x594b8 <f.2+0x4e8>
   59238:      	movq	0x10(%rax), %rax
   5923c:      	testq	%rax, %rax
   5923f:      	je	0x594b8 <f.2+0x4e8>
   59245:      	movq	%rax, 0x38(%rsp)
   5924a:      	movq	0x8(%rax), %rcx
   5924e:      	testq	%rcx, %rcx
   59251:      	je	0x594b8 <f.2+0x4e8>
   59257:      	movq	%r12, %r13
   5925a:      	decq	%r13
   5925d:      	movq	0x10(%rax), %rdi
   59261:      	movq	0x8(%rcx), %rax
   59265:      	movq	%rdi, 0x48(%rsp)
   5926a:      	movq	$0x6, 0x18(%rsp)
   59273:      	movq	%r13, %rsi
   59276:      	callq	*%rax
   59278:      	subq	$0x8, %rsp
   5927c:      	cmpb	$0x0, 0x5c4d(%rip)      # 0x5eed0 <g.6>
   59283:      	je	0x594b8 <f.2+0x4e8>
   59289:      	cmpq	$0x0, 0x5c37(%rip)      # 0x5eec8 <g.5>
   59291:      	je	0x594b8 <f.2+0x4e8>
   59297:      	movq	$0x5, 0x18(%rsp)
   592a0:      	movl	$0x18, %edi
   592a5:      	callq	0x27c90 <native_alloc>
   592aa:      	testq	%rax, %rax
   592ad:      	je	0x594b8 <f.2+0x4e8>
   592b3:      	movq	%rax, %rbp
   592b6:      	movq	$0x3a, (%rax)
   592bd:      	movl	$0x0, 0x8(%rax)
   592c4:      	movq	$0x0, 0x10(%rax)
   592cc:      	movq	%rax, 0x28(%rsp)
   592d1:      	movq	0x40(%rsp), %r15
   592d6:      	movq	%rax, 0x48(%rsp)
   592db:      	movq	%r15, 0x50(%rsp)
   592e0:      	movq	%rbx, 0x58(%rsp)
   592e5:      	movq	%rax, 0x60(%rsp)
   592ea:      	movq	$0x9, 0x18(%rsp)
   592f3:      	movl	$0x20, %edi
   592f8:      	callq	0x27c90 <native_alloc>
   592fd:      	testq	%rax, %rax
   59300:      	je	0x594b8 <f.2+0x4e8>
   59306:      	movq	%rax, %r14
   59309:      	movq	$0x1e, (%rax)
   59310:      	movq	%r15, 0x8(%rax)
   59314:      	movq	%r12, 0x10(%rax)
   59318:      	movq	%rbp, 0x18(%rax)
   5931c:      	movq	%rax, 0x48(%rsp)
   59321:      	movq	%rbx, 0x50(%rsp)
   59326:      	movq	%rbp, 0x58(%rsp)
   5932b:      	movq	$0x8, 0x18(%rsp)
   59334:      	movl	$0x18, %edi
   59339:      	callq	0x27c90 <native_alloc>
   5933e:      	testq	%rax, %rax
   59341:      	je	0x594b8 <f.2+0x4e8>
   59347:      	movq	$0x32, (%rax)
   5934e:      	movq	%rbx, 0x8(%rax)
   59352:      	movq	%r14, 0x10(%rax)
   59356:      	movq	%rax, 0x10(%rbp)
   5935a:      	movq	0x28(%rsp), %rax
   5935f:      	testq	%rax, %rax
   59362:      	je	0x594b8 <f.2+0x4e8>
   59368:      	movl	$0x1, 0x8(%rax)
   5936f:      	movq	0x28(%rsp), %rax
   59374:      	testq	%rax, %rax
   59377:      	leaq	0x3a7a(%rip), %rbp      # 0x5cdf8 <ref.7>
   5937e:      	je	0x594b8 <f.2+0x4e8>
   59384:      	cmpl	$0x0, 0x8(%rax)
   59388:      	je	0x594b8 <f.2+0x4e8>
   5938e:      	movq	0x10(%rax), %rax
   59392:      	testq	%rax, %rax
   59395:      	je	0x594b8 <f.2+0x4e8>
   5939b:      	movq	%rax, 0x38(%rsp)
   593a0:      	movq	0x8(%rax), %rcx
   593a4:      	testq	%rcx, %rcx
   593a7:      	je	0x594b8 <f.2+0x4e8>
   593ad:      	movq	0x10(%rax), %rdi
   593b1:      	movq	0x8(%rcx), %rax
   593b5:      	movq	%rdi, 0x48(%rsp)
   593ba:      	movq	$0x6, 0x18(%rsp)
   593c3:      	movq	%r13, %rsi
   593c6:      	callq	*%rax
   593c8:      	subq	$0x8, %rsp
   593cc:      	movq	0x40(%rsp), %rax
   593d1:      	testq	%rax, %rax
   593d4:      	je	0x594b8 <f.2+0x4e8>
   593da:      	testb	$0x1, %al
   593dc:      	movq	0x68(%rsp), %rbx
   593e1:      	jne	0x594b8 <f.2+0x4e8>
   593e7:      	cmpq	$0x0, 0x8(%rax)
   593ec:      	je	0x594b8 <f.2+0x4e8>
   593f2:      	movq	0x10(%rax), %rax
   593f6:      	testq	%rax, %rax
   593f9:      	je	0x594b8 <f.2+0x4e8>
   593ff:      	testb	$0x1, %al
   59401:      	jne	0x594b8 <f.2+0x4e8>
   59407:      	cmpq	$0x0, 0x8(%rax)
   5940c:      	je	0x594b8 <f.2+0x4e8>
   59412:      	movq	0x30(%rsp), %r14
   59417:      	testq	%r14, %r14
   5941a:      	je	0x594b8 <f.2+0x4e8>
   59420:      	movq	0x10(%r14), %rcx
   59424:      	testq	%rcx, %rcx
   59427:      	je	0x594b8 <f.2+0x4e8>
   5942d:      	cmpl	$0x0, 0x8(%rcx)
   59431:      	je	0x594b8 <f.2+0x4e8>
   59437:      	cmpq	$0x0, 0x10(%rcx)
   5943c:      	je	0x594b8 <f.2+0x4e8>
   5943e:      	movq	0x10(%rax), %r12
   59442:      	incq	%rbx
   59445:      	leaq	0x8(%rsp), %r15
   5944a:      	movq	%r15, %rdi
   5944d:      	callq	0x2a070 <native_roots_leave>
   59452:      	movl	$0x9, %esi
   59457:      	movq	%r15, %rdi
   5945a:      	callq	0x2a020 <native_roots_enter>
   5945f:      	movq	%r14, 0x20(%rsp)
   59464:      	leaq	0x28(%rsp), %rax
   59469:      	movq	$0x0, 0x18(%rax)
   59471:      	movq	$0x0, 0x10(%rax)
   59479:      	movq	$0x0, 0x8(%rax)
   59481:      	movq	$0x0, (%rax)
   59488:      	movq	%r14, 0x30(%rsp)
   5948d:      	cmpq	%rbx, 0x8(%r14)
   59491:      	jg	0x59050 <f.2+0x80>
   59497:      	leaq	0x8(%rsp), %rdi
   5949c:      	callq	0x2a070 <native_roots_leave>
   594a1:      	movq	%r12, %rax
   594a4:      	addq	$0x88, %rsp
   594ab:      	popq	%rbx
   594ac:      	popq	%r12
   594ae:      	popq	%r13
   594b0:      	popq	%r14
   594b2:      	popq	%r15
   594b4:      	popq	%rbp
   594b5:      	retq	$0x8
   594b8:      	callq	0x25cf0 <native_trap>
   594bd:      	int3
   594be:      	int3
   594bf:      	int3

00000000000594c0 <f.3>:
   594c0:      	pushq	%r15
   594c2:      	pushq	%r14
   594c4:      	pushq	%rbx
   594c5:      	subq	$0x40, %rsp
   594c9:      	movq	%rdx, %rbx
   594cc:      	movq	%rdi, %r14
   594cf:      	leaq	0x8(%rsp), %r15
   594d4:      	movl	$0x1, %esi
   594d9:      	movq	%r15, %rdi
   594dc:      	callq	0x2a020 <native_roots_enter>
   594e1:      	movq	%r14, 0x20(%rsp)
   594e6:      	movq	$0x1, 0x18(%rsp)
   594ef:      	leaq	0x28(%rsp), %r14
   594f4:      	movq	%r14, %rdi
   594f7:      	xorl	%esi, %esi
   594f9:      	callq	0x2a020 <native_roots_enter>
   594fe:      	movq	$0x0, 0x38(%rsp)
   59507:      	movq	%rbx, %rdi
   5950a:      	callq	0x14210 <hide_i64>
   5950f:      	movq	%rax, %rbx
   59512:      	movq	%r14, %rdi
   59515:      	callq	0x2a070 <native_roots_leave>
   5951a:      	movq	%r15, %rdi
   5951d:      	callq	0x2a070 <native_roots_leave>
   59522:      	movq	%rbx, %rax
   59525:      	addq	$0x40, %rsp
   59529:      	popq	%rbx
   5952a:      	popq	%r14
   5952c:      	popq	%r15
   5952e:      	retq	$0x8
   59531:      	int3
   59532:      	int3
   59533:      	int3
   59534:      	int3
   59535:      	int3
   59536:      	int3
   59537:      	int3
   59538:      	int3
   59539:      	int3
   5953a:      	int3
   5953b:      	int3
   5953c:      	int3
   5953d:      	int3
   5953e:      	int3
   5953f:      	int3

0000000000059540 <f.4>:
   59540:      	pushq	%rbp
   59541:      	pushq	%r15
   59543:      	pushq	%r14
   59545:      	pushq	%r13
   59547:      	pushq	%r12
   59549:      	pushq	%rbx
   5954a:      	subq	$0x78, %rsp
   5954e:      	movq	%rsi, %r14
   59551:      	movq	%rdi, %rbx
   59554:      	leaq	0x18(%rsp), %rdi
   59559:      	movl	$0x9, %esi
   5955e:      	callq	0x2a020 <native_roots_enter>
   59563:      	movq	%rbx, 0x30(%rsp)
   59568:      	testq	%r14, %r14
   5956b:      	movq	$0x0, 0x38(%rsp)
   59574:      	movq	$0x0, 0x40(%rsp)
   5957d:      	movq	$0x0, 0x48(%rsp)
   59586:      	js	0x5970b <f.4+0x1cb>
   5958c:      	movl	$0x1e, %esi
   59591:      	movq	%rbx, %rdi
   59594:      	xorl	%edx, %edx
   59596:      	xorl	%ecx, %ecx
   59598:      	callq	0x29f30 <native_ref_test>
   5959d:      	testl	%eax, %eax
   5959f:      	je	0x59728 <f.4+0x1e8>
   595a5:      	movq	%rbx, 0x40(%rsp)
   595aa:      	testq	%rbx, %rbx
   595ad:      	je	0x59728 <f.4+0x1e8>
   595b3:      	movq	0x10(%rbx), %rax
   595b7:      	movq	%rax, 0x10(%rsp)
   595bc:      	movq	$0x4, 0x28(%rsp)
   595c5:      	movl	$0x18, %edi
   595ca:      	callq	0x27c90 <native_alloc>
   595cf:      	testq	%rax, %rax
   595d2:      	je	0x59728 <f.4+0x1e8>
   595d8:      	movq	%rax, %r15
   595db:      	movq	$0x3a, (%rax)
   595e2:      	movl	$0x0, 0x8(%rax)
   595e9:      	movq	$0x0, 0x10(%rax)
   595f1:      	movq	%rax, 0x38(%rsp)
   595f6:      	movq	0x40(%rsp), %rax
   595fb:      	testq	%rax, %rax
   595fe:      	je	0x59728 <f.4+0x1e8>
   59604:      	movq	0x8(%rax), %rbp
   59608:      	movq	0x18(%rax), %rbx
   5960c:      	movq	%r15, 0x50(%rsp)
   59611:      	movq	%rbx, 0x58(%rsp)
   59616:      	movq	%rbp, 0x60(%rsp)
   5961b:      	leaq	0x37c6(%rip), %r13      # 0x5cde8 <ref.5>
   59622:      	movq	%r13, 0x68(%rsp)
   59627:      	movq	%r15, 0x70(%rsp)
   5962c:      	movq	$0x9, 0x28(%rsp)
   59635:      	movl	$0x28, %edi
   5963a:      	callq	0x27c90 <native_alloc>
   5963f:      	testq	%rax, %rax
   59642:      	je	0x59728 <f.4+0x1e8>
   59648:      	movq	%rax, %r12
   5964b:      	movq	$0x16, (%rax)
   59652:      	movq	%rbp, 0x8(%rax)
   59656:      	movq	%rbx, 0x10(%rax)
   5965a:      	movq	%r14, 0x18(%rax)
   5965e:      	movq	%r15, 0x20(%rax)
   59662:      	movq	%rax, 0x50(%rsp)
   59667:      	movq	%r13, 0x58(%rsp)
   5966c:      	movq	%r15, 0x60(%rsp)
   59671:      	movq	$0x7, 0x28(%rsp)
   5967a:      	movl	$0x18, %edi
   5967f:      	callq	0x27c90 <native_alloc>
   59684:      	testq	%rax, %rax
   59687:      	je	0x59728 <f.4+0x1e8>
   5968d:      	movq	$0x32, (%rax)
   59694:      	movq	%r13, 0x8(%rax)
   59698:      	movq	%r12, 0x10(%rax)
   5969c:      	movq	%rax, 0x10(%r15)
   596a0:      	movq	0x38(%rsp), %rax
   596a5:      	testq	%rax, %rax
   596a8:      	je	0x59728 <f.4+0x1e8>
   596aa:      	movl	$0x1, 0x8(%rax)
   596b1:      	movq	0x38(%rsp), %rax
   596b6:      	testq	%rax, %rax
   596b9:      	je	0x59728 <f.4+0x1e8>
   596bb:      	cmpl	$0x0, 0x8(%rax)
   596bf:      	je	0x59728 <f.4+0x1e8>
   596c1:      	movq	0x10(%rax), %rax
   596c5:      	testq	%rax, %rax
   596c8:      	je	0x59728 <f.4+0x1e8>
   596ca:      	movq	%rax, 0x48(%rsp)
   596cf:      	movq	0x8(%rax), %rcx
   596d3:      	testq	%rcx, %rcx
   596d6:      	je	0x59728 <f.4+0x1e8>
   596d8:      	movq	0x10(%rsp), %rbx
   596dd:      	decq	%rbx
   596e0:      	movq	0x10(%rax), %r14
   596e4:      	movq	0x8(%rcx), %r15
   596e8:      	leaq	0x18(%rsp), %rdi
   596ed:      	callq	0x2a070 <native_roots_leave>
   596f2:      	movq	%r14, %rdi
   596f5:      	movq	%rbx, %rsi
   596f8:      	movq	%r15, %rax
   596fb:      	addq	$0x78, %rsp
   596ff:      	popq	%rbx
   59700:      	popq	%r12
   59702:      	popq	%r13
   59704:      	popq	%r14
   59706:      	popq	%r15
   59708:      	popq	%rbp
   59709:      	jmpq	*%rax
   5970b:      	leaq	0x18(%rsp), %rdi
   59710:      	callq	0x2a070 <native_roots_leave>
   59715:      	xorl	%eax, %eax
   59717:      	addq	$0x78, %rsp
   5971b:      	popq	%rbx
   5971c:      	popq	%r12
   5971e:      	popq	%r13
   59720:      	popq	%r14
   59722:      	popq	%r15
   59724:      	popq	%rbp
   59725:      	retq	$0x8
   59728:      	callq	0x25cf0 <native_trap>
   5972d:      	int3
   5972e:      	int3
   5972f:      	int3

0000000000059730 <f.5>:
   59730:      	pushq	%rbp
   59731:      	pushq	%r15
   59733:      	pushq	%r14
   59735:      	pushq	%r13
   59737:      	pushq	%r12
   59739:      	pushq	%rbx
   5973a:      	subq	$0xb8, %rsp
   59741:      	movq	%rsi, %rbx
   59744:      	movq	%rdi, %r12
   59747:      	leaq	0x10(%rsp), %rdi
   5974c:      	movl	$0x7, %esi
   59751:      	callq	0x2a020 <native_roots_enter>
   59756:      	movq	%r12, 0x28(%rsp)
   5975b:      	testq	%rbx, %rbx
   5975e:      	movq	$0x0, 0x30(%rsp)
   59767:      	movq	$0x0, 0x38(%rsp)
   59770:      	movq	$0x0, 0x40(%rsp)
   59779:      	js	0x59b3b <f.5+0x40b>
   5977f:      	movq	%rbx, %rax
   59782:      	shrq	$0x20, %rax
   59786:      	movq	%rax, 0x70(%rsp)
   5978b:      	leaq	0x90(%rsp), %r14
   59793:      	nopw	%cs:(%rax,%rax)
   5979d:      	nopl	(%rax)
   597a0:      	cmpq	$0x0, 0x70(%rsp)
   597a6:      	jne	0x59ba5 <f.5+0x475>
   597ac:      	movl	$0x16, %esi
   597b1:      	movq	%r12, %rdi
   597b4:      	xorl	%edx, %edx
   597b6:      	xorl	%ecx, %ecx
   597b8:      	callq	0x29f30 <native_ref_test>
   597bd:      	testl	%eax, %eax
   597bf:      	je	0x59ba5 <f.5+0x475>
   597c5:      	movq	%r12, 0x30(%rsp)
   597ca:      	testq	%r12, %r12
   597cd:      	je	0x59ba5 <f.5+0x475>
   597d3:      	movq	0x8(%r12), %rax
   597d8:      	testq	%rax, %rax
   597db:      	je	0x59ba5 <f.5+0x475>
   597e1:      	testb	$0x1, %al
   597e3:      	jne	0x59ba5 <f.5+0x475>
   597e9:      	cmpq	0x8(%rax), %rbx
   597ed:      	jae	0x59ba5 <f.5+0x475>
   597f3:      	cmpb	$0x0, 0x56c6(%rip)      # 0x5eec0 <g.4>
   597fa:      	je	0x59ba5 <f.5+0x475>
   59800:      	cmpq	$0x0, 0x56b0(%rip)      # 0x5eeb8 <g.3>
   59808:      	je	0x59ba5 <f.5+0x475>
   5980e:      	movq	0x10(%rax,%rbx,8), %r15
   59813:      	movq	%r15, 0x48(%rsp)
   59818:      	movq	$0x5, 0x20(%rsp)
   59821:      	movl	$0x18, %edi
   59826:      	callq	0x27c90 <native_alloc>
   5982b:      	testq	%rax, %rax
   5982e:      	je	0x59ba5 <f.5+0x475>
   59834:      	movq	%rax, %r12
   59837:      	movq	$0x12, (%rax)
   5983e:      	movl	$0x0, 0x8(%rax)
   59845:      	movq	$0x0, 0x10(%rax)
   5984d:      	movq	%rax, 0x38(%rsp)
   59852:      	movq	%rbx, 0x78(%rsp)
   59857:      	cvtsi2sd	%rbx, %xmm1
   5985c:      	movsd	-0x55514(%rip), %xmm0   # 0x4350 <writev+0x4350>
   59864:      	mulsd	%xmm0, %xmm1
   59868:      	addsd	-0x55558(%rip), %xmm1   # 0x4318 <writev+0x4318>
   59870:      	movapd	%xmm1, 0x60(%rsp)
   59876:      	movq	0x30(%rsp), %rax
   5987b:      	testq	%rax, %rax
   5987e:      	je	0x59ba5 <f.5+0x475>
   59884:      	movq	0x18(%rax), %rbp
   59888:      	xorps	%xmm1, %xmm1
   5988b:      	cvtsi2sd	%rbp, %xmm1
   59890:      	mulsd	%xmm0, %xmm1
   59894:      	addsd	-0x5556c(%rip), %xmm1   # 0x4330 <writev+0x4330>
   5989c:      	movapd	%xmm1, 0x80(%rsp)
   598a5:      	movq	%r12, 0x48(%rsp)
   598aa:      	movq	%r12, 0x50(%rsp)
   598af:      	movq	%r15, 0x58(%rsp)
   598b4:      	movq	$0x7, 0x20(%rsp)
   598bd:      	movl	$0x20, %edi
   598c2:      	callq	0x27c90 <native_alloc>
   598c7:      	testq	%rax, %rax
   598ca:      	je	0x59ba5 <f.5+0x475>
   598d0:      	movq	%rax, %r13
   598d3:      	movq	$0xe, (%rax)
   598da:      	movaps	0x60(%rsp), %xmm0
   598df:      	movsd	%xmm0, 0x8(%rax)
   598e4:      	movaps	0x80(%rsp), %xmm0
   598ec:      	movsd	%xmm0, 0x10(%rax)
   598f1:      	movq	%r12, 0x18(%rax)
   598f5:      	movq	%rax, 0x48(%rsp)
   598fa:      	movq	%r12, 0x50(%rsp)
   598ff:      	movq	%r15, 0x58(%rsp)
   59904:      	movq	$0x7, 0x20(%rsp)
   5990d:      	movl	$0x10, %edi
   59912:      	callq	0x27c90 <native_alloc>
   59917:      	testq	%rax, %rax
   5991a:      	je	0x59ba5 <f.5+0x475>
   59920:      	movq	$0xa, (%rax)
   59927:      	movq	%r13, 0x8(%rax)
   5992b:      	movq	%rax, 0x10(%r12)
   59930:      	movq	0x38(%rsp), %rax
   59935:      	testq	%rax, %rax
   59938:      	je	0x59ba5 <f.5+0x475>
   5993e:      	movl	$0x1, 0x8(%rax)
   59945:      	movq	0x38(%rsp), %rax
   5994a:      	testq	%rax, %rax
   5994d:      	je	0x59ba5 <f.5+0x475>
   59953:      	cmpl	$0x0, 0x8(%rax)
   59957:      	je	0x59ba5 <f.5+0x475>
   5995d:      	movq	0x10(%rax), %rax
   59961:      	testq	%rax, %rax
   59964:      	je	0x59ba5 <f.5+0x475>
   5996a:      	movq	0x8(%rax), %r13
   5996e:      	movq	%r15, 0x48(%rsp)
   59973:      	movq	%r13, 0x50(%rsp)
   59978:      	movq	$0x6, 0x20(%rsp)
   59981:      	movq	%r14, %rdi
   59984:      	xorl	%esi, %esi
   59986:      	callq	0x2a020 <native_roots_enter>
   5998b:      	movq	%r13, 0xa8(%rsp)
   59993:      	movq	$0x0, 0xb0(%rsp)
   5999f:      	movapd	0x60(%rsp), %xmm3
   599a5:      	unpcklpd	0x80(%rsp), %xmm3       # xmm3 = xmm3[0],mem[0]
   599ae:      	xorl	%r12d, %r12d
   599b1:      	nopw	%cs:(%rax,%rax)
   599bb:      	nopl	(%rax,%rax)
   599c0:      	movapd	%xmm3, %xmm0
   599c4:      	mulpd	%xmm3, %xmm0
   599c8:      	movapd	%xmm0, %xmm1
   599cc:      	unpckhpd	%xmm0, %xmm1            # xmm1 = xmm1[1],xmm0[1]
   599d0:      	movapd	%xmm1, %xmm2
   599d4:      	addsd	%xmm0, %xmm2
   599d8:      	ucomisd	-0x556b8(%rip), %xmm2   # 0x4328 <writev+0x4328>
   599e0:      	ja	0x59a89 <f.5+0x359>
   599e6:      	testq	%r13, %r13
   599e9:      	je	0x59ba5 <f.5+0x475>
   599ef:      	movq	0x18(%r13), %rax
   599f3:      	movq	%rax, 0xb0(%rsp)
   599fb:      	testq	%rax, %rax
   599fe:      	je	0x59ba5 <f.5+0x475>
   59a04:      	cmpl	$0x0, 0x8(%rax)
   59a08:      	je	0x59ba5 <f.5+0x475>
   59a0e:      	movq	0x10(%rax), %rax
   59a12:      	testq	%rax, %rax
   59a15:      	je	0x59ba5 <f.5+0x475>
   59a1b:      	movq	0x8(%rax), %rbx
   59a1f:      	movapd	%xmm3, %xmm2
   59a23:      	unpckhpd	%xmm3, %xmm2            # xmm2 = xmm2[1],xmm3[1]
   59a27:      	mulsd	%xmm3, %xmm2
   59a2b:      	addsd	%xmm2, %xmm2
   59a2f:      	subsd	%xmm1, %xmm0
   59a33:      	unpcklpd	%xmm2, %xmm0            # xmm0 = xmm0[0],xmm2[0]
   59a37:      	movupd	0x8(%r13), %xmm1
   59a3d:      	addpd	%xmm0, %xmm1
   59a41:      	movapd	%xmm1, 0x60(%rsp)
   59a47:      	incq	%r12
   59a4a:      	movq	%r14, %rdi
   59a4d:      	callq	0x2a070 <native_roots_leave>
   59a52:      	movq	%r14, %rdi
   59a55:      	xorl	%esi, %esi
   59a57:      	callq	0x2a020 <native_roots_enter>
   59a5c:      	movapd	0x60(%rsp), %xmm3
   59a62:      	movq	%rbx, 0xa8(%rsp)
   59a6a:      	movq	$0x0, 0xb0(%rsp)
   59a76:      	cmpq	$0x40, %r12
   59a7a:      	movq	%rbx, %r13
   59a7d:      	jne	0x599c0 <f.5+0x290>
   59a83:      	movl	$0x40, %r12d
   59a89:      	movq	%r14, %rdi
   59a8c:      	callq	0x2a070 <native_roots_leave>
   59a91:      	movq	%rbp, %rax
   59a94:      	shrq	$0x20, %rax
   59a98:      	jne	0x59ba5 <f.5+0x475>
   59a9e:      	testq	%r15, %r15
   59aa1:      	je	0x59ba5 <f.5+0x475>
   59aa7:      	testb	$0x1, %r15b
   59aab:      	jne	0x59ba5 <f.5+0x475>
   59ab1:      	cmpq	0x8(%r15), %rbp
   59ab5:      	jae	0x59ba5 <f.5+0x475>
   59abb:      	movq	%r12, 0x10(%r15,%rbp,8)
   59ac0:      	movq	0x30(%rsp), %r12
   59ac5:      	testq	%r12, %r12
   59ac8:      	je	0x59ba5 <f.5+0x475>
   59ace:      	movq	0x20(%r12), %rax
   59ad3:      	testq	%rax, %rax
   59ad6:      	movq	0x78(%rsp), %rbx
   59adb:      	je	0x59ba5 <f.5+0x475>
   59ae1:      	cmpl	$0x0, 0x8(%rax)
   59ae5:      	je	0x59ba5 <f.5+0x475>
   59aeb:      	cmpq	$0x0, 0x10(%rax)
   59af0:      	je	0x59ba5 <f.5+0x475>
   59af6:      	leaq	0x10(%rsp), %r15
   59afb:      	movq	%r15, %rdi
   59afe:      	callq	0x2a070 <native_roots_leave>
   59b03:      	movl	$0x7, %esi
   59b08:      	movq	%r15, %rdi
   59b0b:      	callq	0x2a020 <native_roots_enter>
   59b10:      	subq	$0x1, %rbx
   59b14:      	movq	%r12, 0x28(%rsp)
   59b19:      	leaq	0x30(%rsp), %rax
   59b1e:      	movq	$0x0, 0x10(%rax)
   59b26:      	movq	$0x0, 0x8(%rax)
   59b2e:      	movq	$0x0, (%rax)
   59b35:      	jae	0x597a0 <f.5+0x70>
   59b3b:      	movl	$0x16, %esi
   59b40:      	movq	%r12, %rdi
   59b43:      	xorl	%edx, %edx
   59b45:      	xorl	%ecx, %ecx
   59b47:      	callq	0x29f30 <native_ref_test>
   59b4c:      	testl	%eax, %eax
   59b4e:      	je	0x59ba5 <f.5+0x475>
   59b50:      	movq	%r12, 0x30(%rsp)
   59b55:      	testq	%r12, %r12
   59b58:      	je	0x59ba5 <f.5+0x475>
   59b5a:      	movq	0x10(%r12), %rax
   59b5f:      	testq	%rax, %rax
   59b62:      	je	0x59ba5 <f.5+0x475>
   59b64:      	cmpl	$0x0, 0x8(%rax)
   59b68:      	je	0x59ba5 <f.5+0x475>
   59b6a:      	movq	0x10(%rax), %rax
   59b6e:      	testq	%rax, %rax
   59b71:      	je	0x59ba5 <f.5+0x475>
   59b73:      	movq	0x18(%r12), %rbx
   59b78:      	movq	0x10(%rax), %r14
   59b7c:      	decq	%rbx
   59b7f:      	leaq	0x10(%rsp), %rdi
   59b84:      	callq	0x2a070 <native_roots_leave>
   59b89:      	movq	%r14, %rdi
   59b8c:      	movq	%rbx, %rsi
   59b8f:      	addq	$0xb8, %rsp
   59b96:      	popq	%rbx
   59b97:      	popq	%r12
   59b99:      	popq	%r13
   59b9b:      	popq	%r14
   59b9d:      	popq	%r15
   59b9f:      	popq	%rbp
   59ba0:      	jmp	0x59540 <f.4>
   59ba5:      	callq	0x25cf0 <native_trap>
   59baa:      	int3
   59bab:      	int3
   59bac:      	int3
   59bad:      	int3
   59bae:      	int3
   59baf:      	int3

0000000000059bb0 <f.7>:
   59bb0:      	pushq	%r15
   59bb2:      	pushq	%r14
   59bb4:      	pushq	%r13
   59bb6:      	pushq	%r12
   59bb8:      	pushq	%rbx
   59bb9:      	subq	$0x40, %rsp
   59bbd:      	movq	%rsi, %rbx
   59bc0:      	movq	%rdi, %r15
   59bc3:      	leaq	0x8(%rsp), %rdi
   59bc8:      	movl	$0x4, %esi
   59bcd:      	callq	0x2a020 <native_roots_enter>
   59bd2:      	movq	%r15, 0x20(%rsp)
   59bd7:      	testq	%rbx, %rbx
   59bda:      	movq	$0x0, 0x28(%rsp)
   59be3:      	movq	$0x0, 0x30(%rsp)
   59bec:      	js	0x59ce3 <f.7+0x133>
   59bf2:      	leaq	0x28(%rsp), %r12
   59bf7:      	movq	%rbx, %r13
   59bfa:      	shrq	$0x20, %r13
   59bfe:      	leaq	0x8(%rsp), %r14
   59c03:      	nopw	%cs:(%rax,%rax)
   59c0d:      	nopl	(%rax)
   59c10:      	movl	$0x26, %esi
   59c15:      	movq	%r15, %rdi
   59c18:      	xorl	%edx, %edx
   59c1a:      	xorl	%ecx, %ecx
   59c1c:      	callq	0x29f30 <native_ref_test>
   59c21:      	testl	%eax, %eax
   59c23:      	je	0x59cff <f.7+0x14f>
   59c29:      	movq	%r15, 0x28(%rsp)
   59c2e:      	testq	%r15, %r15
   59c31:      	je	0x59cff <f.7+0x14f>
   59c37:      	movq	0x8(%r15), %rsi
   59c3b:      	movq	%rsi, %rax
   59c3e:      	shrq	$0x20, %rax
   59c42:      	jne	0x59cff <f.7+0x14f>
   59c48:      	testq	%r13, %r13
   59c4b:      	jne	0x59cff <f.7+0x14f>
   59c51:      	movq	0x10(%r15), %r15
   59c55:      	movq	%r15, 0x38(%rsp)
   59c5a:      	movq	$0x4, 0x18(%rsp)
   59c63:      	movl	$0x2b, %edi
   59c68:      	xorl	%edx, %edx
   59c6a:      	movl	$0x8, %ecx
   59c6f:      	callq	0x29c60 <native_array_new>
   59c74:      	testq	%r15, %r15
   59c77:      	je	0x59cff <f.7+0x14f>
   59c7d:      	testb	$0x1, %r15b
   59c81:      	jne	0x59cff <f.7+0x14f>
   59c83:      	cmpq	0x8(%r15), %rbx
   59c87:      	jae	0x59cff <f.7+0x14f>
   59c89:      	movq	%rax, 0x10(%r15,%rbx,8)
   59c8e:      	movq	0x28(%rsp), %r15
   59c93:      	testq	%r15, %r15
   59c96:      	je	0x59cff <f.7+0x14f>
   59c98:      	movq	0x18(%r15), %rax
   59c9c:      	testq	%rax, %rax
   59c9f:      	je	0x59cff <f.7+0x14f>
   59ca1:      	cmpl	$0x0, 0x8(%rax)
   59ca5:      	je	0x59cff <f.7+0x14f>
   59ca7:      	cmpq	$0x0, 0x10(%rax)
   59cac:      	je	0x59cff <f.7+0x14f>
   59cae:      	movq	%r14, %rdi
   59cb1:      	callq	0x2a070 <native_roots_leave>
   59cb6:      	movl	$0x4, %esi
   59cbb:      	movq	%r14, %rdi
   59cbe:      	callq	0x2a020 <native_roots_enter>
   59cc3:      	addq	$-0x1, %rbx
   59cc7:      	movq	%r15, 0x20(%rsp)
   59ccc:      	movq	$0x0, 0x8(%r12)
   59cd5:      	movq	$0x0, (%r12)
   59cdd:      	jb	0x59c10 <f.7+0x60>
   59ce3:      	leaq	0x8(%rsp), %rdi
   59ce8:      	callq	0x2a070 <native_roots_leave>
   59ced:      	xorl	%eax, %eax
   59cef:      	addq	$0x40, %rsp
   59cf3:      	popq	%rbx
   59cf4:      	popq	%r12
   59cf6:      	popq	%r13
   59cf8:      	popq	%r14
   59cfa:      	popq	%r15
   59cfc:      	retq	$0x8
   59cff:      	callq	0x25cf0 <native_trap>
   59d04:      	int3
   59d05:      	int3
   59d06:      	int3
   59d07:      	int3
   59d08:      	int3
   59d09:      	int3
   59d0a:      	int3
   59d0b:      	int3
   59d0c:      	int3
   59d0d:      	int3
   59d0e:      	int3
   59d0f:      	int3
