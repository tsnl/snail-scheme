import fs from 'node:fs';
const root = '/tmp/sfir-native-production-six-20261016/work-review';
for (const name of process.argv.slice(2)) {
  const lines = fs.readFileSync(`${root}/${name}-candidate.asm`, 'utf8').split('\n');
  const sections = [];
  for (const [index, line] of lines.entries()) {
    const match = line.match(/^([0-9a-f]+) <(.+)>:$/);
    if (match) {
      if (sections.length) sections.at(-1).end = index;
      sections.push({name: match[2], address: match[1], start: index, end: lines.length});
    }
  }
  const guest = sections.filter(section => /^f\.\d+$/.test(section.name));
  fs.writeFileSync(`${root}/${name}-candidate-guest.asm`, guest.map(section => lines.slice(section.start, section.end).join('\n')).join('\n'));
  console.log(JSON.stringify({case: name, guest: guest.map(section => ({name: section.name,
    address: section.address, line: section.start + 1, lines: section.end - section.start,
    directGuestCalls: lines.slice(section.start, section.end).filter(line => /callq\s.*<f\.\d+>/.test(line)).length,
    calls: Object.fromEntries([...new Set(lines.slice(section.start, section.end).map(line => line.match(/callq\s.*<(f\.\d+|native_[a-z_]+)>/)?.[1]).filter(Boolean))]
      .map(target => [target, lines.slice(section.start, section.end).filter(line => line.includes(`<${target}>`) && /callq\s/.test(line)).length]))}))}));
}
