0000000000059fc0 <f.3>:
   59fc0:      	pushq	%rbp
   59fc1:      	pushq	%r14
   59fc3:      	pushq	%rbx
   59fc4:      	subq	$0x20, %rsp
   59fc8:      	movl	%esi, %ebp
   59fca:      	movq	%rdi, %rbx
   59fcd:      	movq	%rsp, %rdi
   59fd0:      	xorl	%esi, %esi
   59fd2:      	callq	0x2adb0 <native_roots_enter>
   59fd7:      	movq	%rbx, 0x18(%rsp)
   59fdc:      	testq	%rbx, %rbx
   59fdf:      	je	0x5a064 <f.3+0xa4>
   59fe5:      	testb	$0x1, %bl
   59fe8:      	jne	0x5a064 <f.3+0xa4>
   59fea:      	movq	0x8(%rbx), %rax
   59fee:      	movl	%ebp, %ecx
   59ff0:      	cmpq	%rcx, %rax
   59ff3:      	jbe	0x5a064 <f.3+0xa4>
   59ff5:      	movzbl	0x10(%rbx,%rcx), %r14d
   59ffb:      	testb	%r14b, %r14b
   59ffe:      	jns	0x5a04e <f.3+0x8e>
   5a000:      	cmpb	$-0x10, %r14b
   5a004:      	movl	$0x4, %edx
   5a009:      	sbbl	$0x0, %edx
   5a00c:      	cmpb	$-0x20, %r14b
   5a010:      	movl	$0x2, %ecx
   5a015:      	cmovael	%edx, %ecx
   5a018:      	movl	$0x7f, %edx
   5a01d:      	shrl	%cl, %edx
   5a01f:      	andl	%edx, %r14d
   5a022:      	incl	%ebp
   5a024:      	decq	%rcx
   5a027:      	nopw	(%rax,%rax)
   5a030:      	movl	%ebp, %edx
   5a032:      	cmpq	%rdx, %rax
   5a035:      	jbe	0x5a064 <f.3+0xa4>
   5a037:      	movzbl	0x10(%rbx,%rdx), %esi
   5a03c:      	andl	$0x3f, %esi
   5a03f:      	shll	$0x6, %r14d
   5a043:      	orl	%esi, %r14d
   5a046:      	leal	0x1(%rdx), %ebp
   5a049:      	decq	%rcx
   5a04c:      	jne	0x5a030 <f.3+0x70>
   5a04e:      	movq	%rsp, %rdi
   5a051:      	callq	0x2ae00 <native_roots_leave>
   5a056:      	movl	%r14d, %eax
   5a059:      	addq	$0x20, %rsp
   5a05d:      	popq	%rbx
   5a05e:      	popq	%r14
   5a060:      	popq	%rbp
   5a061:      	retq	$0x8
   5a064:      	callq	0x26990 <native_trap>
   5a069:      	int3
   5a06a:      	int3
   5a06b:      	int3
   5a06c:      	int3
   5a06d:      	int3
   5a06e:      	int3
   5a06f:      	int3

000000000005a070 <f.4>:
   5a070:      	pushq	%r15
   5a072:      	pushq	%r14
   5a074:      	pushq	%rbx
   5a075:      	subq	$0x30, %rsp
   5a079:      	movl	%esi, %ebx
   5a07b:      	movq	%rdi, %r14
   5a07e:      	leaq	0x8(%rsp), %rdi
   5a083:      	xorl	%esi, %esi
   5a085:      	callq	0x2adb0 <native_roots_enter>
   5a08a:      	movq	%r14, 0x20(%rsp)
   5a08f:      	movq	$0x0, 0x28(%rsp)
   5a098:      	testq	%r14, %r14
   5a09b:      	je	0x5a1c1 <f.4+0x151>
   5a0a1:      	movl	0x8(%r14), %ecx
   5a0a5:      	movl	%ecx, %eax
   5a0a7:      	subl	%ebx, %eax
   5a0a9:      	jb	0x5a1c1 <f.4+0x151>
   5a0af:      	movl	0x10(%r14), %edx
   5a0b3:      	cmpl	%edx, %ecx
   5a0b5:      	jne	0x5a0bf <f.4+0x4f>
   5a0b7:      	movl	%ebx, %r15d
   5a0ba:      	jmp	0x5a1a8 <f.4+0x138>
   5a0bf:      	movl	0x20(%r14), %esi
   5a0c3:      	movl	%ebx, %edi
   5a0c5:      	subl	%esi, %edi
   5a0c7:      	movl	%esi, %r8d
   5a0ca:      	subl	%ebx, %r8d
   5a0cd:      	cmovbl	%edi, %r8d
   5a0d1:      	xorl	%r15d, %r15d
   5a0d4:      	cmpl	%r8d, %ebx
   5a0d7:      	movl	$0x0, %edi
   5a0dc:      	jb	0x5a0e4 <f.4+0x74>
   5a0de:      	movl	0x28(%r14), %r15d
   5a0e2:      	movl	%esi, %edi
   5a0e4:      	movl	%ebx, %esi
   5a0e6:      	subl	%edi, %esi
   5a0e8:      	movl	%edi, %r8d
   5a0eb:      	subl	%ebx, %r8d
   5a0ee:      	cmovbl	%esi, %r8d
   5a0f2:      	cmpl	%r8d, %eax
   5a0f5:      	cmovbl	%edx, %r15d
   5a0f9:      	cmovael	%edi, %ecx
   5a0fc:      	movq	0x18(%r14), %rax
   5a100:      	movq	%rax, 0x28(%rsp)
   5a105:      	movl	%ebx, %edx
   5a107:      	subl	%ecx, %edx
   5a109:      	jbe	0x5a168 <f.4+0xf8>
   5a10b:      	testq	%rax, %rax
   5a10e:      	je	0x5a1c1 <f.4+0x151>
   5a114:      	testb	$0x1, %al
   5a116:      	jne	0x5a1c1 <f.4+0x151>
   5a11c:      	movq	0x8(%rax), %rcx
   5a120:      	movl	$0x2, %esi
   5a125:      	movl	$0x1, %edi
   5a12a:      	nopw	(%rax,%rax)
   5a130:      	movl	%r15d, %r8d
   5a133:      	cmpq	%r8, %rcx
   5a136:      	jbe	0x5a1c1 <f.4+0x151>
   5a13c:      	movzbl	0x10(%rax,%r8), %r9d
   5a142:      	cmpb	$-0x10, %r9b
   5a146:      	movl	$0x4, %r15d
   5a14c:      	sbbl	$0x0, %r15d
   5a150:      	cmpb	$-0x20, %r9b
   5a154:      	cmovbl	%esi, %r15d
   5a158:      	testb	%r9b, %r9b
   5a15b:      	cmovnsl	%edi, %r15d
   5a15f:      	addl	%r8d, %r15d
   5a162:      	decl	%edx
   5a164:      	jne	0x5a130 <f.4+0xc0>
   5a166:      	jmp	0x5a196 <f.4+0x126>
   5a168:      	jae	0x5a196 <f.4+0x126>
   5a16a:      	testq	%rax, %rax
   5a16d:      	je	0x5a1c1 <f.4+0x151>
   5a16f:      	testb	$0x1, %al
   5a171:      	jne	0x5a1c1 <f.4+0x151>
   5a173:      	movq	0x8(%rax), %rdx
   5a177:      	nopw	(%rax,%rax)
   5a180:      	decl	%r15d
   5a183:      	cmpq	%r15, %rdx
   5a186:      	jbe	0x5a1c1 <f.4+0x151>
   5a188:      	cmpb	$-0x40, 0x10(%rax,%r15)
   5a18e:      	jl	0x5a180 <f.4+0x110>
   5a190:      	decl	%ecx
   5a192:      	cmpl	%ecx, %ebx
   5a194:      	jb	0x5a180 <f.4+0x110>
   5a196:      	movl	%ebx, 0x20(%r14)
   5a19a:      	movq	0x20(%rsp), %rax
   5a19f:      	testq	%rax, %rax
   5a1a2:      	je	0x5a1c1 <f.4+0x151>
   5a1a4:      	movl	%r15d, 0x28(%rax)
   5a1a8:      	leaq	0x8(%rsp), %rdi
   5a1ad:      	callq	0x2ae00 <native_roots_leave>
   5a1b2:      	movl	%r15d, %eax
   5a1b5:      	addq	$0x30, %rsp
   5a1b9:      	popq	%rbx
   5a1ba:      	popq	%r14
   5a1bc:      	popq	%r15
   5a1be:      	retq	$0x8
   5a1c1:      	callq	0x26990 <native_trap>
   5a1c6:      	int3
   5a1c7:      	int3
   5a1c8:      	int3
   5a1c9:      	int3
   5a1ca:      	int3
   5a1cb:      	int3
   5a1cc:      	int3
   5a1cd:      	int3
   5a1ce:      	int3
   5a1cf:      	int3

000000000005a1d0 <f.5>:
   5a1d0:      	pushq	%rbp
   5a1d1:      	pushq	%r15
   5a1d3:      	pushq	%r14
   5a1d5:      	pushq	%r13
   5a1d7:      	pushq	%r12
   5a1d9:      	pushq	%rbx
   5a1da:      	subq	$0x48, %rsp
   5a1de:      	movq	%rsi, %rbx
   5a1e1:      	movq	%rdi, %r14
   5a1e4:      	leaq	0x10(%rsp), %rdi
   5a1e9:      	movl	$0x4, %esi
   5a1ee:      	callq	0x2adb0 <native_roots_enter>
   5a1f3:      	movq	%r14, 0x28(%rsp)
   5a1f8:      	testq	%r14, %r14
   5a1fb:      	movq	$0x0, 0x30(%rsp)
   5a204:      	movq	$0x0, 0x38(%rsp)
   5a20d:      	je	0x5a41c <f.5+0x24c>
   5a213:      	movq	0x8(%r14), %rax
   5a217:      	movq	%rax, 0x30(%rsp)
   5a21c:      	testq	%rax, %rax
   5a21f:      	je	0x5a41c <f.5+0x24c>
   5a225:      	testb	$0x1, %al
   5a227:      	jne	0x5a41c <f.5+0x24c>
   5a22d:      	movl	0x8(%rax), %eax
   5a230:      	cmpq	%rax, %rbx
   5a233:      	ja	0x5a41c <f.5+0x24c>
   5a239:      	xorl	%ebp, %ebp
   5a23b:      	testq	%rbx, %rbx
   5a23e:      	je	0x5a37f <f.5+0x1af>
   5a244:      	movl	$0x2, %r15d
   5a24a:      	xorl	%r14d, %r14d
   5a24d:      	jmp	0x5a25e <f.5+0x8e>
   5a24f:      	nop
   5a250:      	addl	%r12d, %r14d
   5a253:      	incl	%ebp
   5a255:      	cmpl	%ebx, %r14d
   5a258:      	je	0x5a371 <f.5+0x1a1>
   5a25e:      	movq	0x30(%rsp), %rdi
   5a263:      	testq	%rdi, %rdi
   5a266:      	je	0x5a41c <f.5+0x24c>
   5a26c:      	testb	$0x1, %dil
   5a270:      	jne	0x5a41c <f.5+0x24c>
   5a276:      	movq	0x8(%rdi), %rax
   5a27a:      	movl	%r14d, %ecx
   5a27d:      	cmpq	%rcx, %rax
   5a280:      	jbe	0x5a41c <f.5+0x24c>
   5a286:      	movzbl	0x10(%rdi,%rcx), %r13d
   5a28c:      	movl	$0x1, %r12d
   5a292:      	testb	%r13b, %r13b
   5a295:      	jns	0x5a250 <f.5+0x80>
   5a297:      	leal	0xb(%r13), %ecx
   5a29b:      	cmpb	$-0x34, %cl
   5a29e:      	jbe	0x5a41c <f.5+0x24c>
   5a2a4:      	cmpb	$-0x10, %r13b
   5a2a8:      	movl	$0x4, %r12d
   5a2ae:      	sbbl	$0x0, %r12d
   5a2b2:      	cmpb	$-0x20, %r13b
   5a2b6:      	cmovbl	%r15d, %r12d
   5a2ba:      	movl	%ebx, %ecx
   5a2bc:      	subl	%r14d, %ecx
   5a2bf:      	cmpl	%ecx, %r12d
   5a2c2:      	ja	0x5a41c <f.5+0x24c>
   5a2c8:      	movl	%r12d, %ecx
   5a2cb:      	leal	0x1(%r14), %edx
   5a2cf:      	decq	%rcx
   5a2d2:      	nopw	%cs:(%rax,%rax)
   5a2dc:      	nopl	(%rax)
   5a2e0:      	movl	%edx, %edx
   5a2e2:      	cmpq	%rdx, %rax
   5a2e5:      	jbe	0x5a41c <f.5+0x24c>
   5a2eb:      	cmpb	$-0x40, 0x10(%rdi,%rdx)
   5a2f0:      	jge	0x5a41c <f.5+0x24c>
   5a2f6:      	incl	%edx
   5a2f8:      	decq	%rcx
   5a2fb:      	jne	0x5a2e0 <f.5+0x110>
   5a2fd:      	movq	%rdi, 0x40(%rsp)
   5a302:      	movq	$0x4, 0x20(%rsp)
   5a30b:      	movl	%r14d, %esi
   5a30e:      	callq	0x59fc0 <f.3>
   5a313:      	subq	$0x8, %rsp
   5a317:      	cmpl	$0x80, %eax
   5a31c:      	jb	0x5a41c <f.5+0x24c>
   5a322:      	xorl	%ecx, %ecx
   5a324:      	cmpb	$-0x20, %r13b
   5a328:      	setb	%cl
   5a32b:      	cmpl	$0x10000, %eax          # imm = 0x10000
   5a330:      	movl	$0x4, %edx
   5a335:      	sbbl	$0x0, %edx
   5a338:      	xorl	%esi, %esi
   5a33a:      	cmpl	%r12d, %edx
   5a33d:      	sete	%sil
   5a341:      	cmpl	$0x800, %eax            # imm = 0x800
   5a346:      	cmovael	%esi, %ecx
   5a349:      	testb	%cl, %cl
   5a34b:      	je	0x5a41c <f.5+0x24c>
   5a351:      	cmpl	$0x10ffff, %eax         # imm = 0x10FFFF
   5a356:      	ja	0x5a41c <f.5+0x24c>
   5a35c:      	andl	$0xfffff800, %eax       # imm = 0xFFFFF800
   5a361:      	cmpl	$0xd800, %eax           # imm = 0xD800
   5a366:      	jne	0x5a250 <f.5+0x80>
   5a36c:      	jmp	0x5a41c <f.5+0x24c>
   5a371:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
   5a376:      	cmpq	%rax, %rbx
   5a379:      	jae	0x5a41c <f.5+0x24c>
   5a37f:      	movq	$0x3, 0x20(%rsp)
   5a388:      	movl	$0xcb, %edi
   5a38d:      	movl	%ebx, %esi
   5a38f:      	xorl	%edx, %edx
   5a391:      	movl	$0x1, %ecx
   5a396:      	callq	0x2a970 <native_array_new>
   5a39b:      	movq	%rax, 0x38(%rsp)
   5a3a0:      	movq	0x30(%rsp), %rdx
   5a3a5:      	movq	%rax, %rdi
   5a3a8:      	xorl	%esi, %esi
   5a3aa:      	xorl	%ecx, %ecx
   5a3ac:      	movl	%ebx, %r8d
   5a3af:      	movl	$0x1, %r9d
   5a3b5:      	callq	0x2a900 <native_array_copy>
   5a3ba:      	movq	0x38(%rsp), %r14
   5a3bf:      	movq	%r14, 0x40(%rsp)
   5a3c4:      	movq	$0x4, 0x20(%rsp)
   5a3cd:      	movl	$0x30, %edi
   5a3d2:      	callq	0x28930 <native_alloc>
   5a3d7:      	testq	%rax, %rax
   5a3da:      	je	0x5a41c <f.5+0x24c>
   5a3dc:      	movq	$0xc6, (%rax)
   5a3e3:      	movl	%ebp, 0x8(%rax)
   5a3e6:      	movl	%ebx, 0x10(%rax)
   5a3e9:      	movq	%r14, 0x18(%rax)
   5a3ed:      	movl	$0x0, 0x20(%rax)
   5a3f4:      	movl	$0x0, 0x28(%rax)
   5a3fb:      	leaq	0x10(%rsp), %rdi
   5a400:      	movq	%rax, %rbx
   5a403:      	callq	0x2ae00 <native_roots_leave>
   5a408:      	movq	%rbx, %rax
   5a40b:      	addq	$0x48, %rsp
   5a40f:      	popq	%rbx
   5a410:      	popq	%r12
   5a412:      	popq	%r13
   5a414:      	popq	%r14
   5a416:      	popq	%r15
   5a418:      	popq	%rbp
   5a419:      	retq	$0x8
   5a41c:      	callq	0x26990 <native_trap>
   5a421:      	int3
   5a422:      	int3
   5a423:      	int3
   5a424:      	int3
   5a425:      	int3
   5a426:      	int3
   5a427:      	int3
   5a428:      	int3
   5a429:      	int3
   5a42a:      	int3
   5a42b:      	int3
   5a42c:      	int3
   5a42d:      	int3
   5a42e:      	int3
   5a42f:      	int3

000000000005a430 <f.6>:
   5a430:      	pushq	%r15
   5a432:      	pushq	%r14
   5a434:      	pushq	%r12
   5a436:      	pushq	%rbx
   5a437:      	subq	$0x58, %rsp
   5a43b:      	movq	%rsi, %r14
   5a43e:      	movq	%rdi, %rbx
   5a441:      	leaq	0x10(%rsp), %rdi
   5a446:      	movl	$0x6, %esi
   5a44b:      	callq	0x2adb0 <native_roots_enter>
   5a450:      	movq	%rbx, 0x28(%rsp)
   5a455:      	movq	$0x0, 0x30(%rsp)
   5a45e:      	movq	$0x0, 0x38(%rsp)
   5a467:      	movq	$0x3, 0x20(%rsp)
   5a470:      	movl	$0x18, %edi
   5a475:      	callq	0x28930 <native_alloc>
   5a47a:      	testq	%rax, %rax
   5a47d:      	je	0x5a580 <f.6+0x150>
   5a483:      	movq	%rax, %rbx
   5a486:      	movq	$0x7a, (%rax)
   5a48d:      	movl	$0x0, 0x8(%rax)
   5a494:      	movq	$0x0, 0x10(%rax)
   5a49c:      	movq	%rax, 0x30(%rsp)
   5a4a1:      	movq	%rax, 0x40(%rsp)
   5a4a6:      	leaq	0x5b8b(%rip), %r12      # 0x60038 <ref.7>
   5a4ad:      	movq	%r12, 0x48(%rsp)
   5a4b2:      	movq	%rax, 0x50(%rsp)
   5a4b7:      	movq	$0x6, 0x20(%rsp)
   5a4c0:      	movl	$0x18, %edi
   5a4c5:      	callq	0x28930 <native_alloc>
   5a4ca:      	testq	%rax, %rax
   5a4cd:      	je	0x5a580 <f.6+0x150>
   5a4d3:      	movq	%rax, %r15
   5a4d6:      	movq	$0x76, (%rax)
   5a4dd:      	movq	%r14, 0x8(%rax)
   5a4e1:      	movq	%rbx, 0x10(%rax)
   5a4e5:      	movq	%rax, 0x40(%rsp)
   5a4ea:      	movq	%r12, 0x48(%rsp)
   5a4ef:      	movq	%rbx, 0x50(%rsp)
   5a4f4:      	movq	$0x6, 0x20(%rsp)
   5a4fd:      	movl	$0x18, %edi
   5a502:      	callq	0x28930 <native_alloc>
   5a507:      	testq	%rax, %rax
   5a50a:      	je	0x5a580 <f.6+0x150>
   5a50c:      	movq	$0xa2, (%rax)
   5a513:      	movq	%r12, 0x8(%rax)
   5a517:      	movq	%r15, 0x10(%rax)
   5a51b:      	movq	%rax, 0x10(%rbx)
   5a51f:      	movq	0x30(%rsp), %rax
   5a524:      	testq	%rax, %rax
   5a527:      	je	0x5a580 <f.6+0x150>
   5a529:      	movl	$0x1, 0x8(%rax)
   5a530:      	movq	0x30(%rsp), %rax
   5a535:      	testq	%rax, %rax
   5a538:      	je	0x5a580 <f.6+0x150>
   5a53a:      	cmpl	$0x0, 0x8(%rax)
   5a53e:      	je	0x5a580 <f.6+0x150>
   5a540:      	movq	0x10(%rax), %rax
   5a544:      	testq	%rax, %rax
   5a547:      	je	0x5a580 <f.6+0x150>
   5a549:      	movq	%rax, 0x38(%rsp)
   5a54e:      	movq	0x8(%rax), %rcx
   5a552:      	testq	%rcx, %rcx
   5a555:      	je	0x5a580 <f.6+0x150>
   5a557:      	movq	0x10(%rax), %rbx
   5a55b:      	movq	0x8(%rcx), %r14
   5a55f:      	leaq	0x10(%rsp), %rdi
   5a564:      	callq	0x2ae00 <native_roots_leave>
   5a569:      	movq	%rbx, %rdi
   5a56c:      	xorl	%esi, %esi
   5a56e:      	xorl	%edx, %edx
   5a570:      	movq	%r14, %rax
   5a573:      	addq	$0x58, %rsp
   5a577:      	popq	%rbx
   5a578:      	popq	%r12
   5a57a:      	popq	%r14
   5a57c:      	popq	%r15
   5a57e:      	jmpq	*%rax
   5a580:      	callq	0x26990 <native_trap>
   5a585:      	int3
   5a586:      	int3
   5a587:      	int3
   5a588:      	int3
   5a589:      	int3
   5a58a:      	int3
   5a58b:      	int3
   5a58c:      	int3
   5a58d:      	int3
   5a58e:      	int3
   5a58f:      	int3

000000000005a590 <f.7>:
   5a590:      	pushq	%rbp
   5a591:      	pushq	%r15
   5a593:      	pushq	%r14
   5a595:      	pushq	%r13
   5a597:      	pushq	%r12
   5a599:      	pushq	%rbx
   5a59a:      	subq	$0x138, %rsp            # imm = 0x138
   5a5a1:      	movq	%rdx, %r13
   5a5a4:      	movq	%rsi, %rbp
   5a5a7:      	movq	%rdi, %r14
   5a5aa:      	leaq	0x30(%rsp), %rbx
   5a5af:      	leaq	0x10(%rsp), %rdi
   5a5b4:      	movl	$0x1b, %esi
   5a5b9:      	callq	0x2adb0 <native_roots_enter>
   5a5be:      	movq	%r14, 0x28(%rsp)
   5a5c3:      	movl	$0xa8, %edx
   5a5c8:      	movq	%rbx, %rdi
   5a5cb:      	xorl	%esi, %esi
   5a5cd:      	callq	0x5cf90 <memset@plt>
   5a5d2:      	testq	%r14, %r14
   5a5d5:      	je	0x5b841 <f.7+0x12b1>
   5a5db:      	leaq	0x120(%rsp), %r15
   5a5e3:      	movq	%r14, 0x68(%rsp)
   5a5e8:      	cmpq	%rbp, 0x8(%r14)
   5a5ec:      	jle	0x5b802 <f.7+0x1272>
   5a5f2:      	nopw	%cs:(%rax,%rax)
   5a5fc:      	nopl	(%rax)
   5a600:      	cmpb	$0x0, 0x7f41(%rip)      # 0x62548 <g.28>
   5a607:      	je	0x5b841 <f.7+0x12b1>
   5a60d:      	cmpb	$0x0, 0x7ef4(%rip)      # 0x62508 <g.20>
   5a614:      	leaq	0x5a7d(%rip), %r13      # 0x60098 <ref.16>
   5a61b:      	je	0x5b841 <f.7+0x12b1>
   5a621:      	cmpq	$0x0, 0x7ed7(%rip)      # 0x62500 <g.19>
   5a629:      	je	0x5b841 <f.7+0x12b1>
   5a62f:      	movq	0x7f0a(%rip), %rbx      # 0x62540 <g.27>
   5a636:      	movq	$0x16, 0x20(%rsp)
   5a63f:      	movq	%r15, %rdi
   5a642:      	xorl	%esi, %esi
   5a644:      	callq	0x2adb0 <native_roots_enter>
   5a649:      	movq	$0x0, 0x130(%rsp)
   5a655:      	movq	%rbx, %rdi
   5a658:      	callq	0x14b30 <hide_i64>
   5a65d:      	movq	%rax, %r14
   5a660:      	movq	%r15, %rdi
   5a663:      	callq	0x2ae00 <native_roots_leave>
   5a668:      	cmpb	$0x0, 0x7ee9(%rip)      # 0x62558 <g.30>
   5a66f:      	je	0x5b841 <f.7+0x12b1>
   5a675:      	cmpb	$0x0, 0x7e8c(%rip)      # 0x62508 <g.20>
   5a67c:      	je	0x5b841 <f.7+0x12b1>
   5a682:      	cmpq	$0x0, 0x7e76(%rip)      # 0x62500 <g.19>
   5a68a:      	je	0x5b841 <f.7+0x12b1>
   5a690:      	movq	0x7eb9(%rip), %rbx      # 0x62550 <g.29>
   5a697:      	movq	$0x16, 0x20(%rsp)
   5a6a0:      	movq	%r15, %rdi
   5a6a3:      	xorl	%esi, %esi
   5a6a5:      	callq	0x2adb0 <native_roots_enter>
   5a6aa:      	movq	$0x0, 0x130(%rsp)
   5a6b6:      	movq	%rbx, %rdi
   5a6b9:      	callq	0x14b30 <hide_i64>
   5a6be:      	movq	%rax, %rbx
   5a6c1:      	movq	%r15, %rdi
   5a6c4:      	callq	0x2ae00 <native_roots_leave>
   5a6c9:      	cmpb	$0x0, 0x7e68(%rip)      # 0x62538 <g.26>
   5a6d0:      	je	0x5b841 <f.7+0x12b1>
   5a6d6:      	cmpq	$0x0, 0x7e52(%rip)      # 0x62530 <g.25>
   5a6de:      	je	0x5b841 <f.7+0x12b1>
   5a6e4:      	movq	%r14, 0x110(%rsp)
   5a6ec:      	movq	%r13, 0xd8(%rsp)
   5a6f4:      	movq	$0x17, 0x20(%rsp)
   5a6fd:      	movl	$0x18, %edi
   5a702:      	callq	0x28930 <native_alloc>
   5a707:      	testq	%rax, %rax
   5a70a:      	je	0x5b841 <f.7+0x12b1>
   5a710:      	movq	%rax, %r14
   5a713:      	movq	$0x56, (%rax)
   5a71a:      	movl	$0x0, 0x8(%rax)
   5a721:      	movq	$0x0, 0x10(%rax)
   5a729:      	movq	%rax, 0x78(%rsp)
   5a72e:      	movq	%rax, 0xd8(%rsp)
   5a736:      	movq	%r13, 0xe0(%rsp)
   5a73e:      	movq	$0x18, 0x20(%rsp)
   5a747:      	movl	$0x18, %edi
   5a74c:      	callq	0x28930 <native_alloc>
   5a751:      	testq	%rax, %rax
   5a754:      	je	0x5b841 <f.7+0x12b1>
   5a75a:      	movq	%rax, %r12
   5a75d:      	movq	%rbx, 0x108(%rsp)
   5a765:      	movq	$0x52, (%rax)
   5a76c:      	movl	$0x0, 0x8(%rax)
   5a773:      	movq	$0x0, 0x10(%rax)
   5a77b:      	movq	%rax, 0x90(%rsp)
   5a783:      	movq	%rax, 0xd8(%rsp)
   5a78b:      	movq	%r14, 0xe0(%rsp)
   5a793:      	movq	%r13, 0xe8(%rsp)
   5a79b:      	movq	$0x19, 0x20(%rsp)
   5a7a4:      	movl	$0x18, %edi
   5a7a9:      	callq	0x28930 <native_alloc>
   5a7ae:      	testq	%rax, %rax
   5a7b1:      	je	0x5b841 <f.7+0x12b1>
   5a7b7:      	movq	%rax, %r15
   5a7ba:      	movq	%rbp, 0x118(%rsp)
   5a7c2:      	movq	$0x56, (%rax)
   5a7c9:      	movl	$0x0, 0x8(%rax)
   5a7d0:      	movq	$0x0, 0x10(%rax)
   5a7d8:      	movq	%rax, 0x80(%rsp)
   5a7e0:      	movq	%rax, 0xd8(%rsp)
   5a7e8:      	movq	%r12, 0xe0(%rsp)
   5a7f0:      	movq	%r14, 0xe8(%rsp)
   5a7f8:      	movq	%r13, 0xf0(%rsp)
   5a800:      	movq	$0x1a, 0x20(%rsp)
   5a809:      	movl	$0x18, %edi
   5a80e:      	callq	0x28930 <native_alloc>
   5a813:      	testq	%rax, %rax
   5a816:      	je	0x5b841 <f.7+0x12b1>
   5a81c:      	movq	%rax, %rbx
   5a81f:      	movq	$0x56, (%rax)
   5a826:      	movl	$0x0, 0x8(%rax)
   5a82d:      	movq	$0x0, 0x10(%rax)
   5a835:      	movq	%rax, 0x88(%rsp)
   5a83d:      	movq	%rax, 0xd8(%rsp)
   5a845:      	movq	%r15, 0xe0(%rsp)
   5a84d:      	movq	%r12, 0xe8(%rsp)
   5a855:      	movq	%r14, 0xf0(%rsp)
   5a85d:      	movq	%r13, 0xf8(%rsp)
   5a865:      	movq	$0x1b, 0x20(%rsp)
   5a86e:      	movl	$0x28, %edi
   5a873:      	callq	0x28930 <native_alloc>
   5a878:      	testq	%rax, %rax
   5a87b:      	je	0x5b841 <f.7+0x12b1>
   5a881:      	movq	%r13, %rbp
   5a884:      	movq	%rax, %r13
   5a887:      	movq	$0x3e, (%rax)
   5a88e:      	movq	%r14, 0x8(%rax)
   5a892:      	movq	%r12, 0x10(%rax)
   5a896:      	movq	%r15, 0x18(%rax)
   5a89a:      	movq	%rbx, 0x20(%rax)
   5a89e:      	movq	%rax, 0xd8(%rsp)
   5a8a6:      	movq	%rbp, 0xe0(%rsp)
   5a8ae:      	movq	$0x18, 0x20(%rsp)
   5a8b7:      	movl	$0x18, %edi
   5a8bc:      	callq	0x28930 <native_alloc>
   5a8c1:      	testq	%rax, %rax
   5a8c4:      	je	0x5b841 <f.7+0x12b1>
   5a8ca:      	movq	%rax, %rbx
   5a8cd:      	movq	$0x92, (%rax)
   5a8d4:      	movq	%rbp, 0x8(%rax)
   5a8d8:      	movq	%r13, 0x10(%rax)
   5a8dc:      	movq	%rax, 0xd8(%rsp)
   5a8e4:      	movq	$0x17, 0x20(%rsp)
   5a8ed:      	movl	$0x10, %edi
   5a8f2:      	callq	0x28930 <native_alloc>
   5a8f7:      	testq	%rax, %rax
   5a8fa:      	je	0x5b841 <f.7+0x12b1>
   5a900:      	movq	$0x4e, (%rax)
   5a907:      	movq	%rbx, 0x8(%rax)
   5a90b:      	movq	%rax, 0x98(%rsp)
   5a913:      	movq	0x78(%rsp), %rax
   5a918:      	testq	%rax, %rax
   5a91b:      	leaq	0x5766(%rip), %r12      # 0x60088 <ref.14>
   5a922:      	leaq	0x573f(%rip), %r13      # 0x60068 <ref.12>
   5a929:      	je	0x5b841 <f.7+0x12b1>
   5a92f:      	movq	$0x2bd, 0x10(%rax)      # imm = 0x2BD
   5a937:      	movq	0x78(%rsp), %rax
   5a93c:      	testq	%rax, %rax
   5a93f:      	je	0x5b841 <f.7+0x12b1>
   5a945:      	movl	$0x1, 0x8(%rax)
   5a94c:      	movq	0x90(%rsp), %rbx
   5a954:      	movq	%rbx, 0xd8(%rsp)
   5a95c:      	movq	$0x17, 0x20(%rsp)
   5a965:      	movl	$0x10, %edi
   5a96a:      	callq	0x28930 <native_alloc>
   5a96f:      	testq	%rax, %rax
   5a972:      	je	0x5b841 <f.7+0x12b1>
   5a978:      	movq	$0x3a, (%rax)
   5a97f:      	movq	$0x1, 0x8(%rax)
   5a987:      	testq	%rbx, %rbx
   5a98a:      	je	0x5b841 <f.7+0x12b1>
   5a990:      	movq	%rax, 0x10(%rbx)
   5a994:      	movq	0x90(%rsp), %rax
   5a99c:      	testq	%rax, %rax
   5a99f:      	je	0x5b841 <f.7+0x12b1>
   5a9a5:      	movl	$0x1, 0x8(%rax)
   5a9ac:      	movq	0x80(%rsp), %rax
   5a9b4:      	testq	%rax, %rax
   5a9b7:      	je	0x5b841 <f.7+0x12b1>
   5a9bd:      	movq	$0xb583b, 0x10(%rax)    # imm = 0xB583B
   5a9c5:      	movq	0x80(%rsp), %rax
   5a9cd:      	testq	%rax, %rax
   5a9d0:      	je	0x5b841 <f.7+0x12b1>
   5a9d6:      	movl	$0x1, 0x8(%rax)
   5a9dd:      	movq	0x88(%rsp), %rax
   5a9e5:      	testq	%rax, %rax
   5a9e8:      	je	0x5b841 <f.7+0x12b1>
   5a9ee:      	movq	$0x7ffff, 0x10(%rax)    # imm = 0x7FFFF
   5a9f6:      	movq	0x88(%rsp), %rax
   5a9fe:      	testq	%rax, %rax
   5aa01:      	je	0x5b841 <f.7+0x12b1>
   5aa07:      	movl	$0x1, 0x8(%rax)
   5aa0e:      	movq	$0x16, 0x20(%rsp)
   5aa17:      	movl	$0x18, %edi
   5aa1c:      	callq	0x28930 <native_alloc>
   5aa21:      	testq	%rax, %rax
   5aa24:      	je	0x5b841 <f.7+0x12b1>
   5aa2a:      	movq	%rax, %r14
   5aa2d:      	movq	$0x5a, (%rax)
   5aa34:      	movl	$0x0, 0x8(%rax)
   5aa3b:      	movq	$0x0, 0x10(%rax)
   5aa43:      	movq	%rax, 0x70(%rsp)
   5aa48:      	movq	0x98(%rsp), %r15
   5aa50:      	movq	%rax, 0xd8(%rsp)
   5aa58:      	movq	%r15, 0xe0(%rsp)
   5aa60:      	movq	%rax, 0xe8(%rsp)
   5aa68:      	movq	$0x19, 0x20(%rsp)
   5aa71:      	movl	$0x18, %edi
   5aa76:      	callq	0x28930 <native_alloc>
   5aa7b:      	testq	%rax, %rax
   5aa7e:      	je	0x5b841 <f.7+0x12b1>
   5aa84:      	movq	%rax, %rbx
   5aa87:      	movq	$0x36, (%rax)
   5aa8e:      	movq	%r15, 0x8(%rax)
   5aa92:      	movq	%r14, 0x10(%rax)
   5aa96:      	movq	%rax, 0xd8(%rsp)
   5aa9e:      	movq	%r14, 0xe0(%rsp)
   5aaa6:      	movq	$0x18, 0x20(%rsp)
   5aaaf:      	movl	$0x10, %edi
   5aab4:      	callq	0x28930 <native_alloc>
   5aab9:      	testq	%rax, %rax
   5aabc:      	je	0x5b841 <f.7+0x12b1>
   5aac2:      	movq	$0x32, (%rax)
   5aac9:      	movq	%rbx, 0x8(%rax)
   5aacd:      	movq	%rax, 0x10(%r14)
   5aad1:      	movq	0x70(%rsp), %rax
   5aad6:      	testq	%rax, %rax
   5aad9:      	je	0x5b841 <f.7+0x12b1>
   5aadf:      	movl	$0x1, 0x8(%rax)
   5aae6:      	movq	0x70(%rsp), %r14
   5aaeb:      	movq	0x98(%rsp), %r15
   5aaf3:      	movq	%r14, 0xd8(%rsp)
   5aafb:      	movq	%r15, 0xe0(%rsp)
   5ab03:      	movq	%r12, 0xe8(%rsp)
   5ab0b:      	movq	%r13, 0xf0(%rsp)
   5ab13:      	movq	$0x1a, 0x20(%rsp)
   5ab1c:      	movl	$0x18, %edi
   5ab21:      	callq	0x28930 <native_alloc>
   5ab26:      	testq	%rax, %rax
   5ab29:      	je	0x5b841 <f.7+0x12b1>
   5ab2f:      	movq	%rax, %rbx
   5ab32:      	movq	$0x2e, (%rax)
   5ab39:      	movq	%r15, 0x8(%rax)
   5ab3d:      	movq	%r14, 0x10(%rax)
   5ab41:      	movq	%rax, 0xd8(%rsp)
   5ab49:      	movq	%r12, 0xe0(%rsp)
   5ab51:      	movq	%r13, 0xe8(%rsp)
   5ab59:      	movq	$0x19, 0x20(%rsp)
   5ab62:      	movl	$0x18, %edi
   5ab67:      	callq	0x28930 <native_alloc>
   5ab6c:      	testq	%rax, %rax
   5ab6f:      	je	0x5b841 <f.7+0x12b1>
   5ab75:      	movq	%rax, %r14
   5ab78:      	movq	$0x92, (%rax)
   5ab7f:      	movq	%r12, 0x8(%rax)
   5ab83:      	movq	%rbx, 0x10(%rax)
   5ab87:      	movq	%rax, 0xd8(%rsp)
   5ab8f:      	movq	%r13, 0xe0(%rsp)
   5ab97:      	movq	$0x18, 0x20(%rsp)
   5aba0:      	movl	$0x10, %edi
   5aba5:      	callq	0x28930 <native_alloc>
   5abaa:      	testq	%rax, %rax
   5abad:      	je	0x5b841 <f.7+0x12b1>
   5abb3:      	movq	%rax, %r15
   5abb6:      	movq	$0x4e, (%rax)
   5abbd:      	movq	%r14, 0x8(%rax)
   5abc1:      	movq	%rax, 0xd8(%rsp)
   5abc9:      	movq	%r13, 0xe0(%rsp)
   5abd1:      	movq	$0x18, 0x20(%rsp)
   5abda:      	movl	$0x10, %edi
   5abdf:      	callq	0x28930 <native_alloc>
   5abe4:      	testq	%rax, %rax
   5abe7:      	je	0x5b841 <f.7+0x12b1>
   5abed:      	movq	%rax, %rbx
   5abf0:      	movq	$0x4a, (%rax)
   5abf7:      	movq	%r15, 0x8(%rax)
   5abfb:      	movq	%rax, 0xd8(%rsp)
   5ac03:      	movq	%r13, 0xe0(%rsp)
   5ac0b:      	movq	$0x18, 0x20(%rsp)
   5ac14:      	movl	$0x18, %edi
   5ac19:      	callq	0x28930 <native_alloc>
   5ac1e:      	testq	%rax, %rax
   5ac21:      	je	0x5b841 <f.7+0x12b1>
   5ac27:      	movq	%rax, %r14
   5ac2a:      	movq	$0xc2, (%rax)
   5ac31:      	movq	%r13, 0x8(%rax)
   5ac35:      	movq	%rbx, 0x10(%rax)
   5ac39:      	movq	%rax, 0xd8(%rsp)
   5ac41:      	movq	$0x17, 0x20(%rsp)
   5ac4a:      	movl	$0x18, %edi
   5ac4f:      	callq	0x28930 <native_alloc>
   5ac54:      	testq	%rax, %rax
   5ac57:      	je	0x5b841 <f.7+0x12b1>
   5ac5d:      	movq	$0x66, (%rax)
   5ac64:      	movl	$0x1, 0x8(%rax)
   5ac6b:      	movq	%r14, 0x10(%rax)
   5ac6f:      	movq	%rax, 0x48(%rsp)
   5ac74:      	cmpl	$0x0, 0x8(%rax)
   5ac78:      	je	0x5b841 <f.7+0x12b1>
   5ac7e:      	movq	0x10(%rax), %rax
   5ac82:      	testq	%rax, %rax
   5ac85:      	je	0x5b841 <f.7+0x12b1>
   5ac8b:      	movq	0x10(%rax), %rbx
   5ac8f:      	movl	$0x4a, %esi
   5ac94:      	movq	%rbx, %rdi
   5ac97:      	xorl	%edx, %edx
   5ac99:      	xorl	%ecx, %ecx
   5ac9b:      	callq	0x2acc0 <native_ref_test>
   5aca0:      	testl	%eax, %eax
   5aca2:      	je	0x5b841 <f.7+0x12b1>
   5aca8:      	movq	%rbx, 0xb0(%rsp)
   5acb0:      	testq	%rbx, %rbx
   5acb3:      	je	0x5b841 <f.7+0x12b1>
   5acb9:      	movq	0x8(%rbx), %rax
   5acbd:      	testq	%rax, %rax
   5acc0:      	je	0x5b841 <f.7+0x12b1>
   5acc6:      	movq	0x8(%rax), %rax
   5acca:      	movq	%rax, 0xb8(%rsp)
   5acd2:      	testq	%rax, %rax
   5acd5:      	je	0x5b841 <f.7+0x12b1>
   5acdb:      	movq	0x8(%rax), %rcx
   5acdf:      	testq	%rcx, %rcx
   5ace2:      	je	0x5b841 <f.7+0x12b1>
   5ace8:      	movq	0x10(%rax), %rdi
   5acec:      	movq	0x8(%rcx), %rax
   5acf0:      	movq	%rdi, 0xd8(%rsp)
   5acf8:      	movq	$0x17, 0x20(%rsp)
   5ad01:      	movl	$0xa, %esi
   5ad06:      	callq	*%rax
   5ad08:      	subq	$0x8, %rsp
   5ad0c:      	cmpb	$0x0, 0x7775(%rip)      # 0x62488 <g.4>
   5ad13:      	je	0x5b841 <f.7+0x12b1>
   5ad19:      	cmpq	$0x0, 0x775f(%rip)      # 0x62480 <g.3>
   5ad21:      	je	0x5b841 <f.7+0x12b1>
   5ad27:      	movq	%rax, %rbx
   5ad2a:      	shrq	$0x20, %rax
   5ad2e:      	jne	0x5b841 <f.7+0x12b1>
   5ad34:      	movq	$0x16, 0x20(%rsp)
   5ad3d:      	movl	$0x18, %edi
   5ad42:      	callq	0x28930 <native_alloc>
   5ad47:      	testq	%rax, %rax
   5ad4a:      	je	0x5b841 <f.7+0x12b1>
   5ad50:      	movq	%rax, %r14
   5ad53:      	movq	$0x66, (%rax)
   5ad5a:      	movl	$0x0, 0x8(%rax)
   5ad61:      	movq	$0x0, 0x10(%rax)
   5ad69:      	movq	%rax, 0x40(%rsp)
   5ad6e:      	movq	0xb0(%rsp), %rax
   5ad76:      	testq	%rax, %rax
   5ad79:      	je	0x5b841 <f.7+0x12b1>
   5ad7f:      	movq	0x8(%rax), %r13
   5ad83:      	movq	%r13, 0xd8(%rsp)
   5ad8b:      	leaq	0x52e6(%rip), %r12      # 0x60078 <ref.13>
   5ad92:      	movq	%r12, 0xe0(%rsp)
   5ad9a:      	movq	%r14, 0xe8(%rsp)
   5ada2:      	movq	$0x19, 0x20(%rsp)
   5adab:      	movl	$0xcb, %edi
   5adb0:      	movq	%rbx, 0x100(%rsp)
   5adb8:      	movl	%ebx, %esi
   5adba:      	xorl	%edx, %edx
   5adbc:      	movl	$0x1, %ecx
   5adc1:      	callq	0x2a970 <native_array_new>
   5adc6:      	movq	%rax, %r15
   5adc9:      	movq	%rax, 0xd8(%rsp)
   5add1:      	movq	%r13, 0xe0(%rsp)
   5add9:      	movq	%r12, 0xe8(%rsp)
   5ade1:      	movq	%r14, 0xf0(%rsp)
   5ade9:      	movq	$0x1a, 0x20(%rsp)
   5adf2:      	movl	$0x10, %edi
   5adf7:      	callq	0x28930 <native_alloc>
   5adfc:      	testq	%rax, %rax
   5adff:      	je	0x5b841 <f.7+0x12b1>
   5ae05:      	movq	%rax, %rbx
   5ae08:      	movq	$0x82, (%rax)
   5ae0f:      	movq	%r15, 0x8(%rax)
   5ae13:      	movq	0x40(%rsp), %rbp
   5ae18:      	movq	%rbp, 0xd8(%rsp)
   5ae20:      	movq	%rax, 0xe0(%rsp)
   5ae28:      	movq	%r13, 0xe8(%rsp)
   5ae30:      	movq	%r12, 0xf0(%rsp)
   5ae38:      	movq	%r14, 0xf8(%rsp)
   5ae40:      	movq	$0x1b, 0x20(%rsp)
   5ae49:      	movl	$0x28, %edi
   5ae4e:      	callq	0x28930 <native_alloc>
   5ae53:      	testq	%rax, %rax
   5ae56:      	je	0x5b841 <f.7+0x12b1>
   5ae5c:      	movq	%rax, %r15
   5ae5f:      	movq	$0x2a, (%rax)
   5ae66:      	movq	%r13, 0x8(%rax)
   5ae6a:      	movq	0x100(%rsp), %rax
   5ae72:      	movq	%rax, 0x10(%r15)
   5ae76:      	movq	%rbx, 0x18(%r15)
   5ae7a:      	movq	%rbp, 0x20(%r15)
   5ae7e:      	movq	%r15, 0xd8(%rsp)
   5ae86:      	movq	%r12, 0xe0(%rsp)
   5ae8e:      	movq	%r14, 0xe8(%rsp)
   5ae96:      	movq	$0x19, 0x20(%rsp)
   5ae9f:      	movl	$0x18, %edi
   5aea4:      	callq	0x28930 <native_alloc>
   5aea9:      	testq	%rax, %rax
   5aeac:      	je	0x5b841 <f.7+0x12b1>
   5aeb2:      	movq	$0xc2, (%rax)
   5aeb9:      	movq	%r12, 0x8(%rax)
   5aebd:      	movq	%r15, 0x10(%rax)
   5aec1:      	movq	%rax, 0x10(%r14)
   5aec5:      	movq	0x40(%rsp), %rax
   5aeca:      	testq	%rax, %rax
   5aecd:      	movq	0x118(%rsp), %rbp
   5aed5:      	leaq	0x517c(%rip), %r12      # 0x60058 <ref.10>
   5aedc:      	je	0x5b841 <f.7+0x12b1>
   5aee2:      	movl	$0x1, 0x8(%rax)
   5aee9:      	movq	0x40(%rsp), %rax
   5aeee:      	testq	%rax, %rax
   5aef1:      	je	0x5b841 <f.7+0x12b1>
   5aef7:      	cmpl	$0x0, 0x8(%rax)
   5aefb:      	je	0x5b841 <f.7+0x12b1>
   5af01:      	movq	0x10(%rax), %rax
   5af05:      	testq	%rax, %rax
   5af08:      	je	0x5b841 <f.7+0x12b1>
   5af0e:      	movq	%rax, 0xc0(%rsp)
   5af16:      	movq	0x8(%rax), %rcx
   5af1a:      	testq	%rcx, %rcx
   5af1d:      	je	0x5b841 <f.7+0x12b1>
   5af23:      	movq	0x10(%rax), %rdi
   5af27:      	movq	0x8(%rcx), %rax
   5af2b:      	movq	%rdi, 0xd8(%rsp)
   5af33:      	movq	$0x17, 0x20(%rsp)
   5af3c:      	xorl	%esi, %esi
   5af3e:      	callq	*%rax
   5af40:      	subq	$0x8, %rsp
   5af44:      	movq	%rax, 0xa0(%rsp)
   5af4c:      	cmpb	$0x0, 0x7545(%rip)      # 0x62498 <g.6>
   5af53:      	je	0x5b841 <f.7+0x12b1>
   5af59:      	cmpq	$0x0, 0x752f(%rip)      # 0x62490 <g.5>
   5af61:      	je	0x5b841 <f.7+0x12b1>
   5af67:      	cmpb	$0x0, 0x753a(%rip)      # 0x624a8 <g.8>
   5af6e:      	je	0x5b841 <f.7+0x12b1>
   5af74:      	cmpq	$0x0, 0x7524(%rip)      # 0x624a0 <g.7>
   5af7c:      	je	0x5b841 <f.7+0x12b1>
   5af82:      	testq	%rax, %rax
   5af85:      	je	0x5b841 <f.7+0x12b1>
   5af8b:      	movq	0x8(%rax), %rcx
   5af8f:      	testq	%rcx, %rcx
   5af92:      	je	0x5b841 <f.7+0x12b1>
   5af98:      	testb	$0x1, %cl
   5af9b:      	jne	0x5b841 <f.7+0x12b1>
   5afa1:      	movl	0x8(%rcx), %esi
   5afa4:      	movq	%rax, 0xd8(%rsp)
   5afac:      	movq	$0x17, 0x20(%rsp)
   5afb5:      	movq	%rax, %rdi
   5afb8:      	callq	0x5a1d0 <f.5>
   5afbd:      	subq	$0x8, %rsp
   5afc1:      	movq	%rax, %rbx
   5afc4:      	movq	%rax, 0x50(%rsp)
   5afc9:      	movq	%rax, 0xd8(%rsp)
   5afd1:      	movq	$0x17, 0x20(%rsp)
   5afda:      	movl	$0x10, %edi
   5afdf:      	callq	0x28930 <native_alloc>
   5afe4:      	testq	%rax, %rax
   5afe7:      	je	0x5b841 <f.7+0x12b1>
   5afed:      	movq	%rax, %r14
   5aff0:      	movq	$0x22, (%rax)
   5aff7:      	movq	%rbx, 0x8(%rax)
   5affb:      	movq	0x50(%rsp), %rdi
   5b000:      	testq	%rdi, %rdi
   5b003:      	je	0x5b841 <f.7+0x12b1>
   5b009:      	movl	0x8(%rdi), %ebx
   5b00c:      	movq	%r14, 0xd8(%rsp)
   5b014:      	movq	%rdi, 0xe0(%rsp)
   5b01c:      	movq	$0x18, 0x20(%rsp)
   5b025:      	xorl	%esi, %esi
   5b027:      	callq	0x5a070 <f.4>
   5b02c:      	subq	$0x8, %rsp
   5b030:      	movl	%eax, %r15d
   5b033:      	movq	0x50(%rsp), %rdi
   5b038:      	movq	%r14, 0xd8(%rsp)
   5b040:      	movq	%rdi, 0xe0(%rsp)
   5b048:      	movq	$0x18, 0x20(%rsp)
   5b051:      	movl	%ebx, %esi
   5b053:      	callq	0x5a070 <f.4>
   5b058:      	subq	$0x8, %rsp
   5b05c:      	movl	%eax, %ebx
   5b05e:      	subl	%r15d, %ebx
   5b061:      	movq	%r14, 0xd8(%rsp)
   5b069:      	movq	$0x17, 0x20(%rsp)
   5b072:      	movl	$0xcb, %edi
   5b077:      	movl	%ebx, %esi
   5b079:      	xorl	%edx, %edx
   5b07b:      	movl	$0x1, %ecx
   5b080:      	callq	0x2a970 <native_array_new>
   5b085:      	movq	%rax, 0xc8(%rsp)
   5b08d:      	movq	0x50(%rsp), %rcx
   5b092:      	testq	%rcx, %rcx
   5b095:      	je	0x5b841 <f.7+0x12b1>
   5b09b:      	movq	0x18(%rcx), %rdx
   5b09f:      	movq	%rax, %rdi
   5b0a2:      	xorl	%esi, %esi
   5b0a4:      	movl	%r15d, %ecx
   5b0a7:      	movl	%ebx, %r8d
   5b0aa:      	movl	$0x1, %r9d
   5b0b0:      	callq	0x2a900 <native_array_copy>
   5b0b5:      	movq	0xc8(%rsp), %rbx
   5b0bd:      	movq	%rbx, 0xd8(%rsp)
   5b0c5:      	movq	%r14, 0xe0(%rsp)
   5b0cd:      	movq	$0x18, 0x20(%rsp)
   5b0d6:      	movl	$0x10, %edi
   5b0db:      	callq	0x28930 <native_alloc>
   5b0e0:      	testq	%rax, %rax
   5b0e3:      	je	0x5b841 <f.7+0x12b1>
   5b0e9:      	movq	$0x82, (%rax)
   5b0f0:      	movq	%rbx, 0x8(%rax)
   5b0f4:      	movq	%rax, 0xa8(%rsp)
   5b0fc:      	movq	0x8(%rax), %rcx
   5b100:      	testq	%rcx, %rcx
   5b103:      	je	0x5b841 <f.7+0x12b1>
   5b109:      	testb	$0x1, %cl
   5b10c:      	jne	0x5b841 <f.7+0x12b1>
   5b112:      	movl	0x8(%rcx), %esi
   5b115:      	movq	%r14, 0xd8(%rsp)
   5b11d:      	movq	%rax, 0xe0(%rsp)
   5b125:      	movq	$0x18, 0x20(%rsp)
   5b12e:      	movq	%rax, %rdi
   5b131:      	callq	0x5a1d0 <f.5>
   5b136:      	subq	$0x8, %rsp
   5b13a:      	movq	%r14, 0xd8(%rsp)
   5b142:      	movq	%rax, 0xe0(%rsp)
   5b14a:      	movq	$0x18, 0x20(%rsp)
   5b153:      	movq	%r14, %rdi
   5b156:      	movq	%rax, %rsi
   5b159:      	callq	0x5bfe0 <f.11>
   5b15e:      	subq	$0x8, %rsp
   5b162:      	movq	$0x16, 0x20(%rsp)
   5b16b:      	movl	$0x18, %edi
   5b170:      	callq	0x28930 <native_alloc>
   5b175:      	testq	%rax, %rax
   5b178:      	je	0x5b841 <f.7+0x12b1>
   5b17e:      	movq	%rax, %r14
   5b181:      	movq	$0x62, (%rax)
   5b188:      	movl	$0x0, 0x8(%rax)
   5b18f:      	movq	$0x0, 0x10(%rax)
   5b197:      	movq	%rax, 0x58(%rsp)
   5b19c:      	movq	0x48(%rsp), %r15
   5b1a1:      	movq	%rax, 0xd8(%rsp)
   5b1a9:      	movq	%r15, 0xe0(%rsp)
   5b1b1:      	movq	%r12, 0xe8(%rsp)
   5b1b9:      	movq	%rax, 0xf0(%rsp)
   5b1c1:      	movq	$0x1a, 0x20(%rsp)
   5b1ca:      	movl	$0x28, %edi
   5b1cf:      	callq	0x28930 <native_alloc>
   5b1d4:      	testq	%rax, %rax
   5b1d7:      	je	0x5b841 <f.7+0x12b1>
   5b1dd:      	movq	%rax, %rbx
   5b1e0:      	movq	$0x1e, (%rax)
   5b1e7:      	movq	0x110(%rsp), %rax
   5b1ef:      	movq	%rax, 0x8(%rbx)
   5b1f3:      	movq	0x108(%rsp), %rax
   5b1fb:      	movq	%rax, 0x10(%rbx)
   5b1ff:      	movq	%r15, 0x18(%rbx)
   5b203:      	movq	%r14, 0x20(%rbx)
   5b207:      	movq	%rbx, 0xd8(%rsp)
   5b20f:      	movq	%r12, 0xe0(%rsp)
   5b217:      	movq	%r14, 0xe8(%rsp)
   5b21f:      	movq	$0x19, 0x20(%rsp)
   5b228:      	movl	$0x18, %edi
   5b22d:      	callq	0x28930 <native_alloc>
   5b232:      	testq	%rax, %rax
   5b235:      	je	0x5b841 <f.7+0x12b1>
   5b23b:      	movq	$0x42, (%rax)
   5b242:      	movq	%r12, 0x8(%rax)
   5b246:      	movq	%rbx, 0x10(%rax)
   5b24a:      	movq	%rax, 0x10(%r14)
   5b24e:      	movq	0x58(%rsp), %rax
   5b253:      	testq	%rax, %rax
   5b256:      	leaq	0x120(%rsp), %r15
   5b25e:      	je	0x5b841 <f.7+0x12b1>
   5b264:      	movl	$0x1, 0x8(%rax)
   5b26b:      	movq	0x58(%rsp), %rax
   5b270:      	testq	%rax, %rax
   5b273:      	je	0x5b841 <f.7+0x12b1>
   5b279:      	cmpl	$0x0, 0x8(%rax)
   5b27d:      	je	0x5b841 <f.7+0x12b1>
   5b283:      	movq	0x10(%rax), %rax
   5b287:      	testq	%rax, %rax
   5b28a:      	je	0x5b841 <f.7+0x12b1>
   5b290:      	movq	%rax, 0xd0(%rsp)
   5b298:      	movq	0x8(%rax), %rcx
   5b29c:      	testq	%rcx, %rcx
   5b29f:      	je	0x5b841 <f.7+0x12b1>
   5b2a5:      	movq	0x10(%rax), %rdi
   5b2a9:      	movq	0x8(%rcx), %rax
   5b2ad:      	movq	%rdi, 0xd8(%rsp)
   5b2b5:      	movq	$0x17, 0x20(%rsp)
   5b2be:      	xorl	%esi, %esi
   5b2c0:      	callq	*%rax
   5b2c2:      	subq	$0x8, %rsp
   5b2c6:      	cmpb	$0x0, 0x724b(%rip)      # 0x62518 <g.22>
   5b2cd:      	je	0x5b841 <f.7+0x12b1>
   5b2d3:      	movq	0x7236(%rip), %rax      # 0x62510 <g.21>
   5b2da:      	testq	%rax, %rax
   5b2dd:      	je	0x5b841 <f.7+0x12b1>
   5b2e3:      	movq	0x8(%rax), %rax
   5b2e7:      	movq	%rax, 0x30(%rsp)
   5b2ec:      	cmpb	$0x0, 0x71c5(%rip)      # 0x624b8 <g.10>
   5b2f3:      	je	0x5b841 <f.7+0x12b1>
   5b2f9:      	cmpq	$0x0, 0x71af(%rip)      # 0x624b0 <g.9>
   5b301:      	je	0x5b841 <f.7+0x12b1>
   5b307:      	movq	$0x16, 0x20(%rsp)
   5b310:      	movl	$0x18, %edi
   5b315:      	callq	0x28930 <native_alloc>
   5b31a:      	testq	%rax, %rax
   5b31d:      	je	0x5b841 <f.7+0x12b1>
   5b323:      	movq	%rax, %r14
   5b326:      	movq	$0x5e, (%rax)
   5b32d:      	movl	$0x0, 0x8(%rax)
   5b334:      	movq	$0x0, 0x10(%rax)
   5b33c:      	movq	%rax, 0x60(%rsp)
   5b341:      	movq	%rax, 0xd8(%rsp)
   5b349:      	movq	%rax, 0xe0(%rsp)
   5b351:      	movq	$0x18, 0x20(%rsp)
   5b35a:      	movl	$0x10, %edi
   5b35f:      	callq	0x28930 <native_alloc>
   5b364:      	testq	%rax, %rax
   5b367:      	je	0x5b841 <f.7+0x12b1>
   5b36d:      	movq	%rax, %rbx
   5b370:      	movq	$0x6a, (%rax)
   5b377:      	movq	%r14, 0x8(%rax)
   5b37b:      	movq	%rax, 0xd8(%rsp)
   5b383:      	movq	%r14, 0xe0(%rsp)
   5b38b:      	movq	$0x18, 0x20(%rsp)
   5b394:      	movl	$0x10, %edi
   5b399:      	callq	0x28930 <native_alloc>
   5b39e:      	testq	%rax, %rax
   5b3a1:      	je	0x5b841 <f.7+0x12b1>
   5b3a7:      	movq	$0x16, (%rax)
   5b3ae:      	movq	%rbx, 0x8(%rax)
   5b3b2:      	movq	%rax, 0x10(%r14)
   5b3b6:      	movq	0x60(%rsp), %rax
   5b3bb:      	testq	%rax, %rax
   5b3be:      	je	0x5b841 <f.7+0x12b1>
   5b3c4:      	movl	$0x1, 0x8(%rax)
   5b3cb:      	movq	0x60(%rsp), %rax
   5b3d0:      	testq	%rax, %rax
   5b3d3:      	je	0x5b841 <f.7+0x12b1>
   5b3d9:      	cmpl	$0x0, 0x8(%rax)
   5b3dd:      	je	0x5b841 <f.7+0x12b1>
   5b3e3:      	movq	0x10(%rax), %rax
   5b3e7:      	testq	%rax, %rax
   5b3ea:      	je	0x5b841 <f.7+0x12b1>
   5b3f0:      	movq	0x8(%rax), %rdi
   5b3f4:      	movq	%rdi, 0x38(%rsp)
   5b3f9:      	movq	0x30(%rsp), %rax
   5b3fe:      	testq	%rax, %rax
   5b401:      	je	0x5b710 <f.7+0x1180>
   5b407:      	movq	0x8(%rax), %rax
   5b40b:      	movq	%rax, 0x30(%rsp)
   5b410:      	testq	%rdi, %rdi
   5b413:      	je	0x5b841 <f.7+0x12b1>
   5b419:      	movq	0x8(%rdi), %rcx
   5b41d:      	testq	%rcx, %rcx
   5b420:      	je	0x5b841 <f.7+0x12b1>
   5b426:      	cmpl	$0x0, 0x8(%rcx)
   5b42a:      	je	0x5b841 <f.7+0x12b1>
   5b430:      	cmpq	$0x0, 0x10(%rcx)
   5b435:      	je	0x5b841 <f.7+0x12b1>
   5b43b:      	testq	%rax, %rax
   5b43e:      	je	0x5b720 <f.7+0x1190>
   5b444:      	movq	0x8(%rax), %rax
   5b448:      	movq	%rax, 0x30(%rsp)
   5b44d:      	movq	0x8(%rdi), %rcx
   5b451:      	testq	%rcx, %rcx
   5b454:      	je	0x5b841 <f.7+0x12b1>
   5b45a:      	cmpl	$0x0, 0x8(%rcx)
   5b45e:      	je	0x5b841 <f.7+0x12b1>
   5b464:      	cmpq	$0x0, 0x10(%rcx)
   5b469:      	je	0x5b841 <f.7+0x12b1>
   5b46f:      	testq	%rax, %rax
   5b472:      	je	0x5b728 <f.7+0x1198>
   5b478:      	movq	0x8(%rax), %rax
   5b47c:      	movq	%rax, 0x30(%rsp)
   5b481:      	movq	0x8(%rdi), %rcx
   5b485:      	testq	%rcx, %rcx
   5b488:      	je	0x5b841 <f.7+0x12b1>
   5b48e:      	cmpl	$0x0, 0x8(%rcx)
   5b492:      	je	0x5b841 <f.7+0x12b1>
   5b498:      	cmpq	$0x0, 0x10(%rcx)
   5b49d:      	je	0x5b841 <f.7+0x12b1>
   5b4a3:      	testq	%rax, %rax
   5b4a6:      	je	0x5b730 <f.7+0x11a0>
   5b4ac:      	movq	0x8(%rax), %rax
   5b4b0:      	movq	%rax, 0x30(%rsp)
   5b4b5:      	movq	0x8(%rdi), %rcx
   5b4b9:      	testq	%rcx, %rcx
   5b4bc:      	je	0x5b841 <f.7+0x12b1>
   5b4c2:      	cmpl	$0x0, 0x8(%rcx)
   5b4c6:      	je	0x5b841 <f.7+0x12b1>
   5b4cc:      	cmpq	$0x0, 0x10(%rcx)
   5b4d1:      	je	0x5b841 <f.7+0x12b1>
   5b4d7:      	testq	%rax, %rax
   5b4da:      	je	0x5b738 <f.7+0x11a8>
   5b4e0:      	movq	0x8(%rax), %rax
   5b4e4:      	movq	%rax, 0x30(%rsp)
   5b4e9:      	movq	0x8(%rdi), %rcx
   5b4ed:      	testq	%rcx, %rcx
   5b4f0:      	je	0x5b841 <f.7+0x12b1>
   5b4f6:      	cmpl	$0x0, 0x8(%rcx)
   5b4fa:      	je	0x5b841 <f.7+0x12b1>
   5b500:      	cmpq	$0x0, 0x10(%rcx)
   5b505:      	je	0x5b841 <f.7+0x12b1>
   5b50b:      	testq	%rax, %rax
   5b50e:      	je	0x5b740 <f.7+0x11b0>
   5b514:      	movq	0x8(%rax), %rax
   5b518:      	movq	%rax, 0x30(%rsp)
   5b51d:      	movq	0x8(%rdi), %rcx
   5b521:      	testq	%rcx, %rcx
   5b524:      	je	0x5b841 <f.7+0x12b1>
   5b52a:      	cmpl	$0x0, 0x8(%rcx)
   5b52e:      	je	0x5b841 <f.7+0x12b1>
   5b534:      	cmpq	$0x0, 0x10(%rcx)
   5b539:      	je	0x5b841 <f.7+0x12b1>
   5b53f:      	testq	%rax, %rax
   5b542:      	je	0x5b748 <f.7+0x11b8>
   5b548:      	movq	0x8(%rax), %rax
   5b54c:      	movq	%rax, 0x30(%rsp)
   5b551:      	movq	0x8(%rdi), %rcx
   5b555:      	testq	%rcx, %rcx
   5b558:      	je	0x5b841 <f.7+0x12b1>
   5b55e:      	cmpl	$0x0, 0x8(%rcx)
   5b562:      	je	0x5b841 <f.7+0x12b1>
   5b568:      	cmpq	$0x0, 0x10(%rcx)
   5b56d:      	je	0x5b841 <f.7+0x12b1>
   5b573:      	testq	%rax, %rax
   5b576:      	je	0x5b750 <f.7+0x11c0>
   5b57c:      	movq	0x8(%rax), %rax
   5b580:      	movq	%rax, 0x30(%rsp)
   5b585:      	movq	0x8(%rdi), %rcx
   5b589:      	testq	%rcx, %rcx
   5b58c:      	je	0x5b841 <f.7+0x12b1>
   5b592:      	cmpl	$0x0, 0x8(%rcx)
   5b596:      	je	0x5b841 <f.7+0x12b1>
   5b59c:      	cmpq	$0x0, 0x10(%rcx)
   5b5a1:      	je	0x5b841 <f.7+0x12b1>
   5b5a7:      	testq	%rax, %rax
   5b5aa:      	je	0x5b758 <f.7+0x11c8>
   5b5b0:      	movq	0x8(%rax), %rax
   5b5b4:      	movq	%rax, 0x30(%rsp)
   5b5b9:      	movq	0x8(%rdi), %rcx
   5b5bd:      	testq	%rcx, %rcx
   5b5c0:      	je	0x5b841 <f.7+0x12b1>
   5b5c6:      	cmpl	$0x0, 0x8(%rcx)
   5b5ca:      	je	0x5b841 <f.7+0x12b1>
   5b5d0:      	cmpq	$0x0, 0x10(%rcx)
   5b5d5:      	je	0x5b841 <f.7+0x12b1>
   5b5db:      	testq	%rax, %rax
   5b5de:      	je	0x5b760 <f.7+0x11d0>
   5b5e4:      	movq	0x8(%rax), %rax
   5b5e8:      	movq	%rax, 0x30(%rsp)
   5b5ed:      	movq	0x8(%rdi), %rcx
   5b5f1:      	testq	%rcx, %rcx
   5b5f4:      	je	0x5b841 <f.7+0x12b1>
   5b5fa:      	cmpl	$0x0, 0x8(%rcx)
   5b5fe:      	je	0x5b841 <f.7+0x12b1>
   5b604:      	cmpq	$0x0, 0x10(%rcx)
   5b609:      	je	0x5b841 <f.7+0x12b1>
   5b60f:      	testq	%rax, %rax
   5b612:      	je	0x5b768 <f.7+0x11d8>
   5b618:      	movq	0x8(%rax), %rax
   5b61c:      	movq	%rax, 0x30(%rsp)
   5b621:      	movq	0x8(%rdi), %rcx
   5b625:      	testq	%rcx, %rcx
   5b628:      	je	0x5b841 <f.7+0x12b1>
   5b62e:      	cmpl	$0x0, 0x8(%rcx)
   5b632:      	je	0x5b841 <f.7+0x12b1>
   5b638:      	cmpq	$0x0, 0x10(%rcx)
   5b63d:      	je	0x5b841 <f.7+0x12b1>
   5b643:      	testq	%rax, %rax
   5b646:      	je	0x5b770 <f.7+0x11e0>
   5b64c:      	movq	0x8(%rax), %rax
   5b650:      	movq	%rax, 0x30(%rsp)
   5b655:      	movq	0x8(%rdi), %rcx
   5b659:      	testq	%rcx, %rcx
   5b65c:      	je	0x5b841 <f.7+0x12b1>
   5b662:      	cmpl	$0x0, 0x8(%rcx)
   5b666:      	je	0x5b841 <f.7+0x12b1>
   5b66c:      	cmpq	$0x0, 0x10(%rcx)
   5b671:      	je	0x5b841 <f.7+0x12b1>
   5b677:      	testq	%rax, %rax
   5b67a:      	je	0x5b778 <f.7+0x11e8>
   5b680:      	movq	0x8(%rax), %rax
   5b684:      	movq	%rax, 0x30(%rsp)
   5b689:      	movq	0x8(%rdi), %rcx
   5b68d:      	testq	%rcx, %rcx
   5b690:      	je	0x5b841 <f.7+0x12b1>
   5b696:      	cmpl	$0x0, 0x8(%rcx)
   5b69a:      	je	0x5b841 <f.7+0x12b1>
   5b6a0:      	cmpq	$0x0, 0x10(%rcx)
   5b6a5:      	je	0x5b841 <f.7+0x12b1>
   5b6ab:      	testq	%rax, %rax
   5b6ae:      	je	0x5b780 <f.7+0x11f0>
   5b6b4:      	movq	0x8(%rax), %rsi
   5b6b8:      	movq	%rsi, 0x30(%rsp)
   5b6bd:      	movq	0x8(%rdi), %rax
   5b6c1:      	testq	%rax, %rax
   5b6c4:      	je	0x5b841 <f.7+0x12b1>
   5b6ca:      	cmpl	$0x0, 0x8(%rax)
   5b6ce:      	je	0x5b841 <f.7+0x12b1>
   5b6d4:      	cmpq	$0x0, 0x10(%rax)
   5b6d9:      	je	0x5b841 <f.7+0x12b1>
   5b6df:      	movq	%rdi, 0xd8(%rsp)
   5b6e7:      	movq	%rsi, 0xe0(%rsp)
   5b6ef:      	movq	$0x18, 0x20(%rsp)
   5b6f8:      	movl	$0xe, %edx
   5b6fd:      	callq	0x5b850 <f.8>
   5b702:      	subq	$0x8, %rsp
   5b706:      	movq	%rax, %r13
   5b709:      	jmp	0x5b790 <f.7+0x1200>
   5b70e:      	nop
   5b710:      	xorl	%r13d, %r13d
   5b713:      	jmp	0x5b790 <f.7+0x1200>
   5b715:      	nopw	%cs:(%rax,%rax)
   5b71f:      	nop
   5b720:      	movl	$0x1, %r13d
   5b726:      	jmp	0x5b790 <f.7+0x1200>
   5b728:      	movl	$0x2, %r13d
   5b72e:      	jmp	0x5b790 <f.7+0x1200>
   5b730:      	movl	$0x3, %r13d
   5b736:      	jmp	0x5b790 <f.7+0x1200>
   5b738:      	movl	$0x4, %r13d
   5b73e:      	jmp	0x5b790 <f.7+0x1200>
   5b740:      	movl	$0x5, %r13d
   5b746:      	jmp	0x5b790 <f.7+0x1200>
   5b748:      	movl	$0x6, %r13d
   5b74e:      	jmp	0x5b790 <f.7+0x1200>
   5b750:      	movl	$0x7, %r13d
   5b756:      	jmp	0x5b790 <f.7+0x1200>
   5b758:      	movl	$0x8, %r13d
   5b75e:      	jmp	0x5b790 <f.7+0x1200>
   5b760:      	movl	$0x9, %r13d
   5b766:      	jmp	0x5b790 <f.7+0x1200>
   5b768:      	movl	$0xa, %r13d
   5b76e:      	jmp	0x5b790 <f.7+0x1200>
   5b770:      	movl	$0xb, %r13d
   5b776:      	jmp	0x5b790 <f.7+0x1200>
   5b778:      	movl	$0xc, %r13d
   5b77e:      	jmp	0x5b790 <f.7+0x1200>
   5b780:      	movl	$0xd, %r13d
   5b786:      	nopw	%cs:(%rax,%rax)
   5b790:      	movq	0x68(%rsp), %r14
   5b795:      	testq	%r14, %r14
   5b798:      	je	0x5b841 <f.7+0x12b1>
   5b79e:      	movq	0x10(%r14), %rax
   5b7a2:      	testq	%rax, %rax
   5b7a5:      	je	0x5b841 <f.7+0x12b1>
   5b7ab:      	cmpl	$0x0, 0x8(%rax)
   5b7af:      	je	0x5b841 <f.7+0x12b1>
   5b7b5:      	cmpq	$0x0, 0x10(%rax)
   5b7ba:      	je	0x5b841 <f.7+0x12b1>
   5b7c0:      	incq	%rbp
   5b7c3:      	leaq	0x10(%rsp), %rbx
   5b7c8:      	movq	%rbx, %rdi
   5b7cb:      	callq	0x2ae00 <native_roots_leave>
   5b7d0:      	movl	$0x1b, %esi
   5b7d5:      	movq	%rbx, %rdi
   5b7d8:      	callq	0x2adb0 <native_roots_enter>
   5b7dd:      	movq	%r14, 0x28(%rsp)
   5b7e2:      	movl	$0xa8, %edx
   5b7e7:      	leaq	0x30(%rsp), %rdi
   5b7ec:      	xorl	%esi, %esi
   5b7ee:      	callq	0x5cf90 <memset@plt>
   5b7f3:      	movq	%r14, 0x68(%rsp)
   5b7f8:      	cmpq	%rbp, 0x8(%r14)
   5b7fc:      	jg	0x5a600 <f.7+0x70>
   5b802:      	testq	%rbp, %rbp
   5b805:      	jle	0x5b81e <f.7+0x128e>
   5b807:      	cmpb	$0x0, 0x6d5a(%rip)      # 0x62568 <g.32>
   5b80e:      	je	0x5b841 <f.7+0x12b1>
   5b810:      	xorl	%ebx, %ebx
   5b812:      	cmpq	%r13, 0x6d47(%rip)      # 0x62560 <g.31>
   5b819:      	sete	%bl
   5b81c:      	jmp	0x5b820 <f.7+0x1290>
   5b81e:      	xorl	%ebx, %ebx
   5b820:      	leaq	0x10(%rsp), %rdi
   5b825:      	callq	0x2ae00 <native_roots_leave>
   5b82a:      	movq	%rbx, %rax
   5b82d:      	addq	$0x138, %rsp            # imm = 0x138
   5b834:      	popq	%rbx
   5b835:      	popq	%r12
   5b837:      	popq	%r13
   5b839:      	popq	%r14
   5b83b:      	popq	%r15
   5b83d:      	popq	%rbp
   5b83e:      	retq	$0x8
   5b841:      	callq	0x26990 <native_trap>
   5b846:      	int3
   5b847:      	int3
   5b848:      	int3
   5b849:      	int3
   5b84a:      	int3
   5b84b:      	int3
   5b84c:      	int3
   5b84d:      	int3
   5b84e:      	int3
   5b84f:      	int3

000000000005b850 <f.8>:
   5b850:      	pushq	%r15
   5b852:      	pushq	%r14
   5b854:      	pushq	%r12
   5b856:      	pushq	%rbx
   5b857:      	subq	$0x28, %rsp
   5b85b:      	movq	%rdx, %rbx
   5b85e:      	movq	%rsi, %r14
   5b861:      	movq	%rdi, %r15
   5b864:      	movq	%rsp, %rdi
   5b867:      	xorl	%esi, %esi
   5b869:      	callq	0x2adb0 <native_roots_enter>
   5b86e:      	movq	%r15, 0x18(%rsp)
   5b873:      	movq	%r14, 0x20(%rsp)
   5b878:      	testq	%r14, %r14
   5b87b:      	je	0x5b8d3 <f.8+0x83>
   5b87d:      	testq	%r15, %r15
   5b880:      	je	0x5b8f1 <f.8+0xa1>
   5b882:      	movq	%rsp, %r12
   5b885:      	nopw	%cs:(%rax,%rax)
   5b88f:      	nop
   5b890:      	movq	0x8(%r14), %r14
   5b894:      	movq	%r14, 0x20(%rsp)
   5b899:      	movq	0x8(%r15), %rax
   5b89d:      	testq	%rax, %rax
   5b8a0:      	je	0x5b8ec <f.8+0x9c>
   5b8a2:      	cmpl	$0x0, 0x8(%rax)
   5b8a6:      	je	0x5b8ec <f.8+0x9c>
   5b8a8:      	cmpq	$0x0, 0x10(%rax)
   5b8ad:      	je	0x5b8ec <f.8+0x9c>
   5b8af:      	incq	%rbx
   5b8b2:      	movq	%r12, %rdi
   5b8b5:      	callq	0x2ae00 <native_roots_leave>
   5b8ba:      	movq	%r12, %rdi
   5b8bd:      	xorl	%esi, %esi
   5b8bf:      	callq	0x2adb0 <native_roots_enter>
   5b8c4:      	movq	%r15, 0x18(%rsp)
   5b8c9:      	movq	%r14, 0x20(%rsp)
   5b8ce:      	testq	%r14, %r14
   5b8d1:      	jne	0x5b890 <f.8+0x40>
   5b8d3:      	movq	%rsp, %rdi
   5b8d6:      	callq	0x2ae00 <native_roots_leave>
   5b8db:      	movq	%rbx, %rax
   5b8de:      	addq	$0x28, %rsp
   5b8e2:      	popq	%rbx
   5b8e3:      	popq	%r12
   5b8e5:      	popq	%r14
   5b8e7:      	popq	%r15
   5b8e9:      	retq	$0x8
   5b8ec:      	callq	0x26990 <native_trap>
   5b8f1:      	movq	0x8(%r14), %rax
   5b8f5:      	movq	%rax, 0x20(%rsp)
   5b8fa:      	callq	0x26990 <native_trap>
   5b8ff:      	int3

000000000005b900 <f.9>:
   5b900:      	pushq	%r15
   5b902:      	pushq	%r14
   5b904:      	pushq	%rbx
   5b905:      	subq	$0x40, %rsp
   5b909:      	movq	%rdx, %rbx
   5b90c:      	movq	%rdi, %r14
   5b90f:      	leaq	0x8(%rsp), %r15
   5b914:      	movl	$0x1, %esi
   5b919:      	movq	%r15, %rdi
   5b91c:      	callq	0x2adb0 <native_roots_enter>
   5b921:      	movq	%r14, 0x20(%rsp)
   5b926:      	movq	$0x1, 0x18(%rsp)
   5b92f:      	leaq	0x28(%rsp), %r14
   5b934:      	movq	%r14, %rdi
   5b937:      	xorl	%esi, %esi
   5b939:      	callq	0x2adb0 <native_roots_enter>
   5b93e:      	movq	$0x0, 0x38(%rsp)
   5b947:      	movq	%rbx, %rdi
   5b94a:      	callq	0x14b30 <hide_i64>
   5b94f:      	movq	%rax, %rbx
   5b952:      	movq	%r14, %rdi
   5b955:      	callq	0x2ae00 <native_roots_leave>
   5b95a:      	movq	%r15, %rdi
   5b95d:      	callq	0x2ae00 <native_roots_leave>
   5b962:      	movq	%rbx, %rax
   5b965:      	addq	$0x40, %rsp
   5b969:      	popq	%rbx
   5b96a:      	popq	%r14
   5b96c:      	popq	%r15
   5b96e:      	retq	$0x8
   5b971:      	int3
   5b972:      	int3
   5b973:      	int3
   5b974:      	int3
   5b975:      	int3
   5b976:      	int3
   5b977:      	int3
   5b978:      	int3
   5b979:      	int3
   5b97a:      	int3
   5b97b:      	int3
   5b97c:      	int3
   5b97d:      	int3
   5b97e:      	int3
   5b97f:      	int3

000000000005b980 <f.10>:
   5b980:      	pushq	%rbp
   5b981:      	pushq	%r15
   5b983:      	pushq	%r14
   5b985:      	pushq	%r13
   5b987:      	pushq	%r12
   5b989:      	pushq	%rbx
   5b98a:      	subq	$0xa8, %rsp
   5b991:      	movq	%rsi, %rbx
   5b994:      	movq	%rdi, %r15
   5b997:      	leaq	0x8(%rsp), %rdi
   5b99c:      	movl	$0xf, %esi
   5b9a1:      	callq	0x2adb0 <native_roots_enter>
   5b9a6:      	movq	%r15, 0x20(%rsp)
   5b9ab:      	movq	$0x0, 0x28(%rsp)
   5b9b4:      	movq	$0x0, 0x30(%rsp)
   5b9bd:      	movq	$0x0, 0x38(%rsp)
   5b9c6:      	movq	$0x0, 0x40(%rsp)
   5b9cf:      	movq	$0x0, 0x48(%rsp)
   5b9d8:      	movq	$0x0, 0x50(%rsp)
   5b9e1:      	movq	$0x0, 0x58(%rsp)
   5b9ea:      	movq	$0x0, 0x60(%rsp)
   5b9f3:      	movq	$0x0, 0x68(%rsp)
   5b9fc:      	movl	$0x1e, %esi
   5ba01:      	movq	%r15, %rdi
   5ba04:      	xorl	%edx, %edx
   5ba06:      	xorl	%ecx, %ecx
   5ba08:      	callq	0x2acc0 <native_ref_test>
   5ba0d:      	testl	%eax, %eax
   5ba0f:      	je	0x5bfba <f.10+0x63a>
   5ba15:      	decq	%rbx
   5ba18:      	leaq	0x4659(%rip), %r13      # 0x60078 <ref.13>
   5ba1f:      	nop
   5ba20:      	testq	%r15, %r15
   5ba23:      	je	0x5bfba <f.10+0x63a>
   5ba29:      	incq	%rbx
   5ba2c:      	cmpq	0x8(%r15), %rbx
   5ba30:      	je	0x5bfbf <f.10+0x63f>
   5ba36:      	movq	0x20(%rsp), %r15
   5ba3b:      	movl	$0x1e, %esi
   5ba40:      	movq	%r15, %rdi
   5ba43:      	xorl	%edx, %edx
   5ba45:      	xorl	%ecx, %ecx
   5ba47:      	callq	0x2acc0 <native_ref_test>
   5ba4c:      	testl	%eax, %eax
   5ba4e:      	je	0x5bfba <f.10+0x63a>
   5ba54:      	movq	%r15, 0x28(%rsp)
   5ba59:      	testq	%r15, %r15
   5ba5c:      	je	0x5bfba <f.10+0x63a>
   5ba62:      	movq	0x18(%r15), %rax
   5ba66:      	testq	%rax, %rax
   5ba69:      	je	0x5bfba <f.10+0x63a>
   5ba6f:      	cmpl	$0x0, 0x8(%rax)
   5ba73:      	je	0x5bfba <f.10+0x63a>
   5ba79:      	movq	0x10(%rax), %rax
   5ba7d:      	testq	%rax, %rax
   5ba80:      	je	0x5bfba <f.10+0x63a>
   5ba86:      	movq	0x10(%r15), %r15
   5ba8a:      	movq	0x10(%rax), %r12
   5ba8e:      	movl	$0x4a, %esi
   5ba93:      	movq	%r12, %rdi
   5ba96:      	xorl	%edx, %edx
   5ba98:      	xorl	%ecx, %ecx
   5ba9a:      	callq	0x2acc0 <native_ref_test>
   5ba9f:      	testl	%eax, %eax
   5baa1:      	je	0x5bfba <f.10+0x63a>
   5baa7:      	movq	%r12, 0x50(%rsp)
   5baac:      	testq	%r12, %r12
   5baaf:      	je	0x5bfba <f.10+0x63a>
   5bab5:      	movq	0x8(%r12), %rax
   5baba:      	testq	%rax, %rax
   5babd:      	je	0x5bfba <f.10+0x63a>
   5bac3:      	movq	0x8(%rax), %rax
   5bac7:      	movq	%rax, 0x58(%rsp)
   5bacc:      	testq	%rax, %rax
   5bacf:      	je	0x5bfba <f.10+0x63a>
   5bad5:      	movq	0x8(%rax), %rcx
   5bad9:      	testq	%rcx, %rcx
   5badc:      	je	0x5bfba <f.10+0x63a>
   5bae2:      	movq	0x10(%rax), %rdi
   5bae6:      	movq	0x8(%rcx), %rax
   5baea:      	movq	%rdi, 0x70(%rsp)
   5baef:      	movq	$0xb, 0x18(%rsp)
   5baf8:      	movq	%r15, %rsi
   5bafb:      	callq	*%rax
   5bafd:      	subq	$0x8, %rsp
   5bb01:      	cmpb	$0x0, 0x6980(%rip)      # 0x62488 <g.4>
   5bb08:      	je	0x5bfba <f.10+0x63a>
   5bb0e:      	cmpq	$0x0, 0x696a(%rip)      # 0x62480 <g.3>
   5bb16:      	je	0x5bfba <f.10+0x63a>
   5bb1c:      	movq	%rax, %r12
   5bb1f:      	shrq	$0x20, %rax
   5bb23:      	jne	0x5bfba <f.10+0x63a>
   5bb29:      	movq	$0xa, 0x18(%rsp)
   5bb32:      	movl	$0x18, %edi
   5bb37:      	callq	0x28930 <native_alloc>
   5bb3c:      	testq	%rax, %rax
   5bb3f:      	je	0x5bfba <f.10+0x63a>
   5bb45:      	movq	%rax, %r15
   5bb48:      	movq	$0x66, (%rax)
   5bb4f:      	movl	$0x0, 0x8(%rax)
   5bb56:      	movq	$0x0, 0x10(%rax)
   5bb5e:      	movq	%rax, 0x30(%rsp)
   5bb63:      	movq	0x50(%rsp), %rax
   5bb68:      	testq	%rax, %rax
   5bb6b:      	je	0x5bfba <f.10+0x63a>
   5bb71:      	movq	%rbx, 0x98(%rsp)
   5bb79:      	movq	0x8(%rax), %r14
   5bb7d:      	movq	%r14, 0x70(%rsp)
   5bb82:      	movq	%r13, 0x78(%rsp)
   5bb87:      	movq	%r15, 0x80(%rsp)
   5bb8f:      	movq	$0xd, 0x18(%rsp)
   5bb98:      	movl	$0xcb, %edi
   5bb9d:      	movq	%r12, 0xa0(%rsp)
   5bba5:      	movl	%r12d, %esi
   5bba8:      	xorl	%edx, %edx
   5bbaa:      	movl	$0x1, %ecx
   5bbaf:      	callq	0x2a970 <native_array_new>
   5bbb4:      	movq	%rax, %rbp
   5bbb7:      	movq	%rax, 0x70(%rsp)
   5bbbc:      	movq	%r14, 0x78(%rsp)
   5bbc1:      	movq	%r13, 0x80(%rsp)
   5bbc9:      	movq	%r15, 0x88(%rsp)
   5bbd1:      	movq	$0xe, 0x18(%rsp)
   5bbda:      	movl	$0x10, %edi
   5bbdf:      	callq	0x28930 <native_alloc>
   5bbe4:      	testq	%rax, %rax
   5bbe7:      	je	0x5bfba <f.10+0x63a>
   5bbed:      	movq	%r13, %r12
   5bbf0:      	movq	%rax, %r13
   5bbf3:      	movq	$0x82, (%rax)
   5bbfa:      	movq	%rbp, 0x8(%rax)
   5bbfe:      	movq	0x30(%rsp), %rbx
   5bc03:      	movq	%rbx, 0x70(%rsp)
   5bc08:      	movq	%rax, 0x78(%rsp)
   5bc0d:      	movq	%r14, 0x80(%rsp)
   5bc15:      	movq	%r12, 0x88(%rsp)
   5bc1d:      	movq	%r15, 0x90(%rsp)
   5bc25:      	movq	$0xf, 0x18(%rsp)
   5bc2e:      	movl	$0x28, %edi
   5bc33:      	callq	0x28930 <native_alloc>
   5bc38:      	testq	%rax, %rax
   5bc3b:      	je	0x5bfba <f.10+0x63a>
   5bc41:      	movq	%rax, %rbp
   5bc44:      	movq	$0x2a, (%rax)
   5bc4b:      	movq	%r14, 0x8(%rax)
   5bc4f:      	movq	0xa0(%rsp), %rax
   5bc57:      	movq	%rax, 0x10(%rbp)
   5bc5b:      	movq	%r13, 0x18(%rbp)
   5bc5f:      	movq	%rbx, 0x20(%rbp)
   5bc63:      	movq	%rbp, 0x70(%rsp)
   5bc68:      	movq	%r12, 0x78(%rsp)
   5bc6d:      	movq	%r15, 0x80(%rsp)
   5bc75:      	movq	$0xd, 0x18(%rsp)
   5bc7e:      	movl	$0x18, %edi
   5bc83:      	callq	0x28930 <native_alloc>
   5bc88:      	testq	%rax, %rax
   5bc8b:      	je	0x5bfba <f.10+0x63a>
   5bc91:      	movq	%r12, %r13
   5bc94:      	movq	$0xc2, (%rax)
   5bc9b:      	movq	%r12, 0x8(%rax)
   5bc9f:      	movq	%rbp, 0x10(%rax)
   5bca3:      	movq	%rax, 0x10(%r15)
   5bca7:      	movq	0x30(%rsp), %rax
   5bcac:      	testq	%rax, %rax
   5bcaf:      	je	0x5bfba <f.10+0x63a>
   5bcb5:      	movl	$0x1, 0x8(%rax)
   5bcbc:      	movq	0x30(%rsp), %rax
   5bcc1:      	testq	%rax, %rax
   5bcc4:      	je	0x5bfba <f.10+0x63a>
   5bcca:      	cmpl	$0x0, 0x8(%rax)
   5bcce:      	je	0x5bfba <f.10+0x63a>
   5bcd4:      	movq	0x10(%rax), %rax
   5bcd8:      	testq	%rax, %rax
   5bcdb:      	je	0x5bfba <f.10+0x63a>
   5bce1:      	movq	%rax, 0x60(%rsp)
   5bce6:      	movq	0x8(%rax), %rcx
   5bcea:      	testq	%rcx, %rcx
   5bced:      	je	0x5bfba <f.10+0x63a>
   5bcf3:      	movq	0x10(%rax), %rdi
   5bcf7:      	movq	0x8(%rcx), %rax
   5bcfb:      	movq	%rdi, 0x70(%rsp)
   5bd00:      	movq	$0xb, 0x18(%rsp)
   5bd09:      	xorl	%esi, %esi
   5bd0b:      	callq	*%rax
   5bd0d:      	subq	$0x8, %rsp
   5bd11:      	movq	%rax, 0x40(%rsp)
   5bd16:      	cmpb	$0x0, 0x677b(%rip)      # 0x62498 <g.6>
   5bd1d:      	je	0x5bfba <f.10+0x63a>
   5bd23:      	cmpq	$0x0, 0x6765(%rip)      # 0x62490 <g.5>
   5bd2b:      	je	0x5bfba <f.10+0x63a>
   5bd31:      	cmpb	$0x0, 0x6770(%rip)      # 0x624a8 <g.8>
   5bd38:      	je	0x5bfba <f.10+0x63a>
   5bd3e:      	cmpq	$0x0, 0x675a(%rip)      # 0x624a0 <g.7>
   5bd46:      	je	0x5bfba <f.10+0x63a>
   5bd4c:      	testq	%rax, %rax
   5bd4f:      	je	0x5bfba <f.10+0x63a>
   5bd55:      	movq	0x8(%rax), %rcx
   5bd59:      	testq	%rcx, %rcx
   5bd5c:      	je	0x5bfba <f.10+0x63a>
   5bd62:      	testb	$0x1, %cl
   5bd65:      	jne	0x5bfba <f.10+0x63a>
   5bd6b:      	movl	0x8(%rcx), %esi
   5bd6e:      	movq	%rax, 0x70(%rsp)
   5bd73:      	movq	$0xb, 0x18(%rsp)
   5bd7c:      	movq	%rax, %rdi
   5bd7f:      	callq	0x5a1d0 <f.5>
   5bd84:      	subq	$0x8, %rsp
   5bd88:      	movq	%rax, %r12
   5bd8b:      	movq	%rax, 0x38(%rsp)
   5bd90:      	movq	%rax, 0x70(%rsp)
   5bd95:      	movq	$0xb, 0x18(%rsp)
   5bd9e:      	movl	$0x10, %edi
   5bda3:      	callq	0x28930 <native_alloc>
   5bda8:      	testq	%rax, %rax
   5bdab:      	je	0x5bfba <f.10+0x63a>
   5bdb1:      	movq	%rax, %r15
   5bdb4:      	movq	$0x22, (%rax)
   5bdbb:      	movq	%r12, 0x8(%rax)
   5bdbf:      	movq	0x38(%rsp), %rdi
   5bdc4:      	testq	%rdi, %rdi
   5bdc7:      	je	0x5bfba <f.10+0x63a>
   5bdcd:      	movl	0x8(%rdi), %r12d
   5bdd1:      	movq	%r15, 0x70(%rsp)
   5bdd6:      	movq	%rdi, 0x78(%rsp)
   5bddb:      	movq	$0xc, 0x18(%rsp)
   5bde4:      	xorl	%esi, %esi
   5bde6:      	callq	0x5a070 <f.4>
   5bdeb:      	subq	$0x8, %rsp
   5bdef:      	movl	%eax, %ebp
   5bdf1:      	movq	0x38(%rsp), %rdi
   5bdf6:      	movq	%r15, 0x70(%rsp)
   5bdfb:      	movq	%rdi, 0x78(%rsp)
   5be00:      	movq	$0xc, 0x18(%rsp)
   5be09:      	movl	%r12d, %esi
   5be0c:      	callq	0x5a070 <f.4>
   5be11:      	subq	$0x8, %rsp
   5be15:      	movl	%eax, %r12d
   5be18:      	subl	%ebp, %r12d
   5be1b:      	movq	%r15, 0x70(%rsp)
   5be20:      	movq	$0xb, 0x18(%rsp)
   5be29:      	movl	$0xcb, %edi
   5be2e:      	movl	%r12d, %esi
   5be31:      	xorl	%edx, %edx
   5be33:      	movl	$0x1, %ecx
   5be38:      	callq	0x2a970 <native_array_new>
   5be3d:      	movq	%rax, 0x68(%rsp)
   5be42:      	movq	0x38(%rsp), %rcx
   5be47:      	testq	%rcx, %rcx
   5be4a:      	je	0x5bfba <f.10+0x63a>
   5be50:      	movq	0x18(%rcx), %rdx
   5be54:      	movq	%rax, %rdi
   5be57:      	xorl	%esi, %esi
   5be59:      	movl	%ebp, %ecx
   5be5b:      	movl	%r12d, %r8d
   5be5e:      	movl	$0x1, %r9d
   5be64:      	callq	0x2a900 <native_array_copy>
   5be69:      	movq	0x68(%rsp), %rbx
   5be6e:      	movq	%rbx, 0x70(%rsp)
   5be73:      	movq	%r15, 0x78(%rsp)
   5be78:      	movq	$0xc, 0x18(%rsp)
   5be81:      	movl	$0x10, %edi
   5be86:      	callq	0x28930 <native_alloc>
   5be8b:      	testq	%rax, %rax
   5be8e:      	je	0x5bfba <f.10+0x63a>
   5be94:      	movq	$0x82, (%rax)
   5be9b:      	movq	%rbx, 0x8(%rax)
   5be9f:      	movq	%rax, 0x48(%rsp)
   5bea4:      	movq	0x8(%rax), %rcx
   5bea8:      	testq	%rcx, %rcx
   5beab:      	je	0x5bfba <f.10+0x63a>
   5beb1:      	testb	$0x1, %cl
   5beb4:      	movq	0x98(%rsp), %rbx
   5bebc:      	jne	0x5bfba <f.10+0x63a>
   5bec2:      	movl	0x8(%rcx), %esi
   5bec5:      	movq	%r15, 0x70(%rsp)
   5beca:      	movq	%rax, 0x78(%rsp)
   5becf:      	movq	$0xc, 0x18(%rsp)
   5bed8:      	movq	%rax, %rdi
   5bedb:      	callq	0x5a1d0 <f.5>
   5bee0:      	subq	$0x8, %rsp
   5bee4:      	movq	%r15, 0x70(%rsp)
   5bee9:      	movq	%rax, 0x78(%rsp)
   5beee:      	movq	$0xc, 0x18(%rsp)
   5bef7:      	movq	%r15, %rdi
   5befa:      	movq	%rax, %rsi
   5befd:      	callq	0x5bfe0 <f.11>
   5bf02:      	subq	$0x8, %rsp
   5bf06:      	movq	0x28(%rsp), %r15
   5bf0b:      	testq	%r15, %r15
   5bf0e:      	je	0x5bfba <f.10+0x63a>
   5bf14:      	movq	0x20(%r15), %rax
   5bf18:      	testq	%rax, %rax
   5bf1b:      	je	0x5bfba <f.10+0x63a>
   5bf21:      	cmpl	$0x0, 0x8(%rax)
   5bf25:      	je	0x5bfba <f.10+0x63a>
   5bf2b:      	cmpq	$0x0, 0x10(%rax)
   5bf30:      	je	0x5bfba <f.10+0x63a>
   5bf36:      	leaq	0x8(%rsp), %r14
   5bf3b:      	movq	%r14, %rdi
   5bf3e:      	callq	0x2ae00 <native_roots_leave>
   5bf43:      	movl	$0xf, %esi
   5bf48:      	movq	%r14, %rdi
   5bf4b:      	callq	0x2adb0 <native_roots_enter>
   5bf50:      	movq	%r15, 0x20(%rsp)
   5bf55:      	leaq	0x28(%rsp), %rax
   5bf5a:      	movq	$0x0, 0x40(%rax)
   5bf62:      	movq	$0x0, 0x38(%rax)
   5bf6a:      	movq	$0x0, 0x30(%rax)
   5bf72:      	movq	$0x0, 0x28(%rax)
   5bf7a:      	movq	$0x0, 0x20(%rax)
   5bf82:      	movq	$0x0, 0x18(%rax)
   5bf8a:      	movq	$0x0, 0x10(%rax)
   5bf92:      	movq	$0x0, 0x8(%rax)
   5bf9a:      	movq	$0x0, (%rax)
   5bfa1:      	movl	$0x1e, %esi
   5bfa6:      	movq	%r15, %rdi
   5bfa9:      	xorl	%edx, %edx
   5bfab:      	xorl	%ecx, %ecx
   5bfad:      	callq	0x2acc0 <native_ref_test>
   5bfb2:      	testl	%eax, %eax
   5bfb4:      	jne	0x5ba20 <f.10+0xa0>
   5bfba:      	callq	0x26990 <native_trap>
   5bfbf:      	leaq	0x8(%rsp), %rdi
   5bfc4:      	callq	0x2ae00 <native_roots_leave>
   5bfc9:      	xorl	%eax, %eax
   5bfcb:      	addq	$0xa8, %rsp
   5bfd2:      	popq	%rbx
   5bfd3:      	popq	%r12
   5bfd5:      	popq	%r13
   5bfd7:      	popq	%r14
   5bfd9:      	popq	%r15
   5bfdb:      	popq	%rbp
   5bfdc:      	retq	$0x8
   5bfdf:      	int3

000000000005bfe0 <f.11>:
   5bfe0:      	pushq	%r15
   5bfe2:      	pushq	%r14
   5bfe4:      	pushq	%r12
   5bfe6:      	pushq	%rbx
   5bfe7:      	subq	$0x98, %rsp
   5bfee:      	movq	%rsi, %rbx
   5bff1:      	movq	%rdi, %r14
   5bff4:      	leaq	0x8(%rsp), %rdi
   5bff9:      	movl	$0xc, %esi
   5bffe:      	callq	0x2adb0 <native_roots_enter>
   5c003:      	movq	%r14, 0x20(%rsp)
   5c008:      	movq	%rbx, 0x28(%rsp)
   5c00d:      	testq	%r14, %r14
   5c010:      	movq	$0x0, 0x30(%rsp)
   5c019:      	movq	$0x0, 0x38(%rsp)
   5c022:      	movq	$0x0, 0x40(%rsp)
   5c02b:      	movq	$0x0, 0x48(%rsp)
   5c034:      	movq	$0x0, 0x50(%rsp)
   5c03d:      	movq	$0x0, 0x58(%rsp)
   5c046:      	je	0x5c48b <f.11+0x4ab>
   5c04c:      	movq	0x8(%r14), %rcx
   5c050:      	movq	%rcx, 0x40(%rsp)
   5c055:      	cmpq	%rbx, %rcx
   5c058:      	jne	0x5c061 <f.11+0x81>
   5c05a:      	xorl	%esi, %esi
   5c05c:      	jmp	0x5c0fd <f.11+0x11d>
   5c061:      	testq	%rcx, %rcx
   5c064:      	je	0x5c48b <f.11+0x4ab>
   5c06a:      	testq	%rbx, %rbx
   5c06d:      	je	0x5c48b <f.11+0x4ab>
   5c073:      	movl	0x10(%rcx), %eax
   5c076:      	movb	$0x1, %sil
   5c079:      	cmpl	0x10(%rbx), %eax
   5c07c:      	jne	0x5c0fd <f.11+0x11d>
   5c07e:      	movq	0x18(%rcx), %rcx
   5c082:      	movq	%rcx, 0x48(%rsp)
   5c087:      	movq	0x18(%rbx), %rdx
   5c08b:      	movq	%rdx, 0x50(%rsp)
   5c090:      	testl	%eax, %eax
   5c092:      	je	0x5c05a <f.11+0x7a>
   5c094:      	testq	%rcx, %rcx
   5c097:      	je	0x5c48b <f.11+0x4ab>
   5c09d:      	testb	$0x1, %cl
   5c0a0:      	jne	0x5c48b <f.11+0x4ab>
   5c0a6:      	testq	%rdx, %rdx
   5c0a9:      	movq	0x8(%rcx), %rdi
   5c0ad:      	je	0x5c488 <f.11+0x4a8>
   5c0b3:      	testb	$0x1, %dl
   5c0b6:      	jne	0x5c488 <f.11+0x4a8>
   5c0bc:      	decl	%eax
   5c0be:      	xorl	%r8d, %r8d
   5c0c1:      	nopw	%cs:(%rax,%rax)
   5c0cb:      	nopl	(%rax,%rax)
   5c0d0:      	cmpq	%r8, %rdi
   5c0d3:      	jbe	0x5c48b <f.11+0x4ab>
   5c0d9:      	cmpq	%r8, 0x8(%rdx)
   5c0dd:      	jbe	0x5c48b <f.11+0x4ab>
   5c0e3:      	movzbl	0x10(%rcx,%r8), %esi
   5c0e9:      	cmpb	0x10(%rdx,%r8), %sil
   5c0ee:      	setne	%sil
   5c0f2:      	jne	0x5c0fd <f.11+0x11d>
   5c0f4:      	cmpl	%r8d, %eax
   5c0f7:      	leaq	0x1(%r8), %r8
   5c0fb:      	jne	0x5c0d0 <f.11+0xf0>
   5c0fd:      	cmpb	$0x0, 0x6424(%rip)      # 0x62528 <g.24>
   5c104:      	je	0x5c48b <f.11+0x4ab>
   5c10a:      	cmpq	$0x0, 0x640e(%rip)      # 0x62520 <g.23>
   5c112:      	je	0x5c48b <f.11+0x4ab>
   5c118:      	cmpb	$0x0, 0x63a9(%rip)      # 0x624c8 <g.12>
   5c11f:      	je	0x5c48b <f.11+0x4ab>
   5c125:      	cmpq	$0x0, 0x6393(%rip)      # 0x624c0 <g.11>
   5c12d:      	je	0x5c48b <f.11+0x4ab>
   5c133:      	testb	%sil, %sil
   5c136:      	je	0x5c46d <f.11+0x48d>
   5c13c:      	cmpb	$0x0, 0x63a5(%rip)      # 0x624e8 <g.16>
   5c143:      	je	0x5c48b <f.11+0x4ab>
   5c149:      	cmpq	$0x0, 0x638f(%rip)      # 0x624e0 <g.15>
   5c151:      	je	0x5c48b <f.11+0x4ab>
   5c157:      	movq	$0x8, 0x18(%rsp)
   5c160:      	movl	$0x18, %edi
   5c165:      	callq	0x28930 <native_alloc>
   5c16a:      	testq	%rax, %rax
   5c16d:      	je	0x5c48b <f.11+0x4ab>
   5c173:      	movq	%rax, %rbx
   5c176:      	movq	$0x62, (%rax)
   5c17d:      	movl	$0x0, 0x8(%rax)
   5c184:      	movq	$0x0, 0x10(%rax)
   5c18c:      	movq	%rax, 0x30(%rsp)
   5c191:      	movq	%rax, 0x60(%rsp)
   5c196:      	leaq	0x61c3(%rip), %r12      # 0x62360 <object.2.1>
   5c19d:      	movq	%r12, 0x68(%rsp)
   5c1a2:      	leaq	0x3eff(%rip), %r15      # 0x600a8 <ref.17>
   5c1a9:      	movq	%r15, 0x70(%rsp)
   5c1ae:      	movq	%rax, 0x78(%rsp)
   5c1b3:      	movq	$0xc, 0x18(%rsp)
   5c1bc:      	movl	$0x18, %edi
   5c1c1:      	callq	0x28930 <native_alloc>
   5c1c6:      	testq	%rax, %rax
   5c1c9:      	je	0x5c48b <f.11+0x4ab>
   5c1cf:      	movq	%rax, %r14
   5c1d2:      	movq	$0xa, (%rax)
   5c1d9:      	movq	%r12, 0x8(%rax)
   5c1dd:      	movq	%rbx, 0x10(%rax)
   5c1e1:      	movq	%rax, 0x60(%rsp)
   5c1e6:      	movq	%r15, 0x68(%rsp)
   5c1eb:      	movq	%rbx, 0x70(%rsp)
   5c1f0:      	movq	$0xb, 0x18(%rsp)
   5c1f9:      	movl	$0x18, %edi
   5c1fe:      	callq	0x28930 <native_alloc>
   5c203:      	testq	%rax, %rax
   5c206:      	je	0x5c48b <f.11+0x4ab>
   5c20c:      	movq	$0x42, (%rax)
   5c213:      	movq	%r15, 0x8(%rax)
   5c217:      	movq	%r14, 0x10(%rax)
   5c21b:      	movq	%rax, 0x10(%rbx)
   5c21f:      	movq	0x30(%rsp), %rax
   5c224:      	testq	%rax, %rax
   5c227:      	je	0x5c48b <f.11+0x4ab>
   5c22d:      	movl	$0x1, 0x8(%rax)
   5c234:      	movq	0x30(%rsp), %rax
   5c239:      	testq	%rax, %rax
   5c23c:      	je	0x5c48b <f.11+0x4ab>
   5c242:      	cmpl	$0x0, 0x8(%rax)
   5c246:      	je	0x5c48b <f.11+0x4ab>
   5c24c:      	movq	0x10(%rax), %rax
   5c250:      	testq	%rax, %rax
   5c253:      	je	0x5c48b <f.11+0x4ab>
   5c259:      	movq	%rax, 0x38(%rsp)
   5c25e:      	movq	0x8(%rax), %rcx
   5c262:      	testq	%rcx, %rcx
   5c265:      	je	0x5c48b <f.11+0x4ab>
   5c26b:      	movq	0x10(%rax), %rdi
   5c26f:      	movq	0x8(%rcx), %rax
   5c273:      	movq	%rdi, 0x60(%rsp)
   5c278:      	movq	$0x9, 0x18(%rsp)
   5c281:      	xorl	%esi, %esi
   5c283:      	callq	*%rax
   5c285:      	subq	$0x8, %rsp
   5c289:      	cmpb	$0x0, 0x6258(%rip)      # 0x624e8 <g.16>
   5c290:      	je	0x5c48b <f.11+0x4ab>
   5c296:      	cmpq	$0x0, 0x6242(%rip)      # 0x624e0 <g.15>
   5c29e:      	je	0x5c48b <f.11+0x4ab>
   5c2a4:      	movq	$0x8, 0x18(%rsp)
   5c2ad:      	movl	$0x18, %edi
   5c2b2:      	callq	0x28930 <native_alloc>
   5c2b7:      	testq	%rax, %rax
   5c2ba:      	je	0x5c48b <f.11+0x4ab>
   5c2c0:      	movq	%rax, %rbx
   5c2c3:      	movq	$0x62, (%rax)
   5c2ca:      	movl	$0x0, 0x8(%rax)
   5c2d1:      	movq	$0x0, 0x10(%rax)
   5c2d9:      	movq	%rax, 0x30(%rsp)
   5c2de:      	movq	%rax, 0x60(%rsp)
   5c2e3:      	leaq	0x6016(%rip), %r12      # 0x62300 <object.1.1>
   5c2ea:      	movq	%r12, 0x68(%rsp)
   5c2ef:      	movq	%r15, 0x70(%rsp)
   5c2f4:      	movq	%rax, 0x78(%rsp)
   5c2f9:      	movq	$0xc, 0x18(%rsp)
   5c302:      	movl	$0x18, %edi
   5c307:      	callq	0x28930 <native_alloc>
   5c30c:      	testq	%rax, %rax
   5c30f:      	je	0x5c48b <f.11+0x4ab>
   5c315:      	movq	%rax, %r14
   5c318:      	movq	$0xa, (%rax)
   5c31f:      	movq	%r12, 0x8(%rax)
   5c323:      	movq	%rbx, 0x10(%rax)
   5c327:      	movq	%rax, 0x60(%rsp)
   5c32c:      	movq	%r15, 0x68(%rsp)
   5c331:      	movq	%rbx, 0x70(%rsp)
   5c336:      	movq	$0xb, 0x18(%rsp)
   5c33f:      	movl	$0x18, %edi
   5c344:      	callq	0x28930 <native_alloc>
   5c349:      	testq	%rax, %rax
   5c34c:      	je	0x5c48b <f.11+0x4ab>
   5c352:      	movq	$0x42, (%rax)
   5c359:      	movq	%r15, 0x8(%rax)
   5c35d:      	movq	%r14, 0x10(%rax)
   5c361:      	movq	%rax, 0x10(%rbx)
   5c365:      	movq	0x30(%rsp), %rax
   5c36a:      	testq	%rax, %rax
   5c36d:      	je	0x5c48b <f.11+0x4ab>
   5c373:      	movl	$0x1, 0x8(%rax)
   5c37a:      	movq	0x30(%rsp), %rax
   5c37f:      	testq	%rax, %rax
   5c382:      	je	0x5c48b <f.11+0x4ab>
   5c388:      	cmpl	$0x0, 0x8(%rax)
   5c38c:      	je	0x5c48b <f.11+0x4ab>
   5c392:      	movq	0x10(%rax), %rax
   5c396:      	testq	%rax, %rax
   5c399:      	je	0x5c48b <f.11+0x4ab>
   5c39f:      	movq	%rax, 0x38(%rsp)
   5c3a4:      	movq	0x8(%rax), %rcx
   5c3a8:      	testq	%rcx, %rcx
   5c3ab:      	je	0x5c48b <f.11+0x4ab>
   5c3b1:      	movq	0x10(%rax), %rdi
   5c3b5:      	movq	0x8(%rcx), %rax
   5c3b9:      	movq	%rdi, 0x60(%rsp)
   5c3be:      	movq	$0x9, 0x18(%rsp)
   5c3c7:      	xorl	%esi, %esi
   5c3c9:      	callq	*%rax
   5c3cb:      	subq	$0x8, %rsp
   5c3cf:      	cmpb	$0x0, 0x6122(%rip)      # 0x624f8 <g.18>
   5c3d6:      	je	0x5c48b <f.11+0x4ab>
   5c3dc:      	cmpq	$0x0, 0x610c(%rip)      # 0x624f0 <g.17>
   5c3e4:      	je	0x5c48b <f.11+0x4ab>
   5c3ea:      	movq	$0x8, 0x18(%rsp)
   5c3f3:      	leaq	0x80(%rsp), %rbx
   5c3fb:      	movq	%rbx, %rdi
   5c3fe:      	xorl	%esi, %esi
   5c400:      	callq	0x2adb0 <native_roots_enter>
   5c405:      	movq	$0x0, 0x90(%rsp)
   5c411:      	movl	$0xa, %edi
   5c416:      	callq	0x14b70 <write_character>
   5c41b:      	movq	%rbx, %rdi
   5c41e:      	callq	0x2ae00 <native_roots_leave>
   5c423:      	cmpb	$0x0, 0x60ee(%rip)      # 0x62518 <g.22>
   5c42a:      	je	0x5c48b <f.11+0x4ab>
   5c42c:      	movq	0x60dd(%rip), %rbx      # 0x62510 <g.21>
   5c433:      	testq	%rbx, %rbx
   5c436:      	je	0x5c48b <f.11+0x4ab>
   5c438:      	movq	0x8(%rbx), %r14
   5c43c:      	movq	%r14, 0x60(%rsp)
   5c441:      	movq	%rbx, 0x68(%rsp)
   5c446:      	movq	$0xa, 0x18(%rsp)
   5c44f:      	movl	$0x10, %edi
   5c454:      	callq	0x28930 <native_alloc>
   5c459:      	testq	%rax, %rax
   5c45c:      	je	0x5c48b <f.11+0x4ab>
   5c45e:      	movq	$0x6e, (%rax)
   5c465:      	movq	%r14, 0x8(%rax)
   5c469:      	movq	%rax, 0x8(%rbx)
   5c46d:      	leaq	0x8(%rsp), %rdi
   5c472:      	callq	0x2ae00 <native_roots_leave>
   5c477:      	addq	$0x98, %rsp
   5c47e:      	popq	%rbx
   5c47f:      	popq	%r12
   5c481:      	popq	%r14
   5c483:      	popq	%r15
   5c485:      	retq	$0x8
   5c488:      	testq	%rdi, %rdi
   5c48b:      	callq	0x26990 <native_trap>

000000000005c490 <f.12>:
   5c490:      	pushq	%rbp
   5c491:      	pushq	%r15
   5c493:      	pushq	%r14
   5c495:      	pushq	%r13
   5c497:      	pushq	%r12
   5c499:      	pushq	%rbx
   5c49a:      	subq	$0x78, %rsp
   5c49e:      	movq	%rsi, %rbx
   5c4a1:      	movq	%rdi, %r14
   5c4a4:      	leaq	0x10(%rsp), %rdi
   5c4a9:      	movl	$0xa, %esi
   5c4ae:      	callq	0x2adb0 <native_roots_enter>
   5c4b3:      	movq	%r14, 0x28(%rsp)
   5c4b8:      	movq	$0x0, 0x30(%rsp)
   5c4c1:      	movq	$0x0, 0x38(%rsp)
   5c4ca:      	movq	$0x0, 0x40(%rsp)
   5c4d3:      	movq	$0x0, 0x48(%rsp)
   5c4dc:      	movl	$0x4a, %esi
   5c4e1:      	movq	%r14, %rdi
   5c4e4:      	xorl	%edx, %edx
   5c4e6:      	xorl	%ecx, %ecx
   5c4e8:      	callq	0x2acc0 <native_ref_test>
   5c4ed:      	testl	%eax, %eax
   5c4ef:      	je	0x5c73b <f.12+0x2ab>
   5c4f5:      	movq	%r14, 0x38(%rsp)
   5c4fa:      	testq	%r14, %r14
   5c4fd:      	je	0x5c73b <f.12+0x2ab>
   5c503:      	movq	0x8(%r14), %rax
   5c507:      	testq	%rax, %rax
   5c50a:      	je	0x5c73b <f.12+0x2ab>
   5c510:      	movq	0x8(%rax), %rax
   5c514:      	movq	%rax, 0x40(%rsp)
   5c519:      	testq	%rax, %rax
   5c51c:      	je	0x5c73b <f.12+0x2ab>
   5c522:      	movq	0x8(%rax), %rcx
   5c526:      	testq	%rcx, %rcx
   5c529:      	je	0x5c73b <f.12+0x2ab>
   5c52f:      	movq	0x10(%rax), %rdi
   5c533:      	movq	0x8(%rcx), %rax
   5c537:      	movq	%rdi, 0x50(%rsp)
   5c53c:      	movq	$0x6, 0x20(%rsp)
   5c545:      	movq	%rbx, %rsi
   5c548:      	callq	*%rax
   5c54a:      	subq	$0x8, %rsp
   5c54e:      	cmpb	$0x0, 0x5f33(%rip)      # 0x62488 <g.4>
   5c555:      	je	0x5c73b <f.12+0x2ab>
   5c55b:      	cmpq	$0x0, 0x5f1d(%rip)      # 0x62480 <g.3>
   5c563:      	je	0x5c73b <f.12+0x2ab>
   5c569:      	movq	%rax, %r14
   5c56c:      	shrq	$0x20, %rax
   5c570:      	jne	0x5c73b <f.12+0x2ab>
   5c576:      	movq	$0x5, 0x20(%rsp)
   5c57f:      	movl	$0x18, %edi
   5c584:      	callq	0x28930 <native_alloc>
   5c589:      	testq	%rax, %rax
   5c58c:      	je	0x5c73b <f.12+0x2ab>
   5c592:      	movq	%rax, %rbx
   5c595:      	movq	$0x66, (%rax)
   5c59c:      	movl	$0x0, 0x8(%rax)
   5c5a3:      	movq	$0x0, 0x10(%rax)
   5c5ab:      	movq	%rax, 0x30(%rsp)
   5c5b0:      	movq	0x38(%rsp), %rax
   5c5b5:      	testq	%rax, %rax
   5c5b8:      	je	0x5c73b <f.12+0x2ab>
   5c5be:      	movq	0x8(%rax), %rbp
   5c5c2:      	movq	%rbp, 0x50(%rsp)
   5c5c7:      	leaq	0x3aaa(%rip), %r15      # 0x60078 <ref.13>
   5c5ce:      	movq	%r15, 0x58(%rsp)
   5c5d3:      	movq	%rbx, 0x60(%rsp)
   5c5d8:      	movq	$0x8, 0x20(%rsp)
   5c5e1:      	movl	$0xcb, %edi
   5c5e6:      	movl	%r14d, %esi
   5c5e9:      	xorl	%edx, %edx
   5c5eb:      	movl	$0x1, %ecx
   5c5f0:      	callq	0x2a970 <native_array_new>
   5c5f5:      	movq	%rax, %r12
   5c5f8:      	movq	%rax, 0x50(%rsp)
   5c5fd:      	movq	%rbp, 0x58(%rsp)
   5c602:      	movq	%r15, 0x60(%rsp)
   5c607:      	movq	%rbx, 0x68(%rsp)
   5c60c:      	movq	$0x9, 0x20(%rsp)
   5c615:      	movl	$0x10, %edi
   5c61a:      	callq	0x28930 <native_alloc>
   5c61f:      	testq	%rax, %rax
   5c622:      	je	0x5c73b <f.12+0x2ab>
   5c628:      	movq	%rax, %r15
   5c62b:      	movq	$0x82, (%rax)
   5c632:      	movq	%r12, 0x8(%rax)
   5c636:      	movq	0x30(%rsp), %r13
   5c63b:      	movq	%r13, 0x50(%rsp)
   5c640:      	movq	%rax, 0x58(%rsp)
   5c645:      	movq	%rbp, 0x60(%rsp)
   5c64a:      	leaq	0x3a27(%rip), %rax      # 0x60078 <ref.13>
   5c651:      	movq	%rax, 0x68(%rsp)
   5c656:      	movq	%rbx, 0x70(%rsp)
   5c65b:      	movq	$0xa, 0x20(%rsp)
   5c664:      	movl	$0x28, %edi
   5c669:      	callq	0x28930 <native_alloc>
   5c66e:      	testq	%rax, %rax
   5c671:      	je	0x5c73b <f.12+0x2ab>
   5c677:      	movq	%rax, %r12
   5c67a:      	movq	$0x2a, (%rax)
   5c681:      	movq	%rbp, 0x8(%rax)
   5c685:      	movq	%r14, 0x10(%rax)
   5c689:      	movq	%r15, 0x18(%rax)
   5c68d:      	movq	%r13, 0x20(%rax)
   5c691:      	movq	%rax, 0x50(%rsp)
   5c696:      	leaq	0x39db(%rip), %rax      # 0x60078 <ref.13>
   5c69d:      	movq	%rax, 0x58(%rsp)
   5c6a2:      	movq	%rbx, 0x60(%rsp)
   5c6a7:      	movq	$0x8, 0x20(%rsp)
   5c6b0:      	movl	$0x18, %edi
   5c6b5:      	callq	0x28930 <native_alloc>
   5c6ba:      	testq	%rax, %rax
   5c6bd:      	je	0x5c73b <f.12+0x2ab>
   5c6bf:      	movq	$0xc2, (%rax)
   5c6c6:      	leaq	0x39ab(%rip), %rcx      # 0x60078 <ref.13>
   5c6cd:      	movq	%rcx, 0x8(%rax)
   5c6d1:      	movq	%r12, 0x10(%rax)
   5c6d5:      	movq	%rax, 0x10(%rbx)
   5c6d9:      	movq	0x30(%rsp), %rax
   5c6de:      	testq	%rax, %rax
   5c6e1:      	je	0x5c73b <f.12+0x2ab>
   5c6e3:      	movl	$0x1, 0x8(%rax)
   5c6ea:      	movq	0x30(%rsp), %rax
   5c6ef:      	testq	%rax, %rax
   5c6f2:      	je	0x5c73b <f.12+0x2ab>
   5c6f4:      	cmpl	$0x0, 0x8(%rax)
   5c6f8:      	je	0x5c73b <f.12+0x2ab>
   5c6fa:      	movq	0x10(%rax), %rax
   5c6fe:      	testq	%rax, %rax
   5c701:      	je	0x5c73b <f.12+0x2ab>
   5c703:      	movq	%rax, 0x48(%rsp)
   5c708:      	movq	0x8(%rax), %rcx
   5c70c:      	testq	%rcx, %rcx
   5c70f:      	je	0x5c73b <f.12+0x2ab>
   5c711:      	movq	0x10(%rax), %rbx
   5c715:      	movq	0x8(%rcx), %r14
   5c719:      	leaq	0x10(%rsp), %rdi
   5c71e:      	callq	0x2ae00 <native_roots_leave>
   5c723:      	movq	%rbx, %rdi
   5c726:      	xorl	%esi, %esi
   5c728:      	movq	%r14, %rax
   5c72b:      	addq	$0x78, %rsp
   5c72f:      	popq	%rbx
   5c730:      	popq	%r12
   5c732:      	popq	%r13
   5c734:      	popq	%r14
   5c736:      	popq	%r15
   5c738:      	popq	%rbp
   5c739:      	jmpq	*%rax
   5c73b:      	callq	0x26990 <native_trap>

000000000005c740 <f.13>:
   5c740:      	pushq	%r15
   5c742:      	pushq	%r14
   5c744:      	pushq	%r12
   5c746:      	pushq	%rbx
   5c747:      	subq	$0x48, %rsp
   5c74b:      	movq	%rsi, %rbx
   5c74e:      	movq	%rdi, %r15
   5c751:      	leaq	0x10(%rsp), %rdi
   5c756:      	movl	$0x4, %esi
   5c75b:      	callq	0x2adb0 <native_roots_enter>
   5c760:      	movq	%r15, 0x28(%rsp)
   5c765:      	movq	$0x0, 0x30(%rsp)
   5c76e:      	movq	$0x0, 0x38(%rsp)
   5c777:      	movl	$0x2a, %esi
   5c77c:      	movq	%r15, %rdi
   5c77f:      	xorl	%edx, %edx
   5c781:      	xorl	%ecx, %ecx
   5c783:      	callq	0x2acc0 <native_ref_test>
   5c788:      	testl	%eax, %eax
   5c78a:      	je	0x5c8b4 <f.13+0x174>
   5c790:      	leaq	0x30(%rsp), %r12
   5c795:      	leaq	0x10(%rsp), %r14
   5c79a:      	nopw	(%rax,%rax)
   5c7a0:      	movq	%r15, 0x30(%rsp)
   5c7a5:      	testq	%r15, %r15
   5c7a8:      	je	0x5c8b4 <f.13+0x174>
   5c7ae:      	cmpq	0x10(%r15), %rbx
   5c7b2:      	je	0x5c8b9 <f.13+0x179>
   5c7b8:      	movq	0x8(%r15), %rax
   5c7bc:      	testq	%rax, %rax
   5c7bf:      	je	0x5c8b4 <f.13+0x174>
   5c7c5:      	movq	0x8(%rax), %rax
   5c7c9:      	movq	%rax, 0x38(%rsp)
   5c7ce:      	testq	%rax, %rax
   5c7d1:      	je	0x5c8b4 <f.13+0x174>
   5c7d7:      	movq	0x8(%rax), %rcx
   5c7db:      	testq	%rcx, %rcx
   5c7de:      	je	0x5c8b4 <f.13+0x174>
   5c7e4:      	movq	0x10(%rax), %rdi
   5c7e8:      	movq	0x8(%rcx), %rax
   5c7ec:      	movq	%rdi, 0x40(%rsp)
   5c7f1:      	movq	$0x4, 0x20(%rsp)
   5c7fa:      	movl	$0x80, %esi
   5c7ff:      	callq	*%rax
   5c801:      	subq	$0x8, %rsp
   5c805:      	movq	%rbx, %rcx
   5c808:      	shrq	$0x20, %rcx
   5c80c:      	jne	0x5c8b4 <f.13+0x174>
   5c812:      	cmpq	$0x100, %rax            # imm = 0x100
   5c818:      	jae	0x5c8b4 <f.13+0x174>
   5c81e:      	movq	0x30(%rsp), %rcx
   5c823:      	testq	%rcx, %rcx
   5c826:      	je	0x5c8b4 <f.13+0x174>
   5c82c:      	movq	0x18(%rcx), %rcx
   5c830:      	testq	%rcx, %rcx
   5c833:      	je	0x5c8b4 <f.13+0x174>
   5c835:      	movq	0x8(%rcx), %rcx
   5c839:      	testq	%rcx, %rcx
   5c83c:      	je	0x5c8b4 <f.13+0x174>
   5c83e:      	testb	$0x1, %cl
   5c841:      	jne	0x5c8b4 <f.13+0x174>
   5c843:      	cmpq	0x8(%rcx), %rbx
   5c847:      	jae	0x5c8b4 <f.13+0x174>
   5c849:      	movb	%al, 0x10(%rcx,%rbx)
   5c84d:      	movq	0x30(%rsp), %r15
   5c852:      	testq	%r15, %r15
   5c855:      	je	0x5c8b4 <f.13+0x174>
   5c857:      	movq	0x20(%r15), %rax
   5c85b:      	testq	%rax, %rax
   5c85e:      	je	0x5c8b4 <f.13+0x174>
   5c860:      	cmpl	$0x0, 0x8(%rax)
   5c864:      	je	0x5c8b4 <f.13+0x174>
   5c866:      	cmpq	$0x0, 0x10(%rax)
   5c86b:      	je	0x5c8b4 <f.13+0x174>
   5c86d:      	incq	%rbx
   5c870:      	movq	%r14, %rdi
   5c873:      	callq	0x2ae00 <native_roots_leave>
   5c878:      	movl	$0x4, %esi
   5c87d:      	movq	%r14, %rdi
   5c880:      	callq	0x2adb0 <native_roots_enter>
   5c885:      	movq	%r15, 0x28(%rsp)
   5c88a:      	movq	$0x0, 0x8(%r12)
   5c893:      	movq	$0x0, (%r12)
   5c89b:      	movl	$0x2a, %esi
   5c8a0:      	movq	%r15, %rdi
   5c8a3:      	xorl	%edx, %edx
   5c8a5:      	xorl	%ecx, %ecx
   5c8a7:      	callq	0x2acc0 <native_ref_test>
   5c8ac:      	testl	%eax, %eax
   5c8ae:      	jne	0x5c7a0 <f.13+0x60>
   5c8b4:      	callq	0x26990 <native_trap>
   5c8b9:      	movq	0x18(%r15), %rbx
   5c8bd:      	leaq	0x10(%rsp), %rdi
   5c8c2:      	callq	0x2ae00 <native_roots_leave>
   5c8c7:      	movq	%rbx, %rax
   5c8ca:      	addq	$0x48, %rsp
   5c8ce:      	popq	%rbx
   5c8cf:      	popq	%r12
   5c8d1:      	popq	%r14
   5c8d3:      	popq	%r15
   5c8d5:      	retq	$0x8
   5c8d8:      	int3
   5c8d9:      	int3
   5c8da:      	int3
   5c8db:      	int3
   5c8dc:      	int3
   5c8dd:      	int3
   5c8de:      	int3
   5c8df:      	int3

000000000005c8e0 <f.14>:
   5c8e0:      	pushq	%rbp
   5c8e1:      	pushq	%r15
   5c8e3:      	pushq	%r14
   5c8e5:      	pushq	%r13
   5c8e7:      	pushq	%r12
   5c8e9:      	pushq	%rbx
   5c8ea:      	subq	$0x68, %rsp
   5c8ee:      	movq	%rsi, %rbx
   5c8f1:      	movq	%rdi, %r14
   5c8f4:      	leaq	0x38(%rsp), %rdi
   5c8f9:      	movl	$0x3, %esi
   5c8fe:      	callq	0x2adb0 <native_roots_enter>
   5c903:      	movq	%r14, 0x50(%rsp)
   5c908:      	movq	$0x0, 0x58(%rsp)
   5c911:      	movl	$0x2e, %esi
   5c916:      	movq	%r14, %rdi
   5c919:      	xorl	%edx, %edx
   5c91b:      	xorl	%ecx, %ecx
   5c91d:      	callq	0x2acc0 <native_ref_test>
   5c922:      	cmpq	$0x3fff, %rbx           # imm = 0x3FFF
   5c929:      	jg	0x5c97d <f.14+0x9d>
   5c92b:      	testl	%eax, %eax
   5c92d:      	je	0x5cb0b <f.14+0x22b>
   5c933:      	testq	%r14, %r14
   5c936:      	je	0x5cb0b <f.14+0x22b>
   5c93c:      	movq	0x8(%r14), %rax
   5c940:      	testq	%rax, %rax
   5c943:      	je	0x5cb0b <f.14+0x22b>
   5c949:      	movq	0x8(%rax), %rax
   5c94d:      	testq	%rax, %rax
   5c950:      	je	0x5cb0b <f.14+0x22b>
   5c956:      	movq	0x10(%rax), %r14
   5c95a:      	leaq	0x38(%rsp), %rdi
   5c95f:      	callq	0x2ae00 <native_roots_leave>
   5c964:      	movq	%r14, %rdi
   5c967:      	movq	%rbx, %rsi
   5c96a:      	addq	$0x68, %rsp
   5c96e:      	popq	%rbx
   5c96f:      	popq	%r12
   5c971:      	popq	%r13
   5c973:      	popq	%r14
   5c975:      	popq	%r15
   5c977:      	popq	%rbp
   5c978:      	jmp	0x5cb40 <f.16>
   5c97d:      	testl	%eax, %eax
   5c97f:      	je	0x5cb0b <f.14+0x22b>
   5c985:      	movq	%r14, 0x58(%rsp)
   5c98a:      	testq	%r14, %r14
   5c98d:      	je	0x5cb0b <f.14+0x22b>
   5c993:      	movq	0x8(%r14), %rax
   5c997:      	testq	%rax, %rax
   5c99a:      	je	0x5cb0b <f.14+0x22b>
   5c9a0:      	movq	0x8(%rax), %rax
   5c9a4:      	testq	%rax, %rax
   5c9a7:      	je	0x5cb0b <f.14+0x22b>
   5c9ad:      	movq	0x10(%rax), %rdi
   5c9b1:      	movq	%rdi, 0x60(%rsp)
   5c9b6:      	movq	$0x3, 0x48(%rsp)
   5c9bf:      	movl	$0x4000, %esi           # imm = 0x4000
   5c9c4:      	callq	0x5cb40 <f.16>
   5c9c9:      	subq	$0x8, %rsp
   5c9cd:      	movq	%rax, %r14
   5c9d0:      	movq	0x58(%rsp), %rax
   5c9d5:      	testq	%rax, %rax
   5c9d8:      	je	0x5cb0b <f.14+0x22b>
   5c9de:      	movq	0x10(%rax), %rax
   5c9e2:      	testq	%rax, %rax
   5c9e5:      	je	0x5cb0b <f.14+0x22b>
   5c9eb:      	cmpl	$0x0, 0x8(%rax)
   5c9ef:      	je	0x5cb0b <f.14+0x22b>
   5c9f5:      	movq	0x10(%rax), %rax
   5c9f9:      	testq	%rax, %rax
   5c9fc:      	je	0x5cb0b <f.14+0x22b>
   5ca02:      	movq	0x8(%rax), %rbp
   5ca06:      	movl	$0x4000, %esi           # imm = 0x4000
   5ca0b:      	movq	%rbx, %rdi
   5ca0e:      	callq	0x2ac40 <native_i64_div_s>
   5ca13:      	movq	%rax, %r15
   5ca16:      	leaq	0x38(%rsp), %rdi
   5ca1b:      	callq	0x2ae00 <native_roots_leave>
   5ca20:      	leaq	0x10(%rsp), %rdi
   5ca25:      	movl	$0x2, %esi
   5ca2a:      	callq	0x2adb0 <native_roots_enter>
   5ca2f:      	movq	%rbp, 0x28(%rsp)
   5ca34:      	cmpb	$0x1, 0x5a9d(%rip)      # 0x624d8 <g.14>
   5ca3b:      	jne	0x5cb0b <f.14+0x22b>
   5ca41:      	leaq	0x10(%rsp), %r12
   5ca46:      	nopw	%cs:(%rax,%rax)
   5ca50:      	cmpq	$0x0, 0x5a78(%rip)      # 0x624d0 <g.13>
   5ca58:      	je	0x5cb0b <f.14+0x22b>
   5ca5e:      	testq	%r15, %r15
   5ca61:      	je	0x5cb10 <f.14+0x230>
   5ca67:      	testq	%rbp, %rbp
   5ca6a:      	je	0x5cb0b <f.14+0x22b>
   5ca70:      	movq	0x8(%rbp), %rax
   5ca74:      	testq	%rax, %rax
   5ca77:      	je	0x5cb0b <f.14+0x22b>
   5ca7d:      	movq	0x8(%rax), %rax
   5ca81:      	testq	%rax, %rax
   5ca84:      	je	0x5cb0b <f.14+0x22b>
   5ca8a:      	movq	0x10(%rax), %rdi
   5ca8e:      	movq	%rdi, 0x30(%rsp)
   5ca93:      	movq	$0x2, 0x20(%rsp)
   5ca9c:      	movl	$0x4000, %esi           # imm = 0x4000
   5caa1:      	callq	0x5cb40 <f.16>
   5caa6:      	subq	$0x8, %rsp
   5caaa:      	movq	0x28(%rsp), %rbp
   5caaf:      	testq	%rbp, %rbp
   5cab2:      	je	0x5cb0b <f.14+0x22b>
   5cab4:      	movq	%rax, %r13
   5cab7:      	movq	0x10(%rbp), %rax
   5cabb:      	testq	%rax, %rax
   5cabe:      	je	0x5cb0b <f.14+0x22b>
   5cac0:      	cmpl	$0x0, 0x8(%rax)
   5cac4:      	je	0x5cb0b <f.14+0x22b>
   5cac6:      	cmpq	$0x0, 0x10(%rax)
   5cacb:      	je	0x5cb0b <f.14+0x22b>
   5cacd:      	movl	$0x4000, %esi           # imm = 0x4000
   5cad2:      	movq	%r15, %rdi
   5cad5:      	callq	0x2ac40 <native_i64_div_s>
   5cada:      	movq	%rax, %r15
   5cadd:      	shlq	$0xe, %r14
   5cae1:      	addq	%r13, %r14
   5cae4:      	movq	%r12, %rdi
   5cae7:      	callq	0x2ae00 <native_roots_leave>
   5caec:      	movl	$0x2, %esi
   5caf1:      	movq	%r12, %rdi
   5caf4:      	callq	0x2adb0 <native_roots_enter>
   5caf9:      	movq	%rbp, 0x28(%rsp)
   5cafe:      	cmpb	$0x0, 0x59d3(%rip)      # 0x624d8 <g.14>
   5cb05:      	jne	0x5ca50 <f.14+0x170>
   5cb0b:      	callq	0x26990 <native_trap>
   5cb10:      	movq	%r14, %rdi
   5cb13:      	movq	%rbx, %rsi
   5cb16:      	callq	0x2ac80 <native_i64_rem_s>
   5cb1b:      	movq	%rax, %rbx
   5cb1e:      	leaq	0x10(%rsp), %rdi
   5cb23:      	callq	0x2ae00 <native_roots_leave>
   5cb28:      	movq	%rbx, %rax
   5cb2b:      	addq	$0x68, %rsp
   5cb2f:      	popq	%rbx
   5cb30:      	popq	%r12
   5cb32:      	popq	%r13
   5cb34:      	popq	%r14
   5cb36:      	popq	%r15
   5cb38:      	popq	%rbp
   5cb39:      	retq	$0x8
   5cb3c:      	int3
   5cb3d:      	int3
   5cb3e:      	int3
   5cb3f:      	int3

000000000005cb40 <f.16>:
   5cb40:      	pushq	%r15
   5cb42:      	pushq	%r14
   5cb44:      	pushq	%rbx
   5cb45:      	subq	$0x30, %rsp
   5cb49:      	movq	%rsi, %rbx
   5cb4c:      	movq	%rdi, %r14
   5cb4f:      	movq	%rsp, %rdi
   5cb52:      	xorl	%esi, %esi
   5cb54:      	callq	0x2adb0 <native_roots_enter>
   5cb59:      	movq	%r14, 0x18(%rsp)
   5cb5e:      	movq	$0x0, 0x20(%rsp)
   5cb67:      	movq	$0x0, 0x28(%rsp)
   5cb70:      	movl	$0x3e, %esi
   5cb75:      	movq	%r14, %rdi
   5cb78:      	xorl	%edx, %edx
   5cb7a:      	xorl	%ecx, %ecx
   5cb7c:      	callq	0x2acc0 <native_ref_test>
   5cb81:      	testl	%eax, %eax
   5cb83:      	je	0x5cca8 <f.16+0x168>
   5cb89:      	testq	%r14, %r14
   5cb8c:      	je	0x5cca8 <f.16+0x168>
   5cb92:      	movq	0x10(%r14), %rax
   5cb96:      	testq	%rax, %rax
   5cb99:      	je	0x5cca8 <f.16+0x168>
   5cb9f:      	cmpl	$0x0, 0x8(%rax)
   5cba3:      	je	0x5cca8 <f.16+0x168>
   5cba9:      	movq	0x18(%rsp), %r14
   5cbae:      	movl	$0x3e, %esi
   5cbb3:      	movq	%r14, %rdi
   5cbb6:      	xorl	%edx, %edx
   5cbb8:      	xorl	%ecx, %ecx
   5cbba:      	callq	0x2acc0 <native_ref_test>
   5cbbf:      	testl	%eax, %eax
   5cbc1:      	je	0x5cca8 <f.16+0x168>
   5cbc7:      	movq	%r14, 0x20(%rsp)
   5cbcc:      	testq	%r14, %r14
   5cbcf:      	je	0x5cca8 <f.16+0x168>
   5cbd5:      	movq	0x10(%r14), %rcx
   5cbd9:      	testq	%rcx, %rcx
   5cbdc:      	je	0x5cca8 <f.16+0x168>
   5cbe2:      	movq	0x10(%rcx), %r15
   5cbe6:      	testq	%r15, %r15
   5cbe9:      	je	0x5cca8 <f.16+0x168>
   5cbef:      	movq	0x8(%r14), %rax
   5cbf3:      	testq	%rax, %rax
   5cbf6:      	je	0x5cca8 <f.16+0x168>
   5cbfc:      	cmpl	$0x0, 0x8(%rax)
   5cc00:      	je	0x5cca8 <f.16+0x168>
   5cc06:      	cmpl	$0x0, 0x8(%rcx)
   5cc0a:      	je	0x5cca8 <f.16+0x168>
   5cc10:      	movq	0x18(%r14), %rcx
   5cc14:      	testq	%rcx, %rcx
   5cc17:      	je	0x5cca8 <f.16+0x168>
   5cc1d:      	cmpl	$0x0, 0x8(%rcx)
   5cc21:      	je	0x5cca8 <f.16+0x168>
   5cc27:      	movq	0x20(%r14), %rdx
   5cc2b:      	testq	%rdx, %rdx
   5cc2e:      	je	0x5cca8 <f.16+0x168>
   5cc30:      	cmpl	$0x0, 0x8(%rdx)
   5cc34:      	je	0x5cca8 <f.16+0x168>
   5cc36:      	movq	0x8(%r15), %rdi
   5cc3a:      	imulq	0x10(%rax), %rdi
   5cc3f:      	addq	0x10(%rcx), %rdi
   5cc43:      	movq	0x10(%rdx), %rsi
   5cc47:      	incq	%rsi
   5cc4a:      	callq	0x2ac80 <native_i64_rem_s>
   5cc4f:      	movq	%rax, 0x8(%r15)
   5cc53:      	movq	0x20(%rsp), %rax
   5cc58:      	testq	%rax, %rax
   5cc5b:      	je	0x5cca8 <f.16+0x168>
   5cc5d:      	movq	0x10(%rax), %rax
   5cc61:      	testq	%rax, %rax
   5cc64:      	je	0x5cca8 <f.16+0x168>
   5cc66:      	cmpl	$0x0, 0x8(%rax)
   5cc6a:      	je	0x5cca8 <f.16+0x168>
   5cc6c:      	movq	0x10(%rax), %rax
   5cc70:      	testq	%rax, %rax
   5cc73:      	je	0x5cca8 <f.16+0x168>
   5cc75:      	movq	0x8(%rax), %rdi
   5cc79:      	movl	$0x8, %esi
   5cc7e:      	callq	0x2ac40 <native_i64_div_s>
   5cc83:      	movq	%rax, %rdi
   5cc86:      	movq	%rbx, %rsi
   5cc89:      	callq	0x2ac80 <native_i64_rem_s>
   5cc8e:      	movq	%rax, %rbx
   5cc91:      	movq	%rsp, %rdi
   5cc94:      	callq	0x2ae00 <native_roots_leave>
   5cc99:      	movq	%rbx, %rax
   5cc9c:      	addq	$0x30, %rsp
   5cca0:      	popq	%rbx
   5cca1:      	popq	%r14
   5cca3:      	popq	%r15
   5cca5:      	retq	$0x8
   5cca8:      	callq	0x26990 <native_trap>
   5ccad:      	int3
   5ccae:      	int3
   5ccaf:      	int3

000000000005ccb0 <f.17>:
   5ccb0:      	pushq	%rbp
   5ccb1:      	pushq	%r15
   5ccb3:      	pushq	%r14
   5ccb5:      	pushq	%r13
   5ccb7:      	pushq	%r12
   5ccb9:      	pushq	%rbx
   5ccba:      	subq	$0x68, %rsp
   5ccbe:      	movq	%rsi, %rbx
   5ccc1:      	movq	%rdi, %r12
   5ccc4:      	leaq	0x10(%rsp), %rdi
   5ccc9:      	movl	$0x5, %esi
   5ccce:      	callq	0x2adb0 <native_roots_enter>
   5ccd3:      	movq	%r12, 0x28(%rsp)
   5ccd8:      	movq	$0x0, 0x30(%rsp)
   5cce1:      	movq	$0x0, 0x38(%rsp)
   5ccea:      	movl	$0xa, %esi
   5ccef:      	movq	%r12, %rdi
   5ccf2:      	xorl	%edx, %edx
   5ccf4:      	xorl	%ecx, %ecx
   5ccf6:      	callq	0x2acc0 <native_ref_test>
   5ccfb:      	testl	%eax, %eax
   5ccfd:      	je	0x5ce60 <f.17+0x1b0>
   5cd03:      	leaq	0x30(%rsp), %r13
   5cd08:      	leaq	0x50(%rsp), %r14
   5cd0d:      	leaq	0x10(%rsp), %r15
   5cd12:      	nopw	%cs:(%rax,%rax)
   5cd1c:      	nopl	(%rax)
   5cd20:      	testq	%r12, %r12
   5cd23:      	je	0x5ce60 <f.17+0x1b0>
   5cd29:      	movq	0x8(%r12), %rax
   5cd2e:      	testq	%rax, %rax
   5cd31:      	je	0x5ce60 <f.17+0x1b0>
   5cd37:      	movl	0x8(%rax), %eax
   5cd3a:      	cmpq	%rax, %rbx
   5cd3d:      	je	0x5ce65 <f.17+0x1b5>
   5cd43:      	movq	0x28(%rsp), %r12
   5cd48:      	movl	$0xa, %esi
   5cd4d:      	movq	%r12, %rdi
   5cd50:      	xorl	%edx, %edx
   5cd52:      	xorl	%ecx, %ecx
   5cd54:      	callq	0x2acc0 <native_ref_test>
   5cd59:      	testl	%eax, %eax
   5cd5b:      	je	0x5ce60 <f.17+0x1b0>
   5cd61:      	movq	%r12, 0x30(%rsp)
   5cd66:      	testq	%r12, %r12
   5cd69:      	je	0x5ce60 <f.17+0x1b0>
   5cd6f:      	movq	0x8(%r12), %rdi
   5cd74:      	movq	%rdi, 0x38(%rsp)
   5cd79:      	testq	%rdi, %rdi
   5cd7c:      	je	0x5ce60 <f.17+0x1b0>
   5cd82:      	movl	0x8(%rdi), %eax
   5cd85:      	cmpq	%rax, %rbx
   5cd88:      	jae	0x5ce60 <f.17+0x1b0>
   5cd8e:      	movq	0x18(%rdi), %r12
   5cd92:      	movq	%r12, 0x40(%rsp)
   5cd97:      	movq	%rdi, 0x48(%rsp)
   5cd9c:      	movq	$0x5, 0x20(%rsp)
   5cda5:      	movl	%ebx, %esi
   5cda7:      	callq	0x5a070 <f.4>
   5cdac:      	subq	$0x8, %rsp
   5cdb0:      	movq	%r12, 0x40(%rsp)
   5cdb5:      	movq	$0x4, 0x20(%rsp)
   5cdbe:      	movq	%r12, %rdi
   5cdc1:      	movl	%eax, %esi
   5cdc3:      	callq	0x59fc0 <f.3>
   5cdc8:      	subq	$0x8, %rsp
   5cdcc:      	movl	%eax, %ebp
   5cdce:      	movq	$0x3, 0x20(%rsp)
   5cdd7:      	movq	%r14, %rdi
   5cdda:      	xorl	%esi, %esi
   5cddc:      	callq	0x2adb0 <native_roots_enter>
   5cde1:      	movq	$0x0, 0x60(%rsp)
   5cdea:      	movl	%ebp, %edi
   5cdec:      	callq	0x14b70 <write_character>
   5cdf1:      	movq	%r14, %rdi
   5cdf4:      	callq	0x2ae00 <native_roots_leave>
   5cdf9:      	movq	0x30(%rsp), %r12
   5cdfe:      	testq	%r12, %r12
   5ce01:      	je	0x5ce60 <f.17+0x1b0>
   5ce03:      	movq	0x10(%r12), %rax
   5ce08:      	testq	%rax, %rax
   5ce0b:      	je	0x5ce60 <f.17+0x1b0>
   5ce0d:      	cmpl	$0x0, 0x8(%rax)
   5ce11:      	je	0x5ce60 <f.17+0x1b0>
   5ce13:      	cmpq	$0x0, 0x10(%rax)
   5ce18:      	je	0x5ce60 <f.17+0x1b0>
   5ce1a:      	incq	%rbx
   5ce1d:      	movq	%r15, %rdi
   5ce20:      	callq	0x2ae00 <native_roots_leave>
   5ce25:      	movl	$0x5, %esi
   5ce2a:      	movq	%r15, %rdi
   5ce2d:      	callq	0x2adb0 <native_roots_enter>
   5ce32:      	movq	%r12, 0x28(%rsp)
   5ce37:      	movq	$0x0, 0x8(%r13)
   5ce3f:      	movq	$0x0, (%r13)
   5ce47:      	movl	$0xa, %esi
   5ce4c:      	movq	%r12, %rdi
   5ce4f:      	xorl	%edx, %edx
   5ce51:      	xorl	%ecx, %ecx
   5ce53:      	callq	0x2acc0 <native_ref_test>
   5ce58:      	testl	%eax, %eax
   5ce5a:      	jne	0x5cd20 <f.17+0x70>
   5ce60:      	callq	0x26990 <native_trap>
   5ce65:      	leaq	0x10(%rsp), %rdi
   5ce6a:      	callq	0x2ae00 <native_roots_leave>
   5ce6f:      	xorl	%eax, %eax
   5ce71:      	addq	$0x68, %rsp
   5ce75:      	popq	%rbx
   5ce76:      	popq	%r12
   5ce78:      	popq	%r13
   5ce7a:      	popq	%r14
   5ce7c:      	popq	%r15
   5ce7e:      	popq	%rbp
   5ce7f:      	retq	$0x8
   5ce82:      	int3
   5ce83:      	int3
   5ce84:      	int3
   5ce85:      	int3
   5ce86:      	int3
   5ce87:      	int3
   5ce88:      	int3
   5ce89:      	int3
   5ce8a:      	int3
   5ce8b:      	int3
   5ce8c:      	int3
   5ce8d:      	int3
   5ce8e:      	int3
   5ce8f:      	int3

000000000005ce90 <f.18>:
   5ce90:      	pushq	%r14
   5ce92:      	pushq	%rbx
   5ce93:      	subq	$0x28, %rsp
   5ce97:      	movq	%rsi, %rbx
   5ce9a:      	movq	%rdi, %r14
   5ce9d:      	movq	%rsp, %rdi
   5cea0:      	movl	$0x2, %esi
   5cea5:      	callq	0x2adb0 <native_roots_enter>
   5ceaa:      	movq	%r14, 0x18(%rsp)
   5ceaf:      	movq	%rbx, %rax
   5ceb2:      	shrq	$0x20, %rax
   5ceb6:      	jne	0x5cf17 <f.18+0x87>
   5ceb8:      	movq	$0x1, 0x10(%rsp)
   5cec1:      	movl	$0xcb, %edi
   5cec6:      	movl	%ebx, %esi
   5cec8:      	xorl	%edx, %edx
   5ceca:      	movl	$0x1, %ecx
   5cecf:      	callq	0x2a970 <native_array_new>
   5ced4:      	movq	%rax, %rbx
   5ced7:      	movq	%rax, 0x20(%rsp)
   5cedc:      	movq	$0x2, 0x10(%rsp)
   5cee5:      	movl	$0x10, %edi
   5ceea:      	callq	0x28930 <native_alloc>
   5ceef:      	testq	%rax, %rax
   5cef2:      	je	0x5cf17 <f.18+0x87>
   5cef4:      	movq	$0x82, (%rax)
   5cefb:      	movq	%rbx, 0x8(%rax)
   5ceff:      	movq	%rsp, %rdi
   5cf02:      	movq	%rax, %rbx
   5cf05:      	callq	0x2ae00 <native_roots_leave>
   5cf0a:      	movq	%rbx, %rax
   5cf0d:      	addq	$0x28, %rsp
   5cf11:      	popq	%rbx
   5cf12:      	popq	%r14
   5cf14:      	retq	$0x8
   5cf17:      	callq	0x26990 <native_trap>
   5cf1c:      	int3
   5cf1d:      	int3
   5cf1e:      	int3
   5cf1f:      	int3
