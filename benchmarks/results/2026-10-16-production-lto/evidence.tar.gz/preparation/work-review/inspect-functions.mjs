import fs from 'node:fs';
const root = '/tmp/sfir-native-production-six-20261016/work-review';
const [name, ...wanted] = process.argv.slice(2);
const lines = fs.readFileSync(`${root}/${name}-candidate.asm`, 'utf8').split('\n');
let current;
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const head = line.match(/^([0-9a-f]+) <(.+)>:$/);
  if (head) current = head[2];
  if (!wanted.includes(current)) continue;
  const jump = line.match(/^\s*([0-9a-f]+):\s+j\w+\s+0x([0-9a-f]+)/);
  if (head || /callq.*<f\.|<ref\.|callq\s+\*|imulq|idivq|divsd|mov[bqlsd]+\s+.*0x10\([^)]*,/.test(line)
      || jump && parseInt(jump[2], 16) < parseInt(jump[1], 16)) {
    console.log(`${i + 1}: ${line}`);
  }
}
