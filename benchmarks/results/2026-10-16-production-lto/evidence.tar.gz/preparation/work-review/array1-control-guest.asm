0000000000059090 <f.2>:
   59090:      	pushq	%rbp
   59091:      	pushq	%r15
   59093:      	pushq	%r14
   59095:      	pushq	%r13
   59097:      	pushq	%r12
   59099:      	pushq	%rbx
   5909a:      	subq	$0x78, %rsp
   5909e:      	movq	%rdx, %r12
   590a1:      	movq	%rsi, %rbx
   590a4:      	movq	%rdi, %r13
   590a7:      	leaq	0x10(%rsp), %rdi
   590ac:      	movl	$0x7, %esi
   590b1:      	callq	0x2a020 <native_roots_enter>
   590b6:      	movq	%r13, 0x28(%rsp)
   590bb:      	movq	$0x0, 0x30(%rsp)
   590c4:      	movq	$0x0, 0x38(%rsp)
   590cd:      	movq	$0x0, 0x40(%rsp)
   590d6:      	movl	$0x22, %esi
   590db:      	movq	%r13, %rdi
   590de:      	xorl	%edx, %edx
   590e0:      	xorl	%ecx, %ecx
   590e2:      	callq	0x29f30 <native_ref_test>
   590e7:      	testl	%eax, %eax
   590e9:      	je	0x593f5 <f.2+0x365>
   590ef:      	decq	%rbx
   590f2:      	leaq	0x3f6f(%rip), %rbp      # 0x5d068 <ref.4>
   590f9:      	nopl	(%rax)
   59100:      	testq	%r13, %r13
   59103:      	je	0x593f5 <f.2+0x365>
   59109:      	incq	%rbx
   5910c:      	cmpq	%rbx, 0x8(%r13)
   59110:      	jle	0x593fa <f.2+0x36a>
   59116:      	cmpb	$0x0, 0x604b(%rip)      # 0x5f168 <g.12>
   5911d:      	je	0x593f5 <f.2+0x365>
   59123:      	cmpb	$0x0, 0x5fee(%rip)      # 0x5f118 <g.2>
   5912a:      	je	0x593f5 <f.2+0x365>
   59130:      	cmpq	$0x0, 0x5fd8(%rip)      # 0x5f110 <g.1>
   59138:      	je	0x593f5 <f.2+0x365>
   5913e:      	movq	0x601b(%rip), %r15      # 0x5f160 <g.11>
   59145:      	movq	$0x4, 0x20(%rsp)
   5914e:      	leaq	0x60(%rsp), %r14
   59153:      	movq	%r14, %rdi
   59156:      	xorl	%esi, %esi
   59158:      	callq	0x2a020 <native_roots_enter>
   5915d:      	movq	$0x0, 0x70(%rsp)
   59166:      	movq	%r15, %rdi
   59169:      	callq	0x13a10 <hide_i64>
   5916e:      	movq	%rax, %r12
   59171:      	movq	%r14, %rdi
   59174:      	callq	0x2a070 <native_roots_leave>
   59179:      	cmpb	$0x0, 0x5fe8(%rip)      # 0x5f168 <g.12>
   59180:      	je	0x593f5 <f.2+0x365>
   59186:      	cmpb	$0x0, 0x5feb(%rip)      # 0x5f178 <g.14>
   5918d:      	je	0x593f5 <f.2+0x365>
   59193:      	cmpb	$0x0, 0x5f7e(%rip)      # 0x5f118 <g.2>
   5919a:      	je	0x593f5 <f.2+0x365>
   591a0:      	cmpq	$0x0, 0x5f68(%rip)      # 0x5f110 <g.1>
   591a8:      	je	0x593f5 <f.2+0x365>
   591ae:      	movq	%rbp, %r14
   591b1:      	movq	0x5fb8(%rip), %r15      # 0x5f170 <g.13>
   591b8:      	movq	$0x4, 0x20(%rsp)
   591c1:      	leaq	0x60(%rsp), %r13
   591c6:      	movq	%r13, %rdi
   591c9:      	xorl	%esi, %esi
   591cb:      	callq	0x2a020 <native_roots_enter>
   591d0:      	movq	$0x0, 0x70(%rsp)
   591d9:      	movq	%r15, %rdi
   591dc:      	callq	0x13a10 <hide_i64>
   591e1:      	movq	%rax, %rbp
   591e4:      	movq	%r13, %rdi
   591e7:      	callq	0x2a070 <native_roots_leave>
   591ec:      	cmpb	$0x0, 0x5f65(%rip)      # 0x5f158 <g.10>
   591f3:      	je	0x593f5 <f.2+0x365>
   591f9:      	cmpq	$0x0, 0x5f4f(%rip)      # 0x5f150 <g.9>
   59201:      	je	0x593f5 <f.2+0x365>
   59207:      	movq	$0x4, 0x20(%rsp)
   59210:      	movl	$0x18, %edi
   59215:      	callq	0x27c90 <native_alloc>
   5921a:      	testq	%rax, %rax
   5921d:      	je	0x593f5 <f.2+0x365>
   59223:      	movq	%rax, %r13
   59226:      	movq	$0x26, (%rax)
   5922d:      	movl	$0x0, 0x8(%rax)
   59234:      	movq	$0x0, 0x10(%rax)
   5923c:      	movq	%rax, 0x30(%rsp)
   59241:      	movq	%rax, 0x48(%rsp)
   59246:      	movq	%r14, 0x50(%rsp)
   5924b:      	movq	%rax, 0x58(%rsp)
   59250:      	movq	$0x7, 0x20(%rsp)
   59259:      	movl	$0x18, %edi
   5925e:      	callq	0x27c90 <native_alloc>
   59263:      	testq	%rax, %rax
   59266:      	je	0x593f5 <f.2+0x365>
   5926c:      	movq	%rax, %r15
   5926f:      	movq	$0x1e, (%rax)
   59276:      	movq	%rbp, 0x8(%rax)
   5927a:      	movq	%r13, 0x10(%rax)
   5927e:      	movq	%rax, 0x48(%rsp)
   59283:      	movq	%r14, 0x50(%rsp)
   59288:      	movq	%r13, 0x58(%rsp)
   5928d:      	movq	$0x7, 0x20(%rsp)
   59296:      	movl	$0x18, %edi
   5929b:      	callq	0x27c90 <native_alloc>
   592a0:      	testq	%rax, %rax
   592a3:      	je	0x593f5 <f.2+0x365>
   592a9:      	movq	%r14, %rbp
   592ac:      	movq	$0x3a, (%rax)
   592b3:      	movq	%r14, 0x8(%rax)
   592b7:      	movq	%r15, 0x10(%rax)
   592bb:      	movq	%rax, 0x10(%r13)
   592bf:      	movq	0x30(%rsp), %rax
   592c4:      	testq	%rax, %rax
   592c7:      	je	0x593f5 <f.2+0x365>
   592cd:      	movl	$0x1, 0x8(%rax)
   592d4:      	movq	0x30(%rsp), %rax
   592d9:      	testq	%rax, %rax
   592dc:      	je	0x593f5 <f.2+0x365>
   592e2:      	cmpl	$0x0, 0x8(%rax)
   592e6:      	je	0x593f5 <f.2+0x365>
   592ec:      	movq	0x10(%rax), %rax
   592f0:      	testq	%rax, %rax
   592f3:      	je	0x593f5 <f.2+0x365>
   592f9:      	movq	%rax, 0x38(%rsp)
   592fe:      	movq	0x8(%rax), %rcx
   59302:      	testq	%rcx, %rcx
   59305:      	je	0x593f5 <f.2+0x365>
   5930b:      	movq	0x10(%rax), %rdi
   5930f:      	movq	0x8(%rcx), %rax
   59313:      	movq	%rdi, 0x48(%rsp)
   59318:      	movq	$0x5, 0x20(%rsp)
   59321:      	movq	%r12, %rsi
   59324:      	xorl	%edx, %edx
   59326:      	callq	*%rax
   59328:      	subq	$0x8, %rsp
   5932c:      	movq	%rax, %r12
   5932f:      	movq	0x28(%rsp), %r15
   59334:      	movl	$0x22, %esi
   59339:      	movq	%r15, %rdi
   5933c:      	xorl	%edx, %edx
   5933e:      	xorl	%ecx, %ecx
   59340:      	callq	0x29f30 <native_ref_test>
   59345:      	testl	%eax, %eax
   59347:      	je	0x593f5 <f.2+0x365>
   5934d:      	testq	%r15, %r15
   59350:      	je	0x593f5 <f.2+0x365>
   59356:      	movq	0x10(%r15), %rax
   5935a:      	testq	%rax, %rax
   5935d:      	je	0x593f5 <f.2+0x365>
   59363:      	cmpl	$0x0, 0x8(%rax)
   59367:      	je	0x593f5 <f.2+0x365>
   5936d:      	movq	0x28(%rsp), %r13
   59372:      	movl	$0x22, %esi
   59377:      	movq	%r13, %rdi
   5937a:      	xorl	%edx, %edx
   5937c:      	xorl	%ecx, %ecx
   5937e:      	callq	0x29f30 <native_ref_test>
   59383:      	testl	%eax, %eax
   59385:      	je	0x593f5 <f.2+0x365>
   59387:      	movq	%r13, 0x40(%rsp)
   5938c:      	testq	%r13, %r13
   5938f:      	je	0x593f5 <f.2+0x365>
   59391:      	movq	0x10(%r13), %rax
   59395:      	testq	%rax, %rax
   59398:      	je	0x593f5 <f.2+0x365>
   5939a:      	cmpq	$0x0, 0x10(%rax)
   5939f:      	je	0x593f5 <f.2+0x365>
   593a1:      	leaq	0x10(%rsp), %r14
   593a6:      	movq	%r14, %rdi
   593a9:      	callq	0x2a070 <native_roots_leave>
   593ae:      	movl	$0x7, %esi
   593b3:      	movq	%r14, %rdi
   593b6:      	callq	0x2a020 <native_roots_enter>
   593bb:      	movq	%r13, 0x28(%rsp)
   593c0:      	leaq	0x30(%rsp), %rax
   593c5:      	movq	$0x0, 0x10(%rax)
   593cd:      	movq	$0x0, 0x8(%rax)
   593d5:      	movq	$0x0, (%rax)
   593dc:      	movl	$0x22, %esi
   593e1:      	movq	%r13, %rdi
   593e4:      	xorl	%edx, %edx
   593e6:      	xorl	%ecx, %ecx
   593e8:      	callq	0x29f30 <native_ref_test>
   593ed:      	testl	%eax, %eax
   593ef:      	jne	0x59100 <f.2+0x70>
   593f5:      	callq	0x25cf0 <native_trap>
   593fa:      	leaq	0x10(%rsp), %rdi
   593ff:      	callq	0x2a070 <native_roots_leave>
   59404:      	movq	%r12, %rax
   59407:      	addq	$0x78, %rsp
   5940b:      	popq	%rbx
   5940c:      	popq	%r12
   5940e:      	popq	%r13
   59410:      	popq	%r14
   59412:      	popq	%r15
   59414:      	popq	%rbp
   59415:      	retq	$0x8
   59418:      	int3
   59419:      	int3
   5941a:      	int3
   5941b:      	int3
   5941c:      	int3
   5941d:      	int3
   5941e:      	int3
   5941f:      	int3

0000000000059420 <f.3>:
   59420:      	pushq	%r15
   59422:      	pushq	%r14
   59424:      	pushq	%r13
   59426:      	pushq	%r12
   59428:      	pushq	%rbx
   59429:      	subq	$0x50, %rsp
   5942d:      	movq	%rdx, %r15
   59430:      	movq	%rsi, %rbx
   59433:      	movq	%rdi, %r14
   59436:      	leaq	0x8(%rsp), %rdi
   5943b:      	movl	$0x6, %esi
   59440:      	callq	0x2a020 <native_roots_enter>
   59445:      	movq	%r14, 0x20(%rsp)
   5944a:      	movq	$0x0, 0x28(%rsp)
   59453:      	movq	$0x0, 0x30(%rsp)
   5945c:      	movq	$0x3, 0x18(%rsp)
   59465:      	movl	$0x18, %edi
   5946a:      	callq	0x27c90 <native_alloc>
   5946f:      	testq	%rax, %rax
   59472:      	je	0x59578 <f.3+0x158>
   59478:      	movq	%rax, %r14
   5947b:      	movq	$0x26, (%rax)
   59482:      	movl	$0x0, 0x8(%rax)
   59489:      	movq	$0x0, 0x10(%rax)
   59491:      	movq	%rax, 0x28(%rsp)
   59496:      	movq	%rax, 0x38(%rsp)
   5949b:      	leaq	0x3bc6(%rip), %r13      # 0x5d068 <ref.4>
   594a2:      	movq	%r13, 0x40(%rsp)
   594a7:      	movq	%rax, 0x48(%rsp)
   594ac:      	movq	$0x6, 0x18(%rsp)
   594b5:      	movl	$0x18, %edi
   594ba:      	callq	0x27c90 <native_alloc>
   594bf:      	testq	%rax, %rax
   594c2:      	je	0x59578 <f.3+0x158>
   594c8:      	movq	%rax, %r12
   594cb:      	movq	$0x1e, (%rax)
   594d2:      	movq	%r15, 0x8(%rax)
   594d6:      	movq	%r14, 0x10(%rax)
   594da:      	movq	%rax, 0x38(%rsp)
   594df:      	movq	%r13, 0x40(%rsp)
   594e4:      	movq	%r14, 0x48(%rsp)
   594e9:      	movq	$0x6, 0x18(%rsp)
   594f2:      	movl	$0x18, %edi
   594f7:      	callq	0x27c90 <native_alloc>
   594fc:      	testq	%rax, %rax
   594ff:      	je	0x59578 <f.3+0x158>
   59501:      	movq	$0x3a, (%rax)
   59508:      	movq	%r13, 0x8(%rax)
   5950c:      	movq	%r12, 0x10(%rax)
   59510:      	movq	%rax, 0x10(%r14)
   59514:      	movq	0x28(%rsp), %rax
   59519:      	testq	%rax, %rax
   5951c:      	je	0x59578 <f.3+0x158>
   5951e:      	movl	$0x1, 0x8(%rax)
   59525:      	movq	0x28(%rsp), %rax
   5952a:      	testq	%rax, %rax
   5952d:      	je	0x59578 <f.3+0x158>
   5952f:      	cmpl	$0x0, 0x8(%rax)
   59533:      	je	0x59578 <f.3+0x158>
   59535:      	movq	0x10(%rax), %rax
   59539:      	testq	%rax, %rax
   5953c:      	je	0x59578 <f.3+0x158>
   5953e:      	movq	%rax, 0x30(%rsp)
   59543:      	movq	0x8(%rax), %rcx
   59547:      	testq	%rcx, %rcx
   5954a:      	je	0x59578 <f.3+0x158>
   5954c:      	movq	0x10(%rax), %r14
   59550:      	movq	0x8(%rcx), %r15
   59554:      	leaq	0x8(%rsp), %rdi
   59559:      	callq	0x2a070 <native_roots_leave>
   5955e:      	movq	%r14, %rdi
   59561:      	movq	%rbx, %rsi
   59564:      	xorl	%edx, %edx
   59566:      	movq	%r15, %rax
   59569:      	addq	$0x50, %rsp
   5956d:      	popq	%rbx
   5956e:      	popq	%r12
   59570:      	popq	%r13
   59572:      	popq	%r14
   59574:      	popq	%r15
   59576:      	jmpq	*%rax
   59578:      	callq	0x25cf0 <native_trap>
   5957d:      	int3
   5957e:      	int3
   5957f:      	int3

0000000000059580 <f.4>:
   59580:      	pushq	%rbp
   59581:      	pushq	%r15
   59583:      	pushq	%r14
   59585:      	pushq	%r13
   59587:      	pushq	%r12
   59589:      	pushq	%rbx
   5958a:      	subq	$0x88, %rsp
   59591:      	movq	%rdx, %r12
   59594:      	movq	%rsi, %r13
   59597:      	movq	%rdi, %r15
   5959a:      	leaq	0x10(%rsp), %rdi
   5959f:      	movl	$0xa, %esi
   595a4:      	callq	0x2a020 <native_roots_enter>
   595a9:      	movq	%r15, 0x28(%rsp)
   595ae:      	testq	%r13, %r13
   595b1:      	movq	$0x0, 0x30(%rsp)
   595ba:      	movq	$0x0, 0x38(%rsp)
   595c3:      	movq	$0x0, 0x40(%rsp)
   595cc:      	movq	$0x0, 0x48(%rsp)
   595d5:      	jle	0x59a8e <f.4+0x50e>
   595db:      	incq	%r13
   595de:      	leaq	0x3ac3(%rip), %rbx      # 0x5d0a8 <ref.8>
   595e5:      	nopw	%cs:(%rax,%rax)
   595ef:      	nop
   595f0:      	movl	$0x1e, %esi
   595f5:      	movq	%r15, %rdi
   595f8:      	xorl	%edx, %edx
   595fa:      	xorl	%ecx, %ecx
   595fc:      	callq	0x29f30 <native_ref_test>
   59601:      	testl	%eax, %eax
   59603:      	je	0x59aaf <f.4+0x52f>
   59609:      	testq	%r15, %r15
   5960c:      	je	0x59aaf <f.4+0x52f>
   59612:      	cmpb	$0x0, 0x5b2f(%rip)      # 0x5f148 <g.8>
   59619:      	je	0x59aaf <f.4+0x52f>
   5961f:      	cmpq	$0x0, 0x5b19(%rip)      # 0x5f140 <g.7>
   59627:      	je	0x59aaf <f.4+0x52f>
   5962d:      	cmpb	$0x0, 0x5af4(%rip)      # 0x5f128 <g.4>
   59634:      	je	0x59aaf <f.4+0x52f>
   5963a:      	cmpq	$0x0, 0x5ade(%rip)      # 0x5f120 <g.3>
   59642:      	je	0x59aaf <f.4+0x52f>
   59648:      	movq	0x8(%r15), %r12
   5964c:      	movq	%r12, %rax
   5964f:      	shrq	$0x20, %rax
   59653:      	jne	0x59aaf <f.4+0x52f>
   59659:      	movq	%r13, 0x80(%rsp)
   59661:      	movq	$0x5, 0x20(%rsp)
   5966a:      	movl	$0x18, %edi
   5966f:      	callq	0x27c90 <native_alloc>
   59674:      	testq	%rax, %rax
   59677:      	je	0x59aaf <f.4+0x52f>
   5967d:      	movq	%rax, %r15
   59680:      	movq	$0x1a, (%rax)
   59687:      	movl	$0x0, 0x8(%rax)
   5968e:      	movq	$0x0, 0x10(%rax)
   59696:      	movq	%rax, 0x30(%rsp)
   5969b:      	movq	%rbx, 0x50(%rsp)
   596a0:      	movq	%rax, 0x58(%rsp)
   596a5:      	movq	$0x7, 0x20(%rsp)
   596ae:      	movl	$0x17, %edi
   596b3:      	movl	%r12d, %esi
   596b6:      	xorl	%edx, %edx
   596b8:      	movl	$0x8, %ecx
   596bd:      	callq	0x29c60 <native_array_new>
   596c2:      	movq	%rax, %rbp
   596c5:      	movq	%rax, 0x50(%rsp)
   596ca:      	movq	%rbx, 0x58(%rsp)
   596cf:      	movq	%r15, 0x60(%rsp)
   596d4:      	movq	$0x8, 0x20(%rsp)
   596dd:      	movl	$0x10, %edi
   596e2:      	callq	0x27c90 <native_alloc>
   596e7:      	testq	%rax, %rax
   596ea:      	je	0x59aaf <f.4+0x52f>
   596f0:      	movq	%rbx, %r14
   596f3:      	movq	%rax, %r13
   596f6:      	movq	$0x12, (%rax)
   596fd:      	movq	%rbp, 0x8(%rax)
   59701:      	movq	0x30(%rsp), %rbx
   59706:      	movq	%rbx, 0x50(%rsp)
   5970b:      	movq	%rax, 0x58(%rsp)
   59710:      	movq	%r14, 0x60(%rsp)
   59715:      	movq	%r15, 0x68(%rsp)
   5971a:      	movq	$0x9, 0x20(%rsp)
   59723:      	movl	$0x20, %edi
   59728:      	callq	0x27c90 <native_alloc>
   5972d:      	testq	%rax, %rax
   59730:      	je	0x59aaf <f.4+0x52f>
   59736:      	movq	%rax, %rbp
   59739:      	movq	$0xe, (%rax)
   59740:      	movq	%r12, 0x8(%rax)
   59744:      	movq	%r13, 0x10(%rax)
   59748:      	movq	%rbx, 0x18(%rax)
   5974c:      	movq	%rax, 0x50(%rsp)
   59751:      	movq	%r14, 0x58(%rsp)
   59756:      	movq	%r15, 0x60(%rsp)
   5975b:      	movq	$0x8, 0x20(%rsp)
   59764:      	movl	$0x18, %edi
   59769:      	callq	0x27c90 <native_alloc>
   5976e:      	testq	%rax, %rax
   59771:      	je	0x59aaf <f.4+0x52f>
   59777:      	movq	$0x36, (%rax)
   5977e:      	movq	%r14, 0x8(%rax)
   59782:      	movq	%rbp, 0x10(%rax)
   59786:      	movq	%rax, 0x10(%r15)
   5978a:      	movq	0x30(%rsp), %rax
   5978f:      	testq	%rax, %rax
   59792:      	je	0x59aaf <f.4+0x52f>
   59798:      	movl	$0x1, 0x8(%rax)
   5979f:      	movq	0x30(%rsp), %rax
   597a4:      	testq	%rax, %rax
   597a7:      	je	0x59aaf <f.4+0x52f>
   597ad:      	cmpl	$0x0, 0x8(%rax)
   597b1:      	je	0x59aaf <f.4+0x52f>
   597b7:      	movq	0x10(%rax), %rax
   597bb:      	testq	%rax, %rax
   597be:      	je	0x59aaf <f.4+0x52f>
   597c4:      	movq	%rax, 0x38(%rsp)
   597c9:      	movq	0x8(%rax), %rcx
   597cd:      	testq	%rcx, %rcx
   597d0:      	je	0x59aaf <f.4+0x52f>
   597d6:      	movq	0x10(%rax), %rdi
   597da:      	movq	0x8(%rcx), %rax
   597de:      	movq	%rdi, 0x50(%rsp)
   597e3:      	movq	$0x6, 0x20(%rsp)
   597ec:      	xorl	%esi, %esi
   597ee:      	callq	*%rax
   597f0:      	subq	$0x8, %rsp
   597f4:      	movq	%rax, 0x40(%rsp)
   597f9:      	cmpb	$0x0, 0x5938(%rip)      # 0x5f138 <g.6>
   59800:      	je	0x59aaf <f.4+0x52f>
   59806:      	cmpq	$0x0, 0x5922(%rip)      # 0x5f130 <g.5>
   5980e:      	je	0x59aaf <f.4+0x52f>
   59814:      	testq	%rax, %rax
   59817:      	je	0x59aaf <f.4+0x52f>
   5981d:      	testb	$0x1, %al
   5981f:      	jne	0x59aaf <f.4+0x52f>
   59825:      	movl	0x8(%rax), %ebx
   59828:      	movq	$0x5, 0x20(%rsp)
   59831:      	movl	$0x18, %edi
   59836:      	callq	0x27c90 <native_alloc>
   5983b:      	testq	%rax, %rax
   5983e:      	je	0x59aaf <f.4+0x52f>
   59844:      	movq	%rax, %r12
   59847:      	movq	$0x1a, (%rax)
   5984e:      	movl	$0x0, 0x8(%rax)
   59855:      	movq	$0x0, 0x10(%rax)
   5985d:      	movq	%rax, 0x30(%rsp)
   59862:      	movq	0x40(%rsp), %r14
   59867:      	movq	%r14, 0x50(%rsp)
   5986c:      	leaq	0x3815(%rip), %r15      # 0x5d088 <ref.6>
   59873:      	movq	%r15, 0x58(%rsp)
   59878:      	movq	%rax, 0x60(%rsp)
   5987d:      	movq	$0x8, 0x20(%rsp)
   59886:      	movl	$0x17, %edi
   5988b:      	movq	%rbx, 0x78(%rsp)
   59890:      	movl	%ebx, %esi
   59892:      	xorl	%edx, %edx
   59894:      	movl	$0x8, %ecx
   59899:      	callq	0x29c60 <native_array_new>
   5989e:      	movq	%rax, %rbp
   598a1:      	movq	0x30(%rsp), %rbx
   598a6:      	movq	%rbx, 0x50(%rsp)
   598ab:      	movq	%rax, 0x58(%rsp)
   598b0:      	movq	%r14, 0x60(%rsp)
   598b5:      	movq	%r15, 0x68(%rsp)
   598ba:      	movq	%r12, 0x70(%rsp)
   598bf:      	movq	$0xa, 0x20(%rsp)
   598c8:      	movl	$0x20, %edi
   598cd:      	callq	0x27c90 <native_alloc>
   598d2:      	testq	%rax, %rax
   598d5:      	je	0x59aaf <f.4+0x52f>
   598db:      	movq	%rax, %r13
   598de:      	movq	$0x6, (%rax)
   598e5:      	movq	%r14, 0x8(%rax)
   598e9:      	movq	%rbp, 0x10(%rax)
   598ed:      	movq	%rbx, 0x18(%rax)
   598f1:      	movq	%rax, 0x50(%rsp)
   598f6:      	movq	%r15, 0x58(%rsp)
   598fb:      	movq	%r12, 0x60(%rsp)
   59900:      	movq	$0x8, 0x20(%rsp)
   59909:      	movl	$0x18, %edi
   5990e:      	callq	0x27c90 <native_alloc>
   59913:      	testq	%rax, %rax
   59916:      	je	0x59aaf <f.4+0x52f>
   5991c:      	movq	$0x36, (%rax)
   59923:      	movq	%r15, 0x8(%rax)
   59927:      	movq	%r13, 0x10(%rax)
   5992b:      	movq	%rax, 0x10(%r12)
   59930:      	movq	0x30(%rsp), %rax
   59935:      	testq	%rax, %rax
   59938:      	movq	0x80(%rsp), %r13
   59940:      	je	0x59aaf <f.4+0x52f>
   59946:      	movl	$0x1, 0x8(%rax)
   5994d:      	movq	0x30(%rsp), %rax
   59952:      	testq	%rax, %rax
   59955:      	leaq	0x374c(%rip), %rbx      # 0x5d0a8 <ref.8>
   5995c:      	je	0x59aaf <f.4+0x52f>
   59962:      	cmpl	$0x0, 0x8(%rax)
   59966:      	je	0x59aaf <f.4+0x52f>
   5996c:      	movq	0x10(%rax), %rax
   59970:      	testq	%rax, %rax
   59973:      	je	0x59aaf <f.4+0x52f>
   59979:      	movq	%rax, 0x38(%rsp)
   5997e:      	movq	0x8(%rax), %rcx
   59982:      	testq	%rcx, %rcx
   59985:      	je	0x59aaf <f.4+0x52f>
   5998b:      	movq	0x78(%rsp), %rsi
   59990:      	decq	%rsi
   59993:      	movq	0x10(%rax), %rdi
   59997:      	movq	0x8(%rcx), %rax
   5999b:      	movq	%rdi, 0x50(%rsp)
   599a0:      	movq	$0x6, 0x20(%rsp)
   599a9:      	callq	*%rax
   599ab:      	subq	$0x8, %rsp
   599af:      	testq	%rax, %rax
   599b2:      	je	0x59aaf <f.4+0x52f>
   599b8:      	testb	$0x1, %al
   599ba:      	jne	0x59aaf <f.4+0x52f>
   599c0:      	movl	0x8(%rax), %r12d
   599c4:      	movq	0x28(%rsp), %r15
   599c9:      	movl	$0x1e, %esi
   599ce:      	movq	%r15, %rdi
   599d1:      	xorl	%edx, %edx
   599d3:      	xorl	%ecx, %ecx
   599d5:      	callq	0x29f30 <native_ref_test>
   599da:      	testl	%eax, %eax
   599dc:      	je	0x59aaf <f.4+0x52f>
   599e2:      	testq	%r15, %r15
   599e5:      	je	0x59aaf <f.4+0x52f>
   599eb:      	movq	0x10(%r15), %rax
   599ef:      	testq	%rax, %rax
   599f2:      	je	0x59aaf <f.4+0x52f>
   599f8:      	cmpl	$0x0, 0x8(%rax)
   599fc:      	je	0x59aaf <f.4+0x52f>
   59a02:      	movq	0x28(%rsp), %r15
   59a07:      	movl	$0x1e, %esi
   59a0c:      	movq	%r15, %rdi
   59a0f:      	xorl	%edx, %edx
   59a11:      	xorl	%ecx, %ecx
   59a13:      	callq	0x29f30 <native_ref_test>
   59a18:      	testl	%eax, %eax
   59a1a:      	je	0x59aaf <f.4+0x52f>
   59a20:      	movq	%r15, 0x48(%rsp)
   59a25:      	testq	%r15, %r15
   59a28:      	je	0x59aaf <f.4+0x52f>
   59a2e:      	movq	0x10(%r15), %rax
   59a32:      	testq	%rax, %rax
   59a35:      	je	0x59aaf <f.4+0x52f>
   59a37:      	cmpq	$0x0, 0x10(%rax)
   59a3c:      	je	0x59aaf <f.4+0x52f>
   59a3e:      	leaq	0x10(%rsp), %r14
   59a43:      	movq	%r14, %rdi
   59a46:      	callq	0x2a070 <native_roots_leave>
   59a4b:      	movl	$0xa, %esi
   59a50:      	movq	%r14, %rdi
   59a53:      	callq	0x2a020 <native_roots_enter>
   59a58:      	movq	%r15, 0x28(%rsp)
   59a5d:      	leaq	0x30(%rsp), %rax
   59a62:      	movq	$0x0, 0x18(%rax)
   59a6a:      	movq	$0x0, 0x10(%rax)
   59a72:      	movq	$0x0, 0x8(%rax)
   59a7a:      	movq	$0x0, (%rax)
   59a81:      	decq	%r13
   59a84:      	cmpq	$0x1, %r13
   59a88:      	jg	0x595f0 <f.4+0x70>
   59a8e:      	leaq	0x10(%rsp), %rdi
   59a93:      	callq	0x2a070 <native_roots_leave>
   59a98:      	movq	%r12, %rax
   59a9b:      	addq	$0x88, %rsp
   59aa2:      	popq	%rbx
   59aa3:      	popq	%r12
   59aa5:      	popq	%r13
   59aa7:      	popq	%r14
   59aa9:      	popq	%r15
   59aab:      	popq	%rbp
   59aac:      	retq	$0x8
   59aaf:      	callq	0x25cf0 <native_trap>
   59ab4:      	int3
   59ab5:      	int3
   59ab6:      	int3
   59ab7:      	int3
   59ab8:      	int3
   59ab9:      	int3
   59aba:      	int3
   59abb:      	int3
   59abc:      	int3
   59abd:      	int3
   59abe:      	int3
   59abf:      	int3

0000000000059ac0 <f.5>:
   59ac0:      	pushq	%r15
   59ac2:      	pushq	%r14
   59ac4:      	pushq	%rbx
   59ac5:      	subq	$0x40, %rsp
   59ac9:      	movq	%rdx, %rbx
   59acc:      	movq	%rdi, %r14
   59acf:      	leaq	0x8(%rsp), %r15
   59ad4:      	movl	$0x1, %esi
   59ad9:      	movq	%r15, %rdi
   59adc:      	callq	0x2a020 <native_roots_enter>
   59ae1:      	movq	%r14, 0x20(%rsp)
   59ae6:      	movq	$0x1, 0x18(%rsp)
   59aef:      	leaq	0x28(%rsp), %r14
   59af4:      	movq	%r14, %rdi
   59af7:      	xorl	%esi, %esi
   59af9:      	callq	0x2a020 <native_roots_enter>
   59afe:      	movq	$0x0, 0x38(%rsp)
   59b07:      	movq	%rbx, %rdi
   59b0a:      	callq	0x13a10 <hide_i64>
   59b0f:      	movq	%rax, %rbx
   59b12:      	movq	%r14, %rdi
   59b15:      	callq	0x2a070 <native_roots_leave>
   59b1a:      	movq	%r15, %rdi
   59b1d:      	callq	0x2a070 <native_roots_leave>
   59b22:      	movq	%rbx, %rax
   59b25:      	addq	$0x40, %rsp
   59b29:      	popq	%rbx
   59b2a:      	popq	%r14
   59b2c:      	popq	%r15
   59b2e:      	retq	$0x8
   59b31:      	int3
   59b32:      	int3
   59b33:      	int3
   59b34:      	int3
   59b35:      	int3
   59b36:      	int3
   59b37:      	int3
   59b38:      	int3
   59b39:      	int3
   59b3a:      	int3
   59b3b:      	int3
   59b3c:      	int3
   59b3d:      	int3
   59b3e:      	int3
   59b3f:      	int3

0000000000059b40 <f.6>:
   59b40:      	pushq	%r15
   59b42:      	pushq	%r14
   59b44:      	pushq	%r13
   59b46:      	pushq	%r12
   59b48:      	pushq	%rbx
   59b49:      	subq	$0x30, %rsp
   59b4d:      	movq	%rsi, %r14
   59b50:      	movq	%rdi, %rbx
   59b53:      	movq	%rsp, %rdi
   59b56:      	xorl	%esi, %esi
   59b58:      	callq	0x2a020 <native_roots_enter>
   59b5d:      	movq	%rbx, 0x18(%rsp)
   59b62:      	testq	%r14, %r14
   59b65:      	movq	$0x0, 0x20(%rsp)
   59b6e:      	movq	$0x0, 0x28(%rsp)
   59b77:      	js	0x59c5f <f.6+0x11f>
   59b7d:      	leaq	0x20(%rsp), %r12
   59b82:      	movq	%r14, %r13
   59b85:      	shrq	$0x20, %r13
   59b89:      	movq	%rsp, %r15
   59b8c:      	nopl	(%rax)
   59b90:      	movl	$0x6, %esi
   59b95:      	movq	%rbx, %rdi
   59b98:      	xorl	%edx, %edx
   59b9a:      	xorl	%ecx, %ecx
   59b9c:      	callq	0x29f30 <native_ref_test>
   59ba1:      	testl	%eax, %eax
   59ba3:      	je	0x59c98 <f.6+0x158>
   59ba9:      	movq	%rbx, 0x20(%rsp)
   59bae:      	testq	%rbx, %rbx
   59bb1:      	je	0x59c98 <f.6+0x158>
   59bb7:      	testq	%r13, %r13
   59bba:      	jne	0x59c98 <f.6+0x158>
   59bc0:      	movq	0x8(%rbx), %rax
   59bc4:      	testq	%rax, %rax
   59bc7:      	je	0x59c98 <f.6+0x158>
   59bcd:      	testb	$0x1, %al
   59bcf:      	jne	0x59c98 <f.6+0x158>
   59bd5:      	cmpq	0x8(%rax), %r14
   59bd9:      	jae	0x59c98 <f.6+0x158>
   59bdf:      	movq	0x10(%rbx), %rcx
   59be3:      	testq	%rcx, %rcx
   59be6:      	je	0x59c98 <f.6+0x158>
   59bec:      	testb	$0x1, %cl
   59bef:      	jne	0x59c98 <f.6+0x158>
   59bf5:      	cmpq	0x8(%rcx), %r14
   59bf9:      	jae	0x59c98 <f.6+0x158>
   59bff:      	movq	0x10(%rax,%r14,8), %rax
   59c04:      	movq	%rax, 0x10(%rcx,%r14,8)
   59c09:      	movq	0x20(%rsp), %rbx
   59c0e:      	testq	%rbx, %rbx
   59c11:      	je	0x59c98 <f.6+0x158>
   59c17:      	movq	0x18(%rbx), %rax
   59c1b:      	testq	%rax, %rax
   59c1e:      	je	0x59c98 <f.6+0x158>
   59c20:      	cmpl	$0x0, 0x8(%rax)
   59c24:      	je	0x59c98 <f.6+0x158>
   59c26:      	cmpq	$0x0, 0x10(%rax)
   59c2b:      	je	0x59c98 <f.6+0x158>
   59c2d:      	movq	%r15, %rdi
   59c30:      	callq	0x2a070 <native_roots_leave>
   59c35:      	movq	%r15, %rdi
   59c38:      	xorl	%esi, %esi
   59c3a:      	callq	0x2a020 <native_roots_enter>
   59c3f:      	addq	$-0x1, %r14
   59c43:      	movq	%rbx, 0x18(%rsp)
   59c48:      	movq	$0x0, 0x8(%r12)
   59c51:      	movq	$0x0, (%r12)
   59c59:      	jb	0x59b90 <f.6+0x50>
   59c5f:      	movl	$0x6, %esi
   59c64:      	movq	%rbx, %rdi
   59c67:      	xorl	%edx, %edx
   59c69:      	xorl	%ecx, %ecx
   59c6b:      	callq	0x29f30 <native_ref_test>
   59c70:      	testl	%eax, %eax
   59c72:      	je	0x59c98 <f.6+0x158>
   59c74:      	testq	%rbx, %rbx
   59c77:      	je	0x59c98 <f.6+0x158>
   59c79:      	movq	0x10(%rbx), %rbx
   59c7d:      	movq	%rsp, %rdi
   59c80:      	callq	0x2a070 <native_roots_leave>
   59c85:      	movq	%rbx, %rax
   59c88:      	addq	$0x30, %rsp
   59c8c:      	popq	%rbx
   59c8d:      	popq	%r12
   59c8f:      	popq	%r13
   59c91:      	popq	%r14
   59c93:      	popq	%r15
   59c95:      	retq	$0x8
   59c98:      	callq	0x25cf0 <native_trap>
   59c9d:      	int3
   59c9e:      	int3
   59c9f:      	int3

0000000000059ca0 <f.7>:
   59ca0:      	pushq	%rbp
   59ca1:      	pushq	%r15
   59ca3:      	pushq	%r14
   59ca5:      	pushq	%r13
   59ca7:      	pushq	%r12
   59ca9:      	pushq	%rbx
   59caa:      	subq	$0x58, %rsp
   59cae:      	movq	%rsi, %rbx
   59cb1:      	movq	%rdi, %r14
   59cb4:      	leaq	0x8(%rsp), %rdi
   59cb9:      	movl	$0x7, %esi
   59cbe:      	callq	0x2a020 <native_roots_enter>
   59cc3:      	movq	%r14, 0x20(%rsp)
   59cc8:      	movq	%rbx, %rax
   59ccb:      	shrq	$0x20, %rax
   59ccf:      	movq	$0x0, 0x28(%rsp)
   59cd8:      	movq	$0x0, 0x30(%rsp)
   59ce1:      	jne	0x59e71 <f.7+0x1d1>
   59ce7:      	movq	$0x3, 0x18(%rsp)
   59cf0:      	movl	$0x18, %edi
   59cf5:      	callq	0x27c90 <native_alloc>
   59cfa:      	testq	%rax, %rax
   59cfd:      	je	0x59e71 <f.7+0x1d1>
   59d03:      	movq	%rax, %r14
   59d06:      	movq	$0x1a, (%rax)
   59d0d:      	movl	$0x0, 0x8(%rax)
   59d14:      	movq	$0x0, 0x10(%rax)
   59d1c:      	movq	%rax, 0x28(%rsp)
   59d21:      	leaq	0x3380(%rip), %r13      # 0x5d0a8 <ref.8>
   59d28:      	movq	%r13, 0x38(%rsp)
   59d2d:      	movq	%rax, 0x40(%rsp)
   59d32:      	movq	$0x5, 0x18(%rsp)
   59d3b:      	movl	$0x17, %edi
   59d40:      	movl	%ebx, %esi
   59d42:      	xorl	%edx, %edx
   59d44:      	movl	$0x8, %ecx
   59d49:      	callq	0x29c60 <native_array_new>
   59d4e:      	movq	%rax, %r12
   59d51:      	movq	%rax, 0x38(%rsp)
   59d56:      	movq	%r13, 0x40(%rsp)
   59d5b:      	movq	%r14, 0x48(%rsp)
   59d60:      	movq	$0x6, 0x18(%rsp)
   59d69:      	movl	$0x10, %edi
   59d6e:      	callq	0x27c90 <native_alloc>
   59d73:      	testq	%rax, %rax
   59d76:      	je	0x59e71 <f.7+0x1d1>
   59d7c:      	movq	%rax, %r15
   59d7f:      	movq	$0x12, (%rax)
   59d86:      	movq	%r12, 0x8(%rax)
   59d8a:      	movq	0x28(%rsp), %rbp
   59d8f:      	movq	%rbp, 0x38(%rsp)
   59d94:      	movq	%rax, 0x40(%rsp)
   59d99:      	movq	%r13, 0x48(%rsp)
   59d9e:      	movq	%r14, 0x50(%rsp)
   59da3:      	movq	$0x7, 0x18(%rsp)
   59dac:      	movl	$0x20, %edi
   59db1:      	callq	0x27c90 <native_alloc>
   59db6:      	testq	%rax, %rax
   59db9:      	je	0x59e71 <f.7+0x1d1>
   59dbf:      	movq	%rax, %r12
   59dc2:      	movq	$0xe, (%rax)
   59dc9:      	movq	%rbx, 0x8(%rax)
   59dcd:      	movq	%r15, 0x10(%rax)
   59dd1:      	movq	%rbp, 0x18(%rax)
   59dd5:      	movq	%rax, 0x38(%rsp)
   59dda:      	movq	%r13, 0x40(%rsp)
   59ddf:      	movq	%r14, 0x48(%rsp)
   59de4:      	movq	$0x6, 0x18(%rsp)
   59ded:      	movl	$0x18, %edi
   59df2:      	callq	0x27c90 <native_alloc>
   59df7:      	testq	%rax, %rax
   59dfa:      	je	0x59e71 <f.7+0x1d1>
   59dfc:      	movq	$0x36, (%rax)
   59e03:      	movq	%r13, 0x8(%rax)
   59e07:      	movq	%r12, 0x10(%rax)
   59e0b:      	movq	%rax, 0x10(%r14)
   59e0f:      	movq	0x28(%rsp), %rax
   59e14:      	testq	%rax, %rax
   59e17:      	je	0x59e71 <f.7+0x1d1>
   59e19:      	movl	$0x1, 0x8(%rax)
   59e20:      	movq	0x28(%rsp), %rax
   59e25:      	testq	%rax, %rax
   59e28:      	je	0x59e71 <f.7+0x1d1>
   59e2a:      	cmpl	$0x0, 0x8(%rax)
   59e2e:      	je	0x59e71 <f.7+0x1d1>
   59e30:      	movq	0x10(%rax), %rax
   59e34:      	testq	%rax, %rax
   59e37:      	je	0x59e71 <f.7+0x1d1>
   59e39:      	movq	%rax, 0x30(%rsp)
   59e3e:      	movq	0x8(%rax), %rcx
   59e42:      	testq	%rcx, %rcx
   59e45:      	je	0x59e71 <f.7+0x1d1>
   59e47:      	movq	0x10(%rax), %rbx
   59e4b:      	movq	0x8(%rcx), %r14
   59e4f:      	leaq	0x8(%rsp), %rdi
   59e54:      	callq	0x2a070 <native_roots_leave>
   59e59:      	movq	%rbx, %rdi
   59e5c:      	xorl	%esi, %esi
   59e5e:      	movq	%r14, %rax
   59e61:      	addq	$0x58, %rsp
   59e65:      	popq	%rbx
   59e66:      	popq	%r12
   59e68:      	popq	%r13
   59e6a:      	popq	%r14
   59e6c:      	popq	%r15
   59e6e:      	popq	%rbp
   59e6f:      	jmpq	*%rax
   59e71:      	callq	0x25cf0 <native_trap>
   59e76:      	int3
   59e77:      	int3
   59e78:      	int3
   59e79:      	int3
   59e7a:      	int3
   59e7b:      	int3
   59e7c:      	int3
   59e7d:      	int3
   59e7e:      	int3
   59e7f:      	int3

0000000000059e80 <f.8>:
   59e80:      	pushq	%r15
   59e82:      	pushq	%r14
   59e84:      	pushq	%rbx
   59e85:      	subq	$0x30, %rsp
   59e89:      	movq	%rsi, %rbx
   59e8c:      	movq	%rdi, %r14
   59e8f:      	leaq	0x8(%rsp), %rdi
   59e94:      	xorl	%esi, %esi
   59e96:      	callq	0x2a020 <native_roots_enter>
   59e9b:      	movq	%r14, 0x20(%rsp)
   59ea0:      	movq	$0x0, 0x28(%rsp)
   59ea9:      	movl	$0xe, %esi
   59eae:      	movq	%r14, %rdi
   59eb1:      	xorl	%edx, %edx
   59eb3:      	xorl	%ecx, %ecx
   59eb5:      	callq	0x29f30 <native_ref_test>
   59eba:      	testl	%eax, %eax
   59ebc:      	je	0x59f6e <f.8+0xee>
   59ec2:      	leaq	0x8(%rsp), %r15
   59ec7:      	nopw	(%rax,%rax)
   59ed0:      	movq	%r14, 0x28(%rsp)
   59ed5:      	testq	%r14, %r14
   59ed8:      	je	0x59f6e <f.8+0xee>
   59ede:      	cmpq	%rbx, 0x8(%r14)
   59ee2:      	jle	0x59f73 <f.8+0xf3>
   59ee8:      	movq	%rbx, %rax
   59eeb:      	shrq	$0x20, %rax
   59eef:      	jne	0x59f6e <f.8+0xee>
   59ef1:      	movq	0x10(%r14), %rax
   59ef5:      	testq	%rax, %rax
   59ef8:      	je	0x59f6e <f.8+0xee>
   59efa:      	movq	0x8(%rax), %rax
   59efe:      	testq	%rax, %rax
   59f01:      	je	0x59f6e <f.8+0xee>
   59f03:      	testb	$0x1, %al
   59f05:      	jne	0x59f6e <f.8+0xee>
   59f07:      	cmpq	0x8(%rax), %rbx
   59f0b:      	jae	0x59f6e <f.8+0xee>
   59f0d:      	movq	%rbx, 0x10(%rax,%rbx,8)
   59f12:      	movq	0x28(%rsp), %r14
   59f17:      	testq	%r14, %r14
   59f1a:      	je	0x59f6e <f.8+0xee>
   59f1c:      	movq	0x18(%r14), %rax
   59f20:      	testq	%rax, %rax
   59f23:      	je	0x59f6e <f.8+0xee>
   59f25:      	cmpl	$0x0, 0x8(%rax)
   59f29:      	je	0x59f6e <f.8+0xee>
   59f2b:      	cmpq	$0x0, 0x10(%rax)
   59f30:      	je	0x59f6e <f.8+0xee>
   59f32:      	incq	%rbx
   59f35:      	movq	%r15, %rdi
   59f38:      	callq	0x2a070 <native_roots_leave>
   59f3d:      	movq	%r15, %rdi
   59f40:      	xorl	%esi, %esi
   59f42:      	callq	0x2a020 <native_roots_enter>
   59f47:      	movq	%r14, 0x20(%rsp)
   59f4c:      	movq	$0x0, 0x28(%rsp)
   59f55:      	movl	$0xe, %esi
   59f5a:      	movq	%r14, %rdi
   59f5d:      	xorl	%edx, %edx
   59f5f:      	xorl	%ecx, %ecx
   59f61:      	callq	0x29f30 <native_ref_test>
   59f66:      	testl	%eax, %eax
   59f68:      	jne	0x59ed0 <f.8+0x50>
   59f6e:      	callq	0x25cf0 <native_trap>
   59f73:      	movq	0x10(%r14), %rax
   59f77:      	testq	%rax, %rax
   59f7a:      	je	0x59f6e <f.8+0xee>
   59f7c:      	movq	0x8(%rax), %rbx
   59f80:      	leaq	0x8(%rsp), %rdi
   59f85:      	callq	0x2a070 <native_roots_leave>
   59f8a:      	movq	%rbx, %rax
   59f8d:      	addq	$0x30, %rsp
   59f91:      	popq	%rbx
   59f92:      	popq	%r14
   59f94:      	popq	%r15
   59f96:      	retq	$0x8
   59f99:      	int3
   59f9a:      	int3
   59f9b:      	int3
   59f9c:      	int3
   59f9d:      	int3
   59f9e:      	int3
   59f9f:      	int3
